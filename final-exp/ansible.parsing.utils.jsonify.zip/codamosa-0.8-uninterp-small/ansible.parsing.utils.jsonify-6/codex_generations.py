

# Generated at 2022-06-25 04:11:33.448770
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(b'') == "{}"
    assert jsonify(b'') == "{}"
    assert jsonify(None) == "{}"
    assert jsonify(None) == "{}"
    assert jsonify(b'bar') == "\"bar\""
    assert jsonify(b'bar') == "\"bar\""
    assert jsonify(b'bar') == "\"bar\""
    assert jsonify(b'bar') == "\"bar\""
    assert jsonify({b'a': b'1', b'c': b'2', b'b': b'3'}) == "{\"a\": \"1\", \"b\": \"3\", \"c\": \"2\"}"

# Generated at 2022-06-25 04:11:41.200131
# Unit test for function jsonify
def test_jsonify():
    """Unit test for the jsonify() function"""

    assert jsonify({"X": {"Y": 4}}, format=True) == '''{
    "X": {
        "Y": 4
    }
}'''

    # test with ascii and non-ascii data
    assert jsonify({"X": {"Y": 4, "Z": b"\xc4"}}, format=True) == '''{
    "X": {
        "Y": 4,
        "Z": "\\u00c4"
    }
}'''
    assert jsonify({"X": {"Y": 4, "Z": b"\xc4"}}) == '''{"X":{"Y":4,"Z":"\\u00c4"}}'''


# Test boilerplate

# Generated at 2022-06-25 04:11:44.648493
# Unit test for function jsonify
def test_jsonify():
    try:
        # Test case 1
        bytes_1 = b''
        var_1 = jsonify(bytes_1)
        assert var_1 == "{}"
    except AssertionError as e:
        print("AssertionError: {}".format(e))
        raise e

# Generated at 2022-06-25 04:11:45.887716
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(b'', format=False) == '{}'

# Generated at 2022-06-25 04:11:50.081913
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'
    assert '"2"' in jsonify({'foo': 2})
    assert '"2"' in jsonify({'foo': 2}, format=True)

# Generated at 2022-06-25 04:11:51.845995
# Unit test for function jsonify
def test_jsonify():
    bytes_0 = b''
    var_0 = jsonify(bytes_0)
    assert var_0 == "{}"

# Generated at 2022-06-25 04:12:02.123585
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None, False) == '{}', 'Expected call to jsonify(None, False) to return "{}".'
    assert jsonify(None, True) == '{}', 'Expected call to jsonify(None, True) to return "{}".'
    assert jsonify(0, True) == '0', 'Expected call to jsonify(0, True) to return "0".'
    assert jsonify(0, False) == '0', 'Expected call to jsonify(0, False) to return "0".'
    assert jsonify('', True) == '""', 'Expected call to jsonify(\'\', True) to return "\\"\\"".'
    assert jsonify('', False) == '""', 'Expected call to jsonify(\'\', False) to return "\\"\\"".'

# Generated at 2022-06-25 04:12:05.027834
# Unit test for function jsonify
def test_jsonify():
    print('Testing jsonify')
    print('function jsonify passed all tests.')

# Unit tests to check if jsonify function throws exceptions

# Generated at 2022-06-25 04:12:06.764929
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(bytes([])), '{}'



# Generated at 2022-06-25 04:12:10.019248
# Unit test for function jsonify
def test_jsonify():
    try:
        test_case_0()
    except Exception as exc:
        import traceback
        print(traceback.format_exc())
        assert False, "Failed test_case_0: %s" % exc

# vim: set expandtab shiftwidth=4 tabstop=4 softtabstop=4

# Generated at 2022-06-25 04:12:25.179219
# Unit test for function jsonify

# Generated at 2022-06-25 04:12:27.636493
# Unit test for function jsonify
def test_jsonify():
    assert var_0 == "{}"

# Generated at 2022-06-25 04:12:35.646395
# Unit test for function jsonify
def test_jsonify():

    # Literal_Values
    bytes_0 = b''
    var_0 = jsonify(bytes_0)
    str_0 = "''"
    assert var_0 == str_0

    bytes_1 = b'\x00\xff'
    var_1 = jsonify(bytes_1)
    str_1 = "'\\x00\\xff'"
    assert var_1 == str_1

    bytes_2 = b'\x00\xff'
    var_2 = jsonify(bytes_2)
    str_2 = "'\\x00\\xff'"
    assert var_2 == str_2

    bytes_3 = b'{"a": "b"}'
    var_3 = jsonify(bytes_3)
    str_3 = "'{\"a\": \"b\"}'"
    assert var_3 == str_

# Generated at 2022-06-25 04:12:42.558704
# Unit test for function jsonify
def test_jsonify():
    f = open('data_jsonify.json', 'r')
    jstr = f.read()
    f.close()
    assert jsonify(json.loads(jstr)) == json.dumps(json.loads(jstr), indent=4, ensure_ascii=False)


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:12:46.122013
# Unit test for function jsonify
def test_jsonify():
    with open('fixtures/test.json') as f:
        var_0 = json.load(f)
    jsonify(var_0)



# Generated at 2022-06-25 04:12:50.839400
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(None)
    assert result == '{}'
    
    result = jsonify('foo-bar')
    assert result == '"foo-bar"'

    result = jsonify(13)
    assert result == '13'

    result = jsonify({'test': [1,2,3]})
    assert result == '{"test": [1, 2, 3]}'

    result = jsonify({'test': [1,2,3]}, True)
    assert result == '''{
    "test": [
        1,
        2,
        3
    ]
}'''

    # This is the only case where the for and the test should differ.
    # We test for the correct behavior and to make sure the function itself
    # does not crash on it
    result = jsonify(test_case_0)

# Generated at 2022-06-25 04:12:51.558394
# Unit test for function jsonify
def test_jsonify():
    assert jsonify == '''{}'''


# Generated at 2022-06-25 04:12:52.486912
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({'a': 1})
    expected = "{\"a\": 1}"
    assert result == expected

# Generated at 2022-06-25 04:12:58.808016
# Unit test for function jsonify
def test_jsonify():
    """Unit test for function jsonify"""
    assert True
    # var_0 = '{"_ansible_builtins": {"Absent": {"true": true, "name": "Absent"}, "AllowModuleDowngrade": {"name": "AllowModuleDowngrade"}, "Archive": {"dest": {"required": true, "type": "path"}, "default_options": "", "path": {"required": true, "type": "path"}, "no_log": {"default": false, "type": "bool"}, "original_basename": {}, "follow": {"default": "no", "type": "bool"}, "recurse": {"default": "no", "type": "bool"}, "validate_certs": {"default": true, "type": "bool"}, "format": {"default": "", "type": "str"}, "exclude": {"default": "", "type": "

# Generated at 2022-06-25 04:13:08.548283
# Unit test for function jsonify
def test_jsonify():
    bytes_0 = b''
    var_0 = jsonify(bytes_0)
    assert var_0 == '{}'
    bytes_1 = b'\x80\xd3\xcd\xb3\xca\xd5\x0b'
    var_1 = jsonify(bytes_1)
    assert var_1 == '"\\u0080\\u00d3\\u00cd\\u00b3\\u00ca\\u00d5\\u000b"'
    bytes_2 = b'\xfe'
    var_2 = jsonify(bytes_2)
    assert var_2 == '"\\u00fe"'
    bytes_3 = b'\xfa\xbf\xbf'
    var_3 = jsonify(bytes_3)
    assert var_3 == '"\\ufffd"'

# Generated at 2022-06-25 04:13:15.651384
# Unit test for function jsonify
def test_jsonify():
    var_0 = json.dumps({u'invocation': {u'module_args': {u'hostname': u'foo.example.com', u'username': u'admin', u'name': u'foo.example.com', u'password': u'', u'filter': u'', u'validate_certs': True}}}, sort_keys=True, indent=4, ensure_ascii=False)
    var_1 = jsonify({u'invocation': {u'module_args': {u'hostname': u'foo.example.com', u'username': u'admin', u'name': u'foo.example.com', u'password': u'', u'filter': u'', u'validate_certs': True}}}, format=True)

# Generated at 2022-06-25 04:13:16.419581
# Unit test for function jsonify
def test_jsonify():
    pass


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:13:22.997696
# Unit test for function jsonify
def test_jsonify():
    print("Calling jsonify()")
    var_0 = b''
    var_0 = jsonify(var_0)
    print("Passed!")


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:13:31.565673
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(None)
    print(result)
    assert result == "{}"

    result = jsonify(None, True)
    print(result)
    assert result == "{}"

    result = jsonify(1, False)
    print(result)
    assert result == "1"

    result = jsonify(1)
    print(result)
    assert result == "1"

    result = jsonify({u"0": u"0"})
    print(result)
    assert result == "{\"0\": \"0\"}"

    result = jsonify({u"0": {u"0": u"0"}})
    print(result)
    assert result == "{\"0\": {\"0\": \"0\"}}"

# Generated at 2022-06-25 04:13:34.163303
# Unit test for function jsonify
def test_jsonify():
    """
    Basic test to ensure that the function properly handles jsonifying a unicode string
    """
    input = b'{ "unicode_string": "bonjour" }'
    output = jsonify(input)
    assert output == '{"unicode_string": "bonjour"}'

# Generated at 2022-06-25 04:13:40.572491
# Unit test for function jsonify
def test_jsonify():
    '''
    Test for the jsonify function
    '''
    test_case_0()


if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-25 04:13:43.535605
# Unit test for function jsonify
def test_jsonify():
    print(jsonify(None))

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:13:45.125436
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(b"b''") == '"b\'\'"'

# Generated at 2022-06-25 04:13:50.208329
# Unit test for function jsonify
def test_jsonify():
    with open('test_jsonify.json', 'r') as f:
        tests = json.load(f)

    for test in tests:
        yield (check_jsonify, test['result'], test['input'])


# Generated at 2022-06-25 04:13:52.702317
# Unit test for function jsonify
def test_jsonify():
    assert (test_case_0() == "{}")

test_jsonify()

# Generated at 2022-06-25 04:14:03.369555
# Unit test for function jsonify
def test_jsonify():
    jsonify(None, False)
    jsonify("", False)
    jsonify("", True)
    jsonify("", True)
    jsonify("{}", False)
    jsonify("{}", True)
    jsonify("{}", False)
    jsonify("{}", True)
    jsonify("[]", False)
    jsonify("[]", True)
    jsonify("[]", False)
    jsonify("[]", True)
    jsonify("null", True)
    jsonify("null", False)
    jsonify("null", False)
    jsonify("null", True)
    jsonify("true", True)
    jsonify("true", False)
    jsonify("true", False)
    jsonify("true", True)
    jsonify("false", True)
    jsonify("false", False)


# Generated at 2022-06-25 04:14:06.149581
# Unit test for function jsonify
def test_jsonify():
    ret = jsonify({'v': 'foo', 'b': 'true'})
    assert ret == '{"b": "true", "v": "foo"}'

    ret = jsonify({'v': 'foo', 'b': 'true'}, True)
    assert ret == '{\n    "b": "true",\n    "v": "foo"\n}'

    ret = jsonify(None)
    assert ret == '{}'

# Generated at 2022-06-25 04:14:16.165573
# Unit test for function jsonify
def test_jsonify():
    bytes_0 = b''
    var_0 = jsonify(bytes_0)
    bytes_1 = b'bytes_1'
    var_1 = jsonify(bytes_1)
    bytes_2 = b'bytes_2'
    var_2 = jsonify(bytes_2)
    str_3 = 'str_3'
    var_3 = jsonify(str_3)
    str_4 = 'str_4'
    var_4 = jsonify(str_4)
    dict_5 = dict(a=1, b=2)
    var_5 = jsonify(dict_5)
    list_6 = [list(), list(), list(), list()]
    var_6 = jsonify(list_6)
    tuple_7 = (1, 2, 3, 4)
    var_7 = jsonify

# Generated at 2022-06-25 04:14:19.795521
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify('') == '{}'
    assert jsonify('""') == '{}'
    assert jsonify('["foo"]') == '["foo"]'
    assert jsonify('{"bar":"baz"}') == '{"bar": "baz"}'
    assert jsonify('{"bar":"baz", "foo":"blah"}') == '{"bar": "baz", "foo": "blah"}'

# Generated at 2022-06-25 04:14:23.149409
# Unit test for function jsonify
def test_jsonify():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 04:14:23.747357
# Unit test for function jsonify
def test_jsonify():
    test_case_0()


test_jsonify()

# Generated at 2022-06-25 04:14:24.718932
# Unit test for function jsonify
def test_jsonify():
    assert isinstance(jsonify(None), basestring)

# Generated at 2022-06-25 04:14:27.547162
# Unit test for function jsonify
def test_jsonify():
    # test_case_0
    assert jsonify(b'', format=True) == '{}'
    assert jsonify(b'', format=False) == '{}'

# Generated at 2022-06-25 04:14:34.863982
# Unit test for function jsonify
def test_jsonify():
    # Change this to the path to the test file
    json_path = '/path/to/test/file'
    result = jsonify(json_path)
    pass


# Generated at 2022-06-25 04:14:40.021967
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Local variables:
# tab-width: 4
# c-basic-offset: 4
# indent-tabs-mode: nil
# coding: utf-8
# End:
# vim: fileencoding=utf-8 filetype=python :

# Generated at 2022-06-25 04:14:53.052935
# Unit test for function jsonify
def test_jsonify():
    sample_0 = {'foo': 'bar'}
    sample_1 = {'foo': 'bar'}
    sample_2 = {'foo': 'bar'}
    sample_3 = b'abc'
    sample_4 = u'abc'
    sample_5 = [1, 2, 3]
    sample_6 = [4, 5, 6]
    var_0 = jsonify(sample_0)
    var_1 = jsonify(sample_1, True)
    var_2 = jsonify(sample_2)
    var_3 = jsonify(sample_3)
    var_4 = jsonify(sample_4)
    var_5 = jsonify(sample_5)
    var_6 = jsonify(sample_6)

    assert var_0 == u'{"foo": "bar"}'

# Generated at 2022-06-25 04:15:01.758200
# Unit test for function jsonify
def test_jsonify():
    # The line below is actual test code
    # The line below is actual test code
    # The line below is actual test code
    # The line below is actual test code
    assert json.loads(jsonify({'a': 'b'})) == {u'a': u'b'}

    # The line below is actual test code
    # The line below is actual test code
    # The line below is actual test code
    # The line below is actual test code
    assert json.loads(jsonify({'a': u'b'})) == {u'a': u'b'}

    # The line below is actual test code
    # The line below is actual test code
    # The line below is actual test code
    # The line below is actual test code

# Generated at 2022-06-25 04:15:11.647301
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'test': 1}, True).decode("utf-8") == '{\n    "test": 1\n}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 2, 'b': 1}) == '{"a": 2, "b": 1}'
    assert jsonify({'b': 2, 'a': 1}) == '{"a": 1, "b": 2}'
    assert jsonify({'b': 1, 'a': 2}) == '{"a": 2, "b": 1}'
    assert jsonify(None) == "{}"
    assert jsonify({'a': {'b': {'c': 0}}}) == '{"a": {"b": {"c": 0}}}'

# Generated at 2022-06-25 04:15:16.586163
# Unit test for function jsonify

# Generated at 2022-06-25 04:15:22.781944
# Unit test for function jsonify
def test_jsonify():
    var_0 = b"{\'msg\': u\'All items completed\', \'failed\': False, \'changed\': True}"
    var_1 = jsonify(var_0, False)
    var_2 = b"{\'failed\': False, \'parsed\': True, \'changed\': True, \'results\': []}"
    var_3 = jsonify(var_2, False)

# Generated at 2022-06-25 04:15:31.194253
# Unit test for function jsonify
def test_jsonify():
    # Make sure we're testing something
    assert json.dumps({'a': 'b'}) == '{"a": "b"}'
    # JSONify a dict
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    # JSONify an array
    assert jsonify(['a', 'b']) == '["a", "b"]'
    # JSONify a string
    assert jsonify('foobar') == '"foobar"'
    # JSONify floats/ints/bools
    assert jsonify(1.1) == '1.1'
    assert jsonify(1) == '1'
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    assert jsonify(None) == 'null'
    # JSONify a unicode string

# Generated at 2022-06-25 04:15:37.653475
# Unit test for function jsonify
def test_jsonify():
    # byte input test
    bytes_0 = b'test'
    json_bytes_0 = jsonify(bytes_0)
    if json_bytes_0 != '"test"':
        print("error: jsonify(b'test') != '\"test\"'")
        test_case_0()
    # unicode test
    unicode_0 = "test"
    json_unicode_0 = jsonify(unicode_0)
    if json_unicode_0 != '"test"':
        print("error: jsonify(u'test') != '\"test\"'")
    # list test
    list_0 = [1, 2, 3]
    json_list_0 = jsonify(list_0)

# Generated at 2022-06-25 04:15:40.240900
# Unit test for function jsonify

# Generated at 2022-06-25 04:15:43.266066
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify('') == '{}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-25 04:15:52.629278
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify
    from ansible.utils.unicode import to_unicode

    test_cases = [
        {
            'input': {'a': 1, 'b': 2, 'c': 3},
            'output': u'{"a": 1, "b": 2, "c": 3}',
            'minified': True
        },
        {
            'input': {'a': 1, 'b': 2, 'c': 3},
            'output': to_unicode(r"""{
    "a": 1,
    "b": 2,
    "c": 3
}"""),
            'minified': False
        },
    ]

    for case in test_cases:
        yield check_jsonify, case['input'], case['output'], case['minified']



# Generated at 2022-06-25 04:16:11.684615
# Unit test for function jsonify
def test_jsonify():
    var_1 = jsonify({u'changed': False, u'msg': u'[Errno 2] No such file or directory', u'invocation': {u'module_args': {u'username': None, u'path': u'/home/foo/sample', u'force': False, u'state': u'directory', u'group': None, u'other': None, u'conf_file': u'None', u'src': None, u'secret': None, u'owner': None}, u'module_name': u'file'}, u'failed': True, u'rc': 2})

# Generated at 2022-06-25 04:16:17.525825
# Unit test for function jsonify
def test_jsonify():
    try:
        test_case_0()
        success_case = True
    except Exception as e:
        print("Exception occured while processing test case: " + str(e))
        success_case = False
    finally:
        assert success_case

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:16:20.675798
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:16:25.683544
# Unit test for function jsonify
def test_jsonify():
    print("Testing jsonify")

    data = {
        "a": "simple string",
        "c": 5,
        "b": [1, 2, 3, 4],
        "d": { "one": 1, "two": 2 }
    }
    assert jsonify(data) == """{
    "a": "simple string", 
    "b": [
        1, 
        2, 
        3, 
        4
    ], 
    "c": 5, 
    "d": {
        "one": 1, 
        "two": 2
    }
}"""

# Generated at 2022-06-25 04:16:29.319736
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    assert jsonify(None) == '{}'
    assert jsonify([None]) == '[{}]'

# Generated at 2022-06-25 04:16:36.182042
# Unit test for function jsonify
def test_jsonify():
    try:
        test_case_0()
    except:
        import traceback
        details = traceback.format_exc()
        print("\n*** TEST FAILED ***\n")
        print(details)
        assert False
    else:
        print("\n*** TEST PASSED ***\n")
        assert True

if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-25 04:16:37.124172
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == "{}"

# Generated at 2022-06-25 04:16:46.500382
# Unit test for function jsonify

# Generated at 2022-06-25 04:16:54.566599
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(b'') == '{}'
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    assert jsonify(None) == 'null'
    assert jsonify(1) == '1'
    assert jsonify(1.0) == '1.0'
    assert jsonify('one') == '"one"'
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify(['a', 'b']) == '["a", "b"]'

# Generated at 2022-06-25 04:17:06.277513
# Unit test for function jsonify
def test_jsonify():
    test_case_0()
    print("Test finished")

# test_jsonify()

# Each test case is a file
# The name of the file is 0...N.py
import glob
import importlib.util
import os

import pytest

import vrnetlab

# Dynamically create tests for every file in test_cases directory
tests_dir = os.path.dirname(os.path.realpath(__file__))
test_case_files = glob.glob(tests_dir + "/test_cases/*.py")
test_case_ids = [os.path.basename(test_case_file).replace('.py', '') for test_case_file in test_case_files]



# Generated at 2022-06-25 04:17:30.539603
# Unit test for function jsonify
def test_jsonify():
    assert {"a": "b"} == jsonify(u'{"a": "b"}')
    #assert '{}' == jsonify(None)

# Generated at 2022-06-25 04:17:40.507249
# Unit test for function jsonify
def test_jsonify():
    # Replace these examples with your own test cases
    assert callable(jsonify)
    bytes_0 = b''
    var_0 = jsonify(bytes_0)
    bytes_1 = b''
    var_1 = jsonify(bytes_1)
    bytes_2 = b''
    var_2 = jsonify(bytes_2)
    bytes_3 = b''
    var_3 = jsonify(bytes_3)
    bytes_4 = b''
    var_4 = jsonify(bytes_4)
    bytes_5 = b''
    var_5 = jsonify(bytes_5)
    bytes_6 = b''
    var_6 = jsonify(bytes_6)
    bytes_7 = b'#!/usr/bin/env python'
    var_7 = jsonify(bytes_7)
    bytes

# Generated at 2022-06-25 04:17:42.114799
# Unit test for function jsonify
def test_jsonify():
    assert 0 == test_case_0()

# Generated at 2022-06-25 04:17:51.493650
# Unit test for function jsonify
def test_jsonify():
    bytes_0 = b''
    var_0 = jsonify(bytes_0)
    assert var_0 == "{}"
    bytes_0 = b'{"changed": false, "ping": "pong"}'
    var_0 = jsonify(bytes_0)
    assert var_0 == '{"changed": false, "ping": "pong"}'
    bytes_0 = b'{"changed": false, "ping": "pong"}'
    var_0 = jsonify(bytes_0, False)
    assert var_0 == '{"changed": false, "ping": "pong"}'
    bytes_0 = b'{"changed": false, "ping": "pong"}'
    var_0 = jsonify(bytes_0, True)

# Generated at 2022-06-25 04:17:52.107391
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:17:55.372034
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(None)
    assert result == '{}'

    result = jsonify({'key': 'value'})
    assert result == '{"key": "value"}'

    result = jsonify({'key': 'value'}, format=True)
    assert result == '{\n    "key": "value"\n}'

    result = jsonify({'key': 'value%s' % chr(0)})
    assert result == '{"key": "value\\u0000"}'

# Generated at 2022-06-25 04:17:58.925780
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import basic

    #
    # Test case 0
    #

    test_case_0()


# Generated at 2022-06-25 04:18:02.447018
# Unit test for function jsonify
def test_jsonify():
    assert False


# Generated at 2022-06-25 04:18:03.047999
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'


# Generated at 2022-06-25 04:18:04.972200
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(b'', False) == b'{}'
    assert jsonify(b'', True) == b'{}'

# Generated at 2022-06-25 04:18:46.497873
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(b'',format=False) == "{}"
    assert jsonify(b'',format=True) == "{}"

# Generated at 2022-06-25 04:18:49.011748
# Unit test for function jsonify
def test_jsonify():
    result = jsonify('[u\'test1\', [u\'test2\', u\'test3\']]', False)
    assert result == '{}'

# Generated at 2022-06-25 04:18:57.047420
# Unit test for function jsonify
def test_jsonify():
    # b'' should be decoded to UTF-8 with ''
    bytes_0 = b''
    assert jsonify(bytes_0) == ''
    # b'abc' should be decoded to UTF-8 with 'abc'
    bytes_0 = b'abc'
    assert jsonify(bytes_0) == 'abc'
    # b'\xe3\x81\x82' should be decoded to UTF-8 with 'あ'
    bytes_0 = b'\xe3\x81\x82'
    assert jsonify(bytes_0) == 'あ'

# Generated at 2022-06-25 04:18:58.537661
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-25 04:19:05.557293
# Unit test for function jsonify
def test_jsonify():
    '''
    Test to format JSON output (uncompressed or uncompressed)
    :return: None
    '''

    result = {'ansible_facts': {'discovered_interpreter_python': '/usr/bin/python', 'vars': {'ansible_python_interpreter': '/usr/bin/python'}}, 'changed': False}
    jsonify(result, True)


if __name__ == '__main__':
    jsonify()

# Generated at 2022-06-25 04:19:09.940470
# Unit test for function jsonify
def test_jsonify():
    print('\n\nTESTING jsonify')
    var_1 = {'a': '1', 'b': '2', 'c': '3'}
    var_2 = jsonify(var_1)
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 04:19:11.224383
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import *
    test_case_0()


# Generated at 2022-06-25 04:19:11.951935
# Unit test for function jsonify
def test_jsonify():
    assert True

# Generated at 2022-06-25 04:19:20.199555
# Unit test for function jsonify

# Generated at 2022-06-25 04:19:21.288731
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify(b'') == '{}')

# Generated at 2022-06-25 04:20:03.605763
# Unit test for function jsonify
def test_jsonify():
    try:
        assert(test_case_0())
    except AssertionError:
        print("test_case_0 assertion failed")

test_jsonify()

# Generated at 2022-06-25 04:20:07.838022
# Unit test for function jsonify
def test_jsonify():
    print('Testing jsonify')
    bytes_0 = b'\x7b\x22\x7d'
    str_0 = '%c%c%c' % (123,34,125)
    test_case_0()
    assert str_0 == var_0, 'Test variable not equal: %c != %c' % (str_0, var_0)


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:20:08.499477
# Unit test for function jsonify
def test_jsonify():
    # @TODO
    pass

# Generated at 2022-06-25 04:20:17.684684
# Unit test for function jsonify
def test_jsonify():
    # Check for correct results of jsonify(result, format=False)
    var_0 = jsonify([1,2,3])
    assert var_0 == '[1,2,3]'

# -*- -*- -*- End included fragment: class/tests/ansible_base/test/test_jsonify.py -*- -*- -*-

# -*- -*- -*- Begin included fragment: class/tests/ansible_base/test/test_utils.py -*- -*- -*-

# (c) 2012-2014, Michael DeHaan <michael.dehaan@gmail.com>
#
# This file is part of Ansible
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by

# Generated at 2022-06-25 04:20:27.862506
# Unit test for function jsonify
def test_jsonify():
    bytes_1 = b'this is a test'
    assert jsonify(bytes_1) == json.dumps(
        bytes_1, sort_keys=True, indent=None, ensure_ascii=False)
    bytes_2 = b''
    assert jsonify(bytes_2) == json.dumps(
        bytes_2, sort_keys=True, indent=None, ensure_ascii=False)
    bytes_3 = b'{"var": "value"}'
    assert jsonify(bytes_3) == json.dumps(
        bytes_3, sort_keys=True, indent=None, ensure_ascii=False)

# Generated at 2022-06-25 04:20:29.676709
# Unit test for function jsonify
def test_jsonify():

  try:
    test_case_0()
  except Exception as err:
    import traceback
    traceback.print_tb(err.__traceback__)
    print('Exception from test: {0}'.format(err))

# Generated at 2022-06-25 04:20:31.239308
# Unit test for function jsonify
def test_jsonify():
    print('Testing jsonify')
    test_case_0()

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:20:32.934884
# Unit test for function jsonify
def test_jsonify():
    # this should not be accepted by the format checker
    test_case_0()


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:20:38.892815
# Unit test for function jsonify
def test_jsonify():
    res_0 = {"test_key": "test_value"}
    res_1 = {u"test_key": u"test_value"}
    res_2 = {"test_key_1": "test_value_1", "test_key_2": "test_value_2"}
    res_3 = {u"test_key_1": u"test_value_1", u"test_key_2": u"test_value_2"}
    res_4 = {"test_key": {"test_key_1": "test_value_1", "test_key_2": "test_value_2"}}
    res_5 = {u"test_key": {u"test_key_1": u"test_value_1", u"test_key_2": u"test_value_2"}}
    res_6

# Generated at 2022-06-25 04:20:41.499889
# Unit test for function jsonify
def test_jsonify():
    result_0 = jsonify(result=None)
    assert result_0 == "{}"
    result_1 = jsonify(result=None, format=True)
    assert result_1 == "{\n}\n"

