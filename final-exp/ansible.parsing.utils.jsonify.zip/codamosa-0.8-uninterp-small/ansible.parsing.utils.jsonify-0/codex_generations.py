

# Generated at 2022-06-25 04:11:27.753873
# Unit test for function jsonify
def test_jsonify():
    test_case_0()


# Generated at 2022-06-25 04:11:29.793835
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(list_0) == "{}"

# Generated at 2022-06-25 04:11:30.944813
# Unit test for function jsonify
def test_jsonify():
    print('Test # 0')
    test_case_0()

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:11:39.403555
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict_0) == json.dumps(dict_0, sort_keys=True, indent=4, ensure_ascii=False)
    assert jsonify(dict_1) == json.dumps(dict_1, sort_keys=True, indent=4, ensure_ascii=False)
    assert jsonify(dict_2) == json.dumps(dict_2, sort_keys=True, indent=4, ensure_ascii=False)
    assert jsonify(dict_3) == json.dumps(dict_3, sort_keys=True, indent=4, ensure_ascii=False)

# Generated at 2022-06-25 04:11:41.276930
# Unit test for function jsonify
def test_jsonify():
    # Case 0
    try:
        test_case_0()
    except Exception as e:
        print('Case 0 failed: ' + str(e))

# Generated at 2022-06-25 04:11:47.737829
# Unit test for function jsonify
def test_jsonify():
    test_cases = [
        (
            [
                []
            ],
            "{}"
        ),
        (
            [
                [1, 2]
            ],
            "[\n    1,\n    2\n]"
        ),
        (
            [
                [
                    [1, 2]
                ]
            ],
            "[\n    [\n        1,\n        2\n    ]\n]"
        )
    ]

    for test_case, expected in test_cases:
        assert jsonify(*test_case) == expected, 'Expected : %s\nGot: %s' % (expected, jsonify(*test_case))


test_case_0()
#test_jsonify()

# Generated at 2022-06-25 04:11:53.559089
# Unit test for function jsonify
def test_jsonify():
    list_0 = []
    test_object_0 = jsonify(list_0)
    assert test_object_0



# Generated at 2022-06-25 04:11:54.436803
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([]) == '[]'


# Generated at 2022-06-25 04:12:02.618681
# Unit test for function jsonify
def test_jsonify():
    j0 = {"skipped": False, "changed": False, "ping": "pong"}
    assert jsonify(j0) == '{"changed": false, "skipped": false, "ping": "pong"}'

    j1 = {"skipped": False, "changed": False, "ping": "pong"}
    assert jsonify(j1, format=True) == '''{
    "changed": false, 
    "skipped": false, 
    "ping": "pong"
}'''

    assert jsonify(None) == "{}"

    j2 = [{"skipped": False, "changed": False, "ping": "pong"}]

# Generated at 2022-06-25 04:12:11.311226
# Unit test for function jsonify
def test_jsonify():
    # Testing with a list
    result = jsonify(["apple", "banana", "cherry"])
    expected_result = '''[
    "apple",
    "banana",
    "cherry"
]'''
    assert result == expected_result

    # Testing with a list of dictionaries
    result = jsonify([
        {"name":"Tom", "age":10},
        {"name":"Sam", "age":50},
        {"name":"Bob", "age":20},
    ])
    expected_result = '''[
    {
        "age": 10,
        "name": "Tom"
    },
    {
        "age": 50,
        "name": "Sam"
    },
    {
        "age": 20,
        "name": "Bob"
    }
]'''
    assert result

# Generated at 2022-06-25 04:12:25.179423
# Unit test for function jsonify
def test_jsonify():
    list_0 = []
    var_0 = jsonify(list_0)
    assert var_0 == "{}"
    dict_0 = {}
    var_1 = jsonify(dict_0)
    assert var_1 == "{}"
    dict_1 = {"a":{"a":{"a":"\"a\""}}}
    var_2 = jsonify(dict_1)
    assert var_2 == '{"a": {"a": {"a": "\\"a\\""}}}'
    dict_2 = {"a":"a"}
    var_3 = jsonify(dict_2)
    assert var_3 == '{"a": "a"}'
    dict_3 = {"a":"\"a\""}
    var_4 = jsonify(dict_3)
    assert var_4 == '{"a": "\\"a\\""}'
   

# Generated at 2022-06-25 04:12:28.030063
# Unit test for function jsonify
def test_jsonify():
    results = []
    results.append(test_case_0())
    return results

# Generated at 2022-06-25 04:12:38.373709
# Unit test for function jsonify
def test_jsonify():
    input = [
        {"a": "b", "c": "d"},
        {"a": "b", "c": "d", "e": {"f": "g"}},
        [ {"a": "b", "c": "d"}, {"a": "b", "c": "d", "e": {"f": "g"}} ],
        None
    ]
    output = [
        '{"a": "b", "c": "d"}',
        '{"a": "b", "c": "d", "e": {"f": "g"}}',
        '[{"a": "b", "c": "d"}, {"a": "b", "c": "d", "e": {"f": "g"}}]',
        '{}'
    ]
    for i in range(0, len(input)):
        assert json

# Generated at 2022-06-25 04:12:43.475169
# Unit test for function jsonify
def test_jsonify():
    test_case_0()
    test_case_1()


if __name__ == '__main__':
    # Needs to be run with `python -m unit_tests.ansible.mcp.playbook.play_helpers`.
    test_jsonify()

# Generated at 2022-06-25 04:12:52.238477
# Unit test for function jsonify
def test_jsonify():
    from random import randint
    from random import shuffle
    from random import seed

    seed(1)

# Generated at 2022-06-25 04:12:58.655237
# Unit test for function jsonify

# Generated at 2022-06-25 04:13:08.526014
# Unit test for function jsonify
def test_jsonify():
    list_0 = []
    var_0 = jsonify(list_0)
    assert var_0 == '[]'
    string_0 = "json.dumps(result, sort_keys=True, indent=indent, ensure_ascii=False)"
    var_1 = jsonify(string_0)
    assert var_1 == '"json.dumps(result, sort_keys=True, indent=indent, ensure_ascii=False)"'
    tuple_0 = (1, 2, 3, '4', 5)
    var_2 = jsonify(tuple_0)
    assert var_2 == '[1, 2, 3, "4", 5]'
    dictionary_0 = {'foo': 'bar'}
    var_3 = jsonify(dictionary_0)

# Generated at 2022-06-25 04:13:16.480359
# Unit test for function jsonify
def test_jsonify():
    try:
        list_0 = []
        assert jsonify(list_0) == "{}"
        with open("tests/test.json") as var_0:
            var_1 = json.load(var_0)
        assert jsonify(var_1, True) == "{\n    \"ansible_facts\": {\n        \"foo\": 1,\n        \"bar\": 2\n    },\n    \"changed\": false,\n    \"invocation\": {\n        \"module_args\": {\n            \"bar\": 2,\n            \"foo\": 1\n        },\n        \"module_name\": \"test\"\n    }\n}"
    except AssertionError:
        raise
    except:
        print("Test Failed: The test 'test_jsonify' was not found")



# Generated at 2022-06-25 04:13:21.785794
# Unit test for function jsonify
def test_jsonify():
    list_0 = []
    assert jsonify(list_0) == "{}"

# Generated at 2022-06-25 04:13:23.150512
# Unit test for function jsonify
def test_jsonify():
    #Case 0:
    test_case_0()


# Generated at 2022-06-25 04:13:28.153097
# Unit test for function jsonify
def test_jsonify():
    test_cases = [{
        'input': {'test': 'hello'},
        'expected': '{"test": "hello"}',
    }]
    for test_case in test_cases:
        assert jsonify(test_case['input']) == test_case['expected']
    return True

# Generated at 2022-06-25 04:13:29.638664
# Unit test for function jsonify
def test_jsonify():
    # Check the case 0
    json = jsonify(1)
    assert(json == "1")


# Generated at 2022-06-25 04:13:31.688755
# Unit test for function jsonify
def test_jsonify():
    # import jsonify
    # print(jsonify(int_0))
    assert 0 == 0

if __name__ == '__main__':
    jsonify()

# Generated at 2022-06-25 04:13:32.391282
# Unit test for function jsonify
def test_jsonify():
    test_jsonify_0()


# Generated at 2022-06-25 04:13:33.934457
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(int_0)
    assert result == '{}', 'Expected different output than what was produced: %s' % result

# Generated at 2022-06-25 04:13:35.939770
# Unit test for function jsonify
def test_jsonify():
    data = "good"
    with patch('ansible.module_utils.basic.jsonify', return_value=data) as mock_jsonify:
        result = basic.jsonify(data)
        assert result == data

# Generated at 2022-06-25 04:13:37.640420
# Unit test for function jsonify
def test_jsonify():
    print('Test jsonify')
    print('Test Case 0')
    test_case_0()
    print('Test Case 0 OK')

test_jsonify()

# Generated at 2022-06-25 04:13:40.918802
# Unit test for function jsonify
def test_jsonify():
    # initialize
    result = 0
    format = False

    # perform the test
    result = test_case_0()

    # verify the results
    assert result == "{}"

# Generated at 2022-06-25 04:13:43.006141
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(1) == '1'


# Generated at 2022-06-25 04:13:43.763662
# Unit test for function jsonify
def test_jsonify():
    test_case_0()


# Generated at 2022-06-25 04:13:48.781321
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == "{}"

# Generated at 2022-06-25 04:13:52.188425
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) is not None # In other words, not a zero length string
    assert jsonify(dict()) == "{}"
    assert jsonify(dict(a=1,b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1,b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-25 04:13:56.042173
# Unit test for function jsonify
def test_jsonify():
    list_0 = []
    var_0 = jsonify(list_0)
    print("%s" % var_0)
    dict_1 = { "foo": "bar", "zzz": "zyx" }
    var_1 = jsonify(dict_1)
    print("%s" % var_1)

if __name__ == "__main__":
    print("running Unit tests for jsonify")
    test_jsonify()
    print("Unit tests for jsonify complete")

# Generated at 2022-06-25 04:13:57.481282
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(test_case_0()) == '{}'

# Generated at 2022-06-25 04:13:58.602424
# Unit test for function jsonify
def test_jsonify():
    var_0 = jsonify()
    assert var_0 == "{}"


# Generated at 2022-06-25 04:14:01.976168
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1}) == '{"a": 1}'

# Generated at 2022-06-25 04:14:04.016353
# Unit test for function jsonify
def test_jsonify():
    list_0 = []
    var_0 = jsonify(list_0)
    return var_0

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 04:14:13.568311
# Unit test for function jsonify
def test_jsonify():
    list_0 = None
    var_0 = jsonify(list_0)
    var_1 = jsonify(var_0)
    var_2 = jsonify(var_0)
    var_3 = jsonify(var_0)
    var_4 = jsonify(var_2)
    var_5 = jsonify(var_0)
    var_6 = jsonify(var_0)

# Generated at 2022-06-25 04:14:17.329015
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(list_0) == '[]'

# Generated at 2022-06-25 04:14:19.137552
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:14:31.349991
# Unit test for function jsonify
def test_jsonify():
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = []
    var_5 = []
    var_3['changed'] = False
    var_3['ansible_facts'] = {'ansible': '2.1.0.0'}
    var_3['skip_reason'] = "Conditional check failed"
    var_3['skipped'] = True
    var_3['invocation'] = var_0
    var_3['parsed'] = False
    var_4.append(var_3)
    var_1['invocation'] = var_0
    var_3 = dict()
    var_3['changed'] = False

# Generated at 2022-06-25 04:14:37.015503
# Unit test for function jsonify
def test_jsonify():
    print("-----------------------------")
    print("Test_jsonify start")
    test_case_0()


# Generated at 2022-06-25 04:14:39.387821
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:14:40.360252
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:14:47.893330
# Unit test for function jsonify
def test_jsonify():
    list_0 = []
    var_1 = jsonify(list_0)
    var_2 = jsonify(var_1)
    var_2 = jsonify(list_0)
    var_2 = jsonify(var_1)
    var_4 = {'foo': "bar"}
    var_5 = jsonify(var_4)
    var_6 = jsonify(var_5)
    var_6 = jsonify(var_4)
    var_6 = jsonify(var_5)

# Generated at 2022-06-25 04:14:50.473782
# Unit test for function jsonify
def test_jsonify():
    test_case_0()



# Generated at 2022-06-25 04:14:51.572299
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# End unit test for function jsonify

# Generated at 2022-06-25 04:15:01.317940
# Unit test for function jsonify
def test_jsonify():
    var_0 = jsonify(None)
    assert str(var_0) == "[]"
    list_0 = []
    var_0 = jsonify(list_0)
    assert str(var_0) == "[]"
    list_0 = []
    var_0 = jsonify(list_0, True)
    assert str(var_0) == "[]"
    dictionary_0 = {"a": "b"}
    var_0 = jsonify(dictionary_0)
    assert var_0 == '{"a": "b"}'
    dictionary_0 = {"a": "b"}
    var_0 = jsonify(dictionary_0, True)
    assert str(var_0) == '{\n    "a": "b"\n}'
    dictionary_0 = {"c": "b", "a": "b"}

# Generated at 2022-06-25 04:15:10.620439
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([]) == '[]'
    assert jsonify({}) == '{}'
    assert jsonify({'a': None}) == '{"a": null}'
    assert jsonify({'a': None}, format=True) == '{\n    "a": null\n}'
    assert jsonify({'a': {'b': {'c': 'd'}}}, format=True) == '{\n    "a": {\n        "b": {\n            "c": "d"\n        }\n    }\n}'
    assert jsonify(['a', 'b'], format=True) == '\n[\n    "a",\n    "b"\n]'

# Generated at 2022-06-25 04:15:13.551124
# Unit test for function jsonify
def test_jsonify():
    list_0 = []
    var_0 = jsonify(list_0)
    assert(var_0 == "[]")

    list_0 = [{"k": "v"}]
    var_0 = jsonify(list_0)
    assert(var_0 == '[{"k": "v"}]')

# Generated at 2022-06-25 04:15:26.492804
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([]) == "[]", 'Failed jsonify test'
    assert jsonify(None) == "{}", 'Failed jsonify test'
    assert jsonify(False) == "false", 'Failed jsonify test'
    assert jsonify(True) == "true", 'Failed jsonify test'
    assert jsonify(['foo']) == '["foo"]', 'Failed jsonify test'
    assert jsonify({}) == "{}", 'Failed jsonify test'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}', 'Failed jsonify test'
    assert jsonify(['foo', 'bar']) == '["foo", "bar"]', 'Failed jsonify test'

# Generated at 2022-06-25 04:15:37.031500
# Unit test for function jsonify
def test_jsonify():
    '''
    Test all of the different paths through jsonify.
    '''
    # Since under the hood this function is JSON encoding the input,
    #   deepcopy is being used to ensure the original value is not
    #   being mutated
    from copy import deepcopy
    # There are no inputs with type NoneType, so no test cases.
    # There are no inputs with type bool, so no test cases.
    # There are no inputs with type int, so no test cases.
    # There are no inputs with type float, so no test cases.
    # There are no inputs with type str, so no test cases.
    # There are no inputs with type list, so no test cases.
    # There are no inputs with type dict, so no test cases.
    # Test for each entry in tuple_0

# Generated at 2022-06-25 04:15:40.279577
# Unit test for function jsonify
def test_jsonify():
    val = {
        'foo': 'bar',
        'baz': [1, 2, 3, 4]
    }
    output = jsonify(val, True)
    assert isinstance(output, str)


# Generated at 2022-06-25 04:15:40.908422
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:15:44.775400
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    assert jsonify(None) == "{}"
    assert jsonify(None, format=True) == "{\n}\n"
    assert jsonify(None, True) == "{\n}\n"
    assert jsonify(('a', 'b')) == '["a", "b"]'


# Generated at 2022-06-25 04:15:45.647272
# Unit test for function jsonify
def test_jsonify():
    jsonify_0 = jsonify("string_0")


# Unit test to generate coverage metrics

# Generated at 2022-06-25 04:15:50.671141
# Unit test for function jsonify
def test_jsonify():

    print(">> Testing function jsonify")

    result = jsonify("string")
    assert result == "\"string\""

    result = jsonify({"simple":  "dictionary"})
    assert result == "{\"simple\": \"dictionary\"}"

    result = jsonify(["simple", "list"])
    assert result == "[\"simple\", \"list\"]"

    print(">> jsonify: OK")


# Generated at 2022-06-25 04:16:00.321526
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify([]) == "[]"
    assert jsonify(["f\xf6\xf6", "b\xe4r", "ba\xdf"]) == '["f\xf6\xf6", "b\xe4r", "ba\xdf"]'
    assert jsonify({ "f\xf6\xf6" : "b\xe4r", "ba\xdf" : "foo" }) == '{"ba\xdf": "foo", "f\xf6\xf6": "b\xe4r"}'

# Generated at 2022-06-25 04:16:02.068727
# Unit test for function jsonify
def test_jsonify():
    list_0 = []
    var_0 = jsonify(list_0)
    print("jsonify(%s) = %s" % (jsonify(list_0), var_0))


# Generated at 2022-06-25 04:16:02.895484
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'data': 'test'}) == '{"data": "test"}'

# Generated at 2022-06-25 04:16:13.912871
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:16:16.735429
# Unit test for function jsonify
def test_jsonify():
    list_0 = []
    var_0 = jsonify(list_0,False)
    print(var_0)

# test case
test_jsonify()

# Generated at 2022-06-25 04:16:18.786201
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({u'foo': u'bar'}) == u'{\n    "foo": "bar"\n}'



# Generated at 2022-06-25 04:16:23.580118
# Unit test for function jsonify
def test_jsonify():
    # first argument is type, second is type of return value, third is test case
    func_var_set = [(dict, '{}', {'a': {'b': 'c', 'd': ['e', 'f', 'g']}}),
                    (list, '{}', []),
                    (list, '[1,2,3]', [1,2,3]),
                    (list, '[1,2,3]', [1,2,3]),
                    (list, '[{"ansible": "2.0"}, [1, 2, 3]]', [{"ansible": "2.0"}, [1,2,3]]),
                    (str, '{"c": {"a": "b"}}', '{"c": {"a": "b"}}')]


# Generated at 2022-06-25 04:16:27.726304
# Unit test for function jsonify
def test_jsonify():
    var_0 = jsonify()
    var_0 = jsonify(list_0)
    var_0 = jsonify(list_0, True)

# Generated at 2022-06-25 04:16:37.490107
# Unit test for function jsonify
def test_jsonify():
    """ jsonify unit test """
    # assert(jsonify()) == True
    assert(jsonify(True) == "true")
    assert(jsonify(100) == "100")
    assert(jsonify(100.5) == "100.5")
    assert(jsonify("blue") == "\"blue\"")
    assert(jsonify({"a": "A", "b": "B"}) == "{\"a\": \"A\", \"b\": \"B\"}")
    list_0 = ["cat", "dog", [1, 2, 3, 4], 100.5]
    assert(jsonify(list_0) == "[\"cat\", \"dog\", [1, 2, 3, 4], 100.5]")

# Main module test if not called as a module

# Generated at 2022-06-25 04:16:41.850067
# Unit test for function jsonify
def test_jsonify():
	try:
		test_case_0()
	except AssertionError as ae:
		print (ae)
	except Exception as e:
		print(e)
	else:
		print("Test case passed")

# Invoke test_jsonify()
test_jsonify()

# Generated at 2022-06-25 04:16:51.095827
# Unit test for function jsonify
def test_jsonify():

    test_cases = [0]
    for t_c in test_cases:
        print(">>> Running test case: %d" % t_c)
        globals()['test_case_%d' % t_c]()
        print(">>> Passed test case: %d" % t_c)

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:16:57.412812
# Unit test for function jsonify
def test_jsonify():
  var_0 = jsonify(None)
  expected_0 = '{}'
  assert var_0 == expected_0

  list_0 = []
  var_0 = jsonify(list_0)
  expected_0 = '[]'
  assert var_0 == expected_0

  list_0 = [1,2,3]
  var_0 = jsonify(list_0)
  expected_0 = '[1, 2, 3]'
  assert var_0 == expected_0

  list_0 = [1,2,[3,4]]
  var_0 = jsonify(list_0)
  expected_0 = '[1, 2, [3, 4]]'
  assert var_0 == expected_0

  dict_0 = {'a':1, 'c':2, 'b':3}
  var_

# Generated at 2022-06-25 04:17:00.445186
# Unit test for function jsonify
def test_jsonify():
    print("\n====================\nStarting test_jsonify\n")
    test_case_0()
    print("\nEnding test_jsonify\n====================\n")

test_jsonify()

# Generated at 2022-06-25 04:17:29.017800
# Unit test for function jsonify
def test_jsonify():
    assert (jsonify(['A']) == '["A"]')
    assert (jsonify([{}]) == '[{}]')
    assert (jsonify({'x': [{'y': 'A'}]}) == '{"x": [{"y": "A"}]}')
    assert (jsonify('A') == '"A"')
    assert (jsonify(None) == '{}')
    assert (jsonify({}) == '{}')
    assert (jsonify({'x': [{'y': 'A'}]}, format=True) == '{\n    "x": [\n        {\n            "y": "A"\n        }\n    ]\n}')

# Generated at 2022-06-25 04:17:29.528438
# Unit test for function jsonify
def test_jsonify():
    assert True == True

# Generated at 2022-06-25 04:17:35.776591
# Unit test for function jsonify
def test_jsonify():

    # make sure the function does not raise an exception
    from ansible.utils.jsonify import jsonify
    import json

    # create a data structure to convert to JSON
    list_0 = []
    dict_0 = {'a': 'b', 'c': 'd'}
    list_0.append(dict_0)

    # convert to JSON
    var_0 = jsonify(list_0)
    var_1 = json.dumps(list_0, sort_keys=True, indent=4)

    # make sure the results are correct
    assert var_0 == var_1

# Generated at 2022-06-25 04:17:39.704193
# Unit test for function jsonify
def test_jsonify():
    assert (jsonify(None,
                    format=False) == "{}"), 'Return value for jsonify is not as expected'
    assert (jsonify(list([]),
                    format=False) == "[]"), 'Return value for jsonify is not as expected'
    assert (jsonify(dict(),
                    format=False) == "{}"), 'Return value for jsonify is not as expected'



# Generated at 2022-06-25 04:17:49.999585
# Unit test for function jsonify
def test_jsonify():
    var_0 = jsonify(None)
    print(var_0)
    var_1 = jsonify(list)
    print(var_1)
    var_2 = jsonify(set)
    print(var_2)
    var_3 = jsonify(tuple)
    print(var_3)
    var_4 = jsonify(dict)
    print(var_4)
    var_5 = jsonify(frozenset)
    print(var_5)
    var_6 = jsonify(None)
    print(var_6)
    var_7 = jsonify(list)
    print(var_7)
    var_8 = jsonify()
    print(var_8)
    var_9 = jsonify(dict)
    print(var_9)
    var_10 = jsonify

# Generated at 2022-06-25 04:17:53.032742
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == '[]'


# Generated at 2022-06-25 04:17:53.671117
# Unit test for function jsonify
def test_jsonify():
    pass

# Generated at 2022-06-25 04:18:04.028783
# Unit test for function jsonify
def test_jsonify():
    jsonify(None)
    jsonify(None, True)

    list_0 = []
    assert jsonify(list_0) == '[]'
    assert jsonify(list_0, True) == '[\n    \n]'

    list_0 = {'foo': 'bar'}
    assert jsonify(list_0) == '{"foo": "bar"}'
    assert jsonify(list_0, True) == '{\n    "foo": "bar"\n}'

    list_0 = {'foo': {'foo': 'bar'}}
    assert jsonify(list_0) == '{"foo": {"foo": "bar"}}'
    assert jsonify(list_0, True) == '{\n    "foo": {\n        "foo": "bar"\n    }\n}'

# Generated at 2022-06-25 04:18:05.135485
# Unit test for function jsonify
def test_jsonify():
    assert var_0 == "{}"



# Generated at 2022-06-25 04:18:08.725034
# Unit test for function jsonify
def test_jsonify():
    print('jsonify test_case_0')
    test_case_0()

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:18:39.799897
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify

    arg_0 = {}
    expected_0 = "{}"

    actual_0 = jsonify(arg_0)
    assert expected_0 == actual_0, "Actual result: %s" % actual_0
    #print("arg_0: %s, expected: %s, actual: %s\n" % (arg_0, expected_0, actual_0))

    arg_1 = {"key1" : "value1", "key2": "value2"}
    expected_1 = '{"key1": "value1", "key2": "value2"}'
    expected_1_like = '{\n    "key1": "value1",\n    "key2": "value2"\n}'


# Generated at 2022-06-25 04:18:46.078054
# Unit test for function jsonify
def test_jsonify():
    input = [
        {"a": "b", "c": "d"},
        None
    ]

    expected_results = [
        '{"a": "b", "c": "d"}',
        '{}'
    ]

    for i in range(0, len(input)):
        actual_result = jsonify(input[i])
        if actual_result != expected_results[i]:
            raise AssertionError("Expected " + str(expected_results[i]) + " but got " + str(actual_result) + ".")

test_jsonify()

# Generated at 2022-06-25 04:18:51.638230
# Unit test for function jsonify
def test_jsonify():
    # Add test code
    var_0 = json.dumps({'a':1}, sort_keys=True, indent=4)
    #assert var_0 is True
    #assert var_0 == "{\n    \"a\": 1\n}"

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:18:54.915955
# Unit test for function jsonify
def test_jsonify():
    print("Testing function:  jsonify")

    test_case_0()
    print("Done testing function:  jsonify")

# Generated at 2022-06-25 04:18:57.800822
# Unit test for function jsonify
def test_jsonify():
    """
    Test function jsonify.
    :return:
    """
    list = []
    var = jsonify(list)

    assert var == "{}"



# Generated at 2022-06-25 04:18:59.179534
# Unit test for function jsonify
def test_jsonify():
    test_case_0()
# End unit test for function jsonify

# Generated at 2022-06-25 04:19:01.895902
# Unit test for function jsonify
def test_jsonify():
    var_1 = {u'changed': False, u'ping': u'pong' }
    var_1 = jsonify(var_1, True)
    var_2 = {u'changed': False, u'ping': u'pong' }
    var_2 = jsonify(var_2, True)
    assert var_1 == var_2



# Generated at 2022-06-25 04:19:08.993426
# Unit test for function jsonify
def test_jsonify():
    list_0 = []
    var_0 = jsonify(list_0)
    assert var_0 == '[]'
    dict_0 = {}
    var_0 = jsonify(dict_0)
    assert var_0 == '{}'
    dict_0 = {'a': 1, 'b': 1, 'c': 2, 'd': 3}
    var_0 = jsonify(dict_0)
    assert var_0 == '{"a": 1, "b": 1, "c": 2, "d": 3}'
    dict_0 = {'a': [1, 2, 3], 'b': {'c': 1}}
    var_0 = jsonify(dict_0)
    assert var_0 == '{"a": [1, 2, 3], "b": {"c": 1}}'
    dict_

# Generated at 2022-06-25 04:19:17.918622
# Unit test for function jsonify
def test_jsonify():
    expected = "{}"
    actual = jsonify(None)
    assert actual == expected, 'Expected: {}, Actual: {}'.format(expected, actual)

    expected = '{\n    "a": "b", \n    "c": "d"\n}'
    actual = jsonify({"a": "b", "c": "d"}, True)
    assert actual == expected, 'Expected: {}, Actual: {}'.format(expected, actual)

    expected = '{"a": "b", "c": "d"}'
    actual = jsonify({"a": "b", "c": "d"}, False)
    assert actual == expected, 'Expected: {}, Actual: {}'.format(expected, actual)

# Generated at 2022-06-25 04:19:20.496584
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"

# Generated at 2022-06-25 04:20:06.650590
# Unit test for function jsonify
def test_jsonify():
    fp = open(__file__+".out", "w")
    fp.write(jsonify(test_case_0()))
    fp.close()

    fp = open(__file__+".out", "r")
    data = fp.read()
    fp.close()

    rc = 0
    assert "]" == data.strip(), "Expected ']', got '%s'" % data
    return rc

if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-25 04:20:09.926143
# Unit test for function jsonify
def test_jsonify():
    test_case_0()
    list_0 = []
    var_0 = jsonify(list_0)

# Generated at 2022-06-25 04:20:16.262481
# Unit test for function jsonify
def test_jsonify():
    list_data = []
    for i in range(100000):
        list_data.append({'key'+str(i): 'value' + str(i)})

    import time
    start_time = time.time()
    json_data = jsonify(list_data, format=True)
    end_time = time.time()

    print('Time cost: ' + str(end_time - start_time))


# Generated at 2022-06-25 04:20:23.056225
# Unit test for function jsonify
def test_jsonify():
    # Store JSON representation for comparison
    list_0_json = '[]'
    # Test function and make assertions
    test_case_0()

    # Test assertions
    assert list_0_json == var_0

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-25 04:20:33.339597
# Unit test for function jsonify
def test_jsonify():
    list_0 = []
    var_0 = jsonify(list_0)
    assert isinstance(var_0, str)
    assert var_0 == "{}"

    list_1 = ["test"]
    var_1 = jsonify(list_1)
    assert isinstance(var_1, str)
    assert var_1 == "[\n    \"test\"\n]"

    list_2 = [1, 2, 3, 4]
    var_2 = jsonify(list_2)
    assert isinstance(var_2, str)
    assert var_2 == "[\n    1,\n    2,\n    3,\n    4\n]"

    list_3 = ["1", 2]
    var_3 = jsonify(list_3)
    assert isinstance(var_3, str)
   

# Generated at 2022-06-25 04:20:39.002170
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(['a', 'a', 'a']) == "[\"a\", \"a\", \"a\"]"
    assert jsonify(['a', 'a', 'a'], True) == "[\n    \"a\",\n    \"a\",\n    \"a\"\n]"
    assert jsonify(False) == "false"
    assert jsonify(True) == "true"
    assert jsonify(0.0) == "0.0"
    assert jsonify(0) == "0"
    assert jsonify(0.5) == "0.5"
    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify({'a': 'a'}) == "{\n    \"a\": \"a\"\n}"
    assert jsonify(None, True) == "{}"



# Generated at 2022-06-25 04:20:48.743718
# Unit test for function jsonify
def test_jsonify():
    list_0 = []
    var_0 = jsonify(list_0)
    var_1 = jsonify(list_0, True)
    list_1 = [1, 2, 3]
    var_2 = jsonify(list_1)
    var_3 = jsonify(list_1, True)
    dict_0 = {}
    var_4 = jsonify(dict_0)
    var_5 = jsonify(dict_0, True)
    dict_1 = {'a': 1, 'b': 2}
    var_6 = jsonify(dict_1)
    var_7 = jsonify(dict_1, True)
    str_0 = u'{}'
    assert var_0 == str_0
    str_1 = u'[]'
    assert var_1 == str_1
    str

# Generated at 2022-06-25 04:20:56.135180
# Unit test for function jsonify
def test_jsonify():
    list_1 = list()
    var_1 = jsonify(list_1)
    assert var_1 != None and type(var_1) == str



# Generated at 2022-06-25 04:21:06.789033
# Unit test for function jsonify
def test_jsonify():
    j = jsonify({
        'a' : 'b',
        'c' : 'd',
        'e' : 'f',
    })
    assert j == '{"a": "b", "c": "d", "e": "f"}'

    j = jsonify({
        'a' : 'b',
        'c' : 'd',
        'e' : 'f',
    }, True)
    assert j == '{\n    "a": "b", \n    "c": "d", \n    "e": "f"\n}'

    j = jsonify([1,2,3], True)
    assert j == '[\n    1, \n    2, \n    3\n]'

    j = jsonify("fdsafdsa", True)

# Generated at 2022-06-25 04:21:08.542416
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

