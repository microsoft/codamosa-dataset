

# Generated at 2022-06-25 04:11:24.984458
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('Q.+sB);m@', 'Q.+sB);m@') == '["Q.+sB);m@", "Q.+sB);m@"]'


# Generated at 2022-06-25 04:11:27.754007
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:11:36.828020
# Unit test for function jsonify
def test_jsonify():
    # Assert 0
    assert jsonify('Q.+sB);m@', 'Q.+sB);m@') == '{}'

    # Assert 4
    assert jsonify(jsonify.__annotations__, jsonify.__annotations__) == '{}'

    # Assert 7

# Generated at 2022-06-25 04:11:47.261312
# Unit test for function jsonify

# Generated at 2022-06-25 04:11:52.057404
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:12:01.117147
# Unit test for function jsonify
def test_jsonify():
    values = [{'test_key1': 'test_value1',
               'test_key2': ['test_value2', 'test_value3'],
               'test_key3': [{'test_key4': 'test_value4',
                              'test_key5': 'test_value5'},
                             [{'test_key6': 'test_value6',
                               'test_key7': ['test_value7',
                                             'test_value8']},
                              {'test_key9': 'test_value9'}]]},
              {"aaa": "bbb"}]
    try:
        import json
    except ImportError:
        print("SKIP: json python module not available")
        return

# Generated at 2022-06-25 04:12:04.301708
# Unit test for function jsonify
def test_jsonify():

    # Test 0: Edge case
    try:
        assert (test_case_0())
    except AssertionError as ae:
        print('Failed test 0')
        print('Assertion Error: ', ae)
        exit(1)


if __name__ == '__main__':
    test_jsonify()
    exit(0)

# Generated at 2022-06-25 04:12:07.141837
# Unit test for function jsonify
def test_jsonify():
    # FIXME:
    # This test is a placeholder for now.
    #
    # The jsonify function is used by the ansible-galaxy command,
    # which I have not implemented.  This test needs to be updated
    # once that is added.
    assert True

# Generated at 2022-06-25 04:12:12.381184
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({'a': '1', 'b': '2'})
    assert result == '{"a": "1", "b": "2"}'

# Generated at 2022-06-25 04:12:17.694777
# Unit test for function jsonify
def test_jsonify():
    # TODO: Need to check the actual input args.
    assert jsonify(input_var1, input_var2) == output_var


# Generated at 2022-06-25 04:12:20.469927
# Unit test for function jsonify
def test_jsonify():
    # Encourage code coverage
    test_case_0()
# end of test_jsonify()

# Generated at 2022-06-25 04:12:22.112450
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'Q.+sB);m@'
    var_0 = jsonify(str_0, str_0)



# Generated at 2022-06-25 04:12:23.143769
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify('abc', 'abc') == 'abc')




# Generated at 2022-06-25 04:12:27.161074
# Unit test for function jsonify
def test_jsonify():
    test_0 = '1'
    if not test_0 == '1':
        raise Exception('test_0 not complete')
    test_1 = '2'
    if not test_1 == '2':
        raise Exception('test_1 not complete')
    test_2 = '3'
    if not test_2 == '3':
        raise Exception('test_2 not complete')
    test_3 = '4'
    if not test_3 == '4':
        raise Exception('test_3 not complete')

# Generated at 2022-06-25 04:12:35.296823
# Unit test for function jsonify
def test_jsonify():
    assert str(jsonify({})) == "{}"

    # some unicode
    assert jsonify(u'\u00f6') == str(u'\"\u00f6\"')

    # unicode with non-ascii
    assert jsonify(u'\u5c3a') == str(u'\"\u5c3a\"')

    # unicode with non-ascii
    assert jsonify(u'\u5c3a'.encode('utf16')) == str(u'\"\u5c3a\"')

    # unicode with non-ascii
    assert jsonify(u'\u5c3a'.encode('utf16').decode('utf16')) == str(u'\"\u5c3a\"')

    # unicode with non-ascii

# Generated at 2022-06-25 04:12:36.980544
# Unit test for function jsonify
def test_jsonify():
    print("Testing jsonify")
    test_case_0()


# Run unit tests
test_jsonify()

# Generated at 2022-06-25 04:12:38.523071
# Unit test for function jsonify
def test_jsonify():
    assert str_0 == var_0

# Generated at 2022-06-25 04:12:43.089485
# Unit test for function jsonify
def test_jsonify():
    '''
    Unit test for jsonify
    '''
    str_0 = 'Q.+sB);m@'
    var_0 = jsonify(str_0, str_0)

# Generated at 2022-06-25 04:12:44.733437
# Unit test for function jsonify
def test_jsonify():
    # no tests available
    pass


# Generated at 2022-06-25 04:12:49.390330
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'Q.+sB);m@'
    var_0 = jsonify(str_0, str_0)
    assert var_0 == "Q.+sB);m@"

    str_1 = '#\x15\x0e\x0c\x03\x1c\x0e'
    var_1 = jsonify(str_1, str_1)
    assert var_1 == "\"#\\u0015\\u000e\\u000c\\u0003\\u001c\\u000e\""

    str_2 = '?{e'
    var_2 = jsonify(str_2, str_2)
    assert var_2 == "\"?{e\""


# Generated at 2022-06-25 04:12:52.911675
# Unit test for function jsonify
def test_jsonify():
    result = jsonify()
    assert result == "{}"

# Run test functions
test_jsonify()
test_case_0()

# Generated at 2022-06-25 04:13:03.859811
# Unit test for function jsonify
def test_jsonify():
    import copy
    import inspect
    try:
        from ansible.module_utils.basic import AnsibleModule
    except:
        import sys
        print(sys.path)

    top = inspect.getfile(inspect.currentframe())
    parent, _ = os.path.split(top)
    sys.path.append(parent)
    from library import jsonify

    # Generate test matrix
    func_name = 'jsonify'
    func_params = ('result', 'format')
    data_type_combinations = [
        ('string', 'boolean'),
        ('string', 'None'),
        ('None', 'boolean'),
        ('int', 'None'),
        ('Array', 'None'),
        ('Object', 'None'),
    ]

    # Run tests

# Generated at 2022-06-25 04:13:09.418960
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('Q.+sB);m@', 'Q.+sB);m@') == '"Q.+sB);m@"'



# Generated at 2022-06-25 04:13:16.521059
# Unit test for function jsonify
def test_jsonify():

    # Example for function jsonify
    def test_case_1():
        var_0 = {}
        var_1 = None
        assert jsonify(var_0) == jsonify(var_1),  \
        "jsonify: test_case_1"
        var_2 = {}
        var_3 = True
        assert jsonify(var_2) == jsonify(var_3),  \
        "jsonify: test_case_1"
        var_4 = {}
        var_5 = False
        assert jsonify(var_4) == jsonify(var_5),  \
        "jsonify: test_case_1"
        var_6 = {}
        var_7 = None

# Generated at 2022-06-25 04:13:28.507502
# Unit test for function jsonify
def test_jsonify():

    assert jsonify({}) == '{}'
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    assert jsonify(1) == '1'
    assert jsonify(1.1) == '1.1'
    assert jsonify([1]) == '[1]'
    assert jsonify((1,)) == '[1]'
    assert jsonify({1:1}) == '{"1": 1}'
    assert jsonify('{"1": "1"}') == '"{\\"1\\": \\"1\\"}"'
    assert jsonify({"a": "a", "b": "b"}) == '{"a": "a", "b": "b"}'

# Generated at 2022-06-25 04:13:29.369134
# Unit test for function jsonify
def test_jsonify():
    assert(test_case_0())

# Generated at 2022-06-25 04:13:32.754025
# Unit test for function jsonify
def test_jsonify():
    assert str_0 == 'Q.+sB);m@'
    assert var_0 == '{"Q.+sB);m@": "Q.+sB);m@"}'
    assert var_0 == '{"Q.+sB);m@": "Q.+sB);m@"}' #testing for correct encoding

# Generated at 2022-06-25 04:13:34.584965
# Unit test for function jsonify
def test_jsonify():
    try:
        test_case_0()
    except Exception as e:
        print(e)


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:13:40.324315
# Unit test for function jsonify
def test_jsonify():
    print('Testing function jsonify')
    test_case_0()
    print('Hooray! All test cases are passed.')


# Generated at 2022-06-25 04:13:43.224457
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == ''

test_jsonify()

# Generated at 2022-06-25 04:13:57.748904
# Unit test for function jsonify
def test_jsonify():
    '''
    Make sure function function jsonify has no errors.
    '''
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os

    currentDirectory = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(currentDirectory + "/lib")

    moduleArgs = dict(
        name="Test",
        path="Test",
        state="Test"
    )
    tmpdir = os.path.realpath(os.path.join(currentDirectory, '../tmp'))

# Generated at 2022-06-25 04:14:01.119243
# Unit test for function jsonify
def test_jsonify():
    var_0 = 'Q.+sB);m@'
    var_1 = 'Q.+sB);m@'
    var_2 = jsonify(var_0, var_1)
    assert var_2 == '"Q.+sB);m@"'

# Generated at 2022-06-25 04:14:07.844573
# Unit test for function jsonify
def test_jsonify():

    global STR_0
    STR_0 = 'jsonify'

    # test_case_0
    print('test_case_0')
    test_case_0()


test_jsonify()

# Generated at 2022-06-25 04:14:10.104254
# Unit test for function jsonify
def test_jsonify():
    test_case_0()


# Generated at 2022-06-25 04:14:17.764145
# Unit test for function jsonify
def test_jsonify():
  
  # Example from documentation
  result = jsonify({ 'foo': 'bar', 'baz': None }, True)
  assert result == '{\n    "baz": null,\n    "foo": "bar"\n}'

  data = { 'foo': 'bar',
           'baz': None,
           'waldo': "fred",
           'true': True,
           'false': False,
           'empty_list': [],
           'list': [1, 2, 3, 4],
           'empty_dict': {},
           'dict': {'a': 1, 'b': 2}
         }

  # Raw data should be properly formatted as JSON
  result = jsonify(data, False)

# Generated at 2022-06-25 04:14:31.264389
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'JZV@lZKp'
    var_0 = jsonify(str_0)
    assert var_0 == '"JZV@lZKp"'

    str_0 = 'WU!xK@J&$\\'
    var_0 = jsonify(str_0)
    assert var_0 == '"WU!xK@J&$\\\\"'

    str_0 = 'Z1qle,g_e'
    var_0 = jsonify(str_0)
    assert var_0 == '"Z1qle,g_e"'

    str_0 = 'bq&OyKQT'
    var_0 = jsonify(str_0)
    assert var_0 == '"bq&OyKQT"'


# Generated at 2022-06-25 04:14:38.788985
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify('Q.+sB);m@', 'Q.+sB);m@') is "\"Q.+sB);m@\"")

# Generated at 2022-06-25 04:14:40.050364
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:14:49.725651
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'test string'
    ansible_dict = jsonify(str_0)
    str_1 = 'test string'
    assert(ansible_dict == str_1)
    str_0 = 'test string'
    ansible_dict = jsonify(str_0)
    str_1 = 'test string'
    assert(ansible_dict == str_1)
    str_0 = 'test string'
    ansible_dict = jsonify(str_0)
    str_1 = 'test string'
    assert(ansible_dict == str_1)
    str_0 = 'test string'
    ansible_dict = jsonify(str_0)
    str_1 = 'test string'
    assert(ansible_dict == str_1)
    str_0 = 'test string'
   

# Generated at 2022-06-25 04:14:50.914048
# Unit test for function jsonify
def test_jsonify():
    print(test_case_0())

# Generated at 2022-06-25 04:15:03.245969
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == None


# Generated at 2022-06-25 04:15:05.378206
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Unit test stubs

# Generated at 2022-06-25 04:15:08.008584
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify('{"a": "b"}', True) == '{\n    "a": "b"\n}')


# Generated at 2022-06-25 04:15:13.984487
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == """{
    "count": 1,
    "results": [
        {
            "changed": false,
            "invocation": {
                "module_args": "",
                "module_complex_args": {},
                "module_name": "setup"
            },
            "item": "",
            "rc": 0
        }
    ]
}
"""

# Generated at 2022-06-25 04:15:20.887710
# Unit test for function jsonify
def test_jsonify():

    # call jsonify
    test_case_0()

# main function
if __name__ == "__main__":

    # call test function
    test_jsonify()


# Generated at 2022-06-25 04:15:31.132264
# Unit test for function jsonify
def test_jsonify():
    # check expected values for jsonify
    str_0 = 'Q.+sB);m@'
    var_0 = jsonify(str_0, str_0)

    #
    # Test input and expected outputs for frequently executed code paths.
    #
    # If a single test case is given, check for the presence of the test
    # case on the given path.
    #
    # If a list of test cases is given, check for the presence of ANY of
    # the test cases on the given path.
    #

    test_cases = [
        [
            # {:
            test_case_0,
        ]
    ]

    #
    # For each path identified above, check the path for the test case(s).
    #
    # If a test case is found on the path, increment a counter for that
    # test

# Generated at 2022-06-25 04:15:37.605994
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"

    assets = ["abc", "def", 1, 2, 3]
    assets_json = '["abc","def",1,2,3]'
    assert jsonify(assets) == assets_json
    assert jsonify(assets, format=True) == assets_json

    # FIXME: do we want the json to be sorted?
    assets = ["zzz", "ccc", "aaa"]
    assets_json = '["aaa","ccc","zzz"]'
    assert jsonify(assets) == assets_json
    assert jsonify(assets, format=True) == assets_json

    assets = [{"zzz": "abc", "ccc": "def", "aaa": "ghi"}]
    assets_json = '[{"aaa":"ghi","ccc":"def","zzz":"abc"}]'


# Generated at 2022-06-25 04:15:39.603750
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:15:45.775852
# Unit test for function jsonify
def test_jsonify():
    assert None == jsonify(None, False)
    assert "{}" == jsonify(None, True)
    assert "{}" == jsonify("")
    assert "{}" == jsonify("", True)
    assert '[{"key": "value"}]' == jsonify([{"key": "value"}])
    assert '[{"key": "value"}]' == jsonify([{"key": "value"}])
    assert '[{"key": "value"}]' == jsonify([{"key": "value"}], True)
    assert '{"key": "value"}' == jsonify({"key": "value"})
    assert '{"key": "value"}' == jsonify({"key": "value"})
    assert '{\n    "key": "value"\n}' == jsonify({"key": "value"}, True)

# Generated at 2022-06-25 04:15:47.149405
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:16:05.978413
# Unit test for function jsonify
def test_jsonify():
    assert(test_case_0())

# Generated at 2022-06-25 04:16:11.752405
# Unit test for function jsonify
def test_jsonify():
    
    result_0 = jsonify(None, None)
    assert result_0 == '{}'

# Generated at 2022-06-25 04:16:16.737570
# Unit test for function jsonify
def test_jsonify():
    test_cases = [
        ['Q.+sB);m@', 'Q.+sB);m@', True]
    ]
    for arg, expected, format in test_cases:
        result = jsonify(arg, format)
        assert expected == result

# Generated at 2022-06-25 04:16:17.861860
# Unit test for function jsonify
def test_jsonify():
    assert 1 == 1


# Generated at 2022-06-25 04:16:26.303495
# Unit test for function jsonify
def test_jsonify():
    '''
    The function jsonify is used to format json output.
    The function has two parameters.
    Parameter 1: Json data to format
    Parameter 2: A boolean value to enable formatting
    '''
    # Define a python dict object:
    # 'PROMPT' will be a dict in the json output
    PROMPT = {
        'user': 'root',
        'path': '/home/root'
    }

    # We expect the formatted json output to be:
    # {
    #     "path": "/home/root",
    #     "user": "root"
    # }
    # The following test asserts if the json output will be
    # formatted as expected or not.

# Generated at 2022-06-25 04:16:27.542558
# Unit test for function jsonify
def test_jsonify():
    test_case_0()


# Generated at 2022-06-25 04:16:28.720143
# Unit test for function jsonify
def test_jsonify():
    assert True is not False

test_jsonify()

# Generated at 2022-06-25 04:16:31.532260
# Unit test for function jsonify
def test_jsonify():
    test_case_0()
    print("Unit test complete")

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:16:41.036281
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'Q.+sB);m@'

# Generated at 2022-06-25 04:16:43.295598
# Unit test for function jsonify
def test_jsonify():
    try:
        assert True
    except AssertionError as e:
        print("Test jsonify() is FAILED. Error: %s" %(e))

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:17:26.851869
# Unit test for function jsonify
def test_jsonify():
    try:
        test_case_0()
    except Exception as err:
        print('Exception: {}'.format(err))
        raise


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:17:27.878628
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == None

# Generated at 2022-06-25 04:17:34.298383
# Unit test for function jsonify
def test_jsonify():
    pass
    assert jsonify(0, False)
    assert jsonify(0, True)
    assert jsonify(0, False)
    assert jsonify(None, False)
    assert jsonify(False, False)
    assert jsonify(None, False)
    assert jsonify(False, True)
    assert jsonify(0, True)
    assert jsonify(0, True)
    assert jsonify(0, False)
    assert jsonify(True, False)
    assert jsonify(None, True)
    assert jsonify(None, True)
    assert jsonify(0, True)
    assert jsonify(0, False)
    assert jsonify(0, False)
    assert jsonify(False, True)
    assert jsonify(0, True)
    assert jsonify(False, False)

# Generated at 2022-06-25 04:17:35.744303
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('key', 'value') == '{"key": "value"}'


# Generated at 2022-06-25 04:17:44.556485
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

if __name__ == '__main__':
    import os
    import sys
    import difflib

    ansible_path = os.path.abspath(__file__).split('/')[:-2]
    lib_path = os.path.join(os.path.sep.join(ansible_path), 'lib')
    sys.path.append(lib_path)

    from ansible.module_utils import basic
    from ansible.module_utils import json
    from ansible.module_utils import yaml

    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import urllib

# Generated at 2022-06-25 04:17:55.499371
# Unit test for function jsonify
def test_jsonify():
    # Input parameters
    result = None
    format = None

    # Expected return value
    expected = "{}"

    # Call the function
    actual = jsonify(result, format)

    # Print results
    print("jsonify() returned:  " + actual)
    print("Expected to return:  " + expected)
    print()

    #
    # Add your own tests here
    #

    # Check return value
    assert actual == expected


# Run unit tests
if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:17:57.867064
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == True

# Generated at 2022-06-25 04:18:04.426147
# Unit test for function jsonify
def test_jsonify():
    # Test Case 0
    assert False
    # Test Case 1
    assert False
    # Test Case 2
    assert False
    # Test Case 3
    assert False
    # Test Case 4
    assert False
    # Test Case 5
    assert False
    # Test Case 6
    assert False
    # Test Case 7
    assert False
    # Test Case 8
    assert False
    # Test Case 9
    assert False
    # Test Case 10
    assert False
    # Test Case 11
    assert False
    # Test Case 12
    assert False
    # Test Case 13
    assert False
    # Test Case 14
    assert False
    # Test Case 15
    assert False
    # Test Case 16
    assert False
    # Test Case 17
    assert False
    # Test Case 18
    assert False
    # Test Case 19
    assert False

# Generated at 2022-06-25 04:18:12.414541
# Unit test for function jsonify
def test_jsonify():
    json_string = jsonify({'test': 'mytest', 'hello': 'world'})
    print("")
    print("json_string: " + json_string)
    print("")
    print("")
    json_string = jsonify([1, 2, 3, 4])
    print("")
    print("json_string: " + json_string)
    print("")
    print("")

    test_case_0()


# Generated at 2022-06-25 04:18:17.023069
# Unit test for function jsonify
def test_jsonify():
    # test case 0
    str_0 = 'Q.+sB);m@'
    var_0 = jsonify(str_0, str_0)


# Generated at 2022-06-25 04:19:45.591628
# Unit test for function jsonify
def test_jsonify():
    assert jsonify("foo") == "\"foo\""
    assert jsonify("foo\n") == "\"foo\\n\""
    assert jsonify("foo\t") == "\"foo\\t\""
    assert jsonify(b"a") == "\"a\""
    assert jsonify(b"a\n") == "\"a\\n\""
    assert jsonify(b"a\t") == "\"a\\t\""
    assert jsonify(u"foo") == "\"foo\""
    assert jsonify(u"foo\n") == "\"foo\\n\""
    assert jsonify(u"foo\t") == "\"foo\\t\""
    assert jsonify(10) == "10"
    assert jsonify(10.0) == "10.0"

# Generated at 2022-06-25 04:19:46.825409
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'This is a test'
    var_0 = jsonify(str_0, str_0)

# Generated at 2022-06-25 04:19:47.956091
# Unit test for function jsonify
def test_jsonify():
    print("Running function tests for function jsonify")
    test_case_0()


# Generated at 2022-06-25 04:19:57.242641
# Unit test for function jsonify

# Generated at 2022-06-25 04:20:00.775311
# Unit test for function jsonify
def test_jsonify():
    print('Testing function jsonify')
    test_case_0()

# Generated at 2022-06-25 04:20:02.383150
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == 1

# Generated at 2022-06-25 04:20:08.955079
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'Q.+sB);m@'
    var_0 = jsonify(str_0, str_0)
    assert var_0 == '"Q.+sB);m@"'

    str_0 = 'Q.+sB);m@'
    var_0 = jsonify(str_0, str_0)
    assert var_0 == '"Q.+sB);m@"'

    str_0 = 'Q.+sB);m@'
    var_0 = jsonify(str_0, str_0)
    assert var_0 == '"Q.+sB);m@"'

    str_0 = 'Q.+sB);m@'
    var_0 = jsonify(str_0, str_0)

# Generated at 2022-06-25 04:20:12.256446
# Unit test for function jsonify
def test_jsonify():
    # Case 0 =>
    str_0 = 'Q.+sB);m@'
    var_0 = jsonify(str_0, str_0)
    print(var_0)

# Generated at 2022-06-25 04:20:14.229965
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == '{"Q.+sB);m@": "Q.+sB);m@"}'


# Generated at 2022-06-25 04:20:17.065690
# Unit test for function jsonify