

# Generated at 2022-06-25 04:11:33.612785
# Unit test for function jsonify
def test_jsonify():
    result = jsonify("my_string")
    assert result == "\"my_string\""
    result = jsonify(123)
    assert result == "123"
    result = jsonify({"key": "value"})
    assert result == "{\"key\": \"value\"}"
    result = jsonify(["listitem1", "listitem2"])
    assert result == "[\"listitem1\", \"listitem2\"]"
    result = jsonify(None)
    assert result == "{}"
    result = jsonify(None, True)
    assert result == "{\n}\n"
    result = jsonify({"key": "value"}, True)
    assert result == "{\n    \"key\": \"value\"\n}\n"
    result = jsonify(123, True)
    assert result == "123"
    result = jsonify

# Generated at 2022-06-25 04:11:34.433270
# Unit test for function jsonify
def test_jsonify():
    test_case_0()



# Generated at 2022-06-25 04:11:36.309764
# Unit test for function jsonify
def test_jsonify():
    assert var_0 == "'\\\\xf5\\\\x90I\\\\x06\\\\xc1\\\\xfb-9T\\\\x84'"
    assert var_1 == "'\\\\xf5\\\\x90I\\\\x06\\\\xc1\\\\xfb-9T\\\\x84'"

# Generated at 2022-06-25 04:11:47.219910
# Unit test for function jsonify

# Generated at 2022-06-25 04:12:01.679910
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(b'\xf5\x90I\x06\xc1\xfb-9T\x84') == '"\\xf5\\x90I\\x06\\xc1\\xfb-9T\\x84"'
    assert jsonify(b'\x19\xb3\x18\x88\x99\xe5\xf9c\x97\x9d\x9e]\x93\xdc') == '"\\x19\\xb3\\x18\\x88\\x99\\xe5\\xf9c\\x97\\x9d\\x9e]\\x93\\xdc"'

# Generated at 2022-06-25 04:12:02.358470
# Unit test for function jsonify
def test_jsonify():
	test_case_0()

# Generated at 2022-06-25 04:12:03.372237
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:12:10.001755
# Unit test for function jsonify
def test_jsonify():
    bytes_0 = b'\xf5\x90I\x06\xc1\xfb-9T\x84'
    var_0 = jsonify(bytes_0)
    assert var_0 == '"\\xf5\\x90I\\x06\\xc1\\xfb-9T\\x84"'
    var_1 = jsonify(bytes_0, True)
    assert var_1 == '"\\xf5\\x90I\\x06\\xc1\\xfb-9T\\x84"'


# Generated at 2022-06-25 04:12:10.805769
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:12:13.541451
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

if __name__ == '__main__':

    print( "Testing jsonify()")
    test_jsonify()

# Generated at 2022-06-25 04:12:18.888308
# Unit test for function jsonify
def test_jsonify():
    assert True == False # TODO: implement your test here

# vim: expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

# Generated at 2022-06-25 04:12:24.356221
# Unit test for function jsonify
def test_jsonify():
    bytes_0 = b'\xf5\x90I\x06\xc1\xfb-9T\x84'
    var_0 = jsonify(bytes_0)
    var_1 = jsonify(bytes_0, True)
    assert var_0 == '"\xf5\x90I\x06\xc1\xfb-9T\x84"'
    assert var_1 == '''"\xf5\x90I\x06\xc1\xfb-9T\x84"'''

# Unit test - this should fail

# Generated at 2022-06-25 04:12:27.120968
# Unit test for function jsonify
def test_jsonify():
    test_case_0()


import unittest


# Generated at 2022-06-25 04:12:33.248290
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(None)
    assert result == "{}"
    data = {'foo': 'bar', 'baz': 1, 'bat': ['a', 'b', 'c']}
    assert jsonify(data) == '{"bat": ["a", "b", "c"], "baz": 1, "foo": "bar"}'
    assert jsonify(data, True) == '''{
    "bat": [
        "a",
        "b",
        "c"
    ],
    "baz": 1,
    "foo": "bar"
}'''

# Generated at 2022-06-25 04:12:35.966101
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(b'\xf5\x90I\x06\xc1\xfb-9T\x84', False) == '"\\xf5\\x90I\\x06\\xc1\\xfb-9T\\x84"'


# Generated at 2022-06-25 04:12:36.669792
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:12:46.869958
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('test') == '"test"'
    assert jsonify([1,2,3]) == '[1, 2, 3]'
    assert jsonify([1,2,[3,4,5]], True) == """[
    1,
    2,
    [
        3,
        4,
        5
    ]
]"""
    assert jsonify(dict(a=1, b=2, c=dict(d=3, e=4, f=5)), True) == """{
    "a": 1,
    "b": 2,
    "c": {
        "d": 3,
        "e": 4,
        "f": 5
    }
}"""
    try:
        jsonify(None)
    except:
        assert False, 'jsonify(None) should not raise exception'

# Generated at 2022-06-25 04:12:47.801651
# Unit test for function jsonify
def test_jsonify():
    assert "????A??-9T??" == test_case_0()

# Generated at 2022-06-25 04:12:53.724611
# Unit test for function jsonify
def test_jsonify():
    try:
        test_case_0()
    except Exception as e:
        raise AssertionError('Uncaught exception when executing test_jsonify(): %s' % e)

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:12:54.438301
# Unit test for function jsonify
def test_jsonify():
    print(test_case_0())



# Generated at 2022-06-25 04:13:00.094759
# Unit test for function jsonify
def test_jsonify():
    # Unit test for jsonify with invalid arguments
    assert test_case_0() is None # Invalid case with wrong arguments

    # Unit test for jsonify without arguments
    assert jsonify() is not None


test_jsonify()

# Generated at 2022-06-25 04:13:03.018043
# Unit test for function jsonify
def test_jsonify():
    # Note: try various input types

    # jsonify(var_0)
    pass



# Generated at 2022-06-25 04:13:15.464615
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify

    assert jsonify(None) == '{}'
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=[1,2], b=2)) == '{"a": [1, 2], "b": 2}'
    assert jsonify(dict(a=[1,2], b=dict(c=3, d=4))) == '{"a": [1, 2], "b": {"c": 3, "d": 4}}'

    # ensure invalid values are jsonified to empty strings
    assert jsonify(object()) == "\"\""
    assert jsonify(type) == "\"\""
    assert jsonify(type('', (), {})) == "\"\""

    # Check the behaviour

# Generated at 2022-06-25 04:13:23.977998
# Unit test for function jsonify
def test_jsonify():
    var_0 = '\u001b[1;31mFAILED! =>\u001b[0m'
    var_1 = '\u001b[1;32mSUCCESS! =>\u001b[0m'
    var_2 = None
    try:
        test_case_0()
        var_2 = var_1
    except Exception:
        var_2 = var_0
    print(var_2 + ' test_case_0')


if __name__ == '__main__':
    try:
        test_jsonify()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 04:13:26.001550
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import jsonify
    test_case_0()

# Generated at 2022-06-25 04:13:33.673360
# Unit test for function jsonify
def test_jsonify():
    # Test passing None as parameter
    assert jsonify(result = None) == "{}"

    # Test passing bytes as parameter
    bytes_0 = b'\xf5\x90I\x06\xc1\xfb-9T\x84'
    assert jsonify(result = bytes_0) == '"\\uff15\\u00901\\u0006\\uff41\\ufffb-9T\\u0084"'

    # Test passing list as parameter
    list_0 = [7, 'c', '4Vl', -2, None, True, ']', 'S']
    assert jsonify(result = list_0) == '[7, "c", "4Vl", -2, null, true, "]", "S"]'

    # Test passing dictionary as parameter

# Generated at 2022-06-25 04:13:35.533072
# Unit test for function jsonify
def test_jsonify():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 04:13:37.231849
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == "{'bytes_0': '\\xf5\\x90I\\x06\\xc1\\xfb-9T\\x84'}"

# Generated at 2022-06-25 04:13:43.459085
# Unit test for function jsonify
def test_jsonify():
    str_0 = jsonify(0, False)
    assert str_0 == "0"
    assert str_0.__class__ == str
    str_1 = jsonify(0, True)
    assert str_1 == "0"
    assert str_1.__class__ == str
    str_2 = jsonify([1, 2, 3], False)
    assert str_2 == "[1, 2, 3]"
    assert str_2.__class__ == str
    str_3 = jsonify([1, 2, 3], True)
    assert str_3 == "[\n    1,\n    2,\n    3\n]"
    assert str_3.__class__ == str
    str_4 = jsonify({'a': "A", 'b': "B", 'c': "C"}, False)
    assert str

# Generated at 2022-06-25 04:13:46.435706
# Unit test for function jsonify
def test_jsonify():
    print('Testing function jsonify from module misc')
    test_case_0()


if __name__ == '__main__':
    print('In main: misc')
    test_jsonify()

# Generated at 2022-06-25 04:13:53.212304
# Unit test for function jsonify
def test_jsonify():
    # TODO: Create a test case for this function
    try:
        test_case_0()
    except Exception as exception:
        print(exception)
        # TODO: Add more tests
        assert False


# Generated at 2022-06-25 04:13:57.009656
# Unit test for function jsonify
def test_jsonify():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 04:13:57.902626
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:14:00.968083
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(b'\xf5\x90I\x06\xc1\xfb-9T\x84') == '"\\xf5\\x90I\\x06\\xc1\\xfb-9T\\x84"'

# Generated at 2022-06-25 04:14:11.780004
# Unit test for function jsonify

# Generated at 2022-06-25 04:14:18.412940
# Unit test for function jsonify
def test_jsonify():
    ''
    bytes_0 = b'\xf5\x90I\x06\xc1\xfb-9T\x84'
    var_0 = jsonify(bytes_0)
    assert var_0 == '"\\\\uff57\\\\1649\\\\u0006\\\\u0201\\\\ufffb-9T\\\\u0204"'

    var_1 = jsonify(123)
    assert var_1 == '123'

    var_2 = jsonify(123,True)
    assert var_2 == '123'

    var_3 = jsonify("123")
    assert var_3 == '"123"'

    var_4 = jsonify("123",True)
    assert var_4 == '"123"'

    var_5 = jsonify({})
    assert var_5 == '{}'

    var_6 = jsonify

# Generated at 2022-06-25 04:14:31.262075
# Unit test for function jsonify
def test_jsonify():
    my_dictionary = dict(foo='bar')
    my_string = 'a string'
    my_number = 1
    my_list = [2, 3, 4]
    my_bytes = b'\xf5\x90I\x06\xc1\xfb-9T\x84'

    # Verify simple dictionary
    assert jsonify(my_dictionary) == '{"foo": "bar"}'

    # Verify simple string
    assert jsonify(my_string) == '"a string"'

    # Verify simple number
    assert jsonify(my_number) == '1'

    # Verify simple list
    assert jsonify(my_list) == '[2, 3, 4]'

    # Verify bytes

# Generated at 2022-06-25 04:14:37.003158
# Unit test for function jsonify
def test_jsonify():
    # Ensure that the code will run
    assert True

    # Test case
    test_case_0()

# Generated at 2022-06-25 04:14:39.353538
# Unit test for function jsonify
def test_jsonify():
    test_case_0()


# Generated at 2022-06-25 04:14:44.683771
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import *
    try:
        test_case_0()
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:14:56.886632
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    bytes_0 = b'\xf5\x90I\x06\xc1\xfb-9T\x84'
    jsonify(bytes_0)

# Generated at 2022-06-25 04:14:58.796703
# Unit test for function jsonify
def test_jsonify():
    assert False, 'Need to write your own test'

# Generated at 2022-06-25 04:14:59.881927
# Unit test for function jsonify
def test_jsonify():
    assert var_0 == "{\"f5904906c1fb2d3954\"}"

# Generated at 2022-06-25 04:15:01.926030
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(b'\xf5\x90I\x06\xc1\xfb-9T\x84') == '"\\xf5\\x90I\\x06\\xc1\\xfb-9T\\x84"'

# Generated at 2022-06-25 04:15:05.919555
# Unit test for function jsonify
def test_jsonify():
    # Testing string as input
    data_0 = "dupa"
    var_0 = jsonify(data_0)
    assert var_0 == '"dupa"'

# Generated at 2022-06-25 04:15:13.699048
# Unit test for function jsonify
def test_jsonify():
    # unit tests here
    def _assert_result_is_same_as_format(result):
        assert jsonify(result) == jsonify(result, True)

    _assert_result_is_same_as_format(None)

# Generated at 2022-06-25 04:15:16.234955
# Unit test for function jsonify
def test_jsonify():
    bytes_0 = b'\xf5\x90I\x06\xc1\xfb-9T\x84'
    var_0 = jsonify(bytes_0)



# Generated at 2022-06-25 04:15:17.092942
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:15:20.185611
# Unit test for function jsonify
def test_jsonify():

    test_case_0()

# Generated at 2022-06-25 04:15:22.802375
# Unit test for function jsonify
def test_jsonify():
    assert "ewogICAgInVybCI6ICIgIn0K" == jsonify(b(b'\x7b\x22\x75\x72\x6c\x22\x3a\x20\x22\x20\x22\x7d'))



# Generated at 2022-06-25 04:15:47.633364
# Unit test for function jsonify
def test_jsonify():
    bytes_0 = b'\xf5\x90I\x06\xc1\xfb-9T\x84'
    var_0 = jsonify(bytes_0)
    assert var_0 == '"\\xf5\\x90I\\x06\\xc1\\xfb-9T\\x84"'
    assert var_0 != '"õ\x90I\x06Áû-9T\x84"'
    assert var_0 != '"õ\x90I\x06Áû-9T\x84"'
    assert var_0 != '"õ\x90I\x06Áû-9T\x84"'
    assert var_0 != '"õ\x90I\x06Áû-9T\x84"'


# Generated at 2022-06-25 04:15:50.176901
# Unit test for function jsonify
def test_jsonify():
    # test_case_0
    bytes_0 = b'\xf5\x90I\x06\xc1\xfb-9T\x84'
    var_0 = jsonify(bytes_0)

# Generated at 2022-06-25 04:15:54.000056
# Unit test for function jsonify
def test_jsonify():
    print(jsonify(None))
    print(jsonify({'foo': 'bar'}))
    print(jsonify({'foo': 'bar'}, format=True))

# call case for function jsonify
test_jsonify()

# call case for function test_case_0
test_case_0()

# Generated at 2022-06-25 04:15:55.540228
# Unit test for function jsonify
def test_jsonify():
    assert False == test_case_0()


# Generated at 2022-06-25 04:16:01.696719
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({}, True) == "{\n    \n}"
    assert jsonify({'a': 'foo', 'b': 42}) == '{"a": "foo", "b": 42}'
    assert jsonify({'a': 'foo', 'b': 42}, True) == '''{
    "a": "foo",
    "b": 42
}'''
    assert jsonify({'a': 'foo'}, True) == '''{
    "a": "foo"
}'''
    assert jsonify(42) == "42"
    assert jsonify('foo') == '"foo"'
    assert jsonify({'a': False, 'b': True}) == '{"a": false, "b": true}'

# Generated at 2022-06-25 04:16:05.033802
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'y': 'z'}) == "{\"y\": \"z\"}"
    assert jsonify({'x': [1, 2, 3]}, True) == "{\n    \"x\": [\n        1,\n        2,\n        3\n    ]\n}"

# Generated at 2022-06-25 04:16:08.169131
# Unit test for function jsonify
def test_jsonify():
    var_0 = jsonify(None)
    var_1 = jsonify([])
    var_2 = jsonify({})
    var_3 = jsonify([1, 2, 3, 4], True)
    print(var_0)
    print(var_1)
    print(var_2)
    print(var_3)


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:16:12.694667
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Unit test runs
if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-25 04:16:15.454199
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

if __name__ == "__main__":
    import sys
    sys.exit(test_jsonify())

# Generated at 2022-06-25 04:16:22.688013
# Unit test for function jsonify

# Generated at 2022-06-25 04:17:01.747528
# Unit test for function jsonify
def test_jsonify():
    test_case_0()



# Generated at 2022-06-25 04:17:02.587812
# Unit test for function jsonify
def test_jsonify():
    assert jsonify is not None


# Generated at 2022-06-25 04:17:06.874183
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:17:08.421501
# Unit test for function jsonify
def test_jsonify():
    assert True, "Test that a bytes object doesn't throw an exception"

# Test object creation from existing object
# j = json.loads(json.dumps(o))

# Generated at 2022-06-25 04:17:10.639731
# Unit test for function jsonify
def test_jsonify():
    from json import loads

    assert loads(jsonify(dict(a=1)))["a"] == 1
    assert loads(jsonify(list(range(10)))) == list(range(10))



# Generated at 2022-06-25 04:17:18.167765
# Unit test for function jsonify
def test_jsonify():
    # Mock out test_case_0
    jsonify.test_case_0 = test_case_0

    # Mock out json.dumps
    json.dumps = lambda *args, **kwargs: args[0]

    # Call jsonify
    var_0 = "hello"
    var_1 = jsonify(var_0)

    # Assertions
    assert var_1 == "hello"

# Generated at 2022-06-25 04:17:19.958338
# Unit test for function jsonify
def test_jsonify():
    '''jsonify'''
    bytes_0 = b"\xf5\x90I\x06\xc1\xfb-9T\x84"
    var_0 = jsonify(bytes_0)

# Generated at 2022-06-25 04:17:22.995132
# Unit test for function jsonify
def test_jsonify():
    print('Running Test TestCase_0')
    test_case_0()

if __name__ == '__main__':
    import traceback
    try:
        test_jsonify()
    except Exception as e:
        print(e)
        traceback.print_exc()

# Generated at 2022-06-25 04:17:27.416554
# Unit test for function jsonify
def test_jsonify():
    print ("**test_jsonify**")
    
    try:
        test_case_0()
    except:
        assert False

# Run the test and print results
test_jsonify()

# Generated at 2022-06-25 04:17:29.638808
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == '"\\xf5\\x90I\\x06\\xc1\\xfb-9T\\x84"'

# Generated at 2022-06-25 04:18:14.268136
# Unit test for function jsonify
def test_jsonify():
    assert jsonify((b'\xf5\x90I\x06\xc1\xfb-9T\x84')) == r'"\xf5\x90I\x06\xc1\xfb-9T\x84"'
    assert jsonify(None) == r'{}'
    assert jsonify(dict(a=1, b=2)) == r'{"a": 1, "b": 2}'
    assert jsonify((1, 2, 3)) == r'[1, 2, 3]'
    assert jsonify(1) == r'1'
    assert jsonify(False) == r'false'
    assert jsonify(True) == r'true'



# Generated at 2022-06-25 04:18:15.593301
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0()



# Generated at 2022-06-25 04:18:20.044621
# Unit test for function jsonify
def test_jsonify():
    # function to return a byte object of a dict
    byte_dict = lambda d: json.dumps(d).encode('utf-8') 

    # create a dictionary with a byte object as a value
    result = { 'foo': byte_dict({'bar': 'baz'}) }

    # jsonify the dict and compare again
    result2 = jsonify(result)
    
    assert result2 == '{"foo": {"bar": "baz"}}'
    print('Success')

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:18:21.086484
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'

import pytest


# Generated at 2022-06-25 04:18:21.834044
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:18:31.435624
# Unit test for function jsonify
def test_jsonify():
    test_case_0()


if __name__ == "__main__":
    import sys
    import argparse

    parser = argparse.ArgumentParser(
        description="Perform unit tests, optionally specify which function to test.",
        usage="python -m test.utils jsonify",
    )

    parser.add_argument('function', nargs='?', default='', type=str,
                        help='function to test', choices=['', 'jsonify'])

    args = parser.parse_args()

    print("Performing unit tests for Ansible")

    if args.function == '':
        print("==> Performing unit tests for utils.py")
        print("==> Running unit tests for function jsonify")
        test_case_0()


# Generated at 2022-06-25 04:18:35.474400
# Unit test for function jsonify
def test_jsonify():
    ret_val = test_case_0()
    assert ret_val == "{\"%s\": \"%s\"}" % (b'\xf5\x90I\x06\xc1\xfb-9T\x84', '\xf5\x90I\x06\xc1\xfb-9T\x84')

# Generated at 2022-06-25 04:18:38.860218
# Unit test for function jsonify
def test_jsonify():
    assert type(test_case_0()) is str

## UNIT TESTS ##


# Generated at 2022-06-25 04:18:39.633350
# Unit test for function jsonify
def test_jsonify():
    assert True is not False


# Generated at 2022-06-25 04:18:44.686741
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(b'\xf5\x90I\x06\xc1\xfb-9T\x84')
    assert result == '"\\xf5\\x90I\\x06\\xc1\\xfb-9T\\x84"'
    result = jsonify(b'\xf5\x90I\x06\xc1\xfb-9T\x84', format = True)
    assert result == '"\\xf5\\x90I\\x06\\xc1\\xfb-9T\\x84"'



# Generated at 2022-06-25 04:20:10.852984
# Unit test for function jsonify
def test_jsonify():
    bytes_0 = b'\xf5\x90I\x06\xc1\xfb-9T\x84'
    var_0 = jsonify(bytes_0)
    assert var_0 == '"\\xf5\\x90I\\x06\\xc1\\xfb-9T\\x84"'

# Generated at 2022-06-25 04:20:15.888351
# Unit test for function jsonify
def test_jsonify():
    bytes_0 = b'\xf5\x90I\x06\xc1\xfb-9T\x84'
    var_0 = jsonify(bytes_0)
    assert type(var_0) == str
    assert var_0 == '"\\xf5\\x90I\\x06\\xc1\\xfb-9T\\x84"'

# Generated at 2022-06-25 04:20:23.065558
# Unit test for function jsonify
def test_jsonify():

    import random

    result = random.randint(0, 255)
    result_bytes_0 = b'\xf5\x90I\x06\xc1\xfb-9T\x84'

    # Create a JSON string from result
    var_0 = jsonify(result)
    # Create a JSON string from result
    # Verifies that jsonify encodes bytes as base64
    var_1 = jsonify(result_bytes_0)

    assert var_0 == json.dumps(result)
    assert var_1 == json.dumps(result_bytes_0, separators = (',', ':'))

    # Create a JSON string from result
    # Ensures that indentation is applied
    var_2 = jsonify(result, True)
    # Create a JSON string from result_bytes_0
    # Ensures that

# Generated at 2022-06-25 04:20:33.340033
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    # test the function in various ways, types and combinations
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": None}) == '{"a": null}'
    assert jsonify([1, 2, 3]) == "[1, 2, 3]"
    assert jsonify(["a", "b", "c"]) == '["a", "b", "c"]'
    assert jsonify(["a", u"\ud83d\ude04"]) == '["a", "\\ud83d\\ude04"]'
    assert jsonify(["a", None]) == '["a", null]'
   

# Generated at 2022-06-25 04:20:38.246981
# Unit test for function jsonify
def test_jsonify():
  bytes_0 = b'\xf5\x90I\x06\xc1\xfb-9T\x84'
  var_0 = jsonify(bytes_0)



if __name__ == '__main__':

    #Load json file containing variables
    with open('../../vars/variables.json') as f:
        vars = json.load(f)


    #Write the output file
    with open('../unit_test/unit_test_'+vars['test_name']+'.json',"w") as f:
        f.write(jsonify(test_jsonify().__func__.func_globals))

# Generated at 2022-06-25 04:20:41.607312
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == True
    assert test_case_1() == True
    assert test_case_2() == True
    assert test_case_3() == True
    assert test_case_4() == True
    assert test_case_5() == True
    assert test_case_6() == True
    assert test_case_7() == True


# Asserts that the function 'jsonify' from the module 'ansible.utils.jsonify'
# raises the expected exception.

# Generated at 2022-06-25 04:20:48.776965
# Unit test for function jsonify
def test_jsonify():
    print(jsonify(None, True))
    print(jsonify(None, False))
    print(jsonify(b'\xf5\x90I\x06\xc1\xfb-9T\x84', True))
    print(jsonify(b'\xf5\x90I\x06\xc1\xfb-9T\x84', False))
    print(jsonify(b'\xf5\x90I\x06\xc1\xfb-9T\x84'))

# Generated at 2022-06-25 04:20:55.440569
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == '{"\\xf5\\x90I\\x06\\xc1\\xfb-9T\\x84"}'

# Generated at 2022-06-25 04:20:56.965151
# Unit test for function jsonify
def test_jsonify():
    print(jsonify.__name__)

# Unit test execution
if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 04:20:59.030687
# Unit test for function jsonify
def test_jsonify():
    print("\n*** test_jsonify ***")

    test_case_0()

    # more test cases go here

# Unit test entry point
if __name__ == '__main__':
    test_jsonify()