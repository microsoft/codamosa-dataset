

# Generated at 2022-06-25 04:11:27.928255
# Unit test for function jsonify
def test_jsonify():
    var_0 = test_case_0()
    return var_0

# Generated at 2022-06-25 04:11:29.996207
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:11:34.656488
# Unit test for function jsonify
def test_jsonify():
    a_float = -332.08
    assert jsonify(a_float) == '-332.08'
    a_list = [1, 2, 3]
    assert jsonify(a_list) == '[1, 2, 3]'
    a_dict = {'a': 1, 'b': 2, 'c': 3}
    assert jsonify(a_dict) == '{"a": 1, "b": 2, "c": 3}'


# Generated at 2022-06-25 04:11:35.147325
# Unit test for function jsonify
def test_jsonify():
    assert False


# Generated at 2022-06-25 04:11:38.008600
# Unit test for function jsonify
def test_jsonify():
    tests = [
        {
            "name": "test_case_0",
            "function": test_case_0
        }
    ]

    for test in tests:
        yield test

# Generated at 2022-06-25 04:11:47.133556
# Unit test for function jsonify
def test_jsonify():
    float_0 = float(1.0)
    float_1 = float(1.0)
    float_2 = float(1.0)
    float_3 = float(1.0)
    float_4 = float(1.0)
    float_5 = float(1.0)
    float_6 = float(1.0)

    dict_0 = dict()
    dict_0[u'a'] = float_6
    dict_0[u'c'] = float_5
    dict_0[u'b'] = float_2
    dict_1 = dict()
    dict_1[u'a'] = float_0
    dict_1[u'c'] = float_1
    dict_1[u'b'] = float_4
    dict_2 = dict()

# Generated at 2022-06-25 04:11:51.993878
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:12:01.518704
# Unit test for function jsonify
def test_jsonify():
    float_0 = -332.08
    var_0 = jsonify(float_0)


# Main program
if __name__ == '__main__':
    import timeit

    float_0 = -332.08
    var_0 = jsonify(float_0)

    n = 100
    t1 = timeit.Timer("test_case_0()", setup="from __main__ import test_case_0")
    t2 = timeit.Timer("test_jsonify()", setup="from __main__ import test_jsonify")

    print("[%s/%s] (%.3f, %.3f)" % (n, n, t1.timeit(n), t2.timeit(n)))

# Generated at 2022-06-25 04:12:05.923152
# Unit test for function jsonify
def test_jsonify():
    # Test of function jsonify, generated using tools/generate_tests.py script
    test_cases = [
        (0, ),
    ]
    for index, case in enumerate(test_cases):
        test_case_0()


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:12:15.311052
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(None, format=False) == "{}"
    assert jsonify(None, format=True) == "{}"
    assert jsonify(123) == "123"
    assert jsonify(123, format=False) == "123"
    assert jsonify(123, format=True) == "123"
    assert jsonify(123, format=False) == "123"
    simp_dict = { "a": 1, "b": "two" }
    assert jsonify(simp_dict) == '{"a": 1, "b": "two"}'
    assert jsonify(simp_dict, format=False) == '{"a": 1, "b": "two"}'

# Generated at 2022-06-25 04:12:24.227388
# Unit test for function jsonify
def test_jsonify():
    float_0 = -332.08
    var_0 = jsonify(float_0)
    assert var_0 == '-332.08'
    bool_0 = True
    var_1 = jsonify(bool_0)
    assert var_1 == 'true'
    str_0 = '-332.08'
    var_2 = jsonify(str_0)
    assert var_2 == '"-332.08"'


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-25 04:12:30.044037
# Unit test for function jsonify
def test_jsonify():
    from jinja2 import Template

    source = "{{a}}"

    # test for the string to be rendered
    assert jsonify(source) == '"{{a}}"'

    # test for the variable we are going to render
    result = Template(source).render(a=1)

    # test that the variable was rendered
    assert result == "1"

# Generated at 2022-06-25 04:12:38.374358
# Unit test for function jsonify
def test_jsonify():
    assert jsonify( -332.08 ) == '-332.08'
    assert jsonify( 'spam' ) == '"spam"'
    assert jsonify( 3.14 ) == '3.14'
    assert jsonify( 42 ) == '42'
    assert jsonify( True ) == 'true'
    assert jsonify( False ) == 'false'
    assert jsonify( None ) == 'null'
    assert jsonify( [ 1, 2, 3 ] ) == '[1,2,3]'
    assert jsonify( { 'a': 'b' } ) == '{"a":"b"}'

# Generated at 2022-06-25 04:12:39.404900
# Unit test for function jsonify
def test_jsonify():
    var_0 = test_case_0()
    assert var_0 == "-332.08"

# Generated at 2022-06-25 04:12:42.659492
# Unit test for function jsonify
def test_jsonify():
    # test_case_0()
    test_case_1()


# Generated at 2022-06-25 04:12:51.005514
# Unit test for function jsonify
def test_jsonify():
    for tc_num, tc in test_cases.items():
        test_fn = 'test_case_%s' % tc_num
        print('Calling test function: %s' % test_fn)
        test_globals[test_fn]()
        print('... success')
        print()

test_cases =  { '0': 0, }

test_globals = globals()


if __name__ == '__main__':
    if '0' not in test_cases:
        print('Failed to find specified test case.')

    if '0' in test_cases:
        test_jsonify()

# Generated at 2022-06-25 04:12:51.928171
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == None, "test_case_0"

test_jsonify()

# Generated at 2022-06-25 04:12:56.030616
# Unit test for function jsonify
def test_jsonify():
    from json import dumps as json_dumps
    from sys import _getframe as sys_getframe

    result_0 = jsonify(None, True)
    assert result_0 == '{}'

    result_1 = jsonify([])
    assert result_1 == json_dumps([])

    result_2 = jsonify([{'a':1}])
    assert result_2 == json_dumps([{'a':1}])

    result_3 = jsonify([], True)
    assert result_3 == json_dumps([], indent=4)

    result_4 = jsonify([{'a':1}], True)
    assert result_4 == json_dumps([{'a':1}], indent=4)


# Generated at 2022-06-25 04:13:04.074723
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify('foo') == '"foo"')
    assert(jsonify(None) == "{}")
    assert(jsonify(False) == "false")
    assert(jsonify(True) == "true")
    assert(jsonify(42) == "42")
    assert(jsonify(42.0) == "42.0")
    assert(jsonify({}) == "{}")
    assert(jsonify([]) == "[]")
    assert(jsonify({"foo": "bar"}) == '''{"foo": "bar"}''')
    assert(jsonify(["foo", "bar"]) == '''["foo", "bar"]''')

    # jsonify the result of jsonify
    assert(jsonify(jsonify('foo')) == '''"\"foo\""''')

# Generated at 2022-06-25 04:13:04.854288
# Unit test for function jsonify
def test_jsonify():
    pass

# Generated at 2022-06-25 04:13:13.232532
# Unit test for function jsonify
def test_jsonify():

    # Input parameters
    # Param: result
    result = None

    # Param: format
    format = False

    # Perform the operation
    if test_case_0():
        var_0 = jsonify(result, format)
        assert var_0 == '{}'
        print('Test case 0: PASSED')
    else:
        print('Test case 0: FAILED')


# Create test cases

# Generated at 2022-06-25 04:13:19.153574
# Unit test for function jsonify
def test_jsonify():
    float_0 = -332.08
    var_0 = jsonify(float_0)
    assert var_0 == '-332.08'
    float_1 = 9.78
    var_1 = jsonify(float_1)
    assert var_1 == '9.78'
    list_1 = [0, 'test']
    var_2 = jsonify(list_1)
    assert var_2 == '["0", "test"]'
    # Testing function "jsonify"
    float_2 = 0.09
    var_3 = jsonify(float_2)
    assert var_3 == '0.09'

# Generated at 2022-06-25 04:13:30.949501
# Unit test for function jsonify
def test_jsonify():
    test_cases = [
        # test_case_0
        ( 0, { 'func': 'test_case_0', 'expected_result': '-332.08',
        },
        ),
    ]

    for test_case in test_cases:
        test_case_number = test_case[0]
        test_case_dict   = test_case[1]

        func = test_case_dict['func']
        test_case_setup = setup_function(func)
        exec(test_case_setup)

        func_to_test = '%s()' % func
        expected_result = test_case_dict['expected_result']

        result = eval(func_to_test)
        #print("%s() returned '%s'" % (func, result))


# Generated at 2022-06-25 04:13:37.608681
# Unit test for function jsonify
def test_jsonify():
    
    assert jsonify(1) == "1"
    assert jsonify([1,2,3]) == '[1, 2, 3]'
    assert jsonify([1,2,3], True) == '[\n    1, \n    2, \n    3\n]'
    assert jsonify({'a':1,'b':2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a':1,'b':2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(1.0) == '1.0'
    assert jsonify(123) == '123'
    assert jsonify([1.0,2.0,3.0]) == '[1.0, 2.0, 3.0]'

# Generated at 2022-06-25 04:13:39.903174
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(0.0) == "0.0"
    assert jsonify(True) == "true"
    assert jsonify('{}') == "\"{}\""
    assert jsonify(None) == "{}"

# Generated at 2022-06-25 04:13:45.203677
# Unit test for function jsonify
def test_jsonify():
    print("in main function")
    var_1 = jsonify(float(-332.08))
    print("\n")
    print(var_1)

if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-25 04:13:49.279932
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == "{}"

# vim: set expandtab shiftwidth=4:

# Generated at 2022-06-25 04:13:50.508130
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# main
if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-25 04:13:52.377831
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:13:56.163962
# Unit test for function jsonify
def test_jsonify():
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 04:14:07.600695
# Unit test for function jsonify
def test_jsonify():
    print('Unit test for jsonify.')
    # Run the unit test.
    test_case_0()

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:14:10.088187
# Unit test for function jsonify
def test_jsonify():
    input_str = '{"key1":"val1", "key2": "val2"}'
    output_str = jsonify(input_str)
    assert output_str == input_str

# Generated at 2022-06-25 04:14:17.032643
# Unit test for function jsonify
def test_jsonify():
    import json
    json1 = '{"sadf": "asdf"}'
    json2 = '{"sadf": "asdf", "foo": "bar"}'
    json3 = '{"sadf": "asdf", "foo": "bar", "test": "blah", "gibberish": "alskdjf", "_meta": {"hostvars": {"test": "test"}}}'
    json4 = '{"sadf": "asdf", "foo": "bar", "test": "blah", "gibberish": "alskdjf"}'
    json5 = '{"sadf": "asdf", "foo": "bar", "test": "blah", "_meta": {"hostvars": {"test": "test", "foo": "bar"}}}'

# Generated at 2022-06-25 04:14:21.644041
# Unit test for function jsonify
def test_jsonify():

    # Results that are unused
    result_0 = None

    # Results of function call
    result_1 = jsonify(result_0)

    # Test cases
    assert result_1 == '{}', "Expected {}"



# Generated at 2022-06-25 04:14:24.170167
# Unit test for function jsonify
def test_jsonify():
    try:
        test_case_0()
    except:
        print("Exception caught in function test_case_0()")
        assert False

    assert True

# Generated at 2022-06-25 04:14:29.967835
# Unit test for function jsonify
def test_jsonify():
    print("Testing jsonify")

    test_cases = [
        {
            "func_name" : "test_case_0"
        },
    ]

    for case in test_cases:
        print("Running test: %s" % (case["func_name"]))
        globals()[case["func_name"]]()
        print("Test Passed")

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-25 04:14:38.413043
# Unit test for function jsonify
def test_jsonify():
    test_case = '0'
    # Construct the arguments
    float_0 = -332.08
    func_args = {}
    func_args['float_0'] = float_0

    # Retrieve the function from the script
    func = globals()['test_case_' + test_case]

    # Execute the function
    ret_val = func(**func_args)

    # Verify the results
    assert ret_val is not None, "Return val from function should not be None"

if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-25 04:14:39.262022
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Test for issue #3750

# Generated at 2022-06-25 04:14:40.482348
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == '-332.08'


# Generated at 2022-06-25 04:14:42.316730
# Unit test for function jsonify
def test_jsonify():
    test_case_0()


# Generated at 2022-06-25 04:14:54.502523
# Unit test for function jsonify
def test_jsonify():
    """Ensure jsonify function behaves as expected.

    :param function test_case_0: Ensure jsonify function behaves as expected for the following test case.
    """
    test_case_0()

# Generated at 2022-06-25 04:14:58.596541
# Unit test for function jsonify
def test_jsonify():
    assert (test_case_0() == -332.08)

# Generated at 2022-06-25 04:15:01.933488
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify '''

    # Test for string for dict
    dict_0 = {"one": "apple", "two": "banana", "three": "carrot"}
    var_0 = jsonify(dict_0)

# Generated at 2022-06-25 04:15:04.410838
# Unit test for function jsonify
def test_jsonify():
    print(jsonify)
    test_case_0()

# Generated at 2022-06-25 04:15:10.716230
# Unit test for function jsonify
def test_jsonify():
    assert (jsonify(-300) == '-300'), 'jsonify(-300) == -300'
    assert (jsonify(1) == '1'), 'jsonify(1) == 1'
    assert (jsonify(2) == '2'), 'jsonify(2) == 2'
    assert (jsonify(3) == '3'), 'jsonify(3) == 3'
    assert (jsonify(4) == '4'), 'jsonify(4) == 4'
    assert (jsonify(5) == '5'), 'jsonify(5) == 5'


# Generated at 2022-06-25 04:15:11.888885
# Unit test for function jsonify
def test_jsonify():
    result_0 = jsonify('')
    assert result_0 == '{}'



# Generated at 2022-06-25 04:15:13.339581
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == None

# Generated at 2022-06-25 04:15:21.618739
# Unit test for function jsonify
def test_jsonify():
    print('Test jsonify')

    # Setup
    float_0 = -332.08

    # Testing function
    var_0 = jsonify(float_0)

    # Checking if the result is as expected
    print('Test 1/4: Checking if the result is as expected')
    assert var_0 == '-332.08'

    # Testing function
    var_0 = jsonify(float_0)

    # Checking if the result is as expected
    print('Test 2/4: Checking if the result is as expected')
    assert var_0 == '-332.08'

    # Testing function
    var_0 = jsonify(float_0)

    # Checking if the result is as expected
    print('Test 3/4: Checking if the result is as expected')
    assert var_0 == '-332.08'

    # Testing

# Generated at 2022-06-25 04:15:33.235578
# Unit test for function jsonify
def test_jsonify():
    # Test for float_0
    float_0 = -332.08
    ans = jsonify(float_0)
    assert ans=="-332.08"

    # Test for list_0
    list_0 = [2, 3, 4, '5', 6, 7]
    ans = jsonify(list_0, format=True)
    assert ans=="[\n    2,\n    3,\n    4,\n    \"5\",\n    6,\n    7\n]"
    
    # Test for list_1
    list_1 = [1, 2, 3, 4]
    ans = jsonify(list_1, format=False)
    assert ans=="[1, 2, 3, 4]"
    
    # Test for int_0
    int_0 = -8

# Generated at 2022-06-25 04:15:34.208730
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:15:58.391092
# Unit test for function jsonify
def test_jsonify():
    var_0 = jsonify('z')
    assert str(var_0) == '"z"'

    float_0 = -332.08
    var_0 = jsonify(float_0)
    assert float(var_0) == float_0

    str_0 = ''
    var_0 = jsonify(str_0)
    assert str(var_0) == '""'

    str_0 = ''
    var_0 = jsonify(str_0)
    assert str(var_0) == '""'

    str_0 = '""'
    var_0 = jsonify(str_0)
    assert str(var_0) == '"\\"\\""'

    float_0 = -13.65
    float_1 = -0.04
    var_0 = jsonify(float_0)


# Generated at 2022-06-25 04:16:02.914857
# Unit test for function jsonify
def test_jsonify():
    print('Testing jsonify()')
    test_case_0()
    print('Finished testing jsonify()')

# Main function that takes care of calling the test functions

# Generated at 2022-06-25 04:16:08.940966
# Unit test for function jsonify
def test_jsonify():
    var_0 = None
    var_0 = jsonify(var_0)

    float_0 = -332.08
    var_0 = jsonify(float_0)
    assert var_0 == '-332.08'

    str_0 = 'foobar'
    int_0 = 8
    dict_0 = {'foo': 'bar'}
    list_0 = -70
    list_0 = [75]
    list_1 = -320
    list_1 = [list_0, list_1]
    dict_0 = {'foo': list_1, 'bar': dict_0, 'foobar': str_0, 'foobarbaz': int_0}
    var_0 = jsonify(dict_0)

# Generated at 2022-06-25 04:16:16.664426
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(45) == "45"
    assert jsonify("test") == "\"test\""
    assert jsonify(True) == "true"
    assert jsonify(["one", "two"]) == "[\n    \"one\", \n    \"two\"\n]"
    assert jsonify({'one': 'two'}) == "{\n    \"one\": \"two\"\n}"
    assert jsonify({"one": "two"}) == "{\n    \"one\": \"two\"\n}"
    assert jsonify(1.5) == "1.5"
    assert jsonify([]) == "[]"
    assert jsonify(None) == "{}"

# Generated at 2022-06-25 04:16:18.526448
# Unit test for function jsonify
def test_jsonify():
    class TestJsonify:
        def test_jsonify(self):
            test_case_0()



# Generated at 2022-06-25 04:16:20.678539
# Unit test for function jsonify
def test_jsonify():
    float_0 = -332.08
    var_0 = jsonify(float_0)

    assert var_0 == "-332.08"



# Generated at 2022-06-25 04:16:22.783895
# Unit test for function jsonify
def test_jsonify():
    expected_0 = '-332.08'
    json_0 = jsonify(-332.08)
    assert json_0 == expected_0

# Generated at 2022-06-25 04:16:23.705894
# Unit test for function jsonify
def test_jsonify():
    # Unit: test_0
    test_case_0()
    pass

# Generated at 2022-06-25 04:16:34.451789
# Unit test for function jsonify
def test_jsonify():
    '''jsonify'''
    ansible_1 = dict(changed=False, failed=True, stdout='fubar')
    json_1 = jsonify(ansible_1, format=False)
    json_2 = jsonify(ansible_1, format=True)
    # This example includes non-ASCII characters, so it cannot be represented
    # with a python string literal.
    expected_1 = ('{"stdout": "fubar", "changed": false, "failed": true}')
    expected_2 = ('{\n    "changed": false, \n    "failed": true, \n    "stdout": "fubar"\n}')

    assert json_1 == expected_1
    assert json_2 == expected_2



# Generated at 2022-06-25 04:16:36.208109
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([1, 2, 3], True) == '[\n    1, \n    2, \n    3\n]'

test_case_0()

# Generated at 2022-06-25 04:17:17.230491
# Unit test for function jsonify
def test_jsonify():
    float_0 = -332.08
    var_0 = jsonify(float_0)
    assert var_0 == '-332.08'

# Generated at 2022-06-25 04:17:22.925858
# Unit test for function jsonify
def test_jsonify():
    print("In test_jsonify")

    # Execute the function we are testing
    test_case_0()

# Execute the unit tests
test_jsonify()

# Generated at 2022-06-25 04:17:32.736047
# Unit test for function jsonify
def test_jsonify():
    var_0 = jsonify(None)
    assert var_0 == '{}'
    var_1 = jsonify(None, True)
    assert var_1 == '{}'
    var_2 = jsonify(float('-332.08'))
    assert var_2 == '-332.08'
    var_3 = jsonify(float('-332.08'), True)
    assert var_3 == '-332.08'
    var_4 = jsonify(int(-1171457611))
    assert var_4 == '-1171457611'
    var_5 = jsonify(int(-1171457611), True)
    assert var_5 == '-1171457611'
    var_6 = jsonify(int(-1833608336))
    assert var_6 == '-1833608336'


# Generated at 2022-06-25 04:17:33.984662
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:17:42.428813
# Unit test for function jsonify
def test_jsonify():
    # Stage 1
    float_0 = -332.08
    var_0 = jsonify(float_0)
    # Stage 2
    dict_0 = { 'B': { 'B': { 'C': -7.71, 'A': -8.51 }, 'A': -5.5, 'C': -6.5 }, 'A': { 'B': -6.67, 'A': -6.85, 'C': -6.31 } }
    var_1 = jsonify(dict_0)
    # Stage 3

# Generated at 2022-06-25 04:17:44.174923
# Unit test for function jsonify
def test_jsonify():
    float_0 = -332.08
    var_0 = jsonify(float_0)


# Generated at 2022-06-25 04:17:45.351550
# Unit test for function jsonify
def test_jsonify():
    print("Testing jsonify()")

    test_case_0()


# Generated at 2022-06-25 04:17:49.254977
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:17:51.803616
# Unit test for function jsonify
def test_jsonify():
    float_0 = -332.08
    var_0 = jsonify(float_0)


# Generated at 2022-06-25 04:17:55.013160
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('hello') == '"hello"'
    assert jsonify({'hello': 'world'}) == '{"hello": "world"}'
    assert jsonify({'hello': 'world'}, True) == '{\n    "hello": "world"\n}'

# Generated at 2022-06-25 04:19:14.696641
# Unit test for function jsonify
def test_jsonify():
    test_case_0()


if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-25 04:19:15.686785
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:19:18.557235
# Unit test for function jsonify
def test_jsonify():

    # From test case test_case_0
    float_0 = -332.08
    var_0 = jsonify(float_0)
    print('var_0 : ' + str(var_0))

if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-25 04:19:20.007241
# Unit test for function jsonify
def test_jsonify():
    from __main__ import jsonify

    result = jsonify({"msg": "this is a test"})

    assert result == '{"msg": "this is a test"}'

# Generated at 2022-06-25 04:19:23.118602
# Unit test for function jsonify
def test_jsonify():
    print("INFO: test_jsonify")
    try:
        test_case_0()
        print("INFO: Success")
    except Exception as e:
        print("INFO: Failed")
        print("ERROR: {0}".format(e))

# Generated at 2022-06-25 04:19:29.330018
# Unit test for function jsonify
def test_jsonify():
    test_0_json = test_case_0()
    test_0_result = json.loads(test_0_json)
    assert test_0_result == -332.08

# Generated at 2022-06-25 04:19:30.730820
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:19:32.920874
# Unit test for function jsonify
def test_jsonify():
    # Unit test for function jsonify

    # Passed
    print("")
    print("test_jsonify")
    print("Passed")
    print("")
    pass




# Generated at 2022-06-25 04:19:33.528177
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-25 04:19:38.381377
# Unit test for function jsonify
def test_jsonify():
    print("Test: function jsonify")
    test_case_0()

