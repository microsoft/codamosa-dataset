

# Generated at 2022-06-17 06:22:55.132274
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:23:00.800127
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(None) == '{}'
    assert jsonify(None, True) == '{}'

# Generated at 2022-06-17 06:23:12.225394
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:23:23.635514
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:23:29.670125
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:23:36.041012
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:23:40.533247
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:23:44.924912
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify '''

    assert jsonify(None) == '{}'
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, True) == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 06:23:48.283778
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:23:58.317033
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:24:02.780621
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:24:09.061835
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:24:12.333043
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == '{\n    "a": 1\n}'
    assert jsonify(None) == '{}'
    assert jsonify(None, True) == '{}'

# Generated at 2022-06-17 06:24:25.550845
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, format=True) == '{\n    "a": "b"\n}'
    assert jsonify({'a': 'b', 'c': 'd'}, format=True) == '{\n    "a": "b", \n    "c": "d"\n}'
    assert jsonify({'a': 'b', 'c': 'd'}) == '{"a": "b", "c": "d"}'
    assert jsonify({'a': 'b', 'c': 'd', 'e': 'f'}) == '{"a": "b", "c": "d", "e": "f"}'

# Generated at 2022-06-17 06:24:31.543196
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'


# Generated at 2022-06-17 06:24:33.921229
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:24:42.577633
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, format=True) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify({'a': 1, 'b': 2, 'c': 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:24:50.141915
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, True) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'

# Generated at 2022-06-17 06:24:59.877765
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(None) == '{}'
    assert jsonify(None, True) == '{}'
    assert jsonify(['a', 'b']) == '["a", "b"]'
    assert jsonify(['a', 'b'], True) == '[\n    "a", \n    "b"\n]'

# Generated at 2022-06-17 06:25:09.107813
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-17 06:25:24.595018
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:25:30.346307
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": "中文"}) == '{"a": 1, "b": 2, "c": "\\u4e2d\\u6587"}'

# Generated at 2022-06-17 06:25:41.690826
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({'a': 1, 'b': [2, 3]}) == '{"a": 1, "b": [2, 3]}'

# Generated at 2022-06-17 06:25:46.270435
# Unit test for function jsonify
def test_jsonify():
    result = {'a': 'b'}
    assert jsonify(result) == '{"a": "b"}'
    assert jsonify(result, True) == '{\n    "a": "b"\n}'
    assert jsonify(None) == '{}'
    assert jsonify(None, True) == '{}'

# Generated at 2022-06-17 06:25:54.059153
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({'a': 1}, format=False) == '{"a": 1}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({'a': 1, 'b': 2}, format=False) == '{"a": 1, "b": 2}'

# Generated at 2022-06-17 06:25:58.012797
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:26:06.823814
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2, c=dict(d=3, e=4)), format=True) == '{\n    "a": 1, \n    "b": 2, \n    "c": {\n        "d": 3, \n        "e": 4\n    }\n}'

# Generated at 2022-06-17 06:26:13.908314
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:26:24.764387
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, format=True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-17 06:26:30.423696
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:26:47.279759
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2, c=dict(d=3, e=4))) == '{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}'

# Generated at 2022-06-17 06:26:51.773559
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:26:55.206045
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, True) == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 06:26:58.280116
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:27:08.667941
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, True) == '{\n    "a": "b"\n}'
    assert jsonify(['a', 'b']) == '["a", "b"]'
    assert jsonify(['a', 'b'], True) == '[\n    "a", \n    "b"\n]'
    assert jsonify({'a': ['b', 'c']}) == '{"a": ["b", "c"]}'
    assert jsonify({'a': ['b', 'c']}, True) == '{\n    "a": [\n        "b", \n        "c"\n    ]\n}'

# Generated at 2022-06-17 06:27:17.447942
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, True) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b", "c": "d"}, True) == '{\n    "a": "b", \n    "c": "d"\n}'
    assert jsonify({"a": "b", "c": "d", "e": "f"}, True) == '{\n    "a": "b", \n    "c": "d", \n    "e": "f"\n}'

# Generated at 2022-06-17 06:27:23.648538
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(None) == '{}'

# Generated at 2022-06-17 06:27:34.290600
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2, c=dict(d=3, e=4))) == '{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}'

# Generated at 2022-06-17 06:27:44.450762
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2, c=dict(d=3, e=4))) == '{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}'

# Generated at 2022-06-17 06:27:52.939214
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({'a': 1, 'b': 2, 'c': 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:28:24.642012
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, True) == '{\n    "a": "b"\n}'
    assert jsonify({'a': 'b', 'c': 'd'}) == '{"a": "b", "c": "d"}'
    assert jsonify({'a': 'b', 'c': 'd'}, True) == '{\n    "a": "b", \n    "c": "d"\n}'
    assert jsonify({'a': 'b', 'c': 'd', 'e': 'f'}) == '{"a": "b", "c": "d", "e": "f"}'

# Generated at 2022-06-17 06:28:29.979161
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2, c=dict(d=3, e=4))) == '{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}'

# Generated at 2022-06-17 06:28:40.747704
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, format=True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-17 06:28:48.859310
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:28:53.684276
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:29:02.916723
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2, c=dict(d=3, e=4))) == '{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}'

# Generated at 2022-06-17 06:29:14.063027
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({'a': 1, 'b': 2, 'c': 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:29:24.331699
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:29:27.892992
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:29:39.919130
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, format=True) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:30:27.150624
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-17 06:30:33.881467
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:30:43.500115
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:30:46.573665
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:30:52.724230
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:31:00.441362
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:31:07.106110
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2}, False) == '{"a": 1, "b": 2}'

# Generated at 2022-06-17 06:31:15.302420
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-17 06:31:26.251575
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2, c=dict(d=3, e=4))) == '{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}'

# Generated at 2022-06-17 06:31:38.230153
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'