

# Generated at 2022-06-17 06:23:03.161144
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:23:13.489799
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2, c=dict(d=3, e=4))) == '{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}'

# Generated at 2022-06-17 06:23:20.373343
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:23:24.823297
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, True) == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 06:23:35.025833
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:23:39.424096
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, format=True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:23:43.601280
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:23:51.824597
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, format=True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-17 06:24:02.953704
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:24:10.577484
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, format=True) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b", "c": "d"}, format=True) == '{\n    "a": "b", \n    "c": "d"\n}'

# Generated at 2022-06-17 06:24:18.114527
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:24:26.327178
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1)) == '{"a": 1}'
    assert jsonify(dict(a=1), True) == '{\n    "a": 1\n}'
    assert jsonify(dict(a=1, b=2), True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2, c=3), True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-17 06:24:28.056067
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:24:31.750323
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:24:38.128241
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2, c=dict(d=3, e=4))) == '{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}'

# Generated at 2022-06-17 06:24:45.080967
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:24:48.309432
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:24:52.471595
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:25:02.693709
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-17 06:25:11.530460
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-17 06:25:26.575607
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, True) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'

# Generated at 2022-06-17 06:25:37.104087
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2, c=dict(d=3, e=4))) == '{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}'

# Generated at 2022-06-17 06:25:48.309563
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({'a': {'b': 1, 'c': 2}}) == '{"a": {"b": 1, "c": 2}}'

# Generated at 2022-06-17 06:25:52.998632
# Unit test for function jsonify
def test_jsonify():
    result = {'a': 1, 'b': 2}
    assert jsonify(result) == '{"a": 1, "b": 2}'
    assert jsonify(result, True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:26:03.832879
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2, c=AnsibleUnsafeText(u'\u1234'))) == '{"a": 1, "b": 2, "c": "\\u1234"}'

# Generated at 2022-06-17 06:26:13.584292
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": [1, 2, 3]}) == '{"a": 1, "b": [1, 2, 3]}'

# Generated at 2022-06-17 06:26:24.713417
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({'a': 1, 'b': 2}, format=False) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({'a': 1, 'b': 2}, format=False) == '{"a": 1, "b": 2}'

# Generated at 2022-06-17 06:26:36.049322
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": {"c": 2}}) == '{"a": 1, "b": {"c": 2}}'

# Generated at 2022-06-17 06:26:46.730497
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, True) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'

# Generated at 2022-06-17 06:26:52.387397
# Unit test for function jsonify
def test_jsonify():
    result = {'a': 1, 'b': 2}
    assert jsonify(result) == '{"a": 1, "b": 2}'
    assert jsonify(result, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(None) == '{}'

# Generated at 2022-06-17 06:27:07.742697
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:27:11.675752
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, format=True) == '{\n    "a": "b"\n}'
    assert jsonify(None) == '{}'

# Generated at 2022-06-17 06:27:17.436407
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, True) == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 06:27:27.724960
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, True) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:27:37.950985
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:27:43.443687
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, format=True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:27:48.856534
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, True) == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 06:27:59.419952
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, format=True) == '{\n    "a": "b"\n}'
    assert jsonify({'a': 'b', 'c': 'd'}) == '{"a": "b", "c": "d"}'
    assert jsonify({'a': 'b', 'c': 'd'}, format=True) == '{\n    "a": "b", \n    "c": "d"\n}'
    assert jsonify({'a': 'b', 'c': 'd', 'e': 'f'}) == '{"a": "b", "c": "d", "e": "f"}'

# Generated at 2022-06-17 06:28:06.137364
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({'a': 1, 'b': 2}, True) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify({'a': 1, 'b': 2, 'c': 3}, True) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'

# Generated at 2022-06-17 06:28:12.580437
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:28:28.649048
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2, c=dict(d=3, e=4))) == '{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}'

# Generated at 2022-06-17 06:28:40.153183
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:28:43.124862
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:28:48.309187
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(None) == '{}'
    assert jsonify(AnsibleUnsafeText('test')) == '"test"'

# Generated at 2022-06-17 06:28:59.690520
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:29:03.731675
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:29:14.659856
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({'a': 1, 'b': 2}, format=True) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify({'a': 1, 'b': 2, 'c': 3}, format=True) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'

# Generated at 2022-06-17 06:29:21.240221
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == '{\n    "a": 1\n}'
    assert jsonify(None) == '{}'
    assert jsonify(None, True) == '{}'

# Generated at 2022-06-17 06:29:29.053974
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-17 06:29:41.021191
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:30:01.126473
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(True) == "true"
    assert jsonify(False) == "false"
    assert jsonify(1) == "1"
    assert jsonify(1.1) == "1.1"
    assert jsonify("foo") == "\"foo\""
    assert jsonify([1,2,3]) == "[1, 2, 3]"
    assert jsonify({"a":1,"b":2}) == "{\"a\": 1, \"b\": 2}"
    assert jsonify({"a":1,"b":2}, format=True) == "{\n    \"a\": 1, \n    \"b\": 2\n}"

# Generated at 2022-06-17 06:30:13.477186
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": "中文"}) == '{"a": 1, "b": 2, "c": "中文"}'
    assert jsonify({"a": 1, "b": 2, "c": "中文"}, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": "中文"\n}'

if __name__ == '__main__':
    test_

# Generated at 2022-06-17 06:30:25.355011
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2, c=dict(d=3, e=4))) == '{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}'

# Generated at 2022-06-17 06:30:30.067252
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(None) == '{}'

# Generated at 2022-06-17 06:30:32.935595
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:30:43.406823
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-17 06:30:47.031634
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({'a': 1}, False) == '{"a": 1}'

# Generated at 2022-06-17 06:30:56.422823
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:31:02.384432
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:31:06.120718
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:31:30.539014
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:31:40.846815
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-17 06:31:45.070057
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:31:52.139945
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:32:01.396964
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, format=True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-17 06:32:10.678551
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-17 06:32:18.009733
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-17 06:32:23.468106
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-17 06:32:34.118669
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, True) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b", "c": "d"}, True) == '{\n    "a": "b", \n    "c": "d"\n}'
    assert jsonify({"a": "b", "c": "d", "e": "f"}, True) == '{\n    "a": "b", \n    "c": "d", \n    "e": "f"\n}'

# Generated at 2022-06-17 06:32:37.716631
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'