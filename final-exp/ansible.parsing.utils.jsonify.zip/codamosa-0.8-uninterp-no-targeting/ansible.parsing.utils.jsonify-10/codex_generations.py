

# Generated at 2022-06-20 23:29:56.478899
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify '''

    # No input
    string = jsonify(None)
    assert string == "{}"

    # With input
    string = jsonify({"a": 1, "b": 2, "c": 3})
    assert string == '{"a": 1, "b": 2, "c": 3}'

    # With input, unicode (from ansible-doc)
    string = jsonify({"a": 1, "b": u'\xaf'})
    assert string == '{"a": 1, "b": "\\u00af"}'

# Generated at 2022-06-20 23:29:58.852050
# Unit test for function jsonify
def test_jsonify():

    assert jsonify({"a": 2}) == '{\"a\": 2}'

# Generated at 2022-06-20 23:30:04.247259
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(1) == '1'
    assert jsonify(True) == 'true'
    assert jsonify(None) == '{}'
    assert jsonify([1]) == '[1]'

# Generated at 2022-06-20 23:30:16.673828
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text

    # Check that jsonify immediately returns for None
    assert jsonify(None) == "{}"

    # Test with good output
    value = {u'state': u'foo'}
    assert jsonify(value) == "{\"state\": \"foo\"}"

    # Test format=True
    assert jsonify(value, format=True) == "{\n    \"state\": \"foo\"\n}"

    # Test with UnicodeDecodeError
    value = {u'state': to_text("\u2026")}
    assert jsonify(value) == "{\"state\": \"\\u2026\"}"
    assert jsonify(value, format=True) == "{\n    \"state\": \"\\u2026\"\n}"



# Generated at 2022-06-20 23:30:24.473791
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify function '''

    # test object is serialized
    result = jsonify({'foo': 'bar'})
    assert result == '{"foo": "bar"}'

    # test non-serializable object is wrapped
    result = jsonify(all)
    assert result == '{"_ansible_no_log": false, "invocation": {"module_args": {"_ansible_debug": false}}}'

    # test indenting
    result = jsonify({'foo': 'bar'}, format=True)
    assert result == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-20 23:30:30.858956
# Unit test for function jsonify
def test_jsonify():
    # Test no result
    no_result = {}
    test_result = jsonify(no_result)
    assert test_result == '{}'

    # Test result that is a list
    list_result = [1,2,3]
    test_result = jsonify(list_result)
    assert test_result == '[1, 2, 3]'

# Generated at 2022-06-20 23:30:40.140711
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a":"b"}) == "{\"a\": \"b\"}"
    assert jsonify({"a":"b", "c":"d"}) == "{\"a\": \"b\", \"c\": \"d\"}"
    assert jsonify({"a":None}) == "{\"a\": null}"
    assert jsonify({"a":[1,2,3]}) == "{\"a\": [1, 2, 3]}"
    assert jsonify({"a":{"b":1, "c":2}}) == "{\"a\": {\"b\": 1, \"c\": 2}}"

# Generated at 2022-06-20 23:30:51.263049
# Unit test for function jsonify
def test_jsonify():
    args = {'foo': 'bar', 'baz': ['a', 1, {'c': 2}]}
    results = [
        jsonify(args, format=False),
        jsonify(args, format=True)
    ]
    assert results == ['{"baz": ["a", 1, {"c": 2}], "foo": "bar"}',
                      '{\n    "baz": [\n        "a", \n        1, \n        {\n            "c": 2\n        }\n    ], \n    "foo": "bar"\n}']

# vim: set expandtab sw=4:

# Generated at 2022-06-20 23:31:04.843304
# Unit test for function jsonify
def test_jsonify():
    ''' ansible jsonify unit tests '''

    import ansible.utils.jsonify
    import types

    # empty input
    assert ansible.utils.jsonify.jsonify(None) == "{}"

    # basic structure
    data = {'token': 'string', 'value': 1}
    assert ansible.utils.jsonify.jsonify(data) == '{"token": "string", "value": 1}'

    # unicode support
    data = {'token': u'string', 'value': 1}
    assert ansible.utils.jsonify.jsonify(data) == '{"token": "string", "value": 1}'

    # nested array
    data = {'token': ['string', 1]}
    assert ansible.utils.jsonify.jsonify(data) == '{"token": ["string", 1]}'

# Generated at 2022-06-20 23:31:13.874102
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1}) == '{"a": 1}\n'
    assert jsonify({'a': 1}, format=True) == '{\n    "a": 1\n}\n'
    assert jsonify(['a', 'b', 'c']) == '["a", "b", "c"]\n'
    assert jsonify(['a', 'b', 'c'], format=True) == '[\n    "a", \n    "b", \n    "c"\n]\n'

# Generated at 2022-06-20 23:31:27.393464
# Unit test for function jsonify
def test_jsonify():
    """ test dict with utf-8 unicode"""
    assert jsonify(dict(name="dave", info=u"\u7a33\u5b9a"), format=True) == \
        """{
    "info": "\\u7a33\\u5b9a",
    "name": "dave"
}"""

    assert jsonify(dict(name="dave", info=u"\u7a33\u5b9a"), format=False) == \
        '{"name": "dave", "info": "\\u7a33\\u5b9a"}'

    """ test dict with non utf-8 unicode"""

# Generated at 2022-06-20 23:31:29.546465
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 2}) == '{"a": 2}'

# Generated at 2022-06-20 23:31:44.040300
# Unit test for function jsonify
def test_jsonify():

    assert "{}" == jsonify(None)
    assert jsonify(42) == '{"msg": "42"}'
    assert jsonify('bob') == '{"msg": "bob"}'
    assert jsonify(dict(a=1,b=2)) == '{"a": 1, "b": 2}'
    assert jsonify([1,2,3]) == '[1, 2, 3]'
    assert jsonify({'msg': 'foo', 'changed': True, 'invocation': {'module_args': {'param1': 'value1', 'param2': 'value2', 'param3': 'value3'}}})  == '{"changed": true, "invocation": {"module_args": {"param1": "value1", "param2": "value2", "param3": "value3"}}, "msg": "foo"}'


# Generated at 2022-06-20 23:31:45.726951
# Unit test for function jsonify
def test_jsonify():
    # TODO: Finish jsonify unit test
    return True

# Generated at 2022-06-20 23:31:53.495609
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import six

    result = {
        'changed': False,
        'failed': False,
        'foo': {
            'bar': [
                'baz',
                six.u('p\xe9ch\xe9')
            ]
        },
        'invocation': {},
        'rc': 0
    }

    assert jsonify(result) == "{\"changed\": false, \"failed\": false, \"invocation\": {}, \"rc\": 0, \"foo\": {\"bar\": [\"baz\", \"péché\"]}}"

# Generated at 2022-06-20 23:32:03.047611
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(['a', 'b']) == json.dumps(['a', 'b'])
    assert jsonify(['a', 'b'], format=True) == json.dumps(['a', 'b'], sort_keys=True, indent=4, ensure_ascii=False)
    assert jsonify(['a', 'b']).encode('utf-8') == b'["a", "b"]'
    assert jsonify(['a', 'b'], format=True).encode('utf-8') == b'[\n    "a",\n    "b"\n]'

# Generated at 2022-06-20 23:32:07.896332
# Unit test for function jsonify
def test_jsonify():
    struct1 = {'a': 1, 'b': 2, 'c': 3}
    struct2 = None
    struct3 = [1, 2, 3]

    assert jsonify(struct1) == "{\"a\": 1, \"b\": 2, \"c\": 3}"
    assert jsonify(struct1, format=True) == "{\n    \"a\": 1, \n    \"b\": 2, \n    \"c\": 3\n}"
    assert jsonify(struct2) == "{}"
    assert jsonify(struct3, format=True) == "[\n    1, \n    2, \n    3\n]"
    assert jsonify(struct3) == "[1, 2, 3]"
    assert jsonify(struct3, format=True) == "[\n    1, \n    2, \n    3\n]"



# Generated at 2022-06-20 23:32:10.386099
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == "{}"
    assert jsonify(None) == "{}"
    assert jso

# Generated at 2022-06-20 23:32:17.472104
# Unit test for function jsonify
def test_jsonify():
    result = { 'a': 1, 'b': 2, 'c': 3 }
    assert jsonify(result) == "{\"a\": 1, \"b\": 2, \"c\": 3}"
    assert jsonify(result, True) == "{\n    \"a\": 1,\n    \"b\": 2,\n    \"c\": 3\n}"


# Generated at 2022-06-20 23:32:21.538354
# Unit test for function jsonify
def test_jsonify():
    results = {}
    result = jsonify(results, True)
    assert result == '{\n    \n}'

    results = {'a': 'test'}
    result = jsonify(results)
    assert result == '{"a":"test"}'

# Generated at 2022-06-20 23:32:36.918544
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([{'foo': 'bar'}], False)    == '[{"foo": "bar"}]'
    assert jsonify([{'foo': 'bar'}], True)     == '[\n    {\n        "foo": "bar"\n    }\n]'
    assert jsonify(None, False)                == '{}'
    assert jsonify(None, True)                 == '{}'
    assert jsonify({'a': 'b', 'c': 'd'}, False) == '{"a": "b", "c": "d"}'
    assert jsonify({'a': 'b', 'c': 'd'}, True)  == '{\n    "a": "b", \n    "c": "d"\n}'

# Generated at 2022-06-20 23:32:50.068549
# Unit test for function jsonify
def test_jsonify():
    '''testing jsonify()'''
    # Simple result set
    result = jsonify({'a':1})
    assert result == '{"a": 1}'

    # Complex result set
    result = jsonify({'a':1, 'b':[1,2,3,4], 'c':[{'d':{'e':5}}, 'f']})
    assert result == '''{
    "a": 1,
    "b": [
        1,
        2,
        3,
        4
    ],
    "c": [
        {
            "d": {
                "e": 5
            }
        },
        "f"
    ]
}'''

    # Unicode
    result = jsonify({u'a':u'€'})

# Generated at 2022-06-20 23:32:57.098944
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify()'''

    result = jsonify({'hello': 'world'})
    assert result == '{"hello": "world"}'

    result2 = jsonify({'hello': 'world'}, format=True)
    assert result2 == '{\n    "hello": "world"\n}'

    result3 = jsonify(None)
    assert result3 == '{}'

# Generated at 2022-06-20 23:32:59.812514
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(x=1)) == '{"x": 1}'
    assert jsonify(dict(x=1), format=True) == "{\n    \"x\": 1\n}"


# Generated at 2022-06-20 23:33:12.834078
# Unit test for function jsonify
def test_jsonify():
    '''test jsonify'''

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.compat.tests import unittest

    test_data = b'{"unicode_data": "\xe9"}'
    json_data = json.loads(test_data)

    class TestJsonify(unittest.TestCase):
        ''' class to test jsonify '''


# Generated at 2022-06-20 23:33:20.417026
# Unit test for function jsonify
def test_jsonify():
    ''' Function jsonify should return proper JSON regardless input format (string, dict, list, integer)
        Testcases:
        - Input: string
        - Input: dict
        - Input: list
        - Input: integer

        Returned JSON should be correctly indented and unicode characters should be properly handled.
    '''
    result = {'a': 'string', 'b': [1, 2, 3], 'c': {'x': 'y'}}
    assert jsonify(result) == '{\n"a": "string", \n"b": [\n1, \n2, \n3\n], \n"c": {\n"x": "y"\n}\n}'

# Generated at 2022-06-20 23:33:23.737264
# Unit test for function jsonify
def test_jsonify():
    # basic jsonify test
    res = dict(changed=False, msg="foo")
    assert "{\"changed\": false, \"msg\": \"foo\"}" == jsonify(res)


# Generated at 2022-06-20 23:33:28.050956
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(1) == "{}"
    assert jsonify(dict(foo=1)) == '{"foo": 1}'
    assert jsonify(dict(foo=1), format=True) == '{\n    "foo": 1\n}'

# Generated at 2022-06-20 23:33:34.590437
# Unit test for function jsonify
def test_jsonify():
    # test returning of an empty string for a null value
    assert jsonify(None) == '{}'

    # test returning of an empty string for a value of False
    assert jsonify(False) == 'false'

    # test returning of a string for a value of True
    assert jsonify(True) == 'true'

# Generated at 2022-06-20 23:33:44.211109
# Unit test for function jsonify
def test_jsonify():
    ''' Test jsonify '''
    import os

    old_display = os.environ.get("ANSIBLE_DISPLAY_OK_HOSTS", None)
    os.environ["ANSIBLE_DISPLAY_OK_HOSTS"] = "1"
    result = jsonify({
        'dark': {
            'hosts': {
                'joker': {
                    'ok': True,
                    'msg': 'All is well',
                    'changed': False
                }
            }
        }
    })
    assert result == '''{
    "dark": {
        "hosts": {
            "joker": {
                "ok": true,
                "msg": "All is well",
                "changed": false
            }
        }
    }
}'''


# Generated at 2022-06-20 23:33:57.539585
# Unit test for function jsonify
def test_jsonify():
    result = dict(changed=True, rc=0, stdout='some stdout', start='s', end='e', delta='d')
    assert jsonify(result) == "{}"
    assert jsonify(result, True) == "{}"

    x = "foo"
    assert jsonify(x) == "\"foo\""
    assert jsonify(x, True) == "\"foo\""

    result['host'] = x
    assert jsonify(result) == "{\"host\": \"foo\"}"
    assert jsonify(result, True) == "{\n    \"host\": \"foo\"\n}"

    x = dict()
    x['o'] = "o"
    x['1'] = "1"
    x['2'] = "2"
    x['b'] = "b"
    x["d"] = dict()
   

# Generated at 2022-06-20 23:34:07.381061
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils import jsonify
    results = {'success': {'foo': 'bar'}}
    results_str = "{'success': {'foo': 'bar'}}"
    results_json = '{"success": {"foo": "bar"}}'
    assert jsonify(results, False) == results_json
    assert jsonify(results, True) == results_str
    results_str = "{'failed': {'foo': u'bar'}}"
    results_json = '{"failed": {"foo": "bar"}}'
    assert jsonify(results, False) == results_json
    assert jsonify(results, True) == results_str

# Generated at 2022-06-20 23:34:18.874327
# Unit test for function jsonify
def test_jsonify():
    _result = {
        'skipped': True,
        '_ansible_no_log': False,
        '_ansible_item_result': True,
        'item': 'test',
        'changed': False,
        'failed': False
    }

    _result_unformatted = '{"skipped": true, "changed": false, "_ansible_item_result": true, "failed": false, "_ansible_no_log": false, "item": "test"}'
    _result_formatted = '''{
    "skipped": true,
    "changed": false,
    "_ansible_item_result": true,
    "failed": false,
    "_ansible_no_log": false,
    "item": "test"
}'''
    assert jsonify(_result) == _result_unform

# Generated at 2022-06-20 23:34:25.057564
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == "{}"
    assert jsonify({}, True) == "{\n}\n"
    assert jsonify({'a':1}) == '{"a": 1}'
    assert jsonify({'a':1}, True) == '{\n    "a": 1\n}\n'

# Generated at 2022-06-20 23:34:30.068854
# Unit test for function jsonify
def test_jsonify():
    result = dict(a=1, b="two", c=[3, "four"], d=dict(e=5), f=False)
    assert jsonify(result, format=True) == """{
    "a": 1,
    "b": "two",
    "c": [
        3,
        "four"
    ],
    "d": {
        "e": 5
    },
    "f": false
}"""

# Generated at 2022-06-20 23:34:32.609880
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'



# Generated at 2022-06-20 23:34:36.870428
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == "{}"
    assert jsonify(["one", "two", "three"]) == '["one", "two", "three"]'
    assert jsonify("foo") == '"foo"'
    assert jsonify({"one": "two"}) == '{"one": "two"}'
    assert jsonify({"three": "four", "one": "two"}) == '{"one": "two", "three": "four"}'

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-20 23:34:42.538104
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({'a':1, 'b':2})
    assert result == '{"a": 1, "b": 2}'
    result2 = jsonify({'a':1, 'b':2}, format=True)
    assert result2 == '{\n    "a": 1, \n    "b": 2\n}'



# Generated at 2022-06-20 23:34:48.915100
# Unit test for function jsonify
def test_jsonify():
    r = [{"a": [{"b": "c"}, 2], "d": 3}]
    assert jsonify(r) == '[{"a": [{"b": "c"}, 2], "d": 3}]'
    assert jsonify(r, format=True) == """\
{
    "a": [
        {
            "b": "c"
        },
        2
    ],
    "d": 3
}"""
    assert jsonify(None) == "{}"

__all__ = ['jsonify']

# Generated at 2022-06-20 23:34:56.409917
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': True}) == '{"a": true}'
    assert jsonify({'a': True}, format=True) == '{\n    "a": true\n}'
    assert jsonify(dict(a=True, b=[1, 2, 3])) == '{"a": true, "b": [1, 2, 3]}'

# Generated at 2022-06-20 23:35:09.999887
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({1: 'foo'}, format=False) == '{"1": "foo"}'
    assert jsonify({1: 'foo'}, format=True) == '{\n    "1": "foo"\n}'
    assert jsonify({1: u'\u00e9'}, format=True) == u'{\n    "1": "\u00e9"\n}'


# Generated at 2022-06-20 23:35:18.602797
# Unit test for function jsonify
def test_jsonify():
    result = {'a': 1, 'b': 2}
    assert jsonify(result) == "{}"
    assert jsonify(result, True) == "{}"

    result = {'a': 1, 'b': 2}
    assert jsonify(result) == '{"a": 1, "b": 2}'
    assert jsonify(result, True) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-20 23:35:25.746705
# Unit test for function jsonify
def test_jsonify():
    ''' Test the jsonify function '''

    assert jsonify(None) == '{}'

    data = {
        "a": 1,
        "b": 2,
        "c": "ansible",
        "d": [0, 1, 2],
        "e": "简体中文",
    }

    # Non-formatted output
    assert jsonify(data) == '{"a": 1, "b": 2, "c": "ansible", "d": [0, 1, 2], "e": "简体中文"}'

    # Formatted output

# Generated at 2022-06-20 23:35:37.923252
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should return a string that is valid JSON using the standard
    library's JSON module.'''

    from ansible import constants as C

    # Set default jsonify
    C.DEFAULT_JSONIFY = True
    test_string = jsonify({'msg': 'Hello World'}, True)
    assert isinstance(test_string, unicode)
    assert json.loads(test_string) == {'msg': 'Hello World'}

    # Set compact jsonify
    C.DEFAULT_JSONIFY = False
    test_string = jsonify({'msg': 'Hello World'}, True)
    assert isinstance(test_string, unicode)
    assert json.loads(test_string) == {'msg': 'Hello World'}

# Generated at 2022-06-20 23:35:43.243893
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({"foo": "bar"}, format=True)
    assert result == '{\n    "foo": "bar"\n}'
    result = jsonify({"foo": "bar"}, format=False)
    assert result == '{"foo": "bar"}'

# Generated at 2022-06-20 23:35:51.323793
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({'a': {u'\u2713': u'\u2713'}}) == '{"a": {"\u2713": "\u2713"}}'
    assert jsonify({'a': {u'\u2713': u'\u2713'}}, format=True) == '{\n    "a": {\n        "\u2713": "\u2713"\n    }\n}'

# Generated at 2022-06-20 23:35:55.397268
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == "{}"
    assert jsonify({'a': 1, 'b': 2}) == "{\"a\": 1, \"b\": 2}"
    assert jsonify({'a': 1, 'b': 2}, format=True) == "{\n    \"a\": 1, \n    \"b\": 2\n}"

# Generated at 2022-06-20 23:36:01.614693
# Unit test for function jsonify
def test_jsonify():
    ''' test the jsonify function '''

    result = None
    result2 = jsonify(result)
    assert result2 == "{}"

    result = {"a": 1}
    result2 = jsonify(result, format=True)
    assert result2 == '{\n    "a": 1\n}'

# this is partly a test to ensure we don't break the jinja2 template


# Generated at 2022-06-20 23:36:12.574172
# Unit test for function jsonify

# Generated at 2022-06-20 23:36:14.420664
# Unit test for function jsonify
def test_jsonify():
    test_dict = dict(a=1, b=2)
    assert json.loads(jsonify(test_dict)) == test_dict
    assert json.loads(jsonify(test_dict, True)) == test_dict

# Generated at 2022-06-20 23:36:38.554741
# Unit test for function jsonify
def test_jsonify():
    ''' Unit test for function jsonify '''

    data = '''
{
"changed": false,
"ping": "pong"
}
'''.lstrip()

    assert jsonify(json.loads(data)) == data

    data = '''
{
    "changed": false,
    "ping": "pong"
}
'''.lstrip()

    assert jsonify(json.loads(data), format=True) == data

    data = {"a":"b"}
    for _ in range(0, 100):
        data = { "a": "b", "c": data }

    assert jsonify(data, format=True)

    data = {"a": unicode("b")}
    assert jsonify(data, format=True)

# Generated at 2022-06-20 23:36:46.467019
# Unit test for function jsonify

# Generated at 2022-06-20 23:36:48.139432
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1}) == '{\"a\": 1}'


# Generated at 2022-06-20 23:36:54.322351
# Unit test for function jsonify
def test_jsonify():
    data = dict(
        test1 = 'foo',
        test2 = 'bar',
        test3 = dict(
            test4 = 'baz'
        )
    )

    result = jsonify(data)
    assert result

    result2 = jsonify(data, True)
    assert result2

# vim: set et ai ts=4 sts=4 ft=python:

# Generated at 2022-06-20 23:36:56.723221
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": [1,2,3]}, False) == '{"a": [1, 2, 3]}'
    assert jsonify({"a": [1,2,3]}) == '''{
    "a": [
        1,
        2,
        3
    ]
}'''

# Generated at 2022-06-20 23:36:59.524459
# Unit test for function jsonify
def test_jsonify():

    # Make sure jsonify returns unicode
    assert(isinstance(jsonify(None), unicode))

# Generated at 2022-06-20 23:37:03.302639
# Unit test for function jsonify
def test_jsonify():
    a = dict(
        foo = dict(
            bar = ["a", "b"]
        )
    )
    assert jsonify(a) == '{"foo": {"bar": ["a", "b"]}}'



# Generated at 2022-06-20 23:37:08.382717
# Unit test for function jsonify
def test_jsonify():
    assert jsonify("ok") == "\"ok\""
    assert jsonify(["ok", 1]) == "[\"ok\", 1]"
    assert jsonify({"a": "a", "b": "b"}, True) \
        == '{\n    "a": "a",\n    "b": "b"\n}'



# Generated at 2022-06-20 23:37:12.632762
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils import jsonify
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestJsonify(unittest.TestCase):

        def test_jsonify(self):
            self.assertEqual(jsonify(None), '{}')
            self.assertEqual(jsonify({'a':1}), '{"a": 1}')
            self.assertEqual(jsonify({'a':1}, format=True), '{\n    "a": 1\n}')

# Generated at 2022-06-20 23:37:23.410308
# Unit test for function jsonify
def test_jsonify():

    d = {"foo": "bar", "answer": [1, 2, 3, 4, 5], "spam": True}

    assert jsonify(d) == '{"answer": [1, 2, 3, 4, 5], "foo": "bar", "spam": true}'

    assert jsonify(d, format=True) == '{\n    "answer": [\n        1, \n        2, \n        3, \n        4, \n        5\n    ], \n    "foo": "bar", \n    "spam": true\n}'

    assert jsonify(None) == "{}"

# Generated at 2022-06-20 23:38:11.533501
# Unit test for function jsonify
def test_jsonify():
    a = {}
    a['foo1'] = 1
    a['foo2'] = 2
    a['foo3'] = 3

    assert jsonify(a,False) == '{"foo1": 1, "foo2": 2, "foo3": 3}'

    b = {}
    b['foo1'] = 1
    b['foo2'] = 2
    b['foo3'] = 3
    b['foo4'] = a

    assert jsonify(b,True) == dedent('''
        {
            "foo1": 1,
            "foo2": 2,
            "foo3": 3,
            "foo4": {
                "foo1": 1,
                "foo2": 2,
                "foo3": 3
            }
        }
    ''')

# Generated at 2022-06-20 23:38:24.948172
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify(['a', 'b', 'c']) == '["a", "b", "c"]'
    assert jsonify({'a': [1,2,3,{'b': 'c'}]}) == '{"a": [1, 2, 3, {"b": "c"}]}'
    assert jsonify({'a': {'b': {'c': "d"}}}) == '{"a": {"b": {"c": "d"}}}'
    assert jsonify('{"a": {"b": "c"}}') == '"{\\"a\\": {\\"b\\": \\"c\\"}}"'

# Generated at 2022-06-20 23:38:29.192427
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should convert python datastructures to json '''

    # Create some test data
    data = dict(a=1, b=2, c=3)
    data['d'] = data

    # Always check for a valid conversion
    assert jsonify(data)
    assert json.loads(jsonify(data)) == data

    # Check for indentation
    assert json.loads(jsonify(data, format=True)) == data

# Generated at 2022-06-20 23:38:38.624096
# Unit test for function jsonify
def test_jsonify():
    ''' test to make sure JSON output is valid '''

    assert jsonify(None) == "{}"
    assert jsonify([{'a':1},{'b':2}]) == '[{"a": 1}, {"b": 2}]'
    assert jsonify({'a':1,'b':2}) == '{"a": 1, "b": 2}'
    assert jsonify([{'a':1},{'b':'s'}]) == '[{"a": 1}, {"b": "s"}]'

# Generated at 2022-06-20 23:38:48.687698
# Unit test for function jsonify
def test_jsonify():
    result_dict = {"key1": 1234, "key2": "ansible"}
    json_result = jsonify(result_dict)
    expected_result = '''{
    "key1": 1234,
    "key2": "ansible"
}'''
    assert json_result == expected_result

    json_result = jsonify(result_dict, format=True)
    assert json_result == expected_result

    result_list = [1234, "ansible"]
    json_result = jsonify(result_list, format=True)
    expected_result = '[\n    1234,\n    "ansible"\n]'
    assert json_result == expected_result

    json_result = jsonify(result_list)
    expected_result = '[1234, "ansible"]'
    assert json_

# Generated at 2022-06-20 23:39:00.474199
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils import template
    from ansible.playbook.play import Play

    def assert_json_equal(result, format=False):
        if format:
            assert(jsonify(result, format) == jsonify(result, False))
        assert(jsonify(result, format) == jsonify(result, format))

    # test ansible objects
    play = Play.load(dict(
        name = "test play",
        hosts = 'all',
        gather_facts = 'no',
        vars_prompt = [
            {'name': 'foo', 'prompt': 'foo?', 'private': False}
        ],
        tasks = [
            {'action': {'module': 'debug', 'msg': '{{foo}}'}},
        ]
    ), loader=None, variable_manager=None)
   

# Generated at 2022-06-20 23:39:02.858007
# Unit test for function jsonify
def test_jsonify():
    data = {"key1": "value1", "key2": "value2"}
    result = jsonify(data)
    assert(result == '{"key1": "value1", "key2": "value2"}')


# Generated at 2022-06-20 23:39:07.438815
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({ 'a': 1 }) == "{\"a\": 1}"
    assert jsonify({ 'a': 1 }, format=True) == "{\n    \"a\": 1\n}"

# Generated at 2022-06-20 23:39:14.940753
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([1,2,3]) == '[1, 2, 3]'
    assert jsonify([1,"two",3]) == '[1, "two", 3]'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': ['c', 'd']}) == '{"a": 1, "b": ["c", "d"]}'
    assert jsonify({'a': {'c': 1, 'b': 2}}) == '{"a": {"b": 2, "c": 1}}'
    assert jsonify({'a': [1, 2, 3], 'b': ['c', 'd']}) == '{"a": [1, 2, 3], "b": ["c", "d"]}'
    assert jsonify

# Generated at 2022-06-20 23:39:27.514941
# Unit test for function jsonify
def test_jsonify():
    """Unit test for function jsonify
    """
    import StringIO

    a = jsonify({}, format=True)
    b = jsonify({}, format=False)
    c = jsonify([], format=True)
    d = jsonify([], format=False)
    e = jsonify(42, format=True)
    f = jsonify(42, format=False)
    g = jsonify('foo', format=True)
    h = jsonify('foo', format=False)

    assert a == '{}'
    assert b == '{}'
    assert c == '[]'
    assert d == '[]'
    assert e == '42'
    assert f == '42'
    assert g == '"foo"'
    assert h == '"foo"'
