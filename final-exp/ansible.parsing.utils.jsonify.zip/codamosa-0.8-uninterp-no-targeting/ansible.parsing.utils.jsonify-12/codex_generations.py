

# Generated at 2022-06-20 23:29:53.789444
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'
    assert jsonify({}) == '{}'

# Generated at 2022-06-20 23:30:07.359165
# Unit test for function jsonify
def test_jsonify():
    result = dict()
    result["ansible_facts"] = dict()
    result["ansible_facts"]["ansible_lsb"] = dict()
    result["ansible_facts"]["ansible_lsb"]["codename"] = "precise"
    result["ansible_facts"]["ansible_machine"] = "x86_64"
    result["ansible_facts"]["ansible_memtotal_mb"] = 1017632
    result["ansible_facts"]["ansible_processor"] = ("Intel64 Family 6 Model "
                                                    "23 Stepping 6, GenuineIntel")
    result["ansible_facts"]["ansible_processor_cores"] = 4
    result["ansible_facts"]["ansible_processor_count"] = 4

# Generated at 2022-06-20 23:30:18.952201
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"

    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == "{\n    \"a\": 1\n}"
    assert jsonify({"b": 2, "a": 1}) == '{"a": 1, "b": 2}'
    assert jsonify({"b": 2, "a": 1}, True) == "{\n    \"a\": 1,\n    \"b\": 2\n}"

    assert jsonify({"a": 1, "b": 2, "c": [3,4,{"d": 5, "e": 6}]}) == '{"a": 1, "b": 2, "c": [3, 4, {"d": 5, "e": 6}]}'

# Generated at 2022-06-20 23:30:23.421586
# Unit test for function jsonify
def test_jsonify():
    from ansible.cli import CLI

    cli = CLI() # just need the output callback
    assert jsonify(dict(foo=1)) == '{"foo": 1}'
    assert jsonify(dict(foo=1), format=True) == '{\n    "foo": 1\n}'

# Generated at 2022-06-20 23:30:27.193340
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == "{\n    \"a\": 1\n}"



# Generated at 2022-06-20 23:30:31.381109
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a':1, 'b':2}, True) == "{\"a\": 1, \"b\": 2}"
    assert jsonify({'a':1, 'b':2}) == '{"a": 1, "b": 2}'

# Generated at 2022-06-20 23:30:38.537279
# Unit test for function jsonify
def test_jsonify():

    data = {
                "changed": False,
                "failed": False,
                "invocation": {
                     "module_args": "/etc/ansible/hosts",
                     "module_name": "lineinfile"
                 },
                "item": "hosts",
                "matche": True,
                "msg": "One line was refreshed",
                "rc": 0
            }

    assert jsonify(data, False) == '{"failed": false, "item": "hosts", "rc": 0, "msg": "One line was refreshed", "invocation": {"module_name": "lineinfile", "module_args": "/etc/ansible/hosts"}, "changed": false, "matche": true}'

# Generated at 2022-06-20 23:30:45.771437
# Unit test for function jsonify
def test_jsonify():
    result = {"a": 1, "b": 2}
    assert jsonify(result) == "{\"a\": 1, \"b\": 2}"
    assert jsonify(result, True) == "{\n    \"a\": 1,\n    \"b\": 2\n}"

# Generated at 2022-06-20 23:30:54.990517
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(1) == '1'
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': {'b': 2}}) == '{"a": {"b": 2}}'
    assert jsonify({'a': [1, 2, {'c': 3}]}) == '{"a": [1, 2, {"c": 3}]}'
    assert jsonify({'a': [1, 2, {'c': [3]}]}) == '{"a": [1, 2, {"c": [3]}]}'

# Generated at 2022-06-20 23:31:06.263323
# Unit test for function jsonify
def test_jsonify():

    complex_result = {'complex': {
        'dict': {
            'with': {
                "unicode": u"\u00E9"
            }
        },
        'list': [
            {'one': {'two': 'three'}}
        ]
    }}
    expected_result = "{\"complex\": {\"dict\": {\"with\": {\"unicode\": \"\\u00e9\"}}, \"list\": [{\"one\": {\"two\": \"three\"}}]}}"
    assert jsonify(complex_result) == expected_result
    assert jsonify(complex_result, True) is not None

# Generated at 2022-06-20 23:31:23.426762
# Unit test for function jsonify
def test_jsonify():

    a = {
        "a": 1,
        "b": 2,
        "c": {
            "d": 3,
            "e": ["a", "b", "c"],
            "f": "hello world"
        }
    }

    b = {
        u"a": 1,
        u"b": 2,
        u"c": {
            u"d": 3,
            u"e": ["a", "b", "c"],
            u"f": u"hello world"
        }
    }

    r1 = jsonify(a)
    r2 = jsonify(a, True)
    r3 = jsonify(b)
    r4 = jsonify(b, True)

    print(r1)
    print(r2)
    print(r3)

# Generated at 2022-06-20 23:31:29.712315
# Unit test for function jsonify
def test_jsonify():
    result = {"failed": True}
    assert jsonify(result) == '{"failed": true}'
    assert jsonify(result, True) == '{\n    "failed": true\n}'

    result = {"failed": True, "msg": "this is an error message"}
    assert jsonify(result) == '{"failed": true, "msg": "this is an error message"}'
    assert jsonify(result, True) == '{\n    "failed": true,\n    "msg": "this is an error message"\n}'

    result = {"failed": False, "msg": "this is not an error message"}
    assert jsonify(result) == '{"failed": false, "msg": "this is not an error message"}'

# Generated at 2022-06-20 23:31:44.166400
# Unit test for function jsonify
def test_jsonify():

    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}) != '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, True) != '{\n    "a": 1\n}'

    assert jsonify([{"a": 1}, {"b": 2}], True) == '[\n    {\n        "a": 1\n    }, \n    {\n        "b": 2\n    }\n]'
    assert jsonify([{"a": 1}, {"b": 2}], True) != '[\n    {\n        "a": 1\n    }, \n    {\n        "b": 2\n    }\n]'

# Generated at 2022-06-20 23:31:51.925530
# Unit test for function jsonify
def test_jsonify():
    # Simulate a playbook result
    result = dict(
        changed=True,
        failed=False,
        msg='',
        start='2013-05-21 22:14:47.857796',
        end='2013-05-21 22:14:47.858607',
        delta='0:00:00.000811s',
        rc=0,
        stdout='',
        stderr='',
        invocation=dict(module_args=''),
    )
    # Should be a string
    assert isinstance(jsonify(result, format=False), str)

# Generated at 2022-06-20 23:31:54.128512
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(changed=False, rc=0)) == '{"changed": false, "rc": 0}'

# Generated at 2022-06-20 23:32:07.330527
# Unit test for function jsonify
def test_jsonify():
    #result = {}
    result = dict(changed=True, unreachable=1)
    assert jsonify(result) == '{"unreachable": 1, "changed": true}'

    result = dict(changed=True, unreachable=1, results=[dict(item=1), dict(item=2)])
    assert jsonify(result) == '{"unreachable": 1, "changed": true, "results": [{"item": 1}, {"item": 2}]}'

    result = dict(changed=True, unreachable=1, results=[dict(item=1), dict(item=2, foo='bar')])
    assert jsonify(result) == '{"unreachable": 1, "changed": true, "results": [{"item": 1}, {"foo": "bar", "item": 2}]}'


# Generated at 2022-06-20 23:32:16.139397
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.py27compat import StringIO

    class Stream(object):
        def __init__(self):
            self.data = StringIO()
        def fail_json(self, **kwargs):
            self.data.write(jsonify(kwargs, True))

    stream = Stream()
    stream.fail_json(msg="line1\nline2", rc=1)
    assert 'msg' and 'rc' in stream.data.getvalue()

    result = jsonify({"a": 1, "b": 2, "c": 3})
    assert result == '{"a": 1, "b": 2, "c": 3}'


# Generated at 2022-06-20 23:32:28.601131
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(None, False)
    assert result == '{}'

    result = jsonify({'key': 'value'}, False)
    assert result == '{"key": "value"}'

    result = jsonify({'key': 'value'}, True)
    assert result == '{\n    "key": "value"\n}'

    result = jsonify({'key': 'value', 'key2': 'value2'}, False)
    assert result == '{"key": "value", "key2": "value2"}'

    result = jsonify({'key': 'value', 'key2': 'value2'}, True)
    assert result == '{\n    "key": "value", \n    "key2": "value2"\n}'


# Generated at 2022-06-20 23:32:35.258279
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(42) == "42"
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify([1, 2, 3]) == "[1, 2, 3]"
    assert jsonify({'foo': 'bar'}, format=True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-20 23:32:48.952448
# Unit test for function jsonify
def test_jsonify():
    ''' verify our JSON output is the same after running through jsonify() '''

    # This test came from working with the AWS boto library and
    # the JSON it provides doesn't always translate well.  The
    # test string is real output and the goal is to ensure
    # it's a proper objet and not a simple string.

# Generated at 2022-06-20 23:32:56.287448
# Unit test for function jsonify
def test_jsonify():

    assert(jsonify(None) == "{}")

    json = jsonify({'key': 'value'}, True)
    assert('    "key": "value"' in json)

    json = jsonify({'key': 'value'}, False)
    assert('"key": "value"' in json)

# Generated at 2022-06-20 23:33:01.327196
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils import context_objects as co
    from six import StringIO

    obj1 = { 'a' : 1, 'b' : 2, 'c' : 'foo', 'd' : 'bar' }
    obj2 = co.AnsibleContext(invocation='invocation')

    assert json.loads(jsonify(obj1)) == obj1
    assert json.loads(jsonify(obj2, format=True)) == obj2.dump()


# Generated at 2022-06-20 23:33:05.169000
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(['test']) == '''[
    "test"
]'''

# Generated at 2022-06-20 23:33:11.043057
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a':'b'}) == '{"a": "b"}'
    assert jsonify({'a':'b'}, format=True) == '{\n    "a": "b"\n}'
    assert jsonify({'a':'b', 'c':'d'}) == '{"a": "b", "c": "d"}'


# Generated at 2022-06-20 23:33:19.103323
# Unit test for function jsonify
def test_jsonify():
    def check(inp, expected):
        if expected != jsonify(inp):
            raise AssertionError("'%s' produces '%s', expected '%s'" % (inp, jsonify(inp), expected))

    check([1,2,3], "[1, 2, 3]")
    check(["a", {"b": "c"}], '["a", {"b": "c"}]')
    check({"a": "b"}, '{"a": "b"}')
    check({"a": 1}, '{"a": 1}')
    check({"a": [1,2]}, '{"a": [1, 2]}')

    # Identical to the above, but "expected" is optimally minified
    check({"a": [1,2]}, '{"a":[1,2]}')

    #

# Generated at 2022-06-20 23:33:30.449725
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a":1}) == '{"a": 1}'
    assert jsonify({"a":1}, format=True) == "{\n    \"a\": 1\n}"
    assert jsonify({"a": True}) == '{"a": true}'
    assert jsonify({"a": False}) == '{"a": false}'
    assert jsonify({"a": None}) == '{"a": null}'
    assert jsonify({"a": [{"b": "c"}]}) == '{"a": [{"b": "c"}]}'
    assert jsonify({"a": {"b": [{"c": "d"}]}}) == '{"a": {"b": [{"c": "d"}]}}'

# Generated at 2022-06-20 23:33:34.312426
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([]) == "[]"
    assert jsonify([1]) == "[1]"
    assert jsonify({}) == "{}"
    assert jsonify('foo') == '"foo"'

# Generated at 2022-06-20 23:33:41.253848
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    assert jsonify([1, 2, 3], True) == '''[
    1,
    2,
    3
]'''
    assert jsonify({1: 2}) == '{"1": 2}'
    assert jsonify({1: 2}, True) == '''{
    "1": 2
}'''

# Generated at 2022-06-20 23:33:48.522099
# Unit test for function jsonify
def test_jsonify():
    ''' ensure jsonify function works as expected '''

    assert jsonify(dict(a=1, b=2, c=3)) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(dict(a=1, b=2, c=3), format=True) == '''{
    "a": 1,
    "b": 2,
    "c": 3
}'''

# Generated at 2022-06-20 23:33:51.249999
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify

    assert jsonify({'foo': 'bar'}) == "{\"foo\": \"bar\"}"


# Generated at 2022-06-20 23:34:02.058461
# Unit test for function jsonify
def test_jsonify():
    test_dict = {'a': 'b'}
    assert jsonify(test_dict,True) == '{\n    "a": "b"\n}'
    assert jsonify(test_dict,False) == '{"a": "b"}'
    assert jsonify(None,True) == '{}'
    assert jsonify(None,False) == '{}'

# Generated at 2022-06-20 23:34:07.642317
# Unit test for function jsonify
def test_jsonify():
    ''' test JSON output format '''
    result = dict(changed=True, rc=0, stderr='', stdout='black')
    result = jsonify(result, False)
    assert result == '{"changed": true, "rc": 0, "stderr": "", "stdout": "black"}'
    result = jsonify(result, True)
    assert result == '''{
    "changed": true,
    "rc": 0,
    "stderr": "",
    "stdout": "black"
}'''

# Generated at 2022-06-20 23:34:10.159546
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(test=2)) == '{"test": 2}'


# Generated at 2022-06-20 23:34:20.089299
# Unit test for function jsonify
def test_jsonify():
    results = jsonify(dict(changed=False, rc=0, stdout='foo', stderr='bar', warnings=['baz']))
    assert results == ('{\n'
        '    "changed": false, \n'
        '    "rc": 0, \n'
        '    "stderr": "bar", \n'
        '    "stdout": "foo", \n'
        '    "warnings": [\n'
        '        "baz"\n'
        '    ]\n'
        '}')

    results = jsonify({'changed': False, 'rc': 0, 'stdout': u'f\u00f6\u00f6', 'stderr': 'bar', 'warnings': ['baz']}, True)

# Generated at 2022-06-20 23:34:25.021080
# Unit test for function jsonify
def test_jsonify():
    result = {"foo": "bar"}
    assert jsonify(result) == '{"foo": "bar"}'
    assert jsonify(result, True) == '{\n    "foo": "bar"\n}'



# Generated at 2022-06-20 23:34:34.179623
# Unit test for function jsonify
def test_jsonify():
    # input = {'list_items': [{'uuid': '1', 'body': u'bbbbb'}, {'uuid': '2', 'body': u'超文本'}, {'uuid': '3', 'body': u'ccccc'}, {'uuid': '4', 'body': u'eeeee'}], 'status': 'success'}
    input_format(False)

    # input = {'list_items': [{'uuid': '1', 'body': u'bbbbb'}, {'uuid': '2', 'body': u'超文本'}, {'uuid': '3', 'body': u'ccccc'}, {'uuid': '4', 'body': u'eeeee'}], 'status': 'success'}
    input_

# Generated at 2022-06-20 23:34:47.024641
# Unit test for function jsonify
def test_jsonify():

    # Test jsonify()-function
    # compare dict and json-string
    data = {'foobar': None}
    json_obj = jsonify(data)
    assert data == json.loads(json_obj), 'jsonify()-function failed'

    # jsonify()-function should return empty dict on None-value
    assert jsonify(None) == "{}", 'jsonify()-function failed'

    # jsonify()-function should return empty dict on wrong (str-type) value
    assert jsonify('foobar') == "{}", 'jsonify()-function failed'

    # compare dict, JSON-string and formatted JSON-string
    data = {'foobar': 1, 'barfoo': True, 'foofoo': False, 'barbar': 'foo'}
    json_obj = jsonify(data)
    formatted_json

# Generated at 2022-06-20 23:35:00.812360
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify() should serialize a Python data structure or a string '''
    data = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': 5,
    }
    data_dump = '{"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}'
    data_dump_pretty = '''{
    "a": 1,
    "b": 2,
    "c": 3,
    "d": 4,
    "e": 5
}'''

    # Dump a dict
    assert jsonify(data) == data_dump
    assert jsonify(data, format=True) == data_dump_pretty

    # Dump a string

# Generated at 2022-06-20 23:35:07.470049
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils import jsonify
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # Make a result that contains non-ascii characters and make
    # sure that the JSON is valid
    tmp_play = Play()
    tmp_task = Task()
    tmp_task.action = "shell"
    tmp_task.args = "echo 'é'"
    tmp_play.add_task(tmp_task)

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult

    tqm = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback="default")
    host_name = 'testhost'
    tqm

# Generated at 2022-06-20 23:35:10.273644
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify
    result = [ { "distro": "Ubuntu", "version": "12.04" } ]
    assert jsonify(result) == '[{"distro": "Ubuntu", "version": "12.04"}]'



# Generated at 2022-06-20 23:35:24.082600
# Unit test for function jsonify
def test_jsonify():
    from ansible import constants
    from ansible.utils.unicode import to_bytes

    res = jsonify(dict(foo='bar'), format=True)
    assert res == '{\n    "foo": "bar"\n}'

    # test with boolean value
    res = jsonify(dict(foo=True), format=True)
    assert res == '{\n    "foo": true\n}'

    # test with integer value
    res = jsonify(dict(foo=1), format=True)
    assert res == '{\n    "foo": 1\n}'

    # test with empty value
    res = jsonify(dict(foo=''), format=True)
    assert res == '{\n    "foo": ""\n}'

    # test with None value

# Generated at 2022-06-20 23:35:36.124498
# Unit test for function jsonify
def test_jsonify():

    test_result = { 'a': 1, 'b': 2, 'c': 3, 'd': { 'z': 26 } }
    test_result2 = None

    assert jsonify(test_result) == '{"a": 1, "b": 2, "c": 3, "d": {"z": 26}}'
    assert jsonify(test_result, format=True) == '''{
    "a": 1,
    "b": 2,
    "c": 3,
    "d": {
        "z": 26
    }
}'''
    assert jsonify(test_result2) == '{}'
    assert jsonify(test_result2, format=True) == '{}'

# Generated at 2022-06-20 23:35:39.556371
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'

    assert jsonify({'a': 1}) == '{"a": 1}'

    assert jsonify({'a': 1, 'b': 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-20 23:35:50.331852
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'
    assert jsonify({'a': 1}) == '{"a": 1}'

# FIXME: implement to_nice_json
# def to_nice_json(result, format=False):
#     ''' format JSON output (uncompressed or uncompressed) '''
#
#     if result is None:
#         return "{}"
#
#     indent = None
#     if format:
#         indent = 4
#
#     try:
#         return json.dumps(result, sort_keys=True, indent=indent, ensure_ascii=False)
#     except UnicodeDecodeError:
#         return json.dumps(result, sort_keys=True, indent=indent)
#
# # Unit test for function to_nice_json
# def test_to

# Generated at 2022-06-20 23:35:52.606648
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'returned_value': 1}) == '{"returned_value": 1}'
    assert jsonify(None) == '{}'

# Generated at 2022-06-20 23:36:05.683108
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify

    # Testing `jsonify` function
    result = {
        'foo': 'bar',
        'baz': ['baz0', 'baz1', 'baz2'],
        'num': 42,
        'nested': {
            'out': [1, 2, 3, 4],
            'in': {
                'inside': 'value',
            }

        },
        'empty': None,
        u'lala': u'lalala',
    }

    # format json data
    formatted_json_result = jsonify(result, format=True)
    # compare strings

# Generated at 2022-06-20 23:36:09.610975
# Unit test for function jsonify
def test_jsonify():
    result = { 'a': 1, 'b': 2 }
    assert jsonify(result)   == "{\"a\": 1, \"b\": 2}"
    assert jsonify(result, True) == """{
    "a": 1,
    "b": 2
}"""

# Generated at 2022-06-20 23:36:13.518482
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'foo':'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo':'bar'}, format=True) == '{\n    "foo": "bar"\n}'


# this is a function and not a method in the module because
# it's also called from other modules that import this module

# Generated at 2022-06-20 23:36:18.092050
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'test': 'foo'}) == '{"test": "foo"}'
    assert jsonify({'test': 'foo'}, format=True) == '{\n    "test": "foo"\n}'

# Generated at 2022-06-20 23:36:25.335243
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None, True)  == "{}"
    assert jsonify({'a':'b'})  == '{"a": "b"}'
    assert jsonify({'a':'b'}, True)  == '{\n    "a": "b"\n}'
    a = jsonify({'a': 'abcd'})
    assert a == '{"a": "abcd"}' or a == '{"a": "\\u00e1bcd"}'

# Generated at 2022-06-20 23:36:30.862356
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'

# Generated at 2022-06-20 23:36:33.435587
# Unit test for function jsonify
def test_jsonify():
    result = { 'foo': 'bar' }
    assert json.loads(jsonify(result, format=False)) == result
    assert json.loads(jsonify(result, format=True))  == result

# Generated at 2022-06-20 23:36:38.804330
# Unit test for function jsonify
def test_jsonify():

    assert "{}" == jsonify (None)

    dict1 = {
        "qwer": "asdf",
        "zxcv": "dsfa"
    }
    assert '{\n    "qwer": "asdf", \n    "zxcv": "dsfa"\n}' == jsonify(dict1, format=True)
    assert '{"qwer": "asdf", "zxcv": "dsfa"}' == jsonify(dict1, format=False)

# Generated at 2022-06-20 23:36:42.418401
# Unit test for function jsonify
def test_jsonify():
    result = {"foo": 1, "bar": 2}
    assert jsonify(result) == "{\"bar\": 2, \"foo\": 1}"

# Generated at 2022-06-20 23:36:54.107707
# Unit test for function jsonify
def test_jsonify():

    assert jsonify({}, True) == '{\n}'

    simple_dict = { "a": 1, "b": 2, "c": 3 }
    assert simple_dict == json.loads(jsonify(simple_dict))


# Generated at 2022-06-20 23:36:58.999212
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify(None) == '{}')
    assert(jsonify(False) == 'false')
    assert(jsonify(list()) == '[]')
    assert(jsonify(dict()) == '{}')
    assert(jsonify(True) == 'true')
    assert(jsonify("test") == '"test"')
    assert(jsonify("中文") == '"中文"')
    assert(jsonify(['test1', 'test2']) == '["test1", "test2"]')
    assert(jsonify({'key': 'value'}) == '{"key": "value"}')
    assert(jsonify({'key': '中文'}) == '{"key": "中文"}')

# Generated at 2022-06-20 23:37:02.192654
# Unit test for function jsonify
def test_jsonify():
    result = {"foo": "ascii char in unicode string"}
    # Ensure this doesn't throw a traceback
    jsonify(result)

# Generated at 2022-06-20 23:37:09.318239
# Unit test for function jsonify
def test_jsonify():
    '''
    format no data return {}
    format data with indent 4
    format data with indent None
    '''
    result = None
    assert jsonify(result) == "{}"

    result = { 'key': 'value' }
    assert jsonify(result, True) == '''{
"key": "value"
}'''
    assert jsonify(result, False) == '{"key": "value"}'

# Generated at 2022-06-20 23:37:14.962908
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"

    data = {"a": "b"}
    assert jsonify(data) == '{"a": "b"}'

if __name__ == "__main__":
    test_jsonify()
    print("SUCCESS")

# Generated at 2022-06-20 23:37:26.579294
# Unit test for function jsonify
def test_jsonify():
    # Test None case
    result = None
    assert "{}" == jsonify(result)

    # Test empty list / dict
    result = []
    assert "[]" == jsonify(result)

    result = {}
    assert "{}" == jsonify(result)

    # Test basic list / dict
    result = [ "foo", "bar" ]
    assert '[\n    "foo", \n    "bar"\n]' == jsonify(result, format=True)

    result = { "foo": "bar" }
    assert '{\n    "foo": "bar"\n}' == jsonify(result, format=True)

    # Test complex list / dict
    result = [ "foo", "bar", { "foo": { "bar": "baz" } } ]

# Generated at 2022-06-20 23:37:46.553271
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"test": "1234"}) == '{"test": "1234"}'
    assert jsonify(None) == "{}"
    assert jsonify({"test": {"test": None}}) == '{"test": {"test": null}}'
    assert jsonify({"test": {u'\xe8': None}}) == '{"test": {"\u00e8": null}}'
    assert jsonify({"test": {'\xe8': None}}) == '{"test": {"\u00e8": null}}'
    assert jsonify({"test": {u'\xe8': None}}, True) == '{\n    "test": {\n        "\u00e8": null\n    }\n}'

# Generated at 2022-06-20 23:37:58.665238
# Unit test for function jsonify
def test_jsonify():
    ''' unit tests for ansible.utils.jsonify_module '''

    assert jsonify(None) == '{}'

    assert '\n' not in jsonify({'foo': 'bar'}, False)
    assert '\n' not in jsonify({'foo': 'bar', 'spam': ['eggs']}, False)

    assert '\n' in jsonify({'foo': 'bar'}, True)
    assert '\n' in jsonify({'foo': 'bar', 'spam': ['eggs']}, True)

    assert jsonify({'foo': 'bar'}, False) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar', 'spam': ['eggs']}, False) == '{"foo": "bar", "spam": ["eggs"]}'


# Generated at 2022-06-20 23:38:07.013200
# Unit test for function jsonify
def test_jsonify():
    # test empty result
    assert jsonify(None) == "{}"
    # test formatted result
    assert jsonify(dict(a=3), format=True) == '{\n    "a": 3\n}'
    # test json result with chars > 127
    assert jsonify(dict(a="fr\xc3\xa9d")) == '{"a": "fr\\u00e9d"}'

# Generated at 2022-06-20 23:38:10.686909
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, format=True) == '{\n    "foo": "bar"\n}'
    assert jsonify(None) == "{}"

# Generated at 2022-06-20 23:38:14.418618
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should return an empty object if the result is None'''
    result = None
    expected = "{}"
    assert jsonify(result) == expected

# Generated at 2022-06-20 23:38:20.812890
# Unit test for function jsonify
def test_jsonify():
    result = {'a': 1, 'b': 2}
    assert jsonify(result) == '{"a": 1, "b": 2}'
    assert jsonify(result, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(None) == '{}'

# Generated at 2022-06-20 23:38:25.080543
# Unit test for function jsonify
def test_jsonify():
    json_output = jsonify({'foo': 'bar'}, format=False)
    assert json_output == '{"foo": "bar"}'
    json_output = jsonify({'foo': 'bar'}, format=True)
    assert json_output == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-20 23:38:27.507156
# Unit test for function jsonify
def test_jsonify():
    if jsonify({}) != "{}":
        raise AssertionError("failed jsonify test")
    print("jsonify() ok")

if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-20 23:38:33.103105
# Unit test for function jsonify
def test_jsonify():
    data = {
        'string': 'test',
        'int': 123,
        'bool': True,
        'float': 3.14159,
        'unicode': u'\u1234\u5678',
        'utf-8 encoded string': '\xe1\x88\xb4',
        'utf-8 encoded unicode': u'\xe1\x88\xb4',
    }
    assert jsonify(data) == '{"bool": true, "float": 3.14159, "int": 123, "string": "test", "unicode": "\\u1234\\u5678", "utf-8 encoded string": "\\u1234", "utf-8 encoded unicode": "\\u1234"}'

# Generated at 2022-06-20 23:38:36.888637
# Unit test for function jsonify
def test_jsonify():
    # Test None returns {}
    assert jsonify(None) == "{}"
    # Test format JSON output
    result = "Hello"
    assert jsonify(result, True) == '"Hello"'

# Generated at 2022-06-20 23:39:04.005599
# Unit test for function jsonify
def test_jsonify():

    # Test with multiple JSON types and ensure we get back valid JSON for all
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify([1,2,3]) == '[1, 2, 3]'
    assert jsonify(1234) == '1234'
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    assert jsonify(None) == 'null'

    # Test that we get back correctly formatted JSON when we specify format=True
    assert jsonify({'foo': 'bar'}, format=True) == '{\n    "foo": "bar"\n}'
    assert jsonify([1,2,3], format=True) == '[\n    1,\n    2,\n    3\n]'

# Generated at 2022-06-20 23:39:12.936064
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_unicode

    result = {'a':1, 'b':[1,2,3], 'c':{'d':'e', 'f':'g'}}
    res = jsonify(result, True)
    assert res == to_unicode('''{
    "a": 1,
    "b": [
        1,
        2,
        3
    ],
    "c": {
        "d": "e",
        "f": "g"
    }
}''')

    res = jsonify(result, False)
    assert res == to_unicode('{"a":1,"b":[1,2,3],"c":{"d":"e","f":"g"}}')

# Generated at 2022-06-20 23:39:24.270895
# Unit test for function jsonify
def test_jsonify():
    assert '{\n    "a": true, \n    "b": [\n        1, \n        2, \n        3\n    ]\n}' == jsonify({'a':True, 'b':[1,2,3]}, format=True)
    assert '{\n    "a": true, \n    "b": [\n        1, \n        2, \n        3\n    ]\n}' == jsonify({'b':[1,2,3], 'a':True}, format=True)
    assert '{"a": true, "b": [1, 2, 3]}' == jsonify({'a':True, 'b':[1,2,3]})

# Generated at 2022-06-20 23:39:29.248604
# Unit test for function jsonify
def test_jsonify():
    json_str = jsonify({"a":{'b':[1,2,3,{'c':'d'}],'e':'f'},'g':'h'})
    assert json_str == '{"a": {"b": [1, 2, 3, {"c": "d"}], "e": "f"}, "g": "h"}'

# Generated at 2022-06-20 23:39:35.090368
# Unit test for function jsonify
def test_jsonify():
    ''' Make sure custom jsonify works as expected '''

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert jsonify(None) == "{}"
    assert jsonify(['a', 'b', 'c']) == '["a", "b", "c"]'
    assert jsonify(['a', 'b', 'c'], format=True) == '''[
    "a",
    "b",
    "c"
]
'''

    # Special case where the text is not unicode; in py3, json.dumps
    # requires unicode
    assert jsonify([b'abc']) == '["abc"]'

# Generated at 2022-06-20 23:39:41.184810
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo':'bar'}) == '{\n    "foo": "bar"\n}'
    assert jsonify({'foo':'bar'}, format=False) == '{"foo": "bar"}'
    assert jsonify(None) == "{}"

# Generated at 2022-06-20 23:39:49.465602
# Unit test for function jsonify
def test_jsonify():
    test_data = dict()
    test_data['1'] = 'a'
    test_data['2'] = 'b'

    compressed_result = jsonify(test_data)
    compressed_result_expected = '{"1": "a", "2": "b"}'
    assert compressed_result == compressed_result_expected

    formatted_result = jsonify(test_data, True)
    formatted_result_expected = '''{
    "1": "a",
    "2": "b"
}'''

    assert formatted_result == formatted_result_expected

    test_data2 = dict()
    test_data2['1'] = '\xe4'
    test_data2['2'] = '\xe4'

    formatted_result = jsonify(test_data2)