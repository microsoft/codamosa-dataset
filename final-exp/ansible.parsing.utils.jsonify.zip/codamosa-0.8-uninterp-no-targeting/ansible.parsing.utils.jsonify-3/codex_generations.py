

# Generated at 2022-06-20 23:29:55.966093
# Unit test for function jsonify
def test_jsonify():
    data = {
        'changed': False,
        'ping': 'pong'
    }
    assert jsonify(data) == '{"changed": false, "ping": "pong"}'
    assert jsonify(None) == "{}"

# Generated at 2022-06-20 23:30:07.358949
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify([]) == "[]"
    assert jsonify({'a': True}) == '{"a": true}'
    assert jsonify([1, 2, 3]) == "[1, 2, 3]"
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=[1,2,3], b=[4,5,6])) == '{"a": [1, 2, 3], "b": [4, 5, 6]}'

# Generated at 2022-06-20 23:30:11.592988
# Unit test for function jsonify
def test_jsonify():
    foo = { "skiddoo": 1, "bar": 1, "baz": 1 }
    bar = { "skiddoo": 1, "bar": 1, "baz": 1 }
    assert jsonify(foo) == jsonify(bar)

# Generated at 2022-06-20 23:30:23.746982
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import ansible.constants as C
    from ansible.compat.tests import unittest
    from six import text_type

    class TestJsonify(unittest.TestCase):

        def setUp(self):
            self.nonascii_unicode = u'\u83ab\u65e9\u8981\u83ab\u65e9\u8981'
            self.ascii_unicode = u'ascii unicode string'

            self.nonascii_str = text_type(self.nonascii_unicode)
            self.ascii_str = text_type(self.ascii_unicode)

            self.nonascii_bytes = self.nonasci

# Generated at 2022-06-20 23:30:33.694941
# Unit test for function jsonify
def test_jsonify():
    import sys
    if sys.version_info[0] > 2:
        x = {u'foo': u'bar'}
    else:
        x = {'foo': 'bar'}
    print("input: %s" % x)
    a = jsonify(x)
    print("formatted json: %s" % a)
    assert a == '{"foo": "bar"}'
    a = jsonify(x, format=True)
    print("unformatted json: %s" % a)
    assert a == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-20 23:30:41.291564
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'
    assert jsonify({'a':1}) == '{"a": 1}'
    assert jsonify({'a':{'b':1}}) == '{"a": {"b": 1}}'
    assert jsonify({'a':{'b':1}}, True) == '{\n    "a": {\n        "b": 1\n    }\n}'
    assert jsonify(['test']) == '["test"]'
    assert jsonify(['test'], True) == '[\n    "test"\n]'

# Generated at 2022-06-20 23:30:54.120816
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b'}
    assert(jsonify(data) == "{\"a\": \"b\"}")
    # formatted
    assert(jsonify(data, True) == "{\n    \"a\": \"b\"\n}")
    data = {'a': ['b', 'c']}
    assert(jsonify(data) == "{\"a\": [\"b\", \"c\"]}")
    # formatted
    assert(jsonify(data, True) == "{\n    \"a\": [\n        \"b\", \n        \"c\"\n    ]\n}")
    data = {'a': 'b', 'c': 'd'}
    assert(jsonify(data) == "{\"a\": \"b\", \"c\": \"d\"}")
    # formatted

# Generated at 2022-06-20 23:31:00.397086
# Unit test for function jsonify
def test_jsonify():
    a = {'a':'test'}
    assert(jsonify(a) == '{"a": "test"}')
    assert(jsonify(a, True) == '{\n    "a": "test"\n}')
    assert(jsonify(None) == '{}')

# Generated at 2022-06-20 23:31:11.232484
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify([1,2,3]) == '[1, 2, 3]'
    assert jsonify({"a": 1, "b": False}, format=True) == '''{
    "a": 1,
    "b": false
}'''

    string = '[{}\x80]'
    if type(string) == str:
        # Python 2
        assert jsonify(string) == '["[{}\\\\u0080]"]'
    else:
        # Python 3
        assert jsonify(string) == '[\'[{}\x80]\']'

# Generated at 2022-06-20 23:31:24.424332
# Unit test for function jsonify
def test_jsonify():
    assert '{}' == jsonify(None)
    assert '{}' == jsonify(None, False)
    assert '{}' == jsonify(None, True)
    assert '"foo"' == jsonify('foo')
    assert '"foo"' == jsonify('foo', False)
    assert '"foo"' == jsonify('foo', True)
    assert '{"abc": "123", "foo": "bar"}' == jsonify({'foo': 'bar', 'abc':123})
    assert '{"abc": "123", "foo": "bar"}' == jsonify({'foo': 'bar', 'abc':123}, False)
    assert '{\n    "abc": "123", \n    "foo": "bar"\n}' == jsonify({'foo': 'bar', 'abc':123}, True)

# Generated at 2022-06-20 23:31:39.558038
# Unit test for function jsonify
def test_jsonify():

    from ansible import constants as C

    # with _jsonify_format, result should be pretty-printed
    C._jsonify_format = True
    result = jsonify({"a": [1,2,3], "b": {"c": "d"}})
    assert result == '''{
    "a": [
        1,
        2,
        3
    ],
    "b": {
        "c": "d"
    }
}'''

    # without _jsonify_format, no pretty-printing
    C._jsonify_format = False
    result = jsonify({"a": [1,2,3], "b": {"c": "d"}})
    assert result == '{"a": [1, 2, 3], "b": {"c": "d"}}'

# Generated at 2022-06-20 23:31:45.497496
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_bytes
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert to_bytes(jsonify({"a": 1}, True), errors='strict') == b'{\n    "a": 1\n}\n'

# Generated at 2022-06-20 23:31:48.890086
# Unit test for function jsonify
def test_jsonify():
    '''
    Basic test for jsonify
    '''
    assert jsonify(dict(changed=True, rc=0)) == '{"changed": true, "rc": 0}'


# Generated at 2022-06-20 23:31:49.910464
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(changed=False)) == "{}"

# Generated at 2022-06-20 23:31:56.292537
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify([]) == "[]"
    assert jsonify({"foo":"bar"}) == '{"foo": "bar"}'
    assert jsonify([1,2,3]) == "[1, 2, 3]"

# Generated at 2022-06-20 23:32:01.862093
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonfuncs import jsonify
    assert jsonify(['a']) == '["a"]'
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, True) == '{\n    "a": "b"\n}'

# Generated at 2022-06-20 23:32:12.985555
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify function '''
    result = { 'a': 'b' }
    json_result = jsonify(result)
    assert json_result == "{\"a\": \"b\"}"

    result = { 'changed': False }
    result2 = { 'changed': False, 'rc': 1 }
    json_result = jsonify(result)
    json_result2 = jsonify(result2)
    assert json_result == json_result2 == "{\"changed\": false}"

    json_result = jsonify(result, format=True)
    json_result2 = jsonify(result2, format=True)
    assert json_result == json_result2 == "{\n    \"changed\": false\n}"

    result = { 'changed': False, '_ansible_parsed': True }

# Generated at 2022-06-20 23:32:16.839043
# Unit test for function jsonify
def test_jsonify():
    data = {
        'foo' : 1,
        'bar' : [ 2, 3, 4, 5 ],
        'baz' : { 'x' : 'x', 'y' : 'y', 'z' : 'z' },
    }
    assert jsonify(data) == json.dumps(data)
    assert jsonify(data, True) == json.dumps(data, sort_keys=True, indent=4)

# Generated at 2022-06-20 23:32:20.369522
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == "{\"a\": 1}"
    assert jsonify(["a", "b"]) == "[\n    \"a\",\n    \"b\"\n]"

# Generated at 2022-06-20 23:32:24.060597
# Unit test for function jsonify
def test_jsonify():
    res = {'status': 'ok', 'msg': 'all fine'}
    assert jsonify(res, format=False) == jsonify(res, format=True) == '{"msg": "all fine", "status": "ok"}'
    assert jsonify(None) == '{}'

# Generated at 2022-06-20 23:32:35.726907
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=2, b=dict(c=1, d=1))) == '{"a": 2, "b": {"c": 1, "d": 1}}'
    assert jsonify(dict(a=2, b=dict(c=[1,2,3], d=1))) == '{"a": 2, "b": {"c": [1, 2, 3], "d": 1}}'
    assert jsonify(dict(changed=False, foo="one")) == '{"changed": false, "foo": "one"}'

# Generated at 2022-06-20 23:32:49.188982
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_bytes

    # Test empty dict
    result_unicode = jsonify(None, True)
    result_bytes = jsonify(None, True)

    # Test non-empty dict
    result_unicode = jsonify({'key1':'value1', 'key2':'value2'}, True)
    result_bytes = jsonify({'key1':'value1', 'key2':'value2'}, True)

    # Assert that the returned type was unicode
    assert isinstance(result_unicode, unicode)

    # Assert that the returned type was bytes
    assert isinstance(result_bytes, bytes)

    # Assert that the bytes and unicode results are the same
    assert to_bytes(result_unicode) == result_bytes

# Generated at 2022-06-20 23:32:59.018036
# Unit test for function jsonify
def test_jsonify():
    results = {
        'foo': 'bar',
        'bam': [ 1, 2, { 'booze': 'whiskey' } ]
    }
    # Should give 1 line of output
    assert jsonify(results, False) == '{"bam": [1, 2, {"booze": "whiskey"}], "foo": "bar"}'

    # Should give multiple lines of output
    assert jsonify(results, True) == \
'''{
    "bam": [
        1,
        2,
        {
            "booze": "whiskey"
        }
    ],
    "foo": "bar"
}'''

# Generated at 2022-06-20 23:33:02.681757
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, format=True) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(None) == '{}'
    assert jsonify(None, format=True) == '{}'

# Generated at 2022-06-20 23:33:12.759086
# Unit test for function jsonify
def test_jsonify():
    ''' unit tests for jsonify(), with various input formats '''

    # empty
    assert jsonify({}) == "{}"

    # sample input
    sample = jsonify({'foo': 'bar', 'baz': 'meow'}, format=True)
    sample_normal = jsonify({'foo': 'bar', 'baz': 'meow'})

    # check length (minified is smaller)
    assert len(sample) > len(sample_normal)

    # make sure JSON is valid
    assert json.loads(sample) == {'baz': 'meow', 'foo': 'bar'}
    assert json.loads(sample_normal) == {'baz': 'meow', 'foo': 'bar'}

# Generated at 2022-06-20 23:33:19.715695
# Unit test for function jsonify
def test_jsonify():
    # FIXME: not sure how to test without coverage.py messing up assertEqual
    #        for some reason.
    return
    results = (
        (dict(bob=2, alice=3), '{"alice": 3, "bob": 2}'),
        (dict(bob=dict(alice=3)), '{ "bob": { "alice": 3 } }'),
        (None, '{}'),
        ('', '{}'),
        ('bob alice', '{}'),
    )

    for result, expected in results:
        ret = jsonify(result)
        assert ret == expected, 'failed on %s. got %s' % (result, ret)

# Generated at 2022-06-20 23:33:29.391065
# Unit test for function jsonify
def test_jsonify():

    # Test with a value = None
    result = jsonify(None)
    assert result == "{}"

    # Test with a value = dictionary
    result = jsonify({"foo": "bar"}, format=True)
    assert result == "{\n    \"foo\": \"bar\"\n}"

    # Test with a value = list
    result = jsonify(["foo", "bar"], format=True)
    assert result == "[\n    \"foo\",\n    \"bar\"\n]"

    # Test with a value = list
    result = jsonify(["foo", "bar"])
    assert result == "[\"bar\", \"foo\"]"

# Generated at 2022-06-20 23:33:42.043202
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo="bar", bam=[1,2,3]), True) == """{
    "bam": [
        1,
        2,
        3
    ],
    "foo": "bar"
}"""
    assert jsonify(dict(foo="bar", bam=[1,2,3]), False) == '{"bam": [1, 2, 3], "foo": "bar"}'
    assert jsonify(dict(foo="bar", bam=[1,2,3])) == '{"bam": [1, 2, 3], "foo": "bar"}'
    assert jsonify(None) == "{}"
    assert jsonify(dict(foo=dict(bam=dict(moof="quux")))) == '{"foo": {"bam": {"moof": "quux"}}}'

# Generated at 2022-06-20 23:33:51.389752
# Unit test for function jsonify
def test_jsonify():
    inputdata = { 'a' : 1, 'b' : 2, 'c' : "3" }
    noformat = "{\"a\": 1, \"b\": 2, \"c\": \"3\"}"
    assert jsonify(inputdata)          == noformat, "jsonify: no format"
    assert jsonify(inputdata,True)     == json.dumps(inputdata, sort_keys=True, indent=4, ensure_ascii=False), "jsonify: format"
    assert jsonify(None)               == "{}", "jsonify: None"

# Generated at 2022-06-20 23:33:58.177062
# Unit test for function jsonify
def test_jsonify():
    import datetime
    today = datetime.date.today()
    result = {'today': today, 'today_str': str(today)}
    assert jsonify(result) == ('{"today": {"year": %s, "month": %s, "day": %s}, '
                               '"today_str": "%s"}' %
                               ((today.year, today.month, today.day) + (str(today),)))

    assert jsonify(result, True) == ('''{
    "today": {
        "day": %s,
        "month": %s,
        "year": %s
    },
    "today_str": "%s"
}''' % ((today.day, today.month, today.year) + (str(today),)))

# Generated at 2022-06-20 23:34:10.426621
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should return a json-formatted string from a python structure '''

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    a_dict = dict(a=1, b=2, c=3)
    a_list = ['a', 'b', 'c']
    a_tuple = (1, 2, 3)
    an_int = 1
    a_unicode = u'f'

    assert jsonify(a_dict) == '{ "a": 1, "b": 2, "c": 3 }'
    assert jsonify(a_list) == '["a", "b", "c"]'
    assert jsonify(a_tuple) == '[1, 2, 3]'
    assert jsonify(an_int) == '1'
    assert jsonify(a_unicode)

# Generated at 2022-06-20 23:34:16.344877
# Unit test for function jsonify
def test_jsonify():
    result = {}
    result['a'] = 1
    result['b'] = 2
    assert jsonify(result) == '{"a": 1, "b": 2}'
    assert jsonify(result, True) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-20 23:34:21.233689
# Unit test for function jsonify
def test_jsonify():
    '''
    Basic test for function jsonify

    >>> data1 = {'a': 1, 'b': 2}
    >>> data2 = 'string'
    >>> data3 = ['one', 'two', 'three']
    >>> data4 = True
    >>> print(jsonify(data1))
    {"a": 1, "b": 2}
    >>> print(jsonify(data2))
    "string"
    >>> print(jsonify(data3))
    ["one", "two", "three"]
    >>> print(jsonify(data4))
    true
    >>> print(jsonify())
    "{}"
    '''



# Generated at 2022-06-20 23:34:26.216899
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1, 'b': 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-20 23:34:34.693621
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify() should return a json string from a dict '''
    data = dict(a='foo', b='bar', c=['one', 'two', 'three'])
    expected = '{"a": "foo", "b": "bar", "c": ["one", "two", "three"]}'
    assert jsonify(data, format=False) == expected
    assert jsonify(data, format=True) == expected

    data = dict(a=None, b=[None])
    expected = '{"a": null, "b": [null]}'
    assert jsonify(data, format=False) == expected
    assert jsonify(data, format=True) == expected

    data = dict(a=[1, [2, [3]]], b=dict(c=4, d=5))

# Generated at 2022-06-20 23:34:40.169398
# Unit test for function jsonify
def test_jsonify():
    '''Make sure we handle unicode and bytes objects in to_json'''

    assert jsonify(b'ascii') == '"ascii"'
    assert jsonify(u'\u2019') == '"\\u2019"'

# Generated at 2022-06-20 23:34:45.078880
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify() '''
    assert jsonify({}) == '{}'
    assert jsonify({'unicode_val': u'\xe4'}, True) == '{\n    "unicode_val": "\\u00e4"\n}'

# Generated at 2022-06-20 23:34:51.490879
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify

    class Bunch:
        def __init__(self, **kw):
            self.__dict__.update(kw)

    a = {'a':1,'b':2,'c':3}
    assert jsonify(a,True) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'

    b = Bunch(a=1,b=2,c=3)
    # 'index' is not ordered when using object
    assert jsonify(b,True) in ('{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}', '{\n    "c": 3,\n    "b": 2,\n    "a": 1\n}')

   

# Generated at 2022-06-20 23:35:02.769288
# Unit test for function jsonify
def test_jsonify():
    import sys

    # Python 2.6 does not understand ensure_ascii=False, so we have to specify
    # sort_keys=True to get an expected result (otherwise the keys are not ordered
    # and the test fails)
    if sys.version_info < (2,7):
        result = jsonify(dict(a=1,b=2,c=3), format=True)
        assert result == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'

    assert jsonify(dict(a=1,b=2,c=3)) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-20 23:35:08.033732
# Unit test for function jsonify
def test_jsonify():
    from ansible.runner.return_data import ReturnData
    result = ReturnData()
    result.update({'foo': 'bar'})
    assert jsonify(result, True) == "{\"failed\": false, \"foo\": \"bar\"}"
    assert jsonify(result, False) == "{\"failed\": false, \"foo\": \"bar\"}"

# Generated at 2022-06-20 23:35:25.060219
# Unit test for function jsonify
def test_jsonify():
    # result can be None
    assert jsonify(None) == "{}"
    # result can be an array
    assert jsonify(['foo', {'bar': ('baz', None, 1.0, 2)}]) == '["foo", {"bar": ["baz", null, 1.0, 2]}]'
    # result can be a set
    assert jsonify(set(['a', 'b', 1, 2])) == '["1", "2", "a", "b"]'
    assert jsonify(['a', 'b', 1, 2], True) == '''[
    "a",
    "b",
    "1",
    "2"
]'''
    # result can be a dict
    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'

# Generated at 2022-06-20 23:35:37.930852
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify '''
    result = {"a":1, "b":2, "c":3, "d":[1,2,3,{'foo':'bar'}]}
    assert jsonify(result) == '''{"a": 1, "c": 3, "b": 2, "d": [1, 2, 3, {"foo": "bar"}]}'''
    assert jsonify(result, True) == '''{
    "a": 1,
    "c": 3,
    "b": 2,
    "d": [
        1,
        2,
        3,
        {
            "foo": "bar"
        }
    ]
}'''

# Generated at 2022-06-20 23:35:40.682187
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(changed=True, foo='bar')) == "{\"changed\": true, \"foo\": \"bar\"}"
    assert jsonify(dict(changed=True, foo='bar'), True) == "{\n    \"changed\": true,\n    \"foo\": \"bar\"\n}"

# Generated at 2022-06-20 23:35:50.617389
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, format=True) == '{\n    "foo": "bar"\n}'

    assert jsonify({"foo": [1, 2, 3]}) == '{"foo": [1, 2, 3]}'
    assert jsonify({"foo": [1, 2, 3]}, format=True) == '{\n    "foo": [\n        1, \n        2, \n        3\n    ]\n}'

    assert jsonify({'foo': {'bar': 'baz'}}) == '{"foo": {"bar": "baz"}}'

# Generated at 2022-06-20 23:35:57.575448
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 1, 'b': [1, 2, 3], 'c': 'foo'}
    assert jsonify(data, False) == '{"a": 1, "b": [1, 2, 3], "c": "foo"}'
    assert jsonify(data, True) == '''{
    "a": 1,
    "b": [
        1,
        2,
        3
    ],
    "c": "foo"
}'''



# Generated at 2022-06-20 23:36:03.770146
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'data': 'value'}) == '{"data": "value"}'
    assert jsonify({'data': 'value'}, format=True) == '''{
    "data": "value"
}'''
    assert jsonify('value') == '"value"'
    assert jsonify('value', format=True) == '"value"'


# Generated at 2022-06-20 23:36:05.847929
# Unit test for function jsonify
def test_jsonify():
    print(jsonify({'a': 'b'}, True))
    print(jsonify({u'\xe0': u'\xe7'}, True))

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-20 23:36:12.714470
# Unit test for function jsonify
def test_jsonify():
    test_result = {
        "a": 1,
        "b": 2,
        "c": {
            "d": 3
        }
    }
    assert (jsonify(test_result, True) ==
            '{\n    "a": 1, \n    "b": 2, \n    "c": {\n        "d": 3\n    }\n}')
    assert (jsonify(test_result, False) ==
            '{"a": 1, "b": 2, "c": {"d": 3}}')
    assert (jsonify(None, False) == '{}')

# Generated at 2022-06-20 23:36:19.376133
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a":4, "b":5, "c":6}) == '{"a": 4, "b": 5, "c": 6}'
    assert jsonify({"a":4, "b":5, "c":6}, format=True) == '{\n    "a": 4,\n    "b": 5,\n    "c": 6\n}'

# Generated at 2022-06-20 23:36:21.009850
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify function '''
    result = dict(pong='hello world')
    x = jsonify(result)
    y = jsonify(result, format=True)
    assert x == '{"pong": "hello world"}'
    assert y == '{\n    "pong": "hello world"\n}'



# Generated at 2022-06-20 23:36:46.129762
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(dict(foo='bar', bam='baz')) == '{"bam": "baz", "foo": "bar"}'
    assert jsonify(dict(foo='bar', bam='baz'), format=True) == '{\n    "bam": "baz", \n    "foo": "bar"\n}'

# Generated at 2022-06-20 23:36:54.931805
# Unit test for function jsonify
def test_jsonify():
    test_dict = dict(foo='foo', bar='bar', bam='bam')
    assert jsonify(test_dict) == '{"bar": "bar", "bam": "bam", "foo": "foo"}'
    assert jsonify(test_dict, format=True) == '{\n    "bar": "bar", \n    "bam": "bam", \n    "foo": "foo"\n}'
    assert jsonify(None) == "{}"

# Generated at 2022-06-20 23:37:01.442419
# Unit test for function jsonify
def test_jsonify():
    result = {
        'abc': 'def',
        'ghi': 1
    }

    assert jsonify(result) == json.dumps(result, sort_keys=True, indent=None)

# vi: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-20 23:37:02.606498
# Unit test for function jsonify
def test_jsonify():

    # Just making sure we don't crash
    jsonify({})


# Generated at 2022-06-20 23:37:09.318156
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'
    assert jsonify(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a="\xe5\xe5", b="\xf6\xf6"), format=True) == '{\n    "a": "\xe5\xe5", \n    "b": "\xf6\xf6"\n}'

# Generated at 2022-06-20 23:37:22.561701
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify(['a', 'b'], format=True) == '[\n    "a", \n    "b"\n]'
    assert jsonify(['a', 'b']) == '["a", "b"]'
    assert jsonify({'a': {'b': {'c': {'d': 1}}}}) == '{"a": {"b": {"c": {"d": 1}}}}'

# Generated at 2022-06-20 23:37:26.008862
# Unit test for function jsonify
def test_jsonify():
    input = {'1': '2'}
    assert jsonify(input) == "{\"1\": \"2\"}"
    assert jsonify(input, format=True) == "{\n    \"1\": \"2\"\n}"

# Generated at 2022-06-20 23:37:31.349887
# Unit test for function jsonify
def test_jsonify():
    from ansible.compat.tests import unittest
    class TestJsonify(unittest.TestCase):
        """ function jsonify """
        def test_jsonify_none(self):
            result = None
            self.assertEqual(jsonify(result), "{}")

    unittest.main(verbosity=2)


# Generated at 2022-06-20 23:37:36.050845
# Unit test for function jsonify
def test_jsonify():
    result = {'a': 'b'}
    print('1', jsonify(result, False))
    print('2', jsonify(result, True))

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-20 23:37:42.786798
# Unit test for function jsonify
def test_jsonify():
    # simple test
    res = {'a': 1, 'b': 2}
    assert jsonify(res) == json.dumps(res, sort_keys=True, indent=None)

    # indent and format test
    res = {'a': 1, 'b': 2}
    assert jsonify(res, format=True) == json.dumps(res, sort_keys=True, indent=4)

# Generated at 2022-06-20 23:38:24.176364
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'spam': 'eggs'}, format=True) == '{\n    "spam": "eggs"\n}'
    assert jsonify({'spam': 'eggs'}, format=False) == '{"spam": "eggs"}'

# Generated at 2022-06-20 23:38:27.746753
# Unit test for function jsonify
def test_jsonify():
    '''jsonify should return value for various conditions'''
    assert jsonify(None) == "{}", "Result should be {}"
    assert jsonify({'a': 1}, True) == '''{
    "a": 1
}''', "Result should be properly indented json"


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-20 23:38:28.664013
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(changed=True)) == '{"changed": true}'

# Generated at 2022-06-20 23:38:33.693798
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'name': u'fòô'}, True) == '''{
    "name": "fòô"
}'''
    assert jsonify(
        [{u'name': u'fòô'}, {u'name': u'fòô'}], True) == '''[
    {
        "name": "fòô"
    },
    {
        "name": "fòô"
    }
]'''
    assert jsonify({'name': u'fôo'}, False) == '{"name": "fôo"}'

# Generated at 2022-06-20 23:38:44.519626
# Unit test for function jsonify
def test_jsonify():

    import os
    import sys
    import shutil
    import tempfile
    import subprocess

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a temporary file
    fd, tf = tempfile.mkstemp()

    # write the test data to file
    out = {'msg': 'Hello World'}
    os.write(fd, json.dumps(out))
    os.close(fd)


# Generated at 2022-06-20 23:38:47.379216
# Unit test for function jsonify
def test_jsonify():
    import ansible.utils.jsonify
    assert isinstance(ansible.utils.jsonify.jsonify({}), str)

# Generated at 2022-06-20 23:38:50.027442
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a':1}) == '{"a": 1}'
    assert jsonify({'a':1}, True) == '{\n    "a": 1\n}'


# Generated at 2022-06-20 23:38:51.932848
# Unit test for function jsonify
def test_jsonify():
    result = { 'a': 'A+B' }
    assert json.loads(jsonify(result)) == result

    result = { u'a': u'A+B' }
    assert json.loads(jsonify(result)) == result

# Generated at 2022-06-20 23:39:02.481854
# Unit test for function jsonify
def test_jsonify():
    # test two samples of json
    json1 = {'name': "ansible", 'version': 1.2}
    json2 = ['a','b','c','d','e',1,2,3]

    # confirm it can output compressed properly
    assert jsonify(json1) == '{"name": "ansible", "version": 1.2}'
    assert jsonify(json2) == '["a", "b", "c", "d", "e", 1, 2, 3]'

    # confirm it can output standard (uncompressed) properly
    assert jsonify(json1, True) == '{\n    "name": "ansible", \n    "version": 1.2\n}'

# Generated at 2022-06-20 23:39:12.623541
# Unit test for function jsonify
def test_jsonify():

    # test return of an empty dictionary
    assert jsonify(None) == "{}"

    # test return of a dictionary
    assert jsonify({'a': 10, 'b': 'foo'}) == '{"a": 10, "b": "foo"}'

    # test that a set is converted to a list
    assert jsonify({'a': [1], 'b': set([1, 2, 3])}) == '{"a": [1], "b": [1, 2, 3]}'

    # test that a list is converted to a list in output
    assert jsonify({'a': [1, 2]}) == '{"a": [1, 2]}'

    # test that a tuple is converted to a list in output
    assert jsonify({'a': (1, 2)}) == '{"a": [1, 2]}'

    # test that