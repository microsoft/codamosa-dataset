

# Generated at 2022-06-20 23:29:58.863628
# Unit test for function jsonify
def test_jsonify():
    from ansible.playbook.play_iterator import Iterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    PASSED = {'invocation': {'module_args': {},
              'module_name': u'test'},
              'changed': False,
              'failed': False,
              'rc': 0,
              'results': u'success',
              'state': u'pending'}

    json_result =  jsonify({'contacted': {'127.0.0.1': PASSED}, 'dark': {}})

# Generated at 2022-06-20 23:30:02.537557
# Unit test for function jsonify
def test_jsonify():
    assert "{}" == jsonify(None)
    assert '{}' == jsonify(None, True)

# Generated at 2022-06-20 23:30:11.934607
# Unit test for function jsonify
def test_jsonify():

    res = dict(changed=False, failed=False, source="https://github.com/ansible/ansible")
    j = jsonify(res)
    assert j == '{"changed": false, "failed": false, "source": "https://github.com/ansible/ansible"}', j
    j = jsonify(res, True)
    assert j == '''{
    "changed": false,
    "failed": false,
    "source": "https://github.com/ansible/ansible"
}''', j

    res = dict(changed=True, failed=True, invocations=[dict(module_name="ping", module_args=dict(data="pong"))])
    j = jsonify(res)

# Generated at 2022-06-20 23:30:18.594457
# Unit test for function jsonify
def test_jsonify():
    result = { 'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5 }
    assert jsonify(result, True) == '''{
    "a": 1,
    "b": 2,
    "c": 3,
    "d": 4,
    "e": 5
}'''
    assert jsonify(result, False) == '{"a":1,"b":2,"c":3,"d":4,"e":5}'

# Generated at 2022-06-20 23:30:26.333072
# Unit test for function jsonify
def test_jsonify():
    import os
    import sys
    libdir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lib'))
    sys.path.append(libdir)

    from ansible.module_utils.basic import AnsibleModule

    def test(expected, *args, **kwargs):
        assert jsonify(*args, **kwargs) == expected

    test('{"a": 1, "b": 2}', {"a":1,"b":2})
    test('{"a": 1, "b": 2}', {"b":2,"a":1})
    test('{"a": 1, "b": 2}', {"a":1,"b":2}, format=True)

# Generated at 2022-06-20 23:30:31.191037
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1, "b": 2}) == "{\"a\": 1, \"b\": 2}"
    assert jsonify({"a": 1, "b": 2}, format=True) == "{\n    \"a\": 1, \n    \"b\": 2\n}"


# Generated at 2022-06-20 23:30:41.352265
# Unit test for function jsonify
def test_jsonify():
    import copy
    test_data = [
        None,
        {'some_key': 'some_value'},
        {u'\u043c\u0435\u0441\u0441\u0430': u'\u043c\u0435\u0441\u0441\u0430'},
        [1, 2, 3, 4],
        [1, [1, 2], '3', u'\u043c\u0435\u0441\u0441\u0430']
    ]
    for data in test_data:
        assert json.loads(jsonify(data)) == json.loads(jsonify(copy.deepcopy(data)))

# Generated at 2022-06-20 23:30:55.102687
# Unit test for function jsonify
def test_jsonify():
    from ansible import __version__
    from ansible.utils.jsonify import jsonify
    import sys

    (major, minor) = sys.version_info[:2]

    assert jsonify(['user', 'group']) == '["user", "group"]'
    assert jsonify(('user', 'group')) == '["user", "group"]'
    assert jsonify({'user': 'slartibartfast'}) == '{"user": "slartibartfast"}'
    assert jsonify({'ansible_facts': {'distribution': 'Ubuntu','distribution_major_version': '12'}}) == '{"ansible_facts": {"distribution": "Ubuntu", "distribution_major_version": "12"}}'

# Generated at 2022-06-20 23:31:02.591042
# Unit test for function jsonify
def test_jsonify():

    v1 = {'name': 'value'}
    v2 = jsonify(v1)
    assert v2 == '{"name": "value"}'

    v1 = {'name': 'value'}
    v2 = jsonify(v1, True)
    assert v2 == '{\n    "name": "value"\n}'

# Unit tests for the utils


# Generated at 2022-06-20 23:31:08.282096
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'foo': 'bar'}, format=True) == '{\n    "foo": "bar"\n}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'

# Generated at 2022-06-20 23:31:18.288063
# Unit test for function jsonify
def test_jsonify():
    class Test(object):
        def __init__(self):
            self.name = "test"
        def to_json(self):
            return '{"name": "%s"}' % self.name
    assert jsonify(Test()) == '{"name": "test"}'

try:
    import yaml
    has_yaml = True
except ImportError:
    has_yaml = False



# Generated at 2022-06-20 23:31:28.034775
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify
    from ansible import constants as C

    result = dict(changed=False, ansible_facts={"a_fact": "a_value"}, rc=0)
    assert jsonify(result, format=True) == r'''{
    "ansible_facts": {
        "a_fact": "a_value"
    },
    "changed": false,
    "rc": 0
}'''

    result2 = dict(changed=False, ansible_facts={u"a_fact": {u"a_sub_fact": u"a_sub_value"}}, rc=0)

# Generated at 2022-06-20 23:31:42.476317
# Unit test for function jsonify
def test_jsonify():
    # pylint: disable=unused-argument
    data = { 'a': 1 }
    assert jsonify({}, format=True) == '{}'
    assert jsonify({}, format=False) == '{}'
    assert jsonify(data, format=True) == '{\n    "a": 1\n}'
    assert jsonify(data, format=False) == '{"a": 1}'
    data = { 'b': 'value' }
    assert jsonify(data, format=True) == '{\n    "b": "value"\n}'
    assert jsonify(data, format=False) == '{"b": "value"}'
    data = { 'c': None }
    assert jsonify(data, format=True) == '{\n    "c": null\n}'
    assert jsonify

# Generated at 2022-06-20 23:31:50.313388
# Unit test for function jsonify
def test_jsonify():
    result = dict(failed=True, changed=False, diff={'before': 'foo', 'after':'bar'})
    assert jsonify(result) == '{"changed": false, "diff": {"after": "bar", "before": "foo"}, "failed": true}'
    assert jsonify(result, True) == '{\n    "changed": false, \n    "diff": {\n        "after": "bar", \n        "before": "foo"\n    }, \n    "failed": true\n}'

# Generated at 2022-06-20 23:31:56.185568
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({'a': 1, 'b': [2, 3]}, True)
    print(result)
    assert result == '{\n    "a": 1,\n    "b": [\n        2, \n        3\n    ]\n}'

# Generated at 2022-06-20 23:32:06.159931
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify'''
    result = {'a':1,'b':2,'c':[3,4,5]}
    json_result = jsonify(result, True)
    assert json_result == '{\n    "a": 1,\n    "b": 2,\n    "c": [\n        3,\n        4,\n        5\n    ]\n}'
    json_result = jsonify(result, False)
    assert json_result == '{"a": 1, "b": 2, "c": [3, 4, 5]}'
    json_result = jsonify(None)
    assert json_result == '{}'

# Generated at 2022-06-20 23:32:08.577263
# Unit test for function jsonify
def test_jsonify():
    if jsonify(None) == "{}" and \
       jsonify(["foo", "bar"]) == '["bar", "foo"]' and \
       jsonify(dict(a=1,b=2,c=3)) == '{"a": 1, "c": 3, "b": 2}':
        return True
    else:
        return False


# Generated at 2022-06-20 23:32:16.706745
# Unit test for function jsonify
def test_jsonify():
    
    class MockModule:
        def __init__(self):
            self.fail_json = {}
            self.module = self

        def fail_json(self, **args):
            self.fail_json = args

    m = MockModule()
    result = None
    assert(jsonify(result) == "{}")
    result = []
    assert(jsonify(result) == "[]")
    result = {}
    assert(jsonify(result) == "{}")
    result = "string"
    assert(jsonify(result) == '"string"')
    result = 13
    assert(jsonify(result) == "13")
    result = 42.0
    assert(jsonify(result) == "42.0")
    result = True
    assert(jsonify(result) == "true")
    result = False

# Generated at 2022-06-20 23:32:21.139343
# Unit test for function jsonify
def test_jsonify():
    ''' test the jsonify function '''
    result = {
        'foo': 'bar',
        'blah': [ 1, 2, 3, 'good job' ],
        'ugh': {
            'a': 1,
            'b': 2
        }
    }
    assert jsonify(result) == '{"blah": [1, 2, 3, "good job"], "foo": "bar", "ugh": {"a": 1, "b": 2}}'
    assert jsonify(result, format=True) == '''{
    "blah": [
        1,
        2,
        3,
        "good job"
    ],
    "foo": "bar",
    "ugh": {
        "a": 1,
        "b": 2
    }
}'''

# Generated at 2022-06-20 23:32:24.870139
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"key": "value"}) == '{"key": "value"}'

# Generated at 2022-06-20 23:32:32.130132
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify function '''
    jsonify_result = jsonify({'a': 123, 'b': True}, format=True)
    assert jsonify_result == '{\n    "a": 123, \n    "b": true\n}'

# Generated at 2022-06-20 23:32:39.038335
# Unit test for function jsonify
def test_jsonify():
    ''' test to ensure the jsonify function works correctly. '''
    from ansible.utils.jsonify import jsonify

    # Test valid json
    valid_json = '[{"key1":"val1", "key2":"val2"}]'
    valid = jsonify(json.loads(valid_json))
    assert valid == '[{"key1": "val1", "key2": "val2"}]'

    # Test invalid json
    invalid_json = '{"key1":"val1", "key2":"val2"}'
    invalid = jsonify(json.loads(invalid_json))
    assert invalid == '{"key1": "val1", "key2": "val2"}'

# Generated at 2022-06-20 23:32:44.842544
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == """{
    "a": 1
}"""


# Generated at 2022-06-20 23:32:48.991507
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({})
    assert '{}' == result

#    result = jsonify(None)
#    assert '{}' == result

    result = jsonify({'key':'value'})
    assert '{"key": "value"}' == result

    result = jsonify({'key':'value'}, True)
    assert result

# Generated at 2022-06-20 23:32:54.765782
# Unit test for function jsonify
def test_jsonify():
    mydict = {'name': 'george', 'age': 18}
    assert jsonify(mydict) == '{"age": 18, "name": "george"}'
    assert jsonify(mydict, format = True) == '{\n    "age": 18, \n    "name": "george"\n}'
    assert jsonify(None) == "{}"



# Generated at 2022-06-20 23:33:00.152582
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(None, format=True) == "{\n}\n"
    assert jsonify(dict(changed=False, foo=1)) == '{"changed": false, "foo": 1}'
    assert jsonify(dict(changed=False, foo=1), format=True) == '''{\n    "changed": false, \n    "foo": 1\n}\n'''

# Generated at 2022-06-20 23:33:05.387560
# Unit test for function jsonify
def test_jsonify():

    res = jsonify({'a':1}, format=True)
    assert res == '{\n    "a": 1\n}'

    res = jsonify([1,2])
    assert res == '[1, 2]'

# Generated at 2022-06-20 23:33:14.438994
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify

    # Test the format option
    result = {'1': 'one', 'two': 2, 'three': {'4': 'four'}}
    assert jsonify(result, True) == '{\n    "1": "one", \n    "2": 2, \n    "3": {\n        "4": "four"\n    }\n}'

    # Test the default value
    assert jsonify(result) == '{"1": "one", "2": 2, "3": {"4": "four"}}'

    # Test without a value
    assert jsonify(None) == "{}"

# Generated at 2022-06-20 23:33:20.909686
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should return valid JSON for various inputs '''
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import wrap_var

    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify(1) == "1"
    assert jsonify(dict(a=1)) == '{"a": 1}'
    assert jsonify(dict(a=1, b=[1,2])) == '{"a": 1, "b": [1, 2]}'
    assert jsonify(dict(a=dict(b=1))) == '{"a": {"b": 1}}'

# Generated at 2022-06-20 23:33:30.010644
# Unit test for function jsonify
def test_jsonify():

    data = {
    'conso_exp': 100,
    'conso_tot': 10,
    'longitude': 2.2839799999999998,
    'latitude': 48.8597
    }

    assert jsonify(data, format=True) == "{\"conso_exp\": 100, \"conso_tot\": 10, \"latitude\": 48.8597, \"longitude\": 2.2839799999999998}"
    assert jsonify(data, format=False) == "{\"conso_exp\": 100, \"conso_tot\": 10, \"latitude\": 48.8597, \"longitude\": 2.2839799999999998}"

# Generated at 2022-06-20 23:33:38.051836
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1)) == '{\"a\": 1}'
    assert jsonify(dict(a=1, b=2)) == '{\"a\": 1, \"b\": 2}'
    assert jsonify(dict(a=1, b=2, c=3)) == '{\"a\": 1, \"b\": 2, \"c\": 3}'

# Generated at 2022-06-20 23:33:45.381086
# Unit test for function jsonify
def test_jsonify():
    """basic JSON encode tests"""
    from ansible import constants as C

    # basic
    result = C.json_dict
    result = jsonify(result)
    assert '"exclude_hosts": [], "nocows": 0' in result
    if C.DEFAULT_HASH_BEHAVIOUR == "merge":
        assert '"roles_path": ["/etc/ansible/roles", "/usr/share/ansible/roles"]' in result
    else:
        assert '"roles_path": "/etc/ansible/roles"' in result
    assert '"callback_whitelist": ["stdout"]' in result

    # format
    result = C.json_dict
    result = jsonify(result, True)

# Generated at 2022-06-20 23:33:50.433761
# Unit test for function jsonify
def test_jsonify():
    test_result = { 'a': '1', 'b': '2', 'c': '3' }
    assert jsonify(test_result) == '{"a": "1", "b": "2", "c": "3"}'

# Generated at 2022-06-20 23:33:55.161245
# Unit test for function jsonify
def test_jsonify():
    import json
    # Check that None really is printed as '{}'
    assert jsonify(None, format=True) == '{}'
    # Check that we can convert a dict to JSON
    assert jsonify({'a': 1, 'b': 2}, format=True) == '''{
    "a": 1,
    "b": 2
}'''

# Generated at 2022-06-20 23:34:01.231405
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'b'}) == "{\"a\": \"b\"}"
    assert jsonify({"c": "d"}, format=True) == "{\n    \"c\": \"d\"\n}"

# -- Jinja2 Filters for JSON --

# Generated at 2022-06-20 23:34:04.866858
# Unit test for function jsonify
def test_jsonify():
    result = dict(changed=True, failed=False)
    unformatted = jsonify(result)
    assert unformatted == '{"changed": true, "failed": false}'
    formatted = jsonify(result, format=True)
    assert formatted == '{\n    "changed": true, \n    "failed": false\n}'

# Generated at 2022-06-20 23:34:09.957245
# Unit test for function jsonify
def test_jsonify():
    result = {
        "a": 1,
        "b": 2,
        "c": [ 3, 4, 5 ],
        "d": {
            "e": "f",
            "g": "h"
        }
    }
    pretty = jsonify(result, True)
    assert "a" in pretty

# Generated at 2022-06-20 23:34:13.197623
# Unit test for function jsonify
def test_jsonify():
    empty_json = jsonify(None)
    assert empty_json == "{}"
    assert isinstance(empty_json, str)
    assert isinstance(jsonify(empty_json), str)

# Generated at 2022-06-20 23:34:21.128981
# Unit test for function jsonify
def test_jsonify():
    ''' test_jsonify: test jsonify function '''

    result = jsonify(None)
    assert(result == "{}")
    assert(result == '{}')

    result = jsonify(dict(one=1, two=2))
    assert(result == '{"one": 1, "two": 2}')
    assert(result == '{"two": 2, "one": 1}')
    assert(result == '{ "one": 1, "two": 2 }')
    assert(result == '{ "two": 2, "one": 1 }')
    assert(result.count('"') == 4)
    assert(result == json.loads(result))

    result = jsonify(dict(one=1, two=2), format=True)

# Generated at 2022-06-20 23:34:28.378820
# Unit test for function jsonify
def test_jsonify():

    print("Testing jsonify")
    d = { "item": 1 }

    expected = '{\n    "item": 1\n}'
    actual = jsonify(d, True)
    assert expected == actual

    d = { "item": 1 }

    expected = '{"item": 1}'
    actual = jsonify(d, False)
    assert expected == actual

    d = None

    expected = "{}"
    actual = jsonify(d, False)
    assert expected == actual

# Generated at 2022-06-20 23:34:40.290784
# Unit test for function jsonify
def test_jsonify():
    result = {'a': 1, 'b': 2, 'c': 3}
    assert jsonify(result, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'
    assert jsonify(result) == '{"a":1,"b":2,"c":3}'

# Generated at 2022-06-20 23:34:49.781497
# Unit test for function jsonify

# Generated at 2022-06-20 23:34:58.761254
# Unit test for function jsonify
def test_jsonify():
    assert '{}' == jsonify(None)
    assert ({'a': '1', 'b': '2', 'c': '3'} ==
            json.loads(jsonify({'c': '3', 'a': '1', 'b': '2'})))
    assert ('{\n    "a": "1", \n    "b": "2", \n    "c": "3"\n}' ==
            jsonify({'c': '3', 'a': '1', 'b': '2'}, True))

# Generated at 2022-06-20 23:35:04.832052
# Unit test for function jsonify

# Generated at 2022-06-20 23:35:11.436320
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify('foo') == '"foo"'
    assert jsonify(['foo', 'bar']) == '["foo", "bar"]'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': ['bar', 'baz']}) == '{"foo": ["bar", "baz"]}'
    assert jsonify({'foo': ['bar', 'baz']}, format=True) == '{\n    "foo": [\n        "bar", \n        "baz"\n    ]\n}'

# Generated at 2022-06-20 23:35:14.900358
# Unit test for function jsonify
def test_jsonify():
    if jsonify(None) != "{}":
        return False
    if jsonify({'key':'value'}) != '{"key": "value"}' :
        return False
    return True

# Generated at 2022-06-20 23:35:21.332792
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, True) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-20 23:35:29.031453
# Unit test for function jsonify
def test_jsonify():

    a = None
    b = jsonify(a)
    assert b == "{}"

    a = { "some" : "thing" }
    b = jsonify(a)
    assert b == '{"some": "thing"}'
    b = jsonify(a, format=True)
    assert b == '{\n    "some": "thing"\n}'

# Generated at 2022-06-20 23:35:39.911143
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils import jsonify

    res = {
        'foo': 'bar',
        'baz': None,
        'blarg': True,
        'wibble': 0,
        'wobble': 0.0,
        'wubble': '',
        'flip': [1,2,3],
        'flop': [],
        'count': 2,
        'dict': {
            'status': 'ok',
            'results': [
                {'a':1,'b':2},
                {'a':3,'b':4},
            ]
        }
    }


# Generated at 2022-06-20 23:35:50.437153
# Unit test for function jsonify
def test_jsonify():
    a = { "foo": 1, 'bar': u'A\xa1', 5: u"h\xe9h\xe9", (1,2): "a",
          'b': { 'ba': [ 1, {'baa': 'bar'}]}}
    b = jsonify(a)
    c = u'{"bar": "A\xa1", "b": {"ba": [1, {"baa": "bar"}]}, "foo": 1, "(1, 2)": "a", "5": "h\\u00e9h\\u00e9"}'

# Generated at 2022-06-20 23:36:11.650364
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(1) == '1'
    assert jsonify({}) == '{}'
    assert jsonify({'a':1}) == '{"a": 1}'
    assert jsonify({'a':1,'b':2}) == '{"a": 1, "b": 2}'
    assert jsonify({'b':2,'a':1}) == '{"a": 1, "b": 2}'
    assert jsonify({'a':2}, format=True) == '{\n    "a": 2\n}'
    assert jsonify({'a':1,'b':{'c':1,'d':2}}, format=True) == '{\n    "a": 1,\n    "b": {\n        "c": 1,\n        "d": 2\n    }\n}'

# Generated at 2022-06-20 23:36:13.487077
# Unit test for function jsonify
def test_jsonify():
    ''' Test function jsonify '''

    assert jsonify(None) == '{}'
    assert jsonify([]) == '[]'
    assert jsonify(dict()) == '{}'

# Generated at 2022-06-20 23:36:22.471249
# Unit test for function jsonify
def test_jsonify():
    assert isinstance(jsonify({'a': 1, 'b': 2}), str)
    assert isinstance(jsonify({'a': 1, 'b': 2}, format=True), str)

    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, format=True) == '''{
    "a": 1,
    "b": 2
}'''

# Generated at 2022-06-20 23:36:26.245620
# Unit test for function jsonify
def test_jsonify():
    result = {
        "test": ["value", "value2"],
        "test2": 5,
        "test3": "value3",
    }
    assert jsonify(result, format=False) == "{\"test\": [\"value\", \"value2\"], \"test2\": 5, \"test3\": \"value3\"}"

# Generated at 2022-06-20 23:36:33.711039
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None, True) == '{}'
    assert jsonify('foo', True) == '"foo"'
    assert jsonify([1,2,3], True) == '[\n    1, \n    2, \n    3\n]'
    assert jsonify([1,2,3], False) == '[1, 2, 3]'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'
    assert jsonify({'foo': 'bar'}, False) == '{"foo": "bar"}'

# Generated at 2022-06-20 23:36:42.377290
# Unit test for function jsonify
def test_jsonify():

    test1 = jsonify(None)
    assert test1 == "{}"

    test2 = jsonify({ 'a': 123, 'b': 456}, format=True)
    assert test2 == '{\n    "a": 123,\n    "b": 456\n}'

    test3 = jsonify({ 'a': 123, 'b': 456}, format=False)
    assert test3 == '{"a": 123, "b": 456}'

# Generated at 2022-06-20 23:36:54.019516
# Unit test for function jsonify
def test_jsonify():
    result = dict()
    result['ansible_facts'] = dict()
    result['ansible_facts']['test_fact'] = 'test_fact_value'
    result['ansible_facts']['test_fact_number'] = 123
    result['ansible_facts']['test_fact_unicode'] = u'\u20ac'
    result['ansible_facts']['test_fact_utf8'] = 'utf8'
    result['ansible_facts']['test_fact_true'] = True
    result['ansible_facts']['test_fact_false'] = False

# Generated at 2022-06-20 23:36:56.510213
# Unit test for function jsonify
def test_jsonify():
    ''' trivial test for jsonify '''
    assert jsonify({})    == '{}'
    assert jsonify({'a':1})  == '{"a": 1}'
    assert jsonify({'a':1}, True)  == '{\n    "a": 1\n}'


# Generated at 2022-06-20 23:37:02.930112
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify with various inputs '''
    # Test list
    assert jsonify(["foo", "bar"]) == '["bar", "foo"]'
    # Test dict
    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'
    # Test None
    assert jsonify(None) == "{}"

# Generated at 2022-06-20 23:37:03.822491
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'

# Generated at 2022-06-20 23:37:18.954685
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify unit test '''
    result = [{"foo": 1, "bar": 2}]
    assert jsonify(result) == jsonify(result, False)
    assert jsonify(result, True) == """{\n    "foo": 1, \n    "bar": 2\n}"""

# Generated at 2022-06-20 23:37:21.478357
# Unit test for function jsonify
def test_jsonify():
    from nose.plugins.skip import SkipTest
    raise SkipTest("currently not implemented in unit tests")

# Generated at 2022-06-20 23:37:24.888825
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo='bar')) == '{"foo": "bar"}'


# Generated at 2022-06-20 23:37:37.574809
# Unit test for function jsonify
def test_jsonify():
    import os
    import sys
    import tempfile
    import subprocess

    test_data = {
        'a': 'string',
        'b': 10,
        'c': {
            'd': 'nested',
            'e': 'json'
        }
    }

    # -- Test formatted output
    fd, fname = tempfile.mkstemp()
    os.close(fd)

    json.dump(test_data, open(fname, 'w'), sort_keys=True, indent=4)
    expected = open(fname, 'rt').read()

    result = jsonify(test_data, format=True)
    assert result == expected

    # -- Test non-formatted output
    fd, fname = tempfile.mkstemp()
    os.close(fd)

    json.dump

# Generated at 2022-06-20 23:37:48.350287
# Unit test for function jsonify
def test_jsonify():
    data = {
        'a': 1,
        'b': 2,
        'c': [ 2, 4, 6, 8 ],
        'd': {
            'e': [ 1, 2, 3 ],
            'f': 4
        },
        'g': 'ansiballz',
        'h': {
            'i': 9,
            'j': [ 9, 8, 7 ],
            'k': {
                'l': 6,
                'm': 7,
                'n': 8
            }
        }
    }

    compressed = jsonify(data, format=False)

# Generated at 2022-06-20 23:37:55.981158
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils import json
    if not hasattr(json, 'loads'):
        print("SKIP: no json library present")
        raise SkipTest

    data = {"json": "is", "great": True}
    assert jsonify(data, format=True) == '''{
    "great": true,
    "json": "is"
}'''
    assert jsonify(data, format=False) == '{"great":true, "json":"is"}'

# Generated at 2022-06-20 23:38:01.878789
# Unit test for function jsonify
def test_jsonify():
    import sys

    assert sys.getdefaultencoding() == 'utf-8'
    # Test with unicode
    data = {'result': 'passed', 'unicode': u'\xe2'}
    jdata = jsonify(data)
    assert jdata == '{"result": "passed", "unicode": "\xe2"}'
    jdata = jsonify(data, True)
    assert jdata == '{\n    "result": "passed", \n    "unicode": "\xe2"\n}'

    # Test with non-unicode
    data = {'result': 'passed', 'string': 'spam'}
    jdata = jsonify(data)
    assert jdata == '{"result": "passed", "string": "spam"}'

    # Test with None
    jdata = json

# Generated at 2022-06-20 23:38:08.095387
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None, format=False) == "{}"
    assert jsonify(None, format=True) == "{}"
    assert jsonify({'foo': 'bar'}, format=False) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, format=True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-20 23:38:12.928073
# Unit test for function jsonify
def test_jsonify():
    result_none = jsonify(None)
    assert json.loads(result_none) == {}

    test_dict = dict(
        foo="""bar'bar"bar'''bar"""
    )

    result_dict = jsonify(test_dict, False)
    assert json.loads(result_dict) == test_dict

    result_dict = jsonify(test_dict, True)
    assert json.loads(result_dict) == test_dict

# Generated at 2022-06-20 23:38:18.408804
# Unit test for function jsonify
def test_jsonify():
    result = {'foo': 'bar'}
    assert jsonify(result, format=False) == '{"foo": "bar"}'
    assert jsonify(result, format=True) == '{\n    "foo": "bar"\n}'



# Generated at 2022-06-20 23:38:32.954987
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'b'}) == '{"a": "b"}'

# instantiate the test function only if we're being called as a module
if __name__ == '__main__':
    from ansible import utils
    utils.run_tests()

# Generated at 2022-06-20 23:38:43.739812
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(None, True) == '{}'

    # Test basic str type
    assert jsonify('{"foo": "bar"}') == '"{\\"foo\\": \\"bar\\"}"'
    assert jsonify('{"foo": "bar"}', True) == '"{\\"foo\\": \\"bar\\"}"'

    # Test basic int type
    assert jsonify(123) == '123'
    assert jsonify(123, True) == '123'

    # Test basic boolean type
    assert jsonify(True) == 'true'
    assert jsonify(True, True) == 'true'

    # Test basic array type
    assert jsonify(['foo', 'bar']) == '["foo", "bar"]'

# Generated at 2022-06-20 23:38:48.654401
# Unit test for function jsonify
def test_jsonify():
    from nose.tools import assert_equal
    assert_equal('{}', jsonify(None))
    assert_equal(
            '{"a": 1, "b": 2, "c": 3}',
            jsonify({u'a': 1, u'b': 2, u'c': 3}),
        )

# Generated at 2022-06-20 23:38:51.233777
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({ 'a': 'b' }) == '{"a": "b"}'
    assert jsonify(None) == '{}'
    assert jsonify({'a': 'b'}, format=True) == '{\n    "a": "b"\n}'

# Generated at 2022-06-20 23:39:02.213320
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify("test string", True) == "\"test string\""
    assert jsonify("test string") == "\"test string\""
    assert jsonify("test string", False) == "\"test string\""
    assert jsonify({'a':'value of A'}, True) == '{\n    "a": "value of A"\n}'
    assert jsonify({'a':'value of A'}) == '{"a": "value of A"}'
    assert jsonify({'a':'value of A'}, False) == '{"a": "value of A"}'
    assert jsonify(["one", "two", "three"], True) == '[\n    "one", \n    "two", \n    "three"\n]'

# Generated at 2022-06-20 23:39:06.073258
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, True) == '{\n    "a": "b"\n}'

# Generated at 2022-06-20 23:39:09.281484
# Unit test for function jsonify
def test_jsonify():
    import __builtin__
    __builtin__.dict = dict
    # we just want to make sure this runs without errors
    assert jsonify({"hello":"world"}) == '{"hello": "world"}'

# Generated at 2022-06-20 23:39:14.669492
# Unit test for function jsonify
def test_jsonify():
    ''' unit testing for jsonify() '''

    class _Module(object):
        def __init__(self, output=None):
            self.output = output

    result = _Module(dict(foo='bar')).output
    assert jsonify(result) == '{"foo": "bar"}'
    assert jsonify(result, format=True) == '{\n    "foo": "bar"\n}'

if __name__ == '__main__':
    # Run unit tests if we're called directly
    import sys
    sys.exit(__import__('unitest').main())

# Generated at 2022-06-20 23:39:24.738272
# Unit test for function jsonify
def test_jsonify():
    result = { 'foo': 'bar' }
    output = jsonify(result, format=False)
    assert output == "{\"foo\": \"bar\"}"
    output = jsonify(result, format=True)
    assert output == """{
    "foo": "bar"
}"""
    result['baz'] = [1, 2, 3]
    output = jsonify(result, format=True)
    assert output == """{
    "baz": [
        1,
        2,
        3
    ],
    "foo": "bar"
}"""
    output = jsonify(None, format=True)
    assert output == "{}"

# Generated at 2022-06-20 23:39:33.628732
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify("hello") == "\"hello\""
    assert jsonify("hello there") == "\"hello there\""
    assert jsonify("\"hello there\"") == "\"\\\"hello there\\\"\""
    assert jsonify("hello \'there\'") == "\"hello 'there'\""
    assert jsonify("hello " + chr(0x641) + "there" + chr(0x200E) + chr(0x200F)) == "\"hello \\u0641there\\u200e\\u200f\""
    assert jsonify(["a","b","c"]) == "[\"a\", \"b\", \"c\"]"
    assert jsonify({"a":"b","c":"d"}) == "{\"a\": \"b\", \"c\": \"d\"}"