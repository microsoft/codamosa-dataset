

# Generated at 2022-06-20 23:29:57.325301
# Unit test for function jsonify
def test_jsonify():
    result = {'failed': 'True'}
    assert jsonify(result, format=False) == '{"failed": "True"}'
    assert jsonify(result, format=True) == '{\n    "failed": "True"\n}'

# Generated at 2022-06-20 23:30:09.498769
# Unit test for function jsonify
def test_jsonify():
    '''
    jsonify: return JSON representation of a data structure
    '''
    my_dict = dict(a=1, b=2, c=3)
    my_list = [1, 2, 'string']
    assert jsonify(my_dict) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(my_list) == '[1, 2, "string"]'
    assert jsonify(my_dict, True) == '''{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'''
    assert jsonify(my_list, True) == '''[\n    1, \n    2, \n    "string"\n]'''

# Generated at 2022-06-20 23:30:20.645563
# Unit test for function jsonify
def test_jsonify():
    import collections
    import os

    # Create namedtuple object
    id = collections.namedtuple('id', ('name', 'uid'))
    user1 = id(name='john', uid=1001)
    user2 = id(name='jack', uid=1002)
    user3 = id(name='jim', uid=1003)
    user4 = id(name='joe', uid=1004)
    user5 = id(name='jerry', uid=1005)
    user6 = id(name='josh', uid=1006)
    user7 = id(name='justin', uid=1007)
    user8 = id(name='jared', uid=1008)
    user9 = id(name='jesse', uid=1009)

# Generated at 2022-06-20 23:30:24.187091
# Unit test for function jsonify
def test_jsonify():
    # input must be a dictonary, since jsonify fails with other types
    # like list, int, string, boolean, etc.
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-20 23:30:37.904002
# Unit test for function jsonify
def test_jsonify():
    data = {
        "foo": "bar",
        "a": [ "b", "c", 42 ],
        "d": { "e": "f" },
        "g": ( "h", "i" )
    }
    uncompressed = '{"a": ["b", "c", 42], "d": {"e": "f"}, "foo": "bar", "g": ["h", "i"]}\n'
    compressed = '{"a":["b","c",42],"d":{"e":"f"},"foo":"bar","g":["h","i"]}\n'
    assert uncompressed == jsonify(data, format=True)
    assert compressed == jsonify(data, format=False)

    assert '{}\n' == jsonify(None)
    assert 'null\n' == jsonify(None, True)
    assert 'null\n'

# Generated at 2022-06-20 23:30:40.580631
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify("foo") == "\"foo\""
    assert jsonify(1) == "1"

# Generated at 2022-06-20 23:30:53.934091
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify'''

    from ansible.utils.unicode import to_unicode

    # Testing with a unicode string
    ustring = u'{ "foo": "bar" }'
    ajson = jsonify(to_unicode(ustring))
    assert ustring == ajson

    # Testing with a utf-8 string
    utf8string = u'{ "unicode": "f\xf8\xf8" }'
    ajson = jsonify(utf8string)
    assert utf8string == ajson

    # Testing with a dictionary
    adict = {"foo": "bar"}
    ajson = jsonify(adict)
    assert ustring == ajson

    # Testing with a list
    alist = ["foo", "bar"]
    ajson = jsonify(alist)
    assert u

# Generated at 2022-06-20 23:31:04.013731
# Unit test for function jsonify
def test_jsonify():
    '''
    jsonify(result, format=False): return JSON serialization of result

    >>> print(jsonify(1))
    1
    >>> print(jsonify({u'foo': [u'bar', u'baz']}))
    {"foo": ["bar", "baz"]}
    >>> print(jsonify({u'foo': [u'bar', u'baz']}, True))
    {
        "foo": [
            "bar",
            "baz"
        ]
    }
    '''
    pass

# Generated at 2022-06-20 23:31:18.474217
# Unit test for function jsonify
def test_jsonify():
    result = {
        'msg': 'this is a test',
        'changed': True,
        'rc': 0,
        'results': ['one', 'two'],
        'deeper': {
            'a': 1,
            'b': 2,
            'c': 3,
            }
        }

    assert jsonify(result, False) == '{"changed": true, "deeper": {"a": 1, "b": 2, "c": 3}, "msg": "this is a test", "rc": 0, "results": ["one", "two"]}'

# Generated at 2022-06-20 23:31:28.089608
# Unit test for function jsonify
def test_jsonify():

    from ansible.module_utils._text import to_bytes

    assert to_bytes(jsonify({}, False)) == to_bytes('{"changed": false, "failed": false, "invocation": {}, "rc": 0}')
    assert to_bytes(jsonify('test', False)) == to_bytes('{"changed": false, "failed": false, "invocation": {}, "rc": 0, "stdout": "test"}')
    assert jsonify({'a': {'b': {'c': {'d': [1,2,3]}}}}) == '{\n    "a": {\n        "b": {\n            "c": {\n                "d": [\n                    1, \n                    2, \n                    3\n                ]\n            }\n        }\n    }\n}'

# Generated at 2022-06-20 23:31:37.300947
# Unit test for function jsonify
def test_jsonify():

    d1 = jsonify({"a": 1, "b": 2})
    assert isinstance(d1, str)

    # assert jsonify(None) == "{}"

    d1 = jsonify({"a": 1, "b": 2}, True)
    assert isinstance(d1, str)

    # assert jsonify(None, True) == "{}"

    print("success")

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-20 23:31:50.393373
# Unit test for function jsonify
def test_jsonify():
    import os
    import sys
    import tempfile
    #-- clean up to make sure the test runs
    os.chdir(sys.path[0])
    #-- tempfile used to write json output
    temp = tempfile.TemporaryFile()
    #-- make sure we have an object to jsonify
    results = {"example_playbook.yml": []}
    #-- compress the results
    json_results = jsonify(results)
    #-- make sure we have a dictionary to unpack
    #-- we're concerned about a parse error, not a key error
    results_unpacked = json.loads(json_results)
    #-- make sure we have a dictionary, not a string
    assert(isinstance(results_unpacked, dict),
           "json_unpacked should be a dictionary, not a string")



# Generated at 2022-06-20 23:32:03.370844
# Unit test for function jsonify
def test_jsonify():
    result = {
        'test1': 'test1',
        'test2': {
            'test3': 'test3',
            'test4': 'test4',
            'test5': {
                'test6': 'test6'
            }
        }
    }
    assert jsonify(result) == '{"test1": "test1", "test2": {"test3": "test3", "test4": "test4", "test5": {"test6": "test6"}}}'
    assert jsonify(result, True) == '''{
    "test1": "test1",
    "test2": {
        "test3": "test3",
        "test4": "test4",
        "test5": {
            "test6": "test6"
        }
    }
}'''
   

# Generated at 2022-06-20 23:32:14.341842
# Unit test for function jsonify
def test_jsonify():
    import unit_tests
    result = {'server': 'localhost', 'changed': False, 'failures': 7}
    assert jsonify(result) == '{"failures": 7, "changed": false, "server": "localhost"}'
    assert jsonify(result, format=True) == '''{
    "changed": false,
    "failures": 7,
    "server": "localhost"
}'''
    result = {'server': 'localhost', 'changed': False, 'failures': 7, 'random_key': 'my key\xe9'}
    assert jsonify(result) == '{"random_key": "my key\xc3\xa9", "failures": 7, "changed": false, "server": "localhost"}'

# Generated at 2022-06-20 23:32:22.058190
# Unit test for function jsonify
def test_jsonify():
    ''' unit test for jsonify function '''

    result = {'a':1,'b':2,'c':3}
    assert "{\"a\": 1, \"b\": 2, \"c\": 3}" == jsonify(result)
    assert "{\n    \"a\": 1, \n    \"b\": 2, \n    \"c\": 3\n}" == jsonify(result, True)

    assert "{}" == jsonify(None)

# Generated at 2022-06-20 23:32:34.827540
# Unit test for function jsonify
def test_jsonify():
    # Test dicts and lists
    assert jsonify({"a": 2}) == '{"a": 2}'
    assert jsonify(["a", 2]) == '["a", 2]'
    assert jsonify({}) == '{}'
    assert jsonify([]) == '[]'

    # Test indenting
    assert jsonify({"a": 2},format=False) == '{"a": 2}'
    assert jsonify(["a", 2],format=False) == '["a", 2]'
    assert jsonify({},format=False) == '{}'
    assert jsonify([],format=False) == '[]'

    assert jsonify({"a": 2},format=True) == '{\n    "a": 2\n}'

# Generated at 2022-06-20 23:32:42.185584
# Unit test for function jsonify
def test_jsonify():
    # Neither of these should have any escape characters in them
    print(jsonify({'strings_u8': 'blah\u2713'}))
    print(jsonify({'strings_u8': 'blah\u2713'}, True))

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-20 23:32:46.138571
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None, True)=="{}"
    test_array = [1, 2, 3, 4]
    assert jsonify(test_array)=='[1,2,3,4]'

# Generated at 2022-06-20 23:32:50.584291
# Unit test for function jsonify
def test_jsonify():
    result = {'a': 42, 'b': 43}
    assert jsonify(result) == jsonify(result, False) == '{"a": 42, "b": 43}'
    assert jsonify(result, True) == '{\n    "a": 42, \n    "b": 43\n}'
    assert jsonify(None) == '{}'


# Generated at 2022-06-20 23:32:58.575328
# Unit test for function jsonify
def test_jsonify():
    data = jsonify(None)
    assert data == "{}"
    data = jsonify(dict(a=1))
    assert data == '{"a": 1}'
    data = jsonify(dict(a=dict(b=2)))
    assert data == '{"a": {"b": 2}}'
    data = jsonify(dict(a=dict(b=2)), format=True)
    assert data == '{\n    "a": {\n        "b": 2\n    }\n}'

# Generated at 2022-06-20 23:33:11.231677
# Unit test for function jsonify
def test_jsonify():
    dict = dict()
    dict[u'foo'] = u'bar'
    dict[u'baz'] = [u'zab1', u'zab2']
    assert jsonify(dict) == u'{"foo": "bar", "baz": ["zab1", "zab2"]}', "Uncompressed format does not match"
    assert jsonify(dict, True) == u'{\n    "baz": [\n        "zab1", \n        "zab2"\n    ], \n    "foo": "bar"\n}', "Compressed format does not match"

# Generated at 2022-06-20 23:33:15.312340
# Unit test for function jsonify
def test_jsonify():
    result = { 'A' : 1 }
    assert jsonify(result) == '{ "A": 1 }'
    assert jsonify(result, True) == '{\n    "A": 1\n}'
    assert jsonify({}) == '{}'
    assert jsonify(None) == '{}'

# Generated at 2022-06-20 23:33:29.001619
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import basic

    assert jsonify(dict(changed=True, foo='bar')) == '{"changed": true, "foo": "bar"}'
    assert jsonify(dict(changed=True, foo='bar'), format=True) == "{\n    \"changed\": true, \n    \"foo\": \"bar\"\n}"
    assert jsonify(dict(changed=True, foo=u'bar')) == '{"changed": true, "foo": "bar"}'
    assert jsonify(dict(changed=True, foo='bar', bam=dict(one=1, two=2))) == '{"changed": true, "bam": {"one": 1, "two": 2}, "foo": "bar"}'

# Generated at 2022-06-20 23:33:39.816962
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify() '''
    data = {
        'a': 'foo',
        'b': 'bar',
        'c': {
            'foo': 'bar'
            }
        }
    assert jsonify(data) == '{"a": "foo", "b": "bar", "c": {"foo": "bar"}}'
    assert jsonify(data, True) == '''{
    "a": "foo",
    "b": "bar",
    "c": {
        "foo": "bar"
    }
}'''



# Generated at 2022-06-20 23:33:45.137686
# Unit test for function jsonify
def test_jsonify():
    result = {'foo': 'bar', 'blah': [1,2,3], 'deeper': {'a': 'b'}}
    result_uncompressed = jsonify(result)
    assert(result_uncompressed == '{"blah": [1, 2, 3], "deeper": {"a": "b"}, "foo": "bar"}')
    result_compressed = jsonify(result, format=True)
    assert(result_compressed == '''{
    "blah": [
        1,
        2,
        3
    ],
    "deeper": {
        "a": "b"
    },
    "foo": "bar"
}''')

# Generated at 2022-06-20 23:33:56.135539
# Unit test for function jsonify
def test_jsonify():
    import difflib
    def compare_json(expected, actual):
        a = json.loads(expected)
        b = json.loads(actual)
        diff = '\n'.join(difflib.ndiff(json.dumps(a, indent=4, sort_keys=True).splitlines(),
                                        json.dumps(b, indent=4, sort_keys=True).splitlines()))
        assert a == b, "JSON mismatch:\n%s" % diff

    # input: 'result'
    # output: json representation of 'result'

    compare_json('{}', jsonify(None))
    compare_json('{}', jsonify([]))
    compare_json('{}', jsonify({}))
    compare_json('[]', jsonify([]))

# Generated at 2022-06-20 23:34:02.984824
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-20 23:34:10.180101
# Unit test for function jsonify
def test_jsonify():
    tmp_json = {'foo': 'bar', 'baz': 'qux'}
    expected_one_line_json = '{"baz": "qux", "foo": "bar"}'
    result_one_line_json = jsonify(tmp_json)
    assert result_one_line_json == expected_one_line_json, "one line did not match. expected: %s, actual: %s" % (expected_one_line_json, result_one_line_json)

    expected_formated_json = """{
    "baz": "qux",
    "foo": "bar"
}"""
    result_formated_json = jsonify(tmp_json, True)

# Generated at 2022-06-20 23:34:20.112149
# Unit test for function jsonify
def test_jsonify():
    # Test with an empty object
    assert jsonify(None) == "{}"
    # Test with a dict
    assert jsonify({"hello": "world"}) == '{"hello": "world"}'
    # Test with a list
    assert jsonify(["hello", "world"]) == '["hello", "world"]'
    # Test with a list of dicts
    assert jsonify([ {"hello": "world"}, {"hello": "world"} ]) == '[{"hello": "world"}, {"hello": "world"}]'
    # Test with another list of dicts
    assert jsonify([ {"hello": [1,2,3]} ]) == '[{"hello": [1, 2, 3]}]'
    # Test with a dict with a list inside

# Generated at 2022-06-20 23:34:31.414179
# Unit test for function jsonify
def test_jsonify():

    # Test None
    assert jsonify(None) == '{}'

    # Test empty dict
    assert jsonify({}) == '{}'
    assert jsonify({}, format=True) == '{}'

    # Test empty list
    assert jsonify([]) == '[]'
    assert jsonify([], format=True) == '[]'

    # Test empty string
    assert jsonify('') == "\"\""
    assert jsonify('', format=True) == "\"\""

    # Test False
    assert jsonify(False) == "false"
    assert jsonify(False, format=True) == "false"

    # Test True
    assert jsonify(True) == "true"
    assert jsonify(True, format=True) == "true"

    # Test int

# Generated at 2022-06-20 23:34:40.837955
# Unit test for function jsonify
def test_jsonify():
    assert '"foo": "bar"' in jsonify({'foo': 'bar'}, False), "simple jsonify test failed"
    assert '[\n    "foo", \n    "bar"\n]' in jsonify(['foo', 'bar'], True), "list jsonify test failed"

# Generated at 2022-06-20 23:34:45.929780
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify function '''
    assert jsonify(None) == '{}'
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}) == '{\n    "a": "b"\n}'


# Generated at 2022-06-20 23:34:51.907277
# Unit test for function jsonify
def test_jsonify():
    import json
    assert json.loads(jsonify({"a": 1})) == {"a": 1}
    assert json.loads(jsonify({"a": 1}, format=True)) == {"a": 1}
    result = json.loads(jsonify({"a": {"b": 1}}))
    assert result["a"]["b"] == 1
    result = json.loads(jsonify({"a": {"b": 1}}, format=True))
    assert result["a"]["b"] == 1
    result = json.loads(jsonify({"a": {"b": 1, "c": [1, 2]}}))
    assert result["a"]["b"] == 1
    assert result["a"]["c"][0] == 1
    assert result["a"]["c"][1] == 2
    result = json

# Generated at 2022-06-20 23:35:01.549589
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify
    assert jsonify(dict(changed=False, rc=0, stdout='', stderr='')) == '{"changed": false, "rc": 0, "stderr": "", "stdout": ""}'
    assert jsonify(dict(changed=False, rc=0, stdout='', stderr=''), format=True) == '{\n    "changed": false, \n    "rc": 0, \n    "stderr": "", \n    "stdout": ""\n}'

# vim: set ts=4 sw=4 et:

# Generated at 2022-06-20 23:35:09.284634
# Unit test for function jsonify
def test_jsonify():
    res = {"a": ["1", "2"]}
    res_compressed = '{"a": ["1", "2"]}'
    res_compressed_no_sort = '{"a": ["2", "1"]}'
    assert jsonify(res, True) == res_compressed
    # json.dumps returns a dict sorted by keys
    assert jsonify({"a": ["2", "1"]}, True) == res_compressed
    assert jsonify({"a": ["2", "1"]}) == res_compressed_no_sort

# Generated at 2022-06-20 23:35:23.425261
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import basic
    assert jsonify({
                    'a': 'hello',
                    'b': 'world',
                    'c': [ '1', '2', '3' ]
                   }) == '{"a": "hello", "c": ["1", "2", "3"], "b": "world"}'
    assert jsonify({
                    'a': 'hello',
                    'b': 'world',
                    'c': [ '1', '2', '3' ]
                   }, True) == '{\n    "a": "hello",\n    "c": [\n        "1",\n        "2",\n        "3"\n    ],\n    "b": "world"\n}'

# Generated at 2022-06-20 23:35:28.420927
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'
    assert jsonify({"foo": "bar"}, True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-20 23:35:34.651667
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(None, True) == "{}"
    assert jsonify("foo") == "\"foo\""
    assert jsonify("foo", True) == "\"foo\""
    assert jsonify({"foo":"bar"}, True) == "{\n    \"foo\": \"bar\"\n}"

# Generated at 2022-06-20 23:35:37.965152
# Unit test for function jsonify
def test_jsonify():
    print("testing jsonify")
    print(jsonify(dict(a=1,b=2), format=True))
    print(jsonify(dict(a=1,b=2), format=False))
    print(jsonify(dict(a=1,b=2)))

# Generated at 2022-06-20 23:35:48.527063
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_bytes

    def _json_repr(o):
        return to_bytes(json.dumps(o), errors='surrogate_or_strict')

    # Strings
    o = 'a string'
    assert jsonify(o) == _json_repr(o)
    o = u'a string'
    assert jsonify(o) == _json_repr(o)

    # Bytes
    o = b'a string'
    assert jsonify(o) == _json_repr(o)

    # Non-byte strings
    o = u'\u2019'
    assert jsonify(o) == _json_repr(o)

# Generated at 2022-06-20 23:36:03.636324
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(changed=False, failed=False, rc=0)) == '{}'
    assert jsonify(None) == '{}'
    assert jsonify(dict(changed=False, failed=False, rc=0), format=True) == '{}'
    assert jsonify(None, format=True) == '{}'

# Generated at 2022-06-20 23:36:08.072980
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'

# ---- Ansible filters ----

# Generated at 2022-06-20 23:36:17.839282
# Unit test for function jsonify
def test_jsonify():

    assert jsonify({'a': 'b'}) == "{\"a\": \"b\"}"
    assert jsonify({'a': {'b': 'c'}}) == "{\"a\": {\"b\": \"c\"}}"
    assert jsonify({'a': {'b': 'c'}}, True) == "{\n    \"a\": {\n        \"b\": \"c\"\n    }\n}"
    assert jsonify(None) == "{}"

# vim: filetype=python sts=4 sw=4 et si :

# Generated at 2022-06-20 23:36:29.820976
# Unit test for function jsonify

# Generated at 2022-06-20 23:36:35.873705
# Unit test for function jsonify
def test_jsonify():
    result = {'a': 1, 'b': [1, 2, 3], 'c': {'d': 4, 'e': 5}}
    assert jsonify(result) == "{\"a\": 1, \"b\": [1, 2, 3], \"c\": {\"d\": 4, \"e\": 5}}"
    assert jsonify(result, True) == "{\n    \"a\": 1, \n    \"b\": [\n        1, \n        2, \n        3\n    ], \n    \"c\": {\n        \"d\": 4, \n        \"e\": 5\n    }\n}"

# Generated at 2022-06-20 23:36:39.302948
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'blah': 'bleh'}, format=True) == '''{
    "blah": "bleh"
}'''

# Generated at 2022-06-20 23:36:44.294092
# Unit test for function jsonify
def test_jsonify():
    assert "{}" == jsonify(None)
    assert '{"a": 1}' == jsonify({'a': 1})
    assert '{"a": 1, "b": 2}' == jsonify({'a': 1, 'b': 2})

# Generated at 2022-06-20 23:36:50.309375
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(changed=True, failed=False, rc=0, json_result=None)) == "{}"
    assert jsonify(dict(changed=True, failed=False, rc=0, json_result=None), format=True) == '''{
    "changed": true,
    "failed": false,
    "json_result": null,
    "rc": 0
}'''
    assert jsonify(dict(changed=True, failed=False, rc=0, json_result="None")) == '{"json_result": "None", "rc": 0, "changed": true, "failed": false}'

# Generated at 2022-06-20 23:36:50.973912
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'

# Generated at 2022-06-20 23:36:57.974484
# Unit test for function jsonify
def test_jsonify():
    import sys
    import random
    if sys.version_info < (3, 0):
        assert jsonify(True) == "true"
        assert jsonify(3) == "3"
        assert jsonify(3.14) == "3.14"
        assert jsonify([True]) == "[true]"
        assert jsonify({"a": 3, "b": "yes"}) == '{"a": 3, "b": "yes"}'
        assert jsonify({}) == "{}"
        assert jsonify(None) == "{}"
    else:
        assert jsonify(True) == "true"
        assert jsonify(3) == "3"
        assert jsonify(3.14) == "3.14"
        assert jsonify([True]) == "[true]"

# Generated at 2022-06-20 23:37:21.588530
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(1) == '1'
    assert jsonify(['a', 'b']) == '["a", "b"]'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'

# Generated at 2022-06-20 23:37:33.116618
# Unit test for function jsonify
def test_jsonify():
    result = {
        'msg': 'foo',
        'messages': [
            {'msg': 'foo'},
            {'msg': 'bar'},
        ],
        'invocation': {
            'module_args': {
                'name': 'test',
                'state': 'present',
                'get_type_list': True,
            },
            'module_name': 'test',
        },
    }
    result_str = jsonify(result, format=True)

# Generated at 2022-06-20 23:37:37.446724
# Unit test for function jsonify
def test_jsonify():
    import sys
    if sys.version_info[0] > 2:
        assert(jsonify(None) == '{}')
    else:
        assert(jsonify(None) == '{}')

# Generated at 2022-06-20 23:37:42.724818
# Unit test for function jsonify
def test_jsonify():
    result = {'foo': 'bar',
              'alpha': {'bravo': ['charlie', 'delta', 'echo']}
             }
    assert(jsonify(result) == '{"alpha": {"bravo": ["charlie", "delta", "echo"]}, "foo": "bar"}')
    assert(jsonify(result, format=True) == '''{
    "alpha": {
        "bravo": [
            "charlie",
            "delta",
            "echo"
        ]
    },
    "foo": "bar"
}''')
    assert(jsonify(None) == '{}')

if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-20 23:37:50.600805
# Unit test for function jsonify
def test_jsonify():
    from contextlib import nested
    from StringIO import StringIO

    # Basic
    ansible_dict = {'a': 1, 'b': 2, 'c': 3}
    assert jsonify(ansible_dict) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(ansible_dict, format=True) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'

    # Empty dict
    ansible_dict = {}
    assert jsonify(ansible_dict) == '{}'
    assert jsonify(ansible_dict, format=True) == '{}'

    # List dict

# Generated at 2022-06-20 23:37:59.842104
# Unit test for function jsonify
def test_jsonify():
    ''' This function tests the jsonify function '''
    import datetime
    assert jsonify(None) == "{}"

    assert jsonify([]) == "[]"
    assert jsonify([1]) == "[\n    1\n]"

    assert jsonify({"a": "b"}) == '{\n    "a": "b"\n}'
    assert jsonify({"a": 1}) == '{\n    "a": 1\n}'
    assert jsonify({"a": {"b": "c"}}) == '{\n    "a": {\n        "b": "c"\n    }\n}'

    data = {"a": [1,2,3]}

# Generated at 2022-06-20 23:38:03.376279
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None,format=True) == "{}"
    assert jsonify(None,format=False) == "{}"


# Generated at 2022-06-20 23:38:12.976044
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'foo':'bar'}) == '{"foo": "bar"}'
    assert jsonify(['foo','bar']) == '["foo", "bar"]'
    assert jsonify({'foo':['bar', 'baz']}) == '{"foo": ["bar", "baz"]}'
    assert jsonify({'foo':'bar', 'baz':'qux'}) == '{"foo": "bar", "baz": "qux"}'
    assert jsonify({'foo':'bar', 'baz':'qux'}, format=True) == """{
    "foo": "bar",
    "baz": "qux"
}"""

# Generated at 2022-06-20 23:38:19.192952
# Unit test for function jsonify
def test_jsonify():

    # Test empty string
    assert jsonify('') == '{}'

    # Test normal string
    assert jsonify('foo') == '"foo"'

    # Test unicode string
    assert jsonify(u'bar') == '"bar"'

# vim: set expandtab sw=4 ts=4:

# Generated at 2022-06-20 23:38:20.996730
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'



# Generated at 2022-06-20 23:39:03.751956
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(dict(foo='bar')) == '{"foo": "bar"}'

    assert jsonify(dict('foo','bar')) == '{"foo": "bar"}'

    assert jsonify({ 'foo' : ['a','b'], 'bar' : 'baz'}) == json.dumps({ 'foo' : ['a','b'], 'bar' : 'baz'}, sort_keys=True, indent=None, ensure_ascii=False)

    assert jsonify([1,2,3]) == '[1, 2, 3]'

# Generated at 2022-06-20 23:39:12.188941
# Unit test for function jsonify
def test_jsonify():
    import sys

    class MockModule(object):
        params = dict()

    class MockArgs(object):
        def __init__(self, module):
            self.module = module

    fm = MockModule()
    args = MockArgs(fm)
    sys.modules['ansible.module_utils.basic'] = fm

    print(jsonify({'a': 'b'}))
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    print(jsonify({'a': 'b'}, True))
    assert jsonify({'a': 'b'}, True) == '{\n    "a": "b"\n}'

# Generated at 2022-06-20 23:39:15.412675
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({"a": "あいうえお"}, sort_keys=True) == '{"a": "あいうえお"}'

# Generated at 2022-06-20 23:39:19.696576
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'
    assert jsonify({"foo": "bar"}, format=True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-20 23:39:31.132680
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify(None) == '{}')
    assert(jsonify(dict(changed=True)) == '{"changed": true}')
    assert(jsonify(dict(changed=True, foo="bar")) == '{"changed": true, "foo": "bar"}')
    assert(jsonify(dict(changed=True, foo="bar")) == '{"changed": true, "foo": "bar"}')
    assert(jsonify(dict(changed=True, foo="bar", ansible_facts=dict(foo="bar"))) == '{"changed": true, "foo": "bar", "ansible_facts": {"foo": "bar"}}')

# Generated at 2022-06-20 23:39:34.260096
# Unit test for function jsonify
def test_jsonify():
    result = dict()
    result['foo'] = 'bar'

    unformated = jsonify(result, format=False)
    formated = jsonify(result, format=True)
    assert unformated == '{"foo": "bar"}'
    assert formated == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-20 23:39:38.642611
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert jsonify(None) == "{}"
    assert jsonify({'a': 'b'}) == '{\n    "a": "b"\n}'
    assert jsonify({'a': 1}) == '{\n    "a": 1\n}'
    assert jsonify({'a': [1,2,3]}) == '{\n    "a": [\n        1, \n        2, \n        3\n    ]\n}'
    assert jsonify({'a': [1,[2]]}) == '{\n    "a": [\n        1, \n        [\n            2\n        ]\n    ]\n}'


# Generated at 2022-06-20 23:39:48.428300
# Unit test for function jsonify
def test_jsonify():
    import json
    from ansible.utils.unicode import to_unicode
    from ansible.utils.hashing import md5s

    # normal list
    data = [ 1, 2, 3, {'a':'b'} ]
    assert data == json.loads(jsonify(data))

    # list with utf-8
    data = [ 1, 2, 3, { 'a':'b', u'foo': u'this \xe2\x80\x99s a test' } ]
    assert data == json.loads(jsonify(data))

    # list with binary objects
    data = [ 1, 2, 3, { 'a':'b', u'foo': u'this \xe2\x80\x99s a test', 'test': md5s('test') } ]

# Generated at 2022-06-20 23:39:52.063566
# Unit test for function jsonify
def test_jsonify():
    data = {'foo': 'bar'}
    res = jsonify(data, True)
    assert res == "{\"foo\": \"bar\"}"