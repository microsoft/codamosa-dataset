

# Generated at 2022-06-11 09:04:31.355319
# Unit test for function jsonify
def test_jsonify():
    input = dict(changed=True, rc=0)
    output = '{"changed": true, "rc": 0}'

    assert output == jsonify(input)
    output = '{\n    "changed": true, \n    "rc": 0\n}'
    assert output == jsonify(input, True)

# Generated at 2022-06-11 09:04:35.609339
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_text

    assert to_text(jsonify(dict(a=1, b=2, c=3))) == "{\"a\": 1, \"b\": 2, \"c\": 3}"

# Generated at 2022-06-11 09:04:38.794094
# Unit test for function jsonify
def test_jsonify():
    from ansible.callbacks import vvv
    import pprint
    # test empty set
    assert jsonify(None) == "{}"
    # test a simple dict
    result = jsonify({'foo': 'bar'}, format=True)
    print("result=|%s|" % result)
    assert result == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-11 09:04:42.926601
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify function '''
    result = jsonify(None, format=False)
    assert result == '{}'

    test_dict = dict(ansible_facts=dict(test='test'))
    result = jsonify(test_dict, format=True)
    assert result == u'{\n    "ansible_facts": {\n        "test": "test"\n    }\n}'

# Generated at 2022-06-11 09:04:50.425038
# Unit test for function jsonify
def test_jsonify():
    body = [
        { "name": "a", "age": 20 },
        { "name": "b", "age": 30 },
    ]
    assert jsonify(body, False) == "[{\"age\": 20, \"name\": \"a\"}, {\"age\": 30, \"name\": \"b\"}]"
    assert jsonify(body, True) == """\
[
    {
        "age": 20,
        "name": "a"
    },
    {
        "age": 30,
        "name": "b"
    }
]"""

# Generated at 2022-06-11 09:04:56.824785
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a':1, 'b':2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a':1, 'b':2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'


# Generated at 2022-06-11 09:05:01.022486
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo='bar')) == '{"foo": "bar"}'
    assert jsonify(dict(foo='bar'), format=True) == '''{\n    "foo": "bar"\n}'''

# Generated at 2022-06-11 09:05:04.107902
# Unit test for function jsonify
def test_jsonify():
    ''' test_jsonify '''

    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'

# Generated at 2022-06-11 09:05:10.925484
# Unit test for function jsonify
def test_jsonify():
    assert jsonify("hello") == '"hello"'
    assert jsonify(3) == '3'
    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify([]) == "[]"
    assert jsonify(['a', 'b', True]) == '["a", "b", true]'
    assert jsonify(dict(a=[1,2],b='c')) == '{"a": [1, 2], "b": "c"}'

# Generated at 2022-06-11 09:05:18.326876
# Unit test for function jsonify
def test_jsonify():
    from ansible.plugins.loader import connection_loader
    module_name = 'raw'
    class_name = 'Raw'
    cls = connection_loader.get(module_name, class_name)

    # Test jsonify is called with single value which can be converted to list
    result = cls.jsonify('result')
    assert result == '[\n    "result"\n]'

    # Test jsonify is called with non-list
    result = cls.jsonify({"foo": "bar"})
    assert result == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-11 09:05:30.785801
# Unit test for function jsonify
def test_jsonify():
    ''' unit test for function jsonify()'''

    from ansible.compat import StringIO

    def _output(value, format=False):
        saved_stdout = sys.stdout
        try:
            sys.stdout = StringIO()
            result = jsonify(value, format=format)
            return sys.stdout.getvalue()
        finally:
            sys.stdout = saved_stdout

    import sys
    # The following test should not raise an exception
    # (see https://github.com/ansible/ansible/issues/13672)
    try:
        _output([ None ])
    except Exception:
        sys.exit(1)
    else:
        sys.exit(0)

# Generated at 2022-06-11 09:05:35.985368
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "A", "b": "B", "c": "C"}) == '{"a": "A", "b": "B", "c": "C"}'
    assert jsonify({"a": "A", "b": "B", "c": "C"}, True) == '''{
    "a": "A",
    "b": "B",
    "c": "C"
}'''
    assert jsonify(None) == "{}"

# Generated at 2022-06-11 09:05:47.847633
# Unit test for function jsonify
def test_jsonify():
    from ansible import constants as C

    # Test different return value of jsonify
    assert jsonify('foo') == '"foo"'
    assert jsonify(1) == '1'
    assert jsonify(1.3) == '1.3'
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    assert jsonify({'foo': 'bar', 'baz': True}) == '{"baz": true, "foo": "bar"}'
    assert jsonify(['foo', 'bar', True, 1, 1.3]) == '["foo", "bar", true, 1, 1.3]'

    # Test string with different format
    val = jsonify({'a': 'b'}, format=True)
    assert val == '{\n    "a": "b"\n}'

   

# Generated at 2022-06-11 09:05:51.928277
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a':'a', 'b':1}) == '{"a": "a", "b": 1}'
    assert jsonify({'a':'a', 'b':1}, True) == '{\n    "a": "a", \n    "b": 1\n}'

# Generated at 2022-06-11 09:05:58.632175
# Unit test for function jsonify
def test_jsonify():
    # JSON without unicode
    assert jsonify('{"foo": "bar"}') == '{"foo": "bar"}'

    # JSON with unicode
    assert jsonify('{"föo": "bár"}') == '{"föo": "bár"}'

    # JSON with unicode and formatting
    assert jsonify('{"föo": "bár"}', True) == '{\n    "föo": "bár"\n}'

    # None as input
    assert jsonify(None) == '{}'

# Generated at 2022-06-11 09:06:02.983076
# Unit test for function jsonify
def test_jsonify():
    test = dict(a=1, b=2, c=3)
    result = jsonify(test)
    assert result == '{"a": 1, "b": 2, "c": 3}'

    result = jsonify(test, format=True)
    assert result == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'


# Generated at 2022-06-11 09:06:12.708373
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify(["abc", "defg", "hi"]) == '["abc", "defg", "hi"]'
    assert jsonify(["abc", "defg", "hi"], True) == '[\n    "abc", \n    "defg", \n    "hi"\n]'

# Generated at 2022-06-11 09:06:16.663492
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a':1}) == '{"a": 1}'
    assert jsonify({'a':1}, True) == '{\n    "a": 1\n}'

    print("Successfully passed simple JSON test.")

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:06:20.691577
# Unit test for function jsonify
def test_jsonify():
    # Current default string type is unicode; make sure it works
    assert jsonify('foo') == '"foo"'
    # Explicitly passing unicode strings should also work
    assert jsonify(u'foo') == '"foo"'
    # Bytestrings should work
    assert jsonify('foo'.encode('utf-8')) == '"foo"'


# Generated at 2022-06-11 09:06:25.399838
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'spam': 'eggs'}) == "{\"spam\": \"eggs\"}"
    assert jsonify({'spam': 'eggs'}, format=True) == "{\n    \"spam\": \"eggs\"\n}"

# Generated at 2022-06-11 09:06:36.366916
# Unit test for function jsonify
def test_jsonify():
    assert isinstance(jsonify(None), basestring)
    assert jsonify(None) == '{}'
    assert isinstance(jsonify({'foo': 'bar'}, format=True), basestring)
    assert jsonify({'foo': 'bar'}, format=True) == '{\n    "foo": "bar"\n}'
    assert isinstance(jsonify({'foo': 'bar'}, format=False), basestring)
    assert jsonify({'foo': 'bar'}, format=False) == '{"foo": "bar"}'

# Generated at 2022-06-11 09:06:46.847204
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 0}) == '{"a": 0}'
    assert jsonify({"a": 0}, format=True) == '{\n    "a": 0\n}'
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, format=True) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b", "c": 1}) == '{"a": "b", "c": 1}'
    assert jsonify({"a": "b", "c": 1}, format=True) == '{\n    "a": "b",\n    "c": 1\n}'

# Generated at 2022-06-11 09:06:52.554369
# Unit test for function jsonify
def test_jsonify():
    data = [
        {'a': 1, 'b': 'two', 'c': 3, 'd': [4, 5, 'six'], 'e': {'f': 7, 'g': 'eight', 'h': [9, 0]}, 'i': '10'},
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    ]

    compressed = jsonify(data)
    uncompressed = jsonify(data, True)

    for each in [compressed, uncompressed]:
        assert '{' in each
        assert '}' in each
        assert '[' in each
        assert ']' in each
        assert 'one' not in each


# Generated at 2022-06-11 09:07:01.152674
# Unit test for function jsonify
def test_jsonify():
    from collections import OrderedDict
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._text import to_text

    # Class for testing
    class TestClass:
        """Class for testing jsonify"""
        def __init__(self):
            self.a = None
            self.b = 1
            self.c = "two"
            self.d = 3.0

        def to_jsonable(self):
            return {self.c: self.b}

    # Create test data
    test_unicode_data = [u'R\xe4ksm\xf6rg\xe5s', u'\u00c5kergatan 24']


# Generated at 2022-06-11 09:07:02.249523
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'


# Generated at 2022-06-11 09:07:13.177110
# Unit test for function jsonify
def test_jsonify():
    result_dict = dict(changed=True, rc=0, stdout='test', task='test_task', msg='test_message')
    result_list = [
        dict(changed=True, rc=0, stdout='test'),
        dict(changed=False, rc=1, stdout='test'),
    ]

    # Test with format=True
    assert jsonify(result_dict, True) == '{\n    "changed": true, \n    "msg": "test_message", \n    "rc": 0, \n    "stdout": "test", \n    "task": "test_task"\n}'

# Generated at 2022-06-11 09:07:21.321449
# Unit test for function jsonify
def test_jsonify():
    d = {'a': 1, 'b': 2}
    assert jsonify(d) == '{"a": 1, "b": 2}'

    d_unicode = {'a': 1, 'b': u'\u1234'}
    assert jsonify(d_unicode) == '{u"a": 1, u"b": u"\u1234"}'
    assert jsonify(d_unicode, format=True) == u'{\n    u"a": 1, \n    u"b": u"\u1234"\n}'

# Generated at 2022-06-11 09:07:28.143972
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(changed=False)) == '{"changed": false}'
    assert jsonify(dict(changed=True))  == '{"changed": true}'
    assert jsonify(dict(changed=False, rc=0)) == '{"changed": false, "rc": 0}'
    assert '\n' not in jsonify(dict(changed=False, rc=0))
    assert jsonify(dict(changed=False, rc=0), format=True) == '''{
    "changed": false,
    "rc": 0
}'''



# Generated at 2022-06-11 09:07:30.888950
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, True) == '{\n    "a": "b"\n}'



# Generated at 2022-06-11 09:07:38.570064
# Unit test for function jsonify
def test_jsonify():
    result = { "foo": "one", "bar": 2, "baz": False, "bat": None }
    assert jsonify(result, format=True) == '{\n    "bar": 2,\n    "bat": null,\n    "baz": false,\n    "foo": "one"\n}'
    assert jsonify(result, format=False) == '{"bar": 2, "bat": null, "baz": false, "foo": "one"}'


# Generated at 2022-06-11 09:07:49.024541
# Unit test for function jsonify
def test_jsonify():
    test_dict = {'success': 1, 'failed': None, 'warnings': None}
    assert jsonify(test_dict) == '{"failed": null, "success": 1, "warnings": null}'

    test_dict = {'success': 1, 'failed': None, 'warnings': None}
    assert jsonify(test_dict, format=True) == '{\n    "failed": null,\n    "success": 1,\n    "warnings": null\n}'

# Generated at 2022-06-11 09:07:50.692633
# Unit test for function jsonify
def test_jsonify():

    result = {'success': True}
    assert jsonify(result) == '{"success": true}'



# Generated at 2022-06-11 09:07:55.950046
# Unit test for function jsonify
def test_jsonify():

    x = {'a': 1, 'b': 2, 'c': {'x': 'y'}}
    assert jsonify(x) == '{"a": 1, "b": 2, "c": {"x": "y"}}'
    assert jsonify(x, format=True) == '{\n    "a": 1,\n    "b": 2,\n    "c": {\n        "x": "y"\n    }\n}'

# Generated at 2022-06-11 09:07:57.451192
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"


# Generated at 2022-06-11 09:08:08.481058
# Unit test for function jsonify
def test_jsonify():
    from ansible.plugins import result_handler
    assert result_handler.jsonify({"a": 1, "b": ["x", "y"], "c": {"x": "y"}}) == '{"a": 1, "b": ["x", "y"], "c": {"x": "y"}}'
    assert result_handler.jsonify({"a": 1, "b": ["x", "y"], "c": {"x": "y"}}, True) == '{\n    "a": 1,\n    "b": [\n        "x", \n        "y"\n    ], \n    "c": {\n        "x": "y"\n    }\n}'

# Generated at 2022-06-11 09:08:13.526564
# Unit test for function jsonify
def test_jsonify():
    # Compressed
    result = { 'key': 'value1' }
    assert jsonify(result) == '{\"key\": \"value1\"}'

    # Uncompressed
    result = { 'key': 'value2' }
    assert jsonify(result, True) == '{\n    \"key\": \"value2\"\n}'

# Generated at 2022-06-11 09:08:17.473600
# Unit test for function jsonify
def test_jsonify():
    json = jsonify({"a": 1, "b": 2}, False)
    assert json == '{"a": 1, "b": 2}', json

    json = jsonify({"a": 1, "b": 2}, True)
    assert json == '''{
    "a": 1,
    "b": 2
}''', json

    json = jsonify(None, True)
    assert json == '''{}''', json

# Generated at 2022-06-11 09:08:28.653605
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils import unsafe_proxy_string

    class FakeResult(object):
        def __init__(self, dict_):
            self.__dict__.update(dict_)

    l = [ FakeResult(dict(field=unsafe_proxy_string("\xc3\xb1"))) ]
    assert u'{\n    "field": "\\u00f1"\n}' == jsonify(l, True)
    assert b'[\n    {\n        "field": "\\u00f1"\n    }\n]' == jsonify(l, True).encode("utf-8")
    assert u'[{"field": "\\u00f1"}]' == jsonify(l)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 09:08:34.430797
# Unit test for function jsonify
def test_jsonify():
    temp_json = jsonify({"a": 1, "b": 2, "c": 3})
    assert temp_json == '{"a": 1, "b": 2, "c": 3}'
    temp_json = jsonify({"a": 1, "b": 2, "c": 3}, True)
    assert temp_json == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-11 09:08:37.589145
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert "foo" not in jsonify({'ansible_facts': {'foo': 'bar'}}, format=True)
    assert "foo" in jsonify({'foo': 'bar'}, format=True)

# Generated at 2022-06-11 09:08:51.233356
# Unit test for function jsonify
def test_jsonify():
    # Unit test for function jsonify
    from ansible.compat.tests import unittest

    class TestJsonify(unittest.TestCase):

        def test_jsonify(self):
            testresult = jsonify({"This": "That"})
            self.assertTrue(testresult == '{"This": "That"}' or testresult == u'{"This": "That"}')

    return unittest.main()


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:08:56.545097
# Unit test for function jsonify
def test_jsonify():
    result = {
        'a': 'test',
        'b': False,
        'c': None
    }
    assert jsonify(result) == '{"a": "test", "b": false, "c": null}'
    assert jsonify(result, True) == '{\n    "a": "test",\n    "b": false,\n    "c": null\n}'

# Generated at 2022-06-11 09:09:05.449262
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({"a": 1, "b": 2, "c": [1, 2, 3], "d": "abcd efgh"}) == '{"a": 1, "b": 2, "c": [1, 2, 3], "d": "abcd efgh"}'
    assert jsonify({"a": 1, "b": 2, "c": [1, 2, 3], "d": "abcd efgh"}, format=True) == '{\n    "a": 1,\n    "b": 2,\n    "c": [\n        1,\n        2,\n        3\n    ],\n    "d": "abcd efgh"\n}'
    # TODO: add these tests when json.dumps() is fixed

# Generated at 2022-06-11 09:09:08.884884
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, True) == '{\n    "a": "b"\n}'


# Generated at 2022-06-11 09:09:12.174177
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, format=True) == '{\n    "a": 1\n}'

# Generated at 2022-06-11 09:09:21.691323
# Unit test for function jsonify
def test_jsonify():

    res = {
        "name": "dave",
        "age": 123,
        "extra": [
            "a",
            "b"
        ]
    }

    formatted_res = jsonify(res, format=True)
    assert formatted_res == '{\n    "age": 123,\n    "extra": [\n        "a",\n        "b"\n    ],\n    "name": "dave"\n}'

    unformatted_res = jsonify(res, format=False)
    assert unformatted_res == '{"age": 123, "extra": ["a", "b"], "name": "dave"}'

# Generated at 2022-06-11 09:09:31.849566
# Unit test for function jsonify

# Generated at 2022-06-11 09:09:40.079045
# Unit test for function jsonify
def test_jsonify():
    test_input = {'a': True, 'b': False, 'c': 42}
    test_output = jsonify(test_input)
    test_output_expected = '{"a": true, "b": false, "c": 42}'
    assert test_output == test_output_expected

    test_input = {'a': True, 'b': False, 'c': u'\xe9'}
    test_output = jsonify(test_input)
    test_output_expected = u'{"a": true, "b": false, "c": "\\u00e9"}'
    assert test_output == test_output_expected

    return True

# Generated at 2022-06-11 09:09:43.399999
# Unit test for function jsonify
def test_jsonify():
    assert jsonify("OK") == "\"OK\""
    assert jsonify({"a": [1,2,3], "b": {"c": "OK", "d": "OK"}}, format=True) == """{
    "a": [
        1,
        2,
        3
    ],
    "b": {
        "c": "OK",
        "d": "OK"
    }
}"""

# Generated at 2022-06-11 09:09:53.385363
# Unit test for function jsonify
def test_jsonify():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.basic import AnsibleModule
    from ansible.context import CLIContext
    from ansible.plugins.callback import CallbackBase

    class TestJobResultCallbacks(CallbackBase):
        def __init__(self, *args):
            super(TestJobResultCallbacks, self).__init__(*args)
            self.host_ok     = {}
            self.host_unreachable = {}
            self.host_failed

# Generated at 2022-06-11 09:10:03.532812
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify function '''
    result = { 
        'a': True,
        'b': 42,
        'c': [ 1, 2, 3 ],
        'd': { 'a': 'foo', 'b': 'bar' },
    }
    assert jsonify(result) == jsonify(result)
    assert jsonify(result, format=False) == jsonify(result)
    assert jsonify(result, format=True) == jsonify(result, format=True)

# Generated at 2022-06-11 09:10:14.859397
# Unit test for function jsonify
def test_jsonify():
    result = dict(changed=True,
                ansible_facts=dict(test='testval'))
    res = jsonify(result)
    assert '"changed": true' in res, res
    assert '"ansible_facts": {"test": "testval"}' in res, res
    assert jsonify(None) == "{}", res

if __name__ == '__main__':
    import sys
    import doctest
    failed, tests = doctest.testmod()

    if failed:
        print("Failed to parse documents")
        sys.exit(1)
else:
    # Practice safe importing 
    from ansible.module_utils.basic import *
    from ansible.module_utils.six import iteritems
    from ansible.module_utils._text import to_bytes, to_native

# Generated at 2022-06-11 09:10:25.551187
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify([]) == "[]"
    assert jsonify("hello") == "\"hello\""
    assert jsonify(1) == "1"
    assert jsonify(False) == "false"
    assert jsonify({u"world": True}) == "{\"world\": true}"
    assert jsonify({u"world": True}, True) == "{\n    \"world\": true\n}"
    assert jsonify({1: u"hello", u"world": 1}) == "{\"1\": \"hello\", \"world\": 1}"
    assert jsonify({1: u"hello", u"world": 1}, True) == "{\n    \"1\": \"hello\", \n    \"world\": 1\n}"
    assert jsonify([1, u"hello", True])

# Generated at 2022-06-11 09:10:27.254551
# Unit test for function jsonify
def test_jsonify():
    ''' function jsonify is a true function'''
    assert callable(jsonify)


# Generated at 2022-06-11 09:10:29.263326
# Unit test for function jsonify
def test_jsonify():

    j = jsonify({'a': 1, 'b': 2})
    data = json.loads(j)
    assert 'a' in data
    assert data['a'] == 1

# Generated at 2022-06-11 09:10:37.515051
# Unit test for function jsonify
def test_jsonify():
    '''make sure jsonify returns the expected JSON'''
    result = dict(foo="bar", baz=9001)
    json_result = jsonify(result)
    assert json_result == '{"baz": 9001, "foo": "bar"}'
    json_result = jsonify(result, format=True)
    assert json_result == '{\n    "baz": 9001, \n    "foo": "bar"\n}'



# Generated at 2022-06-11 09:10:48.842483
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None, False) == "{}"
    assert jsonify(None, True) == "{}"
    assert jsonify([1, 2, 3], False) == "[1, 2, 3]"
    assert jsonify([1, 2, 3], True) == "[\n    1, \n    2, \n    3\n]"
    assert jsonify({"key": "value"}, False) == '{"key": "value"}'
    assert jsonify({"key": "value"}, True) == '{\n    "key": "value"\n}'
    assert jsonify({"key": "value".encode('utf-8')}, False) == '{"key": "value"}'

# Generated at 2022-06-11 09:10:52.308488
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'hello': 'world'}) == '{"hello": "world"}'
    assert jsonify(None) == '{}'
    assert jsonify({'hello': 'world'}, True) == '{\n    "hello": "world"\n}'
    assert jsonify([1,2,3]) == '[1, 2, 3]'

# Generated at 2022-06-11 09:10:54.923633
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'


# Generated at 2022-06-11 09:10:57.663347
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify({ "test": "value" }) == '{"test": "value"}'

# Generated at 2022-06-11 09:11:12.398218
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == "{}"

    # just make sure this works
    result = {'a': 'b'}
    jsonified = jsonify(result)
    assert jsonified == '{"a": "b"}'

    # and make sure string handling is done properly
    result = {'a': 'a\nb'}
    jsonified = jsonify(result)
    assert jsonified == '{"a": "a\\nb"}'

# Generated at 2022-06-11 09:11:19.880225
# Unit test for function jsonify
def test_jsonify():
    '''
    Testing jsonify function
    '''

    from ansible.utils import jsonify

    assert jsonify({'a': 'QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}) == '{"a": "QWxhZGRpbjpvcGVuIHNlc2FtZQ=="}'
    assert jsonify({'a': 'QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}, True) == '{   \n    "a": "QWxhZGRpbjpvcGVuIHNlc2FtZQ=="\n}'

# Generated at 2022-06-11 09:11:29.949618
# Unit test for function jsonify
def test_jsonify():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestJsonify(unittest.TestCase):
        @patch('ansible.utils.jsonify.json.dumps')
        def test_format_true(self, mock_dumps):
            jsonify(None, True)
            mock_dumps.assert_called_once_with(None, sort_keys=True, indent=4, ensure_ascii=False)

        @patch('ansible.utils.jsonify.json.dumps')
        def test_format_false(self, mock_dumps):
            jsonify(None)
            mock_dumps.assert_called_once_with(None, sort_keys=True, indent=None, ensure_ascii=False)

   

# Generated at 2022-06-11 09:11:34.085115
# Unit test for function jsonify
def test_jsonify():

    expected = "{}"
    assert jsonify(None) == "{}"

    data = {'a': 'hello world'}
    assert jsonify(data) == '{"a":"hello world"}'

    assert jsonify(data, format=True) == '{\n    "a": "hello world"\n}'

# Generated at 2022-06-11 09:11:42.536193
# Unit test for function jsonify
def test_jsonify():
    result = {
        'foo': 'bar',
        'blip': [ 1, 2, 3 ],
        'flooble': {
            'nooble': 'floom',
        }
    }

    # Test default format=False
    assert jsonify(result) == '{"blip": [1, 2, 3], "flooble": {"nooble": "floom"}, "foo": "bar"}'

    # Test format=True
    assert jsonify(result, True) == '''{
    "blip": [
        1,
        2,
        3
    ],
    "flooble": {
        "nooble": "floom"
    },
    "foo": "bar"
}'''

    # Test strange character in string
    result = { 'str': '\xe3' }


# Generated at 2022-06-11 09:11:46.831309
# Unit test for function jsonify
def test_jsonify():
    import sys
    # Ansible's tests are run using Python 2.6 which does not have json.dumps with ensure_ascii argument.
    if sys.version_info > (2, 6):
        assert jsonify({"foo": "bar"}, True) == '{\n    "foo": "bar"\n}'
    else:
        assert jsonify({"foo": "bar"}, True) == '{"foo": "bar"}'

# Generated at 2022-06-11 09:11:54.152832
# Unit test for function jsonify
def test_jsonify():
    result = {
        '1': [ u'foo', u'bar' ],
        '2': {
            '2a': "foo",
            '2b': u"bar",
            '2c': { 'unicode': u'\xc4\x85', 'ascii': '\xc4\x85' }
        },
        '3': { '3a': "foo", '3b': u"bar" }
    }
    assert jsonify(result) == '{"1": ["foo", "bar"], "2": {"2a": "foo", "2b": "bar", "2c": {"unicode": "\xc4\x85", "ascii": "\xc4\x85"}}, "3": {"3a": "foo", "3b": "bar"}}'
    assert jsonify(result, True)

# Generated at 2022-06-11 09:11:57.061917
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1, 'b': 2}) == "{\"a\":1,\"b\":2}"

# Generated at 2022-06-11 09:12:08.809101
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify output '''

    a = dict(a=dict(b='c', d='efg'))
    result = jsonify(a, format=False)
    assert result == '{"a": {"b": "c", "d": "efg"}}'

    result = jsonify(a, format=True)
    assert result == '''{
    "a": {
        "b": "c",
        "d": "efg"
    }
}'''

    b = dict(a=dict(b='c', d=dict(e=['f', 'g'], h='i')))
    result = jsonify(b, format=False)
    assert result == '{"a": {"b": "c", "d": {"e": ["f", "g"], "h": "i"}}}'

   

# Generated at 2022-06-11 09:12:10.495257
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-11 09:12:33.421893
# Unit test for function jsonify
def test_jsonify():

    result = { 'foo' : 'bar' }
    format = True
    returned = jsonify(result, format)
    assert type(returned) is str
    assert returned == "{\"foo\": \"bar\"}"

    result = None
    format = False
    returned = jsonify(result, format)
    assert type(returned) is str
    assert returned == "{}"

# Generated at 2022-06-11 09:12:41.891690
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should return JSON data structures as JSON. '''
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestJsonify(unittest.TestCase):

        def test_jsonify_fails_if_json_module_fails(self):
            ''' Test for exception raising if json.dumps() raises an exception. '''
            with patch('json.dumps', side_effect=TypeError):
                self.assertRaises(Exception, jsonify, dict(a=1))

    return unittest.main()

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:12:52.539704
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({}) == '{}'
    assert jsonify({'foo': 42}) == '{"foo": 42}'
    assert jsonify([]) == '[]'
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    assert jsonify([1, [2, 3]]) == '[1, [2, 3]]'
    assert jsonify({'bar': [1, 2, 3]}) == '{"bar": [1, 2, 3]}'
    assert jsonify({'bar': [1, [2, 3]]}) == '{"bar": [1, [2, 3]]}'
    assert jsonify({'foo': 42}, True) == '{\n    "foo": 42\n}'

# Generated at 2022-06-11 09:12:58.170458
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify function '''
    _test = {'a':1,'b':2,'c':[1,2,3]}
    _ans  = jsonify(_test)
    assert _ans == '{}'
    _ans  = jsonify(_test, True)
    assert _ans == '{}'
    _ans  = jsonify(_test, False)
    assert _ans == '{}'
    _test = {'a':1,'b':2,'c':[1,2,3]}
    _ans  = jsonify(_test)
    assert _ans == '{"a": 1, "c": [1, 2, 3], "b": 2}'
    _ans  = jsonify(_test, True)

# Generated at 2022-06-11 09:13:03.865327
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(None) == '{}'



# Generated at 2022-06-11 09:13:10.080800
# Unit test for function jsonify
def test_jsonify():
    # When no result is provided, we will get empty JSON
    assert "{}" == jsonify(None)

    # Test formatting of the JSON
    result = {
        "user": "johndoe",
        "value": "test"
    }
    assert '{\n    "user": "johndoe", \n    "value": "test"\n}' == jsonify(result, True)

    # Data can be serialized
    assert '{"value": "test", "user": "johndoe"}' == jsonify(result)

# Generated at 2022-06-11 09:13:20.298598
# Unit test for function jsonify
def test_jsonify():
    '''Test jsonify'''
    assert jsonify(None) == '{}'
    assert jsonify(None,  format=True) == '{}'
    assert jsonify({}) == '{}'
    assert jsonify({}, format=True) == '{}'
    assert jsonify(dict(foo='bar')) == '{"foo": "bar"}'
    assert jsonify(dict(foo='bar'), format=True) == '{\n    "foo": "bar"\n}'
    assert jsonify(dict(foo='\xe9')) == '{"foo": "\xe9"}'
    assert jsonify(dict(foo='\xe9'), format=True) == '{\n    "foo": "\xe9"\n}'

# Generated at 2022-06-11 09:13:26.059143
# Unit test for function jsonify
def test_jsonify():
    # Check empty json returned
    assert jsonify(None) == "{}"

    # Check indenting of json
    result1 = { u"a": u"b" }
    assert jsonify(result1, True) == """{
    "a": "b"
}"""

    # Check non-indenting of json
    result1 = { u"a": u"b" }
    assert jsonify(result1) == """{"a": "b"}"""

# Generated at 2022-06-11 09:13:28.574613
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(dict(a=42, b=43))
    assert result == '{"a": 42, "b": 43}', "jsonify failed: got %s" % result

# Generated at 2022-06-11 09:13:35.028240
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('foo') == '"foo"'
    assert jsonify(42) == '42'
    assert jsonify(42.1) == '42.1'
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    assert jsonify(None) == 'null'
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    assert jsonify({'foo': 'bar', 'baz': 'qux'}) == '{"baz": "qux", "foo": "bar"}'

# Generated at 2022-06-11 09:14:19.587597
# Unit test for function jsonify
def test_jsonify():
    ''' return a json object based on the text provided '''
    assert jsonify(['foo', 'bar', 42]) == '[\n    "foo",\n    "bar",\n    42\n]'
    assert jsonify(dict(a=1, b=2, c=3)) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-11 09:14:23.468917
# Unit test for function jsonify
def test_jsonify():
    result  = { "this": { "is": { "a": "test" } } }
    assert jsonify(result)  == '{"this": {"is": {"a": "test"}}}'
    assert jsonify(result, True) == '''{
    "this": {
        "is": {
            "a": "test"
        }
    }
}'''

# Generated at 2022-06-11 09:14:26.044982
# Unit test for function jsonify
def test_jsonify():
    args = json.loads("{}")
    assert jsonify(args) == '{}'
    args = json.loads("{\"a\": 1}")
    assert jsonify(args) == '{"a": 1}'
