

# Generated at 2022-06-11 09:04:42.004693
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import basic
    from ansible.compat import unittest

    class TestModule(object):
        def __init__(self, result):
            self.result = result

    module = TestModule({'test': 'aaa', 'bbb': {'ccc': 'ddd', 'eee': ['fff', 'ggg']}})

    def check_jsonify(result, expected):
        basic._ANSIBLE_ARGS = None
        basic.ANSIBLE_MODULE_ARGS = {'format': False}
        res = jsonify(result)
        assert res == expected

        basic._ANSIBLE_ARGS = None
        basic.ANSIBLE_MODULE_ARGS = {'format': True}
        res = jsonify(result)

# Generated at 2022-06-11 09:04:47.384434
# Unit test for function jsonify
def test_jsonify():
    for test in [(None, "{}"),
                 ({}, "{}"),
                 ({1: 2}, '{"1": 2}'),
                 ([{'a': 1}], '[\n    {\n        "a": 1\n    }\n]')]:
        assert test[1] == jsonify(test[0], format=True)
    # TODO: Add tests for the unicode case
    pass

# Generated at 2022-06-11 09:04:58.960212
# Unit test for function jsonify
def test_jsonify():
    '''
    jsonify unit test
    '''

    test_dict = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    test_dict_str = jsonify(test_dict)
    test_dict_str_format = jsonify(test_dict, True)
    assert test_dict_str == '{"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}'
    assert test_dict_str_format == '{\n    "a": 1, \n    "b": 2, \n    "c": 3, \n    "d": 4, \n    "e": 5\n}'

# Generated at 2022-06-11 09:05:03.641134
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo": 1}) == '{"foo": 1}'
    assert jsonify({"foo": 1}, format=True) == '{\n    "foo": 1\n}'
    assert jsonify(None) == "{}"


# Generated at 2022-06-11 09:05:11.243869
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({1:2}) == '{"1": 2}'
    assert jsonify([1,2]) == '[1, 2]'
    assert jsonify(dict(foo="fooval", bar="barval"), format=True) == '{\n    "bar": "barval", \n    "foo": "fooval"\n}'
    json_string = '{"foo": "fooval", "bar": "barval", "spam": "spamval", "baz": "quxval"}'
    assert jsonify(json.loads(json_string), format=True) == json_string

# Generated at 2022-06-11 09:05:15.368981
# Unit test for function jsonify
def test_jsonify():
    from ansible import utils
    from ansible.runner import Runner

    results = Runner(
        pattern='all', forks=10,
        module_name='setup', module_args='',
    ).run()

    json_out = utils.jsonify(results)
    assert(json_out is not None)

# Generated at 2022-06-11 09:05:22.342703
# Unit test for function jsonify
def test_jsonify():
    result={"a": "hello"}
    actual=jsonify(result, format=False)
    expected='{"a": "hello"}'
    assert actual == expected

    result={"a": "hello"}
    actual=jsonify(result, format=True)
    expected='''{
    "a": "hello"
}'''
    assert actual == expected

    result=None
    actual=jsonify(result)
    expected='{}'
    assert actual == expected

# Generated at 2022-06-11 09:05:31.496693
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({"a": 1, "b": 2})
    assert result == "{\"a\": 1, \"b\": 2}"
    result = jsonify({"a": 1, "b": [1, 2, 3]})
    assert result == "{\"a\": 1, \"b\": [1, 2, 3]}"
    result = jsonify({"a": 1, "b": [1, 2, 3]}, True)
    assert result == """{
    "a": 1,
    "b": [
        1,
        2,
        3
    ]
}"""
    result = jsonify(None)
    assert result == "{}"

# Generated at 2022-06-11 09:05:40.529388
# Unit test for function jsonify
def test_jsonify():
    from ansible.constants import templar

    module_results = {
        'ping': 'pong',
        'one': 1,
        'foo': True,
        'list': [ 1, 2, 3 ],
        'list2': [ 'a', 'b', 'c' ],
        'dict': { 'a': 1, 'b': 2 }
    }
    jsonified = jsonify(module_results, format=True)

# Generated at 2022-06-11 09:05:43.453738
# Unit test for function jsonify
def test_jsonify():
    assert '{}' == jsonify(None)
    assert '{"a": 1}' == jsonify({'a': 1})

# Generated at 2022-06-11 09:05:48.534448
# Unit test for function jsonify
def test_jsonify():
    result = { 'this': 'that' }
    assert jsonify(result) == '{"this": "that"}'



# Generated at 2022-06-11 09:05:56.268731
# Unit test for function jsonify
def test_jsonify():
    from ansible.compat.tests import unittest

    class TestJsonify(unittest.TestCase):

        def test_jsonify(self):
            result = dict(foo='bar', baz=dict(spam='eggs'))
            self.assertEqual(jsonify(result), '{"baz": {"spam": "eggs"}, "foo": "bar"}')
            self.assertEqual(jsonify(result, format=True),
'''{
    "baz": {
        "spam": "eggs"
    },
    "foo": "bar"
}
''')

# Generated at 2022-06-11 09:06:02.108901
# Unit test for function jsonify
def test_jsonify():
    ''' This is a simple test for the jsonify function '''

    from ansible.utils import jsonify

    assert jsonify({'a': 'some string', 'b': ['a', 'b', 'c']}, True) == '''{
    "a": "some string",
    "b": [
        "a",
        "b",
        "c"
    ]
}
'''

    assert jsonify({'a': 'some string', 'b': ['a', 'b', 'c']}, False) == '{"a": "some string", "b": ["a", "b", "c"]}'

# Generated at 2022-06-11 09:06:10.508407
# Unit test for function jsonify
def test_jsonify():
    # Test that empty result is returned as empty json object
    assert jsonify(None) == '{}'

    # Test that result is properly formatted if format is true
    assert jsonify({'a':'b'}, True) == '{\n    "a": "b"\n}'

    # Test that result is properly formatted if format is false
    assert jsonify({'a':'b'}, False) == '{"a": "b"}'

# Generated at 2022-06-11 09:06:20.382779
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == '{}'

    data = { u'foo': u"m\u00f6p",
             u"bar": [ u"b\u00e4z", u"qu\u00f6x" ],
             u"baz": { u"a":1, u"b":2, u"c":3 } }
    expect = '''{
    "bar": [
        "b\\u00e4z",
        "qu\\u00f6x"
    ],
    "baz": {
        "a": 1,
        "b": 2,
        "c": 3
    },
    "foo": "m\\u00f6p"
}'''

    assert jsonify(data, True) == expect

# Generated at 2022-06-11 09:06:32.084711
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify
    import ast
    import sys

    # Test case 1: Test with None input
    data = None
    result = jsonify(data)
    expected_result = "{}"
    assert result == expected_result, "Expected result is %s and got %s" % (expected_result, result)

    # Test case 2: Test with empty dictionary input
    data = {}
    result = jsonify(data)
    expected_result = '{}'
    assert result == expected_result, "Expected result is %s and got %s" % (expected_result, result)

    # Test case 3: Test with non-empty dictionary input
    data = {"a": "b"}
    result = jsonify(data)
    expected_result = '{"a": "b"}'

# Generated at 2022-06-11 09:06:37.280303
# Unit test for function jsonify
def test_jsonify():

    # Test no input
    assert jsonify(None) == "{}"

    # Test specified indented output
    assert jsonify({'a': 'b'}, format=True) == '{\n    "a": "b"\n}'

    # Test JSON.dumps error handling - Can't handle ascii unicode in python2
    assert jsonify('\xe1') == '"\xc3\xa1"'

# Generated at 2022-06-11 09:06:42.100136
# Unit test for function jsonify
def test_jsonify():
    result = {"a": 1, "b": 2}
    json_result = jsonify(result)
    assert json_result == "{\"a\": 1, \"b\": 2}"

    json_result = jsonify(result, True)
    assert json_result == "{\n    \"a\": 1, \n    \"b\": 2\n}"

# Generated at 2022-06-11 09:06:44.247916
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify '''
    assert jsonify(dict(a='b')) == '{"a": "b"}'

# Generated at 2022-06-11 09:06:51.622459
# Unit test for function jsonify
def test_jsonify():
    test_input  = None
    test_input2 = dict(spam="eggs")
    test_input3 = dict(spam="b\xe5con")
    test_input4 = dict(spam="b\u00e5con")
    test_input5 = dict(spam=None)

    assert(jsonify(test_input)  == '{}')
    assert(jsonify(test_input2) == '{"spam": "eggs"}')


# Generated at 2022-06-11 09:07:06.171517
# Unit test for function jsonify
def test_jsonify():

    assert jsonify({"a": None}, format=True) == ("{\n"
        "    \"a\": null\n"
        "}")

    assert jsonify(["a", "b", "c"], format=True) == ("[\n"
        "    \"a\",\n"
        "    \"b\",\n"
        "    \"c\"\n"
        "]")

    assert jsonify({"a": [1,2,3]}, format=True) == ("{\n"
        "    \"a\": [\n"
        "        1,\n"
        "        2,\n"
        "        3\n"
        "    ]\n"
        "}")


# Generated at 2022-06-11 09:07:15.909293
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import AnsibleModule
    assert jsonify({'a': 1, 'c': 3, 'b': 2}, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'
    assert jsonify({'a': 1, 'c': 3, 'b': 2}, False) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(AnsibleModule(dict()).exit_json(changed=False, meta=None)) == '{"changed": false}'
    assert jsonify(None) == "{}"
    assert jsonify(1) == "1"
    assert jsonify(u'test') == '"test"'

# Generated at 2022-06-11 09:07:26.624560
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.compat.tests import unittest

    # assert that AnsibleUnsafeText instances are not json encoded
    fixture = dict(
        {
            AnsibleUnsafeText("test"): AnsibleUnsafeText("test"),
            "test2": "test2",
        }
    )
    result = jsonify(fixture)
    assert result == '{"test2": "test2", "test": "test"}'

    assert jsonify(None) == '{}'
    assert jsonify({}) == '{}'
    assert jsonify(dict(foo="one", bar="two")) == '{"bar": "two", "foo": "one"}'

    # Test format

# Generated at 2022-06-11 09:07:28.171262
# Unit test for function jsonify
def test_jsonify():
    result = dict(changed=False, invalid_invocation=True)
    assert jsonify(result) == '{"changed": false, "invalid_invocation": true}'

# Generated at 2022-06-11 09:07:39.639853
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify '''
    result = {
        'complex': {
            'a': ['spam', 1, ('ham', 'eggs')],
            'b': {'mike' : 'mdehaan'},
            'c': True
        },
        'null': None
    }
    assert jsonify(result) == '{"complex": {"a": ["spam", 1, ["ham", "eggs"]], "c": true, "b": {"mike": "mdehaan"}}, "null": null}'

# Generated at 2022-06-11 09:07:50.279728
# Unit test for function jsonify
def test_jsonify():

    # If format is False
    assert jsonify(None) == '{}'
    assert jsonify([1,2,3]) == '[1, 2, 3]'
    assert jsonify({'a':1, 'b':2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a':1, 'b':{'c':[1,2,3], 'd':4}}) == '{"a": 1, "b": {"c": [1, 2, 3], "d": 4}}'

    # If format is True
    assert jsonify(None, True) == '{}'
    assert jsonify([1,2,3], True) == '''[
    1,
    2,
    3
]'''

# Generated at 2022-06-11 09:07:53.156955
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 2}) == '{"a": 2}'
    assert jsonify({"a": 2}, True) == '{\n    "a": 2\n}'
    assert jsonify(None) == '{}'

# Generated at 2022-06-11 09:07:59.318694
# Unit test for function jsonify
def test_jsonify():
    # Test to make sure jsonify() returns valid json
    assert json.loads(jsonify({'foo':'bar'})) == {'foo':'bar'}

    # Test to make sure jsonify() returns valid json with formatting
    assert json.loads(jsonify({'foo':'bar'}, format=True)) == {'foo':'bar'}

    # Test to make sure jsonify() can handle None
    assert jsonify(None) == "{}"


# Generated at 2022-06-11 09:08:06.457335
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a":"a", "b":"b"}) == '{"a": "a", "b": "b"}'
    assert jsonify({"a":"\u2028", "b":"\u2029"}) == '{"a": "\u2028", "b": "\u2029"}'
    assert jsonify({"a":"\u2028a", "b":"\u2029b"}) == '{"a": "\u2028a", "b": "\u2029b"}'



# Generated at 2022-06-11 09:08:16.353463
# Unit test for function jsonify
def test_jsonify():
    test_object = {
        'a': 'b',
        'c': ['d', 'e'],
        'f': {
            'g': 'h',
            'i': 'j',
        }
    }

    # Unformatted
    res1 = jsonify(test_object)
    assert res1 == '{"a": "b", "c": ["d", "e"], "f": {"g": "h", "i": "j"}}'

    # Formatted
    res2 = jsonify(test_object, format=True)
    expected2 = '''{
    "a": "b",
    "c": [
        "d",
        "e"
    ],
    "f": {
        "g": "h",
        "i": "j"
    }
}'''

# Generated at 2022-06-11 09:08:32.595284
# Unit test for function jsonify
def test_jsonify():
    test_output = {
        "changed": False,
        "ping": "pong",
    }

    assert(jsonify(test_output) == '{"changed": false, "ping": "pong"}')
    assert(jsonify(test_output, True) == '{\n    "changed": false, \n    "ping": "pong"\n}')

# Generated at 2022-06-11 09:08:35.687339
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'
    assert jsonify({'a':1}) == '{"a": 1}'
    assert jsonify({'a':1}, True) == '{\n    "a": 1\n}'
    assert jsonify('foo') == '"foo"'
    assert jsonify(['foo', 'bar']) == '["foo", "bar"]'

# Generated at 2022-06-11 09:08:46.246367
# Unit test for function jsonify
def test_jsonify():
    test = dict(changed=False, rc=0)
    output = jsonify(test)
    assert output == '{"changed": false, "rc": 0}'

    test2 = dict(changed=True, rc=0)
    output2 = jsonify(test2)
    assert output2 == '{"changed": true, "rc": 0}'

    test3 = dict(unreachable=True, rc=0)
    output3 = jsonify(test3)
    assert output3 == '{"rc": 0, "unreachable": true}'

    test4 = dict(failed=True, rc=0)
    output4 = jsonify(test4)
    assert output4 == '{"failed": true, "rc": 0}'

# Generated at 2022-06-11 09:08:57.525188
# Unit test for function jsonify
def test_jsonify():
    import os

    test_json = json.dumps({'test':{'test':{'test':test_json}}})
    test_str = str(test_json)

    # Not (de)formatting json
    result = jsonify(test_json)
    assert result == test_str

    # Formatting json
    result = jsonify(test_json, format=True)

# Generated at 2022-06-11 09:09:03.807164
# Unit test for function jsonify
def test_jsonify():

    # Test for None ref
    assert jsonify(None) == "{}"

    # Test for no formatting
    assert jsonify({'a':1}) == '{"a": 1}'

    # Test for formatting
    assert jsonify({'a':1}, True) == '{\n    "a": 1\n}\n'

    # Test for unicode
    assert jsonify({u'a':1}) == '{"a": 1}'

    # Test for ascii
    assert jsonify({'a':1}) != '{"a": 1}'

# Generated at 2022-06-11 09:09:10.818469
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils import jsonify
    res = jsonify({"a": [1,2,3]})
    assert res == '{\n    "a": [\n        1, \n        2, \n        3\n    ]\n}'
    res = jsonify({"a": [1,2,3]}, format=True)
    assert res == '{\n    "a": [\n        1, \n        2, \n        3\n    ]\n}'

# Generated at 2022-06-11 09:09:22.169498
# Unit test for function jsonify
def test_jsonify():
    class Py2Test:
        pass

    class Py3Test:
        def __bool__(self):
            return True

# Generated at 2022-06-11 09:09:23.991319
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'


# Generated at 2022-06-11 09:09:30.415805
# Unit test for function jsonify
def test_jsonify():
    # Test empty result
    assert '{}' == jsonify(None)
    # Test dict response
    assert '{}' == jsonify({})
    assert '{"a": 1}' == jsonify({"a": 1})
    # Test list response
    assert '[]' == jsonify([])
    assert '[1, 2, 3]' == jsonify([1, 2, 3])
    # Test format
    assert '{\n    "a": 1\n}' == jsonify({"a": 1}, True)

# Generated at 2022-06-11 09:09:40.741974
# Unit test for function jsonify
def test_jsonify():

    # Deal with unicode.
    unicode_src = {"fail": "\u1f4a9"}
    assert jsonify(unicode_src) == '{"fail": "\\u1f4a9"}'

    # Deal with empty results.
    assert jsonify({}) == "{}"
    assert jsonify(None) == "{}"

    # Deal with pretty formatting.
    jdata = {"hello": "world", "michael": "dehaan", "nested": {"a": 5}}
    assert jsonify(jdata, format=True) == '''{
    "hello": "world",
    "michael": "dehaan",
    "nested": {
        "a": 5
    }
}
'''
    # Deal with non-string keys.
    jdata = {0: "world"}
    assert json

# Generated at 2022-06-11 09:09:53.916769
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'some':{'result':'to jsonify'}}) == '{"some": {"result": "to jsonify"}}'
    assert jsonify(None) == "{}"
    assert jsonify(None, True) == "{}"

# Generated at 2022-06-11 09:09:58.436597
# Unit test for function jsonify
def test_jsonify():
    d = {'a':'b'}
    assert jsonify(d) == '{"a":"b"}'
    assert jsonify(d,True) == '{\n    "a": "b"\n}'
    assert jsonify(None) == '{}'


# Generated at 2022-06-11 09:10:06.313134
# Unit test for function jsonify
def test_jsonify():
    import datetime
    from six import string_types

    ansible_vars = dict(
        ansible_default_ipv4=dict(address='127.0.0.1'),
        ansible_facts=dict(distribution='debian', kernel='linux')
    )
    date = datetime.datetime.utcnow()

# Generated at 2022-06-11 09:10:14.858271
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None, True) == "{}"
    assert jsonify(["a", "b", "c"], True) == '''[
    "a",
    "b",
    "c"
]'''
    assert jsonify(["a", "b", "c"], False) == '["a","b","c"]'
    assert jsonify({"a": 1, "b": 2}, True) == '''{
    "a": 1,
    "b": 2
}'''
    assert jsonify({"a": 1, "b": 2}, False) == '{"a":1,"b":2}'

# Generated at 2022-06-11 09:10:22.115479
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify('a') == '"a"'
    assert jsonify(1) == '1'
    assert jsonify(None) == '{}'
    try:
        jsonify({"a": 1, "b": chr(1000)})
        assert False
    except UnicodeDecodeError:
        assert True


# https://stackoverflow.com/a/23357273/566351

# Generated at 2022-06-11 09:10:30.695845
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should format JSON output (uncompressed or uncompressed) '''

    # Empty input
    result = jsonify(None)
    assert "{}" == result or b"{}" == result

    # Not a dictionary
    result = jsonify('This is a string')
    assert '"This is a string"' == result or b'"This is a string"' == result

    # Format to True
    result = jsonify({'This': 'is', 'a': 'dictionary'}, True)

# Generated at 2022-06-11 09:10:37.805754
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify

    # simple string
    assert jsonify("sample") == '"sample"'
    # list of integers
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    # dict with multiple values
    assert jsonify({'a': 1, 'b': 'c'}) == '{"a": 1, "b": "c"}'

# Generated at 2022-06-11 09:10:44.536029
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify([1, 2, {"a": 3}]) == '[\n    1, \n    2, \n    {\n        "a": 3\n    }\n]'
    assert jsonify(u'\u1234') == u'"\u1234"'

# Generated at 2022-06-11 09:10:47.916121
# Unit test for function jsonify
def test_jsonify():
    d = dict(a='foo', b='bar', c=dict(d='foobar'))
    assert jsonify(d) == '{"a": "foo", "c": {"d": "foobar"}, "b": "bar"}'

# Generated at 2022-06-11 09:10:53.311564
# Unit test for function jsonify
def test_jsonify():
    assert '{}' == jsonify(None)

    test_input = {'some': 'dict'}
    assert '{"some": "dict"}' == jsonify(test_input)

    test_input = {'some': 'dict', 'foo': ['bar', 'baz']}
    assert '{\n    "foo": [\n        "bar", \n        "baz"\n    ], \n    "some": "dict"\n}' == jsonify(test_input, format=True)

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:11:18.573590
# Unit test for function jsonify
def test_jsonify():
    result = dict(
        one=1,
        two=2,
        three=3,
        list=[
            dict(name='one', value=1),
            dict(name='two', value=2),
            dict(name='three', value=3),
        ],
        dict=dict(
            one=1,
            two=2,
            three=3,
        )
    )

    assert '"one": 1' in jsonify(result, False)
    assert '"examples": {' in jsonify(result, True)

# Generated at 2022-06-11 09:11:28.053004
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify(dict(changed=False)) == '{"changed": false}'
    assert jsonify(dict(changed=True)) == '{"changed": true}'
    assert jsonify(dict(changed=True, rc=0)) == '{"changed": true, "rc": 0}'
    assert jsonify(dict(changed=True, results=[1, 2, 3])) == '{"changed": true, "results": [1, 2, 3]}'
    assert jsonify(dict(changed=True, results=[1, 2, 3]), format=True) == '''{
    "changed": true,
    "results": [
        1,
        2,
        3
    ]
}'''

# Generated at 2022-06-11 09:11:38.150401
# Unit test for function jsonify
def test_jsonify():
    '''
    jsonify: Test jsonify function
    '''
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestJsonify(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        @patch.object(json, 'dumps')
        def test_jsonify_normal_case(self, mock_dumps):
            mock_dumps.return_value = 'foo bar'
            result = jsonify('baz')
            mock_dumps.assert_called_with('baz', sort_keys=True, ensure_ascii=False, indent=None)
            self.assertEqual(result, 'foo bar')


# Generated at 2022-06-11 09:11:41.959305
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo='foo', bar='bar', bam='bam')) == '{"foo": "foo", "bar": "bar", "bam": "bam"}'


# Generated at 2022-06-11 09:11:44.032670
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(failed=False, changed=False, msg="Some message")) == '{"changed": false, "failed": false, "msg": "Some message"}'

# Generated at 2022-06-11 09:11:46.581234
# Unit test for function jsonify
def test_jsonify():
    data = {}
    assert jsonify(data) == "{}"
    result = [dict(omg=1, lol=2)]
    assert jsonify(result) == '[\n  {\n    "lol": 2, \n    "omg": 1\n  }\n]'

# Generated at 2022-06-11 09:11:48.314988
# Unit test for function jsonify
def test_jsonify():
    assert '{' in jsonify(None)
    assert '"foo"' in jsonify({'foo': 'bar'}, format=True)

# Generated at 2022-06-11 09:11:58.895396
# Unit test for function jsonify
def test_jsonify():
    test_input = {
        "test1": "test1",
        "test2": 1,
        "test3": [1, 2, 3],
        "test4": [
            "test5",
            "test6"
        ],
        "test7": {
            "test8": "test8"
        },
        "test9": {
            "test10": {
                "test11": "test11"
            }
        }
    }
    expected_output_compressed = '{"test1": "test1", "test2": 1, "test3": [1, 2, 3], "test4": ["test5", "test6"], "test7": {"test8": "test8"}, "test9": {"test10": {"test11": "test11"}}}'
    expected_output_pretty = ''


# Generated at 2022-06-11 09:12:04.120609
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({"a": 1, "b": 2}) == json.dumps({"a": 1, "b": 2})
    assert jsonify({"a": 1, "b": 2}, format=True) == json.dumps({"a": 1, "b": 2}, indent=4)

# Generated at 2022-06-11 09:12:09.808388
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(dict(changed=False, rc=0), True) == '''{
    "changed": false,
    "rc": 0
}'''

    assert jsonify(dict(changed=True, results=[dict(item='value')]), True) == '''{
    "changed": true,
    "results": [
        {
            "item": "value"
        }
    ]
}'''

# Generated at 2022-06-11 09:12:52.576781
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(None, format=True) == '{}'

    # Ensure that the stringified result is proper JSON
    assert json.loads(jsonify({'hello': 'world'})) == {u'hello': u'world'}
    assert json.loads(jsonify({'hello': 'world'}, format=True)) == {u'hello': u'world'}

# Generated at 2022-06-11 09:12:56.912242
# Unit test for function jsonify
def test_jsonify():
    ''' test format of jsonify output '''

    # basic test
    assert jsonify({"a": 1}) == '{"a": 1}'

    # unicode handling test
    assert jsonify({"a": u'\u2603'}) == '{"a": "\\u2603"}'

    # format test
    assert jsonify({"a": [1,2,3]}, format=True) == '{\n    "a": [\n        1, \n        2, \n        3\n    ]\n}'

# Generated at 2022-06-11 09:13:05.686408
# Unit test for function jsonify
def test_jsonify():
    result = dict(changed=True, rc=0, stdout="the output", start=0.12345678, delta=0.98765432, end=1.11111111)
    formatted = ("{\n"
                 "    \"changed\": true, \n"
                 "    \"delta\": 0.98765432, \n"
                 "    \"end\": 1.11111111, \n"
                 "    \"rc\": 0, \n"
                 "    \"start\": 0.12345678, \n"
                 "    \"stdout\": \"the output\"\n"
                 "}")
    assert jsonify(result) == formatted

# Generated at 2022-06-11 09:13:14.640082
# Unit test for function jsonify
def test_jsonify():
    test_result = None
    assert jsonify(test_result) == '{}'
    test_result = {'a':1}
    assert jsonify(test_result) == '{"a": 1}'
    test_result = {u'a':1}
    assert jsonify(test_result) == '{"a": 1}'
    test_result = {u'a':1, 'b':u'\xee'}
    assert jsonify(test_result, True) == '{\n    "a": 1, \n    "b": "?' + u'\\xee' + '"\n}'

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:13:16.829297
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}) == "{\"foo\": \"bar\"}"

# ----


# Generated at 2022-06-11 09:13:26.988895
# Unit test for function jsonify
def test_jsonify():
    import difflib
    a = {'a':1,'b':2,'c':'x'}
    a = jsonify(a, True)
    b = '''{
    "a": 1,
    "b": 2,
    "c": "x"
}'''
    assert a == b
    a = {'a':1,'b':2,'c':'x'}
    a = jsonify(a)
    b = '{"a": 1, "b": 2, "c": "x"}'
    # https://docs.python.org/2/library/difflib.html
    diff = difflib.ndiff(a, b)
    assert ''.join(diff) == '  {"a": 1, "b": 2, "c": "x"}'
    assert jsonify(None) == "{}"

# Generated at 2022-06-11 09:13:35.325346
# Unit test for function jsonify
def test_jsonify():
    result = {
        'msg': {
            'some_dict': {
                'some_string': 'a string',
                'some_list': ['a list'],
                'some_bool': False
            },
            'some_empty_dict': {},
        },
        'changed': False
    }
    result = jsonify(result, True)
    assert result == '''{
    "changed": false,
    "msg": {
        "some_dict": {
            "some_bool": false,
            "some_list": [
                "a list"
            ],
            "some_string": "a string"
        },
        "some_empty_dict": {}
    }
}'''

# Generated at 2022-06-11 09:13:41.173057
# Unit test for function jsonify
def test_jsonify():

    result = {"one": 1, "two": 2, "foo": u"bar"}

    assert jsonify(result, True) == "{\"foo\": \"bar\", \"one\": 1, \"two\": 2}"
    assert jsonify(result, False) == '{"foo": "bar", "one": 1, "two": 2}'

# Generated at 2022-06-11 09:13:51.109555
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import basic
    import sys

    if sys.version_info < (2, 7):
        module = basic.AnsibleModule(argument_spec={})
        module_result = dict(cmd=["/bin/true"], rc=0, stdout="ansible", stderr="")
        assert jsonify(module_result) == '{"cmd": ["/bin/true"], "rc": 0, "stderr": "", "stdout": "ansible"}'
        assert jsonify(module_result, True) == '''{
    "cmd": [
        "/bin/true"
    ],
    "rc": 0,
    "stderr": "",
    "stdout": "ansible"
}'''

# Generated at 2022-06-11 09:13:57.371721
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == "{}"

    # worst case scenario for non-ascii handling: a chinese character
    # this test will fail if python is running in ascii mode.
    myunicode = u'\u5317\u4EB0'
    mydict = { 'myunicode': myunicode }
    assert jsonify(mydict, format=False) == r'{"myunicode": "\u5317\u4eb0"}'

    # double check that the return is always a string
    assert isinstance(jsonify({'foo': 'bar'}), basestring)