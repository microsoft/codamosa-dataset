

# Generated at 2022-06-11 09:04:41.201098
# Unit test for function jsonify
def test_jsonify():
    ''' test the jsonify() function '''

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from datetime import datetime

    def json_date_handler(obj):
        ''' serialize datetime objects as ISO 8601 '''
        if isinstance(obj, datetime):
            return obj.strftime("%Y-%m-%dT%H:%M:%S%z")
        raise TypeError('Unserializable object {} of type {}'.format(obj, type(obj)))

    # Test basic data types
    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'

    # Test None value
    assert jsonify(None) == '{}'

    # Test complex data type (dictionary of lists and dictionaries)

# Generated at 2022-06-11 09:04:43.308045
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'


# Generated at 2022-06-11 09:04:46.114278
# Unit test for function jsonify
def test_jsonify():
    # I don't see an easy way around this "unreachable code" warning.
    from nose.plugins.skip import SkipTest
    raise SkipTest("FIXME: jsonify doesn't have unit tests yet")

# Generated at 2022-06-11 09:04:54.968546
# Unit test for function jsonify
def test_jsonify():
    class Foo:
        def __init__(self, a, b):
            self.a = a
            self.b = b
        def to_json(self):
            return {
                'a': self.a,
                'b': self.b,
            }
    f = Foo(42, "hello")
    assert jsonify(f) == "{\"a\": 42, \"b\": \"hello\"}"
    assert jsonify({"a": f}) == "{\"a\": {\"a\": 42, \"b\": \"hello\"}}"

# Generated at 2022-06-11 09:04:57.162742
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a":"b"}) == '{"a": "b"}'


# Generated at 2022-06-11 09:05:09.334830
# Unit test for function jsonify
def test_jsonify():
    '''
    jsonify returns valid JSON for various inputs
    '''
    from ansible.compat.tests import unittest
    from ansible.utils.unicode import to_unicode

    class TestJsonify(unittest.TestCase):

        def test_none(self):
            self.assertEqual(jsonify(None), '{}')

        def test_dict(self):
            self.assertEqual(jsonify(dict(a=1, b='foo')), '{"a": 1, "b": "foo"}')

        def test_list(self):
            self.assertEqual(jsonify([1, 2, 3]), '[1, 2, 3]')

        def test_string(self):
            self.assertEqual(jsonify('foo'), '"foo"')


# Generated at 2022-06-11 09:05:10.607209
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo':'bar'}) == '{"foo": "bar"}'

# Generated at 2022-06-11 09:05:15.584842
# Unit test for function jsonify
def test_jsonify():
    result = {
        'foo': 'bar',
        'blip': {
            'blap': 'blop'
        }
    }
    assert jsonify(result, True) == "{'blip': {'blap': 'blop'}, 'foo': 'bar'}"
    assert jsonify(result, False) == "{'blip': {'blap': 'blop'}, 'foo': 'bar'}"

# Generated at 2022-06-11 09:05:27.472890
# Unit test for function jsonify
def test_jsonify():

    # Test valid json
    test_dict = {"Name": "Homer Simpson", "Age": 38, "Occupation": "Nuclear Safety Inspector"}
    test_json_string = jsonify(test_dict)
    test_out = json.loads(test_json_string)
    assert test_out['Name'] == "Homer Simpson"
    assert test_out['Age'] == 38
    assert test_out['Occupation'] == "Nuclear Safety Inspector"

    # Test empty input
    test_json_string = jsonify(None)
    test_out = json.loads(test_json_string)
    assert test_out == {}

    # Test broken json (will expect failure)
    test_dict = "Name: Homer Simpson, Age: 38, Occupation: Nuclear Safety Inspector"

# Generated at 2022-06-11 09:05:34.851496
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_unicode
    import datetime

    assert '{"a": "b", "c": "d"}' == jsonify({'a': 'b', 'c': 'd'})
    assert '{}' == jsonify(None)

    non_json = datetime.datetime.now()
    if not isinstance(non_json, json.JSONEncoder().default(non_json)):
        non_json = to_unicode(non_json, errors='surrogate_then_replace')
        assert '"%s"' % non_json == jsonify(non_json)

# Generated at 2022-06-11 09:05:42.357250
# Unit test for function jsonify
def test_jsonify():
    datadict = {'status': 'success', 'results': [{'item1': 'one'}, {'item2': 'two'}]}
    assert json.dumps(datadict) == jsonify(datadict)
    assert '"status": "success"' in jsonify(datadict)
    assert '    "item1": "one"' in jsonify(datadict, format=True)

# Generated at 2022-06-11 09:05:53.157436
# Unit test for function jsonify
def test_jsonify():
    import os

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager

    # The following data is used for the test of
    # ansible.module_utils.jsonify (this file).
    #
    # We define a `host` with some attributes, a `group` with some children
    # (some of them being `host` objects)
    #
    # From that, we obtain a `result` object which is a list of dictionaries
    # which represent the JSON to be returned by the function.
    #
    # Then we use the function `jsonify` to obtain a string representation of this
    # JSON.
    #
    # Finally we compare it to a reference value by reading a file which is
    # supposed to contain it


# Generated at 2022-06-11 09:05:58.236614
# Unit test for function jsonify
def test_jsonify():
    ''' Test jsonify '''
    res = jsonify({1:2, 3:[4]})
    assert res == "{\"1\":2, \"3\":[4]}"

    res = jsonify({1:2, 3:[4]}, True)
    assert res == "{\n    \"1\": 2, \n    \"3\": [\n        4\n    ]\n}"

# Generated at 2022-06-11 09:06:02.873003
# Unit test for function jsonify
def test_jsonify():
    import pytest
    assert jsonify({"a": 1}) == "{\"a\": 1}"
    assert jsonify({"a": 1}, format=True) == "{\n    \"a\": 1\n}"
    assert jsonify(None) == "{}"
    assert jsonify(None, format=True) == "{}"
    with pytest.raises(TypeError):
        jsonify(["This is not", "JSON serializable"])
    with pytest.raises(TypeError):
        jsonify(["This is not", "JSON serializable"], format=True)

# Generated at 2022-06-11 09:06:13.421901
# Unit test for function jsonify
def test_jsonify():
    import sys

    test_result = { 'foo' : 1, 'bar' : 2 }

    # Set up
    old_stdout = sys.stdout
    sys.stdout = open('/dev/null', 'w')

    # Run the tests
    assert jsonify(test_result, False) == '{"bar": 2, "foo": 1}'
    assert jsonify(test_result, True) == '{\n    "bar": 2,\n    "foo": 1\n}'

    # Tear down
    sys.stdout.close()
    sys.stdout = old_stdout

# Generated at 2022-06-11 09:06:22.264203
# Unit test for function jsonify
def test_jsonify():
    from ansible.compat.tests import unittest
    class TestJsonify(unittest.TestCase):
        def test_jsonify_returns_dict(self):
            self.assertEqual(
                jsonify(None),
                '{}'
            )

        def test_jsonify_returns_formatted_json_string(self):
            obj = {'foo': 'bar'}
            self.assertEqual(
                jsonify(obj),
                '''{
    "foo": "bar"
}'''
            )

        def test_jsonify_returns_json_string(self):
            obj = {'foo': 'bar'}
            self.assertEqual(
                jsonify(obj, format=False),
                '{"foo": "bar"}'
            )

    unitt

# Generated at 2022-06-11 09:06:29.809766
# Unit test for function jsonify
def test_jsonify():

    # Test that it accepts None
    assert jsonify(None) == "{}"

    # Test that it accepts a dictionary
    assert '{' in jsonify({u'key': u'value'})
    assert 'key' in jsonify({u'key': u'value'})
    assert 'value' in jsonify({u'key': u'value'})

    # Test that it accepts a unicode string
    assert 'value' in jsonify({u'key': u'value'})



# Generated at 2022-06-11 09:06:39.682463
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'foo', 'b': 'bar', 'c': [1,2,3]}
    jsonified = jsonify(data)
    assert jsonified == '{"a": "foo", "b": "bar", "c": [1, 2, 3]}'

    data = {'a': 'foo', 'b': 'bar', 'c': [1,2,3]}
    jsonified = jsonify(data, format=True)
    assert jsonified == '''{
    "a": "foo",
    "b": "bar",
    "c": [
        1,
        2,
        3
    ]
}'''

    data = { u"\u8d64": 'foo' }
    jsonified = jsonify(data)

# Generated at 2022-06-11 09:06:49.349734
# Unit test for function jsonify
def test_jsonify():
    import os
    import sys
    my_env = os.environ
    my_env["ANSIBLE_NOCOLOR"] = "1"
    my_env["ANSIBLE_FORCE_COLOR"] = "false"

    # This is a bit hacky, but lets us test this specific function without calling ansible-playbook
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    from lib.utils.plugins import Jinja2FilterModule
    filter_loader = Jinja2FilterModule()
    filter_loader._filters = {}
    import ansible.plugins.filter


# Generated at 2022-06-11 09:06:54.020339
# Unit test for function jsonify
def test_jsonify():

    # Simple test
    assert jsonify({"un":"deux","trois":"quatre"}) == '{"trois": "quatre", "un": "deux"}'

    # unicode test
    assert jsonify({"één":"twee","drie":"vier"}) == '{"drie": "vier", "één": "twee"}'

    # None test
    assert jsonify(None) == "{}"

# Generated at 2022-06-11 09:06:56.983596
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1}) == '{"a": 1}'


# Generated at 2022-06-11 09:07:02.823464
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"hello": "world"}) == '{"hello": "world"}'
    assert jsonify({"hello": "world"}, True) == '{\n    "hello": "world"\n}'
    assert jsonify({"hello": "w\u1234rld", 1: 2}, True) == '{\n    "1": 2, \n    "hello": "w\\u1234rld"\n}'
    assert jsonify({"hello": "w\u1234rld", 1: 2}) == '{\n    "1": 2, \n    "hello": "w\\u1234rld"\n}'

# Generated at 2022-06-11 09:07:10.088676
# Unit test for function jsonify
def test_jsonify():
    ''' unit test for jsonify '''
    result = {'1': ['2'], '2': ['3']}

    assert jsonify(result) == "{\"1\": [\"2\"], \"2\": [\"3\"]}"
    assert jsonify(result, True) == "{\n    \"1\": [\n        \"2\"\n    ], \n    \"2\": [\n        \"3\"\n    ]\n}"
    assert jsonify(None) == "{}"

# Generated at 2022-06-11 09:07:20.599601
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import jsonify

    test1 = dict(spam='eggs', foo='bar', baz=dict(one='two', three='four', five=dict(six='seven')))
    result = jsonify(test1, format=True)
    assert result == """{
    "baz": {
        "five": {
            "six": "seven"
        },
        "one": "two",
        "three": "four"
    },
    "foo": "bar",
    "spam": "eggs"
}"""

    test2 = dict(RESULT='{"failed":true}')
    result = jsonify(test2)
    assert result == '{"RESULT": "{\\"failed\\":true}"}'

# Generated at 2022-06-11 09:07:24.791491
# Unit test for function jsonify
def test_jsonify():
    ''' test_jsonify '''
    assert jsonify({"foo": "bar"}, True) == '''{
    "foo": "bar"
}'''

    assert jsonify({"foo": "bar"}, False) == '{"foo": "bar"}'

    assert jsonify(None) == "{}"

# Generated at 2022-06-11 09:07:26.381645
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'one'}, True) == '''{
    "a": "one"
}'''

# Generated at 2022-06-11 09:07:32.622483
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(True) == "true"
    assert jsonify(1) == "1"
    assert jsonify(dict(a=1,b=2)) == '{"a":1,"b":2}'
    assert jsonify(dict(a=1,b=2), format=True) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1,b="two"), format=True) == '{\n    "a": 1,\n    "b": "two"\n}'
    assert jsonify(dict(a=1,b="two")) == '{"a":1,"b":"two"}'

# Generated at 2022-06-11 09:07:38.025309
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'
    assert jsonify(None) == '{}'

# vim: set sw=4 et sts=4:

# Generated at 2022-06-11 09:07:41.781337
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': None}) == '{"a": null}'
    assert jsonify({'a': None}, True) == '{\n    "a": null\n}\n'


# Generated at 2022-06-11 09:07:49.337600
# Unit test for function jsonify
def test_jsonify():

    # Test with a simple dictionary
    d = { 'a': 1,
          'b': 2,
          'c': [ 'd', 'e', 'f' ]}
    answer = jsonify(d)
    assert answer.count('\n') == 0
    assert json.loads(answer) == d

    answer = jsonify(d, True)
    assert answer.count('\n') == 3
    assert json.loads(answer) == d

    # Test with None
    assert jsonify(None) == "{}"

    # Test with no args
    assert jsonify() == "{}"

# Generated at 2022-06-11 09:08:01.239473
# Unit test for function jsonify
def test_jsonify():
    from nose.tools import assert_equals
    from nose.tools import raises

    # Check that we can encode an empty dictionary
    assert_equals(jsonify({}), '{}')

    # Check that we can encode a dictionary with data
    assert_equals(jsonify({'a':1,'b':2,'c':3}), '{"a": 1, "b": 2, "c": 3}')

    # Check that we can encode a nested dictionary
    assert_equals(jsonify({'a':{'b':2,'c':3},'d':4}), '{"a": {"b": 2, "c": 3}, "d": 4}')

    # Check that we can encode a list
    assert_equals(jsonify([1,2,3]), '[1, 2, 3]')

    # Check that we can

# Generated at 2022-06-11 09:08:07.564671
# Unit test for function jsonify
def test_jsonify():
    # empty test
    assert jsonify(None) == "{}"

    # format test
    assert jsonify(None, True) == "{}"

    # some return test
    assert jsonify({"test": "value"}) == '{"test": "value"}'

    # some return with format test
    assert jsonify({"test": "value"}, True) == '''{
    "test": "value"
}'''

# Generated at 2022-06-11 09:08:11.830117
# Unit test for function jsonify
def test_jsonify():
    result = {'success':True}
    assert jsonify(result) == "{\"success\": true}"

    result = {'success':True}
    assert jsonify(result, True) == "{\n    \"success\": true\n}"

# Generated at 2022-06-11 09:08:17.266890
# Unit test for function jsonify
def test_jsonify():
    kwargs = {'name': 'TestHost', 'inventory_hostname': 'testhost', 'groups': [],
              'groups_list': [], 'omit': 'me'}
    assert 'TestHost' in jsonify(kwargs)
    assert 'testhost' in jsonify(kwargs)
    assert 'groups' in jsonify(kwargs)
    assert 'omit' not in jsonify(kwargs)
    assert '    ' not in jsonify(kwargs)
    assert '    ' in jsonify(kwargs, format=True)
    assert u"\u2026" in jsonify({'foo': "bar" * 100})

# Generated at 2022-06-11 09:08:18.925131
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None, format=True) == "{}"
    assert jsonify(None, format=False) == "{}"

# Generated at 2022-06-11 09:08:27.382418
# Unit test for function jsonify
def test_jsonify():

    # Return None immediately
    assert len(jsonify(None)) == len("{}")

    # Return string
    assert len(jsonify("{a: b}")) >= len("\"{a: b}\"")

    # Return dict as json, not string
    assert len(jsonify([{'a':'b'}])) > len("[{'a':'b'}]")

    # Return dict as json with pretty printing
    assert len(jsonify([{'a':'b'}], format=True)) > len("[{'a':'b'}]")

# Generated at 2022-06-11 09:08:29.421109
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'

# Generated at 2022-06-11 09:08:31.882428
# Unit test for function jsonify
def test_jsonify():
    import sys

    if sys.version_info >= (3, 0):
        assert jsonify(None, True) == 'null'
    else:
        assert jsonify(None, True) == 'None'
    assert jsonify({}) == '{}'
    assert jsonify(dict(a=1)) == '{"a": 1}'

# Generated at 2022-06-11 09:08:35.277179
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"hello": "world"}) == '{"hello": "world"}'

    assert jsonify({"hello": "world"}, format=True) == '''{
    "hello": "world"
}'''

test_jsonify()


# Generated at 2022-06-11 09:08:37.538244
# Unit test for function jsonify
def test_jsonify():
    expected_result = '{"changed": false, "ping": "pong"}'
    result = jsonify({'ping': 'pong', 'changed': False})
    assert result == expected_result

# Generated at 2022-06-11 09:08:51.369608
# Unit test for function jsonify
def test_jsonify():
    from collections import namedtuple
    result = namedtuple('result', ['stdout'])
    assert jsonify(result(stdout=None)) == "{}"
    result = namedtuple('result', ['stdout'])
    assert jsonify(result(stdout=u'\u1234')) == '"\u1234"'
    result = namedtuple('result', ['stdout'])
    assert jsonify(result(stdout=u'\u1234'), format=True) == "\"\u1234\""

# Generated at 2022-06-11 09:08:59.223840
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_unicode

    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify(None) == '{}'
    assert jsonify(None, True) == '{}'
    assert jsonify({"a": [1, 2, 3]}) == '{"a": [1, 2, 3]}'
    assert jsonify({"a": [1, 2, 3]}, True) == '{\n    "a": [\n        1,\n        2,\n        3\n    ]\n}'

# Generated at 2022-06-11 09:09:09.024320
# Unit test for function jsonify
def test_jsonify():
    result1 = dict(foo='bar', baz='faz')
    result2 = dict(foo='bar', baz=dict(faz='bar'))
    assert jsonify(result1, format=False) == "{\"foo\": \"bar\", \"baz\": \"faz\"}"
    assert jsonify(result2, format=False) == "{\"baz\": {\"faz\": \"bar\"}, \"foo\": \"bar\"}"
    assert jsonify(result1, format=True) == """{
    "baz": "faz",
    "foo": "bar"
}"""
    assert jsonify(result2, format=True) == """{
    "baz": {
        "faz": "bar"
    },
    "foo": "bar"
}"""

# Generated at 2022-06-11 09:09:20.953861
# Unit test for function jsonify
def test_jsonify():
    import collections

    # Remove this when Python2 is no longer supported
    # convert unicode to string
    def convert_unicode(data):
        if isinstance(data, basestring):
            return str(data)
        elif isinstance(data, collections.Mapping):
            return dict(map(convert_unicode, data.iteritems()))
        elif isinstance(data, collections.Iterable):
            return type(data)(map(convert_unicode, data))
        else:
            return data

    # create a test dictionary & "json" formatted string
    test_dict = {'a':'b'}
    test_json = '{\n    "a": "b"\n}'
    assert jsonify(test_dict, True) == test_json

    # test non-ascii charcater

# Generated at 2022-06-11 09:09:25.086165
# Unit test for function jsonify
def test_jsonify():
    data = [{'a':1, 'b':'two', 'c':3.0}]
    assert '{\n    "a": 1,\n    "b": "two",\n    "c": 3.0\n}' == jsonify(data, format=True)
    assert '{"a": 1, "b": "two", "c": 3.0}' == jsonify(data)
    assert '"one"' == jsonify("one")

# Generated at 2022-06-11 09:09:35.336946
# Unit test for function jsonify
def test_jsonify():

    # No input, empty JSON is returned
    assert "{}" == jsonify(None)
    assert "{}" == jsonify(None, True)

    # Simple JSON
    assert '1' == jsonify(1)
    assert '1' == jsonify(1, True)

    # Simple JSON
    assert '{"a":1}' == jsonify({'a': 1})
    assert '{\n    "a": 1\n}' == jsonify({'a': 1}, True)

    # Not-so-simple JSON
    assert '{"a":{"b":1,"c":2,"d":3}}' == jsonify({'a': {'b': 1, 'c': 2, 'd': 3}})

# Generated at 2022-06-11 09:09:44.414443
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify("hello", True) == '"hello"'
    assert jsonify("hello", False) == '"hello"'
    assert jsonify({"a": "b"}, True) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, False) == '{"a": "b"}'
    assert jsonify({"a": {"b": "c"}}, True) == '{\n    "a": {\n        "b": "c"\n    }\n}'
    assert jsonify({"a": {"b": "c"}}, False) == '{"a": {"b": "c"}}'
    assert jsonify(["a", "b"], True) == '[\n    "a", \n    "b"\n]'

# Generated at 2022-06-11 09:09:45.287299
# Unit test for function jsonify
def test_jsonify():

    assert jsonify({}) == "{}"


# Generated at 2022-06-11 09:09:47.047987
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 42}) == '{"a": 42}'



# Generated at 2022-06-11 09:09:55.841725
# Unit test for function jsonify
def test_jsonify():
    from nose.tools import assert_equals
    d = dict(a=1, b=2, c=3)
    assert_equals(jsonify(d), "{\"a\": 1, \"b\": 2, \"c\": 3}")
    assert_equals(jsonify(d, True), "{\n" +
                                        "    \"a\": 1, \n" +
                                        "    \"b\": 2, \n" +
                                        "    \"c\": 3\n" +
                                        "}")
    assert_equals(jsonify(None), "{}")

# Generated at 2022-06-11 09:10:14.243121
# Unit test for function jsonify
def test_jsonify():
    '''
    jsonify() returns a json string
    '''
    # Default (verbose)
    result = dict(foo='bar', bam=42)
    s = jsonify(result, True)
    assert s == '{\n    "bam": 42, \n    "foo": "bar"\n}'

    # Non-verbose
    result = dict(foo='bar', bam=42)
    s = jsonify(result, False)
    assert s == '{"bam": 42, "foo": "bar"}'

    # Special case: empty json string
    result = None
    s = jsonify(result, True)
    assert s == '{}'

# Generated at 2022-06-11 09:10:23.367891
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify
    from ansible.module_utils._text import to_text

    assert jsonify({"a": "b"}) == '{"a": "b"}'

    # via to_text()
    a_unicode_string = to_text(u'\u2603')
    assert a_unicode_string == u'\u2603'

    # default non-formatted output
    assert jsonify(a_unicode_string) == '"\u2603"'

    # formatted output should wrap value in quotes
    assert jsonify(a_unicode_string, format=True) == '"\\u2603"'

# Generated at 2022-06-11 09:10:25.177995
# Unit test for function jsonify
def test_jsonify():
    # Test
    assert isinstance(jsonify(None, False), basestring)



# Generated at 2022-06-11 09:10:26.903769
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    # TODO: add more unit tests for jsonify

# Generated at 2022-06-11 09:10:33.265381
# Unit test for function jsonify
def test_jsonify():
    # jsonify should return an empty json object for None
    assert jsonify(None) == '{}'

    # jsonify should return the json form of a dictionary
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'

    # jsonify should sort dictionary keys
    assert jsonify({'b': 1, 'a': 2}) == '{"a": 2, "b": 1}'

    # jsonify should format output with indent 4 if format is True
    assert jsonify({'b': 1, 'a': 2}, True) == '{\n    "a": 2, \n    "b": 1\n}'

    # jsonify should return the json form of a list
    assert jsonify(['foo', 'bar']) == '["foo", "bar"]'

    # jsonify should return the json form of a

# Generated at 2022-06-11 09:10:38.658870
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(None, True) == '{}'
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == '{\n    "a": 1\n}'



# Generated at 2022-06-11 09:10:49.662530
# Unit test for function jsonify
def test_jsonify():

    results = [
        None,
        {},
        {'foo':'bar'},
        {'foo':['bar', 'baz']}
    ]

    formats = [
        None,
        False,
        True
    ]


# Generated at 2022-06-11 09:10:53.182700
# Unit test for function jsonify
def test_jsonify():
    result = {'foo': 'bar', 'baz': 'qux'}
    flattened = jsonify(result)
    assert flattened == '{"baz": "qux", "foo": "bar"}'
    formatted = jsonify(result, True)
    assert formatted == '''{
    "baz": "qux",
    "foo": "bar"
}'''

# Generated at 2022-06-11 09:11:04.142970
# Unit test for function jsonify
def test_jsonify():
    # Test that the uncompressed output gives what we want
    assert jsonify({'a': '1', 'b': [2, 3, 4]}) == '{"a": "1", "b": [2, 3, 4]}'

    # Test that the compressed output gives what we want
    assert jsonify({'a': '1', 'b': [2, 3, 4]}, format=True) == '{\n    "a": "1",\n    "b": [\n        2,\n        3,\n        4\n    ]\n}'

    # Test that the compressed output gives what we want
    assert jsonify(None, format=True) == '{}'

    # Test fix for https://github.com/ansible/ansible/issues/7948

# Generated at 2022-06-11 09:11:08.735331
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify({'a': 'A'}) == '{"a": "A"}'
    assert jsonify({'a': 'A'}, True) == '''{
    "a": "A"
}'''

# Generated at 2022-06-11 09:11:32.258627
# Unit test for function jsonify
def test_jsonify():
    # Empty dictionary conversion
    assert jsonify(None) == "{}"

    # Dictionary conversion
    assert jsonify( { "a" : 1, "b" : 2 } ) == "{\"a\": 1, \"b\": 2}"

    # Dictionary conversion with indentation
    assert jsonify( { "a" : 1, "b" : 2 }, True ) == "{\n    \"a\": 1, \n    \"b\": 2\n}"

# Generated at 2022-06-11 09:11:39.163201
# Unit test for function jsonify
def test_jsonify():
    # All args
    result = jsonify({"foo":"bar"}, True)
    assert result == '''{
    "foo": "bar"
}'''

    # result only
    result = jsonify({"foo":"bar"})
    assert result == '{"foo": "bar"}'

    # None only
    result = jsonify(None)
    assert result == '{}'
    return True

###
# for backwards compatibility, deprecated 2014-03-03

from ansible.plugins.callback import CallbackBase


# Generated at 2022-06-11 09:11:44.185867
# Unit test for function jsonify
def test_jsonify():
    result = dict(foo='bar', bam='baz')
    json = jsonify(result)
    assert(json == '{"bam": "baz", "foo": "bar"}')

    json = jsonify(result, True)
    assert(json == "{\n    \"bam\": \"baz\", \n    \"foo\": \"bar\"\n}")

# Generated at 2022-06-11 09:11:47.719921
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify # noqa
    assert jsonify({u'foo': u'bar'}) == '{\"foo\": \"bar\"}'
    assert jsonify({'foo': 'bar', 'baz': 'bam'}, format=True) == '{\n    \"baz\": \"bam\", \n    \"foo\": \"bar\"\n}'

# Generated at 2022-06-11 09:11:53.896887
# Unit test for function jsonify
def test_jsonify():

    # test with None
    result = jsonify(None)
    assert result == '{}'
    result = jsonify(None, format=True)
    assert result == '{}'

    # test no formatting
    data = {
        'test':'data',
        'test2':'data2'
    }
    result = jsonify(data)
    assert result == '{"test": "data", "test2": "data2"}'

    # test formatting
    result = jsonify(data, format=True)
    expected = '''{
    "test": "data",
    "test2": "data2"
}'''
    assert result == expected

# Generated at 2022-06-11 09:12:06.999255
# Unit test for function jsonify
def test_jsonify():
    ''' make sure the jsonify function works as expected '''
    import sys

    # Simple dict
    result = {'a': 1, 'b': 2}
    assert jsonify(result) == '{"a": 1, "b": 2}'
    assert jsonify(result, True) == '''{
    "a": 1,
    "b": 2
}'''
    # Unicode strings
    result = {'c': u'foo', 'd': u'bar'}
    if sys.version_info >= (3, 0):
        assert jsonify(result) == '{"c": "foo", "d": "bar"}'
        assert jsonify(result, True) == '''{
    "c": "foo",
    "d": "bar"
}'''

# Generated at 2022-06-11 09:12:17.234736
# Unit test for function jsonify
def test_jsonify():
    d = {
         'a': '1',
         'b': [1, 2, 3],
         'c': {
              'd': '4',
              'e': [4, 5, 6],
              'f': {
                   'g': 7,
                   'h': 8,
                   'i': 9
                  }
             }
        }
    j = jsonify(d)
    assert j == '{"a": "1", "b": [1, 2, 3], "c": {"d": "4", "e": [4, 5, 6], "f": {"g": 7, "h": 8, "i": 9}}}'
    k = jsonify(d, True)

# Generated at 2022-06-11 09:12:27.161859
# Unit test for function jsonify

# Generated at 2022-06-11 09:12:29.319105
# Unit test for function jsonify
def test_jsonify():
    '''jsonify should return an empty dictionary for None'''
    assert "{}" == jsonify(None)

# Generated at 2022-06-11 09:12:34.402660
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None, True) == '{}'
    assert jsonify(dict(a=1,b=[1,2,3]), False) == '{"a": 1, "b": [1, 2, 3]}'
    assert jsonify(dict(a=1,b=[1,2,3]), True) == """{\n    "a": 1,
    "b": [\n        1,
        2,
        3\n    ]\n}"""

# Generated at 2022-06-11 09:13:23.448554
# Unit test for function jsonify
def test_jsonify():
    ''' unit test for jsonify '''

    result = {
        'uncompressed':  {
            'age': 20,
            'name': 'Joe'
        },
        'compressed':  {
            'age': 20,
            'name': 'Joe'
        }
    }

    result['uncompressed'] = jsonify(result['uncompressed'], format=True)
    result['compressed'] = jsonify(result['compressed'])

    assert(result['uncompressed'] == '{\n    "age": 20, \n    "name": "Joe"\n}')
    assert(result['compressed'] == '{"age":20,"name":"Joe"}')

# Generated at 2022-06-11 09:13:32.693979
# Unit test for function jsonify
def test_jsonify():

    test1_input = { "key1": "value1",
                    "key2": "value2",
                    "key3": "value3",
                    "key4": {
                        "innerkey1": "innervalue1",
                        "innerkey2": "innervalue2",
                        "innerkey3": {
                            "innerinnerkey1": "innerinnervalue1",
                            "innerinnerkey2": "innerinnervalue2",
                            "innerinnerkey3": "innerinnervalue3" }
                    }
                }


# Generated at 2022-06-11 09:13:40.333058
# Unit test for function jsonify
def test_jsonify():
    result = {
        1: 'foo',
        'bar': 'baz',
        'null': None,
        'number': 1,
    }
    assert jsonify(result, format=False) == "{\"1\": \"foo\", \"bar\": \"baz\", \"null\": null, \"number\": 1}"
    assert jsonify(result, format=True) == "{\n    \"1\": \"foo\",\n    \"bar\": \"baz\",\n    \"null\": null,\n    \"number\": 1\n}"

# Generated at 2022-06-11 09:13:42.129463
# Unit test for function jsonify
def test_jsonify():
    # Unit test for function jsonify
    assert jsonify({}) == "{}"


# Generated at 2022-06-11 09:13:45.622048
# Unit test for function jsonify
def test_jsonify():
    ''' unit test for function jsonify '''
    assert jsonify(None) == "{}"
    assert jsonify({"a":"b"}) == '{"a": "b"}'


# Generated at 2022-06-11 09:13:51.564350
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == "{}"
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, format=True) == '{\n    "foo": "bar"\n}'
    assert jsonify({'foo': [1,2,3]}, format=True)  == '{\n    "foo": [\n        1, \n        2, \n        3\n    ]\n}'

# Generated at 2022-06-11 09:13:56.658821
# Unit test for function jsonify
def test_jsonify():
    value = {'Changed': True, 'Failed': False, 'stdout': '', 'stdout_lines': [], 'rc': 0}
    assert jsonify(value) == '{"Changed": true, "Failed": false, "stdout": "", "rc": 0}'
    assert jsonify(value, True) == '{\n    "Changed": true, \n    "Failed": false, \n    "stdout": "", \n    "rc": 0\n}'

# Generated at 2022-06-11 09:14:00.408494
# Unit test for function jsonify
def test_jsonify():
    a_dict = {'a_list': [1, 2, 3], 'a_string': 'test string'}
    assert json.loads(jsonify(a_dict)) == a_dict
    assert json.loads(jsonify(a_dict, True)) == a_dict



# Generated at 2022-06-11 09:14:02.833085
# Unit test for function jsonify
def test_jsonify():
    assert '"foo": "bar"' in jsonify({'foo':'bar'})
    assert '"foo": "bar"' in jsonify({'foo':'bar'}, format=True)

# Generated at 2022-06-11 09:14:08.263132
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({ 'foo': 'bar' }, True)
    assert result == '''{
    "foo": "bar"
}'''

    result = jsonify({ 'foo': 'bar' }, False)
    assert result == '{"foo": "bar"}'

    # When 'foo' is None, we get a special case
    result = jsonify({ 'foo': None }, True)
    assert result == '''{
    "foo": null
}'''