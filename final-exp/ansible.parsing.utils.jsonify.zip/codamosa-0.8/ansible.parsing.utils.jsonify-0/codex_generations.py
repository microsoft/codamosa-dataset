

# Generated at 2022-06-11 09:04:32.477384
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'hello': 'world'}) == '{"hello": "world"}'

# Generated at 2022-06-11 09:04:42.342889
# Unit test for function jsonify
def test_jsonify():
    result = None
    assert jsonify(result) == "{}"
    result = {'foo': 'bar'}
    assert jsonify(result) == '{"foo": "bar"}'
    assert jsonify(result, format=True) == '{\n    "foo": "bar"\n}'
    result = {'foo': 'bar', 'baz': [1, 2, 3], 'unicode': u'\xe1b\x8d'}
    assert jsonify(result) == '{"baz": [1, 2, 3], "foo": "bar", "unicode": "\\u00e1b\\u008d"}'

# Generated at 2022-06-11 09:04:53.616148
# Unit test for function jsonify
def test_jsonify():

    res = jsonify({'k1': 'v1', 'k2': 2})
    assert res == '{"k1": "v1", "k2": 2}'


# Generated at 2022-06-11 09:05:06.961487
# Unit test for function jsonify
def test_jsonify():
    a = dict(
        id = 1,
        name = "geo",
        details = dict(
            state = "CA",
            city = "San Francisco"
        )
    )
    # Test with indent
    assert jsonify(a, format=True) == json.dumps(a, sort_keys=True, indent=4, ensure_ascii=False)

    # Test without indent
    assert jsonify(a, format=False) == json.dumps(a, sort_keys=True, indent=None, ensure_ascii=False)

    # Test when ensure_ascii=False fails
    b = {u'caf\xe9': u'caf\xe9'}
    assert jsonify(b, format=False) == json.dumps(b, sort_keys=True, indent=None)

# Generated at 2022-06-11 09:05:09.848235
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"

    assert "foobar" in jsonify(dict(foo="bar"))
    assert "foobar" in jsonify(dict(foo="bar"), format=True)

# Test for bad input/output

# Generated at 2022-06-11 09:05:16.235384
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(True) == "true"
    assert jsonify(False) == "false"
    assert jsonify(1) == "1"
    assert jsonify("test") == "\"test\""
    assert jsonify([1,2,3]) == "[1, 2, 3]"
    assert jsonify({"one":1}) == "{\"one\": 1}"
    assert jsonify({"one":1, "two":2}) == "{\"one\": 1, \"two\": 2}"


# Generated at 2022-06-11 09:05:17.971023
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1,b=2)) == "{\"a\": 1, \"b\": 2}"


# Generated at 2022-06-11 09:05:24.297890
# Unit test for function jsonify
def test_jsonify():
    data = {"a": "b"}
    assert(jsonify(data) in [json.dumps(data), json.dumps(data, ensure_ascii=False)])
    assert(jsonify(data, True) in [json.dumps(data, indent=4), json.dumps(data, indent=4, ensure_ascii=False)])

# Generated at 2022-06-11 09:05:34.430243
# Unit test for function jsonify
def test_jsonify():

    try:
        import json
    except ImportError:
        print("SKIP: json (or simplejson) is not installed")
        raise SystemExit

    MY_TEST_DATA = {'a': {'b': 'c'}}
    MY_TEST_DATA2 = [{'a': {'b': 'c'}}]
    MY_TEST_DATA_ONE_KEY = {'key': 'value'}
    MY_TEST_DATA_ONE_LIST = ['value']
    MY_TEST_DATA_ONE_LIST2 = [['value']]
    MY_TEST_DATA_ONE_LIST3 = [[['value']]]
    MY_TEST_DATA_ONE_ITEM = ['value']
    MY_TEST_DATA_ONE_ITEM2 = [['value']]
    MY_TEST

# Generated at 2022-06-11 09:05:46.487344
# Unit test for function jsonify
def test_jsonify():

    from ansible.module_utils.six import PY2

    assert jsonify(None) == '{}'
    assert jsonify([]) == '[]'
    assert jsonify('test') == '"test"'
    assert jsonify({}) == '{}'
    assert jsonify(dict(changed=False, rc=0)) == '{"changed": false, "rc": 0}'

    # Python 2 cannot represent certain unicode characters in json
    assert jsonify(dict(a=u'\u2713'), format=True) == '{\n    "a": "\\u2713"\n}'

    if PY2:
        # Python 2 cannot represent certain unicode characters in python objects
        # so the following check is only possible in Python 3
        assert jsonify(dict(a=u'\u2713'), format=False)

# Generated at 2022-06-11 09:05:59.095913
# Unit test for function jsonify
def test_jsonify():
    test_data = {
        'a': 1,
        'b': 2,
        'c': [1, 2, 3, 4],
        'd': {'e': 'f'},
        'g': 'hij',
        'i': u'a',
        'j': {u'b': u'c'},
        'k': [u'd', u'e', u'f']
    }

    expected_compacted = '''{"a":1,"b":2,"c":[1,2,3,4],"d":{"e":"f"},"g":"hij","i":"a","j":{"b":"c"},"k":["d","e","f"]}'''

# Generated at 2022-06-11 09:06:09.697811
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    result = dict(
        a = 'string',
        b = True,
        c = [1, 2, 3],
        d = dict(
            one = 'one',
            two = 'two',
        ),
        e = AnsibleUnsafeText('unicode value')
    )

    # Make sure that the result is valid JSON
    assert(json.loads(jsonify(result)))

    # Make sure that jsonify doesn't throw an exception if it's passed
    # AnsibleUnsafeText and instead returns valid JSON
    assert(jsonify(result))
    assert(json.loads(jsonify(result))['e'] == 'unicode value')

# Generated at 2022-06-11 09:06:19.909949
# Unit test for function jsonify

# Generated at 2022-06-11 09:06:22.207004
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo="bar"), True)  == '''{
    "foo": "bar"
}'''



# Generated at 2022-06-11 09:06:32.834595
# Unit test for function jsonify
def test_jsonify():
    # Test case 1.
    result = {"data": "string1", "key": "value", "list": [1,2,3]}
    expected = '{"data": "string1", "key": "value", "list": [1, 2, 3]}'
    assert jsonify(result, False) == expected
    assert jsonify(result, True) == expected
    # Test case 2.
    result = None
    expected = "{}"
    assert jsonify(result, False) == expected
    assert jsonify(result, True) == expected
    # Test case 3.
    result = "test"
    expected = '"test"'
    assert jsonify(result, False) == expected
    assert jsonify(result, True) == expected

test_jsonify()

# Generated at 2022-06-11 09:06:38.742515
# Unit test for function jsonify
def test_jsonify():

    # Make sure jsonify can return None
    assert jsonify(None) == "{}"

    # Make sure things that aren't dictionaries fail
    try:
        jsonify(["foo", "bar", "baz"])
        failed = False
    except TypeError:
        failed = True

    assert failed

    # Should be able to jsonify a dictionary
    assert jsonify({"foo":"bar"})

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:06:42.544209
# Unit test for function jsonify
def test_jsonify():
    ''' function is using the Python 2.6 json module '''

    assert jsonify({"arg":2}) == '{"arg": 2}'
    assert jsonify({"arg":2}, format=True) == '{\n    "arg": 2\n}'

# Generated at 2022-06-11 09:06:48.966886
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"

    assert jsonify("foo") == "\"foo\""
    assert jsonify("foo\nbar") == "\"foo\\nbar\""
    assert jsonify("foo\nbar\r\n") == "\"foo\\nbar\\r\\n\""

    assert jsonify(dict(foo="bar")) == "{\n    \"foo\": \"bar\"\n}"
    assert jsonify(dict(foo="bar\n"), True) == "{\n    \"foo\": \"bar\\n\"\n}"

# Generated at 2022-06-11 09:06:51.008715
# Unit test for function jsonify
def test_jsonify():
    res = jsonify(dict(foo='bar'))
    assert res == '''{
    "foo": "bar"
}'''

# Generated at 2022-06-11 09:06:53.424314
# Unit test for function jsonify
def test_jsonify():

    result = {
        'a': 1,
        'b': 2
    }

    assert jsonify(result) == '{"a": 1, "b": 2}'

# Generated at 2022-06-11 09:07:07.814510
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(changed=True, rc=0)) == '{"changed": true, "rc": 0}'
    assert jsonify(dict(changed=True, rc=0), format=True) == '''{
    "changed": true,
    "rc": 0
}'''

    assert jsonify(dict(changed=True, rc=0, ansible_facts=dict(a=1, b=2)), format=True) == '''{
    "ansible_facts": {
        "a": 1,
        "b": 2
    },
    "changed": true,
    "rc": 0
}'''

    assert jsonify('asdf') == '"asdf"'
    assert jsonify([1,2,3]) == '[1,2,3]'

# Generated at 2022-06-11 09:07:13.887284
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"

    datastruct = {'a': 1, 'b': 2, 'c': 3}
    assert jsonify(datastruct) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(datastruct, format=True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'


# Generated at 2022-06-11 09:07:20.838900
# Unit test for function jsonify
def test_jsonify():

    testcase = {u'foo':{u'bar':[u'baz', u'bam']}}

    result = jsonify(testcase, False)
    assert result == '{"foo": {"bar": ["baz", "bam"]}}'
    result = jsonify(testcase, True)
    assert result == '''{
    "foo": {
        "bar": [
            "baz",
            "bam"
        ]
    }
}'''

# Generated at 2022-06-11 09:07:22.944034
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'

# Generated at 2022-06-11 09:07:27.556249
# Unit test for function jsonify
def test_jsonify():

    result = {
        "foo": "bar",
        "blah": [ 1, 2, 3, "cheese", "grATEDPARMESAN" ]
    }

    assert jsonify(result) == '{"blah": [1, 2, 3, "cheese", "grATEDPARMESAN"], "foo": "bar"}'

# Test for formatting

# Generated at 2022-06-11 09:07:38.506862
# Unit test for function jsonify
def test_jsonify():
    '''
    jsonify: Test to make sure data is not corrupted and formatting is OK.
    '''
    data = {
        "a": {
            "b": [ 1, 2, 3, 4, 5, 6, 7 ],
            "c": [ "a", "b", "c", "d", "e", "f", "g" ]
        },
        "b": [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 ],
        "c": "ABCDEFG"
    }


# Generated at 2022-06-11 09:07:49.530412
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    result = {
        "failed": False,
        "changed": True,
        "foo": {
            "bar": 1,
            "baz": "two"
        },
        "bar": [
            "one",
            "two",
            3,
            {
                "foo": "bar"
            }
        ]
    }
    json = jsonify(result, False)
    assert json == "{\"changed\": true, \"failed\": false, \"bar\": [\"one\", \"two\", 3, {\"foo\": \"bar\"}], \"foo\": {\"bar\": 1, \"baz\": \"two\"}}"
    json = jsonify(result, True)

# Generated at 2022-06-11 09:07:54.225069
# Unit test for function jsonify
def test_jsonify():
    a = {'a': 'b', '5': [1,2,3]}
    assert jsonify(a) == '{"5": [1, 2, 3], "a": "b"}'
    assert jsonify(a, True) == '{\n    "5": [\n        1, \n        2, \n        3\n    ], \n    "a": "b"\n}'

# Generated at 2022-06-11 09:07:58.455935
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify function '''

    result = {'a': 1, 'b': 2}

    assert jsonify(result) == '{"a": 1, "b": 2}'
    assert jsonify(result, format=True) == '''{
    "a": 1,
    "b": 2
}'''

# Generated at 2022-06-11 09:08:09.697787
# Unit test for function jsonify
def test_jsonify():
    ''' unit tests for jsonify '''

    from ansible.utils import module_docs
    from ansible.utils.module_docs import *

    def compare(source, expected):
        result = jsonify(source, format=True)
        assert result == expected

    source = dict(a=1, b=2, c=dict(d=4, e=5, f=6))
    compare(source, '''{
    "a": 1,
    "b": 2,
    "c": {
        "d": 4,
        "e": 5,
        "f": 6
    }
}''')

    source = dict(a=1, b=2, c=dict(d=4, e=5, f=6), z=None)

# Generated at 2022-06-11 09:08:31.013728
# Unit test for function jsonify
def test_jsonify():

    # Test no result (should return empty json)
    result = None
    assert jsonify(result) == "{}"

    # Test input with Unicode characters (no exceptions should occur)
    result = { "status": "\\u041b\\u043e\\u043c\\u0430\\u0439\\u043d \\u043d\\u0435" }
    res = jsonify(result)
    assert json.loads(res) == result

    # Test the argument format
    result = { "status": "\\u041b\\u043e\\u043c\\u0430\\u0439\\u043d \\u043d\\u0435" }

# Generated at 2022-06-11 09:08:38.829381
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify output (uncompressed and compressed) '''

    # Test some data structures without unicode
    assert jsonify({}) == '{}'
    assert jsonify({'param1': 'one'}) == '{"param1": "one"}'
    assert jsonify({'param1': 'one', 'param2': 'two'}) == '{"param1": "one", "param2": "two"}'
    assert jsonify({'param1': ['a','b','c']}) == '{"param1": ["a", "b", "c"]}'
    assert jsonify({'param1': {'param2':'b'}}, True) == '{\n    "param1": {\n        "param2": "b"\n    }\n}'

    # Test some data structures with unicode
    assert jsonify

# Generated at 2022-06-11 09:08:44.723275
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(changed=False, rc=0)) == '{"changed": false, "rc": 0}'
    assert jsonify(dict(changed=False, rc=0), True) == json.dumps(dict(changed=False, rc=0), sort_keys=True, indent=4)
    assert jsonify(None, True) == "{}"

# Generated at 2022-06-11 09:08:52.513306
# Unit test for function jsonify
def test_jsonify():
    ''' return the correct data structure '''

    # Test the basic json output
    test = jsonify(dict(foo='bar'))
    assert test == '{"foo": "bar"}'

    # Test the formatted output
    test = jsonify(dict(foo='bar'), True)
    assert test == '{\n    "foo": "bar"\n}'

    # Test None
    test = jsonify(None)
    assert test == '{}'

# Generated at 2022-06-11 09:08:55.812960
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == "{}"
    assert jsonify({"a":1}) == '{"a": 1}'
    assert jsonify({"a":1}, True) == '''{
    "a": 1
}'''

# Generated at 2022-06-11 09:08:58.606181
# Unit test for function jsonify
def test_jsonify():

    assert '{"foo": "bar"}' == jsonify({'foo': 'bar'})
    assert 'null' == jsonify(None)
    assert '{"foo": "bar"}' == jsonify({'foo': 'bar'}, True)

# Generated at 2022-06-11 09:09:07.394717
# Unit test for function jsonify
def test_jsonify():
    r1_in  = {'a': 1, 'b': 2, 'c': 3}
    r1_out = '{"a": 1, "b": 2, "c": 3}'

    r2_in  = [1, 2, 3]
    r2_out = '[1, 2, 3]'

    r3_in  = "a"
    r3_out = '"a"'

    r1 = jsonify(r1_in)
    r2 = jsonify(r2_in)
    r3 = jsonify(r3_in)

    assert(r1 == r1_out)
    assert(r2 == r2_out)
    assert(r3 == r3_out)

# Generated at 2022-06-11 09:09:09.118924
# Unit test for function jsonify
def test_jsonify():
    res = jsonify({'a': 'value'})
    assert res == u'{"a": "value"}'

# Generated at 2022-06-11 09:09:15.477751
# Unit test for function jsonify
def test_jsonify():
    result = {
        '_ansible_verbose_always': True,
        'changed': False,
        'module_stderr': '',
        'module_stdout': '{"changed": false, "ping": "pong"}',
        'msg': '',
        'rc': 0
    }

    assert jsonify(result, False)
    assert jsonify(result, True)

# Generated at 2022-06-11 09:09:19.026117
# Unit test for function jsonify
def test_jsonify():
    result = {'a': 5}
    assert jsonify(result) == "{\"a\": 5}"
    assert jsonify(result, format=True) == "{\n    \"a\": 5\n}"

# Generated at 2022-06-11 09:09:41.670939
# Unit test for function jsonify
def test_jsonify():
    ''' unit test for jsonify()'''
    results = dict(changed=True)
    assert jsonify(results) == "{\"changed\": true}"
    assert jsonify(results, format=True) == "{\n    \"changed\": true\n}"
    assert jsonify(None) == "{}"

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:09:46.994372
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'
    assert jsonify({'foo': 'bar'}, indent=4) == '{\n    "foo": "bar"\n}'
    assert jsonify({'foo': u'bar', u'baz': 'qux'}) == '{"baz": "qux", "foo": "bar"}'

# Generated at 2022-06-11 09:09:58.840551
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(dict(changed=True, ping="pong", foo=list(range(3))))
    # Trim final newline to simplify tests.
    assert '\n' not in result, "Test result contains newlines."
    assert "  " not in result, "Test result is indented."
    assert '"changed": true' in result
    assert '"ping": "pong"' in result
    assert '"foo": [0, 1, 2]' in result

    result = jsonify(dict(changed=True, ping="pong", foo=list(range(3))), format=True)
    assert '\n' in result, "Test result lacks newlines."
    assert "  " in result, "Test result is not indented."
    assert '"changed": true' in result
    assert '"ping": "pong"'

# Generated at 2022-06-11 09:10:02.854013
# Unit test for function jsonify
def test_jsonify():
    result = dict(changed=True, rc=0)
    assert jsonify(result, False) == '{"changed": true, "rc": 0}'
    assert jsonify(result, True)  == '{\n    "changed": true,\n    "rc": 0\n}'
    assert jsonify(None) == '{}'

# Generated at 2022-06-11 09:10:05.810570
# Unit test for function jsonify
def test_jsonify():
    result = {'foo': 'bar'}

    uncompressed = jsonify(result, format=False)
    assert uncompressed == '{"foo": "bar"}'

    compressed = jsonify(result, format=True)
    assert compressed == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-11 09:10:10.611116
# Unit test for function jsonify
def test_jsonify():

    """ jsonify unit tests """

    #FIXME: these tests seem way to simple
    assert jsonify(None) == "{}"

    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'

    assert jsonify({"foo": "bar"}, True) == '''{
    "foo": "bar"
}'''

# Generated at 2022-06-11 09:10:22.185456
# Unit test for function jsonify
def test_jsonify():
    ''' verify that jsonify() works correctly '''

    res = { 'item1': 'value1', 'item2': 'value2', 'item3': 'value3' }
    assert jsonify(res) == '{"item1": "value1", "item2": "value2", "item3": "value3"}'

    res = ['item1', 'item2', 'item3']
    assert jsonify(res) == '["item1", "item2", "item3"]'

    res = [ { 'item1': 'value1' }, { 'item2': 'value2' }, { 'item3': 'value3' } ]
    assert jsonify(res) == '[{"item1": "value1"}, {"item2": "value2"}, {"item3": "value3"}]'


# Generated at 2022-06-11 09:10:26.093430
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'
    assert jsonify(None) == '{}'
    assert jsonify(None, True) == '{}'

# Generated at 2022-06-11 09:10:32.775323
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}, True) == '''{
    "foo": "bar"
}'''
    assert jsonify({'foo': 'bar', 'fie': 'baz'}, True) == '''{
    "fie": "baz",
    "foo": "bar"
}'''
    assert jsonify({'foo': 'bar', 'fie': 'baz', 'fum': [1, 2, {'one': 1, 'two': 2}]}, True) == '''{
    "fie": "baz",
    "foo": "bar",
    "fum": [
        1,
        2,
        {
            "one": 1,
            "two": 2
        }
    ]
}'''

# Generated at 2022-06-11 09:10:45.653664
# Unit test for function jsonify
def test_jsonify():
    result = {
      "contacted": {
        "localhost": {
          "invocation": {
            "module_args": "foo=bar",
            "module_name": "command"
          },
          "rc": 0,
          "stderr": "",
          "stderr_lines": [],
          "stdout": "Hello world",
          "stdout_lines": [
            "Hello world"
          ]
        }
      },
      "dark": {}
    }

# Generated at 2022-06-11 09:11:14.808737
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == "{}"
    assert jsonify("foo") == '"foo"'
    assert jsonify("føø") == '"f\u00f8\u00f8"'
    assert jsonify(u"føø") == '"f\u00f8\u00f8"'
    assert jsonify([1,2,3]) == "[1, 2, 3]"
    assert jsonify({"a":1,"b":2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a":1,"b":2}, True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-11 09:11:22.379952
# Unit test for function jsonify
def test_jsonify():
    complex_data = {
        'a_dict': {
            'a_float': 3.14159,
            'an_int': 42,
            'a_list': [1, 2, 3, 4],
        },
        'a_float': 3.14159,
        'an_int': 42,
        'a_list': [1, 2, 3, 4],
    }
    # Make sure unformatted data works
    assert jsonify(complex_data) == '{"a_dict": {"a_float": 3.14159, "an_int": 42, "a_list": [1, 2, 3, 4]}, "a_float": 3.14159, "an_int": 42, "a_list": [1, 2, 3, 4]}'

    # Make sure formatted data works

# Generated at 2022-06-11 09:11:26.240950
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-11 09:11:29.618617
# Unit test for function jsonify
def test_jsonify():
   assert jsonify({}) == '{}'
   assert jsonify({'a': 1}) == '{\n    "a": 1\n}'

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:11:31.308845
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify
    assert jsonify({}) == '{}'


# Generated at 2022-06-11 09:11:33.945248
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo":"bar"}) == '{"foo": "bar"}'
    assert jsonify(["foo", "bar"]) == '["foo", "bar"]'

# Generated at 2022-06-11 09:11:41.698896
# Unit test for function jsonify
def test_jsonify():
    json_result = jsonify(dict(a=1, b=2, c=3, d=4, e='foo'))
    assert json_result == "{\"a\": 1, \"b\": 2, \"c\": 3, \"d\": 4, \"e\": \"foo\"}"
    json_result = jsonify(dict(a=1, b=2, c=3, d=4, e='foo'), format=True)
    assert json_result == "{\n    \"a\": 1, \n    \"b\": 2, \n    \"c\": 3, \n    \"d\": 4, \n    \"e\": \"foo\"\n}"
    json_result = jsonify(None)
    assert json_result == "{}"

# Generated at 2022-06-11 09:11:47.148221
# Unit test for function jsonify
def test_jsonify():
    result1 = jsonify(dict(foo='bar', baz=[1, 2, 3]), format=False)
    assert result1 == '{"baz": [1, 2, 3], "foo": "bar"}'
    result2 = jsonify(dict(foo='bar', baz=[1, 2, 3]), format=True)
    assert result2.startswith("{\n    \"baz\": [\n        1, \n        2, \n        3")
    assert result2.endswith("        \"foo\": \"bar\"\n}")


# Generated at 2022-06-11 09:11:50.563285
# Unit test for function jsonify
def test_jsonify():
    result = dict(changed=False,
                  failed=True,
                  msg="This is a stdout message",
                  results="This is a results message")
    print(jsonify(result, format=True))
    print(jsonify(result, format=False))

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:11:54.056937
# Unit test for function jsonify
def test_jsonify():
    x = { "test": { "test": 1 } }
    y = """{
    "test": {
        "test": 1
    }
}"""
    assert jsonify(x, True) == y
    x = { "test": { "test": 1 } }
    y = '{"test": {"test": 1}}'
    assert jsonify(x, False) == y

# Generated at 2022-06-11 09:12:22.477912
# Unit test for function jsonify
def test_jsonify():
    result = dict(changed=True,somevar=dict(val1='10',val2=20),othervar='0')
    assert jsonify(result, format=False) == '{"changed": true, "somevar": {"val1": "10", "val2": 20}, "othervar": "0"}'
    assert jsonify(result, format=True) == '''{
    "changed": true,
    "othervar": "0",
    "somevar": {
        "val1": "10",
        "val2": 20
    }
}'''

if __name__ == "__main__":
    import __main__
    print(__main__)
    __main__.test_jsonify()

# Generated at 2022-06-11 09:12:26.145563
# Unit test for function jsonify
def test_jsonify():
    result = {'test_key': 'test_result'}
    pass_result = '{"test_key": "test_result"}'
    try:
        assert(pass_result == jsonify(result))
    except AssertionError:
        print("Failed to jsonify data")

# Generated at 2022-06-11 09:12:31.783223
# Unit test for function jsonify
def test_jsonify():
    try:
        import json
    except ImportError:
        print("SKIP: json not available")
        return

    assert jsonify({}) == "{}"
    assert jsonify(None) == "{}"
    assert jsonify({'test': 'data'}) == '{"test": "data"}'
    assert jsonify({'test': 'data'}, True) == '{\n    "test": "data"\n}'

# Generated at 2022-06-11 09:12:35.732616
# Unit test for function jsonify
def test_jsonify():
    dict_obj = { 'a': 1, 'b': 2, 'c': 3 }
    assert jsonify(dict_obj, True) == '''{
    "a": 1,
    "b": 2,
    "c": 3
}
'''
    assert jsonify(dict_obj) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(None) == '{}'
    assert jsonify(None, True) == '{}'

# Generated at 2022-06-11 09:12:41.643942
# Unit test for function jsonify
def test_jsonify():
    d = dict(a=1, b=2, c=3)
    assert jsonify(d) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(d, True) == '''{
    "a": 1, 
    "b": 2, 
    "c": 3
}'''
    assert jsonify(None) == '{}'

# Generated at 2022-06-11 09:12:45.884980
# Unit test for function jsonify
def test_jsonify():
    result = { 'foo':'bar' }
    assert "{\"foo\": \"bar\"}" == jsonify(result)
    assert "{\n    \"foo\": \"bar\"\n}" == jsonify(result, True)

# Generated at 2022-06-11 09:12:47.704392
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'foo': 1}) == '{"foo": 1}'

# Generated at 2022-06-11 09:12:53.531754
# Unit test for function jsonify
def test_jsonify():
    result = {'foo': 'bar'}
    assert jsonify(result, format=False) == '{"foo": "bar"}'
    assert jsonify(result, format=True) == '{\n    "foo": "bar"\n}'

    result = ['foo', 'bar']
    assert jsonify(result, format=False) == '["foo", "bar"]'
    assert jsonify(result, format=True) == '[\n    "foo", \n    "bar"\n]'

# Generated at 2022-06-11 09:13:03.981445
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo':'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo':'bar', 'inky':'pinky'}) == '{"foo": "bar", "inky": "pinky"}'
    assert jsonify({'foo':'bar', 'inky':{'blinky':'pinky'}}) == '{"foo": "bar", "inky": {"blinky": "pinky"}}'

    assert jsonify({'foo':'bar'}, format=False) == '{"foo": "bar"}'
    assert jsonify({'foo':'bar', 'inky':'pinky'}, format=False) == '{"foo": "bar", "inky": "pinky"}'

# Generated at 2022-06-11 09:13:07.531141
# Unit test for function jsonify
def test_jsonify():
    data = {"a": 1, "b": 2}
    assert jsonify(data, format=False) == '{"a": 1, "b": 2}'
    assert jsonify(data, format=True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-11 09:13:48.060229
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a":1}) == '{"a": 1}'

# Generated at 2022-06-11 09:13:53.347598
# Unit test for function jsonify
def test_jsonify():
    assert '{"a": 1, "b": [2, 3]}' == jsonify(dict(a=1, b=[2,3]))
    # Make sure that ident=4 doesn't break anything
    assert '{\n    "a": 1, \n    "b": [\n        2, \n        3\n    ]\n}' == jsonify(dict(a=1, b=[2,3]), True)

# Generated at 2022-06-11 09:13:58.027799
# Unit test for function jsonify
def test_jsonify():
    result = { 'a': 1, 'b': 2, u'\u0105sc\u0103': u'unicode' }
    expected = '{"a": 1, "b": 2, "asc\u0103": "unicode"}'
    assert jsonify(result) == expected
    assert jsonify(result, format=True) == '{\n    "a": 1,\n    "asc\u0103": "unicode",\n    "b": 2\n}'

# Generated at 2022-06-11 09:14:05.231626
# Unit test for function jsonify
def test_jsonify():
    result = {'success': {}, 'dark': {}, 'failures': {}, 'unreachable': {}}
    assert jsonify(result) == '{"dark": {}, "failures": {}, "success": {}, "unreachable": {}}'

    result = {'success': {}, 'dark': {}, 'failures': {}, 'unreachable': {}}
    assert jsonify(result, True) == '{\n    "dark": {}, \n    "failures": {}, \n    "success": {}, \n    "unreachable": {}\n}'


# Generated at 2022-06-11 09:14:09.364856
# Unit test for function jsonify
def test_jsonify():
    result1 = jsonify({"foo":"bar"})
    assert result1 == '{"foo": "bar"}'
    result2 = jsonify(None)
    assert result2 == "{}"
    result3 = jsonify({"foo": "bar"}, format=True)
    assert result3 == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-11 09:14:12.594065
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-11 09:14:16.206467
# Unit test for function jsonify
def test_jsonify():
    assert '{\n    "foo": "bar",\n    "fuu": "baz"\n}' == jsonify({ "foo": "bar", "fuu": "baz"}, True)

# Generated at 2022-06-11 09:14:22.379020
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({u'a': u'中文', u'b': 2}) == u'{"a": "中文", "b": 2}'
    assert jsonify({"a": "中文", "b": 2}, format=True) == u'{\n    "a": "中文", \n    "b": 2\n}'
    assert jsonify({u"a": None}) == '{"a": null}'

# Generated at 2022-06-11 09:14:27.885202
# Unit test for function jsonify
def test_jsonify():

    # Test empty object
    result = jsonify(None)
    assert result == "{}"

    # Test simple object
    result = jsonify({ "a": 1, "b": 2 }, True)
    assert result == "{\"a\": 1, \"b\": 2}"

    # Test nested object
    result = jsonify({ "a": 1, "b": { "c": 2, "d": 3 } }, True)
    assert result == "{\n    \"a\": 1,\n    \"b\": {\n        \"c\": 2, \n        \"d\": 3\n    }\n}"

# Generated at 2022-06-11 09:14:35.870389
# Unit test for function jsonify
def test_jsonify():
    from ansible.playbook.play_context import PlayContext

    pc = PlayContext()
    orig = {'a': 'b', 'c': 2, 'd': ['a', 'b', 'c'], 'e': {'a': 'b', 'c': 2, 'd': ['a', 'b', 'c']}, 'f': pc}
    orig_json = jsonify(orig)
    orig_formatted = jsonify(orig, True)
    #print orig_json
    #print orig_formatted
    new = json.loads(orig_json)

    assert new == orig
    assert new != orig_formatted

    assert type(new['f']) == str
    assert type(pc.serialize()) == str

    assert pc == PlayContext(new['f'])