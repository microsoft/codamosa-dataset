

# Generated at 2022-06-11 09:04:41.369246
# Unit test for function jsonify
def test_jsonify():
    assert u'{"foo": 1, "bar": "baz", "\\u0410": "\\u0430"}' == jsonify({u'foo': 1, u'bar': u'baz', u'\u0410': u'\u0430'})
    assert u'{"foo": "bar"}' == jsonify({u'foo': u'bar'})
    assert u'{"foo": "bar"}' == jsonify({u'foo': u'bar'}, False)
    assert u'{\n    "foo": "bar"\n}' == jsonify({u'foo': u'bar'}, True)

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:04:43.014428
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1, "b": 2}, True) == "{\"a\": 1, \"b\": 2}"

# Generated at 2022-06-11 09:04:46.162093
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == "{}"
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, True) == '{\n    "a": "b"\n}'

# Generated at 2022-06-11 09:04:48.951403
# Unit test for function jsonify
def test_jsonify():
    ''' Unit tests for module AnsibleModule '''

    from ansible.utils.jsonify import jsonify

    assert jsonify(None) == '{}'

# Generated at 2022-06-11 09:05:02.228224
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_unicode
    result = {
        'a': 'this is a string',
        'b': 1,
        'c': 'this is some other string',
        'd': {
            'da': 2,
            'db': 'test',
            'dc': 'test2'
        },
        'e': [
            'list',
            'of',
            'strings'
        ]
    }

    plain = to_unicode(jsonify(result))
    pretty = to_unicode(jsonify(result, format=True))


# Generated at 2022-06-11 09:05:08.696940
# Unit test for function jsonify
def test_jsonify():
    ''' test_jsonify() - test the jsonify function '''

    assert(jsonify({'a': 1, 'b': 2}, format=True) == '''{
    "a": 1,
    "b": 2
}''')
    assert(jsonify({'a': 1, 'b': 2}) == '{"a":1,"b":2}')
    assert(jsonify(None) == '{}')



# Generated at 2022-06-11 09:05:18.639405
# Unit test for function jsonify
def test_jsonify():
    from collections import namedtuple
    TestCase = namedtuple('TestCase', ['obj', 'result_raw', 'result_formatted'])

# Generated at 2022-06-11 09:05:30.113432
# Unit test for function jsonify
def test_jsonify():

    import sys
    if sys.version_info[0] == 2:
        # python2 has no ensure_ascii parameter
        result = jsonify({"name": "ruссian"}, True)
        assert result == '{\n    "name": "ru\\\\u0441\\\\u0441ian"\n}'
        result = jsonify({"name": "ruссian"})
        assert result == '{"name": "ru\\\\u0441\\\\u0441ian"}'
        result = jsonify({"name": "test"})
        assert result == '{"name": "test"}'
        result = jsonify({"name": "test"}, True)
        assert result == '{\n    "name": "test"\n}'
        result = jsonify({"name": "test"}, False)

# Generated at 2022-06-11 09:05:36.632572
# Unit test for function jsonify
def test_jsonify():
    result = dict(test=dict(a='a',b='b',c=dict(a1='a1')))
    assert jsonify(result, format=False) == '{"test": {"a": "a", "b": "b", "c": {"a1": "a1"}}}'
    assert jsonify(result, format=True) == """{
    "test": {
        "a": "a",
        "b": "b",
        "c": {
            "a1": "a1"
        }
    }
}"""
    assert jsonify(None) == '{}'

# Generated at 2022-06-11 09:05:48.257493
# Unit test for function jsonify
def test_jsonify():
    struct = {'foo': [1,2,3], 'bar': "hello"}
    expected = "{\"bar\": \"hello\", \"foo\": [1, 2, 3]}"
    actual = jsonify(struct)
    assert expected == actual

    expected = "{\n    \"bar\": \"hello\", \n    \"foo\": [\n        1, \n        2, \n        3\n    ]\n}"
    actual = jsonify(struct, format=True)
    assert expected == actual

    # test utf-8
    struct = {'foo': [1,2,3], 'bar': "\xC0\xC1\xC2"}
    actual = jsonify(struct)
    assert expected != actual

# Generated at 2022-06-11 09:06:00.356930
# Unit test for function jsonify
def test_jsonify():
    result = {}
    result['hosts'] = ['foo']
    result['_ansible_version'] = "2.0.2.0"
    result['_ansible_no_log'] = False
    result['msg'] = "All items completed"
    result['results'] = [
        {
            "item": "10.20.30.40",
            "ping": "pong"
        }
    ]
    # Add unicode char in msg to test ascii
    result2 = {}
    result2['msg'] = u"Iñtërnâtiônàlizætiøn"

# Generated at 2022-06-11 09:06:05.218641
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'abc': '123', 'def': '456'}) == '{"abc": "123", "def": "456"}'
    assert jsonify({'abc': '123', 'def': '456'}, True) == '{\n    "abc": "123", \n    "def": "456"\n}'

# Generated at 2022-06-11 09:06:06.979135
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'

# Generated at 2022-06-11 09:06:13.002632
# Unit test for function jsonify
def test_jsonify():
    result1 = jsonify(None, False)
    result2 = jsonify(None, True)
    result3 = jsonify({}, False)
    result4 = jsonify({}, True)
    assert result1 == result3
    assert result1 == '{}'
    assert result2 == result4
    assert result2 == '{}'

# Generated at 2022-06-11 09:06:21.942248
# Unit test for function jsonify
def test_jsonify():

    from ansible.utils.jsonify import jsonify

    # Test invalid unicode values
    result = {'failed': False, 'msg': u'\u0a0a'}
    assert isinstance(result['msg'], unicode), "msg must be unicode"
    try:
        jsonify(result, format=False)
        assert False, "Expected json.dumps to fail"
    except UnicodeDecodeError:
        # We expect to fail here
        pass

    result = {'failed': False, 'msg': u'\u0a0a'}
    assert isinstance(result['msg'], unicode), "msg must be unicode"

# Generated at 2022-06-11 09:06:30.784421
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.json_utils import jsonify

    result = {"A": 12, "B": "does it work?"}
    json_out = jsonify(result,format=True)
    assert json_out == '{\n    "A": 12, \n    "B": "does it work?"\n}'
    json_out = jsonify(result,format=False)
    assert json_out == '{"A": 12, "B": "does it work?"}'
    # TODO: Add tests for when we're encoding unicode


# Generated at 2022-06-11 09:06:33.933548
# Unit test for function jsonify
def test_jsonify():
    ''' ensure the jsonify function behaves correctly '''

    data = {'foo': 'bar'}
    assert jsonify(data) == '{"foo": "bar"}'

    data = None
    assert jsonify(data) == "{}"

# Generated at 2022-06-11 09:06:36.059831
# Unit test for function jsonify
def test_jsonify():
    jsonify("dummy")
    jsonify(["dummy"], format=True)
    jsonify({"dummy": "dummy"})


# Generated at 2022-06-11 09:06:46.598260
# Unit test for function jsonify
def test_jsonify():

    from ansible.module_utils import basic

    result = {}
    result['foo'] = 1
    result['bar'] = 2
    rez = jsonify(result, format=False)
    basic.assert_equals('{"bar": 2, "foo": 1}', rez)

    rez = jsonify(result, format=True)
    basic.assert_equals('''{
    "bar": 2,
    "foo": 1
}''', rez)

    result = [ 1, 2, 3 ]
    rez = jsonify(result, format=False)
    basic.assert_equals('[1, 2, 3]', rez)

    rez = jsonify(result, format=True)

# Generated at 2022-06-11 09:06:50.268005
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_unicode
    test_data = [
        dict(
            inp="{{ 'foo' | to_json }}",
            out=b'{"foo": null}'
        ),
    ]
    for test in test_data:
        assert jsonify(to_unicode(test['inp'])) == test['out']

# Generated at 2022-06-11 09:07:02.795001
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'key1': 'value1', 'key2': 'value2'}, True) == \
        "{'key2': 'value2', 'key1': 'value1'}", "Test JSON format output failed"
    assert jsonify({}) == "{}", "Test JSON output failed"
    assert jsonify(None) == "{}", "Test JSON output failed"


# ============================================
# Subclass JSONEncoder to add support for dates
# ============================================

import datetime
import re
# import os
# import fnmatch
import ansible.constants as C
import sys
import types

if sys.version_info < (2, 6):
    try:
        import simplejson as json
    except ImportError:
        import json
else:
    import json


# Generated at 2022-06-11 09:07:07.609202
# Unit test for function jsonify
def test_jsonify():
    test_data = {'a': 1, 'b': 2, 'c': 3}
    assert(test_data == json.loads(jsonify(test_data)))
    assert('{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}' == jsonify(test_data, format=True))

# Generated at 2022-06-11 09:07:18.793472
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify
    from ansible.playbook.play import Play
    import json

    for ref in [None, {}, { 'foo':'bar', 'bam':'boo' }]:
        result = jsonify(ref, True)
        assert isinstance(result, str)
        assert json.loads(result) == ref
    for ref in [None, {}, { 'foo':'bar', 'bam':'boo' }]:
        result = jsonify(ref, False)
        assert isinstance(result, str)
        assert json.loads(result) == ref
    for ref in [None, {}, { 'foo':'bar', 'bam':'boo' }]:
        result = jsonify(ref)
        assert isinstance(result, str)

# Generated at 2022-06-11 09:07:28.416179
# Unit test for function jsonify
def test_jsonify():
    result = {
        "msg": "All items completed",
        "changed": False,
        "failed": False,
        "results": [
            {
                "ansible_facts": {
                    "discovered_interpreter_python": "/usr/bin/python"
                },
                "changed": False,
                "failed": False,
                "item": "localhost"
            }
        ]
    }
    # Formatting on

# Generated at 2022-06-11 09:07:32.567498
# Unit test for function jsonify
def test_jsonify():
    # Test default
    assert jsonify({'a': 'a'}) == '{"a": "a"}'
    # Test format
    assert jsonify({'a': 'a'}, True) == '{\n    "a": "a"\n}'
    # Test None return
    assert jsonify(None) == "{}"

# Generated at 2022-06-11 09:07:36.462274
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(dict(changed=False, failed=False, rc=0))
    assert isinstance(result, str)
    assert not result.startswith(' ')
    assert not result.endswith('\n')

# Generated at 2022-06-11 09:07:42.336652
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(['a','b','c']) == '["a", "b", "c"]'
    assert jsonify(['a','b','c'], format=True) == """\
[
    "a",
    "b",
    "c"
]"""


# Generated at 2022-06-11 09:07:46.305255
# Unit test for function jsonify
def test_jsonify():
    result = dict(changed=False, rc=0, stdout=[])
    assert jsonify(result, format=True) == '{\n    "changed": false, \n    "rc": 0, \n    "stdout": []\n}'

# Generated at 2022-06-11 09:07:53.424922
# Unit test for function jsonify
def test_jsonify():
    result = {
        "invocation": {
            "module_args": "",
            "module_name": "setup"
        },
        "changed": False,
        "ansible_facts": {
            "discovered_interpreter_python": "/usr/bin/python"
        },
        "_ansible_no_log": False,
        "failed": False,
        "ansible_facts_cacheable": True,
        "ansible_facts_cacheable_reason": "SAFE"
    }
    json_data = jsonify(result, format=True)

# Generated at 2022-06-11 09:07:57.594393
# Unit test for function jsonify
def test_jsonify():
    result = dict(a=1,b=2,c=3,d=dict(x=4,y=5,z=6))
    assert jsonify(result) == '{"a": 1, "b": 2, "c": 3, "d": {"x": 4, "y": 5, "z": 6}}'

# Generated at 2022-06-11 09:08:13.050811
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import AnsibleModule
    import platform
    if platform.system() == 'Windows':
        from nose.plugins.skip import SkipTest
        raise SkipTest("jsonify test not yet implemented for Windows")

    result_in = dict(changed=False, rc=1, stdout=None, stderr="error", failed=True)
    result_out = jsonify(result_in, True)
    result_dict = AnsibleModule(json.loads(result_out))

    assert result_dict['stdout'] is None
    assert result_dict['stderr'] == "error"
    assert result_dict['failed']
    assert result_dict['changed']


# Generated at 2022-06-11 09:08:16.652836
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None, True) == "{}"
    assert jsonify(None, False) == "{}"
    assert jsonify({}, True) == "{}"
    assert jsonify({}, False) == "{}"
    assert jsonify({"a": "b"}, True) == "{\n    \"a\": \"b\"\n}"
    assert jsonify({"a": "b"}, False) == "{\"a\": \"b\"}"

# Generated at 2022-06-11 09:08:28.124798
# Unit test for function jsonify
def test_jsonify():

    # jsonify()
    res1 = jsonify(None)
    assert res1 == "{}"
    res2 = jsonify({"1":  2})
    assert res2 == '{"1": 2}'

    # jsonify(format=False)
    res3 = jsonify(None, False)
    assert res3 == "{}"
    res4 = jsonify({"1":  2}, False)
    assert res4 == '{"1": 2}'

    # jsonify(format=True)
    res5 = jsonify(None, True)
    assert res5 == """{}"""
    res6 = jsonify({"1":  2}, True)
    assert res6 == """{
    "1": 2
}"""
    res7 = jsonify({"1":  2, "3":  4}, True)

# Generated at 2022-06-11 09:08:34.753830
# Unit test for function jsonify
def test_jsonify():
    print(jsonify(None, True))
    print(jsonify({'a': 1, 'b': 2}, True))
    print(jsonify(dict(a=1,b=2), True))
    print(jsonify(dict(changed=True, failed=False, rc=0, results=['test']), True))
    print(jsonify(dict(a=1, b=dict(c=2, d=3)), True))


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:08:42.038963
# Unit test for function jsonify
def test_jsonify():
    import os

    tmpfile = os.path.join(os.path.dirname(__file__), '../../test/output/jsonify.out')
    d = dict(spam=42, eggs=dict(a='a', b='b'))
    out = open(tmpfile,'w')
    out.write(jsonify(d, True))
    out.close()

    out = open(tmpfile,'r')
    out.readline()
    out.readline()
    assert out.readline() == '        "eggs": {\n'
    out.close()
    os.unlink(tmpfile)

# Generated at 2022-06-11 09:08:46.261699
# Unit test for function jsonify
def test_jsonify():
    """Test function jsonify"""
    assert jsonify(None) == "{}"
    assert jsonify({u'foo': [1, 2, 3]})
    assert jsonify({"foo": "bar\u2026"})

# Generated at 2022-06-11 09:08:50.457454
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify()'''
    assert jsonify({'cow': "moo", 'pig': "oink"}) == '{"cow": "moo", "pig": "oink"}'


# Generated at 2022-06-11 09:08:58.018115
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    assert jsonify(None) == 'null'
    assert jsonify([1,2,3]) == '[1, 2, 3]'
    assert jsonify({'foo':'bar', 'baz':'qux'}) == '{"baz": "qux", "foo": "bar"}'
    assert jsonify({'foo':'bar', 'baz':None}) == '{"baz": null, "foo": "bar"}'
    assert jsonify({'foo':'bar', 'baz':{'a':'b'}}) == '{"baz": {"a": "b"}, "foo": "bar"}'
    assert jsonify([1, None, 3]) == '[1, null, 3]'

# Generated at 2022-06-11 09:09:05.268770
# Unit test for function jsonify
def test_jsonify():
    result = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 'four',
        }
    }
    assert jsonify(result, False) == '''{"a": 1, "b": 2, "c": {"d": 3, "e": "four"}}'''
    assert jsonify(result, True) == '''{
    "a": 1,
    "b": 2,
    "c": {
        "d": 3,
        "e": "four"
    }
}'''

# Generated at 2022-06-11 09:09:08.792104
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({
        "a": 1,
        "b": 2,
        "c": 3,
    },
    True)
    print(result)

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:09:22.318002
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'
    assert jsonify({'foo': 'bar'}, False) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar', 'baz': None}, False) == '{"baz": null, "foo": "bar"}'

# Generated at 2022-06-11 09:09:27.595870
# Unit test for function jsonify
def test_jsonify():
    class FakeModule:
        pass

    result = {'rc': 0}

    fn = jsonify(result)
    assert fn == "{\"rc\": 0}"

    fn = jsonify(result, True)
    assert fn == "{\n    \"rc\": 0\n}"


if __name__ == "__main__":
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-11 09:09:29.353641
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should return an empty string for None '''
    assert jsonify(None) == "{}"


# Generated at 2022-06-11 09:09:36.528683
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({}) == '{}'
    assert jsonify({}, True) == '{}'
    assert "{}" in jsonify({'a': 1})
    assert jsonify({'a': 1}, True) == "{'a': 1}"
    assert '\\u' not in jsonify({'a': u'\u00e9'})
    assert jsonify({'a': u'\u00e9'}, True) == "{'a': '\xe9'}"

# Generated at 2022-06-11 09:09:44.379236
# Unit test for function jsonify
def test_jsonify():
    # Test without indent
    assert jsonify({
        'b': [4, 5, 6],
        'a': [1, 2, 3]
    }) == '{"a": [1, 2, 3], "b": [4, 5, 6]}'

    # Test with indent
    assert jsonify({
        'b': [4, 5, 6],
        'a': [1, 2, 3]
    }, format=True) == '''{
    "a": [
        1,
        2,
        3
    ],
    "b": [
        4,
        5,
        6
    ]
}'''

    # Test with empty result
    assert jsonify(None) == '{}'

# Generated at 2022-06-11 09:09:45.637304
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(dict(changed=True, rc=0)) == '{"changed": true, "rc": 0}'

# Generated at 2022-06-11 09:09:56.869685
# Unit test for function jsonify
def test_jsonify():
    test_result = { 
        "a": 1, 
        "b": 1.1, 
        "c": "hello", 
        "d": { "d1": [1,2,3] },
        "e": None
    }

    test_result_compressed = '{"a":1,"b":1.1,"c":"hello","d":{"d1":[1,2,3]},"e":null}'
    test_result_format = '''{
    "a": 1,
    "b": 1.1,
    "c": "hello",
    "d": {
        "d1": [
            1,
            2,
            3
        ]
    },
    "e": null
}'''

    assert jsonify(test_result) == test_result_compressed
    assert json

# Generated at 2022-06-11 09:10:05.605326
# Unit test for function jsonify
def test_jsonify():
    # Python 2:
    assert "{}" == jsonify(None)
    assert json.dumps({'x': 1, 'y': 2}, indent=4, sort_keys=True) == jsonify({u'x': 1, u'y': 2}, format=True)
    # Python 3:
    assert "{}" == jsonify(None)
    assert json.dumps({'x': 1, 'y': 2}, indent=4, sort_keys=True, ensure_ascii=False) == jsonify({'x': 1, 'y': 2}, format=True)
    # Also works on Python 3 when some value is unicode:

# Generated at 2022-06-11 09:10:16.617499
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import basic

    unformatted_result = {'foo': 'bar',
                          'baz': 'qux',
                          'tasks': {'a': 'b', 'c': 'd'},
                          'results': [{'1': '2', '3': '4'}, {'5': '6'}, '7', '8']}


# Generated at 2022-06-11 09:10:24.697935
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(1) == '1'
    assert jsonify(True) == 'true'
    assert jsonify(None) == '{}'
    assert jsonify({}) == '{}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify(['foo', 'bar']) == '["foo", "bar"]'
    assert jsonify([{'foo': 'bar'}, {'foo': 'baz'}]) == '[{"foo": "bar"}, {"foo": "baz"}]'

# Generated at 2022-06-11 09:10:47.069685
# Unit test for function jsonify
def test_jsonify():

    test_data = dict(
        stdout='stdout output',
        stdout_lines=['stdout', 'output', 'lines'],
        stderr='stderr output',
        stderr_lines=['stderr', 'output', 'lines'],
        msg='Some random message',
        rc=0,
        changed=False
    )

    assert jsonify(test_data) == '{"changed": false, "rc": 0, "stderr": "stderr output", "stderr_lines": ["stderr", "output", "lines"], "stdout": "stdout output", "stdout_lines": ["stdout", "output", "lines"], "msg": "Some random message"}'


# Generated at 2022-06-11 09:10:48.557483
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(None)
    assert result == "{}"

    result = jsonify({'a': 'b'})
    assert result == '{"a": "b"}'

# Generated at 2022-06-11 09:10:51.844282
# Unit test for function jsonify
def test_jsonify():
    result = {"a": "b",
              "c": {"d": "e",
                    "f": "g"
                   }
             }
    assert jsonify(result, format=True) == """{
    "a": "b",
    "c": {
        "d": "e",
        "f": "g"
    }
}"""

# Generated at 2022-06-11 09:10:55.823781
# Unit test for function jsonify
def test_jsonify():
    assert '"foo"' in jsonify(dict(foo='bar'))
    # ini-style formatting
    assert '{\n    "foo": "bar"\n}' in jsonify(dict(foo='bar'), format=True)

# Generated at 2022-06-11 09:10:59.832901
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(failed=False, changed=False)) == '{"changed": false, "failed": false}'
    assert jsonify(dict(failed=False, changed=False, meta=dict(foo='bar'))) == '{"changed": false, "failed": false, "meta": {"foo": "bar"}}'

# Generated at 2022-06-11 09:11:10.624886
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(False) == 'false'
    assert jsonify(True) == 'true'
    assert jsonify({}) == '{}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': ['a', 'b']}) == '{"a": ["a", "b"]}'
    assert jsonify({'failed': False}) == '{"failed": false}'
    assert jsonify({'failed': False, 'changed': True}) == '{"changed": true, "failed": false}'
    assert jsonify({'changed': True}) == '{"changed": true}'

# Generated at 2022-06-11 09:11:17.065083
# Unit test for function jsonify
def test_jsonify():
    ''' test_jsonify '''
    assert jsonify(None, format=True) == "{}"
    assert jsonify({'foo': 'bar'}, format=True) == "{\"foo\": \"bar\"}"
    assert jsonify({'foo': 'bar'}, format=False) == '{"foo": "bar"}'

    try:
        jsonify({'foo': u'bar'}, format=False)
    except UnicodeDecodeError:
        return
    raise AssertionError("Failed to jsonify")

# Generated at 2022-06-11 09:11:18.920792
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == "{}"
    assert jsonify({'hello': 'world'}) == '{"hello": "world"}'

# Generated at 2022-06-11 09:11:20.951311
# Unit test for function jsonify
def test_jsonify():

    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'

# Generated at 2022-06-11 09:11:23.612733
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'
    assert jsonify({"a":1}) == '{"a": 1}'
    assert jsonify([1,2,3]) == '[1, 2, 3]'

# Generated at 2022-06-11 09:11:43.992980
# Unit test for function jsonify
def test_jsonify():
    result = {'b': 2, 'a': 1}
    assert jsonify(result) == '{"a": 1,\n"b": 2}'

# Generated at 2022-06-11 09:11:50.162263
# Unit test for function jsonify
def test_jsonify():

    # none input, empty json
    assert jsonify(None) == "{}"

    # simple data, empty json
    assert jsonify({}) == "{}"
    assert jsonify([]) == "[]"

    # object in object
    assert jsonify({ "a": { "b": 1 } }) == '{"a": {"b": 1}}'

    # format is off by default
    assert jsonify({ "a": { "b": 1 } }) == '{"a": {"b": 1}}'

    # format is on when asked
    assert jsonify({ "a": { "b": 1 } }, format=True) == '{\n    "a": {\n        "b": 1\n    }\n}'

# Generated at 2022-06-11 09:11:53.306681
# Unit test for function jsonify
def test_jsonify():
    test = {'a': 2, 'b': 'foo'}
    print(jsonify(test, format=True))
    print(jsonify(test, format=False))


#test_jsonify()

# Generated at 2022-06-11 09:11:59.181281
# Unit test for function jsonify
def test_jsonify():
    assert '{"foo": "bar"}' == jsonify({'foo': 'bar'})
    assert "{}" == jsonify(None)
    assert '{"foo": "bar"}' == jsonify({'foo': 'bar'}, format=True)
    assert "{}\n" == jsonify(None, format=True)

# Generated at 2022-06-11 09:12:03.201054
# Unit test for function jsonify
def test_jsonify():
    result = {'foo':'bar'}
    assert(jsonify(result) == '{"foo": "bar"}')
    assert(jsonify(result, format=True) == '{\n    "foo": "bar"\n}')

# Generated at 2022-06-11 09:12:07.176206
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"some": "thing"}) == '{"some": "thing"}'
    assert jsonify({"some": "thing"}, format=True) == '{\n    "some": "thing"\n}'

# Generated at 2022-06-11 09:12:12.949075
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify({"a": 1, "b": 2, "c": 3}, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'
    assert jsonify(None) == '{}'
    assert jsonify(None, True) == '{}'

# Generated at 2022-06-11 09:12:23.199590
# Unit test for function jsonify
def test_jsonify():

    # Test jsonify with format=False
    # Check for empty string
    assert jsonify(None) == "{}"

    # Check for one item tuple
    assert jsonify("hello") == "\"hello\""

    # Check for two item tuple
    assert jsonify(("hello", "world")) == "[\"hello\", \"world\"]"

    # Check for base64 encoded string
    assert jsonify("aGVsbG8=") == "\"aGVsbG8=\""

    # Check for boolean True
    assert jsonify(True) == "true"

    # Check for boolean False
    assert jsonify(False) == "false"

    # Check for float
    assert jsonify(float(123.456)) == "123.456"

    # Check for integer
    assert jsonify(123) == "123"

    # Check for long


# Generated at 2022-06-11 09:12:26.712951
# Unit test for function jsonify
def test_jsonify():
    print('Testing jsonify')
    print('Should return {}')
    assert jsonify(None) == "{}"

    print('Should return {"a": "b"}')
    assert jsonify({'a': 'b'}) == '{"a": "b"}'

# Generated at 2022-06-11 09:12:35.645223
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify() with non-ascii, indented, and raw '''

    # non-ascii
    ans_dict = {"unicode_text": u"\u05d0\u05d9\u05df"}
    test_string = '{"unicode_text": "אין"}'
    test_string = test_string.encode('utf-8')
    assert jsonify(ans_dict) == test_string, "non-ascii formatting failed"

    # indented
    ans_dict = {"unicode_text": u"\u05d0\u05d9\u05df", "nested_dict": {}}
    test_string = u'{\n    "nested_dict": {}, \n    "unicode_text": "אין"\n}'
   

# Generated at 2022-06-11 09:13:18.035326
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'


# Generated at 2022-06-11 09:13:21.619155
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(foo='bar')) == '{"foo": "bar"}'
    assert jsonify(dict(foo=[1,2,3])) == '{"foo": [1, 2, 3]}'

# Generated at 2022-06-11 09:13:28.107271
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify'''
    test_data = {'a': 'test', 'b': {'c': 'test2'}}
    assert jsonify(test_data) == '{"a": "test", "b": {"c": "test2"}}'
    assert jsonify(test_data, format=True) == '{\n    "a": "test", \n    "b": {\n        "c": "test2"\n    }\n}'
    assert jsonify(None) == '{}'

# Generated at 2022-06-11 09:13:30.767607
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({"a": 1})
    assert result == '{ "a": 1 }'

    result = jsonify({"a": 1}, True)
    assert result == '{ "a": 1 }'

# Generated at 2022-06-11 09:13:37.915924
# Unit test for function jsonify
def test_jsonify():
    '''Test the format and indentation of JSON output'''


# Generated at 2022-06-11 09:13:45.670605
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(dict(a=2,b=3)) == '{"a": 2, "b": 3}'
    assert jsonify(dict(a=2,b=3), True) == '{\n    "a": 2, \n    "b": 3\n}'
    assert jsonify(dict(a=2,b=3)) == jsonify(dict(b=3,a=2))

# Generated at 2022-06-11 09:13:49.935076
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify
    from ansible.module_utils import basic

    # test None
    assert jsonify(None) == '{}'

    # test dict
    result = dict(a=1, b=2)
    assert jsonify(result) == '{"a": 1, "b": 2}'
    assert jsonify(result, format=True) == '{\n    "a": 1,\n    "b": 2\n}\n'

    # test basic.AnsibleModule
    am = basic.AnsibleModule(argument_spec=dict())
    assert json.loads(jsonify(am.fail_json(msg='hi')))['msg'] == 'hi'
    assert json.loads(jsonify(am.exit_json(changed=True)))['changed']

    # test dict with

# Generated at 2022-06-11 09:13:54.255841
# Unit test for function jsonify
def test_jsonify():
    result = dict(a=1,b=2)
    result_formatted = jsonify(result, True)
    assert result_formatted == '{\n    "a": 1,\n    "b": 2\n}'

    result_unformatted = jsonify(result, False)
    assert result_unformatted == '{"a": 1, "b": 2}'

# Generated at 2022-06-11 09:14:03.164259
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1, 'b': 2}) in [
        '{"a": 1, "b": 2}',
        '{"b": 2, "a": 1}',
    ]
    assert jsonify({'a': 1, 'b': 2}, format=True) in [
        '{\n    "a": 1, \n    "b": 2\n}',
        '{\n    "b": 2, \n    "a": 1\n}',
    ]

# Generated at 2022-06-11 09:14:06.834589
# Unit test for function jsonify
def test_jsonify():

    results = []
    results.append(jsonify({"a": 1}))
    results.append(jsonify({"a": 1}, format=True))

    assert results[0] == '{"a": 1}'
    assert results[1] == '{\n    "a": 1\n}'