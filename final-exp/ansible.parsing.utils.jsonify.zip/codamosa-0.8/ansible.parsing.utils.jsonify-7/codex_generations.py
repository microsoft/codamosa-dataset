

# Generated at 2022-06-11 09:04:41.162878
# Unit test for function jsonify
def test_jsonify():
    ''' Test function jsonify '''

    # test whether jsonify converts dict to json
    result = jsonify({"key": "value"}, False)
    assert(result == '{"key": "value"}')

    # test whether jsonify converts dict to json with indent
    result = jsonify({"key": "value"}, True)
    assert(result == '{\n    "key": "value"\n}')

    # test whether jsonify converts list to json
    result = jsonify(["key", "value"], False)
    assert(result == '["key", "value"]')

    # test whether jsonify converts list to json with indent
    result = jsonify(["key", "value"], True)
    assert(result == '[\n    "key", \n    "value"\n]')

    # test whether jsonify converts string to json

# Generated at 2022-06-11 09:04:52.026724
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"b": 2, "a": 1}) == '{"a": 1, "b": 2}'
    assert jsonify({"b": 2, "a": 1}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-11 09:04:53.469537
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == "{}"


# Generated at 2022-06-11 09:04:57.299273
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify("foobar") == "\"foobar\""
    assert jsonify({"foo": "bar"}) == "{\"foo\": \"bar\"}"

# Generated at 2022-06-11 09:05:08.342598
# Unit test for function jsonify
def test_jsonify():
    assert jsonify("foo") == '"foo"'
    assert jsonify(1) == "1"
    assert jsonify(1) != "\"1\""
    assert jsonify({"foo":"bar"}) == '{"foo": "bar"}'
    assert jsonify({"foo":"bar"}) != '{"foo":"bar"}'
    assert jsonify(["foo","bar"]) == '["foo", "bar"]'
    assert jsonify(["foo","bar"]) != '["foo","bar"]'

    assert jsonify({"foo":"bar"}, True) == '{\n    "foo": "bar"\n}'
    assert jsonify({"foo":"bar"}, False) == '{"foo": "bar"}'

# Generated at 2022-06-11 09:05:10.953820
# Unit test for function jsonify
def test_jsonify():
    ''' Test that jsonify does what it does '''
    s = jsonify(dict(a=1))
    assert json.loads(s) == dict(a=1)
# --


# Generated at 2022-06-11 09:05:21.391071
# Unit test for function jsonify
def test_jsonify():
    '''
    jsonify: return json string from given data structure.
    '''
    origin = {'a': 'b', 'c': 'd'}
    result = None
    assert jsonify(result, format=False) == "{}"

    result = origin
    ret = jsonify(result, format=False)
    assert ret == '{"a": "b", "c": "d"}' or ret == '{"c": "d", "a": "b"}'

    ret = jsonify(result, format=True)
    assert ret == '{\n    "a": "b", \n    "c": "d"\n}' or ret == '{\n    "c": "d", \n    "a": "b"\n}'


# Generated at 2022-06-11 09:05:27.236907
# Unit test for function jsonify
def test_jsonify():
    res = {'foo': 'bar'}
    assert jsonify(res) == "{\"foo\": \"bar\"}"
    assert jsonify(res, True) == "{\n    \"foo\": \"bar\"\n}"
    assert jsonify(res, None) == "{\"foo\": \"bar\"}"
    assert jsonify(None) == "{}"

# Generated at 2022-06-11 09:05:36.315703
# Unit test for function jsonify
def test_jsonify():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    t = Task()
    t.name = 'test'
    t.action = 'shell echo "test"'
    b = Block()
    b.block  = [ t ]
    r = Role()
    r.name = 'test'
    r.block = b
    p = Play()
    p.name = 'test'
    p.hosts = 'all'
    h = Handler()
    h.name = 'test'
    h.notify = [ b ]
    p.handlers = [ h ]
    p.block = b
    p.post_validate

# Generated at 2022-06-11 09:05:48.085007
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(False) == 'false'
    assert jsonify(0) == '0'
    assert jsonify(1) == '1'
    assert jsonify('foo') == '"foo"'
    assert jsonify([1, 2]) == '[1, 2]'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar', 'baz': [1, 2, 3]}) == '{"baz": [1, 2, 3], "foo": "bar"}'

    assert jsonify(None, format=True) == '{}'
    assert jsonify(False, format=True) == 'false'
    assert jsonify(0, format=True) == '0'

# Generated at 2022-06-11 09:05:52.778761
# Unit test for function jsonify
def test_jsonify():
    ''' unit test for jsonify '''
    from ansible.utils.jsonify import jsonify

    assert jsonify({'test': 'test'}, format=True) == '{\n    "test": "test"\n}'

# Generated at 2022-06-11 09:05:54.251440
# Unit test for function jsonify
def test_jsonify():
    ''' return a test object that jsonify() can use '''
    return "unit test"

# Generated at 2022-06-11 09:05:57.412022
# Unit test for function jsonify
def test_jsonify():
    ''' test for function jsonify '''
    import ansible.utils
    result = {'fist_key': 'foo', 'second_key': ['first', 'second']}
    assert result == ansible.utils.jsonify(result, format=False)

# Generated at 2022-06-11 09:06:00.916792
# Unit test for function jsonify
def test_jsonify():
    ''' test_jsonify '''

    jsonify_fields = dict()

    for field in ('results', 'msg', 'stats', 'invocation'):
        jsonify_fields[field] = 'just a test'

    assert "\n" not in jsonify(jsonify_fields)
    assert "\n" in jsonify(jsonify_fields, True)

# Generated at 2022-06-11 09:06:02.187353
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo='bar')) == '{"foo": "bar"}'

# Generated at 2022-06-11 09:06:11.214501
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should return a valid JSON string '''

    assert jsonify(None) == "{}"
    assert jsonify({'hello': 'world'}) == "{\"hello\": \"world\"}"
    assert jsonify({'a': {'a1': 'v1'}, 'b': 'v2'}) == "{\"a\": {\"a1\": \"v1\"}, \"b\": \"v2\"}"
    assert jsonify("\xac") == "\"\\u00ac\""

# Generated at 2022-06-11 09:06:16.570980
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == '{}', "JSON object without any keys"

    assert jsonify({"a": "b"}) == '{"a": "b"}', "JSON object with a single key"

    assert jsonify(dict(a=1,b=2), True) == '{\n    "a": 1, \n    "b": 2\n}', "JSON object with a single key"


# Generated at 2022-06-11 09:06:21.265532
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == "{}"
    assert jsonify({"a": "b"}) == '{"a": "b"}'

    # Unicode decode errors can occur due to utf-8 encoding
    # Issue #9201
    assert jsonify({"a": u"\u4e2d\u6587"}) == unicode('{"a": "\u4e2d\u6587"}')

# Generated at 2022-06-11 09:06:23.866069
# Unit test for function jsonify
def test_jsonify():
    ''' unit test for function jsonify '''

    assert jsonify(None) == '{}'

    # FIXME: perhaps expand the test coverage?

# Generated at 2022-06-11 09:06:33.389430
# Unit test for function jsonify
def test_jsonify():
    input = {'a': {'b': 'c'}, 'b': 'c', 'c': None, 'd': 1}
    assert jsonify(result=input, format=True) == """{
    "a": {
        "b": "c"
    },
    "b": "c",
    "c": null,
    "d": 1
}"""
    assert jsonify(result=input, format=False) == '{"a":{"b":"c"},"b":"c","c":null,"d":1}'
    assert jsonify(result=None, format=False) == '{}'
    assert jsonify(result=None, format=True) == '{}'

# Generated at 2022-06-11 09:06:45.203212
# Unit test for function jsonify
def test_jsonify():
    # following unicode characters are utf-32 encoded
    test_unicode_in  = u'\U0001F4A9'
    test_unicode_out = '"\xf0\x9f\x92\xa9"'

    test_datetime = datetime(1970, 1, 1)

    # unicode string
    test_string = { 'foo': test_unicode_in }
    assert jsonify(test_string) == '{"foo": "%s"}' % test_unicode_in

    # unicode string dumped as json
    test_string = { 'foo': test_unicode_in }
    assert jsonify(test_string, format=True) == '{\n    "foo": "%s"\n}' % test_unicode_in

    # datetime object

# Generated at 2022-06-11 09:06:51.986763
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_unicode
    from ansible.utils import py26_compat

    test_dict1 = {'foo': 'bar'}
    test_dict2 = {u'baz': 'qux'}
    assert to_unicode(jsonify(test_dict1, True)) == to_unicode('{\n    "foo": "bar"\n}')
    assert to_unicode(jsonify(test_dict1, False)) == to_unicode('{"foo": "bar"}')
    assert to_unicode(jsonify(test_dict2, True)) == to_unicode('{\n    "baz": "qux"\n}')

# Generated at 2022-06-11 09:06:53.643061
# Unit test for function jsonify
def test_jsonify():
    result = {'a': 3}
    assert jsonify(result, format=False) == "{\"a\": 3}"

# Generated at 2022-06-11 09:06:58.525317
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1, "b": 2}) == "{\"a\": 1, \"b\": 2}"
    assert jsonify({"a": 1, "b": 2}, format=True) == "{\n    \"a\": 1, \n    \"b\": 2\n}"
    assert jsonify(None, format=True) == "{}"

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-11 09:07:00.005964
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'

# Generated at 2022-06-11 09:07:10.228187
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_unicode

    simple_dict = { 'ansible': 'awesome' }
    formatted_dict = to_unicode(jsonify(simple_dict, format=True))
    assert formatted_dict == u'{\n    "ansible": "awesome"\n}'

    simple_list = [ 1, 2, 3, { 'ansible': 'awesome' } ]
    formatted_list = to_unicode(jsonify(simple_list, format=True))
    assert formatted_list == u'[\n    1,\n    2,\n    3,\n    {\n        "ansible": "awesome"\n    }\n]'

    # Test string with non-ascii character, test for unicode output

# Generated at 2022-06-11 09:07:17.296496
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify

    assert(jsonify({},True) == '{\n    \n}')
    assert(jsonify(None,True) == '{}')
    assert(jsonify(None,False) == '{}')
    assert(jsonify({'foo':'bar'},True) == '{\n    "foo": "bar"\n}')
    assert(jsonify({'foo':'bar'},False) == '{"foo": "bar"}')

# Generated at 2022-06-11 09:07:22.099616
# Unit test for function jsonify
def test_jsonify():
    # test empty
    assert jsonify({}) == '{}'
    # test not empty
    assert jsonify({'test': 'test'}) == '{"test": "test"}'
    # test format
    assert jsonify({'test': 'test'}, format=True) == '{\n    "test": "test"\n}'

# Generated at 2022-06-11 09:07:28.717399
# Unit test for function jsonify
def test_jsonify():
    result = { 'a': 1, 'b': 2, 'c': 3 }
    assert(jsonify(result, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}')
    assert(jsonify(result, False) == '{"a": 1, "b": 2, "c": 3}')
    assert(jsonify(None, False) == '{}')
    assert(jsonify(None, True) == '{}')

if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-11 09:07:32.476608
# Unit test for function jsonify
def test_jsonify():
    result = dict(changed=True, rc=0)
    assert(jsonify(result, format=True) == "{\"changed\": true, \"rc\": 0}")
    assert(jsonify(result, format=False) == "{\"changed\": true, \"rc\": 0}")

# Generated at 2022-06-11 09:07:47.238845
# Unit test for function jsonify
def test_jsonify():
    # test a normal return
    cmd = "foo"
    rc = 0
    stdout = "bar"
    stderr = "baz"
    result = dict(cmd=cmd, rc=rc, stdout=stdout, stderr=stderr)
    assert jsonify(result) == '{"cmd": "foo", "rc": 0, "stdout": "bar", "stderr": "baz"}'

    # test an error
    cmd = "foo"
    rc = 1
    stdout = "bar"
    stderr = "baz"
    result = dict(cmd=cmd, rc=rc, stdout=stdout, stderr=stderr)

# Generated at 2022-06-11 09:07:52.046860
# Unit test for function jsonify
def test_jsonify():
    """ Unit tests for jsonify """
    results = { "success": True, "foo": "hello" }
    assert jsonify(results) == "{\"foo\": \"hello\", \"success\": true}"
    assert jsonify(results, format=True) == "{\n    \"foo\": \"hello\",\n    \"success\": true\n}"
    assert jsonify(None) == "{}"

# Generated at 2022-06-11 09:07:59.548826
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'
    assert jsonify([1, 2, 3], format=True) == "[\n    1, \n    2, \n    3\n]"
    assert jsonify({"k": [1, 2, 3]}, format=True) == "{\"k\": [\n    1, \n    2, \n    3\n]}"
    assert jsonify({"k": "\u3053"}, format=True) == '{\"k\": "\u3053"}'


# Generated at 2022-06-11 09:08:10.090716
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify
    from ansible.compat.tests import unittest

    class TestJsonify(unittest.TestCase):

        def test_jsonify(self):
            result = {'test': 123, 'test2': {'test3': 'test4'}}

            self.assertEqual(jsonify(result), '{"test": 123, "test2": {"test3": "test4"}}')
            self.assertEqual(jsonify(result, format=True), '''{
    "test": 123,
    "test2": {
        "test3": "test4"
    }
}''')
            self.assertEqual(jsonify(None), '{}')

# Generated at 2022-06-11 09:08:18.065877
# Unit test for function jsonify

# Generated at 2022-06-11 09:08:24.039523
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(dict(foo='bar'))
    assert result == '{"foo": "bar"}'
    result = jsonify(dict(foo='bar'), format=True)
    assert result == '{\n    "foo": "bar"\n}'
    result = jsonify(dict(foo='bar', uni='\u3042'))
    assert result == '{"foo": "bar", "uni": "\\u3042"}'

# Generated at 2022-06-11 09:08:32.503077
# Unit test for function jsonify
def test_jsonify():
    ''' Ensure that jsonify works correctly '''
    result = { 'a': 'b', 'c': { 'd': [1,2,3] } }
    assert jsonify(result, False) == '{"a": "b", "c": {"d": [1, 2, 3]}}'
    assert jsonify(result, True) == '{\n    "a": "b",\n    "c": {\n        "d": [\n            1,\n            2,\n            3\n        ]\n    }\n}'

# Generated at 2022-06-11 09:08:37.224948
# Unit test for function jsonify
def test_jsonify():
    json_struct = {
        'one': 1,
        'two': [1, 2, 3, 4],
        'three': {
            'A': 'a',
            'B': 'b',
        }
    }
    assert(jsonify(json_struct) == json.dumps(json_struct))
    assert(jsonify(json_struct, format=True) == json.dumps(json_struct, indent=4))

# Generated at 2022-06-11 09:08:40.909066
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'
    assert jsonify({}, format=True) == '{\n}'

# Unit tests for class BaseJsonModule
import unittest

from ansible.module_utils.basic import AnsibleModule
import ansible.module_utils.basic


# Generated at 2022-06-11 09:08:44.451680
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(dict(foo='bar')) == '{"foo": "bar"}'

# Generated at 2022-06-11 09:08:53.759815
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    s = jsonify(dict(a=dict(b=AnsibleUnsafeText(u'\u1234'))))
    assert isinstance(s, str)
    assert u'\u1234' in s

# Generated at 2022-06-11 09:08:56.459853
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo="bar")) == '{"foo": "bar"}'
    assert jsonify(dict(foo="bar"), True) == '''{
    "foo": "bar"
}'''


# Generated at 2022-06-11 09:08:59.486090
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == jsonify({})
    assert jsonify({'foo':'bar'}) == "{\"foo\": \"bar\"}"
    assert jsonify({'foo':'bar'}, format=True) == "{\n    \"foo\": \"bar\"\n}"

# Generated at 2022-06-11 09:09:01.956486
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a':1}) == '{"a": 1}'
    assert jsonify({'a':1}, True) == '''{
    "a": 1
}'''

# Generated at 2022-06-11 09:09:12.764992
# Unit test for function jsonify
def test_jsonify():
    data = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': 5
    }
    formatted = jsonify(data, True)
    assert formatted == '''{
    "a": 1,
    "b": 2,
    "c": 3,
    "d": 4,
    "e": 5
}'''
    unformatted = jsonify(data)
    assert unformatted == '{"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}'

    if formatted != unformatted:
        assert 'minify' in unformatted
        assert 'minify' not in formatted

    assert jsonify(None) == "{}"

# Generated at 2022-06-11 09:09:19.954079
# Unit test for function jsonify
def test_jsonify():
    result = '''
{
    "changed": false,
    "ping": "pong"
}'''
    assert result == jsonify({'changed': False, 'ping': 'pong'}, True)
    json_result = '''
    {
        "changed": false,
        "ping": "pong"
    }'''.replace('\n', '').replace(' ', '')
    assert json_result == jsonify({'changed': False, 'ping': 'pong'})

# Generated at 2022-06-11 09:09:26.110824
# Unit test for function jsonify
def test_jsonify():
    d = { 'a': 1 }
    assert jsonify(d, True) == '{\n    "a": 1\n}'

    d = { 'a': 1 }
    assert jsonify(d) == '{"a": 1}'

    d = None
    assert jsonify(d) == "{}"

    d = { 'a': '\xe9' }
    assert jsonify(d, True) == u'{\n    "a": "\\u00e9"\n}'

    d = { 'a': '\xe9' }
    assert jsonify(d) == u'{"a": "\xe9"}'


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:09:36.395781
# Unit test for function jsonify
def test_jsonify():
    result = {
        '_ansible_delegated_vars': {},
        '_ansible_no_log': False,
        '_ansible_parsed': True,
        '_ansible_verbose_always': True,
        'changed': True,
        'invocation': {
            'module_args': {
                'msg': 'System args'
            }
        }
    }
    # print("result={0}".format(result))
    # print("type={0}".format(type(result)))
    jsonout = jsonify(result)
    # print("jsonout={0}".format(jsonout))
    # print("type={0}".format(type(jsonout)))

# Generated at 2022-06-11 09:09:41.879940
# Unit test for function jsonify
def test_jsonify():
    result = {"a": 1, "b": 2, u"\u043c": u"\u043c"}
    assert jsonify(result, True) == '{\n    "a": 1, \n    "b": 2, \n    "\u043c": "\u043c"\n}'
    assert jsonify(result, False) == '{"a":1,"b":2,"\u043c":"\u043c"}'

# Generated at 2022-06-11 09:09:44.481198
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, format=True) == '{\n    "a": 1\n}'



# Generated at 2022-06-11 09:10:00.812269
# Unit test for function jsonify
def test_jsonify():
    ''' unit test for function jsonify '''

    from ansible.utils.unicode import to_unicode

    assert jsonify(dict(foo="bar")) == "{\"foo\": \"bar\"}"
    assert jsonify(dict(foo=[1,2,3])) == "{\"foo\": [1, 2, 3]}"
    assert jsonify(dict(foo=dict(bar=to_unicode("\u00f1")))) == "{\"foo\": {\"bar\": \"\\u00f1\"}}"
    assert jsonify(dict(foo=dict(bar=u"\u00f1"))) == u"{\"foo\": {\"bar\": \"\u00f1\"}}"


# Generated at 2022-06-11 09:10:04.429612
# Unit test for function jsonify
def test_jsonify():
    result = {'a': 1, 'b': 2}
    assert jsonify(result) == '{"a": 1, "b": 2}'
    assert jsonify(result, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    result = None
    assert jsonify(result) == '{}'

# Generated at 2022-06-11 09:10:10.843104
# Unit test for function jsonify
def test_jsonify():
    result = { 'foo' : 'bar', 'baz' : None, 'meow' : 'purr' }
    assert jsonify(result) == '{"baz": null, "foo": "bar", "meow": "purr"}'
    assert jsonify(result, True) == '''{
    "baz": null,
    "foo": "bar",
    "meow": "purr"
}'''
    assert jsonify(None) == '{}'

# Generated at 2022-06-11 09:10:16.055093
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({'foo': 'bar'})
    if result != "{\"foo\": \"bar\"}":
        raise Exception("jsonify failed")
    result = jsonify({'foo': 'bar'}, True)
    if result != '{\n    "foo": "bar"\n}':
        raise Exception("jsonify failed")



# Generated at 2022-06-11 09:10:18.244679
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-11 09:10:21.619442
# Unit test for function jsonify
def test_jsonify():
    result = { 'foo': 1, 'bar': 2 }
    assert jsonify(result, format=True) == '{\n    "bar": 2, \n    "foo": 1\n}'

# Generated at 2022-06-11 09:10:23.792420
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1}) == '{"a": 1}'

# Generated at 2022-06-11 09:10:25.177187
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'b'}) == "{\"a\": \"b\"}"

# Generated at 2022-06-11 09:10:29.338133
# Unit test for function jsonify
def test_jsonify():
    # Empty result is converted to "{}"
    assert "{}" == jsonify(None)
    assert "{}" == jsonify(None, True)

    # Dict with a key is converted to JSON
    assert '{"a": "b"}' == jsonify({"a":"b"})
    assert '{\n    "a": "b"\n}' == jsonify({"a":"b"}, True)

# Generated at 2022-06-11 09:10:34.649580
# Unit test for function jsonify
def test_jsonify():
    # Test jsonify function
    assert jsonify(None) == "{}"
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'


# Generated at 2022-06-11 09:10:52.667455
# Unit test for function jsonify
def test_jsonify():

    result = jsonify({"a": 1, "b": 2, "c": 3})
    print (result)
    assert result == "{\"a\": 1, \"b\": 2, \"c\": 3}"

    result = jsonify({"a": 1, "b": 2, "c": 3}, format=True)
    print (result)
    assert result == "{\n    \"a\": 1, \n    \"b\": 2, \n    \"c\": 3\n}"

    result = jsonify(["a", {"b": 1, "c":2}, "d", 1, 2, 3])
    print (result)
    assert result == "[\"a\", {\"b\": 1, \"c\": 2}, \"d\", 1, 2, 3]"


# Generated at 2022-06-11 09:10:58.081307
# Unit test for function jsonify
def test_jsonify():
    import re
    test = [{'foo': 'bar'}]
    j = jsonify(test, format=True)
    assert re.search(r'"foo": "bar"', j) is not None
    assert re.search(r'^\s+"foo": "bar"', j, re.MULTILINE) is not None

# Generated at 2022-06-11 09:11:08.689528
# Unit test for function jsonify
def test_jsonify():
    # Test a real data structure
    result = { "a": 1, "b": 2, "c": { "a": 1, "b": 2, "c": 3 } }
    assert jsonify(result, False) == '{"a": 1, "b": 2, "c": {"a": 1, "b": 2, "c": 3}}'
    assert jsonify(result, True)  == '''{
    "a": 1,
    "b": 2,
    "c": {
        "a": 1,
        "b": 2,
        "c": 3
    }
}'''

    # Test a unicode data structure

# Generated at 2022-06-11 09:11:18.454685
# Unit test for function jsonify
def test_jsonify():
    def test_jsonify_none():
        assert(jsonify(None) == '{}')

    def test_jsonify_simple_dict():
        assert(jsonify({'foo': 'bar'}) == '{"foo": "bar"}')
        assert(jsonify({'foo': 'bar'}, True) == '''{
    "foo": "bar"
}''')

    def test_jsonify_list():
        assert(jsonify(['foo', 'bar']) == '["foo", "bar"]')
        assert(jsonify(['foo', 'bar'], True) == '''[
    "foo",
    "bar"
]''')


# Generated at 2022-06-11 09:11:21.798042
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'hello': 'world'}, True) == '{\n    "hello": "world"\n}'
    assert jsonify({'hello': u'André'}, True) == '{\n    "hello": "André"\n}'

# Generated at 2022-06-11 09:11:24.324444
# Unit test for function jsonify
def test_jsonify():
    result = { 'foo': 'bar' }
    expected = '{\n    "foo": "bar"\n}'

    assert expected == jsonify(result, format=True)

# Generated at 2022-06-11 09:11:31.213545
# Unit test for function jsonify
def test_jsonify():
    assert "{}" == jsonify(None)
    assert '{"k1": "v1"}' == jsonify(dict(k1='v1'))
    assert '{"k1": "v1"}' == jsonify(dict(k1=u'v1'))
    assert '{"k1": "v1"}\n' == jsonify(dict(k1='v1'), format=True)
    assert '{"k1": "v1"}' == jsonify(dict(k1=u'v1'), format=True)

# Generated at 2022-06-11 09:11:33.121902
# Unit test for function jsonify
def test_jsonify():
    result = {"hello": 2, "world": 3}
    print(jsonify(result, format=True))

# Generated at 2022-06-11 09:11:41.412709
# Unit test for function jsonify
def test_jsonify():
    class DummyResult:
        def __init__(self, name):
            self.name = name
        def __repr__(self):
            return json.dumps(self.name)

    dummy_result = DummyResult('test')
    result = jsonify(dummy_result)

    assert result == json.dumps(dummy_result, sort_keys=True, indent=None, ensure_ascii=False)

    dummy_result = DummyResult('test\u00f6\u00f6test')
    result = jsonify(dummy_result)

    assert result == json.dumps('test\u00f6\u00f6test', sort_keys=True, indent=None, ensure_ascii=False)

# Generated at 2022-06-11 09:11:48.594115
# Unit test for function jsonify
def test_jsonify():
    import copy
    import re
    import string


# Generated at 2022-06-11 09:12:02.344750
# Unit test for function jsonify
def test_jsonify():
    # Formatting
    assert jsonify(dict(changed=False),True) == '{\n    "changed": false\n}'

    # Not formatting
    assert jsonify(dict(changed=False),False) == '{"changed": false}'

# Generated at 2022-06-11 09:12:05.522102
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1, "b": ["x", "y", "z"]}) == '{"a": 1, "b": ["x", "y", "z"]}'

# Generated at 2022-06-11 09:12:10.019510
# Unit test for function jsonify
def test_jsonify():
    result = {
        'a':1,
        'b':2,
        'c':3,
    }
    test_result = jsonify(result, format=False)
    print(test_result)
    print(type(test_result))

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:12:12.474646
# Unit test for function jsonify
def test_jsonify():
    result = jsonify([0])
    assert result == '[0]'

    result = jsonify([0], format=True)
    assert result == '[\n    0\n]'

# Generated at 2022-06-11 09:12:15.118053
# Unit test for function jsonify
def test_jsonify():
    jsonify_results = jsonify({'JSONIFY_TEST': 'FAILED'})
    assert jsonify_results == '{"JSONIFY_TEST": "FAILED"}'

# Generated at 2022-06-11 09:12:20.811241
# Unit test for function jsonify
def test_jsonify():

    data = {
        'a': 1,
        'b': True,
        'c': None,
        'd': [1,2,3,'a','b','c'],
        'e': { 'k': 'v' },
    }

    print(jsonify(data))
    print(jsonify(data, True))


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:12:31.111853
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'foo':'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo':'bar'}, format=True) == '{\n    "foo": "bar"\n}'
    assert jsonify({'foo':{'bar':[1,'2',{"foo":"bar"}]}}) == '{"foo": {"bar": [1, "2", {"foo": "bar"}]}}'
    assert jsonify({'foo':{'bar':[1,'2',{"foo":"bar"}]}}) != '{"foo": {"bar": [1, "3", {"foo": "bar"}]}}'

# Generated at 2022-06-11 09:12:36.629077
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should be able to format a single result'''
    assert "{}" == jsonify(None)
    assert "{}" == jsonify({})
    assert '{"a": 1}' == jsonify({"a": 1})
    assert '{"a": "b"}' == jsonify({"a": "b"})

    assert "" == jsonify(None, format=True)
    assert "{\n}\n" == jsonify({}, format=True)
    assert '{\n    "a": 1\n}\n' == jsonify({"a": 1}, format=True)
    assert '{\n    "a": "b"\n}\n' == jsonify({"a": "b"}, format=True)


# Generated at 2022-06-11 09:12:40.205531
# Unit test for function jsonify
def test_jsonify():
    result = { 'foo': 'bar' }
    test_result = jsonify(result, True)
    assert test_result == '{\n    "foo": "bar"\n}'


# Generated at 2022-06-11 09:12:42.463356
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'hello': None}, True) == '{\n    "hello": null\n}'

# Generated at 2022-06-11 09:13:11.588809
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_unicode
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY2
    import json

    mod = AnsibleModule(argument_spec=dict())
    assert jsonify(mod.params) == '{}'
    assert jsonify(mod.params, dict()) == '{}'
    assert jsonify(mod.params, format=True) == '{}'
    assert jsonify(mod.params, dict(), format=True) == '{}'
    assert jsonify({}) == '{}'
    assert jsonify({}, format=True) == '{}'

# Generated at 2022-06-11 09:13:19.968902
# Unit test for function jsonify
def test_jsonify():
    # Test empty result
    result = None
    assert jsonify(result) == '{}'
    result = {}
    assert jsonify(result) == '{}'

    # Test JSON output formatting (a.k.a. pretty printing)
    result = { 'a': 'b' }
    assert jsonify(result, format=True) == '{\n    "a": "b"\n}'

    # Test unicode encoding troubles
    result = { u'a': u'b' }
    assert jsonify(result) == '{"a": "b"}'

# Generated at 2022-06-11 09:13:29.528108
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': [1, 2, 3], 'b': 2}) == '{"a": [1, 2, 3], "b": 2}'

# sanity check for documentation
if False:
    result = None
    result = {'a': 'foo', 'b': 'bar'}
    result = [1,2,3]
    result = ('a', 'b', 'c')
    result = {
        'ansible': {
            'version': {
                'full': '1.0',
            }
        }
    }
    result = jsonify(result)

# Generated at 2022-06-11 09:13:32.841209
# Unit test for function jsonify
def test_jsonify():
    assert '{' in jsonify(None)
    assert '{' in jsonify(None, True)
    assert '{' in jsonify({}, True)
    assert '{' in jsonify({}, False)
    assert '{' in jsonify({'foo': 'bar'}, False)
    assert '{' in jsonify({'foo': 'bar'}, True)

# Generated at 2022-06-11 09:13:45.095777
# Unit test for function jsonify
def test_jsonify():
    import os
    import sys
    import pkg_resources

    # Get relative path of the Ansible library
    lib = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

    # Skip the test if Ansible is not installed
    if lib not in sys.path:
        return

    # Get the relative path of the test file
    test_module = os.path.join(lib, 'test/unit/plugins/test_utils.py')

    # Get the relative path of the test file
    test_sample = os.path.join(lib, 'test/integration/sample_json_output.json')

    # Load the test module
    print('Loading module at: ' + test_module)

# Generated at 2022-06-11 09:13:49.109429
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a":1}) == '{"a": 1}'
    assert jsonify({"a":1}, True) == '{\n    "a": 1\n}'

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-11 09:13:53.072293
# Unit test for function jsonify
def test_jsonify():
    ''' basic test of jsonify '''
    assert jsonify({"1":2,"b":3}) == "{\"1\": 2, \"b\": 3}"
    assert jsonify({"1":2,"b":3}, True) == "{\n    \"1\": 2, \n    \"b\": 3\n}"


# Generated at 2022-06-11 09:13:55.302662
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '''{
    "a": 1
}'''

# Generated at 2022-06-11 09:13:59.013579
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import wrap_var

    text_data = wrap_var(u"\u0384")
    assert jsonify(text_data) == u'["\u0384"]'
    assert jsonify(text_data, True) == u'[\n    "\u0384"\n]'

# Generated at 2022-06-11 09:14:06.227234
# Unit test for function jsonify
def test_jsonify():

    data = {'a': 'b', 'c': None}

    my_json = jsonify(data)
    import json as json_lib
    data_py = json_lib.loads(my_json)
    assert data_py['a'] == data['a']
    assert data_py['c'] is data['c']

    assert my_json == '{"a": "b", "c": null}'

    my_json_formatted = jsonify(data, format=True)
    assert my_json_formatted == """{
    "a": "b",
    "c": null
}"""