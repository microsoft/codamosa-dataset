

# Generated at 2022-06-11 09:04:37.260114
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('foo') == '"foo"'
    assert jsonify(None) == "{}"
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'

    # Test with unicode strings
    assert jsonify(u'foó') == '"foó"'
    assert jsonify({u'fóo': u'bár'}) == '{"fóo": "bár"}'

# Generated at 2022-06-11 09:04:39.914637
# Unit test for function jsonify
def test_jsonify():
    import ansible.utils.jsonify as jsonify
    assert jsonify.jsonify(None, False) == '{}'
    assert jsonify.jsonify({'foo': 'bar'}, False) == '{"foo": "bar"}'
    assert jsonify.jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-11 09:04:42.546648
# Unit test for function jsonify
def test_jsonify():
    for i in ('', None):
        assert '{}' == jsonify(i, True)
    # Make sure this doesn't throw an error
    jsonify([u'\u2600'])

# Generated at 2022-06-11 09:04:53.922496
# Unit test for function jsonify
def test_jsonify():
    # test jsonify

    # test empty
    result = jsonify(None)
    assert result == "{}"

    # test compression
    result = jsonify({ 'a': 'foo' }, True)
    assert result == json.dumps({ 'a': 'foo' }, sort_keys=True, indent=4, ensure_ascii=False)

    # test compression
    result = jsonify({ u'a': u'foo' }, False)
    assert result == json.dumps({ u'a': u'foo' }, sort_keys=True, indent=None, ensure_ascii=False)

    # test compression
    result = jsonify({ 'a': u'foo' }, False)

# Generated at 2022-06-11 09:05:07.143858
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unicode import to_bytes

    assert jsonify(None) == '{}'
    assert jsonify({"a": 1, "b": 2}) == "{\"a\": 1, \"b\": 2}"
    assert jsonify({"a": 1, "b": 2}, format=True) == "{\n    \"a\": 1, \n    \"b\": 2\n}"

    # unicode string test
    assert jsonify(to_unicode("foo")) == "\"foo\""
    assert jsonify(to_unicode("foo"), format=True) == "\"foo\""

    # byte string test
    assert jsonify(to_bytes("foo")) == "\"foo\""

# Generated at 2022-06-11 09:05:14.834971
# Unit test for function jsonify
def test_jsonify():
    import StringIO
    out = StringIO.StringIO()
    ds = dict(a='b')
    out.write(jsonify(ds))
    data = json.load(StringIO.StringIO(out.getvalue()))
    assert data['a'] == 'b'
    out1 = StringIO.StringIO()
    out1.write(jsonify(ds, True))
    assert '{\n    "a": "b"\n}' == out1.getvalue()
    out2 = StringIO.StringIO()
    out2.write(jsonify(None))
    assert '{}' == out2.getvalue()

# Generated at 2022-06-11 09:05:26.268573
# Unit test for function jsonify
def test_jsonify():

    home_dir = {'home': '/home/test'}
    home_dir_str = json.dumps(home_dir)

    # Should return valid JSON if not formatted
    assert jsonify(home_dir) == home_dir_str

    # Should return valid JSON if formatted
    assert jsonify(home_dir, format=True) == "\n".join([
        "{"
        "    \"home\": \"/home/test\"",
        "}"
    ])

    # Should return valid JSON if formatted with non-ascii chars
    assert jsonify({'home': u'\u0e50'}, format=True) == "\n".join([
        "{"
        "    \"home\": \"\xe0\xb9\x90\"",
        "}"
    ])

# Generated at 2022-06-11 09:05:35.680904
# Unit test for function jsonify
def test_jsonify():
    # input = dict with one key/value pair
    # expected output = json string '{"a": 1}'
    input = {'a':1}
    expected = '{"a": 1}'
    output = jsonify(input)
    assert(output == expected)

    # input = dict with one key/value pair
    # expected output = json string '{\n    "a": 1\n}'
    input = {'a':1}
    expected = '{\n    "a": 1\n}'
    output = jsonify(input, format=True)
    assert(output == expected)

    # input = dict with one key/value pair
    # expected output = json string '{\n    "a": 1\n}'
    input = {'a':1}

# Generated at 2022-06-11 09:05:41.511831
# Unit test for function jsonify
def test_jsonify():
    result = dict(changed=False, rc=0, stdout="foobar")

    assert jsonify(result) == '{"changed": false, "rc": 0, "stdout": "foobar"}'
    assert jsonify(result, True) == '{\n    "changed": false, \n    "rc": 0, \n    "stdout": "foobar"\n}'

# Generated at 2022-06-11 09:05:46.580363
# Unit test for function jsonify
def test_jsonify():
    data = {'a':1, 'b':2}
    assert jsonify(data) == "{\"a\": 1, \"b\": 2}"
    assert jsonify(data, True) == "{\n    \"a\": 1, \n    \"b\": 2\n}"
    assert jsonify(None) == "{}"

# Generated at 2022-06-11 09:05:54.393302
# Unit test for function jsonify
def test_jsonify():
    import yaml
    yaml_string = """
    foo:
      bar:
        baz:
          - one
          - two
          - three
    """
    json_string = jsonify(yaml.safe_load(yaml_string))
    assert yaml.safe_load(json_string) == yaml.safe_load(yaml_string)

# Generated at 2022-06-11 09:06:02.326406
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_unicode

    test_1 = {
        'some_key': 'some_value',
        'some_dict': {'a': 1, 'b': 2},
        'some_list': [1, 2, 3],
        'true_value': True,
        'false_value': False,
    }

    # Test that result was converted to native string type
    # and is formatted properly

# Generated at 2022-06-11 09:06:12.753606
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == "{}"

    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    assert jsonify({'a': 1, 'b': [1, 2, 3], 'c': {'d': 1, 'e': 2, 'f': 3}}, True) == '''{
    "a": 1,
    "b": [
        1,
        2,
        3
    ],
    "c": {
        "d": 1,
        "e": 2,
        "f": 3
    }
}'''

# Generated at 2022-06-11 09:06:15.188908
# Unit test for function jsonify
def test_jsonify():
    '''Check that jsonify converts dict to json properly'''
    assert isinstance(jsonify({"a": 3, "b": [1, 2, 3]}), str)

# Generated at 2022-06-11 09:06:23.071686
# Unit test for function jsonify
def test_jsonify():
    result = {'a':1, 'b':2, 'c':3}
    output = jsonify(result, True)
    assert output == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'
    output = jsonify(result, False)
    assert output == '{"a":1,"b":2,"c":3}'
    result = []
    output = jsonify(result, True)
    assert output == '[]'
    output = jsonify(result, False)
    assert output == '[]'
    result = None
    output = jsonify(result, True)
    assert output == '{}'
    output = jsonify(result, False)
    assert output == '{}'

# Generated at 2022-06-11 09:06:29.645966
# Unit test for function jsonify
def test_jsonify():
    data = dict(
        a = dict(
            b = "c",
            d = "e",
        )
    )

    assert jsonify(data, False) == "{\"a\": {\"d\": \"e\", \"b\": \"c\"}}"
    assert jsonify(data, True) == """{
    "a": {
        "b": "c",
        "d": "e"
    }
}"""

# Generated at 2022-06-11 09:06:34.025448
# Unit test for function jsonify
def test_jsonify():
    import pprint
    test_result = {'foo': 'bar'}
    assert jsonify(test_result) == json.dumps(test_result)
    assert pprint.pformat(test_result,indent=4) == jsonify(test_result,format=True)
    assert jsonify(None) == "{}"

# Generated at 2022-06-11 09:06:40.597983
# Unit test for function jsonify
def test_jsonify():
    test = dict()
    test['a'] = 1
    test['b'] = 2
    test['c'] = 3

    my_test_1 = jsonify(test, format=True)
    my_test_2 = jsonify(test, format=False)
    assert my_test_1 == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'
    assert my_test_2 == '{"a": 1, "b": 2, "c": 3}'

# Generated at 2022-06-11 09:06:49.952258
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo='bar'), False) == '{"foo": "bar"}'
    assert jsonify(dict(foo='bar'), True) == '{\n    "foo": "bar"\n}'
    assert jsonify(dict(foo=['bar', 'baz']), False) == '{"foo": ["bar", "baz"]}'
    assert jsonify(dict(foo=['bar', 'baz']), True) == '{\n    "foo": [\n        "bar", \n        "baz"\n    ]\n}'
    assert jsonify(dict(foo=dict(bar='baz', bam='baz')), False) == '{"foo": {"bar": "baz", "bam": "baz"}}'

# Generated at 2022-06-11 09:06:57.031164
# Unit test for function jsonify
def test_jsonify():
    results = []
    results.append({'item1': 'one', 'item2': 'two'})
    results.append(None)

    output = jsonify(results[0], True)
    assert output == '''{
    "item1": "one",
    "item2": "two"
}'''
    output = jsonify(results[1], True)
    assert output == '{}'
    output = jsonify(results[0])
    assert output == '{"item1":"one","item2":"two"}'
    output = jsonify(results[1])
    assert output == '{}'

# Generated at 2022-06-11 09:07:05.448559
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify('a') == '"a"'
    assert jsonify(False) == "false"
    assert jsonify(0) == "0"
    assert jsonify([]) == "[]"
    assert jsonify({}) == "{}"
    assert jsonify({'a':[]}) == '{"a": []}'
    assert jsonify({'a':[]}, format=True) == '{\n    "a": []\n}'

# Generated at 2022-06-11 09:07:15.862187
# Unit test for function jsonify
def test_jsonify():

    def assert_json_equal(a, b):
        assert json.loads(jsonify(a)) == json.loads(jsonify(b))

    assert_json_equal({}, None)
    assert_json_equal({}, {})
    assert_json_equal({"a": 1}, {"a": 1})
    assert_json_equal({"a": 1}, {"a": 1, "b": 2})
    assert_json_equal({"b": 2}, {"a": 1, "b": 2})
    assert_json_equal({"a": {"b": 2}}, {"a": {"b": 2, "c": 3}})
    assert_json_equal({"b": 2, "c": 3}, {"a": {"b": 2, "c": 3}})

# Generated at 2022-06-11 09:07:19.182511
# Unit test for function jsonify
def test_jsonify():
    result = {u"some": u"unicode"}
    assert jsonify(result, True) == u"{\n    \"some\": \"unicode\"\n}"

# Generated at 2022-06-11 09:07:28.641422
# Unit test for function jsonify
def test_jsonify():

    # Test 1:
    # Test simple dict input
    input_dict  = dict(a=1, b=2, c=3)
    output_json = jsonify(input_dict)
    assert json.dumps(input_dict) == output_json, 'test_jsonify: test1 failed'

    # Test 2:
    # Test None input
    input_dict  = None
    output_json = jsonify(input_dict)
    assert json.dumps({}) == output_json, 'test_jsonify: test2 failed'

    # Test 3:
    # Test simple ascii string
    input_string = '{"a": 1}'
    output_json = jsonify(input_string)
    assert json.dumps(input_string) == output_json, 'test_jsonify: test3 failed'



# Generated at 2022-06-11 09:07:30.475062
# Unit test for function jsonify
def test_jsonify():
    assert isinstance(jsonify(dict(foo='bar')), basestring)


# Generated at 2022-06-11 09:07:43.047394
# Unit test for function jsonify
def test_jsonify():
    '''
    jsonify: Return json data in serialized and pretty printed form
    '''

    # Jsonify a list
    assert jsonify(['foo', 'bar']) == '["foo", "bar"]'

    # Jsonify a dict
    assert jsonify(dict(foo='bar')) == '{"foo": "bar"}'

    # Jsonify None
    assert jsonify(None) == '{}'

    # Jsonify of an object
    class TestObj():
        def __init__(self):
            self.foo = 'bar'
    assert jsonify(TestObj()) == '{"foo": "bar"}'

    # Jsonify with unicode should handle ascii correctly

# Generated at 2022-06-11 09:07:47.192629
# Unit test for function jsonify
def test_jsonify():
    result = dict(foo=dict(bar='baz'))
    jtext = jsonify(result, format=True)
    assert jtext.startswith('{\n    "foo": {\n        "bar": "baz"\n    }\n}')

# Generated at 2022-06-11 09:07:53.308113
# Unit test for function jsonify
def test_jsonify():
    data1 = dict(foo='bar', bam=5)
    assert jsonify(data1) == '{\"bam\": 5, \"foo\": \"bar\"}'
    assert jsonify(data1, format=True) == '{\n    \"bam\": 5, \n    \"foo\": \"bar\"\n}'
    assert jsonify(None) == "{}"

    data2 = dict([(u'\u00e9', u'\u00e9'), (u'\u00e9', u'\u00e9')])
    assert jsonify(data2) == '{\"\u00e9\": \"\u00e9\", \"\u00e9\": \"\u00e9\"}'

# Generated at 2022-06-11 09:08:03.185265
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    # Test that we return a json literal when we have a dictionary
    assert json.loads(jsonify({'a': 'bc'})) == {'a': 'bc'}

    # Test that we return a json literal when we have a integer
    assert jsonify(2) == '2'

    # Test that we return an empty string for None
    assert jsonify(None) == '{}'

    # Test that unsafe text is json encoded correctly
    assert jsonify(AnsibleUnsafeText(u'a\u0a16')) == u'"a\u0a16"'

    # Test that we return an empty string for None when format is true
    assert jsonify(None, True) == '{}'

    # Test that we return a formatted json literal when we

# Generated at 2022-06-11 09:08:14.677250
# Unit test for function jsonify
def test_jsonify():
    '''
    Tests for proper behavior of the jsonify module.
    '''
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    import pytest

    data_formatted = jsonify({"A": 1, "B": 2, "C": [3, 4, 5]}, format=True)
    data_unformatted = jsonify({"A": 1, "B": 2, "C": [3, 4, 5]}, format=False)
    assert data_formatted == '''{
    "A": 1,
    "B": 2,
    "C": [
        3,
        4,
        5
    ]
}'''


# Generated at 2022-06-11 09:08:31.588121
# Unit test for function jsonify

# Generated at 2022-06-11 09:08:35.357476
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1, 'b': 2}) == r'{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, True) == '''{
    "a": 1,
    "b": 2
}'''



# Generated at 2022-06-11 09:08:40.432775
# Unit test for function jsonify
def test_jsonify():
    '''
    ansible.utils.jsonify unit tests
    '''

    assert jsonify(None) == '{}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify(['foo', 'bar']) == '["foo", "bar"]'
    assert jsonify({'foo': ['bar', 'baz']}) == '{"foo": ["bar", "baz"]}'



# Generated at 2022-06-11 09:08:54.077317
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify '''
    from ansible.utils.listify import listify_lookup_plugin_terms

    # Test simple dictionary
    #
    # {'test': 1}
    assert jsonify({'test': 1}) == "{\"test\": 1}"

    # Test dictionary with unicode string
    #
    # {'test': u'\xe9'}
    assert jsonify({u'test': u'\xe9'}) == "{\"test\": \"é\"}"

    # Test dictionary with ascii string
    #
    # {'test': 'a'}
    assert jsonify({u'test': 'a'}) == "{\"test\": \"a\"}"

    # Test list
    #
    # {'test': [{'a': 1}, {'b': 2}]}

# Generated at 2022-06-11 09:08:59.243519
# Unit test for function jsonify
def test_jsonify():
    # Default (uncompressed JSON)
    assert jsonify({'a': 'world', 'b': 'hello'}) == '{"a": "world", "b": "hello"}'

    # Compressed JSON
    assert jsonify({'a': 'world', 'b': 'hello'}, format=True) == '{\n    "a": "world", \n    "b": "hello"\n}'

    # None value
    assert jsonify(None) == '{}'

# Generated at 2022-06-11 09:09:07.929285
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(['a', 'b', 'c'], True) == json.dumps(['a', 'b', 'c'])
    assert jsonify(dict(a=1, b=2, c=3, d=4, e=5), True) == json.dumps(dict(a=1, b=2, c=3, d=4, e=5))
    assert jsonify(dict(a=1, b=2, c=3, d=4, e=5), False) == json.dumps(dict(a=1, b=2, c=3, d=4, e=5))


# Generated at 2022-06-11 09:09:14.379272
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({'foo': 'bar'})
    print(result)
    assert result == '{"foo": "bar"}'
    print(jsonify({'foo': 'bar'}, True))
    print(jsonify(None, True))
    print(jsonify([]))
    print(jsonify({}))

if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-11 09:09:22.980434
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import AnsibleModule
    test_cases = [
        {'args': {'msg': 'Hello World'}, 'format': False},
        {'args': {'msg': 'Hello World'}, 'format': True},
    ]

    for test_case in test_cases:
        m = AnsibleModule(
            argument_spec = {
                'msg': {'required': True},
            },
            supports_check_mode=True
        )
        result = {'msg': m.params['msg']}
        assert jsonify(result, test_case['format']) == json.dumps(result, sort_keys=True, indent=4)

# Generated at 2022-06-11 09:09:33.369970
# Unit test for function jsonify
def test_jsonify():
    dict1 = { 'a': 1, 'b': [1, 2] }
    assert jsonify(dict1, True) == '''{
    "a": 1,
    "b": [
        1,
        2
    ]
}'''
    assert jsonify(dict1, False) == '{"a": 1, "b": [1, 2]}'
    dict2 = { "a": 1, "b": [ { "c": True, "d": None, "e": u"\u042f\u0448\u0438\u0448\u0438\u0448" } ] }

# Generated at 2022-06-11 09:09:39.056906
# Unit test for function jsonify
def test_jsonify():
    import os
    import sys

    # This should not throw an exception.
    if sys.version_info[0] > 2:
        jsonify({"a": u"\u2603"})
    else:
        jsonify({"a": "\xe2\x98\x83"})

    # This will throw an exception.
    try:
        jsonify({"a": os.urandom(2**20)})
    except Exception:
        pass

# Generated at 2022-06-11 09:10:00.327887
# Unit test for function jsonify
def test_jsonify():
    # Test using a dict
    result={'a':'b', 'c':'d'}
    expected='{"a": "b", "c": "d"}'
    assert jsonify(result, False) == expected
    # Test using a list
    result=['a','b','c']
    expected='["a", "b", "c"]'
    assert jsonify(result, False) == expected
    # Test using a string
    result='foobar'
    expected='"foobar"'
    assert jsonify(result, False) == expected
    # Test using None
    result=None
    expected='{}'
    assert jsonify(result, False) == expected
    # Test using int
    result=5
    expected='5'
    assert jsonify(result, False) == expected
    # Test using boolean

# Generated at 2022-06-11 09:10:05.428045
# Unit test for function jsonify
def test_jsonify():
    test_obj = {'a': '1', 'b': '2'}
    formatted = jsonify(test_obj, True)
    unformatted = jsonify(test_obj, False)
    assert formatted == json.dumps(test_obj, sort_keys=True, indent=4, ensure_ascii=False)
    assert unformatted == json.dumps(test_obj, sort_keys=True, indent=None, ensure_ascii=False)
    assert formatted != unformatted

# Generated at 2022-06-11 09:10:10.296216
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, format=True) == '''{
    "a": 1,
    "b": 2
}'''
    assert jsonify(None) == '{}'

# Generated at 2022-06-11 09:10:17.032455
# Unit test for function jsonify
def test_jsonify():
    # Test with different input
    assert jsonify({"ansible_facts": {"a": "b"}}) == '{"ansible_facts": {"a": "b"}}'
    assert jsonify(None) == "{}"
    # Test with format=True
    assert jsonify({"ansible_facts": {"a": "b"}}, True) == '{\n    "ansible_facts": {\n        "a": "b"\n    }\n}'


# Generated at 2022-06-11 09:10:26.177439
# Unit test for function jsonify
def test_jsonify():
    result = None
    assert jsonify(result) == "{}"

    result = {u"abc":"def"}
    assert jsonify(result) == '{"abc": "def"}'

    result = {u"abc":u"def"}
    assert jsonify(result) == '{"abc": "def"}'

    result = {u"abc":u"def\u2019"}
    assert jsonify(result) == '{"abc": "def\xe2\x80\x99"}'

    result = {u"abc":u"def\u2019"}
    assert jsonify(result, True) == '{\n    "abc": "def\xe2\x80\x99"\n}'

# Generated at 2022-06-11 09:10:27.814063
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-11 09:10:33.697898
# Unit test for function jsonify
def test_jsonify():
    a = dict(a=1, b=2)
    assert jsonify(a) == '{"a": 1, "b": 2}'
    assert jsonify(a, True) == '''{
    "a": 1,
    "b": 2
}'''

    a = dict(a=u"\u6d4b\u8bd5")
    assert jsonify(a) == '{"a": "\u6d4b\u8bd5"}'
    assert jsonify(a, True) == '''{
    "a": "\u6d4b\u8bd5"
}'''

    a = dict(a=1, b="column_name")
    assert jsonify(a) == '{"a": 1, "b": "column_name"}'

# Generated at 2022-06-11 09:10:46.276480
# Unit test for function jsonify
def test_jsonify():
    def t(instr, expected, format=False):
        result = jsonify(instr, format=format)
        assert result == expected

    t('blah', '"blah"')
    t(42, '42')
    t(False, 'false')
    t(True, 'true')
    t({}, '{}')
    t(["foo", "bar", None], '["foo", "bar", null]')
    t({ "foo" : "bar", "meh" : False, "stuff" : None }, '{"foo": "bar", "meh": false, "stuff": null}', format=True)

    class Foo(object):
        def __init__(self):
            self.foo = 'bar'
            self.meh = None

# Generated at 2022-06-11 09:10:49.624675
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    indent = 4
    assert jsonify({"a": 1}, True) == '{\n' + ' ' * indent + '"a": 1\n' + ' ' * (indent - 2) + '}'

# Generated at 2022-06-11 09:10:52.699422
# Unit test for function jsonify
def test_jsonify():
    # Tests to allow in both Python 2.6 and 2.7
    assert jsonify(['a', 'b']) == '["a", "b"]'

# Generated at 2022-06-11 09:11:19.149297
# Unit test for function jsonify
def test_jsonify():

    # Test with a simple dictionary
    data = { 'a': 1, 'b': 2 }
    assert jsonify(data) == '{"a": 1, "b": 2}'

    # Test with a simple list
    data = [ { 'a': 1 }, { 'b': 2 } ]
    assert jsonify(data) == '[{"a": 1}, {"b": 2}]'

    # Test with a simple string
    data = "abc"
    assert jsonify(data) == '"abc"'

    # Test with a simple integer
    data = 123
    assert jsonify(data) == '123'

    # Test with a None object
    data = None
    assert jsonify(data) == "{}"

# Generated at 2022-06-11 09:11:28.982181
# Unit test for function jsonify
def test_jsonify():
    import datetime
    assert jsonify({'foo': 'bar', 'spam': 12, 'eggs': [1,2,3]}) == "{\"eggs\": [1, 2, 3], \"foo\": \"bar\", \"spam\": 12}"
    assert jsonify({'foo': 'bar', 'spam': 12, 'eggs': [1,2,3]}, format=True) == "{\n    \"eggs\": [\n        1, \n        2, \n        3\n    ], \n    \"foo\": \"bar\", \n    \"spam\": 12\n}"

# Generated at 2022-06-11 09:11:38.928825
# Unit test for function jsonify
def test_jsonify():
    assert '{"a": [1, 2], "b": "foo"}' in jsonify({'a': [1,2], 'b': 'foo'})
    assert '"bar"' in jsonify({'a': 'bar'})
    assert '"baz"' in jsonify({'a': 'baz'})
    assert '{"a": "baz", "c": "qux"}' in jsonify({'a':  'baz', 'c':  'qux'})
    assert '{\n    "a": "baz", \n    "c": "qux"\n}' in jsonify({'a': 'baz', 'c':  'qux'}, True)

# Generated at 2022-06-11 09:11:47.645384
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": []}) == '{"a": []}'
    assert jsonify({"a": []}, True) == "{\n    \"a\": []\n}"
    assert jsonify({"a": 4}, True) == "{\n    \"a\": 4\n}"
    assert jsonify({"a": {"b": [1,2,3]}}, True) == "{\n    \"a\": {\n        \"b\": [\n            1, \n            2, \n            3\n        ]\n    }\n}"
    assert jsonify({u"a": u"\u3593"}) == '{"a": "\u3593"}'

# Generated at 2022-06-11 09:11:52.798846
# Unit test for function jsonify
def test_jsonify():
    result = dict(failed=True, stdout=u'é', changed=True)
    flattened = jsonify(result, format=True)
    assert 'failed' in flattened
    assert 'stdout' in flattened
    assert 'changed' in flattened
    assert 'true' in flattened.lower()
    assert flattened.count('\n') == 3
    assert u'é' in flattened
    # Non ascii text should be encoded in utf8
    assert flattened.split(u': u')[1][0] != u'u'



# Generated at 2022-06-11 09:12:05.567400
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert jsonify(dict(a=1, b=2, c=3)) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(dict(a=dict(b=1, c=2), d=dict(e=3, f=4))) == '{"a": {"b": 1, "c": 2}, "d": {"e": 3, "f": 4}}'
    assert jsonify({'_ansible_parsed': True, 'a': AnsibleUnsafeText('hello'), 'b': 'world'}) == '{"_ansible_parsed": true, "a": "hello", "b": "world"}'
    assert jsonify(dict(changed=True, failed=True, msg='the message'))

# Generated at 2022-06-11 09:12:15.479274
# Unit test for function jsonify
def test_jsonify():

    # Sample data
    test_data = {
        "hostvars": {},
        "ok": {
            "host1": {
                "changed": False,
                "invocation": {
                    "module_name": "ping"
                },
                "ping": "pong"
            }
        },
        "dark": {
            "host2": {
                "invocation": {
                    "module_name": "ping"
                },
                "unreachable": True,
                "msg": "Invalid credentials"
            }
        }
    }

    # Assert we can jsonify the data

# Generated at 2022-06-11 09:12:24.468744
# Unit test for function jsonify
def test_jsonify():
    value = dict(a=1, b="two", c=3.0, d=list(range(10)))
    assert jsonify(value) == "{\"a\": 1, \"b\": \"two\", \"c\": 3.0, \"d\": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]}"
    assert jsonify(value, True) == """{
    "a": 1,
    "b": "two",
    "c": 3.0,
    "d": [
        0,
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9
    ]
}"""

# Generated at 2022-06-11 09:12:34.257743
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1,b=2,c=3)) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(dict(a=1,b=2,c=3), format=True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'
    assert jsonify(dict(changed=False, failed=False, rc=0, results=[])) == '{"changed": false, "failed": false, "rc": 0, "results": []}'

# Generated at 2022-06-11 09:12:42.545250
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"hello": "world"}, format=True) == '''{
    "hello": "world"
}'''
    assert jsonify({u"hello": u"world"}, format=True) == '''{
    "hello": "world"
}'''
    assert jsonify({u"hello": u"wörld"}, format=True) == u'''{
    "hello": "wörld"
}'''
    assert jsonify({"hello": "wörld"}, format=True) == '''{
    "hello": "w\\u00f6rld"
}'''

# Generated at 2022-06-11 09:13:24.331949
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify

    assert jsonify(None) == "{}"
    assert jsonify([]) == "[]"


# Generated at 2022-06-11 09:13:30.731414
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a':1, 'b':2}) == '{\"a\": 1, \"b\": 2}'
    assert jsonify({'a':1, 'b':2}, format=True) == '{\n    \"a\": 1, \n    \"b\": 2\n}'
    assert jsonify({'insert_key': u"a unicode string with a non-ascii char: \u2019"}) == '{\"insert_key\": \"a unicode string with a non-ascii char: \u2019\"}'

# Generated at 2022-06-11 09:13:37.745905
# Unit test for function jsonify
def test_jsonify():

    mydict = dict(changed=True, rc=0, results='All Good')
    json_str = jsonify(mydict, format=True)
    assert(json_str == '{\n    "changed": true, \n    "rc": 0, \n    "results": "All Good"\n}')

    mydict = dict(changed=True, rc=0, results=[u'All Good\u2713'])
    json_str = jsonify(mydict, format=True)
    assert(json_str == '{\n    "changed": true, \n    "rc": 0, \n    "results": [\n        "All Good\\\\u2713"\n    ]\n}')
    assert("\u2713" not in json_str)

# Generated at 2022-06-11 09:13:48.983850
# Unit test for function jsonify
def test_jsonify():
    ''' test_jsonify '''

    assert jsonify(None) == '{}', 'jsonify failed'
    assert jsonify(1) == '1', 'jsonify failed'
    assert jsonify({"a": 1}) == '{"a": 1}', 'jsonify failed'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}', 'jsonify failed'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}', 'jsonify failed'
    assert jsonify({"a": 1}) == '{"a": 1}', 'jsonify failed'

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-11 09:13:55.601137
# Unit test for function jsonify
def test_jsonify():
    # Testing jsonify
    assert "{}" == jsonify(None)
    # This should be an ASCII string, so it will come out as Unicode
    assert u"\"\"" == jsonify("")
    assert "\"\u2014\"" == jsonify(u"\u2014")
    assert u"\"\u2014\"" == jsonify(u"\u2014", True)
    assert "\"\\u2014\"" == jsonify(u"\u2014", False)
    assert '1' == jsonify(1)

# Testing function jsonify with the test function itself

# Generated at 2022-06-11 09:14:01.068299
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1, 'b': 2}) == '{\n    "a": 1, \n    "b": 2\n}' # format=True
    assert jsonify({'a': 1, 'b': 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({'a': 1, 'b': 2}, format=False) == '{"a": 1, "b": 2}'


# Generated at 2022-06-11 09:14:10.507565
# Unit test for function jsonify
def test_jsonify():
    ''' function jsonify() with different inputs '''

    # test the function jsonify()
    # when the result is None
    result = None
    my_jsonify = jsonify(result)
    assert my_jsonify == "{}"

    # when the result is not None
    result = {
        "changed": False,
        "ping": "pong",
        "dataset": {
            "bar": "baz"
        }
    }
    my_jsonify = jsonify(result)
    assert json.loads(my_jsonify) == result

    # when the result contains unicode
    result = {
        "changed": False,
        "ping": u"pong",
        "dataset": {
            "bar": u"b\xe1z"
        }
    }
    my_jsonify

# Generated at 2022-06-11 09:14:19.670658
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'

    test_dict = dict(
        a=1,
        b=2,
        c=3,
    )
    test_dict_str = jsonify(test_dict)
    assert test_dict_str == '{"a": 1, "b": 2, "c": 3}'
    test_dict_str = jsonify(test_dict, True)
    assert test_dict_str == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'

# Generated at 2022-06-11 09:14:25.400450
# Unit test for function jsonify
def test_jsonify():
    """This is a basic test"""
    data = [{"a": "b", "c": 1},
            {"a": "b1", "c": 2}]
    assert jsonify(data) == '[\n    {\n        "a": "b", \n        "c": 1\n    }, \n    {\n        "a": "b1", \n        "c": 2\n    }\n]'
    assert jsonify(data, format=True) == '[\n    {\n        "a": "b", \n        "c": 1\n    }, \n    {\n        "a": "b1", \n        "c": 2\n    }\n]'

# Generated at 2022-06-11 09:14:27.098480
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo=dict(bar="baz"))) == "{\"foo\": {\"bar\": \"baz\"}}"