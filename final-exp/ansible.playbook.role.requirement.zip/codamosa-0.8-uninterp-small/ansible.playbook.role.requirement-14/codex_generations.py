

# Generated at 2022-06-25 05:55:29.598672
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    role_requirement_0 = RoleRequirement()

    repo_url_0 = "https://github.com/myrepo.git"
    assert role_requirement_0.repo_url_to_role_name(repo_url_0) == "myrepo"

    repo_url_1 = "https://github.com/myrepo"
    assert role_requirement_0.repo_url_to_role_name(repo_url_1) == "myrepo"

    repo_url_2 = "https://github.com/myrepo.tar.gz"
    assert role_requirement_0.repo_url_to_role_name(repo_url_2) == "myrepo"

    repo_url_3 = "https://github.com/myrepo,stable"


# Generated at 2022-06-25 05:55:36.127397
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    # repo_url_list[0] is a repo_url that doens't contain name of the role
    # repo_url_list[1] is a repo_url that contains name of the role
    # repo_url_list[2] is a repo_url that doesn't start with "https://", "http://" or "git@" so we can't get the name of the role
    # repo_url_list[3] is a repo_url that doesn't end with ".git" so we can't get the name of the role
    repo_url_list = ["http://github.com/ansible/ansible-examples", "https://github.com/ansible/ansible-examples.git", "test_repo", "test_role.tar.gz"]

# Generated at 2022-06-25 05:55:43.932779
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_0 = "git+git://github.com/my_user/my_role.git,v1.2.3"
    actual_role_0 = role_requirement_0.role_yaml_parse(role_0)
    expected_role_0 = {'name': "my_role", 'version': "v1.2.3", 'scm': 'git', 'src': 'git://github.com/my_user/my_role.git'}
    assert actual_role_0 == expected_role_0
    role_1 = "git+git://github.com/my_user/my_role.git,v1.2.3,other_role_name"
    actual_role_1 = role_requirement_0.role_yaml_parse

# Generated at 2022-06-25 05:55:54.855283
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    result_1 = role_requirement_1.role_yaml_parse({"src": "ansible.builtin", "version": "1.0", "name": "ansible-builtin"})
    assert result_1 == {"src": "ansible.builtin", "version": "1.0", "name": "ansible-builtin"}, "Failed to parse: {'src': 'ansible.builtin', 'version': '1.0', 'name': 'ansible-builtin'}"

    role_requirement_2 = RoleRequirement()

# Generated at 2022-06-25 05:56:04.213422
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    assert role_requirement_1.role_yaml_parse("https://github.com/davedoesdev/ansible-role-ntp.git,v1.0,davedoesdev_ntp") == {"scm": "git",
                                                                                                                           "version": "v1.0",
                                                                                                                           "src": "https://github.com/davedoesdev/ansible-role-ntp.git",
                                                                                                                           "name": "davedoesdev_ntp"}

# Generated at 2022-06-25 05:56:15.519242
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    assert role_requirement_0.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role_requirement_0.repo_url_to_role_name("https://git.example.com/repos/repo.git") == "repo"
    assert role_requirement_0.repo_url_to_role_name("http://user@git.example.com/repos/repo.git") == "repo"
    assert role_requirement_0.repo_url_to_role_name("https://user@git.example.com/repos/repo.git") == "repo"
    assert role_requirement_0.repo_url_

# Generated at 2022-06-25 05:56:22.208329
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse("0")
    role_requirement_0.role_yaml_parse("0,1")
    role_requirement_0.role_yaml_parse("0,1,2")
    role_requirement_0.role_yaml_parse("0,1,2,3,4")


# Generated at 2022-06-25 05:56:30.377769
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    repo_url = 'http://git.example.com/repos/repository.git'
    assert role_requirement.repo_url_to_role_name(repo_url) == 'repository'
    repo_url = 'https://git.example.com/repos/repository.git'
    assert role_requirement.repo_url_to_role_name(repo_url) == 'repository'
    repo_url = 'git@git.example.com:repos/repository.git'
    assert role_requirement.repo_url_to_role_name(repo_url) == 'repository'
    repo_url = 'repository.com'
    assert role_requirement.repo_url_to

# Generated at 2022-06-25 05:56:38.743846
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test_case_1
    role_requirement_1 = RoleRequirement.role_yaml_parse('https://github.com/apache/cassandra')
    assert role_requirement_1['name'] == "cassandra"

    # test_case_2
    role_requirement_2 = RoleRequirement.role_yaml_parse('https://github.com/apache/cassandra,1.2.3')
    assert role_requirement_2['name'] == "cassandra"

    # test_case_3
    role_requirement_3 = RoleRequirement.role_yaml_parse('https://github.com/apache/cassandra,1.2.3,foo')
    assert role_requirement_3['name'] == "foo"


# Generated at 2022-06-25 05:56:48.742728
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 05:57:09.148058
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    import yaml
    from collections import OrderedDict

    role_requirement_0 = RoleRequirement()

    # Test case 0:
    # Input:
    #   role = "foo,v2,foobar"
    # Expect:
    #   role = {"name": "foobar", "src": "foo", "version": "v2"}
    print("Test case 0")
    role_0 = "foo,v2,foobar"
    expect_0 = OrderedDict([('name', 'foobar'), ('scm', None), ('src', 'foo'), ('version', 'v2')])
    actual_0 = role_requirement_0.role_yaml_parse(role_0)
    if expect_0 != actual_0:
      print("Failed")

# Generated at 2022-06-25 05:57:11.864482
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_role_0 = {'a': 1, 'b': 2}
    actual_result = RoleRequirement.role_yaml_parse(test_role_0)
    expected_result = {'a': 1, 'b': 2, 'scm': None, 'name': None, 'src': None, 'version': None}
    assert actual_result == expected_result
    return


# Generated at 2022-06-25 05:57:18.342540
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    print("Unit test for repo_url_to_role_name")
    repo_url = "git://git.example.com/repos/repo.git"
    print("Testing the method with value ", repo_url)
    expected_result = "repo"
    result = RoleRequirement.repo_url_to_role_name(repo_url)
    if result == expected_result:
        print("Test Passed")
    else:
        print("Test Failed with this error: ", result, " ", expected_result)

# Generated at 2022-06-25 05:57:26.516199
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1') == 'repo'
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1,role') == 'repo'


# Generated at 2022-06-25 05:57:30.985210
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement=RoleRequirement()
    test_1=role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    assert test_1=='repo'


# Generated at 2022-06-25 05:57:37.164730
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    r = RoleRequirement()
    assert r.repo_url_to_role_name('https://github.com/someuser/somerepo') == 'somerepo'
    assert r.repo_url_to_role_name('git@github.com:someuser/somerepo') == 'somerepo'
    assert r.repo_url_to_role_name('someuser.github.com/somerepo') == 'somerepo'
    assert r.repo_url_to_role_name('https://github.com/someuser/somerepo.git') == 'somerepo'
    assert r.repo_url_to_role_name('git@github.com:someuser/somerepo.git') == 'somerepo'
    assert r.repo_url_to_role_name

# Generated at 2022-06-25 05:57:41.315045
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml_parse = RoleRequirement.role_yaml_parse('test_galaxy.role_name.tar.gz')
    assert isinstance(role_yaml_parse, dict)
    assert role_yaml_parse['name'] == 'test_galaxy.role_name.tar.gz'
    assert role_yaml_parse['src'] == 'test_galaxy.role_name.tar.gz'
    assert role_yaml_parse['version'] == None
    assert role_yaml_parse['scm'] == None


# Generated at 2022-06-25 05:57:49.065638
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    a = RoleRequirement()
    input_str = "example.com/role_name,v0.1.0,the_name"
    role_dict = a.role_yaml_parse(input_str)
    print ("role_dict: %s" % role_dict)
    assert role_dict["name"] == "the_name"
    assert role_dict["src"] == "example.com/role_name"
    assert role_dict["version"] == "v0.1.0"
    assert role_dict["scm"] == None


# Generated at 2022-06-25 05:57:53.629128
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Case 0: Testing for a repo_url that is not a git repo
    src = "git@github.com:ansible/ansible"
    role_name = RoleRequirement.repo_url_to_role_name(src)
    assert role_name == "ansible"

    # Case 1: Testing for a repo_url that is a git repo
    src = "github.com:ansible/ansible"
    role_name = RoleRequirement.repo_url_to_role_name(src)
    assert role_name == "ansible"

    # Case 2: Testing for a repo_url that is a not a git repo
    src = "http://github.com:ansible/ansible"
    role_name = RoleRequirement.repo_url_to_role_name(src)
    assert role_name

# Generated at 2022-06-25 05:57:58.506525
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-25 05:58:12.330285
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_obj_1 = RoleRequirement()
    test_1 = "{'src': 'git@github.com:some_organization/some_repo.git', 'version': 'some_version', 'name': 'some_name'}"
    test_1_result = role_requirement_obj_1.role_yaml_parse(test_1)
    assert test_1_result == {'src': 'git@github.com:some_organization/some_repo.git', 'version': 'some_version', 'name': 'some_name'}


# Generated at 2022-06-25 05:58:16.826088
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    # Test parse of requirement with only src
    if role_requirement_0.role_yaml_parse("ansible/ssh-hardening")['src'] == "ansible/ssh-hardening"\
        and role_requirement_0.role_yaml_parse("ansible/ssh-hardening")['name'] == "ssh-hardening"\
        and role_requirement_0.role_yaml_parse("ansible/ssh-hardening")['scm'] is None\
        and role_requirement_0.role_yaml_parse("ansible/ssh-hardening")['version'] == '':
        return True

    # Test parse of requirement with src and name

# Generated at 2022-06-25 05:58:27.236798
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Testing a simple case of url
    url = 'http://git.example.com/repos/repo.git'
    expected = {'name':'repo', 'scm': None, 'src': 'http://git.example.com/repos/repo.git', 'version': None}
    assert RoleRequirement.role_yaml_parse(url) == expected
    # Testing the case of having a version
    url_ver = 'http://git.example.com/repos/repo.git,1.0.1'
    expected_ver = {'name': 'repo', 'scm': None, 'src': 'http://git.example.com/repos/repo.git', 'version': '1.0.1'}

# Generated at 2022-06-25 05:58:32.840975
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()

    print("##################################################################################################")
    print("TESTING: role_yaml_parse")
    print("##################################################################################################")

    ###################################################################################################
    print("TEST A: Single string with active role")
    role_input_0 = "role_name"

    role_output_0 = role_requirement_0.role_yaml_parse(role_input_0)

    print("single string with active role = " + str(role_output_0))
    if (role_output_0 != {'name': 'role_name', 'scm': None, 'src': None, 'version': ''}):
        print("UNIT TEST FAILED")

    ###################################################################################################
    print("TEST B: Single string with src")
    role_input

# Generated at 2022-06-25 05:58:41.050661
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    repo_url1 = "https://github.com/ansible/ansible-modules-extras.git"
    role_name1 = "ansible-modules-extras"
    assert role_name1 == role_requirement_1.repo_url_to_role_name(repo_url1)
    repo_url2 = "https://github.com/ansible/ansible-modules-extras.git,v1.1"
    role_name2 = "ansible-modules-extras"
    assert role_name2 == role_requirement_1.repo_url_to_role_name(repo_url2)

# Generated at 2022-06-25 05:58:49.785851
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement = RoleRequirement()
    role = 'geerlingguy.git'
    expected = {'name': 'geerlingguy.git', 'src': 'geerlingguy.git', 'scm': None, 'version': None}
    returned = role_requirement.role_yaml_parse(role)
    assert expected == returned

    role = {'role': 'geerlingguy.git,v1.0', 'name': 'geerlingguy.git'}
    expected = {'name': 'geerlingguy.git', 'role': 'geerlingguy.git,v1.0', 'src': 'geerlingguy.git,v1.0', 'scm': None, 'version': 'v1.0'}
    returned = role_requirement.role_yaml_parse(role)

# Generated at 2022-06-25 05:59:01.030433
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    name_0 = role_requirement_0.role_yaml_parse("test_src_0")
    name_1 = role_requirement_0.role_yaml_parse("test_scm_0+test_src_1")
    name_2 = role_requirement_0.role_yaml_parse("test_scm_1+test_src_2,test_version_0")
    name_3 = role_requirement_0.role_yaml_parse("test_src_3,test_version_1,test_name_0")
    name_4 = role_requirement_0.role_yaml_parse("test_scm_2+test_src_4,test_version_2,test_name_1")

# Generated at 2022-06-25 05:59:11.173400
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print("Testing method role_yaml_parse of class RoleRequirement")

    role_requirement = RoleRequirement()

    role = role_requirement.role_yaml_parse(role="git+https://github.com/geerlingguy/ansible-role-apache.git")
    assert role["name"] == "ansible-role-apache"
    assert role["scm"] == "git"
    assert role["src"] == "https://github.com/geerlingguy/ansible-role-apache.git"
    assert role["version"] == ""


    role = role_requirement.role_yaml_parse(role="https://github.com/geerlingguy/ansible-role-apache,v1.0,geerlingguy.apache")
    assert role["name"] == "geerlingguy.apache"

# Generated at 2022-06-25 05:59:23.009538
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    # Case 1:
    assert role_requirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache.git') == 'ansible-role-apache'
    # Case 2:
    assert role_requirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache') == 'ansible-role-apache'
    # Case 3:
    assert role_requirement.repo_url_to_role_name('git@github.com:geerlingguy/ansible-role-apache.git') == 'ansible-role-apache'
    # Case 4:

# Generated at 2022-06-25 05:59:33.903209
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-25 05:59:50.007194
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('test') == {'name': 'test', 'scm': None, 'src': 'test', 'version': None}
    assert role_requirement.role_yaml_parse('test,') == {'name': 'test', 'scm': None, 'src': 'test', 'version': None}
    assert role_requirement.role_yaml_parse('test,1.1') == {'name': 'test', 'scm': None, 'src': 'test', 'version': '1.1'}
    assert role_requirement.role_yaml_parse('test,1.1,') == {'name': 'test', 'scm': None, 'src': 'test', 'version': '1.1'}

# Generated at 2022-06-25 05:59:57.751750
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_yaml_parse_arg_1 = 'galaxy.role,1.0'
    role_yaml_parse_res_1 = role_requirement_1.role_yaml_parse(role_yaml_parse_arg_1)
    assert role_yaml_parse_res_1 == {'name': 'galaxy.role', 'src': 'galaxy.role', 'scm': None, 'version': '1.0'}
    role_requirement_2 = RoleRequirement()
    role_yaml_parse_arg_2 = 'src: galaxy.role,1.0'
    role_yaml_parse_res_2 = role_requirement_2.role_yaml_parse(role_yaml_parse_arg_2)

# Generated at 2022-06-25 06:00:08.792720
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    role_name = role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.git')
    assert(role_name == 'repo')

    role_name = role_requirement.repo_url_to_role_name('git@git.example.com:repos/repo.git')
    assert(role_name == 'repo')

    role_name = role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz')
    assert(role_name == 'repo')


# Generated at 2022-06-25 06:00:16.238703
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    assert role_requirement_0.role_yaml_parse('test_proj.testing,foo,nginx')['name'] == 'nginx'
    assert role_requirement_0.role_yaml_parse('test_proj.testing,foo')['name'] == 'test_proj.testing'
    assert role_requirement_0.role_yaml_parse('git+https://github.com/geerlingguy/ansible-role-mysql.git,98a2a8a59e254f9edbb2fe7b1e21f67eff716d3e,geerlingguy.mysql')['name'] == 'geerlingguy.mysql'

# Generated at 2022-06-25 06:00:27.853011
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name("https://github.com/username/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("https://github.com/username/repo,master") == "repo"
    assert role_requirement.repo_url_to_role_name("git@github.com:username/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("/path/to/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("/path/to/repo.tar.gz") == "repo"

# Generated at 2022-06-25 06:00:35.063256
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1 - check the new style
    role_requirement_1 = RoleRequirement()
    role_1 = role_requirement_1.role_yaml_parse({"src": "geerlingguy.ntp", "name": "ntp"})
    assert role_1['name'] == "ntp"
    assert role_1['src'] == "geerlingguy.ntp"

    # Test case 2 - check the old style
    role_requirement_2 = RoleRequirement()
    role_2 = role_requirement_2.role_yaml_parse({"role": "geerlingguy.ntp"})
    assert role_2['name'] == "geerlingguy.ntp"

    # Test case 3 - check the old style, with version
    role_requirement_3 = RoleRequirement()

# Generated at 2022-06-25 06:00:39.301439
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    url = "http://git.example.com/repos/repo.git"
    role_name = role_requirement.repo_url_to_role_name(url)
    assert role_name == "repo"



# Generated at 2022-06-25 06:00:46.709760
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    # Retrieve test data from the test data file
    f = open("./test/unit/utils/data/ansible-role-requirement/role_yaml_parse.json")
    json_string = f.read()
    f.close()

    # Parse string to json format
    role_requirement_data = json.loads(json_string)

    # Do test
    for role_requirement_item in role_requirement_data:
        # Test the method role_yaml_parse of class RoleRequirement with result
        assert role_requirement.role_yaml_parse(role_requirement_item["role_param"]) == role_requirement_item["role_result"], "role_yaml_parse() method failed with error message: %s" % role_requirement

# Generated at 2022-06-25 06:00:54.874668
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()

    # Test using a valid input: a string containing a comma-separated list of at least two strings
    src = 'galaxy.role'
    scm = 'git'
    version = ''
    name = 'galaxy.role'

    role_requirement_1.role_yaml_parse(role = 'galaxy.role')
    assert role_requirement_1.name == name
    assert role_requirement_1.src == src
    assert role_requirement_1.scm == scm
    assert role_requirement_1.version == version

    # Test using a valid input: a string containing a comma-separated list of at least two strings
    src = 'galaxy.role,10.5'
    scm = 'git'

# Generated at 2022-06-25 06:01:05.920331
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    # Test role_yaml_parse method with a string argument
    role = "https://github.com/apache/storm.git"
    expected_result = {'name': 'storm', 'src': 'https://github.com/apache/storm.git', 'scm': None, 'version': ''}
    actual_result = role_requirement.role_yaml_parse(role)
    assert expected_result == actual_result

    # Test role_yaml_parse with an object argument
    role = {'src': 'https://github.com/apache/storm.git', 'version': '1.0.x'}

# Generated at 2022-06-25 06:01:24.744216
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role = {'role': 'galaxy.role_name'}
    out = role_requirement_0.role_yaml_parse(role)
    assert out['src'] == 'galaxy.role_name'
    assert out['name'] == 'role_name'
    assert out['scm'] == None
    assert out['version'] == ''


# Generated at 2022-06-25 06:01:34.734637
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()


# Generated at 2022-06-25 06:01:41.454300
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role_yaml_parse_results_expected = dict(name='foo', src='https://github.com/bar/foo.git', scm=None, version='0.1')
    role_yaml_parse_results_actual = role_requirement.role_yaml_parse('foo,0.1')
    assert role_yaml_parse_results_expected == role_yaml_parse_results_actual, 'test_RoleRequirement_role_yaml_parse() failed'


# Generated at 2022-06-25 06:01:44.867572
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()

    src = 'michaelxu-ansible-cobbler-server'
    scm = 'git'
    version = 'v1.1'
    expected_result = {'src': src, 'scm': scm, 'name': src, 'version': version}
    role = role_requirement_0.role_yaml_parse('%s,%s,%s' % (src, version, '%s' % src))
    assert role == expected_result

# Generated at 2022-06-25 06:01:54.341476
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': ''}
    assert role_requirement.role_yaml_parse('geerlingguy.apache,1.7.1') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': '1.7.1'}

# Generated at 2022-06-25 06:01:59.850383
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    repo_url_0 = 'git@git.company.com:ansible/ansible-modules-core.git'
    expected = 'ansible-modules-core'
    actual = RoleRequirement.repo_url_to_role_name(repo_url_0)
    print("Result for test_RoleRequirement_repo_url_to_role_name: " + str(actual == expected))
    print("Expected result: " + str(expected))
    print("Actual result: " + str(actual))
    repo_url_1 = 'git+http://git.company.com/ansible/ansible-modules-core.git@devel'
    expected = 'ansible-modules-core'
    actual = RoleRequirement.repo_url_to_role_name(repo_url_1)
   

# Generated at 2022-06-25 06:02:06.428502
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_role_requirement = RoleRequirement()
    #Test case where name is not present
    role = "https://github.com/ansible/ansible-examples.git,devel"
    expected_name = "ansible-examples"
    actual_name = test_role_requirement.role_yaml_parse(role)['name']
    assert expected_name == actual_name
    #Test case where name is present
    role = "https://github.com/ansible/ansible-examples.git,devel,TestRole"
    expected_name = "TestRole"
    actual_name = test_role_requirement.role_yaml_parse(role)['name']
    assert expected_name == actual_name
    #Test case with old style role

# Generated at 2022-06-25 06:02:11.732579
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    assert role_requirement_1.repo_url_to_role_name('https://github.com/pearlhq/ansible-keepalived.git') == 'ansible-keepalived'

# Generated at 2022-06-25 06:02:22.973062
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    expected_0 = dict(name='role_name', src='galaxy.role', scm=None, version='')
    test_0 = role_requirement_0.role_yaml_parse('role_name')
    assert expected_0 == test_0

    role_requirement_1 = RoleRequirement()
    expected_1 = dict(name='home.user.role', src='https://github.com/home_user/role.git', scm=None, version='')
    test_1 = role_requirement_1.role_yaml_parse('home.user.role')
    assert expected_1 == test_1


# Generated at 2022-06-25 06:02:32.875409
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    repo_url = "https\://github.com/ansible/ansible-examples.git"
    assert RoleRequirement.repo_url_to_role_name(repo_url) == "ansible-examples"
    repo_url = "https://github.com/ansible/ansible-examples"
    assert RoleRequirement.repo_url_to_role_name(repo_url) == "ansible-examples"
    repo_url = "git@github.com\:ansible/ansible-examples.git"
    assert RoleRequirement.repo_url_to_role_name(repo_url) == "ansible-examples"
    repo_url = "http://github.com/ansible/ansible-examples"
   

# Generated at 2022-06-25 06:03:08.225211
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = {'role': 'user.name,1.0', 'x': 'y'}
    RoleRequirement.role_yaml_parse(role)
    assert role == {'src': 'user.name', 'name': 'user.name', 'scm': None, 'version': '1.0', 'x': 'y'}

    role = {'role': 'user.name'}
    RoleRequirement.role_yaml_parse(role)
    assert role == {'name': 'user.name', 'src': 'user.name', 'scm': None, 'version': ''}



# Generated at 2022-06-25 06:03:17.780102
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement() # create an object from class RoleRequirement

    # Tests for role_yaml_parse always use format string_type => dict
    # Tests for role_yaml_parse with string_type
    ssh_key_type = 'string_type'
    ssh_key_type_list = ['string_type']
    ssh_key_type_dict = {'type': 'string'}
    for each_ssh_key_type in [ssh_key_type, ssh_key_type_list, ssh_key_type_dict]:
        expected = {'name': 'galaxy.role', 'scm': None, 'src': 'galaxy.role', 'version': ''}
        obtained = role_requirement_0.role_yaml_parse(each_ssh_key_type)
        assert expected

# Generated at 2022-06-25 06:03:21.588308
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    assert role_requirement_1.repo_url_to_role_name('git+https://github.com/myrepo/myrole.git,v1.0') == 'myrole'


# Generated at 2022-06-25 06:03:27.124138
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test case 0
    print('Test case 0')
    print('Test for resolving role name from URL')
    role_spec_0 = role_requirement_0.role_yaml_parse('https://github.com/chafey/dicomweb-client')
    assert role_spec_0['name'] == 'dicomweb-client'
    assert role_spec_0['version'] == ''
    assert role_spec_0['src'] == 'https://github.com/chafey/dicomweb-client'
    assert role_spec_0['scm'] == 'git'

    # Test case 1
    print('Test case 1')
    print('Test for resolving role name from scm URL')

# Generated at 2022-06-25 06:03:36.838906
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    with pytest.raises(AnsibleError):
        role_requirement_0 = RoleRequirement()
        role_requirement_0.role_yaml_parse("name, v1, v2, v3")

    # Test 1
    # Tests parsing of a role string:
    #  - input argument: {role_str}
    #  - expected output: role_dict

    role_requirement_1 = RoleRequirement()
    role_str = "geerlingguy.java"
    role_dict = role_requirement_1.role_yaml_parse(role_str)
    assert (role_dict['name'] == 'geerlingguy.java')
    assert (role_dict['src'] == 'geerlingguy.java')
    assert (role_dict['scm'] == None)

# Generated at 2022-06-25 06:03:46.757697
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Tests when `role` is a string
    assert RoleRequirement.role_yaml_parse('myrole') == {'name': 'myrole', 'src': 'myrole', 'scm': None, 'version': None}
    # Tests when `role` is a dictionary
    assert RoleRequirement.role_yaml_parse({'role': 'myrole', 'version': 1}) == {'name': 'myrole', 'src': 'myrole', 'scm': None, 'version': '1'}

# Generated at 2022-06-25 06:03:55.684821
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_1 = RoleRequirement()
    role_requirement_2 = RoleRequirement()
    role_requirement_3 = RoleRequirement()
    role_requirement_4 = RoleRequirement()
    role_requirement_5 = RoleRequirement()
    role_requirement_6 = RoleRequirement()
    role_requirement_7 = RoleRequirement()
    role_requirement_8 = RoleRequirement()
    role_requirement_9 = RoleRequirement()
    role_requirement_10 = RoleRequirement()
    role_requirement_11 = RoleRequirement()
    role_requirement_12 = RoleRequirement()
    role_requirement_13 = RoleRequirement()
    role_requirement_14 = RoleRequirement()
    role_requ

# Generated at 2022-06-25 06:04:00.436978
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    display.info('Test: role_yaml_parse should return dict with expected structure')
    role_requirement_0 = RoleRequirement()
    role = role_requirement_0.role_yaml_parse(role="role_name[,version[,name]]")
    expected = {
        "name": "role_name",
        "version": "version",
        "src": "name",
        "scm": None
    }
    assert role == expected


# Generated at 2022-06-25 06:04:12.004001
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.michael.de/my_ansible_role.git') == 'my_ansible_role'
    assert RoleRequirement.repo_url_to_role_name('http://git.michael.de/my_ansible_role,some_version.git') == 'my_ansible_role,some_version'
    assert RoleRequirement.repo_url_to_role_name('http://git.michael.de/my_ansible_role,some_version,some_name.git') == 'my_ansible_role,some_version,some_name'

# Generated at 2022-06-25 06:04:23.103673
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()

    role_yaml_parse_0 = role_requirement_0.role_yaml_parse('test_value_0')
    assert role_yaml_parse_0 == {'name': 'test_value_0', 'src': 'test_value_0', 'version': None, 'scm': None}

    role_yaml_parse_1 = role_requirement_0.role_yaml_parse('test_value_0,test_value_1')
    assert role_yaml_parse_1 == {'name': 'test_value_0', 'src': 'test_value_0', 'version': 'test_value_1', 'scm': None}
