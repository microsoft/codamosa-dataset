

# Generated at 2022-06-25 05:55:34.523804
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # test case 0
    role_requirement_0 = RoleRequirement()
    role_0 = dict(name='rolename', scm='git', src='github.com/rolename.git')
    assert role_requirement_0.role_yaml_parse(role_0) == dict(name='rolename', scm='git', src='github.com/rolename.git', version='')


# Generated at 2022-06-25 05:55:36.421807
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()


# Generated at 2022-06-25 05:55:42.569646
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    repo_url = 'http://git.example.com/repos/repo.git'
    expected_role_name = 'repo'

    returned_role_name = RoleRequirement.repo_url_to_role_name(repo_url)

    assert returned_role_name == expected_role_name, \
        "RoleRequirement.repo_url_to_role_name('%s'). Got: %s Expected: %s" % \
        (repo_url, returned_role_name, expected_role_name)


# Generated at 2022-06-25 05:55:46.501301
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    role_name_0 = role_requirement_0.repo_url_to_role_name(repo_url='https://github.com/ansible/ansible-modules-extras')
    assert role_name_0 != None
    test_complete('RoleRequirement', 'repo_url_to_role_name')


# Generated at 2022-06-25 05:55:54.306780
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # set up test case
    role_requirement_0 = RoleRequirement()

    data = """
    - role: michaelmiiller.influxdb
      when: ansible_os_family == 'Debian'
    """
    obj = RoleRequirement.role_yaml_parse(data)
    assert obj == dict(name='michaelmiiller.influxdb',
                       src=None,
                       scm=None,
                       version=None)

# Generated at 2022-06-25 05:56:04.141584
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/example/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/example/repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/example/repo,master") == "repo"

# Generated at 2022-06-25 05:56:14.721515
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("git@git.example.com/repos/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1") == "repo,v1"
    assert role_requirement.repo_url_to_role_name("git@git.example.com/repos/repo,v1") == "repo,v1"

# Generated at 2022-06-25 05:56:25.202984
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    print("Testing RoleRequirement_repo_url_to_role_name ...")
    url = 'https://github.com/ansible/ansible-modules-core/archive/master.zip'
    assert RoleRequirement.repo_url_to_role_name(url) == 'ansible-modules-core'
    url = 'git+git://github.com/ansible/ansible-modules-core.git'
    assert RoleRequirement.repo_url_to_role_name(url) == 'ansible-modules-core'
    url = 'https://github.com/ansible/ansible-modules-core.git,v1.1'
    assert RoleRequirement.repo_url_to_role_name(url) == 'ansible-modules-core'

# Generated at 2022-06-25 05:56:35.085765
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()
    # Test of simple case: one mandatory parameter: name
    print("Test of simple case: one mandatory parameter: name")
    simple_case = 'scenario_0'
    result = RoleRequirement.role_yaml_parse(simple_case)
    assert (RoleRequirement.repo_url_to_role_name(simple_case) == result['name'])
    assert ('' == result['src'])

    # Test of version case: one mandatory parameter: name and version
    print("Test of version case: one mandatory parameter: name and version")
    version_case = 'scenario_0,latest'
    result = RoleRequirement.role_yaml_parse(version_case)

# Generated at 2022-06-25 05:56:46.281489
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role = role_requirement.role_yaml_parse("sudosh2-1.2.2")
    assert role == {"name": "sudosh2", "src": "sudosh2-1.2.2", "version": "", "scm": None}

    role = role_requirement.role_yaml_parse("sudosh2@1.2.2")
    assert role == {"name": "sudosh2", "src": "sudosh2@1.2.2", "version": "", "scm": None}

    role = role_requirement.role_yaml_parse("geerlingguy.java")

# Generated at 2022-06-25 05:56:57.287286
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_1 = RoleRequirement()
    role_text_1 = "geerlingguy.java,1.7"
    role_text_2 = "geerlingguy.java,1.7,jdk"
    role_text_3 = "geerlingguy.java,,jdk"
    role_text_4 = "geerlingguy.java,1.8,jdk"

    ret = role_requirement_1.role_yaml_parse(role_text_1)
    assert ret['src'] == "geerlingguy.java"
    assert ret['version'] == "1.7"

    ret = role_requirement_1.role_yaml_parse(role_text_2)
    assert ret['src'] == "geerlingguy.java"

# Generated at 2022-06-25 05:57:05.510971
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role = role_requirement_1.role_yaml_parse('git+https://github.com/geerlingguy/ansible-role-apache,1.7.2')
    assert role['name'] == 'ansible-role-apache'
    assert role['src'] == 'https://github.com/geerlingguy/ansible-role-apache'
    assert role['scm'] == 'git'
    assert role['version'] == '1.7.2'


# Generated at 2022-06-25 05:57:09.649938
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()

    # Test with string_types
    role = 'name'
    role_requirement_0.role_yaml_parse(role)

    # Test with dict
    role = {'role': 'name'}
    role_requirement_0.role_yaml_parse(role)


# Generated at 2022-06-25 05:57:12.574753
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse(role="http://github.com/jlund/ansible-opsworks,v2.2.2")
#

# Generated at 2022-06-25 05:57:19.140079
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()

    role_0 = role_requirement_0.role_yaml_parse("  https://github.com/geerlingguy/ansible-role-repo-epel,1.0.0,geerlingguy.repo-epel  ")
    assert role_0['name'] == 'geerlingguy.repo-epel'
    assert role_0['src'] == 'https://github.com/geerlingguy/ansible-role-repo-epel'
    assert role_0['scm'] == None
    assert role_0['version'] == '1.0.0'

# Generated at 2022-06-25 05:57:27.457845
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()

    # Test for valid input
    test_case_0 = {'role': 'nginx', 'scm': None, 'src': 'nginx', 'version': '', 'name': 'nginx'}
    result_0 = role_requirement_0.role_yaml_parse(role='nginx')
    assert result_0 == test_case_0

    # Test for valid input
    test_case_1 = {'role': 'nginx', 'scm': None, 'src': 'nginx', 'version': '', 'name': 'nginx'}
    result_1 = role_requirement_0.role_yaml_parse(role=dict(role='nginx'))
    assert result_1 == test_case_1

    # Test for valid input
    test

# Generated at 2022-06-25 05:57:33.750572
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()

    # repo_url_to_role_name with None as the value for parameter repo_url
    assert role_requirement_1.repo_url_to_role_name(None) == None

    # repo_url_to_role_name with "https://github.com/galaxyproject/ansible-galaxy" as the value for parameter repo_url
    assert role_requirement_1.repo_url_to_role_name('https://github.com/galaxyproject/ansible-galaxy') == 'ansible-galaxy'

    # repo_url_to_role_name with "https://github.com/galaxyproject/ansible-galaxy.git" as the value for parameter repo_url
    assert role_requirement_1.repo_url_to_

# Generated at 2022-06-25 05:57:40.763893
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    correct_url_value_1 = 'geerlingguy.apache'
    correct_url_value_2 = 'geerlingguy.mysql'
    correct_url_value_3 = 'geerlingguy.php'
    correct_url_value_4 = 'geerlingguy.composer'
    correct_url_value_5 = 'geerlingguy.php'
    correct_url_value_6 = 'geerlingguy.memcached'
    correct_url_value_7 = 'geerlingguy.php'
    correct_url_value_8 = 'geerlingguy.solr'
    correct_url_value_9 = 'geerlingguy.mysql'

# Generated at 2022-06-25 05:57:47.044033
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    result = role_requirement.role_yaml_parse('https://github.com/bennojoy/nginx')
    assert 'name' in result
    assert 'src' in result
    assert 'scm' in result
    assert 'version' in result
    assert result['name'] == 'nginx'
    assert result['src'] == 'https://github.com/bennojoy/nginx'
    assert result['version'] == ''
    assert result['scm'] == 'git'


# Generated at 2022-06-25 05:57:56.337352
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    dict_src = dict(name='foo', scm='git', version='HEAD', src='git@github.com/ansible/ansible-modules-core.git', extra_var='foobar')
    dict_src_invalid = dict(name='foo', scm='git', version='HEAD', src='git@github.com/ansible/ansible-modules-core.git', extra_var='foobar', invalid_key='barfoo')
    dict_src_lowercase = dict(name='foo', scm='git', version='HEAD', src='git@github.com/ansible/ansible-modules-core.git', extra_var='foobar')

# Generated at 2022-06-25 05:58:10.608414
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 05:58:20.168778
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    assert role_requirement.role_yaml_parse('src name') == dict(name='name', src='src', scm=None, version=None)
    assert role_requirement.role_yaml_parse('src,name') == dict(name='name', src='src', scm=None, version=None)
    assert role_requirement.role_yaml_parse('src,version,name') == dict(name='name', src='src', scm=None, version='version')
    assert role_requirement.role_yaml_parse('src, version, name') == dict(name='name', src='src', scm=None, version='version')

# Generated at 2022-06-25 05:58:28.169731
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    test_role_requirement_1_0 = role_requirement_1.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    assert(test_role_requirement_1_0 == "repo")
    test_role_requirement_1_1 = role_requirement_1.repo_url_to_role_name("http://git.example.com/repos/repo")
    assert(test_role_requirement_1_1 == "repo")
    test_role_requirement_1_2 = role_requirement_1.repo_url_to_role_name("http://git.example.com/repos/repo,0.1")

# Generated at 2022-06-25 05:58:39.171291
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-25 05:58:42.068082
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"


# Generated at 2022-06-25 05:58:50.678186
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()

    # testing 'git+git@github.com:geerlingguy/ansible-role-apache.git'
    repo_url = 'git+git@github.com:geerlingguy/ansible-role-apache.git'
    result = role_requirement_1.repo_url_to_role_name(repo_url)
    assert result == 'ansible-role-apache'

    # testing 'ansible-role-apache'
    repo_url = 'ansible-role-apache'
    result = role_requirement_1.repo_url_to_role_name(repo_url)
    assert result == 'ansible-role-apache'

    # testing 'git@github.com:geerlingguy/ansible-role-apache.git'

# Generated at 2022-06-25 05:59:01.289406
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com:repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+https://git.example.com/repos/repo.git') == 'repo'

# Generated at 2022-06-25 05:59:11.237761
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_instance = RoleRequirement()
    print("Testing repo_url_to_role_name of class RoleRequirement")
    assert role_requirement_instance.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role_requirement_instance.repo_url_to_role_name("https://git.example.com/repos/repo2.git") == "repo2"
    assert role_requirement_instance.repo_url_to_role_name("git.example.com/repos/repo3.git") == "repo3"
    assert role_requirement_instance.repo_url_to_role_name("repo4.git") == "repo4"
    assert role_requ

# Generated at 2022-06-25 05:59:23.009471
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role = {
        'name': 'test_name',
        'scm': 'test_scm',
        'src': 'test_src',
        'version': 'test_version',
    }
    expected_result = role
    result = role_requirement.role_yaml_parse(role)
    assert expected_result == result

    role = 'test_name,test_version,test_src'
    expected_result = {
        'name': 'test_name',
        'scm': None,
        'src': 'test_version,test_src',
        'version': None,
    }
    result = role_requirement.role_yaml_parse(role)
    assert expected_result == result

    role = 'test_name,test_version'


# Generated at 2022-06-25 05:59:28.996308
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert isinstance(role_requirement.role_yaml_parse("https://github.com/gantsign/ansible-role-stunnel.git,v1.0.0,gantsign.stunnel"), dict)


# Generated at 2022-06-25 05:59:46.293796
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement = RoleRequirement()

    spec_file = {'src': './'}
    role_data = role_requirement.role_yaml_parse(spec_file)

    assert role_requirement.role_yaml_parse({'src': './'}) == {'src': './', 'scm': None, 'name': None, 'version': ''}
    assert role_requirement.role_yaml_parse({'role': 'geerlingguy.java'}) == {'src': 'geerlingguy.java', 'scm': None, 'name': 'geerlingguy.java', 'version': ''}


# Generated at 2022-06-25 05:59:55.156927
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Case 0
    role_requirement_0 = RoleRequirement()
    role_0 = 'geerlingguy.java'
    role_1 = 'geerlingguy.java,1.8.0'
    role_2 = 'geerlingguy.java,1.8.0,java'
    role_3 = 'geerlingguy.java,,java'
    role_4 = 'geerlingguy.java,1.8.0,'
    role_5 = 'geerlingguy.java,,name'
    role_6 = 'geerlingguy.java,,'
    role_7 = 'geerlingguy.java,1.8.0,1.8.0'
    role_8 = 'geerlingguy.java,1.8.0,1.8.0,1.8.0'


# Generated at 2022-06-25 05:59:56.620806
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"

# Generated at 2022-06-25 06:00:07.328584
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml_parse_0 = RoleRequirement.role_yaml_parse({'role': 'name'})
    assert type(role_yaml_parse_0) == dict
    assert role_yaml_parse_0['name'] == 'name'
    assert role_yaml_parse_0['scm'] is None
    assert role_yaml_parse_0['src'] is None
    assert role_yaml_parse_0['version'] is None
    role_yaml_parse_1 = RoleRequirement.role_yaml_parse({'role': 'name', 'src': 'url', 'scm': 'git'})
    assert type(role_yaml_parse_1) == dict
    assert role_yaml_parse_1['name'] == 'name'

# Generated at 2022-06-25 06:00:13.560605
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    role = { 'src': 'git+https://github.com/bertvv/ansible-role-php7.2.git' }
    result = role_requirement.role_yaml_parse(role)
    assert result['scm'] == "git"
    assert result['src'] == "https://github.com/bertvv/ansible-role-php7.2.git"


# Generated at 2022-06-25 06:00:20.986864
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement = RoleRequirement()

    # Ensure that an AnsibleError is raised for an invalid role 'role_name,name2,name3'
    invalid_role_spec_to_test = 'role_name,name2,name3'
    try:
        role_requirement.role_yaml_parse(invalid_role_spec_to_test)
        assert(False)
    except AnsibleError:
        assert(True)

    # Ensure that a role line 'role_name' returns the expected role object
    role_spec_to_test = 'role_name'
    expected_result = dict(name='role_name', src='role_name', scm=None, version='')
    role = role_requirement.role_yaml_parse(role_spec_to_test)

# Generated at 2022-06-25 06:00:29.772147
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print("Test method RoleRequirement.role_yaml_parse")

    role_requirement_0 = RoleRequirement()

    role = {'role': 'geerlingguy.nginx', 'name': None, 'scm': None, 'src': None, 'version': None}
    role_requirement_0.role_yaml_parse(role)

    role_0 = {'role': 'geerlingguy.nginx,1.0', 'name': None, 'scm': None, 'src': None, 'version': None}
    role_requirement_0.role_yaml_parse(role_0)

    role_1 = {'role': 'geerlingguy.nginx,1.0,my.nginx', 'name': None, 'scm': None, 'src': None, 'version': None}


# Generated at 2022-06-25 06:00:40.610359
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    display.display("Testing conversion of repo URL to role name")

    role_requirement = RoleRequirement()

    # Test parsing of valid input
    expected_role_name = "test-one"
    actual_role_name = role_requirement.repo_url_to_role_name("https://github.com/test-one.git")

    if expected_role_name != actual_role_name:
        display.display("Expected role name '%s', got '%s'" % (expected_role_name, actual_role_name))
        raise Exception("Expected role name '%s', got '%s'" % (expected_role_name, actual_role_name))

    expected_role_name = "another-name"

# Generated at 2022-06-25 06:00:52.279559
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    # test case with input value of "http://git.example.com/repos/repo.git"
    expected = "repo"
    actual = role_requirement_1.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    assert expected == actual
    # test case with input value of "http://git.example.com/repos/repo.tar.gz"
    expected = "repo"
    actual = role_requirement_1.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz")
    assert expected == actual
    # test case with input value of "http://git.example.com/repos/repo-1.2

# Generated at 2022-06-25 06:00:56.383351
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    if(role_requirement_1 == 'repo'):
        print("Test passed")
    else:
        print("Test Failed")


# Generated at 2022-06-25 06:01:11.164124
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_0 = 'role_name[,version[,name]]'
    role_requirement_1 = role_requirement_0.role_yaml_parse(role_0)
    assert role_requirement_1 is None


# Generated at 2022-06-25 06:01:15.658124
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Case 1: repo_url is http://git.example.com/repos/repo.git
    role_requirement_1 = RoleRequirement()
    repo_url = 'http://git.example.com/repos/repo.git'
    assert role_requirement_1.repo_url_to_role_name(repo_url) == 'repo'

    # Case 2: repo_url is git@git.example.com:repos/repo.git
    role_requirement_2 = RoleRequirement()
    repo_url = 'git@git.example.com:repos/repo.git'
    assert role_requirement_2.repo_url_to_role_name(repo_url) == 'repo'


# Generated at 2022-06-25 06:01:24.342355
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement=RoleRequirement()
    actual_result = role_requirement.role_yaml_parse("https://github.com/geerlingguy/ansible-role-apache.git,master")
    expected_result = dict(name='ansible-role-apache', src='https://github.com/geerlingguy/ansible-role-apache.git', scm='git', version='master')
    assert actual_result == expected_result
    #assert actual_result == expected_result, "Actual result: %s and expected result: %s did not match" % (actual_result, expected_result)


# Generated at 2022-06-25 06:01:33.851411
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    url = "https://github.com/geerlingguy/ansible-role-apache.git"
    assert RoleRequirement.repo_url_to_role_name(url) == "ansible-role-apache"

    url = "https://github.com/geerlingguy/ansible-role-apache,v2.2.2,name"
    assert RoleRequirement.repo_url_to_role_name(url) == "ansible-role-apache"

    url = "https://github.com/geerlingguy/ansible-role-apache.git"
    assert RoleRequirement.repo_url_to_role_name(url) == "ansible-role-apache"

# Generated at 2022-06-25 06:01:43.567265
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import yaml
    # TODO: Redesign tests for RoleRequirement
    #role_requirement = RoleRequirement()
    #role_requirement.role_yaml_parse("test,v1.2.3")

    expected_yaml_0 = "name: test\nscm: null\nsrc: test\nversion: v1.2.3\n"
    role_requirement_0 = RoleRequirement.role_yaml_parse("test,v1.2.3")
    yaml_out = yaml.dump(role_requirement_0, default_flow_style=False, allow_unicode=True)
    print("yaml_out:    %s" % yaml_out)
    print("expected_yaml_0: %s" % expected_yaml_0)
    assert y

# Generated at 2022-06-25 06:01:49.925032
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement = RoleRequirement()

    # Test "Old-style" YAML requirement spec.
    role_spec_1 = dict(
        name="geerlingguy.nginx",
        src="https://github.com/geerlingguy/ansible-role-nginx",
        version="1.9.7"
    )
    parsed_role_1 = role_requirement.role_yaml_parse(role_spec_1)
    if not parsed_role_1 == role_spec_1:
        raise AssertionError("role_yaml_parse() failed to parse old-style role spec.")

    # Test 'src: scm' requirement spec.

# Generated at 2022-06-25 06:01:57.328031
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()


# Generated at 2022-06-25 06:02:06.174134
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_1 = RoleRequirement()
    role_requirement_2 = RoleRequirement()
    role_requirement_3 = RoleRequirement()
    role_requirement_4 = RoleRequirement()
    role_requirement_5 = RoleRequirement()
    role_requirement_6 = RoleRequirement()
    role_requirement_7 = RoleRequirement()
    role_requirement_8 = RoleRequirement()
    role_requirement_9 = RoleRequirement()
    role_requirement_10 = RoleRequirement()
    role_requirement_11 = RoleRequirement()
    role_requirement_12 = RoleRequirement()
    role_requirement_13 = RoleRequirement()
    role_requirement_14 = RoleRequirement()

    assert role_

# Generated at 2022-06-25 06:02:16.926255
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 06:02:17.975013
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    pass

# Generated at 2022-06-25 06:02:34.557760
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case No. 1
    role = dict(role="plugin.name, 1.0")
    data = RoleRequirement.role_yaml_parse(role)
    assert data == dict(name="plugin.name", src=None, scm=None, version="1.0")

    # Test case No. 2
    role = dict(role="git+git@github.com:user/repo.git, 1.0")
    data = RoleRequirement.role_yaml_parse(role)
    assert data == dict(name="repo", src="git@github.com:user/repo.git", scm="git", version="1.0")

    # Test case No. 3
    role = dict(role="any_string")
    data = RoleRequirement.role_yaml_parse(role)
    assert data

# Generated at 2022-06-25 06:02:38.134375
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    rolesource = "git+ssh://git@github.com/geerlingguy/ansible-role-drupal.git"
    expected_result = "ansible-role-drupal"
    result = RoleRequirement.repo_url_to_role_name(rolesource)
    assert(result == expected_result)


# Generated at 2022-06-25 06:02:45.418096
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    assert RoleRequirement.role_yaml_parse("https://github.com/geerlingguy/ansible-role-apache.git,v1.0.1,geerlingguy.apache") == {'name': 'geerlingguy.apache', 'version': 'v1.0.1', 'scm': None, 'src': 'https://github.com/geerlingguy/ansible-role-apache.git'}

# Generated at 2022-06-25 06:02:55.157856
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """Case 1:
    1. Input is a new-style role definition containing 'name', 'scm', 'src', and 'version'
    2. All expected field values should be same as input value.
    """
    role_requirement_0 = RoleRequirement()
    role_definition = {u'src': u'git+git@git.example.com:path/to/repo.git', u'name': u'has_name', u'scm': u'git', u'version': u'1.0'}
    # Generate method input
    # Generate expected result

# Generated at 2022-06-25 06:03:01.417657
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Case 0: Valid role line
    test_case_0 = dict(name='geerlingguy.apache', src='geerlingguy.apache', version='')
    assert(test_case_0 == RoleRequirement.role_yaml_parse('geerlingguy.apache'))

    # Case 1: Valid role line with version
    test_case_1 = dict(name='geerlingguy.apache', src='geerlingguy.apache', version='1.8.0')
    assert(test_case_1 == RoleRequirement.role_yaml_parse('geerlingguy.apache,1.8.0'))

    # Case 2: Valid role line with name
    test_case_2 = dict(name='geerlingguy.apache', src='geerlingguy.apache', version='1.8.0')


# Generated at 2022-06-25 06:03:10.864641
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    '''
    RoleRequirement: role_yaml_parse
    '''
    # Tests a role definition and an older non-dict style role
    role_requirement = RoleRequirement()
    result = role_requirement.role_yaml_parse({"role": "geerlingguy.mysql"})
    assert result == {'name': 'geerlingguy.mysql', 'scm': None, 'src': None, 'version': ''}
    result = role_requirement.role_yaml_parse("geerlingguy.mysql")
    assert result == {'name': 'geerlingguy.mysql', 'scm': None, 'src': None, 'version': ''}
    result = role_requirement.role_yaml_parse("galaxy.role,version,name")

# Generated at 2022-06-25 06:03:18.413150
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Basic test case:
    role_requirement_0 = RoleRequirement()
    role_requirement_0_result = role_requirement_0.role_yaml_parse("galaxy.rolename, version, name")
    assert role_requirement_0_result == "galaxy.rolename, version, name"

    # Basic test case:
    role_requirement_0 = RoleRequirement()
    role_requirement_0_result = role_requirement_0.role_yaml_parse("galaxy.rolename,version,name")
    assert role_requirement_0_result == "galaxy.rolename,version,name"

# Generated at 2022-06-25 06:03:24.196276
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()


# Generated at 2022-06-25 06:03:26.932423
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    repo_url_0='https://github.com/geerlingguy/ansible-role-apache'
    role_requirement_0 = RoleRequirement()
    assert role_requirement_0.repo_url_to_role_name(repo_url_0) == 'ansible-role-apache'


# Generated at 2022-06-25 06:03:36.198995
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    # Test with a valid 'url' argument
    repo_url = "http://git.example.com/repos/repo.git"
    role_name = "repo"
    assert role_requirement.repo_url_to_role_name(repo_url) == role_name, "The role name should be " + role_name

    # Test with an invalid 'url' argument
    repo_url = "git.example.com/repos/repo.git"
    role_name = "repo"
    assert role_requirement.repo_url_to_role_name(repo_url) == repo_url, "The role name should be " + repo_url



# Generated at 2022-06-25 06:03:59.704360
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from nose.tools import assert_equals
    from nose.tools import assert_raises

    role_requirement_0 = RoleRequirement()

    data = "geerlingguy.ntp"
    assert_equals(role_requirement_0.role_yaml_parse(data), {'name': 'geerlingguy.ntp', 'src': 'geerlingguy.ntp', 'scm': None, 'version': ''})

    data = "git+https://github.com/geerlingguy/ansible-role-ntp.git,v1.2.3"

# Generated at 2022-06-25 06:04:06.479816
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    test_role_requirement_0 = RoleRequirement()

    test_role_requirement_0.role_yaml_parse({u'role': 'role1', u'other_vars': u'here'})

    test_role_requirement_0.role_yaml_parse(u'role2,2.0,role_name1')

    test_role_requirement_0.role_yaml_parse({u'src': u'galaxy.role,version,name', u'other_vars': u'here'})


# Generated at 2022-06-25 06:04:13.687342
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    repo_url_0 = "http://git.example.com/repos/repo.git"
    role_name_0 = role_requirement_0.repo_url_to_role_name(repo_url_0)
    assert role_name_0 == "repo"

    repo_url_1 = "git+http://git.example.com/repos/repo.git"
    role_name_1 = role_requirement_0.repo_url_to_role_name(repo_url_1)
    assert role_name_1 == "repo"

    repo_url_2 = "git+http://git.example.com/repos/repo.git,1.5"
    role_name_2 = role_requirement

# Generated at 2022-06-25 06:04:23.504092
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test 1:
    # Test for string type input for role_yaml_parse() method of the class RoleRequirement

    role_requirement_0 = RoleRequirement()
    role_0 = 'galaxy.role'
    expected_role_0 = {'name': 'galaxy.role', 'version': None, 'src': 'galaxy.role', 'scm': None}
    assert(role_requirement_0.role_yaml_parse(role_0) == expected_role_0), "Test 1 Failed"

    # Test 2:
    # Test for different types of syntax for the role_yaml_parse() method of the class RoleRequirement

    role_requirement_1 = RoleRequirement()
    role_1 = 'galaxy.role,v1.0'

# Generated at 2022-06-25 06:04:32.563421
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    assert role_requirement.repo_url_to_role_name("git@github.com:who/what.git") == "what"
    assert role_requirement.repo_url_to_role_name("scm+git@github.com:who/what.git") == "what"
    assert role_requirement.repo_url_to_role_name("scm1+scm2+git@github.com:who/what.git") == "what"
    assert role_requirement.repo_url_to_role_name("git://github.com:who/what.git") == "what"

# Generated at 2022-06-25 06:04:41.823251
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()

    # Test valid key:role with string value 'valid_role_name'
    role_requirement_1.role = 'valid_role_name'
    assert role_requirement_1.role_yaml_parse('valid_role_name') == {'name': 'valid_role_name', 'scm': None, 'src': 'valid_role_name', 'version': ''}

    # Test valid key:role with string value: 'valid_role_name,version'
    role_requirement_1.role = 'valid_role_name,version'

# Generated at 2022-06-25 06:04:44.180364
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_obj = RoleRequirement()

    role_requirement_obj.role_yaml_parse(role={'role': "git@github.com:foo/ansible-role-bar.git"})


# Generated at 2022-06-25 06:04:50.806824
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()

    assert role_requirement_0.repo_url_to_role_name('git+http://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement_0.repo_url_to_role_name('git+http://git.example.com/repos/repo.git,1.0') == 'repo'
    assert role_requirement_0.repo_url_to_role_name('git+http://git.example.com/repos/repo.git,1.0,foobar') == 'repo'

# Generated at 2022-06-25 06:04:55.328015
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Case 0:
    role_requirement_0 = RoleRequirement()
    repo_url_0 = 'https://github.com/github/example.git'
    role_name_0 = role_requirement_0.repo_url_to_role_name(repo_url_0)

    assert role_name_0 == 'example'


# Generated at 2022-06-25 06:05:05.244379
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_requirement_2 = RoleRequirement()
    role_requirement_3 = RoleRequirement()
    role_requirement_4 = RoleRequirement()
    role_requirement_5 = RoleRequirement()
    role_requirement_6 = RoleRequirement()
    role_requirement_7 = RoleRequirement()
    role_requirement_8 = RoleRequirement()
    role_requirement_9 = RoleRequirement()
    role_requirement_10 = RoleRequirement()
    role_requirement_11 = RoleRequirement()
    role_requirement_12 = RoleRequirement()
    role_requirement_13 = RoleRequirement()
    role_requirement_14 = RoleRequirement()
    role_requirement_15 = RoleRequirement()
    role_requ