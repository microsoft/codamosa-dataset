

# Generated at 2022-06-25 05:55:30.997114
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()

    assert role_requirement_0.repo_url_to_role_name("git://git.example.com/repos/repo.git") == 'repo'
    assert role_requirement_0.repo_url_to_role_name("git+http://git.example.com/repos/repo.git") == 'repo'
    assert role_requirement_0.repo_url_to_role_name("http://git.example.com/repos/repo.git") == 'repo'
    assert role_requirement_0.repo_url_to_role_name("git@git.example.com:repos/repo.git") == 'repo'
    assert role_requirement_0.repo_url_to_

# Generated at 2022-06-25 05:55:42.498694
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Testing with a value for the "role" key.
    # This is the old style.
    role_requirement_0 = RoleRequirement()
    role_0 = dict(role='myrole')
    result_0 = role_requirement_0._role_yaml_parse(role_0)
    assert result_0 == dict(name='myrole', src=None, scm=None, version=None)

    # Testing with a value for the source "src" key
    # (in the form name:url).
    role_requirement_1 = RoleRequirement()
    role_1 = dict(src='testrole:http://www.example.com/testrole.git')
    result_1 = role_requirement_1._role_yaml_parse(role_1)

# Generated at 2022-06-25 05:55:53.035591
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('Role_Name, v1.0') == {'name': 'Role_Name', 'src': 'Role_Name', 'scm': None, 'version': 'v1.0'}
    assert RoleRequirement.role_yaml_parse('git@git.example.com:blah/blah.git') == {'name': 'blah', 'src': 'git@git.example.com:blah/blah.git', 'scm': None, 'version': ''}

# Generated at 2022-06-25 05:56:03.741106
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()

    # Test case 1
    role_1 = role_requirement_1.role_yaml_parse("../parsed:release/3.0")
    assert role_1["name"] == "../parsed:release/3.0"
    assert role_1["version"] == ""
    assert role_1["src"] == "../parsed:release/3.0"
    assert role_1["scm"] == None
    print("RoleRequirement.role_yaml_parse: test case 1" + PASSED )

    # Test case 2
    role_2 = role_requirement_1.role_yaml_parse("git+git@github.com:ansible/ansible-examples.git,v1.3.4,my_role")
    assert role

# Generated at 2022-06-25 05:56:09.664734
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Test when repo_url start with http/https
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://git.example.com/repos/repo.git') == 'repo'

    # Test when repo_url start with git@
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com:repos/repo.git') == 'repo'

    # Test when repo_url start without http/https and git@
    assert RoleRequirement.repo_url_to_role_name('git.example.com/repos/repo.git') == 'repo'

# Unit test

# Generated at 2022-06-25 05:56:14.612517
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    repo_url = "http://git.example.com/repos/repo.git"
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert role_name == "repo"


# Generated at 2022-06-25 05:56:22.344347
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_requirement_1.role_yaml_parse("role_name[,version[,name]]")
    assert role_requirement_1.role_yaml_parse("role_name[,version[,name]]") == dict(name="role_name[,version[,name]]", src="role_name[,version[,name]]", scm=None, version=None)


# Generated at 2022-06-25 05:56:28.888537
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    answer = dict(
        name='foo',
        src='https://github.com/geerlingguy/ansible-role-foo',
        scm='git',
        version=''
    )
    assert RoleRequirement.role_yaml_parse(dict(name='foo', src='geerlingguy.foo')) == answer
    assert RoleRequirement.role_yaml_parse(dict(src='geerlingguy.foo')) == answer
    assert RoleRequirement.role_yaml_parse(dict(src='geerlingguy.foo', version='1.0')) == dict(
        name='foo',
        src='geerlingguy.foo',
        scm=None,
        version='1.0',
    )

# Generated at 2022-06-25 05:56:38.484169
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_1 = RoleRequirement()
    role_0 = role_requirement_0.role_yaml_parse({'src': 'git+https://github.com/bennojoy/nginx.git', 'scm': 'git', 'name': 'nginx'})
    assert role_0['name'] == "nginx"
    role_1 = role_requirement_1.role_yaml_parse({'src': 'https://github.com/ansible/ansible-examples,devel'})
    assert role_1['name'] == "ansible-examples"
    assert role_1['scm'] == None
    assert role_1['version'] == "devel"

# Generated at 2022-06-25 05:56:48.712787
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()

    role_test_0 = dict(name='testname', src='https://github.com/testuser/testrole.git', scm='git', version='1.0')
    if role_requirement_0.role_yaml_parse('testuser/testrole,1.0') == role_test_0:
        print("Passed test_RoleRequirement_role_yaml_parse_0")
    else:
        print("Failed test_RoleRequirement_role_yaml_parse_0")
        print("Input: testuser/testrole,1.0")
        print("Expected:")
        print(role_test_0)
        print("Returned:")

# Generated at 2022-06-25 05:57:01.074868
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("git+http://git.example.com/repos/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("git+http://git.example.com/repos/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"

# Generated at 2022-06-25 05:57:10.215425
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    cases = {}
    cases[0] = {
        'meta.yaml': {
            'dependencies': [
                'geerlingguy.ntp',
                'geerlingguy.apache,1.8.4',
                'geerlingguy.java,7.0.65,my-java'
            ]
        }
    }

    cases[1] = {
        'meta.yaml': {
            'dependencies': [
                'src: https://github.com/geerlingguy/ansible-role-ntp.git'
            ]
        }
    }


# Generated at 2022-06-25 05:57:15.079085
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_requirement_dict_A = role_requirement_1.role_yaml_parse(role="test,1.1.1,m")
    assert role_requirement_dict_A == dict(name='m', src='test', scm=None, version='1.1.1')

    role_requirement_dict_B = role_requirement_1.role_yaml_parse(role="test,1.1.1")
    assert role_requirement_dict_B == dict(name='test', src='test', scm=None, version='1.1.1')

    role_requirement_dict_C = role_requirement_1.role_yaml_parse(role="test")

# Generated at 2022-06-25 05:57:20.407424
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    display.vvvv("Executing test_RoleRequirement_role_yaml_parse")
    test_RoleRequirement_role_yaml_parse_01()
    test_RoleRequirement_role_yaml_parse_02()


# Unit test 01 for method role_yaml_parse of class RoleRequirement
# RoleRequirement: old-style

# Generated at 2022-06-25 05:57:28.346970
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()


# Generated at 2022-06-25 05:57:34.722353
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    print("Test Case 1")
    role = "nickjj.nodejs,v2.2.0"
    print("Input:")
    print("role: " + str(role))
    print("Output:")
    print("Dictionary: " + str(RoleRequirement.role_yaml_parse(role)))


# Generated at 2022-06-25 05:57:45.919858
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    assert role_requirement_0.repo_url_to_role_name('https://github.com/Kami/ansible-ssh-hardening.git') == 'ansible-ssh-hardening'
    assert role_requirement_0.repo_url_to_role_name('git@github.com:Kami/ansible-ssh-hardening.git') == 'ansible-ssh-hardening'
    assert role_requirement_0.repo_url_to_role_name('ssh://user@server/project.git') == 'project'
    assert role_requirement_0.repo_url_to_role_name('project.tar.gz') == 'project'

# Generated at 2022-06-25 05:57:47.325973
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role = 'ansible-role-python'
    role_requirement.role_yaml_parse(role)


# Generated at 2022-06-25 05:57:52.306861
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role = "geerlingguy.java"
    role_dict = role_requirement_0.role_yaml_parse(role)
    assert role_dict['name'] == role.split(',')[0]
    assert role_dict['version'] == ''
    assert role_dict['scm'] == None
    assert role_dict['src'] == role.split(',')[0]

    role = "geerlingguy.java,1.8"
    role_dict = role_requirement_0.role_yaml_parse(role)
    assert role_dict['name'] == role.split(',')[0]
    assert role_dict['version'] == role.split(',')[1]
    assert role_dict['scm'] == None
    assert role

# Generated at 2022-06-25 05:58:01.159689
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1
    role = 'git+http://git.example.com/repos/foo.git,1.2.3'
    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse(role)

    # Test case 2
    role = 'http://github.com/foo/bar.git,1.2.3'
    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse(role)

    # Test case 3
    role = 'git+http://git.example.com/repos/foo.git'
    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse(role)

    # Test case 4

# Generated at 2022-06-25 05:58:13.304313
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    role_0 = role_requirement.role_yaml_parse('git+https://github.com/ansible/fail2ban-role.git,v1.0.0,myrole')
    assert role_0['name'] == 'myrole'
    assert role_0['src'] == 'https://github.com/ansible/fail2ban-role.git'
    assert role_0['scm'] == 'git'
    assert role_0['version'] == 'v1.0.0'

    role_1 = role_requirement.role_yaml_parse('https://github.com/ansible/fail2ban-role.git,myrole')
    assert role_1['name'] == 'myrole'

# Generated at 2022-06-25 05:58:20.306656
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    result = role_requirement_0.role_yaml_parse('test')
    expected_dict = {'name': 'test', 'scm': None, 'src': 'test', 'version': ''}
    display.vvvv(result)
    display.vvvv(expected_dict)
    assert result == expected_dict

    result = role_requirement_0.role_yaml_parse('test, version string')
    expected_dict = {'name': 'test', 'scm': None, 'src': 'test', 'version': 'version string'}
    display.vvvv(result)
    display.vvvv(expected_dict)
    assert result == expected_dict

    result = role_requirement_0.role_yaml_parse('test, version string, name')

# Generated at 2022-06-25 05:58:23.979216
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    assert role_requirement_1.repo_url_to_role_name("git://github.com/geerlingguy/ansible-role-mysql.git") == "ansible-role-mysql"


# Generated at 2022-06-25 05:58:30.726899
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    yaml_without_commas = "git+https://github.com/alikins/ferm.git,v2.0.8"
    result_without_commas = RoleRequirement.role_yaml_parse(yaml_without_commas)
    expected_result_without_commas = {'scm': 'git', 'name': 'ferm', 'src': 'https://github.com/alikins/ferm.git', 'version': 'v2.0.8'}
    if result_without_commas != expected_result_without_commas:
        raise AssertionError("RoleRequirement.role_yaml_parse('%s') generated wrong result: %s (expected %s)" % (yaml_without_commas, result_without_commas, expected_result_without_commas))

   

# Generated at 2022-06-25 05:58:35.639049
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    r = RoleRequirement()
    # Test case 1
    #
    # Input:
    #    repo_url = 'https://example.com/repo.git'
    # Expected Output:
    #    repo
    result = r.repo_url_to_role_name('https://example.com/repo.git')
    assert (result == 'repo')
    # Test case 2
    #
    # Input:
    #    repo_url = 'https://example.com/repo.git'
    # Expected Output:
    #    repo
    result = r.repo_url_to_role_name('https://example.com/repo.git')
    assert (result == 'repo')
    # Test case 3
    #
    # Input:
    #    repo_url = 'https

# Generated at 2022-06-25 05:58:43.771202
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://example.com/repos/repo.git") == "repo.git"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo") == "repo"


# Generated at 2022-06-25 05:58:49.157220
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    expected = dict(name="galaxyrole_0", src="git+https://github.com/ansible/ansible-examples.git", scm="git", version="v0.9.1")
    actual = role_requirement.role_yaml_parse("git+https://github.com/ansible/ansible-examples.git,v0.9.1,galaxyrole_0")
    assert(expected==actual)


# Generated at 2022-06-25 05:59:00.144710
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print("Test case for RoleRequirement.role_yaml_parse")
    role_requirement_0 = RoleRequirement()
    test_current_role = "role_name,version,name"
    test_current_role_dict = {'role': 'role_name'}
    test_current_role_dict_modified = {'src': 'role_name', 'version': 'version', 'name': 'name'}
    role_requirement_0.role_yaml_parse(test_current_role).keys() == role_requirement_0.role_yaml_parse(test_current_role_dict).keys()
    role_requirement_0.role_yaml_parse(test_current_role) == test_current_role_dict_modified


# Generated at 2022-06-25 05:59:11.107335
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Case 1 : Old style
    role_requirement_1 = RoleRequirement().role_yaml_parse("role_name_1")
    assert(  role_requirement_1['name'] == "role_name_1" )
    assert(  role_requirement_1['src'] == "role_name_1" )
    assert(  role_requirement_1['scm'] == None )
    assert(  role_requirement_1['version'] == "" )

    # Case 2 : Old style with version
    role_requirement_2 = RoleRequirement().role_yaml_parse("role_name_2,version_2")
    assert(  role_requirement_2['name'] == "role_name_2" )

# Generated at 2022-06-25 05:59:22.982893
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    display.display("TEST1 name='user_name', src='github.com/user_name/ansible_role,v1.0.0,my_name'")
    role_requirement = RoleRequirement()
    role = role_requirement.role_yaml_parse('user_name,github.com/user_name/ansible_role,v1.0.0,my_name')
    assert role == dict(name='my_name', src='github.com/user_name/ansible_role', scm='git', version='v1.0.0')

    display.display("TEST2 name='user_name', src='github.com/user_name/ansible_role'")
    role_requirement = RoleRequirement()

# Generated at 2022-06-25 05:59:36.535995
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 0 of 1
    test_case_0()


# Generated at 2022-06-25 05:59:48.358580
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,version") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,version,name") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/repo.git") == "repo"


# Generated at 2022-06-25 05:59:50.392209
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    result = role_requirement.role_yaml_parse('git+https://github.com/coreos/ansible-coreos-bootstrap,0.0.1,coreos-bootstrap')
    print (result)


# Generated at 2022-06-25 05:59:58.030077
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    print("testing repo_url_to_role_name")
    role_requirement = RoleRequirement()

    # first case, repo_url has '://'
    repo_url = "http://git.example.com/repos/repo.git"
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert role_name == "repo"

    # second case, repo_url has '@'
    repo_url = "https://github.com/ansible/ansible-examples.git"
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert role_name == "ansible-examples"

    # third case, repo_url does not have '://' or '@'
    repo

# Generated at 2022-06-25 06:00:05.186950
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    src = "role[my_role],v1.0.0,michael"
    result = role_requirement_1.role_yaml_parse(src)
    assert result == {'src': 'my_role', 'version': 'v1.0.0', 'name': 'michael'}


# Generated at 2022-06-25 06:00:11.945470
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement = RoleRequirement()

    # New style
    sample_dict = {'name': 'git', 'role': 'git', 'scm': 'git', 'src': 'https://github.com/ansible/ansible-examples.git', 'version': '1.2.3'}
    result_dict = role_requirement.role_yaml_parse(sample_dict.copy())
    assert role_requirement.role_yaml_parse(sample_dict) == result_dict

    # Old style
    sample_dict = {'name': 'git', 'role': 'git', 'scm': 'git', 'src': 'https://github.com/ansible/ansible-examples.git', 'version': '1.2.3'}
    result_dict = role_requirement.role_yaml_

# Generated at 2022-06-25 06:00:15.682521
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    expected_result_0 = {'version': '', 'name': 'ansible-role-web', 'scm': 'git', 'src': 'https://github.com/robertdebock/ansible-role-web'}
    returned_result_0 = RoleRequirement.role_yaml_parse('https://github.com/robertdebock/ansible-role-web')

    assert returned_result_0 == expected_result_0, "Testcase 0 failed!"


# Generated at 2022-06-25 06:00:27.818248
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from test.units.callback import CallbackModule

    role_requirement = RoleRequirement()
    print('role_requirement: ', role_requirement)
    print('role_requirement.repo_url_to_role_name(\'http://git.example.com/repos/repo.git\'): ', role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.git'))

# Generated at 2022-06-25 06:00:35.037748
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = "git+https://github.com/user/role.git,v1.2"
    result = RoleRequirement.role_yaml_parse(role)

    if result['name'] != 'role':
        raise Exception(
            "Name from 'git+https://github.com/user/role.git,v1.2' should be role but is %s" % result[
            'name'])

    if result['scm'] != 'git':
        raise Exception(
            "scm from 'git+https://github.com/user/role.git,v1.2' should be git but is %s" % result['scm'])


# Generated at 2022-06-25 06:00:40.274870
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    test_input_0 = "https://github.com/geerlingguy/ansible-role-apache,2.1.1,geerlingguy.apache"
    expected_output = "geerlingguy.apache"
    assert role_requirement_1.repo_url_to_role_name(test_input_0) == expected_output


# Generated at 2022-06-25 06:01:07.350842
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    test_role = "geerlingguy.nginx,v1.0.0"
    role = role_requirement.role_yaml_parse(test_role)

    assert(role['name'] == 'geerlingguy.nginx')
    assert(role['scm'] is None)
    assert(role['version'] == 'v1.0.0')
    assert(role['src'] == 'geerlingguy.nginx')


# Generated at 2022-06-25 06:01:11.869201
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_yaml_parse_1 = role_requirement_1.role_yaml_parse('wikimedia.apt-get-update')
    assert role_yaml_parse_1 == {'name': 'wikimedia.apt-get-update', 'scm': None, 'src': None, 'version': None}
    role_requirement_2 = RoleRequirement()
    role_yaml_parse_2 = role_requirement_2.role_yaml_parse('wikimedia.apt-get-update,0.0.2')
    assert role_yaml_parse_2 == {'name': 'wikimedia.apt-get-update', 'scm': None, 'src': None, 'version': '0.0.2'}
    role_requirement_3 = Role

# Generated at 2022-06-25 06:01:16.428631
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_obj = RoleRequirement()
    role_yaml_parse_output = role_requirement_obj.role_yaml_parse('http://github.com/user/repo.git')

    output = {'src': 'http://github.com/user/repo.git', 'version': None, 'scm': None, 'name': 'repo'}


# Generated at 2022-06-25 06:01:26.392393
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse(role='geerlingguy.git') == {'name': 'geerlingguy.git', 'scm': None, 'src': 'geerlingguy.git', 'version': ''}
    assert RoleRequirement.role_yaml_parse(role='geerlingguy.git,v1') == {'name': 'geerlingguy.git', 'scm': None, 'src': 'geerlingguy.git', 'version': 'v1'}
    assert RoleRequirement.role_yaml_parse(role='geerlingguy.git,v1,my-role') == {'name': 'my-role', 'scm': None, 'src': 'geerlingguy.git', 'version': 'v1'}
    assert RoleRequirement.role_yaml_parse

# Generated at 2022-06-25 06:01:31.928658
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name(
        'http://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name(
        'https://github.com/username/repo.tar.gz') is None


# Generated at 2022-06-25 06:01:39.368502
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1
    src = '/Users/michaelhuang/playground/galaxy'
    scm = 'git'
    name = 'rolename'
    version = 'head'
    role = dict(src=src, scm=scm, name=name, version=version)
    role_requirement_0 = RoleRequirement()
    role_requirement = role_requirement_0.role_yaml_parse(role)

# Generated at 2022-06-25 06:01:43.654205
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement() 
    # Assert that the method get called
    assert role_requirement_0.role_yaml_parse('role_name') == dict(name='role_name', src='role_name', scm=None, version='')


# Generated at 2022-06-25 06:01:47.479814
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    test_case_1 = role_requirement_1.role_yaml_parse('roles/kolo.subversion,v0')
    assert test_case_1['name'] == 'roles/kolo.subversion'
    assert test_case_1['version'] == 'v0'


# Generated at 2022-06-25 06:01:55.034579
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test case 1
    role_requirement_1 = RoleRequirement()
    input_1 = 'geerlingguy.repo-remi'
    expected_output_1 = {'name': 'geerlingguy.repo-remi', 'src': 'geerlingguy.repo-remi', 'scm': None, 'version': ''}
    actual_output_1 = RoleRequirement.role_yaml_parse(input_1)
    assert expected_output_1 == actual_output_1

    # test case 2
    role_requirement_2 = RoleRequirement()
    input_2 = 'src: https://github.com/geerlingguy/ansible-role-repo-remi.git'

# Generated at 2022-06-25 06:02:00.351372
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    # Testing for git url is not being tested as we are passing in http url to the method.
    # httpUrl = 'https://github.com/ansible/ansible-modules-core.git'
    # Testing with repo url having ansible@
    httpUrl = 'ansible@github.com/ansible/ansible-modules-core.git'
    if role_requirement_0.repo_url_to_role_name(httpUrl) != 'ansible-modules-core':
        print('\ttest_RoleRequirement_repo_url_to_role_name() failed on line number: {}'.format(
            sys._getframe().f_lineno))

    # Testing for http url

# Generated at 2022-06-25 06:02:46.227771
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    assert role_requirement_0.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'

# Generated at 2022-06-25 06:02:55.784141
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    repo_url = "ansible-role-zabbix"
    assert role_requirement.repo_url_to_role_name(repo_url) == "ansible-role-zabbix"

    repo_url = "https://github.com/jtyr/ansible-nginx-memcached-php-site.git"
    assert role_requirement.repo_url_to_role_name(repo_url) == "ansible-nginx-memcached-php-site"

    repo_url = "https://github.com/jtyr/ansible-nginx-memcached-php-site.git,v1,role"

# Generated at 2022-06-25 06:03:05.195536
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement = RoleRequirement()
    role = dict(name='role', src='galaxy.role', scm='git', version='HEAD', keep_scm_meta=False)
    if RoleRequirement.role_yaml_parse(role) == dict(name='role', src='galaxy.role', scm='git', version='HEAD', keep_scm_meta=False):
        print('OK')
    else:
        print('Not OK')

    role = dict(name='role', src='galaxy.role', scm='git', version='HEAD', keep_scm_meta=False)
    if RoleRequirement.role_yaml_parse(role) == dict(name='role', src='galaxy.role', scm='git', version='HEAD', keep_scm_meta=False):
        print('OK')

# Generated at 2022-06-25 06:03:12.226577
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement
    if not getattr(role_requirement_1, "repo_url_to_role_name", False):
        raise AssertionError("Could not find method 'repo_url_to_role_name'")
    role_requirement_2 = RoleRequirement()
    if not getattr(role_requirement_2, "repo_url_to_role_name", False):
        raise AssertionError("Could not find method 'repo_url_to_role_name'")
    if not isinstance(role_requirement_2.repo_url_to_role_name, staticmethod):
        raise AssertionError("Class method is not static for 'repo_url_to_role_name'")
    result = role_requirement_2.repo_

# Generated at 2022-06-25 06:03:18.219281
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    #
    # Check that new style parsing (with src, scm and name) works
    #
    role_dict = RoleRequirement.role_yaml_parse(
        dict(
            src='https://github.com/example/ansible-role-example.git',
            scm='git',
            version='1.2.3',
            name='example.ansible-role-example',
        )
    )
    assert role_dict['name'] == 'example.ansible-role-example'
    assert role_dict['src'] == 'https://github.com/example/ansible-role-example.git'
    assert role_dict['scm'] == 'git'
    assert role_dict['version'] == '1.2.3'

    #
    # Check that old style parsing (with role) works
    #

# Generated at 2022-06-25 06:03:23.821668
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    role_requirement_1 = RoleRequirement()
    name = role_requirement_1.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    assert name == "repo"

    role_requirement_2 = RoleRequirement()
    name = role_requirement_1.repo_url_to_role_name("git://git.example.com/repos/repo.git")
    assert name == "repo"

    role_requirement_3 = RoleRequirement()
    name = role_requirement_1.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz")
    assert name == "repo"


# Generated at 2022-06-25 06:03:28.991453
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Test for param repo_url = 'git://git.example.com/repos/repo.git'
    role_requirement = RoleRequirement()
    expected = 'repo'
    actual = role_requirement.repo_url_to_role_name('git://git.example.com/repos/repo.git')
    assert actual == expected

    # Test for param repo_url = 'http://git.example.com/repos/repo.git'
    role_requirement = RoleRequirement()
    expected = 'repo'
    actual = role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.git')
    assert actual == expected

    # Test for param repo_url = 'git@git.example.com:repos/repo

# Generated at 2022-06-25 06:03:37.444798
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()

    role_0 = 'https://github.com/ansible/ansible-examples.git,master,examples'
    py_req_0 = '\npass\n'

    try:
        result = role_requirement_0.role_yaml_parse(role_0)
    except Exception as e:
        print(e)
        py_req_0 = '\nraise Exception\n'

    assert result == {'name': 'ansible-examples', 'src': 'https://github.com/ansible/ansible-examples.git', 'scm': None, 'version': 'master'} or py_req_0 == '\nraise Exception\n'


# Generated at 2022-06-25 06:03:42.630657
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    example_0_input = 'git+https://github.com/certbot/certbot.git,0.13.0,certbot'
    example_0_result = RoleRequirement.role_yaml_parse(example_0_input)
    assert example_0_result == example_0_result

# Generated at 2022-06-25 06:03:52.650720
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 06:04:43.353534
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    test_src_0_0 = "https://github.com/galaxyproject/ansible-galaxy,1.0"
    test_dict_0_0 = {
        u'name': u'ansible-galaxy',
        u'scm': u'git',
        u'src': u'https://github.com/galaxyproject/ansible-galaxy',
        u'version': u'1.0',
    }
    assert role_requirement_0.role_yaml_parse(test_src_0_0) == test_dict_0_0

# Generated at 2022-06-25 06:04:51.163733
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_0 = dict()
    (role_1, role_2, role_3, role_4) = role_requirement_0.role_yaml_parse(role_0)
    if (role_1, role_2, role_3, role_4) != (None, None, None, None):
        raise AssertionError("role_1, role_2, role_3, role_4: got (%r, %r, %r, %r), expected (None, None, None, None)" % (role_1, role_2, role_3, role_4,))


# Generated at 2022-06-25 06:04:58.904240
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    # test for http urls
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'

    # test for ssh urls
    assert role_requirement.repo_url_to_role_name('git@git.example.com:repos/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('git@git.example.com:repos/repo.tar.gz') == 'repo'

    # test for name without .git

# Generated at 2022-06-25 06:05:06.416774
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
