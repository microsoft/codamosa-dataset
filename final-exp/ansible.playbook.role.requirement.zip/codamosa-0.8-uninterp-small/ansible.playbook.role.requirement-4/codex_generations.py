

# Generated at 2022-06-25 05:55:30.826244
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git') == {'name': 'repo', 'scm': None, 'src': 'http://git.example.com/repos/repo.git', 'version': ''}
    assert RoleRequirement.role_yaml_parse('http://github.com/robertdebock/ansible-role-yum') == {'name': 'ansible-role-yum', 'scm': None, 'src': 'http://github.com/robertdebock/ansible-role-yum', 'version': ''}

# Generated at 2022-06-25 05:55:34.813567
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    repo_url = "http://git.example.com/repos/repo.git"
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert role_name == "repo"


# Generated at 2022-06-25 05:55:43.393577
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role_string = "rolename"
    print("\nrole_string: %s" % role_string)
    role = role_requirement.role_yaml_parse(role_string)
    if role is not None:
        if 'name' in role.keys():
            print("name=%s" % role["name"])
        if 'src' in role.keys():
            print("src=%s" % role["src"])
        if 'scm' in role.keys():
            print("scm=%s" % role["scm"])
        if 'version' in role.keys():
            print("version=%s" % role["version"])

    role_string = "rolename,2.3.3"

# Generated at 2022-06-25 05:55:47.564086
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = {'role': 'geerlingguy.ntp', 'version': 'v1.1.0'}
    expected_output = {'name': 'geerlingguy.ntp', 'src': None, 'scm': None, 'version': 'v1.1.0'}
    output = RoleRequirement.role_yaml_parse(role)

    assert (expected_output == output)


# Generated at 2022-06-25 05:55:53.125858
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Check the case when the role string is passed
    role = "my_role"
    role_requirement = RoleRequirement().role_yaml_parse(role)
    assert(role_requirement["name"] == "my_role")
    assert(role_requirement["scm"] == None)
    assert(role_requirement["src"] == "my_role")
    assert(role_requirement["version"] == None)

    # Check the case when the role string is passed with version
    role = "my_role, 1.3"
    role_requirement = RoleRequirement().role_yaml_parse(role)
    assert(role_requirement["name"] == "my_role")
    assert(role_requirement["scm"] == None)
    assert(role_requirement["src"] == "my_role")

# Generated at 2022-06-25 05:56:03.410230
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo-1,2.tar.gz') == 'repo-1'
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo,version.tar.gz') == 'repo'



# Generated at 2022-06-25 05:56:08.571482
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    arg_0 = 'git+git://git.example.com/repos/repository.git'
    res_0 = role_requirement_0.repo_url_to_role_name(arg_0)
    print(res_0)
    assert res_0 == 'repository'

if __name__ == '__main__':
    '''
    # How to test?
    python -m playground.ansible_playbook.role.requirement
    '''
    test_case_0()
    test_RoleRequirement_repo_url_to_role_name()

# Generated at 2022-06-25 05:56:17.560702
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_data_0 = {"src":"https://github.com/abc/def,1.2.3,app1"}
    role_data_1 = {"src":"git+https://github.com/abc/def,1.2.3,app1"}
    role_data_2 = {"src":"git+https://github.com/abc/def"}
    role_data_3 = {"src":"https://github.com/abc/def"}
    role_data_4 = {"src":"https://github.com/abc/def,version,name"}
    role_data_5 = {"src": "https://github.com/abc/def.tar.gz"}
    role_data_6 = {"src": "git+https://github.com/abc/def.tar.gz"}

# Generated at 2022-06-25 05:56:27.424284
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    inputs = [
        "http://git.example.com/repos/repo.git",
        "git+http://git.example.com/repos/repo.git",
        "ansible-galaxy+http://git.example.com/repos/repo.git+feature/new-stuff",
        "git+http://git.example.com/repos/repo.git,commit_hash",
        "git+http://git.example.com/repos/repo.git",
        "file+/Users/johndoe/ansible-roles/role.tar.gz",
    ]
    expected_results = [
        "repo",
        "repo",
        "ansible-galaxy",
        "repo",
        "repo",
        "role",
    ]
   

# Generated at 2022-06-25 05:56:34.691448
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Invalid role line (paul/foo). Proper format is 'role_name[,version[,name]]'
    role_0 = 'paul/foo'
    role_requirement_0 = RoleRequirement()
    assert role_requirement_0.role_yaml_parse(role=role_0) == {'name': 'foo', 'src': 'paul/foo', 'scm': None, 'version': None}


# Generated at 2022-06-25 05:56:49.317952
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    required_attributes = ["name", "src", "scm", "version"]
    test_case_1 = dict(
        name = "galaxy.role",
        src = "http://github.com/org/role",
        scm = "git",
        version= "v0.0.3"
    )

    test_case_2 = dict(
        name = "galaxy.role",
        src = "http://github.com/org/role",
        scm = None,
        version = "HEAD"
    )

    test_case_3 = dict(
        name = "galaxy.role",
        src = "ansible-galaxy install -p ./roles/ org.role",
        scm = None,
        version = "v0.0.3"
    )


# Generated at 2022-06-25 05:56:57.738755
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()

    if not isinstance(role_requirement_0, RoleRequirement):
        raise AssertionError("expected RoleRequirement, got %s" % type(role_requirement_0))

    repo_url = "ansible-role-repo-url"
    expected = "ansible-role-repo-url"
    actual = role_requirement_0.repo_url_to_role_name(repo_url)

    if expected != actual:
        raise AssertionError("expected '" + str(expected) + "', got '" + str(actual) + "'")


# Generated at 2022-06-25 05:57:08.629539
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    result = RoleRequirement.role_yaml_parse('src,version,name')
    assert result == {'scm': None, 'version': 'version', 'src': 'src', 'name': 'name'}
    result = RoleRequirement.role_yaml_parse('src,version')
    assert result == {'scm': None, 'version': 'version', 'src': 'src', 'name': 'src'}
    result = RoleRequirement.role_yaml_parse('src')
    assert result == {'scm': None, 'version': '', 'src': 'src', 'name': 'src'}
    result = RoleRequirement.role_yaml_parse('scm+src')

# Generated at 2022-06-25 05:57:13.549225
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    assert role_requirement_1.role_yaml_parse('http://git.example.com/repos/repo.git,1.0.0,myrole') == {'name': 'myrole', 'src': 'http://git.example.com/repos/repo.git', 'scm': 'git', 'version': '1.0.0'}


# Generated at 2022-06-25 05:57:18.001036
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    test_input = 'https://github.com/ansible/ansible-modules-extras.git'
    expect_ret = 'ansible-modules-extras'
    actual_ret = RoleRequirement.repo_url_to_role_name(test_input)
    if actual_ret != expect_ret:
        print('FAILED: repo_url_to_role_name() parsing of repo URL %s' % test_input)
        print('        expected role name: %s' % actual_ret)
        print('        actual role name: %s' % expect_ret)
    else:
        print('PASSED: repo_url_to_role_name() parsing of repo URL %s' % test_input)


# Generated at 2022-06-25 05:57:26.813377
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Invalid role line (). Proper format is 'role_name[,version[,name]]'
    role_line_0 = "test"
    result_0 = RoleRequirement.role_yaml_parse(role_line_0)
    assert isinstance(result_0, dict)
    assert len(result_0) == 4
    assert 'name' in result_0
    assert result_0['name'] == 'test'
    assert 'src' in result_0
    assert result_0['src'] == 'test'
    assert 'scm' in result_0
    assert result_0['scm'] is None
    assert 'version' in result_0
    assert result_0['version'] is None

    # Invalid role line (). Proper format is 'role_name[,version[,name]]'

# Generated at 2022-06-25 05:57:35.484324
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    result = role_requirement.role_yaml_parse(role='jdauphant.nginx')
    print (result)

    result = role_requirement.role_yaml_parse(role='geerlingguy.java,1.8.0')
    print (result)

    result = role_requirement.role_yaml_parse(role='http://github.com/geerlingguy/ansible-role-java,1.8.0')
    print (result)

    result = role_requirement.role_yaml_parse(role='git+git://github.com/geerlingguy/ansible-role-java,1.8.0')
    print (result)


# Generated at 2022-06-25 05:57:45.995443
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # New style: { src: 'galaxy.role,version,name', other_vars: "here" }
    assert RoleRequirement.role_yaml_parse({"src": "galaxy.role,version,name", "other_vars": "here"}) == {"scm": None, "src": "galaxy.role", "name": "name", "version": "version"}

    # New style: { src: 'git+https://path/to/role.git,version,name' }
    assert RoleRequirement.role_yaml_parse("git+https://path/to/role.git,version,name") == {"scm": "git", "src": "https://path/to/role.git", "name": "name", "version": "version"}

    # Old style: { role: 'galaxy.role' }

# Generated at 2022-06-25 05:57:55.572440
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    role = role_requirement.role_yaml_parse("geerlingguy.apache")
    assert role["name"] == "geerlingguy.apache"
    assert role["version"] == ""
    assert role["scm"] is None
    assert role["src"] == 'geerlingguy.apache'

    role = role_requirement.role_yaml_parse("geerlingguy.apache,1.7")
    assert role["name"] == "geerlingguy.apache"
    assert role["version"] == "1.7"
    assert role["scm"] is None
    assert role["src"] == "geerlingguy.apache"

    role = role_requirement.role_yaml_parse("geerlingguy.apache,1.7,my_apache")
   

# Generated at 2022-06-25 05:58:05.914235
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = {"role": "geerlingguy.ntp", "version": "2.0.0"}
    parsed_role = RoleRequirement.role_yaml_parse(role)
    assert(parsed_role['name'] == "geerlingguy.ntp")
    assert(parsed_role['src'] == "geerlingguy.ntp")
    assert(parsed_role['scm'] is None)
    assert(parsed_role['version'] == "2.0.0")

    role = "geerlingguy.ntp,1.0.1,foo"
    parsed_role = RoleRequirement.role_yaml_parse(role)
    assert(parsed_role['name'] == "foo")

# Generated at 2022-06-25 05:58:15.696699
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    repo_url = "https://github.com/example/repo"
    assert role_requirement_0.repo_url_to_role_name(repo_url) == "repo"


# Generated at 2022-06-25 05:58:25.735887
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    display.display('Unit test for method role_yaml_parse of class RoleRequirement')
    role_requirement = RoleRequirement()
    role = 'https://github.com/ansible/ansible-examples.git'
    try:
        role_yaml_parse = role_requirement.role_yaml_parse(role)
        display.display('role_yaml_parse = ' + str(role_yaml_parse))
        assert role_yaml_parse is not None
    except Exception as e:
        display.display_error('Failed to parse role %s: %s' % (role, e))


# Generated at 2022-06-25 05:58:36.822773
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    myResultDict = RoleRequirement.role_yaml_parse('jdauphant.nginx,v1.8.0,test_name')
    if myResultDict['name'] != 'test_name' or myResultDict['version'] != 'v1.8.0' or myResultDict['src'] != 'jdauphant.nginx':
        raise AssertionError("role_yaml_parse test_case_1 error")
    if 'scm' in myResultDict:
        raise AssertionError("role_yaml_parse test_case_1 error")

    myResultDict = RoleRequirement.role_yaml_parse('jdauphant.nginx,v1.8.0')

# Generated at 2022-06-25 05:58:47.342098
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    assert role_requirement_1.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement_1.repo_url_to_role_name('https://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement_1.repo_url_to_role_name('git@git.example.com/repos/repo.git') == 'repo'
    assert role_requirement_1.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement_1.repo_url_to_role_

# Generated at 2022-06-25 05:58:56.108166
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

  # Case 0 - role with the new style
  role_requirement_0 = RoleRequirement()
  role = dict(src="http://git.example.com/repos/repo.git")

  role_return_value = role_requirement_0.role_yaml_parse(role)

  if not isinstance(role_return_value, dict):
      raise ValueError("role_yaml_parse return value (%s) is not an instance of dict" % role_return_value)

  if len(role_return_value) != 4:
      raise ValueError("role_yaml_parse return value's size (%s) != 4" % len(role_return_value))


# Generated at 2022-06-25 05:59:04.624612
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    '''
    Test that a string is properly parsed into a dict suitable
    for consumption by the Role constructor.
    Validate in the process that the role name
    is properly extracted from the role specifier.
    '''
    role_requirement = RoleRequirement()
    role = 'my_role'
    expected_role_dict = dict(name=role, scm=None, src=role, version=None)
    actual_role_dict = role_requirement.role_yaml_parse(role)
    assert actual_role_dict == expected_role_dict, \
        "Expected role dict %s but got %s" % (expected_role_dict, actual_role_dict)


# Generated at 2022-06-25 05:59:07.486680
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_requirement_1.role_yaml_parse("role_name")
    assert role_requirement_1.name == "role_name"


# Generated at 2022-06-25 05:59:16.176070
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Test case: None
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name(None) == None

    # Test case: Invalid repo urls
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name(":/repos/repo.git") == None
    assert role_requirement.repo_url_to_role_name("git@git.example.com/repos/repo.git") == None
    assert role_requirement.repo_url_to_role_name("url://git.example.com/repos/repo.git") == None

# Generated at 2022-06-25 05:59:26.762666
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert 'galaxy.role,version,name' == RoleRequirement.role_yaml_parse('galaxy.role,version,name')['src']
    assert False

    # test AnsibleError raised
    try:
        RoleRequirement.role_yaml_parse(',,')
    except AnsibleError:
        pass
    else:
        assert "AssertionError: Invalid role line (,,). Proper format is 'role_name[,version[,name]]'"
        assert False

    # test correct format for new style
    assert 'galaxy.role' == RoleRequirement.role_yaml_parse('galaxy.role')['src']
    assert 'galaxy.role,version,name' == RoleRequirement.role_yaml_parse('galaxy.role,version,name')['src']

    # test AnsibleError raised

# Generated at 2022-06-25 05:59:36.512902
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role = 'geerlingguy.java,v1.7.0,Java 7 development'
    expected_role_1 = {
        'name': 'geerlingguy.java',
        'scm': None,
        'src': 'geerlingguy.java',
        'version': 'v1.7.0'
    }
    display.display("1st test case")
    display.display("role: " + str(role))
    display.display("expected_role: " + str(expected_role_1))
    calculated_role_1 = role_requirement_1.role_yaml_parse(role)
    display.display("calculated_role: " + str(calculated_role_1))

# Generated at 2022-06-25 05:59:50.406809
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # This is a test for proper error handling
    role_requirement_2 = RoleRequirement()
    role_0 = 'git+git://git.example.com/repos/repo.git,v1.0,role_name'.split(',')[:3]
    try:
        role_requirement_2.role_yaml_parse(role_0)
    except AnsibleError:
        pass

    # Create a test object
    role_requirement_3 = RoleRequirement()
    role_1 = 'git+git://git.example.com/repos/repo.git'
    role_2 = 'git+git://git.example.com/repos/repo.git, v1.1'

# Generated at 2022-06-25 05:59:58.029161
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    role_requirement_0 = RoleRequirement()
    result_0 = role_requirement_0.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    assert("repo" == result_0)

    result_1 = role_requirement_0.repo_url_to_role_name("git+https://git.example.com/repos/repo.git")
    assert("repo" == result_1)

    result_2 = role_requirement_0.repo_url_to_role_name("git+https://git.example.com/repos/repo.git,v1.2")
    assert("repo" == result_2)

    result_3 = role_requirement_0.repo_url_to_role_

# Generated at 2022-06-25 06:00:09.226478
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_1 = RoleRequirement()
    role_yaml_parse_1 = role_requirement_1.role_yaml_parse('https://github.com/username/repo')
    print("\nrole_yaml_parse_1: %s" % role_yaml_parse_1)

    role_requirement_2 = RoleRequirement()
    role_yaml_parse_2 = role_requirement_2.role_yaml_parse('https://github.com/username/repo,v1.0')
    print("\nrole_yaml_parse_2: %s" % role_yaml_parse_2)

    role_requirement_3 = RoleRequirement()

# Generated at 2022-06-25 06:00:17.036627
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    repo_url = 'http://git.example.com/repos/repo.git'
    expected_name = 'repo'
    actual_name = role_requirement.repo_url_to_role_name(repo_url)
    assert expected_name == actual_name, "Expected: " + expected_name + " Actual: " + actual_name


# Generated at 2022-06-25 06:00:24.355939
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    assert role_requirement_1.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement_1.repo_url_to_role_name('https://github.com/foo/bar.git') == 'bar'
    assert role_requirement_1.repo_url_to_role_name('https://github.com/foo/bar.git,1.0,foo') == 'bar'
    assert role_requirement_1.repo_url_to_role_name('git://git.example.com/repos/repo.git,branch') == 'repo'
    assert role_requirement_1.repo_url_to_role_name

# Generated at 2022-06-25 06:00:31.111880
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print("Testing role_yaml_parse")
    # Test line requirement - only name
    try:
        role_0 = {'role': 'test'}
        role_0_res = role_requirement_0.role_yaml_parse(role_0)
        assert role_0_res['name'] == 'test'
        assert role_0_res['src'] == 'test'
        assert role_0_res['version'] == ''
        assert role_0_res['scm'] == None
    except AssertionError:
        print("ERROR: role_0 dict is not right")

    # Test line requirement - name and version

# Generated at 2022-06-25 06:00:41.097439
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()


# Generated at 2022-06-25 06:00:50.544483
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()

    # Put your test command here
    # result[0] = role_requirement_0.role_yaml_parse("git+http://github.com/geerlingguy/ansible-role-apache,1.5.5,name=geerlingguy.apache")
    result = role_requirement_0.role_yaml_parse("git+http://github.com/geerlingguy/ansible-role-apache")

    assert result['scm'] == 'git'
    assert result['name'] == 'geerlingguy.apache'


# Generated at 2022-06-25 06:00:55.709806
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    src_0 = "git+git@github.com:ansible/ansible-modules-core.git"
    return role_requirement_0.role_yaml_parse(src_0)


if __name__ == '__main__':
    test_case_0()
    test_RoleRequirement_role_yaml_parse()

# Generated at 2022-06-25 06:01:06.288237
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    repo_url1 = "http://git.example.com/repos/repo.git"
    role_name = role_requirement.repo_url_to_role_name(repo_url1)
    assert(role_name == "repo")

    repo_url2 = "git@git.example.com:repos/repo.git"
    role_name = role_requirement.repo_url_to_role_name(repo_url2)
    assert(role_name == "repo")

    repo_url3 = "repo"
    role_name = role_requirement.repo_url_to_role_name(repo_url3)
    assert(role_name == "repo")


# Generated at 2022-06-25 06:01:19.070650
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    r1 = RoleRequirement()
    s='grafana.grafana,v3.1.1'
    r1_d = r1.role_yaml_parse(s)
    assert(r1_d['name'] == 'grafana.grafana')
    assert(r1_d['scm'] == None)
    assert(r1_d['src'] == 'grafana.grafana')
    assert(r1_d['version'] == 'v3.1.1')

    r2 = RoleRequirement()
    s='git+https://github.com/grafana/grafana-ansible,v3.1.1'
    r2_d = r2.role_yaml_parse(s)

# Generated at 2022-06-25 06:01:27.165459
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 06:01:36.115557
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse("https://github.com/geerlingguy/ansible-role-apache.git") == {'name': 'ansible-role-apache', 'scm': 'git', 'src': 'ansible-role-apache', 'version': None}
    assert role_requirement.role_yaml_parse("https://github.com/geerlingguy/ansible-role-apache.git,v1") == {'name': 'ansible-role-apache', 'scm': 'git', 'src': 'ansible-role-apache', 'version': 'v1'}

# Generated at 2022-06-25 06:01:43.694398
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_yaml_parse_result = role_requirement_1.role_yaml_parse({'src': 'roles/role1,master,bogus'})
    assert(role_yaml_parse_result['name'] == 'role1')
    assert(role_yaml_parse_result['version'] == 'master')
    assert(role_yaml_parse_result['src'] == 'roles/role1')
    assert(role_yaml_parse_result['scm'] == None)
    
    role_yaml_parse_result = role_requirement_1.role_yaml_parse({'src': 'roles/role1,master'})
    assert(role_yaml_parse_result['name'] == 'role1')

# Generated at 2022-06-25 06:01:54.256317
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role = dict()

    role['role'] = 'geerlingguy.jenkins'
    result = role_requirement_1.role_yaml_parse(role)
    assert result['name'] == 'geerlingguy.jenkins'
    assert result['role'] == 'geerlingguy.jenkins'
    assert result['scm'] == 'git'
    assert result['src'] == 'geerlingguy.jenkins'
    assert result['version'] == ''

    role = dict()

    role['role'] = 'geerlingguy.jenkins,v1.2.3'
    result = role_requirement_1.role_yaml_parse(role)
    assert result['name'] == 'geerlingguy.jenkins'
    assert result['role']

# Generated at 2022-06-25 06:01:57.083851
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_0 = RoleRequirement.role_yaml_parse("geerlingguy.jenkins")
    assert role_0 == { 'name': 'geerlingguy.jenkins', 'src': 'geerlingguy.jenkins', 'scm': None, 'version': None }


# Generated at 2022-06-25 06:02:06.152122
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-25 06:02:16.925509
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.git") == "repo,v1.0"
    assert role_requirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("file:///path/to/repo") == "repo"

# Generated at 2022-06-25 06:02:27.364581
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Arrange
    role_requirement_1 = RoleRequirement()

    # Act
    result_1 = role_requirement_1.role_yaml_parse("ansible-role-apache,1.0")

    # Assert
    # print("Result_1: %s" % result_1)
    assert result_1['name'] == 'ansible-role-apache'
    assert result_1['version'] == '1.0'

    # Act
    result_2 = role_requirement_1.role_yaml_parse("https://github.com/geerlingguy/ansible-role-apache.git,1.0,geerlingguy.apache")

    # Assert
    # print("Result_2: %s" % result_2)

# Generated at 2022-06-25 06:02:34.116115
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    # normal HTTP case
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git")=="repo", "HTTP case failed"
    # normal SSH case
    assert role_requirement.repo_url_to_role_name("git@git.example.com:repos/repo.git")=="repo", "SSH case failed"
    # test leading slash
    assert role_requirement.repo_url_to_role_name("git.example.com/repos/repo.git")=="repo", "leading slash case failed"
    # test trailing slash

# Generated at 2022-06-25 06:02:45.417487
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    requirement_a = {"src": "git+https://github.com/someuser/somegitrepo.git,master,some_name",
                     "version": "master"}
    requirement_a["name"] = "someuser.somegitrepo"
    requirement_b = RoleRequirement.role_yaml_parse(requirement_a)
    assert requirement_a == requirement_b

    requirement_a = {"name": "someuser.somegitrepo", "scm": "git", "src": "https://github.com/someuser/somegitrepo.git"}
    requirement_b = RoleRequirement.role_yaml_parse(requirement_a)
    assert requirement_a == requirement_b


# Generated at 2022-06-25 06:02:55.159553
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()

# Generated at 2022-06-25 06:03:02.181512
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = {
        "role": "Ansible-devel.galaxy_server",
        "scm": "git",
        "src": "https://github.com/ansible/galaxy_server.git",
        "version": "v1.0rc1"
    }
    res = RoleRequirement.role_yaml_parse(role)
    assert res['name'] == "Ansible-devel.galaxy_server"
    assert res['scm'] == 'git'
    assert res['src'] == 'https://github.com/ansible/galaxy_server.git'
    assert res['version'] == "v1.0rc1"


# Generated at 2022-06-25 06:03:11.346076
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    # Case 1
    role = {'role': 'galaxy.user.role_name'}
    role_requirement_1.role_yaml_parse(role)

    # Case 2
    role = {'role': 'galaxy.user.role_name,v2.0'}
    role_requirement_1.role_yaml_parse(role)

    # Case 3
    role = {'role': 'galaxy.user.role_name,v2.0,DifferentName'}
    role_requirement_1.role_yaml_parse(role)

    # Case 4
    role = {'role': 'galaxy.user.role_name,v2.0,DifferentName,Ignored'}
    role_requirement_1.role_yaml

# Generated at 2022-06-25 06:03:17.858508
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role = 'geerlingguy.apache'
    name = 'geerlingguy.apache'
    src = 'geerlingguy.apache'
    version = None
    scm = None

    role_dict = {'name': name, 'role': 'geerlingguy.apache', 'src': src, 'scm': scm, 'version': version}
    assert role_requirement_0.role_yaml_parse(role) == role_dict


# Generated at 2022-06-25 06:03:23.696788
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    # Test cases
    assert role_requirement_0.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'

    # Case: no protocol
    assert role_requirement_0.repo_url_to_role_name('git.example.com/repos/repo.git') == 'repo'

    # Case: trailing .tar.gz
    assert role_requirement_0.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'

    # Case: trailing .git

# Generated at 2022-06-25 06:03:26.246004
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    url_0 = 'http://git.example.com/repos/repo.git'
    role_name_0 = role_requirement_0.repo_url_to_role_name(url_0)
    assert role_name_0 == 'repo'


# Generated at 2022-06-25 06:03:36.664215
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    test_url_0 = 'http://git.example.com/repos/repo.git'
    role_name_0 = role_requirement.repo_url_to_role_name(test_url_0)
    assert role_name_0 == 'repo'

    test_url_1 = 'http://git.example.com/repos/repo_with_version.2.0.git'
    role_name_1 = role_requirement.repo_url_to_role_name(test_url_1)
    assert role_name_1 == 'repo_with_version.2.0'

    test_url_2 = 'http://git.example.com/repos/repo.tar.gz'
    role_name_2 = role_

# Generated at 2022-06-25 06:03:46.756406
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    # Invalid case
    expected_result_1 = None
    actual_result_1 = role_requirement_1.role_yaml_parse('apache,version,name,extra')
    assert expected_result_1 == actual_result_1

    # Valid case
    role_requirement_2 = RoleRequirement()
    expected_result_2 = dict(name='apache', src='apache', scm=None, version='version,name')
    actual_result_2 = role_requirement_2.role_yaml_parse('apache,version,name')
    assert expected_result_2 == actual_result_2

    # Valid case
    role_requirement_3 = RoleRequirement()

# Generated at 2022-06-25 06:03:48.673857
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 06:04:01.335685
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 06:04:12.092743
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    src_url = "https://github.com/geerlingguy/ansible-role-apache.git"
    src_url2 = "https://github.com/geerlingguy/ansible-role-apache.git,v1.0.1"
    src_url3 = "https://github.com/geerlingguy/ansible-role-apache.git,v1.0.1,whatevs"
    src_url4 = "https://github.com/geerlingguy/ansible-role-apache.git,v1.0.1,whatevs,too_many"

    role_requirement = RoleRequirement()
    result = role_requirement.role_yaml_parse(src_url)

# Generated at 2022-06-25 06:04:21.423214
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()

    # run test
    ret = role_requirement_1.role_yaml_parse("geerlingguy.nfs")

    assert ret["src"] == "geerlingguy.nfs", "Error on line 62 of test_galaxy.py"
    assert ret["name"] == "geerlingguy.nfs", "Error on line 63 of test_galaxy.py"
    assert ret["scm"] is None, "Error on line 64 of test_galaxy.py"
    assert ret["version"] == "", "Error on line 65 of test_galaxy.py"


# Generated at 2022-06-25 06:04:31.093830
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    result = RoleRequirement.role_yaml_parse("my-role,v0.2.0,my_name")
    assert result == {'name': 'my_name', 'src': 'my-role', 'scm': None, 'version': 'v0.2.0'}
    result = RoleRequirement.role_yaml_parse("my-role,v0.2.0")
    assert result == {'name': 'my-role', 'src': 'my-role', 'scm': None, 'version': 'v0.2.0'}
    result = RoleRequirement.role_yaml_parse("my-role")
    assert result == {'name': 'my-role', 'src': 'my-role', 'scm': None, 'version': ''}
    result = RoleRequirement.role_yaml

# Generated at 2022-06-25 06:04:34.875635
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_string = 'my-role,v0.1.0'
    assert RoleRequirement.role_yaml_parse(test_string) == {'name': 'my-role', 'src': 'my-role', 'version': 'v0.1.0', 'scm': None}



# Generated at 2022-06-25 06:04:44.933563
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    repo_url_0 = 'git+git://git.example.com/repos/repo.git'
    expected_role_name_0 = 'repo'
    role_name = role_requirement.repo_url_to_role_name(repo_url_0)
    assert role_name == expected_role_name_0

    repo_url_1 = 'http://git.example.com/repos/repo.git'
    expected_role_name_1 = 'repo'
    role_name = role_requirement.repo_url_to_role_name(repo_url_1)
    assert role_name == expected_role_name_1


# Generated at 2022-06-25 06:04:51.429731
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Test 1
    role_requirement = RoleRequirement()
    repo_url = "http://git.example.com/repos/repo.git"
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert('repo' == role_name)

    # Test 2
    role_requirement = RoleRequirement()
    repo_url = "http://git.example.com/repos/repo"
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert('repo' == role_name)

    # Test 3
    role_requirement = RoleRequirement()
    repo_url = "http://git.example.com/repos/repo.tar.gz"
    role_name

# Generated at 2022-06-25 06:04:59.045375
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # New style: { src: 'galaxy.role,version,name', other_vars: "here" }
    role = role_requirement_0.role_yaml_parse("galaxy.role,version,name")
    assert role == dict(name='name', src='galaxy.role,version', scm=None, version='version')

    # New style: { src: 'galaxy.role,version', other_vars: "here" }
    role = role_requirement_0.role_yaml_parse("galaxy.role,version")
    assert role == dict(name='galaxy.role', src='galaxy.role', scm=None, version='version')

    # New style: { src: 'galaxy.role', other_vars: "here" }

# Generated at 2022-06-25 06:05:07.081503
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Single role with scm, version and name specified
    role_yaml = dict(role='my_galaxy_role,version=1.0.1,name=my_galaxy_role_name')
    role = RoleRequirement.role_yaml_parse(role_yaml)
    assert role == dict(name='my_galaxy_role_name', src='my_galaxy_role', scm=None, version='version=1.0.1')

    # Single role with scm, version and no name specified
    role_yaml = dict(role='my_galaxy_role,version=1.0.1')
    role = RoleRequirement.role_yaml_parse(role_yaml)

# Generated at 2022-06-25 06:05:15.374836
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print('+++ unit test for RoleRequirement::role_yaml_parse +++')
    role_1 = {
        'role': 'geerlingguy.mysql',
        'version': '1.0.0'
    }
    role_requirement = RoleRequirement()
    role = role_requirement.role_yaml_parse(role_1)
    print('role: name: %s, src: %s, scm: %s, version: %s' % \
          (role['name'], role['src'], role['scm'], role['version']))
    assert role['name'] == 'geerlingguy.mysql'
    assert role['src'] == 'geerlingguy.mysql'
    assert role['scm'] == None
    assert role['version'] == '1.0.0'
