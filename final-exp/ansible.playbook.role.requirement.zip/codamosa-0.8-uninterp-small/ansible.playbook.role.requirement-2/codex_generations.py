

# Generated at 2022-06-25 05:55:32.454646
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    display.info('*****Test case: test_RoleRequirement_role_yaml_parse*****')


# Generated at 2022-06-25 05:55:36.003194
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    result = RoleRequirement.role_yaml_parse("")
    assert result is None

test_case_0()

# Generated at 2022-06-25 05:55:42.462267
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print("Testing role_yaml_parse")
    test_args = {}
    test_args['src'] = 'git+https://github.com/rackerlabs/ansible-role-redis.git'
    test_args['scm'] = 'git'
    test_args['name'] = 'ansible-role-redis'
    test_args['version'] = 'master'
    rr = RoleRequirement()
    expected_rc = test_args
    rc = rr.role_yaml_parse(test_args['name'] + ',' + test_args['version'])
    assert( rc == expected_rc)


# Generated at 2022-06-25 05:55:53.010968
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Case 1: old style - name only
    role_name_only = dict(role="apt")
    data_expected = dict(name="apt", src=None, scm=None, version=None)
    data = RoleRequirement().role_yaml_parse(role_name_only)
    assert data == data_expected

    # Case 2: old style - name and version
    role_name_version = dict(role="apt,1.0")
    data_expected = dict(name="apt", src=None, scm=None, version="1.0")
    data = RoleRequirement().role_yaml_parse(role_name_version)
    assert data == data_expected

    # Case 3: old style - name, version, and src

# Generated at 2022-06-25 05:56:03.660806
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    # Test for repo_url of the form:
    # url_0 = "http://git.example.com/repos/repo.git" => "repo"
    url_0 = "http://git.example.com/repos/repo.git"
    assert role_requirement.repo_url_to_role_name(url_0) == "repo"
    # Test for repo_url of the form:
    # url_1 = "git@git.example.com:repos/repo.git" => "repo"
    url_1 = "git@git.example.com:repos/repo.git"
    assert role_requirement.repo_url_to_role_name(url_1) == "repo"
    # Test for

# Generated at 2022-06-25 05:56:14.553643
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Positive test case
    role_requirement_1 = RoleRequirement()
    role_info_1 = role_requirement_1.role_yaml_parse(src="http://git.example.com/repos/repo.git")
    assert role_info_1["name"] == "repo", "Role name not extracted correctly"
    assert role_info_1["src"] == "http://git.example.com/repos/repo.git", "Source of role not extracted correctly"
    assert role_info_1["scm"] is None, "No scm should be extracted"
    assert role_info_1["version"] == "", "Empty version should be extracted"

    # Positive test case, with variation
    role_requirement_2 = RoleRequirement()

# Generated at 2022-06-25 05:56:24.708475
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.release import __version__
    from ansible.utils.version import LooseVersion

    role = 'git+https://github.com/test/test.git'
    role_requirement = RoleRequirement()
    result = role_requirement.role_yaml_parse(role)

    if LooseVersion(__version__) < LooseVersion('2.4.0'):
        assert result == {'scm': 'git', 'version': None, 'src': 'https://github.com/test/test.git', 'name': 'test.git'}
    else:
        assert result == {'scm': 'git', 'version': 'HEAD', 'src': 'https://github.com/test/test.git', 'name': 'test.git'}



# Generated at 2022-06-25 05:56:31.343159
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    data_0 = {
        'role': 'geerlingguy.apache',
        'allow_duplicates': False,
    }
    role_requirement_0 = RoleRequirement.role_yaml_parse(data_0)
    assert role_requirement_0['name'] == 'geerlingguy.apache'
    assert role_requirement_0['allow_duplicates'] == False
    assert role_requirement_0['scm'] is None
    assert role_requirement_0['src'] is None
    assert role_requirement_0['version'] is None



# Generated at 2022-06-25 05:56:36.797032
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    print(role_requirement.role_yaml_parse("geerlingguy.mysql,v0.1.0"))

if __name__ == "__main__":
    test_RoleRequirement_role_yaml_parse()

# Generated at 2022-06-25 05:56:46.860125
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    role_requirement = RoleRequirement()

    repo_url = "git+git://github.com/ansible/ansible-examples.git,v1.2.3,ansible-examples"
    assert role_requirement.repo_url_to_role_name(repo_url) == "ansible-examples"

    repo_url = "http://git.example.com/repos/repo.git"
    assert role_requirement.repo_url_to_role_name(repo_url) == "repo"

    repo_url = "file:///home/someuser/testing/awesome.tar.gz"
    assert role_requirement.repo_url_to_role_name(repo_url) == "awesome"


# Generated at 2022-06-25 05:57:00.637996
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # First test case
    input_0 = dict(src='https://github.com/jlund/ansible_extras.git', version='master')
    actual_result_0 = RoleRequirement.role_yaml_parse(input_0)
    expected_result_0 = dict(name='ansible_extras', scm='git', src='https://github.com/jlund/ansible_extras.git', version='master')
    assert actual_result_0 == expected_result_0
    # Second test case
    input_1 = dict(role='geerlingguy.java')
    actual_result_1 = RoleRequirement.role_yaml_parse(input_1)
    expected_result_1 = dict(name='geerlingguy.java', scm=None, src=None, version='')
   

# Generated at 2022-06-25 05:57:09.869140
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('src_test') == {'name': 'src_test', 'src': 'src_test', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('src_test,version_test') == {'name': 'src_test', 'src': 'src_test', 'scm': None, 'version': 'version_test'}
    assert RoleRequirement.role_yaml_parse('src_test,version_test,name_test') == {'name': 'name_test', 'src': 'src_test', 'scm': None, 'version': 'version_test'}

# Generated at 2022-06-25 05:57:14.383012
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement = role_requirement_0.role_yaml_parse("role1,v0.1")
    print("Role requirement %s" % role_requirement)
    if role_requirement["name"] != "role1" or role_requirement["version"] != "v0.1":
        raise ValueError("Role requirement not parsed correctly")


# Generated at 2022-06-25 05:57:22.450502
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Given:
    role = 'http://git.example.com/repos/repo.git,v1.0'

    # When:
    role_requirement = role_requirement_0.role_yaml_parse(role)

    # Then:
    assert role_requirement['name'] == 'repo'
    assert role_requirement['scm'] == 'git'
    assert role_requirement['src'] == 'http://git.example.com/repos/repo.git'
    assert role_requirement['version'] == 'v1.0'


# Generated at 2022-06-25 05:57:29.984893
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_1 = RoleRequirement.role_yaml_parse({u'src': u'https://github.com/github1', u'name': u'github1'})
    assert role_requirement_1 == {'src': 'https://github.com/github1', 'scm': None, 'version': '', 'name': 'github1'}
    #print(role_requirement_1)
    role_requirement_2 = RoleRequirement.role_yaml_parse({u'src': u'https://github.com/github2', u'name': u'github2', u'scm': u'git'})

# Generated at 2022-06-25 05:57:39.481486
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_definition_1 = role_requirement_1.role_yaml_parse("/home/user/roles_host/myrole")
    assert role_definition_1 == {'name': 'myrole', 'scm': None, 'src': '/home/user/roles_host/myrole', 'version': None}
    role_definition_2 = role_requirement_1.role_yaml_parse("http://git.example.com/repos/repo.git")
    assert role_definition_2 == {'name': 'repo', 'scm': None, 'src': 'http://git.example.com/repos/repo.git', 'version': None}
    

# Generated at 2022-06-25 05:57:51.495046
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_1 = RoleRequirement()
    role_requirement_1_result = role_requirement_1.role_yaml_parse("galaxy.role,v1,name")
    assert "name" in role_requirement_1_result
    assert role_requirement_1_result["name"] == "name"
    assert "scm" in role_requirement_1_result
    assert role_requirement_1_result["scm"] is None
    assert "src" in role_requirement_1_result
    assert role_requirement_1_result["src"] == "galaxy.role"
    assert "version" in role_requirement_1_result
    assert role_requirement_1_result["version"] == "v1"

    role_requirement_2 = RoleRequirement()
    role

# Generated at 2022-06-25 05:57:56.528689
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    role_requirement_1.repo_url_to_role_name("git+git://git.example.com/ansible-role-nginx.git")
    role_requirement_1.repo_url_to_role_name("git://git.example.com/ansible-role-nginx.git")
    role_requirement_1.repo_url_to_role_name("http://github.com/kewljoe/ansible-role-example")
    role_requirement_1.repo_url_to_role_name("kewljoe.example")


# Generated at 2022-06-25 05:58:03.744169
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_role_yaml_parse = RoleRequirement()
    role = "foo,1.2.3,bar"
    result = role_requirement_role_yaml_parse.role_yaml_parse(role)
    expected = {
        'name': 'bar',
        'src': 'foo',
        'scm': None,
        'version': '1.2.3'
    }
    assert(result == expected)



# Generated at 2022-06-25 05:58:10.822269
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    # role is a string
    role_0 = "foo,bar"
    result = role_requirement.role_yaml_parse(role_0)
    assert result['scm'] == None
    assert result['src'] == 'foo'
    assert result['name'] == 'bar'
    assert result['version'] == None
    # role is a dict
    role_1 = dict(role="foo", bar="baz")
    result = role_requirement.role_yaml_parse(role_1)
    assert result['name'] == 'foo'
    assert result['bar'] == 'baz'
    # role is a dict
    role_2 = dict(src="http://github.com/user/repo", bar="baz")
    result = role_requirement.role

# Generated at 2022-06-25 05:58:26.250006
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    role_requirement_0 = RoleRequirement()

    # Tests for the method repo_url_to_role_name of class RoleRequirement
    # Test case for the method repo_url_to_role_name of class RoleRequirement

    # Test case for the method repo_url_to_role_name of class RoleRequirement
    # Test case for the method repo_url_to_role_name of class RoleRequirement
    # Test case for the method repo_url_to_role_name of class RoleRequirement
    # Test case for the method repo_url_to_role_name of class RoleRequirement
    # Test case for the method repo_url_to_role_name of class RoleRequirement
    # Test case for the method repo_url_to_role_name of class RoleRequirement
    # Test case for the method repo_url_

# Generated at 2022-06-25 05:58:36.848587
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    role_requirement_0 = RoleRequirement()
    assert role_requirement_0.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'

    role_requirement_1 = RoleRequirement()
    assert role_requirement_1.repo_url_to_role_name('git@git.example.com/repos/repo.git') == 'repo'

    role_requirement_2 = RoleRequirement()
    assert role_requirement_2.repo_url_to_role_name('ssh://git@git.example.com/repos/repo.git') == 'repo'

    role_requirement_3 = RoleRequirement()
    assert role_requirement_3.repo_url_to_role_name

# Generated at 2022-06-25 05:58:45.874497
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    print("Test for method role_yaml_parse of class RoleRequirement")

    role_requirement_0 = RoleRequirement()
    input_string_0 = "{'role': 'galaxy.role', 'foo': 'bar'}"
    role_requirement_expected_result = {'foo': 'bar', 'name': 'galaxy.role'}
    assert role_requirement_expected_result == role_requirement_0.role_yaml_parse(input_string_0)



if __name__ == "__main__":
    test_case_0()
    test_RoleRequirement_role_yaml_parse()

# Generated at 2022-06-25 05:58:54.128738
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_2 = RoleRequirement()
    assert role_requirement_2.repo_url_to_role_name('git@github.com:ansible/ansible.git') == 'ansible'
    assert role_requirement_2.repo_url_to_role_name('https://github.com:ansible/ansible.git') == 'ansible'
    assert role_requirement_2.repo_url_to_role_name('https://github.com:ansible/ansible.tar.gz') == 'ansible'

if __name__ == '__main__':
    test_case_0()
    test_RoleRequirement_repo_url_to_role_name()

# Generated at 2022-06-25 05:59:02.583230
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    if isinstance(role_requirement, object):
        assert True
    else:
        assert False

    role_yaml_parse = role_requirement.role_yaml_parse

    # Test 1
    r1 = role_yaml_parse(dict(role='geerlingguy.jenkins', exclusive=True))
    assert r1['name'] == 'geerlingguy.jenkins'
    assert r1['exclusive'] == True
    assert r1.get('scm') is None
    assert r1.get('version') is None

    # Test 2
    r2 = role_yaml_parse(dict(role='geerlingguy.jenkins,1.2.3', exclusive=True))
    assert r2['name'] == 'geerlingguy.jenkins'


# Generated at 2022-06-25 05:59:05.933796
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    assert role_requirement_0.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'


# Generated at 2022-06-25 05:59:11.882886
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("") == ""
    assert RoleRequirement.repo_url_to_role_name("foo") == "foo"
    assert RoleRequirement.repo_url_to_role_name("git@github.com:foo/bar.git") == "bar"
    assert RoleRequirement.repo_url_to_role_name("git@github.com:foo/bar,baz.git") == "bar"


# Generated at 2022-06-25 05:59:18.751658
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("https://github.com/user/repo.git") == "repo"



# Generated at 2022-06-25 05:59:25.716379
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    repo_url = "http://git.example.com/repos/repo.git"
    assert role_requirement.repo_url_to_role_name(repo_url) == "repo"

    repo_url = "https://git.example.com/repos/repo.git"
    assert role_requirement.repo_url_to_role_name(repo_url) == "repo"

    repo_url = "user@git.example.com/repos/repo.git"
    assert role_requirement.repo_url_to_role_name(repo_url) == "repo"

    repo_url = "git.example.com/repos/repo.git"
    assert role_requirement.repo_url

# Generated at 2022-06-25 05:59:32.354277
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role_string = "{ src: 'galaxy.role,version,name', other_vars: 'here' }"
    role_dict = {"src": "galaxy.role,version,name", "other_vars": "here"}
    assert role_requirement.role_yaml_parse(role_string) == role_dict
    assert role_requirement.role_yaml_parse(role_dict) == role_dict

# Generated at 2022-06-25 05:59:48.404237
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 05:59:53.533463
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    from ansible.module_utils.six import PY2


# Generated at 2022-06-25 05:59:55.537227
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    src_url = 'git@github.com:ansible/ansible-examples.git'
    role_requirement_0 = RoleRequirement()
    assert role_requirement_0.repo_url_to_role_name(src_url) == 'ansible-examples'

# Generated at 2022-06-25 05:59:59.853468
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()

    assert role_requirement_1.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role_requirement_1.repo_url_to_role_name("https://github.com/user/repo.git") == "repo"
    assert role_requirement_1.repo_url_to_role_name("git://git.example.com/repos/repo.git") == "repo"
    assert role_requirement_1.repo_url_to_role_name("git+http://git.example.com/repos/repo.git") == "repo.git"
    assert role_requirement_1.repo_url_to_role

# Generated at 2022-06-25 06:00:06.354568
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test case using the following input:
    # role = 'test_role_name'

    role_requirement = RoleRequirement()
    role = 'test_role_name'
    return_value = role_requirement.role_yaml_parse(role)

    # Assert the return value equals to the following value:
    #
    # {'name': 'test_role_name', 'scm': None, 'src': 'test_role_name', 'version': None}

    assert return_value == {'name': 'test_role_name', 'scm': None, 'src': 'test_role_name', 'version': None}


# Generated at 2022-06-25 06:00:15.212044
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test with no arguments
    role_requirement = RoleRequirement()
    expected = {}
    actual = role_requirement.role_yaml_parse()
    assert actual == expected
    # Test with single argument
    role_requirement = RoleRequirement()
    expected = {}
    actual = role_requirement.role_yaml_parse("")
    assert actual == expected
    expected = { 'name' : 'testname'}
    actual = role_requirement.role_yaml_parse("testname")
    assert actual == expected
    expected = { 'name' : 'testname'}
    actual = role_requirement.role_yaml_parse("git+git@git.server.com:user/testname.git")
    assert actual == expected
    expected = {}
    actual = role_requirement.role_y

# Generated at 2022-06-25 06:00:22.449713
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role = "some_role,v1.0"
    role_yaml = role_requirement_1.role_yaml_parse(role)
    assert(role_yaml["name"] == "some_role")
    assert(role_yaml["version"] == "v1.0")


# Generated at 2022-06-25 06:00:30.355928
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    print("\n---- Method repo_url_to_role_name of class RoleRequirement:")

    role_requirement_0 = RoleRequirement()
    print("\nCase 0:")
    assert role_requirement_0.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    print("\tCase 0 passed !")

    print("\nCase 1:")
    assert role_requirement_0.repo_url_to_role_name("git+git@github.com:ansible/ansible-examples.git") == "ansible-examples"
    print("\tCase 1 passed !")

    print("\nCase 2:")
    assert role_requirement_0.repo_url_to_role_

# Generated at 2022-06-25 06:00:40.815496
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_1 = RoleRequirement()
    role_requirement_2 = RoleRequirement()
    role_requirement_3 = RoleRequirement()
    role_requirement_4 = RoleRequirement()
    role_requirement_5 = RoleRequirement()
    assert role_requirement_0.role_yaml_parse(role={}) == {'name': None, 'src': None, 'scm': None, 'version': ''}
    assert role_requirement_1.role_yaml_parse(role={'role': 'NAME'}) == {'name': 'NAME', 'src': None, 'scm': None, 'version': ''}

# Generated at 2022-06-25 06:00:48.480997
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    # Test for:
    #   'name' in role
    #   invalid old style role requirement:
    #   'role' in role
    src = 'git@github.com:galaxy-examples/ansible-role-postgresql.git,v1.0.0,pgdatabase'
    role_requirement_1 = role_requirement_0.role_yaml_parse(src)
    assert role_requirement_1['name'] == 'git@github.com:galaxy-examples/ansible-role-postgresql.git,v1.0.0,pgdatabase'
    assert role_requirement_1['scm'] == None
    assert role_requirement_1['src'] == None
    assert role_requirement_1['version'] == None

# Generated at 2022-06-25 06:01:02.881746
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert 'role_name' == role_requirement.repo_url_to_role_name('https://github.com/my/repository.git')
    assert 'role_name' == role_requirement.repo_url_to_role_name('git://git.git.git/role_name.git')
    assert 'role_name' == role_requirement.repo_url_to_role_name('file:///tmp/role_name.git')
    assert 'role_name' == role_requirement.repo_url_to_role_name('git@git.git.git:roles/role_name.git')

# Generated at 2022-06-25 06:01:13.255425
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_obj = RoleRequirement()

    assert(role_requirement_obj.role_yaml_parse('geerlingguy.jenkins,1.6.0') == {'name': 'geerlingguy.jenkins', 'src': 'geerlingguy.jenkins', 'scm': None, 'version': '1.6.0'})
    assert(role_requirement_obj.role_yaml_parse('geerlingguy.jenkins') == {'name': 'geerlingguy.jenkins', 'src': 'geerlingguy.jenkins', 'scm': None, 'version': ''})

# Generated at 2022-06-25 06:01:22.516951
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    assert role_requirement_1.repo_url_to_role_name('ansible-role-nginx') == 'ansible-role-nginx'
    assert role_requirement_1.repo_url_to_role_name('https://github.com/myuser/ansible-role-nginx') == 'ansible-role-nginx'
    assert role_requirement_1.repo_url_to_role_name('git+https://github.com/myuser/ansible-role-nginx,v1.0,myuser.nginx') == 'myuser.nginx'

# Generated at 2022-06-25 06:01:29.160793
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_requirement_1 = dict(name='role_requirement_1', src='src_1')
    name = role_requirement_1['name']
    src = role_requirement_1['src']
    role_requirement_1 = role_requirement_1
    role_requirement_1 = role_requirement_1.copy()
    role_requirement_1 = dict(name=name, src=src, scm=None, version=None)
    role_requirement_1_check = RoleRequirement.role_yaml_parse(role_requirement_1)
    print ("\n\n")
    print ("role_requirement_1_check = ", role_requirement_1_check)
    print ("\n\n")

# Generated at 2022-06-25 06:01:36.963919
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    display.info("TESTING role_yaml_parse")
    role_requirement_0 = RoleRequirement()
    role_requirement_src_0 = "/etc/ansible/roles/one"
    role_requirement_name_0 = "one"
    role_requirement_version_0 = "HEAD"
    role_requirement_scm_0 = None
    role_requirement_resolved_0 = role_requirement_0.role_yaml_parse(role_requirement_src_0, role_requirement_name_0, role_requirement_version_0, role_requirement_scm_0)

    display.info(type(role_requirement_resolved_0))


# Generated at 2022-06-25 06:01:44.079509
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    my_instance = RoleRequirement()

    val = my_instance.role_yaml_parse("username.role_name, 1.2.3, optional_role_name")
    assert((val == {'name': 'optional_role_name', 'version': '1.2.3', 'src': 'username.role_name', 'scm': None}))

    val = my_instance.role_yaml_parse("username.role_name")
    assert((val == {'name': 'role_name', 'version': '', 'src': 'username.role_name', 'scm': None}))

    val = my_instance.role_yaml_parse("username.role_name,1.2.3")

# Generated at 2022-06-25 06:01:54.284083
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()

    role_0 = 'alice.role,v1.2.3'
    assert role_requirement_0.role_yaml_parse(role_0) == dict(name='alice.role', src='alice.role', scm=None, version='v1.2.3')

    role_1 = 'https://github.com/libgit2/libgit2.git,v0.24.0,libgit2'
    assert role_requirement_0.role_yaml_parse(role_1) == dict(name='libgit2', src='https://github.com/libgit2/libgit2.git', scm=None, version='v0.24.0')


# Generated at 2022-06-25 06:01:59.824393
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_str = 'https://github.com/myuser/myrepo.git'
    role_str_result = role_requirement_0.role_yaml_parse(role_str)
    print(role_str_result)
    # Check result
    assert 'name' in role_str_result
    assert role_str_result['name'] == 'myrepo'
    assert 'src' in role_str_result
    assert role_str_result['src'] == 'https://github.com/myuser/myrepo.git'
    assert 'scm' in role_str_result
    assert role_str_result['scm'] == None
    assert 'version' in role_str_result
    assert role_str_result['version'] == None

    role

# Generated at 2022-06-25 06:02:06.408215
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_requirement_1.role_yaml_parse('role_name')
    role_requirement_1.role_yaml_parse('role_name,v1.0')
    role_requirement_1.role_yaml_parse('role_name,v1.0,my_name')

    role_requirement_2 = RoleRequirement()
    role_requirement_2.role_yaml_parse(dict(src='http://git.example.com/repos/repo.git'))
    role_requirement_2.role_yaml_parse(dict(src='http://git.example.com/repos/repo.git', name='repo'))

# Generated at 2022-06-25 06:02:16.948078
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role = role_requirement.role_yaml_parse("role[,version[,name]]")
    assert role == {'name': 'role', 'src': 'role', 'scm': None, 'version': 'HEAD'}

    role = role_requirement.role_yaml_parse("role, version")
    assert role == {'name': 'role', 'src': 'role', 'scm': None, 'version': 'version'}

    role = role_requirement.role_yaml_parse("role, version, name")
    assert role == {'name': 'name', 'src': 'role', 'scm': None, 'version': 'version'}


# Generated at 2022-06-25 06:02:33.340074
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_1 = role_requirement_0.role_yaml_parse({'role': 'geerlingguy.java', 'version': '1'})
    assert role_requirement_1 == {'name': 'geerlingguy.java', 'scm': None, 'src': None, 'version': '1'}
    role_requirement_1 = role_requirement_0.role_yaml_parse({'src': 'git+https://github.com/geerlingguy/ansible-role-java.git', 'version': '1'})

# Generated at 2022-06-25 06:02:34.750132
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    url = "http://git.example.com/repos/repo.git"
    assert RoleRequirement.repo_url_to_role_name(url) == "repo"



# Generated at 2022-06-25 06:02:42.517375
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse({"src": "https://github.com/geerlingguy/ansible-role-docker.git", "name": "geerlingguy.docker", "version": "1.1.1", "scm": "git"})

# Generated at 2022-06-25 06:02:52.324005
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement = RoleRequirement()
    role = role_requirement.role_yaml_parse("geerlingguy.ntp")
    assert role['name'] == "geerlingguy.ntp"
    assert role['src'] == "geerlingguy.ntp"
    assert role['scm'] == None
    assert role['version'] == ''

    role = role_requirement.role_yaml_parse("geerlingguy.ntp,1.9")
    assert role['name'] == "geerlingguy.ntp"
    assert role['src'] == "geerlingguy.ntp"
    assert role['scm'] == None
    assert role['version'] == "1.9"

    role = role_requirement.role_yaml_parse("geerlingguy.ntp,v2")

# Generated at 2022-06-25 06:03:02.595148
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Old style
    r_0 = RoleRequirement.role_yaml_parse('foo,v1.0,old')
    assert r_0['name'] == 'old'
    assert r_0['src'] == 'foo'
    assert r_0['scm'] == None
    assert r_0['version'] == 'v1.0'

    r_1 = RoleRequirement.role_yaml_parse('foo,v1.0')
    assert r_1['name'] == 'foo'
    assert r_1['src'] == 'foo'
    assert r_1['scm'] == None
    assert r_1['version'] == 'v1.0'

    r_2 = RoleRequirement.role_yaml_parse('foo')
    assert r_2['name'] == 'foo'
    assert r_

# Generated at 2022-06-25 06:03:11.623520
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    print(role_requirement_0.role_yaml_parse({'role': 'yandex.mongodb', 'version': '1.3.0'}))
    print(role_requirement_0.role_yaml_parse({'role': 'yandex.mongodb'}))
    print(role_requirement_0.role_yaml_parse({'role': 'yandex.mongodb', 'version': '1.3.0', 'name': 'test_role'}))
    print(role_requirement_0.role_yaml_parse({'role': 'yandex.mongodb,test_role'}))

# Generated at 2022-06-25 06:03:19.301649
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_1 = "geerlingguy.ntp"
    yaml_parse_1 = role_requirement_1.role_yaml_parse(role_1)
    assert yaml_parse_1['name'] == 'geerlingguy.ntp'
    assert yaml_parse_1['scm'] is None
    assert yaml_parse_1['src'] == 'geerlingguy.ntp'
    assert yaml_parse_1['version'] is None

    role_requirement_2 = RoleRequirement()
    role_2 = "https://github.com/foo/bar.git,v1.0"
    yaml_parse_2 = role_requirement_2.role_yaml_parse(role_2)
    assert yaml_parse_

# Generated at 2022-06-25 06:03:24.278715
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_data = { 'name': 'test', 'src': 'https://github.com/bigcloudsolutions/ansible-role-bigip_imish.git' }
    role_data_result = role_requirement_1.role_yaml_parse(role_data)
    assert role_data_result == {'name': 'bigip_imish', 'version': '', 'scm': None, 'src': 'https://github.com/bigcloudsolutions/ansible-role-bigip_imish.git'}


# Generated at 2022-06-25 06:03:27.160926
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml_parse_result = RoleRequirement.role_yaml_parse('rolename,v1,name')
    assert role_yaml_parse_result['name'] == 'name'
    assert role_yaml_parse_result['version'] == 'v1'
    assert role_yaml_parse_result['src'] == 'rolename'


# Generated at 2022-06-25 06:03:36.839018
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test case 1
    test_case_1 = dict(name="username.rolename", src="git@example.com:username/rolename", scm="git", version="")
    assert RoleRequirement.role_yaml_parse("username.rolename,1.0") == test_case_1, "role_yaml_parse() test failed"

    # Test case 2
    test_case_2 = dict(name="rolename", src="https://github.com/username/rolename", scm="git", version="")
    assert RoleRequirement.role_yaml_parse("git+https://github.com/username/rolename") == test_case_2, "role_yaml_parse() test failed"

    # Test case 3

# Generated at 2022-06-25 06:04:07.438209
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role = "AVI.AVI-LB-Controller-role"
    assert role_requirement_0.role_yaml_parse(role)["name"] == "AVI.AVI-LB-Controller-role"
    assert role_requirement_0.role_yaml_parse(role)["scm"] == None
    assert role_requirement_0.role_yaml_parse(role)["src"] == "AVI.AVI-LB-Controller-role"
    assert role_requirement_0.role_yaml_parse(role)["version"] == None
    role = "AVI.avi-nuke-all"
    assert role_requirement_0.role_yaml_parse(role)["name"] == "AVI.avi-nuke-all"

# Generated at 2022-06-25 06:04:14.156696
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    role_requirement = RoleRequirement()

    repo_url = 'http://git.example.com/repos/repo.git'
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert role_name == 'repo'

    repo_url = 'http://git.example.com/repos/repo.git,1.1.0'
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert role_name == 'repo'

    repo_url = 'https://github.com/example/repo.git'
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert role_name == 'repo'

    repo

# Generated at 2022-06-25 06:04:23.540093
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_0='role_name'
    role_1=dict(role='role_name')
    role_2=dict(role='role_name', src='role_src')
    role_3=dict(role='role_name', src='role_src', version='1.2.3')
    role_4=dict(role='role_name', src='role_src', name='role_name')
    role_5=dict(role='role_name, 1.2.3')
    role_6=dict(role='role_name, 1.2.3, role_name')

# Generated at 2022-06-25 06:04:28.200400
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    data = "git+git@github.com:ansible/ansible-examples.git,test-scm-version-fix"
    role_result = role_requirement.role_yaml_parse(data)
    assert role_result["name"] == "ansible-examples"
    assert role_result["src"] == "git@github.com:ansible/ansible-examples.git"
    assert role_result["scm"] == "git"
    assert role_result["version"] == "test-scm-version-fix"

    data = "src=https://github.com/ansible/ansible-examples.git,version=1.4.4"
    role_result = role_requirement.role_yaml_parse(data)
    assert role_

# Generated at 2022-06-25 06:04:35.178463
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    try:
        role_requirement_1 = RoleRequirement()
        response = role_requirement_1.role_yaml_parse('name,1.0,geerlingguy.apache')
        assert response['name'] == 'apache'
    except:
        print ('Exception caught in test_RoleRequirement_role_yaml_parse')


# Generated at 2022-06-25 06:04:44.980321
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    my_input = {
        'role': 'geerlingguy.git',
        'src': 'git+https://github.com/geerlingguy/ansible-role-git.git',
        'x': 'y',
        'version': '1.0'
    }
    my_output = role_requirement_0.role_yaml_parse(my_input)
    assert my_output == {
        'name': 'git',
        'scm': 'git',
        'src': 'https://github.com/geerlingguy/ansible-role-git.git',
        'version': '1.0'
    }, 'Test failed: my_output: {0}'.format(my_output)

# Generated at 2022-06-25 06:04:47.262609
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    assert role_requirement_0.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"



# Generated at 2022-06-25 06:04:58.265731
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    # Test with an url with the scheme ssh
    repo_url = 'ssh://git@git.example.com:7999/infra/ansible-role-test.git'
    expected_role_name = 'ansible-role-test'
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert(role_name == expected_role_name)

    # Test with an url with the scheme git
    repo_url = 'git://example.com/test.git'
    expected_role_name = 'test'
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert(role_name == expected_role_name)

    # Test with an url with the

# Generated at 2022-06-25 06:05:06.069723
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_1 = RoleRequirement()
    role_requirement_2 = RoleRequirement()
    role_requirement_3 = RoleRequirement()
    role_requirement_4 = RoleRequirement()
    role_requirement_5 = RoleRequirement()
    role_requirement_6 = RoleRequirement()
    role_requirement_7 = RoleRequirement()
    role_requirement_8 = RoleRequirement()
    role_requirement_9 = RoleRequirement()
    role_requirement_10 = RoleRequirement()
    role_requirement_11 = RoleRequirement()

    assert role_requirement_1.role_yaml_parse("") == None