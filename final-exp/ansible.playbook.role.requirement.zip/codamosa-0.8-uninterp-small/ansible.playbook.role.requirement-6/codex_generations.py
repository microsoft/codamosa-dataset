

# Generated at 2022-06-25 05:55:34.984590
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Test 'repo_url' is a String
    role_requirement = RoleRequirement()
    repo_url = "git@github.com:example/repo.git"
    assert role_requirement.repo_url_to_role_name(repo_url) == "repo"

    # Test 'repo_url' is another type
    repo_url = (1, 2, 3)
    try:
        role_requirement.repo_url_to_role_name(repo_url)
    except AnsibleError:
        pass
    else:
        raise Exception('AnsibleError not raised when expected')

    # Test exceptions with 'repo_url' is empty String
    repo_url = ""

# Generated at 2022-06-25 05:55:43.523125
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Testcase 1
    role = 'example.com/myrole'
    expected = {'name': 'myrole', 'src': 'example.com/myrole', 'scm': None, 'version': None}
    actual = RoleRequirement.role_yaml_parse(role)
    assert expected == actual

    # Testcase 2
    role = 'example.com/myrole,v0.1'
    expected = {'name': 'myrole', 'src': 'example.com/myrole', 'scm': None, 'version': 'v0.1'}
    actual = RoleRequirement.role_yaml_parse(role)
    assert expected == actual

    # Testcase 3
    role = 'example.com/myrole,v0.1,myrole'

# Generated at 2022-06-25 05:55:48.465555
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    test_cases = ["http://git.example.com/repos/repo.git", "git@git.example.com:repos/repo.git"]
    expected_results = ["repo", "repo"]
    actual_results = []
    for test_case in test_cases:
        actual_results.append(role_requirement_0.repo_url_to_role_name(test_case))
    assert actual_results == expected_results


# Generated at 2022-06-25 05:55:58.172360
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    data = """
---
- src: git+https://github.com/example/example.git

- src: git+https://github.com/example/example.git
  version: 1.0.0

- src: git+https://github.com/example/example.git
  version: ">=2.0.0, <3.0.0"

- src: git+https://github.com/example/example.git
  version: v2.0.0

- src: git+https://github.com/example/example.git
  name: customRole_name
"""

# Generated at 2022-06-25 05:56:00.465010
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse("role_name[,version[,name]]")


# Generated at 2022-06-25 05:56:02.988353
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Input validation
    if (type(role_requirement_0.repo_url_to_role_name("repo")) is not str):
        raise AssertionError("Output type should be str")


# Generated at 2022-06-25 05:56:09.279753
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print("\n")
    print("| Testing RoleRequirement_role_yaml_parse ")
    print("| ======================================")
    
    role_requirement_0 = RoleRequirement()
    
    #Testing cases of roles with normal 'scm' and 'src'
    print("\n")
    print("| Testing cases of roles with normal 'scm' and 'src'")
    print("| =================================================")
    role = role_requirement_0.role_yaml_parse('scm:https://github.com/author/repo,version,role_name')
    assert role['scm'] == 'https'
    assert role['src'] == '//github.com/author/repo'
    assert role['version'] == 'version'
    assert role['name'] == 'role_name'

    #Testing

# Generated at 2022-06-25 05:56:17.592903
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse(role='http://git.example.com/repos/repo.git')
    role_requirement_0.role_yaml_parse(role='http://git.example.com/repos/repo.git,v0.0.1')
    role_requirement_0.role_yaml_parse(role='http://git.example.com/repos/repo.git,v0.0.1,my_custom_name')
    role_requirement_0.role_yaml_parse(role='http://git.example.com/repos/repo')

# Generated at 2022-06-25 05:56:27.450338
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse({'role': 'geerlingguy.git', 'version': '1.0.0'}) == {'version': '1.0.0', 'name': 'geerlingguy.git', 'src': None, 'scm': None}
    assert role_requirement.role_yaml_parse('geerlingguy.git') == {'version': '', 'name': 'geerlingguy.git', 'src': 'geerlingguy.git', 'scm': None}

# Generated at 2022-06-25 05:56:38.105584
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()

    role_0 = {
        'foo': '1',
        'bar': '2',
        'baz': '3',
        'src': 'git+https://github.com/ansible/ansible-modules-core.git,devel,ansible.modules_core',
    }
    expected = {
        'bar': '2',
        'baz': '3',
        'name': 'ansible.modules_core',
        'scm': 'git',
        'src': 'https://github.com/ansible/ansible-modules-core.git,devel',
        'version': '',
    }
    actual = role_requirement_0.role_yaml_parse(role_0)

# Generated at 2022-06-25 05:56:59.903514
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_requirement_2 = RoleRequirement()
    role_requirement_3 = RoleRequirement()
    role_requirement_4 = RoleRequirement()
    role_requirement_5 = RoleRequirement()
    role_requirement_6 = RoleRequirement()
    role_requirement_7 = RoleRequirement()
    role_requirement_8 = RoleRequirement()
    role_requirement_9 = RoleRequirement()

    # Check type of role_requirement_1.role_yaml_parse()
    assert isinstance(role_requirement_1.role_yaml_parse(src="https://github.com/pearsontechnology/ansible-role-elk.git,1.0"), dict)

    # Check values of dict returned by role_yaml_parse

# Generated at 2022-06-25 05:57:09.138772
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test meta/main.yml
    role = {'role': 'geerlingguy.redis'}
    expected = {'src': 'https://github.com/geerlingguy/ansible-role-redis.git', 'name': 'geerlingguy.redis', 'scm': 'git', 'version': ''}
    result = RoleRequirement.role_yaml_parse(role)
    assert expected == result, "Expected: "+str(expected)+" but got: "+str(result)

    # Test meta/main.yml
    role = {'role': 'geerlingguy.redis,v0.3.3'}

# Generated at 2022-06-25 05:57:17.809754
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """
    Tests the role_yaml_parse method of class RoleRequirement
    """
    test_role_0 = RoleRequirement()
    role_0 = test_role_0.role_yaml_parse('geerlingguy.nginx,1.9.4')
    print(role_0['name'])
    print(role_0['version'])
    print(role_0['scm'])
    print(role_0['src'])
    assert role_0['name'] == 'geerlingguy.nginx'
    assert role_0['version'] == '1.9.4'
    print('')

    test_role_1 = RoleRequirement()

# Generated at 2022-06-25 05:57:27.078050
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 05:57:30.424643
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_str = ''
    role_1 = role_requirement_0.role_yaml_parse(role_str)
    print(role_1)



# Generated at 2022-06-25 05:57:33.770097
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    #assert role_requirement_0.role_yaml_parse() == ''
    pass


# Generated at 2022-06-25 05:57:40.762999
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()

    # Testing valid input
    assert "name" in role_requirement_1.role_yaml_parse({u'role': u'deps,1.2.3,name'})
    assert "src" in role_requirement_1.role_yaml_parse({u'role': u'deps,1.2.3,name'})
    assert "scm" in role_requirement_1.role_yaml_parse({u'role': u'deps,1.2.3,name'})
    assert "version" in role_requirement_1.role_yaml_parse({u'role': u'deps,1.2.3,name'})

# Generated at 2022-06-25 05:57:46.756989
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_1 = RoleRequirement()
    x = 'puppetlabs.postgresql'
    y = dict(name = 'puppetlabs.postgresql')
    assert role_requirement_0.role_yaml_parse(x) == y, 'x: "%s", y: "%s"' % (str(role_requirement_0.role_yaml_parse(x)), str(y))


# Generated at 2022-06-25 05:57:56.143831
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_1 = RoleRequirement()

    # test with string
    input_string = "geerlingguy.mysql,1.0.0,webserver"
    role_yaml = role_requirement_1.role_yaml_parse(input_string)

    assert role_yaml['name'] == 'webserver'
    assert role_yaml['scm'] == None
    assert role_yaml['src'] == 'geerlingguy.mysql'
    assert role_yaml['version'] == '1.0.0'

    # test with dict
    input_dict = dict(role="geerlingguy.mysql,1.0.0,webserver")
    role_yaml = role_requirement_1.role_yaml_parse(input_dict)

    assert role_

# Generated at 2022-06-25 05:58:06.482135
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 05:58:18.508357
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # TODO: move testing to test file
    role_requirement_1 = RoleRequirement()
    data = dict(src='https://github.com/geerlingguy/ansible-role-apache.git,v1.8.2')
    assert(role_requirement_1.role_yaml_parse(data) == dict(name='ansible-role-apache', src='https://github.com/geerlingguy/ansible-role-apache.git', scm='git', version='v1.8.2'))

# Generated at 2022-06-25 05:58:22.080720
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    result = role_requirement_0.role_yaml_parse("ansible-galaxy-requirement-1.0")
    assert result['name'] == 'ansible-galaxy-requirement-1.0'
    assert result['version'] == ''
    assert result['src'] == 'ansible-galaxy-requirement-1.0'

    result = role_requirement_0.role_yaml_parse("ansible-galaxy-requirement-1.0,1.9")
    assert result['name'] == 'ansible-galaxy-requirement-1.0'
    assert result['version'] == '1.9'
    assert result['src'] == 'ansible-galaxy-requirement-1.0'


# Generated at 2022-06-25 05:58:30.539526
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()
    # test old-style format
    candidate_0 = {'role': 'someuser.somerole'}
    assert role_requirement_0.role_yaml_parse(candidate_0) == {'name': 'someuser.somerole', 'src': 'someuser.somerole', 'scm': None, 'version': ''}

    # test new-style format
    candidate_1 = {'name': 'someuser.somerole', 'src': 'https://github.com/someuser/somerole.git'}

# Generated at 2022-06-25 05:58:35.390754
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    input_str_1 = "role_name,1.0,old_name"
    role_requirement_1.role_yaml_parse(input_str_1)


# Generated at 2022-06-25 05:58:39.970838
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse("geerlingguy.apache")


# Generated at 2022-06-25 05:58:43.961456
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    repo_url = 'http://git.example.com/repos/repo.git'
    result = role_requirement_0.repo_url_to_role_name(repo_url)
    assert result == 'repo'


# Generated at 2022-06-25 05:58:53.606659
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 05:59:02.237685
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    import json
    try_role_0 = json.loads('{"role": "geerlingguy.jenkins"}')
    assert role_requirement_0.role_yaml_parse(try_role_0) == {'name': 'geerlingguy.jenkins'}
    try_role_1 = json.loads('{"role": "geerlingguy.jenkins,master"}')
    assert role_requirement_0.role_yaml_parse(try_role_1) == {'name': 'geerlingguy.jenkins', 'version': 'master'}
    try_role_2 = json.loads('{"role": "geerlingguy.jenkins,master,different"}')

# Generated at 2022-06-25 05:59:11.806896
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-25 05:59:23.033454
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test with a string
    role_requirement_1 = RoleRequirement()
    role_requirement_1.role_yaml_parse(role='molla.test,v1.0.0')
    print("role_yaml_parse(role='molla.test,v1.0.0')")
    print(role_requirement_1)
    # Test with a dictionary
    role_requirement_2 = RoleRequirement()
    role_requirement_2.role_yaml_parse(role=dict(role='molla.test,v1.0.0'))
    print("role_yaml_parse(role=dict(role='molla.test,v1.0.0'))")
    print(role_requirement_2)
    # Test with a string

# Generated at 2022-06-25 05:59:35.352741
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    rolerequirement = RoleRequirement()
    #with open('q.yml') as f:
    #    rolerequirement.role_yaml_parse(yaml.load(f))
    assert rolerequirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name':'geerlingguy.apache','src':'geerlingguy.apache', 'scm':None, 'version':'1.0.0'}
    assert rolerequirement.role_yaml_parse('geerlingguy.apache') == {'name':'geerlingguy.apache','src':'geerlingguy.apache', 'scm':None, 'version':''}

# Generated at 2022-06-25 05:59:38.420390
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # from ansible.playbook.role.requirement import RoleRequirement
    #
    #
    # role_requirement = RoleRequirement()

    role = "test_user.test_role"
    test_role = RoleRequirement.role_yaml_parse(role)
    print(test_role)


if __name__ == '__main__':
    test_case_0()
    test_RoleRequirement_role_yaml_parse()

# Generated at 2022-06-25 05:59:48.484101
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
	# Test 1: name, src and scm are setted
	role = {"name": "test", "src": "http://foo.bar/test.git", "scm": "git"}
	role_requirement_0 = RoleRequirement()
	role_requirement_0.role_yaml_parse(role)
	assert role_requirement_0.name == "test"
	assert role_requirement_0.src == "http://foo.bar/test.git"
	assert role_requirement_0.scm == "git"
	# Test 2: name is setted
	role = {"name": "test"}
	role_requirement_0.role_yaml_parse(role)
	assert role_requirement_0.name == "test"
	# Test 3: scm and src are setted
	role

# Generated at 2022-06-25 05:59:58.568811
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # """
    # Unit test for method repo_url_to_role_name of class RoleRequirement
    # """
    role_requirement_0 = RoleRequirement()
    a = 'http://git.example.com/repos/repo.git'
    b = 'repo'
    assert role_requirement_0.repo_url_to_role_name(a) == b

    a = 'http://git.example.com/repos/repo.git'
    b = 'repo'
    assert role_requirement_0.repo_url_to_role_name(a) == b

    a = 'repo'
    b = 'repo'
    assert role_requirement_0.repo_url_to_role_name(a) == b


# Generated at 2022-06-25 06:00:09.822106
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement.role_yaml_parse('geerlingguy.ntp')
    assert 'geerlingguy.ntp' == role_requirement_1['name']
    assert None == role_requirement_1["scm"]
    assert None == role_requirement_1["version"]
    assert 'geerlingguy.ntp' == role_requirement_1["src"]

    role_requirement_2 = RoleRequirement.role_yaml_parse('geerlingguy.ntp,1.0.0')
    assert 'geerlingguy.ntp' == role_requirement_2['name']
    assert '1.0.0' == role_requirement_2["version"]
    assert None == role_requirement_2["scm"]

# Generated at 2022-06-25 06:00:20.067879
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    repo_url_1 = "http://git.example.com/repos/repo.git"
    assert role_requirement_1.repo_url_to_role_name(repo_url_1) == "repo"
    repo_url_1 = "https://git.example.com/repos/repo.git"
    assert role_requirement_1.repo_url_to_role_name(repo_url_1) == "repo"
    repo_url_1 = "http://git.example@example.com/repos/repo.git"
    assert role_requirement_1.repo_url_to_role_name(repo_url_1) == "repo"

# Generated at 2022-06-25 06:00:28.261470
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    name = None
    scm = None
    src = None
    version = None

    role_spec_0 = dict(name=None, src=None, scm=None, version=None)
    role_requirement_0 = RoleRequirement()
    role_0 = role_requirement_0.role_yaml_parse("michaelgrace.java,1.8.0_45")
    role_spec_0 = dict(name="michaelgrace.java", version="1.8.0_45", scm=None, src="michaelgrace.java")
    assert role_0 == role_spec_0

    role_spec_0 = dict(name=None, src=None, scm=None, version=None)
    role_requirement_0 = RoleRequirement()
    role_0 = role_requ

# Generated at 2022-06-25 06:00:31.247912
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git+ssh://git@github.com/geerlingguy/ansible-role-apache.git") == "ansible-role-apache"


# Generated at 2022-06-25 06:00:41.214005
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_dict_0 = dict(name='apache', src="https://github.com/geerlingguy/ansible-role-apache,v2.6.0,geerlingguy.apache", scm='git', version='v2.6.0')
    assert role_requirement_0.role_yaml_parse("geerlingguy.apache,v2.6.0,geerlingguy.apache") == role_dict_0
    role_dict_1 = dict(name='apache', src="https://github.com/geerlingguy/ansible-role-apache", scm='git', version='')
    assert role_requirement_0.role_yaml_parse("https://github.com/geerlingguy/ansible-role-apache") == role_

# Generated at 2022-06-25 06:00:52.388647
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    #Input: 'git+https://github.com/foo/roles.git,bar,baz'
    #Expected Output: {'src': 'https://github.com/foo/roles.git', 'scm': 'git', 'name': 'baz', 'version': 'bar'}
    role = {'src': 'git+https://github.com/foo/roles.git,bar,baz'}
    expected = {'scm': 'git', 'name': 'baz', 'src': 'https://github.com/foo/roles.git', 'version': 'bar'}
    results = role_requirement_1.role_yaml_parse(role)
    assert(results == expected)
    #Input: 'https://github.com/foo/

# Generated at 2022-06-25 06:01:07.930421
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # checking case 1:
    role_requirement_0 = RoleRequirement()
    role_yaml_parse_0 = role_requirement_0.role_yaml_parse('example_string')
    assert role_yaml_parse_0 == dict(name='example_string', src='example_string', scm=None, version=''), \
        'Unexpected value: %s' % role_yaml_parse_0
    # checking case 2:
    role_requirement_1 = RoleRequirement()
    role_yaml_parse_1 = role_requirement_1.role_yaml_parse(dict(role='example_dict'))

# Generated at 2022-06-25 06:01:18.561090
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # input_data_0
    role_0 = 'git+https://github.com/jtyr/ansible-zabbix,2.2.1,zabbix'
    # expected_result_0
    expected_result_0 = dict(name='zabbix', scm='git', src='https://github.com/jtyr/ansible-zabbix', version='2.2.1')

    # input_data_1
    role_1 = 'https://github.com/jtyr/ansible-zabbix,2.2.1,zabbix'
    # expected_result_1
    expected_result_1 = dict(name='zabbix', scm=None, src='https://github.com/jtyr/ansible-zabbix', version='2.2.1')

   

# Generated at 2022-06-25 06:01:26.948446
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Test case 1
    role_requirement_1 = RoleRequirement()
    assert role_requirement_1.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'

    # Test case 2
    role_requirement_2 = RoleRequirement()
    assert role_requirement_2.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'

    # Test case 3
    role_requirement_3 = RoleRequirement()
    assert role_requirement_3.repo_url_to_role_name('http://git.example.com/repos/repo,abc') == 'repo'

    # Test case 4

# Generated at 2022-06-25 06:01:30.398042
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse(role_requirement_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 06:01:35.270051
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    # test cases
    # - old
    #    - valid
    #    - invalid
    #  - new
    #    - valid
    #    - invalid

    # test case - old - valid
    old_style_valid_role_requirements = [
        { 'role': 'name' },
        { 'role': 'name,version' },
        { 'role': 'name,version,name' },
    ]
    for role in old_style_valid_role_requirements:
        result = role_requirement.role_yaml_parse(role)
        assert result == dict(name=role['role'], src=None, scm=None, version='')

    # test case - old - invalid

# Generated at 2022-06-25 06:01:43.655132
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement = RoleRequirement()

    res = role_requirement.role_yaml_parse("geerlingguy.mysql")
    assert res == {'name': 'geerlingguy.mysql', 'src': 'geerlingguy.mysql', 'scm': None, 'version': None}

    res = role_requirement.role_yaml_parse("geerlingguy.mysql")
    assert res == {'name': 'geerlingguy.mysql', 'src': 'geerlingguy.mysql', 'scm': None, 'version': None}

    res = role_requirement.role_yaml_parse("geerlingguy.mysql,2.2")

# Generated at 2022-06-25 06:01:54.257265
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    #bogus_role = 'bogus'
    #assert role_requirement_0.role_yaml_parse(bogus_role) == False

    name = None
    version = 1
    src = None
    scm = None
    role = 'role_name,1.1'

    #assert role_requirement_0.role_yaml_parse(role) == ('role_name', '1.1', None, None)

    name = None
    version = 1
    src = None
    scm = None
    role = 'role_name,v1.1'

    #assert role_requirement_0.role_yaml_parse(role) == ('role_name', 'v1.1', None, None)

    name = None
    version = 1
    src = None

# Generated at 2022-06-25 06:02:00.544911
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test case #1 of method role_yaml_parse of class RoleRequirement
    # Test case where a dictionary is passed to the method role_yaml_parse
    expected = {
            'src' : 'geerlingguy.ntp',
            'version' : '2.1.0',
            'name' : 'ntp',
            'scm' : None
            }
    actual = RoleRequirement.role_yaml_parse({'src' : 'geerlingguy.ntp', 'version' : '2.1.0'})
    assert(actual == expected)

    # Test case #2 of method role_yaml_parse of class RoleRequirement
    # Test case where a dictionary does not have any version field

# Generated at 2022-06-25 06:02:05.312297
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Note:
    # This test-case must be updated if function and/or class changes
    # in file galaxy/roles.py.

    import unittest
    try:
        from galaxy.roles import RoleRequirement
    except ImportError:
        print("ERROR: Not able to import module RoleRequirement from galaxy/roles.py.\n" \
              "       Please make sure that the current working directory is the root of the project.\n" \
              "       (e.g.: $ cd <path to project root>)\n" \
              "       ps:\n" \
              "       The file 'galaxy/roles.py' is expected to be in directory 'ansible/lib/galaxy/'.")
        exit(1)


# Generated at 2022-06-25 06:02:12.052997
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()

    role_yaml_parse_0 = role_requirement_0.role_yaml_parse('geerlingguy.jenkins')
    assert role_yaml_parse_0['name'] == 'geerlingguy.jenkins'
    assert role_yaml_parse_0['version'] == ''
    assert role_yaml_parse_0['src'] == 'geerlingguy.jenkins'
    assert role_yaml_parse_0['scm'] is None

    role_yaml_parse_1 = role_requirement_0.role_yaml_parse('geerlingguy.jenkins,v1.2.3')
    assert role_yaml_parse_1['name'] == 'geerlingguy.jenkins'
    assert role_yaml_parse

# Generated at 2022-06-25 06:02:32.245399
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/role-repo.git") == "role-repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/some_role_repo.git") == "some_role_repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/some-role-repo.git") == "some-role-repo"

# Generated at 2022-06-25 06:02:41.277915
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role1 = RoleRequirement.role_yaml_parse("geerlingguy.apache")
    assert role1 == {'name':'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}, "failed role_yaml_parse with role string of 'geerlingguy.apache'"
    role2 = RoleRequirement.role_yaml_parse("geerlingguy.apache,2.2")
    assert role2 == {'name':'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '2.2'}, "failed role_yaml_parse with role string of 'geerlingguy.apache,2.2'"

# Generated at 2022-06-25 06:02:48.132577
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    spec = dict(
        name='some_name',
        version='some_version',
        src='some_src',
        scm='some_scm',
    )
    role_requirement = RoleRequirement()

    got = role_requirement.role_yaml_parse(spec)
    want = spec
    assert got == want



# Generated at 2022-06-25 06:02:55.102460
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    print("--- test_RoleRequirement_repo_url_to_role_name---")

    # Test case for when repo is of type http://git.example.com/repos/repo.git
    test_role_requirement = RoleRequirement()
    repo_url = "http://git.example.com/repos/repo.git"
    role_name = test_role_requirement.repo_url_to_role_name(repo_url)

    assert role_name == "repo"

    # Test case for when repo is of type git@github.com:user/ansible-role-lighttpd.git
    test_role_requirement = RoleRequirement()
    repo_url = "git@github.com:user/ansible-role-lighttpd.git"
    role_name = test

# Generated at 2022-06-25 06:03:01.381373
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 06:03:10.839445
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Testing the mandatory arguments of function
    src_url = "git://github.com/ansible/ansible-examples.git"
    scm = "git"
    name = "ansible-examples"
    version = "HEAD"
    keep_scm_meta = False
    assert RoleRequirement.scm_archive_role(src=src_url, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta) is not None
    src_url = "git+git://github.com/ansible/ansible-examples.git"
    assert RoleRequirement.scm_archive_role(src=src_url, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta) is not None
    src

# Generated at 2022-06-25 06:03:18.031669
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_name_0 = "foobar"
    role_scm_0 = "git"
    role_src_0 = "foobar"
    role_version_0 = "HEAD"
    role_0 = dict(name=role_name_0, scm=role_scm_0, src=role_src_0, version=role_version_0)
    role_1 = role_requirement_0.role_yaml_parse(role_0)
    assert role_1 == role_0


# Generated at 2022-06-25 06:03:23.847064
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    repo_url = 'http://git.example.com/repos/repo.git'
    # Test middle
    expected = 'repo'
    actual = RoleRequirement.repo_url_to_role_name(repo_url)
    assert expected == actual
    # Test if statement
    repo_url = 'git@git.example.com:repos/repo.git'
    expected = 'repo'
    actual = RoleRequirement.repo_url_to_role_name(repo_url)
    assert expected == actual
    # Test return statement
    repo_url = 'git@git.example.com:repos/repo'
    expected = 'repo'

# Generated at 2022-06-25 06:03:26.621712
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    try:
        role_requirement_0.role_yaml_parse('test_value_3')
    except AnsibleError as e:
        assert(str(e) == "Invalid role line (test_value_3). Proper format is 'role_name[,version[,name]]'")

# Generated at 2022-06-25 06:03:31.659493
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = "geerlingguy.jenkins,1.6.0"
    role_requirement = RoleRequirement.role_yaml_parse(role)
    assert role_requirement == dict(name='geerlingguy.jenkins', scm=None, src='geerlingguy.jenkins', version='1.6.0')


# Generated at 2022-06-25 06:04:14.075500
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_1 = RoleRequirement()
    test_role_1 = "src"
    test_role_2 = "scm+src"
    test_role_3 = "src,version"
    test_role_4 = "scm+src,version"
    test_role_5 = "src,version,name"
    test_role_6 = "scm+src,version,name"

    role_requirement_1.role_yaml_parse(test_role_1)
    role_requirement_1.role_yaml_parse(test_role_2)
    role_requirement_1.role_yaml_parse(test_role_3)
    role_requirement_1.role_yaml_parse(test_role_4)
    role_requirement_1.role_y

# Generated at 2022-06-25 06:04:23.520641
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_url_1 = "http://git.example.com/repos/repo.git"
    role_requirement_url_2 = "http://git.example.com/repos/repo.git,v1.0"
    role_requirement_url_3 = "http://git.example.com/repos/repo.git,v1.0,foo"
    role_requirement_url_4 = "http://git.example.com/repos/repo.git,"
    role_requirement_url_5 = "http://git.example.com/repos/repo.git,,"
    role_requirement_url_6 = "http://git.example.com/repos/repo.git,v1.0,v2.0"
    role_requirement_url_

# Generated at 2022-06-25 06:04:27.774025
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name(None) == None
    assert RoleRequirement.repo_url_to_role_name('username.github.com/repos/role/archive/vars/name/main.yml') == 'role'
    assert RoleRequirement.repo_url_to_role_name('username.github.com/repos/role.git') == 'role'
    assert RoleRequirement.repo_url_to_role_name('username.github.com/repos/role.tar.gz') == 'role'
    assert RoleRequirement.repo_url_to_role_name('http://username.github.com/repos/role/archive/vars/name/main.yml') == 'role'
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-25 06:04:37.641465
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("https://github.com/quintagroup/ansible-quintagroup.secrets-1.0.0.git") == 'ansible-quintagroup.secrets-1.0.0'
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == 'repo'
    assert RoleRequirement.repo_url_to_role_name("https://github.com/quintagroup/ansible-quintagroup.secrets-1.0.0.git,version,name") == 'ansible-quintagroup.secrets-1.0.0'


# Generated at 2022-06-25 06:04:42.919557
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"


# Generated at 2022-06-25 06:04:48.921237
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()

    try:
        role_requirement_0.role_yaml_parse(role='http://git.example.com/repos/repo.git,v1.0.0')
        assert False
    except AnsibleError:
        assert True
    #assert False


# Generated at 2022-06-25 06:04:58.362274
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

        role_requirement_0 = RoleRequirement()
        role_0 = {
            'name': 'role_name',
            'src': 'galaxy.role',
            'scm': None,
            'version': '',
        }
        assert role_requirement_0.role_yaml_parse('role_name') == role_0
        role_1 = {
            'name': 'name',
            'src': 'galaxy.role,1.2.3',
            'scm': None,
            'version': '1.2.3',
        }
        assert role_requirement_0.role_yaml_parse('galaxy.role,1.2.3') == role_1

# Generated at 2022-06-25 06:05:06.147911
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    #
    # Testcase 0
    #
    role_requirement_0 = RoleRequirement()
    data_0 = {}
    data_0['name'] = 'test_role'
    data_0['src'] = 'https://github.com/test_user/test_role.git'
    data_0['scm'] = 'git'
    data_0['version'] = 'master'

    role = 'test_role,master,test_role'

    result = role_requirement_0.role_yaml_parse(role)
    assert data_0['name'] == result['name']
    assert data_0['src'] == result['src']
    assert data_0['scm'] == result['scm']
    assert data_0['version'] == result['version']


    #
    # Testcase 1

# Generated at 2022-06-25 06:05:09.674016
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Test with suffix .git
    test_case_1()
    test_case_2()
    test_case_3()
    # Test without suffix .git
    test_case_4()
    test_case_5()
