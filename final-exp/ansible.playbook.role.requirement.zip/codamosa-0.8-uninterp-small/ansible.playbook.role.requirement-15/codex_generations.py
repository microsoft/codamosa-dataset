

# Generated at 2022-06-25 05:55:36.759142
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 05:55:44.623555
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()

    role_yaml_1 = role_requirement_1.role_yaml_parse("nginx,")
    assert role_yaml_1["src"] == "nginx"
    assert role_yaml_1["name"] == "nginx"
    assert role_yaml_1["version"] is None
    assert role_yaml_1["scm"] is None
    assert role_yaml_1["path"] is None

    role_yaml_2 = role_requirement_1.role_yaml_parse("nginx,v1.0")
    assert role_yaml_2["src"] == "nginx"
    assert role_yaml_2["name"] == "nginx"

# Generated at 2022-06-25 05:55:47.126317
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_instance = RoleRequirement()
    assert role_requirement_instance.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'


# Generated at 2022-06-25 05:55:57.300764
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    assert RoleRequirement.repo_url_to_role_name("https://github.com/alice/ansible-hello.git") == "ansible-hello"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/alice/ansible-hello.git,v0.9") == "ansible-hello"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/alice/ansible-hello.git,v0.9,bob") == "bob"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/alice/ansible-hello.git,v0.9,bob,foo") == "bob"
    assert RoleRequirement

# Generated at 2022-06-25 05:56:03.155545
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    dict_1 = dict(name='galaxy.role', src='git+git://git.example.com/repos/repo.git', version='v0.0.0', scm='git')
    dict_0 = role_requirement_1.role_yaml_parse('git+git://git.example.com/repos/repo.git,v0.0.0')
    assert dict_0 == dict_1, 'values do not match'


# Generated at 2022-06-25 05:56:09.370962
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    assert(role_requirement_0.repo_url_to_role_name("https://github.com/user101/ansible-role-rabbitmq.git") == "ansible-role-rabbitmq")
    assert(role_requirement_0.repo_url_to_role_name("ansible-role-rabbitmq") == "ansible-role-rabbitmq")
    assert(role_requirement_0.repo_url_to_role_name("https://github.com/user101/ansible-role-rabbitmq,2.0.0") == "ansible-role-rabbitmq")

# Generated at 2022-06-25 05:56:17.083103
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    test_input = {
        "role": "myrole",
        "src": "git+https://github.com/ansible/ansible-examples.git",
        "other_var": "other value",
    }
    expected = {
        "name": "myrole",
        "src": "https://github.com/ansible/ansible-examples.git",
        "scm": "git",
        "version": "",
    }
    actual = role_requirement.role_yaml_parse(test_input)
    assert actual == expected, "Expected %s, got %s" % (expected, actual)


# Generated at 2022-06-25 05:56:27.098077
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    role_requirement_0 = RoleRequirement()
    #assert role_requirement_0.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role_requirement_0.repo_url_to_role_name("repo") == "repo"
    assert role_requirement_0.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-apache.git") == "ansible-role-apache"
    assert role_requirement_0.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-apache,v1.1.1") == "ansible-role-apache"


# Generated at 2022-06-25 05:56:37.853353
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role = "role_name"
    # Expected:
    expected_1 = {"name":"role_name","scm":None,"src":"role_name","version":None}
    # Actual:
    actual_1 = role_requirement_1.role_yaml_parse(role)
    # Assertion error
    try:
        assert actual_1 == expected_1, "Expected: %s, Actual: %s" % (expected_1, actual_1)
    except:
        print('Test Fail')
    role_requirement_2 = RoleRequirement()
    role = "role_name,version_number"
    # Expected:
    expected_2 = {"name":"role_name","scm":None,"src":"role_name","version":"version_number"}

# Generated at 2022-06-25 05:56:44.482017
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_yaml_parse_ret = role_requirement_0.role_yaml_parse('roles/files')
    assert role_yaml_parse_ret == {'name': 'files', 'scm': None, 'src': 'roles/files', 'version': None}



# Generated at 2022-06-25 05:57:15.994189
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert (RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo')
    assert (RoleRequirement.repo_url_to_role_name('git+http://git.example.com/repos/repo.git') == 'repo')
    assert (RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo') == 'repo')
    assert (RoleRequirement.repo_url_to_role_name('git+http://git.example.com/repos/repo') == 'repo')
    assert (RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,master') == 'repo')

# Generated at 2022-06-25 05:57:25.999318
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirementobj_0 = RoleRequirement()

    # Invoke method with invalid specification
    try:
        role_requirementobj_0.role_yaml_parse(role="ansible-dcos-marathon,0.9.3")
    except AnsibleError as e:
        print(e)
        assert "'role' key not found in role specification" in str(e)
    else:
        raise AssertionError("AnsibleError not raised")

    # Invoke method with valid specification and valid values
    template_dict = dict(
        src="https://galaxy.ansible.com/dcos/dcos-cli.git,0.0.1",
        version="0.0.1"
    )

# Generated at 2022-06-25 05:57:35.431267
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()

    # Old style { role: "http://git.example.com/repos/repo.git,v1,name" }
    role_yaml_0 = "http://git.example.com/repos/repo.git,v1,name"
    expected_0 = {'name': 'name', 'src': 'http://git.example.com/repos/repo.git', 'scm': None, 'version': 'v1'}
    actual_0 = role_requirement_0.role_yaml_parse(role_yaml_0)
    assert expected_0 == actual_0

    # Old style { role: "http://git.example.com/repos/repo.git,v1" }

# Generated at 2022-06-25 05:57:45.994719
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-25 05:57:51.147445
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()

    role_dict_0 = role_requirement_1.role_yaml_parse('rhel_server + git@github.com:santiago/ansible-role-rhel_server.git,1.0.0,foo')
    role_dict_expected = dict(name='foo', src='git@github.com:santiago/ansible-role-rhel_server.git,1.0.0', scm='rhel_server', version='')
    assert role_dict_0 == role_dict_expected, 'Expected different dict from RoleRequirement.role_yaml_parse'


# Generated at 2022-06-25 05:57:54.578795
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Given
    role_requirement = RoleRequirement()
    input_role = 'geerlingguy.ntp'

    # When
    result = role_requirement.role_yaml_parse(input_role)

    # Then
    assert result == {'name': 'geerlingguy.ntp', 'src': 'geerlingguy.ntp', 'scm': None, 'version': ''}

# Generated at 2022-06-25 05:57:57.735307
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    role_requirement_0.repo_url_to_role_name("git@github.com:galaxyproject/biocontainers-galaxy.git")


# Generated at 2022-06-25 05:58:03.232402
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_test = RoleRequirement()

    # Valid test cases

# Generated at 2022-06-25 05:58:09.679113
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    result = role_requirement_0.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    assert result == "repo"


# Generated at 2022-06-25 05:58:11.663746
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # For instance, this test should fail if method repo_url_to_role_name is not implemented properly when the following line is uncommented:
    assert role_requirement_0.repo_url_to_role_name(None) == None


# Generated at 2022-06-25 05:58:27.083403
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = "geerlingguy.java"
    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse(role)


# Generated at 2022-06-25 05:58:37.192392
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()

    role = "bennojoy.nginx"
    name = role_requirement_0.role_yaml_parse(role)
    assert isinstance(name, dict)
    assert name["name"] == "bennojoy.nginx"
    assert name["version"] is None
    assert name["src"] == "bennojoy.nginx"
    assert name["scm"] is None

    role = "bennojoy.nginx,v0.2"
    name = role_requirement_0.role_yaml_parse(role)
    assert isinstance(name, dict)
    assert name["name"] == "bennojoy.nginx"
    assert name["version"] == "v0.2"

# Generated at 2022-06-25 05:58:42.030941
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    role_requirement_1.repo_url_to_role_name('http://git.example.com/repos/repo.git')
    #assert role_requirement_1.repo_url_to_role_name() == 'repo'


# Generated at 2022-06-25 05:58:50.616198
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    test = RoleRequirement()

# Generated at 2022-06-25 05:58:59.407201
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    repo_url = 'http://git.example.com/repos/repo.git'
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert role_name == 'repo'

    repo_url = 'http://git.example.com/repos/repo-name.tar.gz'
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert role_name == 'repo-name'


# Generated at 2022-06-25 05:59:04.219693
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    global assert_equals
    assert_equals(role_requirement_0.repo_url_to_role_name('http://git.example.com/repos/repo.git'), 'repo')


# Generated at 2022-06-25 05:59:09.026283
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    repo_url = "http://git.example.com/repos/repo.git"
    expected_role_name = "repo"
    assert RoleRequirement.repo_url_to_role_name(repo_url) == expected_role_name

# Generated at 2022-06-25 05:59:11.500468
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    assert role_requirement_0.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"


# Generated at 2022-06-25 05:59:16.476791
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    #RoleRequirement.role_yaml_parse(role)
    print ("TODO: RoleRequirement_role_yaml_parse")


# Generated at 2022-06-25 05:59:26.786967
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    display.display(u'testing method role_yaml_parse of class: RoleRequirement')
    display.display(u'TEST START:\n')
    role_requirement_1 = RoleRequirement()
    role_requirement_result_1 = role_requirement_1.role_yaml_parse(u"http://github.com/geerlingguy/ansible-role-composer.git")
    display.display(u'TEST ROLE: http://github.com/geerlingguy/ansible-role-composer.git')
    display.display(role_requirement_result_1)

# Generated at 2022-06-25 05:59:44.871404
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Testing case 0
    # Testing case when role is a string
    role_requirement_0 = RoleRequirement()
    role_0= "role_name[,version[,name]]"
    expected_results_0 = {"name": "role_name", "scm": None, "src": "role_name", "version": None}
    results_0 = role_requirement_0.role_yaml_parse(role_0)
    assert (results_0 == expected_results_0)


# Generated at 2022-06-25 05:59:53.638530
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 05:59:58.267395
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    # Test with arguments
    test_result_0 = RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    assert test_result_0 == "repo"

    # Test branch of if statement with equality comparison of two strings
    test_result_1 = RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git")
    assert test_result_1 == "repo"

    # Test branch of if statement with equality comparison of two strings
    test_result_2 = RoleRequirement.repo_url_to_role_name("https://github.com/user/repo.git")
    assert test_result_2 == "repo"

# Generated at 2022-06-25 06:00:09.467068
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    # Test case 0
    # src: "galaxy.role,version,name"
    role_spec = dict(src="galaxy.role,version,name")
    role = role_requirement.role_yaml_parse(role_spec)
    assert role == dict(name='galaxy.role', src='galaxy.role', scm=None, version='version')

    # Test case 1
    # src: "http://git.example.com/repos/repo.git,version,name"
    role_spec = dict(src="http://git.example.com/repos/repo.git,version,name")
    role = role_requirement.role_yaml_parse(role_spec)

# Generated at 2022-06-25 06:00:19.902255
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    repo_url_0 = 'http://git.example.com/repos/repo.git'
    ret = role_requirement_0.repo_url_to_role_name(repo_url_0)
    assert ret == 'repo'

    repo_url_0 = 'https://github.com/example/repo.git'
    ret = role_requirement_0.repo_url_to_role_name(repo_url_0)
    assert ret == 'repo'

    repo_url_0 = 'http://git.example.com/repos/repo-1.0.tar.gz'
    ret = role_requirement_0.repo_url_to_role_name(repo_url_0)
    assert ret

# Generated at 2022-06-25 06:00:21.922684
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement().repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'


# Generated at 2022-06-25 06:00:30.151393
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    repo_url = "http://git.example.com/repos/repo.git"
    role_name = RoleRequirement.repo_url_to_role_name(repo_url)
    assert role_name == "repo"

    repo_url = "https://git.example.com/repos/repo.git"
    role_name = RoleRequirement.repo_url_to_role_name(repo_url)
    assert role_name == "repo"

    repo_url = "http://git.example.com/repos/repo.tar.gz"
    role_name = RoleRequirement.repo_url_to_role_name(repo_url)
    assert role_name == "repo"


# Generated at 2022-06-25 06:00:40.692305
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()

    # Case 1:
    # Pass a git url
    repo_url = 'https://github.com/me/you.git'
    result = role_requirement_1.repo_url_to_role_name(repo_url)
    assert result == 'you'

    # Case 2:
    # Pass a git url without .git
    repo_url = 'https://github.com/me/you'
    result = role_requirement_1.repo_url_to_role_name(repo_url)
    assert result == 'you'

    # Case 3:
    # Pass a git url with .tar.gz
    repo_url = 'https://github.com/me/you.tar.gz'
    result = role_requirement_1.repo

# Generated at 2022-06-25 06:00:43.468728
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    result = role_requirement_0.repo_url_to_role_name('http://git.example.com/repos/repo.git')
    assert result == 'repo'

# Generated at 2022-06-25 06:00:50.265066
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert  role_requirement.repo_url_to_role_name("http://git.server.com/path/to/role.git") == "role"
    assert  role_requirement.repo_url_to_role_name("git@git.server.com:1234/path/to/role.git") == "role"
    assert  role_requirement.repo_url_to_role_name("role") == "role"


# Generated at 2022-06-25 06:01:08.094531
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print('Test case: RoleRequirement_role_yaml_parse')
    role_requirement_0 = RoleRequirement()
    role_requirement_1 = RoleRequirement()
    role_requirement_2 = RoleRequirement()
    role_requirement_3 = RoleRequirement()
    role_requirement_4 = RoleRequirement()
    role_requirement_4 = RoleRequirement()
    role_requirement_5 = RoleRequirement()

    str_0 = 'dummy'
    str_1 = 'dummy'
    str_2 = 'geerlingguy.java'
    str_3 = 'dummy'
    str_4 = 'geerlingguy.java,2.0.0,foo'
    str_5 = 'dummy'

# Generated at 2022-06-25 06:01:13.964216
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()

    role_0 = role_requirement_0.role_yaml_parse("examples,v1.2.3,foobar")

    assert len(role_0) == 4
    assert 'name' in role_0
    assert role_0['name'] == 'foobar'
    assert 'role' not in role_0
    assert 'scm' in role_0
    assert role_0['scm'] is None
    assert 'src' in role_0
    assert role_0['src'] == 'examples'
    assert 'version' in role_0
    assert role_0['version'] == 'v1.2.3'


# Generated at 2022-06-25 06:01:19.674474
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = 'freeipa.container'

    role_requirement_1 = RoleRequirement.role_yaml_parse(role)

    assert role_requirement_1['name'] == 'container'
    assert role_requirement_1['src']  == 'freeipa.container'
    assert role_requirement_1['scm']  == None
    assert role_requirement_1['version'] == None


# Generated at 2022-06-25 06:01:27.533635
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case where role = a string
    role = "nginx_galaxy_role_name"
    role_requirement = RoleRequirement()
    role_yaml_parse_return = role_requirement.role_yaml_parse(role)
    print("role_yaml_parse_return = " + str(role_yaml_parse_return))
    assert role_yaml_parse_return == {'name': 'nginx_galaxy_role_name', 'src': 'nginx_galaxy_role_name',
                                      'scm': None, 'version': None}

    # Test case where role = a dict
    role = {"role":"nginx_galaxy_role_name"}
    role_requirement = RoleRequirement()
    role_yaml_parse_return = role_requirement.role_yaml

# Generated at 2022-06-25 06:01:30.749938
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    repo_url = ''
    name = role_requirement_0.repo_url_to_role_name(repo_url)
    assert name == ''


# Generated at 2022-06-25 06:01:36.834572
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    test_cases = [
        (
            'https://github.com/foo/bar.git',
            'bar',
        ),
        (
            'git@git.example.com/repos/repo.git',
            'repo',
        ),
    ]

    for (repo_url, result) in test_cases:
        output = role_requirement_0.repo_url_to_role_name(repo_url)
        assert output == result
        print('Success: repo_url_to_role_name of class RoleRequirement')


# Generated at 2022-06-25 06:01:41.091572
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    repo_url = 'http://git.example.com/repos/repo.git'
    assert role_requirement.repo_url_to_role_name(repo_url) == 'repo', 'Failed repo_url_to_role_name for repo_url="http://git.example.com/repos/repo.git"'


# Generated at 2022-06-25 06:01:48.389561
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Define some inputs for test case
    role_requirement_1 = RoleRequirement()
    role_requirement_2 = RoleRequirement()
    role_requirement_3 = RoleRequirement()
    role_requirement_4 = RoleRequirement()
    role_requirement_5 = RoleRequirement()
    role_requirement_6 = RoleRequirement()
    role_requirement_7 = RoleRequirement()
    role_requirement_8 = RoleRequirement()
    role_requirement_9 = RoleRequirement()
    role_requirement_10 = RoleRequirement()
    role_requirement_11 = RoleRequirement()
    role_requirement_12 = RoleRequirement()

    # Execute the method being tested

# Generated at 2022-06-25 06:01:55.445537
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    '''
    The role_yaml_parse method
    '''
    # Initialize a dict with required data
    role_dict = dict()

    # Call the method of the class and check the output
    assert 'name' in role_dict
    assert 'src' in role_dict
    assert 'scm' in role_dict
    assert 'version' in role_dict


# Generated at 2022-06-25 06:02:06.059934
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    print('Test: repo_url_to_role_name')
    print(f'Expected: repo1')
    print(f'Actual: {RepoUrlToRoleName("http://git.example.com/repos/repo1.git")}')
    print(f'Expected: repo2')
    print(f'Actual: {RepoUrlToRoleName("http://git.example.com/repos/repo2.git")}')
    print(f'Expected: repo3')
    print(f'Actual: {RepoUrlToRoleName("http://git.example.com/repos/repo3.tar.gz")}')
    print(f'Expected: repo4')

# Generated at 2022-06-25 06:02:23.185080
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Case 0 - New style, simple
    role_requirement_0 = RoleRequirement()
    name_0 = role_requirement_0.role_yaml_parse({'name': 'nginx', 'src': 'galaxy.role,version,name'})['name']
    assert name_0 == 'nginx'

    # Case 1 - New style - Scm url
    role_requirement_1 = RoleRequirement()
    name_1 = role_requirement_1.role_yaml_parse({'name': 'nginx', 'src': 'https://github.com/galaxy.role'})['name']
    assert name_1 == 'nginx'

    # Case 2 - New style - Scm and name
    role_requirement_2 = RoleRequirement()
    name_2 = role_requirement_2.role

# Generated at 2022-06-25 06:02:29.294479
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    repo_url = "http://git.example.com/repos/repo.git"
    assert "repo"==role_requirement.repo_url_to_role_name(repo_url)


# Generated at 2022-06-25 06:02:41.077751
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role_name = role_requirement.role_yaml_parse("geerlingguy.java")
    print(role_name)
    role_name = role_requirement.role_yaml_parse("geerlingguy.java,1.8")
    print(role_name)
    role_name = role_requirement.role_yaml_parse("geerlingguy.java,1.8,geerlingguy.java")
    print(role_name)
    role_name = role_requirement.role_yaml_parse("geerlingguy.java,geerlingguy.java,1.8")
    print(role_name)
#if __name__ == '__main__':
#    test_RoleRequirement_role_yaml_parse()

# Generated at 2022-06-25 06:02:52.207947
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    # Test case: old style yaml input
    output = role_requirement.role_yaml_parse(role='git+https://github.com/ansible/ansible.git')
    assert (output == {'name': 'ansible', 'version': None, 'scm': 'git', 'src': 'https://github.com/ansible/ansible.git'})

    # Test case: old style yaml input
    output = role_requirement.role_yaml_parse(role='git+https://github.com/ansible/ansible-test.git,v1.0.0')

# Generated at 2022-06-25 06:03:02.255875
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()

    try:
        assert role_requirement_0.role_yaml_parse('geerlingguy.ntp,v1.0,ntp') == dict(name='ntp', src='geerlingguy.ntp', scm=None, version='v1.0')
    except AssertionError:
        display.warning('TestCase 0: Failed')


# Generated at 2022-06-25 06:03:07.167299
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    assert type(RoleRequirement.role_yaml_parse("michael-dehaan,v3.4.0,geerlingguy.jenkins") is dict)

# Generated at 2022-06-25 06:03:14.717388
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    assert isinstance(RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git"), string_types)
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == 'repo'
    assert role_requirement_0.repo_url_to_role_name("https://github.com/patrix/ansible-git.git") == 'ansible-git'
    assert role_requirement_0.repo_url_to_role_name("galaxy.example.com/example/role") == 'role'

# Generated at 2022-06-25 06:03:18.413695
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()

    expected_result_1 = dict(name=None, scm=None, src=None, version=None)
    role_1 = dict(name=None, scm=None, src=None, version=None)
    actual_result_1 = role_requirement_1.role_yaml_parse(role_1)
    assert actual_result_1 == expected_result_1



# Generated at 2022-06-25 06:03:22.494357
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    repo_url = 'http://git.example.com/repos/repo.git'
    try:
        assert(role_requirement.repo_url_to_role_name(repo_url) == 'repo')
    except AssertionError:
        display.error("Test 'test_RoleRequirement_repo_url_to_role_name' failed")

# Generated at 2022-06-25 06:03:26.024445
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Case sensitive
    role_requirement_0 = RoleRequirement()
    r1 = role_requirement_0.role_yaml_parse({'role': 'prodeng.my-role'})
    assert r1 == {'name': 'prodeng.my-role', 'scm': None, 'src': None, 'version': None}
    print('test_RoleRequirement_role_yaml_parse passed!' + '\n')


# Generated at 2022-06-25 06:03:57.552929
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_correct_yml_0 = {
        "role": "git+https://github.com/nand0p/ansible-role-test-project.git,v1.1.1,pvt-test-project-role",
        "role2": "https://github.com/nand0p/ansible-role-test-project.git,v1.1.1,pvt-test-project-role2",
    }
    expected_0 = {
        'name': 'pvt-test-project-role',
        'src': 'https://github.com/nand0p/ansible-role-test-project.git',
        'scm': 'git',
        'version': 'v1.1.1',
    }

# Generated at 2022-06-25 06:04:07.487972
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # testing for valid url
    url = "https://github.com/martinhoefling/ansible-role-docker.git"
    assert RoleRequirement.repo_url_to_role_name(url) == 'ansible-role-docker'
    # testing for wrong url
    url = "github.com/martinhoefling/ansible-role-docker.git"
    assert RoleRequirement.repo_url_to_role_name(url) == 'ansible-role-docker.git'
    # testing for version control
    url = "git+https://github.com/martinhoefling/ansible-role-docker.git,0.1.0"
    assert RoleRequirement.repo_url_to_role_name(url) == 'ansible-role-docker'
    # testing for version control with name

# Generated at 2022-06-25 06:04:14.617287
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    assert (role_requirement_0.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo")


# Generated at 2022-06-25 06:04:21.500590
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    yaml_0 = "geerlingguy.jenkins,1.6.1,geerlingguy-jenkins"
    assert role_requirement_0.role_yaml_parse(yaml_0) == {'src': 'geerlingguy.jenkins', 'version': '1.6.1', 'scm': None, 'name': 'geerlingguy-jenkins'}


# Generated at 2022-06-25 06:04:31.120034
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role_yaml_parse_0 = role_requirement.role_yaml_parse('geerlingguy.ntp')
    role_yaml_parse_1 = role_requirement.role_yaml_parse('geerlingguy.ntp,1.1.1')
    role_yaml_parse_2 = role_requirement.role_yaml_parse('geerlingguy.ntp,1.1.1,my_role_name')
    role_yaml_parse_3 = role_requirement.role_yaml_parse({'role': 'geerlingguy.ntp'})
    role_yaml_parse_4 = role_requirement.role_yaml_parse({'role': 'geerlingguy.ntp,1.1.1'})

# Generated at 2022-06-25 06:04:35.630145
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_1 = 'git+https://github.com/jakubroztocil/cloud,v0.4.3,cloud'
    role_2 = 'jakubroztocil.cloud,v0.4.3,cloud'
    role_3 = 'jakubroztocil.keboola-writer-git@v0.1.0'
    role_4 = 'jakubroztocil.keboola-writer-git,v0.1.0'
    role_s = [role_1, role_2, role_3, role_4]
    role_r = {'name': 'cloud', 'src': 'https://github.com/jakubroztocil/cloud', 'scm': 'git', 'version': 'v0.4.3'}
    role_requ

# Generated at 2022-06-25 06:04:45.454794
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError

    # invalid input
    display.debug(RoleRequirement.role_yaml_parse(None))
    try:
        display.debug(RoleRequirement.role_yaml_parse([]))
    except:
        display.debug("role_yaml_parse raised error as expected")

    # input as string
    role_dict = RoleRequirement.role_yaml_parse('test-role')
    display.debug('{}'.format(role_dict))
    assert role_dict['name'] == 'test-role'
    assert role_dict['src'] == 'test-role'
    assert role_dict['scm'] == None
    assert role_dict['version']

# Generated at 2022-06-25 06:04:51.967206
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    # Single role is given
    role_name = 'common'
    role = role_requirement.role_yaml_parse(role_name)
    assert role['name'] == role_name
    assert role['scm'] == None
    assert role['src'] == role_name

    # Role is given with a version
    role_name = 'common'
    version = 'v1.2.3'
    role = role_requirement.role_yaml_parse(role_name + ',' + version)
    assert role['name'] == role_name
    assert role['scm'] == None
    assert role['src'] == role_name
    assert role['version'] == version

    # Role is given with a non-git SCM backend
    role_name = 'common'
   

# Generated at 2022-06-25 06:04:59.198458
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    inputs = [
        ("https://github.com/myuser/myrole.git", "myrole"),
        ("git@github.com:myuser/myrole.git", "myrole"),
        ("https://github.com/myuser/myrole.git,1.0", "myrole"),
        ("git@github.com:myuser/myrole.git,1.0", "myrole"),
        ("https://github.com/myuser/myrole.git,1.0,myrole", "myrole"),
        ("git@github.com:myuser/myrole.git,1.0,myrole", "myrole"),
        ("myrole", "myrole"),
        ("myrole,1.0", "myrole"),
        ("myrole,1.0,myrole", "myrole"),
        ]

# Generated at 2022-06-25 06:05:07.079021
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role = 'geerlingguy.java'
    role_result = RoleRequirement.role_yaml_parse(role)
    assert role_result['name'] == 'geerlingguy.java'
    assert role_result['src'] == 'geerlingguy.java'

    role = 'geerlingguy.java,1.7'
    role_result = RoleRequirement.role_yaml_parse(role)
    assert role_result['name'] == 'geerlingguy.java'
    assert role_result['src'] == 'geerlingguy.java'
    assert role_result['version'] == '1.7'

    role = 'geerlingguy.java,1.7,new_name'
    role_result = RoleRequirement.role_yaml_parse(role)