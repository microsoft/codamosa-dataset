

# Generated at 2022-06-25 05:55:29.200367
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()

    # Test case for: name:name
    role_yaml_dict = {"name": "name"}
    assert sorted(RoleRequirement.role_yaml_parse(role_yaml_dict)) == sorted(role_yaml_dict)

    # Test case for: name: name
    role_yaml_dict = {"name": " name"}
    assert sorted(RoleRequirement.role_yaml_parse(role_yaml_dict)) == sorted(role_yaml_dict)

    # Test case for: name :name
    role_yaml_dict = {"name": "name"}
    assert sorted(RoleRequirement.role_yaml_parse(role_yaml_dict)) == sorted(role_yaml_dict)

    # Test case for: name: name
    role

# Generated at 2022-06-25 05:55:35.848596
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()

    role_yaml = "example-role,v2.0.0"
    ret = role_requirement_1.role_yaml_parse(role_yaml)
    assert ret == {'name': 'example-role', 'scm': None, 'src': 'example-role', 'version': 'v2.0.0'}

    role_yaml = "example-role,v2.0.0,myrole"
    ret = role_requirement_1.role_yaml_parse(role_yaml)
    assert ret == {'name': 'myrole', 'scm': None, 'src': 'example-role', 'version': 'v2.0.0'}

    role_yaml = "example-role"
    ret = role_requirement_

# Generated at 2022-06-25 05:55:45.126205
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Negative test case for method role_yaml_parse of class RoleRequirement
    # Invalid role line (apache). Proper format is 'role_name[,version[,name]]
    role_requirement = RoleRequirement()
    with pytest.raises(AnsibleError) as excinfo:
        role_requirement.role_yaml_parse('apache')
    assert "Invalid role line" in str(excinfo.value)
    # Negative test case for method role_yaml_parse of class RoleRequirement
    # Invalid role line (apache, 1.0). Proper format is 'role_name[,version[,name]]
    role_requirement = RoleRequirement()
    with pytest.raises(AnsibleError) as excinfo:
        role_requirement.role_yaml_parse('apache, 1.0')
   

# Generated at 2022-06-25 05:55:55.862605
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    assert role_requirement_0.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement_0.repo_url_to_role_name('http://git.example.com/repos/role.git') == 'role'
    assert role_requirement_0.repo_url_to_role_name('http://git.example.com/repos/role_name.git') == 'role_name'
    assert role_requirement_0.repo_url_to_role_name('http://git.example.com/repos/ansible-role-role-name.git') == 'ansible-role-role-name'
    assert role_requirement

# Generated at 2022-06-25 05:56:04.365466
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    # Test case 1
    role = {
        'src': 'https://github.com/geerlingguy/ansible-role-apache',
        'name': 'geerlingguy.apache',
        'scm': 'git',
        'version': 'v1.1.1'
    }
    result = role_requirement.role_yaml_parse(role)
    assert result == role

    # Test case 2
    role = {
        'role': 'https://github.com/geerlingguy/ansible-role-apache',
        'scm': 'git',
        'version': 'v1.1.1'
    }
    result = role_requirement.role_yaml_parse(role)

# Generated at 2022-06-25 05:56:11.552805
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role = {'name': 'ansible.galaxy_role', 'role': 'ansible.galaxy_role', 'version': None}
    assert role_requirement_0.role_yaml_parse(role) == {'name': 'ansible.galaxy_role', 'role': 'ansible.galaxy_role', 'version': None}

# Generated at 2022-06-25 05:56:14.209118
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    data = 'ansible-role-foo'
    role = RoleRequirement.role_yaml_parse(data)
    assert role['name'] == 'ansible-role-foo'


# Generated at 2022-06-25 05:56:18.016805
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    requested_role_name = 'geerlingguy.ruby'
    actual_role_name = role_requirement.repo_url_to_role_name(requested_role_name)
    assert actual_role_name == 'geerlingguy.ruby'


# Generated at 2022-06-25 05:56:23.306064
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    result_expected = "repo_name"
    result_obtained = RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo_name.git")
    assert result_obtained == result_expected

# Generated at 2022-06-25 05:56:33.698179
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    # test input: repo_url = 
    # expected result: role_name = "repo"
    role_name = role_requirement.repo_url_to_role_name(repo_url="git@example.com:/repos/repo.git")
    #print(role_name)
    assert (role_name == "repo")

    # test input: repo_url = git@example.com:/repos/repo.tar.gz
    # expected result: role_name = "repo"
    role_name = role_requirement.repo_url_to_role_name(repo_url="git@example.com:/repos/repo.tar.gz")
    #print(role_name)

# Generated at 2022-06-25 05:56:48.832180
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    # test with expected key-value pair (role)
    role = "ansible-role-test"
    assert role_requirement_0.role_yaml_parse(role) == dict(name = "ansible-role-test", src = None, scm = None, version = None)
    # test with expected key-value pair (name, src)
    role = dict(name = "ansible-role-test", src = "ansible-role-test_0.1.0.tar.gz", scm = None, version = None)

# Generated at 2022-06-25 05:56:59.383528
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = dict(role = 'yaml_parse')
    assert RoleRequirement.role_yaml_parse(role) == dict(role = 'yaml_parse', name = 'yaml_parse', version = '')

    role = dict(role = 'yaml_parse,version=0')
    assert RoleRequirement.role_yaml_parse(role) == dict(role = 'yaml_parse,version=0', name = 'yaml_parse', version = '0')

    role = dict(role = 'yaml_parse,version=0,name=myName')
    assert RoleRequirement.role_yaml_parse(role) == dict(role = 'yaml_parse,version=0,name=myName', name = 'myName', version = '0')


# Generated at 2022-06-25 05:57:08.841427
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    assert role_requirement_1.role_yaml_parse(role="git+https://github.com/cadre1/ansible-role-firewall.git") == {'scm': 'git', 'name': 'ansible-role-firewall', 'src': 'https://github.com/cadre1/ansible-role-firewall.git', 'version': ''}
    assert role_requirement_1.role_yaml_parse(role="https://github.com/cadre1/ansible-role-firewall.git") == {'scm': None, 'name': 'ansible-role-firewall', 'src': 'https://github.com/cadre1/ansible-role-firewall.git', 'version': ''}
    assert role

# Generated at 2022-06-25 05:57:12.452886
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml_parse_0 = RoleRequirement()
    role_dict_0 = dict()

    try:
        role_yaml_parse_0.role_yaml_parse(role_dict_0)
    except AnsibleError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 05:57:16.569633
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()
    # Test with a string
    role_name_0 = 'role_name[,version[,name]]'
    role_0 = role_requirement_0.role_yaml_parse(role_name_0)
    assert role_0['name'] == 'repo'
    assert role_0['version'] == ''
    assert role_0['scm'] == None

    # Test with a dictionary
    role_1 = role_requirement_0.role_yaml_parse({'role': 'role_name[,version[,name]]'})
    assert role_1['name'] == 'repo'
    assert role_1['version'] == ''
    assert role_1['scm'] == None


# Generated at 2022-06-25 05:57:21.518384
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    assert role_requirement_0.repo_url_to_role_name('https://github.com/robertdebock/ansible-role-ntp') == 'ansible-role-ntp'


# Generated at 2022-06-25 05:57:29.328687
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_1 = RoleRequirement()
    # simple role
    role_string_0 = "geerlingguy.java"
    role_dict_0 = dict(name="geerlingguy.java",
                       src="https://github.com/geerlingguy/ansible-role-java.git",
                       version="")
    assert role_requirement_1.role_yaml_parse(role_string_0) == role_dict_0, \
        "The 'test_RoleRequirement_role_yaml_parse' method has an error."

    role_requirement_2 = RoleRequirement()
    role_string_1 = "geerlingguy.java,2.0.1"

# Generated at 2022-06-25 05:57:39.418636
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    role = 'name'
    spec = role_requirement.role_yaml_parse(role)
    assert spec['name'] == 'name'
    assert spec['scm'] is None
    assert spec['src'] is None
    assert spec['version'] is None


    role = 'name,master,new_name'
    spec = role_requirement.role_yaml_parse(role)
    assert spec['name'] == 'new_name'
    assert spec['scm'] is None
    assert spec['src'] == 'name'
    assert spec['version'] == 'master'


    role = 'name,tag_1_2,new_name'
    spec = role_requirement.role_yaml_parse(role)

# Generated at 2022-06-25 05:57:51.460500
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_requirement_2 = RoleRequirement()
    role_requirement_3 = RoleRequirement()
    role_requirement_4 = RoleRequirement()
    role_requirement_5 = RoleRequirement()
    role_requirement_6 = RoleRequirement()
#    role_requirement_7 = RoleRequirement()
    role_requirement_8 = RoleRequirement()
    role_requirement_9 = RoleRequirement()
    role_requirement_10 = RoleRequirement()
    role_requirement_11 = RoleRequirement()
    role_requirement_12 = RoleRequirement()
    role_requirement_13 = RoleRequirement()
    role_requirement_14 = RoleRequirement()
    role_requirement_15 = RoleRequirement()
    role_

# Generated at 2022-06-25 05:57:56.121137
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Initialize an instance of class RoleRequirement
    role_requirement_0 = RoleRequirement()

    # Testing case where role is a string type
    role = 'geerlingguy.jenkins,1.0.5,geerlingguy-jenkins'
    role_requirement_0.role_yaml_parse(role)

    # Testing case where role is of type dict
    role = {'role': 'geerlingguy.apache', 'other_vars': '"here"'}
    role_requirement_0.role_yaml_parse(role)



# Generated at 2022-06-25 05:58:08.478824
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # test for case: { src: 'galaxy.role,version,name', other_vars: "here" }
    role_requirement_1 = RoleRequirement()
    result = role_requirement_1.role_yaml_parse({'role': 'galaxy.role,version,name', 'other_vars': "here"})
    print(result)

    result_1 = role_requirement_1.role_yaml_parse('galaxy.role,version,name')
    print(result_1)

    # test for case: { src: 'git+http://git.example.com/repos/galaxy.role', other_vars: "here" }
    role_requirement_2 = RoleRequirement()

# Generated at 2022-06-25 05:58:13.517746
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role = 'apache,2.4.7'
    try:
        role_requirement_0.role_yaml_parse(role)
    except AnsibleError as ansible_error:
        if ansible_error.message != "Invalid role line (apache,2.4.7). Proper format is 'role_name[,version[,name]]'":
            raise Exception('InvalidErrorMessage')
    else:
        role_requirement_0 = RoleRequirement()
        role = 'https://github.com/geerlingguy/ansible-role-apache.git,v1.8,geerlingguy.apache'

# Generated at 2022-06-25 05:58:18.190250
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_yaml_parse_str_0 = 'role[,version[,name]]'
    role_yaml_parse_dict_1 = dict(name=None, role=None, scm=None, src=None, version=None)
    role_yaml_parse_dict_1.update(dict(name='role[,version[,name]]', scm=None, src='role[,version[,name]]', version=None))
    assert role_requirement_0.role_yaml_parse(role_yaml_parse_str_0) == role_yaml_parse_dict_1
    role_yaml_parse_str_1 = 'role,version[,name]'

# Generated at 2022-06-25 05:58:27.350250
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    # Test case 0
    role_0 = "geerlingguy.git"
    result_0 = role_requirement_1.role_yaml_parse(role_0)
    assert result_0 == {
      "src": "geerlingguy.git",
      "name": "geerlingguy.git",
      "scm": "git",
      "version": ""
    }
    # Test case 1
    role_1 = "geerlingguy.git,v2.0.0"
    result_1 = role_requirement_1.role_yaml_parse(role_1)

# Generated at 2022-06-25 05:58:31.768651
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    testcase = {'a': 'b', 'c': 'd'}
    result = RoleRequirement.role_yaml_parse(testcase)
    expected = {'a': 'b', 'c': 'd'}
    assert result == expected


# Generated at 2022-06-25 05:58:39.844196
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()

    # Case 1:
    # Empty string
    test_role_1 = ""
    result_role_0 = role_requirement_0.role_yaml_parse(test_role_1)
    assert result_role_0 == {'name': None, 'src': None, 'scm': None, 'version': None}

    # Case 2:
    # String with different format
    test_role_2 = "git+https://github.com/geerlingguy/ansible-role-jenkins.git,v1.0.10"
    result_role_0 = role_requirement_0.role_yaml_parse(test_role_2)

# Generated at 2022-06-25 05:58:48.725826
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Get a test string
    test_string_0 = 'boto_user,v1.0,test'
    # Get a RoleRequirement class
    role_requirement_0 = RoleRequirement()

    # Call the role_yaml_parse method of class RoleRequirement using
    # the test string, and print the output
    role_dict = role_requirement_0.role_yaml_parse(
        test_string_0
    )
    print(role_dict)
    # Verify the output of method role_yaml_parse of class RoleRequirement
    assert role_dict["name"] == 'test'
    assert role_dict["src"] == 'boto_user'
    assert role_dict["version"] == 'v1.0'
    assert role_dict["scm"] == None


# Generated at 2022-06-25 05:59:00.107149
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()

    # Test case 1:
    role = "galaxy.role"
    result1 = role_requirement_1.role_yaml_parse(role)
    assert result1 == {'name': 'role', 'src': 'galaxy.role', 'scm': None, 'version': ''}

    # Test case 2:
    role = "galaxy.role,v1.0"
    result2 = role_requirement_1.role_yaml_parse(role)
    assert result2 == {'name': 'role', 'src': 'galaxy.role', 'scm': None, 'version': 'v1.0'}

    # Test case 3:
    role = "git+git://git.example.com/repos/repo.git"

# Generated at 2022-06-25 05:59:11.108265
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_0 = 'allan'
    assert isinstance(role_requirement_1.role_yaml_parse(role_0), dict)
    assert role_requirement_1.role_yaml_parse(role_0) == {"name": "allan", "src": "allan", "scm": None, "version": None}
    role_1 = 'allan,v1.0.0'
    assert isinstance(role_requirement_1.role_yaml_parse(role_1), dict)
    assert role_requirement_1.role_yaml_parse(role_1) == {"name": "allan", "src": "allan", "scm": None, "version": "v1.0.0"}


# Generated at 2022-06-25 05:59:22.982812
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # build a dict containing the following data
    #{'name':'apache',
    #'role':'geerlingguy.apache',
    #'tasks':['main.yml', 'other.yml'],
    #'handlers':['main.yml'],
    #'vars':'vars.yml',
    #'defaults':'defaults/main.yml',
    #'meta':'meta/main.yml',
    #'files':'files/',
    #'templates':'templates/',
    #'description':'description',
    #'notes':'note',
    #'dependencies':[['some_role','some_version'],['some_other_role','some_other_version']]}
    role = dict()

# Generated at 2022-06-25 05:59:29.546234
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse(role=None)


# Generated at 2022-06-25 05:59:36.987218
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # setup
    role = dict(name='foo', src='git+http://git.example.com/repos/foo.git', version='1.2')
    role_requirement_01 = RoleRequirement()

    result = role_requirement_01.role_yaml_parse(role)
    assert result == dict(name='foo', src='git+http://git.example.com/repos/foo.git', scm='git', version='1.2')

    # setup
    role = dict()
    role['role'] = 'foo'
    role['vars'] = dict(url='git+http://git.example.com/repos/foo.git')
    role['version'] = '1.2'
    role_requirement_02 = RoleRequirement()

    result = role_requirement_02.role_

# Generated at 2022-06-25 05:59:48.393220
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_role_req = RoleRequirement()
    assert test_role_req.role_yaml_parse('geerlingguy.java,1.7.0') == {'name':'geerlingguy.java','version':'1.7.0','scm': None,'src':None}
    assert test_role_req.role_yaml_parse('geerlingguy.java,1.7.0,java') == {'name':'java','version':'1.7.0','scm': None,'src':None}
    assert test_role_req.role_yaml_parse({'role':'geerlingguy.java,1.7.0,java'}) == {'name':'java','version':'1.7.0','scm': None,'src':None}

# Generated at 2022-06-25 05:59:58.569574
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 06:00:08.214115
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert(RoleRequirement.role_yaml_parse('name,version,galaxy_name') == {'name': 'galaxy_name', 'scm': None, 'src': 'name', 'version': 'version'})
    assert(RoleRequirement.role_yaml_parse('name,version') == {'name': 'name', 'scm': None, 'src': 'name', 'version': 'version'})
    assert(RoleRequirement.role_yaml_parse('name') == {'name': 'name', 'scm': None, 'src': 'name', 'version': None})


# Generated at 2022-06-25 06:00:16.193913
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case with no name, version, scm or src passed
    role = {
        'role': 'test',
    }
    test_res = RoleRequirement.role_yaml_parse(role)
    expected_res = {
        'name': 'test',
        'src': 'test',
        'scm': None,
        'version': '',
    }
    assert test_res == expected_res, 'Actual: %s. Expected: %s' % (test_res, expected_res)

    # Test case with no version, scm or src passed
    role = {
        'role': 'test',
        'name': 'test_role',
    }
    test_res = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-25 06:00:27.852930
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()

    assert role_requirement_0.role_yaml_parse("amivitale.redis") == {'name': 'redis', 'version': None, 'scm': None, 'src': 'amivitale.redis'}
    assert role_requirement_0.role_yaml_parse("amivitale.redis,1.0") == {'name': 'redis', 'version': '1.0', 'scm': None, 'src': 'amivitale.redis'}

# Generated at 2022-06-25 06:00:35.074531
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Testing new style req: { src: 'galaxy.role,version,name', other_vars: "here" }
    role = dict(src='github.com/geerlingguy/ansible-role-nginx,v1.9.2,geerlingguy.nginx')
    role_requirement_1 = RoleRequirement()

# Generated at 2022-06-25 06:00:44.096742
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1
    role_requirement_1 = RoleRequirement()
    role_yaml_parse_1_result = role_requirement_1.role_yaml_parse(role='geerlingguy.git,1.3.3,name=geerlingguy.git')
    assert role_yaml_parse_1_result == {'name': 'geerlingguy.git', 'src': 'geerlingguy.git', 'scm': None, 'version': '1.3.3'}
    # Test case 2
    role_requirement_2 = RoleRequirement()
    role_yaml_parse_2_result = role_requirement_2.role_yaml_parse(role='geerlingguy.repo_git')

# Generated at 2022-06-25 06:00:45.046453
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 06:00:55.147143
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    display.display("TEST: role_yaml_parse")

    role_requirement = RoleRequirement()

    # Test invalid role line
    try:
        role_requirement.role_yaml_parse('role_name,bad_version')
        assert False, "role_yaml_parse did not throw expected error"
    except AssertionError as e:
        raise e
    except Exception as e:
        if not isinstance(e, AnsibleError):
            raise e

    # Test valid role line with single quotes
    role_test_1 = role_requirement.role_yaml_parse("galaxy.role,1.1.1,role_name")
    assert role_test_1['name'] == 'role_name'
    assert role_test_1['version'] == '1.1.1'

# Generated at 2022-06-25 06:01:06.107491
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    # test "Name must be present"
    try:
        role_requirement_1.role_yaml_parse(
            {
                "a_key": "a_val",
                "another_key": "another_val",
            }
        )
    except AnsibleError as err:
        assert err.message == "Name must be present", err.message
    else:
        raise AssertionError('Expected `AnsibleError` exception')
    # test "Invalid role line (my_role). Proper format is 'role_name[,version[,name]]'"

# Generated at 2022-06-25 06:01:11.003098
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 06:01:18.757888
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    '''
    verify role_yaml_parse of class RoleRequirement
    '''
    role_requirement_1 = RoleRequirement()
    input_1 = "../"
    expected_1 = {'name': '../', 'role': None, 'scm': None, 'src': None, 'version': None}
    assert role_requirement_1.role_yaml_parse(input_1) == expected_1
    input_2 = "git+http://github.com/cliffano/ansible-cmdb.git"
    expected_2 = {'name': 'ansible-cmdb', 'role': None, 'scm': 'git', 'src': 'http://github.com/cliffano/ansible-cmdb.git', 'version': None}
    assert role_requirement_1.role_yaml

# Generated at 2022-06-25 06:01:23.470502
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Valid tests
    role_requirement_0 = RoleRequirement()
    role_yaml_parse_0_result = role_requirement_0.role_yaml_parse("galaxy")
    assert role_yaml_parse_0_result['name'] == "galaxy"
    assert role_yaml_parse_0_result['src'] == "galaxy"
    assert role_yaml_parse_0_result['scm'] == None
    assert role_yaml_parse_0_result['version'] == ""

    # Invalid tests
    # Test Case 1
    # Test Case 2

# Generated at 2022-06-25 06:01:34.203761
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 06:01:43.590218
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_1 = RoleRequirement()

    role_requirement_1.role_yaml_parse("git+https://github.com/michaelkatz03/fire.ansible.git")
    role_requirement_1.role_yaml_parse("https://github.com/michaelkatz03/fire.ansible.git")
    role_requirement_1.role_yaml_parse("git@github.com:michaelkatz03/fire.ansible.git")
    role_requirement_1.role_yaml_parse("git@github.com:michaelkatz03/fire.ansible.git,v0.0.1")

# Generated at 2022-06-25 06:01:47.035718
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role = 'role_name,version,name'
    expected = dict(name='name', src='role_name', scm=None, version='version')
    actual = role_requirement.role_yaml_parse(role)
    assert expected == actual


# Generated at 2022-06-25 06:01:53.366752
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role = role_requirement_1.role_yaml_parse("git+https://github.com/jhaals/ansible-role-foo.git,v0.0.1,jhaals.ansible-role-foo")
    assert role["name"] == "jhaals.ansible-role-foo"
    assert role["src"] == "https://github.com/jhaals/ansible-role-foo.git"
    assert role["scm"] == "git"
    assert role["version"] == "v0.0.1"


# Generated at 2022-06-25 06:01:59.833680
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_1 = RoleRequirement()

    result0 = role_requirement_0.role_yaml_parse("git+https://github.com/geerlingguy/ansible-role-apache,v1.0.1")
    result1 = role_requirement_1.role_yaml_parse("https://github.com/geerlingguy/ansible-role-apache")
    assert result0['name'] == 'ansible-role-apache'
    assert result0['scm'] == 'git'
    assert result0['src'] == 'https://github.com/geerlingguy/ansible-role-apache'
    assert result0['version'] == 'v1.0.1'

# Generated at 2022-06-25 06:02:18.081013
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    test_role_0 = role_requirement_0.role_yaml_parse("apache")
    assert 'name' in test_role_0
    assert test_role_0['name'] == "apache"
    assert 'scm' in test_role_0
    assert test_role_0['scm'] == None
    assert 'src' in test_role_0
    assert test_role_0['src'] == "apache"
    assert 'version' in test_role_0
    assert test_role_0['version'] == None
    test_role_1 = role_requirement_0.role_yaml_parse("apache,2.4")
    assert test_role_1['name'] == "apache"
    assert test_role_1['scm'] == None

# Generated at 2022-06-25 06:02:28.053527
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 06:02:34.118682
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role = 'geerlingguy.java'
    assert role_requirement.role_yaml_parse(role) == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}
    role = 'https://github.com/geerlingguy/ansible-role-java,1.2.3'
    assert role_requirement.role_yaml_parse(role) == {'name': 'geerlingguy.ansible-role-java', 'src': 'https://github.com/geerlingguy/ansible-role-java', 'scm': None, 'version': '1.2.3'}

# Generated at 2022-06-25 06:02:41.957146
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()

    # Test 1
    input_role1 = 'git+https://github.com/hpcloud-mon/ansible-mongodb.git'
    role1 = role_requirement_0.role_yaml_parse(input_role1)
    assert role1['src'] =='https://github.com/hpcloud-mon/ansible-mongodb.git'
    assert role1['scm'] == 'git'
    assert role1['name'] == 'ansible-mongodb'
    assert role1['version'] == ''

    # Test 2
    input_role2 = 'https://github.com/hpcloud-mon/ansible-mongodb.git'
    role2 = role_requirement_0.role_yaml_parse(input_role2)


# Generated at 2022-06-25 06:02:52.295380
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement = RoleRequirement()

    # Test case 0:
    # Test with a string input
    test_case_0_input = 'git://git.example.com/repos/repo.git,branch=development'
    role1 = role_requirement.role_yaml_parse(test_case_0_input)
    print(role1)
    assert role1['scm'] == 'git'
    assert role1['name'] == 'repo'
    assert role1['src'] == 'git://git.example.com/repos/repo.git'
    assert role1['version'] == 'branch=development'

    # Test case 1:
    # Test with a dictionary input

# Generated at 2022-06-25 06:03:02.291564
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse(role='kubernetes_kubelet')
    role_requirement_0.role_yaml_parse(role='geerlingguy.docker')
    role_requirement_0.role_yaml_parse(role='geerlingguy.docker,1.3.0,geerlingguy.docker')
    role_requirement_0.role_yaml_parse(role='https://github.com/geerlingguy/ansible-role-docker,1.3.0')
    role_requirement_0.role_yaml_parse(role='https://github.com/geerlingguy/ansible-role-ansible,1.3.0')
    role_requirement_0.role_y

# Generated at 2022-06-25 06:03:09.356748
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role = dict(name='gitlab', src='git@gitlab.com:someuser/somerepo', version='1.0.1')
    expected = dict(name='gitlab', src='git@gitlab.com:someuser/somerepo', scm='git', version='1.0.1')
    result = role_requirement_0.role_yaml_parse(role)
    assert expected == result


# Generated at 2022-06-25 06:03:14.142746
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_yaml_parse_0 = role_requirement_0.role_yaml_parse('git+https://github.com/jdauphant/ansible-role-nginx')
    assert role_yaml_parse_0['name'] == 'nginx'
    assert role_yaml_parse_0['src'] == 'https://github.com/jdauphant/ansible-role-nginx'
    assert role_yaml_parse_0['scm'] == 'git'
    assert role_yaml_parse_0['version'] == ''


# Generated at 2022-06-25 06:03:19.693958
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse("https://github.com/ansible/ansible-examples.git,v1.0.0,geerlingguy.mysql")
    role_requirement_0.role_yaml_parse("src=https://github.com/ansible/ansible-examples.git,version=v1.0.0,name=geerlingguy.mysql")

    role_requirement_0.role_yaml_parse("https://github.com/ansible/ansible-examples.git,v1.0.0,geerlingguy.mysql,v1.0.9")

    role_requirement_0.role_yaml_parse("geerlingguy.mysql")
    role_requirement

# Generated at 2022-06-25 06:03:25.657440
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    rr = RoleRequirement()

    # given
    m0 = dict(role='geerlingguy.java', version='1.8.0')
    m1 = dict(role='geerlingguy.java,1.8.0')
    m2 = dict(role='git+https://github.com/geerlingguy/ansible-role-java.git,1.8.0')
    m3 = dict(role='git+https://github.com/geerlingguy/ansible-role-java.git,1.8.0,jdoe.java')
    m4 = dict(role='https://github.com/geerlingguy/ansible-role-java.git,1.8.0,jdoe.java')

# Generated at 2022-06-25 06:04:01.289023
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_0 = "hosmi.common"
    result_0 = role_requirement_0.role_yaml_parse( role_0 )
    dict_0 = { "src": "hosmi.common", "name": "hosmi.common", "scm": None, "version": None}
    assert result_0 == dict_0

# Generated at 2022-06-25 06:04:06.344048
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

# Generated at 2022-06-25 06:04:13.668766
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_0.role_yaml_parse(role="rolename,version,foo")
    role_requirement_0.role_yaml_parse(role={"role":"rolename,version,foo"})
    role_requirement_0.role_yaml_parse(role={"src":"rolename,version,foo"})
    role_requirement_0.role_yaml_parse(role={"src":"rolename,version,foo","name":"rolename","version":"version"})
    role_requirement_0.role_yaml_parse(role={"src":"rolename,version,foo","name":"rolename","version":"version","scm":"git"})

# Generated at 2022-06-25 06:04:22.018729
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    display = Display()
    input = "git+git://github.com/geerlingguy/ansible-role-apache.git,v2.0.0"
    expected = dict(name="ansible-role-apache", scm="git", src="git://github.com/geerlingguy/ansible-role-apache.git", version="v2.0.0")
    result = RoleRequirement.role_yaml_parse(input)
    display.display(input, expected, result)
    assert result == expected


# Generated at 2022-06-25 06:04:31.512521
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement_0 = RoleRequirement()

    # Call method role_yaml_parse with role argument set to "galaxy.role,version,name"
    assert role_requirement_0.role_yaml_parse("galaxy.role,version,name") == dict(name='name', src='galaxy.role', scm=None, version='version')
    # Call method role_yaml_parse with role argument set to "galaxy.role"
    assert role_requirement_0.role_yaml_parse("galaxy.role") == dict(name='galaxy.role', src='galaxy.role', scm=None, version='')
    # Call method role_yaml_parse with role argument set to "galaxy.role,version"

# Generated at 2022-06-25 06:04:39.235332
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    value_0 = role_requirement_0.role_yaml_parse('repo.git')
    print('value_0: %s' % value_0)
    assert value_0 == {'version': None, 'name': 'repo', 'scm': None, 'src': 'repo.git'}

    value_1 = role_requirement_0.role_yaml_parse('git@github.com:name1/name2.git')
    print('value_1: %s' % value_1)
    assert value_1 == {'version': None, 'name': 'name2', 'scm': None, 'src': 'git@github.com:name1/name2.git'}

    value_2 = role_requirement_0.role_

# Generated at 2022-06-25 06:04:45.989121
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_spec = dict(name="myrole", version="1.0")
    assert role_requirement_1.role_yaml_parse(role_spec) == dict(name="myrole", src=None, scm=None, version=("1.0"))
    role_spec = dict(role="myrole", version="1.0")
    assert role_requirement_1.role_yaml_parse(role_spec) == dict(name="myrole", src=None, scm=None, version=("1.0"))
    role_spec = dict(role="myrole,1.0")

# Generated at 2022-06-25 06:04:52.442469
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement = RoleRequirement()

    # TestCase 1: call with value of src set to a scm+url
    src = "git+https://github.com/ansible/ansible-examples"
    role = role_requirement.role_yaml_parse(src)
    assert role["src"] == "https://github.com/ansible/ansible-examples"

    # TestCase 2: call with value of url set to a url without a scm
    src = "https://github.com/ansible/ansible-examples"
    role = role_requirement.role_yaml_parse(src)
    assert role["src"] == "https://github.com/ansible/ansible-examples"

    # TestCase 3: call with value of src set to a url with scm and version
    src

# Generated at 2022-06-25 06:04:55.517239
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role = 'galaxy.example.com,v1.2.3,foo'

    expected_result = dict(name='foo', src='galaxy.example.com', scm=None, version='v1.2.3')
    result = role_requirement_0.role_yaml_parse(role=role)
    assert result == expected_result


# Generated at 2022-06-25 06:05:05.057955
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    expected_result = dict(name='geerlingguy.apache', src='https://github.com/geerlingguy/ansible-role-apache.git', scm='git', version=None)
    actual_result = role_requirement.role_yaml_parse('https://github.com/geerlingguy/ansible-role-apache.git')
    assert expected_result == actual_result

    expected_result = dict(name='geerlingguy.apache', src='https://github.com/geerlingguy/ansible-role-apache.git', scm=None, version='1.9.1')