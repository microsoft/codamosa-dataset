

# Generated at 2022-06-25 05:55:31.191416
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    repo_url = "git+https://github.com/cliffano/ansible-wordpress-nginx.git"
    assert role_requirement.repo_url_to_role_name(repo_url) == "ansible-wordpress-nginx"


# Generated at 2022-06-25 05:55:40.443418
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo-2.0.tar.gz') == 'repo-2.0'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo')

# Generated at 2022-06-25 05:55:49.346697
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    # Test failure of first argument of role_yaml_parse()
    assert role_requirement_0.role_yaml_parse(None) is None
    # Test success of second argumnet of role_yaml_parse()
    assert role_requirement_0.role_yaml_parse('galaxy.name[,version[,name]]') is not None
    assert role_requirement_0.role_yaml_parse('galaxy.name[,version[,name]]').get('name','') == 'galaxy.name'
    # Test success of first argument of role_yaml_parse()
    assert role_requirement_0.role_yaml_parse({'role':'galaxy.role'}).get('name','') == 'galaxy.role'


# Generated at 2022-06-25 05:55:57.253655
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    role_requirement_0.repo_url_to_role_name('http://github.com/roles/role.git')
    role_requirement_0.repo_url_to_role_name('https://github.com/roles/role.git')
    role_requirement_0.repo_url_to_role_name('git@github.com/roles/role.git')
    role_requirement_0.repo_url_to_role_name('ssh://github.com/roles/role.git')


# Generated at 2022-06-25 05:56:03.687613
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Test case 0
    # ex. of a valid git repo url: https://github.com/geerlingguy/ansible-role-apache.git
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache.git') == 'ansible-role-apache'
    # ex. of a valid git repo url with a transport prefix (scp)
    assert RoleRequirement.repo_url_to_role_name('/home/user/ansible-role-apache.git') == 'ansible-role-apache'
    # ex. of a valid git repo url with a transport prefix (scp) and version

# Generated at 2022-06-25 05:56:09.372192
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    result = RoleRequirement.role_yaml_parse('test_case_0')
    assert result == {
        'name': 'test_case_0',
        'role': 'test_case_0',
        'scm': None,
        'src': 'test_case_0',
        'version': None
    }


# Generated at 2022-06-25 05:56:18.280155
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    assert role_requirement_0.repo_url_to_role_name("https://github.com/holms/ansible-role-pyenv") == "ansible-role-pyenv"
    assert role_requirement_0.repo_url_to_role_name("https://github.com/holms/ansible-role-pyenv.git") == "ansible-role-pyenv"
    assert role_requirement_0.repo_url_to_role_name("https://github.com/holms/ansible-role-pyenv.tar.gz") == "ansible-role-pyenv"

# Generated at 2022-06-25 05:56:24.373378
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_repo_url_to_role_name = RoleRequirement()
    actual_result = role_requirement_repo_url_to_role_name.repo_url_to_role_name('https://github.com/ansible/galaxy.git')
    assert 'galaxy' == actual_result


# Generated at 2022-06-25 05:56:31.327015
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Create a class RoleRequirement instance
    role_requirement_1 = RoleRequirement()
    # Call method repo_url_to_role_name with role "sample_role"
    assert role_requirement_1.repo_url_to_role_name("sample_role") == "sample_role"


# Generated at 2022-06-25 05:56:37.917834
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Test for valid repo_url
    role_requirement_1 = RoleRequirement()
    assert role_requirement_1.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    # Test for invalid repo_url
    role_requirement_2 = RoleRequirement()
    role_requirement_2.repo_url_to_role_name('repo.git')


# Generated at 2022-06-25 05:57:00.756838
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Invoke method role_yaml_parse of class RoleRequirement
    role_requirement_0 = RoleRequirement()
    role = 'Rackspace.Redis, v1.3.7'
    expected_result = dict(name='Rackspace.Redis', src=None, scm=None, version='v1.3.7')
    actual_result = role_requirement_0.role_yaml_parse(role)
    assert actual_result == expected_result
    role = 'geerlingguy.java'
    expected_result = dict(name='geerlingguy.java', src=None, scm=None, version='')
    actual_result = role_requirement_0.role_yaml_parse(role)
    assert actual_result == expected_result

# Generated at 2022-06-25 05:57:08.291033
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement = RoleRequirement()

    role = role_requirement.role_yaml_parse("role_name,version,name")
    assert role == {'name': 'name', 'scm': None, 'src': 'role_name', 'version': 'version'}

    role = role_requirement.role_yaml_parse("git+https://github.com/user/repo,v1.4,role_name")
    assert role == {'name': 'role_name', 'scm': 'git', 'src': 'https://github.com/user/repo,v1.4', 'version': ''}


# Generated at 2022-06-25 05:57:16.653752
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 05:57:26.779203
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 05:57:35.486076
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert {'name': 'jdauphant.nginx', 'src': 'jdauphant.nginx', 'scm': None, 'version': ''} \
           == RoleRequirement.role_yaml_parse({'role': 'jdauphant.nginx'})

    assert {'name': 'jdauphant.nginx', 'src': 'https://github.com/jdauphant/ansible-role-nginx.git', 'scm': 'git', 'version': ''} \
           == RoleRequirement.role_yaml_parse({'role': 'jdauphant.nginx', 'src': 'https://github.com/jdauphant/ansible-role-nginx.git'})


# Generated at 2022-06-25 05:57:46.042565
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()

    for case in TEST_CASES:
        result = role_requirement_1.role_yaml_parse(case[0])
        assert result == case[1]
        # FIXME: Create an assert method



# Generated at 2022-06-25 05:57:51.196293
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # simple test case
    role_requirement = RoleRequirement()
    print ("\nTest case 0")
    role = "some-user.some-repo,1.2.3,ansible-test-role"
    expect = dict(name="ansible-test-role", src="some-user.some-repo", scm=None, version="1.2.3")
    actual = role_requirement.role_yaml_parse(role)
    assert sorted(actual) == sorted(expect), "Test case 0 failed"

    # simple test case
    print ("\nTest case 1")
    role = "some-user.some-repo,1.2.3"

# Generated at 2022-06-25 05:57:56.515694
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'


# Generated at 2022-06-25 05:58:06.480302
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('my_role') == dict(name='my_role', src='my_role', scm=None, version='')
    assert RoleRequirement.role_yaml_parse('my_role,1.2.3') == dict(name='my_role', src='my_role', scm=None, version='1.2.3')
    assert RoleRequirement.role_yaml_parse('my_role,v1.2.3') == dict(name='my_role', src='my_role', scm=None, version='v1.2.3')

# Generated at 2022-06-25 05:58:12.329201
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()

    #Should be good
    role = role_requirement_0.role_yaml_parse('geerlingguy.jenkins,1.0.0,jenkins')
    assert type(role) == type({})
    assert "name" in role and role["name"] == "jenkins"
    assert "scm" in role and role["scm"] == "git"
    assert "src" in role and role["src"] == "geerlingguy.jenkins"
    assert "version" in role and role["version"] == "1.0.0"

    #Should be bad
    role = role_requirement_0.role_yaml_parse('geerlingguy.jenkins,1.0.0,jenkins,2.0')
    assert type(role) == type

# Generated at 2022-06-25 05:58:35.274924
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    def test1():
        role = "git+https://github.com/jdauphant/ansible-role-nginx,v1.0,jdauphant.nginx"
        result = RoleRequirement.role_yaml_parse(role)
        assert result['name'] == 'jdauphant.nginx'
        assert result['scm'] == 'git'
        assert result['src'] == 'https://github.com/jdauphant/ansible-role-nginx'
        assert result['version'] == 'v1.0'
    test1()


# Generated at 2022-06-25 05:58:46.900045
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-25 05:58:55.717923
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    # Test old style: 'http://git.example.com/repos/repo.git,master'
    role_0 = {
        'role': 'http://git.example.com/repos/repo.git,master',
    }
    role_yaml_parse_0 = role_requirement_0.role_yaml_parse(role_0)

    print(role_yaml_parse_0)
    assert role_yaml_parse_0 == {
        'name': 'repo',
        'scm': None,
        'src': 'http://git.example.com/repos/repo.git',
        'version': 'master',
    }

    # Test old style: 'http://git.example.com/repos/repo.

# Generated at 2022-06-25 05:59:05.208656
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_0 = "common"
    role_requirement_result_0 = role_requirement_0.role_yaml_parse(role_0)
    if role_requirement_result_0 != {'name': 'common', 'scm': None, 'src': None, 'version': None}:
        return 'FAIL'

    role_1 = {"role": "common", "molecule": {"test": {"platforms": [{"name": "instance"}]}}}
    role_requirement_result_1 = role_requirement_0.role_yaml_parse(role_1)

# Generated at 2022-06-25 05:59:15.629538
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    role_requirement = RoleRequirement()

    # 1. git repo format
    repo_url = 'http://git.example.com/repos/repo.git'
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert role_name == 'repo'

    repo_url = 'http://git.example.com/repos/repo.tar.gz'
    role_name = role_requirement.repo_url_to_role_name(repo_url)
    assert role_name == 'repo'

    repo_url = 'http://git.example.com/repos/repo'
    role_name = role_requirement.repo_url_to_role_name(repo_url)

# Generated at 2022-06-25 05:59:26.737932
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    src = 'galaxy.role,version,name'
    src_1 = 'git+galaxy.role,version,name'
    src_2 = 'galaxy.role'
    src_3 = 'git+galaxy.role'
    src_4 = 'git+galaxy.role,version'
    src_5 = 'git+galaxy.role,version,name'
    src_6 = 'https://github.com/ansible/ansible-galaxy.git,v2.5.0,ansible-galaxy'
    src_7 = 'https://github.com/ansible/ansible-galaxy,v2.5.0,ansible-galaxy'

# Generated at 2022-06-25 05:59:32.707200
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role_yaml_parse_data = {
        'role': 'role1',
        'name': 'role1',
        'src': 'role1',
        'scm': None,
        'version': ''
    }
    role_yaml_parse_data_1 = role_requirement.role_yaml_parse('role1')
    assert role_yaml_parse_data_1 == role_yaml_parse_data


# Generated at 2022-06-25 05:59:38.364093
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    test_case_0 = "test_case_0"
    test_case_0 = "new_style"
    # tests with the new yaml format
    test_case_0_result = {'version': 'webservers', 'name': 'git+https://github.com/geerlingguy/ansible-role-apache.git'}
    assert role_requirement.role_yaml_parse(test_case_0) == test_case_0_result

    # tests with the old yaml format
    test_case_1_result = {'version': 'webservers', 'name': 'git+https://github.com/geerlingguy/ansible-role-apache.git'}
    test_case_1 = "old_style"
    assert role_

# Generated at 2022-06-25 05:59:46.813997
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    test_cases = [
        ("https://github.com/geerlingguy/ansible-role-apache", "ansible-role-apache"),
        ("https://github.com/geerlingguy/ansible-role-apache.git", "ansible-role-apache"),
        ("https://github.com/geerlingguy/ansible-role-apache.tar.gz", "ansible-role-apache")
    ]

    for repo_url, expected_output in test_cases:
        output = RoleRequirement.repo_url_to_role_name(repo_url)
        assert output == expected_output, "Expected %s but got %s" % (expected_output, output)


# Generated at 2022-06-25 05:59:55.612751
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    res = RoleRequirement.role_yaml_parse('http://github.com/geerlingguy/ansible-role-apache.git,v1')
    assert res == {'name': 'ansible-role-apache', 'scm': 'git', 'src': 'http://github.com/geerlingguy/ansible-role-apache.git', 'version': 'v1'}

    res = RoleRequirement.role_yaml_parse('http://github.com/geerlingguy/ansible-role-apache.git,v1,my_apache')
    assert res == {'name': 'my_apache', 'scm': 'git', 'src': 'http://github.com/geerlingguy/ansible-role-apache.git', 'version': 'v1'}

    res = RoleRequirement.role_y

# Generated at 2022-06-25 06:00:17.217608
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_repo_url_to_role_name = RoleRequirement()

    # First test case
    assert role_requirement_repo_url_to_role_name.repo_url_to_role_name('https://github.com/galaxyproject/ansible-role-test.git') == 'ansible-role-test'


# Generated at 2022-06-25 06:00:24.513545
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()

    # Negative test
    # Input: ''
    # Expect: AnsibleError exception
    role = ''
    try:
        role_requirement_1.role_yaml_parse(role)
        assert False, 'AnsibleError exception not thrown'
    except AnsibleError:
        pass

    # Negative test
    # Input: ','
    # Expect: AnsibleError exception
    role = ','
    try:
        role_requirement_1.role_yaml_parse(role)
        assert False, 'AnsibleError exception not thrown'
    except AnsibleError:
        pass

    # Negative test
    # Input: 'role_name,version1,version2,name'
    # Expect: AnsibleError exception

# Generated at 2022-06-25 06:00:28.229012
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    expected = 'repo'
    actual = RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    assert expected == actual


# Generated at 2022-06-25 06:00:35.249366
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_2 = RoleRequirement()
    role_requirement_3 = RoleRequirement()
    role_requirement_4 = RoleRequirement()

    test_data_0 = "user.name,1.0"
    test_data_1 = "user.name,1.0,test"
    test_data_2 = "git+https://name.git,v2"
    test_data_3 = "git+https://name.git"
    test_data_4 = "https://name.git"
    test_data_5 = "https://name.git,v2"
    test_data_6 = "file://path/to/ansible-role-apache,2.2.0"

# Generated at 2022-06-25 06:00:44.224092
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Tests for role_yaml_parse
    role_requirement = RoleRequirement()

    # This test case was added for a bug fixed in 2.0
    role_string_1 = 'https://github.com/rackerlabs/ansible-role-ntp.git,v2.0.0'
    results = role_requirement.role_yaml_parse(role_string_1)
    assert isinstance(results, dict)
    assert 'name' in results
    assert results['name'] == 'ansible-role-ntp'
    assert results['scm'] == 'git'
    assert results['src'] == 'https://github.com/rackerlabs/ansible-role-ntp.git'
    assert results['version'] == 'v2.0.0'


# Generated at 2022-06-25 06:00:46.676025
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_data_0 = {'role': 'openshift3.prometheus'}
    expected_0 = {'name': 'openshift3.prometheus'}
    actual_0 = RoleRequirement.role_yaml_parse(test_data_0)
    assert actual_0 == expected_0


# Generated at 2022-06-25 06:00:54.633025
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    role_spec = {'role': 'arbitrary_name',
                 'name': 'alternate_name',
                 'src': 'git://user:password@github.com/jdauphant/ansible-role-nginx.git',
                 'version': 'v1.6',
                 'scm': 'git'
                 }

    assert role_requirement.role_yaml_parse(role_spec) == {
        'name': 'alternate_name',
        'src': 'git://user:password@github.com/jdauphant/ansible-role-nginx.git',
        'version': 'v1.6',
        'scm': 'git'
    }



# Generated at 2022-06-25 06:01:05.047403
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()

    role_requirement_1.role_yaml_parse({"name": "testRole1", "scm": "git", "src": "git@github.com:example/testRole1"})
    role_requirement_1.role_yaml_parse({"name": "testRole1", "scm": "git", "src": "https://github.com/example/testRole1"})
    role_requirement_1.role_yaml_parse({"name": "testRole1", "scm": "git", "src": "https://github.com/example/testRole1.git"})

# Generated at 2022-06-25 06:01:13.923336
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_req_0_str = 'galaxy.role,v1.0,role_name'
    expected_0 = {'name': 'galaxy.role', 'src': 'galaxy.role', 'scm': None, 'version': 'v1.0'}
    role_req_0 = role_requirement_0.role_yaml_parse(role_req_0_str)
    assert role_req_0 == expected_0, "Expected {}, got {}".format(expected_0, role_req_0)

    role_req_1_str = 'galaxy.role,v1.0'

# Generated at 2022-06-25 06:01:23.707942
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

        # case 0
        role_requirement_0 = RoleRequirement()
        ansible_galaxy_parse_result_0 = role_requirement_0.role_yaml_parse("yunohost.yunohost")
        assert ansible_galaxy_parse_result_0 == dict(name='yunohost.yunohost', src='yunohost.yunohost', scm=None, version='')

        # case 1
        role_requirement_1 = RoleRequirement()
        role_requirement_1.role_yaml_parse("moby,v1.0.0") == dict(name='moby', src='moby', scm=None, version='v1.0.0')

        # case 2
        role_requirement_2 = RoleRequirement()
        role_requ

# Generated at 2022-06-25 06:02:02.212010
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    instance = RoleRequirement()
    result = instance.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    assert result == "repo"


# Generated at 2022-06-25 06:02:11.273792
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-25 06:02:22.941539
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test 1: without parameter
    with pytest.raises(AnsibleError):
        RoleRequirement.role_yaml_parse(None)

    # Test 2: with parameter 'geerlingguy.java'
    expected_role = dict(name='geerlingguy.java', src='geerlingguy.java', scm=None, version='')
    actual_role = RoleRequirement.role_yaml_parse('geerlingguy.java')
    assert expected_role == actual_role

    # Test 3: with parameter 'geerlingguy.java,1.0.0'
    expected_role = dict(name='geerlingguy.java', src='geerlingguy.java', scm=None, version='1.0.0')

# Generated at 2022-06-25 06:02:30.496359
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    requirement_test = {"src": "https://github.com/geerlingguy/ansible-role-ntp.git,v1.0.0", "name": "ntp", "version": "1.0.0"}
    assert RoleRequirement.role_yaml_parse("https://github.com/geerlingguy/ansible-role-ntp.git,v1.0.0") == requirement_test


# Generated at 2022-06-25 06:02:41.167203
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_0 = RoleRequirement()
    role_requirement_1 = 'jdauphant.nginx'
    role_requirement_2 = 'geerlingguy.apache,1.2.3'

    # Test if method role_yaml_parse of class RoleRequirement raise Exception when argument (role) equals to "role_requirement_1"

# Generated at 2022-06-25 06:02:50.072147
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role = 'git+https://github.com/bennojoy/nginx,master,bennojoy.nginx'
    expected_role = {'name': 'bennojoy.nginx', 'version': 'master', 'scm': 'git', 'src': 'https://github.com/bennojoy/nginx'}
    actual_role = role_requirement_1.role_yaml_parse(role)
    assert actual_role == expected_role


# Generated at 2022-06-25 06:02:57.809920
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_0 = RoleRequirement()
    src_0 = "http://git.example.com/repos/repo.git"
    src_0 = RoleRequirement.role_yaml_parse(src_0)
    src_0 = RoleRequirement.repo_url_to_role_name(src_0)
    assert src_0 == "repo"


# Generated at 2022-06-25 06:03:00.524113
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement_1 = RoleRequirement()
    role_requirement_1.role_yaml_parse("git+https://github.com/kosssi/ansible-role-phpapp.git,v0.2.0,kosssi.phpapp")


# Generated at 2022-06-25 06:03:02.864360
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement_1 = RoleRequirement()
    repo_url_1 = "http://git.example.com/repos/repo.git"
    expected_result_1 = "repo"
    actual_result_1 = role_requirement_1.repo_url_to_role_name(repo_url_1)
    display.vvv(actual_result_1)
    assert actual_result_1 == expected_result_1


# Generated at 2022-06-25 06:03:11.728631
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse(role={"role": "foo"}) == {u'name': u'foo'}
    assert RoleRequirement.role_yaml_parse(role={"role": "foo", "version": "bar"}) == {u'name': u'foo', u'version': u'bar'}
    assert RoleRequirement.role_yaml_parse(role={"src": "foo", "version": "bar", "name": "foo"}) == {u'name': u'foo', u'version': u'bar', u'src': u'foo'}

# Generated at 2022-06-25 06:05:06.046536
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    s = 'https://github.com/x/x.git'
    assert RoleRequirement.repo_url_to_role_name(s) == 'x'

    s = 'https://github.com/x.git'
    assert RoleRequirement.repo_url_to_role_name(s) == 'x.git'

    s = 'git+git://github.com/x/x.git'
    assert RoleRequirement.repo_url_to_role_name(s) == 'x'

    s = 'git+git://github.com/x.git'
    assert RoleRequirement.repo_url_to_role_name(s) == 'x.git'

    s = 'git+git://github.com/x/x.git,HEAD'
    assert RoleRequirement.repo_url