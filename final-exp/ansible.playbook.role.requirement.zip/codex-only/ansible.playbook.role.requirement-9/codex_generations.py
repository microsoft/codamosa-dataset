

# Generated at 2022-06-23 06:55:25.984378
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import tempfile

# Generated at 2022-06-23 06:55:30.436520
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Tests for utility method role_yaml_parse
    assert RoleRequirement.role_yaml_parse("test_role") == {'name': 'test_role', 'src': 'test_role', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse("test_role,v1.0") == {'name': 'test_role', 'src': 'test_role', 'scm': None, 'version': 'v1.0'}

# Generated at 2022-06-23 06:55:40.777771
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # test case 1: using git+
    role = {
        'scm': 'git',
        'src': 'git+https://github.com/ansible/ansible-examples.git',
        'name': 'ansible-examples',
        'version': 'HEAD',
        'keep_scm_meta': False,
    }
    assert RoleRequirement.scm_archive_role(**role) == "git+https://github.com/ansible/ansible-examples.git"

    # test case 2: scm not supported

# Generated at 2022-06-23 06:55:47.577138
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    rr = RoleRequirement()
    rr.role_yaml_parse("geerlingguy.jenkins,1.5.2")
    assert rr.version == "1.5.2"
    rr.role_yaml_parse("git+git@github.com:geerlingguy/ansible-role-jenkins.git,v1.5.2,geerlingguy.jenkins")
    assert rr.version == "v1.5.2"

# Generated at 2022-06-23 06:55:48.977635
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    assert role is not None


# Generated at 2022-06-23 06:55:54.168300
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    (rc, sha1) = RoleRequirement.scm_archive_role(src='http://github.com/bennojoy/my-role.git', version='HEAD', keep_scm_meta=False)
    assert rc == 0

# Generated at 2022-06-23 06:55:55.245510
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    assert role is not None

# Generated at 2022-06-23 06:56:01.504335
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache") == {'name': 'geerlingguy.apache', 'version': '', 'src': 'geerlingguy.apache', 'scm': None}
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.0.0") == {'name': 'geerlingguy.apache', 'version': '1.0.0', 'src': 'geerlingguy.apache', 'scm': None}
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.0.0,apache") == {'name': 'apache', 'version': '1.0.0', 'src': 'geerlingguy.apache', 'scm': None}
    assert RoleRequirement.role_yaml_parse

# Generated at 2022-06-23 06:56:05.142005
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    src = "https://github.com/UNINETT/ansible-role-freeipa"
    scm = 'git'
    version = 'HEAD'
    name = 'ansible-role-freeipa'
    keep_scm_meta = False
    role_to_validate = "ansible-role-freeipa,HEAD,UNINETT.ansible-role-freeipa"

    destination = RoleRequirement.scm_archive_role(src=src, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta)

    assert isinstance(destination, string_types)
    assert os.path.isdir(destination)
    assert RoleRequirement.role_yaml_parse(role_to_validate)["name"] in destination



# Generated at 2022-06-23 06:56:17.915051
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # valid data
    assert RoleRequirement.role_yaml_parse("1.2.3") == {'scm': None, 'version': '1.2.3', 'src': None}
    assert RoleRequirement.role_yaml_parse("git+git@github.com:jdauphant/ansible-role-nginx.git") == {'scm': 'git', 'version': None, 'src': 'git@github.com:jdauphant/ansible-role-nginx.git'}

# Generated at 2022-06-23 06:56:29.711109
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test RoleRequirement.role_yaml_parse on string type input
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git') == dict(name='repo', src='http://git.example.com/repos/repo.git', scm=None, version=None)
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,v1.2.3') == dict(name='repo', src='http://git.example.com/repos/repo.git', scm=None, version='v1.2.3')

# Generated at 2022-06-23 06:56:41.305742
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git,") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git,v1") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git,v1,my_role") == "repo"

# Generated at 2022-06-23 06:56:52.627382
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    import os
    import sys
    import logging
    import tempfile

    test_name = 'test_RoleRequirement_repo_url_to_role_name'

    # Set the ansible logger to a temporary file to show log messages
    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    logfile = tmpfile.name
    log = logging.getLogger('testRoleRequirement')
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))
    log.addHandler(logging.FileHandler(logfile))
    log.propagate = False


# Generated at 2022-06-23 06:57:01.211942
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import tempfile
    from ansible.module_utils.urls import fetch_url

    # Check for a valid download with ansible.cfg
    dest = None
    try:
        dest = tempfile.mkdtemp(prefix='ansible_test_')
        (status, url) = RoleRequirement.scm_archive_role(src='http://github.com/ansible/ansible-modules-core.git',
                                                         scm='git', version='devel')
        assert status in [200, 302, 304]
    finally:
        if dest:
            os.rmdir(dest)

# Generated at 2022-06-23 06:57:10.114948
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    """
    Tests for method repo_url_to_role_name of class RoleRequirement
    """
    from ansible.collections.galaxy.plugins.module_utils.galaxy_utils import GalaxyRole
    role = RoleRequirement()
    # Test for valid roles
    assert role.repo_url_to_role_name('http://github.com/username/repo.git') == 'repo'
    assert role.repo_url_to_role_name('git+http://github.com/username/repo.git') == 'repo'
    assert role.repo_url_to_role_name('git+https://github.com/username/repo.git') == 'repo'

# Generated at 2022-06-23 06:57:20.984185
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # only string examples
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.1.1") == "repo"

    # git style

# Generated at 2022-06-23 06:57:27.492491
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    repo_url = "https://github.com/ansible/ansible-examples.git"
    expected = "ansible-examples"
    result = RoleRequirement.repo_url_to_role_name(repo_url)
    assert(expected == result)

    repo_url = "https://github.com/ansible/ansible-examples"
    expected = "ansible-examples"
    result = RoleRequirement.repo_url_to_role_name(repo_url)
    assert(expected == result)

    repo_url = "git@github.com:ansible/ansible-examples.git"
    expected = "ansible-examples"
    result = RoleRequirement.repo_url_to_role_name(repo_url)
    assert(expected == result)



# Generated at 2022-06-23 06:57:38.901378
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:user/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com:user/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com:user/repo.git,foo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com:user/repo,bar.git") == "repo,bar"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com/user/repo.git") == "repo"
    assert Role

# Generated at 2022-06-23 06:57:49.231443
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    print(role)

    # test for role_yaml_parse
    print(role.role_yaml_parse('geerlingguy.apache,2.0'))
    print(role.role_yaml_parse('geerlingguy.jenkins'))
    print(role.role_yaml_parse('geerlingguy.redis,1.0,myredis'))
    print(role.role_yaml_parse('https://github.com/foo/bar.git,1.0'))
    print(role.role_yaml_parse('https://github.com/foo/bar.git,1.0,mycustomredis'))
    print(role.role_yaml_parse('https://github.com/foo/bar.git'))

# Generated at 2022-06-23 06:57:55.253383
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    scm = 'git'
    src = 'https://github.com/geerlingguy/ansible-role-apache.git'
    name = None
    version = 'master'
    keep_scm_meta = True

    role = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)
    print(role)

# Generated at 2022-06-23 06:58:00.993121
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import types
    assert isinstance(RoleRequirement.role_yaml_parse('namelessrole'), dict)
    assert 'name' in RoleRequirement.role_yaml_parse('namelessrole') and 'src' in RoleRequirement.role_yaml_parse('namelessrole') and 'version' in RoleRequirement.role_yaml_parse('namelessrole') and 'scm' in RoleRequirement.role_yaml_parse('namelessrole')
    assert RoleRequirement.role_yaml_parse('namelessrole')['name'] == 'namelessrole'
    assert RoleRequirement.role_yaml_parse('namelessrole')['src'] == 'namelessrole'
    assert RoleRequirement.role_yaml_parse('namelessrole')['version'] == ''
    assert RoleRequirement.role_yaml_parse

# Generated at 2022-06-23 06:58:08.834452
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = 'git+https://github.com/geerlingguy/ansible-role-apache.git'
    name = 'apache'
    version = 'HEAD'
    keep_scm_meta = False

    # args passed as string
    filename = RoleRequirement.scm_archive_role(src, name=name, version=version)
    assert isinstance(filename, string_types)
    assert filename.endswith('.tar.gz')

    # args passed as dict
    filename = RoleRequirement.scm_archive_role({'src': src, 'name': name, 'version': version})
    assert isinstance(filename, string_types)
    assert filename.endswith('.tar.gz')

# Generated at 2022-06-23 06:58:20.922436
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Run a test case
    name = "geerlingguy.ntp"
    version = "v0.0.1"
    role_definition = RoleRequirement()
    role_definition.name = name
    role_definition.src = src = "localhost"
    role_definition.scm = scm = "git"
    role_definition.version = version
    role_definition.defaults = None
    role_definition.vars = None
    role_definition.file = None
    role_definition.tags = None
    role_definition.tasks = None
    role_definition.handlers = None
    role_definition.meta = None
    role_definition.path = None
    role_definition.dependencies = None
    role_definition.post_tasks = None

    # Validate the test case
    assert role_definition

# Generated at 2022-06-23 06:58:33.486802
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.playbook.play_context import PlayContext

    # Get the current directory
    dirname, filename = os.path.split(os.path.abspath(__file__))

    # Setup the environment for the tests
    os.chdir(dirname)
    try:
        os.remove('./test-repo-rolename/.git')
    except OSError as e:
        pass
    shutil.rmtree('./test-repo-rolename', ignore_errors=True)
    shutil.rmtree('./scm_archive', ignore_errors=True)

    # Clone a git repo to be used for the test

# Generated at 2022-06-23 06:58:45.089363
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 06:58:56.041698
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # test archive_resource with a scm url that doesn't end with '.tar.gz'.
    # trailing slashes and commas in the url are handled by archive resources.
    src = 'git://github.com/foo/bar.git/'
    expected_role_path = "bar"
    scm = 'git'
    name = None
    version = 'HEAD'
    keep_scm_meta = False

    downloaded_archive_path = RoleRequirement.scm_archive_role(src, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta)
    assert downloaded_archive_path.endswith(expected_role_path + ".tar.gz")

    # test archive_resource with a scm url that ends with '.tar.gz'

# Generated at 2022-06-23 06:59:04.357566
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    test_cases = [
                    'geerlingguy.nginx,1.2.3',
                    'geerlingguy.nginx,1.2.3,role_name',
                    {
                        "src": "geerlingguy.nginx",
                        "version": "1.2.3",
                        "name": "role_name"
                    },
                    {
                        "src": "git+https://github.com/geerlingguy/ansible-role-nginx.git",
                        "version": "1.2.3",
                        "name": "geerlingguy.nginx"
                    }
                ]

    for test_case in test_cases:
        role = RoleRequirement.role_yaml_parse(test_case)

# Generated at 2022-06-23 06:59:14.122554
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import shutil
    import tempfile
    from ansible.module_utils.six.moves import urllib
    from ansible import __version__

    temp_dir = tempfile.mkdtemp()
    try:
        RoleRequirement.scm_archive_role(temp_dir, scm='git', src="https://github.com/ansible/ansible.git", version="stable-" + __version__)
        assert urllib.parse.unquote(temp_dir) == urllib.parse.unquote(temp_dir)
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-23 06:59:26.521737
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 06:59:29.934798
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    print ("testing RoleRequirement")
    role_requirement = RoleRequirement()
    assert role_requirement is not None


if __name__ == "__main__":
    test_RoleRequirement()

# Generated at 2022-06-23 06:59:41.875139
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # tests without scm
    assert ('repo' == RoleRequirement.repo_url_to_role_name('repo'))
    assert ('repo' == RoleRequirement.repo_url_to_role_name('https://git.example.com/repos/repo.git'))
    assert ('repo' == RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/repo'))
    assert ('repo' == RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/repo.git'))
    assert ('repo' == RoleRequirement.repo_url_to_role_name('git@github.com:geerlingguy/repo'))

# Generated at 2022-06-23 06:59:51.516831
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://github.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('foobar.git') == 'foobar'
    assert RoleRequirement.repo_url_to_role_name('foobar.tar.gz') == 'foobar'
    assert RoleRequirement.repo_url_to_role_name('foobar,v1.0.0') == 'foobar'
    assert RoleRequirement.repo_url_to_role_name('foobar,v1.0.0,name') == 'foobar'

# Generated at 2022-06-23 07:00:02.740207
# Unit test for method scm_archive_role of class RoleRequirement

# Generated at 2022-06-23 07:00:14.651735
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git#1.0") == "repo"
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git#") == "repo"

    assert role_requirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"

# Generated at 2022-06-23 07:00:24.424165
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # Test a git URL
    src = 'git+https://github.com/github/project.git'
    role = RoleRequirement.scm_archive_role(src)
    assert(role.name == 'project')
    assert(role.src == 'https://github.com/github/project.git')
    assert(role.scm == 'git')
    assert(role.version == 'HEAD')

    # Test a git URL with a branch
    src = 'git+https://github.com/github/project.git,branch'
    role = RoleRequirement.scm_archive_role(src)
    assert(role.name == 'project')
    assert(role.src == 'https://github.com/github/project.git')
    assert(role.scm == 'git')

# Generated at 2022-06-23 07:00:35.360596
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    def test(url, name):
        if RoleRequirement.repo_url_to_role_name(url) != name:
            raise AssertionError("Failed: %s != %s" % (url, name))
    test("http://github.com/example/test", "test")
    test("http://github.com/example/test.git", "test")
    test("http://github.com/example/test.tar.gz", "test")
    test("http://github.com/example/test.git,v1.2", "test")
    test("http://github.com/example/test.tar.gz,v1.2", "test")
    test("http://github.com/example/test.git,v1.2,name", "test")

# Generated at 2022-06-23 07:00:47.126851
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert(RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git")) == "repo"
    assert(RoleRequirement.repo_url_to_role_name("user@git.example.com/repos/repo.git")) == "repo"
    assert(RoleRequirement.repo_url_to_role_name("repo")) == "repo"
    assert(RoleRequirement.repo_url_to_role_name("git+http://git.example.com/repos/repo,.tar.gz")) == "repo.tar.gz"

# Generated at 2022-06-23 07:00:48.948970
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement_instance = RoleRequirement()
    assert (role_requirement_instance)

# Generated at 2022-06-23 07:01:01.141702
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # using git
    res = RoleRequirement.scm_archive_role("git+https://github.com/ansible/ansible-examples.git",
                                           scm='git',
                                           name=None,
                                           version='HEAD',
                                           keep_scm_meta=False)
    assert res["name"] == "ansible-examples"
    assert "archive" in res["path"]
    assert "git_archive_submodule_mode" in res
    assert res["git_archive_submodule_mode"] == "none"

    # using git, but specify a non-default value for submodule mode

# Generated at 2022-06-23 07:01:10.175821
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    print("Testing repo_url_to_role_name method of class RoleRequirement...")

# Generated at 2022-06-23 07:01:18.764054
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.utils.display import Display
    display = Display()

    import os
    import tempfile
    from shutil import rmtree
    from ansible.utils.galaxy import RoleRequirement, galaxy_role_matches

    # Generate a temporary directory to work in:
    tmpdir = tempfile.mkdtemp(prefix='ansible-galaxy')

    # Where to download role definition to:
    role_path = os.path.join(tmpdir, 'test.requirement')

    #
    # Test role names
    #
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com/repos/repo.git') == 'repo'

# Generated at 2022-06-23 07:01:29.235754
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = {'role': 'geerlingguy.java',
            'when': 'some_var.some_key == "some_value"'}
    role_parsed = RoleRequirement.role_yaml_parse(role)
    assert role_parsed['name'] == 'geerlingguy.java'
    assert not role_parsed['scm']
    assert role_parsed['src'] == 'geerlingguy.java'
    assert not role_parsed['version']

    role = {'role': 'geerlingguy.java,1.6'}
    role_parsed = RoleRequirement.role_yaml_parse(role)
    assert role_parsed['name'] == 'geerlingguy.java'
    assert not role_parsed['scm']

# Generated at 2022-06-23 07:01:35.737438
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    from ansible.galaxy.role import RoleRequirement
    from ansible import errors

    try:
        RoleRequirement.scm_archive_role(src="https://github.com/test/test.git", scm="git", name="test", version="HEAD", keep_scm_meta=False)
    except errors.AnsibleError as e:
        print(e)

# Generated at 2022-06-23 07:01:47.635362
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.utils.galaxy import Galaxy
    from ansible.utils.galaxy import GalaxyError

    galaxy_instance = Galaxy()

    # Git clone of meta file
    # Invalid spec file
    role_spec = galaxy_instance.parse_role_vars_from_file(
        'https://github.com/geerlingguy/rabbitmq-role.git',
        'meta/main.yml')
    role_requirement = role_spec[0]

# Generated at 2022-06-23 07:01:58.080442
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test 1: Defined role
    test_input = {
        'name': 'role1',
        'scm': None,
        'src': 'http://src1',
        'version': None
    }
    test_output = RoleRequirement.role_yaml_parse(test_input)
    assert test_output == test_input

    # Test 2: Defined role, but undefined name
    test_input = {
        'name': None,
        'scm': 'http',
        'src': 'http://src',
        'version': '1.0.0'
    }
    test_output = RoleRequirement.role_yaml_parse(test_input)
    assert test_output['name'] == 'src'

    # Test 3: Defined role, but undefined name

# Generated at 2022-06-23 07:02:09.179431
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert(RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo')
    assert(RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo')
    assert(RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0') == 'repo')
    assert(RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0,goodform') == 'repo')

# Generated at 2022-06-23 07:02:20.418458
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    assert RoleRequirement.scm_archive_role('git://git/git.git') == (0, 'git', 'git-HEAD.tar.gz')
    assert RoleRequirement.scm_archive_role('git@git/git.git') == (0, 'git', 'git-HEAD.tar.gz')
    assert RoleRequirement.scm_archive_role('git+git://git/git.git') == (0, 'git', 'git-HEAD.tar.gz')
    assert RoleRequirement.scm_archive_role('git+git@git/git.git') == (0, 'git', 'git-HEAD.tar.gz')

# Generated at 2022-06-23 07:02:23.017256
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    x = RoleRequirement()
    assert isinstance(x, RoleRequirement)


# Generated at 2022-06-23 07:02:32.649411
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo-1.2.4.tar.gz') == 'repo-1.2.4'
    assert role_requirement.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement.repo_url_

# Generated at 2022-06-23 07:02:43.473046
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test for old style meta/main.yml format
    assert RoleRequirement().role_yaml_parse("username.rolename,1.0.1") == {"name": "username.rolename", "src": "username.rolename", "version": "1.0.1", "scm": None}

    # test for new style meta/main.yml format
    assert RoleRequirement().role_yaml_parse({"role": "username.rolename,1.0.1"}) == {"name": "username.rolename", "src": "username.rolename", "version": "1.0.1", "scm": None}

    # test for empty src

# Generated at 2022-06-23 07:02:54.817773
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 07:03:02.649156
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # Validate the constructor of class RoleRequirement
    temp_rolereq = RoleRequirement()
    is_instance = isinstance(temp_rolereq, RoleRequirement)
    assert is_instance

    # Validate the repo_url_to_role_name method of class RoleRequirement
    temp_role_name = RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    assert temp_role_name == "repo"

    # Validate the repo_url_to_role_name method of class RoleRequirement
    temp_role_name = RoleRequirement.repo_url_to_role_name("http://example.com/repos/repo.git")
    assert temp_role_name == "repo"

    # Validate the repo_url

# Generated at 2022-06-23 07:03:11.096960
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    #test tarball
    s = RoleRequirement.scm_archive_role(src="https://github.com/ansible/ansible-examples/archive/stable-1.0.tar.gz", scm="git", name="ansible-examples", version="stable-1.0")
    assert isinstance(s, dict)
    assert s["path"].endswith(".tar.gz")
    assert s["name"] == "ansible-examples"

    #test tarball
    s = RoleRequirement.scm_archive_role(src="https://github.com/ansible/ansible-examples/archive/stable-1.0.zip", scm="git", name="ansible-examples", version="stable-1.0")
    assert isinstance(s, dict)

# Generated at 2022-06-23 07:03:23.017486
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # test git scm archive
    role_git_archive = RoleRequirement.scm_archive_role("https://github.com/ansible/ansible-examples/new/master/lamp_simple", scm="git")
    assert role_git_archive is not None, "Fail to archive github.com/ansible/ansible-examples/new/master/lamp_simple using git scm"
    assert role_git_archive.endswith("lamp_simple.tar.gz") or role_git_archive.endswith("lamp_simple.zip"), "Fail to archive github.com/ansible/ansible-examples/new/master/lamp_simple using git scm : wrong extension"
    # test hg scm archive

# Generated at 2022-06-23 07:03:29.414912
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    display.vvvv('test_RoleRequirement_repo_url_to_role_name')
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com:repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.2.3') == 'repo'
    assert RoleRequirement.repo_url_to_role

# Generated at 2022-06-23 07:03:38.251273
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 07:03:48.639103
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-23 07:04:00.902036
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    assert RoleRequirement.scm_archive_role('https://github.com/ansible/ansible-modules-core.git', scm='git', name='ansible-modules-core') == {
        '_ansible_no_log': False,
        'dest': None,
        'force': True,
        'selevel': None,
        'serole': None,
        'setype': None,
        'seuser': None,
        'src': 'https://github.com/ansible/ansible-modules-core.git',
        'version': 'HEAD',
        'warn': True,
        'keep_scm_meta': False,
        'scm': 'git',
        'name': 'ansible-modules-core',
    }

# Generated at 2022-06-23 07:04:12.049179
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    rr = RoleRequirement()

    # simple role spec
    role_spec = 'test-role'
    role_dict = rr.role_yaml_parse(role_spec)
    assert role_dict['name'] == 'test-role'
    assert role_dict['version'] == ""
    assert role_dict['scm'] == None
    assert role_dict['src'] == 'test-role'

    # role spec with version
    role_spec = 'test-role,1.0'
    role_dict = rr.role_yaml_parse(role_spec)
    assert role_dict['name'] == 'test-role'
    assert role_dict['version'] == "1.0"
    assert role_dict['scm'] == None
    assert role_dict['src'] == 'test-role'

   

# Generated at 2022-06-23 07:04:24.161714
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    result = RoleRequirement.scm_archive_role('git+https://github.com/jdauphant/ansible-role-nginx@v1.0.0')
    assert result.get('path') is not None
    result = RoleRequirement.scm_archive_role('git+https://github.com/jdauphant/ansible-role-nginx')
    assert result.get('path') is not None
    result = RoleRequirement.scm_archive_role('https://github.com/jdauphant/ansible-role-nginx')
    assert result.get('path') is not None
    result = RoleRequirement.scm_archive_role('https://github.com/jdauphant/ansible-role-nginx', version='master')
    assert result.get('path') is not None

# Generated at 2022-06-23 07:04:35.247713
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = 'https://github.com/vprudonosov/ansible-role-test.git'
    scm = 'git'
    role_info = RoleRequirement.scm_archive_role(src, scm)
    assert(role_info['name'] == 'test')
    assert(role_info['path'] is not None)
    assert(role_info['version'] == 'HEAD')
    assert(role_info['scm'] == 'git')

    src = 'https://github.com/vprudonosov/ansible-role-test.git'
    scm = 'git'
    version = 'v1'
    role_info = RoleRequirement.scm_archive_role(src, scm, version=version)
    assert(role_info['name'] == 'test')

# Generated at 2022-06-23 07:04:46.778597
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    url = 'http://git.example.com/repos/repo.git'
    name = RoleRequirement.repo_url_to_role_name(url)
    assert name == 'repo'


test_RoleRequirement_yaml_parse_simple = '''
roles:
  - common
'''

test_RoleRequirement_yaml_parse_vars = '''
roles:
  - { role: common, tags: server }
  - { role: apache, become: true }
  - { role: nginx, tags: client }
'''


# Generated at 2022-06-23 07:04:56.824537
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes, to_text

    if not hasattr(string_types, '__iter__'):
        string_types = (basestring,)

    assert to_text(AnsibleBaseYAMLObject("a string")) == to_bytes("a string")
    assert to_text(AnsibleBaseYAMLObject("a string")) == b"a string"
    assert to_bytes(AnsibleBaseYAMLObject("a string")) == b"a string"


# Generated at 2022-06-23 07:05:09.033911
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    from ansible.compat.tests import unittest

    class TestRoleRequirement(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_role_name_extraction(self):
            self.assertEqual(RoleRequirement.repo_url_to_role_name('https://github.com/someuser/SomeRole'), 'SomeRole')
            self.assertEqual(RoleRequirement.repo_url_to_role_name('git://github.com/someuser/SomeRole'), 'SomeRole')
            self.assertEqual(RoleRequirement.repo_url_to_role_name('git@github.com:someuser/SomeRole'), 'SomeRole')

# Generated at 2022-06-23 07:05:18.908829
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    if RoleRequirement.scm_archive_role('git+git://github.com/jtyr/ansible-vsftpd.git', scm='git', name='vsftpd').endswith('ansible-vsftpd-cacf7b5c26baf50a1bfdbc8130ab7fa1025750be'):
        print('Test RoleRequirement.scm_archive_role: Passed!')
    else:
        print('Test RoleRequirement.scm_archive_role: Failed!')
