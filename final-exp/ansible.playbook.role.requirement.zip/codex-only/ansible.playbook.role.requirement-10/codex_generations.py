

# Generated at 2022-06-23 06:55:25.848973
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
  import tempfile
  import os

  roles_meta = '''
- name: test.role
  version: 1.0
  role: test.role
'''

  temp_dir = tempfile.mkdtemp()
  meta_file = os.path.join(temp_dir, 'meta.yml')
  with open(meta_file, 'w') as fd:
    fd.write(roles_meta)
  role = RoleRequirement.role_yaml_parse('test.role')
  assert role['name'] == 'test.role'
  assert role['version'] == ''
  assert role['src'] == 'test.role'
  assert role['scm'] is None


# Generated at 2022-06-23 06:55:33.331615
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_req = RoleRequirement()
    # Test proper roles
    assert role_req.role_yaml_parse(dict(role='role_name')) == dict(name='role_name', scm=None, src=None, version=None)
    assert role_req.role_yaml_parse(dict(role='role_name,v1')) == dict(name='role_name', scm=None, src=None, version='v1')
    assert role_req.role_yaml_parse(dict(role='role_name,v2,new_name')) == dict(name='new_name', scm=None, src=None, version='v2')

# Generated at 2022-06-23 06:55:43.765596
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Prepare testcase
    url_1 = "http://git.example.com/repos/repo.git"
    url_2 = "http://git.example.com/repos/repo,v0.1.tar.gz"
    url_3 = "repo"

    # Execute test
    name_1 = RoleRequirement.repo_url_to_role_name(url_1)
    name_2 = RoleRequirement.repo_url_to_role_name(url_2)
    name_3 = RoleRequirement.repo_url_to_role_name(url_3)

    # Perform assertions
    assert name_1 == 'repo'
    assert name_2 == 'repo'
    assert name_3 == 'repo'

# Generated at 2022-06-23 06:55:50.784145
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    repo_urls = {
        'http://git.example.com/repos/repo.git': 'repo',
        'git@git.example.com:/repos/repo.git': 'repo',
        'git+https://git.example.com/repos/repo.git': 'repo',
        'repo-without-suffix': 'repo-without-suffix',
        'repo.tar.gz': 'repo',
        'repo.tar.gz,v1.1': 'repo',
    }

    for repo_url in repo_urls:
        assert RoleRequirement.repo_url_to_role_name(repo_url) == repo_urls[repo_url]



# Generated at 2022-06-23 06:56:01.486546
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # Basic functional test
    test_src = 'https://github.com/ansible/include_vars.git'
    test_name = 'include_vars'
    test_version = 'HEAD'
    expected_folder_name = 'include_vars-HEAD'
    expected_scm_archive_path = '/home/user/ansible'
    expected_archive_path = '/home/user/ansible/.cache/ansible-galaxy/include_vars-HEAD.tar.gz'
    ansible_galaxy_path = '/home/user/ansible'
    test_archive_path = RoleRequirement.scm_archive_role(src=test_src, name=test_name, version=test_version, ansible_galaxy_path=ansible_galaxy_path)

# Generated at 2022-06-23 06:56:13.153069
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # Test git version
    src = 'https://github.com/kkirsche/test-as-test.git'
    scm = 'git'
    name = 'test-as-test'
    version = 'HEAD'
    result = RoleRequirement.scm_archive_role(src,
                                              scm=scm,
                                              name=name,
                                              version=version)
    assert result == '/tmp/test-as-test-master.tar.gz'

    # Test mercurial version
    src = 'https://bitbucket.org/kkirsche/test-as-test'
    scm = 'hg'
    name = 'test-as-test'

# Generated at 2022-06-23 06:56:22.688278
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    role = RoleRequirement.scm_archive_role("https://github.com/ManageIQ/test-role-test.git")

    assert role.name == "test-role-test"
    assert not role.is_local_path()

    role = RoleRequirement.scm_archive_role("git+https://git@github.com/some/private.git")

    assert role.name == "private"
    assert not role.is_local_path()

    role = RoleRequirement.scm_archive_role("https://github.com/ManageIQ/test-role-test,v0.5")

    assert role.name == "test-role-test"
    assert role.version == "v0.5"
    assert not role.is_local_path()


# Generated at 2022-06-23 06:56:32.074898
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    a = RoleRequirement()
    assert a is not None
    assert a.name is None
    assert a.role_name is None
    assert a.collections is None
    assert a.private is None
    assert a.private_role is None
    assert a.private_collections is None

    a = RoleRequirement(role="test")
    assert a.role_name == "test"
    assert a.name is None

    a = RoleRequirement(name="test")
    assert a.role_name == "test"
    assert a.name == "test"

    a = RoleRequirement(role="test", name="test")
    assert a.role_name == "test"
    assert a.name == "test"

    a = RoleRequirement(role="test", name="test", src="test")

# Generated at 2022-06-23 06:56:34.760891
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    assert role is not None
    assert isinstance(role, RoleRequirement)



# Generated at 2022-06-23 06:56:46.237548
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 06:56:54.620005
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    test_dir = os.path.dirname(os.path.abspath(__file__))
    test_data = os.path.join(test_dir, 'data')

    # Test git
    role = RoleRequirement()
    role_info = role.scm_archive_role(src="https://github.com/ansible/ansible-examples.git", scm='git', version='4327a9a')
    assert role_info['name'] == 'ansible-examples'
    assert os.path.exists(role_info['path'])
    assert os.path.exists(os.path.join(role_info['path'], 'example_playbooks', 'hello_world.yml'))

    # Test hg
    role = RoleRequirement()

# Generated at 2022-06-23 06:57:06.016392
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    #
    # Create RoleRequirement object instance
    #
    obj = RoleRequirement()
    #
    # Check RoleRequirement object methods
    #
    assert obj.role_yaml_parse(role_str="foobar,0.0.1,baz") == {'name': 'baz', 'src': 'foobar', 'scm': None, 'version': '0.0.1'}
    assert obj.role_yaml_parse(role={"role": "foobar,0.0.1,baz"}) == {'name': 'baz', 'src': 'foobar', 'scm': None, 'version': '0.0.1'}

# Generated at 2022-06-23 06:57:19.455536
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    rr = RoleRequirement
    assert rr.role_yaml_parse('a') == {'name': 'a', 'scm': None, 'src': 'a', 'version': ''}
    assert rr.role_yaml_parse('git+a') == {'name': 'a', 'scm': 'git', 'src': 'a', 'version': ''}
    assert rr.role_yaml_parse('a,master') == {'name': 'a', 'scm': None, 'src': 'a', 'version': 'master'}
    assert rr.role_yaml_parse('b,v1.0.0') == {'name': 'b', 'scm': None, 'src': 'b', 'version': 'v1.0.0'}
    assert rr.role_yaml_

# Generated at 2022-06-23 06:57:33.896576
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test case 1: {'role': 'my-role'}
    test_role = {'role': 'my-role'}
    expected_result = {'name': 'my-role'}
    assert RoleRequirement.role_yaml_parse(test_role) == expected_result

    # test case 2: 'my-role'
    test_role = 'my-role'
    expected_result = {'name': 'my-role', 'src': 'my-role', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse(test_role) == expected_result

    # test case 3: 'my-role,v1.0'
    test_role = 'my-role,v1.0'

# Generated at 2022-06-23 06:57:44.723831
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # test 'git' scm with https url
    role_definition = RoleRequirement.scm_archive_role("https://github.com/ansible/ansible-examples")
    assert role_definition['name'] == 'ansible-examples'
    assert role_definition['scm'] == 'git'
    assert role_definition['src'] == 'https://github.com/ansible/ansible-examples'
    assert role_definition['version'] == 'HEAD'

    # test 'git' scm with https url
    role_definition = RoleRequirement.scm_archive_role("https://github.com/ansible/ansible-examples,v1.0")
    assert role_definition['name'] == 'ansible-examples'
    assert role_definition['scm'] == 'git'
    assert role_definition

# Generated at 2022-06-23 06:57:51.818753
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    role_requirement = RoleRequirement()
    src = 'https://github.com/geerlingguy/ansible-role-jenkins.git'
    scm = 'git'
    name = 'geerlingguy.jenkins'
    version = 'v2.2.0'
    keep_scm_meta = False
    role_requirement.scm_archive_role(src, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta)


# Generated at 2022-06-23 06:58:01.560813
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 06:58:11.885080
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    rr = RoleRequirement()
    assert rr.role_yaml_parse("http://git.example.com/repos/repo.git") == {'name': 'repo', 'scm': None, 'src': 'http://git.example.com/repos/repo.git', 'version': None}
    assert rr.role_yaml_parse("http://git.example.com/repos/repo.git,v1.0") == {'name': 'repo', 'scm': None, 'src': 'http://git.example.com/repos/repo.git', 'version': 'v1.0'}

# Generated at 2022-06-23 06:58:13.248802
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    role_definition = RoleRequirement()

# Generated at 2022-06-23 06:58:23.177044
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    import pytest
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com:repos.git') == 'repos'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/user/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git@github.com:user/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/user/repo.git,v1.1') == 'repo'

# Generated at 2022-06-23 06:58:34.876334
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert "repo" == RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    assert "repo" == RoleRequirement.repo_url_to_role_name("git+https://git.example.com/repos/repo.git")
    assert "repo" == RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/repo.git")
    assert "repo" == RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/repo.git#1.2")

# Generated at 2022-06-23 06:58:45.671704
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    if RoleRequirement.repo_url_to_role_name('git+http://git.example.com/repos/repo.git') != 'repo':
        raise Exception('Could not get role name from git url: http://git.example.com/repos/repo.git')
    if RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') != 'repo':
        raise Exception('Could not get role name from git url: http://git.example.com/repos/repo.git')

# Generated at 2022-06-23 06:58:56.457449
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com:repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('example.com:repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('/path/to/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role

# Generated at 2022-06-23 06:59:04.770651
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_dict = RoleRequirement.role_yaml_parse("http://git.example.com/repos/repo.git")
    assert role_dict == {
        'name': 'repo',
        'src': 'http://git.example.com/repos/repo.git',
        'scm': 'git',
        'version': None
    }, "Did not return expected dictionary of key valued pairs for valid input."

    role_dict = RoleRequirement.role_yaml_parse("http://git.example.com/repos/repo.git,master")

# Generated at 2022-06-23 06:59:16.782103
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    line = '- name: test'
    assert RoleRequirement.role_yaml_parse(line) == {'name': 'test', 'src': 'test', 'scm': None, 'version': ''}

    line = '- name: test,v1.0'
    assert RoleRequirement.role_yaml_parse(line) == {'name': 'test', 'src': 'test', 'scm': None, 'version': 'v1.0'}

    line = '- name: test,v1.0,mytest'
    assert RoleRequirement.role_yaml_parse(line) == {'name': 'mytest', 'src': 'test', 'scm': None, 'version': 'v1.0'}


# Generated at 2022-06-23 06:59:28.843397
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile
    import shutil
    import os
    import subprocess
    import sys

    tmp_dir = tempfile.mkdtemp(prefix='ansible-test-role-')

    repo = 'https://github.com/ansible/ansible-examples.git'

    display.vvvv('Creating a temporary git repo at %s' % tmp_dir)
    cmd = ['git', 'init', tmp_dir]
    display.vvvv(cmd)
    rc, out, err = module_common.run_command(cmd)
    display.vvvv('Return code: %s' % rc)
    display.vvvv('Stdout: %s' % out)
    display.vvvv('Stderr: %s' % err)

    orig_cwd = os.getcwd()

# Generated at 2022-06-23 06:59:31.695258
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    role_requirement = RoleRequirement()

    assert role_requirement.__class__.__name__ == 'RoleRequirement'


# Generated at 2022-06-23 06:59:43.618863
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    import ansible.galaxy.role
    assert "foo" == ansible.galaxy.role.RoleRequirement.repo_url_to_role_name("foo")
    assert "foo" == ansible.galaxy.role.RoleRequirement.repo_url_to_role_name("git+https://foo")
    assert "foo" == ansible.galaxy.role.RoleRequirement.repo_url_to_role_name("git+https://foo.git")
    assert "foo" == ansible.galaxy.role.RoleRequirement.repo_url_to_role_name("git+http://foo.git")
    assert "foo" == ansible.galaxy.role.RoleRequirement.repo_url_to_role_name("git+git@foo.git")
    assert "foo" == ans

# Generated at 2022-06-23 06:59:51.339164
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    url = 'git+ssh://git@github.com/user/repo'
    role = 'user.repo'

    from tempfile import mkdtemp
    import os
    tempdir = mkdtemp()

    RoleRequirement.scm_archive_role(src=url,
                                     scm='git',
                                     name=role,
                                     version='HEAD',
                                     dest=tempdir)
    os.chdir(os.path.join(tempdir, *role.split('.')))
    output = os.popen("git log --oneline").read()
    assert output.startswith("b5e7b5c")

# Generated at 2022-06-23 06:59:58.942712
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile
    import os

    src = 'https://github.com/geerlingguy/ansible-role-mythtv.git'
    scm = 'git'
    version_tag = 'v1.0.0'
    version_rev = 'ad8d6c4881cff0b6cef6cb9a1bae65b12118940f'
    version = version_tag
    name = 'ansible-role-mythtv'
    tmpdir = tempfile.mkdtemp()
    keep_scm_meta = False
    srcfile = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)

    os.remove(srcfile)
    os.rmdir(tmpdir)
    assert True

# Generated at 2022-06-23 07:00:10.352943
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    invalid_role = "invalid_role"
    invalid_role = RoleRequirement.role_yaml_parse(invalid_role)
    assert invalid_role["name"] == "invalid_role"
    assert invalid_role["version"] == None
    assert invalid_role["src"] == None
    assert invalid_role["scm"] == None
    
    valid_role = "https://github.com/galaxyproject/ansible-base-container.git,v1.0.0,ansible-base-container"
    valid_role = RoleRequirement.role_yaml_parse(valid_role)
    assert valid_role["name"] == "ansible-base-container"
    assert valid_role["version"] == "v1.0.0"

# Generated at 2022-06-23 07:00:11.194664
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    requirements = RoleRequirement()

# Generated at 2022-06-23 07:00:22.115074
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # test RoleRequirement.repo_url_to_role_name
    assert RoleRequirement.repo_url_to_role_name(None) == None
    assert RoleRequirement.repo_url_to_role_name("") == None
    assert RoleRequirement.repo_url_to_role_name("any_string") == "any_string"
    assert RoleRequirement.repo_url_to_role_name("http://github.com/owner/repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://github.com/owner/repo.git") == "repo"

# Generated at 2022-06-23 07:00:24.305247
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    rr = RoleRequirement()
    print("Class RoleRequirement: %s" % str(rr))
    assert isinstance(rr, RoleRequirement)


# Generated at 2022-06-23 07:00:35.360372
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com:~repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-modules-core.git') == 'ansible-modules-core'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-modules-core.git,v2.0') == 'ansible-modules-core'

# Generated at 2022-06-23 07:00:47.127051
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # validate handling of empty row
    r = RoleRequirement.role_yaml_parse('')
    assert r == {}

    # validate handling of string
    r = RoleRequirement.role_yaml_parse('geerlingguy.apache')
    assert r == {'name': 'apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': None}

    r = RoleRequirement.role_yaml_parse('ansible-galaxy.nginx')
    assert r == {'name': 'nginx', 'scm': None, 'src': 'ansible-galaxy.nginx', 'version': None}

    r = RoleRequirement.role_yaml_parse('git+git://git.example.com/repos/ansible-galaxy.nginx.git')

# Generated at 2022-06-23 07:00:53.812721
# Unit test for constructor of class RoleRequirement

# Generated at 2022-06-23 07:01:03.185706
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os.path
    from ansible.module_utils._text import to_native

    options = dict(
        src='git+https://github.com/geerlingguy/ansible-role-apache.git',
        version='master',
        scm='git',
        name='geerlingguy.apache'
    )

    r = RoleRequirement.scm_archive_role(**options)
    assert to_native(r.get('src')) == options['src']
    assert to_native(r.get('name')) == options['name']
    assert to_native(r.get('path')) == os.path.join('geerlingguy', 'ansible-role-apache')
    assert to_native(r.get('version')) == options['version']

# Generated at 2022-06-23 07:01:05.068448
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    assert role_requirement is not None


# Generated at 2022-06-23 07:01:13.954074
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_data = {
        "name": "test1",
        "version": "v1",
        "src": "git@gitlab.com:ansible-role-test/test1.git",
        "scm": "git"
    }

    output = RoleRequirement.role_yaml_parse(test_data)
    assert output["name"] == test_data["name"]
    assert output["version"] == test_data["version"]
    assert output["src"] == test_data["src"]
    assert output["scm"] == test_data["scm"]



# Generated at 2022-06-23 07:01:26.403971
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = 'https://github.com/example/foobar.git'
    role_info = RoleRequirement.scm_archive_role(src, keep_scm_meta=True)
    assert role_info == {'dest': 'foobar', 'name': 'foobar', 'result': '', 'scm': True, 'src': 'https://github.com/example/foobar.git', 'version': 'HEAD'}
    role_info = RoleRequirement.scm_archive_role(src, 'git', 'foobar_name', 'master', keep_scm_meta=True)

# Generated at 2022-06-23 07:01:36.902377
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/some/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/some/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git+git@github.com:some/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@github.com:some/repo.git") == "repo"

# Generated at 2022-06-23 07:01:47.977334
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # Create a dummy dir and cd into it
    tmp_dir = os.path.realpath( tempfile.mkdtemp() )
    os.chdir( tmp_dir )

    # Run the method scm_archive_role with different values of parameters
    # NOTE: src is non-empty so we get a download attempt
    # NOTE: no valid inventory path is required, thus default argument is fine
    # NOTE: we may want to set up a test repo eventually

    src = "https://github.com/robertdebock/ansible-role-debug"
    version = "HEAD"

    # Testing with src and version
    role = RoleRequirement.scm_archive_role(src=src, version=version, scm='git')
    assert role.version == version
    assert role.name == os.path.basename(src)

   

# Generated at 2022-06-23 07:01:58.282646
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # test with repo_url
    role_req = RoleRequirement()
    assert role_req.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role_req.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert role_req.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz,v1.0.0") == "repo"
    assert role_req.repo_url_to_role_name("http://git.example.com/repos/repo-with-comma,v1.0.0") == "repo-with-comma"

# Generated at 2022-06-23 07:02:09.342806
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.ntp') == {'name': 'geerlingguy.ntp', 'scm': None, 'src': 'geerlingguy.ntp', 'version': None}
    assert RoleRequirement.role_yaml_parse('git+https://github.com/geerlingguy/ansible-role-ntp.git') == {'name': 'ansible-role-ntp', 'scm': 'git', 'src': 'https://github.com/geerlingguy/ansible-role-ntp.git', 'version': None}

# Generated at 2022-06-23 07:02:20.735671
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse('https://github.com/someuser/somerole.git')
    assert role['src'] == 'https://github.com/someuser/somerole.git'
    assert role['name'] == 'somerole'
    assert role['scm'] is None
    assert role['version'] is None

    role = RoleRequirement.role_yaml_parse('https://github.com/someuser/somerole.git,1.0')
    assert role['src'] == 'https://github.com/someuser/somerole.git'
    assert role['name'] == 'somerole'
    assert role['scm'] is None
    assert role['version'] == '1.0'


# Generated at 2022-06-23 07:02:31.630459
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import ansible.utils.module_docs as module_docs
    import os.path

    display.verbosity = 3

    test_role_name = 'test_RoleRequirement_scm_archive_role'
    test_role_repo_url = 'https://github.com/username/fakerepo'
    test_role_dest = 'imported/roles/' + test_role_name

    # Remove the role directory if it exists
    try:
        shutil.rmtree(test_role_dest)
    except (IOError, OSError):
        pass
    # Remove the temporary file with the zip file
    try:
        os.remove(scm_archive_resource.temp_zipfile())
    except (IOError, OSError):
        pass

    # Test with default parameters: scm='

# Generated at 2022-06-23 07:02:42.630215
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    INVALID_SPECS = [
        # type, spec, error msg
        ('Too many commas', 'galaxy.role,v1.0,name', r'Proper format'),
        ('Extra key', {'role': 'galaxy.role', 'version': 'v1.0', 'extra_key': 'oops'}, r'Unexpected key.*extra_key'),
        ('Old style', {'role': 'galaxy.role,v1.0,name'}, r'Invalid old style role requirement.+name'),
        ('No specification', None, r'No specification given'),
    ]

    for (type, spec, error_msg) in INVALID_SPECS:
        display.display("Testing role requirement %s, spec %s" % (type, spec))

# Generated at 2022-06-23 07:02:46.665491
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    display.verbosity = 2
    RoleRequirement.scm_archive_role('https://github.com/ansible/ansible-examples.git', scm='git', name=None, version='HEAD', keep_scm_meta=True)


if __name__ == '__main__':
    test_RoleRequirement()

# Generated at 2022-06-23 07:02:56.774312
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Test function with HTTP URLs

    # Test with path presented as is, without any extension
    inp = "http://git.myserver.com/repos/repo"
    out = RoleRequirement.repo_url_to_role_name(inp)
    assert out == "repo", "Expect %s, got %s" % ("repo", out)

    # Test with path presented as is, with .git extension
    inp = "http://git.myserver.com/repos/repo.git"
    out = RoleRequirement.repo_url_to_role_name(inp)
    assert out == "repo", "Expect %s, got %s" % ("repo", out)

    # Test with path presented as is, with .tar.gz extension

# Generated at 2022-06-23 07:03:09.916229
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # old style
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git') == dict(name="repo", scm="git", version=None, src="http://git.example.com/repos/repo.git")
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,v1') == dict(name="repo", scm="git", version="v1", src="http://git.example.com/repos/repo.git")

# Generated at 2022-06-23 07:03:14.982660
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # Test default initialization of class RoleRequirement
    text = 'RoleRequirement()'
    print(text)
    my_obj = RoleRequirement()
    print(my_obj)

    # Test normal initialization of class RoleRequirement
    text = 'RoleRequirement(scm=Git)'
    print(text)
    my_obj = RoleRequirement(scm=Git)
    print(my_obj)

    assert my_obj is not None

# Generated at 2022-06-23 07:03:25.869995
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    ret = RoleRequirement.repo_url_to_role_name(
        'http://git.example.com/repos/repo.git'
    )
    assert ret == 'repo'

    ret = RoleRequirement.repo_url_to_role_name(
        'http://git.example.com/repos/repo.git,'
    )
    assert ret == ''

    ret = RoleRequirement.repo_url_to_role_name(
        'http://git.example.com/repos/repo.git,master'
    )
    assert ret == ''

    ret = RoleRequirement.repo_url_to_role_name(
        'http://git.example.com/repos/repo.git,master,my_repo'
    )

# Generated at 2022-06-23 07:03:28.790761
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # call the method
    result = RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git")

    # assert the result
    assert result == "repo"



# Generated at 2022-06-23 07:03:36.134594
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test case 1: old style
    test_data_1 = "galaxy.role"
    expect_result_1 = {
        "name": "galaxy.role",
        "scm": None,
        "src": "galaxy.role",
        "version": None,
    }
    result_1 = RoleRequirement.role_yaml_parse(test_data_1)
    assert result_1 == expect_result_1

    # test case 2: old style
    test_data_2 = "galaxy.role,v2.0"
    expect_result_2 = {
        "name": "galaxy.role",
        "scm": None,
        "src": "galaxy.role",
        "version": "v2.0",
    }
    result_2 = RoleRequirement.role_

# Generated at 2022-06-23 07:03:48.100472
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    candidate = RoleRequirement.scm_archive_role('git+https://github.com/ansible/role-test-repo-1.git', scm='git', name='test', version='HEAD', keep_scm_meta=False)
    assert candidate == ('/tmp/ansible_role_test-ed2a74af', '/tmp/ansible_role_test-ed2a74af', 'gzip')
    candidate = RoleRequirement.scm_archive_role('git+https://github.com/ansible/role-test-repo-2.git', scm='git', name='test', version='HEAD', keep_scm_meta=False)

# Generated at 2022-06-23 07:04:01.206200
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    r = RoleRequirement()

# Generated at 2022-06-23 07:04:12.049413
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 07:04:24.098370
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_yaml_parse = RoleRequirement.role_yaml_parse

    # Test: Invalid role line.
    role = 'role1,role2,role3'
    expected = { 'role': 'role1,role2,role3' }
    assert role_yaml_parse(role) == expected, \
        'Dictionary returned by role_yaml_parse for invalid role line is not as expected.'

    # Test: Role line with role name only.
    role = 'role_name'
    expected = { 'src': 'role_name', 'name': 'role_name', 'scm': 'git', 'version': '' }
    assert role_yaml_parse(role) == expected, \
        'Dictionary returned by role_yaml_parse for role line with role name only is not as expected.'

    # Test: Role

# Generated at 2022-06-23 07:04:35.210454
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 07:04:46.760275
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    rr = RoleRequirement()
    assert rr.role_yaml_parse(dict(role="foobar")) == dict(name="foobar", src="foobar", version="", scm=None)
    assert rr.role_yaml_parse(dict(role="foobar,v1.0")) == dict(name="foobar", src="foobar", version="v1.0", scm=None)
    assert rr.role_yaml_parse(dict(role="foobar,v1.0,name")) == dict(name="name", src="foobar", version="v1.0", scm=None)
    assert rr.role_yaml_parse("foobar") == dict(name="foobar", src="foobar", version="", scm=None)
    assert rr.role_yaml_parse

# Generated at 2022-06-23 07:04:54.326013
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    r = RoleRequirement()
    # uri without '://' and '@'
    assert r.repo_url_to_role_name('repo') == 'repo'
    # '://' in uri
    assert r.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'
    # '@' in uri
    assert r.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'


# Generated at 2022-06-23 07:04:58.672228
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_file_path = temp_dir + "/test_role.tar.gz"
        RoleRequirement.scm_archive_role("https://github.com/ansible/ansible-examples.git", scm='git', name=None, version='master', keep_scm_meta=True, path=temp_file_path)
        assert os.path.isfile(temp_file_path)

# Generated at 2022-06-23 07:05:02.421328
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    result = RoleRequirement.scm_archive_role(src='https://github.com/ansible/ansible-modules-extras.git')
    assert result is not None

# Generated at 2022-06-23 07:05:13.074056
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    role_requirement = RoleRequirement()
    role_info = role_requirement.scm_archive_role('https://github.com/geerlingguy/ansible-role-apache')
    assert role_info['name'] == "ansible-role-apache"
    
    role_info = role_requirement.scm_archive_role('git+https://github.com/geerlingguy/ansible-role-apache')
    assert role_info['name'] == "ansible-role-apache"
    
    role_info = role_requirement.scm_archive_role('https://github.com/geerlingguy/ansible-role-apache,v0.0.1')
    assert role_info['name'] == "ansible-role-apache"

# Generated at 2022-06-23 07:05:25.672717
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Init
    rr = RoleRequirement()

    # Test the method repo_url_to_role_name
    assert rr.repo_url_to_role_name('a/b/c') == 'c'
    assert rr.repo_url_to_role_name('a+b+c') == 'c'
    assert rr.repo_url_to_role_name('a/b/c.git') == 'c'

    # Test the method role_yaml_parse
    assert rr.role_yaml_parse('a')['name'] == 'a'
    assert rr.role_yaml_parse('a')['scm'] == None
    assert rr.role_yaml_parse('a')['src'] == 'a'
    assert rr.role_yaml_parse