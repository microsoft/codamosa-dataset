

# Generated at 2022-06-23 06:55:32.206424
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    url = "https://github.com/bennojoy/nginx"
    role = "nginx"
    repo = RoleRequirement.repo_url_to_role_name(url)
    assert(role == repo)


# Generated at 2022-06-23 06:55:34.199115
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    requirement = RoleRequirement()
    assert requirement is not None


# Generated at 2022-06-23 06:55:35.122772
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement() is not None


# Generated at 2022-06-23 06:55:40.301422
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("github.com/foo/bar") == "bar"
    assert RoleRequirement.repo_url_to_role_name("git+ssh://user@foo.example.com/repos/bar,v1.0") == "bar"
    assert RoleRequirement.repo_url_to_role_name("bar") == "bar"


# Generated at 2022-06-23 06:55:50.840763
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    r = RoleRequirement.role_yaml_parse('geerlingguy.nginx,2.2.0,some_awesome_role')
    assert r['src'] == 'geerlingguy.nginx'
    assert r['scm'] is None
    assert r['name'] == 'some_awesome_role'
    assert r['version'] == '2.2.0'

    r = RoleRequirement.role_yaml_parse('geerlingguy.nginx,some_awesome_role')
    assert r['src'] == 'geerlingguy.nginx'
    assert r['scm'] is None
    assert r['name'] == 'some_awesome_role'
    assert r['version'] == ''


# Generated at 2022-06-23 06:56:01.485628
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    """Test scm_archive_role method of class RoleRequirement"""

    # Test with name provided, and without version specified
    foo_name = 'foo'
    foo = 'https://github.com/example/foo.git'
    _, version = RoleRequirement.scm_archive_role(foo, name=foo_name)
    assert version == 'HEAD'

    # Test with name and version provided
    bar_name = 'bar'
    bar_version = 'v2.3.3'
    bar = 'https://github.com/example/bar.git,%s' % bar_version
    _, version = RoleRequirement.scm_archive_role(bar, name=bar_name)
    assert version == bar_version

    # Test without name, and without version specified

# Generated at 2022-06-23 06:56:02.424720
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    requirement = RoleRequirement()
    assert requirement
    assert "RoleRequirement" in str(requirement)

test_RoleRequirement()

# Generated at 2022-06-23 06:56:06.913614
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = "https://github.com/ansible/ansible-examples"
    scm = 'git'
    name = None
    version = 'HEAD'
    keep_scm_meta = False
    RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)


# Generated at 2022-06-23 06:56:16.142213
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 06:56:25.931284
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    failmsg = "Invalid role line. Proper format is 'role_name[,version[,name]]'"
    success = []
    fail = []
    # Failing Tests
    fail.append(dict(fargs=dict(role='git+https://github.com/jdauphant/ansible-role-apache.git'),
                    fmsg="Invalid old style role requirement: git+https://github.com/jdauphant/ansible-role-apache.git"))
    fail.append(dict(fargs=dict(role='https://github.com/jdauphant/ansible-role-apache.git'),
                    fmsg=failmsg))
    fail.append(dict(fargs=dict(role=','), fmsg=failmsg))

# Generated at 2022-06-23 06:56:33.420835
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Old style
    assert RoleRequirement.role_yaml_parse('http://example.com/path/to/role.tar.gz') == {'name': 'role', 'src': 'http://example.com/path/to/role.tar.gz', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('http://example.com/path/to/role.tar.gz,v0.1') == {'name': 'role', 'src': 'http://example.com/path/to/role.tar.gz', 'scm': None, 'version': 'v0.1'}

# Generated at 2022-06-23 06:56:45.318215
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-23 06:56:50.920560
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # testing git repo_url to role name conversion
    assert 'repo' == RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git')
    # testing svn repo_url to role name conversion
    assert 'repo' == RoleRequirement.repo_url_to_role_name('http://svn.example.com/repos/repo')

# Generated at 2022-06-23 06:56:57.240083
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile
    import shutil
    import os.path
    import os
    src = os.path.abspath(os.path.dirname(__file__)+'/../../../')
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)
    keep_scm_meta = False
    (archive_file, checksum) = RoleRequirement.scm_archive_role(src, scm='git', name='ansible', version='HEAD', keep_scm_meta=keep_scm_meta)
    archive_basedir = os.path.dirname(archive_file)
    assert(os.path.basename(archive_basedir) == 'ansible')
    archive_directory = os.path.splitext(archive_file)[0]

# Generated at 2022-06-23 06:57:07.778494
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # Test with Git
    name = "nginx"
    src = "git+https://github.com/jtyr/ansible-nginx.git"
    version = "v1.0.0"
    role = RoleRequirement.scm_archive_role(src=src, name=name, version=version)
    assert role == {'src': 'https://github.com/jtyr/ansible-nginx', 'scm': 'git', 'name': name, 'version': version}
    src = "git+https://github.com/jtyr/ansible-nginx.git,v1.0.0"
    role = RoleRequirement.scm_archive_role(src=src, name=name, version=version)

# Generated at 2022-06-23 06:57:20.408798
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # tests below show the expected output for 3 types of inputs

    # 1. a string input
    # 2. a dictionary object with only the role key
    # 3. a dictionary object with all the keys

    assert RoleRequirement.role_yaml_parse("something.tar.gz") == {'name': 'something', 'scm': None, 'src': 'something.tar.gz', 'version': None}
    assert RoleRequirement.role_yaml_parse("something.tar.gz") == {'name': 'something', 'scm': None, 'src': 'something.tar.gz', 'version': None}

# Generated at 2022-06-23 06:57:27.177862
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.galaxy import Galaxy
    from ansible.constants import DEFAULT_GALAXY_IGNORE_CERTS
    from ansible.config.manager import ConfigManager
    from ansible.galaxy.role import GalaxyRole
    import os
    import shutil
    import tempfile

    ansible_config = ConfigManager(os.path.join(os.path.dirname(__file__), 'ansible.cfg'))

    galaxy_ignore_certs = DEFAULT_GALAXY_IGNORE_CERTS
    if ansible_config.setting_is_true('GALAXY_IGNORE_CERTS'):
        galaxy_ignore_certs = True
    elif ansible_config.setting_is_false('GALAXY_IGNORE_CERTS'):
        galaxy_ignore_

# Generated at 2022-06-23 06:57:38.821066
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # NOTE(retr0h): Testing RoleRequirement scm_archive_role method.
    #               It should return a full path to the source.
    display.display("Testing RoleRequirement.scm_archive_role")
    INPUT_GIT_SRC_1 = 'git+https://github.com/anoopsahni/stress-docker.git'
    INPUT_SCM_1 = 'git'
    ansible_role_1_path = RoleRequirement.scm_archive_role(INPUT_GIT_SRC_1, scm=INPUT_SCM_1)
    display.display("Testing RoleRequirement.scm_archive_role(git) passed.")

    display.display("Testing RoleRequirement.scm_archive_role source name")

# Generated at 2022-06-23 06:57:49.192302
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,1.0.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,1.0.0,renamed') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,1.0.0,renamed,foo') == 'repo'

# Generated at 2022-06-23 06:57:59.960983
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    print(RoleRequirement.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-jenkins"))
    # => ansible-role-jenkins
    print(RoleRequirement.repo_url_to_role_name("ansible-role-jenkins"))
    # => ansible-role-jenkins
    print(RoleRequirement.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-jenkins,1.6.2,jenkins"))
    # => 1.6.2
    print(RoleRequirement.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-jenkins,1.6.2"))
    # => 1.6.2

# Generated at 2022-06-23 06:58:10.889665
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    class MockedRoleRequirement(RoleRequirement):
        def __init__(self):
            pass

    test_repo_url_to_role_name_succeed = [
        ( 'http://git.example.com/repos/repo.git', 'repo' ),
        ( 'https://github.com/foo/bar.git', 'bar' ),
        ( 'git@github.com:foo/bar.git', 'bar' ),
        ( 'git+ssh://git@github.com/foo/bar.git', 'bar.git' ),
    ]

    test_repo_url_to_role_name_failed = [
        ( 'git+ssh://git@github.com/foo/bar.git,v1.0.1', '' ),
    ]


# Generated at 2022-06-23 06:58:21.558378
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    '''
    Unit test for constructor of class RoleRequirement
    '''

    #
    # Test case 1:
    #
    # Correct "role" key
    #

    role_requirement_1 = RoleRequirement()
    result_role_requirement_1 = role_requirement_1.role_yaml_parse({"role": "test_role_1"})

    if result_role_requirement_1["name"] != "test_role_1" or result_role_requirement_1["src"] != "test_role_1" or result_role_requirement_1["scm"] != None or result_role_requirement_1["version"] != None:
        raise AssertionError("Unit test for \"role_requirement.role_yaml_parse\" (correct \"role\" key) failed!")

   

# Generated at 2022-06-23 06:58:28.913091
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_name = 'jdauphant.nginx'
    galaxy_info = 'https://github.com/jdauphant/ansible-role-nginx.git'

    role = RoleRequirement()
    role.role_yaml_parse(role_name)
    role.role_yaml_parse(None)
    role.role_yaml_parse(galaxy_info)
    role.scm_archive_role(galaxy_info)

# Generated at 2022-06-23 06:58:30.523879
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    r = RoleRequirement()
    assert r


# Generated at 2022-06-23 06:58:40.702894
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test to pass the proper format according to Ansible Galaxy
    # {role: <role_name[,version][,name]>}
    role = dict(role='geerlingguy.docker,1.0.0,geerlingguy')
    expected = dict(name='geerlingguy.docker', src=None, scm=None, version='1.0.0')
    result = RoleRequirement.role_yaml_parse(role)
    if result != expected:
        raise AssertionError('The returned dictionary is not the expected one.')

    # Test to pass a wrong format
    role = dict(role='geerlingguy.docker,1.0.0,geerlingguy,something')

# Generated at 2022-06-23 06:58:49.773866
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('ansible-role-nginx') == 'ansible-role-nginx'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-nginx.git') == 'ansible-role-nginx'
    assert RoleRequirement.repo_url_to_role_name('http://github.com/geerlingguy/ansible-role-nginx.git') == 'ansible-role-nginx'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-mariadb,v1.0.0') == 'ansible-role-mariadb'
    assert RoleRequirement.re

# Generated at 2022-06-23 06:58:59.369982
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml_parse = RoleRequirement.role_yaml_parse

    role = role_yaml_parse('foo')
    assert role['name'] == 'foo'
    assert role['src'] == 'foo'
    assert role['version'] is None

    role = role_yaml_parse('foo,v1.0')
    assert role['name'] == 'foo'
    assert role['src'] == 'foo'
    assert role['version'] == 'v1.0'

    role = role_yaml_parse('foo,v1.0,bar')
    assert role['name'] == 'bar'
    assert role['src'] == 'foo'
    assert role['version'] == 'v1.0'


# Generated at 2022-06-23 06:59:10.476880
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name(
            'http://github.com/ansible/ansible-examples.git') == 'ansible-examples'
    assert RoleRequirement.repo_url_to_role_name(
            'https://github.com/ansible/ansible-examples.git') == 'ansible-examples'
    assert RoleRequirement.repo_url_to_role_name(
            'git@github.com:ansible/ansible-examples.git') == 'ansible-examples'
    assert RoleRequirement.repo_url_to_role_name(
            'https://github.com/ansible/ansible-examples.git,v1.0') == 'ansible-examples'
    assert RoleRequirement.repo_url

# Generated at 2022-06-23 06:59:20.252976
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    assert role_requirement.repo_url_to_role_name('git@gitlab.example.com/namespace/name.git') == 'name'
    assert role_requirement.repo_url_to_role_name('https://github.com/namespace/name') == 'name'
    assert role_requirement.repo_url_to_role_name('git@gitlab.example.com/namespace/name,testbranch') == 'name'
    assert role_requirement.repo_url_to_role_name('https://github.com/namespace/name,testbranch') == 'name'

# Generated at 2022-06-23 06:59:25.327327
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    from ansible.errors import AnsibleError

    # a dict with a proper specification should be unchanged
    assert RoleRequirement.role_yaml_parse({'role': 'git+https://github.com/jdauphant/ansible-role-nginx.git,v1.0,jdauphant.nginx'}) == {'role': 'git+https://github.com/jdauphant/ansible-role-nginx.git,v1.0,jdauphant.nginx'}

    # a dict with an invalid role entry should be changed

# Generated at 2022-06-23 06:59:30.143688
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("https://github.com/nickjj/ansible-elasticsearch.git") == "ansible-elasticsearch"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/nickjj/ansible-elasticsearch/tarball/v1.5.1") == "ansible-elasticsearch"

# Generated at 2022-06-23 06:59:42.041191
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    expected_output = {
        '__ansible_galaxy_role_data__': {
            'scm': 'git',
            'src': 'git@git.example.com:owner/ansible-role-test-repo.git',
            'version': 'master',
        },
        '__ansible_galaxy_role_name__': 'test_repo'
    }
    role = RoleRequirement.scm_archive_role("git@git.example.com:owner/ansible-role-test-repo.git")
    assert role == expected_output
    role = RoleRequirement.scm_archive_role("git@git.example.com:owner/ansible-role-test-repo.git", version="master")
    assert role == expected_output
    role = RoleRequirement.scm_

# Generated at 2022-06-23 06:59:45.908766
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # should fail with error
    try:
        req = RoleRequirement()
    except NotImplementedError as e:
        assert e == "RoleRequirement class cannot be used directly, please use GalaxyRole instead"

    # should pass
    req = RoleRequirement()

# Generated at 2022-06-23 06:59:54.013351
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    data = [
        'foo',
        'foo,v1',
        'foo,v1,dest',
        {
            'src': 'foo',
        },
        {
            'src': 'foo,v1,bar',
        },
    ]

# Generated at 2022-06-23 07:00:03.549997
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git') == {
        'name': 'repo',
        'src': 'http://git.example.com/repos/repo.git',
        'scm': None,
        'version': None,
    }

    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,v1.0') == {
        'name': 'repo',
        'src': 'http://git.example.com/repos/repo.git',
        'scm': None,
        'version': 'v1.0',
    }


# Generated at 2022-06-23 07:00:15.355774
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style format
    #
    # This should raise AnsibleError
    # because for old style role requirement,
    # the role string should not have "," in it.
    test_role1 = "galaxy.role,version,name"
    try:
        RoleRequirement.role_yaml_parse(test_role1)
    except AnsibleError:
        pass
    else:
        assert False, "Expected AnsibleError, raised no exception."

    # Test for new style format
    #
    # This should raise AnsibleError
    # because the role string should have 3 parts
    # (separated by ",")
    # for new style role requirement.
    test_role2 = "role_name,version"

# Generated at 2022-06-23 07:00:24.961228
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # parsing input that ca be handled by old parsing
    assert RoleRequirement.role_yaml_parse('A.B,master') == dict(name='A.B', src='A.B', scm=None, version='master')
    assert RoleRequirement.role_yaml_parse('A.B,master,newname') == dict(name='newname', src='A.B', scm=None, version='master')
    assert RoleRequirement.role_yaml_parse('A.B') == dict(name='A.B', src='A.B', scm=None, version=None)

# Generated at 2022-06-23 07:00:29.209211
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('foo,1,blah') == {'name': 'blah', 'version': '1', 'src': 'foo'}
    assert RoleRequirement.role_yaml_parse('foo,2') == {'name': 'foo', 'version': '2', 'src': 'foo'}
    assert RoleRequirement.role_yaml_parse('foo') == {'name': 'foo', 'version': '', 'src': 'foo'}
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,2') == {'name': 'repo', 'version': '2', 'src': 'http://git.example.com/repos/repo.git'}

# Generated at 2022-06-23 07:00:33.336855
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    src_repo = 'https://github.com/ansible/ansible-modules-extras'
    src_repo_name = 'ansible-modules-extras'
    src_role = 'https://github.com/ansible/ansible-modules-extras,devel'
    src_role_name = 'ansible-modules-extras'
    src_role_v = 'devel'
    src_bad = 'https://github.com/ansible/ansible-modules-extras,devel,role_name'
    src_role_name_mismatch = 'https://github.com/ansible/ansible-modules-extras,devel,role_name'

    display.verbosity = 3
    # FIXME: write tests for invalid source URLs:
    # http://ansible.cc,
   

# Generated at 2022-06-23 07:00:45.536862
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://github.com/user/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/user/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('user@github.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo,1.2') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo,1.2,role') == 'repo'

# Generated at 2022-06-23 07:00:53.168819
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # Test where local tar.gz file is downloaded, but gets the name of the tarball
    src, scm, name, version, keep_scm_meta = "ansible/ansible", None, None, None, None
    RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)
     
    # Test where local tar.gz file is downloaded, but gets the name of the tarball
    src, scm, name, version, keep_scm_meta = "ansible-galaxy/ansible-galaxy.tar.gz", None, None, None, None
    RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)
     
    # Test where local tar.gz file is downloaded, but gets the name of the tarball


# Generated at 2022-06-23 07:01:02.761748
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    req1 = RoleRequirement.role_yaml_parse('user.role')
    assert req1['name'] == 'user.role', req1['name']
    assert req1['version'] == None, req1['version']
    assert req1['src'] == 'user.role', req1['src']

    req2 = RoleRequirement.role_yaml_parse('user.role,v2')
    assert req2['name'] == 'user.role', req2['name']
    assert req2['version'] == 'v2', req2['version']
    assert req2['src'] == 'user.role', req2['src']

    req3 = RoleRequirement.role_yaml_parse('user.role,v2,myrole')
    assert req3['name'] == 'myrole', req3['name']

# Generated at 2022-06-23 07:01:14.710632
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # Test case: src = 'https://github.com/michel-slm/ansible-role-mediawiki.git', scm = 'git', name = None, version = 'HEAD', keep_scm_meta = False
    src = 'https://github.com/michel-slm/ansible-role-mediawiki.git'
    scm = 'git'
    name = None
    version = 'HEAD'
    keep_scm_meta = False
    role = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)
    src_clone_path = role[0]
    name = role[1]
    # src_clone_path = /home/user/.ansible/tmp/ansible-tmp-1498520343.37-262814301133360

# Generated at 2022-06-23 07:01:26.692658
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    import os, shutil
    # create a directory to be used as the download_dir
    download_dir = os.path.join('/tmp', 'ansible-test-role-download')
    if os.path.exists(download_dir):
        shutil.rmtree(download_dir)
    os.makedirs(download_dir)

    # create an other directory to be used as cache_dir
    cache_dir = os.path.join('/tmp', 'ansible-test-role-cache')
    if os.path.exists(cache_dir):
        shutil.rmtree(cache_dir)
    os.makedirs(cache_dir)

    # define a test role and call the method

# Generated at 2022-06-23 07:01:37.148266
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v0.0.1') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v0.0.1,foobar') == 'repo'

# Generated at 2022-06-23 07:01:48.124320
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.utils.display import Display

    display = Display()
    display.verbosity = 4


# Generated at 2022-06-23 07:01:54.765939
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('git+https://url.to/something.git') == {'name': 'something', 'src': 'https://url.to/something.git', 'scm': 'git', 'version': None}
    assert RoleRequirement.role_yaml_parse('https://url.to/something.git') == {'name': 'something', 'src': 'https://url.to/something.git', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('url.to/something,1.2.3,something_else') == {'name': 'something_else', 'src': 'url.to/something', 'scm': None, 'version': '1.2.3'}

# Generated at 2022-06-23 07:01:58.293954
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role = 'geerlingguy.apache,1.2.3,my_role'
    result = role_requirement.role_yaml_parse(role)
    assert result['src'] == 'geerlingguy.apache'

# Generated at 2022-06-23 07:02:09.382902
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    display.display("Unit test for role_requirement.py")

    role_req = RoleRequirement()

    # test role_yaml_parse
    # one argument
    role = "http://bitbucket.org/willthames/ansible-git-repo"
    name = "ansible-git-repo"
    src = "http://bitbucket.org/willthames/ansible-git-repo"
    version = None
    scm = None
    expect_result = {'name': name, 'src': src, 'scm': scm, 'version': version}
    assert(role_req.role_yaml_parse(role) == expect_result), 'role_yaml_parse fail'

    # two arguments

# Generated at 2022-06-23 07:02:15.272389
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('https://github.com/robertdebock/ansible-role-kernel') == 'ansible-role-kernel'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/robertdebock/ansible-role-kernel.git') == 'ansible-role-kernel'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/robertdebock/ansible-role-kernel,1.0.0') == 'ansible-role-kernel'
    assert RoleRequirement.repo_url_to_role_name('git@github.com:robertdebock/ansible-role-bootstrap') == 'ansible-role-bootstrap'
    assert RoleRequirement.repo_

# Generated at 2022-06-23 07:02:28.203273
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.galaxy.role import GalaxyRole
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import tempfile

    role_requirement = RoleRequirement()
    role_file = role_requirement.scm_archive_role(src='git+https://github.com/geerlingguy/ansible-role-apache', name='ansible-role-apache', version='0.1.1', scm='git')

    dest = tempfile.mkdtemp(prefix='ansible-config-test-')
    role_dir = role_file.remote_path(dest)
    galaxy_role = GalaxyRole(role_dir)


# Generated at 2022-06-23 07:02:34.753269
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_definition = RoleRequirement.role_yaml_parse("role_name,version,name")
    assert isinstance(role_definition, dict)
    assert 'name' in role_definition
    assert 'scm' in role_definition
    assert 'src' in role_definition
    assert 'version' in role_definition

if __name__ == '__main__':
    test_RoleRequirement()

# Generated at 2022-06-23 07:02:45.000137
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_path = "/home/admin/playbooks/roles/helloworld"
    role_name = "helloworld"
    role_requirement = RoleRequirement(role_path, role_name)
    role_requirement.set_role_path(role_path)
    print("Role Path: " + role_requirement.role_path)
    print("Role Name: " + role_requirement.role_name)
    print("Role Version: " + role_requirement.role_version)

if __name__ == '__main__':
    test_RoleRequirement()

# Generated at 2022-06-23 07:02:53.925267
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    repo_url = 'https://github.com/jboss-openshift/openshift-notes-to-self/archive/master.zip'
    assert RoleRequirement.repo_url_to_role_name(repo_url) == 'openshift-notes-to-self'

    repo_url = 'git+https://github.com/jboss-openshift/openshift-notes-to-self.git'
    assert RoleRequirement.repo_url_to_role_name(repo_url) == 'openshift-notes-to-self'

    repo_url = 'git+https://github.com/jboss-openshift/openshift-notes-to-self,v1.0.0'

# Generated at 2022-06-23 07:03:01.840894
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_source = RoleRequirement.role_yaml_parse('role,version,name')
    assert role_source['name'] == 'name'
    assert role_source['scm'] is None
    assert role_source['src'] == 'role'
    assert role_source['version'] == 'version'
    assert isinstance(role_source, dict)

    role_source = RoleRequirement.role_yaml_parse('https://github.com/user/repo.git,version,name')
    assert role_source['name'] == 'name'
    assert role_source['scm'] == 'git'
    assert role_source['src'] == 'https://github.com/user/repo.git'
    assert role_source['version'] == 'version'
    assert isinstance(role_source, dict)

    role_

# Generated at 2022-06-23 07:03:02.604882
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert not RoleRequirement()


# Generated at 2022-06-23 07:03:11.068230
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_obj = RoleRequirement()
    role = 'git+https://github.com/ansible/role-examples,v0.3.0'
    assert role_obj.role_yaml_parse(role) == {'name': 'role-examples', 'scm': 'git', 'src': 'https://github.com/ansible/role-examples,v0.3.0', 'version': None}
    role = 'git+https://github.com/ansible/role-examples'
    assert role_obj.role_yaml_parse(role) == {'name': 'role-examples', 'scm': 'git', 'src': 'https://github.com/ansible/role-examples', 'version': None}

# Generated at 2022-06-23 07:03:22.976736
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    repo_git = "git@github.com:ansible/ansible-examples.git"
    repo_http = "https://github.com/ansible/ansible-examples.git"
    repo_local = "/etc/my-ansible-roles/ansible-examples"

    ##########################################
    # Object RoleRequirement from string "git@github.com:ansible/ansible-examples.git"
    role_requirement = RoleRequirement.role_yaml_parse(repo_git)

    assert type(role_requirement) == dict
    assert role_requirement["name"] == "ansible-examples"
    assert role_requirement["src"] == repo_git
    assert role_requirement["scm"] == "git"
    assert role_requirement["version"] == ''

   

# Generated at 2022-06-23 07:03:32.258536
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # Test the construction of an RoleRequirement from a dictionary
    from collections import OrderedDict
    role = OrderedDict()
    role['name'] = 'myrole'
    role['version'] = 'v0.0.1'
    role['src'] = 'https://github.com/myuser/myrole.git'
    role['scm'] = 'git'
    role_requirement = RoleRequirement.role_yaml_parse(role)
    assert role_requirement['name'] == 'myrole'
    assert role_requirement['version'] == 'v0.0.1'
    assert role_requirement['src'] == 'https://github.com/myuser/myrole.git'
    assert role_requirement['scm'] == 'git'
    role_requirement = RoleRequirement.role_y

# Generated at 2022-06-23 07:03:38.003238
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Old style: { src: 'galaxy.role,version,name', other_vars: 'here' }
    test_dict = dict(src='foo.bar,1.0,other_name', other_vars='here')
    test_obj = RoleRequirement.role_yaml_parse(test_dict)
    assert test_obj['name'] == 'other_name'
    assert test_obj['src'] == 'foo.bar'
    assert test_obj['version'] == '1.0'
    assert test_obj['other_vars'] == 'here'

    # Old style: { src: 'galaxy.role,version', other_vars: 'here' }
    test_dict = dict(src='foo.bar,1.0', other_vars='here')

# Generated at 2022-06-23 07:03:48.485769
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    #test case 1
    r=RoleRequirement()
    #test case 2
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    #test case 3
    assert RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-examples.git') == 'ansible-examples'
    #test case 4
    assert RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-examples.git,-1.0') == 'ansible-examples'
    #test case 5

# Generated at 2022-06-23 07:04:01.560213
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    parsedRole = RoleRequirement.repo_url_to_role_name('http://url.com/repoName.tar.gz')
    assert parsedRole == 'repoName', 'Failed to parse role name from git repo url'
    parsedRole = RoleRequirement.repo_url_to_role_name('http://url.com/repoName.git')
    assert parsedRole == 'repoName', 'Failed to parse role name from git repo url'
    parsedRole = RoleRequirement.repo_url_to_role_name('https://url.com/repoName.git')
    assert parsedRole == 'repoName', 'Failed to parse role name from git repo url'

# Generated at 2022-06-23 07:04:12.167622
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # Test 1: expected success
    src = 'git@github.com:ansible-collections/community.general.git'
    scm = 'git'
    version = 'HEAD'
    keep_scm_meta = False
    role_path = RoleRequirement.scm_archive_role(src, scm, None, version, keep_scm_meta)
    assert os.path.exists(role_path)

    # Test 2: expected error
    src = 'https://github.com/ansible-collections/community.general.git/tree/master/src'
    try:
        RoleRequirement.scm_archive_role(src, scm, None, version, keep_scm_meta)
    except AnsibleError:
        pass

# Generated at 2022-06-23 07:04:15.748773
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = 'geerlingguy.java,1.7.0,name'
    role_yaml_parse = RoleRequirement.role_yaml_parse(role)
    assert role_yaml_parse['name'] == 'name'
    assert role_yaml_parse['role'] == 'geerlingguy.java'
    assert role_yaml_parse['src'] == 'geerlingguy.java'
    assert role_yaml_parse['version'] == '1.7.0'
    assert role_yaml_parse['scm'] is None
    assert role_yaml_parse['keep_scm_meta'] is False

# Test for scm_archive_resource for git

# Generated at 2022-06-23 07:04:28.761425
# Unit test for method scm_archive_role of class RoleRequirement

# Generated at 2022-06-23 07:04:39.787427
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    result = RoleRequirement.scm_archive_role("https://github.com/ansible/test1")
    assert result["name"] == "test1"
    assert result["path"] == "/Users/binwei/.ansible/roles/test1"

    result = RoleRequirement.scm_archive_role("https://github.com/ansible/test1", scm="git")
    assert result["name"] == "test1"
    assert result["path"] == "/Users/binwei/.ansible/roles/test1"

    result = RoleRequirement.scm_archive_role("https://github.com/ansible/test1", scm="git", name="hello")
    assert result["name"] == "hello"
    assert result["path"] == "/Users/binwei/.ansible/roles/hello"

   

# Generated at 2022-06-23 07:04:49.422864
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    role_name = RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-repo-name.git')
    assert role_name == 'ansible-role-repo-name'

    role_name = RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-repo-name,v1.0,geerlingguy.ansible-role-repo-name')
    assert role_name == 'geerlingguy.ansible-role-repo-name'

    role_name = RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-repo-name.git,v1.0')
    assert role

# Generated at 2022-06-23 07:04:50.817697
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # ToDo
    pass

# Generated at 2022-06-23 07:04:51.885894
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_req = RoleRequirement()


# Generated at 2022-06-23 07:05:02.253217
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert "role_name" == RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/role_name.git")
    assert "role_name" == RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/role_name")
    assert "role_name" == RoleRequirement.repo_url_to_role_name("user@git.example.com/repos/role_name.git")
    assert "role_name" == RoleRequirement.repo_url_to_role_name("role_name.tar.gz")
    assert "role_name" == RoleRequirement.repo_url_to_role_name("git@github.com:user/role_name.git")

# Generated at 2022-06-23 07:05:12.755733
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    fail = False

# Generated at 2022-06-23 07:05:19.728297
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    print('Testing RoleRequirement...')

    # Test normal flow
    print('--- Test normal flow: only src with role name')
    role_test = RoleRequirement()
    role_test.name = 'name_test'
    role_test.scm = 'scm_test'
    role_test.src = 'src_test'
    role_test.version = 'version_test'
    result_test = RoleRequirement.role_yaml_parse(role_test)
    assert result_test['name'] == 'name_test'
    assert result_test['scm'] == 'scm_test'
    assert result_test['src'] == 'src_test'
    assert result_test['version'] == 'version_test'

    # Test exceptional flow
    print('--- Test exceptional flow: role name is empty')
   

# Generated at 2022-06-23 07:05:21.849428
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    pass

# Generated at 2022-06-23 07:05:31.759930
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test = dict(role='geerlingguy.ntp')
    test = RoleRequirement.role_yaml_parse(test)
    assert test == dict(name='geerlingguy.ntp', src='geerlingguy.ntp', scm=None, version=None)

    test = dict(role='git+https://github.com/geerlingguy/ansible-role-ntp.git,v1.1')
    test = RoleRequirement.role_yaml_parse(test)
    assert test == dict(name='ansible-role-ntp', src='https://github.com/geerlingguy/ansible-role-ntp.git', scm='git', version='v1.1')
