

# Generated at 2022-06-23 06:55:26.084445
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    assert role is not None
    assert role.name is None
    assert role.role is None
    assert role.scm is None
    assert role.src is None
    assert role.version is None

    # Test RoleRequirement.role_yaml_parse
    role = RoleRequirement.role_yaml_parse(role_string)
    assert role['name'] == role_name
    assert role['scm'] == role_scm
    assert role['src'] == role_src
    assert role['version'] == role_version

    # Test RoleRequirement.repo_url_to_role_name
    name = RoleRequirement.repo_url_to_role_name(repo_url)
    assert name == role_name

    # Test RoleRequirement.scm_archive_role


# Generated at 2022-06-23 06:55:38.350520
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    print("Testing RoleRequirement.repo_url_to_role_name()")
    # Test URLs with https protocol

# Generated at 2022-06-23 06:55:40.861307
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    obj = RoleRequirement()
    assert obj is not None


# Generated at 2022-06-23 06:55:51.297870
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    fname = RoleRequirement.scm_archive_role(src='https://github.com/ansible/ansible-examples.git', scm='git', name='ansible-examples', version='HEAD')
    assert isinstance(fname, string_types)
    fname = RoleRequirement.scm_archive_role(src='https://github.com/ansible/roles-examples.git', name='roles-examples', version='HEAD')
    assert isinstance(fname, string_types)
    fname = RoleRequirement.scm_archive_role(src='https://github.com/ansible/ansible-examples.git', scm='git', version='HEAD')
    assert isinstance(fname, string_types)

# Generated at 2022-06-23 06:56:02.206993
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 06:56:14.013115
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement.role_yaml_parse('rhel-systemd') == {'name': 'rhel-systemd', 'version': '', 'src': 'rhel-systemd', 'scm': None}
    assert RoleRequirement.role_yaml_parse('rhel-systemd,1.0.0') == {'name': 'rhel-systemd', 'version': '1.0.0', 'src': 'rhel-systemd', 'scm': None}
    assert RoleRequirement.role_yaml_parse('rhel-systemd,1.0.0,systemd') == {'name': 'systemd', 'version': '1.0.0', 'src': 'rhel-systemd', 'scm': None}

# Generated at 2022-06-23 06:56:18.112782
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    result = RoleRequirement.scm_archive_role('https://github.com/geerlingguy/ansible-role-mongo.git', scm='git', version='1.0.0')
    assert result['name'] == 'mongo'
    assert result['version'] == '1.0.0'
    assert result['scm'] == 'git'
    assert 'ansible-role-' in result['path']

# Generated at 2022-06-23 06:56:27.016553
# Unit test for constructor of class RoleRequirement

# Generated at 2022-06-23 06:56:39.250383
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    '''Check the method repo_url_to_role_name'''
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('https://github.com/user/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('git+https://github.com/user/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('user/repo.git') == 'repo'

# Generated at 2022-06-23 06:56:44.325106
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    test_RoleRequirement = RoleRequirement()
    result = test_RoleRequirement.scm_archive_role("https://github.com/ansible/ansible.git", "git", version='v2.0.0', keep_scm_meta=True)
    assert 'ansible-v2.0.0' in result

# Generated at 2022-06-23 06:56:53.802201
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    role = {'name': 'juju4', 'scm': 'git', 'src': 'https://github.com/juju4/ansible-detectdev', 'version': 'HEAD'}
    req = RoleRequirement.role_yaml_parse(role)
    assert req == role

    role = 'juju4.metasploit,HEAD'
    req = RoleRequirement.role_yaml_parse(role)
    assert req['name'] == 'juju4.metasploit'
    assert req['scm'] is None
    assert req['src'] == 'juju4.metasploit'
    assert req['version'] == 'HEAD'

    role = 'https://github.com/juju4/ansible-detectdev,HEAD'

# Generated at 2022-06-23 06:57:04.950935
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    from ansible.utils.display import Display
    display = Display()

    url = "https://github.com/ansible-collections/community.general.collection"
    assert RoleRequirement.repo_url_to_role_name(url) == "community.general.collection"

    url = "https://github.com/ansible-collections/community.general.collection/archive/main.tar.gz"
    assert RoleRequirement.repo_url_to_role_name(url) == "community.general.collection-main"

    url = "https://github.com/ansible-collections/community.general.collection,0.1.0"
    assert RoleRequirement.repo_url_to_role_name(url) == "community.general.collection"

# Generated at 2022-06-23 06:57:09.732112
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Git URL
    print(RoleRequirement.repo_url_to_role_name("git+https://github.com/redhat-openstack/os-ansible-deployment.git,d1b7e8ea"))
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/redhat-openstack/os-ansible-deployment.git,d1b7e8ea") == "os-ansible-deployment"

    # vcs URL
    print(RoleRequirement.repo_url_to_role_name("https://github.com/redhat-openstack/os-ansible-deployment,d1b7e8ea"))

# Generated at 2022-06-23 06:57:14.887895
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test with string input
    role = "geerlingguy.ntp"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'geerlingguy.ntp', 'scm': None, 'src': 'geerlingguy.ntp', 'version': ''}

    role = "geerlingguy.ntp,1.0"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'geerlingguy.ntp', 'scm': None, 'src': 'geerlingguy.ntp', 'version': '1.0'}

    role = "geerlingguy.ntp,1.0,random_name"
    role_dict = RoleRequirement.role_yaml

# Generated at 2022-06-23 06:57:23.855326
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
  from ansible.galaxy.role import GalaxyRole
  import os

  src = 'https://github.com/ansible/ansible-examples.git'
  scm = 'git'
  name = 'ansible-examples'
  version = 'HEAD'
  keep_scm_meta = False

  ret = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)

  galaxy_role_path = '/tmp/ansible_galaxy_' + name
  galaxy_role = GalaxyRole(galaxy_role_path)

  assert os.path.exists(galaxy_role.path)
  assert os.path.exists(galaxy_role.readme_file)
  assert os.path.exists(galaxy_role.meta_file)

 

# Generated at 2022-06-23 06:57:30.769327
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    print("test_RoleRequirement_repo_url_to_role_name")
    print("repo_url: http://git.example.com/repos/repo.git")
    print("test result: 'repo'")

# Generated at 2022-06-23 06:57:41.113659
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    def _scm_archive_role(src, scm='git', name=None, version='HEAD', keep_scm_meta=False):
        return RoleRequirement.scm_archive_role(src, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta)

    assert _scm_archive_role('https://github.com/jtyr/ansible-icinga2.git') == ('https://github.com/jtyr/ansible-icinga2.git', 'git', None, 'HEAD', False)
    assert _scm_archive_role('jtyr.icinga2') == ('jtyr.icinga2', None, None, '', False)

# Generated at 2022-06-23 06:57:52.412467
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile

    # This test is not valid if ansible_galaxy is not installed
    try:
        from ansible_galaxy.collection_artifact import CollectionArtifact
        from ansible_galaxy.api.versions import __version__ as galaxy_version
    except ImportError:
        return

    this = RoleRequirement()

    # test fetching a git archive
    test_src = 'https://github.com/kbrebanov/ansible-testing'
    test_name = 'ansible-testing'
    test_version = 'v0.1.1'
    test_scm = 'git'
    test_keep_scm_meta = False
    test_dest = tempfile.gettempdir()


# Generated at 2022-06-23 06:57:55.412033
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    RoleRequirement.role_yaml_parse("git+https://github.com/keinohguchi/ansible-nginx.git,v1")


# Generated at 2022-06-23 06:58:01.068770
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Unit test for method role_yaml_parse of class RoleRequirement
    role_spec = RoleRequirement.role_yaml_parse("geerlingguy.repo-remi,1.3.0,remi")
    assert isinstance(role_spec, dict)
    assert 'name' in role_spec
    assert 'scm' in role_spec
    assert 'src' in role_spec
    assert 'version' in role_spec
    assert role_spec["name"] == "geerlingguy.repo-remi"
    assert role_spec["scm"] == None
    assert role_spec["src"] == "geerlingguy.repo-remi"
    assert role_spec["version"] == "1.3.0"


# Generated at 2022-06-23 06:58:11.499393
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = dict()
    role['name'] = 'geerlingguy.jenkins'
    role['src'] = 'https://github.com/geerlingguy/ansible-role-jenkins.git'
    role['scm'] = 'git'
    role['version'] = 'v1.0.2'
    test_role = RoleRequirement().role_yaml_parse(role)
    assert test_role['name'] == role['name']
    assert test_role['src'] == role['src']
    assert test_role['scm'] == role['scm']
    assert test_role['version'] == role['version']

    role = dict()
    role['name'] = 'geerlingguy.jenkins'
    role['scm'] = 'git'

# Generated at 2022-06-23 06:58:15.330399
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    expected = dict(name='test', src='test', scm=None, version=None)
    result = role_requirement.role_yaml_parse('test')
    assert result == expected


# Generated at 2022-06-23 06:58:25.283328
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 06:58:32.023115
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    url = "https://github.com/jctanner/ansible-role-aws-vpc"
    name, version, scm, scm_url = RoleRequirement.scm_archive_role(url, scm='git', name=None, version='HEAD')
    assert name == 'ansible-role-aws-vpc'
    assert version == 'HEAD'
    assert scm == 'git'
    assert scm_url == url

# Generated at 2022-06-23 06:58:33.957363
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    RoleRequirement.scm_archive_role('https://github.com/Nexenta/ansible-role-NexentaEdge.git', 'git')

# Generated at 2022-06-23 06:58:45.494266
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    res = RoleRequirement.role_yaml_parse('git+https://github.com/geerlingguy/ansible-role-nginx,v1.0')
    assert res['name'] == 'ansible-role-nginx'
    assert res['src'] == 'https://github.com/geerlingguy/ansible-role-nginx'
    assert res['scm'] == 'git'
    assert res['version'] == 'v1.0'
    res = RoleRequirement.role_yaml_parse('git+https://github.com/geerlingguy/ansible-role-nginx,v1.0,dj-wasabi')
    assert res['name'] == 'dj-wasabi'
    assert res['src'] == 'https://github.com/geerlingguy/ansible-role-nginx'

# Generated at 2022-06-23 06:58:56.307796
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git+https://git.example.com/repos/repo.git") == "repo"

# Generated at 2022-06-23 06:59:04.633344
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    r = RoleRequirement()
    assert r.repo_url_to_role_name("http://git.example.com/repos/repo.git") == 'repo'
    assert r.repo_url_to_role_name("git+git@git.example.com/repos/repo.git") == 'repo'
    assert r.repo_url_to_role_name("git+http://git.example.com/repos/repo.git") == 'repo'
    assert r.repo_url_to_role_name("git://git.example.com/repos/repo.git") == 'repo'
    assert r.repo_url_to_role_name("ssh://git@git.example.com/repos/repo.git") == 'repo'


# Generated at 2022-06-23 06:59:09.345056
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    url = "https://github.com/n0n3m4/ansible-misc.git"
    filename_ok = "n0n3m4-ansible-misc-a954921.tar.gz"
    downloaded_file = RoleRequirement.scm_archive_role(url, scm="git", version="a954921")
    assert downloaded_file == filename_ok

# Generated at 2022-06-23 06:59:19.595579
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    role = RoleRequirement()

    # Test Git archive role
    role_name = 'test_role'
    role_archive = role.scm_archive_role(src='git://github.com/ansible/ansible-examples.git',
                                         scm='git', version='HEAD',
                                         keep_scm_meta=True)
    assert role_name in role_archive
    role_archive = role.scm_archive_role(src='https://github.com/ansible/ansible-examples.git',
                                         scm='git', version='HEAD',
                                         keep_scm_meta=True)
    assert role_name in role_archive

# Generated at 2022-06-23 06:59:21.029652
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    assert role is not None


# Generated at 2022-06-23 06:59:32.024491
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test legacy format with role name and version
    legacy_format = 'role1,1.0'
    legacy_role_yaml = RoleRequirement.role_yaml_parse(legacy_format)
    assert legacy_role_yaml.get('name') == 'role1'
    assert legacy_role_yaml.get('version') == '1.0'

    # Test legacy format with role name, version and alias
    legacy_format = 'role1,1.0,role1.1.0'
    legacy_role_yaml = RoleRequirement.role_yaml_parse(legacy_format)
    assert legacy_role_yaml.get('name') == 'role1.1.0'
    assert legacy_role_yaml.get('version') == '1.0'

    # Test new format with role name

# Generated at 2022-06-23 06:59:43.957217
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Testcase 1:
    role_requirement = RoleRequirement.role_yaml_parse("http://git.example.com/repos/repo.git,v1.0")
    assert role_requirement == {'name': 'repo', 'version': 'v1.0', 'src': 'http://git.example.com/repos/repo.git', 'scm': None}

    # Testcase 2:
    role_requirement = RoleRequirement.role_yaml_parse("http://git.example.com/repos/repo.git")
    assert role_requirement == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'version': '', 'scm': None}

    # Testcase 3:
    role_requirement = Role

# Generated at 2022-06-23 06:59:45.229340
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = dict(name='ansible-role-test')
    role_requirement = RoleRequirement()
    assert role_requirement.role == role


# Generated at 2022-06-23 06:59:53.659073
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    repo_urls = [
        'http://git.example.com/repos/repo.git',
        'https://git.example.com/repos/repo.git',
        'git@git.example.com:repos/repo.git',
        'git+ssh://git@git.example.com/repos/repo.git',
        'git@git.example.com:repos/repo.git',
        'git+https://git.example.com/repos/repo.git',
        'git+http://git.example.com/repos/repo.git',
        'git://git.example.com/repos/repo.git',
        'http://git.example.com/repos/repo.tar.gz'
    ]

# Generated at 2022-06-23 07:00:03.348441
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://github.com/example/ansible-role-foobar') == 'ansible-role-foobar'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/example/ansible-role-foobar2') == 'ansible-role-foobar2'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/example/ansible-role-foobar2,v0.1.0') == 'ansible-role-foobar2'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/example/ansible-role-foobar2,v0.1.0,foobar') == 'ansible-role-foobar2'


# Generated at 2022-06-23 07:00:15.355661
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    method = getattr(RoleRequirement, 'repo_url_to_role_name', None)
    assert method is not None
    result = method("git+http://git.example.com/repos/repo.git")
    assert result == 'repo'
    result = method("git+http://git.example.com/repos/repo")
    assert result == 'repo'
    result = method("http://git.example.com/repos/repo.git")
    assert result == 'repo'
    result = method("ansible-galaxy install git+http://git.example.com/repos/repo.git")
    assert result == "repo"
    result = method("git+http://git.example.com/repos/repo.git,develop")

# Generated at 2022-06-23 07:00:18.207918
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'


# Generated at 2022-06-23 07:00:27.158814
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    url_with_comma = "https://github.com/foo/bar,v0.1.0"
    url_with_comma2 = "https://github.com/foo/bar,v0.1.0,override"
    url_with_comma3 = "https://github.com/foo/bar,v0.1.0,name,bad_stuff_here"
    url_no_comma = "https://github.com/foo/bar"
    url_no_comma_simple = "git@github.com:foo/bar.git"
    url_no_comma_simple2 = "git@github.com:foo/bar"
    url_no_comma_simple3 = "git@github.com:foo/bar.tar.gz"

# Generated at 2022-06-23 07:00:37.453946
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    r = RoleRequirement
    assert r.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert r.repo_url_to_role_name("https://git.example.com/repos/repo.git") == "repo"
    assert r.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"
    assert r.repo_url_to_role_name("repo.git") == "repo"
    assert r.repo_url_to_role_name("repo.tar.gz") == "repo"

# Generated at 2022-06-23 07:00:48.495521
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement.role_yaml_parse("role_name")
    assert role['name'] == "role_name"
    assert role['src'] == "role_name"
    assert role['scm'] is None
    assert role['version'] == ""

    role = RoleRequirement.role_yaml_parse("role_name,1.0")
    assert role['name'] == "role_name"
    assert role['src'] == "role_name"
    assert role['scm'] is None
    assert role['version'] == "1.0"

    role = RoleRequirement.role_yaml_parse("role_name,1.0,http://git.example.com/repos/repo.git")
    assert role['name'] == "role_name"

# Generated at 2022-06-23 07:01:00.858801
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role = RoleRequirement()
    assert role.repo_url_to_role_name('git+git://git.example.com/repos/repo.git') == 'repo'
    assert role.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'
    assert role.repo_url_to_role_name('examples@git.example.com:examples/repo.git') == 'repo'
    assert role.repo_url_to_role_name('ssh://examples@git.example.com/examples/repo.git') == 'repo'
    assert role.repo_url_to_role_name('git@git.example.com:examples/repo.git') == 'repo'


# Generated at 2022-06-23 07:01:05.829672
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_name = 'geerlingguy.jenkins'
    role_version = '1.2.0'
    role_name_version = role_name + ',' + role_version
    role_yaml = RoleRequirement.role_yaml_parse(role_name_version)
    assert role_yaml['name'] == role_name

# Generated at 2022-06-23 07:01:16.192616
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git@github.com:jtyr/ansible-grafana.git") == "ansible-grafana"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/jtyr/ansible-grafana.git") == "ansible-grafana"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/jtyr/ansible-grafana.git") == "ansible-grafana"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/jtyr/ansible-grafana.git,v2.0.0") == "ansible-grafana"
    assert RoleRequ

# Generated at 2022-06-23 07:01:27.802219
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    import ansible.playbook.role.requirement

    def run_with_assert(role):
        assert ansible.playbook.role.requirement.RoleRequirement.role_yaml_parse(role)

    # Test string type
    run_with_assert(role="http://git.localhost/repos/repo.git")
    run_with_assert(role="http://git.localhost/repos/repo.git,v1.0")
    run_with_assert(role="http://git.localhost/repos/repo.git,v1.0,test")
    run_with_assert(role="git+http://git.localhost/repos/repo.git")
    run_with_assert(role="git+http://git.localhost/repos/repo.git,v1.0")
   

# Generated at 2022-06-23 07:01:34.519962
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-23 07:01:44.733631
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.urls import open_url
    from ansible.utils.path import makedirs_safe
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()

    val = RoleRequirement.scm_archive_role(
        src='https://github.com/geerlingguy/ansible-role-apache',
        scm='git',
        name=None,
        version='HEAD',
        keep_scm_meta=False)
    filename = val['path']
    makedirs_safe(os.path.dirname(filename))
    f = open_url(val['url'])
    with open(filename, 'wb') as target:
        shutil.copyfileobj(f, target)
    os.remove(filename)

    val

# Generated at 2022-06-23 07:01:52.550752
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    role = {'meta': {'galaxy_info': {'description': 'test', 'author': 'test', 'min_ansible_version': '1.0', 'platforms': ['test']}},
            'name': 'test', 'src': 'test', 'scm': 'git', 'version': 'master'}
    role_req = RoleRequirement.role_yaml_parse(role)
    assert role_req.get('name') == 'test'
    assert role_req.get('src') == 'test'
    assert role_req.get('scm') == 'git'
    assert role_req.get('version') == 'master'

# Generated at 2022-06-23 07:01:54.628304
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirements = RoleRequirement()
    role_requirements.role_yaml_parse("name,version,other")

# Generated at 2022-06-23 07:02:05.952272
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Old style
    assert RoleRequirement.role_yaml_parse("apache") == {'name': 'apache', 'version': None, 'src': None, 'scm': None}

    # New style
    assert RoleRequirement.role_yaml_parse("scm+https://github.com/ANXS/postgresql.git,v1.0") == {'name': 'postgresql', 'src': 'https://github.com/ANXS/postgresql.git,v1.0', 'scm': 'scm', 'version': None}

# Generated at 2022-06-23 07:02:13.162989
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = 'https://github.com/ansible/ansible-examples.git'
    scm = 'git'
    name = 'ansible-examples'
    version = 'HEAD'
    keep_scm_meta = True
    RoleRequirement.scm_archive_role(src=src, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta)


# Generated at 2022-06-23 07:02:17.001993
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    try:
        src = "https://github.com/ansible/ansible-examples.git"
        RoleRequirement.scm_archive_role(src, name="ansible-examples", version="HEAD")
    except:
        assert(False)

# Generated at 2022-06-23 07:02:29.441939
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement.role_yaml_parse('foo') == {'name': 'foo', 'scm': None, 'src': 'foo', 'version': ''}
    assert RoleRequirement.role_yaml_parse('https://github.com/foo/bar,v1') == {'name': 'bar', 'scm': 'git', 'src': 'https://github.com/foo/bar', 'version': 'v1'}
    assert RoleRequirement.role_yaml_parse('https://github.com/foo/bar.git,v1') == {'name': 'bar', 'scm': 'git', 'src': 'https://github.com/foo/bar.git', 'version': 'v1'}

# Generated at 2022-06-23 07:02:36.360717
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_role_requirement_class = RoleRequirement()
    assert test_role_requirement_class.role_yaml_parse('git+https://github.com/geerlingguy/ansible-role-apache.git,v1.1,geerlingguy.apache') == {'name': 'geerlingguy.apache', 'scm': 'git', 'src': 'https://github.com/geerlingguy/ansible-role-apache.git', 'version': 'v1.1'}


# Generated at 2022-06-23 07:02:47.571281
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    name = 'role_name'
    scm = 'git'
    src = 'http://git.repo.com/repo.git'

    name_returned = RoleRequirement.scm_archive_role(src=src, scm=scm, name=name).replace('+', '-')
    assert name_returned == 'role_name-0.0.0.tar.gz'

    name_returned = RoleRequirement.scm_archive_role(src=src, name=name).replace('+', '-')
    assert name_returned == 'role_name-0.0.0.tar.gz'

    name_returned = RoleRequirement.scm_archive_role(src=src, scm=scm).replace('+', '-')

# Generated at 2022-06-23 07:02:54.702977
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # Arrange
    src = 'https://github.com/nxadm/ansible-role-cassandra.git'
    scm = 'git'
    name = 'ansible-role-cassandra'
    version = 'HEAD'
    keep_scm_meta = False

    # Act
    RoleRequirement.scm_archive_role(
        src = src,
        scm = scm,
        name = name,
        version = version,
        keep_scm_meta = keep_scm_meta,
    )

    # Assert
    assert True



# Generated at 2022-06-23 07:02:58.575710
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    repo_url = "http://git.example.com/repos/repo.git"
    assert role_requirement.repo_url_to_role_name(repo_url) == "repo"

# Generated at 2022-06-23 07:03:10.616173
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from shutil import rmtree
    import tempfile

    # for error handling, the scm is set to git
    src = "https://github.com/test/test"

    # for error handling
    non_existing_src = "https://github.com/reponame/reponame"

    # for success handling
    existing_src = "https://git.ispconfig.org/ispconfig/ispconfig3.git"

    # expected results
    expected_name = "ispconfig"
    expected_scm = "git"
    expected_src = "https://git.ispconfig.org/ispconfig/ispconfig3.git"
    expected_version = "HEAD"

    # testing error handling

# Generated at 2022-06-23 07:03:12.120334
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    res = RoleRequirement()
    assert(res) is not None

# Generated at 2022-06-23 07:03:15.145703
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    test_case = RoleRequirement()
    assert test_case.__init__() == None

# Generated at 2022-06-23 07:03:25.686659
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    for role_line in ['role_name,version,name',
                      'role_name,version',
                      'role_name,',
                      'role_name']:

        role = role_line.split(',')[0]
        version = None
        name = None

        if len(role_line.split(',')) > 1:
            if len(role_line.split(',')) == 3:
                version = role_line.split(',')[1]
                name = role_line.split(',')[2]
            else:
                version = role_line.split(',')[1]
        role_hash = dict(name=name, role=role, version=version)
        assert RoleRequirement.role_yaml_parse(role_line) == role_hash

# Generated at 2022-06-23 07:03:36.367939
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    test_role = RoleRequirement.role_yaml_parse("geerlingguy.apache,2.1.1,geerlingguy_apache")
    assert test_role["name"] == "geerlingguy_apache"
    assert test_role["src"] == "geerlingguy.apache"
    assert test_role["version"] == "2.1.1"
    test_role = RoleRequirement.role_yaml_parse("geerlingguy.apache")
    assert test_role["name"] == "apache"
    assert test_role["src"] == "geerlingguy.apache"
    assert test_role["version"] == ''
    test_role = RoleRequirement.role_yaml_parse("geerlingguy.apache,2.1.1")
    assert test_role["name"] == "apache"


# Generated at 2022-06-23 07:03:48.180941
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml = RoleRequirement.role_yaml_parse("name,version,galaxy_name")
    assert role_yaml["name"] == "galaxy_name"
    assert role_yaml["src"] == "name"
    assert role_yaml["scm"] is None
    assert role_yaml["version"] == "version"

    role_yaml = RoleRequirement.role_yaml_parse("name,galaxy_name")
    assert role_yaml["name"] == "galaxy_name"
    assert role_yaml["src"] == "name"
    assert role_yaml["scm"] is None
    assert role_yaml["version"] == ""

    role_yaml = RoleRequirement.role_yaml_parse("name")
    assert role_yaml["name"] == "name"

# Generated at 2022-06-23 07:04:01.257820
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("https://github.com/foo/bar") == 'bar', "git url not parsed correctly"
    assert RoleRequirement.repo_url_to_role_name("git://github.com/foo/bar.git") == 'bar', "git url not parsed correctly"
    assert RoleRequirement.repo_url_to_role_name("ssh://user@example.com/foo/bar") == 'bar', "ssh url not parsed correctly"
    assert RoleRequirement.repo_url_to_role_name("hg@bitbucket.org:foo/bar") == 'bar', "hg url not parsed correctly"

# Generated at 2022-06-23 07:04:08.050824
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import shutil
    import tempfile
    defaults = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), 'test', 'sanity', 'filter_plugins', 'files', 'defaults.yml')
    defaults = os.path.normpath(defaults)
    assert os.path.exists(defaults)

    defaults_path = os.path.dirname(defaults)
    assert os.path.exists(defaults_path)

    tempdir = tempfile.mkdtemp()
    assert os.path.exists(tempdir)

    tempdefpath = os.path.join(tempdir, 'defaults.yml')
    shutil.copy(defaults, tempdefpath)
   

# Generated at 2022-06-23 07:04:09.058747
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    requirement = RoleRequirement()
    assert requirement is not None

# Generated at 2022-06-23 07:04:16.430028
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    role_definition = {"name": "galaxy1.role1,1.0,role_name", "src": "git+https://github.com/username/project1.git"}
    invalid_role_definition = {"src": "galaxy1.role1,1.0,role_name", "name": "git+https://github.com/username/project1.git"}

    # Test of valid role requirement
    print()
    print("Test of valid role requirement")
    print(role_definition)
    print()
    RoleRequirement.role_yaml_parse(role_definition)
    print()

    # Test of invalid role requirement
    print()
    print("Test of invalid role requirement")
    print(invalid_role_definition)
    print()

# Generated at 2022-06-23 07:04:29.676605
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('example.com:repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('user@example.com:repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'

# Generated at 2022-06-23 07:04:32.443828
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    print("\nTesting constructor of class RoleRequirement")
    role_req = RoleRequirement()
    assert role_req, "Object creation failed"

# Generated at 2022-06-23 07:04:43.898565
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 07:04:56.851549
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.module_utils._text import to_text
    from ansible.utils.hashing import checksum_s
    import os
    import tempfile

    (fd, dest_path) = tempfile.mkstemp(prefix='ansible-role-requirement')
    RoleRequirement.scm_archive_role('https://github.com/ansible/ansible-modules-extras.git',
                                     scm='git',
                                     name='ansible-modules-extras',
                                     version='1.5.3')
    with open(dest_path,'r') as f:
        return_content_on_disk=to_text(f.read(), errors='surrogate_or_strict')
    os.close(fd)
   

# Generated at 2022-06-23 07:05:09.086325
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_spec = dict(name='common', src='http://git.mycompany.com/repos/common.git')
    role_requirement = RoleRequirement()
    role_requirement.role_yaml_parse(role_spec)
    assert role_requirement.name == 'common'
    role_spec = dict(role='common', src='http://git.mycompany.com/repos/common.git')
    role_requirement = RoleRequirement()
    role_requirement.role_yaml_parse(role_spec)
    assert role_requirement.name == 'common'
    role_spec = dict(role='common', src='http://git.mycompany.com/repos/common.git', meta='meta')
    role_requirement = RoleRequirement()
    role_requirement.role_yaml

# Generated at 2022-06-23 07:05:21.856927
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/org/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("ssh://git@git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,master") == "repo,master"
   