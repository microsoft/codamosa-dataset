

# Generated at 2022-06-23 06:55:26.274988
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    def assert_oval(role, **kwargs):
        assert RoleRequirement.role_yaml_parse(role) == kwargs

    assert_oval('http://git.example.com/repos/repo.git,1.0.1', name='repo', version='1.0.1', src='http://git.example.com/repos/repo.git', scm=None)
    assert_oval('myrepo', name='myrepo', version='', src='myrepo', scm=None)
    assert_oval('myrepo,1.0', name='myrepo', version='1.0', src='myrepo', scm=None)

# Generated at 2022-06-23 06:55:33.652520
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile

    tempdir = tempfile.mkdtemp(prefix='ansible-test-galaxy-')

    src = "https://github.com/geerlingguy/ansible-role-apache.git"
    name = "geerlingguy.apache"
    scm = "git"
    version = "master"

    result = RoleRequirement.scm_archive_role(
        src=src,
        name=name,
        scm=scm,
        version=version,
        keep_scm_meta=False
    )

    ret_src = result['src']
    ret_name = result['name']
    ret_scm = result['scm']
    ret_version = result['version']

    assert src == ret_src
    assert name == ret_name
    assert scm == ret_

# Generated at 2022-06-23 06:55:35.720769
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'


# Generated at 2022-06-23 06:55:36.219090
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    pass

# Generated at 2022-06-23 06:55:47.193940
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    ret = RoleRequirement.role_yaml_parse("http://git.example.com/repos/repo.git,v1.0,name")
    assert ret['src'] == "http://git.example.com/repos/repo.git"
    assert ret['version'] == "v1.0"
    assert ret['name'] == "name"

    ret = RoleRequirement.role_yaml_parse("http://git.example.com/repos/repo.git,v1.0")
    assert ret['src'] == "http://git.example.com/repos/repo.git"
    assert ret['version'] == "v1.0"
    assert ret['name'] == "repo"


# Generated at 2022-06-23 06:55:56.264809
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test 1: Call with valid params
    role1 = 'geerlingguy.ntp,v1.2.3,name'
    role2 = dict(role=geerlingguy.ntp, vars=dict(foo=bar))

# Generated at 2022-06-23 06:56:01.947773
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role = RoleRequirement()
    assert role.repo_url_to_role_name("git://git.qnap.com/git/QDK/ansible-role-qnap-qpkg.git") == "ansible-role-qnap-qpkg"

    assert role.repo_url_to_role_name("git+git://git.qnap.com/git/QDK/ansible-role-qnap-qpkg.git") == "ansible-role-qnap-qpkg"

    assert role.repo_url_to_role_name("ansible-role-qnap-qpkg") == "ansible-role-qnap-qpkg"




# Generated at 2022-06-23 06:56:13.350000
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    rr = RoleRequirement()
    try:
        rr.role_yaml_parse(('test_role','test_version','test_name'))
    except Exception as e:
        pass
    else:
        raise Exception("Invalid role line should've failed")

# Generated at 2022-06-23 06:56:22.775389
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # test 1: check expected behavior when valid repo is given
    test_value = "git+https://github.com/someuser/somerepo.git"
    expected_value = "somerepo"
    assert RoleRequirement.repo_url_to_role_name(test_value) == expected_value

    # test 2: check expected behavior if, repo has trailing slash
    test_value = "git+https://github.com/someuser/somerepo.git/"
    expected_value = "somerepo"
    assert RoleRequirement.repo_url_to_role_name(test_value) == expected_value

    # test 3: check expected behavior if, repo has git suffix
    test_value = "git+https://github.com/someuser/somerepo.git.git"

# Generated at 2022-06-23 06:56:25.111242
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Test case: successfully construct RoleRequirement object
    requirement = RoleRequirement()
    assert requirement.__class__.__name__ == 'RoleRequirement'

# Generated at 2022-06-23 06:56:29.105473
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    name = "myrole"
    scm = "git"
    params = {}

    # test url with ".git"
    src = "https://github.com/ansible/ansible-examples.git"
    result = "https://github.com/ansible/ansible-examples/archive/HEAD.tar.gz"
    result = result.replace('/archive/', '/archive/' + name + '-')
    params.update({
        'src': src,
        'scm': scm,
        'name': name
    })
    assert RoleRequirement.scm_archive_role(**params) == result

    # test url without ".git"
    src = "https://github.com/ansible/ansible-examples"

# Generated at 2022-06-23 06:56:38.700215
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    from ansible.utils.path import unfrackpath
    role_src = "git+https://github.com/geerlingguy/ansible-role-jenkins.git"
    role_name = "ansible-role-jenkins"
    role_scm = "git"
    role_version = "master"
    role_filename = "ansible-role-jenkins.tar.gz"
    with RoleRequirement.scm_archive_role(role_src, role_scm, role_name, role_version) as role_file:
        assert role_file.endswith(role_filename)
        os.remove(unfrackpath(role_file))

# Generated at 2022-06-23 06:56:49.154649
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    assert RoleRequirement.repo_url_to_role_name("git@github.com:ANXS/postgresql.git") == "postgresql"
    assert RoleRequirement.repo_url_to_role_name("git@github.com:ANXS/postgresql") == "postgresql"
    assert RoleRequirement.repo_url_to_role_name("git@github.com:ANXS/postgresql.tar.gz") == "postgresql"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/ANXS/postgresql.git") == "postgresql"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/ANXS/postgresql") == "postgresql"
   

# Generated at 2022-06-23 06:56:52.269381
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    assert role_requirement is not None, 'RoleRequirement is not initialized'

# Generated at 2022-06-23 06:56:59.524986
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = "scm+git@gitrepo.example.com/repo.git,1.2.3,myrole"
    expected = dict(name='myrole', src='git@gitrepo.example.com/repo.git', scm='scm+git', version='1.2.3')
    assert RoleRequirement.role_yaml_parse(role) == expected

if __name__ == '__main__':
    test_RoleRequirement_role_yaml_parse()

# Generated at 2022-06-23 06:57:01.051601
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    rr = RoleRequirement()
    assert rr is not None


# Generated at 2022-06-23 06:57:08.598169
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.plugins.loader import find_plugin

    scm = 'git'
    src = 'git://github.com/alikins/ansible-vagrant_test.git'
    name = 'alikins.vagrant_test'
    version = 'HEAD'
    keep_scm_meta = False

    try:
        path_to_role = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)
        plugin = find_plugin(path_to_role)
    except:
        assert False
    assert plugin is not None

# Generated at 2022-06-23 06:57:20.608625
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.playbook.role.requirement import RoleRequirement

    # name, src, scm, version

# Generated at 2022-06-23 06:57:21.787192
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    assert role_requirement

# Generated at 2022-06-23 06:57:34.597701
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # The test uses the repo https://github.com/bennojoy/nginx
    # to test if the role is parsed correctly
    # To test, run test_RoleRequirement.test_RoleRequirement_scm_archive_role
    import tempfile
    from ansible.utils.galaxy import scm_archive_role

    src = "https://github.com/bennojoy/nginx.git"
    scm = 'git'
    name = "bennojoy.nginx"
    version = 'HEAD'
    keep_scm_meta = True

    role_path = scm_archive_role(src, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta)

    assert name in role_path

# Generated at 2022-06-23 06:57:45.341279
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.urls import open_url
    import tempfile
    import os
    import shutil

    role_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 06:57:55.193525
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    r = RoleRequirement()
    assert r.repo_url_to_role_name("https://github.com/username/role.git") == "role"
    assert r.repo_url_to_role_name("git+git://git.example.com/myuser/myrepo.git") == "myrepo"
    assert r.repo_url_to_role_name("git+https://github.com/username/role.git") == "role"
    assert r.repo_url_to_role_name("git+https://github.com/username/role.git,v1.0") == "role"
    assert r.repo_url_to_role_name("https://github.com/username/role.git,v1.0") == "role"
    assert r.repo_url

# Generated at 2022-06-23 06:58:03.121682
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Test for role_yaml_parse
    test_dict = dict(name = "geerlingguy.apache", src = "https://github.com/geerlingguy/ansible-role-apache", scm = "git", version = "")
    assert test_dict == RoleRequirement.role_yaml_parse({"src":"https://github.com/geerlingguy/ansible-role-apache"})
    assert test_dict == RoleRequirement.role_yaml_parse({"name":"geerlingguy.apache", "src":"https://github.com/geerlingguy/ansible-role-apache"})
    assert test_dict == RoleRequirement.role_yaml_parse({"role":"geerlingguy.apache", "src":"https://github.com/geerlingguy/ansible-role-apache"})

# Generated at 2022-06-23 06:58:06.463683
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    req_obj = RoleRequirement()
    assert req_obj

# Generated at 2022-06-23 06:58:07.672579
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_def = RoleRequirement()
    assert role_def != None


# Generated at 2022-06-23 06:58:14.306779
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils import six
    import os
    import tempfile
    import shutil

    # create a temporary directory for the testing
    tmpdir = tempfile.mkdtemp(prefix='ansible-galaxy')
    target_dir = os.path.join(tmpdir, 'role')

    # create a temporary git repo
    git_dir = os.path.join(tmpdir, 'gitdir')
    os.mkdir(git_dir)
    os.chdir(git_dir)
    if six.PY3:
        from subprocess import run
        ret = run(['git', 'init'])
        assert ret.returncode == 0
        ret = run(['git', 'config', 'user.name', 'Git User'])
        assert ret.returncode == 0

# Generated at 2022-06-23 06:58:19.318605
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    role_yaml_parse_dic = role.role_yaml_parse("{ src: 'galaxy.role' }")
    assert_equal(role_yaml_parse_dic, {
        'name': 'galaxy.role',
        'src': 'galaxy.role',
        'version': '',
        'scm': None
    })

# Generated at 2022-06-23 06:58:26.558823
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    sr_obj = RoleRequirement()
    ret = sr_obj.role_yaml_parse("my_src")
    assert ret == dict(name='my_src',src='my_src',scm=None,version=None)
    ret = sr_obj.role_yaml_parse("my_role")
    assert ret == dict(name='my_role',src='my_role',scm=None,version=None)
    ret = sr_obj.role_yaml_parse("my_role,v1.0")
    assert ret == dict(name='my_role',src='my_role',scm=None,version='v1.0')
    ret = sr_obj.role_yaml_parse("my_role,v1.0,my_role_name")

# Generated at 2022-06-23 06:58:38.256363
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Test return name from URL without ending .git
    repo_url = 'git@git.example.com:repos/repo.git'
    result = RoleRequirement.repo_url_to_role_name(repo_url)
    assert(result == 'repo')

    # Test return name from URL with ending .git
    repo_url = 'git@git.example.com:repos/repo.git'
    result = RoleRequirement.repo_url_to_role_name(repo_url)
    assert(result == 'repo')

    # Test return name from URL with ending .tar.gz
    repo_url = 'git@git.example.com:repos/repo.tar.gz'

# Generated at 2022-06-23 06:58:43.315928
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # We test all the cases of what the url could look like when passed to method
    # repo_url_to_role_name of class RoleRequirement.
    github_url_1 = 'https://github.com/nickjj/ansible-git'
    github_url_2 = 'https://github.com/nickjj/ansible-git.git'
    github_url_3 = 'https://github.com/nickjj/ansible-git.tar.gz'
    github_url_4 = 'https://github.com/nickjj/ansible-git,v1.0.0'
    gitlab_url_1 = 'git@gitlab.com:nickjj/ansible-git.git'
    gitlab_url_2 = 'git@gitlab.com:nickjj/ansible-git.git,master'
   

# Generated at 2022-06-23 06:58:54.793823
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    """
    Test that the function creates a dict as expected with all these cases:
    - Only src is given (name and version will be guessed)
    - Only src and version are given
    - Only src and name are given
    - Only src and scm are given
    - Only src, scm and name are given
    - Only src, scm and version are given
    - Only src, scm, name and version are given
    """

# Generated at 2022-06-23 06:59:04.054688
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = 'test,v1.0,myname'
    spec_1 = dict(src='test,v1.0,myname', version='v1.0', name='myname', scm=None)
    spec_2 = RoleRequirement.role_yaml_parse(role)
    assert (spec_1 == spec_2)

    role = dict(src='test,v1.0,myname', var='val')
    spec_1 = dict(src='test,v1.0,myname', var='val', version='v1.0', name='myname', scm=None)
    spec_2 = RoleRequirement.role_yaml_parse(role)
    assert (spec_1 == spec_2)

    role = dict(name='test,v1.0,myname', var='val')


# Generated at 2022-06-23 06:59:13.338892
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = 'geerlingguy.nginx'
    role_obj = RoleRequirement.from_name(role)
    assert(role_obj.name == 'geerlingguy.nginx')
    assert(role_obj.role == 'geerlingguy.nginx')
    assert(role_obj.src == 'geerlingguy.nginx')
    assert(role_obj.version == '')
    assert(role_obj.scm == None)

    role = 'geerlingguy.nginx,v2.2.2'
    role_obj = RoleRequirement.from_name(role)
    assert(role_obj.name == 'geerlingguy.nginx')
    assert(role_obj.role == 'geerlingguy.nginx')

# Generated at 2022-06-23 06:59:26.064654
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test old style of role yaml parse
    role_str = 'bennojoy.nginx'
    role = RoleRequirement.role_yaml_parse(role_str)
    assert role['name'] == role_str
    assert 'src' not in role

    # Test old style of role yaml parse
    role_str = 'bennojoy.nginx,1.0.1'
    role = RoleRequirement.role_yaml_parse(role_str)
    assert role['name'] == 'bennojoy.nginx'
    assert role['version'] == '1.0.1'
    assert 'src' not in role

    # Test old style of role yaml parse
    role_str = 'bennojoy.nginx,1.0.1,nginx'

# Generated at 2022-06-23 06:59:34.497007
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    expected_scm_archive_role = [{'src': 'https://github.com/geerlingguy/ansible-role-apache.git', 'scm': 'git', 'name': 'ansible-role-apache', 'version': '1.3.0', 'keep_scm_meta': False}]

# Generated at 2022-06-23 06:59:36.161846
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    role = RoleRequirement.scm_archive_role('')

# Generated at 2022-06-23 06:59:47.410323
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo-1.2.tar.gz') == 'repo-1.2'
    assert RoleRequirement.repo_url_to_role_name('git://git.example.com/repos/repo.git')

# Generated at 2022-06-23 06:59:52.584368
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    url1 = 'git+https://github.com/usegalaxy-eu/ansible-role-nextflow.git'
    url2 = 'https://github.com/usegalaxy-eu/ansible-role-nextflow'
    assert RoleRequirement.repo_url_to_role_name(url1) == 'ansible-role-nextflow'
    assert RoleRequirement.repo_url_to_role_name(url2) == 'ansible-role-nextflow'

# Generated at 2022-06-23 07:00:02.810827
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role = "http://git.example.com/repos/repo.git,1.0"
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == 'repo'
    assert result['src'] == 'http://git.example.com/repos/repo.git'
    assert result['scm'] == 'git'
    assert result['version'] == '1.0'

    role = "http://git.example.com/repos/repo.git,1.0,my_name"
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == 'my_name'
    assert result['src'] == 'http://git.example.com/repos/repo.git'
    assert result['scm'] == 'git'

# Generated at 2022-06-23 07:00:14.651119
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    rr = RoleRequirement()

    assert rr.role_yaml_parse('example,v2.3.4,myname') == dict(name='myname', scm=None, src='example', version='v2.3.4')
    assert rr.role_yaml_parse('example,v2.3.4') == dict(name='example', scm=None, src='example', version='v2.3.4')
    assert rr.role_yaml_parse('example') == dict(name='example', scm=None, src='example', version='')

# Generated at 2022-06-23 07:00:24.597819
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('https://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('http://user@git.example.com/repos/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'

# Generated at 2022-06-23 07:00:28.985811
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # pylint: disable=import-error
    import tempfile
    import os
    import shutil
    # pylint: enable=import-error
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-23 07:00:39.385018
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # testing parsing a scalar
    rr = RoleRequirement()
    rr.role_yaml_parse('http://git.example.com/git.git')

    # testing parsing a dict
    rr.role_yaml_parse({ 'name': 'http://git.example.com/git.git' })

    # testing parsing a scalar with all three fields filled out
    rr.role_yaml_parse('http://git.example.com/git.git,1.2.3,my_name')

    # testing parsing a dict with all three fields filled out
    rr.role_yaml_parse({ 'src': 'http://git.example.com/git.git', 'version': '1.2.3', 'name': 'my_name' })

# Generated at 2022-06-23 07:00:49.663518
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_obj = RoleRequirement()

    assert role_obj.role_yaml_parse('foo') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': None}
    assert role_obj.role_yaml_parse('foo,1.0') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': '1.0'}
    assert role_obj.role_yaml_parse('foo,bar') == {'name': 'bar', 'src': 'foo', 'scm': None, 'version': None}
    assert role_obj.role_yaml_parse('foo,1.0,bar') == {'name': 'bar', 'src': 'foo', 'scm': None, 'version': '1.0'}
    assert role_obj

# Generated at 2022-06-23 07:00:59.560047
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_req = RoleRequirement.role_yaml_parse('git+https://github.com/geerlingguy/ansible-role-apache,2.2.0')
    if role_req['name'] != 'ansible-role-apache':
        raise AssertionError("")
    if role_req['version'] != '2.2.0':
        raise AssertionError("")
    if role_req['scm'] != 'git':
        raise AssertionError("")
    if role_req['src'] != 'https://github.com/geerlingguy/ansible-role-apache':
        raise AssertionError("")


# Generated at 2022-06-23 07:01:09.834422
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    role_requirement = RoleRequirement()

    repo_url = 'https://github.com/example/example.git'
    if RoleRequirement.repo_url_to_role_name(repo_url) == 'example':
        display.display("repo_url_to_role_name PASSED")
    else:
        display.display("repo_url_to_role_name FAILED")

    role = {'name':'example_role'}
    if role_requirement.role_yaml_parse(role)['name'] == 'example_role':
        display.display("role_yaml_parse PASSED")
    else:
        display.display("role_yaml_parse FAILED")

    src = 'https://github.com/example/example-role.git'

# Generated at 2022-06-23 07:01:14.934903
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.utils.galaxy import GalaxyRole
    from ansible.galaxy import Galaxy
    import ansible.constants as C

    keep_scm_meta = False
    version = 'HEAD'
    name = 'dockerfile'
    user = 'jdauphant'
    src = 'https://github.com/%s/%s.git' % (user, name)
    scm = 'git'

    role = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta=keep_scm_meta)

    role_path = role.path
    name = role.name
    version = role.version
    galaxy_role = GalaxyRole(role.get_info(), role_path)
    galaxy_server = Galaxy(C.GALAXY_SERVER)


# Generated at 2022-06-23 07:01:26.883540
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Testing different strings
    test_cases = dict()

    test_cases[
        {'name': None, 'scm': None, 'src': None, 'version': None}
    ] = "src_string"

    test_cases[
        {'name': None, 'scm': None, 'src': None, 'version': None}
    ] = "src_string,"

    test_cases[
        {'name': None, 'scm': None, 'src': None, 'version': "version_string"}
    ] = "src_string,version_string"

    test_cases[
        {'name': None, 'scm': None, 'src': None, 'version': "version_string"}
    ] = "src_string,version_string,"


# Generated at 2022-06-23 07:01:34.585428
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # test NameError exception
    try:
        RoleRequirement()
    except NameError as e:
        display.display("test_RoleRequirement: %s" % str(e))

    # test ValueError exception
    try:
        RoleRequirement.repo_url_to_role_name("http://github.com/username/repo")
    except ValueError as e:
        display.display("test_RoleRequirement: %s" % str(e))

if __name__ == '__main__':
    test_RoleRequirement()

# Generated at 2022-06-23 07:01:44.760029
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import ansible_galaxy
    import os
    import pprint
    import sys


# Generated at 2022-06-23 07:01:51.498683
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
  url = 'https://github.com/geerlingguy/ansible-role-apache.git'
  print("Testing repo_url_to_role_name")
  print("INPUT: " + str(url))
  print("OUTPUT: " + str(RoleRequirement.repo_url_to_role_name(url)))
  print("\n")


# Generated at 2022-06-23 07:02:00.676745
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("foo") == dict(name='foo', src='foo', scm=None, version='')
    assert RoleRequirement.role_yaml_parse("foo,v1") == dict(name='foo', src='foo', scm=None, version='v1')
    assert RoleRequirement.role_yaml_parse("bar,v1,foo") == dict(name='foo', src='bar', scm=None, version='v1')
    assert RoleRequirement.role_yaml_parse("git+http://git.example.com/repos/repo.git,v1") == dict(name='repo', src='http://git.example.com/repos/repo.git', scm='git', version='v1')
    assert RoleRequirement.role_yaml

# Generated at 2022-06-23 07:02:10.476575
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    # Test with different repo url
    assert role_requirement.repo_url_to_role_name('http://github.com/ansible') == 'ansible'
    assert role_requirement.repo_url_to_role_name('ansible.git.git') == 'ansible.git'
    assert role_requirement.repo_url_to_role_name('ansible.git.git') == 'ansible.git'
    assert role_requirement.repo_url_to_role_name('ansible.git.tar.gz') == 'ansible.git'
    assert role_requirement.repo_url_to_role_name('ansible.git.tar.gz') == 'ansible.git'
    assert role_requirement.repo_url

# Generated at 2022-06-23 07:02:22.450701
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    """
    AnsibleRole
    """

    # Successes
    assert type(RoleRequirement.role_yaml_parse("scm+git://path.git,version,name")) is dict
    assert type(RoleRequirement.role_yaml_parse("git+git://path.git,version,name")) is dict
    assert type(RoleRequirement.role_yaml_parse("hg+hg://path.hg,version,name")) is dict
    assert type(RoleRequirement.role_yaml_parse("svn+svn://path.svn,version,name")) is dict

    assert type(RoleRequirement.role_yaml_parse("scm+http://path.git,version,name")) is dict

# Generated at 2022-06-23 07:02:30.723891
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_name = 'foo'
    role_scm = 'git'
    role_src = 'http://github.com/bar/baz.git'
    role_version = 'HEAD'

    role_req = RoleRequirement()

    role_definition = role_req.role_yaml_parse(role_src)

    assert(role_definition['name'] == role_name)
    assert(role_definition['src'] == role_src)
    assert(role_definition['scm'] == role_scm)
    assert(role_definition['version'] == role_version)

# Generated at 2022-06-23 07:02:37.260406
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # Arrange
    expected = ('git', 'https://github.com/geerlingguy/ansible-role-apache.git', 'ansible-role-apache-v1.6.1-1-ge1cff7e.zip')

    # Act
    result = RoleRequirement.scm_archive_role('https://github.com/geerlingguy/ansible-role-apache', 'git', 'geerlingguy.apache', '1.6.1')

    # Assert
    assert result == expected

# Generated at 2022-06-23 07:02:47.914749
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    role_requirement = RoleRequirement()

    print(role_requirement.role_yaml_parse('foobar'))
    print(role_requirement.role_yaml_parse('foobar,1.0'))
    print(role_requirement.role_yaml_parse('foobar,git+https://github.com/foobar/ansible-role-foobar,1.0'))

    print(role_requirement.role_yaml_parse({'role': 'foobar'}))
    print(role_requirement.role_yaml_parse({'role': 'foobar', 'version': '1.0'}))

# Generated at 2022-06-23 07:02:56.810617
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    def check(s, expected):
        actual = RoleRequirement.role_yaml_parse(s)
        assert actual == expected

    # Old style: http://git.example.com/repos/repo.git,v1.0
    check('http://git.example.com/repos/repo.git,v1.0', {u'name': u'repo', u'src': u'http://git.example.com/repos/repo.git', u'scm': u'git', u'version': u'v1.0'})

    # Old style: http://git.example.com/repos/repo.git,v1.0,name

# Generated at 2022-06-23 07:03:04.293496
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    print((dir(role_requirement)))
    role_requirement.roles_path
    role_requirement.display

if __name__ == '__main__':
    test_RoleRequirement()

# Generated at 2022-06-23 07:03:11.485867
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    test_var_list = (
        {'key': 'name', 'value': 'test_name'},
        {'key': 'role', 'value': 'test_role'},
        {'key': 'scm', 'value': 'test_scm'},
        {'key': 'src', 'value': 'test_src'},
        {'key': 'version', 'value': 'test_version'},
    )

    for test_var in test_var_list:
        role_info = {test_var['key']: test_var['value']}
        role = RoleRequirement.role_yaml_parse(role_info)

        assert role[test_var['key']] == test_var['value']

# Generated at 2022-06-23 07:03:23.256649
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    (rc, data) = RoleRequirement.scm_archive_role("https://github.com/dev-sec/ansible-ssh-hardening", "git", "sshd_hardening", "v1.7", True)
    assert rc == 0
    assert data['status'] == 'success'
    assert data['dest'] == '/Users/nagendra.gandham/.ansible/tmp/ansible-tmp-1593577294.74-209498079167058/sshd_hardening'
    assert data['src'] == 'https://github.com/dev-sec/ansible-ssh-hardening,v1.7,sshd_hardening'
    assert data['role_name'] == 'sshd_hardening'

# Generated at 2022-06-23 07:03:29.528234
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = 'https://github.com/ansible/ansible-examples.git'
    ret = RoleRequirement.scm_archive_role(src, scm='git', name=None, version='HEAD', keep_scm_meta=False)
    assert ret == 'https://github.com/ansible/ansible-examples/archive/HEAD.tar.gz'

    src = 'https://github.com/ansible/ansible-examples.git'
    ret = RoleRequirement.scm_archive_role(src, scm='git', name=None, version='v2.0.0', keep_scm_meta=False)
    assert ret == 'https://github.com/ansible/ansible-examples/archive/v2.0.0.tar.gz'


# Generated at 2022-06-23 07:03:38.285834
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Repo URL without scheme
    assert RoleRequirement.repo_url_to_role_name("git.example.com:repos/repo.git") == "repo"
    # Repo URL with scheme
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    # Repo URL with scheme and user name
    assert RoleRequirement.repo_url_to_role_name("http://user@git.example.com/repos/repo.git") == "repo"
    # Repo URL with git+scheme
    assert RoleRequirement.repo_url_to_role_name("git+http://git.example.com/repos/repo.git") == "repo"
    # Rep

# Generated at 2022-06-23 07:03:46.692258
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    test_list = [
        'http://git.example.com/repos/repo.git',
        'git@git.example.com:user/repo.git',
        'git+https://git.example.com/repos/repo.git',
        'svn+http://svn.example.com/repos/repo/trunk',
        'svn+https://svn.example.com/repos/repo/trunk',
    ]
    for x in test_list:
        print(RoleRequirement.repo_url_to_role_name(x))

# Generated at 2022-06-23 07:03:59.895540
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    r = None
    r = RoleRequirement.role_yaml_parse('role_name')
    assert r['name'] == 'role_name'
    assert r['src'] == 'role_name'
    assert r['scm'] == None
    assert r['version'] == None

    r = RoleRequirement.role_yaml_parse('role_name,v1')
    assert r['name'] == 'role_name'
    assert r['src'] == 'role_name'
    assert r['scm'] == None
    assert r['version'] == 'v1'

    r = RoleRequirement.role_yaml_parse('role_name,v1,newname')
    assert r['name'] == 'newname'
    assert r['src'] == 'role_name'
    assert r['scm'] == None


# Generated at 2022-06-23 07:04:07.632281
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    result = RoleRequirement.role_yaml_parse("http://git.example.com/repos/ansible-role-common.git,1.0.0")
    assert result == dict(name="ansible-role-common", src="http://git.example.com/repos/ansible-role-common.git",
                          scm=None, version="1.0.0")

    result = RoleRequirement.role_yaml_parse("http://git.example.com/repos/ansible-role-common.git,1.0.0,common")
    assert result == dict(name="common", src="http://git.example.com/repos/ansible-role-common.git",
                          scm=None, version="1.0.0")

    result = RoleRequirement.role_yaml_

# Generated at 2022-06-23 07:04:19.075970
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    url = "https://github.com/user/repo.git"
    assert RoleRequirement.repo_url_to_role_name(url) == "repo"

    url = "git+https://github.com/user/repo.git"
    assert RoleRequirement.repo_url_to_role_name(url) == "repo"

    url = "https://github.com/user/repo.git@v0.0.1"
    assert RoleRequirement.repo_url_to_role_name(url) == "repo"

    url = "git+https://github.com/user/repo.git@v0.0.1"
    assert RoleRequirement.repo_url_to_role_name(url) == "repo"


# Generated at 2022-06-23 07:04:32.186232
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement.role_yaml_parse("git+git@git.example.com:test.git,1.0")
    assert role['name'] == 'test'
    assert role['scm'] == 'git'
    assert role['src'] == 'git@git.example.com:test.git'
    assert role['version'] == '1.0'

    role = RoleRequirement.role_yaml_parse("git+git@git.example.com:test.git")
    assert role['name'] == 'test'
    assert role['scm'] == 'git'
    assert role['src'] == 'git@git.example.com:test.git'
    assert role['version'] == ''

    role = RoleRequirement.role_yaml_parse("git@git.example.com:test.git")


# Generated at 2022-06-23 07:04:38.426333
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.playbook.role import RoleRequirement


# Generated at 2022-06-23 07:04:39.995067
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    role_requirement = RoleRequirement()
    assert role_requirement



# Generated at 2022-06-23 07:04:48.697747
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.module_utils.galaxy import scm_archive_resource
    from purger import purge

    name = 'degrees'
    src = 'https://github.com/degrees/ansible-role-degrees.git'
    scm = 'git'
    version = 'v1.0.0'

    try:
        result = RoleRequirement.scm_archive_role(src=src, scm=scm, name=name, version=version, keep_scm_meta=False)
    except:
        result = None
    assert result is not None

    try:
        purge()
    except:
        pass

# Generated at 2022-06-23 07:04:59.322666
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement.role_yaml_parse('role1') == {'name': 'role1', 'scm': None, 'src': 'role1', 'version': ''}
    assert RoleRequirement.role_yaml_parse('https://github.com/user/role1') == {'name': 'role1', 'scm': None, 'src': 'https://github.com/user/role1', 'version': ''}
    assert RoleRequirement.role_yaml_parse('https://github.com/user/role1.git') == {'name': 'role1', 'scm': None, 'src': 'https://github.com/user/role1.git', 'version': ''}

# Generated at 2022-06-23 07:05:10.227501
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement.role_yaml_parse("git+https://github.com/username/role_name.git, my_branch, my_role_name")
    assert isinstance(role, dict)
    assert role['name'] == 'my_role_name'
    assert role['scm'] == 'git'
    assert role['src'] == 'https://github.com/username/role_name.git'
    assert role['version'] == 'my_branch'

    role = RoleRequirement.role_yaml_parse("https://github.com/username/role_name.tar.gz, my_branch, my_role_name")
    assert isinstance(role, dict)
    assert role['name'] == 'my_role_name'
    assert role['scm'] == None
    assert role['src']

# Generated at 2022-06-23 07:05:23.007175
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.urls import open_url
    import os
    import shutil
    import tempfile

    GALAXY_URL = 'https://raw.github.com/ansible/galaxy/devel'

    test_url_zip = '%s/prototype/basic/basic.tar.gz?foo' % GALAXY_URL
    test_url_git = '%s/prototype/basic.git' % GALAXY_URL
    test_url_hg  = '%s/prototype/basic.hg' % GALAXY_URL
    tmp_dir      = tempfile.mkdtemp()
    tmp_path_zip = None
    tmp_path_git = None
    tmp_path_hg  = None

    # Cleanup.
    def cleanup():
        os.remove