

# Generated at 2022-06-23 06:55:34.978114
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse("src") == {'name': 'src', 'src': 'src', 'version': '', 'scm': None}
    assert role_requirement.role_yaml_parse("galaxy.role,version") == {'name': 'galaxy.role', 'src': 'galaxy.role', 'version': 'version', 'scm': None}
    assert role_requirement.role_yaml_parse("galaxy.role,version,name") == {'name': 'name', 'src': 'galaxy.role', 'version': 'version', 'scm': None}

# Generated at 2022-06-23 06:55:46.084270
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 06:55:47.488785
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    roleRequirement = RoleRequirement()
    assert roleRequirement

# Generated at 2022-06-23 06:55:56.451096
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # Test role_yaml_parse
    role = "http://github.com/mpdehaan/ansible-foobar.git,v1.2.3"
    display.debug("role=%s" % role)
    req_dict = RoleRequirement.role_yaml_parse(role)
    assert req_dict["name"] == "ansible-foobar"
    assert req_dict["src"] == "http://github.com/mpdehaan/ansible-foobar.git"
    assert req_dict["version"] == "v1.2.3"

    role = "https://github.com/mpdehaan/ansible-foobar.git,v1.2.3"
    display.debug("role=%s" % role)
    req_dict = RoleRequirement.role_yaml_parse

# Generated at 2022-06-23 06:56:02.430461
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # test trailing_path ends with .git
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    # test trailing_path ends with .tar.gz
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    # test trailing_path ends with .tar.gz and has a version
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,1.0.0.tar.gz") == "repo"
    # test trailing_path ends with .tar.gz, has a version and has a name
    assert RoleRequirement.repo_url

# Generated at 2022-06-23 06:56:10.438442
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # "src" is None
    src = None
    try:
        RoleRequirement.scm_archive_role(src)
    except AnsibleError as e:
        assert 'a download URL must be specified' == str(e)

    # "src" is valid
    src = 'http://github.com/username/rolename'
    try:
        RoleRequirement.scm_archive_role(src)
    except AnsibleError as e:
        assert str(e) == ''

# Generated at 2022-06-23 06:56:18.911104
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.plugins.lookup import LookupModule
    from ansible.utils.galaxy import GalaxyLookup
    lookup_loader = LookupModule()
    lookup = GalaxyLookup()

    test_dict = {}
    test_dict['git'] = {
        'src': 'https://github.com/geerlingguy/ansible-role-apache.git',
    }
    test_dict['hg'] = {
        'scm': 'hg',
        'src': 'https://bitbucket.org/geerlingguy/ansible-role-firewall'
    }
    test_dict['svn'] = {
        'scm': 'svn',
        'src': 'https://github.com/geerlingguy/ansible-role-firewall',
    }


# Generated at 2022-06-23 06:56:30.344137
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    import ansible.galaxy
    import ansible.constants as C

    # Create a temp dir to work with
    tmpdir = tempfile.mkdtemp()

    # Create a fake git repo
    src = os.path.join(tmpdir, 'test_repo')
    src_content = os.path.join(tmpdir, 'content')
    repo_branch = 'master'
    repo_ref = 'master'
    repo_path = os.path.join(src_content, 'roles', 'test_role')

    os.makedirs(src)
    os.makedirs(src_content)
    os.makedirs(repo_path)

# Generated at 2022-06-23 06:56:41.788483
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Check with old style role
    role = RoleRequirement.role_yaml_parse("my.rolename,1.0,my_new_rolename")
    assert role.get("name") == "my_new_rolename"
    assert role.get("scm") == None
    assert role.get("src") == "my.rolename"

    # Check with old style role
    role = RoleRequirement.role_yaml_parse("geerlingguy.jenkins,master")
    assert role.get("name") == "geerlingguy.jenkins"
    assert role.get("scm") == None
    assert role.get("version") == "master"

    # Check with old style role
    role = RoleRequirement.role_yaml_parse("geerlingguy.jenkins")

# Generated at 2022-06-23 06:56:53.006816
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    src = 'https://github.com/ansible/ansible-examples'
    scm= 'git'
    version='HEAD'
    name = RoleRequirement.repo_url_to_role_name(src)
    keep_scm_meta=False
    result = RoleRequirement.scm_archive_role(src, scm, version, name, keep_scm_meta)
    parsed_url = urlparse(result)
    if (parsed_url.scheme == 'file'):
        assert parsed_url.path == '/home/test_user/test_ansible_wd/ansible-examples-master.tar.gz'
    else:
        assert False



# Generated at 2022-06-23 06:57:04.691271
# Unit test for method scm_archive_role of class RoleRequirement

# Generated at 2022-06-23 06:57:16.808831
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # Arrange
    role_requirement = RoleRequirement()

    # Act
    result = role_requirement.scm_archive_role(src='https://github.com/geerlingguy/ansible-role-apache.git')

    # Assert
    assert result['name'] == 'geerlingguy.apache'
    assert result['scm'] == 'git'
    assert result['path'] and result['path'].endswith('/ansible-role-apache')
    assert result['src'] == 'https://github.com/geerlingguy/ansible-role-apache.git'
    assert result['version'] == 'HEAD'

    # Act
    result = role_requirement.scm_archive_role(src='http://github.com/geerlingguy/ansible-role-apache.git')

   

# Generated at 2022-06-23 06:57:21.746787
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = 'https://github.com/ansible/ansible.git'
    scm = 'git'
    version = 'devel'
    folder, commit_hash = RoleRequirement.scm_archive_role(src, scm, version=version)
    assert commit_hash == 'devel'
    assert folder == 'ansible.git-devel'


# Generated at 2022-06-23 06:57:34.802775
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("geerlingguy.java,8.0.121") == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '8.0.121'}
    assert RoleRequirement.role_yaml_parse("https://github.com/geerlingguy/ansible-role-java.git,8.0.121") == {'name': 'ansible-role-java', 'src': 'https://github.com/geerlingguy/ansible-role-java.git', 'scm': None, 'version': '8.0.121'}

# Generated at 2022-06-23 06:57:45.981225
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # testing for src
    # TODO: check for existences of the role
    # TODO: check for different ways of getting the role
    # TODO: git://, ssh://
    # TODO: test with a tag
    # TODO: test with a branch
    # TODO: test with a commit id
    # TODO: test with a tarball url
    # TODO: test with a tarball url and a sha1
    # TODO: test with a tarball file
    # TODO: test with a tarball local file
    # TODO: test with a tarball local file and a sha1
    # TODO: test with a path
    # TODO: test with a path and a sha1
    # TODO: test with a path and a commit id

    # Should work equally
    assert RoleRequirement.role

# Generated at 2022-06-23 06:57:58.120420
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    res = RoleRequirement.scm_archive_role("https://github.com/ansible/ansible-examples.git")
    assert res.startswith("ansible-examples")
    res = RoleRequirement.scm_archive_role("git+https://github.com/ansible/ansible-examples.git")
    assert res.startswith("ansible-examples")
    res = RoleRequirement.scm_archive_role("https://github.com/ansible/ansible-examples.git", version="v0.1")
    assert res.startswith("ansible-examples-v0.1")
    res = RoleRequirement.scm_archive_role("https://github.com/ansible/ansible-examples.git", version="v0.1", name="test")
   

# Generated at 2022-06-23 06:58:07.794818
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import shutil

    # define variables to be used by the function
    src = 'https://github.com/erigones/ansible-role-examples.git'

    # call the method
    role_path = RoleRequirement.scm_archive_role(src)

    # test that a subdir was created
    assert os.path.isdir('test_role') is True

    # test that the role was extracted
    assert os.path.isdir('test_role/role_examples') is True

    # remove the created test_role subdir
    shutil.rmtree('test_role')

# Generated at 2022-06-23 06:58:14.358568
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Parse string
    role_dict = RoleRequirement.role_yaml_parse('src/my-custom-role')
    assert role_dict['name'] == 'my-custom-role'
    assert role_dict['src'] == 'src/my-custom-role'
    assert role_dict['version'] == ''
    assert role_dict['scm'] is None

    role_dict = RoleRequirement.role_yaml_parse('git+git@github.com/user/my-custom-role.git')
    assert role_dict['name'] == 'my-custom-role'
    assert role_dict['src'] == 'git@github.com/user/my-custom-role.git'
    assert role_dict['version'] == ''
    assert role_dict['scm'] == 'git'


# Generated at 2022-06-23 06:58:24.023936
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-23 06:58:36.542469
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    """
    Unit test for method repo_url_to_role_name
    """
    url = 'https://github.com/jshook/ansible-rabbitmq-role.git'
    assert RoleRequirement.repo_url_to_role_name(url) == 'ansible-rabbitmq-role'
    url2 = 'git+https://github.com/jshook/ansible-rabbitmq-role.git'
    assert RoleRequirement.repo_url_to_role_name(url2) == 'ansible-rabbitmq-role'
    url3 = 'https://github.com/jshook/ansible-rabbitmq-role.git,v2.2.0'

# Generated at 2022-06-23 06:58:46.478309
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from six.moves.urllib.parse import urlparse
    # In this unit test, we check the content of the dict returned
    # by RoleRequirement.scm_archive_role, a class method of RoleRequirement.
    # Tests are performed with different values of src URL (git, tar.gz and svn),
    # git version, scm version and version (tag, branch and commit).

    ## test_git_branch:
    # src: https://github.com/boukeversteegh/ansible-keepalived.git
    # version: HEAD
    # scm: git
    # branch: master

    # We check that the value of the key 'name' is 'ansible-keepalived'
    # We check that the value of the key 'repo' is
    # 'https://github.com/

# Generated at 2022-06-23 06:58:56.661803
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role = RoleRequirement()
    assert role.repo_url_to_role_name("http://github.com/bertrand/ansible-role-model_gen") == "ansible-role-model_gen"
    assert role.repo_url_to_role_name("http://github.com/bertrand/ansible-role-model_gen.git") == "ansible-role-model_gen"
    assert role.repo_url_to_role_name("http://github.com/bertrand/ansible-role-model_gen.tar.gz") == "ansible-role-model_gen"

# Generated at 2022-06-23 06:59:08.306626
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache.git') == 'ansible-role-apache'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache.git,v2.0.1') == 'ansible-role-apache'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache.git,v2.0.1,apache') == 'ansible-role-apache'

# Generated at 2022-06-23 06:59:18.093760
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo") == "repo"

# Generated at 2022-06-23 06:59:29.645261
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git+git@git.example.com:repos/repo.git") == "repo"

# Generated at 2022-06-23 06:59:41.473613
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role = RoleRequirement()
    assert role.repo_url_to_role_name('http://github.com/ansible/ansible-examples') == 'ansible-examples'
    assert role.repo_url_to_role_name('ansible.github.com/ansible/ansible-examples') == 'ansible.github.com/ansible/ansible-examples'
    assert role.repo_url_to_role_name('http://github.com/ansible/ansible-examples.git') == 'ansible-examples'
    assert role.repo_url_to_role_name('http://github.com/ansible/ansible-examples,v1.0') == 'ansible-examples'

# Generated at 2022-06-23 06:59:51.338696
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_role = {
      "scm": "git",
      "src": "https://github.com/geerlingguy/ansible-role-security.git",
      "version": "0.0.5"
    }
    assert RoleRequirement.role_yaml_parse(test_role) == test_role

    test_role = 'https://github.com/geerlingguy/ansible-role-security.git'
    assert RoleRequirement.role_yaml_parse(test_role) == {'version': '', 'scm': 'git', 'src': 'https://github.com/geerlingguy/ansible-role-security.git', 'name': 'ansible-role-security'}


# Generated at 2022-06-23 07:00:02.740752
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    display.debug("Testing RoleRequirement class")

    role_requirement = RoleRequirement()

    display.debug("Testing static method role_yaml_parse")
    src = 'https://github.com/user/role2.git'
    display.debug("Testing static method with string type argument")
    result = RoleRequirement.role_yaml_parse(src)
    assert result['name'] == 'role2'
    assert result['scm'] == 'git'
    assert result['src'] == 'https://github.com/user/role2.git'
    assert result['version'] == ''

    display.debug("Testing static method with dict type argument")
    result = RoleRequirement.role_yaml_parse(dict(src=src))
    assert result['name'] == 'role2'

# Generated at 2022-06-23 07:00:13.359388
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import tempfile
    import shutil

    # temp dir
    tempdir = tempfile.mkdtemp()

    # download source
    role = RoleRequirement.scm_archive_role(os.path.join(tempdir, "ansible-role-test"), scm='git', name="ansible-role-test", version='HEAD', keep_scm_meta=True)

    # check that dir ansible-role-test is created
    if not os.path.exists(os.path.join(tempdir, "ansible-role-test")):
        raise AssertionError("Test failed: Source repository is not downloaded.")

    # remove temp dir
    shutil.rmtree(tempdir)

# Generated at 2022-06-23 07:00:23.700640
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-23 07:00:31.382413
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("https://github.com/myorg/my-role") == "my-role"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/myorg/my-role.git") == "my-role"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/myorg/my-role") == "my-role"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/myorg/my-role.git") == "my-role"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/myorg/my-role,v1.0") == "my-role"
   

# Generated at 2022-06-23 07:00:36.675817
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    src = 'git+https://github.com/leucos/ansible-role-redis.git'

    role = RoleRequirement.scm_archive_role(src)

    assert role['role'] == 'redis'
    assert role['version'] == 'HEAD'
    assert role['scm'] == 'git'
    assert role['src'] == 'git+https://github.com/leucos/ansible-role-redis.git'

# Generated at 2022-06-23 07:00:47.943069
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print("Test RoleRequirement role_yaml_parse method ...")
    display.verbosity = 1

    # Test "role"
    role_name = 'foobar'
    role_dict = dict(name=role_name, version='', src='', scm=None)
    assert RoleRequirement.role_yaml_parse(role_name) == role_dict, \
        "Failed to parse role name (%s)" % (role_name)

    role_dict = dict(name=role_name, version='', src='', scm=None)
    assert RoleRequirement.role_yaml_parse(role_dict) == role_dict, \
        "Failed to parse role dict (%s)" % (role_dict)

    # Test "git+https://github.com/<repo_name>"
    repo_url

# Generated at 2022-06-23 07:00:54.407520
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    """
    Runs a series of tests for class RoleRequirement method scm_archive_role.
    """

# Generated at 2022-06-23 07:01:03.396259
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test = RoleRequirement()

    test_result = test.role_yaml_parse("test-galaxy-role,v1.0")
    assert test_result == {'name': 'test-galaxy-role', 'scm': None, 'src': 'test-galaxy-role', 'version': 'v1.0'}

    test_result = test.role_yaml_parse("git+https://github.com/opentable/ansible-role-test-galaxy-role.git,v1.0")
    assert test_result == {'name': 'ansible-role-test-galaxy-role', 'scm': 'git', 'src': 'https://github.com/opentable/ansible-role-test-galaxy-role.git', 'version': 'v1.0'}

    test_

# Generated at 2022-06-23 07:01:07.304578
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git+git@github.com:nathanleclaire/ansible-role-foo.git") == "ansible-role-foo"

# Generated at 2022-06-23 07:01:17.210771
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+https://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+https://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+https://git.example.com/repos/repo.git,v1.0,foo')

# Generated at 2022-06-23 07:01:28.408560
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import os
    import tempfile
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    loader = None
    variable_manager = VariableManager()

    context = PlayContext()
    context.update({
        'basedir': os.path.abspath(os.path.dirname(__file__) + '/../../../../'),
        'tempdir': tempfile.mkdtemp()
    })

    role = dict(role='git+https://github.com/foo/bar.git,feature_branch,some_dest_name')
    parsed_role = RoleRequirement.role_yaml_parse(role)

    assert parsed_role.get('scm') == 'git'

# Generated at 2022-06-23 07:01:40.293764
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert RoleRequirement.role_yaml_parse("") == {
        'name': '',
        'src': None,
        'scm': None,
        'version': None,
    }

    assert RoleRequirement.role_yaml_parse("role_name") == {
        'name': 'role_name',
        'src': None,
        'scm': None,
        'version': None,
    }

    assert RoleRequirement.role_yaml_parse("role_name:") == {
        'name': 'role_name',
        'src': None,
        'scm': None,
        'version': None,
    }


# Generated at 2022-06-23 07:01:49.656200
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    url = 'http://git.example.com/repos/repo.git'
    assert RoleRequirement.repo_url_to_role_name(url) == 'repo'

    url = 'http://git.example.com/repos/repo.git,test@test.test'
    assert RoleRequirement.repo_url_to_role_name(url) == 'repo'

    url = 'http://git.example.com/repos/repo.tar.gz'
    assert RoleRequirement.repo_url_to_role_name(url) == 'repo'

    url = 'http://git.example.com/repos/repo,test@test.test,test'
    assert RoleRequirement.repo_url_to_role_name(url) == 'repo'

   

# Generated at 2022-06-23 07:01:55.628586
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 07:02:07.209503
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/my_repo.tar.gz") == "my_repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/my_repo,other.tar.gz") == "my_repo"

# Generated at 2022-06-23 07:02:18.571838
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git@github.com:myorg/myrepo.git") == "myrepo"
    assert RoleRequirement.repo_url_to_role_name("http://github.com/myorg/myrepo.git") == "myrepo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/myorg/myrepo.git") == "myrepo"
    assert RoleRequirement.repo_url_to_role_name("ssh://git@github.com/myorg/myrepo.git") == "myrepo"
    assert RoleRequirement.repo_url_to_role_name("someusername@example.org:myorg/myrepo.git") == "myrepo"



# Generated at 2022-06-23 07:02:30.412322
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    assert(RoleRequirement.scm_archive_role("git+https://github.com/ansible/ansible-examples.git", scm='git', name='ansible-examples', version='HEAD').fetch_url=="https://github.com/ansible/ansible-examples/archive/HEAD.tar.gz")
    assert(RoleRequirement.scm_archive_role("https://github.com/ansible/ansible-examples.git", scm='git', name='ansible-examples', version='HEAD').fetch_url=="https://github.com/ansible/ansible-examples/archive/HEAD.tar.gz")

# Generated at 2022-06-23 07:02:41.720139
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    print("Test RoleRequirement")
    print(RoleRequirement.role_yaml_parse('http://github.com/usera/rolename'))
    print(RoleRequirement.role_yaml_parse('http://github.com/usera/rolename,v1.0'))
    print(RoleRequirement.role_yaml_parse('http://github.com/usera/rolename,v1.0,fred'))
    print(RoleRequirement.role_yaml_parse('role: usera.rolename'))
    print(RoleRequirement.role_yaml_parse('usera.rolename'))
    print(RoleRequirement.role_yaml_parse('usera.rolename,v1.0'))

# Generated at 2022-06-23 07:02:49.860087
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    repo_url = "https://github.com/fubarhouse/ansible-role-git.git"
    assert role_requirement.repo_url_to_role_name(repo_url) == "ansible-role-git"
    repo_url = "git@github.com:fubarhouse/ansible-role-git.git"
    assert role_requirement.repo_url_to_role_name(repo_url) == "ansible-role-git"

# Generated at 2022-06-23 07:02:58.405478
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role = "role_name"
    role_name = RoleRequirement.repo_url_to_role_name(role)
    assert role_name == "role_name"

    role = "role_name.tar.gz"
    role_name = RoleRequirement.repo_url_to_role_name(role)
    assert role_name == "role_name"

    role = "user@git.example.com:repos/repo.git"
    role_name = RoleRequirement.repo_url_to_role_name(role)
    assert role_name == "repo"

    role = "https://git.example.com/repos/repo.git"
    role_name = RoleRequirement.repo_url_to_role_name(role)

# Generated at 2022-06-23 07:03:10.524004
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from collections import OrderedDict

    # Test without fixed-order yaml loader
    assert RoleRequirement.role_yaml_parse('foo') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('foo,bar') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': 'bar'}
    assert RoleRequirement.role_yaml_parse('foo+bar') == {'name': 'foo', 'src': 'bar', 'scm': 'git', 'version': None}
    assert RoleRequirement.role_yaml_parse('foo,bar,baz') == {'name': 'baz', 'src': 'foo', 'scm': None, 'version': 'bar'}


# Generated at 2022-06-23 07:03:17.664454
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_yaml_metadata = {
        'role': 'aiohttp_session',
        'src': 'aiohttp_session.tar.gz',
        'version': '1.1.0'
    }

    assert RoleRequirement.role_yaml_parse(role_yaml_metadata) == role_yaml_metadata



# Generated at 2022-06-23 07:03:27.572302
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    simple_role = 'test_role'
    simple_role_dict = {'role': 'test_role'}
    expanded_role = 'test_role,v1.0'
    expanded_role_dict = {'role': 'test_role', 'version': 'v1.0'}
    expand_name_role = 'test_role,v1.0,new_name'
    expand_name_role_dict = {'role': 'test_role', 'version': 'v1.0', 'name': 'new_name'}
    scm_role = 'git+https://github.com/ansible/test_role.git'
    scm_role_dict = {'src': scm_role}

# Generated at 2022-06-23 07:03:35.200130
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/roles/foo") == "foo"
    assert role_requirement.repo_url_to_role_name("https://git.example.com/repos/roles/foo") == "foo"
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/roles/foo.git") == "foo"
    assert role_requirement.repo_url_to_role_name("http://github.com/repo/roles/bar.git") == "bar"

# Generated at 2022-06-23 07:03:47.604333
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement.role_yaml_parse("git+git@github.com:username/rolename.git,v1.2")
    assert role == dict(name="rolename", src="git@github.com:username/rolename.git", scm="git", version="v1.2")
    role = RoleRequirement.role_yaml_parse("rolename,v1.2")
    assert role == dict(name="rolename", src=None, scm=None, version="v1.2")
    role = RoleRequirement.role_yaml_parse("rolename,v1.2,machinename")
    assert role == dict(name="machinename", src=None, scm=None, version="v1.2")

# Generated at 2022-06-23 07:03:52.587635
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # Test for constructor with parameter
    role_requirement = RoleRequirement()

    assert isinstance(role_requirement, RoleRequirement)

# Test for method repo_url_to_role_name() of class RoleRequirement

# Generated at 2022-06-23 07:04:04.537824
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("foo") == dict(name="foo", src="foo", scm=None, version=None)
    assert RoleRequirement.role_yaml_parse("foo,bar") == dict(name="foo", src="foo", scm=None, version="bar")
    assert RoleRequirement.role_yaml_parse("foo,bar,baz") == dict(name="baz", src="foo", scm=None, version="bar")
    assert RoleRequirement.role_yaml_parse("git+https://github.com/ansible/ansible-examples,devel") == dict(name="ansible-examples", src="https://github.com/ansible/ansible-examples", scm='git', version="devel")
    assert RoleRequirement.role_yaml_

# Generated at 2022-06-23 07:04:14.086524
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    result = RoleRequirement.role_yaml_parse('geerlingguy.mysql,1.0.0')
    assert result['name'] == 'geerlingguy.mysql'
    assert result['scm'] is None
    assert result['src'] == 'geerlingguy.mysql'
    assert result['version'] == '1.0.0'

    result = RoleRequirement.role_yaml_parse('geerlingguy.mysql,v1.0.0')
    assert result['name'] == 'geerlingguy.mysql'
    assert result['scm'] is None
    assert result['src'] == 'geerlingguy.mysql'
    assert result['version'] == 'v1.0.0'


# Generated at 2022-06-23 07:04:15.664615
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.module_utils.six import b
    from ansible.module_utils._text import to_bytes

    # Test for __init__() of class RoleRequirement
    role = RoleRequirement()
    assert role



# Generated at 2022-06-23 07:04:28.430201
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # role_yaml_parse
    role = dict(name="git.example.com/repos/repo.git", src="galaxy.role,version,name", other_vars="here")
    result = RoleRequirement.role_yaml_parse(role)
    assert result["name"] == "repo"
    assert result["scm"] == None
    assert result["src"] == "galaxy.role,version,name"
    assert result["version"] == None

    role = dict(role="git.example.com/repos/repo.git")
    result = RoleRequirement.role_yaml_parse(role)
    assert result["name"] == "repo"
    assert result["scm"] == None
    assert result["src"] == "git.example.com/repos/repo.git"


# Generated at 2022-06-23 07:04:33.993711
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    role = RoleRequirement()
    role_dict = role.scm_archive_role(src='https://github.com/keinohguchi/ansible-role-dummy.git')
    assert role_dict == dict(scm='git', src='https://github.com/keinohguchi/ansible-role-dummy.git', name='ansible-role-dummy', version='HEAD', keep_scm_meta=False)

# Generated at 2022-06-23 07:04:45.508205
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Invalid input.
    try:
        RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz,v1.0")
        assert False, "Invalid role name should have thrown error."
    except AnsibleError:
        pass

    # Valid repo_url strings.
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("repo,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo.git"


# Generated at 2022-06-23 07:04:57.420401
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_data = {
        "role": "dummy_role,0.0.1",
        "role": "dummy_role,0.0.1,another_role_name"
    }
    for test_value in test_data.values():
        print ("Testing RoleRequirement.role_yaml_parse() with '%s'" % test_value)
        test_result = RoleRequirement.role_yaml_parse(test_value)
        print ("Result of test:", test_result)
        if test_result == {"name": "another_role_name", "role": "dummy_role,0.0.1,another_role_name", "scm": None, "src": "dummy_role", "version": "0.0.1"}:
            print ("Test passed")

# Generated at 2022-06-23 07:05:08.684390
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    result = RoleRequirement.scm_archive_role(
        src = 'https://github.com/test_user/test_repo.git',
        scm = 'git',
        name = 'test_role',
        version = 'an53x6gf7ch4b9',
    )
    assert result == '/tmp/test_ansible_roles/test_role-an53x6gf7ch4b9.tar.gz'
    result = RoleRequirement.scm_archive_role(
        src = 'test_author.test_repo',
        scm = 'galaxy',
    )
    assert result == '/tmp/test_ansible_roles/test_author.test_repo.tar.gz'

# Generated at 2022-06-23 07:05:21.508619
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 07:05:25.677290
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    assert RoleRequirement.scm_archive_role("https://github.com/geerlingguy/ansible-role-jenkins.git", scm="git") is not None


# Generated at 2022-06-23 07:05:33.297614
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # Invalid or missing src parameter
    #
    # No src argument
    try:
        RoleRequirement.scm_archive_role()

    except TypeError:
        pass

    # Empty src parameter
    result = RoleRequirement.scm_archive_role('')
    assert result is None, "Empty src parameter should not return an archive."

    # Invalid src parameter
    result = RoleRequirement.scm_archive_role('some_invalid_url')
    assert result is None, "Invalid src parameter should not return an archive"

    # Valid src parameter
    #
    # A github.com URL with no http(s) protocol
    assert RoleRequirement.scm_archive_role('github.com:myuser/myrepo,v1.0', scm='git').endswith('.tar.gz')

    # A