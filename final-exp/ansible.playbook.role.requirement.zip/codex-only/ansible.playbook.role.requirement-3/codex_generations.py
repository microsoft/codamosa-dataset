

# Generated at 2022-06-23 06:55:35.832352
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    roledef = RoleRequirement()


# Generated at 2022-06-23 06:55:37.035099
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    ''' test for init of class RoleRequirement '''
    rr = RoleRequirement()

# Generated at 2022-06-23 06:55:48.846003
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    test_role_files = ['meta/main.yml','tasks/main.yml','handlers/main.yml']

    # Test with a valid git url
    test_role = RoleRequirement.scm_archive_role('https://github.com/geerlingguy/ansible-role-tomcat.git', version='0.0.1')

    # Test if the zip file is extracted in a directory
    with zipfile.ZipFile(test_role, 'r') as zip_role:
        zip_role.extractall(path=tempfile.mkdtemp())
        extracted_role_files = [name for name in os.listdir(zip_role.namelist()[0])]

    assert test_role_files == extracted_role_files

    # Test with a valid hg url
    test_role = Role

# Generated at 2022-06-23 06:55:57.326896
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile
    import os
    import shutil
    import yaml
    from ansible.constants import COLLECTIONS_PATH

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary ansible collections path
    tmp_collections_path = os.path.join(tmp_dir, 'ansible_collections')
    os.mkdir(tmp_collections_path)

    # Set the ansible collections path to the temporary ansible collections path
    COLLECTIONS_PATH = tmp_collections_path

    # Get the path of the AnsiballZ_RoleRequirement.scm_archive_role function
    path_scm_archive_role = os.path.join(COLLECTIONS_PATH, 'AnsiballZ_RoleRequirement.scm_archive_role.py')

# Generated at 2022-06-23 06:56:08.495681
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    roledef = RoleRequirement()

    # Basic Test
    assert roledef.role_yaml_parse("git+https://github.com/user/gitrepo.git")['name'] == "gitrepo"
    assert roledef.role_yaml_parse("git+https://github.com/user/gitrepo.git")['scm'] == "git"
    assert roledef.role_yaml_parse("git+https://github.com/user/gitrepo.git")['src'] == "https://github.com/user/gitrepo.git"
    assert roledef.role_yaml_parse("git+https://github.com/user/gitrepo.git")['version'] == ""

    # Default version

# Generated at 2022-06-23 06:56:20.166092
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # pylint: disable=unused-variable

    # test new style
    test_dict = RoleRequirement.role_yaml_parse({'src': 'geerlingguy.apache', 'version': 'v0.1.6'})
    assert test_dict == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v0.1.6'}
    test_dict = RoleRequirement.role_yaml_parse({'src': 'https://github.com/geerlingguy/ansible-role-apache.git', 'version': 'v0.1.6'})

# Generated at 2022-06-23 06:56:21.814929
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    assert isinstance(role,RoleRequirement)

# Generated at 2022-06-23 06:56:30.155695
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.constants import ROLE_CACHE_PATH

    src = 'https://github.com/jdauphant/ansible-role-rsyslog.git'
    out = RoleRequirement.scm_archive_role(src, version='master')
    assert out.endswith('.tar.gz')

    print(" \n RoleRequirement: src {} \n ".format(src))
    print(" \n RoleRequirement: out {} \n ".format(out))
    print(" \n RoleRequirement: ROLE_CACHE_PATH {} \n ".format(ROLE_CACHE_PATH))

# Generated at 2022-06-23 06:56:41.605797
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # test with scm_archive_resource, keep_scm_meta=True, HEAD,
    # git, no name

    scm = 'git'
    src = "https://github.com/galaxyproject/ansible-galaxy"
    name = None
    version = 'HEAD'
    keep_scm_meta = True
    expected = ('git', 'git+https://github.com/galaxyproject/ansible-galaxy,HEAD')
    result = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)
    assert (expected == result)

    # test with scm_archive_resource, keep_scm_meta=False, HEAD, git, no name
    keep_scm_meta = False

# Generated at 2022-06-23 06:56:52.662407
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()

    role_yml = role.role_yaml_parse('test')
    assert role_yml['name'] == 'test'
    assert role_yml['src'] == 'test'
    assert role_yml['scm'] is None
    assert role_yml['version'] == ''

    role_yml = role.role_yaml_parse('test,1.0')
    assert role_yml['name'] == 'test'
    assert role_yml['src'] == 'test'
    assert role_yml['scm'] is None
    assert role_yml['version'] == '1.0'

    role_yml = role.role_yaml_parse('test1,1.0,test')
    assert role_yml['name'] == 'test'

# Generated at 2022-06-23 06:56:54.740210
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    my_role = RoleRequirement()
    assert isinstance(my_role, RoleRequirement)


# Generated at 2022-06-23 06:57:06.105214
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 06:57:10.734988
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Simple test for constructor
    role_req_obj = RoleRequirement()
    assert role_req_obj


# Generated at 2022-06-23 06:57:21.305549
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    url1 = 'https://github.com/username/ansible-role-test'
    name1 = 'test'

    url2 = "git://foo.example.com/path/to/repo.git"
    name2 = "repo"

    url3 = "git@git.example.com:user/repo.git"
    name3 = "repo"

    url4 = "git+https://git@git.example.com/user/repo.git"
    name4 = "repo"

    url5 = "hg+http://hg.example.com/hg/repo-name"
    name5 = "repo-name"

    url6 = "https://github.com/username/ansible-role-test/tarball/test"
    name6 = "test"


# Generated at 2022-06-23 06:57:27.613924
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 06:57:38.901333
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import ansible.constants as C
    import tempfile
    import os
    import shutil
    import ansible.release
    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 06:57:49.231770
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert("galaxy_server,version,name" == RoleRequirement.role_yaml_parse("galaxy_server,version,name")['src'])
    assert("galaxy_server" == RoleRequirement.role_yaml_parse("galaxy_server,version,name")['name'])
    assert("galaxy_server,version,name" == RoleRequirement.role_yaml_parse("galaxy_server,version,")['src'])
    assert("galaxy_server" == RoleRequirement.role_yaml_parse("galaxy_server,version,")['name'])
    assert("galaxy_server" == RoleRequirement.role_yaml_parse("galaxy_server")['src'])

# Generated at 2022-06-23 06:57:58.480158
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo.git'
    assert RoleRequirement.repo_url_to_role_name('git+http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+http://git.example.com/repos/repo.git,v1.0') == 'repo.git'

# Generated at 2022-06-23 06:58:04.792701
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    
    role_scm_archive = RoleRequirement.scm_archive_role('https://github.com/datadrivers/ansible-role-postgresql',
                                                        scm='git',
                                                        name='postgresql')

    assert 'ansible_role_postgresql' in role_scm_archive
    assert 'postgresql' in role_scm_archive

# Generated at 2022-06-23 06:58:12.077246
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    import json

    def assert_role_requirement(data):
        role_requirement = RoleRequirement()
        role_requirement_data = role_requirement.role_yaml_parse(data)
        role_definition_data = RoleDefinition.parse(data)
        assert json.dumps(role_requirement_data, sort_keys=True) == json.dumps(role_definition_data, sort_keys=True)

    assert_role_requirement("git+http://git.example.com/repos/repo.git")
    assert_role_requirement("git+http://git.example.com/repos/repo.git,v1.2")
    assert_role

# Generated at 2022-06-23 06:58:23.601382
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # test string type
    # simple, string type case
    test_subject = RoleRequirement()
    result = test_subject.role_yaml_parse('ansible-role-yum')
    expected = {'name': 'yum', 'scm': None, 'src': 'ansible-role-yum', 'version': None}
    assert result == expected

    # 2 elements, string type case
    result = test_subject.role_yaml_parse('ansible-role-yum,1.0')
    expected = {'name': 'yum', 'scm': None, 'src': 'ansible-role-yum', 'version': '1.0'}
    assert result == expected

    # 3 elements, string type case

# Generated at 2022-06-23 06:58:27.320141
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_definition = RoleRequirement()

    assert not role_definition.warnings
    assert not role_definition.deprecated
    assert not role_definition.notice
    assert not role_definition.description

# Generated at 2022-06-23 06:58:33.610832
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert 'role1' == RoleRequirement.repo_url_to_role_name('role1')
    assert 'role2' == RoleRequirement.repo_url_to_role_name('https://role2')
    assert 'role3' == RoleRequirement.repo_url_to_role_name('git@role3')
    assert 'role4' == RoleRequirement.repo_url_to_role_name('git@role4.git')
    assert 'role5' == RoleRequirement.repo_url_to_role_name('https://role5.git')
    assert 'role6' == RoleRequirement.repo_url_to_role_name('git@role6.git,1.0')

# Generated at 2022-06-23 06:58:45.193418
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.dotfiles') == {'name': 'geerlingguy.dotfiles', 'src': 'geerlingguy.dotfiles', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.dotfiles,1.0.0') == {'name': 'geerlingguy.dotfiles', 'src': 'geerlingguy.dotfiles', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.dotfiles,1.0.0,dotfiles') == {'name': 'dotfiles', 'src': 'geerlingguy.dotfiles', 'scm': None, 'version': '1.0.0'}


# Generated at 2022-06-23 06:58:56.122374
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # Test Setup:
    # Create a temporary dir
    # Clone source code repo in temp dir (only checkout stable branch)
    import os
    import tempfile
    import shutil
    import git
    import tarfile
    import json


    # Test Setup:
    # Create a temporary dir
    # Clone source code repo in temp dir (only checkout stable branch)
    tmpdir = tempfile.mkdtemp()
    mytmpdir = tmpdir + '/mytmpdir'
    source_code_repo_dir = tmpdir + '/test_ansible_collections_role_test_collection'
    target_dir = tmpdir + '/test_unpack'
    print('Temp dir: ' + tmpdir)
    print('Temp dir: ' + mytmpdir)
    print('Temp dir: ' + source_code_repo_dir)


# Generated at 2022-06-23 06:59:04.454013
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Should return the role name from a given repo url,
    # e.g. "http://git.ansible.com/galaxy/repo.git" => "repo"
    repo_url = "http://git.ansible.com/galaxy/repo.git"
    assert RoleRequirement.repo_url_to_role_name(repo_url) == 'repo'

    # Should return the role name from a given repo url,
    # e.g. "https://git.ansible.com/galaxy/repo.git" => "repo"
    repo_url = "https://git.ansible.com/galaxy/repo.git"
    assert RoleRequirement.repo_url_to_role_name(repo_url) == 'repo'

    # Should return the role name

# Generated at 2022-06-23 06:59:08.690287
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role1 = {'role': 'git+https://github.com/geerlingguy/ansible-role-apache.git'}
    result = RoleRequirement.role_yaml_parse(role1)
    assert (result.get('name') == 'ansible-role-apache')
    assert (result.get('version') == '')
    assert (result.get('scm') == 'git')
    assert (result.get('src') == 'https://github.com/geerlingguy/ansible-role-apache.git')

    role2 = {'role': 'ansible-role-apache'}
    result = RoleRequirement.role_yaml_parse(role2)
    assert (result.get('name') == 'ansible-role-apache')
    assert (result.get('version') == '')
   

# Generated at 2022-06-23 06:59:10.788219
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Test normal constructor
    test_instance = RoleRequirement()
    assert test_instance != None


# Generated at 2022-06-23 06:59:15.212009
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Create a RoleRequirement
    rr = RoleRequirement()
    # Check if rr is an instance of RoleRequirement
    assert isinstance(rr, RoleRequirement)
    # Check if the class variable has the right value
    assert rr.VALID_SPEC_KEYS == ['name', 'role', 'scm', 'src', 'version']

# Generated at 2022-06-23 06:59:23.530595
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    src = 'https://github.com/jkremser/ansible-role-kafka.git'
    name = 'jkremser.kafka'
    version = 'e83f0d2d84baf35403653c359afd9a9e05c887a3'

    assert(RoleRequirement.scm_archive_role(src, version=version, name=name) == (name, version))

# Generated at 2022-06-23 06:59:29.140816
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # Tested using python2.7 on ubuntu 16.04
    scm_archive_role = RoleRequirement.scm_archive_role
    assert scm_archive_role('https://github.com/c00kiemon5ter/rainbow-bash', version='master') == \
           '/tmp/ansible_rainbow-bash_master.tar.gz'

# Generated at 2022-06-23 06:59:36.472648
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # Test String
    result = RoleRequirement.scm_archive_role('http://github.com/ansible/ansible-modules-core.git',
                                              scm='git',
                                              name='ansible-modules-core',
                                              version='HEAD')
    assert result == ("https://github.com/ansible/ansible-modules-core/archive/HEAD.tar.gz", "HEAD")

    # Test String
    result = RoleRequirement.scm_archive_role('http://github.com/ansible/ansible-modules-core.git',
                                              scm='git',
                                              name='ansible-modules-core',
                                              version='v2.2.1.0-1')


# Generated at 2022-06-23 06:59:42.405926
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    test_role = dict(
        name='test',
        src='git+https://github.com/ansible/ansible-examples.git',
        scm='git',
        version='HEAD'
    )

    role_requirement = RoleRequirement.role_yaml_parse(test_role)

    assert(role_requirement == test_role)

# Generated at 2022-06-23 06:59:43.417967
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    RoleRequirement()


# Generated at 2022-06-23 06:59:52.584508
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 07:00:00.322820
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = "https://github.com/AnsibleShipyard/ansible_test_role"
    name = "role_name"
    scm_archive_role = RoleRequirement.scm_archive_role(src, name=name)
    assert scm_archive_role == {
        "name": name,
        "path": "./" + name,
        "src": src,
        "version": "HEAD"
    }
    src = "https://github.com/AnsibleShipyard/ansible_test_role"
    name = "role_name"
    scm_archive_role = RoleRequirement.scm_archive_role(src, name=name, version="v2.2")

# Generated at 2022-06-23 07:00:12.319151
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # test if the class constructor works
    rr = RoleRequirement()

    # test if RoleRequirement.role_yaml_parse works
    assert rr.role_yaml_parse({'src': 'galaxy.role,version,name', 'x': 'y'}) == {'name': 'name', 'src': 'galaxy.role', 'scm': 'git', 'version': 'version', 'x': 'y'}

    assert rr.role_yaml_parse({'role': 'galaxy.role,version,name', 'x': 'y'}) == {'name': 'name', 'src': 'galaxy.role', 'scm': 'git', 'version': 'version', 'x': 'y'}


# Generated at 2022-06-23 07:00:23.542447
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import shutil
    import tempfile
    import filecmp
    import stat

# Generated at 2022-06-23 07:00:35.177176
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    assert RoleRequirement.scm_archive_role('jdauphant/ansible-role-nginx', 'git', 'ansible-role-nginx', '88ef8075a537a6e894ce9873e7f4c4e1d4c1b972') == 'source=http://github.com/jdauphant/ansible-role-nginx,name=ansible-role-nginx,version=88ef8075a537a6e894ce9873e7f4c4e1d4c1b972'

# Generated at 2022-06-23 07:00:42.748348
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    git_repo = "https://github.com/ansible/test-collection-ansible_collections_test.git"
    role = RoleRequirement.scm_archive_role(git_repo, scm='git', version='v1.0.0')
    display.display("%s" % role)
    assert(role.startswith("/private"))

if __name__ == '__main__':
    test_RoleRequirement_scm_archive_role()

# Generated at 2022-06-23 07:00:56.139408
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    role_name = 'test_role'
    src = 'https://github.com/user_name/test_repo'
    name = None
    version = 'HEAD'
    keep_scm_meta = False
    result = RoleRequirement.scm_archive_role(src=src, name=name, version=version, keep_scm_meta=keep_scm_meta)
    assert result == "/tmp/ansible/test_role", "scm_archive_role() returned unexpected result"

# Generated at 2022-06-23 07:01:07.037081
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    src = "http://git.server.com/repo.git"
    role = RoleRequirement.repo_url_to_role_name(src)
    assert role == "repo", "role should be equal to repo instead of [%s]" % role

    src = "http://git.server.com/repo.tar.gz"
    role = RoleRequirement.repo_url_to_role_name(src)
    assert role == "repo", "role should be equal to repo instead of [%s]" % role

    src = "http://git.server.com/repo,v2.1.1.tar.gz"
    role = RoleRequirement.repo_url_to_role_name(src)
    assert role == "repo", "role should be equal to repo instead of [%s]" % role

# Generated at 2022-06-23 07:01:17.019381
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    assert role
    assert role.repo_url_to_role_name("git+http://git.example.com/repos/repo.git") == "repo"
    assert role.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role.repo_url_to_role_name("git://git.example.com:repos/repo.git") == "repo"
    assert role.repo_url_to_role_name("user@git.example.com:repos/repo.git") == "repo"
    assert role.repo_url_to_role_name("git.example.com:repos/repo.git") == "repo"

# Generated at 2022-06-23 07:01:28.242972
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # galaxy.yml style
    assert RoleRequirement.role_yaml_parse({'src': 'git+https://github.com/ansible/ansible-examples.git'}) == \
        {'version': None, 'name': 'ansible-examples', 'src': 'https://github.com/ansible/ansible-examples.git', 'scm': 'git'}
    assert RoleRequirement.role_yaml_parse({'src': 'git+https://github.com/ansible/ansible-examples.git,devel'}) == \
        {'version': 'devel', 'name': 'ansible-examples', 'src': 'https://github.com/ansible/ansible-examples.git', 'scm': 'git'}
    assert RoleRequirement.role_yaml_parse

# Generated at 2022-06-23 07:01:29.075575
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    requirement = RoleRequirement()
    assert requirement

# Generated at 2022-06-23 07:01:35.179451
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.galaxy.role import GalaxyRole

    role = RoleRequirement.scm_archive_role(src="https://github.com/mivok/mivok.github.io.git", name="mivok.github.io", version="HEAD")
    assert isinstance(role, GalaxyRole)

    role = RoleRequirement.scm_archive_role(src="https://github.com/mivok/mivok.github.io.git", name="mivok.github.io", version="HEAD", keep_scm_meta=True)
    assert isinstance(role, GalaxyRole)

    role = RoleRequirement.scm_archive_role(src="https://github.com/mivok/mivok.github.io.git", name="mivok.github.io")

# Generated at 2022-06-23 07:01:45.539969
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 07:01:47.161702
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    assert role_requirement != None


# Generated at 2022-06-23 07:01:54.213070
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    """
    Utility function to test class RoleRequirement.
    """


# Generated at 2022-06-23 07:02:05.269292
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = "http://github.com/example/repo"
    role = RoleRequirement.scm_archive_role(src)
    assert role.name == "repo"
    assert role.version == 'HEAD'
    assert role.scm == 'git'
    role = RoleRequirement.scm_archive_role(src, scm='hg')
    assert role.name == "repo"
    assert role.version == 'HEAD'
    assert role.scm == 'hg'
    role = RoleRequirement.scm_archive_role(src, version='v2.2.2')
    assert role.name == "repo"
    assert role.version == 'v2.2.2'
    assert role.scm == 'git'

# Generated at 2022-06-23 07:02:06.568673
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()

    assert role_requirement

# Generated at 2022-06-23 07:02:18.295523
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+git://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+git://git.example.com/repos/repo,version') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+git://git.example.com/repos/repo,version,name') == 'repo'

# Generated at 2022-06-23 07:02:30.221873
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    valid_role_defs = [
        ('src', '', 'src'),
        ('src,version', 'version', 'src'),
        ('src,version,name', 'name', 'src'),
        ('src,version,name,other', 'name', 'src'),
        ('name,version,src', 'name', 'src'),
        ('name,version,src,other', 'name', 'src'),
        ('src,version,name,other', 'name', 'src'),
    ]
    invalid_role_defs = [
        'src,version,name,other,another',
        '',
    ]

    for role_def in valid_role_defs:
        role_def_result = RoleRequirement.role_yaml_parse(role_def[0])

# Generated at 2022-06-23 07:02:41.570022
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    wrong_specs_1 = {
        'name': 'name',
        'src': 'src',
        'role': 'role',
        'version': 'version',
        'scm': 'scm'
    }
    wrong_specs_2 = {
        'name': 'name',
        'src': 'src',
        'version': 'version',
        'scm': 'scm'
    }
    right_specs = {
        'name': 'name',
        'src': 'src',
        'version': 'version',
        'scm': 'scm'
    }
    wrong_string_specs_1 = 'name,version,src,role,scm'

# Generated at 2022-06-23 07:02:52.584673
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse('../a-role,v1')
    assert role['src'] == '../a-role'
    assert role['name'] == 'a-role'
    assert role['version'] == 'v1'
    assert role['scm'] is None

    role = RoleRequirement.role_yaml_parse('../a-role,v1,another-role')
    assert role['src'] == '../a-role'
    assert role['name'] == 'another-role'
    assert role['version'] == 'v1'
    assert role['scm'] is None

    role = RoleRequirement.role_yaml_parse('../a-role,v1,another-role,v2')
    assert role['src'] == '../a-role'

# Generated at 2022-06-23 07:03:00.468991
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert(RoleRequirement.role_yaml_parse("geerlingguy.apache") == dict(name='geerlingguy.apache', src='geerlingguy.apache', scm=None, version=''))
    assert(RoleRequirement.role_yaml_parse("geerlingguy.apache,1.9.0") == dict(name='geerlingguy.apache', src='geerlingguy.apache,1.9.0', scm=None, version='1.9.0'))

# Generated at 2022-06-23 07:03:14.113055
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = "ansible-role-apache"
    r = RoleRequirement.role_yaml_parse(role)
    assert r['name'] == "ansible-role-apache"
    assert r['src'] == "ansible-role-apache"
    assert r['version'] == None
    assert r['scm'] == None

    role = "apache"
    r = RoleRequirement.role_yaml_parse(role)
    assert r['name'] == "apache"
    assert r['src'] == "apache"
    assert r['version'] == None
    assert r['scm'] == None

    role = "ansible-role-apache,v2.1"
    r = RoleRequirement.role_yaml_parse(role)
    assert r['name'] == "ansible-role-apache"

# Generated at 2022-06-23 07:03:25.111575
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('scm+https://github.com/maier/ansible-role-foo.git,0.1.2') == {'name': 'ansible-role-foo', 'version': '0.1.2', 'scm': 'scm', 'src': 'https://github.com/maier/ansible-role-foo.git'}
    assert RoleRequirement.role_yaml_parse('https://github.com/maier/ansible-role-foo.git,0.1.2') == {'name': 'ansible-role-foo', 'version': '0.1.2', 'scm': None, 'src': 'https://github.com/maier/ansible-role-foo.git'}

# Generated at 2022-06-23 07:03:36.136403
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git.example.com/repos/repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.re

# Generated at 2022-06-23 07:03:48.100444
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    display.verbosity = 2
    display.debug("testing")

    # check scm_archive_role

    try:
        RoleRequirement.scm_archive_role(None)
    except TypeError as e:
        assert e.args[0] == "scm_archive_role() takes at least 2 arguments (1 given)"

    # check git
    assert "https://github.com/some_role/some_role.git" == RoleRequirement.scm_archive_role(src="some_role", scm="git")

    # check bzr
    assert "lp:ansible-role-some_role" == RoleRequirement.scm_archive_role(src="some_role", scm="bzr")

    # check hg

# Generated at 2022-06-23 07:04:01.207007
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    test_role_requirement = RoleRequirement()
    test_role_requirement.role_yaml_parse("galaxy.role,v1,name")
    test_role_requirement.role_yaml_parse("galaxy.role,version")
    test_role_requirement.role_yaml_parse("galaxy.role")
    test_role_requirement.role_yaml_parse("git+git://github.com/foo/bar.git")
    test_role_requirement.role_yaml_parse("git+git://bad.protocol/foo/bar.git")
    test_role_requirement.role_yaml_parse("github.com/foo/bar.git,tag")
    test_role_requirement.role_yaml_parse("foo/bar")

    return "OK"

# Generated at 2022-06-23 07:04:12.052038
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert RoleRequirement.role_yaml_parse('foo,v1.2') == {"src": 'foo', "name": 'foo', "scm": None, "version": 'v1.2'}
    assert RoleRequirement.role_yaml_parse({'role': 'foo'}) == {"name": 'foo', "scm": None, "src": None, "version": None}
    assert RoleRequirement.role_yaml_parse({"role": "foo,v1.2"}) == {"name": 'foo', "scm": None, "src": None, "version": 'v1.2'}

# Generated at 2022-06-23 07:04:24.161287
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # Testing with a simple source
    role = RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git')
    assert role.get('scm') is None
    assert role.get('src') == 'http://git.example.com/repos/repo.git'
    assert role.get('version') is None

    # Testing with a tagged version
    role = RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,0.1')
    assert role.get('scm') is None
    assert role.get('src') == 'http://git.example.com/repos/repo.git'
    assert role.get('version') == '0.1'

    # Testing with a tagged version and a defined role name


# Generated at 2022-06-23 07:04:35.242566
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    res = RoleRequirement.scm_archive_role(src='git+https://github.com/jdauphant/ansible-role-nginx',
                                           scm='git',
                                           name='nginx',
                                           version='d589f8958cbdbcb6f5c40a9f1cbf9e836b6a301f',
                                           keep_scm_meta=False)

# Generated at 2022-06-23 07:04:46.752397
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test 1:
    # Test the case when the input is a string
    resultDict_1 = RoleRequirement.role_yaml_parse(
        {'src': 'webapp.role', 'scm': 'git', 'version': 'master'})
    # Test case should return: { 'name': 'webapp.role', 'scm': 'git', 'src':
    # 'webapp.role', 'version': 'master'}
    assert resultDict_1 == {
        'name': 'webapp.role', 'scm': 'git', 'src': 'webapp.role', 'version': 'master'}

    # Test 2:
    # Test the case when the input is a string

# Generated at 2022-06-23 07:04:55.448088
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # test coverage for:
    # https://github.com/ansible/ansible/issues/11993
    # https://github.com/ansible/ansible-modules-core/issues/2754
    src = 'https://github.com/ansible/ansible-modules-core'
    src_name = 'ansible-modules-core'
    src_version = 'v2.3.0.0-1'

    for scm in ('git', 'hg', 'svn'):
        role_name = RoleRequirement.scm_archive_role(src, scm, name=src_name, version=src_version)
        assert role_name == 'ansible-modules-core-v2.3.0.0-1'

# Generated at 2022-06-23 07:04:56.952941
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    assert role is not None

# Generated at 2022-06-23 07:05:09.240434
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 07:05:17.222967
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    test_name = "test_role_name"
    test_src = "http://github.com/user/"+test_name+".git"
    test_version = "HEAD"
    test_keep_meta = False

    # git clone
    result = RoleRequirement.scm_archive_role(test_src, name=test_name, version=test_version, keep_scm_meta=test_keep_meta)
    assert result.endswith(".tar.gz")

    # git archive
    result = RoleRequirement.scm_archive_role(test_src, name=test_name, version=test_version, keep_scm_meta=True)
    assert result.endswith(".tar.gz")

    # git clone from local path

# Generated at 2022-06-23 07:05:27.337806
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import BytesIO

    # prepare
    src_git_tarball = b"git_tarball"
    src_git_bare = b"git_bare"
    src_hg_tarball = b"hg_tarball"
    src_hg_bare = b"hg_bare"
    src_unsupported = b"unsupported"

    scm_git = 'git'
    scm_hg = 'hg'
    scm_unsupported = 'unsupported'

    name = 'role_name'
    version = 'HEAD'
    keep_scm_meta = False

    # mock