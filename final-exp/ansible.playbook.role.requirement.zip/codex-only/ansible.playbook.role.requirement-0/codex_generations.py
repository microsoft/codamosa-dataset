

# Generated at 2022-06-23 06:55:23.751576
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = "https://github.com/example"
    scm = "git"
    name = None
    version = "HEAD"
    keep_scm_meta = False
    result = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)
    ## expected result : if git clone cannot happen because of permission issue, it will raise exception
    if result.endswith("example"): 
        assert False
    else:
        assert True

# Generated at 2022-06-23 06:55:27.427668
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # This test case is a bit silly, but it seems like overkill to write a
    # more complex one

    role_requirement = RoleRequirement()

    assert role_requirement.repo_url_to_role_name('something') == 'something'

# Generated at 2022-06-23 06:55:38.610747
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # String
    input_dict = {
        "src": 'http://git.example.com/repos/repo.git,0.1.1,repo',
    }
    expected_output = {'src': 'http://git.example.com/repos/repo.git', 'scm': None, 'name': 'repo', 'version': '0.1.1'}
    assert expected_output == RoleRequirement.role_yaml_parse(input_dict), "role_yaml_parse should return '%s' but returned '%s'" % (expected_output, RoleRequirement.role_yaml_parse(input_dict))

    input_dict = {
        "src": 'http://git.example.com/repos/repo.git',
    }

# Generated at 2022-06-23 06:55:42.950529
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    assert hasattr(role_requirement, 'role_yaml_parse')
    assert hasattr(role_requirement, 'repo_url_to_role_name')



# Generated at 2022-06-23 06:55:46.607575
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.playbook.role.definition import RoleDefinition
    rq = RoleRequirement()
    rd = RoleDefinition()

    assert rq.__class__.__bases__ == (rd.__class__,)



# Generated at 2022-06-23 06:55:55.880692
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+git@git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+https://git.example.com/repos/name,v1.0') == 'name'
    assert RoleRequirement.repo_url_to_role_name('git+http://git.example.com/repos/name.tar.gz') == 'name'

# Generated at 2022-06-23 06:56:01.996505
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os

    # In order to run this test:
    #  - clone the geerlingguy/ansible-role-apache role into a directory
    #  - run this test
    #  - the role should be downloaded and extracted into a temporary directory
    #  - delete the temporary directory
    test_dir = os.path.dirname(os.path.realpath(__file__))
    src = os.path.join(test_dir, 'ansible-role-apache')
    scm='git'
    name='apache'
    version='HEAD'
    keep_scm_meta=False
    role_path = RoleRequirement.scm_archive_role(src, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta)
    assert role_path != None


# Generated at 2022-06-23 06:56:13.400572
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    out = RoleRequirement.role_yaml_parse({'role': 'jdauphant.nginx', 'vars': {"testvar1": "somevalue"}})
    assert out == {'name': 'jdauphant.nginx', 'scm': None, 'src': None, 'version': None, 'vars': {'testvar1': 'somevalue'}}, "role_yaml_parse accepted an old-style requirement: %s" % out

    out = RoleRequirement.role_yaml_parse({'src': 'git+https://github.com/geerlingguy/ansible-role-apache.git', 'vars': {"testvar2": "somevalue2"}})

# Generated at 2022-06-23 06:56:14.564457
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    role_requirement = RoleRequirement()
    assert role_requirement

# Generated at 2022-06-23 06:56:24.803240
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    result = RoleRequirement.role_yaml_parse("geerlingguy.apache")
    assert result["name"] == "geerlingguy.apache"
    assert result["src"] == "geerlingguy.apache"
    assert result["scm"] is None
    assert result["version"] == ""
    result2 = RoleRequirement.role_yaml_parse("https://github.com/geerlingguy/ansible-role-apache,1.4.1,geerlingguy.apache")
    assert result2["name"] == "geerlingguy.apache"
    assert result2["src"] == "https://github.com/geerlingguy/ansible-role-apache"
    assert result2["scm"] == "git"
    assert result2["version"] == "1.4.1"
    result3 = Role

# Generated at 2022-06-23 06:56:36.588312
# Unit test for constructor of class RoleRequirement

# Generated at 2022-06-23 06:56:47.728586
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    display.display("Test RoleRequirement")

    # test case 1
    display.display("  test case 1")

    test_role = {'name': 'ansible-galaxy-role-requirement', 'src': 'https://github.com/username/ansible-galaxy-role-requirement', 'scm': 'git', 'version': '1.0.0'}
    test_role_requirement = RoleRequirement.role_yaml_parse(test_role)

    assert test_role == test_role_requirement

    # test case 2
    display.display("  test case 2")

    test_role = 'ansible-galaxy-role-requirement'
    test_role_requirement = RoleRequirement.role_yaml_parse(test_role)


# Generated at 2022-06-23 06:56:50.589911
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    assert RoleRequirement.scm_archive_role(src="ansible/ansible", scm="git") == "https://github.com/ansible/ansible/archive/HEAD.tar.gz"



# Generated at 2022-06-23 06:57:02.290376
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-23 06:57:10.614690
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    """
    Unit test for method repo_url_to_role_name of class RoleRequirement
    """
    # unit test for repo_url_to_role_name method

# Generated at 2022-06-23 06:57:15.365914
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    assert role_requirement.role_yaml_parse("test") == {'name': 'test', 'src': 'test', 'scm': None, 'version': None}
    assert role_requirement.role_yaml_parse("test,v1") == {'name': 'test', 'src': 'test', 'scm': None, 'version': 'v1'}
    assert role_requirement.role_yaml_parse("test,v1,newname") == {'name': 'newname', 'src': 'test', 'scm': None, 'version': 'v1'}

# Generated at 2022-06-23 06:57:30.826034
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # We use a helper class to test a static method
    role_requirement = RoleRequirement()

    # A string should parse to a simple role definition
    assert role_requirement.role_yaml_parse('foo') == dict(name='foo', src='foo', scm=None, version='')

    assert role_requirement.role_yaml_parse('git+https://github.com/foo/bar.git,mybranch') == dict(name='bar', src='https://github.com/foo/bar.git', scm='git', version='mybranch')

    # When a name is specified, should use it
    assert role_requirement.role_yaml_parse('foo,bar') == dict(name='bar', src='foo', scm=None, version='')

    # New style: { src: 'gal

# Generated at 2022-06-23 06:57:31.401490
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    pass

# Generated at 2022-06-23 06:57:41.650060
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    from ansible_collections.ansible.community.tests.unit.galaxy.conftest import mock_galaxy_context
    from ansible_collections.ansible.community.plugins.module_utils.ansible_galaxy import fetch_role_local_deps

    ansible_galaxy_context = mock_galaxy_context(
        **{
            "output_path": "/tmp/ansible_galaxy",
            "ansible_version": "2.7.10",
            "no_deps": False,
            "ignore_certs": False,
            "server_list": None,
            "force": False,
            "offline": False,
            "role_file": None,
            "collections_paths": None,
        },
    )

    result = RoleRequirement.scm_archive_

# Generated at 2022-06-23 06:57:52.809248
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    from ansible.playbook.role.requirement import RoleRequirement
    assert (RoleRequirement.repo_url_to_role_name("https://github.com/steampunk-ph/ansible-role-st2.git") == "ansible-role-st2")
    assert (RoleRequirement.repo_url_to_role_name("https://github.com/steampunk-ph/ansible-role-st2,v1.0.0") == "ansible-role-st2")
    assert (RoleRequirement.repo_url_to_role_name(
        "https://github.com/steampunk-ph/ansible-role-st2,v1.0.0,ansible.st2.server") == "ansible-role-st2")

# Generated at 2022-06-23 06:58:01.938227
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    role = {
        'role': 'test',
    }
    role = RoleRequirement.role_yaml_parse(role)
    assert role == {'name': 'test', 'src': 'test', 'scm': None, 'version': ''}

    role = {
        'role': 'test+git@github.com:test.git',
    }
    role = RoleRequirement.role_yaml_parse(role)
    assert role == {'name': 'test', 'src': 'git@github.com:test.git', 'scm': 'git', 'version': ''}

    role = {
        'role': 'test,v2.0',
    }
    role = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-23 06:58:12.159763
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    git_with_proto = '''
        - { name: geerlingguy.apache, scm: git, src: https://github.com/geerlingguy/ansible-role-apache.git }
        - { name: geerlingguy.apache, scm: git, src: git@github.com:geerlingguy/ansible-role-apache.git }
        - { name: geerlingguy.apache, scm: git, src: ssh://git@github.com/geerlingguy/ansible-role-apache.git }
    '''
    assert RoleRequirement.role_yaml_parse(git_with_proto)[0]['name'] == 'geerlingguy.apache'


# Generated at 2022-06-23 06:58:22.020065
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # test one
    repo_url = 'git@git.example.com:me/folks.git'
    role_name = RoleRequirement.repo_url_to_role_name(repo_url)
    assert role_name == 'folks', "repo_url_to_role_name() should return 'folks'"

    # test two
    repo_url = 'https://git.example.com/me/folks'
    role_name = RoleRequirement.repo_url_to_role_name(repo_url)
    assert role_name == 'folks', "repo_url_to_role_name() should return 'folks'"

    # test three
    repo_url = 'http://git.example.com:8080/repos/repo.git'
    role_name = Role

# Generated at 2022-06-23 06:58:34.080655
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import shutil
    import tempfile
    from ansible.utils.path import makedirs_safe
    from ansible.utils.galaxy import scm_archive_resource

    def _cleanup_scm_archive_role():
        if os.path.exists(test_directory):
            shutil.rmtree(test_directory)

    # make a copy of the scm_archive_resource method that we can call
    # without arguments.
    copy_of_scm_archive_resource = scm_archive_resource

    # patch scm_archive_resource method to add args

# Generated at 2022-06-23 06:58:45.558932
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role1 = 'weareinteractive.timezone,v1.0.0,mytimezone'
    role2 = 'git+git://example.com/weareinteractive.timezone,v1.0.0,mytimezone'
    role3 = 'https://github.com/weareinteractive/ansible-timezone.git,v1.0.0,mytimezone'
    role4 = 'git@github.com:weareinteractive/ansible-timezone.git,v1.0.0,mytimezone'
    role5 = 'ansible-role-timezone,v1.0.0,mytimezone'
    role6 = 'ansible-role-timezone,v1.0.0'
    role7 = 'ansible-role-timezone'

# Generated at 2022-06-23 06:58:56.421229
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v0.0.1") == "repo"
   

# Generated at 2022-06-23 06:59:04.737122
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    try:
        RoleRequirement.scm_archive_role('https://github.com/username/role.git',
                                         scm='git',
                                         version='1.0')

        RoleRequirement.scm_archive_role('https://github.com/username/role.git',
                                         scm='git')

        RoleRequirement.scm_archive_role('https://github.com/username/role.git',
                                         scm='git',
                                         name='role',
                                         version='1.0')

        RoleRequirement.scm_archive_role('https://github.com/username/role.git',
                                         scm='git',
                                         name='role',
                                         version='1.0',
                                         keep_scm_meta=True)

    except AnsibleError:
        assert False

# Generated at 2022-06-23 06:59:08.840447
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 06:59:19.054438
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v0.1") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v0.1,my_role") == "repo"

# Generated at 2022-06-23 06:59:30.455249
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = '"geerlingguy.jenkins"'
    expected_result = dict(name='geerlingguy.jenkins', src='geerlingguy.jenkins', scm=None, version='')
    assert expected_result == RoleRequirement.role_yaml_parse(role)

    role = '"geerlingguy.jenkins,1.0.0"'
    expected_result = dict(name='geerlingguy.jenkins', src='geerlingguy.jenkins', scm=None, version='1.0.0')
    assert expected_result == RoleRequirement.role_yaml_parse(role)

    role = '"geerlingguy.jenkins,1.0.0,My Role"'

# Generated at 2022-06-23 06:59:33.406991
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    assert role is not None, "Unable to create RoleRequirement object"

# Unit tests for static methods of class RoleRequirement

# Generated at 2022-06-23 06:59:45.052904
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # Initialize all test cases
    test_case_list = []
    test_case_list.append(("git+https://github.com/jtyr/ansible-unbound.git,1.1.0,ansible-unbound",
                           dict(name='ansible-unbound', src='https://github.com/jtyr/ansible-unbound.git', scm='git', version='1.1.0')))
    test_case_list.append(("https://github.com/jtyr/ansible-unbound.git,1.1.0,ansible-unbound",
                           dict(name='ansible-unbound', src='https://github.com/jtyr/ansible-unbound.git', scm=None, version='1.1.0')))
    test_case

# Generated at 2022-06-23 06:59:53.580982
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test string
    role = 'foo,bar'
    expected_result = {'name': 'foo', 'scm': None, 'src': 'foo,bar', 'version': None}
    assert RoleRequirement.role_yaml_parse(role) == expected_result
    # test full
    role = {'role': 'foo,bar', 'scm': 'git', 'src': 'ssh://hg@bitbucket.org/foo/bar', 'version': 'master'}
    expected_result = {'scm': 'git', 'src': 'ssh://hg@bitbucket.org/foo/bar', 'version': 'master', 'name': 'foo,bar'}
    assert RoleRequirement.role_yaml_parse(role) == expected_result
    # test with github url

# Generated at 2022-06-23 06:59:55.383887
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    repo_url = "http://git.example.com/repos/repo.git"
    name = RoleRequirement.repo_url_to_role_name(repo_url)
    assert name == 'repo'


# Generated at 2022-06-23 07:00:04.118993
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    sample_role_requirement = {
        "name": "sample_name",
        "src": "git+https://github.com/user/repo.git",
        "scm": "git",
        "version": "v1.0"
    }
    role_requirement = RoleRequirement(sample_role_requirement)
    assert role_requirement.get_name() == 'sample_name'
    assert role_requirement.get_src() == 'git+https://github.com/user/repo.git'
    assert role_requirement.get_scm() == 'git'
    assert role_requirement.get_version() == 'v1.0'
    assert role_requirement.get_scm_url() == 'https://github.com/user/repo.git'


# Unit test

# Generated at 2022-06-23 07:00:12.008826
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    role = RoleRequirement()
    role_details = role.scm_archive_role(src='https://github.com/ansible/service-modules-core.git', scm='git', name='ansible-service-module', version='master', keep_scm_meta=True)
    assert role_details['name'] == 'ansible-service-module'
    assert role_details['version'] == 'master'
    assert 'ansible/service-modules-core.git' in role_details['scm_archive_src']
    

# Generated at 2022-06-23 07:00:22.692676
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/anouarabd/ansible-role-docker.git") == "ansible-role-docker"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/anouarabd/ansible-role-docker.git") == "ansible-role-docker"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/anouarabd/ansible-role-docker") == "ansible-role-docker"
    assert RoleRequirement.repo_url_to_role_name("github.com:ansible-galaxy/nginx") == "nginx"

# Generated at 2022-06-23 07:00:28.996057
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.parsing.convert_bool import boolean
    import json

    src = "https://github.com/ansible/ansible-for-devops"
    src_rev = "master"

    scm = "git"
    scm_rev = "master"
    scm_rev_no_version = "HEAD"
    scm_rev_tag = "0.1"
    scm_rev_sha = "34a3dcb3a07b314be7e8e3d9ff22879b806e1c84"

    name = "ansible-for-devops"
    keep_scm_meta = boolean(False)
    check_mode = boolean(True)

    # Test with default parameters
    result = RoleRequirement.scm_archive_role(src)


# Generated at 2022-06-23 07:00:35.743583
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    def check_archive_response(response, name='geerlingguy.ntp'):
        assert isinstance(response, dict)
        assert 'archive_path' in response
        assert 'role_path' in response
        assert 'role_name' in response
        assert response['role_name'] == name
        assert response['role_path'].endswith('/%s' % name)

    # Check Git
    tmp_dir = mkdtemp()

# Generated at 2022-06-23 07:00:47.254497
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    assert RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-examples.git') == 'ansible-examples'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-examples') == 'ansible-examples'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-examples.git,v1.0') == 'ansible-examples'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-examples,v1.0') == 'ansible-examples'

# Generated at 2022-06-23 07:01:00.079316
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 07:01:09.653404
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name(
        "http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name(
        "https://github.com/owner/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name(
        "git+https://github.com/owner/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name(
        "git@github.com:owner/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name(
        "git@github.com:owner/repo") == "repo"
   

# Generated at 2022-06-23 07:01:18.553217
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test 1: parse {role: galaxy.role } 
    spec = dict(role="galaxy.role")
    assert RoleRequirement.role_yaml_parse(spec) == dict(
        name="galaxy.role",
        scm=None,
        src=None,
        version=None)

    # Test 2: parse {role: galaxy.role, version, name } 
    spec = dict(role="galaxy.role,1.0.0,role_name")
    assert RoleRequirement.role_yaml_parse(spec) == dict(
        name="role_name",
        scm=None,
        src="galaxy.role",
        version="1.0.0")

    spec = dict(role="galaxy.role,1.0.0")
    assert RoleRequirement.role_yaml

# Generated at 2022-06-23 07:01:29.191604
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    role = RoleRequirement.scm_archive_role('https://github.com/geerlingguy/ansible-role-security.git', 'git', 'geerlingguy.security', 'v0.1.0', True)
    assert role.get('src') == 'https://github.com/geerlingguy/ansible-role-security.git'
    assert role.get('scm') == 'git'
    assert role.get('version') == 'v0.1.0'
    assert role.get('name') is None


# Generated at 2022-06-23 07:01:41.383299
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-23 07:01:50.150949
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert RoleRequirement.role_yaml_parse('robertdebock.bootstrap') == {'name': 'robertdebock.bootstrap', 'src': 'robertdebock.bootstrap', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('robertdebock.bootstrap,1.2.3') == {'name': 'robertdebock.bootstrap', 'src': 'robertdebock.bootstrap', 'scm': None, 'version': '1.2.3'}

# Generated at 2022-06-23 07:01:59.872646
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # Test if return string starts with "https://"
    result1 = RoleRequirement.scm_archive_role(src="https://github.com/galaxyproject/ansible-galaxy.git")
    assert result1.startswith("https://")

    # Test if return string starts with "https://"
    result2 = RoleRequirement.scm_archive_role(src="https://github.com/galaxyproject/ansible-galaxy.git", scm='git+https')
    assert result2.startswith("https://")

    # Test if return string starts with "git+"
    result3 = RoleRequirement.scm_archive_role(src="git+https://github.com/galaxyproject/ansible-galaxy.git", scm='git')
    assert result3.startswith("https://")

# Generated at 2022-06-23 07:02:10.171694
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Test #1
    spec = dict(name='foo', src='http://example.com/bar.git', scm='git', version='master')
    role = RoleRequirement.role_yaml_parse(spec)

    assert role['name'] == 'foo'

    # Test #2
    spec = dict(name='foo', src='http://example.com/bar.git', scm='git', version='master')
    role = RoleRequirement.role_yaml_parse(spec)

    assert role['name'] == 'foo'
    assert role['src'] == 'http://example.com/bar.git'
    assert role['scm'] == 'git'
    assert role['version'] == 'master'

    # Test #3

# Generated at 2022-06-23 07:02:21.594200
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('myrole')['src'] == 'myrole'
    assert RoleRequirement.role_yaml_parse('myrole')['name'] == 'myrole'
    assert RoleRequirement.role_yaml_parse('myrole')['scm'] == None
    assert RoleRequirement.role_yaml_parse('myrole')['version'] == None
    assert RoleRequirement.role_yaml_parse('git+git://github.com/name/repo')['src'] == 'git://github.com/name/repo'
    assert RoleRequirement.role_yaml_parse('git+git://github.com/name/repo')['name'] == 'repo'
    assert RoleRequirement.role_yaml_parse('git+git://github.com/name/repo')

# Generated at 2022-06-23 07:02:32.130142
# Unit test for method scm_archive_role of class RoleRequirement

# Generated at 2022-06-23 07:02:38.190844
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    test_role = RoleRequirement()
    assert test_role is not None


# Generated at 2022-06-23 07:02:48.366860
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-23 07:02:57.239281
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Unit tests for the role_yaml_parse function
    #
    # To run tests:
    #   python lib/ansible/galaxy/role_requirement.py

    # Empty input
    assert RoleRequirement.role_yaml_parse('') == {'name': None, 'src': None, 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse(None) == {'name': None, 'src': None, 'scm': None, 'version': None}

    # Input { 'role': 'role' }
    assert RoleRequirement.role_yaml_parse({'role': 'role'}) == {'name': 'role', 'src': None, 'scm': None, 'version': None}

    # Input { 'role': 'role,version' }

# Generated at 2022-06-23 07:03:10.115460
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    display.current_line = 1
    a_result_dict = RoleRequirement.scm_archive_role('https://github.com/ansible/ansible-pan-modules.git', 'git', version='master', name='pan', keep_scm_meta=True)
    assert a_result_dict == {'path': '../../pan-master', 'repo': 'https://github.com/ansible/ansible-pan-modules.git', 'version': 'master'}
    a_result_dict = RoleRequirement.scm_archive_role('https://github.com/ansible/ansible-modules-core.git', 'git', version='devel', name='pan', keep_scm_meta=True)

# Generated at 2022-06-23 07:03:15.180738
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-23 07:03:26.100785
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.urls import open_url

    import tempfile

    try:
        tmpdir = tempfile.mkdtemp()
        role_data = RoleRequirement.scm_archive_role("https://github.com/geerlingguy/ansible-role-security.git", scm='git', name=None, version='HEAD', keep_scm_meta=True, tmp=tmpdir)
        # Test we have a tar file
        assert role_data["path"].endswith(".tar.gz")
        assert role_data["version"] == 'f58991d'

        # Test we can read the tar file
        tfile = open_url(role_data["path"])
        assert tfile.read(2) == b'PK'
    finally:
        # Cleanup
        import shut

# Generated at 2022-06-23 07:03:36.709713
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task


# Generated at 2022-06-23 07:03:48.220277
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    name = "test_role"
    version = "master"
    src = "https://github.com/ansible/ansible-examples.git"
    scm = "git"
    keep_scm_meta = True

    # Run the method
    result = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)
    assert result is not None
    assert len(result) == 2
    assert type(result[0]).__name__ == 'str'
    assert os.path.splitext(result[0])[1] == ".tar.gz"
    if keep_scm_meta:
        assert result[1]["scm"] == scm
        assert result[1]["version"] == version
        assert result[1]["name"] == name

# Generated at 2022-06-23 07:04:01.257744
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    role_name = "david-garcia.aws-ssh-env"
    role_version = "0.1.1"
    role_scm = "git"
    role_src = "https://github.com/david-garcia/ansible.role.aws-ssh-env.git"

    role = RoleRequirement.scm_archive_role(
        role_src,
        scm=role_scm,
        name=role_name,
        version=role_version)

    assert role["name"] == role_name
    assert role["version"] == role_version
    assert role["scm"] == role_scm
    assert role["src"] == role_src

    # Test with a missing role_name
    role_name = None

# Generated at 2022-06-23 07:04:05.800768
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    assert RoleRequirement.scm_archive_role(
        src='https://github.com/example/ansible-role-test',
        scm='git',
        name='ansible-role-test',
        version='HEAD',
        keep_scm_meta=False) == \
        {'status': 'success', 'scm': 'git',
         'name': 'ansible-role-test',
         'dest': '/home/user/.ansible/tmp/ansible-local/ansible-role-test-git-repo',
         'commit': None,
         'repo': 'https://github.com/example/ansible-role-test',
         'version': 'HEAD',
         'src': 'https://github.com/example/ansible-role-test'}

# Generated at 2022-06-23 07:04:13.381809
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_name = 'foo'
    role_version = 'latest'
    role_src = 'my.git.server'
    role_req = RoleRequirement()
    role = role_req.role_yaml_parse('{0},{1},{2}'.format(role_src, role_version, role_name ))
    assert 'name' in role, "name is not found in role"
    assert 'src' in role, "src is not found in role"
    assert 'scm' in role, "scm is not found in role"
    assert 'version' in role, "version is not found in role"

# Generated at 2022-06-23 07:04:25.123499
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    SPEC = {
        'name': 'role1',
        'version': '1.0',
    }
    r1 = RoleRequirement()
    assert r1.get_name() is None
    assert r1.get_version() is None
    assert r1.get_scm() is None
    assert r1.get_src() is None

    r1 = RoleRequirement(**SPEC)
    assert r1.get_name() == 'role1'
    assert r1.get_scm() is None
    assert r1.get_src() is None
    assert r1.get_version() == '1.0'

    SPEC = {
        'name': 'role2',
        'version': '1.0',
    }
    r2 = RoleRequirement(**SPEC)
    assert r2.get_

# Generated at 2022-06-23 07:04:34.055096
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    '''Test: role_yaml_parse method'''

    from ansible.errors import AnsibleError

    # Test case 1: role name with variable
    # Expected result: return src, version and name
    spec = RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,version,name')

    assert spec['src'] == 'http://git.example.com/repos/repo.git'
    assert spec['version'] == 'version'
    assert spec['name'] == 'name'
    assert spec['scm'] is None

    # Test case 2: role name with invalid variable
    # Expected result: raise AnsibleError

# Generated at 2022-06-23 07:04:35.657506
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    assert isinstance(RoleRequirement, object)


# Generated at 2022-06-23 07:04:40.339475
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    print("Testing RoleRequirement")

    if not RoleRequirement.__doc__:
        print("Failed: RoleRequirement has no doc")
        return 1
    else:
        print("Passed")
        return 0



# Generated at 2022-06-23 07:04:49.717882
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import pytest

# Generated at 2022-06-23 07:04:56.749856
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    try:
        RoleRequirement.scm_archive_role(src='https://github.com/ansible/ansible-examples', scm='git', name='ansible-examples', version='v1.1.0')
    except Exception as e:
        assert False, 'git pull failed: %s' % e.message

if __name__ == '__main__':

    test_RoleRequirement_scm_archive_role()

# Generated at 2022-06-23 07:05:08.931159
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test multiple cases:
    # 1) Old style: |
    #   - role: repo_name
    # 2) New style: |
    #   - role:
    #     name: repo_name
    #     src: repo_url
    #     scm: git
    #     version: some_version
    #     other_option: some_value
    # 3) New style, with extra comma: |
    #   - src: repo_url,version,repo_name
    # 4) New style, with extra comma and scm: |
    #   - src: git+repo_url,version,repo_name

    # Case 1
    role_name = 'repo_name'
    role_list = [{"role": role_name}]
    role_reparse_list = []

# Generated at 2022-06-23 07:05:21.704376
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import os

    # If the test file exists, read the requirements.yml file.
    # We will then test the yaml_parse method.
    requirements_file = os.path.join(
        os.path.dirname(__file__), 'test_data/requirements.yml'
    )
    if os.path.exists(requirements_file):
        import yaml
        with open(requirements_file, 'r') as rfh:
            rd = yaml.safe_load(rfh)
            # Each role is a dict; test each one for sanity
            for role in rd:
                r = RoleRequirement.role_yaml_parse(role)
                # should have expected keys
                assert(hasattr(r, 'name'))
                assert(hasattr(r, 'src'))
