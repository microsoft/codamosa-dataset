

# Generated at 2022-06-21 01:14:26.767059
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://github.com/user/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("user/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://github.com/user/repo,master") == "repo"
    assert RoleRequirement.repo_url_to_role_name("user/repo,master") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://github.com/user/repo,master,foo.tar.gz") == "repo"

# Generated at 2022-06-21 01:14:34.110637
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement().role_yaml_parse('role_name,my_version') == {'src': 'role_name', 'version': 'my_version', 'scm': None, 'name': 'role_name'}
    assert RoleRequirement().role_yaml_parse('role_name,my_version,my_name') == {'src': 'role_name', 'version': 'my_version', 'scm': None, 'name': 'my_name'}
    assert RoleRequirement().role_yaml_parse('role_name') == {'src': 'role_name', 'version': '', 'scm': None, 'name': 'role_name'}

# Generated at 2022-06-21 01:14:41.851274
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert RoleRequirement.role_yaml_parse('foobar') == {'name': 'foobar', 'src': 'foobar', 'scm': None, 'version': None}, \
        'Simple role name'

    assert RoleRequirement.role_yaml_parse('foobar,1.0') == {'name': 'foobar', 'src': 'foobar', 'scm': None, 'version': '1.0'}, \
        'role name and version'

    assert RoleRequirement.role_yaml_parse('foobar,1.0,myname') == {'name': 'myname', 'src': 'foobar', 'scm': None, 'version': '1.0'}, \
        'role name, version and name'


# Generated at 2022-06-21 01:14:50.434849
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert 'role' == RoleRequirement.repo_url_to_role_name('git://git.example.com/foo/role.git')
    assert 'role' == RoleRequirement.repo_url_to_role_name('http://git.example.com/foo/role.git')
    assert 'role' == RoleRequirement.repo_url_to_role_name('https://git.example.com/foo/role.git')
    assert 'role' == RoleRequirement.repo_url_to_role_name('ssh://git.example.com/foo/role.git')
    assert 'role' == RoleRequirement.repo_url_to_role_name('git@git.example.com:foo/role.git')
    assert 'role' == RoleRequirement.repo_url_to_role_

# Generated at 2022-06-21 01:14:52.490641
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    assert role_requirement != None


# Generated at 2022-06-21 01:15:04.345279
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v0.1') == 'repo'

# Generated at 2022-06-21 01:15:14.514847
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    import shutil

    rr = RoleRequirement()

    test_src = "git+git@github.com:mygh/my-org-role.git,1.0.0,my-org-role"
    role = rr.role_yaml_parse(test_src)
    test_name = role["name"]
    test_scm = role["scm"]
    test_src = role["src"]
    test_version = role["version"]
    test_path = "./my-org-role-%s" % test_version
    shutil.rmtree(test_path, ignore_errors=True)

    # get the source from git and unpack it
    rr.scm_archive_role(test_src, test_scm, test_name, test_version)

    # check the expected role

# Generated at 2022-06-21 01:15:26.390554
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()

    # Test without passing any arguments
    role1 = role_requirement.role_yaml_parse('')
    assert role1 == dict(name=None, src=None, scm=None, version=None)

    # Test with empty string
    role2 = role_requirement.role_yaml_parse('')
    assert role2 == dict(name=None, src=None, scm=None, version=None)

    # Test with role name only
    role3 = role_requirement.role_yaml_parse('test_role')
    assert role3 == dict(name='test_role', src='test_role', scm=None, version='')

    # Test with role name and version with tag

# Generated at 2022-06-21 01:15:36.336536
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:15:47.280109
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    def test(role, result):
        actual = RoleRequirement.role_yaml_parse(role)
        try:
            assert actual == result
        except AssertionError:
            print('\n%s' % actual)
            raise

    # test strings
    test('geerlingguy.java', dict(name='geerlingguy.java', src=None, scm=None, version=None))
    test('geerlingguy.java,1.8', dict(name='geerlingguy.java', src=None, scm=None, version='1.8'))
    test('geerlingguy.java,1.8,Java', dict(name='Java', src=None, scm=None, version='1.8'))

# Generated at 2022-06-21 01:16:00.149385
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    def test_parse(str_to_be_parsed, name, src, scm, version):
        role  = RoleRequirement.role_yaml_parse(str_to_be_parsed)
        assert name == role['name']
        assert src == role['src']
        assert scm == role['scm']
        assert version == role['version']

    test_parse("geerlingguy.mysql,1.0.0", "geerlingguy.mysql", "geerlingguy.mysql", None, "1.0.0")

# Generated at 2022-06-21 01:16:11.291931
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:16:21.709083
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Git urls
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/username/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://github.com/username/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/username/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@github.com:username/repo.git") == "repo"
    assert RoleRequirement.repo

# Generated at 2022-06-21 01:16:24.535733
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role = "https://github.com/geerlingguy/ansible-role-apache.git"
    assert RoleRequirement.repo_url_to_role_name(role) == "ansible-role-apache"

# Generated at 2022-06-21 01:16:33.182420
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    role_req = RoleRequirement()
    assert role_req

    spec = {'name': 'foo'}
    assert spec == role_req.role_yaml_parse(spec)

    spec = {'role': 'foo'}
    assert spec == role_req.role_yaml_parse(spec)

    spec_str = 'foo'
    assert {'name': 'foo', 'src': 'foo', 'scm': None, 'version': ''} == role_req.role_yaml_parse(spec_str)

    spec_str = 'foo,1.0'
    assert {'name': 'foo', 'src': 'foo', 'scm': None, 'version': '1.0'} == role_req.role_yaml_parse(spec_str)


# Generated at 2022-06-21 01:16:41.989278
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.compat import yaml
    from ansible.release import __version__

    test_case_file_path = './test_RoleRequirement_role_yaml_parse.yml'

    with open(test_case_file_path) as test_case_file:
        test_case = yaml.load(test_case_file.read())

    actual = [RoleRequirement.role_yaml_parse(role) for role in test_case['inputs']]
    expected = test_case['expected']['ansible_version_'+__version__]

    assert expected == actual

if __name__ == "__main__":
    test_RoleRequirement_role_yaml_parse()

# Generated at 2022-06-21 01:16:53.572735
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # Passed 'src' is not a valid URL.
    import os
    import pytest
    with pytest.raises(AnsibleError, match='Invalid repo URL (src) specified: abcd'):
        RoleRequirement.scm_archive_role('abcd')

    # Passed 'src' is a valid URL.
    from tempfile import mkdtemp
    from ansible.module_utils.six.moves import urllib
    from ansible.module_utils._text import to_bytes, to_native
    from shutil import rmtree

    temp_dir = mkdtemp(prefix="ansible_test_role_requirement")
    role_name = "test_role_requirement_scm_archive_role"
    role_src = "https://github.com/ansible/test-module-utils"
   

# Generated at 2022-06-21 01:17:01.411782
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # This function intended to test "role_yaml_parse" function
    # from ansible/playbook/role/requirement.py
    # Note that this function is only available in Ansible 2.5.5.
    # You may need to update the version of Ansible you use to
    # 2.5.5 or later.

    # Checking function:
    # - parse an single word string,
    # - parse an single word string with a version,
    # - parse an single word string with a version and a name,
    # - parse an complete specifying string,
    # - parse an complete specifying string with a name,
    # - parse a comma separated string,
    # - raise an error in case of a comma separated string with
    #   more than 2 commas
    from ansible.errors import AnsibleError
    from copy import copy
   

# Generated at 2022-06-21 01:17:04.961215
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    print ("RoleRequirement_repo_url_to_role_name - test_1")
    assert "common" == RoleRequirement.repo_url_to_role_name("https://github.com/ansible/ansible-examples,v1.0,common")

    print ("RoleRequirement_repo_url_to_role_name - test_2")
    assert "common" == RoleRequirement.repo_url_to_role_name("https://github.com/ansible/ansible-examples/archive/v1.0.tar.gz,common")


# Generated at 2022-06-21 01:17:15.470274
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:17:31.106961
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    rr = RoleRequirement()

    assert rr.role_yaml_parse('geerlingguy.java,1.7.0') == {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': '1.7.0'}
    assert rr.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': ''}

# Generated at 2022-06-21 01:17:33.029286
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    x = RoleRequirement()
    assert x


# Generated at 2022-06-21 01:17:34.423361
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    pass


# Generated at 2022-06-21 01:17:42.445488
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:17:51.480034
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/myrepo/myroles.git") == "myroles"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/myrepo/myroles.git") == "myroles"
    assert RoleRequirement.repo_url_to_role_name("git@github.com/myrepo/myroles.git") == "myroles"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/myrepo/myroles") == "myroles"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/myrepo/myroles") == "myroles"

# Generated at 2022-06-21 01:18:02.831994
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    rr = RoleRequirement()

    rypp1 = rr.role_yaml_parse('http://server/ansible-role-tomcat.git,1.0.1')
    assert rypp1['name'] == 'ansible-role-tomcat'
    assert rypp1['scm'] == 'git'
    assert rypp1['src'] == 'http://server/ansible-role-tomcat.git'
    assert rypp1['version'] == '1.0.1'

    rypp2 = rr.role_yaml_parse('http://server/ansible-role-tomcat.git,1.0.1,tomcat')
    assert rypp2['name'] == 'tomcat'
    assert rypp2['scm'] == 'git'
    assert ry

# Generated at 2022-06-21 01:18:12.616286
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    roles_dir = "/tmp/test_galaxy_from_roles_dir"
    repo_dir = "/tmp/test_galaxy_from_repo_dir"
    ansible_roles_path = [roles_dir]

    role_name = "test_role"
    installation_path = os.path.join(roles_dir, role_name)

    repo_url = "https://github.com/c4software/fetch_url.git"
    repo_version = "HEAD"
    scm = "git"

    os.makedirs(installation_path)

# Generated at 2022-06-21 01:18:15.743324
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'

# Generated at 2022-06-21 01:18:27.395178
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.compat.tests import unittest

    # RoleRequirement() is a helper class for Galaxy. The role_yaml_parse() method
    # parses roles specified in meta/main.yml and requirements.yml files.
    # https://docs.ansible.com/ansible/galaxy.html
    role_expect = {
        'name': 'foo',
        'src': 'git+git://git.example.com/repos/foo.git',
        'scm': 'git',
        'version': '1.2.3'
    }

    # Test `git+git://git.example.com/repos/foo.git,1.2.3,foo`

# Generated at 2022-06-21 01:18:30.907527
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    repo_url = "http://git.example.com/repos/repo.git"
    result = RoleRequirement.repo_url_to_role_name(repo_url)
    assert result == "repo"



# Generated at 2022-06-21 01:18:46.939305
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    display.vvvv(0, 'TESTING RoleRequirement.role_yaml_parse')

    role_requirement = RoleRequirement()

    role = {'name': 'geerlingguy.nginx'}
    assert role_requirement.role_yaml_parse(role) == {'name': 'geerlingguy.nginx'}

    role = {'role': 'geerlingguy.nginx'}
    assert role_requirement.role_yaml_parse(role) == {'name': 'geerlingguy.nginx'}

    role = {'role': 'geerlingguy.nginx', 'version': 'v1.11.8'}

# Generated at 2022-06-21 01:18:47.641205
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    RoleRequirement()

# Generated at 2022-06-21 01:18:55.952644
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.galaxy import Galaxy
    from .requirement_files import test_requirement_files

    for item in test_requirement_files:
        role = item[0]
        expected = item[1]
        role = RoleRequirement.role_yaml_parse(role)
        if role != expected:
            print("\n")
            print("Input: ", item[0])
            print("Expected:", expected)
            print("Result: ", role)
            raise Exception("RoleRequirement.role_yaml_parse() test failed.")



# Generated at 2022-06-21 01:19:06.133556
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
  r = RoleRequirement()

  # test for valid scm_archive_role input
  assert r.scm_archive_role('git+git@github.com:myrepo/myrepo.git', name='myrepo') == 'git+git@github.com:myrepo/myrepo.git'

  try:
    r.scm_archive_role('git:git@github.com:myrepo/myrepo.git', name='myrepo')
  except Exception:
    assert True

  # test for valid repo_url_to_role_name input
  assert r.repo_url_to_role_name('git+git@github.com:myrepo/myrepo.git') == 'myrepo'

  # test for valid role_yaml_parse input
  assert r.role

# Generated at 2022-06-21 01:19:17.226495
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    rr = RoleRequirement()
    assert rr.role_yaml_parse('geerlingguy.java,1.7.0') == {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': '1.7.0'}
    assert rr.role_yaml_parse('/path/to/role') == {'name': 'role', 'scm': None, 'src': '/path/to/role', 'version': ''}

# Generated at 2022-06-21 01:19:26.077223
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    result = RoleRequirement.scm_archive_role(src='https://github.com/xvzf/onlyoffice-desktopeditors.git', version='0.0.2.27')
    assert 'https://github.com/xvzf/onlyoffice-desktopeditors' == result['url']
    assert '0.0.2.27' == result['version']

    result = RoleRequirement.scm_archive_role(src='https://github.com/xvzf/onlyoffice-desktopeditors.git')
    assert 'https://github.com/xvzf/onlyoffice-desktopeditors' == result['url']
    assert 'HEAD' == result['version']


# Generated at 2022-06-21 01:19:37.913736
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    src = "https://github.com/bennojoy/nginx"
    tar_file_name = RoleRequirement.scm_archive_role(src=src, scm='git', version='HEAD', keep_scm_meta=False)
    assert tar_file_name == 'nginx-b3f2f2c41cef1e47f17a8d5f08511a79b9e0f1d8.tar.gz'

    src = "https://github.com/bennojoy/nginx.git"
    tar_file_name = RoleRequirement.scm_archive_role(src=src, scm='git', version='HEAD', keep_scm_meta=False)

# Generated at 2022-06-21 01:19:45.689714
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile

# Generated at 2022-06-21 01:19:56.758488
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:19:59.547793
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # initilize the class
    rolereq = RoleRequirement()

    # we have not implemented this class yet.
    # assert.ok(rolereq != None)

# Generated at 2022-06-21 01:20:12.774088
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.playbook.role import RoleRequirement
    from ansible.playbook.role.requirement import VALID_SPEC_KEYS
    print("Testing RoleRequirement")
    print("=" * 60)
    # url with git and no version
    url_git_no_version = 'https://github.com/ansible/ansible-examples.git'
    role_req1 = RoleRequirement.role_yaml_parse(url_git_no_version)
    if ',' in role_req1['name']:
        raise AssertionError("Only role_name, version, name must not be allowed")
    if ',' in role_req1['src']:
        raise AssertionError("Only role_name, version, name must not be allowed")

# Generated at 2022-06-21 01:20:23.983597
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test for method role_yaml_parse
    # of class RoleRequirement

    role_requirement = RoleRequirement()

    assert role_requirement.role_yaml_parse('geerlingguy.java') == \
           {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}

    assert role_requirement.role_yaml_parse('geerlingguy.java,1.8') == \
           {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.8'}


# Generated at 2022-06-21 01:20:31.068189
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:20:41.223456
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = dict(
        src = "git+https://github.com/mynamespace/myrole.git",
        version = "v1.0-beta1",
        name = "myrole",
    )
    role_strongly_typed = dict(
        name = "myrole",
        src = "git+https://github.com/mynamespace/myrole.git",
        scm = "git",
        version = "v1.0-beta1",
    )
    assert RoleRequirement.role_yaml_parse(role) == role_strongly_typed
    assert RoleRequirement.role_yaml_parse("myrole,v1.0-beta1,mynamespace.myrole") == role_strongly_typed


# Generated at 2022-06-21 01:20:52.963848
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    test_role = 'geerlingguy.apache,v1.2.3,geerlingguy.apache'
    result = RoleRequirement.role_yaml_parse(test_role)
    assert result['name'] == 'geerlingguy.apache'
    assert result['version'] == 'v1.2.3'
    assert result['src'] == 'geerlingguy.apache'

    test_role = 'geerlingguy.apache,v1.2.3'
    result = RoleRequirement.role_yaml_parse(test_role)
    assert result['name'] == 'geerlingguy.apache'
    assert result['version'] == 'v1.2.3'

    test_role = 'geerlingguy.apache'
    result = RoleRequirement.role_yaml_parse(test_role)

# Generated at 2022-06-21 01:21:03.661560
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    from ansible.module_utils.six import PY3

    src = 'https://github.com/morinb1/ansible-role-test.git'
    scm = 'git'
    version = 'HEAD'
    keep_scm_meta = False

    name = RoleRequirement.repo_url_to_role_name(src)

    # On Travis, we get a permission denied error, so skip. This really shouldn't be
    # happening, but does for some reason that hasn't been determined, but it worked
    # under Ansible < 2.5, so it's something new.
    if 'TRAVIS' in os.environ:
        print('TRAVIS detected, skipping test. This test fails on Travis with a permission denied error, but it worked under Ansible <= 2.4.3')

# Generated at 2022-06-21 01:21:15.766122
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test with string spec
    spec = "test_role_yaml_parse"
    expected = {'name': 'test_role_yaml_parse', 'src': 'test_role_yaml_parse', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse(spec) == expected

    spec = "test_role_yaml_parse,v1"
    expected = {'name': 'test_role_yaml_parse', 'src': 'test_role_yaml_parse', 'scm': None, 'version': 'v1'}
    assert RoleRequirement.role_yaml_parse(spec) == expected

    spec = "test_role_yaml_parse,v1,alternate_name"

# Generated at 2022-06-21 01:21:26.397421
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    print("Testing RoleRequirement")
    ok_role = {
        "name": "conq.test1",
        "galaxy_info": {
            "author": "conq",
            "description": "Test role1",
            "company": "conq",
            "license": "MIT",
            "min_ansible_version": "1.7",
            "platforms": {
                "all": {
                    "constraints": "test1"
                }
            },
            "galaxy_tags": ["test", "test1"]
        }
    }
    rr = RoleRequirement.role_yaml_parse(ok_role)
    print (rr)
    assert rr == ok_role


# Generated at 2022-06-21 01:21:38.323703
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert "ansible-role-apache" == role_requirement.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-apache.git")
    assert "ansible-role-apache" == role_requirement.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-apache")
    assert "ansible-role-apache" == role_requirement.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-apache.tar.gz")

# Generated at 2022-06-21 01:21:47.086026
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test new style
    assert({'name': 'galaxy.role', 'src': 'galaxy.role', 'scm': None, 'version': None} ==
            RoleRequirement.role_yaml_parse({'src': 'galaxy.role'}))
    assert({'name': 'galaxy.role', 'src': 'galaxy.role', 'scm': 'git', 'version': None} ==
            RoleRequirement.role_yaml_parse({'src': 'git+galaxy.role'}))
    assert({'name': 'galaxy.role', 'src': 'galaxy.role', 'scm': 'git', 'version': None} ==
            RoleRequirement.role_yaml_parse({'src': 'git+http://galaxy.role'}))

# Generated at 2022-06-21 01:22:14.808763
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ....galaxy.role_spec import RoleSpecParser

    # test new style with SCM and version
    role = RoleRequirement.role_yaml_parse({ 'src': 'git+https://github.com/geerlingguy/ansible-role-ntp.git,v1.2.2' })
    assert role == { 'src': 'https://github.com/geerlingguy/ansible-role-ntp.git', 'name': 'ansible-role-ntp', 'scm': 'git', 'version': 'v1.2.2' }

    # test new style with name (and SCM, version)

# Generated at 2022-06-21 01:22:18.786765
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = "https://github.com/usmanmughalji/ansible-role-ghost.git"
    scm = "git"
    name = None
    version = "HEAD"
    keep_scm_meta = False

    archive_file = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)

    print ("Archive File: " +  archive_file)
    assert True

# Generated at 2022-06-21 01:22:29.737160
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:22:40.138038
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('rolename') == {'name': 'rolename', 'src': 'rolename', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('rolename,') == {'name': 'rolename', 'src': 'rolename', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('rolename,v1.0') == {'name': 'rolename', 'src': 'rolename', 'scm': None, 'version': 'v1.0'}
    assert RoleRequirement.role_yaml_parse('rolename,v1.0,foo') == {'name': 'rolename', 'src': 'rolename', 'scm': None, 'version': 'v1.0'}


# Generated at 2022-06-21 01:22:49.840002
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    from ansible.errors import AnsibleError

# Generated at 2022-06-21 01:22:54.818647
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # Example 1
    r = RoleRequirement()
    assert 'role_name[,version[,name]]' in str(r)

    # Example 2:
    assert RoleRequirement.repo_url_to_role_name('https://github.com/tony/myrole.git') == 'myrole'


# Generated at 2022-06-21 01:23:04.681503
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    """
    Test the scm_archive_role() function of class RoleRequirement.
    """
    from ansible import constants as C
    from ansible.galaxy import Galaxy
    from ansible.utils.display import Display

    # Setup requirements for galaxy to run
    display = Display()
    C.config.settings._read_config_file()
    C.config.settings.update_config_from_file()
    galaxy_cli = Galaxy(display=display)

    # Testing a git url
    git_url = 'git+git://git.example.com/ansible/example_galaxy.git'
    (valid_role, valid_role_path) = RoleRequirement.scm_archive_role(src=git_url, keep_scm_meta=True)

    # Testing a github url with no version specified
    github_

# Generated at 2022-06-21 01:23:15.625629
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
   assert RoleRequirement.role_yaml_parse(
       'username.myrole') == {'name': 'username.myrole', 'src': 'username.myrole', 'version': '', 'scm': None}

   assert RoleRequirement.role_yaml_parse(
       "git+https://www.example.com/repos/foobar.git") == {'name': 'foobar', 'src': 'https://www.example.com/repos/foobar.git', 'version': '', 'scm': 'git'}

   assert RoleRequirement.role_yaml_parse(
       "username.myrole,v1.0") == {'name': 'username.myrole', 'src': 'username.myrole', 'version': 'v1.0', 'scm': None}

   assert RoleRequirement.role

# Generated at 2022-06-21 01:23:25.156417
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import os

    assert(isinstance(RoleRequirement.role_yaml_parse("git+git@github.com:galaxy/galaxy_role_test.git,v0.2,galaxy_role_test"), dict))
    assert(isinstance(RoleRequirement.role_yaml_parse("git+git@github.com:galaxy/galaxy_role_test.git"), dict))
    assert(isinstance(RoleRequirement.role_yaml_parse("git+git@github.com:galaxy/galaxy_role_test.git,v0.2"), dict))
    assert(isinstance(RoleRequirement.role_yaml_parse("git+git@github.com:galaxy/galaxy_role_test.git,galaxy_role_test"), dict))

    test_role_requirement = RoleRequirement

# Generated at 2022-06-21 01:23:26.459657
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
	print (RoleRequirement.role_yaml_parse('geerlingguy.java'))