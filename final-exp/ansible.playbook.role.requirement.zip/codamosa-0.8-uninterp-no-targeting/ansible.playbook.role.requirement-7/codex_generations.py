

# Generated at 2022-06-21 01:14:21.466190
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    print("Testing RoleRequirement.repo_url_to_role_name")

    # Test URLs

# Generated at 2022-06-21 01:14:30.263394
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test for method role_yaml_parse of class RoleRequirement
    # for the string format of the role requirement
    # Case when name is not specified
    assert {'name': 'test', 'scm': None, 'src': 'https://github.com/test', 'version': ''} == RoleRequirement.role_yaml_parse('https://github.com/test')
    # Case when name is specified (1)
    assert {'name': 'test', 'scm': None, 'src': 'https://github.com/test', 'version': 'v1.0'} == RoleRequirement.role_yaml_parse('https://github.com/test,v1.0')
    # Case when name is specified (2)

# Generated at 2022-06-21 01:14:31.192012
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    requirements = RoleRequirement()
    assert isinstance(requirements, RoleRequirement)


# Generated at 2022-06-21 01:14:35.485181
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:14:47.392822
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # test case 1:
    role = {'name': 'ansible-role-nginx',
            'version': 'v3.0.0',
            'src': 'https://github.com/jdauphant/ansible-role-nginx.git'}
    assert len(role.keys()) == 3
    role_req = RoleRequirement()
    role_req.role_yaml_parse(role)
    assert role_req.get_info()['name'] == 'ansible-role-nginx'
    assert role_req.get_info()['scm'] is None
    assert role_req.get_info()['src'] == 'https://github.com/jdauphant/ansible-role-nginx.git'

# Generated at 2022-06-21 01:14:57.269988
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    src = "https://github.com/cavaliercoder/mock.git"
    scm = 'git'
    name = None
    version = 'HEAD'
    keep_scm_meta = False

    assert RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta) is not None
    assert RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta) == "https://github.com/cavaliercoder/mock/archive/HEAD.tar.gz"



# Generated at 2022-06-21 01:15:07.117034
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    repo_url_to_role_name_tests = [
        ["{user}@{example}.com:{path}.git", "path"],
        ["http://{user}@{example}.com/{path}.git", "path"],
        ["git+{user}@{example}.com:{path}.git", "path"],
        ["{user}@{example}.com:{path}.git", "path"],
        ["{user}@{example}.com:{path}.git", "path"],
    ]
    for test in repo_url_to_role_name_tests:
        input = test[0].format(user="test_user", example="test_host", path="test_path")
        expected = test[1]
        output = RoleRequirement.repo_url_to_role_name(input)

# Generated at 2022-06-21 01:15:16.033820
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_string = 'geerlingguy.java,1.8.0'
    role_dict = RoleRequirement.role_yaml_parse(role_string)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['version'] == '1.8.0'

    role_string = 'geerlingguy.java,1.8.0,some_name'
    role_dict = RoleRequirement.role_yaml_parse(role_string)
    assert role_dict['name'] == 'some_name'
    assert role_dict['version'] == '1.8.0'

    role_string = 'geerlingguy.java,1.8.0,some_name,somethingelse'

# Generated at 2022-06-21 01:15:28.014261
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Testcase 1:
    role = "http://github.com/foo/bar"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'bar', 'version': None, 'src': 'http://github.com/foo/bar', 'scm': None}

    # Testcase 2:
    role = "http://github.com/foo/bar,v1.0"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'bar', 'version': 'v1.0', 'src': 'http://github.com/foo/bar', 'scm': None}

    # Testcase 3:
    role = "http://github.com/foo/bar,v1.0,bar"
    result = RoleRequirement.role_

# Generated at 2022-06-21 01:15:38.293987
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:15:53.931222
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # based on the method description
    role = 'git+https://github.com/user/role,v0.1.0,myrole'
    role = RoleRequirement.role_yaml_parse(role)

    result = RoleRequirement.scm_archive_role(**role)

# Generated at 2022-06-21 01:16:01.415619
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # pylint: disable=missing-docstring
    import os
    import shutil
    import tempfile
    from ansible.module_utils.six.moves.urllib.request import Request, urlopen

    # create a temporary directory to store the archive
    temp_dir = tempfile.mkdtemp()
    meta_path = os.path.join(temp_dir, "meta")
    assert not os.path.exists(meta_path)

    # delete the temporary directory
    def clean_up():
        shutil.rmtree(temp_dir)
    request = Request("http://docs.ansible.com/ansible/latest/modules.html")
    urlopen(request)

    # download the archive and extract it

# Generated at 2022-06-21 01:16:11.857613
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import yaml


# Generated at 2022-06-21 01:16:18.866758
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    """
    Unit test for method scm_archive_role of class RoleRequirement.
    """
    try:
        ClassObject = RoleRequirement()
        result = ClassObject.scm_archive_role(src='https://github.com/wtanaka/ansible-role-test',
                                              scm='git', name='test', version='master', keep_scm_meta=False)
        assert(result)
    except ImportError as err:
        assert(False)


# Generated at 2022-06-21 01:16:28.776892
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    output = RoleRequirement.scm_archive_role('https://github.com/jtyr/ansible-snmp.git', scm='git', name='jtyr.snmp', version='HEAD', keep_scm_meta=False)
    assert output == 'jtyr.snmp-HEAD.tar.gz'
    output = RoleRequirement.scm_archive_role('https://github.com/jtyr/ansible-snmp.git', scm='git', name='jtyr.snmp', version='1.0.0', keep_scm_meta=False)
    assert output == 'jtyr.snmp-1.0.0.tar.gz'

# Generated at 2022-06-21 01:16:39.215737
# Unit test for constructor of class RoleRequirement

# Generated at 2022-06-21 01:16:50.724176
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.utils.path import unfrackpath

    test_role = RoleRequirement()
    assert test_role is not None

    test_role_name = "test_role"
    test_role_version = "test_version"
    test_role_path = unfrackpath("~/test_role")
    test_role_galaxy = "test_galaxy"
    test_role_galaxy_role = "test_galaxy_role"
    test_role_galaxy_version = "test_galaxy_version"

    test_role_name1 = "test_role1"
    test_role_version1 = "test_version1"
    test_role_path1 = unfrackpath("~/test_role1")
    test_role_galaxy1 = "test_galaxy1"
    test_

# Generated at 2022-06-21 01:16:54.784369
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement() is not None
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.role_yaml_parse('myuser.myrole,v1') is not None

# Generated at 2022-06-21 01:17:02.220231
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:17:13.725091
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com:repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('user@git.example.com:repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequ

# Generated at 2022-06-21 01:17:30.630124
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.module_utils.six import BytesIO


# Generated at 2022-06-21 01:17:40.869337
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    result = RoleRequirement.repo_url_to_role_name('git@git.example.com:repos/repo.git')
    assert 'repo' == result, "Expected result 'repo' but got:  %s" % result

    result = RoleRequirement.repo_url_to_role_name('git://git.example.com/repos/repo.git')
    assert 'repo' == result, "Expected result 'repo' but got:  %s" % result

    result = RoleRequirement.repo_url_to_role_name('https://git.example.com/repos/repo.git')
    assert 'repo' == result, "Expected result 'repo' but got:  %s" % result

    result = RoleRequirement.repo_url_to

# Generated at 2022-06-21 01:17:50.368533
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    def test_equal(d1, d2):
        assert len(d1) == len(d2), "dictionaries d1(%s) and d2(%s) are not equal" % (d1, d2)
        for (key, value) in d1.items():
            assert key in d2 and d2[key] == value, "dictionaries d1(%s) and d2(%s) are not equal" % (d1, d2)

    def test(role, correct_output):
        output = RoleRequirement.role_yaml_parse(role)
        test_equal(output, correct_output)

    # Test the old style, strings containing the role names.

# Generated at 2022-06-21 01:17:53.227698
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    import os
    role_Requirement = RoleRequirement()
    assert role_Requirement != None
    assert os.path.isfile('/tmp/temprpm') == False


# Generated at 2022-06-21 01:17:55.584985
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement()

# Generated at 2022-06-21 01:18:07.969043
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    '''
    Assert behavior of RoleRequirement.role_yaml_parse()
    '''
    import pytest

    # test case: value is a string without any version specifier
    result = RoleRequirement.role_yaml_parse('my.role')
    assert result == {'name': 'my.role', 'src': 'my.role', 'version': None, 'scm': None}

    # test case: value is a string with a version specifier
    result = RoleRequirement.role_yaml_parse('my.role,1.0')
    assert result == {'name': 'my.role', 'src': 'my.role', 'version': '1.0', 'scm': None}

    # test case: value is a string with a version specifier and a name
    result = RoleRequirement.role_y

# Generated at 2022-06-21 01:18:10.430791
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"


# Generated at 2022-06-21 01:18:17.678219
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    url = "https://github.com/jdauphant/ansible-role-nginx.git"
    assert RoleRequirement.repo_url_to_role_name(url) == 'ansible-role-nginx'

    url = "https://github.com/jdauphant/ansible-role-nginx"
    assert RoleRequirement.repo_url_to_role_name(url) == 'ansible-role-nginx'

    url = "git+https://github.com/jdauphant/ansible-role-nginx"
    assert RoleRequirement.repo_url_to_role_name(url) == 'ansible-role-nginx'

    url = "git+https://github.com/jdauphant/ansible-role-nginx.git"
    assert RoleRequirement

# Generated at 2022-06-21 01:18:29.295445
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_ok = {
        'src': 'git@git.example.com:ansible/ansible-galaxy.git',
        'version': '',
        'name': 'galaxy',
        'scm': 'git',
    }

    test_ok_src_append_git_git = {
        'src': 'git@git.example.com:ansible/ansible-galaxy-test.git',
        'version': '',
        'name': 'galaxy-test',
        'scm': 'git',
    }


# Generated at 2022-06-21 01:18:36.272141
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = ""
    assert RoleRequirement.role_yaml_parse(role) == {}, "Result differs from expected value"

    role = "git+git://github.com/ansible/ansible-examples.git,v1.1.1,test"
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'test', 'src': 'git://github.com/ansible/ansible-examples.git', 'scm': 'git', 'version': 'v1.1.1'}, "Result differs from expected value"

    role = "git+http://github.com/ansible/ansible-examples.git,v1.1.1,test"

# Generated at 2022-06-21 01:18:56.628185
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com:/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo,master') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo,master,work') == 'repo'


# Generated at 2022-06-21 01:19:07.495219
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement_obj = RoleRequirement()
    role_requirement = role_requirement_obj.role_yaml_parse('myrole')
    assert dict(name='myrole', src='myrole', scm=None, version='') == role_requirement
    role_requirement2 = role_requirement_obj.role_yaml_parse({'src': 'myrole'})
    assert dict(name='myrole', src='myrole', scm=None, version='') == role_requirement2
    role_requirement3 = role_requirement_obj.role_yaml_parse("myrole,=v1.0")
    assert dict(name='myrole', src='myrole', scm=None, version="=v1.0") == role_requirement3
    role_requirement4 = role

# Generated at 2022-06-21 01:19:18.222207
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/user/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/user/repo,test.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/user/repo,test.tar.gz,test") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@github.com:user/repo.git") == "repo"

# Generated at 2022-06-21 01:19:27.632147
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:19:39.350211
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    test_scm_archive_role_git_scm_and_role_with_url_and_version_and_name()
    test_scm_archive_role_hg_scm_and_my_role_with_url_and_version()
    test_scm_archive_role_svn_scm_and_role_with_url_and_version()
    test_scm_archive_role_git_scm_and_role_with_url()
    test_scm_archive_role_role_with_url_and_version_and_name()
    test_scm_archive_role_role_with_scm_prefix_in_url_and_version_and_name()
    test_scm_archive_role_role_with_url_and_version()
    test_scm

# Generated at 2022-06-21 01:19:41.724666
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    req = RoleRequirement()
    result = req.scm_archive_role(src="https://github.com/geerlingguy/ansible-role-apache.git", scm="git")

    assert result is None

# Generated at 2022-06-21 01:19:53.440703
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:20:03.986419
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    src = "file:///home/vagrant/development/ansible_2/ansible/examples/ansible-galaxy"
    scm = "git"
    name = "ansible-galaxy.tar.gz"
    version = "HEAD"
    result = RoleRequirement.scm_archive_role(src, scm, name, version)
    assert result == '/home/vagrant/development/ansible_2/ansible/examples/ansible-galaxy/ansible-galaxy.tar.gz'

    src = "file:///home/vagrant/development/ansible_2/ansible/examples/ansible-galaxy"
    scm = "git"
    name = None
    version = "HEAD"

# Generated at 2022-06-21 01:20:11.164008
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    '''
    Verify module RoleRequirement.role_yaml_parse method.
    '''
    import os

    # Create RoleRequirement object
    role_requirement = RoleRequirement()

    # Given
    # When
    # Then
    assert role_requirement.role_yaml_parse(role='http://galaxy.ansible.com/x/myrole,v1,myrole') == {'name': 'myrole', 'src': 'http://galaxy.ansible.com/x/myrole', 'scm': None, 'version': 'v1'}
    assert role_requirement.role_yaml_parse(role='/home/user/myrole') == {'name': 'myrole', 'src': '/home/user/myrole', 'scm': None, 'version': None}
    assert role_

# Generated at 2022-06-21 01:20:22.493419
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_definition = """
    ---
    - name: test-role
      version: 1.2.3
      src: ssh://git.example.com/repos/repo.git
      scm: git
      collection:
        namespace: foo
        name: bar
    """

    parsed_role = RoleRequirement.role_yaml_parse(yaml.safe_load(role_definition)[0])

    assert parsed_role['name'] == 'test-role'
    assert parsed_role['scm'] == 'git'
    assert parsed_role['src'] == 'ssh://git.example.com/repos/repo.git'
    assert parsed_role['version'] == '1.2.3'
    assert parsed_role['collection']['namespace'] == 'foo'

# Generated at 2022-06-21 01:20:42.280286
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
   role_requirement = RoleRequirement()
   res = role_requirement.role_yaml_parse(role='jdauphant.nginx')
   assert(res['name'] == 'jdauphant.nginx')
   assert(res['version'] == '')

   res = role_requirement.role_yaml_parse(role='jdauphant.nginx,v2.17')
   assert(res['name'] == 'jdauphant.nginx')
   assert(res['version'] == 'v2.17')

   res = role_requirement.role_yaml_parse(role='jdauphant.nginx,v2.17,mynginx')
   assert(res['name'] == 'mynginx')
   assert(res['version'] == 'v2.17')

# Generated at 2022-06-21 01:20:50.088390
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement.role_yaml_parse({'role': 'common', 'version': 'v1.0'}) == {'name': 'common', 'version': 'v1.0'}
    assert RoleRequirement.role_yaml_parse('common') == {'name': 'common', 'version': '', 'src': 'common'}
    assert RoleRequirement.role_yaml_parse('common,v1.0') == {'name': 'common', 'version': 'v1.0', 'src': 'common,v1.0'}

# Generated at 2022-06-21 01:21:01.327906
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:21:08.585717
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    from ansible.module_utils.six.moves.urllib.parse import urlparse
    import os.path

    r = RoleRequirement()
    assert r

    # git+http://example.com/role,bar,3.2.0
    role = r.role_yaml_parse("git+http://example.com/role,bar,3.2.0")
    assert role['name'] == 'bar'
    assert role['scm'] == 'git'
    assert urlparse(role['src']).path == '/role'
    assert role['version'] == '3.2.0'

    # git+http://example.com/role,bar
    role = r.role_yaml_parse("git+http://example.com/role,bar")
    assert role['name'] == 'bar'
    assert role

# Generated at 2022-06-21 01:21:18.408132
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import tempfile
    src = 'git@github.com:savonet/ladspa.git'

    (fd, rq) = tempfile.mkstemp()
    os.close(fd)
    os.remove(rq)
    rq = os.path.abspath(rq)

    scm_archive_role = RoleRequirement.scm_archive_role(src, scm='git', keep_scm_meta=True, version="v1.13", name=rq)
    #print "scm_archive_role:%s" % (scm_archive_role)
    assert scm_archive_role == rq + "/" + os.path.basename(src)

# Generated at 2022-06-21 01:21:27.944429
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:21:39.731876
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    import ansible.utils.plugin_docs as pdocs

    # Test loading of requirements - name, version and relative path

# Generated at 2022-06-21 01:21:46.910994
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    test_role = {
        'name': 'test',
        'src': 'git+https://github.com/ansible/ansible-galaxy.git,4.4.0',
        'version': '4.4.0',
        'scm': 'git'
    }

    test_class = RoleRequirement.role_yaml_parse(test_role)

    assert(test_class['name'] == 'test')
    assert(test_class['scm'] == 'git')
    assert(test_class['version'] == '4.4.0')
    assert(test_class['src'] == 'https://github.com/ansible/ansible-galaxy.git')

# Generated at 2022-06-21 01:21:53.243262
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    scm_path = RoleRequirement.scm_archive_role(
        src='https://github.com/ansible/ansible-examples.git',
        scm='git',
        name='ansible-examples',
        version='HEAD',
        keep_scm_meta=False,
    )
    assert scm_path == '/Users/arumin/.ansible/tmp/ansible-local/tmpd1msdqap'

# Generated at 2022-06-21 01:22:03.312024
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    from ansible.playbook.play_context import PlayContext

    src = 'https://github.com/example/ansible-example.git'
    scm = 'git'
    name = None
    version = 'HEAD'
    keep_scm_meta = False
    expected_result = {
        '__ansible_role_meta__': {
            'version': version,
            'name': 'ansible-example'
        },
        '__ansible_scm_meta__': {
            'scm': scm,
            'scm_src': src,
            'scm_version': version
        },
        '__ansible_galaxy_meta__': {
            'version': version,
            'name': 'ansible-example'
        }
    }

    play_context = PlayContext()
   

# Generated at 2022-06-21 01:22:27.641159
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    assert role_requirement

# Generated at 2022-06-21 01:22:30.265217
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # Test constructor:
    role_req = RoleRequirement()
    # role_req.role_yaml_parse(self, role)

# Generated at 2022-06-21 01:22:40.180349
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import json

    test1 = RoleRequirement.role_yaml_parse("http://foobar.com/role.git")
    assert json.dumps(test1) == '{"scm": null, "version": null, "name": "role", "src": "http://foobar.com/role.git"}'

    test2 = RoleRequirement.role_yaml_parse("http://foobar.com/role.git,v9")
    assert json.dumps(test2) == '{"scm": null, "version": "v9", "name": "role", "src": "http://foobar.com/role.git"}'

    test3 = RoleRequirement.role_yaml_parse("git+http://foobar.com/role.git,v9")

# Generated at 2022-06-21 01:22:49.942966
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_repo = [
        'https://github.com/ansible/ansible-examples.git',
        'https://github.com/ansible/ansible-examples',
        'git+https://github.com/ansible/ansible-examples.git',
        'git+https://github.com/ansible/ansible-examples',
        'git@github.com:ansible/ansible-examples'
    ]
    for repo_url in role_repo:
        assert RoleRequirement.repo_url_to_role_name(repo_url) == 'ansible-examples'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/foo/bar/ansible-examples.git') == 'ansible-examples.git'

# Generated at 2022-06-21 01:23:01.216768
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-21 01:23:11.507192
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # GIT test
    src = 'https://github.com/username/ansible-role-test.git'
    expected_result = {
        'status': 2,
        'name': 'ansible-role-test',
        'scm': 'git',
        'scm_revision': 'HEAD',
        'archive_file': 'ansible-role-test-gitHEAD.tar.gz',
        'path': '/home/ansible/roles/ansible-role-test-gitHEAD',
        'version': 'HEAD',
        'scm_last_commit': '',
        'src': 'https://github.com/username/ansible-role-test.git'
    }
    assert RoleRequirement.scm_archive_role(src) == expected_result

    # HG test

# Generated at 2022-06-21 01:23:23.430606
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    yaml_data = """
    geerlingguy.java: java=1.7
    vars:
      - name: foo
        value: bar
      - name: zookeeper
        value: 3.4.6
    """
    data = AnsibleVaultEncryptedUnicode.load(yaml_data)
    role_req = RoleRequirement(data)
    assert role_req.get_info() == "geerlingguy.java (java=1.7)"
    assert role_req.get_vars() == [{'name': 'foo', 'value': 'bar'},
                                   {'name': 'zookeeper', 'value': '3.4.6'}]

# Generated at 2022-06-21 01:23:34.404620
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    assert role_requirement.repo_url_to_role_name("https://github.com/account1/repo1.git") == "repo1"
    assert role_requirement.repo_url_to_role_name("https://github.com/account1/repo1,v1.0") == "repo1"
    assert role_requirement.repo_url_to_role_name("https://github.com/account1/repo1,v1.0,test") == "repo1"
    assert role_requirement.repo_url_to_role_name("https://github.com/account1/repo1,test") == "repo1"

# Generated at 2022-06-21 01:23:36.476016
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    try:
        RoleRequirement()
    except Exception:
        assert False

test_RoleRequirement()

# Generated at 2022-06-21 01:23:45.646829
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('') == ''
    assert RoleRequirement.repo_url_to_role_name('repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo,') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo,ver') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo,ver,role') == 'repo'

    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'