

# Generated at 2022-06-21 01:14:32.450650
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    rr = RoleRequirement()

    res = rr.role_yaml_parse('foo')
    assert res.get('name') == 'foo', res.get('name')
    assert res.get('scm') is None, res.get('scm')
    assert res.get('src') == 'foo', res.get('src')
    assert res.get('version') is None, res.get('version')

    res = rr.role_yaml_parse('git+https://github.com/foo/bar.git')
    assert res.get('name') == 'bar', res.get('name')
    assert res.get('scm') == 'git', res.get('scm')
    assert res.get('src') == 'https://github.com/foo/bar.git', res.get('src')
   

# Generated at 2022-06-21 01:14:40.268768
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
#   def repo_url_to_role_name(repo_url):
    """
    tests RoleRequirement.repo_url_to_role_name()
    """


# Generated at 2022-06-21 01:14:50.662964
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test = RoleRequirement()


# Generated at 2022-06-21 01:15:02.447279
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert("role1" == RoleRequirement.repo_url_to_role_name("git+git@github.com:user1/role1.git"))
    assert("role1" == RoleRequirement.repo_url_to_role_name("git+http://github.com/user1/role1.git"))
    assert("role1" == RoleRequirement.repo_url_to_role_name("git+https://github.com/user1/role1.git"))
    assert("role1" == RoleRequirement.repo_url_to_role_name("git+https://github.com/user1/role1"))

    assert("role2" == RoleRequirement.repo_url_to_role_name("role2@1.0"))

# Generated at 2022-06-21 01:15:10.358964
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Setup
    test_urls = [
        "https://github.com/alct/ansible-role-pocci",
        "https://github.com/alct/ansible-role-pocci.git",
        "https://github.com/alct/ansible-role-pocci.git,0.1",
        "https://github.com/alct/ansible-role-pocci.git,0.1,alct.pocci",
    ]

    test_results = [
        "ansible-role-pocci",
        "ansible-role-pocci",
        "ansible-role-pocci",
        "ansible-role-pocci",
    ]

    count = 0
    for test_url in test_urls:
        result = Role

# Generated at 2022-06-21 01:15:15.455068
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    test_src = 'https://github.com/some/repo'
    test_name = 'some_repo'
    test_version = '9048f2c'

    result = RoleRequirement.scm_archive_role(test_src, name=test_name, version=test_version)

    assert result.get('repo') == test_src
    assert result.get('commit') == test_version
    assert result.get('name') == test_name

# Generated at 2022-06-21 01:15:18.859708
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    url_string = 'url_string'
    url = RoleRequirement.repo_url_to_role_name(url_string)
    assert url == url_string



# Generated at 2022-06-21 01:15:30.392501
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name("http://foo.bar/baz.git") == "baz"
    assert role_requirement.repo_url_to_role_name("https://foo.bar/baz.git") == "baz"
    assert role_requirement.repo_url_to_role_name("https://foo.bar/baz/") == "baz"
    assert role_requirement.repo_url_to_role_name("https://foo.bar/baz.git") == "baz"
    assert role_requirement.repo_url_to_role_name("https://github.com/foo/baz.git") == "baz"
    assert role_requirement.repo_url_

# Generated at 2022-06-21 01:15:32.315812
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role = RoleRequirement()
    repo_url = "https://github.com/mikeshulver/zabbix.git"
    role_name = role.repo_url_to_role_name(repo_url)
    assert role_name == "zabbix"

# Generated at 2022-06-21 01:15:40.062550
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:15:57.976254
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # test a normal git repo URI
    repo_url = "git+https://github.com/example/repo.git"
    role_name = RoleRequirement.repo_url_to_role_name(repo_url)
    assert role_name == "repo"

    # test a local file
    repo_url = "file:///tmp/playbooks/roles/repo"
    role_name = RoleRequirement.repo_url_to_role_name(repo_url)
    assert role_name == "repo"

    # test a local file with a trailing slash
    repo_url = "file:///tmp/playbooks/roles/repo/"
    role_name = RoleRequirement.repo_url_to_role_name(repo_url)

# Generated at 2022-06-21 01:16:03.455063
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    try:
        path = RoleRequirement.scm_archive_role("https://github.com/jtyr/ansible-multi-nginx.git", scm="git")
    except Exception as e:
        print("except")
    assert path == "jtyr-ansible-multi-nginx-master"

# Generated at 2022-06-21 01:16:12.843044
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement = RoleRequirement()

    # test with a string, no scm and no version
    role = role_requirement.role_yaml_parse('user.role')
    assert role['name'] == 'user.role'
    assert role['src'] == 'user.role'
    assert role['scm'] == None
    assert role['version'] == None

    # test with a string, scm, and version
    role = role_requirement.role_yaml_parse('git+https://github.com/user.role,1.2.3')
    assert role['name'] == 'user.role'
    assert role['src'] == 'https://github.com/user.role'
    assert role['scm'] == 'git'
    assert role['version'] == '1.2.3'

    # test

# Generated at 2022-06-21 01:16:22.382754
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    from ansible.plugins.loader import role_loader


# Generated at 2022-06-21 01:16:30.581175
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import os
    import sys


# Generated at 2022-06-21 01:16:40.624275
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement.role_yaml_parse("git+http://github.com/jdauphant/ansible-role-nginx,v1.0,jdauphant.nginx") == {
        'name': 'jdauphant.nginx',
        'scm': 'git',
        'src': 'http://github.com/jdauphant/ansible-role-nginx',
        'version': 'v1.0'
    }

# Generated at 2022-06-21 01:16:52.077414
# Unit test for method scm_archive_role of class RoleRequirement

# Generated at 2022-06-21 01:17:00.097494
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert(RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo')
    assert(RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v5.5.5') == 'repo')
    assert(RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v5.5.5,foo') == 'repo')
    assert(RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-examples.git,v3.3.3,foo') == 'ansible-examples')

# Generated at 2022-06-21 01:17:11.896589
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    url = "https://github.com/geerlingguy/ansible-role-security.git"
    role_name = RoleRequirement.repo_url_to_role_name(url)
    assert role_name == "ansible-role-security"
    print("RoleRequirement.repo_url_to_role_name returned %s for url %s" % (role_name, url))

    url = "https://github.com/geerlingguy/ansible-role-security"
    role_name = RoleRequirement.repo_url_to_role_name(url)
    assert role_name == "ansible-role-security"
    print("RoleRequirement.repo_url_to_role_name returned %s for url %s" % (role_name, url))


# Generated at 2022-06-21 01:17:19.291839
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test case 1: parse string-based format
    # Input: 'role_name,version,name'
    # Expected result: { 'name': 'name', 'role': role_name, 'version': 'version' }
    role = 'role_name,version,name'
    expectedResult = dict(name='name', role='role_name', version='version')
    assert RoleRequirement.role_yaml_parse(role) == expectedResult

    # Test case 2: parse dict-based format
    # Input: dict(name='role_name', version='version')
    # Expected result: { 'name': 'role_name', 'version': 'version' }
    role = dict(name='role_name', version='version')
    expectedResult = dict(name='role_name', role='role_name', version='version')
   

# Generated at 2022-06-21 01:17:35.686264
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from tempfile import mkdtemp
    from shutil import rmtree

    role_name = 'nested-role-test'
    role_scm = 'git'
    role_src = 'http://github.com/ansible/ansible-examples.git'
    role_version = 'devel'
    role_keep_scm_meta = False
    temp_dir = mkdtemp(prefix='ansible_test_rolerequirement_')

    role = RoleRequirement.scm_archive_role(role_src, role_scm, role_name, role_version, role_keep_scm_meta)
    role.archive(temp_dir, keep_scm=role_keep_scm_meta)

    assert role.scm == role_scm
    assert role.src == role_src

# Generated at 2022-06-21 01:17:42.656215
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    fake_src = 'https://github.com/ansible/ansible-examples.git'
    fake_scm = 'git'
    fake_name = 'ansible-examples'
    fake_version = 'devel'
    fake_keep_scm_meta = False

    try:
        role = RoleRequirement.scm_archive_role(
            fake_src,
            fake_scm,
            fake_name,
            fake_version,
            fake_keep_scm_meta
        )
    except Exception as e:
        raise AssertionError(
            "Failed to scm_archive_role '%s' with error message: %s" %
            (fake_src, e)
        )

# Generated at 2022-06-21 01:17:51.553309
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role1 = {'role': 'geerlingguy.jenkins'}
    role2 = {'role': 'geerlingguy.jenkins', 'version': '1.0.2'}
    role3 = {'role': 'geerlingguy.jenkins,1.0.2'}
    role4 = {'role': 'geerlingguy.jenkins,1.0.2,jenkins'}
    role5 = {'src': 'geerlingguy.jenkins'}
    role6 = {'src': 'geerlingguy.jenkins,1.0.2'}
    role7 = {'src': 'geerlingguy.jenkins,1.0.2,jenkins'}

# Generated at 2022-06-21 01:18:00.379468
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Test case 1:
    # case name: Test the RoleRequirement constructor on 'role' and 'src'
    # case goal: the function should initialize the 'role' and 'src' attribute
    # param src: 'src' object
    # param role: 'src' object
    # case result: the 'role' and 'src' attribute should be equal to 'src'

    src = '/path/to/src'
    role = RoleRequirement()
    assert (role.scm is None)
    assert (role.src == src)
    assert (role.name == 'src')


# Generated at 2022-06-21 01:18:03.541012
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_req = RoleRequirement()
    assert role_req.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'


# Generated at 2022-06-21 01:18:13.129449
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # Test on github.com/ansible/galaxy-test-role-1
    # with version HEAD
    src = 'https://github.com/ansible/galaxy-test-role-1.git'
    name = 'galaxy-test-role-1'
    version = 'HEAD'
    keep_scm_meta = False
    role_archive_path = RoleRequirement.scm_archive_role(src, scm='git', name=name, version=version, keep_scm_meta=keep_scm_meta)
    assert role_archive_path.endswith('galaxy-test-role-1/')

    # Test on git.com/galaxysupport/galaxy-test-role-2
    # with version galaxy_tag

# Generated at 2022-06-21 01:18:19.963679
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://example.com/repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://example.com/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://example.com/repo.tar.gz") == "repo.tar"
    assert RoleRequirement.repo_url_to_role_name("repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git+ssh://git@example.com/repo.git") == "repo"

# Generated at 2022-06-21 01:18:31.237368
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.galaxy.role import Role

    role = RoleRequirement.role_yaml_parse(
        {
            'role': 'myrole',
            'myvar':  'myvalue'
        }
    )
    assert role['name'] == 'myrole'
    assert role['src'] is None
    assert role['scm'] is None
    assert role['version'] == ''
    assert 'myvar' not in role

    role = RoleRequirement.role_yaml_parse(
        {
            'src': 'git+https://github.com/jtyr/ansible-ntp'
        }
    )
    assert role['name'] == 'ansible-ntp'
    assert role['src'] == 'https://github.com/jtyr/ansible-ntp'

# Generated at 2022-06-21 01:18:32.884280
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    return role_requirement


# Generated at 2022-06-21 01:18:44.216921
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    old_style_input = ['mysql', 'mysql,1.0', 'mysql,1.0,othername',
                       'mysql,othername', 'mysql,1.0,othername,', '1.0,mysql']

# Generated at 2022-06-21 01:19:12.553068
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # Tests for repo_url_to_role_name()
    assert RoleRequirement.repo_url_to_role_name("gitlab") == "gitlab"
    assert RoleRequirement.repo_url_to_role_name("git@gitlab") == "gitlab"
    assert RoleRequirement.repo_url_to_role_name("git@gitlab.com:repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://gitlab.com/repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://gitlab.com/repo.git") == "repo"

# Generated at 2022-06-21 01:19:13.745325
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # test for constructor of class RoleRequirement
    pass

# Generated at 2022-06-21 01:19:23.364575
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    from ansible.compat.tests import unittest
    import os
    import shutil
    import tempfile
    import ansible.galaxy.role

    class TestScmArchiveRole(unittest.TestCase):

        def setUp(self):

            self.test_dir = tempfile.mkdtemp()
            self.role_names = []


# Generated at 2022-06-21 01:19:35.420975
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    r = RoleRequirement()
    assert {'src': 'git@github.com:ExampleOrg/ExampleRole.git',
            'name': 'ExampleRole',
            'version': '1.2.3',
            'scm': 'git'} == r.role_yaml_parse(role="git@github.com:ExampleOrg/ExampleRole.git,v1.2.3")
    assert {'src': 'git@github.com:ExampleOrg/ExampleRole.git',
            'name': 'ExampleRole',
            'version': '1.2.3',
            'scm': 'git'} == r.role_yaml_parse(role="git@github.com:ExampleOrg/ExampleRole.git,v1.2.3")

# Generated at 2022-06-21 01:19:44.660431
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('foo') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('foo,bar') == {'name': 'bar', 'src': 'foo', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('foo,bar,garply') == {'name': 'garply', 'src': 'foo', 'scm': None, 'version': 'bar'}

# Generated at 2022-06-21 01:19:55.757459
# Unit test for method scm_archive_role of class RoleRequirement

# Generated at 2022-06-21 01:20:03.307091
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile

    tmpdir = tempfile.gettempdir()

    try:
        result = RoleRequirement.scm_archive_role('https://github.com/bertvv/ansible-role-ejabberd', version='v1.1', scm='git', keep_scm_meta=True, name='ansible-role-ejabberd')

        assert result == '%s/ansible-role-ejabberd-1.1.tar.gz' % tmpdir
    except Exception:
        pass



# Generated at 2022-06-21 01:20:10.853740
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # Test case: 1: Role scm type is git, version HEAD
    # Expected: return absolute path of git repository
    expected_role_path_git_default_version = "/home/ansible/ansible_galaxy/roles/test.git"
    role_path_git_default_version = RoleRequirement.scm_archive_role(src="git://github.com/ansible/test.git", scm='git', name="test", version='HEAD')
    assert(expected_role_path_git_default_version == role_path_git_default_version)

    # Test case: 2: Role scm type is git, version master
    # Expected: return absolute path of git repository

# Generated at 2022-06-21 01:20:22.216812
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    print("Testing method RoleRequirement.repo_url_to_role_name")

    # http://git.example.com/repos/repo.git" => "repo"
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'

    # git@git.example.com:repos/repo.git => "repo"
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com:repos/repo.git') == 'repo'

    # repo => repo
    assert RoleRequirement.repo_url_to_role_name('repo') == 'repo'

    # http://git.example.com/repos/repo,v0.0.

# Generated at 2022-06-21 01:20:30.196407
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:20:48.475924
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    
    # Test input: {'role': 'jdauphant.nginx', 'somevar': 'somevalue'}
    test_input = {'role': 'jdauphant.nginx', 'somevar': 'somevalue'}
    expected_output = {'somevar': 'somevalue', 'name': 'jdauphant.nginx', 'src': None, 'scm': None, 'version': None}

    actual_output = RoleRequirement.role_yaml_parse(test_input)

    if expected_output != actual_output:
        return 1
    else:
        return 0


# Generated at 2022-06-21 01:20:59.679874
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    '''
    Unit test for RoleRequirement constructor
    '''
    test_cases = []
    # test case # 1
    test_cases.append({
        'test_case_name' : 'test case # 1',
        'spec' : {'role': 'test_role_1'},
        'assert' : {'name': 'test_role_1', 'src': None, 'scm': None, 'version': ''},
        })
    # test case # 2
    test_cases.append({
        'test_case_name' : 'test case # 2',
        'spec' : {'role': 'test_role_2,v1'},
        'assert' : {'name': 'test_role_2', 'src': None, 'scm': None, 'version': 'v1'},
        })

# Generated at 2022-06-21 01:21:07.756923
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    role_requirement = RoleRequirement()

    assert role_requirement.repo_url_to_role_name('git@git.example.com:user/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('git@git.example.com:user/repo,1.2.3') == 'repo'
    assert role_requirement.repo_url_to_role_name('git@git.example.com:user/repo,1.2.3,repo') == 'repo'
    assert role_requirement.repo_url_to_role_name('git@git.example.com:user/repo,1.2.3,repo,x') == 'repo'
    assert role_requirement.repo_url_

# Generated at 2022-06-21 01:21:18.850216
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # RoleRequirement.role_yaml_parse(str)
    assert 'git' == RoleRequirement.role_yaml_parse('git+https://github.com/avit/ansible-role-nginx')['scm']
    assert 'ansible-role-nginx' == RoleRequirement.role_yaml_parse('git+https://github.com/avit/ansible-role-nginx')['name']
    assert 'https://github.com/avit/ansible-role-nginx' == RoleRequirement.role_yaml_parse('git+https://github.com/avit/ansible-role-nginx')['src']
    assert '' == RoleRequirement.role_yaml_parse('git+https://github.com/avit/ansible-role-nginx')['version']


# Generated at 2022-06-21 01:21:28.172743
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import shutil
    import tempfile
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary directory that we can delete
    deltempdir = tempfile.mkdtemp()

    # Test of the method scm_archive_role with the parameter src = 'ansible/ansible-examples'
    # and the default value of the other parameters
    RoleRequirement.scm_archive_role(src='ansible/ansible-examples')
    # Test of the method scm_archive_role with the parameter scm = 'git'
    # and the default value of the other parameters
    RoleRequirement.scm_archive_role(scm='git')
    # Test of the method scm_archive_role with the parameter name = 'ansible-examples'
    # and the default value of

# Generated at 2022-06-21 01:21:39.948381
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Check that a string can be parsed to a dictionary.
    # Check that the same result is returned if a dictionary is passed.
    # Check that the parsed dictionary has always the same keys.
    role = 'user.role,0.2.0'
    result = RoleRequirement.role_yaml_parse(role)
    assert isinstance(result, dict), "Result is not a dictionary."
    assert result['name'] == 'user.role', "Wrong role name."
    assert result['version'] == '0.2.0', "Wrong version."
    assert result.has_key('scm'), "Required key 'scm' is missing."
    assert result['scm'] is None, "Wrong value for 'scm'."
    assert result.has_key('src'), "Required key 'src' is missing."

# Generated at 2022-06-21 01:21:47.927861
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert "repo" == RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    assert "repo" == RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/repo.git")
    assert "repo" == RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git")
    assert "repo" == RoleRequirement.repo_url_to_role_name("git://git.example.com:repos/repo.git")
    assert "repo" == RoleRequirement.repo_url_to_role_name("git@git.example.com/repos/repo.git")

# Generated at 2022-06-21 01:21:58.453050
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for valid parsing
    assert RoleRequirement.role_yaml_parse('foo') == dict(name='foo', src='foo', scm=None, version=None)
    assert RoleRequirement.role_yaml_parse('foo,v1.0') == dict(name='foo', src='foo', scm=None, version='v1.0')
    assert RoleRequirement.role_yaml_parse('git+https://github.com/foo/bar') == dict(name='bar', src='https://github.com/foo/bar', scm='git', version=None)

# Generated at 2022-06-21 01:22:06.241618
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    def test(role, name, src, version, scm):
        print ("-"*50)
        print ("Input: ", role)
        spec = RoleRequirement.role_yaml_parse(role)
        print ("Output: ", spec)
        assert spec['name'] == name
        assert spec['scm'] == scm
        assert spec['src'] == src
        assert spec['version'] == version

    # Test 1:
    # input: "geerlingguy.java"
    # output: { 'name': 'geerlingguy.java', 'src': 'https://github.com/geerlingguy/ansible-role-java', 'version': '', 'scm': None }

# Generated at 2022-06-21 01:22:13.203621
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = 'https://github.com/geerlingguy/ansible-role-apache'
    scm = 'git'
    name = 'apache'
    version = 'HEAD'
    keep_scm_meta = False
    role_file = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)
    assert role_file == '/tmp/ansible-role-apache.tar.gz'
    assert os.path.isfile(role_file)

# Generated at 2022-06-21 01:22:42.029230
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:22:55.106915
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    print("\n* test_RoleRequirement():")

    # Test1: Test for the constructor when argument is an empty dictionary for role
    try:
        role = {}
        role_requirement = RoleRequirement(role)
        print("\tPassed: Constructor when argument is an empty dictionary for role")
    except Exception as e:
        print("\tFailed: Constructor when argument is an empty dictionary for role")
        print("\t\tException: " + str(e))

    # Test2: Test for the constructor when argument is a dictionary with string value

# Generated at 2022-06-21 01:23:04.847836
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("https://github.com/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/repo,1.0.0,test.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/repo,1.0.0,test.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/repo,test,test.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/repo,test,repo,test.git") == "repo"


# Generated at 2022-06-21 01:23:06.096300
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    class_ = RoleRequirement()
    assert class_ != None

# Generated at 2022-06-21 01:23:17.635963
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    import json
    import os

    # Setup env variable necessary while running as standalone py test
    os.environ["ANSIBLE_CONFIG"] = "/etc/ansible/ansible.cfg"
    os.environ["ANSIBLE_ROLES_PATH"] = "/etc/ansible/roles"
    os.environ["ANSIBLE_DATA_PATH"] = "/etc/ansible"

    role = RoleRequirement()
    role_json = {}
    role_json = role.role_yaml_parse(role_json)
    print(json.dumps(role_json, indent=4))

    role_json = {}
    role_json["role"] = "geerlingguy.apache"
    role_json = role.role_yaml_parse(role_json)

# Generated at 2022-06-21 01:23:25.602410
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    c = RoleRequirement()
    assert c.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert c.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert c.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0.0') == 'repo.git'
    assert c.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz,v1.0.0') == 'repo.tar.gz'

# Generated at 2022-06-21 01:23:36.630295
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:23:45.784389
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("foo") == {'name': 'foo', 'scm': None, 'src': 'foo', 'version': None}
    assert RoleRequirement.role_yaml_parse("foo,") == {'name': 'foo', 'scm': None, 'src': 'foo', 'version': None}
    assert RoleRequirement.role_yaml_parse("git+git@github.com:ansible/ansible-examples.git,devel") == {'name': 'ansible-examples', 'scm': 'git', 'src': 'git@github.com:ansible/ansible-examples.git', 'version': 'devel'}

# Generated at 2022-06-21 01:23:49.495577
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    tar_path = RoleRequirement.scm_archive_role(src="https://github.com/geerlingguy/ansible-role-apache",
                                                name="apache",
                                                scm="git")
    if tar_path is not None:
        print("Tar Path is: %s" % tar_path)
    else:
        print("Error occurred while downloading role")

test_RoleRequirement_scm_archive_role()

# Generated at 2022-06-21 01:23:59.338639
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # test for exceptions for malformed role string definition
    malformed_role_strings = ['wrong_format_string',
                              'role_name,version,name,extra_field',
                              'role_name,version,name,extra_field,extra_field',
                              'role_name,version,name,extra_field,extra_field,extra_field']

    for malformed_role_string in malformed_role_strings:
        try:
            RoleRequirement.role_yaml_parse(malformed_role_string)
            assert False, 'role_yaml_parse(%s) should have thrown an AnsibleError exception' % malformed_role_string
        except AnsibleError:
            pass

    # test for exceptions for malformed role hash definition