

# Generated at 2022-06-21 01:14:34.881200
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement.role_yaml_parse("git+http://git.example.com/repos/repo.git") == {
        'name': 'repo',
        'scm': 'git',
        'src': 'http://git.example.com/repos/repo.git',
        'version': None
    }
    assert RoleRequirement.role_yaml_parse("git+http://git.example.com/repos/repo.git,v1.0") == {
        'name': 'repo',
        'scm': 'git',
        'src': 'http://git.example.com/repos/repo.git',
        'version': 'v1.0'
    }

# Generated at 2022-06-21 01:14:47.247342
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Test with a well-formed role spec
    assert_spec(RoleRequirement.role_yaml_parse({'role': 'foobar'}), {'name': 'foobar', 'scm': None, 'src': 'foobar', 'version': ''})
    assert_spec(RoleRequirement.role_yaml_parse({'role': 'foobar', 'version': '1.0'}), {'name': 'foobar', 'scm': None, 'src': 'foobar', 'version': '1.0'})

# Generated at 2022-06-21 01:14:59.808561
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile
    temp_dir = tempfile.mkdtemp(prefix='ansible-vault-test')

    result = RoleRequirement.scm_archive_role('https://github.com/bennojoy/mysql', scm='git', name='mysql', version='HEAD', keep_scm_meta=False)

    assert result['path'].startswith(temp_dir)
    assert result['status'] == 'modified'

    result = RoleRequirement.scm_archive_role('https://github.com/bennojoy/mysql', scm='git', name='mysql', version='HEAD', keep_scm_meta=True)

    assert result['path'].startswith(temp_dir)
    assert result['status'] == 'modified'

    result = RoleRequirement.scm_archive_role

# Generated at 2022-06-21 01:15:01.533577
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    RoleRequirement.role_yaml_parse('role-name')

# Generated at 2022-06-21 01:15:04.065663
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    rolereq_object = RoleRequirement()
    assert rolereq_object.__class__.__name__ == "RoleRequirement"


# Generated at 2022-06-21 01:15:14.294292
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.hashing import checksum_s
    import os
    import shutil
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a local git repo
    os.mkdir(os.path.join(tmpdir, 'tst1'))
    os.mkdir(os.path.join(tmpdir, 'tst1', '.git'))
    os.chdir(os.path.join(tmpdir, 'tst1'))
    open('test1', 'w').write('test1')
    os.system('git init >/dev/null 2>&1')
    os.system('git config user.email test@test.test')

# Generated at 2022-06-21 01:15:26.346362
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    url = 'https://github.com/xebialabs-community/xld-ansible-plugin.git'
    assert role_requirement.repo_url_to_role_name(url) == 'xld-ansible-plugin'

    url = 'https://github.com/xebialabs-community/xld-ansible-plugin'
    assert role_requirement.repo_url_to_role_name(url) == 'xld-ansible-plugin'

    # Tar filename gets split
    url = 'https://github.com/xebialabs-community/xld-ansible-plugin,v1.0.0,xebialabs-community.xld-ansible-plugin.tar.gz'
    assert role_requirement.repo_url_to

# Generated at 2022-06-21 01:15:36.298285
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    print("Testing RoleRequirement.scm_archive_role")
    import os, shutil
    from tempfile import mkdtemp, NamedTemporaryFile
    from ansible.utils.path import unfrackpath

    archive_path = None
    archive_dir = None

# Generated at 2022-06-21 01:15:47.234162
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    import pytest
    from ansible.errors import AnsibleError

    assert RoleRequirement.role_yaml_parse("foo") == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse("bar,1.0") == {'name': 'bar', 'src': 'bar', 'scm': None, 'version': '1.0'}
    assert RoleRequirement.role_yaml_parse("baz,1.0,x") == {'name': 'x', 'src': 'baz', 'scm': None, 'version': '1.0'}
    with pytest.raises(AnsibleError) as excinfo:
        RoleRequirement.role_yaml_parse("bar,1.0,x,y")

# Generated at 2022-06-21 01:15:47.848161
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    pass

# Generated at 2022-06-21 01:15:58.876355
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Case 1 - if role is a string then read the values from it and create a dictionary
    role = "test"
    RoleRequirement.role_yaml_parse(role)

    # Case 2 - if role is a dict then check to see if the role key is present it has a comma, in that case throw error
    role = {'role': 'test,1.0,role', 'version': '1.0'}
    RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-21 01:16:10.454277
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import shutil
    import tempfile

    # we want to test this method with a git scm
    src = 'https://github.com/geerlingguy/ansible-role-apache.git'

    # temp directory in which to create
    tmpdir = tempfile.mkdtemp()
    role_dir = RoleRequirement.scm_archive_role(src, 'git', 'apache', version='v1.1.0', keep_scm_meta=True)

    # check that the file has been downloaded and exists
    # we just check the header
    role_dir_expected = os.path.join(tmpdir, 'galaxy-downloads', 'ansible-role-apache-v1.1.0')
    assert role_dir_expected == role_dir

# Generated at 2022-06-21 01:16:12.379714
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement.__name__ == "RoleRequirement"

# Generated at 2022-06-21 01:16:22.236407
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role1 = {'name': 'apache', 'src': 'geerlingguy.apache'}
    assert(RoleRequirement.role_yaml_parse('apache') == role1)
    role2 = {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': 'git', 'version': '1.9.0'}
    assert(RoleRequirement.role_yaml_parse('geerlingguy.apache,1.9.0') == role2)
    role3 = {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': 'git'}
    assert(RoleRequirement.role_yaml_parse('geerlingguy.apache,,') == role3)

# Generated at 2022-06-21 01:16:30.391577
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # Test the RoleRequirement.scm_archive_role function for a git archive
    # that has been installed from a local directory
    local_directory_archive_path = './../../../../../ansible/test/data/roles/git_local_directory'
    scm_archive_result = RoleRequirement.scm_archive_role(local_directory_archive_path)
    assert scm_archive_result.get('version') == 'HEAD'
    assert scm_archive_result.get('name') == 'git_local_directory'
    assert scm_archive_result.get('path') == './../../../../../ansible/test/data/roles/git_local_directory'
    assert scm_archive_result.get('scm') == 'git'

    # Test the RoleRequirement.scm

# Generated at 2022-06-21 01:16:40.522845
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    r = RoleRequirement()
    assert r.scm_archive_role("https://github.com/geerlingguy/ansible-role-jenkins.git") == 'https://github.com/geerlingguy/ansible-role-jenkins.git'
    assert r.scm_archive_role("https://github.com/geerlingguy/ansible-role-jenkins.git", scm='git') == 'https://github.com/geerlingguy/ansible-role-jenkins.git'
    assert r.scm_archive_role("https://github.com/geerlingguy/ansible-role-jenkins.git", scm='git', name='geerlingguy.jenkins') == 'https://github.com/geerlingguy/ansible-role-jenkins.git'
    assert r

# Generated at 2022-06-21 01:16:51.981908
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    requirement = RoleRequirement()
    # Test various different formats of role specs

# Generated at 2022-06-21 01:16:52.674308
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    pass

# Generated at 2022-06-21 01:17:00.365352
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    rr = RoleRequirement()
    test1 = rr.role_yaml_parse({'role': 'test', 'version': '1.0'})

    assert test1['name'] == 'test'
    assert test1['version'] == '1.0'

    test2 = rr.role_yaml_parse('test')

    assert test2['name'] == 'test'

    test3 = rr.role_yaml_parse('http://git.example.com/repos/repo.git')

    assert test3['name'] == 'repo'
    assert test3['src'] == 'http://git.example.com/repos/repo.git'

    test4 = rr.role_yaml_parse('http://git.example.com/repos/repo.git,v1.0')

# Generated at 2022-06-21 01:17:01.836598
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # TODO: Unit test for constructor of class RoleRequirement
    pass

# Generated at 2022-06-21 01:17:26.340296
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # test the examples in the documentation of the class
    assert RoleRequirement.role_yaml_parse("geerlingguy.java") == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse("geerlingguy.java,1.7") == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert RoleRequirement.role_yaml_parse("geerlingguy.java,1.7,myjava") == {'name': 'myjava', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert RoleRequ

# Generated at 2022-06-21 01:17:37.940521
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # 1st test case
    display.warning("\n1st test case: role_name[,version[,name]]\n")
    role = RoleRequirement.role_yaml_parse("git+https://github.com/geerlingguy/ansible-role-security.git,v1.1.1,geerlingguy.security")
    print("role:", role)
    assert 'name' in role
    assert 'src' in role
    assert 'scm' in role
    assert 'version' in role
    assert role['name'] == 'geerlingguy.security'
    assert role['src'] == 'https://github.com/geerlingguy/ansible-role-security.git'
    assert role['scm'] == 'git'
    assert role['version'] == 'v1.1.1'



# Generated at 2022-06-21 01:17:43.185390
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.utils.galaxy import scm_archive_resource
    from ansible.playbook.role.requirement import RoleRequirement

    tmp = RoleRequirement.scm_archive_role('#knight42/awesome-role,v3.3.3')

    # Using a slightly modified version of the internal scm_archive_resource function,
    # we test the output of scm_archive_role
    assert(scm_archive_resource('#knight42/awesome-role,v3.3.3,meta', scm='git', name=None, version='HEAD', keep_scm_meta=False) == tmp)

# Generated at 2022-06-21 01:17:51.803141
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git') == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'version': None, 'scm': None}
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,v1.0') == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'version': 'v1.0', 'scm': None}

# Generated at 2022-06-21 01:18:03.237035
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Test without http prefix and without .git suffix
    test_url1 = 'git://git.example.com/repos/repo.git'
    expected_result1 = 'repo'
    actual_result1 = RoleRequirement.repo_url_to_role_name(test_url1)
    if expected_result1 != actual_result1:
        raise AssertionError('test_RoleRequirement_repo_url_to_role_name failed: Expected %s, got %s' % (expected_result1, actual_result1))

    # Test with http prefix and with .git suffix
    test_url2 = 'https://git.example.com/repos/repo.git'
    expected_result2 = 'repo'
    actual_result2 = RoleRequirement.repo_url_to_role

# Generated at 2022-06-21 01:18:12.908620
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_requirement = "git+https://github.com/username/repo name,1.0.0"
    requirement = RoleRequirement.role_yaml_parse(test_requirement)
    assert requirement["name"] == "name"
    assert requirement["src"] == "https://github.com/username/repo"
    assert requirement["scm"] == "git"
    assert requirement["version"] == "1.0.0"

    test_requirement = "git+https://github.com/username/repo,1.0.0"
    requirement = RoleRequirement.role_yaml_parse(test_requirement)
    assert requirement["name"] == "repo"
    assert requirement["src"] == "https://github.com/username/repo"
    assert requirement["scm"] == "git"

# Generated at 2022-06-21 01:18:19.837235
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.compat.tests import unittest
    from ansible.utils.display import Display
    display = Display()

    class TestRoleYamlParse(unittest.TestCase):

        def test_RoleRequirement_role_yaml_parse_1(self):
            test_role = "test-role"
            result = RoleRequirement.role_yaml_parse(test_role)
            expect = dict(src=test_role, name="test-role", scm=None, version="")
            self.assertEqual(result, expect)

        def test_RoleRequirement_role_yaml_parse_2(self):
            test_role = "test-role,1.0"
            result = RoleRequirement.role_yaml_parse(test_role)

# Generated at 2022-06-21 01:18:31.156626
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src='https://github.com/ansible/ansible-examples.git'
    metadata, default_version = RoleRequirement.scm_archive_role(src)
    assert metadata["name"]=="ansible-examples"
    assert default_version == "master"

    metadata, default_version = RoleRequirement.scm_archive_role(src, version="devel")
    assert metadata["name"] == "ansible-examples"
    assert default_version == "devel"

    src = "https://github.com/ansible/ansible-examples"
    metadata, default_version = RoleRequirement.scm_archive_role(src)
    assert metadata["name"] == "ansible-examples"
    assert default_version == "HEAD"


# Generated at 2022-06-21 01:18:42.474607
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    '''
    validates pull requests related to the scm_archive_role method of class RoleRequirement

    - validates the created directory structure for a role
        see: https://github.com/ansible/ansible/pull/12904
    '''
    from ansible.playbook.role.requirement import RoleRequirement

    # the created directory structure for a role should look like
    #   - role-name-etc...
    #       - meta
    #           - main.yml
    #       - tasks
    #           - main.yml
    #       - handlers
    #           - main.yml
    #       - defaults
    #           - main.yml
    #       - files

# Generated at 2022-06-21 01:18:54.251725
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    assert RoleRequirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,4.0.0') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '4.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,4.0.0,new_name') == {'name': 'new_name', 'src': 'geerlingguy.java', 'scm': None, 'version': '4.0.0'}

# Generated at 2022-06-21 01:19:16.827966
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import shutil
    import tempfile
    from subprocess import call, check_output

    assert(call(["git", "--version"]) == 0)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create test repository
    os.chdir(tmpdir)
    assert(call(["git", "init", "--bare", "foobar.git"]) == 0)

    # Add some commits to test repository
    os.mkdir("foobar")
    os.chdir("foobar")
    assert(call(["git", "clone", "../foobar.git"]) == 0)
    os.chdir("foobar")

    assert(call(["touch", "README.md"]) == 0)

# Generated at 2022-06-21 01:19:25.291464
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
	role = 'yumrepo_role,v1.0.0,myname'
	result = RoleRequirement.role_yaml_parse(role)
	assert result == {'name': 'myname','src': 'yumrepo_role','scm': 'git','version': 'v1.0.0'}

	role = 'yumrepo_role,v1.0.0'
	result = RoleRequirement.role_yaml_parse(role)
	assert result == {'name': 'yumrepo_role','src': 'yumrepo_role','scm': 'git','version': 'v1.0.0'}

	#since the requirement is without src, it will assume src is the same as name
	role = 'yumrepo_role'
	result = RoleRequirement.role_

# Generated at 2022-06-21 01:19:38.045706
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_def = {
        'role': 'test_role',
    }
    role_def_expected = {
        'name': 'test_role',
        'scm': None,
        'src': None,
        'version': None,
    }
    assert RoleRequirement.role_yaml_parse(role_def) == role_def_expected
    role_def = {
        'role': 'test_role,0.2.0',
    }
    role_def_expected = {
        'name': 'test_role',
        'scm': None,
        'src': None,
        'version': '0.2.0',
    }
    assert RoleRequirement.role_yaml_parse(role_def) == role_def_expected

# Generated at 2022-06-21 01:19:48.262713
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

   import os
   import sys
   import pytest
   from nose.plugins.skip import SkipTest

   # Test for scm_archive_role without parameters
   def test_scm_archive_role_without_parameters():
      from ansible.playbook.role.requirement import RoleRequirement
      folder_name = RoleRequirement.scm_archive_role()
      assert os.path.exists(folder_name)
      os.removedirs(folder_name)

    # Test for scm_archive_role with parameters
   def test_scm_archive_role_with_parameters():
      from ansible.playbook.role.requirement import RoleRequirement
      folder_name = RoleRequirement.scm_archive_role(src='https://github.com/ansible/ansible-examples')

# Generated at 2022-06-21 01:19:59.043462
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = dict(name='myrole', src='git+https://git.example.com/project1.git')
    assert RoleRequirement.role_yaml_parse(role) == dict(name='myrole', src='git+https://git.example.com/project1.git', scm='git', version='')
    role = dict(role='myrole', src='git+https://git.example.com/project1.git')
    assert RoleRequirement.role_yaml_parse(role) == dict(name='myrole', src='git+https://git.example.com/project1.git', scm='git', version='')
    role = dict(name='myrole', src='https://git.example.com/project1.git')
    assert RoleRequirement.role_yaml_parse(role) == dict

# Generated at 2022-06-21 01:20:09.315103
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    rr = RoleRequirement()
    
    assert rr.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert rr.repo_url_to_role_name('http://git.example.com/repos/repo') == 'repo'
    assert rr.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert rr.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0') == 'repo'

# Generated at 2022-06-21 01:20:21.250750
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_definition = RoleRequirement()

# Generated at 2022-06-21 01:20:29.817434
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    from ansible.playbook.role.requirement import RoleRequirement

    # test for
    #  - name only
    assert RoleRequirement.role_yaml_parse('apache') == {'src': 'apache', 'version': None, 'scm': None, 'name': 'apache'}

    # test for
    #  - name and version
    assert RoleRequirement.role_yaml_parse('apache,v1.0') == {'src': 'apache', 'version': 'v1.0', 'scm': None, 'name': 'apache'}

    # test for
    #  - name, version and scm

# Generated at 2022-06-21 01:20:37.650785
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name(None) == None
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo,v1.0'


# Generated at 2022-06-21 01:20:38.317342
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    req = RoleRequirement()
    assert req is not None

# Generated at 2022-06-21 01:21:08.145733
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    from ansible.module_utils._text import to_text

    assert RoleRequirement.repo_url_to_role_name(to_text("http://git.example.com/repos/repo.git")) == "repo"
    assert RoleRequirement.repo_url_to_role_name(to_text("git+git@git.example.com:repos/repo.git")) == "repo"
    assert RoleRequirement.repo_url_to_role_name(to_text("git+ssh://git@git.example.com/repos/repo.git")) == "repo"
    assert RoleRequirement.repo_url_to_role_name(to_text("jdoe@git.example.com:repos/repo.git")) == "repo"
    assert RoleRequ

# Generated at 2022-06-21 01:21:10.868197
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    rr = RoleRequirement()
    assert rr
    assert rr.__dict__
    assert rr.__module__ == "ansible.playbook.role.requirement"

# Generated at 2022-06-21 01:21:22.664134
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    role = RoleRequirement()

    # Testcase 1: Version is not passed.
    archive = role.scm_archive_role('https://github.com/danielkrug/ansible-role-jre.git', scm='git', name='danielkrug.jre')

    if not isinstance(archive, dict):
        raise Exception("scm_archive_role() returned unexpected data type")

    if archive['name'] != 'danielkrug.jre':
        raise Exception("scm_archive_role() returned unexpected name")

    if archive['scm'] != 'git':
        raise Exception("scm_archive_role() returned unexpected scm")

    if archive['version'] != 'HEAD':
        raise Exception("scm_archive_role() returned unexpected version")

    # Testcase 2: Version is passed.
    archive

# Generated at 2022-06-21 01:21:29.393876
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    with tempfile.TemporaryDirectory() as tmpdir:
        repo_url = "https://github.com/geerlingguy/ansible-role-apache.git"
        role_name = RoleRequirement.repo_url_to_role_name(repo_url)
        role_version = "1.5.2"
        role_path = os.path.join(tmpdir, role_name)

        RoleRequirement.scm_archive_role(repo_url, scm='git',
                                         name=role_name, version=role_version)

        manifests = ["vars", "defaults", "meta", "tasks", "handlers", "files", "templates", "library", "module_utils", "tests", "locale"]
        for manifest in manifests:
            manifest_path = os.path.join

# Generated at 2022-06-21 01:21:39.946891
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.basic import AnsibleModule

    try:
        import git
    except ImportError:
        module = AnsibleModule(argument_spec=dict())
        module.warn("skipping due to missing required gitpython library")
        module.exit_json(skipped=True)
    else:
        # Testing with a git url
        url = "https://github.com/ansible/ansible-examples.git"
        results = RoleRequirement.scm_archive_role(url)
        assert results == 0

        # Testing with a svn url
        url = "https://github.com/ansible/ansible-examples"
        results = RoleRequirement.scm_archive_role(url, scm="svn")
        assert results == 0

# Generated at 2022-06-21 01:21:47.926501
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git@gitlab.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://gitlab.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://gitlab.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://gitlab.example.com/repos/repo,v2.0.0") == "repo"

# Generated at 2022-06-21 01:21:58.452845
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.module_utils.six import BytesIO
    from ansible.utils.vars import combine_vars
    from ansible.playbook.role.definition import RoleDefinition
    import yaml


# Generated at 2022-06-21 01:22:06.212630
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role1 = RoleRequirement.role_yaml_parse("geerlingguy.nginx")
    role2 = RoleRequirement.role_yaml_parse("geerlingguy.nginx,1.x")
    role3 = RoleRequirement.role_yaml_parse("git+git@github.com:geerlingguy/ansible-role-nginx.git,1.x,geerlingguy.nginx")
    role4 = RoleRequirement.role_yaml_parse("src: geerlingguy.nginx, other_var: other_value")
    role5 = RoleRequirement.role_yaml_parse("src: geerlingguy.nginx, version: 1.x, other_var: other_value")

# Generated at 2022-06-21 01:22:16.030387
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:22:21.762847
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:23:10.118499
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    rr = RoleRequirement()
    assert issubclass(type(rr), RoleDefinition)
    assert rr.__doc__ is not None
    assert hasattr(rr, '__init__')



# Generated at 2022-06-21 01:23:21.164763
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.utils.unicode import to_unicode
    from ansible.utils.vars import combine_vars

    role_spec = dict(
        name='some_role',
        src='git+https://github.com/some_user/some_repo.git',
        version='v2.0.0',
        path='/path/to/',
        scm='git',
        galaxy_info={'platforms': ['all']},
    )

    r = RoleRequirement(**role_spec)

    for k, v in role_spec.items():
        assert getattr(r, k) == v

    assert r.get_info()['description'] == 'some_role'
    assert r.get_info()['authors'] == []

# Generated at 2022-06-21 01:23:27.588301
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    from ansible.module_utils.urls import download_file
    from ansible.utils.path import makedirs_safe

    def content_scm_archive_role(src, scm='git', name=None, version='HEAD', keep_scm_meta=False):
        tmpdir = makedirs_safe(os.path.join(test_dir, 'content'))
        local_path = os.path.join(tmpdir, "test_role")
        fd, local_path = tempfile.mkstemp(prefix='content', dir=tmpdir)
        f = os.fdopen(fd,'w')
        f.write(content_archive_role(src, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta))
        f.close()
       

# Generated at 2022-06-21 01:23:38.081305
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git+git@github.com:ansible/ansible-modules-core.git") == "ansible-modules-core"
    assert RoleRequirement.repo_url_to_role_name("ansible-modules-core.git") == "ansible-modules-core"
    assert RoleRequirement.repo_url_to_role_name("ansible,http://example.com/foo/1.0.tar.gz,foo") == "foo"
    assert RoleRequirement.repo_url_to_role_name("git+git@github.com:ansible/ansible-modules-core.git,v1.0,foo") == "foo"

# Generated at 2022-06-21 01:23:39.618171
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    assert role_requirement

# Generated at 2022-06-21 01:23:47.810967
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("https://github.com/jtyr/ansible-nginx.git") == "ansible-nginx"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/jtyr/ansible-nginx") == "ansible-nginx"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/jtyr/ansible-nginx.tar.gz") == "ansible-nginx"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/jtyr/ansible-nginx,v1.0,my_name") == "ansible-nginx"
    assert RoleRequirement.repo_url_to_role_name

# Generated at 2022-06-21 01:23:52.513015
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.release import __version__ as ansible_version
    from ansible import __version__ as ansible_pkg_version

    print("\nAnsible version: %s" % ansible_version)
    print("Ansible package version: %s\n" % ansible_pkg_version)


# Generated at 2022-06-21 01:24:00.934364
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    rq = RoleRequirement()

    # src is michael
    assert rq.role_yaml_parse('michael') == dict(name='michael', src='michael', scm=None, version=None)

    # src is michael, version is dehaan
    assert rq.role_yaml_parse('michael,dehaan') == dict(name='michael', src='michael', scm=None, version='dehaan')

    # src is michael, version is dehaan, name is michael.dehaan
    assert rq.role_yaml_parse('michael,dehaan,michael.dehaan') == dict(name='michael.dehaan', src='michael', scm=None, version='dehaan')

    # src is git+https://github.com