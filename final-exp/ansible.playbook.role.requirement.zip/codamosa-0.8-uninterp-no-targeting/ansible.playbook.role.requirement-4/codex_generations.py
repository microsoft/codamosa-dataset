

# Generated at 2022-06-21 01:14:25.612883
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("https://github.com/ansible/ansible-examples") == "ansible-examples"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/ansible/ansible-examples") == "ansible-examples"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/ansible/ansible-examples,v0.9.4") == "ansible-examples"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/ansible/ansible-examples,v0.9.4,abc") == "abc"

# Generated at 2022-06-21 01:14:30.167504
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # non-url name
    assert RoleRequirement.scm_archive_role("https://github.com/ansible/ansible-examples", "git", name="ansible-examples", version="HEAD") == "https://github.com/ansible/ansible-examples.git"
    assert RoleRequirement.scm_archive_role("https://github.com/ansible/ansible-examples", "git", version="HEAD") == "https://github.com/ansible/ansible-examples.git"
    assert RoleRequirement.scm_archive_role("https://github.com/ansible/ansible-examples", "git", name="ansible-examples", version="HEAD", keep_scm_meta=True) == "https://github.com/ansible/ansible-examples.git"

# Generated at 2022-06-21 01:14:34.747216
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert(RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo")
    assert(RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo")
    assert(RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.tar.gz") == "repo")
    assert(RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0") == "repo")

# Generated at 2022-06-21 01:14:47.247596
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    def check_result(text, result):
        assert RoleRequirement.role_yaml_parse(text) == result

    check_result("myrole", {'name': 'myrole', 'src': 'myrole', 'scm': None, 'version': ''})
    check_result("geerlingguy.ansible-role-git", {'name': 'geerlingguy.ansible-role-git', 'src': 'geerlingguy.ansible-role-git', 'scm': None, 'version': ''})
    check_result("geerlingguy.nginx,v2.0.0", {'name': 'geerlingguy.nginx', 'src': 'geerlingguy.nginx', 'scm': None, 'version': 'v2.0.0'})

# Generated at 2022-06-21 01:14:59.808928
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    
    display.display("TEST - RoleRequirement.role_yaml_parse")

    if RoleRequirement.role_yaml_parse("geerlingguy.java, 1.8")["name"]=="geerlingguy.java" and RoleRequirement.role_yaml_parse("geerlingguy.java, 1.8")["scm"]==None and RoleRequirement.role_yaml_parse("geerlingguy.java, 1.8")["src"]=="geerlingguy.java" and RoleRequirement.role_yaml_parse("geerlingguy.java, 1.8")["version"]=="1.8":
        display.display("TEST PASSED")
    else:
        display.display("TEST FAILED")


# Generated at 2022-06-21 01:15:08.902927
# Unit test for method scm_archive_role of class RoleRequirement

# Generated at 2022-06-21 01:15:16.436362
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://example.com/repos/repo,ver.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://example.com/repos/repo,ver,name.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo,ver,name') == 'repo'
    assert RoleRequirement.repo_

# Generated at 2022-06-21 01:15:18.603041
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # todo: write unit test
    pass


# Generated at 2022-06-21 01:15:30.156138
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    assert RoleRequirement.scm_archive_role("https://github.com/ansible/ansible-examples.git") == dict(
        scm='git', src='https://github.com/ansible/ansible-examples.git',
        version='HEAD', name='ansible-examples')
    assert RoleRequirement.scm_archive_role("galaxy.ansible.com/ansible/ansible-examples,v1.0") == dict(
        scm=None, src='galaxy.ansible.com/ansible/ansible-examples',
        version='v1.0', name='ansible-examples')

# Generated at 2022-06-21 01:15:39.805455
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement.role_yaml_parse("some_role_name  , 0.1.1,  some_role_name")
    assert role["name"] == "some_role_name"
    assert role["version"] == "0.1.1"
    assert role["src"] == "some_role_name"

    role = RoleRequirement.role_yaml_parse("some_role_name,0.1.1,some_role_name")
    assert role["name"] == "some_role_name"
    assert role["version"] == "0.1.1"
    assert role["src"] == "some_role_name"

    role = RoleRequirement.role_yaml_parse("some_role_name,0.1.1,some_role_name")

# Generated at 2022-06-21 01:15:57.255542
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    url_template = 'github.com/{0}/{1}.git'
    name = 'myrole'
    username = 'foo'
    version = 'v1.0'
    repository = 'myrole'
    tarball_name = '{0}-{1}.tar.gz'.format(repository, version)

    # Test if the method does not fail when called with all optional arguments
    RoleRequirement.scm_archive_role(url_template.format(username, repository),
                                     name=name,
                                     version=version)

    # Test if the method does not fail when called with all optional arguments
    RoleRequirement.scm_archive_role(url_template.format(username, repository),
                                     name=name,
                                     version=version)

    # Test if the method does not fail when called without name

# Generated at 2022-06-21 01:16:09.226666
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Test valid URL formats
    assert RoleRequirement.repo_url_to_role_name('https://github.com/foo/bar') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('http://github.com/foo/bar') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('git@github.com/foo/bar.git') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/foo/bar.tar.gz') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('http://github.com/foo/bar.tar.gz') == 'bar'

# Generated at 2022-06-21 01:16:15.356609
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    d = RoleRequirement.role_yaml_parse('uri, release')
    assert(d == { "src": "uri", "version": "release", "name": "uri", "scm": None })
    e = RoleRequirement.role_yaml_parse('uri,release')
    assert(e == { "src": "uri", "version": "release", "name": "uri", "scm": None })

# Generated at 2022-06-21 01:16:22.722601
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile
    import shutil

    dest = tempfile.mkdtemp()
    try:
        r = RoleRequirement.scm_archive_role(src='http://github.com/ansible/ansible-examples',
                                             scm='git', name='ansible-examples',
                                             version='HEAD', keep_scm_meta=True)
        assert r.role_name == 'ansible-examples'
        assert r.version == 'HEAD'
        assert r.role_path == dest + '/ansible-examples'
        assert r.scm == 'git'
    finally:
        shutil.rmtree(dest)


# Generated at 2022-06-21 01:16:31.538462
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test for deprecated role string deprecation
    # old style: "role_name[,version[,name]]"
    role_string = "git+git@github.com:username/role_name,v0.0.1,role_name"
    test_role = RoleRequirement.role_yaml_parse(role_string)
    assert (test_role[u"name"] == role_string.split(',')[2])

    # Test for deprecated role string deprecation
    # old style: "role_name[,version[,name]]"
    # Note: this should break, only 2 commas allowed

# Generated at 2022-06-21 01:16:41.681098
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_yaml_parse_result = {'scm': None, 'name': 'nginx', 'src': 'https://github.com/geerlingguy/ansible-role-nginx.git'}
    assert RoleRequirement.role_yaml_parse({'src': 'https://github.com/geerlingguy/ansible-role-nginx.git'}) == role_yaml_parse_result

    role_yaml_parse_result = {'scm': None, 'name': 'django', 'src': 'https://github.com/geerlingguy/ansible-role-django', 'version': 'v1.9.2'}

# Generated at 2022-06-21 01:16:53.223000
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:16:54.534440
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    assert not role_requirement

# Generated at 2022-06-21 01:17:02.041098
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """
    This method tests if the method role_yaml_parse of class RoleRequirement
    works as expected.
    """

# Generated at 2022-06-21 01:17:13.598657
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test role with name and version from repository URL
    assert RoleRequirement.role_yaml_parse('https://github.com/ansible/ansible-examples.git') == dict(name='ansible', src='https://github.com/ansible/ansible-examples.git', scm=None, version=None)

    # Test role with name, but no version from repository URL
    assert RoleRequirement.role_yaml_parse('https://github.com/ansible/ansible-examples.git,v1.0.0') == dict(name='ansible', src='https://github.com/ansible/ansible-examples.git', scm=None, version='v1.0.0')

    # Test role with name, but no version and SCM from repository URL
    assert RoleRequirement.role_yaml

# Generated at 2022-06-21 01:17:38.999252
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    src_1 = 'foo.tar.gz'
    assert RoleRequirement.repo_url_to_role_name(src_1) == 'foo'

    src_2 = 'foo.tar'
    assert RoleRequirement.repo_url_to_role_name(src_2) == 'foo.tar'

    src_3 = 'git+https://github.com/vietstacker/ansible-role-rancher.git'
    assert RoleRequirement.repo_url_to_role_name(src_3) == 'ansible-role-rancher'

    src_4 = 'https://github.com/vietstacker/ansible-role-rancher.git'

# Generated at 2022-06-21 01:17:49.614797
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_string = "geerlingguy.ntp"
    role_ansible_galaxy = {"name": "geerlingguy.ntp", "src": "geerlingguy.ntp", "scm": None, "version": None}
    role_dict_galaxy = {"name": "geerlingguy.ntp", "src": "geerlingguy.ntp", "version": 'latest'}
    role_dict_github = {"name": "geerlingguy.ntp", "src": "https://github.com/geerlingguy/ansible-role-ntp.git", "scm": "git", "version": "HEAD"}

# Generated at 2022-06-21 01:18:00.578841
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:18:10.975275
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # Test 1: Scm git source.
    # Expected output: A valid role name.
    role_name = RoleRequirement.scm_archive_role(src='https://github.com/example/test_RoleRequirement_scm_archive_role_1', scm='git')
    assert role_name.endswith('test_RoleRequirement_scm_archive_role_1')

    # Test 2: Scm git source with version.
    # Expected output: A valid role name.
    role_name = RoleRequirement.scm_archive_role(src='https://github.com/example/test_RoleRequirement_scm_archive_role_2', scm='git', version=0.1)

# Generated at 2022-06-21 01:18:23.465886
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test string_types
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git') == \
           {
               'name': 'repo',
               'scm': None,
               'src': 'http://git.example.com/repos/repo.git',
               'version': None,
           }
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,tag_name') == \
           {
               'name': 'repo',
               'scm': None,
               'src': 'http://git.example.com/repos/repo.git',
               'version': 'tag_name',
           }

# Generated at 2022-06-21 01:18:33.394046
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    print("\nTESTING CONSTRUCTOR")

    # Test the constructor
    req = RoleRequirement()

    # Test the private method role_yaml_parse()
    print("\nTESTING PRIVATE METHOD role_yaml_parse()")

    # Since the doc for this method isn't very clear I don't understand the following tests
    #
    role   = 'geerlingguy.ansible-role-apache'
    result = req.role_yaml_parse(role)
    #print(result) # {'name': 'geerlingguy.ansible-role-apache', 'version': None, 'scm': None, 'src': 'geerlingguy.ansible-role-apache'}

# Generated at 2022-06-21 01:18:45.039137
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:18:56.143084
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    """
    # TODO:
    # 1. Tests for "name" and "version" argument for method "scm_archive_role".
    # 2. Tests for creating archive from source SCM.
    """
    from tempfile import TemporaryDirectory
    from os import getcwd, chdir, path, sep
    from shutil import rmtree

    # Getting current working directory
    cwd = getcwd()
    # Creating temporary directory
    with TemporaryDirectory() as tempdir:
        # Changing directory to temporary directory
        chdir(tempdir)
        # Creating temporary tar archive
        tar_file_path = RoleRequirement.scm_archive_role("git://github.com/ansible/ansible-examples.git")
        assert path.exists(tar_file_path)
        assert tar_file_path.endswith

# Generated at 2022-06-21 01:19:06.451903
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role1 = RoleRequirement.repo_url_to_role_name('https://github.com/jdauphant/ansible-role-nginx')
    assert role1 == "ansible-role-nginx"

    role2 = RoleRequirement.repo_url_to_role_name('https://github.com/jdauphant/ansible-role-nginx.git')
    assert role2 == "ansible-role-nginx"

    role3 = RoleRequirement.repo_url_to_role_name('https://github.com/jdauphant/ansible-role-nginx,v1.0')
    assert role3 == "ansible-role-nginx"


# Generated at 2022-06-21 01:19:17.521954
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    """Verify that all supported SCM types work correctly with scm_archive_role."""
    rr = RoleRequirement()
    role_tarball = rr.scm_archive_role('https://github.com/ansible/ansible-examples', scm='git')
    assert role_tarball.endswith('ansible-examples-ansible-1.4.tgz')
    role_tarball = rr.scm_archive_role('git://github.com/ansible/ansible-examples', scm='git')
    assert role_tarball.endswith('ansible-examples-ansible-1.4.tgz')

# Generated at 2022-06-21 01:19:34.427563
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    obj = RoleRequirement()
    assert obj



# Generated at 2022-06-21 01:19:38.045514
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    requirement = RoleRequirement()
    assert requirement is not None
    assert requirement.__class__.__name__ == 'RoleRequirement'


# Generated at 2022-06-21 01:19:40.764470
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('https://github.com/MakG10/ansible-role-git.gittemp') == 'ansible-role-git.gittemp'


# Generated at 2022-06-21 01:19:42.805863
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    ''' Test of constructor of class RoleRequirement '''

    rr = RoleRequirement()
    assert rr



# Generated at 2022-06-21 01:19:54.929339
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test for parsing old-style format "role[,version[,name]]"
    role = RoleRequirement.role_yaml_parse('geerlingguy.java,1.8.0,myjava')
    assert role['name'] == 'myjava'
    assert role['version'] == '1.8.0'
    assert role['scm'] is None
    assert role['src'] == 'geerlingguy.java'

    role = RoleRequirement.role_yaml_parse('geerlingguy.java,1.8.0')
    assert role['name'] == 'geerlingguy.java'
    assert role['version'] == '1.8.0'
    assert role['scm'] is None
    assert role['src'] == 'geerlingguy.java'

    role = RoleRequirement.role_y

# Generated at 2022-06-21 01:20:05.273213
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('https://github.com/user/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/user/repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/user/repo.git,v1.2.3') == 'repo'

# Generated at 2022-06-21 01:20:12.041574
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:20:23.462761
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    from ansible.playbook.role.requirement import RoleRequirement
    role_name = RoleRequirement.repo_url_to_role_name("https://github.com/namespace/role_name.git")
    assert role_name == "role_name"
    role_name = RoleRequirement.repo_url_to_role_name("https://github.com/namespace/role_name")
    assert role_name == "role_name"
    role_name = RoleRequirement.repo_url_to_role_name("https://github.com/namespace/role_name.tar.gz")
    assert role_name == "role_name"

# Generated at 2022-06-21 01:20:30.813232
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import sys
    display.verbosity = 6

    ###########
    #
    # Try on the ansible.git repo (GitHub.com)
    #
    ###########
    success = None
    try:
        success = RoleRequirement.scm_archive_role('git+git://github.com/ansible/ansible.git',
                                                   version="v2.3.3.0-1",
                                                   keep_scm_meta=True)
    except Exception as e:
        print(e)
        print("Ansible.git clone failed.  This is a test error.  Please alert the author.")

    #
    # Verify results
    #

# Generated at 2022-06-21 01:20:33.006940
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    assert role is not None



# Generated at 2022-06-21 01:21:20.890080
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    rr = RoleRequirement()

    # Old style
    assert rr.role_yaml_parse('my.role.name') == {'name': 'my.role.name', 'scm': None, 'src': 'my.role.name', 'version': ''}
    assert rr.role_yaml_parse({'role': 'my.role.name'}) == {'name': 'my.role.name', 'scm': None, 'src': 'my.role.name', 'version': ''}
    assert rr.role_yaml_parse({'role': 'my.role.name', 'version': '1.0'}) == {'name': 'my.role.name', 'scm': None, 'src': 'my.role.name', 'version': '1.0'}

    # New style

# Generated at 2022-06-21 01:21:27.420289
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    role_req_obj = RoleRequirement()
    src = "https://github.com/jtyr/ansible-network-sandbox.git"
    scm = "git"
    name = None
    version = "HEAD"
    keep_scm_meta = False
    assert role_req_obj.scm_archive_role(src=src, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta) == "/tmp/tmpyejaj4b/ansible-network-sandbox-HEAD"


# Generated at 2022-06-21 01:21:39.438370
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test string-based input
    assert RoleRequirement.role_yaml_parse('foo,v2') == dict(name='foo', src='foo', scm=None, version='v2')
    assert RoleRequirement.role_yaml_parse('http://github.com/foo/bar,v2') == dict(name='bar', src='http://github.com/foo/bar', scm=None, version='v2')
    assert RoleRequirement.role_yaml_parse('git+http://github.com/foo/bar,v2') == dict(name='bar', src='http://github.com/foo/bar', scm='git', version='v2')

# Generated at 2022-06-21 01:21:47.642605
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Test implementation of method repo_url_to_role_name of class RoleRequirement
    # with an empty string
    assert RoleRequirement.repo_url_to_role_name("") == ""
    # with a path with no slashes
    assert RoleRequirement.repo_url_to_role_name("foo") == "foo"
    # with a path with only one slash
    assert RoleRequirement.repo_url_to_role_name("/foo") == "foo"
    # with a path with many slashes
    assert RoleRequirement.repo_url_to_role_name("/foo/bar") == "bar"
    # with a path with many slashes and a .git ending
    assert RoleRequirement.repo_url_to_role_name("/foo/bar.git") == "bar"


# Generated at 2022-06-21 01:21:58.074900
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Check if the constructor of class RoleRequirement can deal with spec which is a string
    role = RoleRequirement.role_yaml_parse("galaxy.role,version,name")
    assert 'galaxy.role' == role['src']
    assert 'git' == role['scm']
    assert 'version' == role['version']
    assert 'name' == role['name']

    # Check if the constructor of class RoleRequirement can deal with spec which is a simple dictionary
    role = RoleRequirement.role_yaml_parse({ "role": "galaxy.role" })
    assert 'galaxy.role' == role['name']
    assert None is role['scm']
    assert None is role['src']
    assert None is role['version']

    # Check if the constructor of class RoleRequirement can deal with spec which is a complicated

# Generated at 2022-06-21 01:22:05.144017
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # SCM archive source URL: git@github.com:omgitsads/network_ansible.git
    archive_source = "git@github.com:omgitsads/network_ansible.git"
    # Role name
    role_name = "network_ansible"
    # Version: HEAD
    version = "HEAD"

    role_archive_path = RoleRequirement.scm_archive_role(archive_source, version=version, name=role_name)

    assert role_archive_path.endswith(".tar.gz"), "Role archive should be a tar.gz file"

if __name__ == '__main__':
    test_RoleRequirement()

# Generated at 2022-06-21 01:22:10.494789
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    output = RoleRequirement.scm_archive_role(src="https://github.com/jctanner/test.git", name=None, version='HEAD', keep_scm_meta=False)
    assert output == tmp_dir + "/jctanner-test-73eea57.tar.gz"

# Generated at 2022-06-21 01:22:18.676702
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com:repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com:repo.git') == 'repo'
    assert RoleRequirement

# Generated at 2022-06-21 01:22:25.312185
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = 'https://github.com/geerlingguy/ansible-role-jenkins.git'
    expected = 'https://github.com/geerlingguy/ansible-role-jenkins/archive/HEAD.tar.gz'
    actual = RoleRequirement.scm_archive_role(src)
    assert expected == actual

# Generated at 2022-06-21 01:22:35.806922
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # test some basic cases, using the old-style format:
    # - name, src
    # - name, src, version
    # - name, src, version, scm

    r = RoleRequirement()

    # test the old format "name, src, version"
    role_line = ('foo.bar,src_url,1.2')
    result = r.role_yaml_parse(role_line)
    for key in VALID_SPEC_KEYS:
        assert key in result
    assert result['name'] == 'foo.bar'
    assert result['src'] == 'src_url'
    assert result['version'] == '1.2'

    # test the old format (role, src)
    role_line = ('role_name,src_url')

# Generated at 2022-06-21 01:23:41.170528
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_yaml = 'git+https://github.com/username/repo.git,1.0,role_name'
    results = RoleRequirement.role_yaml_parse(role_yaml)
    assert dict(name='role_name', src='https://github.com/username/repo.git', scm='git', version='1.0') == results

    role_yaml = 'git+https://github.com/username/repo.git,1.0'
    results = RoleRequirement.role_yaml_parse(role_yaml)
    assert dict(name='repo', src='https://github.com/username/repo.git', scm='git', version='1.0') == results


# Generated at 2022-06-21 01:23:48.939526
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    def do_test_role_yaml_parse(role_input, expected_result):
        """ Check that role_input is parsed as expected_result

        :param role_input: the string or dict to check
        :param expected_result: the dict expected for role_input
        :return: bool as success or failure
        """

        actual_result = RoleRequirement.role_yaml_parse(role_input)
        if actual_result == expected_result:
            return True
        else:
            print("RoleRequirement.role_yaml_parse(%s) == %s, not %s" % (role_input, actual_result, expected_result))
            return False


# Generated at 2022-06-21 01:23:59.008935
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    url = 'https://github.com/geerlingguy/ansible-role-apache.git'
    name = 'apache'
    version = 'HEAD'

    req = RoleRequirement.role_yaml_parse('{0},{1}'.format(url, version))
    assert req['name'] == name
    assert req['version'] == version
    assert req['scm'] == 'git'
    assert req['src'] == url

    # Test RoleRequirement.repo_url_to_role_name
    url = 'https://github.com/geerlingguy/ansible-role-apache.git'
    name = 'ansible-role-apache'
    assert RoleRequirement.repo_url_to_role_name(url) == name
