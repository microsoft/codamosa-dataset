

# Generated at 2022-06-21 01:14:11.838279
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role = RoleRequirement()
    # Tests without prefix 'git+'
    assert role.repo_url_to_role_name('foo') == 'foo'
    assert role.repo_url_to_role_name('foo.git') == 'foo'
    assert role.repo_url_to_role_name('foo.tar.gz') == 'foo'
    assert role.repo_url_to_role_name('foo,bar') == 'foo'
    assert role.repo_url_to_role_name('foo.git,bar') == 'foo'
    assert role.repo_url_to_role_name('git://git.foo.com/foo,bar') == 'foo'
    assert role.repo_url_to_role_na

# Generated at 2022-06-21 01:14:23.640616
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("/path/to/repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("/path/to/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("/path/to/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("foo/bar/repo.git,1.2.3") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"

# Generated at 2022-06-21 01:14:31.940773
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement.role_yaml_parse("git+http://github.com/user1/test")['name'] == 'test'
    assert RoleRequirement.role_yaml_parse("https://github.com/user1/test,v1")['name'] == 'test'
    assert RoleRequirement.role_yaml_parse("https://github.com/user1/test,v1,name")['name'] == 'name'
    assert RoleRequirement.role_yaml_parse("http://github.com/user1/test,v1,name")['name'] == 'name'
    assert RoleRequirement.role_yaml_parse("http://github.com/user1/test,v1,name")['version'] == 'v1'

# Generated at 2022-06-21 01:14:39.915031
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # test for old style
    old_style_role_yaml = "my.galaxy.role, v1.0.0"
    rr = RoleRequirement.role_yaml_parse(old_style_role_yaml)
    assert type(rr) == dict
    assert rr['scm'] is None
    assert rr['version'] == "v1.0.0"
    assert rr['name'] == "my.galaxy.role"

    # test for new style
    # without scm
    role_yaml = {'src': 'my.galaxy.role,v1.0.0'}
    rr = RoleRequirement.role_yaml_parse(role_yaml)
    assert type(rr) == dict
    assert rr['scm'] is None

# Generated at 2022-06-21 01:14:49.300550
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert(RoleRequirement.role_yaml_parse('src=galaxy.role,version=1.0,name=role,other_vars=here') == {
        'name': 'role',
        'scm': None,
        'src': 'galaxy.role',
        'version': '1.0'
    })
    assert(RoleRequirement.role_yaml_parse('galaxy.role,1.0,role') == {
        'name': 'role',
        'scm': None,
        'src': 'galaxy.role',
        'version': '1.0'
    })

# Generated at 2022-06-21 01:14:55.338564
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test case #1: Invalid old style role requirement
    role = 'weareinteractive.java,master'
    exception_thrown = False
    try:
        role_yaml_parse(role)
    except AnsibleError:
        exception_thrown = True
    assert(exception_thrown)

    # Test case #2: Old style role requirement(without any optional argument)
    role = 'weareinteractive.java'
    role_yaml_parse(role)

    # Test case #3: Old style role requirement(with version and name)
    role = 'weareinteractive.java,master,role'
    role_yaml_parse(role)

    # Test case #4: Old style role requirement(with name)
    role = 'weareinteractive.java,,role'

# Generated at 2022-06-21 01:15:01.456569
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    import yaml

    #
    # Old format
    #
    example_old_format = yaml.load('''
    - role: galaxy.role
    ''')

    if RoleRequirement.role_yaml_parse(example_old_format[0]) != {'name': 'galaxy.role', 'src': 'galaxy.role', 'scm': None, 'version': ''}:
        print('Example old format FAILED')
        exit(1)
    else:
        print('Example old format OK')

    #
    # New format
    #

    # New format, minimal.
    example_new_format_minimal = yaml.load('''
    - role: galaxy.role
    ''')


# Generated at 2022-06-21 01:15:09.721167
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    r = RoleRequirement()
    role_name = r.repo_url_to_role_name("http://github.com/user/repo.git")
    assert role_name == "repo"

    role_name = r.repo_url_to_role_name("http://github.com/user/repo.git,v1.0")
    assert role_name == "repo"

    role_name = r.repo_url_to_role_name("user/repo,v1.0")
    assert role_name == "repo"


# Generated at 2022-06-21 01:15:17.086048
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('git@example.com:user/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://example.com/user/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('file:///home/user/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('file:///home/user/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('file:///home/user/repo_name,v1.0.0.tar.gz') == 'repo_name'

# Generated at 2022-06-21 01:15:28.432113
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    def check(expected, repo_url):
        assert RoleRequirement.repo_url_to_role_name(repo_url) == expected

    # Typical case
    check("repo", "http://git.example.com/repos/repo.git")

    # Ensure we handle URLs starting with git+
    check("repo", "git+http://git.example.com/repos/repo.git")

    # Ensure we handle URLs not ending in .git
    check("repo", "https://github.com/some/repo")

    # Ensure we handle URLs containing an anchor
    check("repo", "https://github.com/some/repo#anchor")

    # Ensure we handle URLs containing a query string
    check("repo", "https://github.com/some/repo?foo=bar")



# Generated at 2022-06-21 01:15:40.486050
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test with a properly formatted YAML string containing a role definition
    role = "role_name,version,name"
    expected_output = dict(name="name", src="role_name", scm=None, version="version")
    assert RoleRequirement.role_yaml_parse(role) == expected_output

    # Test with a properly formatted YAML string containing a role definition, with
    #   multiple commas in src spec, in order to ensure that only the first two are
    #   used, with the last being ignored
    role = "role_name,version,name,extra_ignored_text"
    expected_output = dict(name="name", src="role_name", scm=None, version="version")
    assert RoleRequirement.role_yaml_parse(role) == expected_output

    # Test with a properly

# Generated at 2022-06-21 01:15:51.762926
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = dict(name='foo', src='git+https://github.com/username/foo.git', version='1.2.3')
    assert RoleRequirement.role_yaml_parse(role) == role
    role = dict(name='foo', src='https://github.com/username/foo.git', version='1.2.3')
    assert RoleRequirement.role_yaml_parse(role) == role
    role = dict(role='git+https://github.com/username/foo.git,1.2.3')
    assert RoleRequirement.role_yaml_parse(role) == role
    role = dict(role='https://github.com/username/foo.git,1.2.3')
    assert RoleRequirement.role_yaml_parse(role) == role

# Generated at 2022-06-21 01:15:53.249415
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    requirement = RoleRequirement()
    assert requirement != None

# Generated at 2022-06-21 01:16:01.044967
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    repo_url = "http://git.example.com/repos/repo.git"
    result = RoleRequirement.repo_url_to_role_name(repo_url)
    assert result == "repo"
    repo_url = "https://github.com/username/ansible-role-nginx.git"
    result = RoleRequirement.repo_url_to_role_name(repo_url)
    assert result == "ansible-role-nginx"
    repo_url = "git+git@github.com:username/ansible-role-nginx.git"
    result = RoleRequirement.repo_url_to_role_name(repo_url)
    assert result == "ansible-role-nginx"

# Generated at 2022-06-21 01:16:05.473521
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    test_case = ["git://github.com/foo/bar.git", "svn+http://github.com/foo/bar.git"]
    for case in test_case:
        assert case == RoleRequirement.repo_url_to_role_name(case)

# Generated at 2022-06-21 01:16:13.874827
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Testing AnsibleError exception
    role_str = 'git+https://github.com/foo/bar.git,master,foobar,baz'
    assert_exception(role_str, AnsibleError)
    role_str = 'git+https://github.com/foo/bar.git,master,foobar'
    assert_exception(role_str, AnsibleError)

    # Testing Format 1: { src: 'galaxy.role,version,name', other_vars: "here" }

# Generated at 2022-06-21 01:16:14.835500
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement()

# Generated at 2022-06-21 01:16:25.748665
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('git+git@github.com:racker/racker-galaxy-vars.git') == 'racker-galaxy-vars'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/racker/racker-galaxy-vars.git') == 'racker-galaxy-vars'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/racker/racker-galaxy-vars,devel') == 'racker-galaxy-vars'

# Generated at 2022-06-21 01:16:37.900245
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # Test for 'role_name[,version[,name]]' form
    role = 'geerlingguy.java'
    requirement = RoleRequirement.role_yaml_parse(role)
    assert requirement['name'] == 'geerlingguy.java'
    assert requirement['scm'] is None
    assert requirement['src'] == 'geerlingguy.java'
    assert requirement['version'] == ''

    role = 'geerlingguy.java,v1.2.3'
    requirement = RoleRequirement.role_yaml_parse(role)
    assert requirement['name'] == 'geerlingguy.java'
    assert requirement['scm'] is None
    assert requirement['src'] == 'geerlingguy.java'
    assert requirement['version'] == 'v1.2.3'


# Generated at 2022-06-21 01:16:49.391306
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    rr = RoleRequirement()
    d = rr.role_yaml_parse("geerlingguy.ntp,1.2.0")
    assert d == {'name': 'geerlingguy.ntp', 'scm': None, 'src': 'geerlingguy.ntp', 'version': '1.2.0'}

    d = rr.role_yaml_parse("https://github.com/geerlingguy/ansible-role-ntp.git,1.2.0")
    assert d == {'name': 'ansible-role-ntp', 'scm': 'git', 'src': 'https://github.com/geerlingguy/ansible-role-ntp.git', 'version': '1.2.0'}


# Generated at 2022-06-21 01:17:02.531695
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:17:13.800030
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.yaml") == "repo.yaml"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.yml") == "repo.yml"

# Generated at 2022-06-21 01:17:23.642282
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:17:30.316910
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import os, tempfile
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.display import Display
    display = Display()


# Generated at 2022-06-21 01:17:40.652008
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse('foo,0.4.2,my_awesome_role')
    assert role['name'] == 'my_awesome_role'
    assert role['src'] == 'foo'
    assert role['version'] == '0.4.2'

    role = RoleRequirement.role_yaml_parse('git+https://github.com/foo.git')
    assert role['name'] == 'foo'
    assert role['src'] == 'https://github.com/foo.git'
    assert role['scm'] == 'git'
    assert role['version'] is None

    role = RoleRequirement.role_yaml_parse('git+https://github.com/foo.git,my_awesome_role,0.4.2')

# Generated at 2022-06-21 01:17:50.226232
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # In this case the method role_yaml_parse should return the name, scm, src and version
    # as expected. The default value of 'head' should be given to version if it is not given.
    role = 'my.test.role'
    expected_result = {'name': 'my.test.role', 'scm': None, 'src': 'my.test.role', 'version': ''}
    actual_result = RoleRequirement.role_yaml_parse(role)
    assert expected_result == actual_result

    # In this case the method role_yaml_parse should return the name, scm, src and version
    # as expected. The default value of 'head' should be given to version if it is not given.
    role = 'my.test.role,1.0.0'

# Generated at 2022-06-21 01:18:01.182425
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # this should fail, but what should it raise?
    #assert_raises(AnsibleError, RoleRequirement.role_yaml_parse, "name,version,extra,cruft")

    assert RoleRequirement.role_yaml_parse("role_name") == {'name': 'role_name', 'scm': None, 'src': 'role_name', 'version': ''}
    assert RoleRequirement.role_yaml_parse("github.com/foo/bar.git") == {'name': 'bar', 'scm': None, 'src': 'github.com/foo/bar.git', 'version': ''}

# Generated at 2022-06-21 01:18:11.428146
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("https://github.com/role") == "role"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/role.git") == "role"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/role.tar.gz") == "role"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/role.git,v1.0.0") == "role"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/role.tar.gz,v1.0.0") == "role"

# Generated at 2022-06-21 01:18:16.376589
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    rr = RoleRequirement()
    assert hasattr(rr, 'role_yaml_parse')
    assert hasattr(rr, 'repo_url_to_role_name')
    assert hasattr(rr, 'scm_archive_role')



# Generated at 2022-06-21 01:18:28.219425
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    display.verbosity = 4
    # test "src": "https://github.com/example/repo.git,v1.0"
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    src = "https://github.com/example/repo.git,v1.0"
    scm = 'git'
    role_name = "repo"
    role_version = "v1.0"
    result = RoleRequirement.scm_archive_role(src, scm=scm, name=role_name, version=role_version)
    assert 'github.com' in result.get('url'), "failed to use 'src' as url, %s" % result.get('url')

# Generated at 2022-06-21 01:18:39.698041
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    """
    Run unit test for constructor.

    :return:
    """
    RoleRequirement.role_yaml_parse("http://github.com/brianthicks/ansible-role-symfony.git")



# Generated at 2022-06-21 01:18:51.609210
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_data_1= {"role": "geerlingguy.apache"}
    role_data_2= {"role": "geerlingguy.git"}
    role_data_3= {"role": "geerlingguy.mysql"}
    role_data_4= {"role": "geerlingguy.php"}
    role_data_5= {"role": "geerlingguy.php-mysql"}
    role_data_6= {"role": "geerlingguy.php-mysql", "some_other_param": "some_value"}
    role_data_7= {"name": "geerlingguy.php-mysql", "some_other_param": "some_value"}

# Generated at 2022-06-21 01:18:58.665705
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse("git+https://github.com/bertram25/ansible-role-minio")
    print (role)
    role = RoleRequirement.role_yaml_parse("git+https://github.com/bertram25/ansible-role-minio,v1.0.1")
    print (role)
    role = RoleRequirement.role_yaml_parse("git+https://github.com/bertram25/ansible-role-minio,v1.0.1,minio")
    print (role)


test_RoleRequirement_role_yaml_parse()

# Generated at 2022-06-21 01:19:06.839968
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    result = RoleRequirement.scm_archive_role('https://github.com/rjocoleman/ansible-role-ntp.git')
    assert result == 'ansible-role-ntp-1.1.1.tar.gz'
    result = RoleRequirement.scm_archive_role('https://github.com/rjocoleman/ansible-role-ntp.git', version='v1.0.0')
    assert result == 'ansible-role-ntp-1.0.0.tar.gz'

# Generated at 2022-06-21 01:19:17.764599
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com:repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('ssh://git@git.example.com:repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-21 01:19:23.777938
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:19:34.650691
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_name = RoleRequirement.repo_url_to_role_name('abc')
    assert role_name == 'abc'
    role_name = RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git')
    assert role_name == 'repo'
    role_name = RoleRequirement.repo_url_to_role_name('git@git.example.com/repos/repo.git')
    assert role_name == 'repo'
    role_name = RoleRequirement.repo_url_to_role_name('abc/repo.tar.gz')
    assert role_name == 'repo'



# Generated at 2022-06-21 01:19:42.952945
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert 'git-repo' == RoleRequirement.repo_url_to_role_name('git-repo')
    assert 'git-repo' == RoleRequirement.repo_url_to_role_name('fake-user@git-repo.git')
    assert 'git-repo' == RoleRequirement.repo_url_to_role_name('ssh://fake-user@git-repo.git')
    assert 'git-repo' == RoleRequirement.repo_url_to_role_name('http://git-repo.git')
    assert 'git-repo' == RoleRequirement.repo_url_to_role_name('http://fake-user@git-repo.git')
    assert 'git-repo' == RoleRequirement.repo_url_to_role_name

# Generated at 2022-06-21 01:19:53.454443
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = "https://github.com/xzhih/ansible-elasticsearch.git"
    scm = 'git'
    name = None
    version = 'HEAD'
    role = RoleRequirement().scm_archive_role(src, scm, name, version)
    assert isinstance(role, dict)
    assert role['name'] == 'ansible-elasticsearch'
    assert role['src'] == 'https://github.com/xzhih/ansible-elasticsearch.git'
    assert role['scm'] == 'git'
    assert role['version'] == 'HEAD'


# Generated at 2022-06-21 01:19:58.128696
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    assert RoleRequirement.repo_url_to_role_name('http://foo.com/bar.git') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('https://foo.com/bar.git') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('git://foo.com/bar.git') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('ssh://foo.com/bar.git') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('git@foo.com:bar.git') == 'bar'

    assert RoleRequirement.repo_url_to_role_name('foo.com/bar.git') == 'foo.com/bar'
    assert RoleRequirement

# Generated at 2022-06-21 01:20:16.709354
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = 'git+https://github.com/ansible/ansible-examples.git'
    (foo, path) = RoleRequirement.scm_archive_role(src, scm='git', version='dc1f4bc9e9e0b1edf93cff51e2cfc8b7a554e02a')
    assert foo == 'ansible-examples'
    assert path == 'ansible-examples-dc1f4bc9e9e0b1edf93cff51e2cfc8b7a554e02a'

# Generated at 2022-06-21 01:20:26.469288
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.galaxy.role import Role
    from ansible.utils.path import get_tmp_path

    tmp_dir = get_tmp_path(subdir='test_RoleRequirement_scm_archive_role')
    display.display(tmp_dir)

    src = 'https://github.com/ansible/ansible-examples.git'
    role_path = RoleRequirement.scm_archive_role(src=src, scm='git', name='ansible-examples', keep_scm_meta=False)

    desired_role = Role('ansible-examples', galaxy='https://galaxy.ansible.com/api/', github_user='ansible', github_repo='ansible-examples', src='/home/username/.ansible/roles/ansible-examples')

    assert role

# Generated at 2022-06-21 01:20:38.165913
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    try:
        RoleRequirement.role_yaml_parse("role,version,name" )
    except AnsibleError:
        pass
    else:
        raise AssertionError("Expected an Ansible error")

    assert RoleRequirement.role_yaml_parse("role-name") == dict(name="role-name",src="role-name",version="",scm=None)
    assert RoleRequirement.role_yaml_parse("src,version") == dict(name=None,src="src",version="version",scm=None)
    assert RoleRequirement.role_yaml_parse("src,version,name") == dict(name="name",src="src",version="version",scm=None)

# Generated at 2022-06-21 01:20:38.656902
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    pass

# Generated at 2022-06-21 01:20:50.041896
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git') == {'name': 'repo', 'scm': None, 'src': 'http://git.example.com/repos/repo.git', 'version': ''}
    assert RoleRequirement.role_yaml_parse('git+http://git.example.com/repos/repo.git') == {'name': 'repo', 'scm': 'git', 'src': 'http://git.example.com/repos/repo.git', 'version': ''}

# Generated at 2022-06-21 01:21:01.282597
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.six import BytesIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.display import Display

    src = "git+https://github.com/ansible/ansible-examples.git"
    scm = 'git'
    name = None
    version = 'HEAD'
    keep_scm_meta = False

    test_path = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)

# Generated at 2022-06-21 01:21:08.562776
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:21:20.123867
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.release import __version__
    from ansible.galaxy import Galaxy
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    import os

    galaxy = Galaxy()
    output = RoleRequirement.scm_archive_role('https://github.com/geerlingguy/ansible-role-mysql.git', 'git', version='0.3.3')
    assert(os.path.exists(output))

    output = RoleRequirement.scm_archive_role('https://github.com/geerlingguy/ansible-role-mysql.git', 'git', version='0.3.3', keep_scm_meta=True)

# Generated at 2022-06-21 01:21:28.518077
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    from ansible.module_utils.six import string_types


# Generated at 2022-06-21 01:21:40.036586
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:22:17.486101
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,test') == 'repo'

# Generated at 2022-06-21 01:22:29.138866
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # test new style
    assert RoleRequirement.role_yaml_parse(dict(scm='git', src='https://github.com/foo/bar.git')) == dict(name='bar', scm='git', src='https://github.com/foo/bar.git', version='')
    assert RoleRequirement.role_yaml_parse(dict(scm='git', src='https://github.com/foo/bar.git', version='v4.0')) == dict(name='bar', scm='git', src='https://github.com/foo/bar.git', version='v4.0')

# Generated at 2022-06-21 01:22:39.765370
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import shutil
    import tempfile


# Generated at 2022-06-21 01:22:46.062096
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    path = '/home/ansible/galaxy/roles/'
    print()
    print('Original role name: role1, version: v1, name: none')
    print('Test result: ', role_requirement.role_yaml_parse('role1,v1'))
    print('Expected: ', {'name': 'role1', 'src': 'role1', 'scm': None, 'version': 'v1'})
    print()
    print('Original role name: role1, version: v1, name: name1')
    print('Test result: ', role_requirement.role_yaml_parse('role1,v1,name1'))

# Generated at 2022-06-21 01:22:53.307711
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = "git+https://github.com/bertvv/ansible-role-container.git"
    scm = 'git'
    name = "ansible-role-container"
    version = 'v1.1'
    keep_scm_meta = False

    RoleRequirement.scm_archive_role(src=src, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta)


# Generated at 2022-06-21 01:22:59.141534
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    src="git+https://github.com/robertdebock/ansible-lint.git"
    scm='git'
    name='ansible-lint'
    version='HEAD'
    keep_scm_meta=False
    RoleRequirement.scm_archive_role(src, scm, name, version,  keep_scm_meta)

# Generated at 2022-06-21 01:23:06.587481
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    url1 = 'https://github.com/geerlingguy/ansible-role-security'
    url2 = 'https://github.com/geerlingguy/ansible-role-security.git'
    url3 = 'https://github.com/geerlingguy/ansible-role-security.tar.gz'
    url4 = 'https://github.com/geerlingguy/ansible-role-security-1.2.3.tar.gz'
    url5 = 'https://github.com/geerlingguy/ansible-role-security.git,1.2.3'
    url6 = 'https://github.com/geerlingguy/ansible-role-security.git,1.2.3,name'

# Generated at 2022-06-21 01:23:15.932785
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import shutil

    rolename = 'pupet-role'
    rolesdir = '/tmp/roles'

    r = RoleRequirement()
    from ansible.utils.path import makedirs_safe
    makedirs_safe(rolesdir)
    r.scm_archive_role('https://github.com/jtyr/puppet-role.git',
                       scm='git',
                       name=rolename,
                       version='HEAD',
                       dest=rolesdir)

    assert os.path.exists(os.path.join(rolesdir, rolename))
    shutil.rmtree(rolesdir)


# Generated at 2022-06-21 01:23:25.298534
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement.role_yaml_parse('some.valid.role,1.0,role_name') == {'name': 'role_name', 'src': 'some.valid.role', 'scm': None, 'version': '1.0'}
    assert RoleRequirement.role_yaml_parse("git+https://github.com/user/repo.git,1.0,role_name") == {'name': 'role_name', 'src': 'https://github.com/user/repo.git', 'scm': 'git', 'version': '1.0'}

# Generated at 2022-06-21 01:23:36.318908
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    import tempfile

    test_dir = tempfile.mkdtemp(dir=None, prefix='test_RoleRequirement_scm_archive_role-')

    local_test_repo = 'file://' + test_dir
    local_test_repo_name = RoleRequirement.repo_url_to_role_name(local_test_repo)

    assert(local_test_repo_name == 'test_RoleRequirement_scm_archive_role')

    local_test_repo_url = 'https://github.com/ansible/ansible-examples.git'
    local_test_repo_url_role_name = RoleRequirement.repo_url_to_role_name(local_test_repo_url)
