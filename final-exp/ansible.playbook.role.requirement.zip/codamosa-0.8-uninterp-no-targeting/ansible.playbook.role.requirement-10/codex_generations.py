

# Generated at 2022-06-21 01:14:18.257163
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    req = RoleRequirement()
    assert req is not None

# Generated at 2022-06-21 01:14:19.328766
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    res = RoleRequirement()
    assert res is not None

# Generated at 2022-06-21 01:14:28.871751
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    from ansible.module_utils.six import BytesIO

    # Test for keep_scm_meta=True
    meta = RoleRequirement.scm_archive_role("git+https://github.com/geerlingguy/ansible-role-apache.git@1.9.9", keep_scm_meta=True)
    assert meta["name"] == "geerlingguy.apache"
    assert meta["version"] == "1.9.9"

    # Test for keep_scm_meta=False
    meta = RoleRequirement.scm_archive_role("git+https://github.com/geerlingguy/ansible-role-apache.git@1.9.9")
    assert meta["name"] == "geerlingguy.apache"
    assert meta["version"] == None

    # Test for a private repo

# Generated at 2022-06-21 01:14:31.797658
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test the role_yaml_parse method of the RoleRequirement class

    # given,
    role_requirement = RoleRequirement()
    role = "geerlingguy.java"

    # when,
    actual = role_requirement.role_yaml_parse(role)

    # then,
    expected = dict(name='geerlingguy.java', scm=None, src='geerlingguy.java', version='')
    assert actual == expected


# Generated at 2022-06-21 01:14:39.856509
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('role1') == {'name': 'role1', 'src': 'role1', 'version': None, 'scm': None}
    assert RoleRequirement.role_yaml_parse('role1,1.0') == {'name': 'role1', 'src': 'role1', 'version': '1.0', 'scm': None}
    assert RoleRequirement.role_yaml_parse('role1,1.0,other_name') == {'name': 'other_name', 'src': 'role1', 'version': '1.0', 'scm': None}

# Generated at 2022-06-21 01:14:41.516991
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    rr = RoleRequirement()
    assert rr

# Generated at 2022-06-21 01:14:49.913389
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.playbook.play_context import PlayContext
    from io import StringIO

    role_vars = dict(connection='local')
    play_context = PlayContext()
    task_vars = dict(omg_a_dict='dict', some_file=StringIO())
    path_to_role = '/some/path/roles/test'
    role = RoleRequirement.load(path_to_role=path_to_role, role_vars=role_vars, play_context=play_context, task_vars=task_vars)
    assert role.name == 'test'
    assert role.task_vars == task_vars
    assert role.role_vars == role_vars
    assert role.play_context == play_context
    assert role.metadata is not None
    assert role

# Generated at 2022-06-21 01:15:01.829400
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test case 1
    role = 'geerlingguy.apache'
    res = RoleRequirement.role_yaml_parse(role)
    assert res['name'] == 'geerlingguy.apache'
    assert res['src'] == 'geerlingguy.apache'
    assert res['scm'] == None
    assert res['version'] == None

    # Test case 2
    role = 'git+https://github.com/username/my-test-role.git'
    res = RoleRequirement.role_yaml_parse(role)
    assert res['name'] == 'my-test-role'
    assert res['src'] == 'https://github.com/username/my-test-role.git'
    assert res['scm'] == 'git'
    assert res['version'] == None

    # Test case 3


# Generated at 2022-06-21 01:15:13.066947
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_text

    import tarfile
    from ansible.module_utils.common._collections_compat import Mapping

    def _assert_role_scm_type(tf, info):
        assert tf.extractfile(info).read().rstrip() == b'HEAD'
        assert info.name == 'HEAD'

    def _assert_role_scm_meta(tf, info_name):
        info = tf.getmember(info_name)
        assert info_name == info.name
        assert info.isdir()
        assert info.mtime == info.atime == info.ctime == 0

        splitted_info_name = info_name.split('/')

# Generated at 2022-06-21 01:15:24.521886
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """Test case for RoleRequirement class."""

    import logging
    import unittest
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types

    class RoleRequirementTestCase(unittest.TestCase):
        """Unit test for RoleRequirement class."""

        def test_role_yaml_parse(self):
            """Test for role_yaml_parse function of class RoleRequirement."""

            # Testcase: role is string type
            role_string = "ansible-role-test"
            role = RoleRequirement.role_yaml_parse(role_string)
            self.assertEqual(role["name"], "ansible-role-test")
            self.assertEqual(role["scm"], None)

# Generated at 2022-06-21 01:15:39.521273
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:15:50.928747
# Unit test for method scm_archive_role of class RoleRequirement

# Generated at 2022-06-21 01:15:59.920253
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:16:11.099223
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # Normal usage
    assert RoleRequirement.role_yaml_parse("username.role_name") == \
        {'name': 'role_name', 'src': 'username.role_name', 'scm': None, 'version': ''}

    # Normal usage with a non-default role name
    assert RoleRequirement.role_yaml_parse("username.role_name,name") == \
        {'name': 'name', 'src': 'username.role_name', 'scm': None, 'version': ''}

    # Normal usage with a non-default version
    assert RoleRequirement.role_yaml_parse("username.role_name,version") == \
        {'name': 'role_name', 'src': 'username.role_name', 'scm': None, 'version': 'version'}

    # Normal usage with

# Generated at 2022-06-21 01:16:21.606438
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse({
        'name': 'MYROLE',
        'role': 'ABSOLUTEROLE',
    }) == {
        'name': 'ABSOLUTEROLE',
        'role': 'ABSOLUTEROLE'
    }

    assert RoleRequirement.role_yaml_parse({
        'name': 'MYROLE',
        'role': 'src: ABSOLUTEROLE',
    }) == {
        'name': 'ABSOLUTEROLE',
        'src': 'ABSOLUTEROLE',
    }


# Generated at 2022-06-21 01:16:29.778555
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    assert RoleRequirement.scm_archive_role("git@github.com:ansible/ansible-modules-core.git", "git", "ansible.modules_core", "HEAD", False)
    assert RoleRequirement.scm_archive_role("git@github.com:ansible/ansible-modules-core.git", "git", "ansible.modules_core", "HEAD", True)
    assert RoleRequirement.scm_archive_role("git@github.com:ansible/ansible-modules-core.git", "git", "ansible.modules_core", "origin/devel", False)
    assert RoleRequirement.scm_archive_role("git@github.com:ansible/ansible-modules-core.git", "git", "ansible.modules_core", "origin/devel", True)
   

# Generated at 2022-06-21 01:16:32.090947
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    r = RoleRequirement()
    assert isinstance(r,RoleRequirement)


# Generated at 2022-06-21 01:16:35.538000
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    requirement = RoleRequirement()
    assert requirement


#--------------------------------------
# Moved from test_galaxy.py in order to be called
# as test_mazer.py is executed with nosetests
#--------------------------------------


# Generated at 2022-06-21 01:16:43.785721
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.utils.path import makedirs_safe
    from ansible.utils.display import Display
    display = Display()

    test_bogus_src = "bogus,0.1.1,test"
    test_yaml_parse_args = RoleRequirement.role_yaml_parse(test_bogus_src)
    assert test_yaml_parse_args == {'name': 'test', 'scm': 'bogus', 'src': '0.1.1', 'version': None}

    test_bogus_src = "bogus,0.1.1,test,extra"

# Generated at 2022-06-21 01:16:54.907446
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # testing with a simple url
    url = "http://git.example.com/repos/repo.git"
    assert RoleRequirement.repo_url_to_role_name(url) == "repo"
    # testing with a complex url
    url = "https://github.com/geerlingguy/ansible-role-apache.git"
    assert RoleRequirement.repo_url_to_role_name(url) == "ansible-role-apache"
    # testing with a complex url and version
    url = "https://github.com/geerlingguy/ansible-role-apache,1.4.4.tar.gz"
    assert RoleRequirement.repo_url_to_role_name(url) == "ansible-role-apache"
    # testing with a complex url, version and name

# Generated at 2022-06-21 01:17:14.152757
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    assert isinstance(role_requirement, RoleRequirement)


# Generated at 2022-06-21 01:17:23.923723
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    role = RoleRequirement.scm_archive_role('https://github.com/username/awesome-role.git')
    assert role['name'] == 'awesome-role'
    assert role['version'] == 'HEAD'
    assert role['src'] == 'https://github.com/username/awesome-role.git'
    assert role['scm'] == 'git'

    role = RoleRequirement.scm_archive_role('username.awesome-role')
    assert role['name'] == 'awesome-role'
    assert role['version'] == 'HEAD'
    assert role['src'] == 'username.awesome-role'
    assert role['scm'] is None

    role = RoleRequirement.scm_archive_role('username.awesome-role,v123')

# Generated at 2022-06-21 01:17:35.992205
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    role_requirement = RoleRequirement()

    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("https://git.example.com/repos/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("https://user@git.example.com/repos/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git#egg=repo") == "repo"

# Generated at 2022-06-21 01:17:46.557150
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test if the method works as expected.
    # It should accept an object of the form specified in the docstring,
    # and either return the correct object, or raise an error
    expected = dict(name="ansible", src="http://github.com/ansible/ansible", scm="git", version=None)
    assert RoleRequirement.role_yaml_parse(expected) == expected
    expected = dict(name="ansible", src="https://github.com/ansible/ansible", scm="git", version=None)
    assert RoleRequirement.role_yaml_parse(expected) == expected
    expected = dict(name="ansible", src="git+git://github.com/ansible/ansible", scm="git", version=None)
    assert RoleRequirement.role_yaml_parse(expected) == expected

# Generated at 2022-06-21 01:17:47.286774
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    requirement = RoleRequirement()
    assert requirement is not None

# Generated at 2022-06-21 01:17:56.228425
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.urls import download_file
    from ansible.module_utils.six.moves.urllib.parse import urlparse, parse_qs, unquote
    import tempfile
    import os
    import shutil

    # Test function with valid scm source URLs

# Generated at 2022-06-21 01:18:07.168782
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    role = RoleRequirement.scm_archive_role(
        src="http://github.com/ansible/ansible-examples.git",
        scm="git",
        version='HEAD',
        keep_scm_meta=False
    )

    assert role == {
        'name': 'ansible-examples',
        'scm': 'git',
        'src': 'http://github.com/ansible/ansible-examples.git',
        'version': 'HEAD'
    }

    role = RoleRequirement.scm_archive_role(
        src="git+http://github.com/ansible/ansible-examples.git",
        scm="git",
        version='HEAD',
        keep_scm_meta=False
    )


# Generated at 2022-06-21 01:18:15.511474
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert RoleRequirement.role_yaml_parse('my_src_name') == dict(name='my_src_name', src='my_src_name', scm=None, version='')
    assert RoleRequirement.role_yaml_parse('my_src_name,1.2.3') == dict(name='my_src_name', src='my_src_name', scm=None, version='1.2.3')
    assert RoleRequirement.role_yaml_parse('my_src_name,my_name') == dict(name='my_name', src='my_src_name', scm=None, version='')

# Generated at 2022-06-21 01:18:18.929591
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    role_requirement = RoleRequirement()
    assert role_requirement
    assert isinstance(role_requirement, RoleRequirement)


# Unit tests for method role_yaml_parse()

# Generated at 2022-06-21 01:18:23.917777
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # call with http://git.example.com/repos/repo.git"
    src = 'http://git.example.com/repos/repo.git'
    res = RoleRequirement.repo_url_to_role_name(src)
    assert res == 'repo'

# Generated at 2022-06-21 01:18:52.103975
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    result = RoleRequirement.role_yaml_parse("A,1.0")
    assert result == {u'src': u'A', u'name': u'A', u'scm': None, u'version': u'1.0'}
    result = RoleRequirement.role_yaml_parse("B,1.0,C")
    assert result == {u'src': u'B', u'name': u'C', u'scm': None, u'version': u'1.0'}
    result = RoleRequirement.role_yaml_parse("git+git://git.example.com/repos/repo.git")

# Generated at 2022-06-21 01:18:59.984134
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v2.2.2.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v2.2.2") == "repo"

# Generated at 2022-06-21 01:19:11.891941
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_yaml = {}
    role_yaml["role"] = "chrismeyersfsu.zabbix-agent"
    role_yaml["version"] = "1.0.0"

    role = RoleRequirement.role_yaml_parse(role_yaml)
    assert role["name"] == "role.chrismeyersfsu.zabbix-agent"
    assert role["scm"] == None
    assert role["src"] == "chrismeyersfsu.zabbix-agent"
    assert role["version"] == "1.0.0"

    role_yaml = {}
    role_yaml["github.com"] = "chrismeyersfsu/zabbix-agent"
    role_yaml["version"] = "1.0.0"

    role = Role

# Generated at 2022-06-21 01:19:20.950080
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role = 'http://git.example.com/repos/repo.git'
    assert RoleRequirement.repo_url_to_role_name(role) == 'repo'
    role = 'git+git@git.example.com/repos/repo.git'
    assert RoleRequirement.repo_url_to_role_name(role) == 'repo'
    role = 'git+git@git.example.com/repos/repo.tar.gz'
    assert RoleRequirement.repo_url_to_role_name(role) == 'repo'
    role = 'git+git@git.example.com/repos/repo.tar.gz,v0.0.1'

# Generated at 2022-06-21 01:19:31.903293
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('name,scm+https://github.com/someuser/somerepo.git,1.0.0') == {'name': 'name', 'src': 'https://github.com/someuser/somerepo.git', 'scm': 'scm', 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('https://github.com/someuser/somerepo.git,1.0.0') == {'name': 'somerepo', 'src': 'https://github.com/someuser/somerepo.git', 'scm': None, 'version': '1.0.0'}

# Generated at 2022-06-21 01:19:34.065837
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    res = RoleRequirement.role_yaml_parse("geerlingguy.apache,1.9.1")
    assert res.get("name") == "geerlingguy.apache"
    assert res.get("scm") is None
    assert res.get("src") == "geerlingguy.apache"
    assert res.get("version") == "1.9.1"

# Generated at 2022-06-21 01:19:43.653362
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    src = "https://github.com/ansible/ansible-examples.git"
    scm = 'git'
    version = '1.0'
    name = 'ansible-examples'

    # Test for the normal case
    expected = {
        'name': name,
        'path': 'ansible-examples',
    }
    actual = RoleRequirement.scm_archive_role(src, scm, name, version)
    assert actual == expected, "actual: %s, expected: %s" % (actual, expected)

    # Test for the version is None case
    version = None
    expected = {
        'name': name,
        'path': 'ansible-examples'
    }
    actual = RoleRequirement.scm_archive_role(src, scm, name, version)


# Generated at 2022-06-21 01:19:55.179235
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:20:05.570280
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert 'repo' == RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    assert 'repo' == RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git?param=value")
    assert 'gitlab.example.com:7999' == RoleRequirement.repo_url_to_role_name("ssh://git@gitlab.example.com:7999/repos/repo.git")
    assert 'repo-v1.0' == RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo-v1.0.git")
    assert 'repo' == RoleRequirement.repo_url_

# Generated at 2022-06-21 01:20:12.907918
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # name only
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    # name in parenthesis
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    # name in parenthesis, version in format v1.0
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    # name in parenthesis, version in format 1.0

# Generated at 2022-06-21 01:20:53.798367
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    role = RoleRequirement()
    assert role

    role = RoleRequirement.role_yaml_parse("role_name")
    assert role["name"] == "role_name"
    assert role["version"] == ""
    assert role["scm"] == None
    assert role["src"] == "role_name"

    role = RoleRequirement.role_yaml_parse("role_name,v1")
    assert role["name"] == "role_name"
    assert role["version"] == "v1"
    assert role["scm"] == None
    assert role["src"] == "role_name"

    role = RoleRequirement.role_yaml_parse("role_name,v1,another_name")
    assert role["name"] == "role_name"
    assert role["version"] == "v1"

# Generated at 2022-06-21 01:20:56.022459
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
  roleReq = RoleRequirement()
  assert roleReq.__class__.__name__ == 'RoleRequirement'

# Generated at 2022-06-21 01:21:00.319830
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # given
    repo_url = 'git@git.example.com:repo.git'

    # when
    result = RoleRequirement.repo_url_to_role_name(repo_url)

    # then
    assert result == 'repo'



# Generated at 2022-06-21 01:21:08.073777
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    cwd = os.getcwd()
    os.mkdir('temp_test_Role')
    os.chdir('temp_test_Role')

    # Test 1. Invalid parameters
    try:
        src = None
        scm = 'git'
        name = 'role_name'
        version = '1.2.3'
        RoleRequirement.scm_archive_role(src, scm, name, version)
        assert False
    except:
        assert True

    # Test 2. git source

# Generated at 2022-06-21 01:21:19.500291
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:21:28.269297
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    spec1 = { 'name': 'amosbatto.my_role', 'src': 'amosbatto.my_role', 'version': '1.0' }
    spec2 = { 'name': 'amosbatto.my_role', 'src': 'git+git://git.example.com/my_role', 'version': '' }
    spec3 = { 'name': 'amosbatto.my_role', 'src': 'http://git.example.com/my_role', 'version': '' }
    spec4 = { 'name': 'amosbatto.my_role', 'src': 'https://git.example.com/my_role', 'version': '' }

# Generated at 2022-06-21 01:21:40.037985
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    import tempfile
    import os
    from shutil import rmtree
    from ansible.utils.display import Display
    from ansible.utils.path import makedirs_safe
    from ansible.module_utils.six import PY2, iteritems

    display = Display()

    archive_path = None
    temp_dir = None

# Generated at 2022-06-21 01:21:47.972136
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    display.display("Running test_RoleRequirement_repo_url_to_role_name")
    repo_url = "http://git.example.com/repos/repo.git"
    assert RoleRequirement.repo_url_to_role_name(repo_url) == "repo"
    repo_url = "http://git.example.com/repos/repo.tar.gz"
    assert RoleRequirement.repo_url_to_role_name(repo_url) == "repo"
    repo_url = "http://git.example.com/repos/repo,master.tar.gz,bla"
    assert RoleRequirement.repo_url_to_role_name(repo_url) == "repo"

# Generated at 2022-06-21 01:21:58.550415
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("https://github.com/ansible/ansible-modules-extras.git") == "ansible-modules-extras"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/Infoblox-CTP/ansible-extra-modules.git") == "ansible-extra-modules"
    assert RoleRequirement.repo_url_to_role_name("ansible-modules-extras") == "ansible-modules-extras"
    assert RoleRequirement.repo_url_to_role_name("user@hostname:user/repository.git") == "repository"

# Generated at 2022-06-21 01:22:06.293775
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()