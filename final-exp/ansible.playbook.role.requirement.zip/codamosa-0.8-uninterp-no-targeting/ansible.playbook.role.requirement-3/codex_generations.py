

# Generated at 2022-06-21 01:14:20.276268
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os
    import tempfile
    import shutil
    import json

    temp_dir = tempfile.mkdtemp()
    cur_dir = os.getcwd()
    galaxy_dir = os.path.join(temp_dir, 'galaxy')

    os.chdir(temp_dir)
    # Test of archive a git repo with commit hash as version
    commit_hash = '5e5edc3b6ac9e622272d8f1ce624fda6f444441f'
    src = 'https://github.com/ansible/ansible-examples.git'
    role_def = RoleRequirement.scm_archive_role(src, scm='git', version=commit_hash, name='ansible-examples')
    assert role_def is not None
    assert 'path'

# Generated at 2022-06-21 01:14:25.612187
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    print(RoleRequirement.scm_archive_role('https://github.com/verhagen/ansible-role-ipa.git', 'git', 'ipa', 'master'))
    print(RoleRequirement.scm_archive_role('https://github.com/verhagen/ansible-role-ipa.git', 'git', 'ipa', 'master', True))


# Generated at 2022-06-21 01:14:30.145364
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Test the constructor of RoleRequirement class
    yaml_string = "trellis-ansible-galaxy-role"
    role = RoleRequirement.role_yaml_parse(yaml_string)
    assert role["name"] == "trellis-ansible-galaxy-role"
    assert role["src"] is None
    assert role["scm"] is None
    assert role["version"] is None

    yaml_string = "trellis-ansible-galaxy-role,master"
    role = RoleRequirement.role_yaml_parse(yaml_string)
    assert role["name"] == "trellis-ansible-galaxy-role"
    assert role["src"] is None
    assert role["scm"] is None
    assert role["version"] is "master"


# Generated at 2022-06-21 01:14:34.711232
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirements = RoleRequirement()
    assert role_requirements.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role_requirements.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0.0") == "repo"
    assert role_requirements.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0.0,foo") == "repo"
    assert role_requirements.repo_url_to_role_name("https://github.com/location/name.git") == "name"
    assert role_requirements.repo_url_to_role_name

# Generated at 2022-06-21 01:14:41.718004
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    repo_url = "https://github.com/monsieurbon/ansible-role-elasticsearch.git"
    role_name = "ansible-role-elasticsearch"
    assert role_name == RoleRequirement.repo_url_to_role_name(repo_url)

# Generated at 2022-06-21 01:14:50.064189
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # Tests for RoleRequirement.scm_archive_role method
    role_src = "https://github.com/ansible/ansible-examples.git"
    role_scm = "git"
    role_name = None
    role_version = "HEAD"
    role_keep_scm_meta = False

    # Test to ensure that the expected dictionary is returned
    expectedres = {
        'name': 'ansible-examples',
        'src': 'ansible-examples',
        'version': 'HEAD'
    }

    res = RoleRequirement.scm_archive_role(role_src, role_scm, role_name, role_version, role_keep_scm_meta)
    assert isinstance(res, dict)
    assert res['name'] == expectedres['name']

# Generated at 2022-06-21 01:15:01.965154
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = 'https://github.com/username/role.git'
    scm = 'git'
    name = 'role'
    version = 'HEAD'
    keep_scm_meta = False

    actual = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)


# Generated at 2022-06-21 01:15:13.233974
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    import os
    import tempfile

    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 01:15:24.861637
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """
    Verify that the role_yaml_parse method of RoleRequirement properly parses the strings
    """

    # Test strings (role as string, correct parsed role)

# Generated at 2022-06-21 01:15:28.530399
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    src = ''
    scm = ''
    name = ''
    version = ''
    keep_scm_meta = ''

    res = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)
    #assert res ==

# Generated at 2022-06-21 01:15:40.617832
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile, shutil, os
    from ansible.module_utils._text import to_bytes

    # Clone a git repository to a temporary directory
    my_path = tempfile.mkdtemp()
    src = 'https://github.com/ansible/ansible-examples.git'
    if not os.path.isdir(os.path.join(my_path, 'ansible-examples')):
        scm_archive_resource(src, my_path)
    ansible_examples_path = os.path.join(my_path, 'ansible-examples')

    # Use the role name as role name
    (my_path, role_name) = tempfile.mkstemp()
    os.close(my_path)

# Generated at 2022-06-21 01:15:47.384352
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    (rc, out_file) = RoleRequirement.scm_archive_role('https://github.com/geerlingguy/ansible-role-apache/archive/master.tar.gz')
    assert rc == 0, "scm_archive_role() returned non-zero Exit Code."
    assert out_file, "scm_archive_role() did not return file name of archive."
# End of Unit test for method scm_archive_role


# Generated at 2022-06-21 01:15:57.485852
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    requirement = RoleRequirement()
    role = "galaxy.role,1.0,main"
    role_dict = requirement.role_yaml_parse(role)
    assert len(role_dict) == 4
    assert role_dict["name"] == "main"
    assert role_dict["scm"] == "galaxy"
    assert role_dict["src"] == "role"
    assert role_dict["version"] == "1.0"
    role = "galaxy.role,1.0"
    role_dict = requirement.role_yaml_parse(role)
    assert len(role_dict) == 4
    assert role_dict["name"] == "role"
    assert role_dict["scm"] == "galaxy"
    assert role_dict["src"] == "role"
    assert role_dict["version"]

# Generated at 2022-06-21 01:16:09.417806
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    assert RoleRequirement.scm_archive_role("git+https://github.com/ansible/ansible-examples.git", "git", "ansible-examples", "HEAD", True) == \
        {'clone_args': ['--branch', 'HEAD'], 'keep_scm_meta': True, 'scm': 'git',
         'src': 'https://github.com/ansible/ansible-examples.git', 'version': 'HEAD'}

# Generated at 2022-06-21 01:16:19.894859
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    ''' Test scm_archive_role method of class RoleRequirement '''

    # Test 1: This should return a tar.gz archive of the latest version of the ansible-role-test role
    # from the ansible-role-test repo on github.
    src = 'git+https://github.com/kewlfft/ansible-role-test'
    filename = RoleRequirement.scm_archive_role(src, scm='git')

    # Check if the file exists
    import os.path
    assert(os.path.isfile(filename))

    # Check if the file is a tar.gz file
    import tarfile
    tar = tarfile.open(filename, 'r:gz')
    assert(tar)
    tar.close()

    # Check if the role name is in the tar file
    tar = tarfile

# Generated at 2022-06-21 01:16:28.885808
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    rr = RoleRequirement()

    # test a simple url
    url_in = "http://git.example.com/repos/repo.git"
    name_out = "repo"
    name_in = rr.repo_url_to_role_name(url_in)
    assert name_in == name_out

    # test a valid url but with a space at the end
    url_in = "http://git.example.com/repos/repo.git "
    name_out = "repo"
    name_in = rr.repo_url_to_role_name(url_in)
    assert name_in == name_out

    # test a valid url but with a space at the beginning

# Generated at 2022-06-21 01:16:31.549425
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"

# Generated at 2022-06-21 01:16:41.669836
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/roles/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('git@git.example.com:roles/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/roles/repo.tar.gz') == 'repo'
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/roles/repo,v1.0') == 'repo'
    assert role_requirement.repo_url_to_

# Generated at 2022-06-21 01:16:48.997701
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = "git+https://github.com/geerlingguy/ansible-role-java.git"
    scm = 'git'
    name = None
    version = 'HEAD'
    keep_scm_meta = True
    ret = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)
    print("\nret:\n"+ret)

test_RoleRequirement_scm_archive_role()

# Generated at 2022-06-21 01:16:58.281511
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    import tempfile
    # set up argv
    argv = ['ansible-galaxy', 'install', '-r', 'test_requirements.yml', '--ignore-errors']
    # create tempfile object
    tfile = tempfile.NamedTemporaryFile()
    # set attributes of tempfile object
    tfile.mode, tfile.name = 'w', '/tmp/requirements.yml'
    # write content to tempfile object
    tfile.write('''---
- src: git+https://github.com/my_github_username/my_role
  name: my_role
  version: master
''')
    tfile.flush()
    # run scm_archive_role method

# Generated at 2022-06-21 01:17:12.337937
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    role = RoleRequirement.scm_archive_role(src="https://github.com/grigorievich/test_roles.git",
                                            scm="git",
                                            name=None,
                                            version="HEAD",
                                            keep_scm_meta=True)
    assert role is not None
    assert role.has_directory() == True
    assert role.has_file() == False
    assert role.get_name() == "test_roles"
    assert role.get_version() == "HEAD"

# Generated at 2022-06-21 01:17:14.543097
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    try:
        test_RoleRequirement_1()
        test_RoleRequirement_2()
    except:
        assert False, 'test_RoleRequirement() failed'


# Generated at 2022-06-21 01:17:20.763552
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:17:32.370208
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test of role_yaml_parse method for old-style role dependency string
    # which is a string without any key
    me = RoleRequirement()
    old_style = me.role_yaml_parse('users,1.0')
    assert old_style['name'] == 'users'
    assert old_style['version'] == '1.0'
    assert old_style['src'] == 'users'
    assert old_style['scm'] is None

    # test of role_yaml_parse method for new-style role dependency dictionary
    # which include 3 keys which is name, version and src
    requirement_dictionary = dict(
        name='users',
        version='1.0',
        src='https://github.com/geerlingguy/ansible-role-users.git',
    )

# Generated at 2022-06-21 01:17:41.602307
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    from ansible.errors import AnsibleError
    from ansible.utils.display import Display
    from ansible.utils.path import makedirs_safe
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.vault import VaultLib
    import os

    display = Display()

    vault = VaultLib([])
    vault_secret = vault.encrypt(AnsibleUnsafeText('ansible_test'))
    vault_secret_file = '.test_vault_pass'
    with open(vault_secret_file, 'w') as out:
        out.write(AnsibleUnsafeText(vault_secret))

    src = 'https://github.com/bertvv/ansible-role-bind'
    name = 'ansible-role-bind'

# Generated at 2022-06-21 01:17:50.900539
# Unit test for method scm_archive_role of class RoleRequirement

# Generated at 2022-06-21 01:18:01.956124
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # parse role name only
    role = 'apache'
    role_result = RoleRequirement.role_yaml_parse(role)
    assert role_result['name'] == 'apache'
    assert role_result['scm'] is None
    assert role_result['src'] == 'apache'
    assert role_result['version'] is None

    # parse role name with version
    role = 'apache,1.0'
    role_result = RoleRequirement.role_yaml_parse(role)
    assert role_result['name'] == 'apache'
    assert role_result['scm'] is None
    assert role_result['src'] == 'apache'
    assert role_result['version'] == '1.0'

    # parse role name with src url

# Generated at 2022-06-21 01:18:03.084405
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
  role = RoleRequirement()

# Generated at 2022-06-21 01:18:12.835935
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    class TestParams:
        def __init__(self):
            self.keep_scm_meta = False
            self.directory = "./test_dir"
            self.roles_path = ["./test_dir"]
            self.role_path = None
            self.path_relative = "test_dir"
            self.tar_file = None
            self.name = None
            self.allow_duplicates = False
            self.version = None
            self.force = False
            self.validate_certs = True
            self.ignore_errors = False
            self.role_file = None
            self.no_deps = False

    test_params = TestParams()

    role_requirement = RoleRequirement()

    test_name = "test_role_name"

# Generated at 2022-06-21 01:18:24.989728
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()

    # single line format
    # FIXME: This test depends on the CWD; it should not.
    assert role.role_yaml_parse(role='test') == {'name': 'test', 'src': 'test', 'scm': None, 'version': ''}
    assert role.role_yaml_parse(role='git+https://github.com/ansible/ansible-examples,origin/devel') == {'name': 'ansible-examples', 'src': 'https://github.com/ansible/ansible-examples', 'scm': 'git', 'version': 'origin/devel'}

# Generated at 2022-06-21 01:18:41.763588
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    print ('\n' + ('=' * 70))
    print ('Unit test RoleRequirement.repo_url_to_role_name()')

# Generated at 2022-06-21 01:18:53.575735
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import sys
    from ansible.utils.color import stringc

    # Testing method role_yaml_parse of class RoleRequirement
    #
    # Args:
    #    role (str, dict): full role name or dictionary of role parameters
    #
    # Returns:
    #    dict: dictionary with role parameters
    #
    # Raises:
    #    AnsibleError: on invalid role name
    #

    test_role = { 'role': 'geerlingguy.nodejs' }
    result = dict(name='geerlingguy.nodejs', src='geerlingguy.nodejs', scm=None, version='')
    ret = RoleRequirement.role_yaml_parse(test_role)

# Generated at 2022-06-21 01:19:01.898933
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    test_result = RoleRequirement.repo_url_to_role_name
    assert test_result("git@git.example.com:ansible-role-foo.git") == "ansible-role-foo"
    assert test_result("https://github.com/foo/foo-ansible-role.git") == "foo-ansible-role"
    assert test_result("git@git.example.com:foo/foo-ansible-role.git") == "foo-ansible-role"
    assert test_result("git@git.example.com:foo/bar/baz/foobar-ansible-role.git") == "foobar-ansible-role"

# Generated at 2022-06-21 01:19:14.124951
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:19:22.098802
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:19:27.478502
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    url = "https://github.com/picotrading/shopify-tasks"
    scm = 'git'
    name = None
    version = 'HEAD'
    keep_scm_meta = False

    role = RoleRequirement.scm_archive_role(url, scm, name, version, keep_scm_meta)

    assert isinstance(role, RoleRequirement)

# Generated at 2022-06-21 01:19:39.198114
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    ## Test case 1
    test_value={'name': 'galaxy.role', 'scm': None, 'src': 'git://github.com/user/galaxy.role.git', 'version': None}
    # This is an example of a role entry in requirements.yml file
    test_string="galaxy.role,user/galaxy.role.git,1.0.0"
    test_dict=RoleRequirement.role_yaml_parse(test_string)
    assert test_dict==test_value

    ## Test case 2
    test_value={'name': 'galaxy.role', 'scm': None, 'src': 'git://github.com/user/galaxy.role.git', 'version': '1.0.0'}
    # This is an example of a role entry in requirements.yml file


# Generated at 2022-06-21 01:19:40.231151
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    assert role

# Generated at 2022-06-21 01:19:51.340906
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print(RoleRequirement.role_yaml_parse("geerlingguy.apache"))
    print(RoleRequirement.role_yaml_parse("geerlingguy.apache,v1.9.9"))
    print(RoleRequirement.role_yaml_parse("geerlingguy.apache,v1.9.9,foo"))
    print(RoleRequirement.role_yaml_parse("git+https://github.com/username/ansible-role-foo.git"))
    print(RoleRequirement.role_yaml_parse("git+https://github.com/username/ansible-role-foo.git,bar"))
    print(RoleRequirement.role_yaml_parse("git+https://github.com/username/ansible-role-foo.git,bar,foo"))


# Generated at 2022-06-21 01:20:02.154841
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Good creation with both scm and name
    spec = dict(
        scm='git',
        src='https://github.com/ansible/ansible-examples',
        name='ansible-examples'
    )
    role = RoleRequirement(spec)
    assert role.get_name() == 'ansible-examples'
    assert role.get_role_name() == 'ansible-examples'

    # Good creation with only scm
    spec = dict(
        scm='git',
        src='https://github.com/ansible/ansible-examples'
    )
    role = RoleRequirement(spec)
    assert role.get_name() == 'ansible-examples'
    assert role.get_role_name() == 'ansible-examples'

    # Role name is extracted from

# Generated at 2022-06-21 01:20:22.404933
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    url = 'https://github.com/foo/bar'
    assert RoleRequirement.role_yaml_parse(url) == dict(name='bar', src=url, scm='git', version=None)

    url = 'git+https://github.com/foo/bar,baz'
    assert RoleRequirement.role_yaml_parse(url) == dict(name='baz', src=url, scm='git', version=None)

    url = 'bar,baz'
    assert RoleRequirement.role_yaml_parse(url) == dict(name='baz', src='bar', scm=None, version=None)

    url = 'bar'
    assert RoleRequirement.role_yaml_parse(url) == dict(name='bar', src='bar', scm=None, version=None)

   

# Generated at 2022-06-21 01:20:24.775338
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    actual = RoleRequirement.repo_url_to_role_name('https://github.com/bennojoy/nginx.git')
    assert actual == 'nginx'

# Generated at 2022-06-21 01:20:33.611283
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    src = 'git@server:jdoe/myrole.git'
    # src = 'https://github.com/jdoe/myrole.git'
    print(RoleRequirement.repo_url_to_role_name(src))

    print(RoleRequirement.role_yaml_parse('jdoe.myrole'))
    print(RoleRequirement.role_yaml_parse('jdoe.myrole,1.2.3'))
    print(RoleRequirement.role_yaml_parse('jdoe.myrole,1.2.3,myrole'))
    print(RoleRequirement.role_yaml_parse('jdoe.myrole,1.2.3,with special chars : &'))

# Generated at 2022-06-21 01:20:42.384963
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Display class for unit tests
    class DisplayUnitTest(object):
        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            print(msg)

    global display
    display = DisplayUnitTest()

    result = RoleRequirement.role_yaml_parse(role="geerlingguy.apache")
    assert result == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}

    result = RoleRequirement.role_yaml_parse(role="user.role,v1")
    assert result == {'name': 'user.role', 'src': 'user.role', 'scm': None, 'version': 'v1'}

    result = RoleRequirement.role_y

# Generated at 2022-06-21 01:20:53.693883
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.constants import DEFAULT_ROLES_PATH
    import os.path
    import tempfile
    import shutil

    path_tmp_dir = tempfile.mkdtemp()
    path_roles_dir = os.path.join(path_tmp_dir, DEFAULT_ROLES_PATH)
    os.makedirs(path_roles_dir)
    os.chdir(path_roles_dir)

    src = 'http://github.com/ansible/ansible-examples.git'
    name = 'ansible-examples'
    version = 'HEAD'
    keep_scm_meta = True

# Generated at 2022-06-21 01:21:04.320880
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    def run_test(src, scm, name, version, keep_scm_meta):
        tmp_role = RoleRequirement.scm_archive_role(src, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta)
        return tmp_role["name"], tmp_role["version"], tmp_role["src"]

    # acme.myrole

# Generated at 2022-06-21 01:21:15.912414
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("https://github.com/Foo/foo-role.git") == "foo-role"
    assert RoleRequirement.repo_url_to_role_name("foo@bar.com/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@github.com:Foo/foo-role.git") == "foo-role"
    assert RoleRequirement.repo_url_to_role_name("git+ssh://git@github.com/Foo/foo-role.git") == "foo-role"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/Foo/foo-role.git") == "foo-role"
    assert Role

# Generated at 2022-06-21 01:21:26.516922
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_spec = {
        'role': 'geerlingguy.apache',
        'src': 'https://github.com/geerlingguy/ansible-role-apache',
        'version': 'v1.0.0',
        'scm': 'git',
        'name': 'geerlingguy.apache',
    }

    def assert_role_spec(spec, spec_expected):
        spec_actual = RoleRequirement.role_yaml_parse(spec)
        for key, value in spec_expected.items():
            assert spec_actual[key] == value

    assert_role_spec(role_spec, role_spec)
    assert_role_spec('geerlingguy.apache', role_spec)

    role_spec.pop('role')

# Generated at 2022-06-21 01:21:38.385407
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("ansible-role-nginx") == {'name': 'ansible-role-nginx', 'src': 'ansible-role-nginx', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse("ansible-role-nginx,1.2.3") == {'name': 'ansible-role-nginx', 'src': 'ansible-role-nginx', 'scm': None, 'version': '1.2.3'}
    assert RoleRequirement.role_yaml_parse("ansible-role-nginx,1.2.3,othername") == {'name': 'othername', 'src': 'ansible-role-nginx', 'scm': None, 'version': '1.2.3'}


# Generated at 2022-06-21 01:21:47.142679
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    testdict = [
        ('http://git.example.com/repos/repo.git', 'repo'),
        ('http://example.com/repo.git', 'repo'),
        ('http://example.com/repo.tar.gz', 'repo'),
        ('http://example.com/repo.tar.gz', 'repo'),
        ('git@example.com:repo', 'repo'),
        ('git@example.com:repo', 'repo'),
        ('git@example.com:repo,v1.0', 'repo'),
        ('git@example.com:repo,v1.0', 'repo'),
        ('/home/user/repo', 'repo'),
        ('/home/user/repo', 'repo')
    ]

# Generated at 2022-06-21 01:22:04.864040
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import os
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    if not hasattr(__builtins__, '__ansible_test_roles'):
        __builtins__.__ansible_test_roles = os.path.join(os.path.dirname(__file__), '../../../test/units/module_utils')

    myanswer = RoleRequirement.role_yaml_parse(dict(role='foo', bar='baz'))
    assert myanswer == dict(name='foo', bar='baz')
    myanswer = RoleRequirement.role_yaml_parse(dict(src='git+https://github.com/geerlingguy/ansible-role-test', bar='baz'))

# Generated at 2022-06-21 01:22:09.845109
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse('geerlingguy.apache')
    assert role['name'] == 'apache'
    assert role['src'] == 'geerlingguy.apache'
    assert role['version'] == ''

    role = RoleRequirement.role_yaml_parse('https://github.com/geerlingguy/ansible-role-apache.git')
    assert role['name'] == 'ansible-role-apache'
    assert role['src'] == 'https://github.com/geerlingguy/ansible-role-apache.git'
    assert role['version'] == ''

    role = RoleRequirement.role_yaml_parse('http://github.com/geerlingguy/ansible-role-apache.git')
    assert role['name'] == 'ansible-role-apache'
   

# Generated at 2022-06-21 01:22:18.336488
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/my_repo,v1.0') == 'my_repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/my_repo,v1.0,my_role') == 'my_repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/my_repo,v1.0,my_role,v2.0') == 'my_repo'


# Generated at 2022-06-21 01:22:29.698777
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """role_yaml_parse returns a dictionary keyed by VALID_SPEC_KEYS"""

# Generated at 2022-06-21 01:22:40.097221
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Empty role name
    assert (RoleRequirement.repo_url_to_role_name('') == '')

    # No http nor scp schema
    assert (RoleRequirement.repo_url_to_role_name('ansible-role-foo') == 'ansible-role-foo')

    # HTTP schema with .git suffix
    assert (RoleRequirement.repo_url_to_role_name('http://git.server.org/git/ansible-role-foo.git') == 'ansible-role-foo')

    # HTTP schema without .git suffix
    assert (RoleRequirement.repo_url_to_role_name('http://git.server.org/git/ansible-role-foo') == 'ansible-role-foo')

    # SSH schema with .git suffix

# Generated at 2022-06-21 01:22:49.734048
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:23:01.050211
# Unit test for constructor of class RoleRequirement

# Generated at 2022-06-21 01:23:11.215870
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    test_cases = [
        ('role_name', dict(name='role_name', scm=None, src='role_name', version=None)),
        ('role_name,v1', dict(name='role_name', scm=None, src='role_name', version='v1')),
        ('role_name,v1,other_name', dict(name='other_name', scm=None, src='role_name', version='v1')),
        ('git+https://github.com/galaxyproject/ansible-galaxy.git,v1.0.0,role_name', dict(name='role_name', scm='git', src='https://github.com/galaxyproject/ansible-galaxy.git', version='v1.0.0')),
    ]


# Generated at 2022-06-21 01:23:17.104179
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    role = RoleRequirement.scm_archive_role('https://github.com/geerlingguy/ansible-role-apache.git', scm='git', name='apache', version='1.0.0')

    assert role['scm'] is 'git'
    assert role['name'] is 'apache'
    assert role['version'] is '1.0.0'


# Generated at 2022-06-21 01:23:25.742916
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    print("Testing RoleRequirement.role_yaml_parse()")
    print("----------------------------------------\n")
