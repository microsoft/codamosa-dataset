

# Generated at 2022-06-21 01:14:21.625320
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:14:28.552327
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("../../../some/local/path") == "path"
    assert RoleRequirement.repo_url_to_role_name("file:///some/local/file.tar.gz") == "file.tar"


# Generated at 2022-06-21 01:14:35.218247
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:14:45.376834
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    src = "git@github.com:peterjc/galaxy_ng"
    scm = "git"
    name = "galaxy_ng"
    version = "HEAD"
    keep_scm_meta = False

    role = RoleRequirement.scm_archive_role(src, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta)
    assert role.get_info()['path'].endswith(name)
    assert role.get_info()['version'] == version
    assert role.get_info()['scm'] == scm

# Generated at 2022-06-21 01:14:58.322347
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import galaxy
    import unittest
    import sys
    import os

    class RoleRequirement_TestCase(unittest.TestCase):
        def setUp(self):
            # set up temp directory for test
            test_dir = os.path.abspath(os.path.dirname(sys.modules['galaxy'].__file__))
            self.temp_dir = os.path.join(test_dir, 'fixtures', 'roleRequirement')
            if not os.path.exists(self.temp_dir):
                os.makedirs(self.temp_dir)
            self.default_version = 'HEAD'


# Generated at 2022-06-21 01:15:08.046612
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    RoleRequirement.scm_archive_role("git+https://github.com/uashid/ansible-role-android-build-tools.git,v2.3.3_r02-5.5.1", "git", "android-build-tools")
    RoleRequirement.scm_archive_role("https://github.com/uashid/ansible-role-android-build-tools.git,v2.3.3_r02-5.5.1", "git", "android-build-tools")
    # RoleRequirement.scm_archive_role("https://github.com/uashid/ansible-role-android-build-tools.git,v2.3.3_r02-5.5.1", "git", "android-build-tools")
    RoleRequirement.scm_archive_

# Generated at 2022-06-21 01:15:15.193033
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    print("test_RoleRequirement_repo_url_to_role_name")

    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('ssh://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com/repos/repo.git') == 'repo'

# Generated at 2022-06-21 01:15:27.100301
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.utils.data import md5s
    definition = RoleRequirement()
    role = definition.role_yaml_parse({"src":"https://github.com/foo/bar","version":"HEAD"})
    assert role["src"] == "https://github.com/foo/bar"
    assert role["version"] == "HEAD"
    assert role["name"] == "bar"
    assert role["scm"] == "git"
    assert sorted(role.keys()) == ['name', 'scm', 'src', 'version']
    assert md5s(role) == "49a6c0f6faa4c47dd8d5ef07b4f4b4ef"

    # test legacy role syntax of 'git+https://github.com/foo/bar'

# Generated at 2022-06-21 01:15:36.983096
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = "test"
    role1 = "test,test1"
    role2 = "test,test1,test2"
    role3 = "test,test1,test2,test3"
    role4 = "test4,test5,test6,test7"
    role5 = "test8,test9,test10,test11,test12"

    answer = dict(name="test", src="test", version="", scm=None)
    answer1 = dict(name="test1", src="test", version="test1", scm=None)
    answer2 = dict(name="test2", src="test", version="test1", scm=None)
    answer3 = dict(name="test2", src="test", version="test1", scm=None)

# Generated at 2022-06-21 01:15:42.075350
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    this_role_requirement = RoleRequirement()
    assert this_role_requirement.role_yaml_parse('testrole,v2.0') == {'name': 'testrole', 'src': 'testrole', 'scm': None, 'version': 'v2.0'}
    assert this_role_requirement.role_yaml_parse('git+git://git.example.com/repos/repo.git,v2.0') == {'name': 'repo', 'src': 'git://git.example.com/repos/repo.git', 'scm': 'git', 'version': 'v2.0'}
    assert this_role_requirement.role_yaml_parse('git+git://git.example.com/repos/repo.git,v2.0,new_name')

# Generated at 2022-06-21 01:15:58.088684
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    #Import modules
    import os
    import stat
    import shutil

    from ansible.errors import AnsibleError
    from ansible.playbook.role.requirement import RoleRequirement

    #Test case 1
    dest_dir = "./tmp"
    src = "https://github.com/ansible/ansible-examples.git"
    rr = RoleRequirement.scm_archive_role(src, scm='git', version="d096f4dc45cf7ce0709b4d4dbe4c1666f7e4a9e9")
    if not os.path.exists(dest_dir + "/.git") and not os.path.exists(dest_dir + "/ansible-examples"):
        raise AssertionError()

# Generated at 2022-06-21 01:16:00.164283
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()

    assert role_requirement != None



# Generated at 2022-06-21 01:16:06.655496
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    test_role_requirement = RoleRequirement()
    output = test_role_requirement.scm_archive_role('https://github.com/jkwarren/buildout-ansible.git',
                                                     scm='git',
                                                     name='test',
                                                     version='HEAD',
                                                     keep_scm_meta=False)
    assert output.endswith('test')

# Generated at 2022-06-21 01:16:14.803124
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    if RoleRequirement.repo_url_to_role_name("https://github.com/ansible/ansible-modules-extras.git") != "ansible-modules-extras":
        raise AssertionError("Failed to parse github URL")
    if RoleRequirement.repo_url_to_role_name("https://github.com/ansible/ansible-modules-extras,v1.0") != "ansible-modules-extras":
        raise AssertionError("Failed to parse github URL")
    if RoleRequirement.repo_url_to_role_name("https://github.com/ansible/ansible-modules-extras,v1.0,my-modules") != "my-modules":
        raise AssertionError("Failed to parse github URL")

# Generated at 2022-06-21 01:16:23.328155
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import tempfile
    import ansible.constants as C

    if not C.SCM_ALLOW_INTERNAL:
        raise AnsibleError("Cannot run unit tests with SCM_ALLOW_INTERNAL=False")

    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.write(b"ASDF")
    test_file.close()

    # Test git
    location = test_file.name
    role = RoleRequirement.scm_archive_role(location, scm='git')
    assert role["name"] == "ansible-test"
    assert len(role["files"]) == 1

    # Test tar:
    location = "file://" + test_file.name + ".tar"

# Generated at 2022-06-21 01:16:27.591006
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = 'https://github.com/geerlingguy/ansible-role-security.git'
    scm = 'git'
    name = 'ansible-role-security'
    version = 'HEAD'
    keep_scm_meta = False

    result = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)
    assert result == 2



# Generated at 2022-06-21 01:16:39.333328
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    assert RoleRequirement().role_yaml_parse('3rdparty.foobar') == dict(name='3rdparty.foobar', src=None, scm=None, version=None)
    assert RoleRequirement().role_yaml_parse('3rdparty.foobar,v1') == dict(name='3rdparty.foobar', src=None, scm=None, version='v1')
    assert RoleRequirement().role_yaml_parse('3rdparty.foobar,v1,name') == dict(name='name', src=None, scm=None, version='v1')

# Generated at 2022-06-21 01:16:50.868550
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test the function with a short string and with a dictionary
    # These results are based on the current implementation and are
    # thus subject to change

    # test a short string
    result = RoleRequirement.role_yaml_parse("src=git+https://github.com/user/repo,v1.0,role_name")
    assert result == {'scm': 'git', 'name': 'role_name', 'src': 'https://github.com/user/repo', 'version': 'v1.0'}, result

    # test a dictionary
    test_dict = {'src': 'git+https://github.com/user/repo,v1.0,role_name', 'ignoreme': 'foo'}
    result = RoleRequirement.role_yaml_parse(test_dict)

# Generated at 2022-06-21 01:16:59.376828
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git+https://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"

# Generated at 2022-06-21 01:17:11.202386
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    result = RoleRequirement.scm_archive_role(src='https://github.com/foo/bar.git', scm='git', name=None, version='HEAD', keep_scm_meta=False)
    assert result == "/var/lib/awx/projects/github.com/foo/bar/HEAD.tar.gz", "An unexpected file path was returned by scm_archive_role: %s" % result

    result = RoleRequirement.scm_archive_role(src='https://github.com/foo/bar.git', scm='git', name=None, version='refs/tags/1.0.0', keep_scm_meta=False)

# Generated at 2022-06-21 01:17:29.486581
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    import types
    assert type(RoleRequirement.repo_url_to_role_name) == types.FunctionType
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-apache.git") == "ansible-role-apache"

# Generated at 2022-06-21 01:17:34.313646
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    # Test
    rr = RoleRequirement()
    rr.role_yaml_parse(role='foo,galaxy')
    rr.role_yaml_parse(role='foo,galaxy,')
    rr.role_yaml_parse(role='foo,,galaxy')

# Generated at 2022-06-21 01:17:42.392401
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('example-role') == 'example-role'
    assert RoleRequirement.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo.git') == 'repo.git'
    assert RoleRequirement.repo_url_to_role_name('repo-role.tar.gz') == 'repo-role'

# Generated at 2022-06-21 01:17:51.412061
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.errors import AnsibleError
    from ansible.playbook.role.definition import RoleDefinition

    results = RoleRequirement.role_yaml_parse(role='/path/to/role,v1.0,name')
    assert results == {'name': 'name', 'src': '/path/to/role', 'scm': None, 'version': 'v1.0'}

    results = RoleRequirement.role_yaml_parse(role='/path/to/role')
    assert results == {'name': 'role', 'src': '/path/to/role', 'scm': None, 'version': None}

    results = RoleRequirement.role_yaml_parse(role='/path/to/role,v1.0')

# Generated at 2022-06-21 01:18:02.742245
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # ansible-galaxy init with name and version
    test_data1 = dict(
        name = "test_role",
        scm = None,
        src = "github.com/user/test_role",
        version = "0.0.1",
    )
    assert RoleRequirement.role_yaml_parse("test_role,0.0.1") == test_data1
    assert RoleRequirement.role_yaml_parse(dict(name="test_role", version="0.0.1")) == test_data1
    assert RoleRequirement.role_yaml_parse(dict(role="test_role,0.0.1")) == test_data1

    # ansible-galaxy init with only name

# Generated at 2022-06-21 01:18:12.582030
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.six import b, PY3

    from ansible.parsing.yaml.objects import AnsibleUnicode

    from os.path import sep as path_sep, join as path_join
    from tempfile import mkdtemp
    from shutil import rmtree
    from errno import EEXIST

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import fetch_url

    from six.moves import urllib
    from six.moves import configparser

    from git import Repo
    from git.exc import GitCommandError

    if PY3:
        unicode = str


# Generated at 2022-06-21 01:18:22.583916
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    # test 1
    src_url = 'https://github.com/bertvv/ansible-role-samba.git'
    name = 'samba'
    scm = 'git'
    version = 'v1.1'
    keep_scm_meta = False

    test_result = RoleRequirement.scm_archive_role(src=src_url, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta)
    assert test_result == ('https://github.com/bertvv/ansible-role-samba.git', 'v1.1')

# Generated at 2022-06-21 01:18:27.797910
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    name = 'ansible-atmos'
    version = '1.0.0'
    scm = 'git'
    src = 'https://github.com/EMC-CMD/ansible-atmos'
    keep_scm_meta = True
    res = RoleRequirement.scm_archive_role(src=src, scm=scm, name=name, version=version, keep_scm_meta=keep_scm_meta)
    assert res['name'] == name
    assert res['scm'] == scm
    assert 'https:' in res['src']
    assert res['version'] == '1.0.0'


# Generated at 2022-06-21 01:18:29.558313
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    required_role = None
    required_role = RoleRequirement()
    if not isinstance(required_role, RoleRequirement):
        raise AssertionError("test_RoleRequirement: constructors test failed")


# Generated at 2022-06-21 01:18:33.931596
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    src = 'https://github.com/david-edmondson/ansible-role-grafana.git'
    scm = 'git'
    name = 'grafana'
    version = 'HEAD'
    keep_scm_meta = False

    actual_result = RoleRequirement.scm_archive_role(src, scm, name, version, keep_scm_meta)

    assert actual_result

# Generated at 2022-06-21 01:18:47.582152
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    assert role is not None

# Generated at 2022-06-21 01:18:56.916709
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git://git.example.com/repos/repo.tar.gz") == "repo"


# Generated at 2022-06-21 01:19:07.979191
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # RoleRequirement.role_yaml_parse(role):
    assert RoleRequirement.role_yaml_parse('role_name') == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('role_name,0.1') == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': '0.1'}
    assert RoleRequirement.role_yaml_parse('role_name,0.1,another_name') == {'name': 'another_name', 'src': 'role_name', 'scm': None, 'version': '0.1'}

    assert RoleRequirement.role_yaml_parse({'role': 'role_name'})

# Generated at 2022-06-21 01:19:18.578742
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # None - Input param should not be None
    assert RoleRequirement.repo_url_to_role_name(None) is None

    # Empty - Input param should not be empty
    assert RoleRequirement.repo_url_to_role_name('') == ''

    # Valid use case
    assert RoleRequirement.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('/local/path/repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('repo.git') == 'repo'
    assert Role

# Generated at 2022-06-21 01:19:28.223697
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:19:39.944980
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:19:50.941916
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test 1
    # Input data
    name = None
    scm = None
    src = None
    version = None

    role = "https://github.com/geerlingguy/ansible-role-apache.git,1.x"
    (src, version, name) = role.strip().split(',', 2)

    if name is None:
        name = RoleRequirement.repo_url_to_role_name(src)

    (scm, src) = src.split('+', 1)

    assert scm == 'git'
    assert version == '1.x'
    assert name == 'ansible-role-apache'

    # Test 2
    role = "https://galaxy.ansible.com/download/linux-system-roles-common-git-master.tar.gz"

# Generated at 2022-06-21 01:20:01.753939
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    print("TestRoleRequirement")

    text_test = "name,version,scm"
    result = RoleRequirement.role_yaml_parse(text_test)
    print(result)

    text_test = "name,version,"
    result = RoleRequirement.role_yaml_parse(text_test)
    print(result)

    text_test = "name,,"
    result = RoleRequirement.role_yaml_parse(text_test)
    print(result)

    text_test = "name,,scm"
    result = RoleRequirement.role_yaml_parse(text_test)
    print(result)

    text_test = "name,,git+https://github.com/geerlingguy/ansible-role-repo-epel.git"
    result = RoleRequirement.role

# Generated at 2022-06-21 01:20:10.081853
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name('https://github.com/username/RepoName') == 'RepoName'
    assert role_requirement.repo_url_to_role_name('git@github.com:username/RepoName.git') == 'RepoName'
    assert role_requirement.repo_url_to_role_name('https://github.com/username/RepoName.git') == 'RepoName'
    assert role_requirement.repo_url_to_role_name('https://github.com/username/RepoName.git,') == 'RepoName'

# Generated at 2022-06-21 01:20:14.732698
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    ret = RoleRequirement.scm_archive_role(pl.path(__file__).dirname().joinpath('data/test_galaxy').abspath())
    print(ret)

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-21 01:20:43.049526
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    display = Display()

    display.display('')
    display.display(stringc('%{=rkw}TEST: %{=kw}RoleRequirement%{-}', bold=True))

    # test role_yaml_parse
    role_yaml = {
        'name': 'test',
        'scm': 'git',
        'src': 'http://git.example.com/repos/repo.git',
        'version': 'HEAD',
    }
    role_yaml_new = {
        'name': 'test',
        'scm': 'git',
        'src': 'https://github.com/repo.git',
        'version': 'HEAD',
    }
    role_y

# Generated at 2022-06-21 01:20:54.255291
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test the old-style role definition
    role = RoleRequirement.role_yaml_parse('mysql,1.0')
    assert role['name'] == 'mysql'
    assert role['src'] == 'mysql'
    assert role['version'] == '1.0'
    assert role['scm'] == None

    # Test the old-style role definition
    role = RoleRequirement.role_yaml_parse('mysql,v1.0')
    assert role['name'] == 'mysql'
    assert role['src'] == 'mysql'
    assert role['version'] == 'v1.0'
    assert role['scm'] == None

    # Test the old-style role definition
    role = RoleRequirement.role_yaml_parse('git+https://github.com/user/repo.git')

# Generated at 2022-06-21 01:21:04.721175
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    name = 'ansible-role-chrony'
    src = 'https://github.com/bertvv/ansible-role-chrony.git'
    scm = 'git'
    version = '1.0.0'

    role = {'name': name, 'src': src, 'scm': scm, 'version': version}
    role_req = RoleRequirement.role_yaml_parse(role)
    assert role_req == role

    role_str = 'git+https://github.com/bertvv/ansible-role-chrony.git'
    assert RoleRequirement.role_yaml_parse(role_str) == {'name': name, 'src': src, 'scm': scm, 'version': ''}


# Generated at 2022-06-21 01:21:16.015002
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-21 01:21:26.583839
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test older format:
    assert RoleRequirement.role_yaml_parse("name,version,role_name") == dict(name="role_name", src="name", scm=None, version="version")
    assert RoleRequirement.role_yaml_parse("name,version") == dict(name=RoleRequirement.repo_url_to_role_name("name"), src="name", scm=None, version="version")
    assert RoleRequirement.role_yaml_parse("name") == dict(name=RoleRequirement.repo_url_to_role_name("name"), src="name", scm=None, version=None)

# Generated at 2022-06-21 01:21:31.106796
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    role_name = RoleRequirement.repo_url_to_role_name("https://code.google.com/p/ansible-ssh-config/")
    assert role_name == "ansible-ssh-config"


# Generated at 2022-06-21 01:21:42.018571
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    from ansible.module_utils._text import to_bytes, to_native

    from ansible.utils.hashing import checksum
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.reserved import Reserved, DEFAULT_VAULT_ID_MATCH

    import os, shutil, tempfile

    tempdir = tempfile.mkdtemp(prefix='ansible-test-tar_util')

    loader = DataLoader()
    vault_pass = loader.get_vault_password(None, None)
    reserved_words = Reserved(DEFAULT_VAULT_ID_MATCH)
    vault = reserved_words.get_vault_secrets(vault_pass)[0]

    tmp = RoleRequirement

    # create a test role with a vars/main.yml, tasks/

# Generated at 2022-06-21 01:21:48.744999
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Test with a simple repo_url
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'

    # Test with a git repo_url
    assert RoleRequirement.repo_url_to_role_name('git@github.com:ansible/ansible-modules-extras.git') == 'ansible-modules-extras'

    # Test with a repo_url with a branch name
    assert RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-modules-extras.git,devel') == 'ansible-modules-extras'

    # Test with a repo_url with a tag name

# Generated at 2022-06-21 01:22:00.125534
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/test@test,test@test.git") == "test@test,test@test"
    assert RoleRequirement.repo_url_to_role_name("test@test") == "test@test"

# Generated at 2022-06-21 01:22:11.262350
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com/foo/bar.git") == "bar"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com/foo/bar.git") == "bar"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com/foo/bar.git?rev=abcdef") == "bar"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com/foo/bar.git?rev=abcdef") == "bar"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com/foo/bar.git?rev=abcdef,v0.1") == "bar"

# Generated at 2022-06-21 01:22:41.105699
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    expected = {
        'name': 'testrole',
        'version': '1.2.3',
        'src': 'https://github.com/example/testrole.git',
        'scm': 'git',
    }

    role = RoleRequirement.role_yaml_parse('https://github.com/example/testrole.git,1.2.3,testrole')
    assert role == expected

    role = RoleRequirement.role_yaml_parse('https://github.com/example/testrole.git,1.2.3')
    assert role == expected

    role = RoleRequirement.role_yaml_parse('https://github.com/example/testrole.git')
    expected.pop('version')
    assert role == expected

    # Old style

# Generated at 2022-06-21 01:22:52.144311
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # Test for github.com
    archive_path = RoleRequirement.scm_archive_role(src='https://github.com/geerlingguy/ansible-role-apache', scm='git')
    assert archive_path.endswith('.tar.gz')
    assert 'ansible-role-apache' in archive_path
    assert 'geerlingguy' in archive_path
    # Test for bitbucket.org
    archive_path = RoleRequirement.scm_archive_role(src='https://bitbucket.org/willthames/ansible-git', scm='git')
    assert archive_path.endswith('.tar.gz')
    assert 'ansible-git' in archive_path
    assert 'willthames' in archive_path
    # Test for gitlab.com
    archive_path

# Generated at 2022-06-21 01:23:02.783942
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert RoleRequirement.role_yaml_parse("geerlingguy.apache") == dict(name=None, src='geerlingguy.apache', scm=None, version='')
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.9.0") == dict(name=None, src='geerlingguy.apache', scm=None, version='1.9.0')
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.9.0,webserver") == dict(name='webserver', src='geerlingguy.apache', scm=None, version='1.9.0')

# Generated at 2022-06-21 01:23:13.904197
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    print("Testing RoleRequirement")
    # failed
    temp = "http://git.mydocsis.com/repos/dcmgr-ansible-role-dcmgr-master.git,v1.0.0,dcmgr"
    assert RoleRequirement.repo_url_to_role_name(temp) != "v1.0.0,dcmgr"
    assert RoleRequirement.repo_url_to_role_name("repo-name") == "repo-name"
    assert RoleRequirement.role_yaml_parse("dummy,version,name") != {'src': 'dummy', 'version': 'version', 'name': 'name'}

# Generated at 2022-06-21 01:23:21.001850
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    test_role = 'my_role_name'
    test_role_dict = dict(name=test_role)

    test_role_dict_returned = role_requirement.role_yaml_parse(test_role_dict)
    test_role_returned = role_requirement.role_yaml_parse(test_role)

    assert test_role_returned == test_role_dict
    assert test_role_dict_returned == test_role_dict

# Generated at 2022-06-21 01:23:21.981023
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    # Test code
    # TODO

    pass

# Generated at 2022-06-21 01:23:32.472373
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('user@git.example.com:/path/to/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/user/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/user/repo/blob/master/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('some+protocol://github.com/user/repo.git') == 'repo'
   

# Generated at 2022-06-21 01:23:42.729658
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """
    tests for the role_yaml_parse() method in the RoleRequirement class
    """
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git') == dict(name='repo', src='http://git.example.com/repos/repo.git', scm=None, version='')
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,v1.0') == dict(name='repo', src='http://git.example.com/repos/repo.git', scm=None, version='v1.0')

# Generated at 2022-06-21 01:23:44.834863
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    print('Testing RoleRequirement constructor')

    rr = RoleRequirement()
    assert(rr.__class__ == RoleRequirement)

test_RoleRequirement()

# Generated at 2022-06-21 01:23:50.983487
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Simple role
    role = "role_name"
    result = RoleRequirement.role_yaml_parse(role)
    expected = {'src': "role_name", 'scm': None, 'version': '', 'name': "role_name"}
    assert result == expected
    # Simple role with spaces
    role = " role_name "
    result = RoleRequirement.role_yaml_parse(role)
    expected = {'src': "role_name", 'scm': None, 'version': '', 'name': "role_name"}
    assert result == expected
    # Role with name and version
    role = "role_name,v2"
    result = RoleRequirement.role_yaml_parse(role)