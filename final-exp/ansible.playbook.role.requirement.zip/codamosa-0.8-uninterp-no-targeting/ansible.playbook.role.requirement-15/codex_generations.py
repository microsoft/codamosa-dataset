

# Generated at 2022-06-21 01:14:25.085447
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    import unittest

    class RoleRequirement_TestCase(unittest.TestCase):
        def test_invalid_inputs(self):
            self.assertRaises(AnsibleError, RoleRequirement.repo_url_to_role_name, 'http://git.example.com/repos/repo.git/does_not_matter')
            self.assertRaises(AnsibleError, RoleRequirement.repo_url_to_role_name, 'http://git.example.com/repos/repo.git/does_not_matter,0.0.1')

# Generated at 2022-06-21 01:14:32.967759
# Unit test for constructor of class RoleRequirement

# Generated at 2022-06-21 01:14:41.114572
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v2.1') == 'repo'

# Generated at 2022-06-21 01:14:49.668019
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz,") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,1.4")

# Generated at 2022-06-21 01:14:55.553034
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert isinstance(RoleRequirement.role_yaml_parse(dict(name='test')), dict)
    assert isinstance(RoleRequirement.role_yaml_parse(''), dict)
    assert isinstance(RoleRequirement.role_yaml_parse('test1,test2,test3'), dict)
    assert isinstance(RoleRequirement.role_yaml_parse('test1,test2,test3,test4'), dict)
    assert isinstance(RoleRequirement.role_yaml_parse('test1,test2,test3,test4,test5'), dict)
    assert isinstance(RoleRequirement.role_yaml_parse('test1,test2,test3,test4,test5,test6'), dict)

# Generated at 2022-06-21 01:14:57.112973
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    role_requirement = RoleRequirement()
    assert role_requirement is not None

# Generated at 2022-06-21 01:15:05.884376
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    """
    Unit test for RoleRequirement.scm_archive_role
    """

    role_requirement = RoleRequirement()
    result = role_requirement.scm_archive_role('https://github.com/ansible/ansible-spec.git')
    assert result == "/tmp/ansible-local/tmpJ9u35s/ansible-spec-master.tar", result
    result = role_requirement.scm_archive_role('https://github.com/ansible/ansible-spec.git', version='2.1')
    assert result == "/tmp/ansible-local/tmpq5at5l/ansible-spec-2.1.tar", result

# Generated at 2022-06-21 01:15:15.486064
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-21 01:15:24.812508
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
   print("\nTesting function scm_archive_role")
   repo_url = 'git+https://github.com/mrlesmithjr/ansible-nginx'
   name = 'ansible-nginx'
   version = 'HEAD'
   keep_scm_meta = False
   role = RoleRequirement.scm_archive_role(repo_url, scm='git', name=name, version=version, keep_scm_meta=keep_scm_meta)
   print(role)
   assert isinstance(role, dict)


# Generated at 2022-06-21 01:15:29.302533
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = RoleRequirement()
    assert role


# Unit tests for role_yaml_parse:
# We test two conditions:
# - Check that role_yaml_parse returns a dict
# - Check that the dict has four keys
# - Check that the dict has correct values
# Also, check that an exception is raised if 'role' key is missing

# Generated at 2022-06-21 01:15:53.672262
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    def compare_role_requirements(test_case, left, right):
        assert left.get_info() == right.get_info()

    # class RoleRequirement()
    # first case data
    name1 = 'common'
    src1 = 'git+https://github.com/bennojoy/galaxy-roles.git'
    scm1 = 'git'
    version1 = 'v1.0'
    role1 = dict(name=name1, src=src1, scm=scm1, version=version1)

    # expected result
    expected_role_requirement1 = RoleRequirement()
    expected_role_requirement1.name = name1
    expected_role_requirement1.src = src1
    expected_role_requirement1.scm = scm1
    expected_role

# Generated at 2022-06-21 01:16:01.272098
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Setups
    display.verbosity = 3
    display.deprecated(display)

    role_requirement = RoleRequirement()

    # Tests
    assert role_requirement.repo_url_to_role_name("foo") == "foo"
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git/tree/master") == "repo.git/tree/master"

# Generated at 2022-06-21 01:16:11.791568
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    from ansible.galaxy import galaxy
    from ansible.galaxy import Galaxy
    from ansible.galaxy.role import GalaxyRole

    # test with scm argument
    src = "git+https://github.com/ansible/ansible-examples.git"
    expected = "/home/gitlab-runner/.ansible/tmp/ansible-local/ansible-examples-f8cc7f37515a6c95db6b0a8b38a0a988"
    returned = RoleRequirement.scm_archive_role(src)
    assert expected == returned

    src = "https://github.com/ansible/ansible-examples.git"

# Generated at 2022-06-21 01:16:23.438966
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git+git@git.example.com:repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git+https://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git+https://git.example.com/repos/repo.git,test") == "repo"

# Generated at 2022-06-21 01:16:27.159843
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible.galaxy import Galaxy
    import os

    class TestRoleRequirementScmArchiveRole(unittest.TestCase):

        def setUp(self):
            self.galaxy = Galaxy()


# Generated at 2022-06-21 01:16:38.342294
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    y1 = "geerlingguy.java"
    assert(RoleRequirement.role_yaml_parse(y1) == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None})

    y2 = "geerlingguy.java,1.8"
    assert(RoleRequirement.role_yaml_parse(y2) == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.8'})

    y3 = "geerlingguy.java,1.8,test-java"

# Generated at 2022-06-21 01:16:49.642907
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0.tar.gz') == 'repo,v1.0.0'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo') == 'repo'

# Generated at 2022-06-21 01:16:57.593746
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    import os
    import shutil
    from ansible.utils.path import path_dwim_relative

    dest = path_dwim_relative("./test_role_requirements", "", "", "", expanduser=False)
    shutil.rmtree(dest, ignore_errors=True)

    assert os.path.exists(dest) is False

    RoleRequirement.scm_archive_role("git+https://github.com/geerlingguy/ansible-role-postgresql", version="v1.5.0", keep_scm_meta=False, dest=dest)

    assert os.path.exists(dest) is True

# Generated at 2022-06-21 01:17:08.803813
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_dict = {
        "role": "geerlingguy.java,1.7.0",
        "some": "variable",
    }
    role = RoleRequirement.role_yaml_parse(role_dict)
    assert role["version"] == "1.7.0"
    assert role["name"] == "geerlingguy.java"
    assert role["some"] == "variable"
    assert "role" not in role

    role_dict = {
        "role": "geerlingguy.java",
        "some": "variable",
    }
    role = RoleRequirement.role_yaml_parse(role_dict)
    assert role["version"] == ""
    assert role["name"] == "geerlingguy.java"
    assert role["some"] == "variable"

# Generated at 2022-06-21 01:17:17.891039
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    display.display("Testing RoleRequirement")
    display.display("----")
    display.display("Testing constructor")
    display.display("----")
    display.display("Testing RoleRequirement(role='test_role')")
    rolereq = RoleRequirement(role='test_role')
    assert rolereq is not None
    assert rolereq.get_info() == {'name': 'test_role', 'src': None, 'scm': None, 'version': None, 'private': False, 'dependencies': [], 'path': None}
    display.display("Testing RoleRequirement(role='test_role,1.0,test_name')")
    rolereq = RoleRequirement(role='test_role,1.0,test_name')
    assert rolereq is not None

# Generated at 2022-06-21 01:17:38.527948
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    from ansible.errors import AnsibleError
    import pytest

    role_yaml_parse = RoleRequirement.role_yaml_parse

    assert role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'version': '', 'src': 'https://galaxy.ansible.com/download/geerlingguy-apache-v1.5.0.tar.gz', 'scm': None}
    assert role_yaml_parse('geerlingguy.apache,v2.2.2') == {'name': 'geerlingguy.apache', 'version': 'v2.2.2', 'src': 'https://galaxy.ansible.com/download/geerlingguy-apache-v2.2.2.tar.gz', 'scm': None}
   

# Generated at 2022-06-21 01:17:49.540478
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    from ansible.playbook.role.requirement import VALID_SPEC_KEYS
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.module_utils.galaxy import scm_archive_resource
    import os.path
    import pytest
    import tempfile
    import shutil
    import importlib
    import contextlib
    import random
    import string


    # Unit test for __init__
    # no tests, because it is not doing anything

    # Unit test for repo_url_to_role_name
    # returns the role name out of a repo like
    # http://git.example.com/repos/repo.git" => "repo"

# Generated at 2022-06-21 01:18:00.448846
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert(RoleRequirement.repo_url_to_role_name("http://foo.org/repos/repo.git") == "repo")
    assert(RoleRequirement.repo_url_to_role_name("git+http://foo.org/repos/repo.git") == "repo")
    assert(RoleRequirement.repo_url_to_role_name("git+http://foo.org/repos/repo-ver.tar.gz") == "repo-ver")
    assert(RoleRequirement.repo_url_to_role_name("git+http://foo.org/repos/repo-ver.tar.gz,v2") == "repo-ver")

# Generated at 2022-06-21 01:18:10.847691
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,0.1.1,role_name") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,0.1.1") == "repo"

# Generated at 2022-06-21 01:18:23.332161
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    import ansible.release as release

    # Handle the case when the constructor is called with a string "rolename"
    r = RoleRequirement('rolename')
    assert not r.get_info()

    # Handle the case when the constructor is called with a dict
    r = RoleRequirement({'role': 'rolename'})
    assert not r.get_info()

    # Handle the case when the constructor is called with a dict
    r = RoleRequirement({'role': 'rolename,1.0'})
    assert r.get_info()['name'] == 'rolename'
    assert r.get_info()['version'] == '1.0'

    # Check that old-style role names, with ',' in them, are not permitted

# Generated at 2022-06-21 01:18:33.307880
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # initialize needed objects
    inventory = InventoryManager(Loader(), sources="/dev/null")
    variable_manager = VariableManager(Loader(), inventory=inventory)
    play_context = PlayContext()
    play_context._set_loader(Loader())

    # create a play and play iterator
    play = Play().load({
        'name' : 'testing role fetching',
        'hosts': 'all',
    }, variable_manager=variable_manager, loader=Loader())

    play_it = PlayIterator(inventory, variable_manager, play_context, play)

   

# Generated at 2022-06-21 01:18:44.941839
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    from ansible.playbook.role.requirement import RoleRequirement
    # test https url
    url = 'https://github.com/geerlingguy/ansible-role-apache.git'
    assert RoleRequirement.repo_url_to_role_name(url) == 'ansible-role-apache'

    # test http url
    url = 'http://github.com/geerlingguy/ansible-role-apache.git'
    assert RoleRequirement.repo_url_to_role_name(url) == 'ansible-role-apache'

    # test ssh
    url = 'git@github.com:geerlingguy/ansible-role-apache.git'
    assert RoleRequirement.repo_url_to_role_name(url) == 'ansible-role-apache'

    # test

# Generated at 2022-06-21 01:18:56.067596
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    import tempfile

    _, tf = tempfile.mkstemp(prefix='ansible-test-')
    rr = RoleRequirement()

    # Test case: Test with the basic case of scm-ing a git repository
    src = 'git+https://github.com/ansible/ansible-examples.git'
    assert rr.scm_archive_role(src) == '/tmp/ansible-test-asyncpixel-role-ansible-examples-git/ansible-examples'

    # Test case: Test with the basic case of scm-ing a git repository and provide a name argument

# Generated at 2022-06-21 01:19:06.353740
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    rr = RoleRequirement()

    # test with repo_urls
    repo_urls = {
        'http://git.example.com/repos/repo.git': 'repo',
        'http://git.example.com/repos/another-repo.git': 'another-repo',
        'git+http://git.example.com/repos/a-repo.git': 'a-repo',
        'git@git.example.com:repos/a-repo.git': 'a-repo',
    }
    for repo_url, role_name in repo_urls.items():
        assert rr.repo_url_to_role_name(repo_url) == role_name

    # test with tarball links

# Generated at 2022-06-21 01:19:17.475753
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    result = RoleRequirement.role_yaml_parse("http://github.com/foo/bar.git")
    assert result == {'name': 'bar', 'scm': 'git', 'src': 'http://github.com/foo/bar.git', 'version': None}

    result = RoleRequirement.role_yaml_parse("git+http://github.com/foo/bar.git")
    assert result == {'name': 'bar', 'scm': 'git', 'src': 'http://github.com/foo/bar.git', 'version': None}

    result = RoleRequirement.role_yaml_parse("http://github.com/foo/bar,devel")

# Generated at 2022-06-21 01:20:01.278905
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    from ansible.playbook.role.requirement import RoleRequirement
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/organization/repo,v0.3") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@github.com/organization/repo,v0.2") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/organization/repo.git,v0.1") == "repo"

# Generated at 2022-06-21 01:20:04.830328
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

# Generated at 2022-06-21 01:20:11.112328
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role = 'https://github.com/telusdigital/ansible-role-homebrew,devel'
    role2 = {'src': 'https://github.com/telusdigital/ansible-role-homebrew,devel'}
    role3 = {'src': 'https://github.com/telusdigital/ansible-role-homebrew,devel', 'version': 'v1'}
    role4 = {'src': 'https://github.com/telusdigital/ansible-role-homebrew,devel', 'version': 'v1', 'name': 'homebrew'}

# Generated at 2022-06-21 01:20:22.448249
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    result1 = RoleRequirement.repo_url_to_role_name("git@git.com/repo.git")
    result2 = RoleRequirement.repo_url_to_role_name("https://github.com/owner/repo.git")
    result3 = RoleRequirement.repo_url_to_role_name("https://github.com/owner/repo.git,version,name")
    result4 = RoleRequirement.repo_url_to_role_name("https://github.com/owner/repo.tar.gz")
    result5 = RoleRequirement.repo_url_to_role_name("https://github.com/owner/repo.tar.gz,version,name")

# Generated at 2022-06-21 01:20:30.325240
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # repo_url_to_role_name is static and should always be available in the class
    if not hasattr(RoleRequirement, 'repo_url_to_role_name'):
        raise AssertionError("repo_url_to_role_name() was not found in RoleRequirement class.")

    # test cases
    #  * repo_url must be a string_types to be a valid input to the method
    #    * Python3: str
    #    * Python2: str, unicode
    test_cases = [
        (1, "1"),
        (1.0, "1.0"),
        ({}, "{}"),
        (True, "True"),
        (False, "False"),
        (None, "None")
    ]

    for test_case in test_cases:
        repo_url,

# Generated at 2022-06-21 01:20:41.138441
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    test_names = ["geerlingguy.apache", "geerlingguy.apache,", "geerlingguy.apache,2.2.2",
                  "geerlingguy.apache,2.2.2,", "geerlingguy.apache,2.2.2,geerlingguy.apache_role",
                  "https://github.com/geerlingguy/ansible-role-apache.git,2.2.2,geerlingguy.apache"]
    for test_name in test_names:
        test_result = RoleRequirement.role_yaml_parse(test_name)
        assert test_result["name"] == "geerlingguy.apache"

# Generated at 2022-06-21 01:20:52.963725
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_yaml_parse = RoleRequirement.role_yaml_parse
    assert role_yaml_parse("Foo") == { 'name': 'Foo', 'src': 'Foo', 'scm': None, 'version': ''}
    assert role_yaml_parse("Foo,bar") == { 'name': 'Foo', 'src': 'Foo,bar', 'scm': None, 'version': ''}
    assert role_yaml_parse("Foo,bar,Baz") == { 'name': 'Baz', 'src': 'Foo,bar', 'scm': None, 'version': ''}
    assert role_yaml_parse("Foo,bar,Baz,foo") == { 'name': 'Baz', 'src': 'Foo,bar', 'scm': None, 'version': ''}



# Generated at 2022-06-21 01:21:03.661775
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():

    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.yaml.loader import AnsibleLoader
    import sys
    import yaml

    if PY3:
        unicode = str 

    if sys.version_info[0] < 3:
        role_definition = u"geerlingguy.jenkins"
    else:
        role_definition = "geerlingguy.jenkins"

    role_definition_result = RoleRequirement.role_yaml_parse(to_bytes(role_definition, errors='surrogate_or_strict'))
    assert isinstance(role_definition_result, dict)
    assert 'name' in role_definition_result
    assert role_definition_result['name']

# Generated at 2022-06-21 01:21:09.595046
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    req = RoleRequirement()
    assert req.role_yaml_parse('user1.role') == dict(name='user1.role', scm=None, src='user1.role', version='')
    assert req.role_yaml_parse('user1.role,1.0') == dict(name='user1.role', scm=None, src='user1.role', version='1.0')
    assert req.role_yaml_parse('user1.role,1.0,myname') == dict(name='myname', scm=None, src='user1.role', version='1.0')
    assert req.role_yaml_parse('user1.role,myname') == dict(name='myname', scm=None, src='user1.role', version='')
    assert req.role

# Generated at 2022-06-21 01:21:21.504847
# Unit test for method scm_archive_role of class RoleRequirement

# Generated at 2022-06-21 01:22:02.479202
# Unit test for constructor of class RoleRequirement
def test_RoleRequirement():
    role_requirement = RoleRequirement()
    assert role_requirement
    assert role_requirement.role_yaml_parse("geerlingguy.docker") == dict(name='geerlingguy.docker', src='geerlingguy.docker', scm=None, version=None)

# Generated at 2022-06-21 01:22:13.694331
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import sys
    from ansible.module_utils.six import PY3

    if PY3:
        role_str1 = "{'src': 'galaxy.role,1.0,name'}"
        role_str2 = "{'src': 'git+galaxy.role'}"
        role_str3 = "{'src': 'galaxy.role'}"
    else:
        role_str1 = "{'src': 'galaxy.role,1.0,name'}"
        role_str2 = "{'src': 'git+galaxy.role'}"
        role_str3 = "{'src': 'galaxy.role'}"

    role1 = eval(role_str1)
    role2 = eval(role_str2)
    role3 = eval(role_str3)

    parsed_role1 = RoleRequirement

# Generated at 2022-06-21 01:22:21.949565
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():

    import sys
    import os
    import tarfile
    from ansible.playbook.role.requirement import RoleRequirement

    path_to_role = os.path.join(sys.path[0], '..', '..', '..', 'lib')
    role = os.path.join(path_to_role, 'ansible-base')

    # create a tarball with the role and get its path
    tar = RoleRequirement.scm_archive_role(role, 'git', version='HEAD', keep_scm_meta=False)
    tar_name = tar.name

    # check if the tar is created
    assert os.path.isfile(tar_name)

    # check if the tar contains role's files
    tar_content = tarfile.open(tar_name).getnames()

# Generated at 2022-06-21 01:22:32.689514
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    print("UNIT TEST - test_RoleRequirement_scm_archive_role")
    print("UNIT TEST - RoleRequirement.scm_archive_role - git")
    print(RoleRequirement.scm_archive_role("git+git://github.com/robertdebock/ansible-role-ntp.git"))
    print("UNIT TEST - RoleRequirement.scm_archive_role - svn")
    print(RoleRequirement.scm_archive_role("svn+http://github.com/robertdebock/ansible-role-ntp.git"))
    print("UNIT TEST - RoleRequirement.scm_archive_role - hg")
    print(RoleRequirement.scm_archive_role("http://github.com/robertdebock/ansible-role-ntp.git"))


# Generated at 2022-06-21 01:22:42.487680
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    class FakeRoleDefinition:
        def __init__(self, role):
            self.role = role
    roleglob = FakeRoleDefinition("http://github.com/example/foo.git,v2,bar")
    roleglob2 = FakeRoleDefinition("http://github.com/example/foo.git")
    roleglob3 = FakeRoleDefinition("http://github.com/example/foo.git,v2")
    roleglob4 = FakeRoleDefinition("http://github.com/examplefoo.git")
    roleglob5 = FakeRoleDefinition("foo,v2,bar")
    roleglob6 = FakeRoleDefinition("foo,v2")
    roleglob7 = FakeRoleDefinition("foo")
    roleglob8 = FakeRoleDefinition("foo,v2,bar,baz")


# Generated at 2022-06-21 01:22:50.761467
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("nginx") == {"name": "nginx", "scm": None, "src": "nginx", "version": None}
    assert RoleRequirement.role_yaml_parse("git+https://github.com/cvvem/cvvem.git") == {"name": "cvvem", "scm": 'git', "src": "https://github.com/cvvem/cvvem.git", "version": None}


# Generated at 2022-06-21 01:23:01.848005
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    # Create a mock object to answer method scm_archive_resource
    class MockSCMArchiveResource(object):
        def __init__(self):
            self.name = 'mock_name'
            self.path = 'mock_path'

    class MockAnsibleModule(object):
        def __init__(self):
            self.params = dict()

    test_mock_scm_archive_resource = MockSCMArchiveResource()
    test_mock_ansible_module = MockAnsibleModule()

    # Create  mock object that overrides method scm_archive_resource
    class MockRoleRequirement(RoleRequirement):
        def __init__(self):
            self.scm_archive_resource = test_mock_scm_archive_resource
            self.AnsibleModule = test_m

# Generated at 2022-06-21 01:23:12.750335
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    import os

    # Test for src=github.com/ansible/ansible-examples
    role_obj = RoleRequirement.scm_archive_role(src="https://github.com/ansible/ansible-examples.git", name="role_requirements_1")

    assert os.path.exists(role_obj.path)
    assert role_obj.name == "role_requirements_1"
    assert role_obj.path.endswith("role_requirements_1")

    # Test for src=github.com/ansible/ansible-examples,HEAD
    role_obj = RoleRequirement.scm_archive_role(src="https://github.com/ansible/ansible-examples.git,HEAD", name="role_requirements_2")


# Generated at 2022-06-21 01:23:24.891932
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse(name) == dict(name=name, src=name, scm=None, version='')
    assert RoleRequirement.role_yaml_parse(versioned) == dict(name=name, src=name, scm=None, version=version)
    assert RoleRequirement.role_yaml_parse(named) == dict(name=name, src=name, scm=None, version=None)
    assert RoleRequirement.role_yaml_parse(named_and_versioned) == dict(name=name, src=name, scm=None, version=version)
    assert RoleRequirement.role_yaml_parse(scm_and_versioned) == dict(name=name, src=scm_and_versioned, scm=scm, version=version)


# Generated at 2022-06-21 01:23:35.693967
# Unit test for method scm_archive_role of class RoleRequirement
def test_RoleRequirement_scm_archive_role():
    assert(RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == 'repo')
    assert(RoleRequirement.repo_url_to_role_name("git.example.com/repos/repo.git") == 'repo')
    assert(RoleRequirement.repo_url_to_role_name("repo.git") == 'repo')
    assert(RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == 'repo')
    assert(RoleRequirement.repo_url_to_role_name("git.example.com/repos/repo.git,v1.0") == 'repo')