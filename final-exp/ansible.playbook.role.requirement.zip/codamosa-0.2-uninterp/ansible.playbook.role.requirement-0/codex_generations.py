

# Generated at 2022-06-17 08:07:21.783991
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role requirement
    role = 'geerlingguy.java'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] == None
    assert role_dict['version'] == None

    # Test for new style role requirement
    role = 'geerlingguy.java,1.7'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] == None
    assert role_dict['version']

# Generated at 2022-06-17 08:07:33.163439
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse('geerlingguy.java')
    assert role['name'] == 'geerlingguy.java'
    assert role['scm'] is None
    assert role['src'] == 'geerlingguy.java'
    assert role['version'] is None

    role = RoleRequirement.role_yaml_parse('geerlingguy.java,1.8')
    assert role['name'] == 'geerlingguy.java'
    assert role['scm'] is None
    assert role['src'] == 'geerlingguy.java'
    assert role['version'] == '1.8'

    role = RoleRequirement.role_yaml_parse('geerlingguy.java,1.8,java')
    assert role['name'] == 'java'

# Generated at 2022-06-17 08:07:40.560964
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1: role is a string
    role = 'geerlingguy.apache'
    expected = {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse(role) == expected

    # Test case 2: role is a string with version
    role = 'geerlingguy.apache,1.0.0'
    expected = {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse(role) == expected

    # Test case 3: role is a string with version and name

# Generated at 2022-06-17 08:07:45.125173
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:07:56.431882
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:08:08.995085
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml_parse = RoleRequirement.role_yaml_parse

    assert role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert role_yaml_parse('geerlingguy.apache,1.0.0,apache') == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert role

# Generated at 2022-06-17 08:08:21.658815
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_role.tar.gz") == "repo"

# Generated at 2022-06-17 08:08:26.364443
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role requirement
    role = "geerlingguy.java"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role requirement
    role = "geerlingguy.java,1.8"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version']

# Generated at 2022-06-17 08:08:31.614691
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:08:42.201902
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_repo.tar.gz") == "repo"

# Generated at 2022-06-17 08:09:20.019077
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = 'galaxy.role'
    r = RoleRequirement.role_yaml_parse(role)
    assert r['name'] == 'galaxy.role'
    assert r['src'] == 'galaxy.role'
    assert r['scm'] is None
    assert r['version'] is None

    # Test for new style role line
    role = 'galaxy.role,v1.0'
    r = RoleRequirement.role_yaml_parse(role)
    assert r['name'] == 'galaxy.role'
    assert r['src'] == 'galaxy.role'
    assert r['scm'] is None
    assert r['version'] == 'v1.0'

    # Test for new style role line with name

# Generated at 2022-06-17 08:09:31.768440
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:09:44.169024
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,extra") == "repo"

# Generated at 2022-06-17 08:09:55.259443
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git')
    assert role == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'scm': 'git', 'version': None}

    role = RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,v1.0')
    assert role == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'scm': 'git', 'version': 'v1.0'}


# Generated at 2022-06-17 08:10:05.146058
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = 'geerlingguy.apache'
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': None}

    role = 'geerlingguy.apache,1.0.0'
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': '1.0.0'}

    role = 'geerlingguy.apache,1.0.0,apache'
    result = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-17 08:10:13.661851
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.2.3') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.2.3'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.2.3,my_apache') == {'name': 'my_apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.2.3'}

# Generated at 2022-06-17 08:10:22.632450
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,foo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,foo,bar') == 'repo'

# Generated at 2022-06-17 08:10:34.941110
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,extra_stuff") == "repo"
    assert RoleRequirement.repo_url_to_role_name

# Generated at 2022-06-17 08:10:43.601471
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}

# Generated at 2022-06-17 08:10:52.327019
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:11:30.573349
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}
    assert role_requirement.role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert role_requirement.role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert role_

# Generated at 2022-06-17 08:11:42.344406
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,myname.tar.gz") == "repo"

# Generated at 2022-06-17 08:11:51.838312
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_role.tar.gz") == "repo"

# Generated at 2022-06-17 08:12:00.445329
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = 'role_name'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}

    # Test for new style role line
    role = 'role_name,version'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': 'version'}

    # Test for new style role line with name
    role = 'role_name,version,name'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'name', 'src': 'role_name', 'scm': None, 'version': 'version'}



# Generated at 2022-06-17 08:12:14.430975
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:12:21.039599
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0,my_name.tar.gz") == "repo"

# Generated at 2022-06-17 08:12:31.222339
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:12:39.380026
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:12:51.234032
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:13:03.101439
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style
    role = "geerlingguy.java"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    role = "geerlingguy.java,1.7"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] == '1.7'


# Generated at 2022-06-17 08:13:23.947859
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'role_name'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = {'role': 'role_name'}
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition

# Generated at 2022-06-17 08:13:35.597493
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.1.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.1.tar.gz,foo') == 'repo'

# Generated at 2022-06-17 08:13:45.035635
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:13:57.399990
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role_line = 'geerlingguy.apache'
    role = RoleRequirement.role_yaml_parse(role_line)
    assert role['name'] == 'geerlingguy.apache'
    assert role['src'] == 'geerlingguy.apache'
    assert role['scm'] is None
    assert role['version'] is None

    # Test for new style role line
    role_line = 'geerlingguy.apache,1.0.0'
    role = RoleRequirement.role_yaml_parse(role_line)
    assert role['name'] == 'geerlingguy.apache'
    assert role['src'] == 'geerlingguy.apache'
    assert role['scm'] is None
    assert role['version'] == '1.0.0'

   

# Generated at 2022-06-17 08:14:09.900777
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:14:21.941284
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:14:28.831315
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.8') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.8'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.8,java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.8'}

# Generated at 2022-06-17 08:14:39.092365
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1: role_yaml_parse(role)
    role = "geerlingguy.apache"
    expected = {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    actual = RoleRequirement.role_yaml_parse(role)
    assert expected == actual

    # Test case 2: role_yaml_parse(role)
    role = "geerlingguy.apache,1.9.0"
    expected = {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.9.0'}
    actual = RoleRequirement.role_yaml_parse(role)
    assert expected == actual

    # Test case 3: role_y

# Generated at 2022-06-17 08:14:48.949609
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "geerlingguy.java"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}

    # Test for new style role definition
    role = {'role': 'geerlingguy.java'}
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}

    # Test for new style role definition with version
    role = {'role': 'geerlingguy.java,1.7'}


# Generated at 2022-06-17 08:14:59.408398
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = "geerlingguy.java"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role line
    role = "geerlingguy.java,1.7"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version']

# Generated at 2022-06-17 08:15:55.924392
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role requirement
    role = 'role_name'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role requirement
    role = dict(role='role_name')
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role requirement with version

# Generated at 2022-06-17 08:16:04.044705
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "git+https://github.com/ansible/ansible-examples.git,v1.0,example_role"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'example_role'
    assert role_dict['src'] == 'https://github.com/ansible/ansible-examples.git'
    assert role_dict['scm'] == 'git'
    assert role_dict['version'] == 'v1.0'

    # Test for new style role definition
    role = dict(src='git+https://github.com/ansible/ansible-examples.git,v1.0,example_role')
    role_dict = RoleRequirement.role_yaml_parse(role)
   

# Generated at 2022-06-17 08:16:12.442124
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = 'geerlingguy.jenkins'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.jenkins'
    assert role_dict['src'] == 'geerlingguy.jenkins'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role line
    role = 'geerlingguy.jenkins,v1.0.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.jenkins'
    assert role_dict['src'] == 'geerlingguy.jenkins'
    assert role_dict['scm'] is None

# Generated at 2022-06-17 08:16:22.639541
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': ''}
    assert role_requirement.role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': '1.7'}
    assert role_requirement.role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'scm': None, 'src': 'geerlingguy.java', 'version': '1.7'}
    assert role_

# Generated at 2022-06-17 08:16:33.581474
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:16:39.237651
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache") == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.0.0") == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.0.0,my_apache") == {'name': 'my_apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}

# Generated at 2022-06-17 08:16:49.632591
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse("geerlingguy.apache") == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': ''}
    assert role_requirement.role_yaml_parse("geerlingguy.apache,v1.0.0") == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': 'v1.0.0'}

# Generated at 2022-06-17 08:17:00.160995
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement()
    assert role.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    assert role.role_yaml_parse('geerlingguy.apache,v1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.0.0'}
    assert role.role_yaml_parse('geerlingguy.apache,v1.0.0,apache') == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.0.0'}