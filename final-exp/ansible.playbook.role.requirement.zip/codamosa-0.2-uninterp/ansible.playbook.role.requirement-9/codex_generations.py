

# Generated at 2022-06-17 08:07:13.157913
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,foo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,foo,bar') == 'repo'

# Generated at 2022-06-17 08:07:22.516798
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git@github.com:username/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/username/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/username/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/username/repo.git,v1.0,myrole") == "repo"

# Generated at 2022-06-17 08:07:33.550032
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:07:42.217192
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,name') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,name,v2.0') == 'repo'

# Generated at 2022-06-17 08:07:50.651361
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'role_name'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    role = 'role_name,v1.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] == 'v1.0'

    role = 'role_name,v1.0,new_name'


# Generated at 2022-06-17 08:07:59.866023
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:08:10.848691
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0,my_role.tar.gz') == 'repo'

# Generated at 2022-06-17 08:08:22.626826
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_role.tar.gz") == "repo"

# Generated at 2022-06-17 08:08:26.515584
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_name.tar.gz") == "repo"

# Generated at 2022-06-17 08:08:31.714046
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:08:58.306053
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,foobar.tar.gz") == "repo"

# Generated at 2022-06-17 08:09:06.777110
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache") == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.0.0") == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.0.0,apache") == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml

# Generated at 2022-06-17 08:09:18.858461
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:09:31.405900
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test for string type
    role = 'git+https://github.com/ansible/ansible-examples.git,v1.0.0,ansible-examples'
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == 'ansible-examples'
    assert result['src'] == 'https://github.com/ansible/ansible-examples.git'
    assert result['scm'] == 'git'
    assert result['version'] == 'v1.0.0'

    # test for dict type
    role = {'role': 'git+https://github.com/ansible/ansible-examples.git,v1.0.0,ansible-examples'}
    result = RoleRequirement.role_yaml_parse(role)
    assert result

# Generated at 2022-06-17 08:09:43.653706
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:09:54.524464
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0,foo.tar.gz') == 'repo'

# Generated at 2022-06-17 08:10:04.793052
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:10:15.900930
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse('geerlingguy.apache')
    assert role['name'] == 'geerlingguy.apache'
    assert role['src'] == 'geerlingguy.apache'
    assert role['scm'] is None
    assert role['version'] == ''

    role = RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.0.0')
    assert role['name'] == 'geerlingguy.apache'
    assert role['src'] == 'geerlingguy.apache'
    assert role['scm'] is None
    assert role['version'] == 'v1.0.0'

    role = RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.0.0,apache')

# Generated at 2022-06-17 08:10:30.265331
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0,my_name.tar.gz") == "repo"

# Generated at 2022-06-17 08:10:39.371023
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for method role_yaml_parse of class RoleRequirement
    #
    # Test for old style role line
    role = "geerlingguy.apache"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == dict(name='geerlingguy.apache', src=None, scm=None, version=None)

    # Test for new style role line
    role = "geerlingguy.apache,v1.0.0"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == dict(name='geerlingguy.apache', src=None, scm=None, version='v1.0.0')

    # Test for new style role line with name

# Generated at 2022-06-17 08:10:53.850409
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_name.tar.gz") == "repo"

# Generated at 2022-06-17 08:11:05.036670
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role requirement
    role = 'role_name'
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == 'role_name'
    assert result['scm'] is None
    assert result['src'] == 'role_name'
    assert result['version'] is None

    # Test for new style role requirement
    role = dict(src='role_name')
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == 'role_name'
    assert result['scm'] is None
    assert result['src'] == 'role_name'
    assert result['version'] is None

    # Test for new style role requirement with version
    role = dict(src='role_name,1.0')
    result = RoleRequirement.role_

# Generated at 2022-06-17 08:11:16.060827
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = 'geerlingguy.apache'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role line
    role = 'geerlingguy.apache,1.0.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None

# Generated at 2022-06-17 08:11:30.147512
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.0.0'}

# Generated at 2022-06-17 08:11:39.098211
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1: role_yaml_parse(role)
    role = 'git+https://github.com/ansible/ansible-examples.git,v1.0.4,ansible-examples'
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'ansible-examples', 'src': 'https://github.com/ansible/ansible-examples.git,v1.0.4', 'scm': 'git', 'version': None}

    # Test case 2: role_yaml_parse(role)
    role = 'git+https://github.com/ansible/ansible-examples.git,v1.0.4'
    result = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-17 08:11:47.846794
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for role_yaml_parse method of class RoleRequirement
    # Test for old style role definition
    role = "role_name"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': ''}

    # Test for new style role definition
    role = {'role': 'role_name'}
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': ''}

    # Test for new style role definition with version
    role = {'role': 'role_name,1.0'}
    role_dict

# Generated at 2022-06-17 08:11:51.749945
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"

# Generated at 2022-06-17 08:11:59.502478
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0,apache') == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml

# Generated at 2022-06-17 08:12:04.438185
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:12:10.244337
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse('geerlingguy.java')
    assert role['name'] == 'geerlingguy.java'
    assert role['src'] == 'geerlingguy.java'
    assert role['scm'] is None
    assert role['version'] is None

    role = RoleRequirement.role_yaml_parse('geerlingguy.java,1.8')
    assert role['name'] == 'geerlingguy.java'
    assert role['src'] == 'geerlingguy.java'
    assert role['scm'] is None
    assert role['version'] == '1.8'

    role = RoleRequirement.role_yaml_parse('geerlingguy.java,1.8,java')
    assert role['name'] == 'java'
    assert role['src']

# Generated at 2022-06-17 08:12:31.064667
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,myrole') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,myrole,v2.0') == 'repo'

# Generated at 2022-06-17 08:12:41.495190
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:12:51.747687
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git') == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,v1.0') == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'scm': None, 'version': 'v1.0'}

# Generated at 2022-06-17 08:13:03.623347
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0,my_name.tar.gz") == "repo"

# Generated at 2022-06-17 08:13:11.957971
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0,my_apache') == {'name': 'my_apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}

# Generated at 2022-06-17 08:13:22.644735
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "role_name"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}

    role = "role_name,version"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': 'version'}

    role = "role_name,version,name"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'name', 'src': 'role_name', 'scm': None, 'version': 'version'}


# Generated at 2022-06-17 08:13:30.782712
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0,my_role.tar.gz') == 'repo'

# Generated at 2022-06-17 08:13:40.815904
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:13:53.462403
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:14:02.344985
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('role_name') == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': ''}
    assert role_requirement.role_yaml_parse('role_name,v1') == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': 'v1'}
    assert role_requirement.role_yaml_parse('role_name,v1,name') == {'name': 'name', 'src': 'role_name', 'scm': None, 'version': 'v1'}

# Generated at 2022-06-17 08:14:38.046058
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("role_name") == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse("role_name,v1") == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': 'v1'}
    assert RoleRequirement.role_yaml_parse("role_name,v1,name") == {'name': 'name', 'src': 'role_name', 'scm': None, 'version': 'v1'}

# Generated at 2022-06-17 08:14:48.304551
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml_parse = RoleRequirement.role_yaml_parse
    assert role_yaml_parse('foo') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': ''}
    assert role_yaml_parse('foo,bar') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': 'bar'}
    assert role_yaml_parse('foo,bar,baz') == {'name': 'baz', 'src': 'foo', 'scm': None, 'version': 'bar'}
    assert role_yaml_parse('git+https://github.com/foo/bar') == {'name': 'bar', 'src': 'https://github.com/foo/bar', 'scm': 'git', 'version': ''}
   

# Generated at 2022-06-17 08:14:59.356704
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test for old style role
    role = 'role_name'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}

    # test for new style role
    role = 'role_name,version'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': 'version'}

    # test for new style role
    role = 'role_name,version,name'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'name', 'src': 'role_name', 'scm': None, 'version': 'version'}

    # test for new

# Generated at 2022-06-17 08:15:09.928747
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for string input
    assert RoleRequirement.role_yaml_parse('http://github.com/user/repo.git,v1.0,role_name') == {'name': 'role_name', 'scm': 'git', 'src': 'http://github.com/user/repo.git', 'version': 'v1.0'}
    assert RoleRequirement.role_yaml_parse('http://github.com/user/repo.git,v1.0') == {'name': 'repo', 'scm': 'git', 'src': 'http://github.com/user/repo.git', 'version': 'v1.0'}

# Generated at 2022-06-17 08:15:17.151781
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for method role_yaml_parse of class RoleRequirement
    # Test for old style role definition
    role = 'geerlingguy.apache'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}

    # Test for new style role definition
    role = {'role': 'geerlingguy.apache'}
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}

    # Test for new style role definition with version
    role = {'role': 'geerlingguy.apache,1.0.0'}

# Generated at 2022-06-17 08:15:31.001014
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:15:42.380271
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = "geerlingguy.java"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role line
    role = "geerlingguy.java,1.8"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version']

# Generated at 2022-06-17 08:15:55.206245
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}
    assert role_requirement.role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert role_requirement.role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert role_

# Generated at 2022-06-17 08:16:06.873366
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role requirement
    role = 'role_name'
    assert RoleRequirement.role_yaml_parse(role) == dict(name='role_name', src=None, scm=None, version=None)

    # Test for new style role requirement
    role = dict(role='role_name')
    assert RoleRequirement.role_yaml_parse(role) == dict(name='role_name', src=None, scm=None, version=None)

    # Test for new style role requirement with version
    role = dict(role='role_name,1.0')
    assert RoleRequirement.role_yaml_parse(role) == dict(name='role_name', src=None, scm=None, version='1.0')

    # Test for new style role requirement with version and name
    role = dict

# Generated at 2022-06-17 08:16:20.302131
# Unit test for method role_yaml_parse of class RoleRequirement