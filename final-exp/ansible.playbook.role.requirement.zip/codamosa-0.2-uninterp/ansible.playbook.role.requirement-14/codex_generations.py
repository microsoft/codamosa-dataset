

# Generated at 2022-06-17 08:07:29.922342
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:07:40.015583
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "role_name"
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'role_name', 'scm': None, 'src': 'role_name', 'version': None}

    role = "role_name,version"
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'role_name', 'scm': None, 'src': 'role_name', 'version': 'version'}

    role = "role_name,version,name"
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'name', 'scm': None, 'src': 'role_name', 'version': 'version'}

    role = "role_name,version,name,extra"

# Generated at 2022-06-17 08:07:44.784625
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:07:56.430663
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,myname') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,myname,v2.0') == 'repo'

# Generated at 2022-06-17 08:08:08.995111
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,extra") == "repo"

# Generated at 2022-06-17 08:08:21.665784
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role requirement
    role = 'role_name'
    role_yaml_parse_result = RoleRequirement.role_yaml_parse(role)
    assert role_yaml_parse_result['name'] == 'role_name'
    assert role_yaml_parse_result['src'] == 'role_name'
    assert role_yaml_parse_result['scm'] is None
    assert role_yaml_parse_result['version'] is None

    # Test for new style role requirement
    role = 'role_name,version'
    role_yaml_parse_result = RoleRequirement.role_yaml_parse(role)
    assert role_yaml_parse_result['name'] == 'role_name'
    assert role_yaml_parse_result['src'] == 'role_name'


# Generated at 2022-06-17 08:08:31.036713
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test 1: Test with a string
    role = "geerlingguy.apache"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}

    # Test 2: Test with a dictionary
    role = {'role': 'geerlingguy.apache'}
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}

    # Test 3: Test with a dictionary
    role = {'role': 'geerlingguy.apache', 'version': '1.0.0'}
   

# Generated at 2022-06-17 08:08:42.188865
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = 'galaxy.role'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'galaxy.role'
    assert role_dict['src'] == 'galaxy.role'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role line
    role = 'galaxy.role,1.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'galaxy.role'
    assert role_dict['src'] == 'galaxy.role'
    assert role_dict['scm'] is None
    assert role_dict['version'] == '1.0'

    # Test for new

# Generated at 2022-06-17 08:08:46.618598
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0')
    assert role['name'] == 'geerlingguy.apache'
    assert role['version'] == '1.0.0'
    assert role['src'] == 'geerlingguy.apache'
    assert role['scm'] is None

    role = RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0,my_apache')
    assert role['name'] == 'my_apache'
    assert role['version'] == '1.0.0'
    assert role['src'] == 'geerlingguy.apache'
    assert role['scm'] is None

    role = RoleRequirement.role_yaml_parse('geerlingguy.apache')
    assert role['name']

# Generated at 2022-06-17 08:08:57.358939
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role_line = 'geerlingguy.java'
    role_dict = RoleRequirement.role_yaml_parse(role_line)
    assert role_dict == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}

    # Test for new style role line
    role_line = 'geerlingguy.java,1.7'
    role_dict = RoleRequirement.role_yaml_parse(role_line)
    assert role_dict == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}

    # Test for new style role line with name

# Generated at 2022-06-17 08:09:10.366057
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('foo') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('foo,v1') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': 'v1'}
    assert RoleRequirement.role_yaml_parse('foo,v1,bar') == {'name': 'bar', 'src': 'foo', 'scm': None, 'version': 'v1'}

# Generated at 2022-06-17 08:09:19.386535
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:09:31.541114
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_repo.tar.gz") == "repo"

# Generated at 2022-06-17 08:09:43.868447
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0,my-apache') == {'name': 'my-apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}

# Generated at 2022-06-17 08:09:52.427844
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,foobar") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,foobar,baz") == "repo"

# Generated at 2022-06-17 08:10:04.132877
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for role_yaml_parse with string
    role = "geerlingguy.apache"
    role_yaml_parse_result = RoleRequirement.role_yaml_parse(role)
    assert role_yaml_parse_result == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': None}

    role = "geerlingguy.apache,v1.8.0"
    role_yaml_parse_result = RoleRequirement.role_yaml_parse(role)
    assert role_yaml_parse_result == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': 'v1.8.0'}


# Generated at 2022-06-17 08:10:13.304835
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0,my_repo.tar.gz') == 'repo'

# Generated at 2022-06-17 08:10:22.357501
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_name.tar.gz") == "repo"

# Generated at 2022-06-17 08:10:34.504517
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "role_name"
    assert RoleRequirement.role_yaml_parse(role) == dict(name="role_name", src="role_name", scm=None, version=None)

    # Test for new style role definition
    role = dict(role="role_name")
    assert RoleRequirement.role_yaml_parse(role) == dict(name="role_name", src="role_name", scm=None, version=None)

    # Test for new style role definition with version
    role = dict(role="role_name,1.0")
    assert RoleRequirement.role_yaml_parse(role) == dict(name="role_name", src="role_name", scm=None, version="1.0")

    # Test for new style role definition with version and

# Generated at 2022-06-17 08:10:41.480586
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:10:54.721695
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for string type
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.0.0,apache') == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.0.0'}

# Generated at 2022-06-17 08:11:00.447758
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}

# Generated at 2022-06-17 08:11:08.516952
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.2.3') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': 'v1.2.3'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.2.3,my_apache') == {'name': 'my_apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': 'v1.2.3'}

# Generated at 2022-06-17 08:11:19.977158
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.0.0') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': 'v1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.0.0,apache') == {'name': 'apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': 'v1.0.0'}

# Generated at 2022-06-17 08:11:32.479434
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role requirement
    role = 'git+https://github.com/geerlingguy/ansible-role-apache.git,v1.0.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'ansible-role-apache', 'src': 'https://github.com/geerlingguy/ansible-role-apache.git', 'scm': 'git', 'version': 'v1.0.0'}

    # Test for new style role requirement
    role = {'src': 'git+https://github.com/geerlingguy/ansible-role-apache.git,v1.0.0'}
    role_dict = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-17 08:11:40.700937
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': '1.7'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'scm': None, 'src': 'geerlingguy.java', 'version': '1.7'}

# Generated at 2022-06-17 08:11:51.917005
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:12:02.914555
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = 'role_name'
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == 'role_name'
    assert result['src'] == 'role_name'
    assert result['scm'] is None
    assert result['version'] is None

    # Test for new style role line with version
    role = 'role_name,1.0'
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == 'role_name'
    assert result['src'] == 'role_name'
    assert result['scm'] is None
    assert result['version'] == '1.0'

    # Test for new style role line with version and name
    role = 'role_name,1.0,my_role'

# Generated at 2022-06-17 08:12:14.642574
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'role_name'
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}

    # Test for new style role definition
    role = {'role': 'role_name'}
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}

    # Test for new style role definition with version
    role = {'role': 'role_name,1.0'}
    result = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-17 08:12:20.103278
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_role.tar.gz") == "repo"

# Generated at 2022-06-17 08:12:39.619805
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = 'galaxy.role'
    assert RoleRequirement.role_yaml_parse(role) == dict(name='galaxy.role', src='galaxy.role', scm=None, version='')

    # Test for old style role line with version
    role = 'galaxy.role,v1.0'
    assert RoleRequirement.role_yaml_parse(role) == dict(name='galaxy.role', src='galaxy.role', scm=None, version='v1.0')

    # Test for old style role line with version and name
    role = 'galaxy.role,v1.0,my_galaxy_role'

# Generated at 2022-06-17 08:12:51.399980
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = 'geerlingguy.apache'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] == None
    assert role_dict['version'] == None

    role = 'geerlingguy.apache,v1.0.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] == None
    assert role_dict['version'] == 'v1.0.0'


# Generated at 2022-06-17 08:13:02.133743
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml_parse = RoleRequirement.role_yaml_parse
    assert role_yaml_parse('foo') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': None}
    assert role_yaml_parse('foo,bar') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': 'bar'}
    assert role_yaml_parse('foo,bar,baz') == {'name': 'baz', 'src': 'foo', 'scm': None, 'version': 'bar'}
    assert role_yaml_parse('git+https://github.com/foo/bar') == {'name': 'bar', 'src': 'https://github.com/foo/bar', 'scm': 'git', 'version': None}
   

# Generated at 2022-06-17 08:13:08.088810
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "role_name,version,name"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['version'] == 'version'
    assert role_dict['scm'] is None

    # Test for new style role definition
    role = dict(role='role_name,version,name')
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['version'] == 'version'
    assert role_dict['scm'] is None

    # Test for new style role definition

# Generated at 2022-06-17 08:13:19.853186
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "role_name"
    assert RoleRequirement.role_yaml_parse(role) == dict(name="role_name", src=None, scm=None, version=None)

    role = "role_name,version"
    assert RoleRequirement.role_yaml_parse(role) == dict(name="role_name", src=None, scm=None, version="version")

    role = "role_name,version,name"
    assert RoleRequirement.role_yaml_parse(role) == dict(name="name", src=None, scm=None, version="version")

    # Test for new style role definition
    role = dict(role="role_name")

# Generated at 2022-06-17 08:13:28.140442
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}

# Generated at 2022-06-17 08:13:38.269893
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0,apache') == {'name': 'apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': '1.0.0'}
    assert RoleRequirement.role_yaml

# Generated at 2022-06-17 08:13:45.360712
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,myrole') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,myrole,v2.0') == 'repo'

# Generated at 2022-06-17 08:13:57.648915
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test case 1: role_yaml_parse(role)
    role = 'git+https://github.com/ansible/ansible-examples.git,v1.0,example'
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'example', 'src': 'https://github.com/ansible/ansible-examples.git', 'scm': 'git', 'version': 'v1.0'}

    # Test case 2: role_yaml_parse(role)
    role = 'https://github.com/ansible/ansible-examples.git,v1.0,example'
    result = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-17 08:14:09.900418
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role_yaml_parse = role_requirement.role_yaml_parse
    assert role_yaml_parse('foo') == dict(name='foo', src='foo', scm=None, version='')
    assert role_yaml_parse('foo,v1') == dict(name='foo', src='foo', scm=None, version='v1')
    assert role_yaml_parse('foo,v1,bar') == dict(name='bar', src='foo', scm=None, version='v1')
    assert role_yaml_parse('git+https://github.com/foo/bar.git') == dict(name='bar', src='https://github.com/foo/bar.git', scm='git', version='')
    assert role_yaml_parse

# Generated at 2022-06-17 08:15:08.369349
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role
    role = 'geerlingguy.java'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] == ''

    # Test for new style role
    role = 'geerlingguy.java,1.8'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None

# Generated at 2022-06-17 08:15:17.328613
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache") == dict(name="geerlingguy.apache", src="geerlingguy.apache", scm=None, version=None)
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.0.0") == dict(name="geerlingguy.apache", src="geerlingguy.apache", scm=None, version="1.0.0")
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.0.0,apache") == dict(name="apache", src="geerlingguy.apache", scm=None, version="1.0.0")

# Generated at 2022-06-17 08:15:31.074115
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1
    role = 'geerlingguy.java'
    expected_result = {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': None}
    result = RoleRequirement.role_yaml_parse(role)
    assert result == expected_result

    # Test case 2
    role = 'geerlingguy.java,1.8'
    expected_result = {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': '1.8'}
    result = RoleRequirement.role_yaml_parse(role)
    assert result == expected_result

    # Test case 3
    role = 'geerlingguy.java,1.8,java'
   

# Generated at 2022-06-17 08:15:38.068122
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement()
    assert role.role_yaml_parse("geerlingguy.apache") == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    assert role.role_yaml_parse("geerlingguy.apache,v1.0.0") == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.0.0'}
    assert role.role_yaml_parse("geerlingguy.apache,v1.0.0,apache") == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.0.0'}

# Generated at 2022-06-17 08:15:49.856187
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "role_name"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == role
    assert role_dict['src'] == role
    assert role_dict['scm'] == None
    assert role_dict['version'] == None

    # Test for new style role definition
    role = "role_name,version"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == "role_name"
    assert role_dict['src'] == "role_name"
    assert role_dict['scm'] == None
    assert role_dict['version'] == "version"

    # Test for new style role definition
    role = "role_name,version,name"
   

# Generated at 2022-06-17 08:15:59.857134
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1:
    # Input:
    #   role: "galaxy.role,version,name"
    # Expected output:
    #   {'name': 'name', 'src': 'galaxy.role', 'scm': None, 'version': 'version'}
    role = "galaxy.role,version,name"
    expected_output = {'name': 'name', 'src': 'galaxy.role', 'scm': None, 'version': 'version'}
    assert RoleRequirement.role_yaml_parse(role) == expected_output

    # Test case 2:
    # Input:
    #   role: "galaxy.role,version"
    # Expected output:
    #   {'name': 'galaxy.role', 'src': 'galaxy.role', 'scm': None, '

# Generated at 2022-06-17 08:16:10.429829
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.2.3') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.2.3'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.2.3,foo') == {'name': 'foo', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.2.3'}

# Generated at 2022-06-17 08:16:21.441975
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style
    role = 'role_name'
    assert RoleRequirement.role_yaml_parse(role) == dict(name='role_name', src='role_name', scm=None, version='')

    role = 'role_name,version'
    assert RoleRequirement.role_yaml_parse(role) == dict(name='role_name', src='role_name', scm=None, version='version')

    role = 'role_name,version,name'
    assert RoleRequirement.role_yaml_parse(role) == dict(name='name', src='role_name', scm=None, version='version')

    role = 'role_name,version,name,extra'

# Generated at 2022-06-17 08:16:33.496560
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('role_name') == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': ''}
    assert role_requirement.role_yaml_parse('role_name,v1') == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': 'v1'}
    assert role_requirement.role_yaml_parse('role_name,v1,my_name') == {'name': 'my_name', 'src': 'role_name', 'scm': None, 'version': 'v1'}

# Generated at 2022-06-17 08:16:42.915051
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1:
    # Input:
    #   role = "geerlingguy.java"
    # Expected output:
    #   {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': ''}
    role = "geerlingguy.java"
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': ''}

    # Test case 2:
    # Input:
    #   role = "geerlingguy.java,1.8.0"
    # Expected output:
    #   {'name': 'geerlingguy.java', 'scm': None, 'src': 'ge