

# Generated at 2022-06-17 08:07:22.593205
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:07:33.640693
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:07:45.884775
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,myrole') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,myrole,v2.0') == 'repo'

# Generated at 2022-06-17 08:07:57.100201
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:08:09.028740
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0") == "repo"

# Generated at 2022-06-17 08:08:21.696406
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:08:28.604464
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:08:35.378576
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement()
    assert role.role_yaml_parse("geerlingguy.apache") == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    assert role.role_yaml_parse("geerlingguy.apache,v1.2.3") == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.2.3'}
    assert role.role_yaml_parse("geerlingguy.apache,v1.2.3,my_apache") == {'name': 'my_apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.2.3'}


# Generated at 2022-06-17 08:08:47.239835
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0,my_repo.tar.gz') == 'repo'

# Generated at 2022-06-17 08:08:57.466643
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:09:30.178546
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,name.tar.gz") == "repo"

# Generated at 2022-06-17 08:09:40.279045
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,myname') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,myname,v2.0') == 'repo'

# Generated at 2022-06-17 08:09:50.513762
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0,myrole.tar.gz') == 'repo'

# Generated at 2022-06-17 08:10:03.241242
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role requirement
    role = 'role_name'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}

    # Test for new style role requirement
    role = {'role': 'role_name'}
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}

    # Test for new style role requirement
    role = {'role': 'role_name', 'version': '1.0'}

# Generated at 2022-06-17 08:10:12.757997
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:10:17.792340
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse("geerlingguy.apache")
    assert role == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}

    role = RoleRequirement.role_yaml_parse("geerlingguy.apache,v1.2.3")
    assert role == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.2.3'}

    role = RoleRequirement.role_yaml_parse("geerlingguy.apache,v1.2.3,apache")

# Generated at 2022-06-17 08:10:30.590001
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}

# Generated at 2022-06-17 08:10:39.509278
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache") == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.0.0") == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.0.0,my_apache") == {'name': 'my_apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}

# Generated at 2022-06-17 08:10:50.577018
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:11:00.140811
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0,apache') == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml

# Generated at 2022-06-17 08:11:17.132587
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:11:30.619522
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0,foo.tar.gz') == 'repo'

# Generated at 2022-06-17 08:11:42.340817
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.2.3') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': 'v1.2.3'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.2.3,my_apache') == {'name': 'my_apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': 'v1.2.3'}

# Generated at 2022-06-17 08:11:53.511996
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse("geerlingguy.apache")
    assert role == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}

    role = RoleRequirement.role_yaml_parse("geerlingguy.apache,v1.2.3")
    assert role == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.2.3'}

    role = RoleRequirement.role_yaml_parse("geerlingguy.apache,v1.2.3,apache")

# Generated at 2022-06-17 08:12:01.609634
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'geerlingguy.java'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = dict(src='geerlingguy.java')
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None

# Generated at 2022-06-17 08:12:14.545336
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:12:21.039071
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "geerlingguy.java"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] == ''

    # Test for new style role definition
    role = "geerlingguy.java,1.8"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version']

# Generated at 2022-06-17 08:12:31.226313
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1: role_yaml_parse(role)
    role = 'git+https://github.com/ansible/ansible-examples.git,v1.0.0,example_role'
    role_yaml_parse_result = RoleRequirement.role_yaml_parse(role)
    assert role_yaml_parse_result == {'name': 'example_role', 'scm': 'git', 'src': 'https://github.com/ansible/ansible-examples.git', 'version': 'v1.0.0'}

    # Test case 2: role_yaml_parse(role)
    role = 'https://github.com/ansible/ansible-examples.git,v1.0.0,example_role'

# Generated at 2022-06-17 08:12:39.379474
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache") == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': None}
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.2.3") == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': '1.2.3'}
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.2.3,foo") == {'name': 'foo', 'scm': None, 'src': 'geerlingguy.apache', 'version': '1.2.3'}
    assert RoleRequirement.role_yaml

# Generated at 2022-06-17 08:12:51.238505
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse("geerlingguy.java")
    assert role == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}

    role = RoleRequirement.role_yaml_parse("geerlingguy.java,1.7")
    assert role == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}

    role = RoleRequirement.role_yaml_parse("geerlingguy.java,1.7,java")
    assert role == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}


# Generated at 2022-06-17 08:13:31.044628
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for method role_yaml_parse of class RoleRequirement
    #
    # Test for old style role definition
    role = "geerlingguy.java"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}

    # Test for new style role definition
    role = {'src': 'geerlingguy.java'}
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}

    # Test for new style role definition with version
   

# Generated at 2022-06-17 08:13:41.063028
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test for old style role definition
    role = "role_name"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = "role_name,version"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] == 'version'

    # Test for new style role definition

# Generated at 2022-06-17 08:13:53.836776
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'test_role'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'test_role'
    assert role_dict['src'] == 'test_role'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = 'test_role,v1.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'test_role'
    assert role_dict['src'] == 'test_role'
    assert role_dict['scm'] is None
    assert role_dict['version'] == 'v1.0'

    # Test for new style role definition


# Generated at 2022-06-17 08:14:02.372679
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1:
    #   input:
    #       role = 'git+https://github.com/geerlingguy/ansible-role-apache.git,v1.0.0'
    #   expected:
    #       {'name': 'ansible-role-apache', 'src': 'https://github.com/geerlingguy/ansible-role-apache.git', 'scm': 'git', 'version': 'v1.0.0'}
    role = 'git+https://github.com/geerlingguy/ansible-role-apache.git,v1.0.0'

# Generated at 2022-06-17 08:14:11.033017
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1:
    #   Input:
    #       role = 'geerlingguy.apache'
    #   Output:
    #       role = {
    #           'name': 'geerlingguy.apache',
    #           'src': 'geerlingguy.apache',
    #           'scm': None,
    #           'version': ''
    #       }
    role = 'geerlingguy.apache'
    expected_role = {
        'name': 'geerlingguy.apache',
        'src': 'geerlingguy.apache',
        'scm': None,
        'version': ''
    }
    assert RoleRequirement.role_yaml_parse(role) == expected_role

    # Test case 2:
    #   Input:
    #       role = 'geerlingguy.

# Generated at 2022-06-17 08:14:19.309269
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'role_name'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = 'role_name,1.0.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] == '1.0.0'

    # Test for new style role

# Generated at 2022-06-17 08:14:28.125121
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement()
    assert role.role_yaml_parse("geerlingguy.java") == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}
    assert role.role_yaml_parse("geerlingguy.java,1.8") == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.8'}
    assert role.role_yaml_parse("geerlingguy.java,1.8,java") == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.8'}

# Generated at 2022-06-17 08:14:39.037321
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("http://git.example.com/repos/repo.git") == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse("http://git.example.com/repos/repo.git,v1.0") == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'scm': None, 'version': 'v1.0'}

# Generated at 2022-06-17 08:14:48.884922
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for string
    role = "geerlingguy.apache"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}

    role = "geerlingguy.apache,v1.0.0"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.0.0'}

    role = "geerlingguy.apache,v1.0.0,apache"
    role_dict = RoleRequirement.role_yaml_

# Generated at 2022-06-17 08:14:59.383878
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role requirement
    role = "geerlingguy.java"
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == "geerlingguy.java"
    assert result['src'] == "geerlingguy.java"
    assert result['scm'] is None
    assert result['version'] is None

    # Test for new style role requirement
    role = dict(src="geerlingguy.java,1.8")
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == "geerlingguy.java"
    assert result['src'] == "geerlingguy.java"
    assert result['scm'] is None
    assert result['version'] == "1.8"

    # Test for new style role requirement with name

# Generated at 2022-06-17 08:15:31.385432
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1:
    #   Input:
    #       role: "https://github.com/geerlingguy/ansible-role-apache.git,v1.0.0"
    #   Expected result:
    #       {'name': 'ansible-role-apache', 'src': 'https://github.com/geerlingguy/ansible-role-apache.git', 'scm': 'git', 'version': 'v1.0.0'}
    role = "https://github.com/geerlingguy/ansible-role-apache.git,v1.0.0"

# Generated at 2022-06-17 08:15:42.854136
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role requirement
    role_old_style = 'galaxy.role'
    role_old_style_result = RoleRequirement.role_yaml_parse(role_old_style)
    assert role_old_style_result == dict(name='galaxy.role', src='galaxy.role', scm=None, version='')

    # Test for new style role requirement
    role_new_style = dict(role='galaxy.role')
    role_new_style_result = RoleRequirement.role_yaml_parse(role_new_style)
    assert role_new_style_result == dict(name='galaxy.role', src='galaxy.role', scm=None, version='')

    # Test for new style role requirement with version

# Generated at 2022-06-17 08:15:55.392947
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'geerlingguy.java'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for old style role definition with version
    role = 'geerlingguy.java,1.8'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None

# Generated at 2022-06-17 08:16:03.644824
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test for string_types
    role = 'test_role'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'test_role'
    assert role_dict['src'] == 'test_role'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    role = 'test_role,v1.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'test_role'
    assert role_dict['src'] == 'test_role'
    assert role_dict['scm'] is None
    assert role_dict['version'] == 'v1.0'

    role = 'test_role,v1.0,test_role_name'

# Generated at 2022-06-17 08:16:12.363044
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:16:22.701855
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache") == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.0.0") == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse("geerlingguy.apache,1.0.0,apache") == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml

# Generated at 2022-06-17 08:16:33.581783
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "geerlingguy.apache"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict["name"] == "geerlingguy.apache"
    assert role_dict["src"] == "geerlingguy.apache"
    assert role_dict["scm"] is None
    assert role_dict["version"] is None

    # Test for new style role definition
    role = "geerlingguy.apache,1.9.0"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict["name"] == "geerlingguy.apache"
    assert role_dict["src"] == "geerlingguy.apache"
    assert role_dict["scm"] is None

# Generated at 2022-06-17 08:16:43.028589
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml_parse = RoleRequirement.role_yaml_parse

    # Test for old style role definition
    assert role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': None}
    assert role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': '1.0.0'}

# Generated at 2022-06-17 08:16:50.484959
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:17:01.191522
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('foo') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('foo,bar') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': 'bar'}
    assert RoleRequirement.role_yaml_parse('foo,bar,baz') == {'name': 'baz', 'src': 'foo', 'scm': None, 'version': 'bar'}
    assert RoleRequirement.role_yaml_parse('git+https://github.com/foo/bar.git') == {'name': 'bar', 'src': 'https://github.com/foo/bar.git', 'scm': 'git', 'version': ''}
