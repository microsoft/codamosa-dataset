

# Generated at 2022-06-17 08:07:21.957882
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Test for a git repo
    assert RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-examples.git') == 'ansible-examples'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-examples') == 'ansible-examples'
    assert RoleRequirement.repo_url_to_role_name('git@github.com:ansible/ansible-examples.git') == 'ansible-examples'
    assert RoleRequirement.repo_url_to_role_name('git@github.com:ansible/ansible-examples') == 'ansible-examples'

# Generated at 2022-06-17 08:07:33.162677
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'role_name,version,name'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'name', 'src': 'role_name', 'scm': None, 'version': 'version'}

    # Test for new style role definition
    role = {'role': 'role_name,version,name'}
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'name', 'src': 'role_name', 'scm': None, 'version': 'version'}

    # Test for new style role definition with src
    role = {'src': 'role_name,version,name'}

# Generated at 2022-06-17 08:07:42.195319
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0,my_role.tar.gz') == 'repo'

# Generated at 2022-06-17 08:07:50.650959
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+http://git.example.com/repos/repo.git') == 'repo'

# Generated at 2022-06-17 08:07:56.725023
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Test with a repo_url with no '://' or '@'
    assert RoleRequirement.repo_url_to_role_name('foo') == 'foo'

    # Test with a repo_url with '://'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'

    # Test with a repo_url with '@'
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com:repos/repo.git') == 'repo'

    # Test with a repo_url with '://' and '@'

# Generated at 2022-06-17 08:08:09.001225
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'role_name'
    role_yaml_parse_result = RoleRequirement.role_yaml_parse(role)
    assert role_yaml_parse_result['name'] == 'role_name'
    assert role_yaml_parse_result['src'] == 'role_name'
    assert role_yaml_parse_result['scm'] is None
    assert role_yaml_parse_result['version'] is None

    # Test for old style role definition with version
    role = 'role_name,1.0'
    role_yaml_parse_result = RoleRequirement.role_yaml_parse(role)
    assert role_yaml_parse_result['name'] == 'role_name'

# Generated at 2022-06-17 08:08:21.658100
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,extra") == "repo"

# Generated at 2022-06-17 08:08:32.264078
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'test_role'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'test_role'
    assert role_dict['src'] == 'test_role'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = 'test_role,v1.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'test_role'
    assert role_dict['src'] == 'test_role'
    assert role_dict['scm'] is None
    assert role_dict['version'] == 'v1.0'

    # Test for new style role definition with

# Generated at 2022-06-17 08:08:42.250384
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1:
    # Input:
    #   role = 'geerlingguy.apache'
    # Expected output:
    #   {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    role = 'geerlingguy.apache'
    expected_output = {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    actual_output = RoleRequirement.role_yaml_parse(role)
    assert expected_output == actual_output

    # Test case 2:
    # Input:
    #   role = 'geerlingguy.apache,1.0.0'
    # Expected output:
    #   {'name': '

# Generated at 2022-06-17 08:08:49.987857
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("role_name") == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse("role_name,v1") == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': 'v1'}
    assert RoleRequirement.role_yaml_parse("role_name,v1,name") == {'name': 'name', 'src': 'role_name', 'scm': None, 'version': 'v1'}

# Generated at 2022-06-17 08:08:57.762791
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test with a string
    role = "geerlingguy.java"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test with a dictionary
    role = {'role': 'geerlingguy.java'}
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None



# Generated at 2022-06-17 08:09:04.288799
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'role_name'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}

    # Test for new style role definition
    role = 'role_name,v1.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': 'v1.0'}

    # Test for new style role definition
    role = 'role_name,v1.0,new_name'
    role_dict = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-17 08:09:18.077664
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse("test_role_name") == {'name': 'test_role_name', 'src': 'test_role_name', 'scm': None, 'version': ''}
    assert role_requirement.role_yaml_parse("test_role_name,1.0") == {'name': 'test_role_name', 'src': 'test_role_name', 'scm': None, 'version': '1.0'}
    assert role_requirement.role_yaml_parse("test_role_name,1.0,test_role_name_2") == {'name': 'test_role_name_2', 'src': 'test_role_name', 'scm': None, 'version': '1.0'}


# Generated at 2022-06-17 08:09:30.986704
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    # Test with a string
    role = 'geerlingguy.java,1.8.0'
    role_yaml_parse = role_requirement.role_yaml_parse(role)
    assert role_yaml_parse['name'] == 'geerlingguy.java'
    assert role_yaml_parse['src'] == 'geerlingguy.java'
    assert role_yaml_parse['scm'] is None
    assert role_yaml_parse['version'] == '1.8.0'

    # Test with a dict
    role = {'role': 'geerlingguy.java,1.8.0'}
    role_yaml_parse = role_requirement.role_yaml_parse(role)

# Generated at 2022-06-17 08:09:42.047521
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role requirement
    role = 'geerlingguy.java'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] == None
    assert role_dict['version'] == ''

    # Test for new style role requirement
    role = 'geerlingguy.java,1.8'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] == None
    assert role_dict['version']

# Generated at 2022-06-17 08:09:51.220993
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0,apache') == {'name': 'apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': '1.0.0'}
    assert RoleRequirement.role_yaml

# Generated at 2022-06-17 08:09:59.377719
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = 'galaxy.role,v1.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'galaxy.role'
    assert role_dict['src'] == 'galaxy.role'
    assert role_dict['scm'] is None
    assert role_dict['version'] == 'v1.0'

    # Test for old style role line with name
    role = 'galaxy.role,v1.0,my_role'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'my_role'
    assert role_dict['src'] == 'galaxy.role'
    assert role_dict['scm'] is None
    assert role_

# Generated at 2022-06-17 08:10:09.804301
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1: role is a string
    role = "geerlingguy.apache"
    expected_result = dict(name="geerlingguy.apache", src="geerlingguy.apache", scm=None, version=None)
    assert RoleRequirement.role_yaml_parse(role) == expected_result

    # Test case 2: role is a string with version
    role = "geerlingguy.apache,1.0.0"
    expected_result = dict(name="geerlingguy.apache", src="geerlingguy.apache", scm=None, version="1.0.0")
    assert RoleRequirement.role_yaml_parse(role) == expected_result

    # Test case 3: role is a string with version and name

# Generated at 2022-06-17 08:10:17.950837
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_repo.tar.gz") == "repo"

# Generated at 2022-06-17 08:10:30.620726
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:10:42.781937
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for method role_yaml_parse of class RoleRequirement
    # Test for old style role definition
    role = "test_role"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'test_role'
    assert role_dict['src'] == 'test_role'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = dict(src="test_role")
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'test_role'
    assert role_dict['src'] == 'test_role'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

# Generated at 2022-06-17 08:10:47.277414
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role
    role = 'role_name'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role with version and name
    role = 'role_name,1.0.0,my_role'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'my_role'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] == '1.0.0'

   

# Generated at 2022-06-17 08:10:54.755565
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'geerlingguy.java'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] == ''

    # Test for new style role definition
    role = 'geerlingguy.java,1.7'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version']

# Generated at 2022-06-17 08:11:00.855309
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role = role_requirement.role_yaml_parse('git+https://github.com/geerlingguy/ansible-role-apache.git,v1.0.0')
    assert role['name'] == 'ansible-role-apache'
    assert role['scm'] == 'git'
    assert role['src'] == 'https://github.com/geerlingguy/ansible-role-apache.git'
    assert role['version'] == 'v1.0.0'
    role = role_requirement.role_yaml_parse('https://github.com/geerlingguy/ansible-role-apache.git,v1.0.0')
    assert role['name'] == 'ansible-role-apache'
    assert role['scm'] == None
   

# Generated at 2022-06-17 08:11:08.785619
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': ''}
    assert role_requirement.role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': '1.7'}
    assert role_requirement.role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'scm': None, 'src': 'geerlingguy.java', 'version': '1.7'}
    assert role_

# Generated at 2022-06-17 08:11:20.193977
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,myrole") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,myrole,v2.0") == "repo"

# Generated at 2022-06-17 08:11:26.599278
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0,apache') == {'name': 'apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': '1.0.0'}
    assert RoleRequirement.role_yaml

# Generated at 2022-06-17 08:11:33.490234
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "geerlingguy.apache"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = dict(src='geerlingguy.apache')
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None

# Generated at 2022-06-17 08:11:44.822714
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'role_name'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = 'role_name,version'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] == 'version'

    # Test for new style role definition with name

# Generated at 2022-06-17 08:11:55.370980
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('foo') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('foo,1.0') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': '1.0'}
    assert RoleRequirement.role_yaml_parse('foo,1.0,bar') == {'name': 'bar', 'src': 'foo', 'scm': None, 'version': '1.0'}

# Generated at 2022-06-17 08:12:14.764896
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0,apache') == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml

# Generated at 2022-06-17 08:12:21.099482
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}

# Generated at 2022-06-17 08:12:31.267839
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git') == {'name': 'repo', 'scm': None, 'src': 'http://git.example.com/repos/repo.git', 'version': None}
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,v1.0') == {'name': 'repo', 'scm': None, 'src': 'http://git.example.com/repos/repo.git', 'version': 'v1.0'}

# Generated at 2022-06-17 08:12:43.265001
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.2.3') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': 'v1.2.3'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.2.3,apache') == {'name': 'apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': 'v1.2.3'}

# Generated at 2022-06-17 08:12:53.698645
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1: role is a string
    role = 'geerlingguy.apache'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}

    # Test case 2: role is a string with version
    role = 'geerlingguy.apache,1.0.0'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}

    # Test case 3: role is a string with version and name
    role = 'geerlingguy.apache,1.0.0,apache'

# Generated at 2022-06-17 08:13:04.288835
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """
    Test for method role_yaml_parse of class RoleRequirement
    """
    role_requirement = RoleRequirement()
    role = role_requirement.role_yaml_parse("geerlingguy.java")
    assert role['name'] == 'geerlingguy.java'
    assert role['src'] == 'geerlingguy.java'
    assert role['scm'] is None
    assert role['version'] is None

    role = role_requirement.role_yaml_parse("geerlingguy.java,1.8")
    assert role['name'] == 'geerlingguy.java'
    assert role['src'] == 'geerlingguy.java'
    assert role['scm'] is None
    assert role['version'] == '1.8'

    role = role_requirement.role_

# Generated at 2022-06-17 08:13:17.389507
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:13:23.585831
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for new style
    role = dict(src='galaxy.role,version,name', other_vars="here")
    role_parsed = RoleRequirement.role_yaml_parse(role)
    assert role_parsed['name'] == 'name'
    assert role_parsed['src'] == 'galaxy.role'
    assert role_parsed['version'] == 'version'
    assert 'other_vars' not in role_parsed

    # Test for old style
    role = dict(role='galaxy.role,version,name', other_vars="here")
    role_parsed = RoleRequirement.role_yaml_parse(role)
    assert role_parsed['name'] == 'name'

# Generated at 2022-06-17 08:13:35.430387
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:13:44.243779
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0,apache') == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml

# Generated at 2022-06-17 08:14:10.316735
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = 'geerlingguy.ntp'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.ntp'
    assert role_dict['src'] == 'geerlingguy.ntp'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role line
    role = 'geerlingguy.ntp,1.0.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.ntp'
    assert role_dict['src'] == 'geerlingguy.ntp'
    assert role_dict['scm'] is None


# Generated at 2022-06-17 08:14:22.194224
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    assert role_requirement.role_yaml_parse('geerlingguy.apache,1.9.2') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.9.2'}

# Generated at 2022-06-17 08:14:30.090679
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git') == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,v1.0') == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'scm': None, 'version': 'v1.0'}

# Generated at 2022-06-17 08:14:42.091908
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse('geerlingguy.apache')
    assert role['name'] == 'geerlingguy.apache'
    assert role['src'] == 'geerlingguy.apache'
    assert role['scm'] is None
    assert role['version'] == ''

    role = RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.2.3')
    assert role['name'] == 'geerlingguy.apache'
    assert role['src'] == 'geerlingguy.apache'
    assert role['scm'] is None
    assert role['version'] == 'v1.2.3'

    role = RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.2.3,my_apache')
    assert role['name']

# Generated at 2022-06-17 08:14:55.756190
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = 'role_name'
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == 'role_name'
    assert result['src'] == 'role_name'
    assert result['scm'] is None
    assert result['version'] is None

    # Test for new style role line
    role = 'role_name,version'
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == 'role_name'
    assert result['src'] == 'role_name'
    assert result['scm'] is None
    assert result['version'] == 'version'

    # Test for new style role line
    role = 'role_name,version,name'
    result = RoleRequirement.role_yaml_parse

# Generated at 2022-06-17 08:15:08.277721
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("geerlingguy.java") == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse("geerlingguy.java,1.7") == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert RoleRequirement.role_yaml_parse("geerlingguy.java,1.7,java") == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}

# Generated at 2022-06-17 08:15:17.257241
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.8') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.8'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.8,java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.8'}

# Generated at 2022-06-17 08:15:31.037948
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'geerlingguy.java'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] == ''

    # Test for new style role definition
    role = 'geerlingguy.java,1.7'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version']

# Generated at 2022-06-17 08:15:42.445812
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = "role_name,version,name"
    assert RoleRequirement.role_yaml_parse(role) == dict(name='name', src='role_name', scm=None, version='version')

    # Test for new style role line
    role = dict(role="role_name,version,name")
    assert RoleRequirement.role_yaml_parse(role) == dict(name='name', src='role_name', scm=None, version='version')

    # Test for new style role line with src
    role = dict(src="role_name,version,name")
    assert RoleRequirement.role_yaml_parse(role) == dict(name='name', src='role_name', scm=None, version='version')

    # Test for new style role line with src and

# Generated at 2022-06-17 08:15:55.253262
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0,my_repo.tar.gz') == 'repo'

# Generated at 2022-06-17 08:16:36.611161
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1: role is a string
    role = 'geerlingguy.java'
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == 'geerlingguy.java'
    assert result['src'] == 'geerlingguy.java'
    assert result['scm'] is None
    assert result['version'] is None

    # Test case 2: role is a string with version
    role = 'geerlingguy.java,1.8'
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == 'geerlingguy.java'
    assert result['src'] == 'geerlingguy.java'
    assert result['scm'] is None
    assert result['version'] == '1.8'

    # Test case 3: role

# Generated at 2022-06-17 08:16:46.161008
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.2.3') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.2.3'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.2.3,apache') == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.2.3'}
    assert RoleRequirement.role_yaml

# Generated at 2022-06-17 08:16:59.702746
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git')
    assert role['name'] == 'repo'
    assert role['src'] == 'http://git.example.com/repos/repo.git'
    assert role['scm'] == 'git'
    assert role['version'] == ''

    role = RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,v1.0')
    assert role['name'] == 'repo'
    assert role['src'] == 'http://git.example.com/repos/repo.git'
    assert role['scm'] == 'git'
    assert role['version'] == 'v1.0'

    role = RoleRequirement.role_yaml