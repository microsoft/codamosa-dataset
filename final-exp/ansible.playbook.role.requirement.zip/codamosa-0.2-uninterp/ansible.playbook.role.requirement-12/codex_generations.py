

# Generated at 2022-06-17 08:07:15.006789
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1:
    #   Input:
    #       role = "git+https://github.com/geerlingguy/ansible-role-apache.git,v1.0.0"
    #   Expected output:
    #       {'name': 'ansible-role-apache', 'src': 'https://github.com/geerlingguy/ansible-role-apache.git', 'scm': 'git', 'version': 'v1.0.0'}
    role = "git+https://github.com/geerlingguy/ansible-role-apache.git,v1.0.0"

# Generated at 2022-06-17 08:07:29.528246
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:07:40.100092
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_name") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_name,other_var") == "repo"
    assert RoleRequirement.repo_url_to_role_name

# Generated at 2022-06-17 08:07:44.844143
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_role.tar.gz") == "repo"

# Generated at 2022-06-17 08:07:56.430155
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('geerlingguy.jenkins') == {'name': 'geerlingguy.jenkins', 'src': 'geerlingguy.jenkins', 'scm': None, 'version': ''}
    assert role_requirement.role_yaml_parse('geerlingguy.jenkins,1.0.0') == {'name': 'geerlingguy.jenkins', 'src': 'geerlingguy.jenkins', 'scm': None, 'version': '1.0.0'}

# Generated at 2022-06-17 08:08:08.994551
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()

    # Test with a string
    role_string = "geerlingguy.java"
    role_dict = role_requirement.role_yaml_parse(role_string)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test with a string with version
    role_string = "geerlingguy.java,1.8"
    role_dict = role_requirement.role_yaml_parse(role_string)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
   

# Generated at 2022-06-17 08:08:18.361616
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,name") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,name,v2.0") == "repo"

# Generated at 2022-06-17 08:08:24.782381
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:08:36.583824
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:08:46.039381
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:09:01.731839
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "role_name"
    assert RoleRequirement.role_yaml_parse(role) == dict(name="role_name", src="role_name", scm=None, version=None)

    # Test for new style role definition
    role = dict(role="role_name")
    assert RoleRequirement.role_yaml_parse(role) == dict(name="role_name", src="role_name", scm=None, version=None)

    # Test for new style role definition with version
    role = dict(role="role_name,v1.0")
    assert RoleRequirement.role_yaml_parse(role) == dict(name="role_name", src="role_name", scm=None, version="v1.0")

    # Test for new style role definition with

# Generated at 2022-06-17 08:09:10.503356
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test for string type
    role = 'geerlingguy.apache'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    role = 'geerlingguy.apache,1.0.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None
    assert role_dict['version'] == '1.0.0'



# Generated at 2022-06-17 08:09:20.984139
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("http://git.example.com/repos/repo.git") == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse("http://git.example.com/repos/repo.git,v1.0") == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'scm': None, 'version': 'v1.0'}

# Generated at 2022-06-17 08:09:32.022730
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role requirement
    role = 'role_name'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role requirement
    role = dict(role='role_name')
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role requirement with version

# Generated at 2022-06-17 08:09:42.314300
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1: role_yaml_parse(role)
    # Input: role = 'https://github.com/geerlingguy/ansible-role-apache.git,v1.0.0'
    # Expected output: {'name': 'ansible-role-apache', 'scm': 'git', 'src': 'https://github.com/geerlingguy/ansible-role-apache.git', 'version': 'v1.0.0'}
    role = 'https://github.com/geerlingguy/ansible-role-apache.git,v1.0.0'

# Generated at 2022-06-17 08:09:54.186607
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role requirement
    assert RoleRequirement.role_yaml_parse('role_name') == dict(name='role_name', src='role_name', scm=None, version='')
    assert RoleRequirement.role_yaml_parse('role_name,v1.0') == dict(name='role_name', src='role_name', scm=None, version='v1.0')
    assert RoleRequirement.role_yaml_parse('role_name,v1.0,name') == dict(name='name', src='role_name', scm=None, version='v1.0')

# Generated at 2022-06-17 08:10:04.761558
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement()
    assert role.role_yaml_parse('http://github.com/user/repo.git,1.0,name') == {'name': 'name', 'scm': 'git', 'src': 'http://github.com/user/repo.git', 'version': '1.0'}
    assert role.role_yaml_parse('http://github.com/user/repo.git,1.0') == {'name': 'repo', 'scm': 'git', 'src': 'http://github.com/user/repo.git', 'version': '1.0'}

# Generated at 2022-06-17 08:10:13.448778
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'role_name'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}

    role = 'role_name,v1.0'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': 'v1.0'}

    role = 'role_name,v1.0,new_name'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'new_name', 'src': 'role_name', 'scm': None, 'version': 'v1.0'}

    # Test for

# Generated at 2022-06-17 08:10:22.501409
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "geerlingguy.java"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = "geerlingguy.java,1.7"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version']

# Generated at 2022-06-17 08:10:34.744400
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:10:51.710411
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('git+https://github.com/geerlingguy/ansible-role-apache.git') == 'ansible-role-apache'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache.git') == 'ansible-role-apache'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache.git,v1.0') == 'ansible-role-apache'

# Generated at 2022-06-17 08:11:00.196306
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:11:08.318676
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('http://github.com/user/repo.git,v1.0') == {'name': 'repo', 'scm': 'git', 'src': 'http://github.com/user/repo.git', 'version': 'v1.0'}
    assert RoleRequirement.role_yaml_parse('http://github.com/user/repo.git,v1.0,myrole') == {'name': 'myrole', 'scm': 'git', 'src': 'http://github.com/user/repo.git', 'version': 'v1.0'}

# Generated at 2022-06-17 08:11:19.955829
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:11:26.396922
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,foo.tar.gz") == "repo"

# Generated at 2022-06-17 08:11:32.621289
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = "geerlingguy.java"
    assert RoleRequirement.role_yaml_parse(role) == dict(name="geerlingguy.java", src="geerlingguy.java", scm=None, version=None)

    role = "geerlingguy.java,1.8"
    assert RoleRequirement.role_yaml_parse(role) == dict(name="geerlingguy.java", src="geerlingguy.java", scm=None, version="1.8")

    role = "geerlingguy.java,1.8,java"
    assert RoleRequirement.role_yaml_parse(role) == dict(name="java", src="geerlingguy.java", scm=None, version="1.8")


# Generated at 2022-06-17 08:11:40.804195
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    role_requirement.role_yaml_parse("geerlingguy.java,1.8.0")
    role_requirement.role_yaml_parse("geerlingguy.java,1.8.0,name")
    role_requirement.role_yaml_parse("geerlingguy.java")
    role_requirement.role_yaml_parse("git+https://github.com/geerlingguy/ansible-role-java.git,1.8.0")
    role_requirement.role_yaml_parse("git+https://github.com/geerlingguy/ansible-role-java.git,1.8.0,name")

# Generated at 2022-06-17 08:11:51.917163
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:12:02.915172
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role_name') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role_name,v2.0') == 'repo'
    assert RoleRequirement.repo_url_

# Generated at 2022-06-17 08:12:14.645828
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': None}
    assert role_requirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': '1.0.0'}

# Generated at 2022-06-17 08:12:38.312873
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.2.3') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.2.3,foobar') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.2.3,foobar,baz') == 'repo'
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:12:50.880924
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    assert role_requirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}

# Generated at 2022-06-17 08:13:01.826871
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,name.tar.gz") == "repo"
    assert role_requirement

# Generated at 2022-06-17 08:13:07.962444
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:13:19.852684
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("http://git.example.com/repos/repo.git") == {'name': 'repo', 'scm': None, 'src': 'http://git.example.com/repos/repo.git', 'version': None}
    assert RoleRequirement.role_yaml_parse("http://git.example.com/repos/repo.git,v1.0") == {'name': 'repo', 'scm': None, 'src': 'http://git.example.com/repos/repo.git', 'version': 'v1.0'}

# Generated at 2022-06-17 08:13:33.180016
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for new style
    role = dict(src='galaxy.role,version,name', other_vars="here")
    assert RoleRequirement.role_yaml_parse(role) == dict(name='name', src='galaxy.role', scm=None, version='version')

    # Test for old style
    role = dict(role='galaxy.role,version,name', other_vars="here")
    assert RoleRequirement.role_yaml_parse(role) == dict(name='name', src='galaxy.role', scm=None, version='version')

    # Test for new style
    role = dict(src='galaxy.role,version', other_vars="here")

# Generated at 2022-06-17 08:13:43.906175
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}

# Generated at 2022-06-17 08:13:56.261036
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role_line = "geerlingguy.java,1.7.0"
    role_dict = RoleRequirement.role_yaml_parse(role_line)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['version'] == '1.7.0'
    assert role_dict['scm'] is None

    # Test for new style role line
    role_line = "geerlingguy.java,1.7.0,name"
    role_dict = RoleRequirement.role_yaml_parse(role_line)
    assert role_dict['name'] == 'name'
    assert role_dict['src'] == 'geerlingguy.java'
   

# Generated at 2022-06-17 08:14:04.249051
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+http://git.example.com/repos/repo.git') == 'repo'

# Generated at 2022-06-17 08:14:12.385132
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:14:48.425772
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:14:59.356507
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:15:09.922571
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'role_name,version,name'
    assert RoleRequirement.role_yaml_parse(role) == dict(name='name', src='role_name', scm=None, version='version')

    # Test for new style role definition
    role = dict(role='role_name,version,name')
    assert RoleRequirement.role_yaml_parse(role) == dict(name='name', src='role_name', scm=None, version='version')

    # Test for new style role definition with extra vars
    role = dict(role='role_name,version,name', other_vars='here')
    assert RoleRequirement.role_yaml_parse(role) == dict(name='name', src='role_name', scm=None, version='version')

    #

# Generated at 2022-06-17 08:15:18.416191
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,myname.tar.gz") == "repo"

# Generated at 2022-06-17 08:15:31.647135
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0,my_role.tar.gz') == 'repo'

# Generated at 2022-06-17 08:15:38.430348
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1:
    #   Input:
    #       role = "geerlingguy.java"
    #   Expected result:
    #       {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}
    role = "geerlingguy.java"
    expected_result = {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}
    actual_result = RoleRequirement.role_yaml_parse(role)
    assert actual_result == expected_result

    # Test case 2:
    #   Input:
    #       role = "geerlingguy.java,1.8.0"
    #   Expected result:
    #       {

# Generated at 2022-06-17 08:15:50.184058
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:16:00.129892
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role_name") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role_name,v2.0") == "repo"
    assert RoleRequirement.repo_url_

# Generated at 2022-06-17 08:16:07.037799
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0') == 'repo'

# Generated at 2022-06-17 08:16:20.036575
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_repo.tar.gz") == "repo"

# Generated at 2022-06-17 08:17:00.764258
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = "role_name"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}

    # Test for new style role line
    role = "role_name,version"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': 'version'}

    # Test for new style role line with name
    role = "role_name,version,name"
    result = RoleRequirement.role_yaml_parse(role)