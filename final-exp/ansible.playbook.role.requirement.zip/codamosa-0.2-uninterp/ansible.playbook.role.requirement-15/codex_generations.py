

# Generated at 2022-06-17 08:07:22.594992
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:07:33.640142
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'test_role'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'test_role'
    assert role_dict['src'] == 'test_role'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = 'test_role,v1.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'test_role'
    assert role_dict['src'] == 'test_role'
    assert role_dict['scm'] is None
    assert role_dict['version'] == 'v1.0'

    # Test for new style role definition


# Generated at 2022-06-17 08:07:45.884816
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_role.tar.gz") == "repo"

# Generated at 2022-06-17 08:07:57.099140
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = "geerlingguy.apache"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role line
    role = "geerlingguy.apache,1.0.0"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None

# Generated at 2022-06-17 08:08:09.030558
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,vars') == 'repo'

# Generated at 2022-06-17 08:08:21.696510
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:08:33.545875
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style
    role = 'galaxy.role'
    assert RoleRequirement.role_yaml_parse(role) == dict(name='galaxy.role', src='galaxy.role', scm=None, version='')

    role = 'galaxy.role,v1.0'
    assert RoleRequirement.role_yaml_parse(role) == dict(name='galaxy.role', src='galaxy.role', scm=None, version='v1.0')

    role = 'galaxy.role,v1.0,my_role'
    assert RoleRequirement.role_yaml_parse(role) == dict(name='my_role', src='galaxy.role', scm=None, version='v1.0')

    # Test for new style

# Generated at 2022-06-17 08:08:45.822505
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:08:57.357214
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:09:06.586885
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:09:21.658594
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:09:28.669252
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:09:39.790576
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:09:50.210827
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml_parse = RoleRequirement.role_yaml_parse
    assert role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': None}
    assert role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': '1.7'}
    assert role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'scm': None, 'src': 'geerlingguy.java', 'version': '1.7'}

# Generated at 2022-06-17 08:10:03.241574
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test for old style role requirement
    role = 'role_name'
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': ''}

    # Test for new style role requirement
    role = {'role': 'role_name'}
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': ''}

    # Test for new style role requirement with version
    role = {'role': 'role_name,1.0'}
    result = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-17 08:10:12.757890
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+http://git.example.com/repos/repo.git') == 'repo'

# Generated at 2022-06-17 08:10:21.927591
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:10:32.046165
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+http://git.example.com/repos/repo.git') == 'repo'

# Generated at 2022-06-17 08:10:37.433816
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:10:45.282012
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}
    assert role_requirement.role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert role_requirement.role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert role_

# Generated at 2022-06-17 08:11:13.273780
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0,my_repo.tar.gz') == 'repo'

# Generated at 2022-06-17 08:11:23.294787
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "role_name"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}

    # Test for new style role definition
    role = {'role': 'role_name'}
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}

    # Test for new style role definition with version
    role = {'role': 'role_name,1.0'}
    result = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-17 08:11:34.809957
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:11:41.856259
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('foo') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('foo,1.0') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': '1.0'}
    assert RoleRequirement.role_yaml_parse('foo,1.0,bar') == {'name': 'bar', 'src': 'foo', 'scm': None, 'version': '1.0'}

# Generated at 2022-06-17 08:11:52.996427
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0,my_role.tar.gz') == 'repo'

# Generated at 2022-06-17 08:12:01.256569
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:12:14.544154
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'role_name'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = 'role_name,1.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] == '1.0'

    # Test for new style role definition with name


# Generated at 2022-06-17 08:12:21.038740
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:12:31.222313
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0,myrole.tar.gz') == 'repo'

# Generated at 2022-06-17 08:12:43.221130
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,foo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,foo,bar') == 'repo'

# Generated at 2022-06-17 08:13:19.256052
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "role_name"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = "role_name,version"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] == 'version'

    # Test for new style role definition

# Generated at 2022-06-17 08:13:32.898660
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('foo') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('foo,1.0') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': '1.0'}
    assert RoleRequirement.role_yaml_parse('foo,1.0,bar') == {'name': 'bar', 'src': 'foo', 'scm': None, 'version': '1.0'}

# Generated at 2022-06-17 08:13:43.674361
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:13:55.959380
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role
    role = "role_name"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': ''}

    # Test for new style role
    role = {'role': 'role_name'}
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': ''}

    # Test for new style role with version
    role = {'role': 'role_name,v1.0'}
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_

# Generated at 2022-06-17 08:14:04.070386
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement.role_yaml_parse("src")
    assert role["name"] == "src"
    assert role["src"] == "src"
    assert role["scm"] == None
    assert role["version"] == None

    role = RoleRequirement.role_yaml_parse("src,version")
    assert role["name"] == "src"
    assert role["src"] == "src"
    assert role["scm"] == None
    assert role["version"] == "version"

    role = RoleRequirement.role_yaml_parse("src,version,name")
    assert role["name"] == "name"
    assert role["src"] == "src"
    assert role["scm"] == None
    assert role["version"] == "version"


# Generated at 2022-06-17 08:14:12.273963
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for string_types
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0,apache') == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}

# Generated at 2022-06-17 08:14:22.879631
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "test_role"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'test_role'
    assert role_dict['src'] == 'test_role'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = "test_role,v1.0"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'test_role'
    assert role_dict['src'] == 'test_role'
    assert role_dict['scm'] is None
    assert role_dict['version'] == 'v1.0'

    # Test for new style role definition with

# Generated at 2022-06-17 08:14:36.613477
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_role.tar.gz") == "repo"

# Generated at 2022-06-17 08:14:47.867805
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-apache.git") == "ansible-role-apache"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-apache,v1.0.0") == "ansible-role-apache"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-apache,v1.0.0,geerlingguy.apache") == "ansible-role-apache"

# Generated at 2022-06-17 08:14:59.270681
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:15:50.517540
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert role_requirement.role_yaml_parse('geerlingguy.apache,v1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.0.0'}

# Generated at 2022-06-17 08:16:00.354771
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.2.3') == {'name': 'geerlingguy.apache', 'scm': None, 'src': 'geerlingguy.apache', 'version': '1.2.3'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.2.3,foo') == {'name': 'foo', 'scm': None, 'src': 'geerlingguy.apache', 'version': '1.2.3'}
    assert RoleRequirement.role_yaml

# Generated at 2022-06-17 08:16:10.462022
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,extra") == "repo"

# Generated at 2022-06-17 08:16:21.468477
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz,v1.0,my_role") == "repo"

# Generated at 2022-06-17 08:16:33.491029
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.utils.display import Display
    display = Display()

    # Test for old style role definition
    role = 'geerlingguy.apache'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None
    assert role_dict['version'] == ''

    # Test for new style role definition
    role = 'geerlingguy.apache,1.0.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
   

# Generated at 2022-06-17 08:16:42.914951
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git+ssh://git.example.com/repos/repo.git") == "repo"

# Generated at 2022-06-17 08:16:50.672337
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,my_role.tar.gz") == "repo"

# Generated at 2022-06-17 08:17:01.348581
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/ansible/ansible-examples.git") == "ansible-examples"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/ansible/ansible-examples.git") == "ansible-examples"
    assert RoleRequirement.repo_url_to_role_name("git@github.com:ansible/ansible-examples.git") == "ansible-examples"
    assert RoleRequirement.repo_url_to_role_name("git@github.com:ansible/ansible-examples.git,v1.0") == "ansible-examples"