

# Generated at 2022-06-17 08:07:19.443424
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for role_yaml_parse with string_types
    role = "geerlingguy.java"
    role_yaml_parse_result = RoleRequirement.role_yaml_parse(role)
    assert role_yaml_parse_result == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}

    # Test for role_yaml_parse with dict
    role = {'role': 'geerlingguy.java'}
    role_yaml_parse_result = RoleRequirement.role_yaml_parse(role)
    assert role_yaml_parse_result == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}

    #

# Generated at 2022-06-17 08:07:27.736827
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:07:36.706307
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = "geerlingguy.apache"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role line
    role = "geerlingguy.apache,v1.0.0"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None
    assert role_dict

# Generated at 2022-06-17 08:07:45.067517
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,name') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,name,v2.0') == 'repo'

# Generated at 2022-06-17 08:07:56.429537
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'role_name'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = 'role_name,v1.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] == 'v1.0'

    # Test for new style role definition


# Generated at 2022-06-17 08:08:09.002683
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:08:21.664795
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    assert role_requirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}

# Generated at 2022-06-17 08:08:26.346039
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "geerlingguy.apache"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for old style role definition with version
    role = "geerlingguy.apache,1.2.3"
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None
    assert role_

# Generated at 2022-06-17 08:08:34.232166
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1: old style role line
    role = 'geerlingguy.apache'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test case 2: new style role line
    role = 'geerlingguy.apache,v1.0.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None
   

# Generated at 2022-06-17 08:08:45.854787
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:09:06.427620
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0,myname.tar.gz") == "repo"

# Generated at 2022-06-17 08:09:18.763999
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml_parse = RoleRequirement.role_yaml_parse
    assert role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}
    assert role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}

# Generated at 2022-06-17 08:09:31.369358
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}
    assert role_requirement.role_yaml_parse('geerlingguy.java,1.8') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.8'}
    assert role_requirement.role_yaml_parse('geerlingguy.java,1.8,java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.8'}
    assert role_

# Generated at 2022-06-17 08:09:43.612529
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-17 08:09:52.279097
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    assert RoleRequirement.role_yaml_parse('role_name') == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('role_name,v1.0') == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': 'v1.0'}
    assert RoleRequirement.role_yaml_parse('role_name,v1.0,new_name') == {'name': 'new_name', 'src': 'role_name', 'scm': None, 'version': 'v1.0'}

# Generated at 2022-06-17 08:10:03.931775
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,name") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,name,v2.0") == "repo"

# Generated at 2022-06-17 08:10:13.238785
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'role_name'
    role_yaml = RoleRequirement.role_yaml_parse(role)
    assert role_yaml['name'] == 'role_name'
    assert role_yaml['src'] == 'role_name'
    assert role_yaml['scm'] is None
    assert role_yaml['version'] is None

    # Test for new style role definition
    role = 'role_name,v1.0'
    role_yaml = RoleRequirement.role_yaml_parse(role)
    assert role_yaml['name'] == 'role_name'
    assert role_yaml['src'] == 'role_name'
    assert role_yaml['scm'] is None
    assert role_yaml['version'] == 'v1.0'

# Generated at 2022-06-17 08:10:22.579045
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = 'geerlingguy.java,1.7.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['version'] == '1.7.0'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None

    role = 'geerlingguy.java,1.7.0,java'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'java'
    assert role_dict['version'] == '1.7.0'
    assert role_dict['src'] == 'geerlingguy.java'

# Generated at 2022-06-17 08:10:34.862042
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = "geerlingguy.apache"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}

    # Test for new style role line
    role = "geerlingguy.apache,1.0.0"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}

    # Test for new style role line with name
    role = "geerlingguy.apache,1.0.0,my_apache"


# Generated at 2022-06-17 08:10:43.573254
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = 'geerlingguy.apache'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    role = 'geerlingguy.apache,v1.0.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.apache'
    assert role_dict['src'] == 'geerlingguy.apache'
    assert role_dict['scm'] is None
    assert role_dict['version'] == 'v1.0.0'


# Generated at 2022-06-17 08:11:58.320747
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role = 'geerlingguy.apache'
    expected = dict(name='geerlingguy.apache', src=None, scm=None, version=None)
    assert RoleRequirement.role_yaml_parse(role) == expected

    # Test for new style role line
    role = dict(role='geerlingguy.apache')
    expected = dict(name='geerlingguy.apache', src=None, scm=None, version=None)
    assert RoleRequirement.role_yaml_parse(role) == expected

    # Test for new style role line with version
    role = dict(role='geerlingguy.apache,1.0.0')

# Generated at 2022-06-17 08:12:05.016644
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_role') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git+http://git.example.com/repos/repo.git') == 'repo'

# Generated at 2022-06-17 08:12:15.188742
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('foo') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('foo,1.0') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': '1.0'}
    assert RoleRequirement.role_yaml_parse('foo,1.0,bar') == {'name': 'bar', 'src': 'foo', 'scm': None, 'version': '1.0'}

# Generated at 2022-06-17 08:12:28.803032
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = "role_name"
    assert RoleRequirement.role_yaml_parse(role) == dict(name="role_name", src="role_name", scm=None, version=None)

    # Test for new style role definition
    role = dict(role="role_name")
    assert RoleRequirement.role_yaml_parse(role) == dict(name="role_name", src="role_name", scm=None, version=None)

    # Test for new style role definition with version
    role = dict(role="role_name,v1.0")
    assert RoleRequirement.role_yaml_parse(role) == dict(name="role_name", src="role_name", scm=None, version="v1.0")

    # Test for new style role definition with

# Generated at 2022-06-17 08:12:39.172310
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'role_name'
    expected_result = {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse(role) == expected_result

    # Test for new style role definition
    role = {'role': 'role_name'}
    expected_result = {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse(role) == expected_result

    # Test for new style role definition with version
    role = {'role': 'role_name,1.0'}

# Generated at 2022-06-17 08:12:51.182957
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role requirement
    role = 'role_name'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role requirement
    role = dict(role='role_name')
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'role_name'
    assert role_dict['src'] == 'role_name'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role requirement with version

# Generated at 2022-06-17 08:13:03.065130
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.tar.gz,name') == 'repo'

# Generated at 2022-06-17 08:13:11.921533
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0,my_apache') == {'name': 'my_apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}

# Generated at 2022-06-17 08:13:22.655167
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'galaxy.role'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'galaxy.role', 'src': 'galaxy.role', 'scm': None, 'version': None}

    # Test for new style role definition
    role = {'role': 'galaxy.role'}
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'galaxy.role', 'src': 'galaxy.role', 'scm': None, 'version': None}

    # Test for new style role definition with version
    role = {'role': 'galaxy.role,1.0'}

# Generated at 2022-06-17 08:13:30.818460
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v0.1") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v0.1,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v0.1,my_role,extra") == "repo"

# Generated at 2022-06-17 08:14:01.779746
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = 'myrole'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'myrole'
    assert role_dict['src'] == 'myrole'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    role = 'myrole,v1.0'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'myrole'
    assert role_dict['src'] == 'myrole'
    assert role_dict['scm'] is None
    assert role_dict['version'] == 'v1.0'

    role = 'myrole,v1.0,myrole'

# Generated at 2022-06-17 08:14:10.606091
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0') == 'repo'
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:14:22.286991
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role line
    role_line = "geerlingguy.apache"
    role_dict = RoleRequirement.role_yaml_parse(role_line)
    assert role_dict == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}

    # Test for new style role line
    role_line = "geerlingguy.apache,v1.0.0"
    role_dict = RoleRequirement.role_yaml_parse(role_line)
    assert role_dict == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.0.0'}

    # Test for new style role line with name
    role_line

# Generated at 2022-06-17 08:14:35.824843
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0,my_repo,extra') == 'repo'
    assert RoleRequirement.repo_url_to_role_name

# Generated at 2022-06-17 08:14:46.865338
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_repo,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_

# Generated at 2022-06-17 08:14:56.728475
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test for string_types
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0,apache') == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}

# Generated at 2022-06-17 08:15:06.840925
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.jenkins') == {'name': 'geerlingguy.jenkins', 'src': 'geerlingguy.jenkins', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.jenkins,1.2.3') == {'name': 'geerlingguy.jenkins', 'src': 'geerlingguy.jenkins', 'scm': None, 'version': '1.2.3'}

# Generated at 2022-06-17 08:15:16.393044
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test for old style role definition
    role = 'role_name'
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == 'role_name'
    assert result['src'] == 'role_name'
    assert result['scm'] is None
    assert result['version'] is None

    # Test for new style role definition
    role = dict(src='role_name')
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == 'role_name'
    assert result['src'] == 'role_name'
    assert result['scm'] is None
    assert result['version'] is None

    # Test for new style role definition with version
    role = dict(src='role_name,1.0')
    result = RoleRequirement.role_

# Generated at 2022-06-17 08:15:30.625620
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:15:41.917409
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case:
    #   role:
    #     name: test_role
    #     src: https://github.com/test_user/test_role.git
    #     version: master
    #     scm: git
    #
    # Expected result:
    #   {'name': 'test_role', 'src': 'https://github.com/test_user/test_role.git', 'version': 'master', 'scm': 'git'}
    test_case = {'role': {'name': 'test_role', 'src': 'https://github.com/test_user/test_role.git', 'version': 'master', 'scm': 'git'}}

# Generated at 2022-06-17 08:16:10.982210
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for old style role definition
    role = 'geerlingguy.java'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version'] is None

    # Test for new style role definition
    role = 'geerlingguy.java,1.7'
    role_dict = RoleRequirement.role_yaml_parse(role)
    assert role_dict['name'] == 'geerlingguy.java'
    assert role_dict['src'] == 'geerlingguy.java'
    assert role_dict['scm'] is None
    assert role_dict['version']

# Generated at 2022-06-17 08:16:21.640149
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role,v2.0") == "repo"
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-17 08:16:33.522162
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test with string
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.0.0') == {'name': 'geerlingguy.apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.0.0'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,v1.0.0,apache') == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': 'v1.0.0'}


# Generated at 2022-06-17 08:16:42.915104
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for string_types
    assert RoleRequirement.role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.7,java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    assert RoleRequirement.role_yaml

# Generated at 2022-06-17 08:16:51.933762
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git+http://git.example.com/repos/repo.git,v1.0,my_role") == "repo"

# Generated at 2022-06-17 08:17:01.904192
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0.tar.gz') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0.0,my_role.tar.gz') == 'repo'