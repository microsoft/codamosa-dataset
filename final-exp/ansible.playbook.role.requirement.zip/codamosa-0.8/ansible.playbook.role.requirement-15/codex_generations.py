

# Generated at 2022-06-11 10:49:54.068750
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    yaml_example_v1 = { "role": "mattray" }
    yaml_example_v1_output = { "name": "mattray",
                               "scm": None,
                               "src": None,
                               "version": None }
    yaml_example_v2 = { "role": "mattray,1.0" }
    yaml_example_v2_output = { "name": "mattray",
                               "scm": None,
                               "src": None,
                               "version": "1.0" }
    yaml_example_v3 = { "role": "mattray,1.0,mattray" }

# Generated at 2022-06-11 10:50:04.829291
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_def1 = RoleDefinition.load("michael.dehaan")
    role_def2 = RoleDefinition.load("michael.dehaan,0.1")
    role_def3 = RoleDefinition.load("michael.dehaan,v0.1")
    role_def4 = RoleDefinition.load("michael.dehaan,0.1,custom_name")
    role_def5 = RoleDefinition.load("michael.dehaan,v0.1,custom_name")
    role_def6 = RoleDefinition.load("https://github.com/michael-dehaan/ansible-role-foobar.git")
    role_def7 = RoleDefinition.load("https://github.com/michael-dehaan/ansible-role-foobar.git,v0.1")
    role_

# Generated at 2022-06-11 10:50:15.012571
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:50:25.954672
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:50:36.923213
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_name = RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git')
    assert role_name == 'repo'
    role_name = RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,1.0')
    assert role_name == 'repo'
    role_name = RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,1.0,roles')
    assert role_name == 'roles'

# Generated at 2022-06-11 10:50:48.505587
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:50:59.518093
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.java') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('https://github.com/geerlingguy/ansible-role-java.git') == {'name': 'java', 'src': 'https://github.com/geerlingguy/ansible-role-java.git', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,1.8.0') == {'name': 'java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.8.0'}
    assert RoleRequirement.role_

# Generated at 2022-06-11 10:51:06.631738
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    display.verbosity = 3
    display.deprecated('Starting tests')

    # test case 1
    role = "src"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'src', 'src': 'src', 'scm': None, 'version': None}

    # test case 1b
    role = "src,"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'src', 'src': 'src', 'scm': None, 'version': ""}

    # test case 2
    role = "src,version,name"
    result = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-11 10:51:18.658989
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    res = RoleRequirement.role_yaml_parse('git+https://github.com/jtyr/ansible-talk-demo.git')
    assert res['name'] == 'ansible-talk-demo'
    assert res['src'] == 'https://github.com/jtyr/ansible-talk-demo.git'
    assert res['scm'] == 'git'
    assert res['version'] == ''

    res = RoleRequirement.role_yaml_parse('git+https://github.com/jtyr/ansible-talk-demo.git,master')
    assert res['name'] == 'ansible-talk-demo'
    assert res['src'] == 'https://github.com/jtyr/ansible-talk-demo.git'

# Generated at 2022-06-11 10:51:26.685452
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_src = 'http://github.com/username/repository'
    test_version = 'v1.0.0'
    test_name = 'testrole'
    test_scm = 'git'

    role = dict(name=test_name, src=test_src, version=test_version, scm=test_scm)
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == test_name
    assert result['version'] == test_version
    assert result['scm'] == test_scm
    assert result['src'] == test_src

    role = dict(role=test_name, src=test_src, version=test_version, scm=test_scm)
    result = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-11 10:51:49.413687
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert 'repo' == RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git')
    assert 'repo' == RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz')
    assert 'repo' == RoleRequirement.repo_url_to_role_name('repo')
    assert 'repo' == RoleRequirement.repo_url_to_role_name('galaxy.server.org/repo')
    assert 'galaxy.server.org/repo' == RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/galaxy.server.org/repo')

# Generated at 2022-06-11 10:52:01.455424
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """
    This unit test checks if the method role_yaml_parse of class RoleRequirement
    tests all code paths.
    """
    assert RoleRequirement.role_yaml_parse("geerlingguy.java") == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('geerlingguy.java,v2.0') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': 'v2.0'}

# Generated at 2022-06-11 10:52:13.431273
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    test_strings = [
        'git+git@github.com:myuser/ansible-role-repo.git',
        'git+https://github.com/myuser/ansible-role-repo.git',
        'https://github.com/myuser/ansible-role-repo.git',
        'git@github.com:myuser/ansible-role-repo.git',
        'github.com/myuser/ansible-role-repo.git',
        'myuser/ansible-role-repo.git',
        'myuser/ansible-role-repo',
        'ansible-role-repo',
    ]


# Generated at 2022-06-11 10:52:25.458058
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    result = RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git')
    assert result == 'repo'

    result = RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0.0')
    assert result == 'repo'

    result = RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0.0,foo')
    assert result == 'repo'

    result = RoleRequirement.repo_url_to_role_name('https://github.com/foo/bar.git')
    assert result == 'bar'

    result = RoleRequirement.repo_url_

# Generated at 2022-06-11 10:52:32.601332
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    input_url = 'http://git.example.com/repos/repo.git'
    expected_output = 'repo'
    actual_output = RoleRequirement.repo_url_to_role_name(input_url)

    assert actual_output == expected_output, "Expected '%s', but got '%s'" % (expected_output, actual_output)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 10:52:38.276181
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """ Tests for method role_yaml_parse of class RoleRequirement """

    role = "geerlingguy.apache"
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'geerlingguy.apache', 'version': '', 'scm': None, 'src': 'geerlingguy.apache'}

    role = "geerlingguy.apache,1.9.2"
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'geerlingguy.apache', 'version': '1.9.2', 'scm': None, 'src': 'geerlingguy.apache'}

    role = "geerlingguy.apache,1.9.2,apache"

# Generated at 2022-06-11 10:52:47.760689
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/user/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo-1.2.3.tar.gz') == 'repo-1.2.3'
    assert RoleRequirement.repo_url_to_role_name('https://raw.github.com/user/repo/v1.2.3/repo.tar.gz') == 'repo'

# Generated at 2022-06-11 10:52:58.633933
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("storage.googleapis.com/ansible-role-test") == "ansible-role-test"
    assert RoleRequirement.repo_url_to_role_name("ansible-role-test") == "ansible-role-test"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-test.git") == "ansible-role-test"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/geerlingguy/ansible-role-test.git") == "ansible-role-test"

# Generated at 2022-06-11 10:53:02.918955
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('https://github.com/myuser/myrole.git') == 'myrole'
    assert RoleRequirement.repo_url_to_role_name('git@github.com:myuser/myrole.git') == 'myrole'


# Generated at 2022-06-11 10:53:10.908209
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://github.com/my_user/my_repo.git') == 'my_repo'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/my_user/my_repo.git') == 'my_repo'
    assert RoleRequirement.repo_url_to_role_name('git+https://github.com/my_user/my_repo.git') == 'my_repo'
    assert RoleRequirement.repo_url_to_role_name('git+http://github.com/my_user/my_repo.git') == 'my_repo'

# Generated at 2022-06-11 10:53:56.148737
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git,v1.0") == "repo.git"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.tar.gz") == "repo.tar.gz"

# Generated at 2022-06-11 10:54:07.628355
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test case 1:
    assert RoleRequirement().role_yaml_parse('geerlingguy.java') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': None}
    # Test case 2:
    assert RoleRequirement().role_yaml_parse('geerlingguy.java,1.8') == {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.8'}
    # Test case 3:

# Generated at 2022-06-11 10:54:18.362664
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    print("RoleRequirement, Testing role_yaml_parse")
    print("- Old style string with two fields")
    role = role_requirement.role_yaml_parse("foo,1.2,bar")
    assert role["src"] == "foo"
    assert role["version"] == "1.2"
    assert role["name"] == "bar"
    print("-- Old style string with two fields passed")
    print("- Old style string with one field")
    role = role_requirement.role_yaml_parse("foo,1.2")
    assert role["src"] == "foo"
    assert role["version"] == "1.2"
    assert role["name"] == "foo"
    print("-- Old style string with one field passed")

# Generated at 2022-06-11 10:54:24.622495
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    """
    Basic test to ensure is_private_address produces the expected output
    """
    assert RoleRequirement.repo_url_to_role_name("http://www.foo.com/bar.git") == "bar"
    assert RoleRequirement.repo_url_to_role_name("http://www.foo.com/bar@1.1.git") == "bar@1.1"
    assert RoleRequirement.repo_url_to_role_name("http://www.foo.com/repos/bar@1.1.git") == "bar@1.1"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/username/repository") == "repository"

# Generated at 2022-06-11 10:54:35.444045
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print("In test_RoleRequirement_role_yaml_parse")
    # method role_yaml_parse takes as input a role of the following form
    # role = "galaxy.role,version,name"
    # It returns a dictionary with the values necessary for the Ansible Role
    # Allowed formats for "role" are
    # 1. galaxy.role
    # 2. scm+url,version,name
    # 3. url,version,name

    # Test with a galaxy.role
    role = 'galaxy.role'
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == 'role'
    assert result['src'] == 'galaxy.role'
    assert result['version'] == ''
    assert result['scm'] is None

    # Test with a scm+url

# Generated at 2022-06-11 10:54:45.461225
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # test running through
    test_RoleRequirement = RoleRequirement()
    method = test_RoleRequirement.repo_url_to_role_name

    # test default (null)
    assert method(None) == None

    # test 'git://...'
    assert method('https://github.com/username/repo.git') == 'repo'

    # test 'git@...'
    assert method('git@github.com:username/repo.git') == 'repo'

    # test 'repo'
    assert method('username.repo') == 'username.repo'

    # test 'repo.git'
    assert method('username.repo.git') == 'username.repo'

    # test 'repo.tar.gz'

# Generated at 2022-06-11 10:54:50.661976
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    from ansible.plugins.loader import role_loader
    role_loader.add_directory("./test/mock/galaxy/collective/mazer/test_role_requirement_repo_url_to_role_name")
    role_info, role_data = role_loader._load_role_definition("test_role_requirement_repo_url_to_role_name")
    assert role_info.get("name", None) == "test_role_requirement_repo_url_to_role_name"


# Generated at 2022-06-11 10:55:00.506870
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = {'role': 'foo,bar'}
    role_yaml = RoleRequirement.role_yaml_parse(role)
    assert role_yaml == {'name': 'foo', 'version': 'bar', 'scm': None, 'src': None}
    role = {'role': 'git+git://git.example.com/repos/repo.git,branch'}
    role_yaml = RoleRequirement.role_yaml_parse(role)
    assert role_yaml == {'name': 'repo', 'version': 'branch', 'scm': 'git', 'src': 'git://git.example.com/repos/repo.git'}
    role = {'role': 'git+git@git.example.com:repos/repo.git,branch'}


# Generated at 2022-06-11 10:55:10.508560
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Case 1: String without '://' or '@' characters
    repo_url = "ansible-role-nginx"
    assert RoleRequirement.repo_url_to_role_name(repo_url) == "ansible-role-nginx"

    # Case 3: Trailing path ends with '.git'
    repo_url = "https://github.com/geerlingguy/ansible-role-nginx.git"
    assert RoleRequirement.repo_url_to_role_name(repo_url) == "ansible-role-nginx"

    # Case 4: Trailing path ends with '.tar.gz'
    repo_url = "https://github.com/ansible-galaxy/ansible-galaxy/archive/v2.2.0.tar.gz"

# Generated at 2022-06-11 10:55:20.051874
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    ''' test the repo_url_to_role_name method '''

    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com:repos/repo.git') == 'repo'

# Generated at 2022-06-11 10:56:03.919452
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import nose.tools as nt
    import os
    import tempfile
    import shutil

    fd, tmp = tempfile.mkstemp()

# Generated at 2022-06-11 10:56:14.834584
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    x = RoleRequirement()

# Generated at 2022-06-11 10:56:21.606518
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:56:31.850554
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml_parse = RoleRequirement.role_yaml_parse
    assert {"name": "myrole", "src": "git@github.com:me/myrole.git", "scm": "git", "version": "1.2"}, role_yaml_parse(
        {"name": "myrole", "scm": "git", "src": "git@github.com:me/myrole.git", "version": "1.2"})

# Generated at 2022-06-11 10:56:41.995154
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test 1
    input_role = 'weareinteractive.ansible-role-redis'
    output_role = RoleRequirement.role_yaml_parse(input_role)
    assert output_role['name'] == 'weareinteractive.ansible-role-redis'
    assert output_role['src'] == 'weareinteractive.ansible-role-redis'
    assert output_role['version'] == ''
    assert output_role['scm'] == None

    # Test 2
    input_role = 'weareinteractive.ansible-role-redis,dev-feature-redis'
    output_role = RoleRequirement.role_yaml_parse(input_role)
    assert output_role['name'] == 'weareinteractive.ansible-role-redis'
    assert output_role

# Generated at 2022-06-11 10:56:46.735044
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/user/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/repo/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("user@git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/user/repo.git") == "repo"
    assert RoleRequirement.repo_url

# Generated at 2022-06-11 10:56:56.536160
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml_parse = RoleRequirement.role_yaml_parse

    result = role_yaml_parse("contrib.hostsinventory")
    assert result == {'name': 'contrib.hostsinventory', 'src': 'contrib.hostsinventory', 'scm': None, 'version': None}

    result = role_yaml_parse("contrib.hostsinventory,v1")
    assert result == {'name': 'contrib.hostsinventory', 'src': 'contrib.hostsinventory', 'scm': None, 'version': 'v1'}

    result = role_yaml_parse("contrib.hostsinventory,v1,alias")
    assert result == {'name': 'alias', 'src': 'contrib.hostsinventory', 'scm': None, 'version': 'v1'}



# Generated at 2022-06-11 10:57:05.615171
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    print("Testing role_yaml_parse")

    role = 'geerlingguy.git'
    print("Testing role_yaml_parse for: %s" % role)
    role_info = RoleRequirement.role_yaml_parse(role)
    assert role_info['name'] == 'git'
    assert role_info['scm'] == 'galaxy'
    assert role_info['src'] == 'geerlingguy.git'
    assert role_info['version'] == ''

    role = 'ansible.git,2.3.0.0'
    print("Testing role_yaml_parse for: %s" % role)
    role_info = RoleRequirement.role_yaml_parse(role)
    assert role_info['name'] == 'git'

# Generated at 2022-06-11 10:57:15.983579
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:57:26.145964
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com/repos/repo.git") == "repo"
    assert RoleRequ

# Generated at 2022-06-11 10:58:41.967588
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # testing
    assert (RoleRequirement.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo')
    assert (RoleRequirement.repo_url_to_role_name('git://git.example.com/repos/repo.tar.gz') == 'repo')
    assert (RoleRequirement.repo_url_to_role_name('user@example.com:repo') == 'repo')
    assert (RoleRequirement.repo_url_to_role_name('user@example.com:repo.git') == 'repo')
    assert (RoleRequirement.repo_url_to_role_name('https://git.example.com/repos/repo.git') == 'repo')

# Generated at 2022-06-11 10:58:49.920621
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('https://github.com/foo/bar.git') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('git+https://github.com/foo/bar.git') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/foo/bar.git,v1.0') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/foo/bar.git,v1.0,myrole') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('git+https://github.com/foo/bar.git,v1.0,myrole') == 'bar'
    assert RoleRequ

# Generated at 2022-06-11 10:58:59.163184
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:59:08.745025
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert RoleRequirement.role_yaml_parse("test-role-1") == dict(name="test-role-1", scm=None, src=None, version=""), 'test failed'
    assert RoleRequirement.role_yaml_parse("bob.test-role-1") == dict(name="bob.test-role-1", scm=None, src=None, version=""), 'test failed'
    assert RoleRequirement.role_yaml_parse("nested.bob.test-role-1") == dict(name="nested.bob.test-role-1", scm=None, src=None, version=""), 'test failed'

# Generated at 2022-06-11 10:59:17.721717
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Valid role line
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git,v1.2.3,foo') == {
        'name': 'foo', 'version': 'v1.2.3', 'scm': None, 'src': 'http://git.example.com/repos/repo.git'
    }
    assert RoleRequirement.role_yaml_parse('git+http://git.example.com/repos/repo.git,v1.2.3,foo') == {
        'name': 'foo', 'version': 'v1.2.3', 'scm': 'git', 'src': 'http://git.example.com/repos/repo.git'
    }
    assert RoleRequirement.role_yaml_parse

# Generated at 2022-06-11 10:59:26.642610
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    assert RoleRequirement.repo_url_to_role_name("my-role") == "my-role"
    assert RoleRequirement.repo_url_to_role_name("my-role,v1") == "my-role"
    assert RoleRequirement.repo_url_to_role_name("my-role,v1,new-name") == "my-role"
    assert RoleRequirement.repo_url_to_role_name("/path/to/my-role") == "my-role"
    assert RoleRequirement.repo_url_to_role_name("/path/to/my-role.git") == "my-role"
    assert RoleRequirement.repo_url_to_role_name("/path/to/my-role.tar.gz") == "my-role"


# Generated at 2022-06-11 10:59:37.190866
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    def test_valid_role_name(url, name):
        assert RoleRequirement.repo_url_to_role_name(url) == name

    # repo_url without scheme and without @
    test_valid_role_name("git@git.example.com/repos/repo.git", "repo")
    test_valid_role_name("http://git.example.com/repos/repo.git", "repo")
    # repo_url without .git suffix
    test_valid_role_name("http://git.example.com/repos/repo", "repo")
    # repo_url with .git suffix
    test_valid_role_name("http://git.example.com/repos/repo.git", "repo")
    # repo_url without scheme and with @
    test