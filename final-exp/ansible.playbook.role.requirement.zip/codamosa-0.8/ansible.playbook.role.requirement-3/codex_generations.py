

# Generated at 2022-06-11 10:49:59.728278
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,v1.0') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,user:name') == 'repo'

# Generated at 2022-06-11 10:50:10.714499
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    r = RoleRequirement()
    assert r.role_yaml_parse('valid_role') == {'name': 'valid_role', 'scm': None, 'src': 'valid_role', 'version': ''}
    assert r.role_yaml_parse('valid_role,v1.0') == {'name': 'valid_role', 'scm': None, 'src': 'valid_role', 'version': 'v1.0'}
    assert r.role_yaml_parse('valid_role,v1.0,my_role') == {'name': 'my_role', 'scm': None, 'src': 'valid_role', 'version': 'v1.0'}

# Generated at 2022-06-11 10:50:21.766109
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.playbook.role.definition import RoleDefinition
    role = RoleDefinition()
    role.name = "test_role"
    role.version = "1.0"
    role.scm = "git"
    role.src = "test_src"

    role_dict = RoleRequirement.role_yaml_parse("test_name,1.0,git+test_src")
    assert role_dict.get("name") == role.name
    assert role_dict.get("version") == role.version
    assert role_dict.get("scm") == role.scm
    assert role_dict.get("src") == role.src
    assert not role_dict.get("rolename")


# Generated at 2022-06-11 10:50:33.157147
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:50:41.087351
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:50:52.729959
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:51:02.783787
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://example.com/foobar.git") == "foobar", "Failed to parse repo name"
    assert RoleRequirement.repo_url_to_role_name("git+http://example.com/foobar.git") == "foobar", "Failed to parse repo name with git+ prefix"
    assert RoleRequirement.repo_url_to_role_name("foobar") == "foobar", "Failed to parse repo without .git extension"
    assert RoleRequirement.repo_url_to_role_name("git+http://example.com/foobar.git,v1.1") == "foobar,v1.1", "Failed to parse repo name with git+ prefix and a version"
    assert RoleRequirement.repo_url_

# Generated at 2022-06-11 10:51:14.707798
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # assert repo_url_to_role_name
    assert RoleRequirement.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-ntp") == "ansible-role-ntp"

    # assert repo_url_to_role_name
    assert RoleRequirement.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-ntp.git") == "ansible-role-ntp"

    # assert repo_url_to_role_name
    assert RoleRequirement.repo_url_to_role_name("https://github.com/geerlingguy/ansible-role-ntp,v1.0") == "ansible-role-ntp"

    # assert repo_url_to_role_name

# Generated at 2022-06-11 10:51:24.334460
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert( RoleRequirement.role_yaml_parse( 'myrole' ) == {'version': None, 'name': 'myrole', 'src': 'myrole', 'scm': None} )
    assert( RoleRequirement.role_yaml_parse( 'myrole,v1' ) == {'version': 'v1', 'name': 'myrole', 'src': 'myrole', 'scm': None} )
    assert( RoleRequirement.role_yaml_parse( 'myrole,v1,othername' ) == {'version': 'v1', 'name': 'othername', 'src': 'myrole', 'scm': None} )

# Generated at 2022-06-11 10:51:28.329569
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    rr = RoleRequirement()

    repo_url = "http://git.example.com/repos/repo.git"
    role_name = rr.repo_url_to_role_name(repo_url)
    assert role_name == "repo"


# Generated at 2022-06-11 10:52:04.294757
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test single string role spec
    role = "geerlingguy.apache"
    name = "apache"
    parsed = RoleRequirement.role_yaml_parse(role)
    assert(parsed["name"] == name)
    assert(parsed["version"] == "")
    assert(parsed["scm"] == None)
    assert(parsed["src"] == role)
    role = "geerlingguy.apache,2.4"
    version = "2.4"
    parsed = RoleRequirement.role_yaml_parse(role)
    assert(parsed["name"] == name)
    assert(parsed["version"] == version)
    assert(parsed["src"] == parsed["name"] + "," + version)

# Generated at 2022-06-11 10:52:15.680388
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_def = RoleRequirement()

    print (role_def.role_yaml_parse(role="michel.dehaan,1.0,test"))
    assert(role_def.role_yaml_parse(role="michel.dehaan,1.0,test") == dict(name="michel.dehaan", src="michel.dehaan", scm=None, version="1.0"))
    assert(role_def.role_yaml_parse(role="michel.dehaan,,test") == dict(name="michel.dehaan", src="michel.dehaan", scm=None, version=''))

# Generated at 2022-06-11 10:52:28.553039
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for different posible values defined for role in requirements.yml or meta/main.yml
    assert RoleRequirement.role_yaml_parse(role="requirement_name") == {'name': 'requirement_name', 'src': 'requirement_name', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse(role="requirement_name,version") == {'name': 'requirement_name', 'src': 'requirement_name', 'scm': None, 'version': 'version'}
    assert RoleRequirement.role_yaml_parse(role="requirement_name,version,name") == {'name': 'name', 'src': 'requirement_name', 'scm': None, 'version': 'version'}
    assert RoleRequirement.role_yaml_parse

# Generated at 2022-06-11 10:52:38.352319
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git') == {'name': 'repo', 'scm': None, 'src': 'http://git.example.com/repos/repo.git', 'version': None}
    assert RoleRequirement.role_yaml_parse('git+http://git.example.com/repos/repo.git') == {'name': 'repo', 'scm': 'git', 'src': 'http://git.example.com/repos/repo.git', 'version': None}

# Generated at 2022-06-11 10:52:48.032985
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    yaml_txt = "foo,v0.1"
    assert RoleRequirement.role_yaml_parse(yaml_txt) == dict(name="foo", version="v0.1", scm=None, src="foo")
    yaml_txt = "foo"
    assert RoleRequirement.role_yaml_parse(yaml_txt) == dict(name="foo", version=None, scm=None, src="foo")
    yaml_txt = "foo,v0.1,bar"
    assert RoleRequirement.role_yaml_parse(yaml_txt) == dict(name="bar", version="v0.1", scm=None, src="foo")
    yaml_txt = "geerlingguy.foo"

# Generated at 2022-06-11 10:52:58.829356
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse(dict(src='https://github.com/foo/bar')) == dict(scm=None, src='https://github.com/foo/bar', name='bar', version=None)
    assert RoleRequirement.role_yaml_parse(dict(src='https://github.com/foo/bar+master')) == dict(scm='https://github.com/foo/', src='bar+master', name='bar', version=None)
    assert RoleRequirement.role_yaml_parse(dict(src='git+https://github.com/foo/bar+master')) == dict(scm='git', src='https://github.com/foo/bar+master', name='bar', version=None)

# Generated at 2022-06-11 10:53:08.290305
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Old Style
    role_requirement = RoleRequirement()
    role = role_requirement.role_yaml_parse('role_name')
    assert role['name'] == 'role_name'
    assert role['src'] is None
    assert role['scm'] is None
    assert role['version'] is None

    role = role_requirement.role_yaml_parse('role_name,v1.2')
    assert role['name'] == 'role_name'
    assert role['src'] is None
    assert role['scm'] is None
    assert role['version'] == 'v1.2'

    role = role_requirement.role_yaml_parse('role_name,v1.2,new_name')
    assert role['name'] == 'new_name'
    assert role['src'] is None


# Generated at 2022-06-11 10:53:17.697352
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_yaml_parse = ''' 
        - { role: aws-cloudwatch, version: '0.0.2' }
    '''
    result = RoleRequirement.role_yaml_parse(role_yaml_parse)
    assert result['name'] == 'aws-cloudwatch'
    assert result['src'] == 'aws-cloudwatch'
    assert result['version'] == '0.0.2'

    role_yaml_parse = ''' 
        - { role: aws-cloudwatch, src: 'github.com/lol.git' }
    '''
    result = RoleRequirement.role_yaml_parse(role_yaml_parse)
    assert result['name'] == 'aws-cloudwatch'
    assert result['src'] == 'github.com/lol.git'
    assert result

# Generated at 2022-06-11 10:53:27.787497
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git.tar.gz") == "repo.git"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.2") == "repo.git"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.2,foo") == "repo.git"

# Generated at 2022-06-11 10:53:35.707639
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print("role_yaml_parse: testing")
    rr = RoleRequirement()


# Generated at 2022-06-11 10:53:54.445828
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    rr = RoleRequirement()

    list_of_tuples = [('git@git.example.com:repo.git', 'repo'),
                      ('http://git.example.com/repos/a.git', 'a'),
                      ('../relative/path', 'path'),
                      ('galaxy.role,foo', 'galaxy.role')]

    for repo_url, expected_result in list_of_tuples:
        result = rr.repo_url_to_role_name(repo_url)
        assert result == expected_result, 'Expected result "%s", got "%s"' % (expected_result, result)


# Generated at 2022-06-11 10:54:05.103835
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    requirement1 = RoleRequirement.role_yaml_parse('geerlingguy.java')
    assert requirement1['name'] == 'geerlingguy.java'
    assert requirement1['src'] == 'https://github.com/geerlingguy/ansible-role-java.git'
    assert requirement1['scm'] == 'git'
    assert requirement1['version'] == ''

    requirement2 = RoleRequirement.role_yaml_parse('example.com,1.0')
    assert requirement2['name'] == 'example.com'
    assert requirement2['src'] == 'example.com'
    assert requirement2['scm'] is None
    assert requirement2['version'] == '1.0'

    requirement3 = RoleRequirement.role_yaml_parse('https://example.com,1.0')
    assert requirement

# Generated at 2022-06-11 10:54:15.893841
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:54:23.710387
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    assert RoleRequirement.repo_url_to_role_name("ansible-modules-core") == "ansible-modules-core"
    assert RoleRequirement.repo_url_to_role_name("git://github.com/ansible/ansible-modules-core") == "ansible-modules-core"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/ansible/ansible-modules-core.git") == "ansible-modules-core"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/ansible/ansible-modules-core.git,devel")

# Generated at 2022-06-11 10:54:34.523308
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    inputs = [
        "test_role,v1.0.0",
        "test_role",
        { 'role': 'test_role' },
        { 'role': 'test_role,v1.0.0' },
        { 'src': 'test_role,v1.0.0', 'name': 'test_role_yaml_parse' }
    ]


# Generated at 2022-06-11 10:54:44.707843
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # call the method to be tested
    result = RoleRequirement.role_yaml_parse("test_role")
    assert result == dict(name="test_role", src='test_role', scm=None, version='')

    result = RoleRequirement.role_yaml_parse("test_role,v1.0")
    assert result == dict(name="test_role", src='test_role', scm=None, version='v1.0')

    result = RoleRequirement.role_yaml_parse("test_role,v1.0,myname")
    assert result == dict(name="myname", src='test_role', scm=None, version='v1.0')


# Generated at 2022-06-11 10:54:51.760499
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Case 1: test for Old style role
    role = "galaxy.role"

    result = RoleRequirement.role_yaml_parse(role)
    assert result == dict(name='galaxy.role', src='galaxy.role', scm=None, version='')

    # Case 2: test for New style role
    role = dict(src='galaxy.role')

    result = RoleRequirement.role_yaml_parse(role)
    assert result == dict(name='galaxy.role', src='galaxy.role', scm=None, version='')

    # Case 3: test for Old style role with version
    role = "galaxy.role,v1"

    result = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-11 10:54:56.562507
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert (RoleRequirement.repo_url_to_role_name('https://github.com/example/repo.git')
            == 'repo')
    assert (RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git')
            == 'repo')

# Generated at 2022-06-11 10:55:00.895683
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    result = RoleRequirement.role_yaml_parse('this.is.a.role,1.2.3')
    assert result == {'name': 'this.is.a.role', 'scm': None, 'src': 'this.is.a.role', 'version': '1.2.3'}


# Generated at 2022-06-11 10:55:10.757232
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('foo') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse('foo,v1') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': 'v1'}
    assert RoleRequirement.role_yaml_parse('bar,v1,foo') == {'name': 'foo', 'src': 'bar', 'scm': None, 'version': 'v1'}

# Generated at 2022-06-11 10:55:29.901419
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import unittest

    class TestRoleRequirement(unittest.TestCase):
        def test_requirement_1(self):
            req_string = "http://github.com/example/repo.git,1.0,foo"
            result = RoleRequirement.role_yaml_parse(req_string)
            self.assertEqual(result, dict(name='repo', src='http://github.com/example/repo.git', scm='git', version='1.0'))

        def test_requirement_2(self):
            req_string = "hg+http://bitbucket.com/example/repo"
            result = RoleRequirement.role_yaml_parse(req_string)

# Generated at 2022-06-11 10:55:39.070496
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:55:49.722884
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """
    Test the method role_yaml_parse of the class RoleRequirement
    """
    from ansible.utils.hashing import md5s

# Generated at 2022-06-11 10:55:57.182852
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    display.debug("Running unit test for method role_yaml_parse of class RoleRequirement")


# Generated at 2022-06-11 10:56:08.682780
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:56:18.281194
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:56:21.544498
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    role_name = role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git")

    assert role_name == 'repo'


# Generated at 2022-06-11 10:56:31.803519
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:56:41.950882
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Plain name
    print(RoleRequirement.role_yaml_parse('Common'))

    # Name and version
    print(RoleRequirement.role_yaml_parse('Common,1.0.0'))

    # Name version and repository name
    print(RoleRequirement.role_yaml_parse('Common,1.0.0,Some_Name'))

    # GitHub short URL
    print(RoleRequirement.role_yaml_parse('geerlingguy.docker'))

    # GitHub URL
    print(RoleRequirement.role_yaml_parse('https://github.com/geerlingguy/ansible-role-docker'))

    # GitHub URL with branch and path

# Generated at 2022-06-11 10:56:45.396402
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git@github.com:foo/bar.git") == 'bar'
    assert RoleRequirement.repo_url_to_role_name("http://github.com/foo/bar.git") == 'bar'
    assert RoleRequirement.repo_url_to_role_name("bar") == 'bar'
    assert RoleRequirement.repo_url_to_role_name("https://github.com/foo/bar.git") == 'bar'

# Generated at 2022-06-11 10:57:21.611027
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print("Testing method role_yaml_parse of class RoleRequirement")
    # Test for:
    #     (1) Old style with "role" key
    #     (2) Old style with "src" key
    #     (3) New style
    role_1 = dict(role="some_name,some_src_name")
    role_2 = dict(src="some_name,some_src_name")
    role_3 = dict(name="some_name", src="some_src_name")
    role_4 = dict(name="some_name", src="some_src_name", scm="git")
    role_5 = dict(name="some_name", src="some_src_name", version="1.0")

# Generated at 2022-06-11 10:57:31.139298
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    requirement = RoleRequirement()
    # test for name, version, src
    assert requirement.role_yaml_parse("http://github.com/namenode/hadoop-ansible.git,1.0.3,hadoop_ansible") == {'scm': None, 'src': 'http://github.com/namenode/hadoop-ansible.git', 'name': 'hadoop_ansible', 'version': '1.0.3'}
    # test for name, src

# Generated at 2022-06-11 10:57:41.871945
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:57:52.077255
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name(
        'https://github.com/geerlingguy/ansible-role-git.git') == 'ansible-role-git'
    assert RoleRequirement.repo_url_to_role_name(
        'https://github.com/geerlingguy/ansible-role-git,1.9.6,geerlingguy.git') == 'ansible-role-git'
    assert RoleRequirement.repo_url_to_role_name(
        'git+git@github.com:geerlingguy/ansible-role-git.git') == 'ansible-role-git'

# Generated at 2022-06-11 10:57:54.943806
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    from ansible.playbook.role.definition import RoleDefinition

    RoleRequirement.role_yaml_parse({'role': 'git+https://github.com/geerlingguy/ansible-role-apache.git'})

# Generated at 2022-06-11 10:58:04.998187
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    test_role_requirement = RoleRequirement()
    assert test_role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == 'repo'
    assert test_role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo") == 'repo'
    assert test_role_requirement.repo_url_to_role_name("example.com/some/repo.git") == 'repo'
    assert test_role_requirement.repo_url_to_role_name("user@example.com/some/repo.git") == 'repo'

# Generated at 2022-06-11 10:58:08.942754
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_data = dict(name="test", src='test_src', scm='test_scm', version='test_version')

    assert RoleRequirement.role_yaml_parse('test') == test_data
    assert RoleRequirement.role_yaml_parse(test_data) == test_data

# Generated at 2022-06-11 10:58:18.649746
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test old style yaml
    role = RoleRequirement.role_yaml_parse("geerlingguy.java")
    assert role['name'] == 'geerlingguy.java'
    assert role['version'] == ''
    assert role['scm'] is None

    # test 2.2 style yaml
    role = RoleRequirement.role_yaml_parse("roles: [{role: geerlingguy.java}]")
    assert role['name'] == 'geerlingguy.java'
    assert role['version'] == ''
    assert role['scm'] is None

    # test 2.2 style yaml with specific version
    role = RoleRequirement.role_yaml_parse("roles: [{role: geerlingguy.java, version: '>=1,<2'}]")
    assert role

# Generated at 2022-06-11 10:58:23.909209
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    os.chdir(TestUtils.WORK_DIR)

    # test git@github.com:ansible/ansible-docker-base.git
    repo_url = "git@github.com:ansible/ansible-docker-base.git"
    role_name = RoleRequirement.repo_url_to_role_name(repo_url)
    TestUtils.assertEquals("ansible-docker-base", role_name)

    # test http://git.example.com/repos/repo.git
    repo_url = "http://git.example.com/repos/repo.git"
    role_name = RoleRequirement.repo_url_to_role_name(repo_url)
    TestUtils.assertEquals("repo", role_name)

    # test http://git

# Generated at 2022-06-11 10:58:33.794782
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    result = RoleRequirement.role_yaml_parse({'role': 'example.com/repo.git,1.0.0,name'})
    assert result == {'name': 'name', 'scm': None, 'src': 'example.com/repo.git', 'version': '1.0.0'}

    result = RoleRequirement.role_yaml_parse({'role': 'example.com/repo.git,1.0.0'})
    assert result == {'name': 'repo', 'scm': None, 'src': 'example.com/repo.git', 'version': '1.0.0'}

    result = RoleRequirement.role_yaml_parse({'role': 'example.com/repo.git'})

# Generated at 2022-06-11 10:59:12.612110
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # This test implicitly checks that the method role_yaml_parse exists.
    role_yaml_parse = RoleRequirement.role_yaml_parse
    if role_yaml_parse is None:
        raise ValueError("The method role_yaml_parse should exist.")

    # This test implicitly checks that the method role_yaml_parse works.
    # (It also implicitly tests the function repo_url_to_role_name.)
    test_input = "role_name,version,name"
    test_output = {"name": "name", "version": "version", "src": "role_name"}
    assert role_yaml_parse(test_input) == test_output


# Generated at 2022-06-11 10:59:21.511743
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test with string
    role_string = 'nocm.docker,1.4.3,twitter.docker'

    # Correct name
    assert RoleRequirement.role_yaml_parse(role_string)['name'] == "twitter.docker"

    # Correct src
    assert RoleRequirement.role_yaml_parse(role_string)['src'] == "nocm.docker,1.4.3,twitter.docker"

    # Correct scm
    assert RoleRequirement.role_yaml_parse(role_string)['scm'] == None

    # Correct version
    assert RoleRequirement.role_yaml_parse(role_string)['version'] == None

    # Test with dict
    role_dict = {'src': 'nocm.docker,1.4.3,twitter.docker'}

    #

# Generated at 2022-06-11 10:59:30.473888
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert("repo" == RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git"))
    assert("repo" == RoleRequirement.repo_url_to_role_name("https://github.com/example.git"))
    assert("repo" == RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz"))
    assert("repo" == RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0"))

# Generated at 2022-06-11 10:59:40.614385
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    rr = RoleRequirement()
    # Test for Invalid role line (name). Proper format is 'role_name[,version[,name]]'
    r = 'geerlingguy.docker,0.3.3,geerlingguy.docker,0.3.3'
    try:
        rr.role_yaml_parse(r)
    except Exception as e:
        assert str(e) == "Invalid role line (%s). Proper format is 'role_name[,version[,name]]'" % r
    else:
        assert 0, "Did not catch exception"
    # Test for Invalid old style role requirement: geerlingguy.docker,0.3.3,geerlingguy.docker