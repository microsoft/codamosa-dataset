

# Generated at 2022-06-11 10:49:53.910453
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Test for URL without dot extension
    assert RoleRequirement.repo_url_to_role_name("http://github.com/michaeljcoyne/ansible-role-jenkins-worker") == "ansible-role-jenkins-worker"

    # Test for URL with one dot extension
    assert RoleRequirement.repo_url_to_role_name("http://github.com/michaeljcoyne/ansible-role-jenkins-worker.git") == "ansible-role-jenkins-worker"

    # Test for URL with two dot extension
    assert RoleRequirement.repo_url_to_role_name("http://github.com/michaeljcoyne/ansible-role-jenkins-worker.tar.gz") == "ansible-role-jenkins-worker"

    # Test for URL with a version

# Generated at 2022-06-11 10:50:04.680121
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """
    Unit test for RoleRequirement.role_yaml_parse.
    """
    role_requirement = RoleRequirement()

# Generated at 2022-06-11 10:50:07.379635
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    result = RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git')
    assert result == 'repo'

# Generated at 2022-06-11 10:50:12.717735
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    from ansible.playbook.role.requirement import RoleRequirement
    # regression test for role name parsing
    repo_url = "http://git.example.com/repos/repo.git"
    role_name = RoleRequirement.repo_url_to_role_name(repo_url)
    assert role_name == "repo"


# Generated at 2022-06-11 10:50:23.203984
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    assert role_requirement.role_yaml_parse('http://git.example.com/repos/repo.git') == {'name': 'repo', 'src': u'http://git.example.com/repos/repo.git', 'scm': None, 'version': None}
    assert role_requirement.role_yaml_parse('http://git.example.com/repos/repo.git,v1') == {'name': 'repo', 'src': u'http://git.example.com/repos/repo.git', 'scm': None, 'version': u'v1'}

# Generated at 2022-06-11 10:50:34.160480
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:50:41.497273
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # The following asserts are valid
    assert RoleRequirement.role_yaml_parse(
        'https://github.com/thegeekstuff/geekstuff.git') == {
        'name': 'geekstuff', 'src': 'https://github.com/thegeekstuff/geekstuff.git', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse(
        'https://github.com/thegeekstuff/geekstuff.git,v1.0') == {
        'name': 'geekstuff', 'src': 'https://github.com/thegeekstuff/geekstuff.git', 'scm': None, 'version': 'v1.0'}

# Generated at 2022-06-11 10:50:53.149623
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # test with a string
    result = RoleRequirement.role_yaml_parse("http://www.example.com/role.git,1.0")
    assert result == dict(src="http://www.example.com/role.git", scm=None, name="role", version="1.0")
    result = RoleRequirement.role_yaml_parse("somebody.somewhere:1234/role.git,1.0")
    assert result == dict(src="somebody.somewhere:1234/role.git", scm=None, name="role", version="1.0")

    # test with a dict
    result = RoleRequirement.role_yaml_parse({
        "role": "http://www.example.com/role.git,1.0",
    })

# Generated at 2022-06-11 10:51:03.087277
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = 'foo'
    role_result = dict(name='foo', scm=None, src=None, version=None)
    assert RoleRequirement.role_yaml_parse(role) == role_result
    role = 'foo,v1'
    role_result = dict(name='foo', scm=None, src=None, version='v1')
    assert RoleRequirement.role_yaml_parse(role) == role_result
    role = 'foo,v1,bar'
    role_result = dict(name='bar', scm=None, src=None, version='v1')
    assert RoleRequirement.role_yaml_parse(role) == role_result
    role = 'https://github.com/foo/bar.git'

# Generated at 2022-06-11 10:51:15.084195
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert RoleRequirement.role_yaml_parse('http://github.com/user/repo,v1.2,role_name') == dict(name='role_name', src='http://github.com/user/repo', scm='git', version='v1.2')
    assert RoleRequirement.role_yaml_parse('user.role_name') == dict(name='role_name', src='user.role_name', scm=None, version=None)
    assert RoleRequirement.role_yaml_parse('user.role_name,v1.2,role_name') == dict(name='role_name', src='user.role_name', scm=None, version='v1.2')

# Generated at 2022-06-11 10:51:47.524012
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    def test_role_yaml_parse(role, expected_result):
        if isinstance(role, string_types):
            # string role
            role_dict = RoleRequirement.role_yaml_parse(role)
            assert role_dict == expected_result
        else:
            # dict role
            for version in version_list:
                role_dict = RoleRequirement.role_yaml_parse(role)
                assert role_dict == expected_result

    # valid string roles

# Generated at 2022-06-11 10:52:00.787494
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_requirement= RoleRequirement()

    # test_role_yaml_parse_string_types

    result = role_requirement.role_yaml_parse("git+http://git.example.com/repos/repo.git")
    assert result['name'] == "repo"
    assert result['scm'] == "git"
    assert result['src'] == "http://git.example.com/repos/repo.git"
    assert result['version'] == ""

    result = role_requirement.role_yaml_parse("git+http://git.example.com/repos/repo.git,1.2")
    assert result['name'] == "repo"
    assert result['scm'] == "git"

# Generated at 2022-06-11 10:52:12.836341
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:52:23.998840
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    test_cases = [
        "http://git.example.com/repos/repo.git",
        "http://git.example.com/repos/repo",
        "http://git.example.com/repos/repo.tar.gz",
        "https://github.com/user/repo.git",
        "https://github.com/user/repo.tar.gz",
        "git+https://github.com/user/repo.git",
        "git+https://github.com/user/repo.tar.gz",
    ]
    for role_url in test_cases:
        role_name = RoleRequirement.repo_url_to_role_name(role_url)

# Generated at 2022-06-11 10:52:34.921933
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """
    Test roleyamlparse method of RoleRequirement class
    """
    display.vvv("Testing RoleRequirement.role_yaml_parse")
    assert RoleRequirement.role_yaml_parse("src: https://github.com/foo/bar.git") == {'src': 'https://github.com/foo/bar.git', 'name': 'bar', 'scm': 'git', 'version': ''}
    assert RoleRequirement.role_yaml_parse("src: http://github.com/foo/bar.git") == {'src': 'http://github.com/foo/bar.git', 'name': 'bar', 'scm': 'git', 'version': ''}

# Generated at 2022-06-11 10:52:42.916394
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("ANXS.postgresql") == dict(name="ANXS.postgresql", src="ANXS.postgresql", scm=None, version="")
    assert RoleRequirement.role_yaml_parse("ANXS.postgresql,v1.0") == dict(name="ANXS.postgresql", src="ANXS.postgresql", scm=None, version="v1.0")
    assert RoleRequirement.role_yaml_parse("github.com/ANXS/postgresql") == dict(name="postgresql", src="github.com/ANXS/postgresql", scm=None, version="")

# Generated at 2022-06-11 10:52:53.407208
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    repo_url = "hello"
    display.display('%s ==> %s' % (repo_url, RoleRequirement.repo_url_to_role_name(repo_url)))
    repo_url = "hello.git"
    display.display('%s ==> %s' % (repo_url, RoleRequirement.repo_url_to_role_name(repo_url)))
    repo_url = "http://hello.com/repos/hello/hello.git"
    display.display('%s ==> %s' % (repo_url, RoleRequirement.repo_url_to_role_name(repo_url)))
    repo_url = "http://hello.com/repos/hello/hello"

# Generated at 2022-06-11 10:53:04.109231
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:53:11.762955
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    display.verbosity = 3
    display.deprecated("role_yaml_parse","","")
    display.v("TESTING role_yaml_parse")

    role_req = RoleRequirement()

    # input, output

# Generated at 2022-06-11 10:53:21.648941
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.playbook.role.required import RoleRequirement
    from ansible.utils.display import Display
    display = Display()


# Generated at 2022-06-11 10:53:35.504676
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    display.vvvv('Test RoleRequirement_role_yaml_parse')
    assert RoleRequirement.role_yaml_parse("gdataviz.grafana_datasource,v1.6.0.0,gdataviz.grafana_datasource") == dict(name='gdataviz.grafana_datasource', src='gdataviz.grafana_datasource', scm=None, version='v1.6.0.0')

# Generated at 2022-06-11 10:53:46.676596
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = dict(role="some_role")
    assert RoleRequirement.role_yaml_parse(role) == dict(role="some_role")

    role = dict(role="some_role,v1")
    assert RoleRequirement.role_yaml_parse(role) == dict(role="some_role,v1")

    role = dict(role="some_role,v1,other")
    assert RoleRequirement.role_yaml_parse(role) == dict(role="some_role,v1,other")

    role = dict(role="role_name,version,name")
    assert RoleRequirement.role_yaml_parse(role) == dict(role="role_name,version,name")

    role = dict(role="some_role,v1,other,v2")

# Generated at 2022-06-11 10:53:56.646858
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git@v1.0') == 'repo.git'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo@v1.0.tar.gz') == 'repo'

# Generated at 2022-06-11 10:54:08.383345
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    test_requirements_yml = {'galaxy': {'roles': ['username.repo']},
                             'file': {'dest': 'path/to/requirements.yml'}}
    # test that a string is returned dictified
    assert isinstance(RoleRequirement.role_yaml_parse('username.repo'), dict)

    # test that a dict with a name without a version is dictified
    assert isinstance(RoleRequirement.role_yaml_parse({'galaxy': {'roles': [{'role': 'username.repo'}]},
                                                       'file': {'path': 'path/to/requirements.yml'}}), dict)

    # test that a dict with a name and version is dictified

# Generated at 2022-06-11 10:54:18.944810
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("http://example.com/repo.git") == dict(name="repo", src="http://example.com/repo.git", scm=None, version="")
    assert RoleRequirement.role_yaml_parse("http://example.com/repo.git,v1.0") == dict(name="repo", src="http://example.com/repo.git", scm=None, version="v1.0")
    assert RoleRequirement.role_yaml_parse("git+http://example.com/repo.git,v1.0") == dict(name="repo", src="http://example.com/repo.git", scm="git", version="v1.0")

# Generated at 2022-06-11 10:54:29.126016
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Test with simple role name
    assert(RoleRequirement.repo_url_to_role_name('simple') == 'simple')

    # Test with repo url ending with .git
    assert(RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo')

    # Test with repo url ending with .tar.gz
    assert(RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo')

    # Test with repo url ending with .tar.gz
    assert(RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz,v2') == 'repo')

# Generated at 2022-06-11 10:54:39.347699
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    print(RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git'))
    # => 'repo'
    print(RoleRequirement.repo_url_to_role_name('git@git.example.com/repos/repo.git'))
    # => 'repo'
    print(RoleRequirement.repo_url_to_role_name('git@git.example.com/repos/repo,2.0.0,repo-2.0.0.tar.gz'))
    # => 'repo'
    print(RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo-2.0.0.tar.gz'))
    # => 'repo

# Generated at 2022-06-11 10:54:47.280924
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    result = RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-modules-core')
    assert result == 'ansible-modules-core'

    result = RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-modules-core,v1.0.10')
    assert result == 'ansible-modules-core'

    result = RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-modules-core,v1.0.10,test')
    assert result == 'test'


# Generated at 2022-06-11 10:54:56.877036
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:55:06.884878
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    from ansible.utils.display import Display
    from ansible.errors import AnsibleError

    display = Display()

    display.display("test: role_yaml_parse")

    try:
        role = RoleRequirement.role_yaml_parse("testrole1")
    except AnsibleError as e:
        display.display("* * * * * * * * * * * * * *")
        display.display("ERROR: %s" % str(e))
        display.display("* * * * * * * * * * * * * *")
        display.display("role: %s" % role)
        display.display("* * * * * * * * * * * * * *")
        raise
    else:
        display.display("role: %s" % role)


# Generated at 2022-06-11 10:55:27.803213
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:55:35.554227
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git@git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git#') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git#v0.1') == 'repo'

# Generated at 2022-06-11 10:55:45.999758
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Testing case: old-style  role: name, verion, src
    role_str_oldstyle = 'geerlingguy.apache, 1.0.0, https://github.com/geerlingguy/ansible-role-apache.git'
    role_dict_oldstyle = dict(name='geerlingguy.apache', scm=None, src='geerlingguy/ansible-role-apache.git', version='1.0.0')
    assert RoleRequirement.role_yaml_parse(role_str_oldstyle) == role_dict_oldstyle

    # Testing case: new-style role: src, version, name
    role_str_newstyle = 'https://github.com/geerlingguy/ansible-role-apache.git, 1.0.0, geerlingguy.apache'
    role

# Generated at 2022-06-11 10:55:55.161611
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = 'src_name'
    assert(RoleRequirement.role_yaml_parse(role) == {'name': 'src_name', 'src': 'src_name', 'scm': None, 'version': None})
    role = 'src_name,version'
    assert(RoleRequirement.role_yaml_parse(role) == {'name': 'src_name', 'src': 'src_name', 'scm': None, 'version': 'version'})
    role = 'src_name,version,name'
    assert(RoleRequirement.role_yaml_parse(role) == {'name': 'name', 'src': 'src_name', 'scm': None, 'version': 'version'})
    role = {'role': 'role_name'}

# Generated at 2022-06-11 10:56:05.888895
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for valid role format
    assert 'name' in RoleRequirement.role_yaml_parse("test_role")

    # Test for old style role format
    assert 'role' in RoleRequirement.role_yaml_parse(dict(role="test_role"))

    # Test for valid role format and with version
    assert RoleRequirement.role_yaml_parse("test_role,v1.0.0")['version'] == 'v1.0.0'
    assert RoleRequirement.role_yaml_parse("test_role,v1.0.0,new_name")['name'] == 'new_name'
    assert RoleRequirement.role_yaml_parse("test_role,v1.0.0,new_name")['version'] == 'v1.0.0'

    # Test for old style role

# Generated at 2022-06-11 10:56:16.420112
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    roledef = RoleRequirement.role_yaml_parse
    assert roledef('foo,v1.0') == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': 'v1.0'}
    assert roledef('http://example.com/foo/bar.git,v1.0') == {'name': 'bar', 'src': 'http://example.com/foo/bar.git', 'scm': None, 'version': 'v1.0'}
    assert roledef('git+http://example.com/foo/bar.git,baz') == {'name': 'baz', 'src': 'http://example.com/foo/bar.git', 'scm': 'git', 'version': ''}

# Generated at 2022-06-11 10:56:25.887191
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # test valid string
    result = RoleRequirement.role_yaml_parse("user.role")
    assert result == { "src": "user.role", "name": "user.role", "version": None, "scm": None }
    result = RoleRequirement.role_yaml_parse("user.role,1.2")
    assert result == { "src": "user.role", "version": "1.2", "scm": None, "name": "user.role" }
    result = RoleRequirement.role_yaml_parse("user.role,1.2,name")
    assert result == { "src": "user.role", "version": "1.2", "name": "name", "scm": None }
    print("test_RoleRequirement_role_yaml_parse: PASSED")

#

# Generated at 2022-06-11 10:56:36.080827
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_definitions = {}
    role_definitions['name'] = dict(name='jdoe.role1')
    role_definitions['src'] = dict(name='jdoe.role2', src='https://github.com/jdoe/ansible-role-role2.git', version='2.0')
    role_definitions['name_version'] = dict(name='jdoe.role3', src='https://github.com/jdoe/ansible-role-role3', version='2.0')
    role_definitions['name_version_scm'] = dict(name='jdoe.role4', src='https://github.com/jdoe/ansible-role-role4', scm='hg', version='2.0')

# Generated at 2022-06-11 10:56:45.368625
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_req = RoleRequirement

    # None
    assert role_req.role_yaml_parse(None) is None

    # String
    assert role_req.role_yaml_parse('myrole') == {'name': 'myrole', 'src': 'myrole', 'version': None, 'scm': None}
    assert role_req.role_yaml_parse('myrole,1.0') == {'name': 'myrole', 'src': 'myrole', 'version': '1.0', 'scm': None}
    assert role_req.role_yaml_parse('myrole,1.0,myrole2') == {'name': 'myrole2', 'src': 'myrole', 'version': '1.0', 'scm': None}

# Generated at 2022-06-11 10:56:49.252742
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    if RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") != "repo":
        raise AssertionError("RoleRequirement.repo_url_to_role_name() method test failed")


# Generated at 2022-06-11 10:57:19.440967
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Test valid repo URLs
    url = "http://git.example.com/repos/repo.git"
    assert RoleRequirement.repo_url_to_role_name(url) == "repo"
    url = "git@git.example.com:repos/repo.git"
    assert RoleRequirement.repo_url_to_role_name(url) == "repo"
    url = "https://github.com/user/repo.git"
    assert RoleRequirement.repo_url_to_role_name(url) == "repo"
    url = "git+https://github.com/user/repo.git"
    assert RoleRequirement.repo_url_to_role_name(url) == "repo"

# Generated at 2022-06-11 10:57:29.267574
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:57:34.639521
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_yaml_parse = RoleRequirement.role_yaml_parse

    role_name = "geerlingguy.nginx"
    role_version = "1.8.0"
    role_name_version = "%s,%s" % (role_name, role_version)

    # test invalid role line
    invalid_role = "geerlingguy.nginx,1.8.0,1.9.0"
    try:
        role_yaml_parse(invalid_role)
        assert False, "Invalid role line not detected"
    except AnsibleError:
        pass

    # test new style role from dictionary
    role = dict(role=role_name_version)

# Generated at 2022-06-11 10:57:46.059593
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:57:55.669654
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test 1
    assert RoleRequirement.role_yaml_parse("name") == dict(name='name', src=None, scm=None, version=None)

    # test 2
    assert RoleRequirement.role_yaml_parse("name,1") == dict(name='name', src=None, scm=None, version='1')

    # test 3
    assert RoleRequirement.role_yaml_parse("name,1,hi") == dict(name='hi', src=None, scm=None, version='1')

    # test 4
    assert RoleRequirement.role_yaml_parse("https://github.com/anisble/ansible,devel,hi") == dict(name='hi', src='https://github.com/anisble/ansible', scm=None, version='devel')

   

# Generated at 2022-06-11 10:58:05.887576
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_role_requirement = RoleRequirement()
    test_dict = {'name': 'ntp', 'src': 'https://github.com/ansible/ansible-ntp.git','version': '1.0.0'}
    test_role_dict = test_role_requirement.role_yaml_parse("https://github.com/ansible/ansible-ntp.git,1.0.0")
    assert test_role_dict == test_dict
    test_role_dict = test_role_requirement.role_yaml_parse("https://github.com/ansible/ansible-ntp.git,1.0.0,")
    assert test_role_dict == test_dict

# Generated at 2022-06-11 10:58:15.070330
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    rr = RoleRequirement()
    assert rr.role_yaml_parse('role_name') == {'name':u'role_name', 'src':u'role_name', 'version':u'', 'scm':None}
    assert rr.role_yaml_parse('role_name,version') == {'name':u'role_name', 'src':u'role_name', 'version':u'version', 'scm':None}
    assert rr.role_yaml_parse('role_name,version,name') == {'name':u'name', 'src':u'role_name', 'version':u'version', 'scm':None}

# Generated at 2022-06-11 10:58:25.515556
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """Test parsing of roles
    """


# Generated at 2022-06-11 10:58:35.208033
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    valid_role_dict_1 = { 'name': 'test_role_1', 'scm': 'git', 'src': 'https://github.com/username/test_role_1', 'version': 'v2.0' }
    valid_role_dict_2 = { 'name': 'test_role_2', 'src': 'ansible-galaxy install username.test_role_2,v2.0,test_role_2' }
    valid_role_dict_3 = { 'name': 'test_role_3', 'scm': 'git', 'src': 'https://github.com/username/test_role_3,v2.0', 'version': 'v2.0' }

# Generated at 2022-06-11 10:58:44.373981
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('foobar') == {'name': 'foobar', 'scm': None, 'src': 'foobar', 'version': ''}
    assert RoleRequirement.role_yaml_parse('foobar,v1') == {'name': 'foobar', 'scm': None, 'src': 'foobar', 'version': 'v1'}
    assert RoleRequirement.role_yaml_parse('foobar,v1,barfoo') == {'name': 'barfoo', 'scm': None, 'src': 'foobar', 'version': 'v1'}

# Generated at 2022-06-11 10:59:07.887587
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from nose.tools import assert_equal


# Generated at 2022-06-11 10:59:16.845224
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,3.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,3.0,RoleName") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/role/repo.git") == "repo"

# Generated at 2022-06-11 10:59:25.736944
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:59:36.170203
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    string1 = "geerlingguy,1.8.0"
    expected_dict1 = dict(
        name="geerlingguy",
        src="geerlingguy",
        scm=None,
        version='1.8.0'
    )
    assert RoleRequirement.role_yaml_parse(string1) == expected_dict1
    string2 = "git+https://github.com/jakubroztocil/httpie.git,0.9.6"
    expected_dict2 = dict(
        name="httpie",
        src="https://github.com/jakubroztocil/httpie.git",
        scm="git",
        version='0.9.6'
    )
    assert RoleRequirement.role_yaml_parse(string2) == expected_dict2