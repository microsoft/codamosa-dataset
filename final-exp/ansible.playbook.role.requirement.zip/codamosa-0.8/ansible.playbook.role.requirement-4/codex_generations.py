

# Generated at 2022-06-11 10:50:12.937467
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git+https://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git+https://user@git.example.com/repos/repo.git") == "repo"

# Generated at 2022-06-11 10:50:23.606399
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role = RoleRequirement()
    assert role.repo_url_to_role_name("git+ssh://git@github.com/bennojoy/django-profiles.git") == "django-profiles"
    assert role.repo_url_to_role_name("https://github.com/bennojoy/django-profiles.git") == "django-profiles"
    assert role.repo_url_to_role_name("https://github.com/bennojoy/django-profiles.git,develop") == "django-profiles"
    assert role.repo_url_to_role_name("github.com/bennojoy/django-profiles.git") == "django-profiles"

# Generated at 2022-06-11 10:50:34.607863
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    yaml_role = "git+https://github.com/AnsibleShipyard/ansible-role-rabbitmq,1.0.1"
    role = RoleRequirement.role_yaml_parse(yaml_role)
    assert role == {'name': 'ansible-role-rabbitmq', 'src': 'https://github.com/AnsibleShipyard/ansible-role-rabbitmq', 'scm': 'git', 'version': '1.0.1'}, \
        "Error in test_RoleRequirement_role_yaml_parse method"

    yaml_role = "galaxy.role,version,name"
    role = RoleRequirement.role_yaml_parse(yaml_role)

# Generated at 2022-06-11 10:50:41.655195
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print("\n test_RoleRequirement_role_yaml_parse: start")

    role_requirement = RoleRequirement()

    input_role = 'geerlingguy.java, 1.8'
    print("\n test_RoleRequirement_role_yaml_parse: input_role=" + input_role)
    result = role_requirement.role_yaml_parse(input_role)
    print(result)

    input_role = {'role': 'geerlingguy.java', 'version': '1.8'}
    print("\n test_RoleRequirement_role_yaml_parse: input_role=" + str(input_role))
    result = role_requirement.role_yaml_parse(input_role)
    print(result)


# Generated at 2022-06-11 10:50:53.297857
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('foo') == 'foo'
    assert RoleRequirement.repo_url_to_role_name('git+https://github.com/foo/bar') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('git+https://github.com/foo/bar.git') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('git+https://github.com/foo/bar.git,v1.0') == 'bar'
    assert RoleRequirement.repo_url_to_role_name('git+https://github.com/foo/bar,v1.0') == 'bar'

# Generated at 2022-06-11 10:51:03.234114
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:51:15.219832
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:51:19.029511
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    from examples.playbooks.roles.role_requirements import RoleRequirement

    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"

# Generated at 2022-06-11 10:51:26.908184
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    
    roleStr = 'role'
    roleStrTest = RoleRequirement.role_yaml_parse(roleStr)
    assert(roleStrTest == {'name': 'role', 'src': None, 'scm': None, 'version': None})

    roleDict = {'role': 'role'}
    roleDictTest = RoleRequirement.role_yaml_parse(roleDict)
    assert(roleDictTest == {'name': 'role', 'src': None, 'scm': None, 'version': None})

    roleWithVersion = 'role,version'
    roleWithVersionTest = RoleRequirement.role_yaml_parse(roleWithVersion)
    assert(roleWithVersionTest == {'name': 'role', 'src': 'version', 'scm': None, 'version': None})

    roleWithVersion

# Generated at 2022-06-11 10:51:39.026320
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    test_str_1 = 'http://git.example.com/repos/repo.git'
    assert RoleRequirement.repo_url_to_role_name(test_str_1) == 'repo'

    test_str_2 = 'http://git.example.com/repos/repo.tar.gz'
    assert RoleRequirement.repo_url_to_role_name(test_str_2) == 'repo'

    test_str_3 = 'http://git.example.com/repos/repo,1.0.0,role'
    assert RoleRequirement.repo_url_to_role_name(test_str_3) == 'repo'

    test_str_4 = 'http://git.example.com/repos/repo'

# Generated at 2022-06-11 10:52:02.441766
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('https://github.com/n0ts/ansible-role-foo.git') == 'ansible-role-foo'
    assert RoleRequirement.repo_url_to_role_name('git@github.com:n0ts/ansible-role-foo.git') == 'ansible-role-foo'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/n0ts/ansible-role-foo') == 'ansible-role-foo'
    assert RoleRequirement.repo_url_to_role_name('git@github.com:n0ts/ansible-role-foo') == 'ansible-role-foo'

# Generated at 2022-06-11 10:52:05.112106
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert 'repo' == RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git')

# Generated at 2022-06-11 10:52:16.131509
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    r = RoleRequirement()
    assert r.role_yaml_parse("http://git.example.com/repos/repo.git") == {'name': "repo", 'src': "http://git.example.com/repos/repo.git", 'scm': None, 'version': None}
    assert r.role_yaml_parse("http://git.example.com/repos/repo") == {'name': "repo", 'src': "http://git.example.com/repos/repo", 'scm': None, 'version': None}

# Generated at 2022-06-11 10:52:29.118078
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test role with name, src and version
    role = "name,src,version"
    parsed_role = RoleRequirement.role_yaml_parse(role)
    assert parsed_role['name'] == 'name'
    assert parsed_role['src'] == 'src'
    assert parsed_role['version'] == 'version'

    # Test role with name, src and no version
    role = "name,src"
    parsed_role = RoleRequirement.role_yaml_parse(role)
    assert parsed_role['name'] == 'name'
    assert parsed_role['src'] == 'src'
    assert parsed_role['version'] == ''

    # Test role with src and no name
    role = "src"
    parsed_role = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-11 10:52:37.837262
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = "anotherrole,v1"
    role_yaml_parse = RoleRequirement.role_yaml_parse(role)

    assert role_yaml_parse['name'] == 'anotherrole', 'role name: %s' % role_yaml_parse['name']
    assert role_yaml_parse['src'] == 'anotherrole', 'role src: %s' % role_yaml_parse['src']
    assert role_yaml_parse['scm'] == None, 'role scm: %s' % role_yaml_parse['scm']
    assert role_yaml_parse['version'] == 'v1', 'role version: %s' % role_yaml_parse['version']

# Generated at 2022-06-11 10:52:44.371146
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from nose.tools import assert_equals, assert_raises
    # test role name
    assert_equals(RoleRequirement.role_yaml_parse('role'), dict(name='role', src='role', scm=None, version=''))
    # test role name and version
    assert_equals(RoleRequirement.role_yaml_parse('role,1.0'), dict(name='role', src='role', scm=None, version='1.0'))
    assert_equals(RoleRequirement.role_yaml_parse('role, v1.0'), dict(name='role', src='role', scm=None, version='v1.0'))
    # test role name and version and tag name

# Generated at 2022-06-11 10:52:55.106459
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = 'git+https://github.com/geerlingguy/ansible-role-jenkins.git, v0.0.2'
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'ansible-role-jenkins', 'src': 'https://github.com/geerlingguy/ansible-role-jenkins.git', 'scm': 'git', 'version': 'v0.0.2'}
    role = 'https://github.com/geerlingguy/ansible-role-jenkins.git, v0.0.2'

# Generated at 2022-06-11 10:53:05.393993
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Test old style git URLs
    result = RoleRequirement.repo_url_to_role_name("git://git.example.com/repos/repo.git")
    assert result == "repo"

    result = RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git")
    assert result == "repo"

    result = RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/repo.git")
    assert result == "repo"

    result = RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git")
    assert result == "repo"

    result = RoleRequirement.repo_url_to_role

# Generated at 2022-06-11 10:53:13.231799
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    repo_urls = [
        'http://git.example.com/repos/repo.git',
        'git@github.com:ansible/ansible-modules-extras.git',
        'git@github.com:ansible/ansible-modules-extras.git,v2.0',
        'git@github.com:ansible/ansible-modules-extras.git,v2.0,my_name',
        'git+https://github.com/ansible-procurve/ansible-procurve.git',
        'git+https://github.com/ansible-procurve/ansible-procurve.git,v1.0',
    ]


# Generated at 2022-06-11 10:53:23.614874
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Common tests
    assert RoleRequirement.role_yaml_parse("role_name") == {
        "src": "role_name",
        "name": "role_name",
        "version": "",
        "scm": None
    }

    assert RoleRequirement.role_yaml_parse("role_name,1.2") == {
        "src": "role_name",
        "name": "role_name",
        "version": "1.2",
        "scm": None
    }

    assert RoleRequirement.role_yaml_parse("role_name,1.2,othername") == {
        "src": "role_name",
        "name": "othername",
        "version": "1.2",
        "scm": None
    }

    # Git syntax

# Generated at 2022-06-11 10:53:37.301532
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Parse requirements.yml entries
    # Test a simple name entry
    print("Test simple name entry")
    role = "foo"
    role = RoleRequirement.role_yaml_parse(role)
    assert(role == {'name': 'foo', 'version': '', 'src': 'foo', 'scm': None})

    # Test a name entry with version
    print("Test name entry with version")
    role = "foo,v1"
    role = RoleRequirement.role_yaml_parse(role)
    assert(role == {'name': 'foo', 'version': 'v1', 'src': 'foo', 'scm': None})

    # Test a name entry with version and name
    print("Test name entry with version, name")
    role = "foo,v1,bar"
    role = RoleRequ

# Generated at 2022-06-11 10:53:48.480932
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert RoleRequirement.role_yaml_parse('test.test,v1.0') == {'name': 'test', 'src': 'test.test', 'scm': None, 'version': 'v1.0'}
    assert RoleRequirement.role_yaml_parse('test.test,v1.0,test') == {'name': 'test', 'src': 'test.test', 'scm': None, 'version': 'v1.0'}
    assert RoleRequirement.role_yaml_parse('test.test') == {'name': 'test', 'src': 'test.test', 'scm': None, 'version': None}

# Generated at 2022-06-11 10:53:57.762590
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@github.com:davidban77/ansible-role-users.git") == "ansible-role-users"
    assert RoleRequirement.repo_url_to_role_name("git+ssh://git@github.com:davidban77/ansible-role-users.git") == "git"
    #assert RoleRequirement.repo_url_to_role_name("https://github.com/davidban77/ansible-role-users.git,v1.0") == "https"

# Generated at 2022-06-11 10:54:09.873909
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    repo_url = "http://git.example.com/repos/repo.git"
    role_name = RoleRequirement.repo_url_to_role_name(repo_url)
    assert role_name == "repo"

    repo_url = "git@git.example.com:repos/repo.git"
    role_name = RoleRequirement.repo_url_to_role_name(repo_url)
    assert role_name == "repo"

    repo_url = "git@git.example.com:repos/repo.git/tree/master"
    role_name = RoleRequirement.repo_url_to_role_name(repo_url)
    assert role_name == "repo"


# Generated at 2022-06-11 10:54:20.028683
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test case 1: test role_yaml_parse when role is a string

    role = "geerlingguy.haproxy"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == dict(name="geerlingguy.haproxy", src="geerlingguy.haproxy", scm=None, version=None)

    role = "geerlingguy.haproxy,v1.0.1"
    result = RoleRequirement.role_yaml_parse(role)
    assert result == dict(name="geerlingguy.haproxy", src="geerlingguy.haproxy", scm=None, version="v1.0.1")

    role = "geerlingguy.haproxy,v1.0.1,geerlingguy.haproxy"
    result = RoleRequirement.role

# Generated at 2022-06-11 10:54:31.145452
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("git+git://git.example.com/repos/repo.git,develop,foo") == {
        "name": "foo",
        "scm": "git",
        "src": "git://git.example.com/repos/repo.git",
        "version": 'develop'
    }
    assert RoleRequirement.role_yaml_parse("git+git://git.example.com/repos/repo.git,develop") == {
        "name": "repo",
        "scm": "git",
        "src": "git://git.example.com/repos/repo.git",
        "version": 'develop'
    }

# Generated at 2022-06-11 10:54:41.253332
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Basic test
    role = {'name': 'test_role', 'src': 'https://github.com/makamaka/ansible-aix-customization'}
    assert(RoleRequirement.role_yaml_parse(role)) == role

    # Test, version and name cases
    assert(RoleRequirement.role_yaml_parse('test_role,v0.0.1,some_name')) == {'name': 'some_name', 'src': 'test_role', 'scm': None, 'version': 'v0.0.1'}

# Generated at 2022-06-11 10:54:49.894824
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:54:59.597393
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:55:09.692398
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('git@git.example.com:repos/repo.git') == 'repo'
    assert role_requirement.repo_url_to_role_name('http://git.example.com/repos/repo-1.0.tar.gz') == 'repo-1.0'
    assert role_requirement.repo_url_to_role_name('repo') == 'repo'

# Generated at 2022-06-11 10:55:33.975353
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache') == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse('geerlingguy.apache,1.0.0') == {'name': 'apache', 'src': 'geerlingguy.apache', 'scm': None, 'version': '1.0.0'}
    assert RoleRequirement.role_yaml_parse('http://git.example.com/repos/repo.git') == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'scm': None, 'version': ''}

# Generated at 2022-06-11 10:55:43.994215
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = dict(src='git://github.com/ansible/ansible-examples.git', scm='git', version='v1.0')
    role_res = role.copy()
    assert RoleRequirement.role_yaml_parse(role) == role_res
    role = dict(src='git+https://github.com/ansible/ansible-examples.git', scm='git', version='v1.0')
    role_res = role.copy()
    assert RoleRequirement.role_yaml_parse(role) == role_res
    role = dict(src='https://github.com/ansible/ansible-examples.git', scm='git', version='v1.0')
    role_res = role.copy()

# Generated at 2022-06-11 10:55:53.751377
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:56:03.970639
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert_result_is(RoleRequirement.role_yaml_parse('foo'), dict(name='foo', src='foo', scm=None, version=''))
    assert_result_is(RoleRequirement.role_yaml_parse('git+https://github.com/foo/bar'), dict(name='bar', src='https://github.com/foo/bar', scm='git', version=''))
    assert_result_is(RoleRequirement.role_yaml_parse('https://github.com/foo/bar,v1'), dict(name='bar', src='https://github.com/foo/bar', scm=None, version='v1'))

# Generated at 2022-06-11 10:56:14.879443
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    print('\nUnit test of method repo_url_to_role_name of class RoleRequirement')
    print('---------------------------------------------------------------------\n')


# Generated at 2022-06-11 10:56:21.624888
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    test_cases = {
        'git@github.com:whatever/galaxy-role.git': 'galaxy-role',
        'https://github.com/whatever/galaxy-role.git': 'galaxy-role',
        'http://git.whatever.com/repo/galaxy-role.git': 'galaxy-role',
        'https://github.com/whatever/galaxy-role.git#v1.2.3,master': 'galaxy-role',
        'galaxy-role.tar.gz': 'galaxy-role',
        'galaxy-role,v1.2.3,new_name': 'new_name',
        'galaxy-role,v1.2.3': 'galaxy-role',
    }


# Generated at 2022-06-11 10:56:31.336015
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Validate the case with path format of a repo URL
    assert "role" == RoleRequirement.repo_url_to_role_name("http://git.example.com/role.git")
    assert "role" == RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/role.git")

    # Validate the case with repo_name format of a repo URL
    assert "role" == RoleRequirement.repo_url_to_role_name("role")
    assert "role" == RoleRequirement.repo_url_to_role_name(",,role")
    assert "role" == RoleRequirement.repo_url_to_role_name("role,,1.0")


# Generated at 2022-06-11 10:56:41.573992
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    assert RoleRequirement.repo_url_to_role_name("org.example.role") == "org.example.role"
    assert RoleRequirement.repo_url_to_role_name("git@github.com:org/role.git") == "role"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/org/role.git") == "role"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/org/role.git") == "role"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/org/role.git,v0.1.0") == "role"

# Generated at 2022-06-11 10:56:51.097664
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-11 10:57:00.832957
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    display.verbosity = 3
    role = RoleRequirement()
    assert role.repo_url_to_role_name("http://git.example.com/repos/repo.git") == 'repo'
    assert role.repo_url_to_role_name("http://git.example.com/repos/repo") == 'repo'
    assert role.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == 'repo.tar'
    assert role.repo_url_to_role_name("http://git.example.com/repos/repo-2.0.tar.gz") == 'repo-2.0'

# Generated at 2022-06-11 10:57:26.812001
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import os
    import tempfile

    class MockRole(RoleDefinition):

        def __init__(self, src, scm=None, version='', name=None):
            self._role_name = name
            self._role_path = os.path.join(tempfile.gettempdir(), 'ansible_test_role')
            if os.path.exists(self._role_path) and not os.path.isdir(self._role_path):
                raise ValueError("target location is not a directory")
            self.cleanup()
            os.makedirs(self._role_path)
            # test Git archive download

# Generated at 2022-06-11 10:57:32.584779
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    roledef = RoleRequirement()

    # Role name only
    assert(roledef.role_yaml_parse("geerlingguy.java") == dict(name="geerlingguy.java", src="", scm=None, version=None))

    # Role name with version number
    assert(roledef.role_yaml_parse("geerlingguy.java,1.9") == dict(name="geerlingguy.java", src="", scm=None, version="1.9"))

    # Role name with full version number
    assert(roledef.role_yaml_parse("geerlingguy.java,1.9.0") == dict(name="geerlingguy.java", src="", scm=None, version="1.9.0"))

    # Role name with version number and custom name
   

# Generated at 2022-06-11 10:57:43.533982
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_def = RoleRequirement()
    result = role_def.role_yaml_parse("role_name,version,name")
    assert result == {'name': 'name', 'scm': None, 'src': 'role_name,version', 'version': 'version'}
    result = role_def.role_yaml_parse("git+git@github.com:username/repo/path.git")
    assert result == {'name': 'path', 'scm': 'git', 'src': 'git@github.com:username/repo/path.git', 'version': ''}
    result = role_def.role_yaml_parse({'role': 'galaxy_role_name,version,name'})

# Generated at 2022-06-11 10:57:53.800992
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Just check some examples; Doctest is not really suited for this purpose
    # but this code is unlikely to change
    assert RoleRequirement.role_yaml_parse("geerlingguy.docker") == {
        'name': 'geerlingguy.docker',
        'scm': None,
        'src': 'geerlingguy.docker',
        'version': None
    }
    assert RoleRequirement.role_yaml_parse("geerlingguy.docker,v1.9.0") == {
        'name': 'geerlingguy.docker',
        'scm': None,
        'src': 'geerlingguy.docker',
        'version': 'v1.9.0'
    }

# Generated at 2022-06-11 10:58:02.999794
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:58:12.400683
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()

    # test with http
    test_role_url = "http://git.example.com/repos/repo.git"
    result = role_requirement.repo_url_to_role_name(test_role_url)
    assert result == "repo"

    # test with https
    test_role_url = "https://git.example.com/repos/repo.git"
    result = role_requirement.repo_url_to_role_name(test_role_url)
    assert result == "repo"

    # test with git
    test_role_url = "git@git.example.com/repos/repo.git"
    result = role_requirement.repo_url_to_role_name(test_role_url)

# Generated at 2022-06-11 10:58:22.441666
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:58:32.526486
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('geerlingguy.apache') == 'geerlingguy.apache'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache.git') == 'ansible-role-apache'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache') == 'ansible-role-apache'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache,v1.0.0') == 'ansible-role-apache'

# Generated at 2022-06-11 10:58:42.249015
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = "git+http://github.com/ANXS/postgresql"
    RoleRequirement.role_yaml_parse(role)
    role = "http://github.com/ANXS/postgresql"
    RoleRequirement.role_yaml_parse(role)
    role = "git+http://github.com/ANXS/postgresql,9.0"
    RoleRequirement.role_yaml_parse(role)
    role = "git+http://github.com/ANXS/postgresql,9.0,debops-postgresql"
    RoleRequirement.role_yaml_parse(role)
    role = "git+http://github.com/ANXS/postgresql,debops-postgresql,9.0"
    RoleRequirement.role_yaml_

# Generated at 2022-06-11 10:58:50.168887
# Unit test for method repo_url_to_role_name of class RoleRequirement