

# Generated at 2022-06-11 10:49:55.232137
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    spec = RoleRequirement.role_yaml_parse('geerlingguy.nginx')
    assert spec['name'] == 'geerlingguy.nginx'
    assert spec['src'] == 'geerlingguy.nginx'
    assert spec['scm'] is None
    assert spec['version'] is None

    spec = RoleRequirement.role_yaml_parse('git+https://github.com/geerlingguy/ansible-role-nginx.git,v1.0')
    assert spec['name'] == 'ansible-role-nginx'
    assert spec['src'] == 'https://github.com/geerlingguy/ansible-role-nginx.git'
    assert spec['scm'] == 'git'
    assert spec['version'] == 'v1.0'


# Generated at 2022-06-11 10:50:06.016941
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    repo_url_with_git_suffix = "http://git.example.com/repos/repo.git"
    repo_url_without_git_suffix = "http://git.example.com/repos/repo"
    repo_url_with_tar_gz_suffix = "http://git.example.com/repos/repo.tar.gz"
    repo_name_without_suffix = "http://git.example.com/repos/repo"
    repo_name_with_branch = "http://git.example.com/repos/repo,some_branch"
    repo_name_with_version = "http://git.example.com/repos/repo,v0.0.1"

# Generated at 2022-06-11 10:50:15.837375
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    r=RoleRequirement()

    assert r.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert r.repo_url_to_role_name('http://git.example.com/repos/repo,1.0') == 'repo'
    assert r.repo_url_to_role_name('http://git.example.com/repos/repo,v1.0,other_name') == 'repo'

    assert r.repo_url_to_role_name('https://github.com/example/repo.git') == 'repo'
    assert r.repo_url_to_role_name('https://github.com/example/repo,1.0') == 'repo'
   

# Generated at 2022-06-11 10:50:27.108269
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    from ansible.collections.ansible.community.tests.unit.galaxy import AnsibleGalaxyRoleRequirementTestCase
    test = AnsibleGalaxyRoleRequirementTestCase()
    test.assertEqual(RoleRequirement.repo_url_to_role_name('https://github.com/example/repo.git'), 'repo')
    test.assertEqual(RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git'), 'repo')
    test.assertEqual(RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git/master.tar.gz'), 'repo')

# Generated at 2022-06-11 10:50:31.626772
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Call method and test result
    result = RoleRequirement.role_yaml_parse('existing_role')
    assert result['name'] == 'existing_role'
    assert result['src'] == 'existing_role'
    assert result['version'] is None
    assert result['scm'] is None

# Generated at 2022-06-11 10:50:35.857378
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from pprint import pprint


# Generated at 2022-06-11 10:50:47.215347
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    sample_role = """
        - src: https://github.com/ANXS/postgresql
          version: v2.0.3
    """

    role = RoleRequirement.role_yaml_parse(sample_role)
    assert role['src'] == 'https://github.com/ANXS/postgresql'
    assert role['version'] == 'v2.0.3'
    assert role['name'] == 'postgresql'

    sample_role = """
        - http://github.com/alikins/ansible-role-something
    """

    role = RoleRequirement.role_yaml_parse(sample_role)
    assert role['src'] == 'http://github.com/alikins/ansible-role-something'
    assert role['name'] == 'ansible-role-something'



# Generated at 2022-06-11 10:50:58.112083
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.utils.display import Display

    display = Display()
    test_role_yaml_parse = RoleRequirement.role_yaml_parse

    def assert_equal(res1, res2):
        if res1 != res2:
            display.display(res1)
            display.display(res2)
            raise AssertionError()

    assert_equal(test_role_yaml_parse('foo'), {'scm': None, 'src': 'foo', 'version': '', 'name': 'foo'})
    assert_equal(test_role_yaml_parse('foo,bar'), {'scm': None, 'src': 'foo', 'version': 'bar', 'name': 'foo'})

# Generated at 2022-06-11 10:51:06.131350
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/alice/role.git") == "role"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@bitbucket.org:bob/role.git") == "role"
    assert RoleRequirement.repo_url_to_role_name("git+https://github.com/alice/role.git,v1.0") == "role"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0") == "repo"


# Generated at 2022-06-11 10:51:18.095686
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.module_utils import six

    # Parse a simple role name
    assert RoleRequirement.role_yaml_parse('myrole') == {'name': 'myrole', 'scm': None, 'src': 'myrole', 'version': None}

    # Parse a simple role name with an invalid char
    assert RoleRequirement.role_yaml_parse('my,role') == {'name': 'myrole', 'scm': None, 'src': 'my,role', 'version': None}

    # Parse a role name and version
    assert RoleRequirement.role_yaml_parse('myrole,v1') == {'name': 'myrole', 'scm': None, 'src': 'myrole', 'version': 'v1'}

    # Parse a role name and version

# Generated at 2022-06-11 10:51:36.331564
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:51:48.166530
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:52:01.207053
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    url = "http://git.example.com/repos/repo.git,1.0,rolename"
    assert RoleRequirement.repo_url_to_role_name(url) == "repo"
    url = "user@git.example.com:repos/repo.git,rolename"
    assert RoleRequirement.repo_url_to_role_name(url) == "repo"
    url = "git+user@git.example.com:repos/repo.git,rolename"
    assert RoleRequirement.repo_url_to_role_name(url) == "repo"
    url = "git+user@git.example.com:repos/repo.git,1.0"
    assert RoleRequirement.repo_url_to_role_name(url)

# Generated at 2022-06-11 10:52:13.182130
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Testing with string type
    a_role = "http://git.example.com/repos/repo.git"
    assert(RoleRequirement.role_yaml_parse(a_role) == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'scm': None, 'version': None})

    a_role = "http://git.example.com/repos/repo.git,master"
    assert(RoleRequirement.role_yaml_parse(a_role) == {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'scm': None, 'version': 'master'})


# Generated at 2022-06-11 10:52:19.885083
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:52:32.206351
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:52:37.960693
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('jdoe.role') == dict(name='jdoe.role', src=None, scm=None, version=None)
    assert RoleRequirement.role_yaml_parse('jdoe.role,1.0') == dict(name='jdoe.role', src=None, scm=None, version='1.0')
    assert RoleRequirement.role_yaml_parse('jdoe.role,1.0,test') == dict(name='test', src=None, scm=None, version='1.0')

# Generated at 2022-06-11 10:52:47.223159
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    def assert_role_data(role, **kwargs):
        for k, v in kwargs.items():
            assert v == role[k]

    # assert parsing of old style
    role = RoleRequirement.role_yaml_parse('geerlingguy.apache')
    assert_role_data(role, name='geerlingguy.apache', src='geerlingguy.apache', scm=None, version=None)

    role = RoleRequirement.role_yaml_parse('some_scm_role+git@github.com:mycompany/some_scm_role.git')
    assert_role_data(role, name='some_scm_role', src='git@github.com:mycompany/some_scm_role.git', scm='git', version=None)


# Generated at 2022-06-11 10:52:58.086351
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test parse a string
    obj = RoleRequirement.role_yaml_parse(
        "src='https://github.com/jctanner/ansible-role-httpd.git', version='1.1.1', scm='git'"
    )
    assert obj['name'] == 'ansible-role-httpd'
    assert obj['version'] == '1.1.1'
    assert obj['scm'] == 'git'
    assert obj['src'] == 'https://github.com/jctanner/ansible-role-httpd.git'

    # Test parse a dict

# Generated at 2022-06-11 10:53:07.758707
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # tests
    x = RoleRequirement.role_yaml_parse("geerlingguy.jenkins")
    assert x == dict(name='geerlingguy.jenkins', src='https://github.com/geerlingguy/ansible-role-jenkins', scm='git', version='')

    x = RoleRequirement.role_yaml_parse("git+https://github.com/geerlingguy/ansible-role-jenkins")
    assert x == dict(name='ansible-role-jenkins', src='https://github.com/geerlingguy/ansible-role-jenkins', scm='git', version='')

    x = RoleRequirement.role_yaml_parse("geerlingguy.jenkins,v1.5")

# Generated at 2022-06-11 10:53:22.156633
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    spec = RoleRequirement.role_yaml_parse("myrole")
    assert spec == dict(name='myrole', src='myrole', version='', scm=None)

    spec = RoleRequirement.role_yaml_parse("myrole,1.2")
    assert spec == dict(name='myrole', src='myrole', version='1.2', scm=None)

    spec = RoleRequirement.role_yaml_parse("myrole,1.2,other")
    assert spec == dict(name='other', src='myrole', version='1.2', scm=None)

    spec = RoleRequirement.role_yaml_parse("git+https://github.com/myrole,1.2,other")

# Generated at 2022-06-11 10:53:31.845147
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    
    # setup
    role_yaml = """
    - { role: role1 }
    - role2
    """
    role_expected = [{ 'name': 'role1' }, { 'name': 'role2' }]
    
    # execute
    display.vvvv("RoleRequirement.role_yaml_parse(role_yaml)")
    roles_actual = RoleRequirement.role_yaml_parse(role_yaml)
    display.vvvv("actual:")
    display.vvvv(roles_actual)
    display.vvvv("expected:")
    display.vvvv(role_expected)

    # assert
    for key in role_expected[0].keys():
        assert key in roles_actual[0].keys()

# Generated at 2022-06-11 10:53:37.687462
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:53:48.771583
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role='role_name,2.0.0,role_name'
    role=RoleRequirement.role_yaml_parse(role)
    assert role['name'] == 'role_name'
    assert role['version'] == '2.0.0'
    assert role['src'] == 'role_name'

    role='github.com/user/repo+role_name,2.0.0,role_name'
    role=RoleRequirement.role_yaml_parse(role)
    assert role['name'] == 'role_name'
    assert role['version'] == '2.0.0'
    assert role['src'] == 'user/repo'
    assert role['scm'] == 'git'

    role='github.com/user/repo,2.0.0,role_name'
    role

# Generated at 2022-06-11 10:53:57.966958
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("ansiblebit.oracle-java") == {
        'name': 'ansiblebit.oracle-java',
        'scm': None,
        'src': 'ansiblebit.oracle-java',
        'version': None}

    assert RoleRequirement.role_yaml_parse("git+https://github.com/ansiblebit/oracle-java") == {
        'name': 'ansiblebit.oracle-java',
        'scm': 'git',
        'src': 'https://github.com/ansiblebit/oracle-java',
        'version': None}


# Generated at 2022-06-11 10:54:10.079597
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_def = RoleRequirement.role_yaml_parse('role_name')
    assert role_def['name'] == 'role_name'
    assert role_def['version'] == ''
    assert role_def['scm'] is None

    role_def = RoleRequirement.role_yaml_parse('git+git@git.example.com:my/role.git')
    assert role_def['name'] == 'role'
    assert role_def['scm'] == 'git'
    assert role_def['src'] == 'git@git.example.com:my/role.git'
    assert role_def['version'] == ''

    role_def = RoleRequirement.role_yaml_parse('git+git@git.example.com:my/role.git,1.0')

# Generated at 2022-06-11 10:54:20.232663
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # input1: string type
    # expected_output1: dict
    # Actual-output1: dict
    input1 = 'https://github.com/geerlingguy/ansible-role-apache.git'
    expected_output1 = {'name': 'ansible-role-apache', 'src': 'https://github.com/geerlingguy/ansible-role-apache.git', 'scm': None, 'version': None}
    actual_output1 = RoleRequirement.role_yaml_parse(input1)
    assert expected_output1 == actual_output1

    # input2: string type
    # expected_output2: dict
    # Actual-output2: dict
    input2 = 'https://github.com/geerlingguy/ansible-role-apache.git,v1.4'
    expected_

# Generated at 2022-06-11 10:54:31.435140
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_line = 'git+https://github.com/geerlingguy/ansible-role-apache.git,v1.5'
    result = RoleRequirement.role_yaml_parse(role_line)
    expected = dict(name=None, src='https://github.com/geerlingguy/ansible-role-apache.git', scm='git', version='v1.5')
    if result != expected:
        raise AssertionError('role_yaml_parse(%s) = %s != expected %s' % (role_line, result, expected))

    role_line = 'https://github.com/geerlingguy/ansible-role-apache.git'
    result = RoleRequirement.role_yaml_parse(role_line)

# Generated at 2022-06-11 10:54:33.947014
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"


# Generated at 2022-06-11 10:54:44.131189
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import tempfile
    import shutil

    string_role = "foobar"
    dict_role = dict(role='foobar')
    string_version = "foobar,1"
    dict_version = dict(role = 'foobar', version = '1')
    string_name = "foobar,1,baz"
    dict_name = dict(role = 'foobar', version = '1', name = 'baz')
    dict_name_noversion = dict(role = 'foobar', name = 'baz')

    assert RoleRequirement.role_yaml_parse(string_role)["name"] == string_role
    assert RoleRequirement.role_yaml_parse(string_role)["scm"] is None
    assert RoleRequirement.role_yaml_parse(string_role)["src"] == string_

# Generated at 2022-06-11 10:55:15.076114
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    test_data = [
        "test.tar.gz,v1.0",
        "test.tar.gz,v1.0,test",
        "test.tar.gz",
        "git+https://github.com/user/repo,v1.0,test"
    ]

# Generated at 2022-06-11 10:55:24.588818
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:55:33.789592
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement()

    assert role.role_yaml_parse("ansible-role-nginx") == {'name': 'ansible-role-nginx', 'src': 'ansible-role-nginx', 'scm': None, 'version': ''}
    assert role.role_yaml_parse("https://github.com/Example/ansible-role-testrole.git,v0.0.1") == {'name': 'ansible-role-testrole', 'src': 'https://github.com/Example/ansible-role-testrole.git', 'scm': 'git', 'version': 'v0.0.1'}

# Generated at 2022-06-11 10:55:34.777854
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # TODO: implement unit tests
    pass

# Generated at 2022-06-11 10:55:43.299320
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    from ansible.galaxy.role import RoleRequirement

    assert RoleRequirement.repo_url_to_role_name('username.roles/example') == 'example'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/username/example.git') == 'example'
    assert RoleRequirement.repo_url_to_role_name('git://username@git.example.com/u/username/example.git') == 'example'
    assert RoleRequirement.repo_url_to_role_name('git+ssh://git@github.com/username/example.git') == 'example'


# Generated at 2022-06-11 10:55:53.213961
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse({'role': 'foo'}) == {'name': 'foo', 'src': None, 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse({'role': 'foo', 'src': 'foo'}) == {'name': 'foo', 'src': 'foo', 'scm': None, 'version': None}
    assert RoleRequirement.role_yaml_parse({'role': 'foo', 'version': '1.0'}) == {'name': 'foo', 'src': None, 'scm': None, 'version': '1.0'}

# Generated at 2022-06-11 10:56:03.406225
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role = "geerlingguy.apache,1.0.0"
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == "geerlingguy.apache"
    assert result['src'] == "geerlingguy.apache"
    assert result['scm'] == None
    assert result['version'] == "1.0.0"

    role = "https://github.com/geerlingguy/ansible-role-apache,1.0.0"
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == "ansible-role-apache"
    assert result['src'] == "https://github.com/geerlingguy/ansible-role-apache"
    assert result['scm'] == None

# Generated at 2022-06-11 10:56:14.364911
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Example
    rp = RoleRequirement()
    assert rp.role_yaml_parse('rolename') == dict(name='rolename', src='rolename', scm=None, version='')
    assert rp.role_yaml_parse('rolename,master') == dict(name='rolename', src='rolename',
                                                         scm=None, version='master')
    assert rp.role_yaml_parse('rolename,version=master') == dict(name='rolename', src='rolename',
                                                                 scm=None, version='master')
    assert rp.role_yaml_parse('username.rolename,version=master') == dict(name='rolename',
                                                                          src='username.rolename', scm=None, version='master')

# Generated at 2022-06-11 10:56:21.398559
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.errors import AnsibleError
    from nose.plugins.attrib import attr
    from six import assertRaisesRegex

    @attr('ansible2.8')
    def test_parse_str_role_definition():
        assert RoleRequirement.role_yaml_parse('role-name') == dict(name="role-name", src="role-name", scm=None, version=None)
        assert RoleRequirement.role_yaml_parse('github.com/username/role-name') == dict(name="role-name", src="github.com/username/role-name", scm=None, version=None)

# Generated at 2022-06-11 10:56:31.657747
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """
    Return a data struct of role requirements information from a serialized role
    """
    role = 'geerlingguy.nginx'
    result = RoleRequirement.role_yaml_parse(role)
    expected = {'name': 'geerlingguy.nginx', 'src': 'geerlingguy.nginx', 'version': None, 'scm': None}
    assert result == expected, result

    role = 'http://git.example.com/repos/repo.git'
    result = RoleRequirement.role_yaml_parse(role)
    expected = {'name': 'repo', 'src': 'http://git.example.com/repos/repo.git', 'version': None, 'scm': None}
    assert result == expected, result


# Generated at 2022-06-11 10:57:04.059986
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role_yaml_parse = RoleRequirement.role_yaml_parse

    assert(role_yaml_parse('ansible-modules-core') == {'name': 'ansible-modules-core', 'scm': None, 'src': 'ansible-modules-core', 'version': None})
    assert(role_yaml_parse('git+https://github.com/ansible/ansible-modules-core.git,v1.0') == {'name': 'ansible-modules-core', 'scm': 'git', 'src': 'https://github.com/ansible/ansible-modules-core.git,v1.0', 'version': None})

# Generated at 2022-06-11 10:57:13.813563
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:57:24.000588
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:57:33.081405
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:57:44.393475
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:57:54.324492
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test: detected name
    role = RoleRequirement.role_yaml_parse('http://server/repo.git')
    assert role['name'] == 'repo'

    # Test: detected name
    role = RoleRequirement.role_yaml_parse('http://server/repo.git,v3')
    assert role['name'] == 'repo'

    # Test: detected name
    role = RoleRequirement.role_yaml_parse('http://server/repo.git,v3,myname')
    assert role['name'] == 'myname'

    # Test: version
    role = RoleRequirement.role_yaml_parse('http://server/repo.git,v3')
    assert role['version'] == 'v3'

    # Test: SCM
    role = RoleRequirement.role_

# Generated at 2022-06-11 10:58:04.075023
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Old style
    role = "example.role"
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'example.role', 'version': None, 'scm': None, 'src': 'example.role'}

    role = "example.role,1.0"
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'example.role', 'version': '1.0', 'scm': None, 'src': 'example.role'}

    role = "example.role,1.0,other_name"
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'other_name', 'version': '1.0', 'scm': None, 'src': 'example.role'}


# Generated at 2022-06-11 10:58:13.539779
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert RoleRequirement.role_yaml_parse("role-name") == {
        'name': "role-name",
        'scm': None,
        'src': "role-name",
        'version': ""
    }

    assert RoleRequirement.role_yaml_parse("role-name,v2") == {
        'name': "role-name",
        'scm': None,
        'src': 'role-name',
        'version': 'v2'
    }

    assert RoleRequirement.role_yaml_parse("role-name,v2,that-role") == {
        'name': 'that-role',
        'scm': None,
        'src': 'role-name',
        'version': 'v2'
    }

    assert RoleRequirement.role_yaml_parse

# Generated at 2022-06-11 10:58:23.785162
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    assert RoleRequirement.role_yaml_parse('jdoe.role') == dict(name='jdoe.role', scm=None, src=None, version=None)
    assert RoleRequirement.role_yaml_parse('git+http://github.com/jdoe/role.git') == dict(name='role', scm='git', src='http://github.com/jdoe/role.git', version=None)
    assert RoleRequirement.role_yaml_parse('git+https://github.com/jdoe/role.git,v1.0') == dict(name='role', scm='git', src='https://github.com/jdoe/role.git', version='v1.0')

# Generated at 2022-06-11 10:58:33.668026
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    assert(RoleRequirement.repo_url_to_role_name("https://github.com/user/repo") == "repo")

    assert(RoleRequirement.repo_url_to_role_name("http://github.com/user/repo.git") == "repo")

    assert(RoleRequirement.repo_url_to_role_name("http://github.com/user/repo,stable") == "repo")

    assert(RoleRequirement.repo_url_to_role_name("http://github.com/user/repo,stable,myname") == "repo")

    assert(RoleRequirement.repo_url_to_role_name("http://github.com/user/repo.git,stable") == "repo")


# Generated at 2022-06-11 10:59:10.318982
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    print("Test case: test_RoleRequirement_role_yaml_parse")


# Generated at 2022-06-11 10:59:19.128840
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert "ansible-jenkins" == role_yaml_parse("git+https://github.com/bertvv/ansible-role-jenkins")['name']
    assert "ansible-jenkins" == role_yaml_parse("git+https://github.com/bertvv/ansible-role-jenkins,v2.0")['name']
    assert "ansible-jenkins" == role_yaml_parse("git+https://github.com/bertvv/ansible-role-jenkins,v2.0,bertvv.jenkins")['name']
    assert "git+https://github.com/bertvv/ansible-role-jenkins" == role_yaml_parse("git+https://github.com/bertvv/ansible-role-jenkins")['src']

# Generated at 2022-06-11 10:59:21.839257
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Testing with a string_type
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'

# Generated at 2022-06-11 10:59:30.864493
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    display.verbosity = 3
    role_req = RoleRequirement()

    # Test repo_url_to_role_name()
    repo_urls = [
        "https://github.com/rolename/rolename.git",
        "git+git://github.com/rolename/rolename.git",
        "git+https://github.com/rolename/rolename.git",
        "git+ssh://git@github.com/rolename/rolename.git",
        "git@github.com:rolename/rolename.git",
        "https://github.com/rolename/rolename.tar.gz",
        "rolename",
        "rolename-rolename",
    ]
