

# Generated at 2022-06-11 10:49:58.334963
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('my-role@git+http://git.example.com/repos/repo.git') == \
           RoleRequirement.role_yaml_parse({'role': 'my-role@git+http://git.example.com/repos/repo.git'}) == \
           {'name': 'my-role', 'src': 'http://git.example.com/repos/repo.git', 'scm': 'git', 'version': ''}

# Generated at 2022-06-11 10:50:09.138255
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test case #1:
    # input:
    #   role = 'https://github.com/geerlingguy/ansible-role-postgresql,v1.0.0,geerlingguy.postgresql'
    # expected output:
    #   {'src': 'https://github.com/geerlingguy/ansible-role-postgresql,v1.0.0', 'version': 'geerlingguy.postgresql', 'scm': None, 'name': None}

    role = "https://github.com/geerlingguy/ansible-role-postgresql,v1.0.0,geerlingguy.postgresql"

    role_dict = RoleRequirement.role_yaml_parse(role)

    if not isinstance(role_dict, dict):
        raise Assert

# Generated at 2022-06-11 10:50:17.646208
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test for the following parameters
    # 'role_name[,version[,name]]'

    role1 = 'role_name'
    role2 = 'role_name,version'
    role3 = 'role_name,version,name'

    # Create RoleRequirement object
    obj = RoleRequirement()

    # Perform test
    result1 = obj.role_yaml_parse(role1)
    result2 = obj.role_yaml_parse(role2)
    result3 = obj.role_yaml_parse(role3)

    # Check expected result
    assert result1 == {'name': 'role_name', 'src': 'role_name', 'scm': None, 'version': ''}

# Generated at 2022-06-11 10:50:28.665929
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = RoleRequirement()

    # Method role_yaml_parse handles a string like 'role_name'
    assert role.role_yaml_parse('role_name')['name'] == 'role_name'

    # Method role_yaml_parse handles a string like 'galaxy.role,version,name'
    assert role.role_yaml_parse('galaxy.role,version,name')['name'] == 'name'
    assert role.role_yaml_parse('galaxy.role,version,name')['version'] == 'version'
    assert role.role_yaml_parse('galaxy.role,version,name')['src'] == 'galaxy.role'

    # Method role_yaml_parse handles a string like 'galaxy.role,version'

# Generated at 2022-06-11 10:50:38.945066
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test a several dict style names

    # All dict style syntax work
    assert RoleRequirement.role_yaml_parse({'src' : 'galaxy.role', 'version' : '1.2.3'}) == {'name' : 'galaxy.role', 'src' : 'galaxy.role', 'scm' : None, 'version' : '1.2.3'}
    assert RoleRequirement.role_yaml_parse({'src' : 'galaxy.role,1.2.3', 'name' : 'my.role'}) == {'name' : 'my.role', 'src' : 'galaxy.role', 'scm' : None, 'version' : '1.2.3'}

# Generated at 2022-06-11 10:50:47.315625
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo", "incorrect pattern for repo_url_to_role_name"
    assert role_requirement.repo_url_to_role_name("git+http://git.example.com/repos/repo.git") == "repo", "incorrect pattern for repo_url_to_role_name"


# Generated at 2022-06-11 10:50:56.547612
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    r = RoleRequirement()

    # Case: valid repo url
    res = r.repo_url_to_role_name("https://github.com/myuser/myrole.git")
    assert res == "myrole"

    # Case: invalid repo url
    res = r.repo_url_to_role_name("https://github.com/myuser/myrole.git_something")
    assert res == "myrole"

    # Case: invalid repo url
    res = r.repo_url_to_role_name("https://github.com/myuser/myrolesomething.git")
    assert res == "myrolesomething"


# Generated at 2022-06-11 10:51:05.399758
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # ------------------------
    # test string format :
    # ------------------------
    # name,src,version
    # src,version,name
    # src,version
    # src
    # name

    role_name = 'ansible.somewhere'
    role_src = 'https://github.com/ansible/foo.git'
    role_version = '123'

    role_str_1 = '{0},{1},{2}'.format(role_name, role_src, role_version)
    role_str_2 = '{0},{1},{2}'.format(role_src, role_version, role_name)
    role_str_3 = '{0},{1}'.format(role_src, role_version)
    role_str_4 = role_src
    role_str_5

# Generated at 2022-06-11 10:51:17.459176
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    """
    collect tests data
    :return:
    """

# Generated at 2022-06-11 10:51:26.048912
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:51:52.774944
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:52:04.160136
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:52:15.602857
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    d = RoleRequirement.role_yaml_parse('foo')
    assert d['name'] == 'foo'
    assert d['src'] == 'foo'
    assert d['version'] is None
    assert d['scm'] is None

    d = RoleRequirement.role_yaml_parse({'role': 'foo'})
    assert d['name'] == 'foo'
    assert d['src'] == 'foo'
    assert d['version'] is None
    assert d['scm'] is None

    d = RoleRequirement.role_yaml_parse({'src': 'foo'})
    assert d['name'] == 'foo'
    assert d['src'] == 'foo'
    assert d['version'] is None
    assert d['scm'] is None


# Generated at 2022-06-11 10:52:28.512774
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # Turn on debug for these tests
    display.verbosity = 3
    # Test the method
    test_result = RoleRequirement.repo_url_to_role_name("https://github.com/myuser/myrepo.git")
    assert test_result == 'myrepo'
    test_result = RoleRequirement.repo_url_to_role_name("https://github.com/myuser/myrepo.git,1.0")
    assert test_result == 'myrepo'
    test_result = RoleRequirement.repo_url_to_role_name("https://github.com/myuser/myrepo.git,1.0,myname")
    assert test_result == 'myrepo'

# Generated at 2022-06-11 10:52:38.352589
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    test_repo_url_to_role_name = RoleRequirement.repo_url_to_role_name  # pylint: disable=invalid-name

    # Test without '://' in the repo
    assert test_repo_url_to_role_name('my_role') == 'my_role'
    assert test_repo_url_to_role_name('ansible-role-my_role') == 'ansible-role-my_role'

    # Test with '://' in the repo
    assert test_repo_url_to_role_name('https://github.com/robertdebock/ansible-role-my_role.git') == 'my_role'

# Generated at 2022-06-11 10:52:48.032471
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Case 1. Correct syntax (new style)
    case1 = dict(
        name = 'some_role',
        version = 'v0.1',
        src = 'https://github.com/username/some_role.git',
        scm = 'git'
    )
    assert RoleRequirement.role_yaml_parse(case1) == case1

    # Case 2. Correct syntax (old style)
    case2 = 'username.some_role,v0.1,some_role'
    assert RoleRequirement.role_yaml_parse(case2) == dict(
        name = 'some_role',
        version = 'v0.1',
        src = 'https://github.com/username/some_role.git',
        scm = 'git'
    )

    # Case 3. Correct syntax (old

# Generated at 2022-06-11 10:52:58.831995
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("name") == {'src': 'name', 'name': 'name', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml_parse("name,2.0") == {'src': 'name', 'name': 'name', 'scm': None, 'version': '2.0'}
    assert RoleRequirement.role_yaml_parse("name,2.0,foobar") == {'src': 'name', 'name': 'foobar', 'scm': None, 'version': '2.0'}
    assert RoleRequirement.role_yaml_parse({'role': "name"}) == {'src': 'name', 'name': 'name', 'scm': None, 'version': ''}
    assert RoleRequirement.role_yaml

# Generated at 2022-06-11 10:53:08.326018
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    repourl = 'https://github.com/Nordstrom/ansible-role-apache.git'
    assert RoleRequirement.repo_url_to_role_name(repourl) == 'ansible-role-apache'
    repourl = 'git@github.com:Nordstrom/ansible-role-apache.git'
    assert RoleRequirement.repo_url_to_role_name(repourl) == 'ansible-role-apache'
    repourl = 'something'
    assert RoleRequirement.repo_url_to_role_name(repourl) == 'something'
    repourl = 'something,temp'
    assert RoleRequirement.repo_url_to_role_name(repourl) == 'something'
    repourl = 'something,temp,test'


# Generated at 2022-06-11 10:53:17.745314
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('https://github.com/cmoulliard/ansible-role.git') == 'ansible-role'
    assert RoleRequirement.repo_url_to_role_name('git@git.corp.com:repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/cmoulliard/ansible-role.git,v1.0') == 'ansible-role'
    assert RoleRequirement.repo_url_to_role_name('git@git.corp.com:repo.git,v1.0') == 'repo'

# Generated at 2022-06-11 10:53:27.443231
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("https://github.com/user/repo.git") == 'repo'
    assert RoleRequirement.repo_url_to_role_name("https://github.com/user/repo.tar.gz") == 'repo.tar'
    assert RoleRequirement.repo_url_to_role_name("https://github.com/user/repo,v1,user") == 'repo'
    assert RoleRequirement.repo_url_to_role_name("https://github.com/user/repo.tar.gz+https://github.com/user/repo2,v1,user") == 'repo.tar.gz+https://github.com/user/repo2'

# Generated at 2022-06-11 10:53:53.246292
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test role as string
    role = "https://github.com/username/repo_name"
    actual = RoleRequirement.role_yaml_parse(role)
    expected = dict(name='repo_name', src='https://github.com/username/repo_name', scm=None, version='')
    assert expected == actual

    role = "https://github.com/username/repo_name,v1.0"
    actual = RoleRequirement.role_yaml_parse(role)
    expected = dict(name='repo_name', src='https://github.com/username/repo_name', scm=None, version='v1.0')
    assert expected == actual

    role = "https://github.com/username/repo_name,v1.0,role_name"
   

# Generated at 2022-06-11 10:53:55.734406
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("scm+https://github.com/geerlingguy/ansible-role-jenkins,1.8.1") == {'name': 'ansible-role-jenkins', 'src': 'https://github.com/geerlingguy/ansible-role-jenkins', 'scm': 'scm', 'version': '1.8.1'}

# Generated at 2022-06-11 10:54:07.271045
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    print("\nDEMO: test_RoleRequirement_role_yaml_parse()")
    ### RoleRequirement.role_yaml_parse('role_name[,version[,name]]') ###
    # role_name:
    role_yaml_parse_result = RoleRequirement.role_yaml_parse('role_name')
    print(role_yaml_parse_result['name'])
    assert role_yaml_parse_result['name'] == 'role_name'
    assert role_yaml_parse_result['src'] == 'role_name'
    assert role_yaml_parse_result['scm'] is None
    assert role_yaml_parse_result['version'] == ''

    # role_name,version:
    role_yaml_parse_result = RoleRequirement.role_yaml_

# Generated at 2022-06-11 10:54:17.915611
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('nickjj.docker_ubuntu') == dict(name='nickjj.docker_ubuntu', src=None, scm=None, version=None)

    assert RoleRequirement.role_yaml_parse('nickjj.docker_ubuntu,1.0.0') == dict(name='nickjj.docker_ubuntu', src=None, scm=None, version='1.0.0')

    assert RoleRequirement.role_yaml_parse('nickjj.docker_ubuntu,1.0.0,apt') == dict(name='apt', src=None, scm=None, version='1.0.0')


# Generated at 2022-06-11 10:54:24.481210
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test RoleRequirement.role_yaml_parse() against expected results
    # If the result of the call to RoleRequirement.role_yaml_parse()
    # does not match the expected result
    # then raise an exception with the mismatch

    # Test 1:
    # Old style role line
    role = 'geerlingguy.java'
    expected_result = dict(name='geerlingguy.java', src=None, scm=None, version=None)
    result = RoleRequirement.role_yaml_parse(role)
    if result != expected_result:
        raise Exception("Test 1: Result %s does not match expected: %s" % (result, expected_result))

    # Test 2:
    # Old style role line with version
    role = 'geerlingguy.java,1.7'
    expected

# Generated at 2022-06-11 10:54:35.298121
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache.git') == 'ansible-role-apache'
    assert RoleRequirement.repo_url_to_role_name('git://github.com/geerlingguy/ansible-role-elasticsearch.git') == 'ansible-role-elasticsearch'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-elasticsearch/archive/1.8.1.tar.gz') == 'ansible-role-elasticsearch-1.8.1'

# Generated at 2022-06-11 10:54:45.336581
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:54:52.040678
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:55:02.243899
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0.0") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,v1.0.0,fred") == "repo"

# Generated at 2022-06-11 10:55:11.838485
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    def assert_role_equals(expected, actual):
        for key in expected:
            assert key in actual
            wrapped = wrap_var(expected[key])
            assert wrapped == actual[key]

    # test parse
    assert_role_equals({'name': 'foo', 'src': 'git+https://github.com/ANXS/foo', 'scm': 'git', 'version': 'galaxy-v1.0'},
                       RoleRequirement.role_yaml_parse({'src': 'git+https://github.com/ANXS/foo,galaxy-v1.0'}))

# Generated at 2022-06-11 10:55:35.200460
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    import os
    import shutil
    import tempfile
    from ansible.playbook.role.requirement import RoleRequirement

    # Setup temp path
    temp_path = tempfile.mkdtemp()

    # Test role_yaml_parse
    assert RoleRequirement.role_yaml_parse('memcached') == dict(name='memcached', src='', scm=None, version=None)
    assert RoleRequirement.role_yaml_parse('memcached,1.2.4') == dict(name='memcached', src='', scm=None, version='1.2.4')
    assert RoleRequirement.role_yaml_parse('memcached,1.2.4,test') == dict(name='test', src='', scm=None, version='1.2.4')

# Generated at 2022-06-11 10:55:40.993202
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    import json

    with open('/tmp/test.json') as f:
        data = json.load(f)
    print(data)
    for x in data:
        print(x, "\n------->\n", RoleRequirement.role_yaml_parse(x))

if __name__ == '__main__':
    print("test RoleRequirement")
    test_RoleRequirement_role_yaml_parse()

# Generated at 2022-06-11 10:55:51.197128
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    #tests with git://
    assert RoleRequirement.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'
    #tests with git@
    assert RoleRequirement.repo_url_to_role_name('git@git.example.com/repos/repo.git') == 'repo'
    #tests with http://
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    #tests with https://
    assert RoleRequirement.repo_url_to_role_name('https://git.example.com/repos/repo.git') == 'repo'
    #tests with file://
    assert RoleRequirement.repo

# Generated at 2022-06-11 10:55:57.911074
# Unit test for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:56:09.586171
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("geerlingguy.jenkins") == {'scm': None, 'name': 'geerlingguy.jenkins', 'version': None, 'src': 'geerlingguy.jenkins'}
    assert RoleRequirement.role_yaml_parse("geerlingguy.jenkins,1.0.2") == {'scm': None, 'name': 'geerlingguy.jenkins', 'version': '1.0.2', 'src': 'geerlingguy.jenkins'}

# Generated at 2022-06-11 10:56:18.873853
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    actual_role = "https://github.com/username/repo,v1.0.0,foo_role"
    expected_role = dict(name="foo_role", src="https://github.com/username/repo", scm="git", version="v1.0.0")
    actual = RoleRequirement.role_yaml_parse(actual_role)
    assert actual == expected_role

    actual_role = "https://github.com/username/repo"
    expected_role = dict(name="repo", src="https://github.com/username/repo", scm="git", version='')
    actual = RoleRequirement.role_yaml_parse(actual_role)
    assert actual == expected_role


# Generated at 2022-06-11 10:56:28.618711
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:56:39.277198
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_name = RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git')
    assert role_name == 'repo'
    role_name = RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,1.0.0')
    assert role_name == 'repo'
    role_name = RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git,1.0.0,toto')
    assert role_name == 'repo'
    role_name = RoleRequirement.repo_url_to_role_name('git+http://git.example.com/repos/repo.git')
   

# Generated at 2022-06-11 10:56:48.485086
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:56:58.464293
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # test repo_url_to_role_name with repo_url's conatining '://' and '@'
    assert ('repo' == RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git'))
    assert ('repo' == RoleRequirement.repo_url_to_role_name('https://git.example.com/repos/repo.git'))
    assert ('repo' == RoleRequirement.repo_url_to_role_name('git@git.example.com/repos/repo.git'))
    assert ('repo' == RoleRequirement.repo_url_to_role_name('git://git.example.com/repos/repo.git'))

# Generated at 2022-06-11 10:57:24.159098
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Case 1:
    role = "galaxy.ansible.com, junaid18183.ntp"
    assert RoleRequirement.role_yaml_parse(role) == {'name':'junaid18183.ntp', 'src':'galaxy.ansible.com', 'scm':None, 'version':None}
    # Case 2:
    role = "https://github.com/geerlingguy/ansible-role-ntp.git"
    assert RoleRequirement.role_yaml_parse(role) == {'name':'geerlingguy.ansible-role-ntp', 'src':'https://github.com/geerlingguy/ansible-role-ntp.git', 'scm':'git', 'version':'HEAD'}
    # Case 3:

# Generated at 2022-06-11 10:57:33.239550
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    RoleRequirement.role_yaml_parse(role='geerlingguy.java') == {'src': 'geerlingguy.java', 'name': 'geerlingguy.java', 'scm': None, 'version': ''}
    RoleRequirement.role_yaml_parse(role='geerlingguy.java,1.7') == {'src': 'geerlingguy.java', 'name': 'geerlingguy.java', 'scm': None, 'version': '1.7'}
    RoleRequirement.role_yaml_parse(role='geerlingguy.java,1.7,test') == {'src': 'geerlingguy.java', 'name': 'test', 'scm': None, 'version': '1.7'}

# Generated at 2022-06-11 10:57:44.540080
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role = {'src': 'https://github.com/ansible/ansible-examples,origin/devel', 'version': 'v1.0'}
    assert RoleRequirement.role_yaml_parse(role) == {'name': 'ansible-examples', 'src': 'https://github.com/ansible/ansible-examples', 'scm': None, 'version': 'v1.0'}

    role = {'src': 'https://github.com/ansible/ansible-examples,origin/devel,ansible-examples'}

# Generated at 2022-06-11 10:57:54.408600
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    if RoleRequirement.repo_url_to_role_name('https://www.example.com/repos/repo.git') != 'repo':
        raise Exception("RoleRequirement.repo_url_to_role_name failed")
    if RoleRequirement.repo_url_to_role_name('https://www.example.com/repos/repo.tar.gz') != 'repo':
        raise Exception("RoleRequirement.repo_url_to_role_name failed")
    if RoleRequirement.repo_url_to_role_name('https://www.example.com/repos/repo,v1.0.tar.gz') != 'repo':
        raise Exception("RoleRequirement.repo_url_to_role_name failed")

# Generated at 2022-06-11 10:58:04.113330
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    rr = RoleRequirement()
    assert rr.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert rr.repo_url_to_role_name('https://git.example.com/repos/repo.git') == 'repo'
    assert rr.repo_url_to_role_name('http://git.example.com/repos/repo.tar.gz') == 'repo'
    assert rr.repo_url_to_role_name('git@git.example.com/repos/repo.git') == 'repo'

# Generated at 2022-06-11 10:58:13.584557
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:58:19.625706
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    repo_url = "git+https://github.com/geerlingguy/ansible-role-apache.git"
    result = RoleRequirement.repo_url_to_role_name(repo_url)
    assert result == "ansible-role-apache"
    repo_url = "geerlingguy.apache"
    result = RoleRequirement.repo_url_to_role_name(repo_url)
    assert result == "geerlingguy.apache"

# Generated at 2022-06-11 10:58:29.915847
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # normal git url
    url = 'http://git.example.com/repos/repo.git'
    name = RoleRequirement.repo_url_to_role_name(url)
    assert name == 'repo'

    # normal ssh url
    url = 'git@git.example.com:repos/repo.git'
    name = RoleRequirement.repo_url_to_role_name(url)
    assert name == 'repo'

    # zip url
    url = 'http://git.example.com/repos/repo.tar.gz'
    name = RoleRequirement.repo_url_to_role_name(url)
    assert name == 'repo'

    # zip url with specific version

# Generated at 2022-06-11 10:58:39.920345
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Case 1
    role_string = 'ansible-role-nagios'
    role = RoleRequirement.role_yaml_parse(role_string)
    assert role["name"] == 'ansible-role-nagios'
    assert role["version"] == ''
    assert role["scm"] == None
    assert role["src"] == 'ansible-role-nagios'

    # Case 2
    role_string = 'ansible-role-nagios,v1.0'
    role = RoleRequirement.role_yaml_parse(role_string)
    assert role["name"] == 'ansible-role-nagios'
    assert role["version"] == 'v1.0'
    assert role["scm"] == None
    assert role["src"] == 'ansible-role-nagios'

# Generated at 2022-06-11 10:58:46.859024
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("https://github.com/user/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://test.example.com/test_repo.git") == "test_repo"
    assert RoleRequirement.repo_url_to_role_name("http://test.example.com/testrepo.git") == "testrepo"
    assert RoleRequirement.repo_url_to_role_name("http://test.example.com/testrepo") == "testrepo"
    assert RoleRequirement.repo_url