

# Generated at 2022-06-11 10:50:01.201234
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.errors import AnsibleError
    from ansible.utils.display import Display

    display = Display()

    # Test old style role name
    role = 'nginx'
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'nginx', 'scm': None, 'src': '', 'version': None}

    # Test old style role name with version
    role = 'nginx,1.9.1'
    result = RoleRequirement.role_yaml_parse(role)
    assert result == {'name': 'nginx', 'scm': None, 'src': '', 'version': '1.9.1'}

    # Test old style role name with version and name
    role = 'nginx,1.9.1,foobar'
    result = Role

# Generated at 2022-06-11 10:50:11.945363
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # RoleRequirement.role_yaml_parse: Should throw an error when having incorrect dependency format.
    invalid_roles = [
        # Have too many parts
        "role1[,version1,name1,name2]",
        "role1+git+https://github.com/user/repo,version1,name1",
        # Have less parts than expected
        "role1[,version1]",
        "role1+git+https://github.com/user/repo[,version1]",
    ]
    for role in invalid_roles:
        try:
            role_details = RoleRequirement.role_yaml_parse(role)
            assert False
        except AnsibleError:
            pass

    # RoleRequirement.role_yaml_parse: Should correctly parse name only dependency format.
    assert Role

# Generated at 2022-06-11 10:50:22.274277
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('test_url') == 'test_url'
    assert RoleRequirement.repo_url_to_role_name('test_url.git') == 'test_url'
    assert RoleRequirement.repo_url_to_role_name('test_url.tar.gz') == 'test_url'
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/test_url.git') == 'test_url'
    assert RoleRequirement.repo_url_to_role_name('test_url,master') == 'test_url'
    assert RoleRequirement.repo_url_to_role_name('test_url,master,new_name') == 'test_url'
    assert RoleRequ

# Generated at 2022-06-11 10:50:23.502350
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # TODO
    pass

# Generated at 2022-06-11 10:50:34.513185
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role = { 'role': 'test_role' }
    spec = RoleRequirement.role_yaml_parse(role)
    assert spec == { 'role': 'test_role', 'name': 'test_role', 'src': 'test_role', 'scm': None, 'version': '' }
    role = { 'role': 'test_role', 'version': 'test_version' }
    spec = RoleRequirement.role_yaml_parse(role)
    assert spec == { 'role': 'test_role', 'name': 'test_role', 'src': 'test_role', 'scm': None, 'version': 'test_version' }
    role = { 'role': 'test_role,test_version' }
    spec = RoleRequirement.role_yaml_parse(role)

# Generated at 2022-06-11 10:50:40.177664
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    display = Display()
    url = 'git+https://github.com/geerlingguy/ansible-role-apache,v1.0.0,geerlingguy.apache'
    role_name = RoleRequirement.repo_url_to_role_name(url)
    if role_name == 'geerlingguy':
        display.display('RoleRequirement.repo_url_to_role_name() unit test passed')
    else:
        display.display('RoleRequirement.repo_url_to_role_name() unit test failed')

# Generated at 2022-06-11 10:50:43.110929
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"


# Generated at 2022-06-11 10:50:54.200538
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    """
    Test role_yaml_parse method of class RoleRequirement
    """
    # test with an incorrect type of argument
    try:
        RoleRequirement.role_yaml_parse(['test', 'test', 'test'])
        assert False
    except AnsibleError:
        assert True

    # test with a good argument
    role = RoleRequirement.role_yaml_parse('test,test,test')
    assert role == {'name': 'test', 'src': 'test', 'scm': None, 'version': 'test'}

    # test with a good argument
    role = RoleRequirement.role_yaml_parse('test')
    assert role == {'name': 'test', 'src': 'test', 'scm': None, 'version': None}

# Generated at 2022-06-11 10:51:03.848137
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # test if repo_url_to_role_name returns the expected role name for all kind of URLs
    expected_role_name = 'repo'
    test_role_name = RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git')
    assert expected_role_name == test_role_name

    expected_role_name = 'repo'
    test_role_name = RoleRequirement.repo_url_to_role_name('https://git.example.com/repos/repo.git')
    assert expected_role_name == test_role_name

    expected_role_name = 'repo'

# Generated at 2022-06-11 10:51:16.198074
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    old_style = 'galaxy.role'
    old_style_result = {'name': 'galaxy.role', 'scm': None, 'src': 'galaxy.role', 'version': None}
    if RoleRequirement.role_yaml_parse(old_style) != old_style_result:
        print('Failure: test_RoleRequirement_role_yaml_parse: {}'.format(old_style))

    old_style = 'galaxy.role,v1'
    old_style_result = {'name': 'galaxy.role', 'scm': None, 'src': 'galaxy.role', 'version': 'v1'}

# Generated at 2022-06-11 10:51:27.884722
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    r = RoleRequirement()

    # Old style
    results = {'name': 'foobar', 'src': 'https://github.com/someuser/foobar', 'scm': 'git', 'version': None}
    assert r.role_yaml_parse({'role': 'https://github.com/someuser/foobar'}) == results

    # New style (not specifying a "name")
    results = {'name': 'foobar', 'src': 'https://github.com/someuser/foobar', 'scm': 'git', 'version': None}
    assert r.role_yaml_parse({'src': 'https://github.com/someuser/foobar'}) == results

    # New style (specifying a "name")

# Generated at 2022-06-11 10:51:40.252078
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    result = RoleRequirement.role_yaml_parse("role[,version[,name]]")
    assert result['name'] == 'role'
    assert result['src'] == 'role'

    result = RoleRequirement.role_yaml_parse("git+git@git.example.com:repo.git,branch[,name]")
    assert result['name'] == 'repo'
    assert result['scm'] == 'git'
    assert result['src'] == 'git@git.example.com:repo.git,branch'
    assert result['version'] == 'HEAD'

    result = RoleRequirement.role_yaml_parse("http://git.example.com/repos/repo.git,branch[,name]")
    assert result['name'] == 'repo'
    assert result['src']

# Generated at 2022-06-11 10:51:50.953720
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    from ansible.module_utils._text import to_bytes

    # Test cases for a correctly formatted meta/main.yml (old style)
    meta_main_yml_old_style_tests = [
        # Test case #1
        {
            'input_meta_main_yml': """
---
dependencies:
- role: ansible-role-foo
  version: v1.0,v2.0
""",
            'expected_output':
                dict(name='ansible-role-foo', src='ansible-role-foo', scm=None, version='v1.0,v2.0'),
        }
    ]

    # Test cases for a correctly formatted meta/main.yml

# Generated at 2022-06-11 10:52:02.010417
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:52:13.952423
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git://git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('http://username@git.example.com/repos/repo.git') == 'repo'
    assert RoleRequirement.repo_url_to_role_name('git://username@git.example.com/repos/repo.git') == 'repo'

# Generated at 2022-06-11 10:52:20.430989
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert 'abc' == RoleRequirement.repo_url_to_role_name('abc')
    assert 'abcdef' == RoleRequirement.repo_url_to_role_name('http://github.com/ansible/abcdef')
    assert 'abcdef' == RoleRequirement.repo_url_to_role_name('https://github.com/ansible/abcdef')
    assert 'abcdef' == RoleRequirement.repo_url_to_role_name('git@github.com/ansible/abcdef')
    assert 'abcdef' == RoleRequirement.repo_url_to_role_name('http://github.com/ansible/abcdef')
    assert 'abcdef' == RoleRequirement.repo_url_to_role_name('https://github.com/ansible/abcdef')


# Generated at 2022-06-11 10:52:32.471457
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Old style: { role: "galaxy.role,version,name", other_vars: "here" }
    assert RoleRequirement.role_yaml_parse(role='michael.dehaan,1.0,z') == {'name': 'z', 'src': 'michael.dehaan', 'scm': None, 'version': '1.0'}
    assert RoleRequirement.role_yaml_parse(role='src+michael.dehaan,1.0,z') == {'name': 'z', 'src': 'michael.dehaan', 'scm': 'src', 'version': '1.0'}

# Generated at 2022-06-11 10:52:38.179021
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git/") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git/master") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,0.0.1")

# Generated at 2022-06-11 10:52:47.625958
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    role_requirement = RoleRequirement()
    assert role_requirement.repo_url_to_role_name('http://github.com/my_repo/my_role') == 'my_role'
    assert role_requirement.repo_url_to_role_name('http://github.com/my_repo/my_role.git') == 'my_role'
    assert role_requirement.repo_url_to_role_name('http://github.com/my_repo/my_role.tar.gz') == 'my_role'
    assert role_requirement.repo_url_to_role_name('http://github.com/my_repo/my_role,v0.1.0') == 'my_role'
    assert role_requirement.repo_url_to_role

# Generated at 2022-06-11 10:52:58.540790
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('git+https://github.com/example42/ansible-tuto-roles.git,master,example42.tuto_test') == {'name': 'example42.tuto_test', 'src': 'https://github.com/example42/ansible-tuto-roles.git', 'scm': 'git', 'version': 'master'}
    assert RoleRequirement.role_yaml_parse('git+https://github.com/example42/ansible-tuto-roles.git') == {'name': 'ansible-tuto-roles', 'src': 'https://github.com/example42/ansible-tuto-roles.git', 'scm': 'git', 'version': ''}

# Generated at 2022-06-11 10:53:30.230723
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_spec = RoleRequirement.role_yaml_parse("a name,1.2.2,another name")
    assert {"name": "another name", "src": "a name", "scm": None, "version": "1.2.2"} == role_spec

    role_spec = RoleRequirement.role_yaml_parse("a name,1.2.2")
    assert {"name": "a name", "src": "a name", "scm": None, "version": "1.2.2"} == role_spec

    role_spec = RoleRequirement.role_yaml_parse("a name")
    assert {"name": "a name", "src": "a name", "scm": None, "version": None} == role_spec


# Generated at 2022-06-11 10:53:37.005009
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    class Test:
        def __init__(self):
            self.name = "test"

    test_object = Test()

    test_object.url = "https://github.com/ansible/ansible-examples.git"
    result = RoleRequirement.repo_url_to_role_name(test_object.url)
    assert result == "ansible-examples"

    test_object.url = "git://git.example.com/repos/repo.git"
    result = RoleRequirement.repo_url_to_role_name(test_object.url)
    assert result == "repo"

    test_object.url = "git@git.example.com:some_user/some_repo"

# Generated at 2022-06-11 10:53:48.190569
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Full form
    assert RoleRequirement.role_yaml_parse(dict(name='n', src='s', scm='c', version='v')) == dict(name='n', src='s', scm='c', version='v')
    assert RoleRequirement.role_yaml_parse(dict(name='n', src='s', scm='c')) == dict(name='n', src='s', scm='c', version='')
    assert RoleRequirement.role_yaml_parse(dict(name='n', src='s')) == dict(name='n', src='s', scm=None, version='')
    assert RoleRequirement.role_yaml_parse(dict(src='s')) == dict(name='s', src='s', scm=None, version='')

    # Old form

# Generated at 2022-06-11 10:53:57.609531
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # test for old style requirements.yml
    assert RoleRequirement.role_yaml_parse('http://foo.com/my/role,1.0') == dict(name='role', src='http://foo.com/my/role', scm='git', version='1.0')

    # test for new style requirements.yml
    assert RoleRequirement.role_yaml_parse(dict(src='http://foo.com/my/role,1.0')) == dict(name='role', src='http://foo.com/my/role', scm='git', version='1.0')

    # test whether the name will be overridden by the src

# Generated at 2022-06-11 10:54:09.716688
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("role1,0.1") == dict(name="role1", scm=None, src="role1", version="0.1")
    assert RoleRequirement.role_yaml_parse("role2,0.2,custom_name") == dict(name="custom_name", scm=None, src="role2", version="0.2")
    assert RoleRequirement.role_yaml_parse({'src': 'user/role3'}) == dict(name='role3', scm=None, src='user/role3', version='')
    assert RoleRequirement.role_yaml_parse({'src': 'user/role3,1.0'}) == dict(name='role3', scm=None, src='user/role3', version='1.0')

# Generated at 2022-06-11 10:54:12.476265
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    result = RoleRequirement.repo_url_to_role_name('http://git.example.com/repos/repo.git')
    assert result == 'repo'

# Generated at 2022-06-11 10:54:21.839948
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # Asserts expected role name for given git protocol
    def assert_role_name(git_protocol, expected_role_name):
        assert RoleRequirement.repo_url_to_role_name('{}{}{}'.format(git_protocol, expected_role_name, git_postfix)) == expected_role_name
        assert RoleRequirement.repo_url_to_role_name('{}{}{}'.format(git_protocol, expected_role_name, git_postfix_tar)) == expected_role_name

    # Asserts expected role name for given git protocol and expected version

# Generated at 2022-06-11 10:54:32.961541
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    # Test for new style
    role = "geerlingguy.apache"
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == "geerlingguy.apache"
    assert result['src'] == "geerlingguy.apache"
    assert result['scm'] == None
    assert result['version'] == None

    role = {'role': 'geerlingguy.apache'}
    result = RoleRequirement.role_yaml_parse(role)
    assert result['name'] == "geerlingguy.apache"
    assert result['src'] == "geerlingguy.apache"
    assert result['scm'] == None
    assert result['version'] == None

    # Test for new style

# Generated at 2022-06-11 10:54:42.984889
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # Test for the old style
    line = 'roles/role1'
    assert(RoleRequirement.role_yaml_parse(line) == dict(name='role1', src='roles/role1', scm=None, version=None))

    line = 'git+http://git.example.com/repos/role2.git'
    assert(RoleRequirement.role_yaml_parse(line) == dict(name='role2', src='http://git.example.com/repos/role2.git', scm='git', version=None))

    line = 'roles/role3,v3.0'
    assert(RoleRequirement.role_yaml_parse(line) == dict(name='role3', src='roles/role3', scm=None, version='v3.0'))

   

# Generated at 2022-06-11 10:54:50.941406
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git")     == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz")  == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,x.y.z")   == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git,x.y.z") == "repo"

# Generated at 2022-06-11 10:55:23.745086
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse('git+https://bitbucket.org/USGS-CIDA/ansible-role-boto') == {'name': 'ansible-role-boto', 'src': 'https://bitbucket.org/USGS-CIDA/ansible-role-boto', 'scm': 'git', 'version': None}
    assert RoleRequirement.role_yaml_parse('https://bitbucket.org/USGS-CIDA/ansible-role-boto,v2.2.0') == {'name': 'ansible-role-boto', 'src': 'https://bitbucket.org/USGS-CIDA/ansible-role-boto', 'scm': None, 'version': 'v2.2.0'}
    assert RoleRequirement.role_

# Generated at 2022-06-11 10:55:33.101789
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    require = RoleRequirement()


# Generated at 2022-06-11 10:55:43.194740
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # TEST: when role is a string
    role = "git+https://github.com/FooBar.git"
    expected_result = {
        'name': 'FooBar',
        'scm': 'git',
        'src': 'https://github.com/FooBar.git',
        'version': None
    }
    assert RoleRequirement.role_yaml_parse(role) == expected_result

    # TEST: when role is a dictionary
    role = {
        "src": "git+https://github.com/FooBar.git",
        "scm": "git"
    }

# Generated at 2022-06-11 10:55:53.134044
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    from ansible.errors import AnsibleError

    # Test for "simple" string
    role = "galaxy.role"
    spec = RoleRequirement.role_yaml_parse(role)
    assert spec["name"] == "galaxy.role"
    assert spec["src"] == role
    assert spec["scm"] is None
    assert spec["version"] == ''

    # Test for "scm+url"
    role = "git+https://github.com/geerlingguy/ansible-role-apache.git"
    spec = RoleRequirement.role_yaml_parse(role)
    assert spec["name"] == "ansible-role-apache"
    assert spec["src"] == role
    assert spec["scm"] == "git"
    assert spec["version"] == ''

    # Test for "scm+url

# Generated at 2022-06-11 10:56:03.186071
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    class TestRoleRequirement(object):

        def test_role_yaml_parse(self):
            role = RoleRequirement.role_yaml_parse('git+https://git.example.com/repos/repo.git,v0.2')
            assert role["name"] == "repo"
            assert role["src"] == "https://git.example.com/repos/repo.git"
            assert role["scm"] == "git"
            assert role["version"] == "v0.2"

        def test_role_yaml_parse_complex_url(self):
            role1 = RoleRequirement.role_yaml_parse('git+https://git.example.com/repos/repo-2.0.tar.gz')
            assert role1['name'] == "repo"
            assert role

# Generated at 2022-06-11 10:56:06.487316
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    url = "https://github.com/foo/bar/tarball/master"
    name = RoleRequirement.repo_url_to_role_name(url)
    assert name == "bar"


# Generated at 2022-06-11 10:56:16.781059
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    role_requirement = RoleRequirement()
    # Test passing string
    result = role_requirement.role_yaml_parse('geerlingguy.java')
    assert(result == {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': None})
    # Test passing string with version
    result = role_requirement.role_yaml_parse('geerlingguy.java, 1.7')
    assert(result == {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': '1.7'})
    # Test passing string with name and version

# Generated at 2022-06-11 10:56:20.526165
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    """
    Validate for git repo url.
    :return:
    """
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache') == 'ansible-role-apache'

# Unit test  for method role_yaml_parse of class RoleRequirement

# Generated at 2022-06-11 10:56:30.551293
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    rrd = RoleRequirement
    assert rrd.role_yaml_parse("http://git.example.com/repos/repo.git") == {'name': 'repo',
                                                                            'src': 'http://git.example.com/repos/repo.git',
                                                                            'scm': None,
                                                                            'version': None}
    assert rrd.role_yaml_parse("http://git.example.com/repos/repo.git,v1.2") == {'name': 'repo',
                                                                                  'src': 'http://git.example.com/repos/repo.git',
                                                                                  'scm': None,
                                                                                  'version': 'v1.2'}
    assert rrd.role_

# Generated at 2022-06-11 10:56:40.945955
# Unit test for method repo_url_to_role_name of class RoleRequirement

# Generated at 2022-06-11 10:57:13.050415
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@github.com:ansible/ansible-examples.git") == "ansible-examples"
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("git@github.com:ansible/ansible-examples,v0.0.0.tar.gz") == "ansible-examples,v0.0.0.tar.gz"
    assert RoleRequirement.repo_url_to_role_

# Generated at 2022-06-11 10:57:23.256673
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert RoleRequirement.role_yaml_parse("geerlingguy.jenkins") == {'name': 'geerlingguy.jenkins', 'scm': None, 'src': 'geerlingguy.jenkins', 'version': None}
    assert RoleRequirement.role_yaml_parse("geerlingguy.jenkins,1.4.2") == {'name': 'geerlingguy.jenkins', 'scm': None, 'src': 'geerlingguy.jenkins', 'version': '1.4.2'}

# Generated at 2022-06-11 10:57:32.486247
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():

    # test for method of class RoleRequirement
    role_requirement = RoleRequirement()

    # test for normal http address
    # Github address
    # https://github.com/michaelrichardson/ansible-config
    assert role_requirement.repo_url_to_role_name("http://github.com/michaelrichardson/ansible-config") == "ansible-config"
    assert role_requirement.repo_url_to_role_name("https://github.com/michaelrichardson/ansible-config") == "ansible-config"
    assert role_requirement.repo_url_to_role_name("http://github.com/michaelrichardson/ansible-config.git") == "ansible-config"
    assert role_requirement.repo_url_to_

# Generated at 2022-06-11 10:57:43.406760
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    # invalid repo_url should raise exception
    try:
        RoleRequirement.repo_url_to_role_name("../../not found")
    except AnsibleError as e:
        assert e.message == "Invalid role line (../../not found). Proper format is 'role_name[,version[,name]]'"
    # non http/https repo_url should just return it
    assert RoleRequirement.repo_url_to_role_name("../../not found") == "../../not found"
    # non http/https repo_url should just return it
    assert RoleRequirement.repo_url_to_role_name("git@git.example.com:ansible-modules-core/ansible") == "ansible-modules-core/ansible"
    # https repo_url should return name

# Generated at 2022-06-11 10:57:52.034631
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert 'repo' == RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/repo.git")
    assert 'repo-1' == RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/repo-1.git")
    assert '11111' == RoleRequirement.repo_url_to_role_name("https://git.example.com/repos/11111.git")
    assert 'repo' == RoleRequirement.repo_url_to_role_name("git@git.example.com:repos/repo.git")


# Generated at 2022-06-11 10:57:59.325015
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    role = "geerlingguy.jenkins,v2.2.2"
    expected_result = dict(name="geerlingguy.jenkins", version="v2.2.2")
    actual_result = RoleRequirement.role_yaml_parse(role)
    assert(actual_result == expected_result)

    role = "git+https://github.com/geerlingguy/ansible-role-jenkins.git,v2.2.2"
    expected_result = dict(src="https://github.com/geerlingguy/ansible-role-jenkins.git", scm="git", version="v2.2.2")
    actual_result = RoleRequirement.role_yaml_parse(role)
    assert(actual_result == expected_result)


# Generated at 2022-06-11 10:58:09.289679
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    tests = [
        ('git://github.com/test/test.git', 'test'),
        ('https://github.com/test/test', 'test'),
        ('https://github.com/test/test.git', 'test'),
        ('https://github.com/test/test.tar.gz', 'test'),
        ('git+http://github.com/test/test.git', 'test'),
        ('git+http://github.com/test/test.git,v1.2.3', 'test'),
        ('git+http://github.com/test/test.git,v1.2.3,foo', 'foo'),
        ('git+http://github.com/test/test.git,v1.2.3, foo', 'foo'),
    ]
    for x, y in tests:
        assert RoleRequirement

# Generated at 2022-06-11 10:58:19.003580
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():

    # test string
    role = 'geerlingguy.java,1.7.0'
    role_sdict = {'name': 'geerlingguy.java', 'scm': None, 'src': 'geerlingguy.java', 'version': '1.7.0'}
    result = RoleRequirement.role_yaml_parse(role)
    assert result == role_sdict

    # test dict
    role = {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7.0'}
    role_sdict = {'name': 'geerlingguy.java', 'src': 'geerlingguy.java', 'scm': None, 'version': '1.7.0'}

# Generated at 2022-06-11 10:58:29.153486
# Unit test for method role_yaml_parse of class RoleRequirement
def test_RoleRequirement_role_yaml_parse():
    assert(RoleRequirement.role_yaml_parse("src") == dict(name="src", src="src", scm=None, version=None))
    assert(RoleRequirement.role_yaml_parse("src,1.0") == dict(name="src", src="src", scm=None, version="1.0"))
    assert(RoleRequirement.role_yaml_parse("src,1.0,name") == dict(name="name", src="src", scm=None, version="1.0"))
    assert(RoleRequirement.role_yaml_parse("git+http://src,1.0,name") == dict(name="name", src="http://src", scm="git", version="1.0"))


# Generated at 2022-06-11 10:58:39.157626
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache.git') == 'ansible-role-apache'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache') == 'ansible-role-apache'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache.tar.gz') == 'ansible-role-apache'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/geerlingguy/ansible-role-apache.zip') == 'ansible-role-apache'
    assert RoleRequirement.repo_url_

# Generated at 2022-06-11 10:59:26.546204
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.git") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo.tar.gz") == "repo"
    assert RoleRequirement.repo_url_to_role_name("http://git.example.com/repos/repo,v1.0.0") == "repo"

# Generated at 2022-06-11 10:59:37.109544
# Unit test for method repo_url_to_role_name of class RoleRequirement
def test_RoleRequirement_repo_url_to_role_name():
    display.display('Testing RoleRequirement.repo_url_to_role_name')
    assert RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-galaxy') == 'ansible-galaxy'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-galaxy.git') == 'ansible-galaxy'
    assert RoleRequirement.repo_url_to_role_name('https://github.com/ansible/ansible-galaxy,v0.1') == 'ansible-galaxy'