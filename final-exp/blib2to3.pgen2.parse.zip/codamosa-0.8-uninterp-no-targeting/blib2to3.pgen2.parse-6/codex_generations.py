

# Generated at 2022-06-21 10:10:15.551691
# Unit test for function lam_sub
def test_lam_sub():
    n = ('Expression', None, (1, 1),
         [('Name', 'foo', (-1, -1), None),
          ('Operator', '+', (-1, -1), None),
          ('Number', '1', (-1, -1), None)])
    assert lam_sub(None, n) == Node(type='Expression', children=[
        Leaf(type='Name', value='foo', context=(-1, -1)),
        Leaf(type='Operator', value='+', context=(-1, -1)),
        Leaf(type='Number', value='1', context=(-1, -1))], context=(1, 1))

# Generated at 2022-06-21 10:10:21.953640
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("bad input", token.NAME, "name", (1, 0))
    except ParseError as pe:
        assert str(pe) == (
            "bad input: type=258, value='name', " "context=(1, 0)"
        ), str(pe)
    else:
        assert 0, "didn't raise exception"


# Generated at 2022-06-21 10:10:27.083103
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import driver
    driver._setup_grammar(grammar.grammar)
    g = grammar.Grammar(grammar.grammar, grammar.syms, grammar.symbol2number)
    p = Parser(g)
    p.setup()

# Generated at 2022-06-21 10:10:35.763284
# Unit test for method setup of class Parser
def test_Parser_setup():
    from .driver import Driver
    from . import grammar, token
    d = Driver(grammar, token)
    # Test default start symbol
    p = d.create_parser()
    p.setup()
    assert p.stack == [(([[(1, 0)], [(0, 0)]], {1: 0}), 0, (256, None, None, []))]
    # Test alternative start symbol
    p.setup(257)
    assert p.stack == [(([[(2, 0)], [(0, 0)]], {1: 0}), 0, (257, None, None, []))]



# Generated at 2022-06-21 10:10:41.105500
# Unit test for method push of class Parser
def test_Parser_push():
    class TestGrammar(Grammar):
        start = 0
        dfas = {0: ([[(0, 1), (1, 2)], [(1, 2), (0, 3)]], {0: 0, 1: 1, 2: 0, 3: 1}),
                1: ([[(0, 1), (1, 2)]], {0: 0, 1: 0, 2: 1}),
                2: ([[(0, 1), (1, 2)]], {0: 0, 1: 0, 2: 1})
               }

    def lam_sub(grammar: Grammar, node: RawNode) -> NL:
        return Node(type=node[0], children=node[-1])

    p = Parser(TestGrammar(), lam_sub)
    p.setup()

# Generated at 2022-06-21 10:10:45.367447
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", "type", "value", "context")
    except ParseError as error:
        assert error.msg == "msg"
        assert error.type == "type"
        assert error.value == "value"
        assert error.context == "context"

# Generated at 2022-06-21 10:10:49.075866
# Unit test for method setup of class Parser
def test_Parser_setup():
    def f():
        var = Parser()
        var.setup()
    ok = False
    try:
        f()
    except AttributeError:
        ok = True
    assert ok


# Generated at 2022-06-21 10:10:59.253496
# Unit test for method push of class Parser
def test_Parser_push():
    import unittest
    import sys
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pgen2 import token as python_tokens
    from blib2to3.pgen2 import driver
    from . import parsetok

    def get_indentation():
        return None

    def set_indentation(value, delta):
        pass

    class Dummy:
        pass

    class TestParser(unittest.TestCase):
        def test_issue_3005(self):
            parser = Parser(driver.load_grammar("Python.g4"))
            tokengen = parsetok.generate_tokens("def f(x): return x")
            tokens = list(tokengen)


# Generated at 2022-06-21 10:11:08.331676
# Unit test for method push of class Parser
def test_Parser_push():
    import re
    import blib2to3.pgen2.grammar as grammar
    from blib2to3.pgen2 import token
    import sys

    def convert_method(g, n):
        if n[0] == token.NAME:
            return Leaf(n[0], n[1])
        else:
            return Node(n[0], n[3])

    if len(sys.argv) == 1:
        sys.exit()

    filename = sys.argv[1]

    f = open(filename, "rb")
    bytes = f.read()
    f.close()
    f = open(filename, "rt", encoding="UTF-8")
    data = f.read()
    f.close()

    g = grammar.grammar_from_file(filename)
    p = grammar.Parser

# Generated at 2022-06-21 10:11:13.646061
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser("")
    p.used_names = set()
    p.stack = [(("dfa", "state", "node"), 0, "node")]
    p.push("type", "newdfa", 0, 0)

    print("Done!")



# Generated at 2022-06-21 10:11:24.784643
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, driver

    # Get a grammar instance
    folder = "blib2to3/pgen2"
    fname = "Grammar.txt"
    input_file = driver.open_file(fname, folder=folder)
    g = grammar.Grammar(input_file)
    g.start = "file_input"
    g.prepare()

    # Get a parser instance
    p = Parser(g, None)

    # Test method classify
    assert p.classify(token.NAME, "bar", None) == 1
    assert p.classify(token.NAME, "if", None) == 4
    assert p.classify(token.LPAR, "(", None) == 6

# Generated at 2022-06-21 10:11:28.667487
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2.generate import generate_grammar, write_grammar
    gr = generate_grammar()
    write_grammar(gr, "Grammar.txt")
    parser = Parser(gr, lam_sub)
    assert parser.stack == []

# Generated at 2022-06-21 10:11:33.719729
# Unit test for constructor of class Parser
def test_Parser():
    from . import pgen
    from . import driver

    parser = pgen.pgen("Grammar.txt")
    parser.parse(driver.Driver("Grammar.txt", convert=lam_sub))
    p = Parser(parser.parsed, convert=lam_sub)


# Generated at 2022-06-21 10:11:44.470785
# Unit test for method pop of class Parser
def test_Parser_pop():
    class DummyGrammar(Grammar):

        class DummyDFAS(DFAS):
            states = [
                [
                    [0, 0],
                    [2, 3],
                    [3, 3],
                ],
                [
                    [0, 1],
                ],
                [
                    [0, 2],
                ],
                [
                    [1, 1],
                ],
            ]

            first = {
                2: {2},
                3: {3},
            }

        dfas = {
            0: DummyDFAS(),
            2: DummyDFAS(),
            3: DummyDFAS(),
        }

        labels = {
            0: (1, None),
            1: (2, None),
            2: (3, None),
        }


# Generated at 2022-06-21 10:11:46.786995
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    f = p.convert



# Generated at 2022-06-21 10:11:50.327290
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar, pgen2

    grammar_file = pgen2.__path__[0] + "/Python.g"
    g = grammar.grammar(grammar_file)
    Parser(g)  # Just test that it's constructed

# Generated at 2022-06-21 10:12:02.418902
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .tokenize import generate_tokens, untokenize
    from . import grammar

    def print_as_tree(node):
        if isinstance(node, Leaf):
            print('Leaf', node.type, repr(node.value), node.context)
        else:
            print('Node', node.type, node.children, node.context)
            for childnode in node.children:
                print_as_tree(childnode)

    # Construct fake input
    input = []
    input.append(token.NAME)
    input.append('if')
    input.append(token.NAME)
    input.append('x')
    input.append(token.NAME)
    input.append('==')
    input.append(token.NAME)
    input.append('y')

# Generated at 2022-06-21 10:12:15.393719
# Unit test for function lam_sub
def test_lam_sub():
    gr = Grammar()
    # Dummy grammar for testing, with a single symbol and a single rule
    gr.symbol2number['a'] = 1
    gr.number2symbol[1] = 'a'
    gr.start = 1
    gr.dfas[1] = (
            [
                (
                    [(1, 1), (2, 2)],
                    [(2, 2)],
                ),
                (
                    [(0, 1)],
                    [(0, 2)],
                ),
                (
                    [(1, 2), (0, 2)],
                    [],
                ),
            ],
            set([1]),
    )
    # Grammar is:
    # a: b c ;
    # b: 'x' ;
    # c: 'y' | 'z' ;
    # The following is

# Generated at 2022-06-21 10:12:28.148218
# Unit test for method push of class Parser
def test_Parser_push():
    from pprint import pprint

    from . import grammar, tokenize_wrapper

    p = Parser(grammar)

    p.setup()
    for t in tokenize_wrapper.generate_tokens("a=4"):
        p.addtoken(*t)
    pprint(p.rootnode)

    p.setup()
    for t in tokenize_wrapper.generate_tokens("[a=4]"):
        p.addtoken(*t)
    pprint(p.rootnode)

    p.setup()
    for t in tokenize_wrapper.generate_tokens("(a=4)"):
        p.addtoken(*t)
    pprint(p.rootnode)

    p.setup()

# Generated at 2022-06-21 10:12:35.442060
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .pgen2 import generate_grammar

    _, grammar = generate_grammar()
    parse = Parser(grammar)
    parse.setup()

    # negative testing
    # type is not a token number and has no matching label
    type = 5
    value = "test"
    context = Context(start_pos=(0, 0))
    try:
        parse.classify(type, value, context)
        assert False
    except ParseError as e:
        assert e.msg == "bad token"
        assert e.type == type
        assert e.value == value
        assert e.context == context

    # positive testing
    # type is a token number
    type = token.NAME
    value = "test"
    context = Context(start_pos=(0, 0))

# Generated at 2022-06-21 10:12:54.819298
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    p = Parser(Grammar(token.tok_name, {}))
    p.setup()
    p.addtoken(token.NAME, "A", (1, 0))
    assert str(p.rootnode) == "A"

# Generated at 2022-06-21 10:13:06.819836
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pytest
    from io import StringIO
    from blib2to3.pgen2.tokenize import tokenize, untokenize

    def run_pop(input: str) -> None:
        from blib2to3.pgen2.parser import Parser
        from blib2to3.pgen2.grammar import Grammar

        g = Grammar()

        input2 = untokenize(list(tokenize(StringIO(input).readline)))
        p = Parser(g)
        p.setup()
        for type, value, begin, end, line in tokenize(StringIO(input).readline):
            if p.addtoken(type, value, (1, 0)):
                break

        assert p.rootnode.children == input2

    run_pop("int = f = a = 1")
   

# Generated at 2022-06-21 10:13:10.171284
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .tokenize import generate_tokens

    from . import grammar

    g = grammar.Grammar()
    g.parse_grammar(open(g.grammar_file))
    assert g.start == "file_input"
    parser = Parser(g)
    parser.setup()
    for type, value, start, end, line in generate_tokens(open("test.py")):
        parser.addtoken(type, value, start)

# Generated at 2022-06-21 10:13:13.973007
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.driver import Driver

    d = Driver()
    p = d.parser
    assert p.classify(token.NAME, "if", None) == 1
    assert p.classify(token.NAME, "foo", None) == 4
    assert p.classify(token.LPAR, "(", None) == 3

# Generated at 2022-06-21 10:13:15.812456
# Unit test for function lam_sub
def test_lam_sub():
    """Test the lam_sub function."""
    lam_sub({}, (42, "test", None, None))

# Generated at 2022-06-21 10:13:23.284975
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError("message", token.NUMBER, "42", None)
    assert p.type == token.NUMBER
    assert p.value == "42"
    assert str(p) == "message: type=token.NUMBER, value='42', context=None"
    assert p.context is None
    p = ParseError("message", token.NUMBER, "42", (1, 2))
    assert p.context == (1, 2)


# Tests for the Parser class

# Generated at 2022-06-21 10:13:27.978617
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2 import driver
    import os.path

    grammar = driver.load_packaged_grammar(os.path.dirname(os.path.dirname(__file__)))
    lam_sub(grammar, (1, None, None, [2, 3, 4]))

# Generated at 2022-06-21 10:13:36.688030
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    # First, create a grammar
    gr = grammar.Grammar()
    gr.add_nonterminal("atom", "1")
    gr.add_nonterminal("test", "2")

    # Then add a production
    gr.add_production(["atom", "test"], "1", "-")

    # The method makes a lot of implicit calls to the grammar; we add these calls
    # back in

    # Then create a parser
    pa = Parser(gr)

    # Check that parsing is incomplete without a call to setup()
    pa.shift(1, 1, 0, (1, 0))
    pa.shift(1, 1, 0, (1, 0))

    # Begin parsing
    pa.setup(1)
    pa.shift(1, 1, 0, (1, 0))
   

# Generated at 2022-06-21 10:13:41.110211
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test", 1, "one", None)
    except ParseError as e:
        assert e.msg == "test"
        assert e.type == 1
        assert e.value == "one"
        assert e.context == None



# Generated at 2022-06-21 10:13:53.659031
# Unit test for method setup of class Parser
def test_Parser_setup():
    import blib2to3.pgen2.parse as parse
    import blib2to3.pgen2.driver as driver
    from . import token
    from . import grammar
    from . import parse
    from . import driver
    from . import token
    from os import path
    from blib2to3.pgen2.parse import Parser
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.token import Token
    from blib2to3.pytree import Leaf, Node
    root_folder: str = path.realpath(path.dirname(__file__))
    grammars_folder: str = path.join(root_folder, '..', 'grammars')
   

# Generated at 2022-06-21 10:14:11.658669
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Unit test for Parser.addtoken"""
    import subprocess

    # Build the parser
    subprocess.call(["python", "pgen2/driver.py", "Python.asdl"], shell=True)
    subprocess.call(["python", "pgen2/pgen.py", "-l", "Python.asdl"], shell=True)
    from pgen2.driver import load_grammar

    grammar = load_grammar("Python")

    parser = Parser(grammar)
    parser.setup()
    tokengen = iter(
        [
            (token.NAME, "if"),
            (token.NEWLINE, "\n"),
            (token.ENDMARKER, ""),
        ]
    )

# Generated at 2022-06-21 10:14:20.852975
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from . import driver
    import pytest
    from collections import namedtuple

    # Parse a simple expression
    g = grammar.Grammar()
    g.parse_gr(Text("""\
    expr: {expr} expr '+' term
        | {term} term
    term: {'term'} 'x'
    """))
    p = Parser(g, lam_sub)
    p.setup()
    tokens = g.tokenize(Text("x + x"))
    for t in tokens:
        if p.addtoken(*t):
            break
    tree = p.rootnode
    # Check the results
    assert type(tree) is Leaf
    assert tree.value == Text("expr")
    assert len(tree.children) == 2
    assert type(tree.children[0])

# Generated at 2022-06-21 10:14:32.272800
# Unit test for method push of class Parser
def test_Parser_push():
    from . import python_grammar
    from .tokenize import generate_tokens

    g = python_grammar
    p = Parser(g)
    p.setup()
    # Push a nonterminal
    p.push(g.symbol2number['print_stmt'], g.dfas[g.symbol2number['print_stmt']],
            0, None)
    print(p.stack[1])
    # Push a token and pop the symbol
    p.addtoken(token.NAME, 'print', (1,0))
    p.pop()
    print(p.stack[0])
    # Now try to push a token on a leaf
    from .tokenize import Untokenizer
    u = Untokenizer()
    u.source = '   print 1'

# Generated at 2022-06-21 10:14:37.448252
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("message", token.NAME, "name", (0, 0))
    except ParseError as err:
        assert err.msg == "message"
        assert err.type == token.NAME
        assert err.value == "name"
        assert err.context == (0, 0)
    else:
        raise AssertionError("failed to raise ParseError")


# Generated at 2022-06-21 10:14:38.550474
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    pass


# Generated at 2022-06-21 10:14:46.403861
# Unit test for constructor of class ParseError
def test_ParseError():
    # The usual case
    exc = ParseError("msg", 5, "val", (1, 2))
    assert exc.msg == "msg"
    assert exc.type == 5
    assert exc.value == "val"
    assert exc.context == (1, 2)
    # The obscure case
    exc = ParseError("msg", None, None, None)
    assert exc.msg == "msg"
    assert exc.type is None
    assert exc.value is None
    assert exc.context is None

# Generated at 2022-06-21 10:14:53.759088
# Unit test for method push of class Parser
def test_Parser_push():
    state = 0
    dfa = [
        [  # state 0
            (1, 1),
            (1, 2),
            (1, 3),
        ],
        [  # state 1
            (1, 2),
            (1, 3),
        ],
        [  # state 2
            (1, 2),
        ],
        None,  # state 3: accept state
    ]
    newdfa = ([], {})
    context = None
    p = Parser(None)
    p.stack = [(dfa, state, (0, None, None, []))]
    p.push(1, newdfa, 0, context)
    expected = [(dfa, state, (0, None, None, [])), (newdfa, 0, (1, None, None, []))]
    assert p

# Generated at 2022-06-21 10:14:54.851263
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(Grammar())

# Generated at 2022-06-21 10:14:57.033436
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(grammar.grammar)
    p.setup()
    p.setup(grammar.sym.SEQUENCE)


# Generated at 2022-06-21 10:15:01.438534
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    # Create a parser
    p = driver.make_parser(True)
    # addtoken() requires a token type, token value, and context
    p.addtoken(token.INDENT, "    ", driver.make_context("\n", (1, 1), (1, 5)))
    assert p.stack[-1][-1][-1][-1][0] == token.INDENT



# Generated at 2022-06-21 10:15:11.331107
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser = Parser(Grammar())
    parser.setup()
    parser.stack.append((None, None, (1, 2, 3, 4)))
    parser.pop()
    assert parser.rootnode[:-1] == (1, 2, 3)

# Generated at 2022-06-21 10:15:18.498660
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError('msg', 'type', 'value', 'context')
    assert err.msg == 'msg'
    assert err.type == 'type'
    assert err.value == 'value'
    assert err.context == 'context'
    try:
        raise ParseError('msg', 'type', 'value', 'context')
    except ParseError as e:
        assert str(e) == "msg: type='type', value='value', context='context'"

# Generated at 2022-06-21 10:15:26.607545
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("test message", token.PLUS, "+", Context(1, 2))
    assert isinstance(pe.msg, str)
    assert pe.type == token.PLUS
    assert pe.value == "+"
    assert pe.context.line == 1
    assert pe.context.column == 2
    assert str(pe) == "test message: type=43, value='+', context=(1, 2)"

# Generated at 2022-06-21 10:15:35.197257
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import parser as ll_parser
    from . import pickle as ll_pickle

    p = ll_parser.Parser(ll_pickle.grammar, ll_pickle.convert)
    p.setup()
    p.shift(token.NAME, 'x', 1, None)
    p.push(1, (1, 1), 0, None)
    p.shift(token.NAME, 'y', 1, None)
    p.pop()
    p.pop()
    assert p.rootnode
    assert len(p.rootnode.children) == 2
    assert p.rootnode.children[0].value == 'x'
    assert p.rootnode.children[1].value == 'y'


# Generated at 2022-06-21 10:15:38.375192
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", 1, "value", None)
    except ParseError as e:
        pass
    else:
        raise Exception("Did not raise")

# Generated at 2022-06-21 10:15:49.133815
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import token
    from . import grammar
    from . import symbol as sym
    p = Parser(grammar)
    p.setup()
    assert (None, None, None, []) == p.stack[-1][2]
    p.shift(token.NAME, "if", 0, (1, 4))
    assert (token.NAME, "if", (1, 4), []) == p.stack[-1][2]
    p.shift(token.NAME, "else", 0, (1, 8))
    assert (token.NAME, "if", (1, 4), [(token.NAME, "else", (1, 8), [])]) == p.stack[-1][2]


# Generated at 2022-06-21 10:15:55.898791
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", "type", "value", "context")
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == "type"
        assert e.value == "value"
        assert e.context == "context"
        # Test that str() doesn't raise an exception
        try:
            str(e)
        except Exception:
            assert False, "str(ParseError('msg', 'type', 'value', 'context')) failed"

# Generated at 2022-06-21 10:16:03.701729
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import pygram
    from .tokenize import detect_encoding

    grammar = pygram.python_grammar
    p = Parser(grammar)
    p.setup()
    s = "import re"
    encoding = "utf-8"
    detect_encoding(s)
    p.addtoken(token.ENCODING, encoding, None)
    p.addtoken(token.NEWLINE, "\n", None)
    for type, value, context in tokenize.tokenize(StringIO(s).readline):
        p.addtoken(type, value, context)

# Generated at 2022-06-21 10:16:15.284449
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, token
    g = grammar.Grammar()
    g.add_nonterminal("file_input", [("stmt", 1, None)])
    g.start = "file_input"
    g.dfas[token.NAME] = ([], {0: {1: [(1, 0)]}})
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", Context(1))
    p.addtoken(token.NEWLINE, "\n", Context(1))
    assert p.rootnode.children == ["foo"]

##def test_Parser_addtoken_add():
##    from . import grammar, token
##    g = grammar.Grammar()
##    g.add_nonterminal("add", [("add", 2, "+"), ("

# Generated at 2022-06-21 10:16:24.072755
# Unit test for method shift of class Parser
def test_Parser_shift():
    class TestGrammar(Grammar):
        pass
    test_grammar = TestGrammar()
    p = Parser(test_grammar)
    p.stack = [(test_grammar.dfas[test_grammar.start], 0, (test_grammar.start, None, None, []))]
    p.shift(token.NAME, "TestValue", 1, (1,1))
    assert p.stack == [(test_grammar.dfas[test_grammar.start], 1, (test_grammar.start, None, None, [Node(type=token.NAME, children=[Leaf(type=token.NAME, value="TestValue", context=(1,1))], context=(1,1))]))]


# Generated at 2022-06-21 10:16:48.740489
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Test method shift of class Parser"""
    import sys
    import filecmp
    import shutil

    # Create a Parser instance
    from .parsers import Grammar, Parser, tokenize
    from .ast import dump
    grammar = Grammar("Grammar/Grammar")
    parser = Parser(grammar)
    parser.setup()

    # Get a token sequence
    string = """\
ftest 1.01
#
"File for testing"

1.0

a
b
c

1
2
4
8

"""
    tokens = tokenize(string)

    # Tokenize the string
    for t, v in tokens:
        assert parser.addtoken(t, v, None)

    # Dump the abstract syntax tree
    tree = dump(parser.rootnode)

    #

# Generated at 2022-06-21 10:16:51.173002
# Unit test for constructor of class Parser
def test_Parser():
    grammar = Grammar()
    parser = Parser(grammar)
    assert parser.grammar == grammar
    assert parser.convert == lam_sub

# Generated at 2022-06-21 10:16:59.760983
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """This unit test checks the method Parser.addtoken().
    In particular, it checks the following scenario:
    There is no transition possible in the current state."""

    # Our dummy grammar
    token_map = {
        token.NAME: 256,
        1: 257,
        2: 258,
        3: 259,
        4: 260,
        5: 261,
        6: 262,
        7: 263,
        8: 264,
        9: 265,
        10: 266,
    }

    def token_types():
        for key in token_map:
            yield token_map[key]

    grammar = Grammar(token_map, token_types, {}, {})
    # Dummy parser
    parser = Parser(grammar)
    # Our starting symbol
    starting_symbol = 256
    #

# Generated at 2022-06-21 10:17:10.015260
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Unit test for method addtoken of class Parser."""
    import unittest
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.driver import Driver

    # See unit test for method tokenize of class Driver
    class MyDriver(Driver):
        def __init__(self, grammar):
            Driver.__init__(self, grammar)
            self.line = 0
            self.column = 0

        def tokenize(self, input):
            self.line += 1
            self.column += 1
            return self.grammar.tokenize(input)

    class TestParser(unittest.TestCase):
        def assertToken(self, parser, type, value, context):
            self.assertFalse(parser.addtoken(type, value, context))


# Generated at 2022-06-21 10:17:13.886529
# Unit test for method pop of class Parser
def test_Parser_pop():
    c = Parser(None)
    assert c.stack == []
    c.pop()  # no exception
    c.stack = [(1, 2, 3)]
    c.pop()  # no exception



# Generated at 2022-06-21 10:17:16.512450
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    p = Parser(grammar.Grammar())
    p.setup()
    p.pop()

# Generated at 2022-06-21 10:17:22.073024
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(Grammar(None))
    r = [[(0, 0)]]
    grammar = Grammar(r)
    p = Parser(grammar)
    p.push(0, None, 0, None)
    assert p.stack == [(None, 0, (0, None, None, [])), None]



# Generated at 2022-06-21 10:17:30.698426
# Unit test for constructor of class Parser
def test_Parser():
    class Foo:
        pass

    # Check mandatory arguments
    try:
        Parser()
    except TypeError:
        pass
    else:
        raise AssertionError("expected TypeError")

    # Check two required arguments
    try:
        Parser(Foo())
    except TypeError:
        pass
    else:
        raise AssertionError("expected TypeError")

    # Check two required arguments
    try:
        Parser(Foo(), Foo())
    except TypeError:
        pass
    else:
        raise AssertionError("expected TypeError")

    # Check argument types
    try:
        Parser(1, 2, 3, 4)
    except TypeError:
        pass
    else:
        raise AssertionError("expected TypeError")


# Generated at 2022-06-21 10:17:42.992050
# Unit test for method setup of class Parser
def test_Parser_setup():
    import pgen2.pgen
    from . import driver

    def _test(p):
        assert p.rootnode is None
        assert p.stack == [(p.grammar.dfas[start], 0, (start, None, None, []))]

    p = Parser(pgen2.pgen.expr_grammar)
    for start in ["expr", "xor_expr", "and_expr"]:
        p.setup(start)
        _test(p)
        p.setup()
        _test(p)

    p = Parser(pgen2.pgen.expr_grammar)
    p.setup()
    assert p.stack == [(p.grammar.dfas[p.grammar.start], 0, (p.grammar.start, None, None, []))]

# Generated at 2022-06-21 10:17:45.207092
# Unit test for function lam_sub
def test_lam_sub():
    node = (1, None, None, [])
    assert lam_sub(Grammar(), node) == Node(type=1, children=[])

# Generated at 2022-06-21 10:18:16.902939
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from .driver import Driver
    d = Driver()
    d.build()
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "print", Context(0, 0, 0))
    assert isinstance(p.rootnode, Leaf)

# Generated at 2022-06-21 10:18:28.605917
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .driver import Driver
    import pytest
    from blib2to3.pgen2 import tokenize

    d = Driver()

    # No function to convert from RawNode to Node.
    parser = Parser(d.grammar)
    parser.setup()
    iterator = tokenize.StringInput("a b")
    for type, value, start, end, line in iterator:
        parser.addtoken(type, value, (start, end))
    parser.pop()
    assert parser.rootnode.type == 258
    assert parser.rootnode.children == [
        Leaf(type=3, value="a", context=(1, 0), parent=parser.rootnode),
        Leaf(type=3, value="b", context=(1, 2), parent=parser.rootnode),
    ]
    assert parser.rootnode.used_names

# Generated at 2022-06-21 10:18:30.736761
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar()
    lam_sub(grammar, (1, "value", (2, 3), None))

# Generated at 2022-06-21 10:18:34.517360
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = Grammar()
    p = Parser(grammar)
    p.push(token.NAME, grammar.dfas[token.NAME], 0, None)

# Generated at 2022-06-21 10:18:43.322010
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    # Some names in the grammar
    for name in ["expr", "term", "power"]:
        # Dump the label for this name
        assert isinstance(name, str)
        print("%s: %d" % (name, grammar.dfas[grammar.symbol2number[name]][1][0]))

    # Some tokens in the grammar, this time with the tokenizer
    from . import driver

    for token in ["NAME", "COLONEQUAL", "NOTEQUAL", "EQUAL"]:
        # Dump the label for this token
        assert isinstance(token, str)
        print("%s: %d" % (token, driver.dfas[grammar.labels[driver.tok_name[token]]][1][0]))



# Generated at 2022-06-21 10:18:51.435834
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    dfa = [[(0, 1), (1, 2)], [(0, 2), (2, 3), (1, 4)],
           [(0, 3), (3, 4), (1, 1)], [(1, 1)], [(0, 1), (1, 5)]]
    expected_dfa: DFA = dfa
    dfas = ([expected_dfa, [[(0, 1), (1, 2)]]], {0: 0, 1: 0, 2: 1, 3: 1, 4: 0, 5: 1})
    expected_dfas: DFAS = dfas

# Generated at 2022-06-21 10:18:56.911765
# Unit test for method push of class Parser
def test_Parser_push():
    import pickle

    g = pickle.load(open("../Grammar/Grammar.pkl", "rb"))
    p = Parser(g)
    assert p.stack == []

    p.push(52, g.dfas[52], 0, None)
    assert p.stack == [(g.dfas[52], 0, (52, None, None, []))]

# Generated at 2022-06-21 10:19:03.804105
# Unit test for function lam_sub
def test_lam_sub():
    class FakeGrammar:
        def __init__(self):
            self.symbol2label = [None] * 256
    g = FakeGrammar()
    n = ('SYMBOL', None, ('foo', 'bar'), ('CHILD1', None, ('mid1', 'mid2'), None),
         ('CHILD2', None, ('mid1', 'mid2'), None))
    r = lam_sub(g, n)
    assert r.type == 'SYMBOL'
    assert r.children == ['CHILD1', 'CHILD2']
    assert r.prefix == "foo\nbar"

# Generated at 2022-06-21 10:19:12.462778
# Unit test for method setup of class Parser
def test_Parser_setup():
    import io
    import unittest
    import blib2to3.pgen2.parse as parse
    import blib2to3.pgen2.driver as driver

    class FakeGrammar:
        def __init__(self):
            self.dfas = {'key': (1, 2)}

        start = 'start'

    class LoggingConvert:
        def __init__(self):
            self.call_list = []

        def __call__(self, grammar, node):
            self.call_list.append(node)
            return None

    def read_grammar(stream):
        p = driver.load_grammar(stream)
        p.parse()
        return p.pgen

    class test_setup(unittest.TestCase):
        def test_convert(self):
            convert

# Generated at 2022-06-21 10:19:19.471025
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import token

    _grammar = grammar.grammar

    def check_classify_Gt(p):
        assert p.classify(token.GREATER, '>', None) == _grammar.labels[p.grammar.keywords['>']]

    def check_classify_Name(p):
        assert p.classify(token.NAME, 'a', None) == _grammar.labels[p.grammar.keywords['a']]

    p = Parser(grammar.grammar, None)
    p.setup()

    check_classify_Gt(p)
    check_classify_Name(p)

# Unit tests for top level functions