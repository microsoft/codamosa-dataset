

# Generated at 2022-06-21 10:10:20.524870
# Unit test for constructor of class ParseError
def test_ParseError():
    context = (1, 4)
    p = ParseError('syntax error', token.ENDMARKER, 'x', context)
    assert p.msg == 'syntax error'
    assert p.type == token.ENDMARKER
    assert p.value == 'x'
    assert p.context == context



# Generated at 2022-06-21 10:10:24.194280
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("test", 0, None, None)
    assert str(e) == "test: type=0, value=None, context=None"


if __name__ == "__main__":
    import sys

    sys.exit("Module is not executable")

# Generated at 2022-06-21 10:10:35.532750
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser = Parser(Grammar(open('/Users/david/dev/python/cpython/Lib/2to3/Grammar.txt')))

# Generated at 2022-06-21 10:10:42.973597
# Unit test for method pop of class Parser
def test_Parser_pop():
    class X:
        def __init__(self):
            self.popdfa = None
            self.popstate = None
            self.popnode = None
            self.newnode = None
            self.stack = None
            self.rootnode = None
            self.used_names = None

        def pop(self):
            self.popdfa, self.popstate, self.popnode = self.stack.pop()
            self.newnode = self.convert(self.grammar, self.popnode)
            if self.newnode is not None:
                if self.stack:
                    dfa, state, node = self.stack[-1]
                    assert node[-1] is not None
                    node[-1].append(self.newnode)
                else:
                    self.rootnode = self.newnode
                   

# Generated at 2022-06-21 10:10:44.572094
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(Grammar)



# Generated at 2022-06-21 10:10:50.536821
# Unit test for constructor of class Parser
def test_Parser():
    from . import parse
    from . import driver

    p = Parser(parse.grammar)
    p.setup()
    t = driver.tokenize_file("pgen.out")
    for typ, value, context in t:
        p.addtoken(typ, value, context)
    driver.print_tree(p.rootnode)

# Generated at 2022-06-21 10:10:59.928011
# Unit test for function lam_sub
def test_lam_sub():
    """
    >>> lam_sub(None, (1, None, None, [2]))
    [1, None, None, [2, None, None, []]]
    >>> lam_sub(None, (1, None, None, [(2, 'x', None, [])]))
    [1, None, None, [[2, 'x', None, []]]]
    """
    print(lam_sub(None, (1, None, None, [2])))
    print(lam_sub(None, (1, None, None, [(2, "x", None, [])])))


if __name__ == "__main__":
    import doctest
    import sys

    if sys.argv[1:2] == ["-v"]:
        args = sys.argv[2:]
        verbose = True


# Generated at 2022-06-21 10:11:04.978766
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar/Grammar")
    p = Parser(grammar)
    p.setup(grammar.start)
    assert p.stack == [(
        ([[(4, 1)], [(4, 1)], [(4, 1)], [(4, 1), (0, 4)], [(0, 5)]],
        {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5}),
        0,
        (256, None, None, [])
        )]
    p.setup(1) # 'file_input'

# Generated at 2022-06-21 10:11:07.760326
# Unit test for method classify of class Parser
def test_Parser_classify():
    import sys
    from blib2to3.pgen2 import (
        tokenize,
        token,
        driver,
    )


# Generated at 2022-06-21 10:11:18.470554
# Unit test for method push of class Parser
def test_Parser_push():
    import unittest
    import blib2to3.pgen2.grammar

    class TestParser(unittest.TestCase):
        def test_parser(self):
            def convert(grammar: blib2to3.pgen2.grammar.Grammar, node: RawNode) -> None:
                if node[0] == grammar.symbol2number["test_symbol"]:
                    self.assertTrue(node[1] == None)
                    self.assertTrue(node[2] == None)
                    self.assertTrue(node[3] == [])
                elif node[0] == grammar.symbol2number["test_test"]:
                    self.assertTrue(node[1] == None)
                    self.assertTrue(node[2] == None)

# Generated at 2022-06-21 10:11:30.113829
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from .pygram import python_symbols
    from .pgen import token

    g = grammar.Grammar(symbols=python_symbols)
    p = Parser(grammar=g, convert=lam_sub)
    p.setup()
    p.addtoken(token.NAME, 'as', None)
    p.addtoken(token.NAME, 'class', None)
    assert p.rootnode.type == python_symbols.simple_stmt

# Generated at 2022-06-21 10:11:42.257238
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .token import tok_name

    class MockParser(Parser):
        def __init__(self, grammar):
            class MockConvert:
                def __init__(self, grammar, node):
                    pass
            super().__init__(grammar, convert=MockConvert.__init__)

    context = Context()
    token_dict = {}

    for type, value in token.tok_name.items():
        assert tok_name[type] == value
    for type, value in tok_name.items():
        token_dict[value] = type

    grammar = Grammar()
    grammar.tokens = {token.NEWLINE: 1, token.INDENT: 2, token.DEDENT: 3}
    grammar.keywords = {"def": 4, "if": 5, "else": 6}


# Generated at 2022-06-21 10:11:52.377775
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver

    def convert(grammar, node):
        return Leaf(node[0], value=node[1], context=node[2])

    d = driver.Driver(convert=convert)
    p = d.parser
    p.stack = [(p.grammar.dfas['_stmt'], 0, [None, None, None, None])]
    p.shift(1, 'A', 1, (1, 0))
    p.shift(2, 'B', 2, (1, 0))
    p.stack = [(p.grammar.dfas['_stmt'], 0, [None, None, None, []], None)]
    p.shift(2, 'B', 1, (1, 0))

# Generated at 2022-06-21 10:12:03.885145
# Unit test for method push of class Parser
def test_Parser_push():
    class TestGrammar(Grammar):
        pass

    g = TestGrammar()
    p = Parser(g)
    p.setup()
    p._Parser__push(13, g.dfas[2], 3, (1, 0))
    p._Parser__push(12, g.dfas[1], 0, (1, 0))
    p._Parser__push(12, g.dfas[1], 0, (1, 0))
    top = p.stack.pop()
    assert top[2][0] == 12
    assert top[2][-1] == []
    assert len(top[2]) == 4
    assert top[1] == 0
    assert top[0] == g.dfas[1]

    top = p.stack.pop()
    assert top[2][0] == 13

# Generated at 2022-06-21 10:12:16.298953
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Here we test the method classify of class Parser

    # Before going further, let us define a Parser class
    class _Parser(Parser):
        def __init__(self, grammar, convert=None):
            self.grammar = grammar
            self.convert = convert or lam_sub

        # The method tokenize will transform a string into a list of tokens

        def tokenize(self, text):
            return [(type, text) for type, text, _, _ in tokenize.generate_tokens(text)]

    # This test is associated with the following input file:
    # class DummyClass():
    #     def method2(self):
    #         '''This is a method'''
    #         self.method1()

    from . import token, tokenize

    # Get all the information from the file

# Generated at 2022-06-21 10:12:21.353688
# Unit test for method classify of class Parser
def test_Parser_classify():
    # The only way to get a Parser instance is to call the constructor
    p = Parser(Grammar())
    # Method classify of class Parser is defined in the class definition
    assert Parser.classify.__func__ is Parser.__dict__["classify"]

# Generated at 2022-06-21 10:12:32.185455
# Unit test for method shift of class Parser
def test_Parser_shift():
    t = token

    grammar = Grammar()

    grammar.start = 257

# Generated at 2022-06-21 10:12:42.328137
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest

    class TestParser_classify(unittest.TestCase):
        def setUp(self):
            self.grammar = Grammar()
            self.parser = Parser(self.grammar)
            self.parser.setup()

        def test_classify_when_tokens_is_None(self):
            self.grammar.tokens = None
            self.assertEqual(self.parser.classify(token.NAME, "", (1, 1)), 0)

        def test_classify_when_tokens_is_not_None(self):
            self.grammar.tokens = {token.NAME: "a"}
            self.assertEqual(self.parser.classify(token.NAME, "", (1, 1)), "a")


# Generated at 2022-06-21 10:12:45.531781
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("msg", 0, "value", "context")
    assert repr(err) == "ParseError('msg: type=0, value=value, context=context')"
    assert err.msg == "msg"
    assert err.type == 0
    assert err.value == "value"
    assert err.context == "context"

# Generated at 2022-06-21 10:12:50.285214
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("msg", 1, "abc", None)
    assert e.msg == "msg"
    assert e.type == 1
    assert e.value == "abc"
    assert e.context == None
    x = str(e)
    assert x == "msg: type=1, value='abc', context=None"

# Generated at 2022-06-21 10:13:05.657048
# Unit test for method setup of class Parser
def test_Parser_setup():
    # Not much to test, really. We just check that initial values are
    # set correctly.
    p = Parser(Grammar())
    p.setup()
    assert p.stack == [([[(0, 0)], {0: [(0, 0)]}], 0, (0, None, None, []))]
    assert p.rootnode is None

# Generated at 2022-06-21 10:13:07.640989
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar()
    lam_sub(grammar, (0, None, None, []))

# Generated at 2022-06-21 10:13:12.509802
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("foo", 1, "bar", (2, 3))
    except ParseError as e:
        assert e.msg == "foo"
        assert e.type == 1
        assert e.value == "bar"
        assert e.context == (2, 3)
    else:
        assert False, "expected to raise"


# Unit tests for class ParseError

# Generated at 2022-06-21 10:13:19.606279
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import pgen2
    import StringIO

    # The "setup" method only needs to run without an error
    # (It's hard to test but we can use a code coverage tool)
    # See also test_parser_driver()
    txt = """if a:
    pass
"""
    f = StringIO.StringIO(txt)
    grammar = pgen2.load_grammar("Grammar.txt")
    parser = Parser(grammar)
    parser.setup()

# Generated at 2022-06-21 10:13:24.434438
# Unit test for method shift of class Parser
def test_Parser_shift():
    class X(object):
        pass
    class Grammar:
       pass
    p = Parser(Grammar())
    p.stack=[(X(), 0, [])]
    p.shift(1, 'test', 1, 'test')
    assert p.stack == [(X(), 1, [])]



# Generated at 2022-06-21 10:13:34.300101
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    import blib2to3.pgen2.driver
    import blib2to3.pgen2.parse

    class _TestCase(unittest.TestCase):

        def check(self, text: Text) -> None:
            driver = blib2to3.pgen2.driver.Driver(
                blib2to3.pgen2.parse.my_grammar, blib2to3.pgen2.parse.CONVERTERS
            )
            tokens: Sequence[Tuple[int, Any, Any]] = []
            for t in driver.tokenize(text, 't.txt'):
                tokens.append((t.type, t.string, t.context))
            p = Parser(blib2to3.pgen2.parse.my_grammar)
            p.setup()

# Generated at 2022-06-21 10:13:39.361231
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("No", 1, "one", (1, 1))
    except ParseError as error:
        assert error.msg == "No"
        assert error.type == 1
        assert error.value == "one"
        assert error.context == (1, 1)
    else:
        raise AssertionError

# Generated at 2022-06-21 10:13:52.137985
# Unit test for method pop of class Parser
def test_Parser_pop():
    class _grammar:
        start = 257

    class _token:
        NAME = 258
        NUMBER = 259

    class _Grammar(object):
        def __init__(self, gram):
            self.start = gram.start
            self.tokens = {_token.NAME: 258, _token.NUMBER: 259}
            self.labels = [(257, 257), (258, 258), (259, 259)]
            self.keywords = {}

# Generated at 2022-06-21 10:14:00.912807
# Unit test for method classify of class Parser
def test_Parser_classify():
    g1 = Grammar()
    g1.keywords["if"] = 2
    g1.keywords["else"] = 3
    g1.keywords["return"] = 4
    g1.keywords["break"] = 5
    p1 = Parser(g1)
    # Check that the reserved words are recognized
    assert p1.classify(token.NAME, "if", None) == 2
    assert p1.classify(token.NAME, "else", None) == 3
    assert p1.classify(token.NAME, "return", None) == 4
    assert p1.classify(token.NAME, "break", None) == 5
    # Check that plain names go through
    assert p1.classify(token.NAME, "foo", None) == 1


# Tests for class Parser

# Generated at 2022-06-21 10:14:12.555432
# Unit test for method push of class Parser
def test_Parser_push():
    # Generated by blib2to3.pgen2.driver
    import blib2to3.pgen2.parse

    def p_empty(p):
        "empty :"

    def p_error(p):
        if p:
            print("Syntax error at '%s'" % p.value)
        else:
            print("Syntax error at EOF")

    grammar = blib2to3.pgen2.parse.pgen(p_empty, p_error)
    parser = Parser(grammar, lam_sub)
    parser.setup()
    parser.addtoken(token.STARTMARKER, None, Context(1, 0, ''))
    parser.addtoken(token.NEWLINE, None, Context(2, 0, ''))

# Generated at 2022-06-21 10:14:36.792005
# Unit test for method shift of class Parser
def test_Parser_shift():
    # One single token
    p = Parser(Grammar(grammar.grammar, grammar.symbol2number))

    p.setup()
    assert p.addtoken(tokenize.NAME, "a", (1, 0))

    # Multiple tokens
    p = Parser(Grammar(grammar.grammar, grammar.symbol2number))
    p.setup()
    assert p.addtoken(tokenize.NAME, "a", (1, 0))
    assert p.addtoken(tokenize.NAME, "b", (1, 1))
    assert p.addtoken(tokenize.NAME, "c", (1, 2))
    assert p.addtoken(tokenize.NAME, "d", (1, 3))
    assert p.addtoken(tokenize.NAME, "e", (1, 4))

# Generated at 2022-06-21 10:14:45.435578
# Unit test for constructor of class Parser
def test_Parser():
    import sys
    import blib2to3.pgen2.grammar as grammar

    class TestParser(Parser):
        def __init__(self) -> None:
            gr = grammar.grammar(grammar.grammar_tuple)
            Parser.__init__(self, gr)

    p = TestParser()
    p.setup()
    try:
        while True:
            if p.addtoken(token.NAME, "test", (1, 2)):
                break
    except ParseError:
        pass

if __name__ == "__main__":
    test_Parser()

# Generated at 2022-06-21 10:14:56.853576
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup("file_input")
    tokens = [
        (token.ENCODING, "utf-8", 0),
        (token.NEWLINE, "\n", 0),
        (token.NAME, "a", 0),
        (token.EQUAL, "=", 0),
        (token.NUMBER, "42", 0),
        (token.NEWLINE, "\n", 0),
    ]
    for type, value, context in tokens:
        if p.addtoken(type, value, context):
            break

# Generated at 2022-06-21 10:15:00.713536
# Unit test for method push of class Parser
def test_Parser_push():
    """Unit test for method push of class Parser"""
    node = (1, 2, 3, 4)
    p = Parser(1)
    p.push(5, 6, 7, 8)
    assert p.stack[-1] == (6, 7, node), \
           "Unexpected result from 'Parser.push'"


# Generated at 2022-06-21 10:15:04.057909
# Unit test for function lam_sub
def test_lam_sub():
    """Test the function lam_sub"""
    assert lam_sub(None, (1, 1, 1, None)) is None
    assert lam_sub(None, (1, 1, 1, [])) == Node(type=1, children=[])

# Generated at 2022-06-21 10:15:12.922800
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .driver import driver
    from .tokenizer import tokenize_str
    import unittest
    # Setup
    g = driver.parse_grammar()
    p = Parser(g)
    p.setup()
    tokens: Sequence[Tuple[int, Text, Context]] = list(tokenize_str("def foo():\n pass"))
    # Exercise
    while tokens:
        type, value, context = tokens.pop(0)
        p.addtoken(type, value, context)
    # Verify
    assert p.rootnode is not None
    # Cleanup - none necessary

# Generated at 2022-06-21 10:15:19.529733
# Unit test for method pop of class Parser
def test_Parser_pop():
    def _convert(grammar, node):
        return "pop"

    p = Parser(None, _convert)
    p.stack = [(None, 2, None), (None, 0, None)]
    p.pop()
    print(p.stack)
    print(p.rootnode)
    assert p.stack == [(None, 2, None)]
    assert p.rootnode == "pop"


# Generated at 2022-06-21 10:15:32.498745
# Unit test for method classify of class Parser
def test_Parser_classify():
    """tests the Parser.classify() method"""

    class FakeGrammar(object):
        """an object that pretends to be a grammar"""

        def __init__(self):
            # Maps from token number to label number
            self.tokens = {
                token.NEWLINE: 1,
                token.NAME: 2,
            }
            # Maps from token.NAME value to label
            self.keywords = {
                "class": 3,
            }
            self.labels = [
                (token.NEWLINE, None),
                (token.NAME, None),
                ("class", "class"),
            ]

    class ParserWithFakeGrammar(Parser):
        """it's a Parser, but uses a fake grammar"""


# Generated at 2022-06-21 10:15:43.383346
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import pkgutil
    import os

    import blib2to3.pgen2.pgen
    import blib2to3.pgen2.grammar

    dir = os.path.dirname(blib2to3.pgen2.pgen.__file__)
    for data in pkgutil.iter_modules([dir]):
        if data[1] == "pgen":
            data = (blib2to3.pgen2.pgen, "blib2to3/pgen2/pgen")
            break
    else:
        raise ImportError("no pgen module")
    sys_grammar = blib2to3.pgen2.grammar.Grammar(data[0].grammar)
    p = Parser(sys_grammar)
    p.setup()
    p.add

# Generated at 2022-06-21 10:15:51.048659
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(g.symbol2number["foo"], None, context=Context(line=0))
    assert p.rootnode is not None
    assert len(p.rootnode) == 1
    assert isinstance(p.rootnode[0], Leaf)
    assert p.rootnode[0].value == "foo"

# Generated at 2022-06-21 10:16:14.669488
# Unit test for constructor of class Parser
def test_Parser():
    oldp = Parser(Grammar())
    p = Parser(Grammar())
    assert p is not oldp

# Generated at 2022-06-21 10:16:24.178480
# Unit test for method shift of class Parser
def test_Parser_shift():
    import sys
    sys.path.insert(0, '../blib2to3/')
    import pygram
    from blib2to3.pgen2 import driver as pgendriver

    grammar = pygram.python_symbols
    p = Parser(grammar)
    p.setup()

    # Increase the chance of getting coverage on branches
    import random
    random.seed(0)

    # Token type and value
    NUM = 0
    NUM_value = 123
    CONST = 3
    CONST_value = 456

    NUM_raw_node = (NUM, NUM_value, None, None)
    CONST_raw_node = (CONST, CONST_value, None, None)

    # State and arc
    state = 0
    newstate = 1

# Generated at 2022-06-21 10:16:34.015334
# Unit test for constructor of class Parser
def test_Parser():
    # Constructor
    #   def __init__(self, grammar, convert = lam_sub):
    import tempfile
    import blib2to3.pgen2.driver

    # Get a grammar object
    fd, fn = tempfile.mkstemp(".py", "parser_")
    driver = blib2to3.pgen2.driver.Driver(fn, fd)
    g = driver.grammar
    driver.generate_grammar()
    p = Parser(g)
    # The grammar and convert instance variables must be initialized
    assert p.grammar is g
    assert p.convert is lam_sub
    # Call setup() to prepare for parsing
    p.setup()
    # Not ready for parsing yet (whitespace is not yet skipped)

# Generated at 2022-06-21 10:16:45.945893
# Unit test for method push of class Parser
def test_Parser_push():
    class TestNode(object):
        def __init__(self, tp, val, children, context):
            self.type = tp
            self.value = val
            self.children = children
            self.context = context

    class TestGrammar(object):
        def __init__(self, dfa=None, dfas=None):
            self.dfa = dfa
            self.dfas = dfas

    class TestParser(Parser):
        def __init__(self, grammar, convert=None):
            self.grammar = grammar
            self.convert = convert

    def test_convert(grammar, node):
        return TestNode(node[0], node[1], node[3], node[2])


# Generated at 2022-06-21 10:16:56.676610
# Unit test for constructor of class Parser
def test_Parser():

    from . import dfa
    from . import nfa
    from . import grammar
    from . import pgen
    import io
    import re

    def convert(grammar, node):
        type, value, context, children = node
        if value is None:
            return Node(type, children, context)
        else:
            return Leaf(type, value, context)

    # Create a small expression grammar as a unit test
    expgrammar = pgen.grammar()
    expgrammar.add_empty('block')
    expgrammar.add_terminal('NAME', ('foo', 'bar', 'spam'))
    expgrammar.add_sequence('block', ('NAME', 'block'))
    expgrammar.start = 'block'
    expgrammar.freeze()

    # Run a test sequence through the parser
   

# Generated at 2022-06-21 10:17:06.268129
# Unit test for constructor of class Parser
def test_Parser():
    def null_convert(grammar: Grammar, node: RawNode) -> Union[Node, Leaf]:
        assert node[-1] is not None
        return node

    from . import driver

    tok = token.tok_name

    g = driver.load_grammar("Grammar.txt")
    p = Parser(g, null_convert)

    # Test error cases:
    # No setup() call
    try:
        p.addtoken(tok.NUMBER, "3", (1, 0))
    except ParseError:
        pass
    else:
        raise AssertionError("no setup() call")

    # Bad token
    p.setup()

# Generated at 2022-06-21 10:17:16.076907
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Unit test for method Parser.shift()."""

    # Imports
    from . import driver, tokens

    # Select the parser
    p = Parser(driver.pgen.grammar, convert=driver.pgen.lam_sub)

    # Set up the parser
    p.setup(driver.pgen.start)

    # Tokenize the input string
    tokengen = tokens.generate_tokens(driver.pgen.grammar, "")

    # Add tokens until the parse is complete
    for type, value, context in tokengen:
        if p.addtoken(type, value, context):
            break

    # Check the result
    assert p.rootnode is not None



# Generated at 2022-06-21 10:17:27.376828
# Unit test for method push of class Parser
def test_Parser_push():
    class TestGrammar(Grammar):
        def __init__(self):
            self.start = 256
            self.grammar = '\n            expr: testlist trailer\n            | trailer trailer\n            | trailer\n            ;\n            trailer: \'(\' testlist \')\'\n            ;\n            '
            self.dfas = {256: ([[(2, 1), (1, 2)], [(1, 3)]], {2: 2, 3: 2}), 257: ([[(1, 1)]], {1: 1})}
            self.tokens = {40: 1, 41: 2, 40: 3, 41: 4}
            self.labels = [(2, 'testlist'), (3, 40), (1, 'expr'), (4, 'trailer')]


# Generated at 2022-06-21 10:17:39.030154
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    pgen = grammar.grammar()
    pgen.parse_grammar(open("Grammar/Grammar"))
    p = Parser(pgen, lam_sub)
    p.setup()
    l = Leaf(value="def", type=1, context=Context(previous_leaf=None))
    p._Parser__stack = [(0, 0, (None, None, None, [l])),
                        (0, 0, (None, None, None, [])),
                        (0, 0, (None, None, None, []))
                        ]
    assert p.rootnode is None
    p.pop()
    assert p.rootnode is not None
    assert p.rootnode[0] is None
    assert p.rootnode[3] == [l]

# Generated at 2022-06-21 10:17:46.919519
# Unit test for constructor of class ParseError
def test_ParseError():
    # This function used to be in 'test_parser', but since PyUnit
    # always does a 'compile' on every single test function, this
    # function was causing a spurious syntax error for not having the
    # module-level docstring.  Moving it here gets rid of the error.
    try:
        raise ParseError("msg", 1, 2, 3)
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == 1
        assert e.value == 2
        assert e.context == 3
    else:
        raise RuntimeError

# Generated at 2022-06-21 10:18:22.991310
# Unit test for method push of class Parser
def test_Parser_push():
    import pickle


# Generated at 2022-06-21 10:18:26.172844
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        # Exception strings can't be compared directly in 2.6
        raise ParseError("msg", 0, None, None)
    except ParseError:
        pass


# Generated at 2022-06-21 10:18:31.814724
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar as G
    from . import pygram
    g = G.Grammar(pygram.python_grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(5, "attest", (1, 0))

# Generated at 2022-06-21 10:18:35.963415
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test constructor of class ParseError."""
    err = ParseError("msg", 42, "value", Context(42, 0))
    assert str(err) == "msg: type=42, value='value', context=(42, 0)"


# Generated at 2022-06-21 10:18:41.594283
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", 1, "value", (1, 4))
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == 1
        assert e.value == "value"
        assert e.context == (1, 4)
        return
    assert False  # Shouldn't be reached

if __name__ == "__main__":
    test_ParseError()
    print("Unit tests completed")

# Generated at 2022-06-21 10:18:49.529158
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    import sys

    x = {'A': 1, 'B': 2, 'C': 3, 'D': 4}
    g = grammar.Grammar(x)
    p = Parser(g)

    class Results:
        def __init__(self):
            self.i = 0
        def __call__(self, g, node):
            self.i += 1
            return node

    res = Results()
    p.setup(1)
    p.convert = res

    p.shift('A', 'A', 0, None)
    assert res.i == 1

# Generated at 2022-06-21 10:18:59.970689
# Unit test for method setup of class Parser

# Generated at 2022-06-21 10:19:07.359029
# Unit test for method classify of class Parser
def test_Parser_classify():
    import t
    import blib2to3.pgen2.grammar as g
    parser = Parser(g.grammar, convert=t.convert)
    parser.setup()

    # Test: call with bad arguments
    try:
        parser.classify(token.NAME, 1, 2)
        assert False, "Should have raised a ParseError."
    except ParseError:
        pass

    # Test: call with good arguments
    assert parser.classify(token.NAME, 1, None), "Should return 1"

# Generated at 2022-06-21 10:19:16.537564
# Unit test for method classify of class Parser
def test_Parser_classify():
    p = Parser(Grammar())

    # Test with an empty keyword map
    p.grammar.keywords = {}

# Generated at 2022-06-21 10:19:21.580839
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = blib2to3.pgen2.pgen.Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(1, "foo", "bar")
    assert parser.rootnode == None
    assert parser.stack == []
