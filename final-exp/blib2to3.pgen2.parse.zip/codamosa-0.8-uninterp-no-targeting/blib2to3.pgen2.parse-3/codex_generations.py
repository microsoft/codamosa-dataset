

# Generated at 2022-06-21 10:10:20.680854
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from blib2to3.pgen2 import grammar, token
    g = grammar.Grammar()
    g.load()
    p = Parser(g)
    p.setup()
    driver.test_parser(p)

# Generated at 2022-06-21 10:10:33.251438
# Unit test for method pop of class Parser
def test_Parser_pop():
    class DummyGrammar(object):
        def __init__(self):
            self.labels = {
                0: (token.NAME, "NAME"),
                1: (token.NUMBER, "NUMBER"),
                2: (token.MINUS, "MINUS"),
                3: (256, "expression"),
            }
            self.dfas: Dict[int, DFAS] = {
                256: (
                    [
                        [(3, 1), (0, 2), (0, 3), (2, 4)],
                        [],
                        [(1, 5)],
                        [(1, 6)],
                        [(1, 7)],
                        [],
                        [],
                        [],
                    ],
                    {0: 4, 2: 4, 4: 4, 7: 4},
                )
            }
            self

# Generated at 2022-06-21 10:10:34.309965
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser()
    p.setup()

# Generated at 2022-06-21 10:10:41.365098
# Unit test for function lam_sub
def test_lam_sub():
    assert lam_sub(None, (1, "foo", None, None)) is None  # type: ignore
    node = lam_sub(None, (1, "foo", None, []))
    assert node.type == 1
    assert node.children == []
    assert node.value == "foo"
    node = lam_sub(None, (1, None, None, [1, 2, 3]))
    assert node.type == 1
    assert node.children == [1, 2, 3]
    assert node.value is None

# Generated at 2022-06-21 10:10:53.915365
# Unit test for function lam_sub
def test_lam_sub():
    from . import symbol
    from . import token

    v = dict((value, name) for name, value in vars(symbol).items()
             if name.isupper())
    v.update(dict((value, name) for name, value in vars(token).items()
                  if name.isupper()))
    v[token.ENDMARKER] = "<EOF>"

    def pprint(node: Union[Node, Leaf]) -> Text:
        if isinstance(node, Leaf):
            if node.type == token.ENDMARKER:
                return "<EOF>"
            return repr(node.value)
        elif node.type == symbol.file_input:
            return "".join(pprint(child) for child in node.children)
        else:
            rv = v[node.type]

# Generated at 2022-06-21 10:10:59.115309
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(Grammar())
    assert p.stack == []
    p.push(0, 10, 0, 0)
    assert p.stack == [(10, 0, (0, None, 0, []))]
    p.push(1, 11, 0, 0)
    assert p.stack == [(10, 0, (0, None, 0, [])), (11, 0, (1, None, 0, []))]
    assert p.rootnode is None

# Generated at 2022-06-21 10:11:04.495269
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class MockGrammar:
        def __init__(self):
            self.keywords = {
                "a": "a",
                "b": "b",
                "c": "c",
                "d": "d",
            }
            self.tokens = {"a": "a", "b": "b", "c": "c", "d": "d"}
            self.labels = ["a", "b", "c", "d"]

# Generated at 2022-06-21 10:11:09.628516
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = Grammar()
    parser = Parser(grammar)
    assert parser.classify(token.NAME, "NAME", None) == 0
    assert parser.classify(token.OP, "+", None) == 1
    print("Parser class test: OK")

if __name__ == '__main__':
    test_Parser_classify()

# Generated at 2022-06-21 10:11:19.377200
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Unit test for method pop of class Parser"""

    class MockConvert:
        """Mock class to emulate the convert method in Parser"""

        def __init__(self, parsed_value: Any) -> None:
            self.parsed_value = parsed_value

        def __call__(self, *args: Any) -> Any:
            return self.parsed_value

    class MockParser:
        """Mock class to emulate the Parser class to test method pop"""

        def __init__(
            self,
            last_converter_value: Any,
            last_node_value: Sequence[Any],
            stack_values: Sequence[Sequence[Any]],
        ) -> None:
            self.last_converter_value = last_converter_value

# Generated at 2022-06-21 10:11:30.383666
# Unit test for method push of class Parser

# Generated at 2022-06-21 10:11:39.238042
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2 import grammar

    g = grammar.grammar
    p = Parser(g)


# Generated at 2022-06-21 10:11:47.408354
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver
    from .grammar import Grammar

    # Create a parser
    g = Grammar()
    p = Parser(g)
    # Put the parser in the proper state
    p.setup(g.symbol2number["file_input"])
    # Check a couple of valid classifications
    i1 = p.classify(token.INDENT, "", driver.empty_context)
    assert i1 == g.symbol2number["INDENT"]
    i2 = p.classify(token.NEWLINE, None, driver.empty_context)
    assert i2 == g.symbol2number["NEWLINE"]
    # Check an unknown token
    try:
        p.classify(token.NT_OFFSET, "", driver.empty_context)
    except ParseError:
        pass

# Generated at 2022-06-21 10:11:52.523199
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2 import driver
    import os

    grammar = driver.load_grammar(os.path.join(os.path.dirname(__file__), "Grammar.txt"))
    lam_sub(grammar, (0, None, None, [("atom", None, None, None)]))

# Generated at 2022-06-21 10:12:01.916693
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(None, None)
    p.setup()

    assert p.grammar is None
    assert p.convert is None
    assert p.stack == []
    assert p.rootnode is None
    assert p.used_names == set()

    p = Parser(None, None)
    p.setup(1)

    assert p.grammar is None
    assert p.convert is None
    assert p.stack == [(None, 1, (1, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-21 10:12:04.212808
# Unit test for method classify of class Parser
def test_Parser_classify():
    p = Parser(Grammar())
    assert p.classify(1, "NAME", None) == 258
    assert p.classify(1, None, None) == 258

# Generated at 2022-06-21 10:12:16.298677
# Unit test for method pop of class Parser
def test_Parser_pop():
    p = Parser(Grammar())
    p.setup()
    assert p.stack == [([[(0, 0)]], 0, (1, None, None, []))]
    p.push(2, ([[(5, 6)]], {5: 5}), 5, Context(0, 0, None))
    assert p.stack == [
        ([[(0, 0)]], 0, (1, None, None, [])),
        ([[(5, 6)]], 5, (2, None, Context(0, 0, None), []))
    ]
    p.pop()
    assert p.stack == [([[(0, 0)]], 0, (1, None, None, [(2, None, Context(0, 0, None), [])]))]

# Generated at 2022-06-21 10:12:29.085983
# Unit test for method push of class Parser
def test_Parser_push():
    from io import StringIO
    from . import tokenize
    from . import driver

    def parse(grammar: Grammar, text: Text) -> Results:
        p = Parser(grammar)
        p.setup()
        for type, value, _, _ in tokenize.generate_tokens(StringIO(text).readline):
            if p.addtoken(type, value, (1, 0)):
                break
        return {
            "grammar": grammar,
            "rootnode": p.rootnode,
        }

    def check_push(grammar: Grammar, text: str, tree: str):
        results = parse(grammar, text)
        assert str(results["rootnode"]) == tree

    # We use the following grammar:
    # START = START . START;
    # START = START .

# Generated at 2022-06-21 10:12:33.281410
# Unit test for method push of class Parser
def test_Parser_push():
    sample = '3*7'
    g = Grammar(start='expr')
    expr = Sequence(('term', 'term'), [('NUMBER', None, None, None)])
    term = Sequence(('factor', 'factor'), [('NUMBER', None, None, None)])
    factor = Sequence(('NUMBER', None, None, None))
    g.dfas['expr'] = (
        [
            [],
            [(4, 1), (5, 2)],
            [(0, 2)],
            [],
            [(5, 5)],
            [(0, 5)],
        ],
        {1: 0, 2: 0, 3: 1, 4: 0, 5: 0, 6: 3, 7: 3},
    )

# Generated at 2022-06-21 10:12:43.251405
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .driver import test_grammar

    def lam_con(grammar, node):
        return Leaf(type=node[0], value=node[1], context=node[2])

    p = Parser(test_grammar, lam_con)
    p.setup()
    p.addtoken(1, "x", (1, 0))
    p.addtoken(2, "+", (1, 1))
    p.addtoken(1, "x", (1, 2))
    p.addtoken(3, None, (1, 3))

# Generated at 2022-06-21 10:12:54.775401
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    def test(line: str, expected: str) -> None:
        grammar.parse_grammar(grammar.gram, StringIO(grammar.text + "\n" + line))
        parser = Parser(grammar.gram, lam_sub)
        parser.setup(grammar.gram.symbol2number["single_input"])
        parser.addtoken(token.NAME, "a", Leaf(0, 0, ""))
        parser.addtoken(token.NEWLINE, "\n", Leaf(0, 0, ""))
        parser.addtoken(token.ENDMARKER, "", Leaf(0, 0, ""))
        assert str(parser.rootnode) == expected

    test("print_stmt: NAME '\\n'", "[stmts=[print_stmt=[NAME='a']]]")

# Generated at 2022-06-21 10:13:12.346940
# Unit test for method setup of class Parser
def test_Parser_setup():
    nodes = [
        (2, 'class', (1, 0), [
            (3, 'def', (1, 6), [
                (4, 'name', (1, 10), None),
                (5, '(', (1, 11), None),
                (6, ')', (1, 12), None),
                (7, ':', (1, 13), None),
                (8, 'pass', (1, 15), None)
            ])
        ])
    ]
    parser = Parser(Grammar(nodes))

    parser.setup()
    assert parser.stack == [(nodes, 0, (2, None, None, []))]
    assert parser.rootnode is None
    assert parser.used_names == set()


# Generated at 2022-06-21 10:13:14.837268
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2 import driver

    p = driver.build_parser()  # type: ignore



# Generated at 2022-06-21 10:13:26.568455
# Unit test for method pop of class Parser
def test_Parser_pop():
    class FakeNode(object):
        def __init__(self) -> None:
            self.values: List[Any] = []

        def append(self, value: Any) -> None:
            self.values.append(value)

    class FakeGrammar(object):
        def convert(self, node: RawNode) -> Optional[FakeNode]:
            return FakeNode()

    grm = FakeGrammar()
    prs = Parser(grm)
    prs.stack = [([(0, 0)], 0, (0, None, None, [None]))]
    prs.pop()
    assert prs.stack == []
    assert isinstance(prs.rootnode, FakeNode)
    assert prs.rootnode.values == []


# Generated at 2022-06-21 10:13:33.116754
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar, token

    g = grammar.Grammar(grammar.gram_file)
    lam_sub(g, (0, None, None, [("NAME", 1, (1, 2), None)]))
    lam_sub(g, (0, None, None, [(0, None, None, [("NAME", 1, (1, 2), None)])]))
    lam_sub(g, (1, None, None, None))
    lam_sub(g, (token.NAME, "abc", None, None))

# Generated at 2022-06-21 10:13:37.151330
# Unit test for function lam_sub
def test_lam_sub():
    g = Grammar(sys.modules[__name__])
    n = lam_sub(g, (1, None, (1, 1), [("a", None, (1, 2), None), ("b", None, (1, 3), None)]))
    assert n.type == 1
    assert n.children == [NL("a", (1, 2)), NL("b", (1, 3))]

# Generated at 2022-06-21 10:13:40.863930
# Unit test for constructor of class ParseError
def test_ParseError():
    exc_data = ("foo", 1, 2, None)
    exc = ParseError(*exc_data)
    assert exc.type == 1
    assert exc.value == 2
    assert exc.msg == "foo"

# Generated at 2022-06-21 10:13:53.303314
# Unit test for method addtoken of class Parser

# Generated at 2022-06-21 10:14:04.383872
# Unit test for method push of class Parser
def test_Parser_push():
    from . import token, tokenize

    from . import grammar
    import sys

    # Sample token list
    def tkgen():
        for t, a in [(tokenize.NUMBER, "2390"), (token.PLUS, "+"), (tokenize.NUMBER, "109")]:
            yield t, a, (1, 1), (1, 1)
        while True:
            yield token.ENDMARKER, "", (1, 1), (1, 1)

    # Sample grammar
    gr = grammar.Grammar(grammar.start, grammar.dfas, grammar.labels, grammar.tokens)

    prs = Parser(gr)

    # Add a token
    def addtoken(type, value, context):
        prs.addtoken(type, value, context)

    # Push a new entry
   

# Generated at 2022-06-21 10:14:08.392395
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    g = grammar.grammar
    r = g.p_ruledef()
    raw = (g.syms["ruledef"], None, None, [r])
    assert lam_sub(g, raw) == r

# Generated at 2022-06-21 10:14:10.116305
# Unit test for constructor of class Parser
def test_Parser():
    class MockGrammar:
        start = 256

    p = Parser(MockGrammar())

# Generated at 2022-06-21 10:14:24.268174
# Unit test for method pop of class Parser

# Generated at 2022-06-21 10:14:29.629509
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", 1, "value", (2, 3))
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == 1
        assert e.value == "value"
        assert e.context == (2, 3)
    else:
        assert False, "Failed to raise ParseError"


# Generated at 2022-06-21 10:14:36.832441
# Unit test for function lam_sub
def test_lam_sub():
    g = Grammar()
    g.add_symbol("root", (0, 2))
    g.add_symbol("A", (0, 2))
    g.add_nonterminal("root", -1, -1, symbol=0)
    g.add_nonterminal("A", 0, 3, symbol=1)

    assert lam_sub(g, ("root", None, None, [("A", None, None, [])])) == NL(
        type="root", children=[NL(type="A", children=[])]
    )

# Generated at 2022-06-21 10:14:38.790251
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver

    parser = driver.parse_string_to_parser('return 1')
    assert parser.used_names == set(['return'])

# Generated at 2022-06-21 10:14:51.022913
# Unit test for method pop of class Parser
def test_Parser_pop():
    from io import StringIO
    from blib2to3.pgen2.tokenize import tokenize

    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.driver as driver

    import unittest
    class ParserTestCase(unittest.TestCase):
        def setUp(self):
            self.buf = StringIO()
            self.tok = tokenize(self.buf.readline)
            self.tok.filename = "<internal>"
            self.tok.lineno = 1
            self.gr = grammar.Grammar()
            self.gr.parse(driver.parse_grammar(StringIO(GRAMMAR), "test_grammar"),
                  driver.PgenGrammar)

# Generated at 2022-06-21 10:15:00.789457
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar, token

    p = Parser(grammar)
    p.setup()
    # Test of method classify of class Parser
    assert p.classify(token.NAME, "if", (1, 0)) == 1
    assert p.classify(token.NAME, "def", (1, 0)) == 3
    assert p.classify(token.NAME, "xyzzy", (1, 0)) == 40

    # Test of method shift
    p.shift(token.NAME, "if", 8, (1, 0))
    assert p.stack == [(([[(1, 1), (2, 2), (3, 3), (4, 4), (5, 5), (6, 6)]], set()), 8, (1, None, None, [Leaf(1, 'if')]))]


# Generated at 2022-06-21 10:15:12.425215
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = Grammar('Grammar/Grammar', convert=lam_sub)
    parser = Parser(grammar, convert=lam_sub)
    parser.setup()
    parser.shift(token.NAME, 'print', 1, (1, 1))
    parser.shift(token.NAME, 'value', 2, (1, 6))
    parser.shift(token.OP, '+', 3, (1, 11))
    parser.shift(token.NAME, 'value', 2, (1, 13))
    parser.shift(token.NL, '\n', 10, (1, 18))

# Generated at 2022-06-21 10:15:19.875953
# Unit test for method push of class Parser
def test_Parser_push():
    """Test case for method push of class Parser
    """
    p = Parser(None)
    p.stack = [[1, 2, 3]]
    newdfa = ([[(1, 2), (5, -1)], [(1, 2), (5, -1)]], {1: 2})
    p.push(5, newdfa, -1, None)
    assert p.stack == [[1, 2, 3], [newdfa, -1, (5, None, None, [])]]

# Generated at 2022-06-21 10:15:25.977100
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError("msg", 4, "value", (1, 0))
    assert p.msg == "msg"
    assert p.type == 4
    assert p.value == "value"
    assert p.context == (1, 0)

# Generated at 2022-06-21 10:15:34.253532
# Unit test for method push of class Parser
def test_Parser_push():
    """Tests method push of class Parser"""
    f = open("data/Grammar.pgen", "rb")
    grammar = Grammar(f)
    p = Parser(grammar)
    p.setup()
    ttype = 0
    value = "ClassDef"
    context = (1, 1)
    newstate = 0
    p.push(ttype, grammar.dfas[ttype], newstate, context)
    assert p.stack[1][2][0] == ttype
    assert p.stack[1][2][1] is None
    assert p.stack[1][2][2] == context
    assert p.stack[1][2][3] == []

# Generated at 2022-06-21 10:16:12.267127
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar('')
    parser = Parser(grammar)
    parser.stack = [
        ([], 0, (None, None, None, None)),
        ([], 0, (None, None, None, None)),
    ]
    parser.rootnode = None
    parser.pop()
    assert parser.stack == [([], 0, (None, None, None, None))]
    assert parser.rootnode is None
    parser.stack = [
        [([], 0, (None, None, None, None))],
        [([], 0, (None, None, None, None))],
    ]
    parser.stack.append(([], 0, (None, None, None, [None])))
    parser.rootnode = None
    parser.pop()

# Generated at 2022-06-21 10:16:14.494050
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(Grammar(), None)
    # Verify that new parser has no tokenstack
    assert len(p.stack) == 0


# Generated at 2022-06-21 10:16:24.081021
# Unit test for method pop of class Parser
def test_Parser_pop():
    converter = lambda grammar, node: node

# Generated at 2022-06-21 10:16:33.907583
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = Grammar()
    for line in open("Grammar/Grammar", "rb"):
        if line.startswith(b"#"):
            continue
        (_, type, value, _, _, _) = line.split()
        if value:
            grammar.tokens[int(value)] = int(type)
        else:
            grammar.labels[int(type)] = (int(type), value)
    grammar.dfas = {}
    for line in open("Grammar/Nfa", "rb"):
        line = line.split()
        if line[0] == b'S':
            type = int(line[1])
            dfas = grammar.dfas[type] = DFA(), {}
            first = dfas[1] = []
            assert not first[1:]


# Generated at 2022-06-21 10:16:40.656609
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2.token import Token
    from blib2to3.pgen2.driver import Driver
    drv = Driver(Token)
    grammar = drv.load_grammar()
    p = Parser(grammar)
    p.setup()
    assert p.stack[0] == (grammar.dfas[grammar.start], 0, (256, None, (1, 0), []))



# Generated at 2022-06-21 10:16:44.785806
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = grammar.Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.rootnode = Node(type=-3, children=[])
    parser.pop()
    assert parser.rootnode is not None

# Generated at 2022-06-21 10:16:47.711080
# Unit test for constructor of class Parser
def test_Parser():
    from .driver import get_grammar

    g = get_grammar()
    p = Parser(g)
    p.setup()

# Generated at 2022-06-21 10:16:57.577768
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    def check(ttype: int, tvalue: Optional[Text], tcontext: Context,
              ntype: int, nvalue: Optional[Text], nchildren: Sequence[NL]) -> None:
        tnode = (ttype, tvalue, tcontext, None)
        nnode = lam_sub(grammar.python_grammar, tnode)
        assert nnode.type == ntype
        assert nnode.value == nvalue
        assert len(nnode.children) == len(nchildren)
        assert all(a == b for a, b in zip(nnode.children, nchildren))

    check(
        token.NAME, "foo", (1, 0),
        symbol.power, None, [(Leaf(token.NAME, "foo", (1, 0)),)]
    )

# Generated at 2022-06-21 10:17:03.581451
# Unit test for function lam_sub
def test_lam_sub():
    x = gram.symbol()
    assert x == 0
    assert gram.symbol2label(x) == "0"
    node = ('0', None, None, ['1', '2'])
    n = lam_sub(gram, node)
    assert n.children == ()
    assert n.prefix == ""


if __name__ == "__main__":
    import unittest

    from . import driver

    class ParserTestCase(unittest.TestCase):
        """Unit tests for this module."""

        parser = None

        def parse(
            self, s: Text, start: str = "file_input", conv: Optional[Convert] = None
        ) -> Node:
            global parser
            if self.parser is None:
                self.parser = Parser(driver.grammar, conv)
            driver

# Generated at 2022-06-21 10:17:14.918044
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    from . import driver

    if len(sys.argv) == 2:
        fname = sys.argv[1]
    else:
        print("Usage: %s <fname>" % (sys.argv[0],), file=sys.stderr)
        sys.exit(2)

    p = driver.Driver(fname, 0)
    t = p.token()

    grammar = Grammar(fname)
    parser = Parser(grammar)
    parser.setup()

    while 1:
        toktype = t[0]
        # tokvalue = t[1]
        lineno = t[3]
        # print(token.tok_name[toktype], tokvalue, lineno)
        if toktype == token.ENDMARKER:
            break


# Generated at 2022-06-21 10:18:15.307754
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def assert_raises(type, *args):
        try:
            parser.addtoken(*args)
        except ParseError as pe:
            assert ((getattr(type, 'type', type) == pe.type and
                     getattr(type, 'value', None) == pe.value) or
                    (isinstance(type, tuple) and
                     tuple(type) == (pe.type, pe.value)))
        else:
            assert 0, 'did not raise'


# Generated at 2022-06-21 10:18:26.730189
# Unit test for method push of class Parser
def test_Parser_push():
    # Dummy Grammar class
    class Grammar:
        def __init__(self, start: int, tokens: Dict[int, int]) -> None:
            self.start = start
            self.tokens = tokens
        def dfas(self) -> Dict[int, DFAS]:
            return {1: ([[(0, 1), (2, 1)]], {0: 2, 1: 1}),
                    2: ([[(0, 2), (1, 3), (3, 2)]], {0: 2, 2: 2, 3: 2}),
                    3: ([[(0, 4), (1, 3), (2, 3), (3, 3)]], {0: 4, 1: 3, 2: 3, 3: 3})}

    t1_1, t2_2, t3_3, t

# Generated at 2022-06-21 10:18:28.605761
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)

# Generated at 2022-06-21 10:18:39.532039
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar


# Generated at 2022-06-21 10:18:49.662119
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest

    from . import grammar, token

    class TestParser(unittest.TestCase):

        def setUp(self):
            self.p = Parser(grammar.Grammar(grammar.leaftypes), None)

        def test_addtoken(self):
            # First, test all possible states in the single-node state table
            self.p.setup(grammar.syms.single)
            # The current state is 0
            self.p.addtoken(token.NAME, "foo", (1, 0))
            # The current state is 1
            self.p.addtoken(token.NAME, "foo", (1, 0))
            # The current state is 2
            self.p.addtoken(token.NAME, "foo", (1, 0))
            # The current state is 3
            self

# Generated at 2022-06-21 10:18:51.411859
# Unit test for function lam_sub
def test_lam_sub():
    # Just make sure it works with trivial input
    lam_sub(None, (1, "foo", None, None))

# Generated at 2022-06-21 10:18:54.481795
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    for gr in [grammar, grammar.pgen2_grammar]:
        p = Parser(gr)
        p.setup()



# Generated at 2022-06-21 10:19:03.805176
# Unit test for constructor of class Parser
def test_Parser():
    import random

    random.seed(1234)

    def f(n):
        if n <= 0:
            return Leaf(value=str(random.randint(0, 100000)))
        else:
            return Node(type=random.randint(256, 340), children=[f(n - 1)])

    from . import python

    p = Parser(python)
    for i in range(1, 10):
        p.setup()
        for j in range(i):
            node = f(i)
            for x in node.leaves():
                p.addtoken(int(x.value), x.value, None)
            assert p.addtoken(token.ENDMARKER, "", None)
            assert node == p.rootnode
    print("test_Parser() passed")



# Generated at 2022-06-21 10:19:07.142359
# Unit test for method shift of class Parser
def test_Parser_shift():
    class TestClass:
        def __init__(self):
            self.stack = list()

        def shift(self, a1, a2, a3, a4):
            self.stack.append(a1)

    obj = TestClass()
    obj.shift(1, 2, 3, 4)
    obj.shift(5, 6, 7, 8)
    assert obj.stack == [1, 5]

# Generated at 2022-06-21 10:19:10.282448
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("foo", None, None, None)
    except ParseError as e:
        assert e.msg == "foo"
    else:
        assert False, "ParseError was not raised"