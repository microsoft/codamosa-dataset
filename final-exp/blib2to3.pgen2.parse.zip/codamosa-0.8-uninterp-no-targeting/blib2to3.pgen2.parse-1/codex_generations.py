

# Generated at 2022-06-21 10:10:25.379254
# Unit test for method shift of class Parser
def test_Parser_shift():
    class FakeGrammar():
        def __init__(self):
            self.tokens = {1: 2}
            self.keywords = {}
    class FakeConverter():
        def __init__(self):
            self.convert_counter = 0

        def convert(self, grammar, node):
            self.convert_counter += 1
            return node
    fake_grammar = FakeGrammar()
    fake_converter = FakeConverter()
    p = Parser(fake_grammar, fake_converter.convert)
    p.setup()
    p.shift(1, "1", 1, None)
    assert fake_converter.convert_counter == 1

# Generated at 2022-06-21 10:10:33.240189
# Unit test for method classify of class Parser
def test_Parser_classify():

    # Verification of the classification of the non-terminal 'expr'
    def test_expr_classify(p, type, value, context):
        assert p.classify(type, value, context) == 2

    # Verification of the classification of the terminal 'for'
    def test_for_classify(p, type, value, context):
        assert p.classify(type, value, context) == 38

    # Verification of the classification of the non-terminal 'xor_expr'
    def test_xor_expr_classify(p, type, value, context):
        assert p.classify(type, value, context) == 9

    # Verification of the classification of the token 'NAME'

# Generated at 2022-06-21 10:10:40.585643
# Unit test for constructor of class Parser
def test_Parser():
    import unittest

    class ParserTestCase(unittest.TestCase):
        def setUp(self) -> None:
            import parser
            g = parser.ParserGenerator(
                [
                    "s : NAME",
                    "s : 's' NAME",
                    "s : NAME 'a'",
                    "s : NAME 'a' NAME",
                    "s : NAME 'a' NAME 'b'",
                    #
                ],
                [
                    "name",
                ],
            )
            self.p = parser.Parser(g.grammar)

        def test_constructor(self) -> None:
            self.assertTrue(self.p)

    unittest.main()

# Generated at 2022-06-21 10:10:47.915216
# Unit test for method setup of class Parser
def test_Parser_setup():
    class MockGrammar:
        def __init__(self):
            self.start = 1
            self.dfas = {1: [0, 0]}

    mock_grammar = MockGrammar()
    parser = Parser(mock_grammar)
    parser.setup()

    # Check the stack was initialized to the start state
    assert parser.stack == [(mock_grammar.dfas[1], 0, (1, None, None, []))]


# Generated at 2022-06-21 10:10:52.826337
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, tokenize

    p = Parser(grammar.grammar)
    p.setup()
    for t in tokenize.generate_tokens(open(__file__)):
        if p.addtoken(*t):
            break



# Generated at 2022-06-21 10:11:00.996571
# Unit test for method shift of class Parser
def test_Parser_shift():
    class Token(object):
        def __init__(self, type, value, context):
            self.type = type
            self.value = value
            self.context = context

    class Grammar(object):
        def __init__(self):
            self.start = 257
            self.labels = [("a", None), ("b", None), ("c", None)]
            self.keywords = {}
            self.tokens = {"a": 0, "b": 1, "c": 2}
            self.dfas = {"blah": (None, None)}
            self.firsts = None

    def convert(grammar, node):
        return "converted"

    def _test(parser, token, dfa, state, node, expected):
        parser.stack = [(dfa, state, node)]
        parser.shift

# Generated at 2022-06-21 10:11:09.286611
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import grammar, token

    class ParserTestCase(unittest.TestCase):

        def assertEqual(self, *args: Any, **kwargs: Any) -> None:
            kwargs.pop('msg', None)
            return super().assertEqual(*args, **kwargs)

        def test_addtoken_bad_input(self) -> None:
            g = grammar.Grammar(g1)
            p = Parser(g)
            p.setup()
            self.assertRaises(ParseError, p.addtoken, token.NUMBER, "1", (1, 2))
            self.assertRaises(ParseError, p.addtoken, token.PLUS, "+", (1, 2))


# Generated at 2022-06-21 10:11:17.495051
# Unit test for method push of class Parser
def test_Parser_push():
    class Fake:
        dfas = {}  # type: Dict[int, DFAS]
        labels = {}  # type: Dict[int, Tuple[int, Optional[Text]]]
        keywords = {}  # type: Dict[Text, int]
        tokens = {}  # type: Dict[int, int]
        start = 0

    p = Parser(Fake())
    p.stack = []  # type: List[Tuple[DFAS, int, RawNode]]

# Generated at 2022-06-21 10:11:22.431477
# Unit test for constructor of class Parser
def test_Parser():
    import blib2to3.pgen2.grammar
    grammar = blib2to3.pgen2.grammar.Grammar('')
    p = Parser(grammar)
    p.grammar == grammar
    p.convert == lam_sub


# Generated at 2022-06-21 10:11:31.996250
# Unit test for method setup of class Parser
def test_Parser_setup():
    class Dummy_Grammar:
        start = 1
        dfas = {1: (Dummy_DFA, {0: 0, 1: 1})}

    class Dummy_DFA:
        pass

    class Dummy_convert:
        pass

    p = Parser(Dummy_Grammar(), Dummy_convert())
    p.setup()
    assert isinstance(p.stack, list), 'Expected a list for attribute stack'
    assert len(p.stack) == 1, 'Expected 1 for attribute stack'
    assert p.stack[0][0] == Dummy_DFA, 'Expected Dummy_DFA for p.stack[0][0]'
    assert p.stack[0][1] == 0, 'Expected 0 for p.stack[0][1]'

# Generated at 2022-06-21 10:11:45.216980
# Unit test for method setup of class Parser
def test_Parser_setup():
    """Unit test for method setup of class Parser."""
    from .token import Token
    from .grammar import Grammar, extract_grammar
    from .pgen import generate_grammar

    import io
    import unittest
    import sys

    class MyTestCase(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_1(self):
            g1 = Grammar(grammar=extract_grammar(open('Grammar', 'r'), convert=eval))
            g2 = generate_grammar(g1)
            self.assertEqual(g1, g2)

        def test_2_parser(self):
            self.assertEqual(token.NAME, 1)

# Generated at 2022-06-21 10:11:52.988404
# Unit test for method setup of class Parser
def test_Parser_setup():
    "Test method setup() of class blib2to3.pgen2.parser.Parser."
    import sys
    import blib2to3.pgen2.grammar as grammar
    g = grammar.Grammar("Grammar.txt")
    p = Parser(g)
    try:
        p.addtoken(token.NAME, "def", (1, 0))
    except AttributeError:
        pass
    else:
        assert False, "method addtoken() must raise AttributeError for invalid call"
    p.setup()


# Generated at 2022-06-21 10:11:58.969253
# Unit test for function lam_sub
def test_lam_sub():
    g = Grammar()
    n = (1, None, (1, 5), ['a', 'b'])
    assert lam_sub(g, n) == Node(type=1, value='1',
                                 children=['a', 'b'], context=(1, 5))

# The following functions are used by pgen.main() to test the parser
# engine:


# Generated at 2022-06-21 10:12:07.905691
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3 import pytree
    from .grammar import Grammar
    from .pgen import tokenize

    p = Parser(Grammar)
    p.setup()
    for t in tokenize(open("<unknown>", "rU"), "print(1)"):
        if p.addtoken(*t):
            break
    assert(isinstance(p.rootnode, pytree.Node))
    assert(isinstance(p.rootnode[0], pytree.Node))
    assert(p.rootnode[0].type == "simple_stmt")
    assert(len(p.rootnode[0]) == 1)
    assert(len(p.rootnode[0][0]) == 2)
    assert(p.rootnode[0][0][0].type == "NAME")

# Generated at 2022-06-21 10:12:20.086377
# Unit test for method push of class Parser
def test_Parser_push():
    from .tokenize import generate_tokens
    from .dfa import DFAMatcher
    from . import tokens, tokenize

    empty_tokens = []


# Generated at 2022-06-21 10:12:31.067837
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import tokenize
    from . import confusion

    tokens = tokenize.generate_tokens(confusion.__doc__)
    g = confusion.confusion_grammar
    p = Parser(g)
    p.setup()
    for t in tokens:
        p.addtoken(t[0], t[1], None)

    import ast
    import sys
    ast.fix_missing_locations(p.rootnode)
    mod = ast.Module(body=[ast.Expr(value=p.rootnode)])
    ast.increment_lineno(mod, 1)
    code = compile(mod, __file__, "exec")
    eval(code)
    sys.stdout.write('\n') # Terminate print

# Generated at 2022-06-21 10:12:42.250049
# Unit test for method pop of class Parser
def test_Parser_pop():
    def lam_sub_test(grammar, node):
        assert node[3] is not None
        return Node(type = node[0],
                    children = node[3],
                    context = node[2])

    grammar = Grammar()

    # Add some dfa's to grammar.dfa
    dfas = [[(0, 2), (3, 4), (0, 5)],
            [(0, 5)],
            [(0, 5)],
            [(0, 5)],
            ]
    states = {
            0: [(0, 2), (3, 4), (0, 5)],
            2: [(0, 5)],
            3: [(0, 5)],
            4: [(0, 5)],
            5: [(0, 5)],
            }

# Generated at 2022-06-21 10:12:45.501212
# Unit test for constructor of class ParseError
def test_ParseError():
    """Verify instantiation of ParseError uses the correct parameters."""
    err = ParseError("test", token.PLUS, "+", (1, 2))
    assert err.msg == "test"
    assert err.type == token.PLUS
    assert err.value == "+"
    assert err.context == (1, 2)

# Generated at 2022-06-21 10:12:56.679859
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    print("test_Parser_addtoken")
    import sys
    import os.path
    import blib2to3.pgen2.driver
    grammar = blib2to3.pgen2.driver.load_grammar("Grammar.txt")
    parser = Parser(grammar)
    parser.setup()  # start symbol is file_input
    # Read from standard input; terminate on Ctrl-Z in DOS, Ctrl-D in Unix
    tokenize = blib2to3.pgen2.driver.tokenize("<stdin>", sys.stdin.read())
    for toktype, value, context in tokenize:
        try:
            done = parser.addtoken(toktype, value, context)
        except ParseError as e:
            print(e)
            break
        if done:
            parser

# Generated at 2022-06-21 10:13:08.330683
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import os
    import blib2to3.pgen2.tokenize
    import blib2to3.pgen2.parse
    import blib2to3.pgen2.driver
    print("Testing method pop of class Parser")
    grammar = blib2to3.pgen2.parse.load_grammar("Lib/json/tests/json.tests.ast.grammar")
    assert grammar
    p = blib2to3.pgen2.driver.load_grammar("Lib/json/tests/json.tests.ast.grammar")
    assert isinstance(p, blib2to3.pgen2.grammar.Grammar)
    parser = blib2to3.pgen2.driver.Parser(p, lambda x, y: None)

# Generated at 2022-06-21 10:13:20.149732
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", 1, "value", (1, 2))
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == 1
        assert e.value == "value"
        assert e.context == (1, 2)

# Generated at 2022-06-21 10:13:31.171441
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, token, tokenize
    from blib2to3.pytree import Leaf, Node
    from blib2to3.pgen2.parse import tokenize_with_comments
    from blib2to3.pgen2.driver import Driver
    from io import StringIO

    buf = StringIO('a = b**2')
    buf = tokenize_with_comments(buf)
    tokens = tokenize.generate_tokens(buf.__next__)
    d = Driver(grammar.grammar, convert=None, strategy='LALR')
    p = d.p
    p.setup(grammar.suite)
    for t in tokens:
        p.addtoken(t.type, t.string, t.start)
    result = p.rootnode

# Generated at 2022-06-21 10:13:41.740023
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """
    >>> import os, sys
    >>> fn = os.path.join(sys.prefix, 'lib', 'python%s' % sys.version[:3], 'test', 'tokenize_tests.txt')
    >>> f = open(fn, 'rb')
    >>> from blib2to3.pgen2.tokenize import generate_tokens
    >>> from blib2to3.pgen2 import driver
    >>> g = driver.load_grammar('Grammar.txt')
    >>> p = driver.Parser(g)
    >>> p.setup()
    >>> for token in generate_tokens(f.readline):
    ...     p.addtoken(*token)
    True
    """

if __name__ == "__main__":
    import doctest, pprint

    # Create a parser instance
   

# Generated at 2022-06-21 10:13:54.083212
# Unit test for function lam_sub
def test_lam_sub():
    from . import driver as pdriver
    from . import syms

    # Test that lam_sub works as intended
    grammar = pdriver.load_grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.LPAR, "(", (1, 0))
    parser.addtoken(token.NAME, "x", (1, 0))
    parser.addtoken(token.EQUAL, "=", (1, 0))
    parser.addtoken(token.NAME, "y", (1, 0))
    parser.addtoken(token.RPAR, ")", (1, 0))
    parser.addtoken(token.NEWLINE, "\n", (1, 0))
    result = parser.rootnode
    assert result.type == syms.file_input

# Generated at 2022-06-21 10:13:55.848821
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()



# Generated at 2022-06-21 10:13:56.705194
# Unit test for function lam_sub
def test_lam_sub():
    # XXX todo
    return

# Generated at 2022-06-21 10:13:59.166016
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = Grammar()
    p = Parser(grammar)
    with pytest.raises(AttributeError):
        p.push(1, 2, 3, 4)

# Generated at 2022-06-21 10:14:11.304734
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # pylint: disable=unused-variable
    def check_ParseError(
        parser: Parser,
        name: Text,
        type: int,
        value: Text,
        offset: int,
        lineno: int,
        msg: Text,
    ) -> None:
        try:
            parser.addtoken(type, value, Context(parser.rootnode, offset, lineno))
        except ParseError as err:
            assert err.msg == msg, "{} != {}".format(err.msg, msg)
            return
        raise AssertionError("ParseError expected")

    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()

# Generated at 2022-06-21 10:14:20.306943
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Test addtoken method of class Parser
    # Test case 1: no error
    # Construct a grammar
    g = Grammar()
    g.labels[1] = (token.NAME, None)
    g.labels[2] = (token.NUMBER, None)
    g.labels[3] = (1, None)
    g.keywords[None] = 1
    g.tokens[11] = 1
    g.tokens[12] = 2
    g.tokens[13] = 3
    first_dfa = [
        [],
        [(0, 1)],
        [(1, 4), (0, 2)],
        [],
        [],
    ]

# Generated at 2022-06-21 10:14:21.504413
# Unit test for method setup of class Parser
def test_Parser_setup():
    pass

# Generated at 2022-06-21 10:14:37.846297
# Unit test for constructor of class Parser
def test_Parser():
    import blib2to3.pgen2.token as token
    import blib2to3.pgen2.driver as driver
    p = driver.Driver(blib2to3.__file__, None, convert=lam_sub)
    p.parse_tokens([(token.NAME, "" + token.ENDMARKER)])
    p.prepare()
    x = ParseError("foo", -1, "bar", None)
    assert x.msg == "foo"
    assert x.type == -1
    assert x.value == "bar"
    assert x.context is None
    p = Parser(None)
    try:
        p.setup()
    except TypeError:
        pass
    p = Parser(None, None)

# Generated at 2022-06-21 10:14:50.028027
# Unit test for method shift of class Parser
def test_Parser_shift():
    class MockGrammar:
        """Mock class for the grammar.Grammar class."""

        def __init__(self) -> None:
            self.labels = [0, 1, 2, 3, 4, 5]
            self.start = 0

    class MockConverter:
        """Mock class for the convert() argument to the Parser constructor."""

        def __init__(self) -> None:
            self.nodes: List[Any] = []

        def __call__(self, grammar, node) -> Union[Node, Leaf]:
            self.nodes.append(node)
            return node

    grammar = MockGrammar()
    converter = MockConverter()
    parser = Parser(grammar, converter)
    parser.setup()

# Generated at 2022-06-21 10:15:00.050959
# Unit test for method shift of class Parser
def test_Parser_shift():
    # An incoming token should be appended to the children of the
    # current node on the stack and the current state changes.
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [([[[(1, 0), (2, 0)], [(3, 0), (4, 0)]]], [0]), (0, 0, (1, None, None, None))]
    p.shift(g.tokens[token.NUMBER], "3", 1, Context(1, 0))

# Generated at 2022-06-21 10:15:06.492693
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest
    import io
    from blib2to3.pgen2.driver import load_grammar
    from blib2to3.pgen2.tokenize import generate_tokens
    from . import parsetok, token

    class TestParserClassify(unittest.TestCase):

        def test_classify(self):

            # Load a simple grammar
            g = load_grammar("Grammar.txt")
            p = Parser(g)
            p.setup()

            # Test classify on some reserved words
            text = "False None True"
            tokengen = generate_tokens(io.StringIO(text).readline)
            tok = next(tokengen)

# Generated at 2022-06-21 10:15:09.045138
# Unit test for function lam_sub
def test_lam_sub():
    return

if __name__ == "__main__":
    from . import driver  # type: ignore

    driver.run_driver(Parser)

# Generated at 2022-06-21 10:15:15.143097
# Unit test for method classify of class Parser
def test_Parser_classify():
    def test(asserts, type, value, etalon):
        pygram = Grammar()
        pygram.load_parser_state(os.path.join(os.path.dirname(__file__), "Python.parser"))
        p = Parser(pygram, convert=None)
        asserts(p.classify(type, value, None) == etalon, type, value, etalon)
    return test

# Generated at 2022-06-21 10:15:24.221329
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import pgen
    from .driver import Driver
    from typing import Any
    driver = Driver(pgen.yacc, optimize=False, ytabversion="0.1")
    parser = Parser(driver.grammar, driver._convert)
    def test_shift(type: Any, value: Any, context: Any) -> None:
        parser.shift(type, value, 1, context)
        assert parser.stack == [(0, 1, (None, None, context, [type, value, context]))]
    from .token import INDENT, DEDENT, NL
    test_shift(INDENT, "", "test")
    test_shift(DEDENT, "", "test")
    test_shift(NL, None, "test")

# Generated at 2022-06-21 10:15:29.147872
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    assert g.sym2tok[g.tokens["def"]] == token.NAME
    assert p.classify(token.NAME, "def", None) == g.tokens["def"]

# Generated at 2022-06-21 10:15:34.253483
# Unit test for function lam_sub
def test_lam_sub():
    class FakeGrammar(object):
        def __init__(self, dfas):
            self.dfas = dfas
    grammar = FakeGrammar({"fake": ([], {})})
    node = (1, "fake", None, [])
    assert lam_sub(grammar, node) == Node(type=1, children=[], context=None,
                                          used_names=set())

# Generated at 2022-06-21 10:15:41.191833
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    gram = grammar.Grammar()
    parse = Parser(gram, None)
    parse.setup(257)
    temp = (257, None, None, [])
    parse.stack = [(gram.dfas[257], 0, temp)]
    parse.shift(token.NAME, "John Doe", 1, None)
    assert parse.stack == [(gram.dfas[257], 1, temp)]


# Generated at 2022-06-21 10:16:00.230799
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Tests the shift method of the Parser class"""
    # A method that returns a new node
    def new_node(grammar):
        return RawNode(None, None, None, [])
    # Test the shift method
    p = Parser(Grammar())
    p.setup()
    p.shift(1, "2", 3, Context(None, None))
    assert len(p.stack) == 1
    assert p.stack[0][1] == 3
    assert len(p.stack[0][2]) == 4
    p.stack[0][2] = RawNode(1, 1, 1, [1])
    p.shift(1, "2", 3, Context(None, None))
    assert len(p.stack) == 1
    assert p.stack[0][1] == 3
    assert len

# Generated at 2022-06-21 10:16:11.870794
# Unit test for function lam_sub
def test_lam_sub():
    import blib2to3.pgen2.token as token
    from blib2to3.pgen2.grammar import Grammar

    grammar = Grammar(
        """
        START = ANY*
        ANY = x | y | z
        x = 'x'
        y = 'y'
        z = 'z'
        """
    )
    parser = Parser(grammar)
    parser.setup()
    for s in "x y z".split():
        parser.addtoken(token.STRING, s, None)
    assert str(parser.rootnode) == "Node(type=START, children=[x, y, z])\n"
    assert parser.rootnode.type == grammar.symbol2number["START"]

# Generated at 2022-06-21 10:16:19.176298
# Unit test for method pop of class Parser
def test_Parser_pop():
    import unittest
    import types
    import datetime
    import _ast as ast
    import sys
    import os
    import shutil

    class Parser_pop_Test(unittest.TestCase):
        def setUp(self):
            self.path_to_grammar = '../grammar/Grammar'
            if os.name == 'java':
                self.path_to_tests = '..\tests'
            else:
                self.path_to_tests = '../tests'
            sys.path.append(self.path_to_grammar)
            sys.path.append(self.path_to_tests)
            from grammar_parser import load_grammar
            from grammar_parser import parse_grammar

# Generated at 2022-06-21 10:16:24.710994
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from blib2to3.pgen2 import token
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pytree import Leaf
    p = Parser(driver.grammar)
    p.setup()
    p.shift(token.NAME, "a", 0, None)
    assert p.stack[-1] == (driver.grammar.dfas[None], 0, ((None, None, None, [Leaf(1, 'a', None, None)]),))

# Generated at 2022-06-21 10:16:28.959269
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar
    import os

    pytree = grammar.pgen_grammar_file(
        os.path.join(os.path.dirname(grammar.__file__), "Grammar")
    )
    grammar_file = grammar.grammar_from_pytree(pytree)
    g = grammar.Grammar(grammar_file.start, {}, {}, {}, {}, {})
    Parser(g)
    return g


if __name__ == "__main__":
    test_Parser()

# Generated at 2022-06-21 10:16:36.541333
# Unit test for constructor of class Parser
def test_Parser():
    import unittest

    class TestParser(unittest.TestCase):
        def test_fail_shift(self):
            grammar = Grammar()
            grammar.dfas = {}
            parser = Parser(grammar)
            parser.setup()
            self.assertRaises(ParseError, parser.addtoken, 1, "x", None)

        def test_fail_push(self):
            grammar = Grammar()
            grammar.dfas = {"S": ([[(2, 1)], [(0, 1)]], set([1]))}
            grammar.labels = [(1, "S"), (2, "S")]
            parser = Parser(grammar)
            parser.setup()
            self.assertRaises(ParseError, parser.addtoken, 1, "x", None)

    unittest.main

# Generated at 2022-06-21 10:16:48.226633
# Unit test for method push of class Parser
def test_Parser_push():
    popstack = [(('fsa', 'A', 0, [[('A', 0), ('C', 1), ('A', 0)]]), 1, 2)]
    node = (3, 4, 5, [])
    popdfa, popstate, popnode = popstack.pop()
    # popdfa            =  ('fsa', 'A', 0, [('A', 0), ('C', 1), ('A', 0)])
    # popstate          =  1
    # popnode           =  2
    assert popdfa == ('fsa', 'A', 0, [[('A', 0), ('C', 1), ('A', 0)]])
    assert popstate == 1
    assert popnode == 2
    newnode = node[-1].append(popnode)

# Generated at 2022-06-21 10:16:57.913684
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar(
        start=str(256),  # A nonterminal
        rules=[((str(256), (str(257),)), None), ((str(257), (str(258),)), None)],
        labels=[
            ("", 0),
            ("", 257),
            ("", 258),
        ],
        key2syms={},
        keywords={},
        tokens=[],
        dfas={
            str(256): ([[], [[1, 1], [0, 2]], [[0, 2]]], {0: 0, 1: 1, 2: 2}),
            str(257): ([[], [[1, 1]]], {0: 0, 1: 1}),
            str(258): ([[], [[1, 1]]], {0: 0, 1: 1}),
        },
    )
    parser

# Generated at 2022-06-21 10:17:03.544500
# Unit test for method setup of class Parser
def test_Parser_setup():
    from .driver import Driver

    d = Driver(verify=False)
    p = Parser(d.grammar, convert=d.driver)
    p.setup()
    print("Parser initialized")
    # print the stack of the parser
    print("stack:", p.stack)
    assert p.stack == [(p.grammar.dfas[1], 0, (1, None, None, []))]


# Generated at 2022-06-21 10:17:14.877673
# Unit test for method push of class Parser
def test_Parser_push():
    parser = Parser(Grammar("""
        e: e '+' e
          | e '-' e
          | '(' e ')'
          | NAME
        """), lam_sub)
    parser.setup()
    parser.addtoken(token.NAME, 'a', None)
    assert parser.rootnode.json == '["e",["e",["e",["NAME","a"]],"+",["e",["NAME","a"]]]]'
    parser.push(parser.grammar.symbol2number['e'], parser.grammar.dfas['e'], 0, None)
    parser.addtoken(token.NAME, 'a', None)
    parser.pop()
    parser.addtoken(token.PLUS, '+', None)

# Generated at 2022-06-21 10:17:45.292467
# Unit test for method push of class Parser
def test_Parser_push():
    class SubParser(Parser):
        def push(self, type: int, newdfa: DFAS, newstate: int, context: Context) -> None:
            Parser.push(self, type, newdfa, newstate, context)

    # Create a Parser instance
    grammar = Grammar()
    parser = SubParser(grammar)

    # Setup the Parser instance, which needs to be done before parsing
    parser.setup()



# Generated at 2022-06-21 10:17:49.167442
# Unit test for function lam_sub
def test_lam_sub():
    g = None
    node = (1, None, None, [(2, "foo", None, None), (3, "bar", None, None)])
    assert lam_sub(g, node) == (1, "foo\nbar")

# Generated at 2022-06-21 10:17:57.065042
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    def _test_addtoken(self: Parser, type: int, value: Optional[Text], context: Context) -> bool:
        tp = self.grammar.tokens.get(type)
        if tp is None:
            tp = "NAME"
        print(tp, repr(value), context)
        return self.addtoken(type, value, context)

    try:
        Parser.addtoken = _test_addtoken
        driver = Driver(grammar, "examples/calc.txt")
        while True:
            if driver.addtoken():
                break
    finally:
        del Parser.addtoken



# Generated at 2022-06-21 10:18:02.110469
# Unit test for method pop of class Parser
def test_Parser_pop():
    t = token
    g = Grammar()
    p = Parser(g)
    p.push(t.NAME, (0,0), 0, Context(0))
    assert p.stack
    p.pop()
    assert not p.stack



# Generated at 2022-06-21 10:18:10.937170
# Unit test for method push of class Parser
def test_Parser_push():
    import os, sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'lib2to3'))
    from . import grammar

    gr = grammar.Grammar('test_.g')
    p = Parser(gr)
    p.setup()
    assert p.stack == [(gr.dfas[gr.start], 0, (gr.start, None, None, []))]
    # Grammar for this test
    #     expr_stmt: testlist ';' | testlist_nocond ';'
    #     testlist_nocond: test+
    #     test: atom | listmaker
    #     atom: NAME
    #     listmaker: test ('for' testlist 'in' testlist_nocond)* [',']

# Generated at 2022-06-21 10:18:22.710177
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import keyword
    from . import token

    def tt(text, type, value):
        return [(type, value)]

    def test_tt(text, type, value):
        if token.tok_name[type] == value:
            return [(type, value)]
        else:
            return []

    # Verify classify accepts numbers and tolerates singleton strings.
    parser = Parser(Grammar(keyword), None)
    parser.grammar.tokens = {token.NAME: 256}
    assert parser.classify(token.NAME, 123, None) == 256
    assert parser.classify(token.NAME, "abc", None) == 256

    # Verify classify accepts tokens from tokenize.tokenize()

# Generated at 2022-06-21 10:18:29.935713
# Unit test for method pop of class Parser
def test_Parser_pop():
    # test when len(stack) > 0
    p = Parser({}, None)
    p.stack = [(1, 2, 3)] #dummy stack
    p.rootnode = 10 #dummy rootnode
    p.pop()
    assert p.stack == [(1, 2, 3)]
    assert p.rootnode == None

    # test when len(stack) == 0
    p.stack = []
    p.pop()
    assert p.stack == []
    assert p.rootnode == 3 #not 10 anymore


# Generated at 2022-06-21 10:18:35.182793
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    p = Parser(grammar)
    p.classify(token.NAME, "True", None)  # check reserved words
    p.classify(token.INDENT, None, None)  # check indents
    p.classify(token.NAME, "x", None)



# Generated at 2022-06-21 10:18:43.738277
# Unit test for constructor of class Parser
def test_Parser():
    # See if it works without a converter
    import blib2to3.pgen2.grammar as g
    g1 = g.Grammar()
    p = Parser(g1)
    p.setup(0)
    p.addtoken(5, "if", None)
    p.addtoken(1, "x", None)
    p.addtoken(4, ":", None)
    p.addtoken(5, "if", None)
    p.addtoken(1, "y", None)
    p.addtoken(4, ":", None)
    p.addtoken(5, "if", None)
    p.addtoken(1, "z", None)
    p.addtoken(4, ":", None)
    p.addtoken(0, "", None)
    p.add

# Generated at 2022-06-21 10:18:51.938076
# Unit test for method pop of class Parser
def test_Parser_pop():
    def lam_convert(grammar, node):
        if node[0] == 'bar':
            node[0] = 'foo'
        return node
    g = Grammar(start='foo', end=['$end', 'bar'], labels=['foo', 'bar'])
    p = Parser(g, lam_convert)
    p.setup()
    p.addtoken(token.NAME, 'bar', 0)
    p.addtoken(token.ENDMARKER, None, 0)
    assert p.rootnode == ('foo', None, None, [('bar', None, None, None)])
    assert p.stack == []
    p.setup()
    p.addtoken(token.NAME, 'foo', 0)

# Generated at 2022-06-21 10:19:52.556352
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from . import pgen
    from blib2to3.pgen2.parse import parse_grammar
    gr = parse_grammar(grammar._Py_grammar_spec, pgen.pgen)
    # make sure lam_sub doesn't raise an error
    lam_sub(gr, (1, '', None, []))

# Generated at 2022-06-21 10:20:00.618254
# Unit test for method push of class Parser
def test_Parser_push():
    import os.path
    from . import pgen2
    from blib2to3.pgen2.tokenize import tokenize_lines

    path = os.path.join(os.path.dirname(__file__), "..", "Lib", "email", "__init__.py")
    module_name = "email.__init__"  # for debugging
    with open(path, "rb") as fp:
        encoding, _ = tokenize_lines.detect_encoding(fp.readline)
        fp.seek(0)
        lines = fp.read().decode(encoding).split("\n")
    tokens: Sequence[Any] = []
    tokenize_lines.tokenize(lines, tokens.append, module_name)

# Generated at 2022-06-21 10:20:10.755844
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    x = g.token("x", "x")
    y = g.token("y", "y")
    e = g.symbol("e", g.dfa([0], [(y, 0, 1)]))
    g.start = "e"
    p = Parser(g)
    p.setup()
    p.addtoken(x, "x", (1, 0))
    assert p.stack == [(g.dfas["e"], 0, ("e", None, (1, 0), [("x", "x", (1, 0), None)])),
                       (g.dfas["e"], 1, ("e", None, (1, 0), []))]