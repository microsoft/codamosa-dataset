

# Generated at 2022-06-21 10:10:25.819329
# Unit test for method shift of class Parser
def test_Parser_shift():
    import tempfile
    from . import driver, grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()

    filename = "foobar"
    # A file with no content at all
    with tempfile.TemporaryFile() as f:
        t = driver.Driver(g, convert=lam_sub, log = None)
        t.set_sreader(filename, f, encoding="ascii")
        assert p.addtoken(token.ENCODING, "ascii", (0, 0)) is True
        assert p.rootnode.children == []

    # A file with one comment
    with tempfile.TemporaryFile() as f:
        s = " #\n"
        f.write(s)
        f.seek(0)

# Generated at 2022-06-21 10:10:29.542592
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError(None, None, None, None)
    assert e.msg is None
    assert e.type is None
    assert e.value is None
    assert e.context is None

# Generated at 2022-06-21 10:10:40.459087
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver

    tokens = [
        (token.NAME, "x", (1, 0)),
        (token.NEWLINE, "\n", (1, 2)),
        (token.NAME, "y", (2, 0)),
        (token.NEWLINE, "\n", (2, 2)),
        (token.NAME, "x", (3, 0)),
        (token.NEWLINE, "\n", (3, 2)),
        (token.NAME, "y", (4, 0)),
        (token.NEWLINE, "\n", (4, 2)),
    ]
    p = driver.Parser(driver.my_grammar)
    p.setup()
    results = {}  # type: Results
    for t, v, c in tokens:
        p.addtoken(t, v, c)
    assert results == {}



# Generated at 2022-06-21 10:10:41.895037
# Unit test for constructor of class ParseError
def test_ParseError():
    # -- this function intentionally left blank --
    """Tests for ParseError."""

# Generated at 2022-06-21 10:10:46.552976
# Unit test for constructor of class Parser
def test_Parser():
    from os import path
    from . import driver

    def convert(grammar, node):
        return node

    parser = Parser(driver.load_grammar("Grammar.txt"), convert)

    test_setup()
    test_addtoken()



# Generated at 2022-06-21 10:10:52.487837
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar
    # Compile the grammar so we can use it
    g = grammar.Grammar()
    g.compile(g.symbol2number, g.number2symbol, g.dfas, g.keywords)
    # Test the constructor
    p = Parser(g)
    assert p


# Generated at 2022-06-21 10:11:05.617789
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest

    class ParserTest(unittest.TestCase):
        def test_addtoken(self):
            grammar = Grammar(test_grammar)
            parser = Parser(grammar)
            parser.setup()
            self.assertEqual(parser.addtoken(NAME, "a", 1), False)
            self.assertEqual(parser.addtoken(OP, "+", 1), False)
            self.assertEqual(parser.addtoken(NAME, "b", 1), False)
            self.assertEqual(parser.addtoken(NEWLINE, "", 1), True)
            self.assertEqual(parser.rootnode.__class__.__name__, "Node")


# Generated at 2022-06-21 10:11:16.825340
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import driver

    # This parser is for the following grammar:
    # expr ::= expr '+' term
    #       | expr '-' term
    #       | term
    # term ::= term '*' factor
    #       | term '/' factor
    #       | factor
    # factor ::= '(' expr ')'
    #         | 'NUMBER'
    #         | 'NAME'

    # expr = 257
    # term = 258
    # factor = 259
    # plus = 260
    # minus = 261
    # times = 262
    # divide = 263
    # lparen = 264
    # rparen = 265
    # number = 266
    # name = 267

    g = grammar.Grammar()

# Generated at 2022-06-21 10:11:19.999797
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = Grammar()
    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NUMBER, '34', 2)



# Generated at 2022-06-21 10:11:30.873417
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.token
    grammar = Grammar(
        """
      aa = a? ':' b
      a = 'a' |
      b = 'b'
      """
    )
    p = Parser(grammar)
    p.setup()
    assert p.classify(blib2to3.pgen2.token.NAME, "a", 0) == 2
    assert p.classify(blib2to3.pgen2.token.NAME, "b", 0) == 5
    assert p.classify(blib2to3.pgen2.token.COLON, ":", 0) == 3

# Generated at 2022-06-21 10:11:46.136445
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammartest
    grammar = grammartest.simplegrammar()
    parser = Parser(grammar, lam_sub)
    parser.setup()
    tokens = [
        (grammar.tokens["x"], "x", None),
        (grammar.literals["2"], "2", None),
        (grammar.tokens["EQUAL"], "=", None),
        (grammar.literals["3"], "3", None),
    ]
    for tok, value, context in tokens:
        parser.addtoken(tok, value, context)
    assert parser.rootnode[0] == 59
    assert parser.rootnode[1] is None
    assert parser.rootnode[2] is None
    assert len(parser.rootnode[3]) == 3  # x, 2, 3


# Generated at 2022-06-21 10:11:58.064916
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class MyParser(Parser):
        def __init__(self, toktype: int, value: Text, context: Context) -> None:
            Parser.__init__(self, grammar.Grammar(self.grammar1, start=1))
            self.setup()
            assert self.addtoken(toktype, value, context)
            assert self.rootnode is not None
            #print self.rootnode,


# Generated at 2022-06-21 10:12:07.228390
# Unit test for method classify of class Parser
def test_Parser_classify():
    p = Parser(Grammar())
    # Check handling of unreserved words
    assert p.classify(token.NUMBER, '1', None) == 1
    assert p.classify(token.STRING, '"test"', None) == 3
    # Check handling of keywords (reserved words)
    assert p.classify(token.NAME, 'class', None) == 0
    # Check handling of reserved words masquerading as names
    assert p.classify(token.NAME, 'def', None) == 4
    # Check handling of invalid tokens
    try:
        p.classify(token.NEWLINE, None, None)
    except ParseError as e:
        assert e.msg == 'bad token'
        assert e.type == token.NEWLINE
        assert e.value is None
    else:
        raise Ass

# Generated at 2022-06-21 10:12:09.857959
# Unit test for method setup of class Parser
def test_Parser_setup():
    g = token.generate_grammar()
    p = Parser(g)
    p.setup()

# Generated at 2022-06-21 10:12:21.914196
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.driver
    grammar = blib2to3.pgen2.driver.load_grammar("Grammar")
    driver = blib2to3.pgen2.driver
    # line: int = 1
    p = Parser(grammar)
    p.setup(grammar.start)
    # line += 1
    # print(line, ":", end=' ')
    # print("p.addtoken(token.NAME, 'sum', '<stdin>')")
    p.addtoken(token.NAME, "sum", "<stdin>")
    # line += 1
    # print(line, ":", end=' ')
    # print("p.addtoken(token.LSQB, '', '<stdin>')")

# Generated at 2022-06-21 10:12:32.023174
# Unit test for method classify of class Parser
def test_Parser_classify():
    import lib2to3.pgen2.driver
    d = lib2to3.pgen2.driver
    p = Parser(d.load_grammar())
    testcases = [
        (token.NAME, "if", None),
        (token.NAME, "else", None),
        (token.NAME, "def", None),
        (token.NAME, "foo", None),
        (token.INDENT, None, None),
    ]
    for type, value, context in testcases:
        label = p.classify(type, value, context)
        print("%r -> %r" % ((type, value, context), label))
    print("used names:", " ".join(sorted(p.used_names)))



# Generated at 2022-06-21 10:12:36.178499
# Unit test for constructor of class Parser
def test_Parser():
    grammar = Grammar("")
    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NUMBER, "1", Context(1, 0))
    assert p.rootnode.children[0].value == "1"



# Generated at 2022-06-21 10:12:45.016957
# Unit test for method push of class Parser
def test_Parser_push():
    # Testing `push'
    #
    # This method is only called when a non-terminal is pushed on the stack.
    #
    # The method appends a tuple to self.stack.  This tuple is a (dfa, state,
    # node) tuple.  The node is a tuple that contains the type of the
    # non-terminal, a None value, and a list (node[3]) that is initially
    # empty.
    #
    # No conversion takes place, so the node is not modified.
    #
    # Here is an example demonstrating that the method works.

    from . import grammar

    g = grammar.Grammar(consts.test_grammar_file)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, 'def', (0, 0))


# Generated at 2022-06-21 10:12:53.410203
# Unit test for method classify of class Parser
def test_Parser_classify():
    g = Grammar(
        r"""
        G: 'g'
        H: 'h'
        J: 'j'
        I: 'i'
        K: 'k'
        """
    )
    p = Parser(g)
    p.setup()
    assert p.addtoken(token.OP, "g", None)
    assert p.addtoken(token.OP, "h", None)
    assert p.addtoken(token.OP, "i", None)
    assert p.addtoken(token.OP, "j", None)
    assert p.addtoken(token.OP, "k", None)

# Generated at 2022-06-21 10:13:05.706955
# Unit test for method push of class Parser
def test_Parser_push():
    from .grammar import Grammar
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    from io import BytesIO

    def convert(grammar: Grammar, node: RawNode) -> Optional[Leaf]:
        if node[0] == grammar.symbol2number["funcdef"]:
            return Leaf(type=token.NAME, value="f", context=node[2])
        return None

    data = b"def f(x):\n pass"
    stream = BytesIO(data)
    tokens = generate_tokens(stream.readline)
    tokens = list(tokens)

# Generated at 2022-06-21 10:13:17.135848
# Unit test for method setup of class Parser
def test_Parser_setup():
    """Verify that method setup of class Parser does not raise an exception."""
    from blib2to3.pgen2 import tokenize
    import StringIO
    p = Parser(Grammar(StringIO.StringIO(tokenize.grammar)))
    p.setup(start=0)

# The following is an automatically generated unit test for method addtoken of class Parser

# Generated at 2022-06-21 10:13:25.429757
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import io
    import sys
    import tokenize

    readline = getattr(io, "TextIOWrapper", file).readline
    g = Grammar([readline(sys.argv[1])], sys._getframe().f_code.co_name)

    t = tokenize.generate_tokens(readline)
    p = Parser(g)
    p.setup()
    for type, value, context,end in t:
        if p.addtoken(type, value, context):
            break


# Generated at 2022-06-21 10:13:34.873707
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar

    for debug in (0, 1):
        pg = driver.load_grammar(debug)
        p = Parser(pg)
        p.setup()

        s = "3 + 4"
        t = driver.gen_tokens(s)
        p.addtoken(token.NUMBER, "3", Context(None, s))
        p.addtoken(token.PLUS, "+", Context(None, s))
        p.addtoken(token.NUMBER, "4", Context(None, s))

        assert p.pop() is None

        assert len(p.stack) == 2
        assert p.stack[0][2] == (grammar.syms.file_input, None, None, [])

# Generated at 2022-06-21 10:13:46.927768
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    global ParseError
    class MockParseError(Exception):
        pass
    ParseError = MockParseError

    class MockRawNode(object):
        def __init__(self, type: int, value: Text, context: Context):
            self.type = type
            self.value = value
            self.context = context
            self.children = []
            self.n: int = 0
            self.i: int = 0

        def __getitem__(self, i: int) -> Any:
            return self.children[i]

        def __setitem__(self, i: int, item: Any) -> None:
            self.children[i] = item

        def __iter__(self) -> Sequence[Any]:
            return iter(self.children)



# Generated at 2022-06-21 10:13:51.286728
# Unit test for method setup of class Parser
def test_Parser_setup():
    """
    f = open('Python.asdl')
    g = Grammar()
    g.parse_file(f)
    d = Parser(g)
    d.setup()
    f.close()
    """


# Generated at 2022-06-21 10:13:55.459961
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver
    from . import grammar

    par = driver.Driver(grammar, convert=None)
    # Test for all tokens in Grammar instance
    for i in grammar.grammar.tokens.values():
        par.classify(i, None, None)

# Generated at 2022-06-21 10:14:07.294931
# Unit test for method push of class Parser
def test_Parser_push():
    class MockParser(Parser):
        def __init__(self, grammar, convert=None):
            self.push_called = False
            self.dfa, self.state, self.node = None, None, None
            self.type, self.newdfa, self.newstate, self.context = None, None, None, None
            super().__init__(grammar, convert)

        def push(self, type, newdfa, newstate, context):
            self.push_called = True
            self.dfa, self.state, self.node = self.stack[-1]
            self.type, self.newdfa, self.newstate, self.context = type, newdfa, newstate, context
            super().push(type, newdfa, newstate, context)


# Generated at 2022-06-21 10:14:15.849545
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    p = driver.Parser(Parser(driver.Grammar()))
    p.setup()

    # Nonterminal
    p.addtoken(token.NAME, "NAME", (1, 1))
    assert len(p.stack) == 2
    dfa, state, node = p.stack[-1]
    assert state == 0
    assert node == (1, None, (1, 1), [])

    # Terminal
    p.addtoken(token.NAME, "NAME", (2, 2))
    assert len(p.stack) == 2
    dfa, state, node = p.stack[-1]
    assert state == 1
    assert node == (1, None, (1, 1), [])
    dfa_states, dfa_first = dfa

# Generated at 2022-06-21 10:14:22.249180
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, tokenizer
    import io

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    t = tokenizer.tokenize(io.StringIO('x = y'))
    t.next()
    r = g.symbols['name']

    assert p.classify(t.type, t.string, (t.start, t.end)) == r



# Generated at 2022-06-21 10:14:27.584614
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("foo", 42, "bar", Context(None, (1, 2), (3, 4)))
    except ParseError as err:
        assert err.msg == "foo"
        assert err.type == 42
        assert err.value == "bar"
        assert err.context == Context(None, (1, 2), (3, 4))
    assert True

# Generated at 2022-06-21 10:15:00.714215
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.parse import tokenize_grammar
    from blib2to3.pgen2.grammar import Grammar, DEFAULT_VERSION
    from blib2to3.pygram import python_grammar
    from io import StringIO

    def gen_tokens(grammar):
        for type, value, _, _, _ in generate_tokens(StringIO(grammar).readline):
            # Ignore ENDMARKER tokens
            if type != 3:
                yield type, value, None

    grammar = python_grammar
    # Parse the grammar file and generate the tables
    dfa, labels, dfas, start = tokenize_grammar(grammar)

# Generated at 2022-06-21 10:15:12.320743
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import tokenize

    test_s = """a = '''\n"""

    # Test the workaround for issue #12802.
    driver._compile_pgen(test_s)

    with open("Parser/Python.asdl", "r") as f:
        grammar = f.read()
    grammar = driver.pgen(grammar)

    # Fake a driver.Options instance
    class Options:
        def __init__(self) -> None:
            self.debug_parser = False
            self.dump_grammar = False
            self.dump_tree = False
            self.output_dir = None
            self.generate_pickle = False
            self.output_dir = None
            self.generate_pickle = False
            self.pickle_protocol = False

# Generated at 2022-06-21 10:15:22.701275
# Unit test for method pop of class Parser
def test_Parser_pop():
    def f(n):
        # type: (RawNode) -> List[Context]
        return [x.context for x in n[-1]]
    n = (0, None, None, [])
    p = Parser(None, f)
    p.stack = [(None, 1, (0, None, 1, []))]
    p.stack[-1][-1][-1].append(2)
    p.stack[-1][-1][-1].append(3)
    p.stack.append((None, 2, (1, None, 4, [])))
    p.stack[-1][-1][-1].append(5)
    p.stack.append((None, 2, (2, None, 6, [])))
    p.stack[-1][-1][-1].append(7)


# Generated at 2022-06-21 10:15:25.585809
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = Grammar()
    myParser = Parser(grammar)
    myParser.setup()
    myParser.shift(0, None, 5, None)
    myParser.shift(0, None, 15, None)



# Generated at 2022-06-21 10:15:35.078632
# Unit test for method pop of class Parser

# Generated at 2022-06-21 10:15:46.260148
# Unit test for method setup of class Parser
def test_Parser_setup():
    # pgen module is needed to generate Parser.
    import re
    import pgen2.pgen

    # A simple grammar.
    grammar: Grammar = pgen2.pgen.parse_grammar(
        """
        start: anything*
        anything: 'a' | 'b' | 'c'
        """
    )
    parser = Parser(grammar)
    parser.setup()

    # Compare stack with expected values.
    stackentry = (
        grammar.dfas[grammar.start],
        0,
        (grammar.start, None, None, []),
    )
    assert parser.stack == [stackentry]

    # Compare rootnode with expected value.
    assert parser.rootnode is None



# Generated at 2022-06-21 10:15:56.735738
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError.__doc__ is not None
    # Test empty instance
    try:
        raise ParseError("msg", None, None, None)
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type is None
        assert e.value is None
        assert e.context is None
    # Test instance with non-empty arguments
    try:
        raise ParseError("msg3", 123, "tok", (1, 2))
    except ParseError as e:
        assert e.msg == "msg3"
        assert e.type == 123
        assert e.value == "tok"
        assert e.context == (1, 2)
    # Test instance with non-empty arguments

# Generated at 2022-06-21 10:16:08.403582
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .driver import Driver
    token_stream = [
        (0, None, None),  # 'S',
        (1, 'a', None),  # 'A'
        (2, None, None),  # 'S',
        (3, 'b', None),  # 'B'
        (4, None, None),  # 'S',
        (5, 'c', None),  # 'C'
        (6, None, None),  # 'S',
        (7, 'd', None),  # 'D'
        (8, 'e', None),  # 'E'
        (9, None, None),  # '$'
    ]

    # Customized converter that appends nonterminals to the list of children

# Generated at 2022-06-21 10:16:19.587752
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver, token

    class T(object):
        """Helper class for test"""

        class Result(object):
            """Helper class for test"""

            def __init__(self) -> None:
                self.root: Optional[NL] = None

        result = Result()

        def __init__(self) -> None:
            self.parser = Parser(driver.Grammar())
            self.parser.setup()

        def addtoken(self, type: int, value: Optional[Text], context: Context) -> None:
            done = self.parser.addtoken(type, value, context)
            if done:
                assert self.result.root is None
                self.result.root = self.parser.rootnode

    # Try various input sequences
    driver.DEBUG = True
    test = T()
    test.addtoken

# Generated at 2022-06-21 10:16:22.524100
# Unit test for method setup of class Parser
def test_Parser_setup():
    with Parser(Grammar()) as p:
        assert p.stack == [(
            ([
                [(0, 0)]
            ], 0),
            0,
            (256, None, None, [])
        )]


# Generated at 2022-06-21 10:16:50.275192
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver, grammar

    g = grammar.parse_grammar('''
    start: NAME "=" test
    ''')

    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, 'x', None)
    p.addtoken(token.EQUAL, '=', None)
    p.addtoken(token.NAME, 'y', None)
    root = p.rootnode
    assert root.type == g.symbol2number['start']
    assert root.children[0].value == 'x'
    assert root.children[1].value == '='
    assert root.children[2].value == 'y'


# Generated at 2022-06-21 10:16:59.245731
# Unit test for method shift of class Parser
def test_Parser_shift():
    print("Unit test for method shift of class Parser")


# Generated at 2022-06-21 10:17:06.454847
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar, tokenize, driver
    for filename in ["Grammar.txt", "Grammar/Grammar"]:
        g = grammar.grammar_from_file(filename)
        t = tokenize.tokenize_lines((open(filename, "rU").read(), "Grammar"))
        p = Parser(g, lam_sub)
        p.setup()
        for type, value, context in t:
            p.addtoken(type, value, context)
        root = p.rootnode
        driver.totuple(root)
        root = p.rootnode
        driver.totree(root)

# Generated at 2022-06-21 10:17:16.917860
# Unit test for method push of class Parser
def test_Parser_push():
    import sys
    import unittest

    class TestParser(unittest.TestCase):

        def setUp(self):
            import blib2to3.pgen2.grammar as grammar
            self.loader = grammar.Loader()
            self.grammar = self.loader.load_grammar(
                grammar.DEFAULT_GRAMMAR_FILE
            )
            self.parser = Parser(self.grammar)

        def test_push(self):
            self.parser.setup()
            self.parser.addtoken(4, "def", Context(1, 0))
            # "def" is shifted, then "NAME" is pushed, and "foo" is shifted
            self.parser.addtoken(1, "foo", Context(1, 4))

# Generated at 2022-06-21 10:17:28.117684
# Unit test for method pop of class Parser
def test_Parser_pop():
    # test successful execution of method pop
    test_input = token.TokenInfo(type=1, string='test', start=(0, 0), prefix='test')
    test_context = Context(test_input, (1, 1))
    test_tree_node = Node(type=1, children=None, context=test_context)
    test_requirement = (1, None, test_context, [test_tree_node])
    test_P = Parser(Grammar(start=1), convert=lam_sub)
    test_P.setup(start=1)
    dfa_1 = [[(2, 1)]]
    dfa_2 = [(1, 1), (2, 1)]

# Generated at 2022-06-21 10:17:28.897057
# Unit test for method push of class Parser
def test_Parser_push():
    assert 0, "Unimplemented!"

# Generated at 2022-06-21 10:17:41.081189
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import parsetok

    def test(text, expected):
        pt = parsetok.Tokenizer()
        try:
            pt.set_input(text)
            p = Parser(Grammar(parsetok.grammar, parsetok.keyword_tokens))
            p.setup()
            while True:
                t = pt.get_token()
                if p.addtoken(t.type, t.string, t.context):
                    break
        except ParseError as e:
            expected = expected[0]
            if e.msg != expected.msg:
                raise AssertionError("expected:" + expected.msg + "but got: " + e.msg)
        else:
            raise AssertionError("expected a ParseError, but got none")

    # Unit tests for method pop of

# Generated at 2022-06-21 10:17:51.697730
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import os
    import unittest
    import pgen2
    import six

    sys.path.insert(0, os.path.abspath('lib2to3/Grammar.txt'))
    sys.path.insert(0, os.path.abspath('lib2to3/PatternGrammar.txt'))

    class ParserPopTests(unittest.TestCase):

        def setUp(self) -> None:
            self.g = pgen2.tokenize.generate_grammar()
            self.pg = pgen2.parse.PatternGrammar()  # type: Any
            self.p = pgen2.parse.Parser(self.pg)
            self.p.setup(self.pg.start_symbol)


# Generated at 2022-06-21 10:18:02.302795
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import blib2to3.pgen2.token as token
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pytree import Leaf
    from .driver import Driver
    from . import pgen2_parse
    

# Generated at 2022-06-21 10:18:05.985798
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import token

    gr = grammar.grammar
    parser = Parser(gr)
    parser.setup()
    parser.shift(token.NAME, 'test', 1, None)



# Generated at 2022-06-21 10:18:39.531892
# Unit test for method setup of class Parser
def test_Parser_setup():
	g = Grammar('grammar', 'empty_grammar')
	no_convert = None
	# No start symbol, thus no symbol table
	p = Parser(g, no_convert)
	assert p.stack == []
	assert p.rootnode == None
	# 'empty' is the start symbol of g
	g = Grammar.read_grammar('empty_grammar')
	p = Parser(g, no_convert)
	# The symbolic name 'empty' is mapped to a number,
	# the symbol number of 'empty'
	p.setup(p.grammar.symbol2number['empty'])
	assert p.stack[0][0][1] == p.grammar.symbol2number['empty']
	assert p.stack[0][1] == 0

# Generated at 2022-06-21 10:18:44.180677
# Unit test for method classify of class Parser
def test_Parser_classify():
    g = get_pickle("Grammar.txt")
    p = Parser(g)

    assert p.classify(token.NAME, 'name', Context(0, 0)) == p.grammar.labels.index(
        (token.NAME, None)
    )
    assert p.classify(token.NUMBER, '42', Context(0, 0)) == p.grammar.labels.index(
        (token.NUMBER, None)
    )

# Generated at 2022-06-21 10:18:46.613990
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver, grammar

    p = Parser(grammar.Grammar())
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))


# Generated at 2022-06-21 10:18:53.165809
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Test to see that classify() finds both tokens and labels
    g1 = Grammar(grammar1)
    p1 = Parser(g1)
    p1.setup()
    # First check a token
    ilabel = p1.classify(token.NUMBER, "1", None)
    assert ilabel == 3
    # Then check a label
    ilabel = p1.classify(token.NAME, "x", None)
    assert ilabel == 5



# Generated at 2022-06-21 10:19:02.861296
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, token

    g = grammar.Grammar()
    g.start = 256
    g.dfas = {256: ([[(0, 2), (1, 263), (5, 264)],
                     [(3, 268), (4, 269)],
                     [],
                     [(1, 262)],
                     [(2, 270)]],
                    {2: 0, 3: 0, 4: 1, 5: 1})}

# Generated at 2022-06-21 10:19:10.831395
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver

    g = driver.load_grammar("Python.g")  # Blib's Python.g is slightly different than CPython's
    parser = Parser(g)
    parser.setup()
    parser.addtoken(token.LPAR, None, Context(1, 0))
    parser.addtoken(token.NAME, "a", Context(1, 0))
    parser.addtoken(token.COMMA, None, Context(1, 0))
    parser.addtoken(token.NEWLINE, None, Context(1, 0))
    parser.addtoken(token.NAME, "b", Context(1, 0))
    parser.addtoken(token.RPAR, None, Context(1, 0))
    assert parser.rootnode.type == symbol.testlist_gexp

# Generated at 2022-06-21 10:19:19.024090
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .tokenize import generate_tokens, untokenize

    import io
    import unittest
    import unittest.mock

    v = """\
"""
    p = Parser(grammar=blib2to3.pgen2.driver.load_grammar("Python3"))
    p.setup()
    tokens = generate_tokens(io.StringIO(v).readline)
    tok = untokenize(tokens)
    for type, token, start, end, line in tokens:
        context = Context(start, end, line)
        p.addtoken(type, token, context)

    v = """\
"""
    p = Parser(grammar=blib2to3.pgen2.driver.load_grammar("Python3"))
    p.setup()

# Generated at 2022-06-21 10:19:21.933686
# Unit test for constructor of class Parser
def test_Parser():
    grammar = Grammar()
    parser = Parser(grammar)
    assert parser.grammar is grammar
    assert parser.rootnode is None


# Generated at 2022-06-21 10:19:32.158876
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Build a simple grammar, then set up a parser
    gr = Grammar(start="start",
                 symbols=["start", "a", "b"],
                 terminals=["a", "b"])
    pa = Parser(gr)
    pa.setup()

    # Shift a simple token
    pa.shift(0, "a", 0, "")

    # Make sure the results match expectations
    assert pa.stack == [(gr.dfas["start"], 0, (0, "a", "", None))]

    # Shift a second token
    pa.shift(1, "b", 0, "")

    # Make sure the results match expectations

# Generated at 2022-06-21 10:19:38.086903
# Unit test for method push of class Parser