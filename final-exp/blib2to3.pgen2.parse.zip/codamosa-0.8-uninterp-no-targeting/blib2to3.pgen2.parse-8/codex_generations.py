

# Generated at 2022-06-21 10:10:24.842955
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    gr = grammar.Grammar()
    gr.start = 1
    gr.add_production(1, [2], "PASS")
    gr.add_production(2, [3, 4], "PASS")
    gr.add_production(4, [5], "PASS")
    gr.add_production(4, [], "PASS")
    gr.add_production(5, [], "PASS")
    gr.add_production(5, [5], "PASS")
    gr.add_production(3, [3, 6], "PASS")
    gr.add_production(3, [6], "PASS")
    gr.add_production(6, [7], "PASS")
    gr.add_production(6, [8], "PASS")

# Generated at 2022-06-21 10:10:32.203797
# Unit test for method classify of class Parser
def test_Parser_classify():
    print("test_Parser_classify()")

    class mock_Grammar:
        tokens: Dict[int, int]
        keywords: Dict[str, int]

    class mock_Context:
        pass

    grammar = mock_Grammar()
    grammar.tokens = {1: 1, 2: 2}
    grammar.keywords = {'abc': 3, 'def': 4}
    context = mock_Context()

    parser = Parser(grammar)
    parser.setup()

    type = 1
    value = "abcd"
    ilabel = parser.classify(type, value, context)
    assert ilabel == 1

    type = 2
    ilabel = parser.classify(type, value, context)
    assert ilabel == 2

    type = token.NAME
    value = 'abc'

# Generated at 2022-06-21 10:10:36.328705
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('foo', token.NAME, 'bar', None)
    except ParseError as err:
        assert err.msg == 'foo'
        assert err.type == token.NAME
        assert err.value == 'bar'
        assert err.context is None
    else:
        raise RuntimeError('ParseError exception not raised')

# Generated at 2022-06-21 10:10:38.101352
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar  # type: ignore

    p = Parser(grammar.grammar)
    p.setup()



# Generated at 2022-06-21 10:10:42.649963
# Unit test for method push of class Parser
def test_Parser_push():
    g = Grammar()
    g.symbol2number = {}
    g.number2symbol = {}
    g.keywords = {}
    g.start = 1
    g.tokens = {}
    g.labels = []
    g.dfas = {}
    p = Parser(g)
    p.stack = []
    p.push(1, (2, 3), 4, 5)

    assert p.stack == [(2, 3, (1, None, 5, []))]

# Generated at 2022-06-21 10:10:47.915591
# Unit test for function lam_sub
def test_lam_sub():
    t = (1, 3, 4, [None, None])
    assert lam_sub(None, t) == Node(type=1, children=[], context=4)
    t = (2, 3, 4, None)
    assert lam_sub(None, t) == Leaf(1, value=3, context=4)

# Generated at 2022-06-21 10:10:51.895867
# Unit test for method push of class Parser
def test_Parser_push():
    # Create parser engine
    #grammar = parse_grammar(open("Python.gram"))
    #grammar = parse_grammar(open("Python2.gram"))
    grammar = parse_grammar(open("Python3.gram"))
    p = Parser(grammar)
    p.setup()

    # Push a nonterminal (stmt)
    p.push(syms.stmt, grammar.dfas[syms.stmt], 0, None)
    assert len(p.stack) == 3

    # Push a nonterminal (expr_stmt)
    p.push(syms.expr_stmt, grammar.dfas[syms.expr_stmt], 0, None)
    assert len(p.stack) == 5

    # Pop a nonterminal (expr_stmt)
    p.pop()


# Generated at 2022-06-21 10:10:57.601728
# Unit test for constructor of class Parser
def test_Parser():
    grammar = Grammar(grammar1)
    p = Parser(grammar)
    assert p.grammar is grammar
    assert p.convert is lam_sub


# Generated at 2022-06-21 10:11:07.513755
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import io
    import unittest
    import os

    # Get the grammar
    path = os.path.dirname(__file__)
    sys.path.insert(0, path)
    import pygram
    sys.path.pop(0)

    with io.open(path + "/python27.gram") as f:
        g = pygram.python_grammar()

    p = Parser(g)
    p.setup()
    state = 0
    while True:
        t = g.token()
        if t == "LAST":
            break
        for tok in g.tokens[t]:
            try:
                state = p.addtoken(tok, t, Context(1, 1))
            except ParseError:
                break
        if state:
            break

# Generated at 2022-06-21 10:11:14.165206
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", 1, "value", (2, 3))
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == 1
        assert e.value == "value"
        assert e.context == (2, 3)
    else:
        assert 0, "ParseError not raised"


# Generated at 2022-06-21 10:11:21.138063
# Unit test for constructor of class Parser
def test_Parser():
    grammar = Grammar()
    parser = Parser(grammar)


# Generated at 2022-06-21 10:11:31.010206
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Check the classify method of the Parser class"""
    input_string: Text = "print(hello)"

    from . import parse
    from . import simple_grammar

    g = simple_grammar.grammar
    p = parse.Parser(g)
    p.setup()

    test_list = [
        (token.NAME, "print", (1, 0)),
        (token.OP, "(", (1, 5)),
        (token.NAME, "hello", (1, 6)),
        (token.OP, ")", (1, 11)),
    ]

    for token in test_list:
        type, value, context = token
        ilabel = p.classify(type, value, context)
        assert ilabel == g.tokens[type]

# Generated at 2022-06-21 10:11:38.865197
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(None)
    p.shift(1, "a", 2, object())
    try:
        p.shift(1, None, 2, object())
    except AssertionError:
        pass
    else:
        raise Exception("Failed.")
    try:
        p.shift(1, "a", 2, None)
    except AssertionError:
        pass
    else:
        raise Exception("Failed.")

# Generated at 2022-06-21 10:11:47.176338
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = Grammar()
    parser = Parser(grammar)
    assert parser.classify(token.NAME, "NAME", None) == 0
    assert parser.classify(token.NUMBER, "NUMBER", None) == 1
    assert parser.classify(token.STRING, "STRING", None) == 2
    assert parser.classify(token.NEWLINE, "NEWLINE", None) == 3
    assert parser.classify(token.INDENT, "INDENT", None) == 4
    assert parser.classify(token.DEDENT, "DEDENT", None) == 5
    assert parser.classify(token.ENDMARKER, "ENDMARKER", None) == 6
    assert parser.classify(token.ENCODING, "ENCODING", None) == 7

# Generated at 2022-06-21 10:11:58.757056
# Unit test for method classify of class Parser

# Generated at 2022-06-21 10:12:07.800834
# Unit test for method pop of class Parser
def test_Parser_pop():
    class mock_grammar:
        def __init__(self):
            self.dfas = {}
            self.labels = {}
            self.keywords = {}
            self.tokens = {}
            self.start = 1
        def convert(self, node):
            return node
    class mock_node:
        def __init__(self):
            self.append = False
    class mock_nodeA:
        def __init__(self):
            self.children = []
    class mock_context:
        def __init__(self):
            pass
    class mock_dfa:
        def __init__(self):
            self.states = {}
            self.first = {}
    mockdfa = mock_dfa()

# Generated at 2022-06-21 10:12:19.978150
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.parse as parse
    import blib2to3.pgen2.driver as driver
    grammar = driver.load_grammar("Python.gram")
    p = Parser(grammar)
    p.setup()
    p.addtoken(1, 'def', (1, 0))
    p.addtoken(0, 'hello', (1, 0))
    p.addtoken(4, ':', (1, 0))

# Generated at 2022-06-21 10:12:31.659818
# Unit test for function lam_sub
def test_lam_sub():
    import pprint

    class MyGrammar(Grammar):
        pass

    g = MyGrammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "NAME", Context(1, 1))
    p.addtoken(token.OP, "OP", Context(1, 1))
    p.addtoken(token.NAME, "NAME", Context(1, 1))
    p.addtoken(token.NEWLINE, "NEWLINE", Context(1, 1))
    p.addtoken(token.NAME, "NAME", Context(1, 1))
    p.addtoken(token.OP, "OP", Context(1, 1))
    p.addtoken(token.NAME, "NAME", Context(1, 1))

# Generated at 2022-06-21 10:12:39.170829
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser = Parser(Grammar())
    assert parser.stack == []
    parser.pop()
    assert parser.stack == []
    node = (0, None, None, [])
    parser.stack = [(0, 0, node)]
    parser.pop()
    assert parser.stack == []
    node = (0, None, None, [])
    parser.stack = [(0, 0, node), (0, 1, node)]
    parser.pop()
    assert parser.stack == [(0, 0, node)]


# Generated at 2022-06-21 10:12:46.680745
# Unit test for function lam_sub
def test_lam_sub():
    from .grammar import Grammar
    testgrammar = Grammar()
    node = (1, None, None, [])
    assert lam_sub(testgrammar, node) == (1, None, None, [])
    node = (1, None, None, None)
    assert lam_sub(testgrammar, node) == (1, None, None, [])
    node = (1, "name", None, None)
    assert lam_sub(testgrammar, node) == (1, "name", None, None)

# Generated at 2022-06-21 10:13:08.562151
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Test to verify that classify can accept any token name or value
    # in the token module.  Looping through the entire token list will
    # ensure that classify can deal with all tokens.  We use the
    # classify method instead of the addtoken method to ensure this
    # test is relevant to classify.
    grammar = Grammar()
    parser = Parser(grammar=grammar)

    # Setup parser prior to parsing
    parser.setup()

    # Iterate through all tokens

# Generated at 2022-06-21 10:13:16.278256
# Unit test for method classify of class Parser
def test_Parser_classify():
    from collections import defaultdict
    import tokenize

    def parser_test_classify(code: Text, expected_used_names: Sequence[str]) -> None:
        parser = Parser(Grammar())
        parser.setup()
        lines = code.split('\n')
        tokens = tokenize.generate_tokens(iter(lines).__next__)
        for token_type, token_string, (_, token_line), _, _ in tokens:
            parser.addtoken(token_type, token_string,
                            Context(None, token_line))
        assert parser.used_names == set(expected_used_names)
    # end def parser_test_classify
    parser_test_classify('foo()', ['foo'])

# Generated at 2022-06-21 10:13:25.328853
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys, os
    import pprint
    from . import driver
    from . import grammar
    # Location of grammar.py / grammar.pyc
    test_dir = os.path.dirname(sys.argv[0])
    sys.path.insert(0, os.path.join(test_dir, os.path.pardir))
    a = Parser(grammar.grammar)
    a.setup()
    for _ in driver.run("0"):
        a.addtoken(_, None, None)
    pprint.pprint(a.rootnode)


# Generated at 2022-06-21 10:13:34.799241
# Unit test for method shift of class Parser
def test_Parser_shift():
    def p(type, value, context):
        return (type, value, context)

    def np(type, value, context):
        return Node(type=type, children=[], context=context)


# Generated at 2022-06-21 10:13:46.881079
# Unit test for method pop of class Parser
def test_Parser_pop():
    class TestGrammar(Grammar):
        def __init__(self):
            super(TestGrammar, self).__init__()
            self.tokens: Dict[int, int] = {}
            self.labels: Dict[int, Tuple[int, Any]] = {}
            self.dfas: Dict[int, DFAS] = {
                16: ([[(4, 1)], [(0, 1)], [(2, 2)], [], [(0, 2)], [(3, 1)], [(0, 2)]], {0: 0, 1: 1, 2: 2})
            }
            self.keywords: Dict['Text', int] = {}
            self.start = 16
    class TestNode(Node):
        def __init__(self, type, children, context):
            super

# Generated at 2022-06-21 10:13:48.951407
# Unit test for method shift of class Parser
def test_Parser_shift():
    assert Parser.__dict__['shift'].__doc__


# Generated at 2022-06-21 10:13:49.653689
# Unit test for method pop of class Parser
def test_Parser_pop():
    pass

# Generated at 2022-06-21 10:13:52.039371
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g, None)
    p.setup()

# Generated at 2022-06-21 10:14:00.853358
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2.token import Token

    def convert(grammar, node):
        if node[0] in grammar.label2str:
            return node[0]
        return None

    g = Grammar()
    g.start = "start"
    g.add_production("start", ["NAME", "OTHER"])
    g.add_production("OTHER", ["NAME"])
    g.build()
    assert g.start == "start"
    assert g.dfas["start"] == ([[(3, 1), (1, 1)], [(0, 2)]], {0: 1, 1: 2, 2: 0})
    assert g.labels == [None, ("NAME", None), ("OTHER", None)]
    assert g.keywords

# Generated at 2022-06-21 10:14:04.384322
# Unit test for constructor of class Parser
def test_Parser():
    from . import pgen2

    gr = pgen2.grammar()
    pa = Parser(gr)


# Generated at 2022-06-21 10:14:22.985972
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar()
    node = (0, None, None, [(1, 'x', None, None)])
    node = lam_sub(grammar, node)
    assert isinstance(node, Node)
    assert len(node.children) == 1
    assert isinstance(node.children[0], Leaf)
    assert node.children[0].value == 'x'


if __name__ == "__main__":
    import driver
    driver.main("--tree-compare", "--tabcheck", "--perfect-tree", "--runtests", "--tokens")

# Generated at 2022-06-21 10:14:33.974690
# Unit test for function lam_sub
def test_lam_sub():
    from .pgen import write_grammar

    # Local imports
    from . import token

    # Helper functions
    def get_tokens(s: Text) -> Sequence[Tuple[Text, int, Text]]:
        from blib2to3.pgen2.tokenize import generate_tokens

        gen = generate_tokens(lambda x=iter(s.splitlines(keepends=True)): next(x))
        return [(e[1], e[0], e[2]) for e in gen]

    def make_syntax_tree(s: Text) -> Node:
        from blib2to3.pgen2 import driver, tokenize

        tokens = get_tokens(s)
        st = driver.parse_tokens(tokens)[0]
        return st


# Generated at 2022-06-21 10:14:35.868913
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    p = Parser(grammar.grammar, None)
    p.setup()
    ilabel = p.classify(token.NAME, "bla", None)
    assert ilabel == grammar.symbol.simple_stmt

# Generated at 2022-06-21 10:14:46.672410
# Unit test for method push of class Parser
def test_Parser_push():
    filename = "2to3/Grammar.txt"
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.pgen as pgen
    import blib2to3.pytree as pytree
    g = grammar.grammar_from_file(filename)
    args = pgen.parse_grammar(g, filename)
    if args.start is None:
        args.start = g.start
    p = pgen.make_pgen(g, args)
    p.setup()
    print(p.addtoken(token.INDENT, "    ", pytree.build_context(0, 0)))
    print(p.addtoken(token.INDENT, "    ", pytree.build_context(0, 0)))

# Generated at 2022-06-21 10:14:54.194324
# Unit test for method shift of class Parser
def test_Parser_shift():
    # pylint: disable=W0603
    import ast
    import blib2to3.pgen2.parse
    from blib2to3.pgen2.tokenize import tokenize

    def verbose(self, *args: Any) -> None:
        # Unit test for method shift of class blib2to3.pgen2.parse.Parser
        global VerboseArgs
        VerboseArgs = args

    blib2to3.pgen2.parse.Parser.verbose = verbose

    def parse_string(string: str) -> ast.mod:
        """Parse the given string.

        This is the main entry point for testing, called by the unit
        test.

        """
        global VerboseArgs
        VerboseArgs = ()
        grammar = blib2to3.pgen2.parse.load_gram

# Generated at 2022-06-21 10:15:02.853078
# Unit test for constructor of class Parser

# Generated at 2022-06-21 10:15:07.572406
# Unit test for constructor of class ParseError
def test_ParseError():
    context = Context(None, 0, 0, 0)
    p = ParseError("msg", token.NAME, "value", context)
    assert p.msg == "msg"
    assert p.type == token.NAME
    assert p.value == "value"
    assert p.context == context

# Generated at 2022-06-21 10:15:19.278943
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest
    import io
    import sys
    import blib2to3.pgen2.token as token
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.pgen as pgen
    from .blib2to3 import pygram

    stream = io.StringIO()
    pgen.generate_grammar(stream)
    pgast = pygram.parse_grammar(stream.getvalue())
    dfa_grammar = pgast.todfa()
    dfa_grammar.compute_nullability()
    dfa_grammar.compute_first()
    dfa_grammar.compute_follow()
    dfa_grammar.check_well_formedness()
    dfa_grammar.compute_dfas

# Generated at 2022-06-21 10:15:32.255809
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .pgen2.tokenize import generate_tokens, untokenize
    from .pgen2.grammar import Grammar
    from .tokenizer import group
    from .tokenize import detect_encoding
    from .pytree import Leaf

    grammar = Grammar()
    with open('grammar_file', 'rb') as f:
        grammar.parse(f)

    # Test with a given source
    source = 'a + b'
    p = Parser(grammar)
    p.setup()
    tokengen = generate_tokens(source.splitlines)
    for fivetuple in tokengen:
        p.addtoken(*fivetuple)
    root = p.rootnode
    print(root)

    # Test with a given source
    source = 'a + b'

# Generated at 2022-06-21 10:15:37.643756
# Unit test for method pop of class Parser
def test_Parser_pop():
    # [2, 3] + [4, 5] => [2, 3, 4, 5]
    def convert(grammar, node):
        if node is not None:
            return Node(type=node[0], children=node[3], context=node[2])

    p = Parser(Grammar(), convert)
    p.setup()
    p.addtoken(1, '1', None)
    p.addtoken(1, '+', None)
    p.addtoken(1, '2', None)
    assert p.rootnode.children == [Leaf(1, '1'), Leaf(1, '+'), Leaf(1, '2')]



# Generated at 2022-06-21 10:16:10.824118
# Unit test for method pop of class Parser
def test_Parser_pop():

    class MyParser(Parser):
        def convert(self: Any, grammar: Any, node: RawNode) -> NL:
            if node[0] == 1:
                return Node(type=1, children=None, context=None)
            else:
                return Node(type=2, children=node[3], context=None)

    grammar = Grammar()
    grammar.labels = {
        0: (1, None),
        1: (2, None),
        2: (4, None),
        3: (4, None),
        4: (5, None),
        5: (token.NEWLINE, None),
    }

# Generated at 2022-06-21 10:16:21.080439
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import _frozen_importlib
    import _frozen_importlib_external
    g = _frozen_importlib.BuiltinImporter.grammar
    p = Parser(g, None)
    p.setup()
    p.addtoken(token.NAME, "class", Context(1, 0, ""))
    p.addtoken(token.NAME, "Foo", Context(1, 6, ""))
    p.addtoken(token.OP, "(", Context(1, 9, ""))
    p.addtoken(token.NAME, "object", Context(1, 10, ""))
    p.addtoken(token.OP, ")", Context(1, 16, ""))
    p.addtoken(token.OP, ":", Context(1, 17, ""))

# Generated at 2022-06-21 10:16:26.754399
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver

    def sub(grammar, node):
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    g = driver.load_grammar("Grammar/Grammar")
    parser = Parser(g, sub)
    parser.setup(g.start)
    assert parser is not None
    assert parser.rootnode is None

# Generated at 2022-06-21 10:16:35.573741
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup(start="s")
    for type, value, context in [("a", "1", 0), ("b", "2", 0), ("c", "3", 0)]:
        assert not p.addtoken(token.NUMBER, value, context), "addtoken should return False"
    assert p.rootnode is not None, "rootnode should store a list of the tokens"
    assert p.rootnode == ("s", None, None, [("a", "1", 0, None), ("b", "2", 0, None)]), "rootnode should store a list of the tokens"

    # Another test, with a parser that converts to a syntax tree
    g = grammar.Grammar()


# Generated at 2022-06-21 10:16:48.413758
# Unit test for function lam_sub
def test_lam_sub():
    import unittest
    from blib2to3.pgen2 import grammar

    class TestCase(unittest.TestCase):
        def runTest(self):
            grammar = grammar.grammar
            self.assertEqual(
                lam_sub(grammar, (1, None, None, [])),
                None
            )
            self.assertEqual(
                lam_sub(grammar, (1, None, None, [1])),
                Leaf(type=1, value=None, context=None)
            )
            self.assertEqual(
                lam_sub(grammar, (1, None, (5, 0), [1])),
                Leaf(type=1, value=None, context=(5, 0))
            )

# Generated at 2022-06-21 10:16:54.497198
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, driver
    p = Parser(grammar.grammar)
    p.setup(start=driver.start)
    # The following loop causes fail on purpose.
    # The purpose is to check that ParseError is raised.
    # Note: the integers in the sequence are token.NUMBER values
    for i in [0, 0, 1]:
        p.addtoken(i, 'i', (1, 0))  # should raise ParseError

# Generated at 2022-06-21 10:16:57.400356
# Unit test for function lam_sub
def test_lam_sub():
    assert lam_sub(None, (0, "", None, None)) is None
    assert lam_sub(None, (0, "", None, [])) == Node(type=0, children=[])

# Generated at 2022-06-21 10:17:06.926494
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver

    def p_test_shift(p):
        """expr : ID"""
        p[0] = p[1]

    def t_ID(t):
        r"[a-zA-Z_][a-zA-Z0-9_]*"
        return t

    def t_error(t):
        t.type = "ILLEGAL_TOKEN"
    driver.ParserDriver.tokenizer_class = driver.PythonTokenizer
    ParserDriver = driver.build_parser(p_test_shift, t_error=t_error)
    parser = ParserDriver()
    parser.setup()

    name = "test_name"
    type = token.NAME
    context = Context(offset=None, lineno=None)

# Generated at 2022-06-21 10:17:11.843229
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test message", "test type", "test value", "test context")
    except ParseError as exc:
        assert exc.msg == "test message"
        assert exc.type == "test type"
        assert exc.value == "test value"
        assert exc.context == "test context"

# Generated at 2022-06-21 10:17:18.969662
# Unit test for method classify of class Parser
def test_Parser_classify():
    from ..pgen2 import driver
    import os

    p = driver.load_grammar(os.path.join(os.path.dirname(__file__), "..", "Grammar.txt"))
    # p.dfas is a tuple of two elements: the first is the actual
    # grammar dfa, the second is a mapping from integers to the
    # symbol to which the DFA state represents a reduce.
    p.dfas[0]  # type: ignore
    list(p.dfas[1].items())  # type: ignore
    p.tokens['COMMENT']  # type: ignore
    p.labels[p.tokens['COMMENT']]  # type: ignore
    p.keywords['def']  # type: ignore
    x = Parser(p)

# Generated at 2022-06-21 10:18:11.114119
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Get the list of token names
    import token

    tokens = [name for name, value in vars(token).items() if name.isupper()]
    # Build a grammar that contains all tokens
    gr = Grammar(False)
    gr[1] = tokens
    gr[2] = []
    # Build a parser
    p = Parser(gr)
    p.setup()
    # Shuffle the token list
    import random

    random.shuffle(tokens)
    # Add the tokens in random order to the parser
    for name in tokens:
        p.addtoken(getattr(token, name), name, (0, 0))

# Generated at 2022-06-21 10:18:17.232154
# Unit test for method setup of class Parser
def test_Parser_setup():
    Grammar = blib2to3.pgen2.Grammar
    Parser = blib2to3.pgen2.Parser

# Generated at 2022-06-21 10:18:28.172498
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2 import driver

    p = driver.load_grammar("Python.g")
    #------------------------------------------------
    t = token.NAME
    value = "x"
    newstate = 0
    context = None
    #------------------------------------------------
    dfa, state, node = p.stack[-1]
    assert value is not None
    assert context is not None
    rawnode: RawNode = (t, value, context, None)
    newnode = p.convert(p.grammar, rawnode)
    if newnode is not None:
        assert node[-1] is not None
        node[-1].append(newnode)
    p.stack[-1] = (dfa, newstate, node)

# Generated at 2022-06-21 10:18:36.164965
# Unit test for method push of class Parser
def test_Parser_push():
    """Unit test for method push(type, newdfa, newstate, context)"""
    from . import grammar

    grammar = grammar.Grammar(
        grammar.grammar,
        start=grammar.start,
        keywords=grammar.keywords,
        tokens=grammar.tokens,
        labels=grammar.labels,
        dfas=grammar.dfas,
        states=grammar.states,
        symbols=grammar.symbols,
    )
    parse = Parser(grammar)
    parse.setup()
    parse.push(NUMBER, grammar.dfas[NUMBER], 3, (1, 2))
    assert len(parse.stack) == 2

# Generated at 2022-06-21 10:18:38.683019
# Unit test for constructor of class Parser
def test_Parser():
    from . import driver

    grammar = driver.load_grammar("Grammar.txt")
    p = Parser(grammar)
    p.setup()
    print(p)

# Generated at 2022-06-21 10:18:45.524645
# Unit test for method push of class Parser
def test_Parser_push():
    stack = [(1, 2, 3)];
    newdfa = 'newdfa';
    newstate = 'newstate';
    context = 'context';
    push_stack = stack;
    push_stack.append((newdfa, 0, (0, None, context, [])));
    p = Parser(None);
    p.stack = stack;
    p.push(0, newdfa, newstate, context);
    assert p.stack == push_stack, \
        'Test failed, method push of class Parser';

# Generated at 2022-06-21 10:18:50.115102
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.driver import Driver
    driver = Driver(True)
    parser = Parser(driver.grammar)
    parser.setup()
    parser.stack = [(None, None, None)]
    assert parser.stack == [(None, None, None)]
    parser.pop()
    assert parser.stack == []

# Generated at 2022-06-21 10:18:52.707333
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2.grammar import Grammar

    g = Grammar()
    p = Parser(g)

# Generated at 2022-06-21 10:18:58.229647
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("foo", 5, "bar", None)
    except ParseError as exc:
        assert str(exc) == "foo: type=5, value=bar, context=None"
        assert exc.msg == "foo"
        assert exc.type == 5
        assert exc.value == "bar"
        assert exc.context == None
    else:
        assert False, "Exception not raised"

# Generated at 2022-06-21 10:19:06.485146
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver as D
    from . import tokenize

    f = open("../blib2to3/pgen2/test.txt")
    g = D.load_grammar("../blib2to3/pgen2/Grammar.txt")
    p = Parser(g)
    p.setup()
    for type, value, line, column, context in tokenize.generate_tokens(f.readline):
        p.addtoken(type, value, Context(line, column, context))

# Generated at 2022-06-21 10:20:04.555466
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("oops", 1, 2, 3)
    assert err.msg == "oops"
    assert err.type == 1
    assert err.value == 2
    assert err.context == 3