

# Generated at 2022-06-21 10:10:25.379548
# Unit test for method setup of class Parser
def test_Parser_setup():
    import sys
    import pprint, inspect
    from blib2to3.pgen2 import driver
    sys.path.insert(0, 'tests/')
    test_pgen = driver.load_grammar("test_pgen.txt")
    p = Parser(test_pgen)
    p.setup()
    assert p.grammar == test_pgen
    assert p.convert == lam_sub
    assert p.stack == [(test_pgen.dfas[test_pgen.start],
                        0,
                        (test_pgen.start, None, None, []))], (
        "Unexpected value for p.stack: " + pprint.pformat(p.stack))

# Generated at 2022-06-21 10:10:28.637933
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("foo", None, None, None)
    assert err.msg == "foo"
    assert err.type is None
    assert err.value is None
    assert err.context is None

# Generated at 2022-06-21 10:10:36.881577
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import parser
    from . import grammar
    from . import tokenize
    from .driver import Driver
    from io import StringIO
    from typing import Dict
    from blib2to3.pgen2.parse import ParseError

    g = grammar.grammar
    p = parser.Parser(g)
    d = Driver(g, p.convert)
    def check(input: Text, ast: Sequence[Any]) -> None:
        source = StringIO(input)
        tokgen = tokenize.generate_tokens(source.readline)

# Generated at 2022-06-21 10:10:43.496818
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .token import generate_tok_name
    from . import grammar

    g = grammar.Grammar(token.tokens, token.keywords)
    p = Parser(g)
    p.setup()
    assert p.classify(token.STRING, None, None) == g.tokens[token.STRING]
    assert p.classify(token.NAME, 'a', None) == g.tokens[token.NAME]
    assert p.classify(token.NAME, 'if', None) == g.keywords['if']
    assert p.classify(token.NAME, 'as', None) == g.keywords['as']

    # The following don't work because token.tok_name doesn't really
    # exist.
    # assert p.classify(generate_tok_name

# Generated at 2022-06-21 10:10:49.526853
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test case for the constructor of class ParseError."""
    try:
        raise ParseError("foo", 1, "bar", 2)
    except ParseError as pe:
        assert pe.msg == "foo"
        assert pe.type == 1
        assert pe.value == "bar"
        assert pe.context == 2
    else:
        assert False, "exception not raised"

# Generated at 2022-06-21 10:10:54.417917
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("msg", 1, "\x20", (2, 3))
    assert exc.msg == "msg"
    assert exc.type == 1
    assert exc.value == "\x20"
    assert exc.context == (2, 3)



# Generated at 2022-06-21 10:11:01.895285
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .grammar import Grammar
    from .tokenize import generate_tokens

    class DummyGrammar(Grammar):
        def __init__(self) -> None:
            super().__init__()
            self.dfas = {}  # type: Dict[int, DFA]
            self.start = 0
            self.labels = [
                (0, None),
                (10, "token"),
                (20, "token2"),
                (30, "token3"),
            ]
            self.tokens = {"token": 1, "token2": 2, "token3": 3}

# Generated at 2022-06-21 10:11:13.462677
# Unit test for function lam_sub
def test_lam_sub():
    class DummyGrammar(object):
        # For this to work we need to follow the convention that
        # grammar symbols have values in the range 256 <= x < 2**16,
        # and tokens have values in the range 0 <= x < 256.
        labels = [
            None,
            (token.NUMBER, "2"),
            (token.PLUS, "+"),
            (token.NAME, "foo"),
            (token.NAME, "bar"),
            (token.EQUAL, "="),
            (token.LPAR, "("),
            (token.RPAR, ")"),
            (token.NEWLINE, "\n"),
        ]


# Generated at 2022-06-21 10:11:21.187989
# Unit test for method setup of class Parser
def test_Parser_setup():
    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.start = 257
            self.nonterminals = {
                257: 'file_input',
            }
            self.labels = (
                (258, 'NAME'),
                (0, 'ENDMARKER'),
                (257, 'file_input'),
            )
            self.keywords: Dict[Text, int] = {}
            self.tokens = {
                0: 0,
                258: 258,
            }
            self.dfas: Dict[int, DFAS] = {
                257: (
                    [
                        [(0, 1)],
                        [(258, 2)],
                        [(0, 1)],
                    ],
                    {258},
                ),
            }

# Generated at 2022-06-21 10:11:22.761328
# Unit test for method classify of class Parser
def test_Parser_classify():
    # No test, include this so coverage will count it
    pass

# Generated at 2022-06-21 10:11:42.546223
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar
    from .token import N_TOKENS

    g = grammar.grammar
    p = Parser(g)  # XXX: should work!
    assert g is p.grammar and g.start is p.stack[0][0][1]
    assert p.rootnode is None
    assert len(p.used_names) == 0
    try:
        p.addtoken(token.NUMBER, "42", (1, 2))
    except ParseError as e:
        assert e.msg == "bad token"
        assert e.type == token.NUMBER
        assert e.value == "42"
        assert e.context == (1, 2)
    else:
        assert False, "Expected a ParseError"

    p.setup()

# Generated at 2022-06-21 10:11:46.542060
# Unit test for constructor of class Parser
def test_Parser():
    # The original test in Python's graminit.py compiled the grammar
    # instead of using the tables.  Since the tables are generated from
    # that grammar, we can safely assume they are good.
    from blib2to3.pgen2.grammar import grammar

    p = Parser(grammar)
    p.setup()



# Generated at 2022-06-21 10:11:58.236186
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver

    g = driver.load_grammar("Python.gram")
    p = Parser(g)
    p.setup(start="file_input")

    # Simulate the first two tokens
    assert p.addtoken(token.ENCODING, "utf-8", (1, 0)) == False
    assert p.addtoken(token.NEWLINE, "\n", (1, 9)) == False

    # This should fail, because push() is not yet defined.
    # Fix the code above and try again.
    assert p.addtoken(token.INDENT, "\t", (2, 0)) == False  # noqa: F841

    assert p.addtoken(token.ENDMARKER, "", (3, 0)) == True
    assert len(p.used_names) == 0
    assert p.root

# Generated at 2022-06-21 10:12:07.376415
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import io
    from . import driver

    def show_results(pre, start, end, results):
        # Show results from parsing
        print(pre + ":", start, end)
        keys = list(results.keys())
        keys.sort()
        for name in keys:
            print("%s: %s" % (name, results[name]))

    def parse_file(filename, start, results):
        # Parse a file and show results
        f = open(filename, "r")
        try:
            tokens = driver.tokenize(f.readline)
        finally:
            f.close()
        tok = None
        parser = Parser(grammar, convert)
        parser.setup(start)

# Generated at 2022-06-21 10:12:10.014848
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar, driver

    gr = grammar.grammar
    p = Parser(gr)



# Generated at 2022-06-21 10:12:22.081545
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .driver import test_grammar

    grammar = test_grammar()
    p = Parser(grammar, lam_sub)
    p.setup()
    p.addtoken(token.NAME, "foo", Context(None, -1, -1))
    p.addtoken(token.NAME, "bar", Context(None, -1, -1))
    p.addtoken(token.LPAR, "(", Context(None, -1, -1))
    p.addtoken(token.NUMBER, "1", Context(None, -1, -1))
    p.addtoken(token.PLUS, "+", Context(None, -1, -1))
    p.addtoken(token.NUMBER, "2", Context(None, -1, -1))

# Generated at 2022-06-21 10:12:28.406786
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .grammar import Grammar

    g = Grammar(Grammar.grammar)

    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "fft", 1)
    assert p.rootnode is None
    p.addtoken(token.NAME, "Foo", 1)
    assert p.rootnode is not None

# Generated at 2022-06-21 10:12:33.786028
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser()
    assert p.stack == []
    p.shift(1, 'a', 2, ('test', 1, 0))
    assert p.stack == [(None, 2, (1, 'a', ('test', 1, 0), None))]
    p.shift(2, 'b', 3, ('test', 1, 0))
    assert p.stack == [(None, 3, (2, 'b', ('test', 1, 0), None)), (None, 2, (1, 'a', ('test', 1, 0), None))]

# Generated at 2022-06-21 10:12:43.578891
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Python", "3.5")
    parser = Parser(grammar)
    parser.setup()

    result = parser.pop()
    assert parser.rootnode is None
    assert result is None
    assert parser.stack == []

    result = parser.pop()
    assert parser.rootnode is None
    assert result is None
    assert parser.stack == []

    result = parser.pop()
    assert parser.rootnode is None
    assert result is None
    assert parser.stack == []

    sys_module = Node(type=grammar.symbol2number["file_input"], children=[])

# Generated at 2022-06-21 10:12:49.222731
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test ParseError", 3, "3", None)
    except ParseError as e:
        assert e.type == 3
        assert e.value == "3"
        assert e.context is None
        assert e.msg == "test ParseError"

if __name__ == "__main__":
    test_ParseError()

# Generated at 2022-06-21 10:13:12.790418
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Setup global variable
    import blib2to3.pgen2 as pgen2
    py_grammar = pgen2.grammar
    py_convert = pgen2.driver.convert

    # Setup input arguments
    py_popnode = [0, None, None, []]
    p = Parser(py_grammar, py_convert)
    p.setup()
    p.stack.append([[], 0, py_popnode])
    p.used_names = set()

    # Construct a dummy return value
    py_result = [
        [[[59, 0], [0, 0]], 0, [1, None, None, []]],
        [[[59, 0], [0, 0]], 1, [0, None, None, []]],
    ]

    p.pop()
   

# Generated at 2022-06-21 10:13:24.483915
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, token
    from .tokenize import generate_tokens, NUMBER, NAME, OP, NEWLINE
    from io import BytesIO

    def check_tokenizer(text: Text, expected_tokens: Sequence[Sequence[int]]) -> None:
        tokens = generate_tokens(BytesIO(text.encode("utf-8")).readline)
        num = 0
        while tokens:
            num += 1
            if expected_tokens:
                expect = expected_tokens.pop(0)
            else:
                expect = [token.ENDMARKER, ""]
            t = tokens.pop(0)

# Generated at 2022-06-21 10:13:28.133022
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar())
    p.setup(0)
    assert p.stack == [(p.grammar.dfas[0], 0, (0, None, None, []))]
    assert p.rootnode is None


# Generated at 2022-06-21 10:13:36.789069
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2.parse import Parser
    from blib2to3.pgen2.driver import driver
    global parser
    parser = Parser(driver.grammar, driver.convert)
    input_text = "a = 3"
    try:
        tokens = tokenize.generate_tokens(input_text)
        parser.setup()
        for toknum, tokval, _, _, _ in tokens:
            if parser.addtoken(toknum, tokval, (1, 0)):
                break
    except ParseError as e:
        print("Parse error at %s: %s" % ((e.context[0], e.context[1]), e.msg))
        assert False

# Generated at 2022-06-21 10:13:41.945876
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .driver import Driver

    d = Driver()
    g = d.build_grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, 1, (0, 0))
    assert p.rootnode.prefix == "1"



# Generated at 2022-06-21 10:13:51.893243
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from pgen2.grammar import driver
    import sys

    grammar = driver.load_grammar(sys.argv[1])
    p = Parser(grammar)
    p.setup()
    while True:
        tok = input().split()
        if tok[0] == "TOK":
            type, value, lineno, col = int(tok[1]), eval(tok[2]), int(tok[3]), int(tok[4])
            if p.addtoken(type, value, (lineno, col)):
                break
    print("Parser.addtoken works")



# Generated at 2022-06-21 10:14:01.922712
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver
    from blib2to3.pgen2 import token
    import re

    # Define a very simple grammar
    grammar = driver.parse_grammar("""
        start: foo bar
        foo: 'f' 'o'
        bar: 'b' 'a' 'r'
        """)

    # Check that it works
    p = Parser(grammar)
    p.setup()
    assert p.addtoken(token.NAME, "f", Context(0, (1, 0))) is False
    assert p.addtoken(token.NAME, "o", Context(0, (1, 1))) is False
    assert p.addtoken(token.NAME, "b", Context(0, (1, 2))) is False

# Generated at 2022-06-21 10:14:13.038448
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    import io

    # For the test, use the same Grammar instance as the grammar module
    grammar = grammar.grammar
    with io.open(grammar.grammarpickle, "rb") as f:
        load_grammar(grammar, f)

    # Add tokens that are specific to the grammar module's Grammar instance
    grammar.tokens[token.IS] = 1
    grammar.labels[1] = (token.IS, "isnot")

    # Create a Parser instance and prepare it for parsing
    p = Parser(grammar)
    p.setup(grammar.start)

    # Check that the classify method of Parser works as expected
    expected = [(token.IS, "isnot", 1)]

# Generated at 2022-06-21 10:14:15.630638
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.driver

    # Defer to the unit test in driver.py
    blib2to3.pgen2.driver.test_token_classification()



# Generated at 2022-06-21 10:14:26.732707
# Unit test for method push of class Parser
def test_Parser_push():
    class TestParser(Parser):
        def push(self, type: int, newdfa: DFAS, newstate: int, context: Context) -> None:
            print(type, newstate)
            Parser.push(self, type, newdfa, newstate, context)
    p = TestParser(Grammar(), None)
    p.setup()
    p.addtoken(token.COMMENT, "", Context(0))
    p.addtoken(token.NAME, "def", Context(0))
    p.addtoken(token.NAME, "test", Context(0))
    p.addtoken(token.OP, "(", Context(0))
    p.addtoken(token.OP, ")", Context(0))
    p.addtoken(token.COLON, ":", Context(0))

# Generated at 2022-06-21 10:15:01.437933
# Unit test for method pop of class Parser
def test_Parser_pop():
    import json
    import os
    from blib2to3.pgen2 import grammar
    from blib2to3.pyparse import driver

    file = os.environ['BLIB2TO3_DATA_DIR'] + '/Grammar.json'
    with open(file) as fp:
        raw_grammar = json.load(fp)
    g = grammar.Grammar(raw_grammar)
    p = Parser(g)
    p.setup(start='file_input')
    p.addtoken(ENDMARKER, None, (0, 0))
    assert p.pop() is None
    assert p.pop() is None


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 10:15:08.339539
# Unit test for function lam_sub
def test_lam_sub():
    class Grammar:
        labels = "ab"
        keywords = {}
        tokens = {token.NAME: 1}

    n = lam_sub(Grammar(), (1, "hello", None, [2]))
    assert len(n) == 1
    assert n[0] == 2
    assert n.context is None
    assert n.type == 1
    assert n.prefix is None
    assert n.value == "hello"

# Generated at 2022-06-21 10:15:13.234841
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    def get_parser(g):
        from . import pgen2

        p = pgen2.driver.load_grammar("Grammar/Grammar", g)
        return Parser(p)

    driver.run_test("test-parse-input.text", get_parser)

# Generated at 2022-06-21 10:15:20.661033
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar(token, {})
    grammar.labels = [(1, 25), (2, 26), (3, 27)]
    grammar.keywords = {}
    node = (1, None, None, [(2, None, None, [(3, 'x', None, None)]), (4, 'y', None, None)])
    assert lam_sub(grammar, node).children == [
        Node(type=2, children=[Leaf(type=3, value='x')]),
        Leaf(type=4, value='y'),
    ]

# Generated at 2022-06-21 10:15:32.692168
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import token
    from . import driver
    p = Parser(grammar)
    p.setup()
    d = driver.Driver(p.addtoken)
    d.tokens = [(token.NUMBER, 1), (token.PLUS, '+'), (token.NUMBER, 2)]
    root = d.parse()
    assert str(root) == 'NUMBER'
    assert str(root[0]) == '1'
    assert str(root[1]) == '+'
    assert str(root[2]) == 'NUMBER'
    assert str(root[2][0]) == '2'


if __name__ == "__main__":
    test_Parser_addtoken()

# Generated at 2022-06-21 10:15:42.386183
# Unit test for function lam_sub
def test_lam_sub():
    # Test 'a'
    node = ('a', 0, 0, [])
    lam_sub(None, node)
    # Test 'b'
    node = ('b', 0, 0, [])
    lam_sub(None, node)
    # Test 'a b'
    a_b = ('a', 0, 0, [Node('b', [])])
    lam_sub(None, a_b)
    # Test 'a b c'
    a_b = ('a', 0, 0, [Node('b', [])])
    a_b_c = ('a', 0, 0, [Node('b', [Node('c', [])])])
    lam_sub(None, a_b_c)

# Generated at 2022-06-21 10:15:47.500908
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.pgen

    gr = blib2to3.pgen2.pgen.generate_grammar()
    p = Parser(gr)
    test_token = (token.NAME, 'True', (1, 1))
    assert p.classify(*test_token) == 0



# Generated at 2022-06-21 10:15:57.647379
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.grammar import DEFAULT_GRAMMAR, Symbol
    from blib2to3.pgen2.parse import ParseError
    p = Parser(DEFAULT_GRAMMAR, lam_sub)
    p.setup()
    assert p.addtoken(1, '+', (1,0))
    assert p.addtoken(2, '1', (1,2))
    assert p.addtoken(1, '*', (1,4))
    assert p.addtoken(3, '3', (1,6))
    assert p.rootnode.type == Symbol.or_test
    assert p.rootnode.children[0].type == Symbol.and_test
    assert p.rootnode.children[0].children[0].type == Symbol.not_test

# Generated at 2022-06-21 10:16:03.648345
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver

    p = Parser(driver.grammar)
    for tok in (token.NUMBER, token.PLUS, token.STAR, token.LPAR, token.NAME,
                token.EQUAL, token.RPAR, token.NEWLINE, token.ENDMARKER):
        print(tok, p.classify(tok, '', None))

# Generated at 2022-06-21 10:16:10.041704
# Unit test for function lam_sub
def test_lam_sub():
    g = Grammar()
    s = g.symbol2number(None, 'single')
    l = Leaf(type='single', children=[], context=(1, 0))
    l.used_names = set()
    node = lam_sub(g, (s, None, (2, 3), None))
    assert l == node
    assert isinstance(node, Leaf)

# Generated at 2022-06-21 10:16:45.579478
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.token import tok_name
    g = Grammar()
    p = Parser(g)
    assert p.stack == []
    p.setup()
    assert p.stack == [(g.dfas[0], 0, (0, None, None, []))]

    # The following test is a very poor test; I'm just not sure how to
    # test the propagated root node correctly.
    p.setup()
    assert p.stack != []


# Generated at 2022-06-21 10:16:55.484912
# Unit test for method pop of class Parser
def test_Parser_pop():
    instance = Parser(None)
    # TODO: this test assumes that the parser is represented by a
    # stack of tuples of the form (dfa, state, node).
    # This representation may change, breaking this test.
    instance.stack = [None, [None, None, None]]
    try:
        instance.pop()
    except AssertionError:
        pass
    instance.stack = []
    # TODO: this test assumes that the parser is represented by a
    # stack of tuples of the form (dfa, state, node).
    # This representation may change, breaking this test.
    instance.stack = [None, [None, None, [None, None, None, []]]]
    instance.pop()

# Generated at 2022-06-21 10:17:04.372857
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Create a toy grammar, demonstrating all aspects needed here
    class grammar:
        tokens: Dict[int, int] = {token.PLUS: 1, token.MINUS: 1, token.NAME: 2}
        keywords: Dict[Text, int] = {}
        start: int = 3
        labels: Sequence[Tuple[int, int]] = [(1, token.PLUS), (2, token.MINUS)]

    # Create parser and test
    p = Parser(grammar)
    assert p.classify(token.PLUS, "+", None) == 1
    assert p.classify(token.MINUS, "-", None) == 1
    assert p.classify(token.NAME, "a", None) == 2

# Generated at 2022-06-21 10:17:10.523373
# Unit test for constructor of class ParseError
def test_ParseError():
    import unittest
    import unittest.mock as mock

    class ParseError_Tester(unittest.TestCase):
        result = Text
        node = mock.MagicMock()
        node.context = mock.MagicMock()
        node.context.tokens = mock.MagicMock()

        def test_parse_error_1(self: "ParseError_Tester") -> None:
            self.result = ParseError("test error", 1, "test value", None)
            self.assertEqual(str(self.result), "test error: type=1, value=test value, context=None")

        def test_parse_error_2(self: "ParseError_Tester") -> None:
            self.result = ParseError("test error", 1, "test value", "test context")

# Generated at 2022-06-21 10:17:18.566718
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from .grammar import Grammar

    # Construct a grammar
    g = Grammar(driver.grammar)
    # Construct a parser
    p = Parser(g)
    # Add 3 tokens
    for i in range(3):
        p.shift(3, i, 0, None)
    # Check the stack content
    assert p.stack == [
        (
            ([[], [(0, 0), (0, 0), (0, 0)]], {0: 1, 1: 2}),
            0,
            (None, None, None, [[(3, 0), None, None, None], [(3, 1), None, None, None], [(3, 2), None, None, None]]),
        )
    ]



# Generated at 2022-06-21 10:17:29.133282
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    import sys

    p1 = driver.ParserDriver(verbose=1)
    p2 = Parser(p1.grammar)

    p2.setup()
    p1.set_parser(p2)

    # Single token
    p1.set_debuglevel(2)
    p1.set_testopts(quiet=1, lineseparator='')
    p1.driver()
    p1.inputstream = p1.tokenize('a')
    p1.driver()
    p2.shift(1, 'a', 0, p1.context)

    # Two tokens
    p1.set_debuglevel(2)
    p1.set_testopts(quiet=1, lineseparator='')
    p1.driver()

# Generated at 2022-06-21 10:17:31.046652
# Unit test for method setup of class Parser
def test_Parser_setup():
    assert hasattr(Parser, "setup")
    p = Parser(None)
    p.setup()


# Generated at 2022-06-21 10:17:41.982944
# Unit test for method push of class Parser
def test_Parser_push():
    # Adapted from pytree_test.py
    from . import pytree
    from .pygram import python_symbols as symbols
    from .pgen2.parse import tokenize_grammar

    grammar = tokenize_grammar("Grammar/Grammar")
    grammar = grammar.parse_grammar(start="file_input")
    p = Parser(grammar)

    # Call push
    p.push(symbols.funcdef, p.grammar.dfas[symbols.funcdef], 0, Context.from_string(""))

    output = pytree.convert(p.rootnode)
    assert output == "FileInput() { funcdef() { NAME() } }"

# Generated at 2022-06-21 10:17:47.494054
# Unit test for constructor of class Parser
def test_Parser():
    global parser_grammar, token_grammar
    p = Parser(parser_grammar)
    assert p.grammar is parser_grammar
    assert p.convert is lam_sub
    def convert(p, n):
        return 0
    p = Parser(parser_grammar, convert)
    assert p.grammar is parser_grammar
    assert p.convert is convert



# Generated at 2022-06-21 10:17:57.184379
# Unit test for method shift of class Parser
def test_Parser_shift():
    import os.path
    import pickle
    from pprint import pprint
    from . import parse

    # _parse is a pickled version of the parser
    fname = os.path.join(os.path.dirname(__file__), "_parse.pkl")
    f = open(fname, "rb")
    p = pickle.load(f)
    f.close()
    assert isinstance(p, parse.Parser)
    print("=== run_shift ===")
    print(p.stack)
    p.shift(1, "int", 7, "context example")
    pprint(p.stack)

# Generated at 2022-06-21 10:18:56.807721
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    for t in token.tok_name:
        #print t
        g = grammar.Grammar(t)
        p = Parser(g)
        p.setup()
        p.addtoken(t, "foo", (1, 1))

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "def", (1, 1))
    p.addtoken(token.NAME, "__init__", (1, 1))
    assert "__init__" in p.used_names
    p = Parser(g)
    p.setup()
    try:
        p.addtoken(token.NAME, "pass", (1, 1))
    except ParseError:
        pass

# Generated at 2022-06-21 10:19:05.855817
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.token as token
    import blib2to3.pgen2.grammar as grammar

    g = grammar.Grammar("""
    start: NAME
    """, {})
    p = Parser(g)

    G = p.grammar
    assert p.classify(token.NAME, "abc", (1, 0)) == G.dfas['start'][1][0][0]
    try:
        p.classify(G.dfas['start'][1][0][0], "abc", (1, 0))
    except ParseError as e:
        assert e.type == token.NAME
        assert e.value == "abc"
        assert e.context == (1, 0)
    else:
        assert False, "Didn't detect ParseError"


# Generated at 2022-06-21 10:19:13.195327
# Unit test for method push of class Parser
def test_Parser_push():
    # Create a Grammar called grammar
    grammar = Grammar()
    # Create a Parser called parser
    parser = Parser(grammar)
    # Call parser's method setup()
    parser.setup()
    # Call parser's method push with type=1, newdfa=[1,2], newstate=0,
    # and context=0
    # This should create a stack with the following values:
    # [([1,2], 0, [(1, None, 0, [])])]
    parser.push(1, [1, 2], 0, 0)
    print('Parser.push(): Success!')



# Generated at 2022-06-21 10:19:17.874617
# Unit test for function lam_sub
def test_lam_sub():
    class DummyGrammar:
        def __init__(self) -> None:
            pass

    g = DummyGrammar()
    tup = (1, 2, 3, [4, 5])
    assert lam_sub(g, tup) == Node(type=1, children=[4, 5], context=3)
    tup = (1, 2, 3, None)
    assert lam_sub(g, tup) is None

# Generated at 2022-06-21 10:19:19.358840
# Unit test for method setup of class Parser
def test_Parser_setup():
    a = Parser(grammar.Grammar())
    a.setup()

# Generated at 2022-06-21 10:19:26.270575
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver

    source = "x y z"
    grammar = driver.load_grammar("Python.asdl")
    p = Parser(grammar)
    tp = driver.tokenize_str(source)
    p.setup()
    for typ, tok, spec, (srow, scol), (erow, ecol), line in tp:
        i = p.classify(typ, tok, spec)
        assert grammar.keywords[tok] == i


# Generated at 2022-06-21 10:19:29.181331
# Unit test for constructor of class Parser
def test_Parser():
    """Parser()"""
    from . import grammar as G

    g = G.Grammar()
    p = Parser(g)
    p.setup()


# Generated at 2022-06-21 10:19:29.709252
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    pass

# Generated at 2022-06-21 10:19:37.890357
# Unit test for method push of class Parser
def test_Parser_push():
    import grammar
    import driver
    import io
    import os
    import sys
    import token
    import tokenize

    dirname = os.path.dirname(__file__) or os.curdir
    stdout = sys.stdout
    g = grammar.parse_grammar(open(os.path.join(dirname, "Grammar.txt")))
    p = Parser(g)
    p.setup()
    stdout = sys.stdout
    sys.stdout = io.StringIO()
    try:
        tokenize.tokenize(sys.stdin.readline, p.addtoken)
        sys.stdout = stdout
        p.rootnode.pprint()
    finally:
        sys.stdout = stdout

# Generated by make_pgen.py

# Generated at 2022-06-21 10:19:43.037288
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar
    grammar1 = grammar.grammar
    p = Parser(grammar1)
    assert p.grammar == grammar1
    assert p.convert is None
    # You must call setup() before parsing
    def f():
        p.addtoken(0, None, None)

    py_exc = raises(ParseError, f)  # type: ignore
    assert py_exc.value.msg == 'no initial state'