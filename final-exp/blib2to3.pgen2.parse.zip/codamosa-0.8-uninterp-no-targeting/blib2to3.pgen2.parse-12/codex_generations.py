

# Generated at 2022-06-21 10:10:14.184442
# Unit test for method push of class Parser
def test_Parser_push():
    import blib2to3.pgen2.driver
    import blib2to3.pgen2.token
    gram = blib2to3.pgen2.driver.load_grammar("Grammar/Grammar")
    p = Parser(gram)
    p.setup()
    p.stack = [([([], 1)]), 0, (0, None, None, [])]
    p.push(256, ([([], 1)]), 0, None)
    assert p.stack == [([([], 1)]), 0, (0, None, None, [])], p.stack

# Generated at 2022-06-21 10:10:25.674061
# Unit test for constructor of class Parser
def test_Parser():
    def myconv(grammar, node):
        if node[1] is None:
            return Node(node[0], node[3], context=node[2])
        else:
            return Leaf(node[0], node[1], context=node[2])

    from . import pgen2

    p = pgen2.driver.load_grammar("Grammar/Grammar", convert=myconv)
    p.setup()
    p.addtoken(token.NAME, "print", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 6))
    p.addtoken(token.NEWLINE, None, Context(1, 7))
    assert p.rootnode.type == "file_input"
    assert p.rootnode.children[0].type == "stmt"
   

# Generated at 2022-06-21 10:10:30.213595
# Unit test for method setup of class Parser
def test_Parser_setup():
    g = Grammar(None, None)
    g.labels = {}
    g.keywords = {}
    g.dfas = {}
    g.start = 1
    p = Parser(g, None)
    p.setup()



# Generated at 2022-06-21 10:10:40.296552
# Unit test for method pop of class Parser
def test_Parser_pop():
    # function is used by pop() in class Parser (see Parser/parser.py)
    # to convert a concrete syntax tree node to an abstract syntax tree node.

    # Dummy arguements
    grammar = Grammar()
    type = 0
    value = None
    context = None
    nodes = []

    # Create a concrete syntax tree
    leaf = (type, value, context, nodes)
    leaf['used_names'] = ['abc', 'def']
    # Call method pop to convert the concrete syntax tree to an abstract syntax tree
    rootnode = Parser.pop(leaf)
    # Test that the abstract syntax tree is now present
    assert rootnode.children == nodes
    assert rootnode.used_names == {'abc', 'def'}

# Generated at 2022-06-21 10:10:52.717665
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import unittest

    class UnusedContext:
        def __init__(self, values):
            self.values = values

    class Test(unittest.TestCase):
        def setUp(self):
            self.p = Parser(Grammar())
            self.p.setup()

        def test_bad_token(self):
            try:
                self.p.addtoken(0, None, UnusedContext([]))
            except ParseError as e:
                self.assertEqual(e.msg, "bad token")
                self.assertEqual(e.type, 0)
                self.assertEqual(e.value, None)
                self.assertEqual(e.context, UnusedContext([]))
            else:
                self.fail("Expected an exception")


# Generated at 2022-06-21 10:10:54.617158
# Unit test for method setup of class Parser
def test_Parser_setup():
    assert hasattr(Parser, "setup")
    assert callable(Parser.setup)


# Generated at 2022-06-21 10:11:01.971264
# Unit test for method push of class Parser
def test_Parser_push():
    from .grammar import Grammar

    g = Grammar(r"""
    stmt: if_stmt | while_stmt
    if_stmt: 'if' NAME ':' suite 'else' ':' suite
    while_stmt: 'while' NAME ':' suite
    suite: stmt
    """)

    def convert(grammar, node):
        return node

    p = Parser(g, convert)

    p.setup()
    p.addtoken(token.NAME, "if", (1, 2))
    p.addtoken(token.NAME, "foo", (1, 3))
    p.addtoken(token.COLON, None, (1, 4))
    p.addtoken(token.NAME, "name", (1, 5))

# Generated at 2022-06-21 10:11:11.852141
# Unit test for method pop of class Parser
def test_Parser_pop():
    p = Parser.__new__(Parser)
    p.stack = [(1, 2, (3, 4, 5, 6)), (7, 8, (9, 10, 11, 12)), (13, 14, (15, 16, 17, 18))]
    p.rootnode = None
    p.convert = lambda x, y: None
    p.pop()
    assert p.stack == [(1, 2, (3, 4, 5, 6)), (7, 8, (9, 10, 11, 12))]
    p.pop()
    assert p.stack == [(1, 2, (3, 4, 5, 6))]
    p.pop()
    assert p.stack == []


# Generated at 2022-06-21 10:11:14.976027
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import pytest

    p = Parser(Grammar())
    p.setup()
    p.addtoken(token.NEWLINE, "\n", (1, 0))

# Generated at 2022-06-21 10:11:22.015596
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    def basic_convert(g: Grammar, node: RawNode) -> Union[Node, Leaf]:
        if node[3]:
            return Node(type=node[0], children=node[3], context=node[2])
        else:
            return Leaf(type=node[0], value=node[1], context=node[2])

    p = Parser(grammar.grammar, basic_convert)
    p.setup()



# Generated at 2022-06-21 10:11:30.770763
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("bad input", token.NAME, "x", "foo")
    assert str(exc) == """\
bad input: type=1, value='x', context='foo'"""
    assert exc.type == token.NAME
    assert exc.value == "x"
    assert exc.context == "foo"

# Generated at 2022-06-21 10:11:42.896520
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from io import StringIO

    from . import driver
    from . import grammar
    from . import tokenize_rt

    # TODO: at the moment, only tests the tree reduction part
    gram = grammar.Grammar("Grammar.txt")
    gram.parse("Grammar.txt", "Grammar.txt")
    finput = StringIO("x = 1\n")
    driver.Driver(gram, tokenize_rt.tokenize_rt).parse_file(finput)

    p = Parser(gram)
    p.setup()
    # print p.stack
    p.addtoken(token.NAME, "x", Context())
    # print p.stack
    p.addtoken(token.EQUAL, "=", Context())
    # print p.stack

# Generated at 2022-06-21 10:11:49.930584
# Unit test for method classify of class Parser
def test_Parser_classify():
    '''Test method classify of class Parser'''

    def _classify(t, v):
        p = Parser(Grammar())
        return p.classify(t, v, Context())

    def _check(t, v, e):
        assert _classify(t, v) == e, (t, v, _classify(t, v))

    _check(token.NAME, 'def', 1)
    _check(token.NAME, 'class', 1)
    _check(token.NAME, 'something', 1)
    _check(token.NAME, None, 1)

# Generated at 2022-06-21 10:12:02.053241
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Load test grammar
    from . import grammar

    gram = grammar.grammar
    gram.initialize()

    # Create a parser object
    parser = Parser(gram)
    parser.setup()

    # assert not parser.used_names
    # parser.addtoken(token.NAME, "a", (1, 2))
    # assert parser.used_names == {"a"}

    # This test procedure has been substantially modified to pass in
    # a context to the parser.  In the original code, context is None
    # and this test produces a segfault.
    #
    # parser = Parser(gram)
    # parser.setup()
    # parser.addtoken(token.NAME, "a", (1, 2))
    # parser.addtoken(token.NAME, "b", (1, 2))
    # parser

# Generated at 2022-06-21 10:12:09.506282
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest

    class ParserClassifyTestCase(unittest.TestCase):
        def check(
            self, name: Text, type: int, value: Optional[Text], expected: int
        ) -> None:
            p = Parser(grammar)
            p.setup()
            actual = p.classify(type, value, None)
            self.assertEqual(
                actual,
                expected,
                "{!r}: type=%r, value=%r: expected %r, got %r".format(
                    name, type, value, expected, actual
                ),
            )

    p = Parser(grammar)
    p.setup()

    grammar = Grammar("grammar.txt")

    testcase = ParserClassifyTestCase("check")

# Generated at 2022-06-21 10:12:21.565846
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest

    from . import grammar

    class ParserTestCase(unittest.TestCase):
        def setUp(self):
            self.grammar = grammar.Grammar()

        def test_shift(self):
            # The same as the default convert function
            def convert(grammar, node):
                return Node(type=node[0], children=node[3], context=node[2])

            parser = Parser(self.grammar, convert)
            parser.setup()
            parser.shift(token.NUMBER, "1", 0, (1, 0))
            node = parser.rootnode
            self.assertEqual(node.type, token.NUMBER)
            self.assertEqual(node.value, "1")
            self.assertEqual(node.children, [])

# Generated at 2022-06-21 10:12:24.209390
# Unit test for method setup of class Parser
def test_Parser_setup():
    g = Grammar()
    p = Parser(grammar=g, convert=None)
    p.setup()



# Generated at 2022-06-21 10:12:33.755137
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from io import BytesIO

    input = BytesIO(b'\nfoo = 1\nbar {\n}\n')
    p = Parser(grammar.grammar)
    p.setup()
    tokenize.tokenize_loop(input.readline, p.addtoken)
    assert len(p.rootnode) == 3
    assert p.rootnode[0].type == 1
    assert p.rootnode[1].type == 1
    assert p.rootnode[2].type == 1
    assert p.rootnode[0].children[0].value == 'foo'
    assert p.rootnode[0].children[1].value == '='
    assert p.rootnode[0].children[2].value == '1'

# Generated at 2022-06-21 10:12:38.843400
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from blib2to3.pgen2 import tokenize

    parser = Parser(grammar)
    parser.setup()
    for type, value, begin, end, line in tokenize.generate_tokens(iter("x+3").__next__):
        parser.addtoken(type, value, (0, 0))



# Generated at 2022-06-21 10:12:49.586737
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2 import tokenize

    def classify_test(data, expected_tokens):
        grammar = Grammar("Grammar", {"START": [['expr']]})
        p = Parser(grammar)
        p.setup()
        g = tokenize.generate_tokens(data.splitlines(True))
        for tok in g:
            token_type = tok[0]
            if token_type == token.NEWLINE:
                token_type = token.NL
            label = p.classify(token_type, tok[1], tokenize.untokenize_pair(tok))
            expected_token = expected_tokens.pop(0)
            assert(label == expected_token)
    # From Python 3.2.2 (Ideally, this should

# Generated at 2022-06-21 10:12:59.574277
# Unit test for method classify of class Parser
def test_Parser_classify():
    p = Parser(Grammar(r"\grammar.txt", r"\terminals.txt", r"\nonterminals.txt"))
    assert(p.classify(token.DEL, "~", (0, 0)) == 256)


# Generated at 2022-06-21 10:13:10.907301
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.grammar import Grammar

    pg = Grammar(test_grammar, "test")
    parser = Parser(pg)
    parser.setup()

    assert parser.classify(1, "1", (1, 0)) == 1
    assert parser.classify(2, "2", (2, 0)) == 2
    assert parser.classify(1, "1.0", (1, 0)) == 1
    assert parser.classify(1, ".1", (1, 0)) == 1
    assert parser.classify(2, "1e-3", (2, 0)) == 3
    assert parser.classify(2, "1.e-3", (2, 0)) == 3

# Generated at 2022-06-21 10:13:22.924188
# Unit test for method pop of class Parser

# Generated at 2022-06-21 10:13:31.171339
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from blib2to3.pgen2 import driver

    d = driver.Driver(grammar.grammar, convert=grammar.convert)
    p = d.parser
    p.setup()
    p.addtoken(token.NAME, "hello", (1, 0))
    p.addtoken(token.NAME, "world", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, len("hello world")))
    p.addtoken(0, "", (1, len("hello world\n")))
    print(p.rootnode)

# Generated at 2022-06-21 10:13:33.074635
# Unit test for constructor of class Parser
def test_Parser():
    import pickle

    g = pickle.load(open("Grammar.pickle", "rb"))
    p = Parser(g)

# Generated at 2022-06-21 10:13:45.148868
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .token import NAME, NUMBER
    from .grammar import Grammar, parse_grammar
    from .driver import Driver
    from .tokenize import generate_tokens
    from typing import Iterable
    from io import StringIO

    grammar = parse_grammar(StringIO(Driver._test_grammar))

    p = Parser(grammar)
    p.setup()

    def _input(t: Iterable[Tuple[int, Text, Context, int, int]]) -> None:
        for v in t:
            p.addtoken(v[0], v[1], v[2])

    _input(generate_tokens(StringIO("[]")))

# Generated at 2022-06-21 10:13:51.040469
# Unit test for function lam_sub
def test_lam_sub():
    foo = NL(type="foo", context=None)
    bar = NL(type="bar", context=None)
    baz = NL(type="baz", context=None)
    node = RawNode(type="foo", value=None, context=None, children=[foo, bar, baz])
    result = lam_sub(None, node)
    assert result == foo + bar + baz

# Generated at 2022-06-21 10:13:57.921577
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar, token

    g = grammar.Grammar()
    assert g.start == 256
    p = Parser(g)
    p.setup()

    p.addtoken(token.NAME, "foo", (1, 1))
    p.addtoken(token.EQUAL, "=", (1, 1))
    p.addtoken(token.NUMBER, "42", (1, 1))
    p.addtoken(token.NEWLINE, "", (1, 1))
    assert p.rootnode is not None

# Generated at 2022-06-21 10:14:09.237275
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver, token

    text = '1'
    import sys
    if sys.version_info.major <= 2:
        text = text.decode('utf-8')
    tokens = driver.tokenize(text)
    p = Parser(driver.Grammar())
    p.setup()

    p.addtoken(token.NUMBER, '1', (1,0))
    p.addtoken(token.ENDMARKER, '', (1,1))

    assert p.stack == [Token(token.ENDMARKER, '', (1, 1), None)]
    p.pop()
    assert p.stack == []
    assert p.rootnode.type == token.ENDMARKER
    assert p.rootnode.children == []

# Generated at 2022-06-21 10:14:17.041227
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar(
        grammar=None,
        start=None,
        keywords={},
        labels=[],
        tokens={},
        dfas={},
        error_func=None,
    )
    assert grammar.start is None
    parser = Parser(grammar=grammar, convert=None)
    assert parser.rootnode is None
    assert parser.stack == []
    assert parser.used_names == set()
    # Prepare for parsing
    parser.setup(None)
    assert parser.rootnode is None
    assert parser.stack == [(None, 0, (None, None, None, []))]
    assert parser.used_names == set()
    # Pop a nonterminal
    parser.pop()
    assert parser.rootnode == (None, None, None, [])
    assert parser.stack == []


# Generated at 2022-06-21 10:14:31.807362
# Unit test for constructor of class Parser
def test_Parser():
    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()


# Generated at 2022-06-21 10:14:40.447291
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Check resrved words
    grammar = Grammar()
    parser = Parser(grammar)


# Generated at 2022-06-21 10:14:52.777446
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, driver
    from .driver import generate_tokens
    from .tokenize import generate_tokens as tokenize

    from blib2to3 import pygram
    from blib2to3.pgen2.parse import ParseError

    for input_string, method in [
        (
            "def f(): return 42\n",
            generate_tokens,
        ),
        (
            "def f(): return 42\n",
            tokenize,
        ),
    ]:
        try:
            tokens = [t for t in method(input_string)]
        except TypeError:
            tokens = tokenize(input_string)

        g = pygram.python_grammar_no_print_statement
        g.keywords["def"] = g.symbol2number["funcdef"]
        g

# Generated at 2022-06-21 10:14:56.675536
# Unit test for method setup of class Parser
def test_Parser_setup():
    import pgen.grammar as g
    g1 = g.Grammar(r"blib2to3/pgen2/Grammar.txt")
    p = Parser(g1)
    p.setup()
    assert p.stack is not None


# Generated at 2022-06-21 10:15:01.990732
# Unit test for method setup of class Parser
def test_Parser_setup():
    from grammars import (
        Grammar,
    )  # NOQA
    from . import driver
    p = driver.Parser(Grammar())
    p.setup()
    assert p.stack == [
        (
            [
                [
                    (
                        1,
                        0,
                    )
                ],
                [(0, 0)],
            ],
            0,
            (
                256,
                None,
                None,
                [],
            ),
        )
    ]

# Generated at 2022-06-21 10:15:04.781480
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("msg", 1, "value", "context")
    assert str(e) == "msg: type=1, value='value', context='context'"

# Generated at 2022-06-21 10:15:08.769984
# Unit test for method push of class Parser
def test_Parser_push():
    from . import pygram
    from .pgen import driver

    parse = driver.parse
    assert parse("for x in y: pass")
    assert parse("for x in y: pass", debug=True)

# Generated at 2022-06-21 10:15:16.059436
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.parser import Parser

    def lam_sub(grammar, node):
        assert node[3] is not None
        return node

    p = Parser(Grammar(start=None), lam_sub)

    try:
        p.shift(None, None, 0, None)
    except TypeError:
        #  Expected TypeError
        pass
    else:
        #  Unexpected failure
        raise TypeError()



# Generated at 2022-06-21 10:15:24.877456
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2.pgen import generate_grammar, load_grammar

    gr = generate_grammar(open("/dev/null"))
    p = Parser(gr, lam_sub)
    p.setup(None)
    tok = (1, "@", (1, 0))
    p.addtoken(*tok)
    dfa, state, node = p.stack[-1]
    tok = (2, ":", (1, 2))
    p.addtoken(*tok)
    dfa, state, node = p.stack[-1]
    tok = (1, "@", (1, 3))
    p.addtoken(*tok)
    dfa, state, node = p.stack[-1]

# Generated at 2022-06-21 10:15:28.427708
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2 import driver

    _, parser, t = driver.load_grammar("Grammar/Grammar", convert=lam_sub)
    try:
        parser.setup()
        # test_Parser_push
        parser.push(1, (2, 3), 4, 5)
    except:
        raise
    # test_Parser_push_after
    assert parser.stack == [(1, 0, 2), (2, 3, 4)]


# Generated at 2022-06-21 10:16:38.936551
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import parser as cpparser
    import grammar
    import sys

    input = "[x for x in range(3)]"
    g = cpparser.Parser(grammar.Grammar([input], 1))
    g.setup()
    assert g.rootnode is None
    g.addtoken(1, '[', None)
    assert g.rootnode is None
    g.addtoken(1, 'x', None)
    assert g.rootnode is None
    g.addtoken(1, 'for', None)
    assert g.rootnode is None
    g.addtoken(1, 'x', None)
    assert g.rootnode is None
    g.addtoken(1, 'in', None)
    assert g.rootnode is None
    g.addtoken(1, 'range', None)
    assert g.root

# Generated at 2022-06-21 10:16:51.635323
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import pgen2
    from .pgen2.parse import driver
    import optparse
    import blib2to3.pgen2.parse as parse

    # Parse command line options
    p = optparse.OptionParser(usage="%prog [OPTIONS] [INPUTFILE]")
    p.add_option("-o", "--output-file", dest="output_file", default=None,
                 help="Write output to OUTPUT_FILE", metavar="OUTPUT_FILE")
    p.add_option("-V", "--version", action="store_true",
                 help="Output the version number of pgen2 and exit")

    options, args = p.parse_args()

    if options.version:
        print("This is pgen2 version %s" % parse.__version__)
       

# Generated at 2022-06-21 10:16:56.982433
# Unit test for constructor of class Parser
def test_Parser():
    import blib2to3.pgen2.pgen

    p = blib2to3.pgen2.pgen.Driver(blib2to3.pgen2.pgen.PythonGrammar, debug=0)
    p.parse_tokens("""
    if 1:
        pass
    """.split())

    p = Parser(blib2to3.pgen2.pgen.PythonGrammar)



# Generated at 2022-06-21 10:17:04.413456
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Get a simple grammar
    import blib2to3.pgen2.convert
    g = blib2to3.pgen2.convert.make_grammar(
        {
            "S'": [("S", [])],
            "S": [("a", [])],
            "b": [("b", [])],
        },
        "S",
    )
    # Create a parser and classify a token
    p = Parser(g)
    result = p.classify(token.NAME, "a", None)
    assert result == 1

# Generated at 2022-06-21 10:17:15.643508
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Test the shift method
    import tempfile

    def try_shift(grammar_text, type, value, context=(0, 0)):
        tmpfile = tempfile.NamedTemporaryFile(mode="w+")
        tmpfile.write("%s\n%%start\n%%\n%%\n" % grammar_text)
        tmpfile.seek(0)
        import blib2to3.pgen2.grammar

        g = blib2to3.pgen2.grammar.Grammar(tmpfile)
        p = Parser(g)
        p.setup()
        p.shift(type, value, 0, context)

    try_shift('%s s <"s">', 21, "s")
    try_shift('%s s { "s" }', 21, "s")


#

# Generated at 2022-06-21 10:17:27.046598
# Unit test for method push of class Parser
def test_Parser_push():
    # Test the push method of class Parser
    # This method is involved in a crash reported as SF bug #1540693
    from .pgen2 import driver
    from .pgen2.parse import ParseError
    import os
    import sys
    import types

    if sys.version_info >= (3, 3):
        module = types.ModuleType("__foo__")
    else:
        module = types.ModuleType("__foo__", "")
    module.__file__ = "__foo__.py"
    sys.modules["__foo__"] = module


# Generated at 2022-06-21 10:17:33.793458
# Unit test for method shift of class Parser
def test_Parser_shift():
    fname = 'blib2to3/pgen2/pgen.g'
    grammar = Grammar(fname)
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NEWLINE, '\n', Context(0, 1))
    parser.addtoken(token.NAME, 'A', Context(0, 1))
    parser.addtoken(token.NEWLINE, '\n', Context(0, 1))

# Generated at 2022-06-21 10:17:36.179602
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    assert True


if __name__ == "__main__":
    test_Parser_addtoken()

# Generated at 2022-06-21 10:17:46.919930
# Unit test for constructor of class Parser
def test_Parser():
    """
    p = Parser(grammar, [converter])  # create instance
    p.setup([start])                  # prepare for parsing
    <for each input token>:
        if p.addtoken(...):           # parse a token; may raise ParseError
            break
    root = p.rootnode                 # root of abstract syntax tree

    """
    from . import grammar

    def convert(grammar: Grammar, node: RawNode) -> NL:
        assert node[3] is not None
        assert node[2] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    g = grammar.Grammar(grammar.grammar)
    assert g.flags == 0
    p = Parser(g, convert)
    p.setup()
    p.addtoken

# Generated at 2022-06-21 10:17:56.864145
# Unit test for method setup of class Parser
def test_Parser_setup():
    class FakeGrammar:
        def __init__(self):
            self.start = 1
            self.dfas = {1: {0: [(1, 2), (2, 3)]}, 2: {0: [(1, 2), (2, 3)]}}

    g = FakeGrammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[1], 0, (1, None, None, []))]

    p.addtoken(2, "a", None)
    assert p.stack == [(g.dfas[1], 2, (1, None, None, [(2, "a", None, None)])),
                       (g.dfas[2], 0, (2, None, None, []))]

# Generated at 2022-06-21 10:18:40.413272
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("msg", token.NUMBER, "42", ((1, 2), (3, 4)))
    assert (e.msg, e.type, e.value, e.context) == (
        "msg",
        token.NUMBER,
        "42",
        ((1, 2), (3, 4)),
    )
    # Try to make sure the instance variables are there.
    assert e.msg == "msg"
    assert e.type == token.NUMBER
    assert e.value == "42"
    assert e.context == ((1, 2), (3, 4))

# Generated at 2022-06-21 10:18:48.319081
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import pytree
    import unittest
    import blib2to3.pgen2.dump as dump
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.token as token

    class ParserTestCase(unittest.TestCase):
        def parse(self, input):
            p = Parser(self.grammar, pytree.convert)
            p.setup()
            for t in input:
                if p.addtoken(t[0], t[1], t[2]):
                    break
            return p.rootnode

        def test(self, text, expected):
            output = self.parse(dump.tokenize(text))
            self.assertEqual(output, expected)


# Generated at 2022-06-21 10:18:55.846959
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.grammar
    from . import driver


# Generated at 2022-06-21 10:19:07.770669
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.pgen import tokenize
    import io

    g = Grammar()
    g.load()

    p = Parser(g)
    p.setup()
    tokens = tokenize(io.StringIO(
        "import os\n"
        "from abc import *\n"
    ), True)
    for t in tokens:
        p.addtoken(*t)
    expected = (2, "import", (1, 0))
    actual = p.rootnode[0]
    assert expected == actual, "Got %s, expected %s" % (actual, expected)
    expected = "import os"
    actual = "".join(n.value for n in p.rootnode[1])

# Generated at 2022-06-21 10:19:11.634665
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar(b"")
    x = RawNode(0, None, None, [RawNode(1, "a", None, None)])
    assert lam_sub(grammar, x) == Node(0, [Leaf(1, "a")])

# Generated at 2022-06-21 10:19:16.861881
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import parse_grammar

    test_grammar = """
    start: NAME
    """
    file_input = """
    a = 1
    """
    parser = Parser(parse_grammar(test_grammar))
    for token in tokenize.generate_tokens(StringIO(file_input).readline):
        if parser.addtoken(*token):
            break
    assert parser.rootnode.children[0].type == token.NAME

# Generated at 2022-06-21 10:19:20.497275
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", "type", "value", "context")
    except ParseError:
        pass
    else:
        assert 0, "ParseError constructor failed"


# Generated at 2022-06-21 10:19:25.061559
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    dummy_grammar: Grammar = grammar.Grammar()
    node = (5, None, None, [(1, "foo", (1, 0), None), (2, "bar", (1, 0), None)])
    assert lam_sub(dummy_grammar, node) is not None

# Generated at 2022-06-21 10:19:34.868621
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver

    def test():
        p = driver.load_grammar("Grammar.txt")
        parser = Parser(p, lam_sub)
        parser.setup()
        assert parser.convert is lam_sub
        assert parser.grammar is p
        assert parser.stack == [(p.dfas[p.start], 0, (p.start, None, None, []))]
        parser.stack.append((p.dfas[token.NAME], 0, (token.NAME, None, None, [])))
        parser.stack.append((p.dfas[token.NAME], 0, (token.NAME, None, None, [])))

# Generated at 2022-06-21 10:19:37.956691
# Unit test for method classify of class Parser
def test_Parser_classify():
    name = "abcdefg"
    grammar = Grammar(sequence=False, whitespace="", comments_format=(), keywords={})
    grammar.tokens = { token.NAME: 0 }
    parser = Parser(grammar=grammar, convert=None)
    result = parser.classify(type=token.NAME, value=name, context=None)
    assert result == 0