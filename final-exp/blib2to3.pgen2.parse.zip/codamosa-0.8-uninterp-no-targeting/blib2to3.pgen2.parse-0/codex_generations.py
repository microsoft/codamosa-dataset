

# Generated at 2022-06-21 10:10:23.101356
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test ParseError class"""
    p = ParseError("bad input", 1, "s", Context(1, 1, ""))
    assert p.msg == "bad input"
    assert p.type == 1
    assert p.value == "s"
    assert p.context == Context(1, 1, "")


# Generated at 2022-06-21 10:10:25.566124
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar())
    p.setup()
    p.setup(start=1)

# Generated at 2022-06-21 10:10:36.556534
# Unit test for method classify of class Parser
def test_Parser_classify():
    import pprint
    from . import driver, grammar, token

    print("import pprint")
    print("import parser")
    print("from . import driver, grammar, token")
    print()
    print("p = parser.Parser(grammar.Grammar())")
    p = Parser(grammar.Grammar())
    print("p.classify(token.NAME, 'else', None)")
    pprint.pprint(p.classify(token.NAME, "else", None))
    print("p.classify(token.NAME, 'if', None)")
    pprint.pprint(p.classify(token.NAME, "if", None))
    print("p.classify(token.NAME, 'if2', None)")

# Generated at 2022-06-21 10:10:43.347856
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from typing import Dict, List, Any
    g: Grammar = driver.GraphAlgorithmGrammar()
    ch: Dict[str, List[Any]] = {}
    def convert(grammar: Grammar, node: RawNode) -> Node:
        assert node[3] is not None
        return Node("MockNode", children=node[3])
    p = Parser(grammar=g, convert=convert)
    p.setup()
    p.addtoken(g.keywords["graph"], "graph", "MockContext")
    p.addtoken(g.keywords["algorithm"], "algorithm", "MockContext")
    node = p.pop()
    assert node.data == "MockNode"
    assert len(node.children) == 2

# Generated at 2022-06-21 10:10:52.432846
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class MyParser(Parser):
        def __init__(self) -> None:
            from . import parsetok
            from . import tokenize
            self.grammar = parsetok.parsetok
            self.convert = parsetok.convert
            self.tokens = tokenize.generate_tokens

    p = MyParser()
    p.setup()
    for t in p.tokens("x = 1"):
        print(t)
        p.addtoken(t.type, t.string, t.start)

# Generated at 2022-06-21 10:11:05.617079
# Unit test for method shift of class Parser
def test_Parser_shift():
    import sys
    import blib2to3.pgen2.driver as driver
    import blib2to3.pgen2.tokenize as tokenize
    from . import token

    # Run the following code to test the shift functionality
    if sys.version_info < (3,):
        g = driver.load_grammar_file(sys.argv[1])
    else:
        f = open(sys.argv[1], "rb")
        g = driver.load_grammar_file(f)
        f.close()
    p = Parser(g)

    # 1. Test if shift is called
    import mock
    with mock.patch.object(p, 'shift', autospec=True) as mock_p_shift:
        p.addtoken(token.NAME, "test", None)
        mock_p

# Generated at 2022-06-21 10:11:16.824932
# Unit test for function lam_sub
def test_lam_sub():
    def make_context(offset: int) -> Context:
        return Context(None, offset)

    def make_nodes(*args: Sequence[Any]) -> List[Any]:
        return list(args)

    def assert_node_equal(na: Node, nb: Node) -> None:
        assert na == nb
        assert na is not nb

    grammar = Grammar()
    assert grammar is not None
    parser = Parser(grammar)
    assert parser is not None
    ctx1 = make_context(1)
    ctx2 = make_context(2)
    ctx3 = make_context(3)
    ctx4 = make_context(4)
    ctx5 = make_context(5)
    ctx6 = make_context(6)
    ctx7 = make_context(7)

# Generated at 2022-06-21 10:11:18.558278
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test the constructor of class ParseError"""
    # no exception raised
    ParseError()

# Generated at 2022-06-21 10:11:28.493137
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.classify(token.NAME, "foo", None) == 32
    assert p.classify(token.NAME, "or", None) == 5
    assert p.classify(token.NAME, "and", None) == 7
    assert p.classify(token.NAME, "is", None) == 34
    assert p.classify(token.NAME, "print", None) == 244
    # XXX Bad token number
    assert p.classify(token.NAME, "not", None) == 35



# Generated at 2022-06-21 10:11:40.630069
# Unit test for method pop of class Parser
def test_Parser_pop():
    import unittest
    import sys
    import os

    class TestParser(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.orig_path = sys.path[:]
            sys.path.insert(0, os.path.join("lib2to3", "pgen2", "test"))
            self.grammar = Grammar("Grammar.txt")
            self.parser = Parser(self.grammar, convert=lam_sub)
            self.parser.setup()
            self.parser.used_names = {"spam"}

        def tearDown(self):
            sys.path = self.orig_path
            sys.modules.pop("Grammar", None)


# Generated at 2022-06-21 10:11:54.485409
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Foobar", None, None, None)
    except ParseError as e:
        assert e.msg == "Foobar", "Message should be 'Foobar'"
        assert e.type is None, "Type should be None"
        assert e.value is None, "Value should be None"
        assert e.context is None, "Context should be None"

# Generated at 2022-06-21 10:12:05.505507
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    import pytree
    driver.grammar = grammar
    driver.tokens = grammar.tokens
    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NAME, "print", (1, 0))
    p.addtoken(token.NAME, "bla", (1, 6))
    p.addtoken(token.NEWLINE, "", (2, 0))

    assert p.rootnode is None
    p.pop()
    n = p.rootnode
    assert  isinstance(n, pytree.Node)
    assert len(n.children) == 3
    assert n.children[0].type == token.NAME
    assert n.children[0].value == "print"
    assert n.children[1].type == token

# Generated at 2022-06-21 10:12:11.054987
# Unit test for function lam_sub
def test_lam_sub():
    foo = test_lam_sub
    g = Grammar(foo, {}, {}, {})
    node = (1, None, None, [2, 3, 4])
    assert lam_sub(g, node) == Node(type=1, children=(2, 3, 4), context=None)

# Generated at 2022-06-21 10:12:23.383126
# Unit test for method addtoken of class Parser

# Generated at 2022-06-21 10:12:27.334713
# Unit test for function lam_sub
def test_lam_sub():
    class grammar:
        dfas = {1: (None, None)}
    n = (1, None, None, [])
    assert lam_sub(grammar, n) == Node(type=1, children=[], context=None)


# Generated at 2022-06-21 10:12:35.205559
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar(token, "test")
    p = Parser(g)


# Generated at 2022-06-21 10:12:44.345261
# Unit test for method pop of class Parser
def test_Parser_pop():
    import ast
    import inspect

    def test(lines, expected_lines=None):
        if expected_lines is None:
            expected_lines = lines
        code = inspect.cleandoc(lines)
        p = Parser(ast.grammar)
        p.setup()
        for t in ast.tokenize(code):
            if p.addtoken(t.type, t.string, Context(t.start, t.end, t.line)):
                break
        else:
            print('ERROR: unexpected end of code')
        actual_lines = p.rootnode.tounicode().splitlines()
        expected_lines = inspect.cleandoc(expected_lines).splitlines()
        if actual_lines != expected_lines:
            print('ERROR: expected lines:')

# Generated at 2022-06-21 10:12:55.224995
# Unit test for constructor of class Parser
def test_Parser():
    import unittest
    import blib2to3.pgen2.pgen

    class ParserTest(unittest.TestCase):

        def setUp(self):
            self.g = blib2to3.pgen2.pgen.generate_grammar()

        def test_some_tokens(self):
            p = Parser(self.g)
            p.setup()
            for type, value in (
                (token.NUMBER, "1"),
                (token.PLUS, "+"),
                (token.NUMBER, "2"),
                (token.NEWLINE, "\n"),
            ):
                self.assertFalse(p.addtoken(type, value, None))
            self.assertIsNotNone(p.rootnode)

    unittest.main()  # run all tests in this module

# Generated at 2022-06-21 10:13:07.238710
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class MockGrammar(object):
        labels = [('', 0, 0)]
        keywords = {'key': 1}
        tokens = {token.NAME: 2}
        dfas = {
            1: DFA(
                states=[
                    [],
                    [(1, 0)],
                    [(1, 0)],
                    [(1, 0)],
                    [(1, 0)],
                    [(1, 0)],
                    [(1, 0)],
                    [(1, 0)],
                    [(1, 0)],
                    [(1, 0)],
                    [(1, 0)],
                ],
                labels=['', '', '', '', '', '', '', '', '', '', ''],
            )
        }

    parser = Parser(MockGrammar())
    parser.setup(1)


# Generated at 2022-06-21 10:13:10.722086
# Unit test for function lam_sub
def test_lam_sub():
    # type: () -> None
    """Unit test for function lam_sub"""
    n = lam_sub(None, (1, None, None, []))  # type: NL
    assert type(n) is Node
    assert n.type == 1
    assert n.children == []
    l = lam_sub(None, (2, 'x', None, None))  # type: Leaf
    assert type(l) is Leaf
    assert l.type == 2
    assert l.value == "x"


# Generated at 2022-06-21 10:13:33.655314
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.refactor import get_fixers_from_package
    from blib2to3.fixer_base import Fixer
    import sys
    import datetime
    import _ast
    class hack:
        def __init__(self):
            self.syms = [getattr(_ast, sym) for sym in dir(_ast) if sym[:1] != '_']
        def __contains__(self, sym):
            return sym in self.syms

    # get fixers
    fixers = get_fixers_from_package("blib2to3.fixes")
    fixers.sort(key=lambda fixer: fixer.order)
    fixers = [fixer for fixer in fixers if isinstance (fixer, Fixer)]

# Generated at 2022-06-21 10:13:46.015212
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class FakeGrammar(object):
        def __init__(self) -> None:
            self.start = 256
            self.labels = [
                (token.LPAR, "("),
                (token.RPAR, ")"),
                (token.LSQB, "["),
                (token.RSQB, "]"),
                (256, "s"),
                (257, "slist"),
                (258, "x"),
                (259, "xlist"),
                (260, "y"),
                (261, "ay"),
                (262, "by"),
            ]
            self.dfas: Dict[int, DFAS] = {}

# Generated at 2022-06-21 10:13:51.942991
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", token.NAME, "name", (1, 1))
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == token.NAME
        assert e.value == "name"
        assert e.context == (1, 1)
    else:
        assert False, "ParseError not raised"

# Generated at 2022-06-21 10:14:00.790366
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class TestParser(Parser):
        # Mockup version of classify
        def classify(self, type, value, context):
            if type == token.NAME:
                if value == "foo":
                    return 1
                elif value == "bar":
                    return 2
            elif type == token.NUMBER:
                return 3
            elif type == token.NEWLINE:
                return 4
            raise ParseError

    p = TestParser(None)
    p.setup()
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NEWLINE, None, None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NEWLINE, None, None)


# Generated at 2022-06-21 10:14:04.758121
# Unit test for method pop of class Parser
def test_Parser_pop():
    foo = Parser(None)
    foo.stack = [1,2,3]
    foo.pop()
    assert foo.stack == [1,2]


# Generated at 2022-06-21 10:14:14.531249
# Unit test for method push of class Parser
def test_Parser_push():
    from .pgen import driver  # type: ignore
    from . import grammar

    import os.path, pickle
    test_grammar = os.path.join(os.path.dirname(__file__), "..", "..", "2to3", "Grammar.txt")
    pgen = driver.Driver(test_grammar, "Parser/pgen.pickle")
    pgen.generate_grammar()
    with open("Parser/pgen.pickle", "rb") as pickle_file:
        gram = pickle.load(pickle_file)
    p = Parser(gram, None)

    p.setup()
    for i in range(5):
        x, y, z = 1, 2, 3
        p.push(1, (2, 3), 2, x, 2, z)

# Generated at 2022-06-21 10:14:25.890741
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    g.symbol2number = {'file_input': 256, 'stmt': 257, 'expr': 258}
    g.number2symbol = ['',
                       '',
                       '',
                       'file_input',
                       '',
                       'stmt',
                       'expr']

    g.start = 256
    g.tokens = {1: 0, 2: 1}
    g.labels = [(1, 1), (2, 1)]
    g.keywords = {}


# Generated at 2022-06-21 10:14:30.554928
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = Grammar()
    parser = Parser(grammar)
    t = (1, [])
    parser.push(1, t, 1, None)
    assert parser.stack == [(t, 0, (1, None, None, []))]



# Generated at 2022-06-21 10:14:39.587857
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Unit test for method addtoken of class Parser"""
    from . import driver


# Generated at 2022-06-21 10:14:51.518205
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import tokenize
    import sys

    encoding = 'utf-8'
    filename = "./Python-3.4.2/Lib/lib2to3/tests/data/fixers/fix_import/__init__.py"
    f = driver.open_file(filename, encoding=encoding)

# Generated at 2022-06-21 10:15:18.446030
# Unit test for method classify of class Parser
def test_Parser_classify():
    p = Parser(Grammar(""))
    p.classify(1, None, None)

# Generated at 2022-06-21 10:15:28.907953
# Unit test for constructor of class ParseError
def test_ParseError():
    # Inconsistent number of arguments
    try:
        raise ParseError("a", 1, 2)
    except TypeError:
        pass
    # Wrong type for argument 2
    try:
        raise ParseError("a", "1", 2, 3)
    except TypeError:
        pass
    # Wrong type for argument 3
    try:
        raise ParseError("a", 1, "2", 3)
    except TypeError:
        pass
    # Wrong type for argument 4
    try:
        raise ParseError("a", 1, 2, "3")
    except TypeError:
        pass

# Generated at 2022-06-21 10:15:36.829266
# Unit test for constructor of class Parser
def test_Parser():
    import io
    import unittest
    import unittest.mock

    class ParserTestCase(unittest.TestCase):
        def setUp(self):
            self.stream = io.StringIO("")
            self.mock_grammar = unittest.mock.sentinel.mock_grammar
            self.mock_convert = unittest.mock.sentinel.mock_convert
            self.parser = Parser(self.mock_grammar, self.mock_convert)

        def test_init_defaults(self):
            parser = Parser(self.mock_grammar)
            self.assertEqual(parser.convert, lam_sub)
            self.assertEqual(parser.grammar, self.mock_grammar)


# Generated at 2022-06-21 10:15:49.524585
# Unit test for constructor of class Parser
def test_Parser():
    from . import token, tokenize
    from .syms import symbols
    from .pgen import driver
    from . import expr

    g = driver.load_grammar("Grammar.txt")
    p = Parser(g)

    p.setup(symbols.funcdef)
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        if p.addtoken(t[0], t[1], (t[2][0], t[2][1] or 0)):
            break
    r = p.rootnode
    assert r.type == symbols.file_input
    assert r[1].type == symbols.funcdef
    assert r[1, 3].type == symbols.parameter
    assert r[1, 3, 1, 1].type == token.NAME
    assert r

# Generated at 2022-06-21 10:15:58.025276
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2.grammar import Grammar
    g = Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(1, "test", None)
    p.addtoken(4, "test4", None)
    p.addtoken(3, "test3", None)
    p.addtoken(2, "test2", None)
    assert p.rootnode.type == 1
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == 2
    assert p.rootnode.children[1].type == 3
    assert p.rootnode.children[2].type == 4

# Generated at 2022-06-21 10:16:10.379358
# Unit test for method push of class Parser
def test_Parser_push():
    import blib2to3.pgen2.pgen as pgen
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.tokenize import generate_tokens

    input_data = """
    whi(l)e (1)
    """
    tokens = list(generate_tokens(input_data.__iter__().__next__))
    grammar = pgen.load_grammar(
        r"D:\work\blib2to3\bin\py2-grammar.txt",
        r"D:\work\blib2to3\lib2to3\Grammar.txt",
    )
    parser = Parser(grammar)

# Generated at 2022-06-21 10:16:11.766601
# Unit test for method shift of class Parser
def test_Parser_shift():
    gr = Grammar()
    p = Parser(gr)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 2))

# Generated at 2022-06-21 10:16:14.626615
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.push(0, 1, 0, None)
    assert len(parser.stack) == 2

# Generated at 2022-06-21 10:16:15.755558
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    pass


# Generated at 2022-06-21 10:16:24.772351
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .driver import Driver
    from .pgen import main, read_grammar
    import sys
    import unittest

    class TestShift(unittest.TestCase):
        def test_Parser_shift(self):
            try:
                main(["blib2to3.pgen2.pgen", "Lib/lib2to3/Grammar.txt"])
            finally:
                sys.stdout = sys.__stdout__
            parser = Parser(read_grammar("Parser/Grammar"))
            parser.setup()
            driver = Driver(parser, convert=lam_sub)
            driver.tokenize("\n")
            driver.addtoken(token.NAME, "if", (1, 0))
            self.assertIsNotNone(parser.rootnode)

# Generated at 2022-06-21 10:16:56.234431
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = Grammar(open("Calc.grammar", "r"))
    parser = Parser(grammar)
    parser.setup()
    assert 1 == parser.classify(token.NUMBER, "42", (1, 0))
    assert 4 == parser.classify(token.NAME, "foo", (1, 0))
    assert 5 == parser.classify(token.NAME, "True", (1, 0))
    assert 5 == parser.classify(token.NAME, "False", (1, 0))
    assert 6 == parser.classify(token.NAME, "bar", (1, 0))

# Generated at 2022-06-21 10:16:59.164287
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser("")
    p.setup(13)
    assert p.grammar == "", f"Expected 13, got {p.stack[-1][0]}"

# Generated at 2022-06-21 10:17:07.760452
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.Grammar()

    class DummyConvert(Callable[[Grammar, RawNode], Union[Node, Leaf]]):
        def __init__(self) -> None:
            self.called = 0

        def __call__(self, grammar: Grammar, node: RawNode) -> Union[Node, Leaf]:
            self.called += 1
            return node

    c = DummyConvert()

    class TestError(Exception):
        pass

    class TestParser(Parser):
        def __init__(self) -> None:
            Parser.__init__(self, g, c)

        def classify(self, type: int, value: Optional[Text], context: Context) -> int:
            raise TestError

    p = TestParser()

# Generated at 2022-06-21 10:17:13.531392
# Unit test for method setup of class Parser
def test_Parser_setup():
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.parse as parse

    gr = grammar.grammar
    parser = parse.Parser(gr, convert=lam_sub)
    parser.setup(start=grammar.syms.file_input)
    print(parser.stack)

# Generated at 2022-06-21 10:17:25.755461
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from .grammar import dfas, nfa  # type: ignore
    from .grammar import G

    g = grammar.Grammar()
    g.start = "s"
    g.labels = {0: ("foo", None), 1: ("bar", None), 2: ("lam", None)}
    g.keywords = {
        "foo": 0,
    }
    g.literal_tokens = set(["bar"])
    g.non_literal_tokens = set(["lam"])
    g.tokens = {
        "foo": 0,
        "bar": 1,
        "lam": 2,
    }

# Generated at 2022-06-21 10:17:31.432215
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar()
    node = (0, None, None, [(1, None, None, None), (2, None, None, None)])
    result = lam_sub(grammar, node)
    assert isinstance(result, Node)
    assert result.type == 0
    assert len(result.children) == 2
    assert isinstance(result.children[0], Leaf)
    assert isinstance(result.children[1], Leaf)

# Generated at 2022-06-21 10:17:36.593294
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("foo", 1, "bar", None)
    except ParseError as pe:
        assert pe.msg == "foo"
        assert pe.type == 1
        assert pe.value == "bar"
        assert pe.context is None



# Generated at 2022-06-21 10:17:44.523877
# Unit test for constructor of class ParseError
def test_ParseError():
    test_cases = [
        ParseError("m1", None, None, None),
        ParseError("m2", 1, "a", (1, 2)),
        ParseError("m3", 3, "bc", (3, 4)),
        ParseError("m4", 5, "d", None),
    ]
    for case in test_cases:
        assert case.msg == case.args[0]
        assert case.type == case.args[1]
        assert case.value == case.args[2]
        assert case.context == case.args[3]

# Generated at 2022-06-21 10:17:53.759269
# Unit test for method shift of class Parser
def test_Parser_shift():
    class Token:
        def __init__(self, type, value, context):
            self.type = type
            self.value = value
            self.context = context

    def convert(grammar, node):
        return node

    parser = Parser(grammar.Grammar(), convert)
    parser.setup()
    token = Token(1, "1", (1, 0))
    parser.shift(token.type, token.value, 0, token.context)
    token = Token(2, "2", (2, 1))
    parser.shift(token.type, token.value, 0, token.context)
    print(parser.stack)
    print(parser.rootnode)

# Generated at 2022-06-21 10:17:59.718873
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    from blib2to3.pgen2.parse import load_grammar
    parser = Parser(load_grammar())
    test_string = \
        """
foo:
    a = 'a'
    b = a
"""
    parser.setup()
    for token_ in generate_tokens(iter([test_string]).__next__):
        parser.addtoken(*token_)
    assert parser.rootnode.children[0].children == ['a', 'a']
    assert untokenize(parser.rootnode) == untokenize(test_string)


# Generated at 2022-06-21 10:18:55.531724
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def test(*args, **kwargs):
        parser.addtoken(*args, **kwargs)

    from .tokenize import generate_tokens

    class Grammar:
        start = 42
        dfas = {42: ([[(1, 2), (2, 3)], [(2, 3)], [(3, 3)]], {1: 2, 2: 2, 3: 2})}
        tokens = {3: 4}
        labels = {1: (1, None), 2: (2, None), 3: (3, None), 4: (3, "3")}

    parser = Parser(Grammar())
    parser.setup(42)

    test(3, "3", None)
    test(3, "3", None)
    test(3, "3", None)



# Generated at 2022-06-21 10:19:07.291264
# Unit test for method classify of class Parser
def test_Parser_classify():
    # test the classify method of Parser, which should turn tokens into labels
    import inspect
    import sys
    import os
    import tempfile
    from io import StringIO
    from . import grammar
    from . import token, tokenize
    from . import driver
    from . import convert
    from . import pgen2

    pgen2.main(["blib2to3/pgen2/parse.py", "blib2to3/Grammar"])

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    stream = StringIO("def function():\n    return None")
    tokens = tokenize.generate_tokens(stream.readline)

# Generated at 2022-06-21 10:19:13.896273
# Unit test for function lam_sub
def test_lam_sub():
    x = (1, None, (1, 0), [[(2, None, (1, 0), None)],
                         [(2, None, (1, 0), None),
                          (2, None, (1, 0), None)]])
    y = lam_sub(None, x)
    assert y.type == 1
    assert y.children == [[(2, None, (1, 0), None)],
                          [(2, None, (1, 0), None),
                           (2, None, (1, 0), None)]]

# Generated at 2022-06-21 10:19:20.704091
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver

    def lam_sub(grammar, node):
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    g = driver.load_grammar("../Grammar/Grammar")
    p = Parser(g, lam_sub)
    p.setup()
    p.addtoken(1, "class", (0, 0))
    p.addtoken(2, "obj", (0, 0))
    p.addtoken(3, ":", (0, 0))
    p.addtoken(4, "pass", (0, 0))

    assert len(p.stack) == 1
    assert p.rootnode is not None

# Generated at 2022-06-21 10:19:30.991638
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.parse import tokenizer, parse_tokens
    from blib2to3.pgen2 import grammar, token

    try:
        from . import grammar as my_grammar
    except ImportError:
        from . import _pgen_grammar as my_grammar

    assert my_grammar, "No grammar object found."
    assert my_grammar.dfas, "No dfas object found."

    x = my_grammar.keywords["each"]
    assert x == my_grammar.labels[x][0], "Bad tokens object found."

    my_pgen = Parser(my_grammar)

    def test_parser(s: Text) -> None:
        print(s)
        my_pgen.setup()
        t = tokenizer.generate_t

# Generated at 2022-06-21 10:19:38.738329
# Unit test for method pop of class Parser
def test_Parser_pop():
    my_grammar = Grammar(None)
    my_grammar.start = 256
    my_dfas = (  [[(0,0)], [(0,1), (256,1), (0,2)]], {0:2, 1:1, 2:0} )
    my_convert = lambda my_grammar, node: None
    my_node =          (256, None, (1,1), [ Node(type=256, children=[], context=(2,2)),  Node(type=token.INDENT, children=[], context=(3,3)),  Node(type=token.INDENT, children=[], context=(4,4)) ])
    my_dfa = my_dfas[0]
    my_start_state = 0
    my_token = token.INDENT
    my_value = "1"
   

# Generated at 2022-06-21 10:19:46.673082
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Check the timing behaviour of Parser.addtoken."""
    # 1st magnitude: 2 secs
    for count in range(20):
        for j in range(10):
            dfa = [[(0, 0)]]
            stack = [(dfa, 0, (0, 0, 0, []))]
            for i in range(10000):
                dfa, state, node = stack[-1]
                states, first = dfa
                arcs = states[state]
                for i, newstate in arcs:
                    stack.append((dfa, newstate, node))
                stack.pop()
            assert not stack


# Generated at 2022-06-21 10:19:49.914653
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar()
    p = Parser(grammar)
    assert not hasattr(p, "stack")
    p.setup()
    assert hasattr(p, "stack")


# Generated at 2022-06-21 10:19:56.133041
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2 import driver

    gp = driver.load_grammar("Python.g")
    g = gp.grammar

    p = Parser(g)
    p.setup(g.start)

    p.shift(token.NAME, "cls", 0, None)
    # p.shift(token.NAME, "cls", 0, None)
    print(p.stack)

# Generated at 2022-06-21 10:20:02.183440
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    p = Parser(grammar.token_grammar)
    p.setup()
    assert p.classify(token.NAME, "a", None) == grammar.token_grammar.labels[5][0]
    assert p.classify(token.NAME, "and", None) == grammar.token_grammar.labels[1][0]
    assert p.classify(token.NAME, "0", None) == grammar.token_grammar.labels[5][0]
    assert p.classify(token.NAME, "and1", None) == grammar.token_grammar.labels[5][0]
    assert p.classify(token.NAME, "0and1", None) == grammar.token_grammar.labels[5][0]
