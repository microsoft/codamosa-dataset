

# Generated at 2022-06-21 10:10:12.442174
# Unit test for constructor of class Parser
def test_Parser():
    import sys
    import tempfile
    import blib2to3.pgen2.grammar

    grammar = blib2to3.pgen2.grammar.Grammar(tempfile.mktemp())
    parser = Parser(grammar)
    # Test if cache is created
    assert parser.grammar is grammar
    # Test if self.convert is initialized
    assert parser.convert is blib2to3.pgen2.pgen.lam_sub


# Generated at 2022-06-21 10:10:24.841675
# Unit test for constructor of class ParseError
def test_ParseError():
    class FakeContext(object):
        def __str__(self):
            return "FakeContext"

    try:
        raise ParseError("msg", 1, "value", FakeContext())
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == 1
        assert e.value == "value"
        assert e.context == "FakeContext"
    else:
        assert False, "No ParseError raised"
    try:
        raise ParseError("msg", None, None, None)
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type is None
        assert e.value is None
        assert e.context is None
    else:
        assert False, "No ParseError raised"


# Generated at 2022-06-21 10:10:32.203406
# Unit test for method pop of class Parser
def test_Parser_pop():
    class Parser_with_grammar(Parser):
        def __init__(self, convert: Optional[Convert] = None) -> None:
            grammar = Grammar(None, None, None, None, None, None)
            super().__init__(grammar, convert)
            self.stack = []
            self.rootnode = None
    parser = Parser_with_grammar()
    parser.stack.append((None, None, (1,None,None,[])))
    parser.stack.append((None,None,(2,None,None,[])))
    parser.stack.append((None,None,(2,None,None,[])))
    parser.stack.append((None,None,(2,None,None,[])))
    parser.stack.append((None,None,(2,None,None,[])))


# Generated at 2022-06-21 10:10:43.172489
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2.convert import Convert
    from blib2to3.pgen2.token import *
    class MockGrammar(object):
        def __init__(self):
            self.symbol2label = {
                "start": 1, "nt1": 2, "nt2": 3, "nt3": 4, "t1": 5, "t2": 6, "t3": 7,
            }

# Generated at 2022-06-21 10:10:55.538489
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar as blib2to3_pygram
    from .pgen2 import token as blib2to3_pytoken
    import sys

    if sys.version_info[0] == 3 and sys.version_info[1] >= 8:
        def foo(x):
            return x

        exec(foo(r"""def test_many_arguments_to_call(x):
        for i in range(1000):
            x(i)
    """))

    p = Parser(blib2to3_pygram.python_grammar)
    driver.main_with_parser(p, "print(1)", debug=True)

    # Test that the parser correctly raises ParseError on too much
    # input.

# Generated at 2022-06-21 10:11:06.730520
# Unit test for method push of class Parser
def test_Parser_push():
    """Test the method push with a strong reference"""
    parser_instance = None
    class NonTerminal(object):
        pass
    class Terminal(object):
        pass
    expected_result = NonTerminal()
    # Define mock_push to check that the reference count of expected_result
    # is the expected one and return a predefined object
    def mock_push(self, type, newdfa, newstate, context):
        assert(sys.getrefcount(expected_result) == 2)
        self.stack.append((newdfa, 0, expected_result))
    with patch.object(Parser, 'push', mock_push):
        class MockGrammar(object):
            pass
        mock_grammar = MockGrammar()
        mock_grammar.dfas = {42: ((), (1,))}
       

# Generated at 2022-06-21 10:11:17.686557
# Unit test for method pop of class Parser
def test_Parser_pop():
    class MockGrammar:
        def __init__(self):
            self.dfas = {}
            self.labels = {}
            self.tokens = {}
            self.keywords = {}
            self.start = 1

    class MockParser:
        def __init__(self):
            self.convert = lambda x, y: self.convert_result
            self.convert_result = None
            self.rootnode = None
            self.stack = []
            self.used_names = set()

    mg = MockGrammar()
    mp = MockParser()
    mg.dfas = {1: ([[(0, 1)], [(0, 1)]], {1: 1}),
               2: ([[(0, 2)], [(0, 2)]], {2: 2})}
    mg.lab

# Generated at 2022-06-21 10:11:29.409030
# Unit test for method setup of class Parser
def test_Parser_setup():

    from . import grammar
    from . import token

    class DummyGrammar(object):
        def __init__(self):
            self.dfas = {0: (1,2)}
            self.start = 0
    class DummyGrammarNodeConverter(object):
        def __init__(self):
            self.call_count = 0
        def __call__(self, grammar: Grammar, node: Sequence[Any]) -> None:
            self.call_count += 1

    dummy_grammar = DummyGrammar()
    dummy_grammar_node_converter = DummyGrammarNodeConverter()

    parser_object = Parser(dummy_grammar, convert=dummy_grammar_node_converter)
    parser_object.setup()
    assert dummy_grammar_

# Generated at 2022-06-21 10:11:35.146488
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar.txt")
    parser = Parser(grammar)

    def test(type, value, context, ilabel):
        parser.setup()
        result = parser.classify(type, value, context)
        assert result == ilabel

    test(token.NAME, "if", 0, 0)
    test(token.NAME, "name", 0, 1)
    test(token.NUMBER, "12", 1, 256)
    test(token.NAME, "and", 2, 257)
    test(token.NAME, "or", 3, 258)
    test(token.NAME, "in", 4, 259)
    test(token.NAME, "not", 5, 260)

# Generated at 2022-06-21 10:11:39.849373
# Unit test for method setup of class Parser
def test_Parser_setup():

    import gc
    foo, bar = object(), object()
    lst = [foo, bar]
    p = Parser(None)
    p.setup()
    p.stack = lst
    p.setup()
    assert not gc.get_referrers(lst)

# Generated at 2022-06-21 10:11:51.177631
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("message", 1, "value", (1, 0))
    assert str(err) == "message: type=1, value='value', context=(1, 0)"
    assert err.msg == "message"
    assert err.type == 1
    assert err.value == "value"
    assert err.context == (1, 0)

# Generated at 2022-06-21 10:11:54.927847
# Unit test for method classify of class Parser
def test_Parser_classify():
    #python2 and python3 return different types for these numbers
    assert Parser.classify(0, 0, None) == token.ENDMARKER
    assert Parser.classify(0, 0, None) != token.NAME



# Generated at 2022-06-21 10:12:05.756526
# Unit test for function lam_sub
def test_lam_sub():
    from .pgen2.parse import ParseError

    def parse(text: Text, type: int) -> None:
        class Foo:
            pass

        grammar = Foo()
        grammar.dfas = {
            "a": (
                [[(0, 0), (1, 1)], [(0, 1)]],
                {0: {0: 0}, 1: {1: 1}},
            )
        }
        parser = Parser(grammar, lam_sub)
        parser.setup("a")
        parser.addtoken(token.NAME, "a", Context(0, 0))
        parser.addtoken(type, "b", Context(0, 0))
        parser.addtoken(token.ENDMARKER, "", Context(0, 0))


# Generated at 2022-06-21 10:12:17.673327
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import io
    from . import driver, pgen
    from .tokenize import tokenize, NAME
    from .pygram import python_symbols as syms

    filename = "Parser/empty.txt"
    f = io.StringIO("# coding: utf-8\n")
    try:
        # Read and parse the file
        p = driver.load_grammar("Grammar/Grammar")
        p.driver.init_parser()
        p.driver.setup_parse(None, f)
        tokens = list(tokenize(f.readline))
        p.driver.parse_tokens(tokens)
    finally:
        f.close()

    # Transform the concrete tree into an abstract tree
    def convert(grammar, node):
        type, value, context, children = node

# Generated at 2022-06-21 10:12:30.243110
# Unit test for method push of class Parser
def test_Parser_push():
    # prepare a test case
    token1 = (1, None, None, [])
    dfa1 = ([(1, [(0, 0)]), (1, [(0, 1)])], {0: 0, 1: 1})
    stackentry1 = (dfa1, 0, token1)
    assert stackentry1 == (dfa1, 0, token1)

    # create the target object
    test_obj = Parser(None)

    # set stack field before push
    test_obj.stack = [stackentry1]

    #call the tested method
    test_obj.push(2, dfa1, 0, Context(None, None))

    # check the result
    assert 2 == len(test_obj.stack)
    assert (dfa1, 1, token1) == test_obj.stack[0]
   

# Generated at 2022-06-21 10:12:36.358742
# Unit test for method push of class Parser
def test_Parser_push():
    # Testsuite for the parser generator.
    # Written by Thomas Wouters <thomas@xs4all.net>

    import unittest

    class Test_Parser_push(unittest.TestCase):
        """Test the push method of the Parser class."""

        def setUp(self):
            import blib2to3.pgen2.parser

            # A simple grammar to test the parser on
            grammar = [
                ('s', ('x', ('s', ('y', ('s', ('z', ('s', ('e', ('s', 'e')))))))))
            ]
            self.parser = blib2to3.pgen2.parser.Parser(grammar)

        def test_empty_push(self):
            """Test pushing an empty symbol."""
            self.parser.setup()
            self.assertE

# Generated at 2022-06-21 10:12:45.140268
# Unit test for method pop of class Parser
def test_Parser_pop():
    test_grammar = Grammar([])
    test_convert = lam_sub
    test_parser = Parser(test_grammar, test_convert)
    test_dfas = (
        (((1, 0), (1, 0)), ((2, 1), (3, 1))),
        {0: [(1, 0), (1, 0)], 1: [(2, 1), (3, 1)]},
    )
    test_type = 1
    test_value = "test value"
    test_context = Context(1, 1)
    test_newstate = 0
    test_stack = [(test_dfas, 0, (0, 0, 0, []))]

    test_parser.stack = test_stack
    test_parser.pop()

    assert test_parser.stack == []
    assert test_parser

# Generated at 2022-06-21 10:12:56.281224
# Unit test for method push of class Parser
def test_Parser_push():
    import blib2to3.pgen2.grammar
    import blib2to3.pgen2.parse
    import blib2to3.pgen2.token
    import blib2to3.pygram

    def lam_sub(grammar, node):
        return node

    def test_case(
        grammar,
        type,
        newdfa,
        newstate,
        expected_type,
        expected_newdfa,
        expected_newstate,
    ):
        p = blib2to3.pgen2.parse.Parser(grammar, lam_sub)
        p.stack = [(("abc", 1), 0, ("abc", None, None, [])), (("def", 1), 0, ("def", None, None, []))]

# Generated at 2022-06-21 10:13:05.038573
# Unit test for method setup of class Parser
def test_Parser_setup():
    """Parser().setup(start=None) -> None"""
    def verify_start(P: Parser, start: int) -> None:
        class foo(object):
            pass

        p = P.Parser(P.grammar)
        if hasattr(p, 'start'):
            start = p.start
        p.setup()
        assert p.start is start, repr(p.start)

    verify_start(Parser, None)

if __name__ == "__main__":
    import pytest  # type: ignore
    pytest.main(["-v", __file__])

# Generated at 2022-06-21 10:13:14.285747
# Unit test for constructor of class Parser
def test_Parser():
    from io import StringIO

    from . import driver, token, grammar

    def test_convert(g, node):
        # Convert concrete syntax tree nodes to abstract syntax tree nodes
        if node[3]:
            return token.NAME, node[0], node[3]
        else:
            return node

    def test_parse(grammar, start=None, convert=test_convert):
        # A tiny parse function useful for unit testing

        p = Parser(grammar, convert)
        p.setup(start)
        while True:
            tok = pgen.tokensource.token()
            if tok is None:
                break
            if p.addtoken(tok.type, tok.value, tok.context):
                break
        return p.rootnode

    def check(s, expected):
        f

# Generated at 2022-06-21 10:13:30.410527
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    # Construct a parser instance
    gram = grammar.Grammar()
    p = Parser(gram)

    # It's empty
    assert not p.stack
    assert p.rootnode is None



# Generated at 2022-06-21 10:13:38.012853
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2 import tokenize, driver

    gram = driver.load_grammar("Grammar.txt")
    parser = Parser(gram)
    parser.setup()
    with tokenize.StringIO("abc") as f:
        parser.addtoken(token.INDENT, "", (1, 0))
        parser.addtoken(token.NAME, "abc", (1, 0))
        parser.addtoken(token.DEDENT, "", (1, 0))
    # Try it again, but with a start symbol
    parser.setup(gram.symbol2number["suite"])

# Generated at 2022-06-21 10:13:50.984473
# Unit test for method push of class Parser
def test_Parser_push():
    # Dummy nodes:
    r1 = RawNode("r1", None, None, [])
    r2 = RawNode("r2", None, None, [])
    r3 = RawNode("r3", None, None, [])

    n1 = Node("n1", [])
    n2 = Node("n2", [])
    n3 = Node("n3", [])

    def lam_n(grammar: Grammar, node: RawNode) -> Node:
        """Convert RawNode to Node"""
        assert node[-1] is not None
        return Node(type=node[0], children=node[-1])

    def lam_r(grammar: Grammar, node: RawNode) -> None:
        """Convert RawNode to None"""
        assert node[-1] is not None
        return



# Generated at 2022-06-21 10:14:00.182274
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys

    def lam_sub(grammar: Grammar, node: RawNode) -> NL:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    parser = Parser(Grammar(sys.modules[__name__]))
    parser.setup()
    type = 1
    value = "test"
    context = (1, 1)
    dfa = [[(0, 0)]]
    state = 1
    node = (1, None, (1, 1), [])
    parser.stack = [(dfa, state, node)]
    parser.rootnode = Leaf(type, value, context)
    parser.stack = [(dfa, state, node)]
    parser.pop()


# Generated at 2022-06-21 10:14:04.997153
# Unit test for constructor of class Parser
def test_Parser():
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.pgen as pgen

    g = pgen.pgen(grammar)
    p = Parser(g, lam_sub)

# Generated at 2022-06-21 10:14:14.671466
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest
    from blib2to3.pgen2 import driver

    class TestParser(unittest.TestCase):
        def test_classify_tokens(self):
            expected_labels = {
                "NAME": 1,
                "NUMBER": 2,
                "STRING": 3,
                "INDENT": 4,
                "DEDENT": 5,
                "NEWLINE": 6,
                "ENDMARKER": 7,
            }
            for key, value in expected_labels.items():
                self.assertEqual(
                    Parser.classify(
                        self, getattr(token, key), None, None
                    ),
                    value,
                    "Expected {0} to have label {1}".format(key, value),
                )

    driver.run_unittest

# Generated at 2022-06-21 10:14:25.935742
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar, driver
    from .tokens import *
    from .dfas import *

    class MyGrammar(grammar.Grammar):
        def p_input(self, args: Sequence[Text]) -> Sequence[Text]:
            """input: NEWLINE | input statement"""
            pass

        def p_statement(self, args: Sequence[Text]) -> Sequence[Text]:
            """statement: expr_stmt
                        | compound_stmt
                        | flow_stmt
                        | import_stmt
                        | global_stmt
                        | assert_stmt"""
            pass

        def p_expr_stmt(self, args: Sequence[Text]) -> Sequence[Text]:
            """expr_stmt: testlist augassign testlist
                        | exprlist"
                        | exprlist augassign testlist"""
            pass

# Generated at 2022-06-21 10:14:28.462595
# Unit test for method push of class Parser
def test_Parser_push():
    assert hasattr(Parser, "push")
    assert Parser.push.__code__.co_argcount == 4


# Generated at 2022-06-21 10:14:38.486371
# Unit test for function lam_sub
def test_lam_sub():
    r = lam_sub(None, (1, "a", (2, 3), [None]))
    assert isinstance(r, Node)
    assert r.type == 1
    assert r.children == []
    assert r.context == (2, 3)
    r = lam_sub(None, (1, "a", (2, 3), [None, None, None]))
    assert isinstance(r, Node)
    assert r.type == 1
    assert r.children == []
    assert r.context == (2, 3)
    leaf = Leaf(1, "a", (2, 3))
    r = lam_sub(None, (1, "a", (2, 3), [leaf]))
    assert r is leaf
    assert isinstance(r, Leaf)

# Generated at 2022-06-21 10:14:48.638059
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar, token

    p = Parser(grammar, lam_sub)
    p.setup(grammar.start)
    p.addtoken(token.NUMBER, 23, (1, 0))
    p.addtoken(token.PLUS, None, (1, 2))
    p.addtoken(token.NUMBER, 42, (1, 4))
    assert p.addtoken(token.NEWLINE, None, (1, 6))
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER

# Generated at 2022-06-21 10:15:17.713961
# Unit test for constructor of class Parser
def test_Parser():
    grammar = Grammar(
        name="Parser",
        tokens={"A": 1, "B": 2, "C": 3},
        start=0,
        dfas={0: ([[1, 0], [2, 0]], {1: 0, 2: 0}), 1: ([[3, 0], [0, 0]], {3: 0, 0: 0})},
    )
    p = Parser(grammar)

# Generated at 2022-06-21 10:15:26.096029
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = Grammar()
    grammar.labels = {0: (256, "boolean"), 1: (257, "int")}
    grammar.tokens = {token.FALSE: 0, token.TRUE: 0, token.INTNUM: 1}
    parser = Parser(grammar)
    assert parser.classify(token.FALSE, "false", None) == 0
    assert parser.classify(token.TRUE, "true", None) == 0
    assert parser.classify(token.INTNUM, "0", None) == 1
    try:
        parser.classify(token.FALSE, "0", None)
    except ParseError:
        pass
    else:
        assert False, "Failed to raise ParseError"

# Generated at 2022-06-21 10:15:35.368788
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .driver import Driver
    from . import keywords, tokens

    d = Driver(convert=None, grammar_debug=False)
    p = Parser(d.grammar, convert=None, debug=False)
    p.setup()
    for type in (token.NAME, token.STRING, token.NEWLINE, token.INDENT, token.DEDENT):
        assert not p.addtoken(type, None, Context(1))
    assert p.stack == [(([[(1, 1), (2, 1)], [(0, 1)]], {1: 1, 2: 1}), 0, (1, None, None, []))]
    assert p.rootnode is None
    assert not p.addtoken(tokens.ENDMARKER, None, Context(2))

# Generated at 2022-06-21 10:15:47.635493
# Unit test for method push of class Parser
def test_Parser_push():
    from .pgen2 import driver
    gr: Grammar = driver.load_grammar(
        "grammar/Grammar", "Grammar", "Grammar", debug=0
    )
    pars: Parser = Parser(gr)
    pars.setup()
    pars.push(
        1024, (([(15, 1)], []), {0: 0, 1: 1, 2: 2}), 1, (1, 1, "test_Parser_push")
    )
    pars.push(
        1025, (([(15, 1)], []), {0: 0, 1: 1, 2: 2}), 1, (1, 1, "test_Parser_push")
    )
    assert len(pars.stack) == 3
    assert pars.stack[1][2][0] == 1024
    pars

# Generated at 2022-06-21 10:15:57.753644
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import os
    import sys
    import unittest
    import tempfile
    import types

    fname = "BadGrammar.txt"  # Unloadable
    try:
        Parser(Grammar(fname))
    except ImportError as e:
        pass
    else:
        raise unittest.TestCase.failureException("did not raise")

    fname = "Python27.txt"  # Loadable
    try:
        Parser(Grammar(fname))
    except ImportError:
        raise unittest.TestCase.failureException("unexpected")

    # Generated by Driver.pgen -- (c)2001-2012 Python Software Foundation
    # Edit this with care!

# Generated at 2022-06-21 10:16:05.352345
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar(start='start')
    node = ('start', None, None, [])
    lam_sub(grammar, node)
    node = ('start', None, None, [('A', None, None, None)])
    lam_sub(grammar, node)
    node = ('start', None, None, [('A', None, None, []), ('B', None, None, None)])
    lam_sub(grammar, node)


# Generated at 2022-06-21 10:16:16.948073
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from . import parsetok
    from . import tokenize

    g = grammar.Grammar()
    g.start = "start"
    g.labels = [None, "thing0", "thing1", "thing2"]
    g.keywords = {}
    g.nonterminals = {}
    g.tokens = {tokenize.NAME: 1, tokenize.NUMBER: 2, tokenize.STRING: 3}

# Generated at 2022-06-21 10:16:24.244109
# Unit test for method push of class Parser
def test_Parser_push():
    from .pgen2 import driver

    g = Grammar(driver.parse_grammar(None, "Grammar"))

    p = Parser(g)
    p.setup()
    p.push(1, (None, {}), 0, None)
    assert len(p.stack) == 2
    p.push(2, (None, {}), 0, None)
    assert len(p.stack) == 3
    p.shift(3, '"', 0, None)
    assert len(p.stack) == 3
    p.pop()
    assert len(p.stack) == 2
    p.pop()
    assert len(p.stack) == 1

# Generated at 2022-06-21 10:16:34.082343
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from .pgen2 import token
    from .pytree import Leaf, Node
    from typing import Tuple

    g = grammar.Grammar(grammar.parse_grammar(grammar.grammar_nt_re))
    g.dfas = {}  # Hack: disable DFA cache
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "x", (1, 3))
    p.addtoken(token.PLUS, "+", (1, 4))
    p.addtoken(token.NAME, "y", (1, 5))
    p.addtoken(token.EQUAL, "=", (1, 6))
    p.addtoken(token.NAME, "x", (1, 7))

# Generated at 2022-06-21 10:16:37.230723
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(None)
    p.push(0, 1, 2, 3)
    assert p.stack == [(1, 0, (0, None, 3, []))]



# Generated at 2022-06-21 10:17:32.503129
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Test case for method Parser.addtoken()"""
    from . import tokenize, token

    with open(__file__) as f:
        data = f.read()
    tokens = list(tokenize.generate_tokens(iter(data.splitlines(True)).__next__))

    from blib2to3.pgen2.grammar import Grammar

    mod = Grammar(__file__)

    # Create a parser
    parser = Parser(mod)
    parser.setup()

    # Feed the tokens
    for type, token, start, end, line in tokens:
        parser.addtoken(type, token, ((start[0], start[1]), (end[0], end[1])))
        if type == token.ENDMARKER:
            break

        # Check that the last token was shifted
       

# Generated at 2022-06-21 10:17:44.127487
# Unit test for method pop of class Parser
def test_Parser_pop():
    class MockNode(object):
        def __init__(self, type, value, context, children=None) -> None:
            self.children = None
            self.type = type
            self.value = value
            self.context = context
            if children:
                self.children = children

    class MockGrammar(object):
        dfa = None
        labels = {
            0: ("class-name", None),
            1: ("token", "test"),
            2: (None, None),
        }
        tokens = {"class-name": 0, "token": 1}

# Generated at 2022-06-21 10:17:46.980868
# Unit test for function lam_sub
def test_lam_sub():
    r = lam_sub(None, (5, None, None, [(-2, None, None, None)]))
    assert r == Node(5, children=[Leaf(-2, context=None)])

# Generated at 2022-06-21 10:17:53.229491
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver
    from . import grammars

    p = Parser(grammars.Grammar())
    p.setup()
    p.addtoken(token.NAME, "name", Context(1, 0))
    p.addtoken(token.NUMBER, "1", Context(1, 0))
    p.addtoken(token.RPAR, ")", Context(1, 0))

# Generated at 2022-06-21 10:18:00.241326
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver

    class MyParser(Parser):
        def __init__(self, grammar, convert=None):
            Parser.__init__(self, grammar, convert=convert)
            self.items: List[int] = []

        def shift(self, type: int, value: Optional[Text], newstate: int, context: Context) -> None:
            Parser.shift(self, type, value, newstate, context)
            self.items.append(type)

        def push(self, type: int, newdfa: DFAS, newstate: int, context: Context) -> None:
            Parser.push(self, type, newdfa, newstate, context)
            self.items.append(type)

    parser = MyParser(driver.grammar, convert=None)
    parser.setup()
   

# Generated at 2022-06-21 10:18:08.776610
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Test for issue #4440
    class DummyParser(Parser):
        def classify(self, type, value, context):
            return super().classify(type, value, context)

    d = DummyParser(Grammar(None))

    class DummyToken:
        def __init__(self, type: int = 54, value: Optional[Text] = None, context: Context = None) -> None:
            self.type = type
            self.value = value
            self.context = context

    assert d.classify(DummyToken().type, DummyToken().value, DummyToken().context) == 54


if __name__ == "__main__":
    test_Parser_classify()

# Generated at 2022-06-21 10:18:13.838339
# Unit test for method shift of class Parser
def test_Parser_shift():
    from parser import Parser
    from grammar import Grammar
    parser = Parser(Grammar())
    parser.stack = [(([[0,0]], None), 0, None)]
    parser.shift(None, None, 1, None)
    assert parser.stack[0][0] == (([[0,0]], None), 1, None)




# Generated at 2022-06-21 10:18:19.244080
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.grammar
    assert g.start == g.symbol2number["file_input"]
    p = Parser(g)
    assert p.grammar is g
    assert p.convert is lam_sub
    assert not p.stack
    assert p.rootnode is None
    assert p.used_names == set()

# Generated at 2022-06-21 10:18:29.138548
# Unit test for function lam_sub
def test_lam_sub():
    class MockGrammar:
        dfas = {
            "foo": ("dfa", {"first": "set"},),
            "bar": ("dfa", {"first": "set"}),
            "baz": ("dfa", {"first": "set"}),
        }

    tree = [
        ("foo", None, None, [("bar", None, None, [("baz", None, None, [])])]),
        (token.NUMBER, "1", None, None),
    ]
    grammar = MockGrammar()
    assert (tree == lam_sub(grammar, tree))
    tree = [(token.NUMBER, "1", None, None)]
    assert (tree == lam_sub(grammar, tree))

# Generated at 2022-06-21 10:18:36.818356
# Unit test for function lam_sub
def test_lam_sub():
    class FakeGrammar(object):
        def __init__(self) -> None:
            self.syms = {1: "F", 2: "X", 3: "Y"}
        def tok_name(self, type: int) -> Text:
            return "foo"
        def num2symbol(self, type: int) -> Text:
            return self.syms.get(type, "False")
    foo = FakeGrammar()
    assert lam_sub(foo, (1, None, None, [(2, None, None, [(3, None, None, None)]), (3, None, None, None)])) == ('F', ('X', ('Y',), ('Y',)), None)