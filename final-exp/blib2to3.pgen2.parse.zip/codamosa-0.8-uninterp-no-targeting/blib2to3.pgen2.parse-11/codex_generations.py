

# Generated at 2022-06-21 10:10:13.486915
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(None)
    assert p.grammar is None
    assert p.convert is None

    def f(grammar: Grammar, node: RawNode) -> NL:
        return Node(type=node[0], children=node[3], context=node[2])

    p = Parser(None, f)
    assert p.grammar is None
    assert p.convert == f
    assert p.convert(None, (1, 2, 3, 4)) == Node(type=1, children=4, context=3)



# Generated at 2022-06-21 10:10:25.341140
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Set up the parser
    from . import grammars

    g = grammars.Grammar()
    p = Parser(g)
    p.setup()
    # Make a simple sentence
    for i, (type, value, context) in enumerate((
        (1, None, None),
        (4, 'a', None),
        (4, 'b', None),
    )):
        # Call the parser method to add this token
        r = p.addtoken(type, value, context)
        if i == 2:
            assert r
            assert p.rootnode is not None
            assert p.rootnode.type == 256
            assert p.rootnode.children[0].value == "a"
            assert p.rootnode.children[2].value == "b"
        else:
            assert not r

# Generated at 2022-06-21 10:10:36.031073
# Unit test for method push of class Parser
def test_Parser_push():
    from .tokenize import generate_tokens

    from . import grammar
    from . import token
    from .parse import Parser

    def tok_gen():
        num = 0
        while 1:
            yield (token.NUMBER, str(num), (1, num), (1, num + 1))
            num += 1

    g = grammar.Grammar(generate_tokens(test_Parser_push.__doc__))
    p = Parser(g)
    p.setup(g.start)
    for num, tok, _, _ in tok_gen():
        if p.addtoken(token.NAME, tok, (1, num)):
            break
    assert p.rootnode == "NUMBER 0"


# Generated at 2022-06-21 10:10:43.136381
# Unit test for method push of class Parser
def test_Parser_push():
    class TestGrammar(Grammar):
        tokens = {
            1: 100,
            2: 200,
            3: 300,
            4: 400,
            5: 500,
        }
        keywords = {}
        start = 1
        dfas = {
            1: ([
                [1],
                [2],
            ], [1]),
            2: ([
                [3],
                [4],
            ], [4]),
            3: ([
                [5],
            ], [5]),
        }
        labels = {
            1: (1, 1),
            2: (2, 2),
            3: (3, 3),
            4: (4, 4),
            5: (5, 5),
        }


# Generated at 2022-06-21 10:10:55.537310
# Unit test for method pop of class Parser
def test_Parser_pop():
    import unittest.mock
    g = unittest.mock.Mock()
    g.labels = {
        0: (1, None),
        1: (2, None),
        2: (3, None),
        3: (4, None),
        4: (5, None),
        5: (6, None),
        6: (7, None),
    }
    dfa_states = {
        0: [(0, 0), (0, 1), (0, 2)],
        1: [(0, 3)],
        2: [(0, 4)],
        3: [(0, 5)],
        4: [(0, 4)],
        5: [(0, 5)],
        6: [(0, 6)],
    }

# Generated at 2022-06-21 10:11:04.046933
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import os
    from . import grammar, token, tokenize
    from .driver import Driver

    assert token.ENCODING is not None

    script_dir = os.path.dirname(os.path.realpath(__file__))
    g = grammar.Grammar(script_dir + "/Grammar", convert=grammar.convert)
    tree = Driver(g, convert=grammar.convert).parse_tokens(tokenize.generate_tokens(open('ex.py')))
    print(tree)

# Generated at 2022-06-21 10:11:07.841860
# Unit test for function lam_sub
def test_lam_sub():
    gram = Grammar()
    assert lam_sub(gram, (1, None, None, [(1, None, None, [(2, "Foo", None, None)])])) \
        == Leaf(1, "Foo", context=None)

# Generated at 2022-06-21 10:11:11.955985
# Unit test for constructor of class ParseError
def test_ParseError():
    ex = ParseError("msg", token.NAME, "value", None)
    assert (ex.msg, ex.type, ex.value, ex.context) == ("msg", token.NAME, "value", None)

# Generated at 2022-06-21 10:11:20.620062
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest2 as unittest
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.pgen as pgen
    import blib2to3.pgen2.parse as parse

    class TestParser(unittest.TestCase):

        def test_shift_string(self):
            p = parse.Parser(grammar.Grammar(pgen.grammar), lam_sub)
            p.setup()
            self.assertEqual(p.addtoken(1, "x", "c"), False)
            node = p.stack[0]
            self.assertEqual(node, (([([(1, 1)], set([1]))], {1: 1}), 1, (256, 'x', 'c', [])))
            self.assertE

# Generated at 2022-06-21 10:11:30.942608
# Unit test for method pop of class Parser
def test_Parser_pop():
    def convert(grammar, node):
        # type: (Grammar, RawNode) -> Node
        return Node(type=node[0], children=node[3], context=node[2])

    g = Grammar("start: foo bar baz\nfoo: 'foo'\nbar: 'bar'")
    p = Parser(g, convert)
    p.setup("start")
    for i, t in enumerate("foobarbaz"):
        p.addtoken(getattr(token, t.upper()), t, Context(i))

# Generated at 2022-06-21 10:11:46.848088
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar, tokenize

    tokens: Sequence[Tuple[int, Text, Context]] = [];
    text = "def f(): pass"
    tokens.extend(tokenize.generate_tokens(iter([text]).__next__))
    tokens.append((token.ENDMARKER, "", (1, 0)))
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for type, value, context in tokens:
        p.addtoken(type, value, context)

# Generated at 2022-06-21 10:11:48.615500
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(Grammar(start=17, dfas={17: ([], {17: 17})}))

# Generated at 2022-06-21 10:12:00.734463
# Unit test for method push of class Parser
def test_Parser_push():
    from .grammar import Grammar
    from . import driver

    grammar = Grammar(
        [
            "S : 'x'",
            "S : S S",
            "S : '(' S",
            "S : S ')'",
            "S : S '*'",
            "S : '-' S",
            "S : S '+'",
            "S : S '^'",
            "S : S '|'",
        ]
    )

    parsr = Parser(grammar)
    parsr.setup()

    tokens = [
        (token.NAME, "x", (1, 0)),
        (token.NAME, "x", (1, 1)),
        (token.OP, "+", (1, 2)),
        (token.NAME, "x", (1, 3)),
    ]

# Generated at 2022-06-21 10:12:05.823397
# Unit test for constructor of class Parser
def test_Parser():
    """Test the Parser constructor."""
    from . import grammar

    gr = grammar.Grammar()
    pa = Parser(gr)
    assert pa.grammar is gr
    assert pa.convert is lam_sub
    def convert2(grammar, node):
        return node
    pa = Parser(gr, convert2)
    assert pa.grammar is gr
    assert pa.convert is convert2


# Generated at 2022-06-21 10:12:11.563004
# Unit test for method shift of class Parser
def test_Parser_shift():
    class MockParser(object):
        def __init__(self, grammar: Grammar, convert: Optional[Convert] = None) -> None:
            self.grammar = grammar
            self.convert = convert or lam_sub
            self.stack: List[Tuple[DFAS, int, RawNode]] = []

    p = MockParser(Grammar(None))
    node = (1, "foo", (1, 1), [])
    p.stack.append((None, 0, node))
    p.shift(2, "bar", 1, (2, 2))
    assert p.stack == [(None, 1, node)]
    assert node[3] == [Node(type=2, value="bar", context=(2, 2))]


# Generated at 2022-06-21 10:12:17.139005
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, token

    g = grammar.grammar
    p = Parser(g)

    p.classify(token.NAME, "if", Context(line="if", column=0))
    assert p.used_names == {"if"}
    assert p.classify(token.NAME, "else", Context(line="else", column=0)) == 1

# Generated at 2022-06-21 10:12:28.356920
# Unit test for method pop of class Parser
def test_Parser_pop():
    import cStringIO
    import unittest

    from . import grammar
    from . import driver

    class ParserTest(unittest.TestCase):

        def test_Parser(self):
            data = cStringIO.StringIO("import sys\n")
            g = grammar.grammar
            p = Parser(g)
            p.setup()
            d = driver.Driver(g, data)
            while 1:
                t = d.get_token()
                if p.addtoken(t.type, t.value, t.context):
                    break
            self.assertEqual(p.rootnode.type, "file_input")

    unittest.main()

# Generated at 2022-06-21 10:12:35.532003
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser = Parser(Grammar())
    root = parser.convert(parser.grammar, [1])
    node1 = parser.convert(parser.grammar, [2])
    node2 = parser.convert(parser.grammar, [3])
    parser.stack.append(([], 0, [1, [2, None, None, 3]]))
    parser.stack.append(([], 0, [2, None, None, 3]))
    parser.pop()
    assert parser.stack == [([], 0, [1, [2, None, None, 3]])]
    assert parser.rootnode == None
    parser.pop()
    assert parser.stack == []
    assert parser.rootnode == root
    assert root != None
    assert root.children == [node1, node2]



# Generated at 2022-06-21 10:12:37.731279
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import parsetok, tokenize
    from .grammar import Grammar
    import io


# Generated at 2022-06-21 10:12:42.478749
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    assert p
    assert p.grammar is g
    assert p.stack == []
    p.setup()
    assert p.stack
    assert len(p.stack) == 1
    assert p.stack[0][0] is g.dfas[g.start]


# Generated at 2022-06-21 10:12:57.878015
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar(grammar.parse_grammar(grammar.start_symbol, grammar.literals))
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[grammar.start_symbol], 0, (grammar.start_symbol, None, None, []))]


# Generated at 2022-06-21 10:13:09.362260
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, token
    from .driver import Driver
    import io
    import sys

    # Get the Python grammar
    # Driver: grammar.Grammar -> Gather
    # Gather: driver.Grammar -> set(driver.Driver)
    g = grammar.grammar
    pg = g.pgen()

    # Synthesize a parser
    # Parser: grammar.Grammar -> parser.Parser
    parser = Parser(pg)
    parser.setup()

    # Load source code
    source = b"for a in b:\n    pass"
    stream = io.StringIO(source)
    tokengen = Driver(pg, stream, b"<test>").tokengen


# Generated at 2022-06-21 10:13:16.655368
# Unit test for method setup of class Parser
def test_Parser_setup():
    import lib2to3.pgen2.pgen

    class Dummy:
        pass

    dummydata = Dummy()
    dummydata.dfas = [([[(1, 0)], [(2, 0)], [(0, 1)]], {0: 0, 1: 1, 2: 2})]
    dummydata.labels = [(1, None), (2, None), (3, None)]
    dummydata.keywords = {}
    dummydata.start = 0
    dummygc = Dummy()
    dummygc.value = dummydata
    # Generate a parser object.
    parser = lib2to3.pgen2.pgen.Parser(dummygc)
    parser.setup()
    # Check if stack is initialized correctly.

# Generated at 2022-06-21 10:13:28.116989
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """
    Tests the method blib2to3.pgen2.parser.Parser.addtoken(). As the method
    is private, the test is run indirectly.

    """
    # Necessary imports
    from . import driver
    from . import tokenize
    from .tokenize import (
        NAME, NUMBER, STRING, INDENT, DEDENT, NEWLINE, COMMENT,
    )
    from blib2to3.pgen2.driver import load_grammar

    # Input string
    s = "foo 1 # Comment\n"
    # Grammar to use
    grammar = load_grammar('Grammar/Grammar')

    # Classify tokens

# Generated at 2022-06-21 10:13:36.789268
# Unit test for method push of class Parser
def test_Parser_push():
    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.start = 1
            self.labels = [None] * 4
            self.labels[1] = (1, None)
            self.labels[2] = (2, None)
            self.labels[3] = (3, None)
            self.keywords = {}
            self.tokens = {2: 3}

# Generated at 2022-06-21 10:13:49.479001
# Unit test for function lam_sub
def test_lam_sub():
    # type: () -> None
    from . import grammar
    from . import driver

    grammar_input = """
    lam_sub
        | {lam_sub}
        | lam_sub token
        | token lam_sub
    ;
    """
    pgen = driver.Driver(grammar_input, "lam_sub", "grammar.py")
    gr = pgen.grammar
    p = Parser(gr)

    def check(input_: Sequence[Sequence[Union[int, Text]]], expected: RawNode) -> None:
        # type: (Sequence[Sequence[Union[int, Text]]], RawNode) -> None
        p.setup(start=gr.symbol2number["lam_sub"])
        for type, value in input_:
            assert p.addtoken(type, value, None)


# Generated at 2022-06-21 10:13:53.820416
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("spam", 1, "bob", Context(2, 3))
    assert exc.msg == "spam"
    assert exc.type == 1
    assert exc.value == "bob"
    assert exc.context == Context(2, 3)

# Generated at 2022-06-21 10:14:05.156827
# Unit test for method classify of class Parser
def test_Parser_classify():
    class MockGrammar:
        labels = {0: (token.NAME, "foo"), 1: (token.STRING, ""), 3: (token.DEDENT, "")}
        tokens = {token.NAME: 0, token.STRING: 1, token.DEDENT: 3}
        keywords = {'foo': 0, 'bar': 2}

    p = Parser(MockGrammar())
    class MockContext:
        pass
    context = MockContext()

    assert p.classify(token.NAME, "foo", context) == 0
    assert p.classify(token.NAME, "bar", context) == 2
    try:
        p.classify(token.STRING, "foo", context)
    except ParseError:
        pass
    else:
        raise Exception("expected ParseError")

# Generated at 2022-06-21 10:14:14.775188
# Unit test for constructor of class Parser
def test_Parser():
    import pgen2.tokenize


# Generated at 2022-06-21 10:14:19.909122
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test", token.PLUS, "+", (2, 3))
    except ParseError as exc:
        assert exc.msg == "test"
        assert exc.type == token.PLUS
        assert exc.value == "+"
        assert exc.context == (2, 3)
    else:
        assert 0, "cannot raise and catch ParseError"

# Generated at 2022-06-21 10:14:49.321734
# Unit test for constructor of class Parser
def test_Parser():
    # Create a grammar from a list of productions
    from . import grammar

    g = grammar.Grammar()

    def prods(l):
        return [g.add_production(x, "") for x in l]

    # Start symbol
    g.start = "S"

    # Nonterminals and terminals
    OP, LP, RP, NAME, NUMBER, EOF = prods(
        ["S", "OP", "LP", "RP", "NAME", "NUMBER", "EOF"]
    )

    # Productions
    g.add_prod(OP, ["NAME", "NAME", "NAME"], num="p1")
    g.add_prod(OP, ["NAME", "NAME", "NUMBER"], num="p2")

# Generated at 2022-06-21 10:14:56.218173
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar()
    t = Parser(grammar)
    t.setup()
    dfa1 = grammer.dfas[1]
    t.stack = [(('a', 'b'), 0, (1, None, None, [])),
               (dfa1, 0, (2, None, None, []))]
    t.pop()
    assert t.stack == [(('a', 'b'), 0, (1, None, None, [2]))]

# Generated at 2022-06-21 10:15:03.989799
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = Grammar(open("python.gram"))
    p = Parser(grammar)
    p.setup()

    # Create a dummy token type
    token.tok_foo = token.NT_OFFSET
    # Create a dummy context
    ctx = ((1, 1), (1, 2))

    # Test case 1 - accept
    assert p.addtoken(token.IF, "if", ctx) is True
    assert p.addtoken(token.COLON, ":", ctx) is True

    # Test case 2 - shift
    p.setup()
    assert p.addtoken(token.IF, "if", ctx) is False

    # Test case 3 - shift/reduce
    p.setup()
    assert p.addtoken(token.IF, "if", ctx) is False
    assert p.add

# Generated at 2022-06-21 10:15:16.329263
# Unit test for function lam_sub
def test_lam_sub():
    # Test converter that is identical to lam_sub

    from blib2to3.pgen2.tokenize import parser
    from blib2to3.pytree import Leaf

    def convert_test(grammar, node):
        assert node[3] is not None
        return Node(type=node[0], children=node[3])

    p = Parser(parser.dfa, convert_test)
    p.setup()
    for t in parser.tokens:
        p.addtoken(t, "", "")
    parser_raw_tree = p.rootnode

    p = Parser(parser.dfa, lam_sub)
    p.setup()
    for t in parser.tokens:
        p.addtoken(t, "", "")
    parser_lam_tree = p.roottoken

    #

# Generated at 2022-06-21 10:15:25.510303
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, symbols
    p = Parser(grammar)
    p.setup()
    p.addtoken(symbols.funcdef, None, None)
    p.addtoken(token.NAME, "foo", None)

# Generated at 2022-06-21 10:15:34.537559
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # This tests only that addtoken() runs without error, not that it
    # successfully parses anything.  See pgen2 for a real parser.
    import sys
    from . import grammar
    from . import tokenize
    g = grammar.Grammar()
    g.parse(open(sys.argv[1], "rb"))
    p = Parser(g)
    p.setup()
    gen = tokenize.generate_tokens(sys.stdin.readline)
    while True:
        t = next(gen)
        if t[0] is token.NEWLINE:
            continue
        if p.addtoken(t[0], t[1], t[2]):
            break
    print(p.rootnode)

# Generated at 2022-06-21 10:15:46.539008
# Unit test for function lam_sub
def test_lam_sub():
    import lib2to3.pgen2.grammar as g

    # Load the Python grammar
    g = g.grammar('Grammar.by')

    # Test the lam_sub function

# Generated at 2022-06-21 10:15:54.943355
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.grammar
    import blib2to3.pygram

    grammar = blib2to3.pgen2.grammar.Grammar(blib2to3.pygram.python_grammar_no_print_statement)

    parser = Parser(grammar)
    parser.setup()

    parser.shift(1, "def", 2, (3,4))
    assert parser.stack == [(grammar.dfas[grammar.start], 2, (grammar.start, None, None, [[1, 'def', (3, 4), None]]))]

# Generated at 2022-06-21 10:16:05.201597
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import enum
    import unittest

    class TestGrammar(enum.Enum):
        START = 258
        X = 259
        NAME = 260

    class TestParser(Parser):
        def __init__(self) -> None:
            keywords = {
                'def': TestGrammar.X.value,
                'class': TestGrammar.X.value,
            }
            tokens = {
                TestGrammar.START.value: TestGrammar.START.value,
                TestGrammar.X.value: TestGrammar.X.value,
                TestGrammar.NAME.value: TestGrammar.NAME.value,
                token.NEWLINE.value: token.NEWLINE.value,
            }

# Generated at 2022-06-21 10:16:08.547987
# Unit test for method setup of class Parser
def test_Parser_setup():
    """Unit test for method setup of class Parser."""
    # FIXME: It seems we don't have a unit test for this class.  We
    # need to create one, and add it to the unit testsuite.

# Generated at 2022-06-21 10:16:35.270533
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    dfa = [
        [(0, 1), (1, 2)],
        [(0, 1), (2, 2)],
        [(0, 1), (3, 2)],
        [(0, 1), (4, 2)],
        [(0, 1), (5, 2)],
    ]
    states = {"A": 0, "B": 1, "C": 2, "D": 3, "E": 4, "F": 5}
    labels = [("A", None), ("B", None), ("C", None), ("D", None), ("E", None), ("F", None)]
    first = [[0]] * 6
    dfas = (dfa, states)
    grammar = Grammar(first, dfas, labels)
    parser = Parser(grammar)
    parser.setup()
    assert parser.addtoken

# Generated at 2022-06-21 10:16:47.952530
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    dfa = [[(1, 0), (2, 0)], [(0, 1)], [(0, 2)]]
    newdfa = (dfa, {0: 3, 1: 3, 2: 3})
    p.stack = [(newdfa, 1, (1, 1, 1, None)), (newdfa, 2, (1, 1, 1, None))]
    p.push(2, newdfa, 0, 1)

# Generated at 2022-06-21 10:16:53.789791
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar.from_string("""
    single: '#' NAME
    """, start="single")
    parser = Parser(grammar)
    parser.setup()
    assert parser.stack == [(grammar.dfas["single"], 0, (0, None, None, []))]
    assert parser.rootnode is None
    assert parser.used_names == set()


# Generated at 2022-06-21 10:17:04.056968
# Unit test for method pop of class Parser
def test_Parser_pop():
    from sys import stderr
    from blib2to3.pgen2.pgen import (
        generate_grammar,
        load_grammar,
        tokenize_lines,
        parse,
    )
    g = generate_grammar()
    g.start()
    load_grammar(g)
    # pylint: disable=too-many-branches,too-many-statements
    p = Parser(g)
    p.setup()

# Generated at 2022-06-21 10:17:05.836885
# Unit test for method setup of class Parser
def test_Parser_setup():
    assert Parser(Grammar(token=token, start='file_input')).setup()

# Generated at 2022-06-21 10:17:07.826918
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()



# Generated at 2022-06-21 10:17:17.525974
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    "Unit test for method addtoken of class Parser."
    # Mock an import of grammar file
    grammar = Grammar()
    grammar.start = 255
    grammar.dfas = {
        255: (
            [
                [(1, 2)],
                [(0, 2)],
                [(2, 2)],
            ],
            {1: 0, 2: 1},
        )
    }
    grammar.labels = {0: (token.COMMENT, None), 1: (token.NAME, "bar"), 2: (token.NAME, "foo")}
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NAME, "foo", None)
    parser.addtoken(token.NAME, "bar", None)
    parser.addtoken(token.NAME, "foo", None)

# Generated at 2022-06-21 10:17:21.263011
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("value1", "type1", "context1")
    assert pe.msg == "value1"
    assert pe.type == "type1"
    assert pe.value == "context1"

# Generated at 2022-06-21 10:17:30.370792
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import _pgen_parse as pparse
    from .tokenize import generate_tokens
    from io import StringIO

    def _classify(text: Text) -> Sequence[int]:
        """Invoke classify() in a way similar to main program of pgen.

        The classify() method is invoked from the main program of pgen
        on each token fed to the parser. The lexer of the pgen module
        generates these tokens. This function duplicates the setup of
        the main program of pgen, but only invokes classify().

        """
        grammar = pparse.pgen(StringIO(text))
        parser = Parser(grammar)
        parser.setup()
        result = []

# Generated at 2022-06-21 10:17:38.194365
# Unit test for method setup of class Parser
def test_Parser_setup():
    from .token import TokenInfo
    from .grammar import Grammar
    p = Parser(Grammar())
    p.setup()
    p.addtoken(TokenInfo(1, '+', (1, 0), (1, 0)))
    p.addtoken(TokenInfo(1, '+', (1, 0), (1, 0)))
    p.addtoken(TokenInfo(1, '+', (1, 0), (1, 0)))


# Generated at 2022-06-21 10:18:34.452974
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, symbol
    from .pgen import driver

    g = driver.load_grammar(grammar)
    p = Parser(g)
    dfa, first = g.dfas[symbol.stmt]
    # List of labels used in the stmt nonterminal
    expected = set(x[0] for x in dfa[0])
    # List of tokens used in the stmt nonterminal
    actual = set(g.labels[x][0] for x in expected)
    p.setup(symbol.stmt)
    for type in actual:
        ilabel = p.classify(type, "dummy", None)
        assert ilabel in expected

# Generated at 2022-06-21 10:18:38.506815
# Unit test for constructor of class ParseError
def test_ParseError():
    context = (1, 2)
    try:
        raise ParseError("message", token.IF, "if", context)
    except ParseError as e:
        assert e.msg == "message"
        assert e.type == token.IF
        assert e.value == "if"
        assert e.context == context

# Generated at 2022-06-21 10:18:46.505530
# Unit test for method shift of class Parser
def test_Parser_shift():
    print("test_Parser_shift")
    from . import driver
    from . import grammar
    from . import pytree
    from .tokenize import generate_tokens

    p = Parser(grammar)
    p.setup()
    for i, t in enumerate(
        generate_tokens(lambda x: "hi".__next__(), "<test>", None)
    ):
        if p.addtoken(t.type, t.string, pytree.Context(i, 0, 0, 0)):
            print()
            print("Nodes:")
            print(p.rootnode.pretty())
            break



# Generated at 2022-06-21 10:18:53.067058
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver

    p = Parser(driver.Grammar(convert=None), None)
    assert p.classify(token.NAME, "if", Context(None, 0)) == driver.syms.if_stmt
    assert p.classify(token.NAME, "foo", Context(None, 0)) == driver.syms.NAME
    assert p.classify(token.IF, None, Context(None, 0)) == driver.syms.IF

# Generated at 2022-06-21 10:18:57.361882
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    assert isinstance(p, Parser)
    assert p.grammar == g
    assert p.convert == lam_sub
    assert p.stack == []
    assert p.rootnode == None

# Generated at 2022-06-21 10:19:06.220456
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    # Load a grammar
    g = grammar.grammar("Python.g")
    pg = g.pgen()
    pg.generate_grammar("Python.tbl")

    gr = grammar.grammar("Python.tbl")

    # Exercise the classify method of the parser
    p = Parser(gr)

    # Test with a NAME token
    assert p.classify(token.NAME, "if", (1, 2)) == p.grammar.keywords["if"]
    assert p.classify(token.NAME, "blah", (1, 2)) == p.grammar.tokens[token.NAME]

    # Test with a NUMBER token

# Generated at 2022-06-21 10:19:12.608434
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    grammar = grammar.grammar
    p = Parser(grammar)
    p.setup()
    for t in tokenize.generate_tokens(open("test/testgrammar.txt")):
        if p.addtoken(t.type, t.string, t.start):
            break
    #print(p.rootnode)
    #print(p.rootnode)
    import pprint

    pprint.pprint(p.rootnode)

# Generated at 2022-06-21 10:19:17.984007
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    # Create a parser instance
    p = Parser(g)
    # Check for reserved words
    p.classify(token.NAME, "if", (1, 0))
    p.classify(token.NAME, "yield", (1, 0))
    p.classify(token.NAME, "foobar", (1, 0))
    p.classify(token.NAME, "nonlocal", (1, 0))



# Generated at 2022-06-21 10:19:23.514545
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar([("A", (("A", "B"),))])
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "A", (None, 0))
    p.addtoken(token.NAME, "B", (None, 0))
    assert p.rootnode == [None, [None, None], None]

# Generated at 2022-06-21 10:19:33.650549
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    import pprint
    import sys
    g = grammar.Grammar()
    sys.stdout.write(
        "ParseError = {0.__module__}.{0.__qualname__}".format(ParseError)
    )
    # Set up grammar
    g.produce('start = "a"')
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 0, ("test_file", 0, 2))
    p.addtoken(1, "a", ("test_file", 0, 2))
    pprint.pprint(p.rootnode)
    # Set up parsing context
    p.setup()
    p.addtoken(1, "a", ("test_file", 0, 2))