

# Generated at 2022-06-21 10:10:21.672437
# Unit test for method setup of class Parser
def test_Parser_setup():
    my_grammar = Grammar()
    my_convert = lam_sub
    my_parser = Parser(grammar=my_grammar, convert=my_convert)
    my_parser.setup()
    assert my_parser.convert == lam_sub
    assert my_parser.grammar == my_grammar
    assert my_parser.rootnode == None
    assert my_parser.stack == []
    assert my_parser.used_names == set()


# Generated at 2022-06-21 10:10:24.768854
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar())
    p.shift(1, 2, 3, 4)
    assert p.stack == [(Grammar().dfas["file_input"], 3, (None, None, None, [2]))]


# Generated at 2022-06-21 10:10:35.986461
# Unit test for method classify of class Parser
def test_Parser_classify():
    # bpo-35264: The Parser class is used only by the _ast.py module,
    # but is also unit tested.
    from . import grammar

    g = grammar.Grammar(open(grammar.grammar_file).read())
    p = Parser(g)
    p.setup()

    # Test keywords
    for keyword in g.keywords.keys():
        # Test that all keywords are accepted by the Parser
        p.addtoken(token.NAME, keyword, Context(1, 0))

        # Test that the Parser has accepted the keyword
        assert p.rootnode is not None
        assert len(p.stack) == 0
        assert p.rootnode.type == g.keywords[keyword]

        # Test that the Parser still accepts the keyword if the keyword
        # is used as a name


# Generated at 2022-06-21 10:10:42.905586
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2 import token
    grammar = Grammar(token)
    node = (token.PLUS, None, (1, 0), [("k", "v", (2, 3), None), "o", None])
    node = lam_sub(grammar, node)
    assert node[0] == token.PLUS
    assert node[1] is None
    assert node[2] == (1, 0)
    assert node[3][0][0] == "k"
    assert node[3][0][1] == "v"
    assert node[3][0][2] == (2, 3)
    assert node[3][0][3] is None
    assert node[3][1] == "o"
    assert node[3][2] is None

# Generated at 2022-06-21 10:10:49.900594
# Unit test for method shift of class Parser
def test_Parser_shift():
    class MockGrammar:
        def __init__(self):
            self.labels = [(0, 0)]

    grammar = MockGrammar()
    parser = Parser(grammar)
    parser.stack = [(None, 0, (0, None, None, []))]
    parser.shift(0, 0, 1, None)
    assert parser.stack == [(None, 1, (0, None, None, []))]

# Generated at 2022-06-21 10:10:59.834922
# Unit test for method pop of class Parser
def test_Parser_pop():
    def pop(
        grammar: Grammar, convert: Callable[[Grammar, RawNode], Optional[Node]], p: Parser
    ) -> None:
        p.setup()
        dfa, state, node = p.stack[-1]
        newnode: RawNode = (dfa[1], None, None, None)
        p.stack[-1] = (dfa, state, node)
        p.stack.append((newdfa, 0, newnode))
        rawnode: RawNode = (newdfa[1], None, None, None)
        newnode = convert(grammar, rawnode)
        if newnode is not None:
            if p.stack:
                dfa, state, node = p.stack[-1]
                assert node[-1] is not None

# Generated at 2022-06-21 10:11:08.630379
# Unit test for method classify of class Parser
def test_Parser_classify():
    import copy
    import sys
    from contextlib import contextmanager

    # Mock _token as done in tokenize.py
    class _token:
        ENDMARKER = 0
        NAME = 1
        NUMBER = 2

    # Mock TokenInfo as done in tokenize.py
    class TokenInfo:
        def __init__(self, type, string, start, end, line):
            self.type, self.string, self.start, self.end, self.line = (
                type,
                string,
                start,
                end,
                line,
            )

    # Mock tokenize, token as done in tokenize.py
    @contextmanager
    def tokenize(readline):
        yield _token, TokenInfo

    class MockTokenError(BaseException):
        pass


# Generated at 2022-06-21 10:11:18.926270
# Unit test for function lam_sub
def test_lam_sub():
    top_node = RawNode(0, None, None, [])
    c1 = RawNode(1, "a", None, None)
    c2 = RawNode(2, "b", None, None)
    l1 = Leaf(1, "a", None)
    l2 = Leaf(2, "b", None)
    # Test one
    top_node[-1].extend([c1, c2])
    result = lam_sub(Grammar(), top_node)
    assert result == Node(0, [l1, l2], None)
    # Test two
    top_node[-1].append(None)
    assert top_node[-1] == [c1, c2, None]
    result = lam_sub(Grammar(), top_node)

# Generated at 2022-06-21 10:11:24.562045
# Unit test for function lam_sub
def test_lam_sub():
    t = token
    g = Grammar(start=2)
    g.dfas[1] = ([[(0, 2)], [(0, 1)]], {0: 1, 1: 2})
    g.dfas[2] = ([[(1, 0), (0, 1)], []], {0: 1, 1: 2})
    g.labels = [t.NAME, t.NAME]
    n = lam_sub(g, (1, None, None, [('a', 'a', None, None)]))
    assert n == Node(1, [Leaf(token.NAME, 'a')])
    n = lam_sub(g, (2, None, None, [('a', 'a', None, None), ('b', 'b', None, None)]))

# Generated at 2022-06-21 10:11:31.879931
# Unit test for method push of class Parser
def test_Parser_push():
    import warnings
    import sys

    # Test code starts here
    grammar: Grammar = Grammar([], [], start=0)
    parser: Parser = Parser(grammar)
    parser.setup()
    assert parser.stack == [([[(0, 0)], {}], 0, None)]
    parser.push(0, ([[(0, 0)], {}], 0, None), 0, None)
    assert parser.stack == [([[(0, 0)], {}], 0, None), ([[(0, 0)], {}], 0, None)]
    raise NotImplemented
    # Test code ends here


# Generated at 2022-06-21 10:11:42.810293
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2.grammar import token2symbol, symbol2label
    import pickle
    from . import token

    # Initialize a parser with a pre-baked grammar
    grammar = pickle.load(open("Python.gram"))
    parser = Parser(grammar)

    # Prepare for parsing
    parser.setup()

    # Fake a NAME token
    faketoken = ("NAME", "fakename", (1, 1), (1, 9))

    # Construct a new node as produced by the lexer
    fakenode = (token2symbol["NAME"],) + faketoken[1:]

    # Label the token
    ilabel = symbol2label[fakenode[0]]

    # Push the NAME token on the stack

# Generated at 2022-06-21 10:11:52.893396
# Unit test for method setup of class Parser
def test_Parser_setup():
    # For now, all the unit tests are in a single function, if the
    # number of tests grow, I will split them out.

    from .pgen2 import driver

    grammar = driver.load_grammar("Grammar.txt")
    parser = Parser(grammar)

    assert parser.grammar is grammar
    assert parser.convert is lam_sub
    assert parser.stack == [(([[], set()], 0), 0, (1, None, None, []))]

    parser.setup(start=2)
    assert parser.stack == [(([[], set()], 0), 0, (2, None, None, []))]

    parser.setup(start=3)
    assert parser.stack == [(([[], {256}], 0), 0, (3, None, None, []))]


# Generated at 2022-06-21 10:12:04.332033
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver

    p = Parser(driver.grammar)
    p.setup()
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.PLUS, "+", None)
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.ENDMARKER, "", None)
    assert p.rootnode.type == driver.grammar.symbol2number["file_input"]

# Generated at 2022-06-21 10:12:11.855797
# Unit test for constructor of class Parser
def test_Parser():
    import sys

    # Import this module as a side-effect of importing the grammar
    import grammar
    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NEWLINE, "\n", Context(0, 0))
    p.addtoken(token.INDENT, "", Context(0, 0))
    p.addtoken(token.DEDENT, "", Context(0, 0))

# Generated at 2022-06-21 10:12:24.265555
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from blib2to3.pgen2 import parse
    from blib2to3.pgen2 import tokenize

    # 1. Test an input string with no errors

    a = parse("foo = 1 + 2")  # raise SyntaxError
    # a = parse("foo = 1 + 2", "exec")  # no error
    # b = parse("foo = 1 + 2", "exec")  # no error
    # assert a == b  # no error

    # 2. Test an input string with an error

    # try:
    #     parse("foo = 1 + 2 +")  # raise SyntaxError
    # except SyntaxError:
    #     pass
    # else:
    #     assert False, "Expected syntax error"

    # 3. Test an input stream with one or more errors

    # p = Parser(G

# Generated at 2022-06-21 10:12:33.015952
# Unit test for constructor of class ParseError
def test_ParseError():
    gram = Grammar()
    gram.start = 256
    gram.labels[256] = (gram.start, None)
    dfas = [{0: [(0, 0)], 1: [(0, 0)]}]
    gram.dfas[256] = (dfas, [0])
    par = Parser(gram)
    par.setup()
    try:
        par.addtoken(1, 'a', (3, 4))
    except ParseError as e:
        assert e.type == 1
        assert e.value == 'a'
        assert e.context == (3, 4)
    else:
        raise AssertionError("Didn't get exception")


# Generated at 2022-06-21 10:12:43.025159
# Unit test for method shift of class Parser
def test_Parser_shift():
    # 1. Setup the objects to be tested and the test
    import unittest
    import io
    from blib2to3.pgen2 import tokenize, driver
    from blib2to3.pgen2 import pgen
    from blib2to3.pgen2.parse import ParseError

    class TestParseError(unittest.TestCase):
        def test_parseError_noError(self):
            # 1. Setup the objects to be tested and the test
            testString = """
            42
        
            """

            testFile = io.StringIO(testString)


# Generated at 2022-06-21 10:12:54.670944
# Unit test for method setup of class Parser

# Generated at 2022-06-21 10:12:58.939573
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    if verbose: print("test_Parser_addtoken()")
    from . import driver
    from .grammar import grammar
    parser = Parser(grammar)
    driver.test(parser, verbose=verbose)
    if verbose: print("done")

# Generated at 2022-06-21 10:13:07.738174
# Unit test for method shift of class Parser
def test_Parser_shift():
    class FakeGrammar:
        def __init__(self):
            self.tokens = {"name": 1, "number": 2}
        def lam_sub(self, node):
            return node
    pgen = FakeGrammar()
    parser = Parser(pgen, pgen.lam_sub)
    parser.setup()
    parser.addtoken(token.NAME, "name", None)
    parser.addtoken(token.NUMBER, 100, None)
    parser.addtoken(token.ENDMARKER, "ENDMARKER", None)


# Generated at 2022-06-21 10:13:30.055113
# Unit test for function lam_sub

# Generated at 2022-06-21 10:13:32.399975
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)

    assert p.grammar is g
    assert p.convert is lam_sub



# Generated at 2022-06-21 10:13:43.768015
# Unit test for constructor of class Parser
def test_Parser():
    # Build a fake grammar
    class FakeDfa:
        def __init__(self, labels):
            self.labels = labels
    class FakeGrammar:
        def __init__(self):
            self.dfas = {
                1: FakeDfa([(1, 0), (2, 1)]),
                2: FakeDfa([(2, 1)]),
            }
            self.keywords = {}
            self.labels = [(1, 0), (2, 1)]
            self.start = 1
            self.tokens = {1: 0, 2: 1}
    # Test the basics
    p = Parser(FakeGrammar(), None)
    p.setup()
    p.addtoken(1, None, None)
    p.addtoken(1, None, None)
    p.add

# Generated at 2022-06-21 10:13:55.504026
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import generate
    grammar = generate.load_grammar("Python")
    parser = Parser(grammar, lam_sub)  # type: ignore
    parser.setup()
    driver.tokenize_file("../Grammar/Grammar", parser.addtoken)
    root = parser.rootnode
    assert len(root) == 3
    assert isinstance(root[0], Leaf)
    assert isinstance(root[0], Leaf)
    assert isinstance(root[1], Node)
    assert isinstance(root[2], Leaf)
    bnf = root[1]
    assert len(bnf) == 5
    tokens = bnf[1]
    assert isinstance(tokens, Node)
    assert len(tokens) == 3

# Generated at 2022-06-21 10:14:07.344829
# Unit test for function lam_sub
def test_lam_sub():
    from .grammar import Grammar

    g = Grammar("""
    stmt: simple_stmt | compound_stmt
    simple_stmt: NAME '=' expr
    expr: NAME
    compound_stmt: if_stmt | while_stmt
    if_stmt: 'if' expr ':' suite
    while_stmt: 'while' expr ':' suite
    suite: simple_stmt
    """)
    p = Parser(g, lam_sub)
    p.setup()

    # A simple statement, an assignment
    p.addtoken(token.NAME, "X", (1, 1))
    p.addtoken(token.EQUAL, "=", (1, 3))
    p.addtoken(token.NAME, "Y", (1, 5))

# Generated at 2022-06-21 10:14:15.878988
# Unit test for method classify of class Parser
def test_Parser_classify():

    import pickle

    from . import driver

    p = Parser(pickle.load(open(driver.DEFAULT_PICKLE, "rb")))
    p.setup()

    # Test some tokens from class Parser.classify()
    p.addtoken(token.NAME, "x", Context(0, 0))
    p.addtoken(token.NAME, "y", Context(0, 0))
    p.addtoken(token.PLUS, "+", Context(0, 0))
    p.addtoken(token.STAR, "*", Context(0, 0))
    p.addtoken(token.RPAR, ")", Context(0, 0))
    p.addtoken(token.RBRACE, "}", Context(0, 0))
    p.addtoken(token.BRACE, "{", Context(0, 0))

# Generated at 2022-06-21 10:14:25.339099
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = Grammar()
    token_definitions = {
        # Keyword arguments to the Parser constructor
        "KEYWORD": 1,
        # Name arguments to the Parser constructor
        "NAME": 2,
        # Non-keyword arguments to the Parser constructor
        "ARG": 3,
    }
    grammar.tokens = token_definitions
    p = Parser(grammar)
    p.setup()
    p.addtoken(1, "KEYWORD", (0,0))
    p.addtoken(2, "NAME", (0,0))
    p.addtoken(3, "ARG", (0,0))
    p.rootnode

# Generated at 2022-06-21 10:14:29.492168
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2.grammar import Grammar

    g = Grammar(r"""
    conditional_expression: logical_or_expression ('?' expression ':'
    conditional_expression)?
    """)
    p = Parser(g)



# Generated at 2022-06-21 10:14:32.503256
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar, tokenize

    with open("Grammar", "rb") as f:
        g = grammar.Grammar(f)
    p = Parser(g)

# Generated at 2022-06-21 10:14:38.870155
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        1 / 0
    except ZeroDivisionError:
        import sys
        _, _, tb = sys.exc_info()
        tb = tb.tb_next
        line = tb.tb_frame.f_lineno
        err = ParseError(msg="You dun goofed", type=1, value="Hello", context=(line, 0))
        assert str(err) == (
            "You dun goofed: type=1, value='Hello', context=(%d, 0)" % line
        )

# Generated at 2022-06-21 10:15:05.376952
# Unit test for method push of class Parser
def test_Parser_push():
    from .token import DEDENT, ENCODING, ENDMARKER, ERRORTOKEN, INDENT, NAME, NUMBER
    from .token import OP, STRING

    import blib2to3.pgen2.parse as parse
    import blib2to3.pgen2.token as token
    import blib2to3.pytree as pytree
    import blib2to3.pgen2.grammar as grammar

    t = token
    parent = t.parent
    # First, use the parse() function to parse a string with a Parser instance
    # (this is how the parser module is supposed to be used).
    s = "1+2"
    p = parse.parse(s, "exec")
    # Compare this with a manually constructed tree:

# Generated at 2022-06-21 10:15:17.868481
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import whitespace, tokenize

    python_grammar_path = "blib2to3/pgen2/python.grammar"
    with open(python_grammar_path) as python_grammar_file:
        python_grammar_content = python_grammar_file.read()
    python_grammar = Grammar(python_grammar_content)

    def classify(code):
        parser = Parser(python_grammar)
        parser.setup()
        for type, value, context in tokenize.generate_tokens(iter([code]).__next__):
            type, value, context = whitespace.untokenize(
                [(type, value, context)],
                python_grammar.version,
                python_grammar.indent_string,
            )[0]

# Generated at 2022-06-21 10:15:30.985535
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import tokenizer, grammar, driver

    grammar_ = grammar.Grammar(grammar.grammar_nts, grammar.grammar_dfas,
        grammar.grammar_labels, {}, {}, {})
    parser_ = Parser(grammar_)
    parser_.setup()
    assert parser_.grammar == grammar_
    assert parser_.convert == lam_sub
    assert not parser_.stack
    assert parser_.rootnode is None
    assert not parser_.used_names

    parser_ = Parser(grammar_, driver.lam_subtract)
    parser_.setup()
    assert parser_.grammar == grammar_
    assert parser_.convert == driver.lam_subtract
    assert not parser_.stack
    assert parser_.rootnode is None
    assert not parser_.used_names

# Unit test

# Generated at 2022-06-21 10:15:34.708881
# Unit test for function lam_sub
def test_lam_sub():
    from .grammar import Grammar

    for input in (
        (1, None, None, None),
        (1, None, (2, 3), []),
        (1, None, (2, 3), [4, 5, 6]),
    ):
        lam_sub(Grammar(start=0), input)

# Generated at 2022-06-21 10:15:46.737305
# Unit test for constructor of class Parser
def test_Parser():
    """Testing function for the Parser() constructor."""
    import sys
    import blib2to3.pgen2.parse as parse

    g = parse.grammar
    p1 = parse.Parser(g)
    p2 = parse.Parser(g, parse.lam_sub)

    # Check grammar
    assert p1.grammar is p2.grammar

    # Check convert
    assert p1.convert is parse.lam_sub
    assert p2.convert is parse.lam_sub

    # Check tokens and labels
    for t in list(parse.token.tok_dict.keys()):
        assert p1.classify(t, "abc", (1, 1)) == p2.classify(t, "abc", (1, 1))

# Generated at 2022-06-21 10:15:57.051970
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver, tokenize
    from .grammar import load_grammar

    # Terminals
    NAME = token.NAME

    # Non-terminals
    file_input = 0
    funcdef = 4
    parameters = 5
    typedargslist = 6
    tfpdef = 7
    varargslist = 8
    vfpdef = 9
    stmt = 10
    simple_stmt = 11
    small_stmt = 12
    expr_stmt = 13
    testlist_star_expr = 14
    test = 15
    or_test = 16
    and_test = 17
    not_test = 18
    comparison = 19
    comp_op = 20
    expr = 21
    xor_expr = 22
    and_expr = 23
    shift_expr = 24
    arith_expr = 25
   

# Generated at 2022-06-21 10:16:06.161757
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, token
    import unittest

    class TestClassify(unittest.TestCase):
        def setUp(self) -> None:
            self.G = grammar.Grammar("Grammar/Grammar.txt", "Grammar/Tokens.txt")
            self.P = Parser(self.G)
            self.P.setup()

        def test_classify_0(self):
            # Issue6573
            self.P.addtoken(token.NAME, "NAME", Context(1, 1))

    unittest.main(TestClassify())



# Generated at 2022-06-21 10:16:14.803859
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar

    p = Parser(g)

    assert p.classify(token.INDENT, "+", None) == g.labels.index(("+", "INDENT"))
    assert p.classify(token.DEDENT, "-", None) == g.labels.index(("-", "DEDENT"))
    assert p.classify(token.NAME, "string", None) == g.labels.index(("string", "NAME"))
    assert p.classify(token.NAME, "def", None) == g.labels.index(("def", "NAME"))

# Generated at 2022-06-21 10:16:24.248371
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar, token

    g = grammar.Grammar()
    p = Parser(g, lam_sub)
    p.setup(g.symbol2number["expr_stmt"])
    p.addtoken(token.NAME, "x", (0, 0))
    p.addtoken(token.ASSIGN, "=", (0, 0))
    p.addtoken(token.NAME, "y", (0, 0))
    root = p.rootnode
    assert len(root) == 1
    expr_stmt = root[0]
    assert expr_stmt.type == "expr_stmt"
    assert not expr_stmt.children  # Semi-colon is implicit
    expr = expr_stmt.children[0]
    assert expr.type == "expr"
    assert not expr.children

# Generated at 2022-06-21 10:16:26.057357
# Unit test for method setup of class Parser
def test_Parser_setup():
    def _f():
        p = Parser()
        p.setup()
    _f()

# Generated at 2022-06-21 10:16:57.394788
# Unit test for method setup of class Parser
def test_Parser_setup():
    g = Grammar()
    p = Parser(g)
    p.setup()
    if p.stack[0][0][1] != {0: [(1, 0)]}:
        raise Exception("Test failed: expected: %r, got: %r" % ({0: [(1, 0)]}, p.stack[0][0][1]))
    if p.rootnode is not None:
        raise Exception("Test failed: expected: %r, got: %r" % (None, p.rootnode))
    if p.used_names != set():
        raise Exception("Test failed: expected: %r, got: %r" % (set(), p.used_names))



# Generated at 2022-06-21 10:17:06.928080
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Unit test for addtoken()"""

# Generated at 2022-06-21 10:17:10.764037
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, token

    p = Parser(grammar)
    p.setup()
    p.shift(token.NUMBER, "1", 1, (1, 0))
    assert p.stack[-1][2][-1][1] == "1"



# Generated at 2022-06-21 10:17:15.568059
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = Grammar()
    convert = Convert
    parser = Parser(grammar, convert)
    type = token.NAME
    value = '+'
    context = Context(('', 1), '+')
    newstate = 0
    parser.shift(type, value, newstate, context)

# Generated at 2022-06-21 10:17:27.003412
# Unit test for method pop of class Parser
def test_Parser_pop():

    import itertools
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pgen2 import driver

    # Create one grammar instance and reuse it
    g = driver.load_grammar("Python.g4")
    p = Parser(g)

    # Parse "a + b" and check the result
    p.setup()
    tok: Any
    for tok in [
        (syms.atom, "a", (1, 0)),
        (token.PLUS, "+", (1, 2)),
        (syms.atom, "b", (1, 4)),
    ]:
        p.addtoken(tok[0], tok[1], tok[2])
    assert len(p.rootnode) == 3

# Generated at 2022-06-21 10:17:33.142264
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("bad token", token.NAME, "a", (1, 0))
    except ParseError as err:
        assert str(err) == 'bad token: type=306, value=\'a\', context=(1, 0)'
        assert err.type == token.NAME
        assert err.value == "a"
        assert err.context == (1, 0)



# Generated at 2022-06-21 10:17:36.863490
# Unit test for constructor of class Parser
def test_Parser():
    import gc

    # Uncollectable until Python 2.0 :(
    # XXX This test should be rewritten to not depend on gc module
    gc.collect()
    n = gc.collect()
    p = Parser(None)
    p.setup()
    p.addtoken(1, "a", "xyz")
    del p
    gc.collect()
    if gc.collect() != n + 1:
        print("del p failed to reclaim p")

# Generated at 2022-06-21 10:17:43.197578
# Unit test for function lam_sub
def test_lam_sub():
    from . import pgen2
    from . import driver

    grammar = pgen2.Grammar()
    grammar.load("Python.gram")
    parser = Parser(grammar, lam_sub)
    parser.setup()
    for token, lineno, col in driver.tokenize_file("Grammar.txt"):
        parser.addtoken(token, None, Context(lineno, col))
    print("OK")

# Generated at 2022-06-21 10:17:53.073779
# Unit test for method setup of class Parser
def test_Parser_setup():
    r"""
    >>> from . import pgen2
    >>> grammar = pgen2.parse_grammar(pgen2.grammar)

    The actual start symbol is determined by the grammar (this one is
    defined in Grammar/Grammar).  We can override it.

    >>> p = Parser(grammar)
    >>> p.setup(grammar.start)
    >>> p.stack
    [(..., 0, (257, None, None, []))]
    >>> p.stack[0][0][0][0]
    [(1, 2), (1, 4), (0, 1)]
    >>> p.stack[0][0][1]
    set([257])
    """



# Generated at 2022-06-21 10:18:00.131508
# Unit test for method pop of class Parser
def test_Parser_pop():
    from unittest import TestCase, mock
    import warnings
    import io
    import tokenize
    import blib2to3.pgen2.grammar
    import blib2to3.pgen2.driver
    import blib2to3.pgen2.parse
    import blib2to3.pytree as pytree
    import blib2to3.pgen2.convert
    import blib2to3.fixes.fix_pass
    import blib2to3.fixes.fix_print
    import blib2to3.fixes.fix_raw_input
    import blib2to3.fixes.fix_reduce
    import blib2to3.fixes.fix_reload
    import blib2to3.fixes.fix_remove_unicode
    import blib2to3.fixes.fix_

# Generated at 2022-06-21 10:18:55.090177
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    # load grammar
    _grammar = grammar.grammar
    assert _grammar.keywords["False"] == 1
    assert _grammar.tokens[57] == 2
    assert _grammar.labels[2] == (57, "lambda")


# Generated at 2022-06-21 10:19:04.242769
# Unit test for method setup of class Parser
def test_Parser_setup():
    # Used to verify that the _context attribute of a Node is set by the
    # Parser.setup() method
    def my_convert(grammar, node):
        if node[0] == 58:  # symbol
            return Node(type=node[0], children=node[3], context=node[2])
        return node[1]

    p = Parser(grammar=Grammar(grammar=None), convert=my_convert)
    p.setup(start=58)

    # If a converter is not given, _context should be set to None.
    # noinspection PyUnresolvedReferences
    assert p.rootnode._context is None

    # If a converter is given, the _context attribute of the rootnode
    # should be the same object as the context argument that was passed
    # to the addtoken() method

# Generated at 2022-06-21 10:19:12.825153
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from blib2to3.pgen2 import driver

    # Create a parser instance
    pg = driver.load_grammar("python2.7.5.gram")
    p = Parser(pg)

    # Start parsing; this only sets up the parser to receive tokens
    p.setup()

    # Feed the parser tokens
    # The list of tokens below is taken from the Python 2.3 tutorial,
    # http://docs.python.org/tut/node9.html
    input = [[(1, 'spam'), (3, ','), (1, 'eggs'), (4, 'and'), (1, 'ham'), (0, '\n')]]
    for input in input:
        for token in input:
            type, value = token

# Generated at 2022-06-21 10:19:16.375322
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    p = Parser(grammar.num_gnu_grammar, None)
    p.setup()
    p.addtoken(token.NUMBER, '1', (1, 1))
    assert p.addtoken(token.ENDMARKER, None, (2, 0))



# Generated at 2022-06-21 10:19:23.692390
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.pgen2.parse as parse
    import blib2to3.pgen2.driver as driver

    s = "a = 1"
    gr = driver.load_grammar("Grammar/Grammar")
    p = parse.Parser(gr)
    p.setup()
    for t in driver.tokenize_by_lines(s):
        p.addtoken(*t)
    assert p.rootnode.leaves() == ['a', '=', '1']



# Generated at 2022-06-21 10:19:28.257265
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("message", 42, "value", "context")
    except ParseError as e:
        assert e.msg == "message"
        assert e.type == 42
        assert e.value == "value"
        assert e.context == "context"

# Generated at 2022-06-21 10:19:31.276444
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("msg", 1, "value", Context(1, 0))
    assert err.msg == "msg"
    assert err.type == 1
    assert err.value == "value"
    assert err.context == Context(1, 0)

# Generated at 2022-06-21 10:19:38.903356
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    assert p
    assert p.stack == []

    def test1(start):
        p.setup(start)
        assert len(p.stack) == 1
        assert p.stack[0][0] == g.dfas[start]
        assert p.stack[0][1] == 0
        assert p.stack[0][2][0] == start

    test1(g.start)
    test1(g.symbol2number["funcdef"])

    p.setup()
    class Test1(object):

        """Dummy class to test conversion."""

        def __init__(self, type: int, value: Optional[Text], children: Sequence[Any]) -> None:
            self.type = type

# Generated at 2022-06-21 10:19:49.243016
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2 import token
    # we need to mock raw nodes so that our parser can create them
    class FakeRawNode:
        def __init__(self, type, value, context, children):
            self.type = type
            self.value = value
            self.context = context
            self.children = children

    mock_stack = []
    mock_node = FakeRawNode(1, 'mock_node', None, [])
    mock_dfa = []
    mock_stack.append((mock_dfa, 0, mock_node))
    mock_stack_entry = mock_stack[-1]
    mock_dfa, mock_state, mock

# Generated at 2022-06-21 10:19:59.055404
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver, grammar

    # Since the key for tokens is a tuple of (type, value) we need a
    # mock tokenizer to create such a tuple, otherwise the tokens
    # would not match the labels and raise an exception.
    class MockTokenizer:
        def __init__(self, token: Sequence[Tuple[Any, Any]]) -> None:
            self.token = token

        def __iter__(self) -> Any:
            for t in self.token:
                yield t

    # Create a grammar instance
    g = grammar.Grammar(driver.grammar)
    # Create a mock tokenizer to generate a tuple of (type, value)
    # since this is the key for the tokens.
    t = MockTokenizer([(1, '1'), (2, '2'), (3, '3')])
   