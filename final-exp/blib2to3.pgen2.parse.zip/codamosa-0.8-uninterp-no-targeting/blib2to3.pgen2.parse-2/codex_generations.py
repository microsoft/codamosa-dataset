

# Generated at 2022-06-21 10:10:24.028292
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    g: Grammar = Grammar()
    g.labels = [('x', 'y'), ('z', 'z')]
    g.tokens = {'z': 1}
    g.dfas[0] = ((((1, 0),), {}), {0: ()})
    p = Parser(g)
    p.setup()
    p.addtoken('z', 'z', None)

# Generated at 2022-06-21 10:10:25.264096
# Unit test for method push of class Parser
def test_Parser_push():
    pass


# Generated at 2022-06-21 10:10:26.731132
# Unit test for constructor of class Parser
def test_Parser():
    grammar = Grammar()
    parser = Parser(grammar)

# Generated at 2022-06-21 10:10:37.534457
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from blib2to3.pgen2.parse import ParseError

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.pop() is None
    assert p.rootnode is None
    assert p.stack == []

    p.setup()
    p.stack.append(('dfa', 'state', ('node_type', None, None, [])))
    assert p.pop() is None
    assert p.rootnode is None
    assert p.stack == [('dfa', 'state', ('node_type', None, None, []))]

    p.setup()
    p.stack.append(('dfa', 'state', ('node_type', None, None, [])))
    p.rootnode = 'ex_rootnode'

# Generated at 2022-06-21 10:10:44.422605
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import __main__ as main

    parser = Parser(main.pgen.pgen.grammar)
    parser.classify(token.NAME, 'and', None)
    parser.classify(token.NAME, 'z', None)
    try:
        parser.classify(token.COMMENT, '# hello', None)
        assert False, 'Should have raised ParseError'
    except ParseError:
        pass

# Generated at 2022-06-21 10:10:48.797885
# Unit test for function lam_sub
def test_lam_sub():
    assert lam_sub(None, ("foo", None, None, None)) is None
    assert lam_sub(None, ("foo", None, None, [1, 2])) == Node(
        type="foo", children=(1, 2), context=None
    )

# Generated at 2022-06-21 10:10:59.079916
# Unit test for method setup of class Parser
def test_Parser_setup():
    import io
    import sys
    import blib2to3.pgen2.driver

    # Set up
    input = io.StringIO(sys.stdin.read())
    encoding = sys.stdin.encoding
    lexer = blib2to3.pgen2.driver.Driver(input, encoding).build_lexer()
    dfa = [[(0, 1), (1, 2)], [(0, 2), (2, 3)], [(0, 3), (3, 3)], [(0, 3)]]
    labels = [('a', ''), ('b', ''), ('b', ''), ('c', ''), ('c', '')]

# Generated at 2022-06-21 10:11:03.822454
# Unit test for function lam_sub
def test_lam_sub():
    r = lam_sub(None, (1, 'type', (1, 1), [1, (1, 'value', (3, 3), None), 3]))
    assert r == Node(1, [(1, 'type', (1, 1), [1, (1, 'value', (3, 3), None), 3])], (1, 1))

# Generated at 2022-06-21 10:11:05.106867
# Unit test for method setup of class Parser
def test_Parser_setup():
    g = Grammar()
    p = Parser(g)
    p.setup()

# Generated at 2022-06-21 10:11:13.353960
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    assert p.rootnode[0] == symbol.atom
    assert p.rootnode[1] == "a"
    assert p.rootnode[2] == (1, 0)
    assert p.rootnode[3] == []


if __name__ == "__main__":
    test_Parser()

# Generated at 2022-06-21 10:11:29.596413
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Tests the function Parser.addtoken in the pgen2.parser module.
    # This is called via unittest.main() in test_parser.py
    # This imports this module so Parser class is available.
    from . import test_parser

    # Define a simple grammar
    tokens = test_parser.make_tokens()
    keywords = {
        "and": tokens["AND"],
        "or": tokens["OR"],
        "not": tokens["NOT"],
        "is": tokens["IS"],
        "None": tokens["NAME"],
        "True": tokens["NAME"],
        "False": tokens["NAME"],
    }
    symbols = test_parser.make_symbols()
    productions = test_parser.make_productions()


# Generated at 2022-06-21 10:11:30.497174
# Unit test for method setup of class Parser
def test_Parser_setup():
    assert Parser


# Generated at 2022-06-21 10:11:42.644374
# Unit test for method pop of class Parser
def test_Parser_pop():
    class MockGrammar:
        def __init__(self) -> None:
            self.start = 257
            self.dfas = {257: (0, {})}

        def __getitem__(self, index: int) -> int:
            return 0

        def __len__(self) -> int:
            return 0

        def __iter__(self) -> int:
            return iter([])

    class MockConverter:
        def __init__(self) -> None:
            self.called = False

        def __call__(self, grammar: Grammar, node: RawNode) -> RawNode:
            self.called = True
            return node

    p = Parser(MockGrammar(), MockConverter())
    p.setup()
    p.push(257, 0, 0, None)

# Generated at 2022-06-21 10:11:52.671487
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Check that shift works well"""
    from .tokenize import tokenize_lines

    grammar = Grammar()
    parser = Parser(grammar, None)

    # Create a very simple parse tree to check that Token(1, '1') is added as a leaf
    parser.push(10, grammar.dfas[10], 1, None)
    parser.push(11, grammar.dfas[11], 2, None)
    parser.stack.append(([([(0, 3)], {100: 2})], 3, ((11, None, None, []))))
    parser.shift(10, '1', 4, None)


# Generated at 2022-06-21 10:12:04.130588
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    import os
    import blib2to3.pgen2.pgen
    import blib2to3.pgen2.tokenize

    def classify(type: int, value: Optional[Text], context: Any) -> Optional[int]:
        assert value is not None
        label = self.grammar.tokens.get(type)
        if label is None:
            raise ParseError("bad token", type, value, context)
        return label

    class TestParser(unittest.TestCase):
        @classmethod
        def setUpClass(cls) -> None:
            dir = os.path.dirname(blib2to3.pgen2.pgen.__file__)
            filename = os.path.join(dir, "..", "Grammar.txt")
            fd

# Generated at 2022-06-21 10:12:16.591487
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2.grammar import Grammar


# Generated at 2022-06-21 10:12:23.612428
# Unit test for function lam_sub
def test_lam_sub():
    gram = Grammar(token)
    node = (1, None, 1, [
        (2, "A", None, None),
        (3, "B", 1, [
            (4, "C", None, None),
            (5, "D", 2, None),
        ]),
        (6, "E", 3, []),
    ])
    lam_sub(gram, node)



# Generated at 2022-06-21 10:12:25.238972
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import tokenize
    from . import parser


# Generated at 2022-06-21 10:12:34.176720
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

# Generated at 2022-06-21 10:12:43.788801
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from .token import ERRORTOKEN, NAME, OP

    g = grammar.Grammar()
    g.symbol("START").add("START", "'a'", "START", "START", "START")
    g.symbol("START").add("START", "'b'", "START", "START", "START")
    g.symbol("START").add("START", "'a'", "'b'")
    g.symbol("START").add("START")
    g.symbol("START").default("START")

    p = Parser(g)
    p.setup("START")
    p.addtoken(NAME, "a", None)
    p.addtoken(NAME, "b", None)

# Generated at 2022-06-21 10:13:01.406608
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar())
    p.setup()
    p.stack.append((None, 0, (None, None, None, [])))
    p.shift(1, "token", 1, RawNode)
    assert p.stack[-1][-1][-1] == [Leaf(1, "token", RawNode)]

# Generated at 2022-06-21 10:13:08.424901
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .tokenizer import generate_tokens
    from . import grammar
    from .pgen import Driver
    d = Driver(grammar, convert=lam_sub)
    p = d.parser
    p.setup()
    with open("test.py") as f:
        for type, value, lineno, line in generate_tokens(f.readline, False):
            assert not p.addtoken(type, value, lineno)

# Generated at 2022-06-21 10:13:13.021355
# Unit test for method shift of class Parser
def test_Parser_shift():
    # This is the first part of driver.py
    import sys
    import random

    import blib2to3.pgen2.driver
    import blib2to3.pgen2.parse
    import blib2to3.pygram.python_symbols as python_symbols
    import blib2to3.pygram.python_grammar as python_grammar
    from blib2to3.pgen2.convert import untokenize

    from . import token

    (grammar, first, _follow) = python_grammar.load_grammar()
    driver = blib2to3.pgen2.driver.Driver(grammar, convert=blib2to3.pgen2.convert)

    # Load sample file
    f = open("../../test/inputs/sample3.py")


# Generated at 2022-06-21 10:13:24.790688
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver
    from . import grammar
    from . import tokenize

    # From .pyi files
    for filename in [
        "./pythonlib/blib2to3/pygram/python_symbols.pyi",
        "./pythonlib/blib2to3/pygram/python_grammar.pyi",
    ]:
        f = open(filename)
        g = grammar.Grammar(f.read())
        t = driver.Driver(grammar=g, convert=lam_sub, tokenizer=tokenize.Untokenizer)
        p = Parser(g, lam_sub)
        p.setup()
        for type, value, start, end, line in t.tokenize(f.readline):
            p.addtoken(type, value, Context(start, end, line))
       

# Generated at 2022-06-21 10:13:34.496398
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver  # needed to untangle imports
    import os.path

    t = driver.driver
    p = driver.load_parser()

    def test(data):
        p.setup()
        p.addtoken(token.INDENT, "    ", Context(None, 1, 0))
        for type, value, start, end, line in data:
            context = Context(line, start[0], start[1])
            p.addtoken(type, value, context)
            assert p.classify(type, value, context) == type

    # Non-keyword tests
    test([(token.NUMBER, "1", (1, 0), (1, 1), "1")])
    test([(token.NAME, "a", (1, 0), (1, 1), "a")])

# Generated at 2022-06-21 10:13:36.083768
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    #
    # Test the behavior at end of input.
    #
    pass

# Generated at 2022-06-21 10:13:43.771562
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import tokenize
    import io

    input = io.StringIO('1 + 2')
    tokens = tokenize.generate_tokens(input.readline)
    grammar = driver.load_grammar('Grammar')
    parser = Parser(grammar)
    parser.setup()
    for type, value, context in tokens:
        if parser.addtoken(type, value, context):
            break
    print(parser.rootnode)

# Generated at 2022-06-21 10:13:48.469257
# Unit test for method setup of class Parser
def test_Parser_setup():
    import blib2to3.pgen2.driver

    g = blib2to3.pgen2.driver.load_grammar("Grammar.txt")
    p = Parser(g)
    # Call the method
    p.setup()
    # Check the required attributes
    assert p.grammar == g, "Parser.setup() failed to assign the attribute grammar"
    assert p.convert == lam_sub, (
        "Parser.setup() failed to assign the attribute convert"
    )
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))], (
        "Parser.setup() failed to assign the attribute stack"
    )
    assert p.rootnode is None, "Parser.setup() failed to assign the attribute rootnode"
    assert p.used_

# Generated at 2022-06-21 10:13:58.670882
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import token
    from . import driver

    from .driver import parse_tokens

    from blib2to3.pytree import Leaf, Node
    from blib2to3.pgen2.grammar import Grammar

    def tree_to_string(tree: Union[Node, Leaf]) -> Text:
        if isinstance(tree, Leaf):
            return tree.value
        else:
            return " ".join([tree.type] + [tree_to_string(x) for x in tree.children])

    def test_parser(
        convert: Optional[Convert],
        input: Sequence[Tuple[int, Text, Context]],
        output: Text,
    ) -> None:
        p = Parser(driver.grammar, convert=convert)
        p.setup(start=driver.grammar.start)

# Generated at 2022-06-21 10:14:10.807495
# Unit test for method shift of class Parser
def test_Parser_shift():
    from textwrap import dedent
    from blib2to3.pgen2.parse import driver
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2.grammar import grammar, flatten, parse_grammar
    from blib2to3.pgen2.pgen import generate_parser
    from . import parse_tree_util
    from . import SimpleGrammar as G

    generate_parser(grammar)
    from .grammar import PgenParser

    def test_parser():
        def convert(grammar, node):
            assert node[-1] is not None
            return Node(node[0], node[-1], node[-2])

        p = Parser(G.grammar.grammar, convert)
        p.setup()

# Generated at 2022-06-21 10:14:31.383348
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import parser
    from . import token
    from . import grammar
    import driver
    import tokenize
    import io

    grammar = grammar.from_file('Python.gram', 'Grammar/Grammar')
    #grammar = grammar.from_file('Python.gram', 'lib2to3/Grammar.txt')
    parser = parser.Parser(grammar)

    f = io.StringIO('x')
    tokenize_gen = tokenize.generate_tokens(f.readline)
    g = driver.generate_tokens(tokenize_gen)
    parser.setup()
    while True:
        try:
            type, value, context, start, end, line = next(g)
        except StopIteration:
            break

# Generated at 2022-06-21 10:14:37.326977
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver
    import sys

    # Create a parser object
    parser = Parser(driver.grammar)

    with open(sys.argv[1]) as f:
        tokens = driver.tokenize(f.readline)
        for typ, token, start, end, line in tokens:
            print(parser.classify(typ, token, (start, end)))


if __name__ == "__main__":
    test_Parser_classify()

# Generated at 2022-06-21 10:14:40.596811
# Unit test for method push of class Parser
def test_Parser_push():
    g = Grammar('', '', {}, {}, {}, {}, [], [])
    p = Parser(g)
    p.push('', ([], {}), 0, '')
    assert p.stack == [(([], {}), 0, ('', None, None, []))]
    assert p.rootnode is None
# End unit test

# Generated at 2022-06-21 10:14:45.328078
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    g = grammar.Grammar(grammar.grammar_nts, grammar.grammar_dfas, grammar.grammar_labels)
    lam_sub(g, (1, None, (1, 0), [2, 3]))

# Generated at 2022-06-21 10:14:56.718453
# Unit test for method push of class Parser
def test_Parser_push():
    import pdb; pdb.set_trace()
    
    # /tmp/calculator.out
    # 6 states, 7 labels, and 62 arcs:
    # States:
    # 0: [1, 3, 6]
    # 1: [5]
    # 2: [4, 7, 3]
    # 3: []
    # 4: [6]
    # 5: []
    # 6: [2, 3, 6]
    # Accepting states:
    # 5
    # Labels:
    # 0: NUMBER
    # 1: PLUS
    # 2: TIMES
    # 3: (
    # 4: )
    # 5: EXPRESSION
    # 6: FACTOR
    # Arcs:
    # 0, 0, 1
    # 0, 0, 3
    # 0,

# Generated at 2022-06-21 10:14:58.859226
# Unit test for function lam_sub
def test_lam_sub():
    # This appears to be the only test that does not assert
    # (It is possible that tests are missing that do check)
    assert lam_sub({'dfas': ((), {}), 'labels': []}, (3, None, None, [])) is not None

# Generated at 2022-06-21 10:15:10.526620
# Unit test for method shift of class Parser
def test_Parser_shift():
    class MockGrammar(object):
        dfa = {}  # type: DFA
        labels = {}  # type: Dict[int, Tuple[int, Text]]
        symbols = {}  # type: Dict[Text, int]
        tokens = {}  # type: Dict[int, int]
        start = 0
        dfas = {0: ([[(0, 0)]], {})}
    grammar = MockGrammar()
    p = Parser(grammar)
    p.stack = [(grammar.dfas[0], 0, ("<int>", None, "1", []))]
    p.shift(33, "@", 0, "1")
    p.shift(33, "=", 0, "1")
    assert len(p.stack) == 1

# Generated at 2022-06-21 10:15:21.252784
# Unit test for method pop of class Parser
def test_Parser_pop():
    from pprint import pprint
    from . import grammar
    from . import tokens
    from . import driver

    print("===== Parser.pop unit test =====")

    # Test data

# Generated at 2022-06-21 10:15:33.680667
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Symbols

    grammar = Grammar(Symbols(["foo", "bar"]), {"bar": "ENDMARKER"}, {}, {})
    parser = Parser(grammar)
    parser.setup()
    parser.push(1, grammar.dfas[1], 0, None)
    parser.shift(1, "bar", 0, None)
    parser.shift(1, "ENDMARKER", 0, None)
    assert len(parser.stack) == 2
    parser.pop()
    assert parser.stack == [(grammar.dfas[1], 0, (1, None, None, [1, "bar"]))]
    parser.pop()
    assert len(parser.stack) == 0
    assert parser.rootnode[1] == 1


# Utility

# Generated at 2022-06-21 10:15:35.947830
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .grammar import Grammar, EmptyProduction

    p = Parser(Grammar([EmptyProduction()]))
    assert p.classify(token.NAME, "foo", 123) == 257


# Generated at 2022-06-21 10:16:00.724772
# Unit test for method classify of class Parser
def test_Parser_classify():
    test_grammar = Grammar()
    test_grammar.tokens = {
        token.NAME: 0,
        token.FALSE: 1,
        token.TRUE: 2,
        token.STRING: 3,
        token.OBJID: 4,
        token.FLOAT: 5,
        token.INTEGER: 6,
    }
    test_grammar.keywords = {"false": 1, "true": 2}
    test_parser = Parser(test_grammar)
    test_parser.used_names = set()
    test_context = Context(0, 0)
    test_name = "test_name"
    test_string = "test_string"

    test_parser.classify(token.NAME, test_name, test_context)
    assert test_parser.used_

# Generated at 2022-06-21 10:16:04.079099
# Unit test for function lam_sub
def test_lam_sub():
    g = Grammar()
    lam_sub(g, (1, '', (1,1), [1,2,3])) # type: ignore

# Generated at 2022-06-21 10:16:15.495874
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import token as token_
    p = Parser(grammar.define_grammar("Spam <eggs> = None"))
    p.setup()
    p.addtoken(token_.NAME, "Spam", (1, 1))
    p.addtoken(token_.OP, "<", (1, 5))
    p.addtoken(token_.NAME, "eggs", (1, 6))
    p.addtoken(token_.OP, ">", (1, 10))
    p.addtoken(token_.OP, "=", (1, 12))
    p.addtoken(token_.NAME, "None", (1, 14))
    assert p.rootnode[0] == "file_input"
    stmt = p.rootnode[1][0]

# Generated at 2022-06-21 10:16:21.461329
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.token import Token
    p = Parser(Grammar())
    assert p.classify(Token.NT_OFFSET + 1, None, None) == 1
    assert p.classify(0, "name", None) == 0
    raises(ParseError, p.classify, 0, None, None)


# Generated at 2022-06-21 10:16:31.141757
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest
    import os
    import unittest.mock as mock

    import blib2to3.tokenize
    from blib2to3.pgen2.tokenizer import generate_tokens
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.tokenize import tokenize, tokenize_loop
    from blib2to3.pygram import python_grammar

    class TestParse(unittest.TestCase):
        def test_Parser_shift(self):

            grammar = python_grammar
            tokens = {}
            for k, v in grammar.tokens.items():
                tokens[v] = k
            # Input string

# Generated at 2022-06-21 10:16:33.871799
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar(grammars=[], keyword_tokens=[], tokens=[], labels=[], dfas={}))
    p.setup()
    assert p.stack == []
    assert p.rootnode is None


# Generated at 2022-06-21 10:16:45.720343
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    assert Parser.__init__.__doc__ is not None

    g = grammar.Grammar()

    p = Parser(g)
    assert p.grammar is g
    assert p.convert is lam_sub

    # Test convert=None
    p = Parser(g, None)
    assert p.convert is lam_sub

    # Test with a user-defined converter
    counter = [0]  # nonlocal

    def my_convert(g: Grammar, node: RawNode) -> Node:
        counter[0] = counter[0] + 1
        return node

    p = Parser(g, my_convert)
    assert p.convert is not lam_sub

    p = Parser(g, my_convert)

# Generated at 2022-06-21 10:16:47.837126
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser()
    p.setup()


# Generated at 2022-06-21 10:16:57.652940
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import driver
    p = Parser(grammar.grammar, None)
    p.setup()
    assert p.stack == [(grammar.grammar.dfas[1], 0, (1, None, None, []))]
    p.setup(1)
    assert p.stack == [(grammar.grammar.dfas[1], 0, (1, None, None, []))]
    p.setup(2)
    assert p.stack == [(grammar.grammar.dfas[2], 0, (2, None, None, []))]
    # An invalid start symbol should give a value error
    try:
        p.setup(3)
    except ValueError:
        pass
    else:
        raise TestFailed('expected ValueError')


# Generated at 2022-06-21 10:17:02.694397
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import pickle

    with open("Grammar.pickle", "rb") as f:
        grammar = pickle.load(f)

    p = Parser(grammar)
    p.setup()

    fp = open("../test/input/simple_expressions.txt")

    for token in tokenize.generate_tokens(fp.readline):
        print(token)
        if p.addtoken(token[0], token[1], token[2]):
            break

    fp.close()

    print(p.rootnode)


if __name__ == "__main__":
    test_Parser_addtoken()

# Generated at 2022-06-21 10:17:47.101461
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Tests the addtoken method of the Parser class.

    The following operations are tested:
    - Adding tokens with no conflicts, and a single conflict that
      requires popping the top of the stack.
    - Adding tokens with a conflict that requires pushing a symbol
      onto the stack.
    - Adding tokens with a conflict that requires popping the stack
      while in an accepting state.

    """
    grammar = Grammar(
        """
    S: a S b | S a | S b | c S | d S | d;
    """
    )
    # This parser has no converter; it will produce a concrete syntax
    # tree.
    p = Parser(grammar)
    p.setup()

    # Add 5 tokens with no conflicts.

# Generated at 2022-06-21 10:17:56.997372
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from .pygram import python_symbols as syms
    import unittest

    class TestLamSub(unittest.TestCase):
        def test_basic(self):
            grammar = grammar.load_grammar()
            g = grammar.grammar

            a = (syms.testlist, None, None, [])
            b = (syms.term_op, "and", None, None)
            c = (syms.and_test, None, None, [])
            subtree = (syms.test, None, None, [a, b, c])

            nl = LamSub(g, subtree)
            assert isinstance(nl, Node)
            assert nl.type == syms.test
            assert nl.children == [a, b, c]

    return un

# Generated at 2022-06-21 10:18:02.646367
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for type, token, start, end, line in tokenize.generate_tokens(open("Grammar.txt")):
        p.addtoken(type, token, (start[0], start[1]))

# Generated at 2022-06-21 10:18:11.286712
# Unit test for constructor of class Parser

# Generated at 2022-06-21 10:18:16.902778
# Unit test for method setup of class Parser
def test_Parser_setup():
    from .driver import Driver

    drv = Driver()
    prs = Parser(drv.grammar)
    prs.setup()
    assert prs.stack[-1][0] is None
    assert prs.stack[-1][1] is None
    assert prs.stack[-1][2][0] == 257  # start symbol is file_input



# Generated at 2022-06-21 10:18:28.560356
# Unit test for method pop of class Parser
def test_Parser_pop():

    class FakeGrammar:
        start = 1
        keywords = {}
        tokens = {}

        def __init__(self):
            self.dfas = {1: ([[(1, 1), (2, 2)]], {}), 2: ([[(2, 2)]], {})}
            self.labels = {1: (1, None), 2: (2, None)}

    class FakeNode:
        pass

    p = Parser(FakeGrammar())
    p.setup()
    assert p.stack == [
        (p.grammar.dfas[p.grammar.start], 0, (1, None, None, []))
    ]
    p.stack.append((p.grammar.dfas[2], 2, (2, None, None, [])))

# Generated at 2022-06-21 10:18:39.531900
# Unit test for function lam_sub
def test_lam_sub():
    from . import pgen

    def nl(seq: Sequence[Any]) -> Node:
        """Build a node from a sequence.

        nl([1, 2, 3]) -> Node(1, [Node(2, [Node(3, [])])])

        """
        if not seq:
            return Node(0, [])
        return Node(seq[0], [nl(seq[1:])])

    # Test 1: no conversion
    g = pgen.grammar.Grammar(debug=False)
    p = Parser(g)
    for i in range(1, 4):
        p.addtoken(g.tokens[i], None, (i, i))
    assert p.rootnode == nl([1, 2, 3])

    # Test 2: lam_sub
    g = pgen.gram

# Generated at 2022-06-21 10:18:42.268400
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar, token

    p = Parser(grammar)

    # A syntax error
    p.setup()
    p.addtoken(token.NAME, "stuff", (1, 0))

# Generated at 2022-06-21 10:18:53.015239
# Unit test for method shift of class Parser
def test_Parser_shift():
    f = Parser(Grammar())
    f.setup()
    # normal
    f.shift(17, "abcd", 1, (1, 2))
    assert f.stack == [(([([(0, 0)], (17, 1))], 0), 1, (17, "abcd", (1, 2), None))]
    # precondition
    try:
        f.shift(None, "abcd", 1, (1, 2))
        assert False
    except AssertionError:
        pass
    # precondition
    try:
        f.shift(17, None, 1, (1, 2))
        assert False
    except AssertionError:
        pass
    # precondition

# Generated at 2022-06-21 10:19:02.425569
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from .pgen2 import (
        driver,
    )

    module_name = "blib2to3.pgen2.pgen2_grammar"
    driver.load_grammar(module_name)
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    # add token.LPAR
    p.addtoken(40, "(", None)
    # add token.NAME
    p.addtoken(1, "f", None)
    # add token.RPAR
    p.addtoken(41, ")", None)
    # add token.NEWLINE
    p.addtoken(4, "\n", None)
    assert p.rootnode
    assert p.rootnode.type == symbol.file_input