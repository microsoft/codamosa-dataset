

# Generated at 2022-06-21 10:10:24.396898
# Unit test for function lam_sub
def test_lam_sub():
    from . import parse

    raw1 = (0, "", None, [])
    raw2 = (1, "", None, [])
    raw3 = (2, "", None, [])
    raw4 = (3, "", None, [])
    raw5 = (4, "", None, [])
    raw6 = (5, "", None, [])
    lam_sub(parse.grammar, raw1)  # Doesn't blow up
    assert lam_sub(parse.grammar, raw2) is None
    assert lam_sub(parse.grammar, raw3) is None
    assert lam_sub(parse.grammar, raw4) is None
    assert lam_sub(parse.grammar, raw5) is None
    assert lam_sub(parse.grammar, raw6) is None


# Unit test

# Generated at 2022-06-21 10:10:35.718799
# Unit test for method pop of class Parser
def test_Parser_pop():
    class MockGrammar:
        """Mock grammar."""
        dfas = {"S": ([[(1, 0), (0, 0)], [(4, 1), (0, 0)]]), 
                "L": ([[(2, 0)], [(3, 2), (0, 1)], [(3, 2), (0, 2)]])}
        start = "S"
        labels = {1: (1, None), 2: (2, None), 3: (3, None), 4: (4, None)}
        keywords = {}
        tokens = {}

    mockgrammar = MockGrammar()
    mockconvert = lambda grammar, node: node
    parser = Parser(mockgrammar, mockconvert)


# Generated at 2022-06-21 10:10:42.386831
# Unit test for method classify of class Parser
def test_Parser_classify():
    g = Grammar()
    g.literal_names = {
        "NAME": token.NAME,
        "STRING": token.STRING,
        "NUMBER": token.NUMBER,
        "INDENT": token.INDENT,
        "DEDENT": token.DEDENT,
    }
    p = Parser(g)
    p.classify(token.NAME, "hello", Context(None, 1, 0))
    p.classify(token.STRING, '"hello"', Context(None, 1, 0))
    try:
        p.classify(token.NAME, "hello", Context(None, 1, 0))
    except Exception:
        pass
    else:
        assert False

# Generated at 2022-06-21 10:10:54.876552
# Unit test for method shift of class Parser
def test_Parser_shift():
    # AssertionError: assert dfa.shape == newdfa.shape
    # AssertionError: assert node[-1] is not None
    # AssertionError: assert value is not None
    #
    # test_Parser_shift() takes 0 positional arguments but 1 was given
    import StringIO
    from .driver import Driver

    parser = Parser(Grammar, None)
    parser.setup()
    # No access to parser.stack
    #
    # State 0 and 1 are not accepting states
    # State 2 is an accepting state
    #
    # Arcs leading out of state 1
    # +1 -> State 0
    #
    # State 0 is not accepting

    # Since there are no arcs out of state 0, the parser won't advance

# Generated at 2022-06-21 10:11:00.709679
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("foo", 1, "bar", Context(0, 0))
    assert err.msg == "foo"
    assert err.type == 1
    assert err.value == "bar"
    assert err.context == Context(0, 0)

# Generated at 2022-06-21 10:11:09.128760
# Unit test for function lam_sub
def test_lam_sub():
    import pytest # type:ignore
    from blib2to3.pgen2.grammar import emptyGrammar

    def check(rawnode: RawNode) -> bool:
        node = lam_sub(emptyGrammar, rawnode)
        pass
        if rawnode[0] == 1:
            assert isinstance(node, Leaf)
            assert node.type.startswith("NAME-")
            assert node.value == "x"
            assert node.context == Context(None, None, None)
            return True
        elif rawnode[0] == 2:
            children = rawnode[3]
            assert isinstance(node, Node)
            assert node.type == "x"
            assert len(node.children) == 2
            assert isinstance(node.children[0], Leaf)

# Generated at 2022-06-21 10:11:14.754706
# Unit test for constructor of class Parser
def test_Parser():
    from .pgen import driver

    gram = driver.load_grammar('Grammar/Grammar')
    p = Parser(gram, None)
    p.setup()
    # Add a token
    p.addtoken(token.NAME, "if", (1, 0))


# Generated at 2022-06-21 10:11:26.664622
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Instantiate a grammar.Grammar instance
    grammar = Grammar()

    def convert(grammar: Grammar, node: RawNode) -> Union[Leaf, Node]:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    # Instantiate a Parser instance, passing the grammar and
    # converter.
    parser = Parser(grammar, convert)

    # The parser is not ready yet for parsing; you must call the
    # setup() method to get it started.
    start = grammar.start
    parser.setup(start)

    # Parsing by calling addtoken with the appropriate parameters until addtoken returns True.
    assert parser.addtoken(1, "a", (1, 1))

# Generated at 2022-06-21 10:11:33.791364
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def get_method(target, name):
        return getattr(target, name)

    def setUp(self):
        self.p = Parser(self.gp)

    gp = Grammar()
    gp.symbol2number('A')
    gp.symbol2number('B')
    gp.add_production('A', 0, 'B C')
    gp.add_production('B', 0, 'B T')
    gp.add_production('B', 1, 'T')
    gp.add_production('C', 0, 'T')
    gp.add_production('T', 0, '"a"')
    gp.add_production('T', 1, '"b"')
    gp.compute_nullability()
    gp.compute_first_sets()
    gp.compute_follow_sets()


# Generated at 2022-06-21 10:11:44.509817
# Unit test for method pop of class Parser
def test_Parser_pop():
    t = token
    k = token.NT

# Generated at 2022-06-21 10:11:50.767498
# Unit test for method setup of class Parser
def test_Parser_setup():
    parser = Parser(Grammar())
    parser.setup()

# Generated at 2022-06-21 10:11:59.015857
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from blib2to3.pgen2.tokenize import tokenize_lines

    p = Parser(grammar.python_grammar)
    p.setup()
    for tok in tokenize_lines("import sys"):
        if p.addtoken(*tok):
            break
    assert p.rootnode.children == [
        Leaf(type=3, value="import", context=(1, 0)),
        Leaf(type=1, value="sys", context=(1, 7)),
    ]

# Generated at 2022-06-21 10:12:06.811428
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Same as built-in class, just to make sure.
    # This test is not part of the core unit test.
    p = Parser(Grammar())
    p.stack = []
    p.stack = [[1,2,3], [4,5,6], [7,8,9]]
    p.pop()
    assert p.stack == [[1,2,3], [4,5,6]]
    p.stack = [[1,2,3]]
    p.pop()
    assert p.stack == []


if __name__ == "__main__":
    import sys
    import doctest

    doctest.testmod()
    sys.exit(0)

# Generated at 2022-06-21 10:12:08.589661
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Test method shift of class Parser
    # XXX

    return lambda: None

# Generated at 2022-06-21 10:12:20.895200
# Unit test for function lam_sub
def test_lam_sub():
    import unittest
    from test.support import captured_stdout

    class TestLamSub(unittest.TestCase):
        def setUp(self) -> None:
            self.grammar = Grammar()

            # Call TableDrivenParser.add_dfa() to add a state machine to the
            # grammar.  The machine is encoded as a sequence of rows.  Each
            # row is a sequence of arcs, each arc being a (label, target)
            # pair.  The label must be a terminal symbol (integer), the target
            # must be a state number (integer).  The machine must be acyclic
            # (i.e. no state may be the target of itself).  Since the machine
            # is acyclic, there must be precisely one arc for each terminal
            # symbol.  The first row is initial.

# Generated at 2022-06-21 10:12:31.989265
# Unit test for method pop of class Parser
def test_Parser_pop():
    import textwrap
    from pprint import pformat
    import unittest
    import blib2to3.pgen2.pgen as pgen
    import blib2to3.pgen2.driver as driver

    class PopTest(unittest.TestCase):
        def parse(self, grammar, source) -> None:
            grammar = pgen.read_grammar("2to3/Grammar.txt")
            driver = driver.Driver("2to3/Grammar.txt", "2to3/PatternGrammar.txt")
            driver.parse_tokens(textwrap.dedent(source).split("\n"))
            parser = Parser(grammar)
            parser.setup()

# Generated at 2022-06-21 10:12:38.437474
# Unit test for method push of class Parser
def test_Parser_push():
    import unittest
    from ..pgen2 import parse

    class TestParser(unittest.TestCase):
        def test_Parser_push(self):
            g = parse("Grammar.txt")
            p = Parser(g)
            p.setup()
            p.push(1, 2, 3, 4)
            self.assertEqual(p.stack, [(2, 0, (1, None, 4, []))])

    unittest.main()

# Generated at 2022-06-21 10:12:46.415953
# Unit test for function lam_sub
def test_lam_sub():
    def cvt(grammar: Grammar, n: RawNode) -> Union[Node, Leaf]:
        return Node(
            type=n[0],
            children=n[3],
            context=n[2],
            value=n[1],
            prefix=f"({n[0]} ->)",
        )

    from blib2to3.pgen2 import tokenize

    # The test file contains only the following lines:
    # class Foo: pass
    # def f(): pass
    #
    # f = Foo()
    # The raw tokens produced by tokenize look like this:
    # [
    #     (token.NAME, 'class'),
    #     (token.NAME, 'Foo'),
    #     (token.COLON, ':'),
    #     (token.NAME, 'pass'),
    #    

# Generated at 2022-06-21 10:12:57.773309
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar
    from . import driver
    import os

    p = Parser(grammar.pgen.grammar)
    p.setup()
    t = driver.Driver(grammar.pgen.grammar, convert=None, log=None)
    t.set_filename("<string>")
    try:
        t.parse_tokens("""
        # Some Python code
        def test_function(param):
            return param + 1
        """)
        for tok in t.tokenize():
            p.addtoken(tok.type, tok.string, tok.context)
    except ParseError as err:
        print(err.msg)
        print(err.type, err.value)
        print(err.context)
        raise err


# Generated at 2022-06-21 10:13:09.273156
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, tokenize

    grammar = grammar.grammar
    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    def get_ilabel(input: str) -> int:
        ilabel, ignore, offset, lineno, line = next(tokenize.generate_tokens(g, input))
        return p.classify(ilabel, None, None)
    assert get_ilabel("if") == grammar.keywords["if"]
    assert get_ilabel("if_") == grammar.keywords["if_"]
    assert get_ilabel("_if") == grammar.keywords["_if"]
    assert get_ilabel("_if_") == grammar.keywords["_if_"]

# Generated at 2022-06-21 10:13:25.226893
# Unit test for constructor of class Parser
def test_Parser():
    # Test the Parser constructor
    p = Parser(Grammar([None, ['a', 'b'], None, {'a':[('aa','a','a',[0])],
                                                 'b':[('bb','b','b',[])]}, {}, {}, {}, {}], start=1))
    assert p.grammar.dfas == {1: ([[(0, 1)], [(2, 2)]], set()),
                              'a': ([[(1, 1), (3, 1)], [(3, 2)]], set()),
                              'b': ([[(0, 1)], [(0, 2)]], set())}

# Unit tests for the two methods of the class Parser

# Generated at 2022-06-21 10:13:29.962439
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError("msg", 1, "val", (2, 3))
    assert p.type == 1
    assert p.value == "val"
    assert p.context == (2, 3)
    assert p.msg == "msg"
    assert str(p) == "msg: type=1, value='val', context=(2, 3)"

# Generated at 2022-06-21 10:13:37.763314
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Helper to build test cases
    def tokens_to_dfa_nodes(tokens: Sequence[int]) -> Union[Node, Leaf]:
        docs = [""]
        context = Context(docs, 0)
        p = Parser(Grammar(token, pgen.dfa, pgen.grammar, pgen.symbol2number))
        p.setup()
        for t in tokens:
            p.addtoken(t, token.tok_name[t], context)
        return p.rootnode, p.used_names

    from . import pgen


# Generated at 2022-06-21 10:13:45.399519
# Unit test for function lam_sub
def test_lam_sub():
    class FakeGrammar:
        def __init__(self):
            self.symbol2label = {}
            self.dfas = {}
    fg = FakeGrammar()
    n = lam_sub(fg, (0, None, None, [1, 2]))
    assert n.type == 0
    assert n[0] == 1
    assert n[1] == 2
    assert n.prefix == ""
    assert n.context is None

# Generated at 2022-06-21 10:13:56.624015
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import os
    import sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "test"))

    from blib2to3.tests.patcompile import PatCompileTestCase
    from blib2to3.pgen2.tokenize import generate_tokens
    from pytree import Leaf, Node, type_repr

    class Blib2to3Patcompile(PatCompileTestCase):

        def runTest(self):
            # Parse the pattern, raising an exception if it doesn't work
            self.pat = self.pat_compile(self.pat)
            if self.pat is not None:
                self.pat = self.pat.totuple()
            assert self.pat_compare(self.pat, self.result)

# Generated at 2022-06-21 10:14:08.721664
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2.parse import parse_grammar
    from blib2to3.pgen2.pgen import generate_grammar

    filename = "../Grammar.txt"
    modname = "blib2to3.pgen2.parser"

    g = parse_grammar(filename, "exec")
    generate_grammar(modname, g)

    from . import grammar

    p = Parser(grammar, lam_sub)
    p.setup()
    p.addtoken(token.NEWLINE, '\n', (1, 0))
    p.addtoken(token.ENDMARKER, '', (2, 0))
    t = p.rootnode

    # print("t =", t)
    assert t == (257, None, None, [])

# Generated at 2022-06-21 10:14:12.882877
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError('test', token.RIGHTSHIFT, '>>', (1, (1, 2), (3, 4)))
    e.msg, e.type, e.value, e.context = \
        'test', token.RIGHTSHIFT, '>>', (1, (1, 2), (3, 4))


# Generated at 2022-06-21 10:14:17.094674
# Unit test for constructor of class Parser
def test_Parser():
    from support.test_parser import Parser as Tester
    from support.test_parser import ParserError
    n = Tester(test_Parser)
    assert n.grammar is test_Parser
    assert n.convert is None
    # Test call to setup()
    try:
        n.setup()
    except AttributeError as e:
        assert "__init__()" in str(e)
        return
    raise RuntimeError("shouldn't get here")

# Generated at 2022-06-21 10:14:26.926876
# Unit test for method push of class Parser
def test_Parser_push():
    import w_grammar
    w_grammar.init()
    wp = Parser(w_grammar.w_grammar)
    wp.setup()
    leaf = Leaf(1, "1", None)
    raw_node = (2, None, None, [leaf] )
    wp.convert = lambda grammar, node: node
    wp.push(2, (([(0, 1)], {1: {0}}), {1: 2}), 0, None)
    node = wp.stack[-1][2]
    assert node[0] == 2
    assert node[1] is None
    assert node[2] is None
    assert node[3] == [leaf]

# Generated at 2022-06-21 10:14:29.491929
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("bad token", token.DOT, ".", None)
    except ParseError:
        pass

# Generated at 2022-06-21 10:14:38.944773
# Unit test for method shift of class Parser
def test_Parser_shift():
    import pprint
    grammar = Grammar(
        grammar_file='./Test/pgen-test/grammar.txt',
        start='single_input',
        keywords='keywords.txt',
        tokens='tokens.txt',
        dfas='dfas.txt',
    )
    parser = Parser(grammar)
    parser.setup()
    parser.shift(0, 1, 0, None)


# Generated at 2022-06-21 10:14:51.169059
# Unit test for constructor of class Parser
def test_Parser():
    import pprint

    class MyToken:
        def __init__(self, *args):
            self.type, self.value, self.lineno, self.lexpos = args

    def print_tree(node, indent=0):
        if node is None:
            return
        print("%s%s" % (" " * indent, node))
        for child in node:
            print_tree(child, indent + 2)

    from . import grammar

    def myparse(s, grammar, convert=None):
        from . import driver

        p = Parser(grammar)
        p.setup()
        for t in driver.tokenize(s):
            if p.addtoken(t.type, t.value, t.context):
                break
        else:
            raise RuntimeError("incomplete input")

# Generated at 2022-06-21 10:15:00.898609
# Unit test for method classify of class Parser
def test_Parser_classify():
    import pgen
    import sys
    import io

    # Create a parser for the Python grammar
    grammar = pgen.parser.pgen(sys.stdin)
    p = Parser(grammar)

    # Prepare for parsing
    p.setup()

    # Introduce the tokens to parse
    tokens = [
        (token.STRING, "'hello'", (1, 0)),
        (token.NAME, "print", (1, 8)),
        (token.NEWLINE, "\n", (1, 12)),
    ]

    # Parse the tokens
    for type, value, context in tokens:
        p.addtoken(type, value, context)

    # Test the parser
    name = "print"
    ilabel = p.classify(token.NAME, name, context)
    print(ilabel)


# Unit

# Generated at 2022-06-21 10:15:03.549309
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Trivial test (just check that this compiles)
    p = Parser(None, None)
    p.shift(0, 0, 0, None)


# Generated at 2022-06-21 10:15:04.162284
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    pass

# Generated at 2022-06-21 10:15:11.431629
# Unit test for function lam_sub
def test_lam_sub():
    class MockGrammar(object):
        symbol2label = {}

    gram = MockGrammar()
    node = (1, 2, 3, 4)
    res = lam_sub(gram, node)
    assert res[0] == node[0] and res[1] == node[1] and res[2] == node[2] and res[
        -1
    ] == node[-1]



# Generated at 2022-06-21 10:15:21.911456
# Unit test for method setup of class Parser
def test_Parser_setup():
    import blib2to3.pgen2.pgen
    arg = blib2to3.pgen2.pgen.main()

# Generated at 2022-06-21 10:15:24.488580
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(None)
    p.setup()



# Generated at 2022-06-21 10:15:34.709417
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import tokenize_rt

    # Load a grammar

    with open("Python.grammar", "rb") as pygrammar:
        g = grammar.Grammar(pygrammar)

    # Tokenize a file

    with open("test.py", "r", encoding='utf-8') as testfile:
        test = tokenize_rt.tokenize_rt(testfile.readline)

    # Prepare to parse

    p = Parser(g)
    p.setup()

    # Parse


# Generated at 2022-06-21 10:15:46.789248
# Unit test for method push of class Parser
def test_Parser_push():
    """Unit test for method push of class Parser"""
    import pickle
    import io
    import blib2to3.pgen2.tokenize as tokenize


# Generated at 2022-06-21 10:15:57.088896
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("msg", token.NUMBER, '3', (1, 0))
    assert e.msg == "msg"
    assert e.type == token.NUMBER
    assert e.value == '3'
    assert e.context == (1, 0)
    assert str(e) == "msg: type='NUMBER', value='3', context=(1, 0)"

# Generated at 2022-06-21 10:15:59.560100
# Unit test for method setup of class Parser
def test_Parser_setup():
    """
    class Parser:
        def setup(self, start=None) -> None:
            ...
    """
    pass



# Generated at 2022-06-21 10:16:11.914815
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver

    class DummyGrammar:

        start = 256
        tokens = {4: 1, 5: 2}
        keywords = {}
        labels = [(1, (4, "a")), (2, (5, "b"))]
        dfas = {256: ([[(1, 1), (2, 2)], [(3, 1), (4, 3)], [(0, 3), (3, 3)]], {2: 2})}

    class DummyConverter:

        def __init__(self):
            self.called = 0

        def __call__(self, g: Any, n: RawNode) -> NL:
            self.called += 1
            assert g is dummygrammar

# Generated at 2022-06-21 10:16:19.201685
# Unit test for function lam_sub
def test_lam_sub():
    from .grammar import Grammar

    class Type(object):
        """Class just to test type() is properly handled."""

    gr = Grammar(start=0, states=[[[(0, 0)], [(1, 0)]]], labels=[(3, None)], dfas=None)
    p = Parser(grammar=gr)
    ret = lam_sub(gr, (0, None, None, [(1, "hello", None, None)]))
    assert ret.type == 0
    assert ret.children[0].type == 1
    assert ret.children[0].value == "hello"
    assert ret is not ret.children[0]
    p.setup()
    assert p.stack == [(None, 0, (0, None, None, []))]
    p.shift(3, "hello", 1, None)

# Generated at 2022-06-21 10:16:21.208517
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """The method addtoken of class Parser needs to be tested"""
    print("The method addtoken of class Parser needs to be tested")


# Generated at 2022-06-21 10:16:31.184070
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import parsetok

    grammar = Grammar(parsetok.parse1, parsetok.dfas)
    p = Parser(grammar)
    p.setup()
    p.addtoken(1, "bob", None)
    p.addtoken(2, None, None)
    p.addtoken(1, "foo", None)
    p.addtoken(2, None, None)
    p.addtoken(2, None, None)
    p.addtoken(1, "boo", None)
    p.addtoken(2, None, None)
    p.addtoken(2, None, None)
    assert len(p.stack) == 1
    p.pop()
    assert len(p.stack) == 0


# Generated at 2022-06-21 10:16:43.286453
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, token

    p = Parser(grammar)
    dfa = p.grammar.dfas['suite']
    dfa_state = 0
    node = (grammar.syms['suite'], None, None, [])
    p.stack = [(dfa, dfa_state, node)]

    dfa = p.grammar.dfas['stmt']
    dfa_state = 0
    node = (grammar.syms['stmt'], None, None, [])
    p.stack.append((dfa, dfa_state, node))
    p.pop()

    # not enough input
    dfa = p.grammar.dfas['suite']
    dfa_state = 2
    node = (grammar.syms['suite'], None, None, [])

# Generated at 2022-06-21 10:16:54.810666
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import python_grammar, tokenize

    # Create dummy grammar with a read-only start symbol (PRINT_STMT)
    dummy_grammar = python_grammar.copy()
    dummy_grammar.start = "PRINT_STMT"
    # Initialize a Parser
    p = Parser(dummy_grammar)
    # Do a first setup
    p.setup()

    # Create a sequence of dummy tokens
    token_list = [
        ("NAME", "print"),
        ("LPAR", "("),
        ("NAME", "hello"),
        ("COMMA", ","),
        ("NAME", "world"),
        ("RPAR", ")"),
        ("NEWLINE", "\n"),
    ]
    # Turn the list of tokens into a generator

# Generated at 2022-06-21 10:17:04.893444
# Unit test for constructor of class Parser
def test_Parser():
    from .tokenize import generate_tokens, untokenize, COMMENT, ENCODING
    from . import grammar, future_builtins
    from .pytree import Leaf, Node, type_repr

    g = grammar.grammar
    fb = future_builtins.future_builtins
    p = Parser(g)

    def gtokens(s):
        return generate_tokens(iter(s.splitlines(keepends=True)).next)

    def test_type(t):
        p.setup()

# Generated at 2022-06-21 10:17:16.041378
# Unit test for method push of class Parser
def test_Parser_push():
    # Run a kind of simple unit test by parsing a string
    import re
    from .token import UMINUS
    from . import grammar

    # Build a parser
    p = Parser(grammar.grammar)

    # Build a tokenizer
    NUMBER = token.NUMBER
    NEWLINE = token.NEWLINE
    NAME = token.NAME
    opmap = {"+": token.PLUS, "-": token.MINUS, "*": token.STAR, "/": token.SLASH, "%": token.PERCENT}
    rx = re.compile(r"""
            (\d+)                                                         |
            ([-+*/%])                                                     |
            (\n)                                                          |
            (\w+)
            """, re.VERBOSE)
    from .driver import SourceLine, Token, SourceToken
   

# Generated at 2022-06-21 10:17:28.896989
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    g = grammar.Grammar()
    p = Parser(g)
    p.setup()

# Generated at 2022-06-21 10:17:41.080194
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar. Grammar()
    for s in """
        S: '#' '!' NAME NEWLINE
        S: ENDMARKER
        S: error
        """.split("\n"):
        g.add_production(s)

    def lam_sub(grammar, node):
        assert node[3] is not None
        return Node(type = node[0], children = node[3], context = node[2])

    p = Parser(g, lam_sub)
    p.setup()
    if p.addtoken(token.NAME, "Spam", (1, 0)):
        raise Exception("addtoken returns True")
    if not p.addtoken(token.ENDMARKER, "", (1, 0)):
        raise Exception("addtoken returns False")

# Generated at 2022-06-21 10:17:52.079367
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .token import DEDENT
    test_grammar=Grammar("file")
    test_grammar.tokens={DEDENT: 0}
    test_stack=[(None, 0, (None, None, None, None))]
    test_context=None
    test_parser=Parser(test_grammar)
    try:
        test_parser.stack=test_stack
        test_parser.shift(DEDENT, None, None, test_context)
    except ValueError as e:
        raise ValueError(
            f"Unexpected ValueError raised by method shift of class Parser: {e}"
        )

# Generated at 2022-06-21 10:17:54.382491
# Unit test for constructor of class Parser
def test_Parser():
    grammar = Grammar()
    parser = Parser(grammar)
    assert isinstance(parser, Parser)

    assert parser.grammar is grammar
    assert parser.convert is lam_sub


# Generated at 2022-06-21 10:17:56.216191
# Unit test for method push of class Parser
def test_Parser_push():
    dummy: Union[None, Sequence[Set[Any]]] = None
    if False:
        dummy = [(None, None, None, [])]

# Generated at 2022-06-21 10:18:07.728655
# Unit test for method push of class Parser
def test_Parser_push():
    class Grammar:
        dfas = {
            10: ([[(11, 0)], [(0, 0), (0, 1)], [(0, 1), (12, 2)], [(0, 2)]], {0: 0, 1: 1}),
            11: ([[(13, 0)], [(0, 0)]], {0: 0, 1: 1}),
            12: ([[(14, 0)], [(0, 0)]], {0: 0, 1: 1}),
            13: ([[(0, 0), (0, 1)]], {0: 0}),
            14: ([[(0, 0), (0, 1)]], {0: 0}),
        }
        labels = {0: (10, None)}
    grammar = Grammar()
    parser = Parser(grammar)

# Generated at 2022-06-21 10:18:14.921143
# Unit test for constructor of class Parser
def test_Parser():
    # Create a simple grammar
    g = Grammar(start=256)
    g.dfas = {256: ([[(1, 1)], [(2, 0)], [(0, 2)]], set())}
    g.labels = [(257, "a"), (258, "b")]
    g.keywords = {}
    g.tokens = {257: 0, 258: 1}

    # Create a simple converter
    def conv(g: Grammar, t: RawNode) -> Optional[Node]:
        # Because this is the only node type, it is not strictly
        # necessary to pass the Grammar argument, but we do it here.
        # Also, this converter accepts all nodes.
        type, value, context, children = t
        return Node(type=type, children=children)

    # Parse a simple sequence
   

# Generated at 2022-06-21 10:18:20.496857
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup(start=1)  # Call to setup() is required
    assert p.stack == [(g.dfas[1], 0, (1, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Unit test

# Generated at 2022-06-21 10:18:30.398948
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver
    g = driver.load_grammar("Grammar.txt")
    p = Parser(g)
    assert p.classify(token.NAME, "print", None) == 1
    assert p.classify(token.NEWLINE, "\n", None) == 12
    assert p.classify(token.INDENT, "", None) == 13
    assert p.classify(token.DEDENT, "", None) == 14
    assert p.classify(token.NAME, "printer", None) == 3
    try:
        p.classify(token.STRING, "x", None)
    except ParseError:
        pass
    else:
        assert False, "should raise ParseError"

# Generated at 2022-06-21 10:18:40.988061
# Unit test for method pop of class Parser
def test_Parser_pop():
    class MockGrammar:
        def __init__(self, mock_results: Text, mock_labels: Sequence[Text]):
            self.results = mock_results
            self.labels = mock_labels

    class MockStackEntry:
        def __init__(self, mock_dfa: Any, mock_state: Any, mock_node: Any):
            self.dfa = mock_dfa
            self.state = mock_state
            self.node = mock_node

    class MockNode(Node):
        def __init__(
            self, mock_type: Any, mock_value: Any, mock_context: Any, mock_children: Any
        ):
            self.type = mock_type
            self.value = mock_value
            self.context = mock_context
            self.children = mock_children

   

# Generated at 2022-06-21 10:19:08.945732
# Unit test for method push of class Parser
def test_Parser_push():
    # create class
    inst = Parser(Grammar())
    inst.push(1, 2, 3, 4)
    assert inst.stack == [(2, 0, (1, None, 4, []))]
    # now push
    inst.push(1, 2, 3, 4)
    assert inst.stack == [(2, 0, (1, None, 4, [])), (2, 0, (1, None, 4, []))]


# Generated at 2022-06-21 10:19:14.151578
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Variables for the arguments of method shift
    type = token.NAME
    value = 'hello'
    newstate = 0
    context = Context('test')

    stack = [(DFAS, 1, RawNode)]
    stack[-1] = (DFAS, newstate, stack[-1])
    stack[-1][2][-1] = [RawNode]
    stack[-1][2][-1].append(type)

# Generated at 2022-06-21 10:19:18.647379
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("msg", 123, "val", (0, 1))
    assert e.msg == "msg"
    assert e.type == 123
    assert e.value == "val"
    assert e.context == (0, 1)

# Generated at 2022-06-21 10:19:29.477113
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    from . import driver
    from . import pytree
    from . import pygram

    import _ast
    import sys

    g = grammar.Grammar(grammar.DEFAULT_GRAMMAR)
    driver.load_grammar(g)

    c = pytree.convert
    p = Parser(g, c)
    p.setup()
    p.addtoken(pygram.tokens.NAME, "a", (1, 0))
    p.addtoken(pygram.tokens.PLUS, "+", (1, 1))
    p.addtoken(pygram.tokens.NAME, "b", (1, 2))
    p.addtoken(pygram.tokens.PLUS, "+", (1, 3))

# Generated at 2022-06-21 10:19:33.041692
# Unit test for constructor of class ParseError
def test_ParseError():
    # create a ParseError object and make sure the constructor sets
    # everything up correctly
    e = ParseError("foo", 1, "a", None)
    assert e.msg == "foo"
    assert e.type == 1
    assert e.value == "a"
    assert e.context is None



# Generated at 2022-06-21 10:19:39.712222
# Unit test for function lam_sub
def test_lam_sub():
    newnode = ("test", None, None, ["child"])
    assert lam_sub(None, newnode) == Node(type="test", children=["child"])
    newnode2 = ("test2", None, "test_context", ["child2"])
    assert lam_sub(None, newnode2) == Node(type="test2", children=["child2"], context="test_context")
    newnode3 = ("test3", None, None, None)
    assert lam_sub(None, newnode3) is None
    newnode4 = (token.ENDMARKER, None, None, None)
    assert lam_sub(None, newnode4) is None


if __name__ == "__main__":
    import driver
    driver.driver()

# Generated at 2022-06-21 10:19:43.364997
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver

    # This method sets the parameter start to None, in case it is not defined
    # The start symbol equals the grammar start
    grammar = driver.build_parser("")
    p = Parser(grammar)
    p.setup()



# Generated at 2022-06-21 10:19:50.777948
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("test", token.STRING, "", None)
    assert pe.msg == "test"
    assert pe.type == token.STRING
    assert pe.value == ""
    assert pe.context is None
    pe = ParseError("test", None, None, (1, 2))
    assert pe.msg == "test"
    assert pe.type is None
    assert pe.value is None
    assert pe.context == (1, 2)
    try:
        raise pe
    except ParseError:
        pass

# Generated at 2022-06-21 10:19:59.968672
# Unit test for method setup of class Parser
def test_Parser_setup():
    """Unit tests of the Parser.setup() method."""
    import unittest

    class TestSetup(unittest.TestCase):

        def test_no_start(self):
            "Parser.setup() without argument."
            from . import grammar
            p = Parser(grammar.parse_grammar("Grammar/Grammar"))
            p.setup()
            self.assertEqual(p.stack, [(grammar.dfas['file_input'], 0, (257, None, None, []))])
            self.assertEqual(p.rootnode, None)

        def test_w_start(self):
            "Parser.setup() with an argument."
            from . import grammar
            p = Parser(grammar.parse_grammar("Grammar/Grammar"))

# Generated at 2022-06-21 10:20:08.618934
# Unit test for method pop of class Parser
def test_Parser_pop():
    class MockRawNode:
        def __init__(self):
            self.children = [1, 2]
    grammar = MockGrammar()
    parser = Parser(grammar)
    parser.stack = [(1, 1, (1, 2, 3, MockRawNode())), (2, 2, (4, 5, 6, None))]
    parser.pop()
    assert parser.stack == [(1, 1, (1, 2, 3, [1, 2]))]
    assert parser.rootnode.children == [1, 2]
