

# Generated at 2022-06-21 10:10:27.289072
# Unit test for method push of class Parser
def test_Parser_push():
    class GrammarTest(Grammar):
        _dfas: Tuple[DFAS, ...] = (([[(1, 0)]], {0: {2}}), ([[(1, 1)]], {1: {3}}))
        _labels = [(2, "a"), (3, "b")]
        _accepting = [0]
        _applied = {0: {0: "ab"} }
        _default = [{}]
        _keywords = {}
        _error_tokens = ()
        _tokens = {25: 2, 26: 3}

    class ConvertTest:
        def __init__(self) -> None:
            self.nodes = []

        def __call__(self, grammar, node):
            self.nodes.append(node)
            return None


# Generated at 2022-06-21 10:10:37.911028
# Unit test for method classify of class Parser
def test_Parser_classify():
    class Parser(blib2to3.pgen2.parser.Parser):
        # Only test classify
        def __init__(self, grammar):
            blib2to3.pgen2.parser.Parser.__init__(self, grammar)
    grammar = blib2to3.pgen2.grammar.Grammar()
    p = Parser(grammar)
    g = grammar

# Generated at 2022-06-21 10:10:50.538480
# Unit test for method classify of class Parser
def test_Parser_classify():
    import sys
    import os.path
    import blib2to3.pgen2.convert
    import blib2to3.pgen2.driver
    grammardir = blib2to3.pgen2.convert.pickle_grammar("Grammar.txt")
    grammar = blib2to3.pgen2.driver.load_grammar(grammardir)
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NAME, 'x', (0,0))
    parser.addtoken(token.EQUAL,None,(0,0))
    parser.addtoken(token.NAME, 'x', (0,0))
    parser.addtoken(token.NEWLINE,None,(0,0))

# Generated at 2022-06-21 10:10:54.517546
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from pprint import pprint

    def test(start):
        p = Parser(grammar)
        p.setup(start)
        print('start=%-7s %s' % (start, p))

    # Test that the argument is a nonterminal
    try:
        test(token.NAME)
    except AssertionError:
        pass
    else:
        raise AssertionError('expected AssertionError')
    # Test that the argument is a known nonterminal
    try:
        test('_unknown_nonterminal_')
    except AssertionError:
        pass
    else:
        raise AssertionError('expected AssertionError')
    # Test that the argument is a non-empty nonterminal

# Generated at 2022-06-21 10:10:59.841218
# Unit test for method pop of class Parser
def test_Parser_pop():
    x = Parser(Grammar(), None)
    x.stack = [('dfa', 0, 'node')]
    x.pop()
    assert not x.stack



# Generated at 2022-06-21 10:11:04.939628
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2 import tokenize, grammar
    from blib2to3.pgen2.pgen import PgenParser
    from io import StringIO
    from unittest import TestCase

    class TestParserClassify(TestCase):
        def test_classify(self):
            grammar_file = PgenParser.load_grammar(grammar)
            tokens = tokenize.generate_tokens(StringIO("def").__next__)
            names = ("NAME", "NAME", "NAME", "NAME", "NAME")
            values = ("a", "ab", "abc", "abcdef", "abcdefg")
            for name, value in zip(names, values):
                tok = next(tokens)
                self.assertEqual(name, tok.type)
                self.assertE

# Generated at 2022-06-21 10:11:16.596627
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver

    # class Parser
    # def classify(self, type, value, context)
    def classify_test1():
        p = driver.Parser(None)
        p.grammar.labels = {1: (1, None), 2: (token.NAME, "NAME"),
            3: (token.STRING, "STRING")}
        p.grammar.tokens = {token.NAME: 2, token.STRING: 3}
        p.grammar.keywords = {'and': 1}
        result = p.classify(token.NAME, "and", None)
        expected = 1
        assert result == expected, \
            "test_Parser_classify.classify_test1()"
    classify_test1()


# Generated at 2022-06-21 10:11:25.328358
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar(1))
    p.setup()
    p.shift(token.ENDMARKER, "", 0)
    assert p.stack[0][-1][-1] == []
    p.shift(token.NAME, "ahoj", 0)
    assert p.stack[0][-1][-1] == ["ahoj"]
    p.shift(token.NAME, "ahoj", 0)
    assert p.stack[0][-1][-1] == ["ahoj", "ahoj"]

# Generated at 2022-06-21 10:11:27.372893
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar([], [], [], 0))
    p.setup()


# Generated at 2022-06-21 10:11:39.237838
# Unit test for method push of class Parser
def test_Parser_push():
    """Testing method push of class Parser"""
    stmt = Grammar()
    stmt.symbols = {
        "<test1>": 0,
        "<basestmt>": 1,
        "<keyword>": 2,
        "<stmt>": 3,
        "<endmarker>": 4,
    }
    stmt.dfas: Dict[int, DFAS] = {}

# Generated at 2022-06-21 10:11:48.400620
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("foo", 3, "bar", None)
    assert exc.args == ("foo", 3, "bar", None)
    assert exc.msg == "foo"
    assert exc.type == 3
    assert exc.value == "bar"
    assert exc.context is None

# Tests for class Parser

# Generated at 2022-06-21 10:11:49.547858
# Unit test for method setup of class Parser
def test_Parser_setup():
    pass



# Generated at 2022-06-21 10:12:01.558598
# Unit test for method push of class Parser
def test_Parser_push():
    from pgen2.pgen import generate_grammar
    from blib2to3 import pygram
    grammar = generate_grammar(pygram.python_grammar)
    p = Parser(grammar)
    p.setup()
    assert p.stack == [(grammar.dfas[grammar.start], 0, (grammar.start, None, None, []))]
    p.push(257, grammar.dfas[257], 0, None)
    assert p.stack == [
        (grammar.dfas[grammar.start], 0, (grammar.start, None, None, [])),
        (grammar.dfas[257], 0, (257, None, None, [])),
    ]
    p.push(258, grammar.dfas[258], 0, None)

# Generated at 2022-06-21 10:12:06.369190
# Unit test for method setup of class Parser
def test_Parser_setup():
    class A: pass
    x = A()
    setattr(x,'thing_one','un')
    setattr(x,'thing_two','deux')
    setattr(x,'thing_three','trois')
    assert getattr(x,'thing_one') == 'un'
    assert getattr(x,'thing_two') == 'deux'
    assert getattr(x,'thing_three') == 'trois'



# Generated at 2022-06-21 10:12:18.092461
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2.token import Token
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.dfa import DFA

    class MockGrammar(Grammar):
        pass

    class MockDFA(DFA):
        pass

    grammar = MockGrammar()
    dfa = MockDFA()
    token = Token(token="token", lineno=1)

    parser = Parser(grammar)
    assert parser.stack == []
    parser.push(token, dfa, 1, Context(1, 1))
    assert len(parser.stack) == 2
    dfa, state, node = parser.stack.pop()
    assert dfa == dfa
    assert state == 1

# Generated at 2022-06-21 10:12:30.573314
# Unit test for function lam_sub
def test_lam_sub():
    from . import pgen2

    grammar = pgen2.driver.load_grammar(2)
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NAME, "print", (1, 0))
    parser.addtoken(token.LPAR, "(", (1, 5))
    parser.addtoken(token.STRING, "'Hello world!'", (1, 6))
    parser.addtoken(token.RPAR, ")", (1, 20))
    assert parser.rootnode[0].type == grammar.start
    assert parser.rootnode[0].children[0].type == token.NAME
    assert parser.rootnode[0].children[0].value == "print"
    assert parser.rootnode[0].children[1].type == token.LPAR
    assert parser.rootnode

# Generated at 2022-06-21 10:12:37.180510
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Syntax Error", 0, "test", (0, 0))
    except ParseError as e:
        assert e.msg == "Syntax Error"
        assert e.type == 0
        assert e.value == "test"
        assert e.context == (0, 0)
    else:
        assert False, "ParseError constructor failed"

# Generated at 2022-06-21 10:12:46.556199
# Unit test for method push of class Parser
def test_Parser_push():
    # It seems as though this is the way to test a class. It appears
    # to run the code in the class.
    from .grammar import Grammar
    from .tokenize import tokenize_wrapper
    from .token import NAME

    g = Grammar()

    # Setup some fake data for the DFA. This gives values for the
    # variables.
    dfa = []
    dfa.append([[(4, 5), (0, 0)]])
    dfa.append([[(4, 5), (0, 0)]])
    dfa.append([[(4, 5), (0, 0)]])
    dfa.append([[(4, 5), (0, 0)]])
    dfa.append([[(4, 5), (0, 0)]])
    g.dfas[NAME]

# Generated at 2022-06-21 10:12:49.498517
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("msg", token.NAME, "val", "cx")
    assert str(err) == "msg: type=token.NAME, value='val', context='cx'"

# Generated at 2022-06-21 10:12:58.986715
# Unit test for method pop of class Parser
def test_Parser_pop():
    g = Grammar()
    parser = Parser(g, convert=None)
    parser.stack = [(([[(1, 2)]], {1: 1, 2: 2}), 0, (1, None, None, [])),
                    (([[(1, 2)]], {1: 1, 2: 2}), 0, (1, None, None, []))]
    parser.pop()
    assert parser.stack == [(([[(1, 2)]], {1: 1, 2: 2}), 0, (1, None, None, [])),
                            (([[(1, 2)]], {1: 1, 2: 2}), 0, (1, None, None, []))]

# Generated at 2022-06-21 10:13:08.424526
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    import blib2to3.pgen2.grammar

    parser = Parser(blib2to3.pgen2.grammar)
    parser.setup()

    parser.setup()
    parser.setup(1)



# Generated at 2022-06-21 10:13:16.205621
# Unit test for method classify of class Parser

# Generated at 2022-06-21 10:13:17.226034
# Unit test for method setup of class Parser
def test_Parser_setup():
    # Intentionally empty
    return None

# Generated at 2022-06-21 10:13:27.170642
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(lam_sub)
    p.stack = [(None, 0, (0, "", "", []))]
    p.shift(token.EQUAL, "=", 5, "")
    assert p.stack == [(None, 5, (0, "", "", [(token.EQUAL, "=", "", None)]))]
    p.stack = [(None, 0, (0, "", "", []))]
    p.shift(token.EQUAL, "=", 5, "")
    assert p.stack == [(None, 5, (0, "", "", [(token.EQUAL, "=", "", None)]))]

# Generated at 2022-06-21 10:13:36.102448
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def check_addtoken(
        self,
        tok: Tuple[int, Optional[Text], Context],
        next_states: Sequence[Tuple[Optional[int], Optional[int], Optional[int]]],
    ) -> None:
        type, value, context = tok
        for next_state, next_ilabel, next_type in next_states:
            if next_state is not None:
                stackentry = self.stack[-1]
                self.assertEqual(stackentry[1], next_state)
            if next_ilabel is not None:
                ilabel = self.classify(type, value, context)
                self.assertEqual(ilabel, next_ilabel)
            if next_type is not None:
                rawnode = (next_type, value, context, None)
                new

# Generated at 2022-06-21 10:13:48.733058
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pytest
    from . import grammar, tokenize
    g = grammar.Grammar(tokenize.pseudoparser())
    class _Convert(object):
        """Convert a node with a single leaf child from a to b.

        Raise an error if the node has more than one child.

        """

        def __init__(self) -> None:
            self.msg = ""

        def __call__(self, grammar: Grammar, node: RawNode) -> Leaf:
            if node[0] == g.symbol2number["expr"]:
                assert node[3] is not None
                child = node[3][0]

# Generated at 2022-06-21 10:13:58.817275
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2 import grammars
    g = grammars.SyntaxGrammar()

# Generated at 2022-06-21 10:14:04.547123
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError(msg='foo', type=1, value='spam', context=('huey', 'foo'))
    assert e.msg == 'foo'
    assert e.type == 1
    assert e.value == 'spam'
    assert e.context == ('huey', 'foo')

# Generated at 2022-06-21 10:14:08.902344
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Tests the Parser.pop method."""
    grammar = Grammar(sorted(token.tok_name.items()))
    parser = Parser(grammar)
    # Check that the method pop of class Parser works correctly
    parser.pop()  # Check error messages

# Generated at 2022-06-21 10:14:16.845810
# Unit test for method classify of class Parser
def test_Parser_classify():
    class TestGrammar(object):
        def __init__(self):
            self.tokens = {
                token.NUMBER: 1,
                token.STRING: 2,
                token.NAME: 3,
                token.NEWLINE: 4,
                token.INDENT: 5,
                token.DEDENT: 6,
            }
            self.keywords = {
                "else": 7,
            }
    g = TestGrammar()
    p = Parser(g)
    # numeric
    assert p.classify(token.NUMBER, "1", None) == 1
    # string
    assert p.classify(token.STRING, "s", None) == 2
    # name
    assert p.classify(token.NAME, "n", None) == 3
    # reserved keyword

# Generated at 2022-06-21 10:14:36.066254
# Unit test for method push of class Parser
def test_Parser_push():
    raise ImportError("Loading Parser.py without importing prelude.py is not supported")


if __name__ == "__main__":
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2 import driver
    from blib2to3.pgen2 import grammar
    from blib2to3.pgen2.convert import driver as convert_driver

    parser = Parser(grammar, convert_driver.convert)
    for token in tokenize.generate_tokens(open(sys.argv[1], encoding="utf-8")):
        parser.addtoken(token[0], token[1], token[2])
        print(token)

# Generated at 2022-06-21 10:14:42.351243
# Unit test for function lam_sub
def test_lam_sub():
    cst_node = (
        1,
        "",
        (1, 0),
        [
            (
                1,
                "",
                (1, 0),
                [
                    (2, "", (1, 0), [])
                ],
            )
        ],
    )
    ast_node = Node(1, [Node(1, [Leaf(2, "")])])
    new_node = lam_sub(Grammar(), cst_node)
    assert ast_node == new_node

# Generated at 2022-06-21 10:14:44.266716
# Unit test for constructor of class Parser
def test_Parser():
    grammar = Grammar()
    p = Parser(grammar)

# Generated at 2022-06-21 10:14:48.344023
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError('foo', 1, 'bar', 'context')
    assert exc.msg == 'foo'
    assert exc.type == 1
    assert exc.value == 'bar'
    assert exc.context == 'context'

# Generated at 2022-06-21 10:14:58.948171
# Unit test for function lam_sub
def test_lam_sub():
    from . import pgen
    from .pgen2 import driver
    import unittest
    from blib2to3.pgen2.parse import ParseError  # type: ignore
    import sys
    import os

    class TestLamSub(unittest.TestCase):
        grammar = driver.load_grammar(os.path.join(driver.GRAMMAR_DIR, "Grammar.txt"))

        def test_lam_sub(self) -> None:
            l = RawNode(1, None, None, [RawNode(1, "1", None, None)])
            n = lam_sub(self.grammar, l)
            self.assertEqual(n.type, 1)
            self.assertIsNone(n.value)
            self.assertEqual(len(n.children), 1)
           

# Generated at 2022-06-21 10:15:10.527293
# Unit test for method push of class Parser
def test_Parser_push():
    pass
    # t = grammar.Grammar()
    # t.symbol2number = {'expr': 1, 'term': 2, 'factor': 3, 'NUM': 4}
    # t.number2symbol = {1: 'expr', 2: 'term', 3: 'factor', 4: 'NUM'}
    # t.dfas = {1: tdfa, 2: tdfa, 3: tdfa, 4: tdfa}
    # t.keywords = {'if': 5, 'else': 6, 'while': 7}
    # t.tokens = {'+': 8, '*': 9}
    # t.labels = {5: (5, 'if'), 6: (6, 'else'), 7: (7, 'while'),
    #     8: (8, '+'), 9

# Generated at 2022-06-21 10:15:13.394008
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("foo", 0, "", None)
    assert str(e) == "foo: type=0, value='', context=None"



# Generated at 2022-06-21 10:15:23.514171
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.addtoken(token.NAME, "a", p.rootnode)
    assert p.addtoken(token.NEWLINE, "\n", p.rootnode)
    assert p.addtoken(token.NAME, "b", p.rootnode)
    assert p.addtoken(token.NEWLINE, "\n", p.rootnode)
    assert p.addtoken(token.NAME, "c", p.rootnode)
    assert p.addtoken(token.NEWLINE, "\n", p.rootnode)
    assert p.addtoken(token.NAME, "d", p.rootnode)
    assert p.addtoken(token.ENDMARKER, "", p.rootnode)

# Generated at 2022-06-21 10:15:27.458673
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    assert str(ParseError("x", 1, "a", None)) == """\
x: type=1, value='a', context=None"""

# Generated at 2022-06-21 10:15:36.098786
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from .token import tok_name
    g = grammar.Grammar(debug=0)
    p = Parser(g, lam_sub)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 2))
    p.addtoken(token.NAME, "b", (1, 3))
    p.addtoken(token.NAME, "c", (1, 4))
    p.addtoken(token.OP, "+", (1, 5))
    p.addtoken(token.NAME, "d", (1, 6))
    p.addtoken(token.NAME, "e", (1, 7))
    p.addtoken(token.NAME, "f", (1, 8))
    p.addtoken(token.OP, "*", (1, 9))

# Generated at 2022-06-21 10:15:57.492157
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError('foo', 1, 'bar', 2)
    assert exc.msg == 'foo'
    assert exc.type == 1
    assert exc.value == 'bar'
    assert exc.context == 2

# Generated at 2022-06-21 10:16:00.359094
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar()
    node = (None, None, None, [])
    node = lam_sub(grammar, node)
    assert isinstance(node, Node)

# Generated at 2022-06-21 10:16:02.199837
# Unit test for constructor of class Parser
def test_Parser():
    """Test Parser constructor."""
    p = Parser(Grammar())

# Generated at 2022-06-21 10:16:11.323770
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    # test of classify() for token.NAME
    for token_text, ilabel in list(g.keywords.items()):
        assert p.classify(token.NAME, token_text, None) == ilabel
    # test of classify() for token.STRING
    assert p.classify(token.STRING, "", None) == 58
    # test of classify() for token.NEWLINE
    assert p.classify(token.NEWLINE, "", None) == 4

# Generated at 2022-06-21 10:16:21.543006
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)

    s = tokenize.generate_tokens(["class", "a", ":", "pass", "EOF", "class", "b", ":",
                                  "pass", "EOF"])

    p.setup()
    while True:
        try:
            t = next(s)
        except (StopIteration):
            break
        r = p.addtoken(t.type, t.string, t.context)
        if r:
            break

    assert(len(p.stack) == 0)
    assert(p.rootnode.type == symbol.file_input)
    assert(p.rootnode.children[0].type == symbol.classdef)

# Generated at 2022-06-21 10:16:31.940421
# Unit test for method classify of class Parser
def test_Parser_classify():
    class FakeGrammar:
        def __init__(self, tokens, keywords):
            self.tokens = tokens
            self.keywords = keywords

    class FakeContext:
        __slots__ = ['lineno', 'offset']

        def __init__(self, lineno: int, offset: int) -> None:
            self.lineno = lineno
            self.offset = offset

    def test(
        grammar,
        tokens,
        keywords,
        token_types: Sequence[int],
        token_values: Sequence[Text],
        expected: Sequence[int],
        msg: Text,
    ):
        parser = Parser(FakeGrammar(tokens, keywords))

# Generated at 2022-06-21 10:16:43.764451
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    # Return tokens from a small test program (see also test/tokenize.py)
    import io
    from io import TextIOBase
    from io import StringIO
    lines = ["x = 0"]
    infile = io.StringIO(lines[0])
    lang = "Python"
    encoding = "utf-8"
    kw = driver.generate_tokens(infile, lang, encoding)

    # Load the grammar
    import pkg_resources
    pkg = pkg_resources.Requirement.parse("blib2to3")
    path = pkg_resources.resource_filename(pkg, "blib2to3/grammar/" + lang + ".txt")
    gr = Grammar(path, encoding)

    # Check that we've got the tokens that we expected

# Generated at 2022-06-21 10:16:55.021175
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.grammar as pgen_grammar
    import blib2to3.pgen2.token as pgen_token
    import blib2to3.pytree as pytree

    def class_convert(grammar,node):
        return pytree.NL.from_node(node)

    g = pgen_grammar.Grammar(pgen_token.tok_name)
    p = Parser(g,convert=class_convert)
    p.setup()
    p.addtoken(1,"a",(1,2))
    p.addtoken(3,None,(1,3))
    p.addtoken(1,"b",(1,4))

    assert isinstance(p.rootnode, pytree.NL)

# Generated at 2022-06-21 10:17:03.060518
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .token import tok_name

    def run(tokens: Sequence[int], names: Sequence[str], expected: Sequence[int]):

        def make_converter(grammar):

            def c(grammar, node):
                return node

            return c

        grammar = setuptables()
        p = Parser(grammar, make_converter(grammar))
        p.setup()
        for t, n in zip(tokens, names):
            # print tok_name[t], `n`
            p.addtoken(t, n, None)



# Generated at 2022-06-21 10:17:14.280254
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import parsetok

    grammar = parsetok.tokenize_grammar(parsetok.grammar)
    grammar.start = parsetok.syms.file_input
    p = Parser(grammar)
    p.setup()

    def check(toks: Sequence[Tuple[int, Text, Context]], results: Results) -> None:
        for type, value, context in toks:
            p.addtoken(type, value, context)
        assert p.rootnode.children == [
            Node(syms.newline, [], context=(1, 0)),
            Node(syms.simple_stmt, [], context=(1, 0)),
        ]
        p.pop()
        assert p.stack == []
        assert p.rootnode.type == syms.file_input
        assert p

# Generated at 2022-06-21 10:17:35.394135
# Unit test for method shift of class Parser
def test_Parser_shift():
    assert 0, "Not yet done"

# Generated at 2022-06-21 10:17:45.933939
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    class MockToken(object):
        """Mock a token instance."""

        def __init__(
            self,
            lineno: int,
            offset: int,
            type: int,
            value: Optional[Text],
            expected: Sequence[Tuple[Text, int, Dict[Text, int]]],
        ) -> None:
            self.lineno = lineno
            self.offset = offset
            self.type = type
            self.value = value
            self.expected = expected

    class MockGrammar(object):
        """Mock a grammar instance."""

        def __init__(self, dfas: DFAS, start: int) -> None:
            self.dfas = dfas
            self.start = start

    # EOF

# Generated at 2022-06-21 10:17:48.548200
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Msg", 5, "Val", "Ctx")
    except ParseError as e:
        assert e.msg == "Msg"
        assert e.type == 5
        assert e.value == "Val"
        assert e.context == "Ctx"
    else:
        assert False, "constructor of class ParseError failed"

# Generated at 2022-06-21 10:17:57.636264
# Unit test for method classify of class Parser
def test_Parser_classify():
    import io
    from . import grammar, driver, token
    from .tokenize import generate_tokens
    g = grammar.grammar
    p = Parser(g, None)
    p.setup()
    src = "if 1: pass\n"
    tokengen = generate_tokens(io.StringIO(src).readline)
    tok = next(tokengen)
    # First token is whitespace
    assert tok == (
        token.INDENT,
        "",
        (driver.__name__, 1, 0, src),
        (1, 0),
        src,
    )
    # Second token is keyword
    tok = next(tokengen)

# Generated at 2022-06-21 10:18:02.567329
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.grammar import Grammar

    test_grammar = Grammar(open("Python.grammar"))
    parser = Parser(test_grammar)
    parser.setup()
    parser.addtoken(1, 1, 2)

# Generated at 2022-06-21 10:18:09.197514
# Unit test for method setup of class Parser
def test_Parser_setup():
    r"""
    >>> from . import grammar
    >>> p = Parser(grammar.grammar, convert=lam_sub)
    >>> p.setup(0)
    >>> p.stack[:]
    [(([[(1, 0), (2, 0), (3, 0), (4, 0)], [(1, 1), (2, 1), (4, 1)], [(1, 2), (4, 2)]], {1: 0, 2: 1, 3: 1, 4: 2}), 0, ('file_input', None, None, []))]
    """


# Generated at 2022-06-21 10:18:15.966656
# Unit test for method shift of class Parser
def test_Parser_shift():

    class A:
        pass

    def foo(grammar, node):
        return "foo"

    def bar(grammar, node):
        assert node[3] is None
        return A()

    print("Testing method shift of class Parser")
    node = (1, "", None, [])
    p = Parser(Grammar(), foo)
    p.push(1, DFA[1], 0, None)
    p.stack[-1] = (p.stack[-1][0], p.stack[-1][1], node)
    p.shift(2, "", 0, None)
    assert node[3][-1] == "foo"

    p = Parser(Grammar(), bar)
    p.push(1, DFA[1], 0, None)

# Generated at 2022-06-21 10:18:27.487071
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import tokenize

    g = driver.Driver().make_grammar()
    p = Parser(g)
    # Test with all tokens, without conversion
    p.setup()
    p.addtoken(token.ENCODING, "utf-8", None)
    p.addtoken(token.ENDMARKER, None, None)
    assert p.rootnode is not None

    # Test with conversion of NAME into NAME_CONST
    def maybe_NAME_CONST(grammar: Grammar, node: RawNode) -> Union[Node, Leaf]:
        if node[0] == grammar.name:
            return Leaf(token.NAME_CONST, node[1], node[2])
        return node

    p = Parser(g, maybe_NAME_CONST)
    p.setup()
   

# Generated at 2022-06-21 10:18:36.095410
# Unit test for method setup of class Parser
def test_Parser_setup():
    from .tokenize import generate_tokens

    from . import grammar
    from . import token

    fp = open("../default.txt", encoding='utf-8')
    g = grammar.grammar
    d = {}
    p = Parser(g)
    p.setup()

    for type, token, start, end, line in generate_tokens(fp.readline):
        d[token] = type
        p.addtoken(type, token, start)

if __name__ == '__main__':
    test_Parser_setup()

# Generated at 2022-06-21 10:18:41.326725
# Unit test for function lam_sub
def test_lam_sub():
    class FakeGrammar:
        pass

    g = FakeGrammar()
    n = (1, "a", None, [2, 3])
    c = lam_sub(g, n)
    n[3] = None
    assert c == n


# Local Variables:
# tab-width:4
# indent-tabs-mode:nil
# End:
# vim: set expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-21 10:19:30.250632
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar, token, driver
    g = grammar.Grammar(driver.grammar)
    p = Parser(g, lam_sub)
    p.setup()
    for s in "print 2+3".split(" "):
        p.addtoken(token.NAME, s, 1)
    p.addtoken(token.RPAR, ")", 1)
    assert p.rootnode is not None
    assert p.rootnode.children[0].type == token.NAME
    assert p.rootnode.children[0].value == "print"
    assert p.rootnode.children[1].children[0].value == "2"
    assert p.rootnode.children[1].children[1].type == token.PLUS



# Generated at 2022-06-21 10:19:32.492147
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test constructor
    pe = ParseError("hello", 1, "world", None)
    assert str(pe) == "hello: type=1, value='world', context=None"

# Generated at 2022-06-21 10:19:33.578714
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.grammar
    Parser(g)


# Generated at 2022-06-21 10:19:39.496375
# Unit test for method push of class Parser
def test_Parser_push():
    def func():
        pass
    from . import tokenize
    from . import grammar
    from . import driver
    from . import python_symbols
    g = grammar.grammar
    p = Parser(g)
    d = driver.Driver(g)
    f = open(__file__)
    try:
        for t in tokenize.tokenize(f.readline):
            n = p.stack[-2][2]
            if n[0] == python_symbols.suite:
                break
            if t[0] == token.NL:
                continue
            p.addtoken(t[0], t[1], d.get_curr_context())
    finally:
        f.close()



# Generated at 2022-06-21 10:19:46.103456
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    grammar_str = """
    S: 'a'
    """
    grammar_construntor = grammar.Grammar(grammar_str)
    g = grammar_construntor.parse_string(grammar_str)
    parser: Parser = Parser(g)
    parser.setup(None)
    
    assert hasattr(parser, 'stack')
    assert hasattr(parser, 'rootnode')
    assert hasattr(parser, 'used_names')


# Generated at 2022-06-21 10:19:46.680690
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    pass

# Generated at 2022-06-21 10:19:57.648749
# Unit test for method push of class Parser
def test_Parser_push():
    from StringIO import StringIO
    # These tests fail without __slots__ attributes.
    p = Parser(grammar)
    p.setup()
    # The grammar is defined in grammar/grammar; this is just a
    # convenience so that it can be accessed here.
    r = h = None
    for t in driver.tokenize(StringIO("2+3")):
        if p.addtoken(t.type, t.string, (t.lineno, t.offset)):
            r = p.rootnode
            break
    assert isinstance(r, Leaf)
    assert r.type == token.NUMBER
    assert len(p.stack) == 1
    assert r.value == "2"
    assert r.context[0] == 1

# Generated at 2022-06-21 10:20:02.917150
# Unit test for method classify of class Parser
def test_Parser_classify():
    p = Parser(Grammar(token.tok_name, token.NT_OFFSET, [], [], [], [], {}, {}))
    assert token.NAME == 1
    assert p.classify(token.NAME, '1', None) == 1