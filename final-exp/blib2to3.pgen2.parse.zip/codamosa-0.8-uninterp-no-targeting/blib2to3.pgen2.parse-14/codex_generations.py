

# Generated at 2022-06-21 10:10:14.902452
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.token import TokenInfo
    #
    # Test the classify method
    #
    class MockGrammar:
        dfas = {}
        labels = [(token.NAME, "a"), (token.NAME, "b")]
        keywords = {'a': 0}
        tokens = {token.NAME: 1}
    x = Parser(MockGrammar())
    x.setup()
    assert x.classify(token.NAME, "a", Context(None, None)) == 0
    assert x.classify(token.NAME, "b", Context(None, None)) == 1
    assert x.classify(token.NAME, "c", Context(None, None)) == 1
    #
    # Test the classify method with a custom token
    #

# Generated at 2022-06-21 10:10:26.184456
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import pprint
    import io
    import blib2to3.pgen2.pgen
    import blib2to3.pgen2.driver
    pgen = blib2to3.pgen2.pgen.Pgen()
    tree = pgen.parse(io.StringIO(test_Parser_addtoken.__doc__), 'test_parser_addtoken')
    p = blib2to3.pgen2.driver.Driver(tree, convert=lam_sub)
    parser = p.make_parser()
    print_tree(parser.rootnode)

    # This should work
    parser.setup()
    for i in range(0, 50):
        if parser.addtoken(i, str(i), None):
            break
    print_tree(parser.rootnode)

    # This should raise a Par

# Generated at 2022-06-21 10:10:36.399222
# Unit test for method push of class Parser
def test_Parser_push():
    parser = Parser(grammar.grammar, lam_sub)
    parser.setup()
    parser.addtoken(token.NAME, "x", None)
    parser.addtoken(token.EQUAL, "=", None)
    parser.addtoken(token.NAME, "y", None)
    parser.addtoken(token.NEWLINE, "\n", None)
    parser.addtoken(token.NAME, "y", None)
    parser.addtoken(token.EQUAL, "=", None)
    parser.addtoken(token.NAME, "x", None)
    parser.addtoken(token.NEWLINE, "\n", None)
    parser.addtoken(token.ENDMARKER, "", None)


# Generated at 2022-06-21 10:10:39.409476
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("test message", token.NAME, "foo", (0, 1))
    assert e.msg == "test message"
    assert e.type == token.NAME
    assert e.value == "foo"
    assert e.context == (0, 1)

# Generated at 2022-06-21 10:10:51.501013
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest
    import re
    from blib2to3.pgen2 import token
    from blib2to3.pgen2.grammar import Grammar

    class Test(unittest.TestCase):
        def compile(self, s):  # Compile a grammar from a string.
            from blib2to3.pgen2.parse import Parser, parse_grammar
            return parse_grammar(s, self.get_grammar(), Parser)

        def get_grammar(self):  # Create the usual grammar instance.
            from blib2to3.pgen2.grammar import Grammar
            from blib2to3.pgen2 import token
            return Grammar(token.NT_OFFSET, {}, {}, {}, "file_input")


# Generated at 2022-06-21 10:10:59.667478
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.parse
    from . import driver
    from . import tokenize
    from . import token
    import sys,io

    source = 'import a ; a.b = 1\n'
    f = io.StringIO(source)
    tokenizer = tokenize.tokenize(f.readline)
    parser = blib2to3.pgen2.parse.Parser(blib2to3.pgen2.driver.load_grammar(sys.version_info),
                                         blib2to3.pgen2.parse.lam_sub)
    parser.setup()
    for tok in tokenizer:
        parser.addtoken(*tok)


# Generated at 2022-06-21 10:11:08.571428
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest
    from . import grammar

    class TestParser(unittest.TestCase):
        def test_classify(self):
            gr = grammar.Grammar()
            gr.start = 257

# Generated at 2022-06-21 10:11:18.896426
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import parse

    def convert(grammar, node):
        node[3] = map(convert, node[3])
        return node
    p = Parser(parse.grammar, convert)
    p.setup()
    p.addtoken(token.NAME, "and", Context(None, None))
    p.addtoken(token.NAME, "and", Context(None, None))
    assert p.addtoken(token.NAME, "or", Context(None, None))
    root = p.rootnode
    assert root[0] == 256
    assert root[1] == None
    assert root[2] == None
    assert len(root[3]) == 2
    assert root[3][0][0] == token.NAME

# Generated at 2022-06-21 10:11:30.265003
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .pgen2 import driver

    class DummyGrammar(object):
        pass

    grammar = DummyGrammar()
    grammar.start = 257
    grammar.dfas = {
        256: ([[0]], set([257])),
        257: ([[0], [1], [2]], set([258])),
        258: ([[3]], set([259])),
        259: ([[4]], set([])),
    }
    grammar.keywords = {}
    grammar.labels = [None, None, None, None, None]
    grammar.labels[1] = (token.STRING, "")
    grammar.labels[2] = (token.INDENT, "")
    grammar.labels[3] = (token.DEDENT, "")

# Generated at 2022-06-21 10:11:33.870678
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("a", 1, "b", (3, 2))
    assert str(pe) == "a: type=1, value='b', context=(3, 2)"

# Generated at 2022-06-21 10:11:40.388898
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("foo", 1, "value", Context(None, 0, 0))
    assert type(str(err)) is str
    assert err.msg == "foo"
    assert err.type == 1
    assert err.value == "value"
    assert err.context == Context(None, 0, 0)


# Generated at 2022-06-21 10:11:47.948850
# Unit test for method setup of class Parser
def test_Parser_setup():
    from ..pgen2 import driver, grammar, pgen
    from . import token
    from sys import stdout
    from os import environ
    from io import StringIO
    import types

    try:
        import _testcapi
        have_types_module = True
    except ImportError:
        have_types_module = False

    g = grammar.Grammar()
    g.parse(StringIO(pgen.grammar), "<string>")
    d = driver.Driver(g, convert=pgen.convert)

    def parse(s, **kwds):
        return d.parse_string(s, **kwds)

    def t(s, tree, **kwds):
        # parse a string, compare it to an expected tree representation
        t1 = parse(s, **kwds)
        assert t1 == tree

# Generated at 2022-06-21 10:11:51.047081
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar())
    p.shift(token.NEWLINE, '\n', 0, None)
    assert p.stack == [(None, 0, (None, None, None, ['\n']))]

# Generated at 2022-06-21 10:12:03.039500
# Unit test for method push of class Parser
def test_Parser_push():
    from . import graminit
    from . import token
    from . import symbols

    g = graminit.Grammar()
    test_stack = []
    dfa = ['A', 'B', 'C']
    grammar = 'Grammar'
    newstate = 1
    context = 'context'
    dfa = [1,2,3]
    newdfa = ['A', 'B', 'C']
    p = Parser(g)
    p.stack = test_stack
    newnode = ('type', None, context, [])
    # case 1
    newdfa[0] = newdfa[1]

    p.push(1, newdfa, newstate, context)
    assert test_stack == [(dfa, 0, newnode)]

    # case 2
    newdfa[0] = new

# Generated at 2022-06-21 10:12:14.389944
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from .pgen import driver

    empty_grammar = grammar.Grammar(None, None, None, None, None, None, None, None)
    parser = Parser(empty_grammar)
    parser.classify(1, 'a', None) # should not crash

    g = driver.load_grammar("Grammar/Grammar")
    p = Parser(g)
    p.classify(g.tokens["NAME"], "name", Context(None, None))
    p.classify(g.tokens["DOT"], ".", Context(None, None))
    p.classify(g.tokens["NEWLINE"], "\n", Context(None, None))

# Generated at 2022-06-21 10:12:16.250891
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)

# Generated at 2022-06-21 10:12:29.035905
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar, token

    g = grammar.Grammar()
    g = g.parse_grammar(grammar.grammar)
    p = Parser(g)
    results = {
        "expr_stmt": NL,
        "testlist_star_expr": NL,
        "test": NL,
        "and_test": NL,
        "not_test": NL,
        "comparison": NL,
        "expr": NL,
        "xor_expr": NL,
        "and_expr": NL,
        "shift_expr": NL,
        "arith_expr": NL,
        "term": NL,
        "factor": NL,
        "power": NL,
        "atom": NL,
    }

# Generated at 2022-06-21 10:12:33.242693
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Test method classify of class Parser
    class Dummy(object):
        def __init__(self, **kwargs: Any) -> None:
            for name, value in kwargs.items():
                setattr(self, name, value)

    class DummyGrammar(object):
        def __init__(self) -> None:
            # This is supposed to be a grammar.Grammar instance
            self.keywords: Dict[Text, int] = {'if': 57, 'while': 58}
            self.tokens: Dict[int, int] = {
                token.NUMBER: 259,
                token.NAME: 260,
                token.LPAR: 51,
                token.RPAR: 52,
            }

# Generated at 2022-06-21 10:12:35.772643
# Unit test for constructor of class Parser
def test_Parser():
    from pprint import pprint

    # Test for the constructor of class Parser
    p = Parser(None)
    p.setup()

# Generated at 2022-06-21 10:12:44.767147
# Unit test for method setup of class Parser
def test_Parser_setup():
    # This version of the setup method encapsulates the two lines:
    #    self.stack = [self.grammar.dfas[start], 0, (start, None, None, [])]
    #    self.rootnode = None
    def setup(self, start=None) -> None:
        if start is None:
            start = self.grammar.start
        self.stack = [self.grammar.dfas[start], 0, (start, None, None, [])]
        self.rootnode = None

    # Won't work because the grammar structure is complex
    #setup(self, start=dict(type=res))
    # Won't work because start is the wrong type
    #setup(self, start=('xxx',))
    # Won't work because start is the wrong type
    #setup(self, start=(1,2

# Generated at 2022-06-21 10:12:58.640130
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.grammar
    assert g is not None
    p = Parser(g)
    p.setup()


# Generated at 2022-06-21 10:13:10.076002
# Unit test for method push of class Parser
def test_Parser_push():
    g = Grammar()
    g.symbol2number = {'START': 1, 'A': 2, 'B': 3, 'C': 4}
    g.start = 1
    g.dfas = {2: ([[(3, 1), (4, 2)], [(0, 1)], [(0, 2)]], {1: 1, 2: 2}),
              3: ([[(5, 3), (6, 4)], [(0, 3)], [(0, 4)]], {3: 1, 4: 2}),
              4: ([[(0, 5)], [(0, 6)]], {5: 1, 6: 2}),
              1: ([[(2, 7)]], {7: 1})}
    p = Parser(g, None)
    # Test the init method of class Parser

# Generated at 2022-06-21 10:13:16.995207
# Unit test for method push of class Parser
def test_Parser_push():
    import StringIO
    from blib2to3.pgen2 import driver
    from blib2to3.pgen2 import tokenize

    def test_file(filename, *, start=None):
        # Read the grammar, construct a Parser
        grammar = driver.load_grammar(filename)
        parser = Parser(grammar)

        # Open the test file and tokenize it
        fp = open(filename, "rb")
        tokens = list(tokenize.generate_tokens(fp.readline))
        fp.close()

        # Set up the parser, feed in the tokens
        parser.setup(start)
        for ttype, value, start, end, line in tokens:
            parser.addtoken(ttype, value, (start, end, line))
        # The root node should be the entire file

# Generated at 2022-06-21 10:13:28.456472
# Unit test for method classify of class Parser
def test_Parser_classify():
    # just a smoke test
    from . import grammar, token, word_tokenize, untokenize
    p = Parser(grammar)
    p.setup()
    t = token.Token(1, "x")  # single character token
    try:
        p.classify(t.type, t.string, t.start)
    except ParseError:
        pass
    else:
        assert False, "should have raised ParseError"
    t = token.Token(token.NAME, "while")  # reserved word token
    try:
        p.classify(t.type, t.string, t.start)
    except ParseError:
        pass
    else:
        assert False, "should have raised ParseError"
    t = token.Token(token.NAME, "if")  # reserved word token
   

# Generated at 2022-06-21 10:13:37.044440
# Unit test for method push of class Parser
def test_Parser_push():
    import pgen2.parse
    import tempfile
    import os
    import shutil

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-21 10:13:49.758197
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .pgen import parse_grammar

    def converttoken(grammar, node):
        # Don't convert tokens to leaf nodes
        assert node[-1] is None
        return None

    def convertsymbol(grammar, node):
        assert node[1] is None
        return Node(type=node[0], children=node[3])

    p = Parser(parse_grammar)
    p.convert = converttoken
    p.setup()

    # Test with one token

    p.addtoken(
        token.NAME, "name", Context(line_num=5, column_offset=10, end_line_num=5, end_column_offset=14)
    )

# Generated at 2022-06-21 10:13:56.665618
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar())
    p.setup()
    token1 = (token.LBRACE, "{")
    raw = (token.LBRACE, "{")
    p.shift(token1[0], token1[1], 1, "convert")
    assert p.stack == [(
        [([(0, 1)], set()),
         ([(-1, 1)], set())],
        1,
        (Grammar().start, None, None, [raw])
    )]

# Generated at 2022-06-21 10:14:01.663570
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("foo", 1, "bar", (1, 2))
    except ParseError as e:
        assert e.msg == "foo"
        assert e.type == 1
        assert e.value == "bar"
        assert e.context == (1, 2)
    else:
        assert 0

# Generated at 2022-06-21 10:14:12.884203
# Unit test for method push of class Parser
def test_Parser_push():
    """AssertionError: Parser.stack.append()

This error is from the configuration:

  -k "name_repr(foo)" --config="asserts={'enable': True}"
"""
    p = Parser(Grammar())
    newdfa = (
        [
            [(3, 2), (1, 3), (2, 4)],
            [(1, 0), (0, 1)],
            [(1, 0), (0, 2)],
            [(3, 2), (1, 3), (2, 4)],
            [(1, 0), (0, 4)],
        ],
        {0: 1, 2: 3, 3: 5, 4: 6},
    )  # type: DFAS
    newstate = 4

# Generated at 2022-06-21 10:14:15.434034
# Unit test for constructor of class Parser
def test_Parser():
    from . import driver

    grammar = driver.load_grammar("Grammar.txt")
    convert = None
    parser = Parser(driver.load_grammar("Grammar.txt"), convert)

# Generated at 2022-06-21 10:14:35.807344
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver
    from . import pgen2

    g = driver.load_grammar("Grammar/Grammar")
    p = Parser(g)
    import token
    assert p.classify(token.NAME, "foo", None) == pgen2.token.NAME
    assert p.classify(token.NAME, "and", None) == pgen2.symbol.and_test
    assert p.classify(token.NAME, "pass", None) == pgen2.symbol.pass_stmt

# Generated at 2022-06-21 10:14:38.896563
# Unit test for constructor of class Parser
def test_Parser():
    """Test the constructor of class Parser."""
    from . import driver

    grammar = driver.load_grammar("Grammar/Grammar")
    p = Parser(grammar)
    assert p.grammar is grammar
    assert p.convert is lam_sub

# Generated at 2022-06-21 10:14:43.575634
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("msg", 123, "value", (1, 0))
    assert e.msg == "msg"
    assert e.type == 123
    assert e.value == "value"
    assert e.context == (1, 0)



# Generated at 2022-06-21 10:14:55.242481
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import driver

    def lam_sub(grammar, node):
        assert node[3] is not None
        return driver.Node(type=node[0], children=node[3], context=node[2])

    parser = Parser(grammar, lam_sub)
    parser.setup()
    parser.addtoken(1, "a", "")
    parser.addtoken(1, "b", "")
    parser.stack == [(0, 0, (334, None, None, [])), (0, 0, (334, None, None, [1, 2]))]
    parser.pop()
    parser.stack == [(0, 0, (334, None, None, [3]))]
    parser.rootnode is None
    parser.pop()

# Generated at 2022-06-21 10:15:03.396891
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import Driver
    from . import tokenize
    import io

    src = io.StringIO(
        '''
        def f(x,y,z):
            if x == 0:
                return 0
            else:
                return f(x-1,y,z)

        f(2,3,4)
        '''
    )
    tokengen = tokenize.generate_tokens(src.readline)

    driver = Driver.Driver(grammar = None, convert = None)
    driver.setup()
    try:
        while True:
            t = next(tokengen)
            print(t)
            if driver.addtoken(*t):
                print(driver.rootnode)
                break
    except ParseError as e:
        print(e.context)
        raise


# Generated at 2022-06-21 10:15:07.662429
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("test", 1, "value", (1, 2))
    assert pe.msg == "test"
    assert pe.type == 1
    assert pe.value == "value"
    assert pe.context == (1, 2)

# Generated at 2022-06-21 10:15:19.354627
# Unit test for method setup of class Parser
def test_Parser_setup():
    # From http://bugs.python.org/issue1636:
    # Keep a reference to the raw node obtained by the first setup().
    # This test ensures that the node is deleted.
    import gc
    import operator
    from blib2to3.pgen2.pgen import generate_grammar
    from blib2to3.pgen2 import token
    import re
    grammar = generate_grammar()
    do_assert = operator.truth
    def check_refs():
        lst = gc.get_referrers(*gc.get_referents(node))

# Generated at 2022-06-21 10:15:32.302555
# Unit test for method pop of class Parser
def test_Parser_pop():
    class SyntaxTreeNode(object):
        def __init__(self, type: int, value: Text, context: Context, children: Sequence[Any]) -> None:
            self.type = type
            self.value = value
            self.context = context
            self.children = children

    def convert(grammar, node):
        type, value, context, children = node
        if len(children) == 0:
            return Leaf(type, value, context)
        return Node(type, children, context)

    grammar = Grammar(
        """
        test: test4 | test4 test4 | test4 test4 test4 | test4 test4 test4 test4;
        test4: test4 test4 | test4 test4 test4 | test4 test4 test4 test4;
        """
    )

# Generated at 2022-06-21 10:15:38.366189
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import io
    import tokenize
    from . import driver
    from . import grammar
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.parse import Parser, ParseError
    from blib2to3.pytree import NL, Context, RawNode, Leaf, Node

    def tok(type: int, string: Text, srow: int, scol: int, brow: int, bcol: int):
        return (type, string, srow, scol, brow, bcol, string)

    g = Grammar(io.StringIO(grammar.grammar))
    p = Parser(g)

    # Test id-or-keyword

# Generated at 2022-06-21 10:15:51.048835
# Unit test for method pop of class Parser
def test_Parser_pop():
    from unittest.mock import Mock
    from blib2to3.pgen2.parse import Parser
    p = Parser(Mock())
    p.stack.append([[(2, 2)] * 3, [0, 2, 3]])

    p.stack.append([[(2, 2)] * 3, [0, 2, 3]])
    p.stack[-1][2] = [12, None, (1,), None]
    p.pop()
    assert p.stack[-1][2][-1][0] == 12

    p.stack.append([[(2, 2)] * 3, [0, 2, 3]])
    p.stack[-1][2] = [13, None, (1,), None]
    p.pop()

# Generated at 2022-06-21 10:16:25.411222
# Unit test for constructor of class Parser
def test_Parser():
    from .grammar import Grammar

    grammar = Grammar(open("Grammar/Grammar"))
    parser = Parser(grammar)
    parser.setup()

# Generated at 2022-06-21 10:16:30.468770
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar({}, {}, {}, {}, {})
    node = (1, None, None, [(1, None, None, None), (2, None, None, None)])
    assert lam_sub(grammar, node) == [
        Node(type=1, children=[]),
        Node(type=2, children=[]),
    ]

# Generated at 2022-06-21 10:16:34.951419
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver

    d = driver.Driver(convert=lam_sub)
    p = d.parser
    p.push(1, (([(0, 1)], 0), {1: 0}), 1, None)
    assert p.stack == [(d.dfas[1], 0, (1, None, None, [])), (([(0, 1)], 0), {1: 0}, 1, None)]



# Generated at 2022-06-21 10:16:38.657574
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for ParseError constructor."""
    e = ParseError("msg", token.NAME, "name", Context(1, 0))
    assert str(e) == "msg: type=NAME, value='name', context=(1, 0)"

# Generated at 2022-06-21 10:16:50.915437
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver
    from . import grammar
    from . import tokens

    # create a Parser instance with default grammar and default token mappings
    p = Parser(grammar.grammar, driver.convert)
    # prepare for parsing
    p.setup()

    type = tokens.NT_OFFSET + 1
    value = None
    context = None
    newdfa: DFAS = ([[(0, 0), (1, 1)]], {0: 1, 1: 2})
    newstate = 0

    p.push(type, newdfa, newstate, context)

    assert p.stack[-1][0] == newdfa
    assert p.stack[-1][1] == newstate
    assert p.stack[-1][2][0] == type

# Generated at 2022-06-21 10:16:59.634655
# Unit test for method shift of class Parser
def test_Parser_shift():
    import lib2to3.pgen2.parse

    grammar_tokens = {1: 1}
    grammar_labels = [(1, (1, 'Test'))]
    grammar_dfas = {}
    grammar_dfas[1] = [(2, 3)]
    grammar_dfas[1] = [grammar_dfas[1], {}]
    grammar_start = 1
    grammar_keywords = {}
    grammar_literals = {}

    grammar = lib2to3.pgen2.parse.Grammar(
        grammar_tokens,
        grammar_labels,
        grammar_dfas,
        grammar_start,
        grammar_keywords,
        grammar_literals,
    )

    parser = lib2to3.pgen2.parse.Parser(grammar)
    parser.stack

# Generated at 2022-06-21 10:17:03.331859
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, 5, (1, 0))
    assert p.rootnode.prefix == "5"


# Generated at 2022-06-21 10:17:03.897329
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    pass

# Generated at 2022-06-21 10:17:15.223814
# Unit test for method push of class Parser
def test_Parser_push():
    def f(x):
        return x

    p = Parser(Grammar('''
        grammar:
            (stmt+ ENDMARKER |)
        stmt:
            simple_stmt (';' |)
        simple_stmt:
            small_stmt ';' small_stmt?
        small_stmt:
            'return'
    '''), f)

    p.setup()
    p.addtoken(token.NAME, 'return', (1, 0))  # push
    p.addtoken(token.RETURN, None, (1, 0))    # shift
    p.addtoken(token.SEMI, None, (1, 0))
    p.addtoken(token.NAME, 'return', (1, 0))  # shift

# Generated at 2022-06-21 10:17:26.659106
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.token
    import blib2to3.pgen2.grammar
    import blib2to3.pytree
    p = Parser(blib2to3.pgen2.grammar.Grammar(open("Grammar.txt", "rb")), lam_sub)
    p.setup()
    r = p.classify(blib2to3.pgen2.token.NAME, "0", blib2to3.pytree.Leaf(0, ""))
    assert r == 265
    r = p.classify(blib2to3.pgen2.token.NAME, "__add__", blib2to3.pytree.Leaf(0, ""))
    assert r == 303

# Generated at 2022-06-21 10:18:36.052277
# Unit test for method push of class Parser
def test_Parser_push():
    """Test of the push method from Parser class
    """
    from . import token
    from blib2to3.tests.support import driver
    from blib2to3.pgen2 import pgen
    from blib2to3.pytree import Leaf, RawChecker

    parser = pgen.driver.load_grammar("Grammar.txt", convert=lam_sub)

    class TestParser(pgen.Parser):
        def __init__(self, grammar, convert=None):
            super().__init__(grammar, convert)

        def push(self, type, newdfa, newstate, context):
            super().push(type, newdfa, newstate, context)
            newnode = newdfa[0][0][0]

# Generated at 2022-06-21 10:18:44.274227
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2 import tokenize

    s = "(a + b)"
    dfa = {0: {('a', (1, 1)): 1, ("(", (1, 0)): 2},
           1: {('+', (1, 3)): 3},
           2: {('a', (1, 1)): 1, ("(", (1, 0)): 2, ('b', (1, 5)): 4},
           3: {('b', (1, 5)): 4},
           4: {(")", (1, 7)): 5},
           5: {},
           }
    first = {0: {'(', 'a'}, 1: {'+'}, 2: {'(', 'a', 'b'}, 3: {'b'}, 4: {')'}}
   

# Generated at 2022-06-21 10:18:52.468419
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar, token

    # This is an excerpt of the test grammar in doc/library/pgen.rst
    # that illustrates the use of push and pop
    # (see also the test in test_grammar.py).


# Generated at 2022-06-21 10:18:58.469256
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar(start="foo", symbols={"foo": 0}, symbols_by_name={"foo": 0})
    node = ("foo", None, None, ["a", "b", "c"])
    r = lam_sub(grammar, node)
    assert isinstance(r, Node)
    assert r.type == "foo"
    assert r.children == ["a", "b", "c"]
    assert r.context is None

# Generated at 2022-06-21 10:19:03.432052
# Unit test for function lam_sub
def test_lam_sub():
    # type: () -> None
    assert lam_sub(None, ("type", None, None, ["a", "b"])) == Node(
        type="type", children=["a", "b"]
    )

# Generated at 2022-06-21 10:19:11.813876
# Unit test for method addtoken of class Parser

# Generated at 2022-06-21 10:19:15.128590
# Unit test for constructor of class ParseError
def test_ParseError():
    exception = ParseError('msg', 1, 'value', (1, 0))
    assert exception.msg == 'msg'
    assert exception.type == 1
    assert exception.value == 'value'
    assert exception.context == (1, 0)



# Generated at 2022-06-21 10:19:20.206972
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    assert p.convert is not None
    assert p.grammar is g
    p.setup()
    assert len(p.stack) == 1
    assert p.rootnode is None



# Generated at 2022-06-21 10:19:24.184884
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar(
        '',
        '',
        {},
        {},
        '',
        {},
        {}
    )
    convert = lam_sub
    p = Parser(
        grammar,
        convert
    )
    start = None

    p.setup(start)


# Generated at 2022-06-21 10:19:27.560305
# Unit test for constructor of class Parser
def test_Parser():
    from .driver import Driver
    from . import grammar

    d = Driver()
    g = d.grammar
    p = Parser(g)
    p.setup()

