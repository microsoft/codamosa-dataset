

# Generated at 2022-06-23 15:40:33.292567
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .pgen import grammar
    from .tokenize import generate_tokens
    import io


# Generated at 2022-06-23 15:40:39.132760
# Unit test for function lam_sub
def test_lam_sub():
    from .tokenize import untokenize
    from . import grammar

    n = (1001, None, (1, 0), [(token.NUMBER, "1", None, None)])
    r = lam_sub(grammar, n)
    assert r == Node(n[0], [RawNode(n[3][0])], context=n[2])
    assert untokenize(r) == "1"

# Generated at 2022-06-23 15:40:49.483832
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .tokenize import (
        untokenize_with_linebreaks,
        tokenize_with_outline,
        SpaceToken,
        tokenize,
        DocString,
    )

    fakeGrammar = Grammar()
    fakeGrammar.tokens = {SpaceToken.name: 0, DocString.name: 1}
    fakeGrammar.add_label(0, SpaceToken)
    fakeGrammar.add_label(1, DocString)
    fakeNode = (SpaceToken.name, "", None, None)
    fakeConvert = lambda g, n: n

    parser = Parser(fakeGrammar, fakeConvert)
    parser.setup()

    parser.shift(SpaceToken.name, "", 0, None)

# Generated at 2022-06-23 15:40:55.833697
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class MockGrammar(Grammar):
        def __init__(self) -> None:
            super().__init__()
            self.start = 257
            self.labels = [
                (1, ""),
                (1, ""),
            ]
            self.dfas = {
                257: ([[(0, 257), (1, 258)], [(1, 258), (0, 257)]], {258: 257})
            }

    g = MockGrammar()
    p = Parser(g)
    p.setup()
    assert p.addtoken(1, "", None) is True
    assert p.rootnode is not None
    assert p.rootnode.type == 257
    assert p.addtoken(2, "", None) is False

# Generated at 2022-06-23 15:40:57.618047
# Unit test for method setup of class Parser
def test_Parser_setup():
    case = [
        Parser,
        {},
    ]
    return case


# Generated at 2022-06-23 15:41:05.226862
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar, token
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize

    class T(object):
        pass
    args = T()
    test1 = """
    var = 1
    if True:
        print(var)
    """
    args.file = test1.splitlines(keepends=True)
    args.debug = False
    gen = generate_tokens(args.file.__iter__().__next__)
    g = grammar.grammar
    p = Parser(g)
    p.setup(0)

    first = True
    for ttype, tstring, _, _, _ in gen:
        if first:
            print("==>", ttype, tstring)
            first = False

# Generated at 2022-06-23 15:41:12.290486
# Unit test for function lam_sub
def test_lam_sub():
    import pytest
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pytree import Leaf
    from pkg_resources import resource_string
    from . import pickle
    from . import driver
    from . import pgen
    from .tokenize import generate_tokens, NAMECHARS

    def is_name_tok(tok: Union[Leaf, Context]) -> bool:
        return isinstance(tok, Leaf) and tok.type == token.NAME

    # Enumerate all name tokens in this grammar, using the lazy AST constructor
    g = Grammar(resource_string(__name__, "Python.asdl"))
    ast_parser = driver.Driver(g, lam_sub)
    ast_parser.setup()

# Generated at 2022-06-23 15:41:25.232423
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Create the grammar for gyo
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.token as token
    g = grammar.Grammar()
    g.start = 'file_input'
    g.add_production('stmt', 'simple_stmt')
    g.add_production('stmt', 'compound_stmt')
    g.add_production('simple_stmt', 'NAME', "=", 'expr', end_marker=True)
    g.add_production('expr', 'NAME')
    g.add_production('expr', 'expr', '+', 'expr')
    g.add_production('file_input', 'endmarker')
    g.add_production('file_input', 'stmt')

# Generated at 2022-06-23 15:41:30.125912
# Unit test for method setup of class Parser
def test_Parser_setup():
    class TestGrammar:
        def __init__(self, start: int, dfas: Any) -> None:
            self.start = start
            self.dfas = dfas

    parser = Parser(TestGrammar(1, {}))
    parser.setup()
    assert parser.stack == [(
        {},
        0,
        (1, None, None, []),
    )]

# Generated at 2022-06-23 15:41:33.308064
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", 0, "value", "context")
    except ParseError as exc:
        assert exc.msg == "msg"
        assert exc.type == 0
        assert exc.value == "value"
        assert exc.context == "context"

# Generated at 2022-06-23 15:41:36.623801
# Unit test for function lam_sub
def test_lam_sub():
    # We can't do much testing here since Grammar is supposed to be
    # private to the grammar module.

    # A simple test for lam_sub itself
    assert lam_sub(None, (4, '4', None, None)) is None


# Generated at 2022-06-23 15:41:49.221960
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import tokenize, untokenize

    # Create a simple grammar
    t = token

    def g(grammar):
        grammar.start = 'stmts'
        grammar.stmts = ['stmt', 'stmts stmt']
        grammar.stmt = ['expr', 'print']
        grammar.expr = ['expr + term', 'term']
        grammar.term = ['term * factor', 'factor']
        grammar.factor = ['( expr )', 'num']
        grammar.num = ['NUM']
        grammar.print = ['print expr', 'printnl']

# Generated at 2022-06-23 15:41:58.776139
# Unit test for method setup of class Parser
def test_Parser_setup():
    from pgen2 import driver
    from pgen2 import grammar

    # Create a grammar
    gr = grammar.Grammar(
        grammar.Grammar(grammar.DEFAULT_GRAMMAR_FILE, "Grammar").grammar,
        "Grammar",
    )
    # Construct a Parser instance
    p = Parser(gr)
    # Prepare for parsing
    p.setup()
    # Test that we're in the right state

# Generated at 2022-06-23 15:42:11.166248
# Unit test for method push of class Parser
def test_Parser_push():
    import sys, blib2to3.pgen2.grammar
    if sys.argv.index("--test_Parser_push") < len(sys.argv) - 1:
        token_name = sys.argv[sys.argv.index("--test_Parser_push") + 1]
        if token_name == "None":
            token_name = None
        else:
            token_name = int(token_name)
        if not isinstance(token_name, int):
            raise AssertionError("token_name is not an int")
    else:
        token_name = token.NAME

# Generated at 2022-06-23 15:42:13.979571
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("msg", 3, "value", "context")
    assert str(err) == "msg: type=3, value='value', context='context'"



# Generated at 2022-06-23 15:42:21.554336
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import tokenize
    import io
    import unittest

    class TestParser(unittest.TestCase):
        def test_simple(self):
            # Test that the parser at least does not crash
            src = "import sys"
            # The following is the equivalent of:
            #
            #   stream = io.StringIO(src)
            #   stream = tokenize.detect_encoding(stream.readline)[0](stream)
            #   g = parser.Parser()
            #   g.setup()
            #   for t in tokenize.generate_tokens(stream.readline):
            #       g.addtoken(t)
            #   g.rootnode

            g = Parser(grammar)
            g.setup()

# Generated at 2022-06-23 15:42:24.208079
# Unit test for method push of class Parser
def test_Parser_push():
    Parser(Grammar(__file__)).push(0, 0, 0, Context(None))

# Generated at 2022-06-23 15:42:34.667501
# Unit test for constructor of class Parser
def test_Parser():
    from . import driver

    grammar = driver.load_grammar("Grammar.txt")
    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.COLON, ":", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))
    p.addtoken(token.INDENT, "", (2, 0))
    p.addtoken(token.NAME, "return", (2, 0))
    p.addtoken(token.NUMBER, "0", (2, 0))
    p.addtoken(token.NEWLINE, "\n", (2, 0))
    p.add

# Generated at 2022-06-23 15:42:42.811513
# Unit test for method push of class Parser

# Generated at 2022-06-23 15:42:52.159501
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar, token

    class Object(object):
        pass

    g = grammar.Grammar(Object())
    p = Parser(g)
    p.setup()
    p.stack = [(1,2,3)]
    p.push(4,5,6,7)
    assert p.stack == [(1,2,3), (5, 0, (4, None, 7, []))]
    p.push(8,9,10,11)
    assert p.stack == [(1,2,3), (5, 0, (4, None, 7, [])),
                              (9, 0, (8, None, 11, []))]
    p.shift(token.NAME, 'x', 12, Context('x', 'y'))

# Generated at 2022-06-23 15:43:03.471659
# Unit test for method push of class Parser
def test_Parser_push():
    from .pgen import Driver

    pd = Driver("Parser/unittest.gram", "Parser/unittest.tok")
    pd.grammar.dfas[3] = ([
        [(2, 0), (3, 1), (4, 2)],
        [(0, 2), (1, 4)],
        [(0, 5), (1, 6)],
        [(0, 7)],
        [(0, 3)],
        [(0, 5)],
        [(0, 8)],
        [(0, 9)]
    ], {
        3: 0, 5: 1, 6: 2, 8: 3, 9: 4
    })
    p = Parser(pd.grammar)
    p.setup()
    p.addtoken(4, None, None)

# Generated at 2022-06-23 15:43:12.411745
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert g.number2symbol[g.start] == "file_input"
    assert p.stack
    dfa, state, node = p.stack[-1]
    assert dfa == g.dfas[g.start]
    assert len(dfa) == 2
    assert dfa[0] == []
    assert dfa[1] == [(0, 1)]
    assert state == 0
    assert node[0] == g.start
    assert node[1] is None
    assert node[2] is None
    assert node[3] == []


# Tests for Parser class
# XXX The tests use internal knowledge of the way the parser is
# implemented.  This should really be cleaned up,

# Generated at 2022-06-23 15:43:22.259942
# Unit test for method pop of class Parser
def test_Parser_pop():
    # import grammar
    # g = grammar.grammar
    g = Grammar()
    g.labels = None  # type: ignore
    g.tokens = None  # type: ignore
    g.keywords = None  # type: ignore
    g.start = None  # type: ignore
    stack = None  # type: List[None]
    dfa, state, node = None, 0, (None, None, None, [])
    stack.append((dfa, state, node))
    type, value, context, children = None, None, None, []
    newnode = (type, value, context, children)
    dfa, state, node = stack.pop()
    children.append(newnode)



# Generated at 2022-06-23 15:43:32.730462
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import token
    from .driver import assert_equal

    class MyParser(Parser):
        def pop(self):
            s = self.stack
            assert_equal(s, [(dfa, 0, n1), (dfa, 0, n2)])
            Parser.pop(self)
            assert_equal(s, [(dfa, 0, n1)])
            Parser.pop(self)
            assert_equal(s, [])
            assert_equal(self.rootnode, n1)
            self.rootnode = []

    g = grammar.grammar
    dfa = g.dfas[g.start]
    assert_equal(dfa[0][0], [])
    n1 = (g.start, None, None, [])
    n

# Generated at 2022-06-23 15:43:38.451301
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar()
    parser = Parser(grammar)
    parser.stack = [
        (0, 0, [(0, None, None, [])]),
        (0, 0, [(0, None, None, [])]),
    ]
    parser.pop()



# Generated at 2022-06-23 15:43:46.283862
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)

    assert p.classify(token.NAME, "foo", None) == g.keywords["NAME"]
    assert p.classify(token.LPAR, "(", None) == g.keywords["LPAR"]
    assert p.classify(token.NAME, "and", None) == g.keywords["and"]
    assert p.classify(token.OP, "x", None) == g.tokens[token.OP]



# Generated at 2022-06-23 15:43:52.514924
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Translation of the following statement into a unit test
    # p = Parser(Grammar)
    # p.stack = [('a', 1, 2)]
    # p.shift(type, value, newstate, context)
    p = Parser(Grammar)
    p.stack = [('a', 1, 2)]
    p.shift(1, 2, 3, 4)
    assert p.stack == [('a', 3, 2)]

# Generated at 2022-06-23 15:43:57.691462
# Unit test for method pop of class Parser
def test_Parser_pop():
    p = Parser(Grammar.from_read(None))
    p.setup()
    p.addtoken(1, "1", None)
    p.addtoken(2, "2", None)
    rootnode = p.rootnode

    assert rootnode.value == "1"
    assert rootnode.next_sibling.value == "2"



# Generated at 2022-06-23 15:44:05.348371
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Simple case, one single non-terminal
    grammar = Grammar(
        """
        start: expr;
        expr: NAME;
        """
    )

    # parser = Parser(grammar, lam_sub)
    parser = Parser(grammar)
    parser.setup()

    # Note that parser.addtoken returns True iff parsing is
    # finished. Hence, two calls to parser.addtoken() are necessary
    # to input the two tokens.
    parser.addtoken(token.NAME, "name_value", Context(None, 1, 0, None))
    parser.addtoken(token.SEMI, ";", Context(None, 1, 4, None))
    assert parser.rootnode.type == "start"
    assert parser.rootnode.children[0].type == "expr"
    assert parser.root

# Generated at 2022-06-23 15:44:13.142925
# Unit test for method addtoken of class Parser

# Generated at 2022-06-23 15:44:19.084464
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("testing", token.NAME, "foo", (1, 0))
    assert e.msg == "testing"
    assert e.type == token.NAME
    assert e.value == "foo"
    assert e.context == (1, 0)
    e = ParseError("testing", None, None, None)
    assert e.msg == "testing"
    assert e.type is None
    assert e.value is None
    assert e.context is None

# Generated at 2022-06-23 15:44:21.963189
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    def convert(g, n):
        if n[-1] is not None:
            n[-1] = [convert(g, x) for x in n[-1]]
        return n

    p = Parser(grammar.grammar, convert)
    p.setup(grammar.start)
    for token in grammar.tokenize("raise 42 from None"):
        p.addtoken(*token)
    assert p.rootnode[-1][0] == "(raise)"



# Generated at 2022-06-23 15:44:28.129206
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.driver

    grammar = blib2to3.pgen2.driver.load_grammar("Python", convert=lam_sub)
    p = Parser(grammar, convert=lam_sub)
    p.setup()
    p.addtoken(2, "def", Context("", 0, 0, 0))
    assert p.rootnode.children[0].children[0].value == "def"

# Generated at 2022-06-23 15:44:38.450951
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    x = ["""\
    lam: 'lam' NAME ':' test '.' test
    """]
    g = grammar.Grammar()
    g.parse(x)
    p = Parser(g)
    p.setup(g.symbol2number["lam"])
    p.addtoken(g.number2symbol[256], "lam", (1, 1))
    p.addtoken(g.number2symbol[257], "a", (1, 2))
    p.addtoken(g.number2symbol[258], ":", (1, 3))
    p.addtoken(g.number2symbol[259], "b", (1, 4))
    p.addtoken(g.number2symbol[260], ".", (1, 5))

# Generated at 2022-06-23 15:44:47.059445
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .pgen2 import driver
    from .token import NAME, STRING

    d = driver.Driver(
        [
            "def tokenize(s):",
            "    f = BytesIO(s)",
            "    p = Parser(feature_version=3)",
            "    p.setup(start='stmt')",
            "    t = tokenize_func(f.readline)",
            "    for (type, value, start, end, line) in t:",
            "        p.addtoken(type, value, (0, 0))",
            "    return p.rootnode",
        ]
    )
    p = d.pgen()
    p.setup(start="stmt")
    p.addtoken(NAME, "def", (1, 0))

# Generated at 2022-06-23 15:44:57.627928
# Unit test for method push of class Parser
def test_Parser_push():
    class DummyGrammar(object):
        start = 256
        dfas = (
            ([[(256, 0), (257, 0)]], {0: [], 1: [(257, 0)], 2: [(256, 1)]}),
            ([[(0, 2)], [(0, 1)]], {0: [], 1: [(257, 0)], 2: [(256, 1)]}),
        )
        labels = ((0, ""), (256, None), (257, None))
        tokens = {0: 0}

    class DummyParser(Parser):
        def __init__(self) -> None:
            Parser.__init__(self, DummyGrammar(), None)

    parser = DummyParser()
    parser.setup()

# Generated at 2022-06-23 15:45:03.547043
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    from . import grammar
    from .pygram import python_grammar_no_print_statement

    g = grammar.Grammar(python_grammar_no_print_statement)
    p = Parser(g)
    p.setup()
    assert p.stack[0][0] == g.dfas[g.start]
    assert p.rootnode is None



# Generated at 2022-06-23 15:45:05.659402
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", token.NAME, "name", None)
    except ParseError:
        pass

# Generated at 2022-06-23 15:45:14.063110
# Unit test for constructor of class Parser
def test_Parser():
    from . import pgen2, driver

    def convert(grammar, node):
        if node[0] == grammar.symbol2number.get("file_input"):
            node[0] = 1
            return None
        return node

    p = Parser(driver.Grammar(), convert)

    # Test default values
    assert p.grammar is driver.Grammar()
    assert p.convert is convert
    assert p.stack is None
    assert p.rootnode is None

    # Test setup()
    p.setup()
    assert p.stack == [(driver.Grammar().dfas[1], 0, (1, None, None, []))]

    # Test adding a token
    p.addtoken(1, "test", (1, 0))

# Generated at 2022-06-23 15:45:26.598317
# Unit test for method setup of class Parser
def test_Parser_setup():
    # This function tests the setup method of the Parser class.
    # It depends on the grammar module.
    # XXX The unit test has been disabled because it imports Python 3
    # grammar tables.
    return
    from . import driver
    p = driver.Driver(grammar.Grammar, "file")
    p.setup()
    p.addtoken(token.NEWLINE, "\n", (1, 0))
    p.addtoken(token.INDENT, "    ", (2, 0))
    p.addtoken(token.NAME, "if", (2, 4))
    p.addtoken(token.NAME, "x", (2, 7))
    p.addtoken(token.NAME, "is", (2, 9))
    p.addtoken(token.NAME, "not", (2, 12))
    p.add

# Generated at 2022-06-23 15:45:37.210042
# Unit test for method pop of class Parser
def test_Parser_pop():
    import blib2to3.pgen2.parse as parse

    class ConcreteGrammar(parse.Grammar):
        def __init__(self) -> None:
            self.start = 1
            self.labels: List[Tuple] = [
                (1, None),
                (2, None),
                (3, None),
                (4, None),
                (5, None),
                (6, None),
            ]

# Generated at 2022-06-23 15:45:47.397151
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = Grammar(Grammar.from_file(token.GRAMMAR_FILE))
    parser = Parser(grammar)
    parser.setup()
    result = parser.addtoken(token.NAME, "start", Context(0, 0)) == False
    result &= parser.addtoken(token.NAME, "my_name", Context(0, 0)) == False
    result &= parser.addtoken(token.EQUAL, "=", Context(0, 0)) == False
    result &= parser.addtoken(token.MBEGIN, "{", Context(0, 0)) == False
    result &= parser.addtoken(token.RIGHTSHIFT, ">>", Context(0, 0)) == False
    result &= parser.addtoken(token.TILDE, "~", Context(0, 0)) == False
    result

# Generated at 2022-06-23 15:45:52.015297
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar, driver
    from .tokenize import generate_tokens

    p = Parser(grammar.grammar)
    p.setup()
    t = generate_tokens(StringIO("pass").readline)
    t.next()  # throw away encoding token
    driver.untokenize(t, p)


# Generated at 2022-06-23 15:45:56.899337
# Unit test for function lam_sub
def test_lam_sub():
    n = (1, None, Context(0, 0), [(2, None, Context(0, 0), [(3, "a", Context(0, 0), None)])])
    assert lam_sub(None, n).leaves() == ["a"]

# Generated at 2022-06-23 15:46:04.079813
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar_parser

    g = grammar_parser.parsestring(
        """\
%ignore COMMENT
%left '-' '+'
%left '*' '/'
%left UMINUS
%nonassoc LESS
%%
expr: expr '+' expr
    | expr '-' expr
    | expr '*' expr
    | expr '/' expr
    | '-' expr %prec UMINUS
    | '(' expr ')'
    | NAME
    | NUMBER
%%
"""
    )
    Parser(g)

# Generated at 2022-06-23 15:46:11.852076
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.parse as parse
    parser = parse.Parser(parse.Grammar(), None)
    assert parser.classify(token.NAME, "foo", None) == 1
    assert parser.classify(token.NAME, "if", None) == 28
    assert parser.classify(token.STRING, "foo", None) == 3
    assert parser.classify(token.STRING, "", None) == 3
    assert parser.classify(-1, "foo", None) == 0

# Generated at 2022-06-23 15:46:22.633466
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    # Test the parser with a simple arithmetic expression grammar
    aexpr_grammar_text = """
    stmt: expr NEWLINE
    expr: expr PLUS term
        | expr MINUS term
        | term
    term: term TIMES factor
        | term DIVIDE factor
        | factor
    factor: NUMBER
    """
    aexpr_grammar = grammar.Grammar(grammar.pgen_grammar(aexpr_grammar_text))

# Generated at 2022-06-23 15:46:31.828494
# Unit test for method classify of class Parser
def test_Parser_classify():
    class MockGrammar:
        tokens: Dict[int, int] = {token.NAME: 47}
        labels: Sequence[Tuple[int, Text]] = [(47, "NAME")]
        keywords: Dict[str, int] = {"def": 456}

    parser = Parser(MockGrammar())
    assert parser.classify(token.NAME, "name", None) == 47
    assert parser.classify(token.NAME, "def", None) == 456
    try:
        parser.classify(token.OP, "+", None)
        assert False
    except ParseError as e:
        assert e.msg == "bad token"
        assert e.type == token.OP
        assert e.value == "+"
        assert e.context is None


# Generated at 2022-06-23 15:46:32.792110
# Unit test for constructor of class Parser
def test_Parser():
    grammar = Grammar()
    parser = Parser(grammar)

# Generated at 2022-06-23 15:46:39.061591
# Unit test for method shift of class Parser
def test_Parser_shift():
    """This function tests the shift() method of the class Parser."""
    # The shift() method is tested as a part of the addtoken() method
    # of the class Parser, which is more easily tested than the shift()
    # method alone.
    # TODO: write it.



# Generated at 2022-06-23 15:46:44.098781
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from .pgen import driver
    p = Parser(grammar.grammar)
    p.setup()
    assert p.stack == [(grammar.grammar.dfas[grammar.grammar.start], 0, (0, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()
    # Test the unit test
    p.setup()
    p.addtoken(driver.TYPE_COMMENT, " # Just a comment\n", (1, 0))
    p.addtoken(driver.TYPE_NL, "\n", (2, 0))



# Generated at 2022-06-23 15:46:53.511951
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.grammar

    grammar = blib2to3.pgen2.grammar.Grammar(grammar_sample)
    parser = Parser(grammar)
    assert parser.classify(token.NAME, "a", (1, 2)) == 2
    assert parser.classify(token.NAME, "b", (1, 2)) == 3
    assert parser.classify(token.NAME, "c", (1, 2)) == 4
    assert parser.classify(token.NAME, "a_123", (1, 2)) == 2
    assert parser.classify(token.NAME, "abc_123", (1, 2)) == 2



# Generated at 2022-06-23 15:47:02.847396
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import tokenize
    from . import grammar

    filename = "./test/test_grammar-py3-nobackup.txt"
    lines = open(filename).readlines()

    tokens = tokenize.generate_tokens(lines)
    p = Parser(grammar.grammar)
    p.setup()
    while True:
        try:
            (type, value, start, end, line) = tokens.next()
        except tokenize.TokenError as e:
            print("Token error: %s" % str(e))
            break
        except tokenize.StopTokenizing:
            break
        if type == token.OP:
            type = grammar.opmap[value]
        type = p.classify(type, value, start)
        if type == token.ENDMARKER:
            break

# Generated at 2022-06-23 15:47:08.232688
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import grammar, token

    class ParserTestCase(unittest.TestCase):
        def test_addtoken(self):
            pgen = grammar.ParserGenerator(["a"])
            g = pgen.build()
            p = Parser(g)
            p.setup()
            self.assertFalse(p.addtoken(token.NAME, "a", None))
            self.assertTrue(p.addtoken(token.ENDMARKER, "", None))
            self.assertRaises(ParseError, p.addtoken, token.NUMBER, "1", None)

    unittest.main()

# Generated at 2022-06-23 15:47:17.041388
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize_rt

    def convert(grammar: Grammar, node: RawNode) -> NL:
        return node[2]

    p = Parser(grammar.pgen_grammar, convert)
    p.setup(1)
    text = "  foo  "
    # 1  NL* single_input
    # 2  single_input_partial
    # 3  single_input_partial_part*
    # 4  single_input_partial_part
    # 5  NEWLINE | simple_stmt
    # 6  simple_stmt
    # 7  expr_stmt | assert_stmt | assignment | flow_stmt
    # 8  print_stmt
    # 9  'print' NAME
    # 10  NAME

# Generated at 2022-06-23 15:47:27.857927
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import re
    from . import pgen

    # Demonstrate that addtoken() can be called more than once.
    def parse_again(p: Parser, tok: Sequence[int]) -> Any:
        for t in tok:
            p.addtoken(t, 'x', None)
        return p.rootnode

    # Test specific addtoken() methods by calling them multiple times.
    def test_addtoken(tok: Sequence[int]) -> None:
        p = pgen.Driver()
        p.grammar = pgen.pgen()
        p.setup()
        p.addtoken(tok[0], 'x', None)
        for t in tok[1:]:
            p.addtoken(t, 'x', None)
        p.parsetokens(tok[-3:])

   

# Generated at 2022-06-23 15:47:34.497147
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(grammar.NT_OFFSET + 1, None, None)
    p.addtoken(grammar.NT_OFFSET + 2, None, None)
    p.addtoken(grammar.T_ENDMARKER, None, None)



# Generated at 2022-06-23 15:47:40.114695
# Unit test for method setup of class Parser
def test_Parser_setup():
    class thing(object):
        pass
    grammar = thing()
    grammar.dfas = {'dfas': []}
    grammar.start = 'start'
    grammar.labels = {'group': ()}
    p = Parser(grammar=grammar)
    p.setup()

# Generated at 2022-06-23 15:47:49.254776
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    testcases = {
        (token.NAME, "a", Context): False,
        (token.NAME, "def", Context): False,
        (token.NAME, "return", Context): False,
        (token.NAME, "b", Context): False,
        (token.NEWLINE, "", Context): True,
    }

    from . import grammar
    from .driver import Driver

    g = grammar.Grammar(token._dump_grammar_table(grammar.pgen))
    p = Parser(grammar=g, convert=None)
    p.setup()
    for testcase in testcases:
        assert p.addtoken(*testcase) == testcases[testcase]

# Generated at 2022-06-23 15:47:56.502179
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Generates a specific sequence of tokens, to test a specific behavior
    def gen_tokens(seq):
        offset = 0
        for (sn, sv) in seq:
            yield token.NUMBER, sn, Context(file="file.txt", line=1, offset=offset)
            offset += len(sn) + 1
            yield token.STRING, sv, Context(file="file.txt", line=1, offset=offset)
            offset += len(sv) + 1

    grammar = Grammar()

# Generated at 2022-06-23 15:48:05.102156
# Unit test for constructor of class Parser
def test_Parser():
    class MockGrammarEngine(object):
        def __init__(self) -> None:
            self.labels = {}
            self.tokens = {}
            self.dfas = {}

    geng = MockGrammarEngine()
    p = Parser(geng)
    assert p.grammar is geng
    p = Parser(geng, convert=lam_sub)
    assert p.grammar is geng
    assert p.convert is lam_sub

# Unit tests for methods of class Parser

# Generated at 2022-06-23 15:48:11.176936
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.parse
    # Test the shift() method by parsing a simple program
    class Grammar:
        start = 256
        dfas = {
            256: ([[(257, 1)], [(258, 2), (0, 2)], [(0, 2)]], {256: 0, 257: 1, 258: 2}),
            257: ([[(259, 3)], [(0, 3)]], {257: 0, 259: 1}),
            258: ([[(260, 4)], [(0, 4)]], {258: 0, 260: 1}),
        }
        tokens = {259: 257, 260: 258}

# Generated at 2022-06-23 15:48:19.288595
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    import io
    import sys
    sys.path.append("../..")
    from blib2to3.pygram import python_symbols as symbols
    from blib2to3.pgen2.parse import ParseError

    with io.open("../../Grammar/Grammar", "rb") as f:
        gr = driver.load_grammar(f)
    parse = Parser(gr, None)
    parse.setup()

    def check(seq):
        for t, v, c in seq:
            if parse.addtoken(t, v, c):
                break

    ctx = Context(0, 0, 0)
    check([(token.NAME, 'bla', ctx)])
    check([(token.NAME, 'foo', ctx)])

# Generated at 2022-06-23 15:48:22.095514
# Unit test for method setup of class Parser
def test_Parser_setup():
    import pgen2.grammar
    mygrammar = pgen2.grammar.Grammar()
    myconvert = Lam_sub(mygrammar, node)
    myparser = Parser(mygrammar, myconvert)
    myparser.setup(start)
    assert (len(myparser.stack) == 1)
    assert (myparser.rootnode == None)


# Generated at 2022-06-23 15:48:31.154785
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import token
    g = driver.get_grammar()

    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "3", None)
    assert p.addtoken(token.ADD, "+", None)
    assert p.addtoken(token.NUMBER, "4", None)
    assert p.addtoken(token.ENDMARKER, "", None)
    assert p.rootnode[0].type == "file_input"
    assert p.rootnode[0].context == None
    assert p.rootnode[0][0].type == "term"
    assert p.rootnode[0][0].context == None
    assert p.rootnode[0][0][0].type == "term"

# Generated at 2022-06-23 15:48:35.290282
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver

    grammar = driver.load_grammar("Grammar.txt")
    parse = Parser(grammar)
    parse.setup()
    for token_id in range(driver.tok_offsets[-1]):
        name = driver.tok_name[token_id]
        parse.classify(token_id, name, (1, 0))

# Generated at 2022-06-23 15:48:39.128840
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    import pytest
    with pytest.warns(UserWarning):
        g = grammar.Grammar()
    p = Parser(g, lam_sub)
    n = p.convert(g, (0, "?", None, []))
    assert n is None



# Generated at 2022-06-23 15:48:43.825223
# Unit test for constructor of class ParseError
def test_ParseError():
    # This is what should happen when a ParseError is caught.  The
    # error message should be a pretty-printed representation of the
    # exception.
    try:
        raise ParseError("msg", token.PLUS, "+", Context(None, 1, 2))
    except ParseError as err:
        assert str(err) == (
            "msg: type=token.PLUS, value='+', "
            "context=<Parser 2, line 1, offset 2>"
        )
        assert err.msg == "msg"
        assert err.type == token.PLUS
        assert err.value == "+"
        assert err.context == Context(None, 1, 2)
    else:
        raise RuntimeError("expected ParseError exception")



# Generated at 2022-06-23 15:48:51.999752
# Unit test for method push of class Parser
def test_Parser_push():
    """
    Push a nonterminal. This method is called every time the parser
    recognizes a new nonterminal. The new nonterminal is put at the
    end of the list of nonterminals stored at the stack.
    """
    parser = Parser(Grammar())
    parser.setup()
    #  (dfa, state, node)
    stackentry = (0, 0, 0)
    parser.stack.append(stackentry)
    parser.push(0, 0, 0, 0)
    assert parser.stack[-1] == stackentry
    assert parser.stack[-2] == (0, 0, 0)

# Generated at 2022-06-23 15:49:02.496374
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from blib2to3.pgen2 import token

    # Create a temporary grammar to hold this test
    g = grammar.Grammar()

    # Build an input node, containing a leaf and a node
    node = (0, None, None, [(1, "a", None, None), (2, None, None, [(3, "b", None, None)])])

    # Convert it
    newnode = lam_sub(g, node)

    # Make sure it looks like expected
    assert len(newnode) == 3
    assert newnode[0] == 0
    assert newnode[2] is None
    children = newnode[1]
    assert len(children) == 2
    assert children[0] == "a"
    assert children[1][0] == 2

# Generated at 2022-06-23 15:49:05.997159
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import token

    p = Parser(grammar)
    p.setup(token.STRING)
    assert p.stack == [(grammar.dfas[token.STRING], 0, (token.STRING, None, None, []))]
    assert p.rootnode is None



# Generated at 2022-06-23 15:49:08.027706
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar, symbols
    g = grammar.Grammar()
    lam_sub(g, (symbols.test2, None, (1,1), []))

# Generated at 2022-06-23 15:49:19.018942
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.pgen2.parse as parse
    import blib2to3.pgen2.token as token
    import blib2to3.pgen2.driver as driver
    import blib2to3.pytree as pytree

    driver.Expr = parse.Expr

    grammar = parse.expr_grammar
    parser = Parser(grammar, pytree.convert)
    parser.setup()

    for t in (3, 2, 4):
        parser.addtoken(token.NUMBER, '42', ((t, 1), (t, 2)))
    parser.addtoken(0, '', ((4, 1), (4, 2)))


# Generated at 2022-06-23 15:49:26.063125
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import driver

    import unittest

    from . import test_grammar

    class ParserPushTests(unittest.TestCase):

        grammar = grammar.grammar
        driver = driver.Driver(grammar, convert=lam_sub, logger=None)

        def parse(self, s: str) -> Sequence[Node]:
            nodes = self.driver.parse_string(s)
            self.assertEqual(len(nodes), 1)
            return nodes[0]

        def test_method_push_1(self):
            # Test method push (1)
            sn = test_grammar.syms
            ast = self.parse("1")
            self.assertEqual(ast.type, sn.file_input)

# Generated at 2022-06-23 15:49:37.504707
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import symbol
    from . import token

    from . import driver

    start = "file_input"
    driver.parse_tokens("", start, "")
    #print("---")

    driver.parse_tokens("a", start, "a")
    #print("---")

    driver.parse_tokens("a = 1", start, "a = 1")
    #print("---")

    driver.parse_tokens("a = 1\n", start, "a = 1")
    #print("---")

    driver.parse_tokens("if 1:\n  pass\n", start, "if 1:  pass")
    #print("---")

    driver.parse_tokens("pass # comment\n", start, "pass")
    #print("---")

    driver.parse_

# Generated at 2022-06-23 15:49:49.783728
# Unit test for constructor of class Parser
def test_Parser():
    import sys
    import pprint
    import StringIO
    from . import driver, token

    d = driver.Driver(grammar, convert=my_convert)
    s = sys.stdin.read()
    # Just for fun, let's parse the compiler's grammar input, so we
    # can print it!
    s = s.replace("'\\n'", "NL")  # Hack to make it parse
    g = d.parse_string(s, "single_input")
    # Print the grammar, using repr()
    oldstdout = sys.stdout

# Generated at 2022-06-23 15:50:00.591713
# Unit test for method pop of class Parser
def test_Parser_pop():
    class MyGrammar(Grammar):
        pass

    g = MyGrammar()
    g.start = 0
    g.labels = [(0, ''), (1, ''), (2, ''), (3, '')]
    g.keywords = {}
    g.tokens = {}
    g.dfas = {
        0: ([[(0, 0)], [(1, 3)]], {}),
        1: ([[(2, 1)], [(0, 2)]], {}),
        2: ([[(0, 2)], [(3, 2)]], {}),
        3: ([[(0, 3)], [(0, 3)]], {}),
    }

    def convert(grammar: MyGrammar, node: RawNode) -> Optional[RawNode]:
        assert node[3] is not None

# Generated at 2022-06-23 15:50:02.530358
# Unit test for method shift of class Parser
def test_Parser_shift():
    # working method - I don't see anything else to do.
    pass


# Generated at 2022-06-23 15:50:15.251862
# Unit test for method shift of class Parser
def test_Parser_shift():
    import sys
    import os
    import unittest
    import blib2to3.pygram as pygram

    class Test_Parser(unittest.TestCase):
        def setUp(self):
            self.parser = pygram.python_grammar_no_print_statement
            self.pygram_parser = Parser(self.parser)
            self.pygram_parser.setup()

            self.token = pygram.python_grammar_no_print_statement.number2symbol["NUMBER"]

            self.context = Context(
                (1, 1),
                "",
                "",
                1,
                self.token,
            )

            self.token2 = pygram.python_grammar_no_print_statement.number2symbol[
                "DEDENT"
            ]


# Generated at 2022-06-23 15:50:18.973148
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar/Grammar")
    parser = Parser(grammar)
    parser.setup()

    parser.shift(grammar.tokens[token.INDENT], " ", 0, (1, 0))
    assert parser.stack == [([([(0, 0)]), {}], 0, (None, None, None, []))]



# Generated at 2022-06-23 15:50:27.526666
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, tokenize

    this_grammar = """
        a_tok: "a"; b_tok: "b";
        x: a_tok b_tok | b_tok;
        y: x | y x ;
        """
    parse = Parser(grammar.Grammar(this_grammar))

    def lam_sub(grammar, node):
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    parse = Parser(grammar.Grammar(this_grammar), lam_sub)
    parse.setup()

    assert parse.addtoken(token.NAME, "a", None) == False
    assert parse.addtoken(token.NAME, "b", None) == True
    assert parse

# Generated at 2022-06-23 15:50:35.122576
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    g = Grammar()
    p = Parser(g)
    context = (0, 0)
    p.setup()
    assert p.rootnode is None
    assert not p.addtoken(0, "0", context)
    assert p.rootnode is None
    assert not p.addtoken(0, "0", context)
    assert p.rootnode is None
    assert p.addtoken(0, "0", context)
    assert p.rootnode is not None