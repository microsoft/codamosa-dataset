

# Generated at 2022-06-23 15:40:41.771111
# Unit test for method classify of class Parser
def test_Parser_classify():
    g = Grammar()
    p = Parser(g)
    p.grammar.keywords = {'T1': 1}
    p.grammar.tokens = {token.NAME: 2, 3: 3}
    assert p.classify(token.NAME, 'T1', None) == 1
    assert p.classify(token.NAME, 'T2', None) == 2
    assert p.classify(3, 'T3', None) == 3
    # This error is not reported because the parser class is not
    # ready yet.
    # try:
    #     p.classify(token.NAME, 'T2', None, "")
    # except ParseError:
    #     pass
    # else:
    #     assert 0
    p.setup()

# Generated at 2022-06-23 15:40:51.549422
# Unit test for function lam_sub
def test_lam_sub():
    # Test one branch of lam_sub
    def lsub(grammar, node):
        return node[3][0]
    grammar = Grammar(start=256)
    grammar.dfas = {256: ([], {0: 5, 1: 6, 2: 5})}
    p = Parser(grammar, lsub)
    p.setup()
    p.addtoken(token.NAME, "x", "line 1, offset 0")
    p.addtoken(token.NAME, "y", "line 1, offset 0")
    p.addtoken(256, "z", "line 1, offset 0")
    assert p.rootnode is None
    assert p.stack == [(grammar.dfas[256], 5, (256, None, None, ["y"]))]

# Generated at 2022-06-23 15:41:02.519121
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    # First, dump the generated tables
    driver.dump("Python.asdl")

    # Now, test addtoken() using the driver
    # Note: the import is local to this function
    c = driver.Parser("Python.asdl", "Module", convert=lam_sub)
    if c.addtoken(token.NAME, "bla", (1, 1)):
        raise AssertionError("addtoken should have raised ParseError")
    if c.stack:
        raise AssertionError("stack should be empty now")
    c.setup()

    if c.addtoken(token.NAME, "def", (1, 1)):
        raise AssertionError("addtoken should have raised ParseError")
    if c.addtoken(token.NAME, "foo", (1, 1)):
        raise

# Generated at 2022-06-23 15:41:07.946684
# Unit test for method push of class Parser
def test_Parser_push():
    parser = Parser(None)
    parser.push(1, None, 2, None)
    parser.push(1, None, 2, None)
    assert parser.stack == [(None, 2, (1, None, None, [])), (None, 2, (1, None, None, []))]

# Generated at 2022-06-23 15:41:10.916320
# Unit test for method classify of class Parser
def test_Parser_classify():
    g = Grammar()
    p = Parser(g)
    p.classify(token.NAME, "foo", (1, 2))
    p.classify(token.NAME, "if", (2, 3))

# Generated at 2022-06-23 15:41:16.730055
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("error", 42, "forty-two", "context")
    assert e.msg == "error"
    assert e.type == 42
    assert e.value == "forty-two"
    assert e.context == "context"

if __name__ == "__main__":
    test_ParseError()
    print("ParseError tests passed.")

# Generated at 2022-06-23 15:41:28.484313
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    g = grammar.grammar
    p = Parser(g, lam_sub)
    p.setup("file_input")
    p.addtoken(token.STRING, '"foo"', (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(token.STRING, '"bar"', (2, 0))
    p.addtoken(token.NEWLINE, "\n", (2, 5))
    assert p.rootnode == [(257, None, (1, 0), [[(4, '"foo"', (1, 0), None)]]),
                          (257, None, (2, 0), [[(4, '"bar"', (2, 0), None)]]),
                           (258, None, None, None)]

# Generated at 2022-06-23 15:41:30.735689
# Unit test for method push of class Parser
def test_Parser_push():
    def w_sub(grammar, node):
        print("w_sub called with", node)
        return node

    from . import grammar
    from . import token

    g = grammar.Grammar()
    p = Parser(g, w_sub)
    p.setup()
    p.push(g.symbol2number["expr"], (None, None), 0, None)

# Generated at 2022-06-23 15:41:36.347945
# Unit test for method pop of class Parser
def test_Parser_pop():
    stack = [
        (([[(1, 1)], [(0, 1)]], {1: 1}), 0, (1, None, None, [])),
        (([[(2, 2)], [(0, 2)]], {2: 2}), 0, (2, None, None, [])),
    ]
    dfa = (([[(1, 1)], [(0, 1)]], {1: 1}), 0, (1, None, None, []))
    Parser.pop(stack, dfa)
    assert stack == [(1, None, None, [2])]



# Generated at 2022-06-23 15:41:44.057074
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.pgen
    import blib2to3.pgen2.convert

    p = Parser(blib2to3.pgen2.pgen.Spec().grammar,
                          blib2to3.pgen2.convert.convert)
    # XXX  This test is not complete.  It is also not run by default.



# Generated at 2022-06-23 15:41:54.593844
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    from . import grammar
    from . import token

    gr = grammar.Grammar()
    gr.symbols = ['S', 'O', 'F', 'A']
    gr.keywords = {'o': 'O'}
    gr.tokens = dict([(token.NAME, 'A'),
                      (token.NUMBER, 'F'),
                      (token.NL, 'NL'),
                      (token.NEWLINE, 'NEWLINE'),
                      (token.ENDMARKER, 'ENDMARKER')])

# Generated at 2022-06-23 15:42:01.613622
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import pprint
    import sys
    import driver, blib2to3.pgen2

    # Parse the grammar into a Grammar object
    grammar = blib2to3.pgen2.parse_grammar(open("Grammar/Grammar"))

    # Make a Parser instance
    p = Parser(grammar)

    # Feed it tokens
    p.setup()

# Generated at 2022-06-23 15:42:12.843436
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def classify(type:int, value:Text, context:Context) -> int:
        return type

    def convert(grammar:Grammar, node:RawNode) -> NL:
        assert node[3] is not None
        return Node(type=node[0], children=node[3])


# Generated at 2022-06-23 15:42:18.504195
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from blib2to3.pgen2.pgen import generate_grammar

    g = generate_grammar()
    def pg(rulestr, start=None):
        return Parser(g, converter=grammar.convert).parse(rulestr, start)
    p = pg('a | b')
    assert isinstance(p, grammar.Grammar)
    p = pg('a | b', 'c')
    assert isinstance(p, grammar.Grammar)


# Generated at 2022-06-23 15:42:29.599886
# Unit test for method push of class Parser
def test_Parser_push():
    class TestGrammar(Grammar):
        pass

    class TestParser(Parser):
        def __init__(self):
            super(TestParser, self).__init__(TestGrammar())

    tp = TestParser()
    tp.setup()
    tp.push(0, ({0: {(0, 1): (1, 2)}}, {0: 1}), 0, {})
    assert tp.stack == [({0: {(0, 1): (1, 2)}}, 1, (0, None, None, [])),
                       ({0: {(0, 1): (1, 2)}}, 0, (0, None, None, []))]

    tp.setup()

# Generated at 2022-06-23 15:42:33.331837
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammars
    from . import driver

    parser = Parser(grammars.Grammar())
    tokens = driver.test_tokens()
    parser.setup()
    for token in tokens:
        parser.addtoken(*token)
    parser.pop()

# Generated at 2022-06-23 15:42:39.435071
# Unit test for method setup of class Parser
def test_Parser_setup():
    import pytest
    from blib2to3.pgen2.grammar import Grammar, GrammarError
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.pgen import (
        generate_grammar,
        driver,
        read_grammar,
    )
    from . import token, driver as _driver
    from .tokenize import generate_tokens

    with pytest.raises(GrammarError):
        # No grammar loaded
        p = Parser(None)
        with pytest.raises(ValueError):
            # Fail to set start symbol
            p.setup(None)


# Generated at 2022-06-23 15:42:50.710159
# Unit test for method push of class Parser

# Generated at 2022-06-23 15:43:03.710206
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    class Parse(Parser):
        def __init__(self, grammar: Grammar, test_case: List[int]) -> None:
            super().__init__(grammar)
            self.tests = test_case

        def addtoken(
            self, type: int, value: Optional[Text], context: Context
        ) -> bool:
            if self.tests:
                type = self.tests.pop(0)
            else:
                return True
            return super().addtoken(type, value, context)

    def run_parser(
        grammar_string: Text, tokens: Sequence[int], start: Optional[int] = None
    ) -> None:
        g = grammar.grammar()
        g.parse(grammar_string)
        p = Parse(g, tokens)

# Generated at 2022-06-23 15:43:12.564832
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver

    # A grammar for simple expressions
    grammar = driver.build_grammar("""
        expr:
            expr '+' term
            | expr '-' term
            | term

        term:
            term '*' factor
            | term '/' factor
            | factor

        factor:
            '(' expr ')'
            | NAME

        """)
    # A low-level parser
    parser = Parser(grammar)

    # A table of tokens

# Generated at 2022-06-23 15:43:13.457516
# Unit test for method shift of class Parser
def test_Parser_shift():
    assert False

# Generated at 2022-06-23 15:43:23.253913
# Unit test for method classify of class Parser
def test_Parser_classify():
    import pprint
    g = Grammar()  # type: Grammar

# Generated at 2022-06-23 15:43:33.484741
# Unit test for method push of class Parser
def test_Parser_push():
    # static object
    def staticobject(self, gram: Grammar, node: Union[Node, Leaf]) -> Union[Node, Leaf]:
        if node[3]:
            ret = Node(type=node[0], children=node[3], context=node[2])
        else:
            ret = Leaf(type=node[0], value=node[1], context=node[2])
        return ret

    pars = Parser(Grammar(open("Python.asdl").read()), staticobject)
    pars.setup(1)
    pars.addtoken(token.LBRACE, '{', (1, 0))
    pars.addtoken(token.NAME, 'a', (1, 1))
    pars.addtoken(token.EQUAL, '=', (1, 3))

# Generated at 2022-06-23 15:43:45.566659
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import pgen2
    import io

    r_program = driver.parse_string(pgen2.grammar, """\
    x = 1 + 2 * 3
    """)

# Generated at 2022-06-23 15:43:54.138103
# Unit test for method pop of class Parser
def test_Parser_pop():
    from _ast import Module, expr, Expr

    grammar = Grammar()
    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NAME, "Module", Context(1, 1))
    p.addtoken(token.NEWLINE, "", Context(1, 1))
    p.addtoken(token.NEWLINE, "", Context(1, 1))
    p.addtoken(token.ENDMARKER, "", Context(1, 1))
    assert isinstance(p.rootnode, Module)
    assert isinstance(p.rootnode.children[0], Expr)

# Generated at 2022-06-23 15:43:54.777798
# Unit test for method pop of class Parser
def test_Parser_pop():
    assert 0

# Generated at 2022-06-23 15:43:56.581087
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar(pgen_grammar), lam_sub)
    p.setup()

# Generated at 2022-06-23 15:44:00.853712
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("foo", "bar", "spam", "eggs")
    except ParseError as e:
        assert e.msg == "foo"
        assert e.type == "bar"
        assert e.value == "spam"
        assert e.context == "eggs"
    else:
        raise AssertionError("ParseError raised no exception")

# Generated at 2022-06-23 15:44:06.336469
# Unit test for constructor of class ParseError
def test_ParseError():
    err_type = token.NAME
    err_value = "xyz"
    err_context = Context(0, 0)
    err = ParseError("test", err_type, err_value, err_context)
    assert err.msg == "test"
    assert err.type == err_type
    assert err.value == err_value
    assert err.context == err_context

# Generated at 2022-06-23 15:44:11.221788
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver, pgen2

    gram = pgen2.load_grammar("Grammar/Grammar", "test-shift", logging.getLogger())
    parsed = driver.Driver(gram, "test-shift").run_parser()
    assert parsed[0][1] == '\n'


# Generated at 2022-06-23 15:44:17.992689
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest
    import sys
    from unittest.mock import patch
    from io import StringIO
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.token import *
    from blib2to3.pgen2 import driver, parse

    grammar = Grammar(grammar_file)
    p = Parser(grammar)
    p.classify(token.NAME, "name", (0, 0))
    p.classify(NAME, "name", (0, 0))
    p.classify(token.NAME, "name", (0, 0))
    p.classify(NAME, "name", (0, 0))
    p.classify(NUMBER, "NUMBER", (0, 0))

# Generated at 2022-06-23 15:44:21.797756
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Testing", token.INDENT, None, None)
    except ParseError as e:
        assert e.msg == "Testing"
        assert e.type == token.INDENT
        assert e.value is None
        assert e.context is None
    else:
        raise SystemExit("Failed to raise ParseError")


if __name__ == "__main__":
    import unittest

    unittest.main("blib2to3.pgen2.parser", verbosity=2)

# Generated at 2022-06-23 15:44:32.486141
# Unit test for method classify of class Parser
def test_Parser_classify():
    print("Testing class Parser, method classify")
    from . import driver

    driver.verbose = 0
    p = Parser(driver.Grammar)
    p.setup()
    p.addtoken(token.MINUS, "-", (1, 1))
    p.addtoken(token.NAME, "x", (1, 2))
    p.addtoken(token.MINUS, "-", (1, 3))
    p.addtoken(token.NAME, "y", (1, 4))
    p.addtoken(token.PLUS, "+", (1, 5))
    p.addtoken(token.NAME, "z", (1, 6))
    p.addtoken(token.NEWLINE, "\n", (1, 7))
    assert p.rootnode[0] == driver.Grammar.symbol2number

# Generated at 2022-06-23 15:44:36.943913
# Unit test for function lam_sub
def test_lam_sub():
    class MockGrammar(object):
        def __init__(self):
            self.tree_grammar = True

    grammar = MockGrammar()
    node = (1, "Foo", None, [])
    res = lam_sub(grammar, node)
    assert res == [1, "Foo", None, []]

# Generated at 2022-06-23 15:44:45.828941
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2 import token
    from . import driver

    gr = Grammar('''
        start:
            sum
        sum:
            sum '+' term
            | sum '-' term
            | term
        term:
            term '*' factor
            | term '/' factor
            | factor
        factor:
            '(' sum ')'
            | NAME
            | NUMBER
        ''')
    p = Parser(gr)
    p.setup()
    p.addtoken(token.NAME, "hello", (1, 0))
    p.addtoken(token.NUMBER, 3, (1, 2))
    p.addtoken(token.OP, "*", (1, 3))
    p.add

# Generated at 2022-06-23 15:44:57.125495
# Unit test for method push of class Parser
def test_Parser_push():
    import blib2to3.pgen2.driver
    from . import parse as _parse
    grammar = blib2to3.pgen2.driver.load_grammar(
        "blib2to3.pgen2.parse.grammar"
    )
    p = _parse.Parser(grammar, lam_sub)
    p.setup()
    p.addtoken(1, "int", (1, 0))
    assert p.rootnode == None
    p.addtoken(1, "a", (1, 3))
    p.addtoken(11, "=", (1, 4))
    assert p.rootnode == None
    p.addtoken(3, "3", (1, 5))
    assert p.rootnode != None
    p.addtoken(0, None, (1, 6))
   

# Generated at 2022-06-23 15:45:07.501910
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar()
    grammar.dfas = {
        "init": ([[(1, 1), (2, 1)], [(0, 2)]], {1: 0, 2: 0}),
        "stmt": ([[(2, 1), (3, 1)], [(0, 2), (1, 2)]], {1: 0, 2: 1}),
    }
    grammar.start = "init"
    grammar.labels = {1: (token.NAME, "x"), 2: (token.NAME, "y"), 3: (token.NAME, "z")}
    grammar.keywords = {"x": 2}
    grammar.tokens = {token.NAME: 1, token.NEWLINE: 3}
    lam = lam_sub

# Generated at 2022-06-23 15:45:15.095816
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def assert_raises(exc, func, *args):
        try:
            func(*args)
        except exc:
            pass
        else:
            print("%s(%s) did not raise %s" % (func, args, exc))

    from . import grammar, driver, token

    p = Parser(grammar)
    p.setup()
    assert_raises(ParseError, p.addtoken, token.NAME, "abc", (9, 0))
    p.addtoken(token.NAME, "abc", (9, 0))
    assert_raises(ParseError, p.addtoken, token.NAME, "xyz", (9, 0))
    p.addtoken(token.DOT, ".", (9, 0))

# Generated at 2022-06-23 15:45:25.665117
# Unit test for method shift of class Parser
def test_Parser_shift():
    dfa = [((9, 1),)]
    grammar = Grammar(start=1, dfas=[[dfa, None]],
                      labels=[(token.NUMBER, "NUMBER")], tokens={token.NUMBER: 0})
    parser = Parser(grammar)
    parser.setup()
    assert parser.addtoken(token.NUMBER, "3", (1, 0))
    assert parser.rootnode is not None
    assert str(parser.rootnode) == "1"
    child = parser.rootnode[0]
    assert child.type == token.NUMBER
    assert child.value == "3"
    assert child.context == (1, 0)


# Generated at 2022-06-23 15:45:32.002881
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import test_grammar

    my_grammar = test_grammar.get_grammar()
    my_parser = Parser(my_grammar)
    my_parser.setup()
    my_parser.addtoken(
        token.NAME, "class", (1, 0),
    )  # Should return False, not raise

# Generated at 2022-06-23 15:45:39.798583
# Unit test for method classify of class Parser
def test_Parser_classify():
    """
    >>> g = Grammar()
    >>> g.keywords['if'] = 1
    >>> g.keywords['then'] = 2
    >>> g.keywords['else'] = 3
    >>> g.tokens[token.NUMBER] = 4
    >>> p = Parser(g)
    >>> p.classify(token.NAME, 'if', (1, 0))
    1
    >>> p.classify(token.NUMBER, '3.14', (2, 0))
    4
    >>> p.classify(token.NAME, 'name', (3, 0))
    Traceback (most recent call last):
    ParseError: bad token: type='NAME', value='name', context=(3, 0)
    """


# Generated at 2022-06-23 15:45:51.417457
# Unit test for method push of class Parser
def test_Parser_push():
    class FakeGrammar:
        dfas = {
            1: (
                [
                    [],
                    [(1, 1), (3, 2)],
                    [(0, 2)],
                    [(2, 3)],
                    [(0, 4)],
                ],
                {1, 2},
            ),
            2: (
                [
                    [],
                    [(2, 5)],
                    [],
                    [],
                    [],
                    [(1, 6), (0, 5)],
                    [(0, 7)],
                ],
                {6, 7},
            ),
        }

    class FakeParser:
        stack: List[Tuple[DFAS, int, RawNode]] = [(None, 0, None), (None, 0, None)]

    parser = FakeParser()

# Generated at 2022-06-23 15:46:03.383832
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, tokenize

    import unittest

    # Parse with a mock grammar and convert function that just returns
    # what is passed in.

# Generated at 2022-06-23 15:46:05.812724
# Unit test for method classify of class Parser
def test_Parser_classify():
    test_grammar = Grammar()
    parser = Parser(test_grammar)

# Generated at 2022-06-23 15:46:17.258273
# Unit test for constructor of class Parser
def test_Parser():
    import sys
    import tokenize
    from io import StringIO
    import pprint
    pp = pprint.PrettyPrinter(stream=sys.stdout)
    from . import grammar
    gram = grammar.Grammar()
    p = Parser(gram)
    p.setup()
    input = StringIO(u"def f(x): return 1+x\n")
    tokengen = tokenize.generate_tokens(input.readline)
    for ttype, value, start, end, line in tokengen:
        if ttype == token.ENCODING:
            continue
        endrow, endcol = end
        context = (start[0], endcol)
        p.addtoken(ttype, value, context)
        if p.rootnode is not None:
            break

# Generated at 2022-06-23 15:46:25.367487
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    from . import driver

    g = grammar.Grammar()
    g.load("Grammar.txt")
    g.start = "file_input"
    p = Parser(g)
    p.setup()
    d = driver.Driver(p.addtoken, g)
    d.reset("")
    result = p.rootnode
    assert result.children == [NL()]
    p.setup(start="single_input")
    d.reset("")
    result = p.rootnode
    assert result.children == [NL()]

# Generated at 2022-06-23 15:46:33.524193
# Unit test for method setup of class Parser
def test_Parser_setup():
    # code taken from parse_grammar.py
    # Modify this code to include a test for method setup of class Parser.
    # import logging
    from .pgen2 import driver
    g = driver.load_grammar("Grammar/Grammar")
    # logging.basicConfig()
    # logging.getLogger('blib2to3.pgen2.parse').setLevel(logging.DEBUG)
    p = Parser(g)
    # print (dir(p))
    # print ('p.grammar:', p.grammar)
    # print ('p.convert:', p.convert)
    # print ('p.setup:', p.setup)
    print('p.setup(1):', p.setup(1))
    return

if __name__ == '__main__':
    test

# Generated at 2022-06-23 15:46:34.504603
# Unit test for constructor of class Parser
def test_Parser():
    pass



# Generated at 2022-06-23 15:46:42.837941
# Unit test for constructor of class Parser
def test_Parser():
    from .grammar import Grammar

    class DummyGrammar(Grammar):
        """A dummy grammar for this unit test
        """

        dfas: Sequence[DFA] = [
            [
                [(1, 1)],
                [(1, 1)],
                [(1, 1)],
                [(1, 1)],
                [(1, 1)],
                [(1, 1)],
                [(1, 1)],
            ],
            [
                [(1, 1)],
                [(1, 1)],
                [(1, 1)],
                [(1, 1)],
                [(1, 1)],
                [(1, 1)],
                [(1, 1)],
            ],
        ]

        def __init__(self) -> None:
            Grammar.__init__(self)
            self

# Generated at 2022-06-23 15:46:46.646216
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("msg", token.PLUS, "+", (1, 2))
    assert err.msg == "msg"
    assert err.type == token.PLUS
    assert err.value == "+"
    assert err.context == (1, 2)


# Generated at 2022-06-23 15:46:57.531702
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest

    class ParserTestCase(unittest.TestCase):
        def setUp(self) -> None:
            self.parser = Parser(grammar)

        def test_addtoken(self) -> None:
            self.parser.setup("stmts")
            self.parser.addtoken(token.NAME, "a", None)
            self.parser.addtoken(token.EQUAL, "=", None)
            self.parser.addtoken(token.NAME, "b", None)
            self.parser.addtoken(token.SEMI, ";", None)
            tree = self.parser.rootnode
            self.assertEqual(tree[0].type, symbol.stmts)
            self.assertEqual(len(tree[0]), 1)

# Generated at 2022-06-23 15:47:07.339344
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    p = Parser(grammar.grammar)
    p.setup()
    import blib2to3.pgen2.tokenize
    blib2to3.pgen2.tokenize
    leaf = Leaf(type=0, value=1, context=2)
    assert leaf.type == 0
    assert leaf.value == 1
    assert leaf.context == 2
    p.shift(0, 1, 2, 3)
    dfa, state, node = p.stack[-1]
    assert dfa == p.grammar.dfas[p.grammar.start]
    assert state == 2
    assert node[-1] is not None
    assert len(node[-1]) == 1
    assert node[-1][-1] == leaf

# Generated at 2022-06-23 15:47:16.408721
# Unit test for constructor of class ParseError
def test_ParseError():

    def assert_raises(exc_type, exc, func, *args):
        try:
            func(*args)
        except exc_type as e:
            # check that e is our expected exception
            assert e == exc, (e, exc)
        else:
            raise AssertionError('%s exception not raised' % exc_type)

    def test_raises():

        def test_trivial_message():
            e = ParseError('test', None, None, None)
            assert e.msg == 'test'
            assert e.type == None
            assert e.value == None
            assert e.context == None

        def test_non_trivial_message():
            e = ParseError('test', 1, 'a', None)
            assert e.msg == 'test'
            assert e.type == 1

# Generated at 2022-06-23 15:47:23.967922
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .pgen2 import driver

    def calling(input):
        p = Parser(driver.grammar, driver.convert)
        p.setup()
        for type, value, context in input:
            p.addtoken(type, value, context)
        return p.rootnode

    input = [(token.NAME, "abc", Context(1, 2)), (token.NAME, "def", Context(2, 3))]
    def test(input):
        print(calling(input))
    test(input)

# Generated at 2022-06-23 15:47:29.583779
# Unit test for constructor of class Parser
def test_Parser():
    gr = Grammar(r'TLabel : NAME | NUMBER | LPAREN')
    pa = Parser(gr)
    pa.addtoken(token.NAME, "a", None)
    pa.addtoken(token.NUMBER, "1", None)
    pa.addtoken(token.LPAREN, "(", None)
    pa.addtoken(token.NAME, "b", None)
    pa.addtoken(token.RPAREN, ")", None)


# Generated at 2022-06-23 15:47:39.031728
# Unit test for constructor of class Parser
def test_Parser():
    import unittest
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pytree as pytree
    import blib2to3.pygram as pygram
    import test.test_support

    class ParserTestCase(unittest.TestCase):
        def test_Parser(self):
            grammar_data = grammar.grammar_data

            # Create the grammar
            g = grammar.Grammar(grammar_data, pygram.python_grammar_no_print_statement)

            # Create the parser
            p = Parser(g)

            # Test the addtoken method
            for start in range(256, len(g.labels)):
                assert p.addtoken(token.NAME, "<TEST>", Context(0, 0, None))

            p.setup

# Generated at 2022-06-23 15:47:49.831481
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import python_grammar
    from . import driver
    import io

    class FauxGrammar:
        def __init__(self, dfas):
            self.dfas = dfas
        def __getitem__(self, key):
            return self.dfas[key]
    class FauxGrammarDfas:
        def __init__(self, _dfas):
            self._dfas = _dfas
        def __getitem__(self, key):
            return self._dfas[key]
    class FauxDFAS:
        def __init__(self, states):
            self.states = states
    class FauxStates:
        def __init__(self, states):
            self.states = states


# Generated at 2022-06-23 15:48:01.516165
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2.grammar import Grammar
    g = Grammar()
    g.start = 1
    g.dfas = {1: (DFA, {0: 0})}
    p = Parser(g, lam_sub)
    p.setup()
    p.addtoken(token.NAME, "foo", Context(1, 1))
    p.addtoken(token.PLUS, "+", Context(1, 4))
    p.addtoken(token.NAME, "bar", Context(1, 6))
    root = p.rootnode
    print(root)
    assert len(root) == 3
    assert root[0] == "foo"
    assert root[1] == "+"
    assert root[2] == "bar"
test_lam_sub.__test__ = False

# Generated at 2022-06-23 15:48:12.450814
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .grammar import Grammar
    g = Grammar(root_grammar="Grammar")
    p = Parser(g)
    p.setup()
    p.shift(0, "example", 0, None)
    assert p.stack[-1][-1] == (32, None, None, [])
    p.shift(1, "x", 0, None)
    assert p.stack[-1][-1] == (32, None, None, [(1, 'x', None, None)])
    p.shift(2, "xx", 0, None)
    assert p.stack[-1][-1] == (32, None, None, [(1, 'x', None, None), (2, 'xx', None, None)])
    assert p.rootnode is None

# Generated at 2022-06-23 15:48:20.844200
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar()
    lam_sub(grammar, (1, "foo", None, [2]))
    lam_sub(grammar, (1, None, None, [2, 3]))
    lam_sub(grammar, (1, None, None, [2, 3]))
    lam_sub(grammar, (1, "foo", None, []))
    lam_sub(grammar, (1, "foo", None, None))

# Generated at 2022-06-23 15:48:27.820301
# Unit test for method push of class Parser
def test_Parser_push():
    from .driver import Driver
    from . import pgen2
    from .grammar import Grammar

    driver = Driver(pgen2.tokenize, pgen2.parsestr)
    parser = Parser(Grammar(), driver.driver)
    parser.setup()

    driver.grammar = parser.grammar
    driver.buildtree(pgen2.parsestr("a = 1"))
    parser.push(40, (10, 20), 30, 40)
    assert parser.stack == [(10, 20, 30, 40), (10, 20, 30, 40)]

# Generated at 2022-06-23 15:48:39.124534
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Stress test the addtoken method of the Parser class."""
    import sys
    import time
    import test.test_support
    from test.test_parse import generate_grammar, pickle, unpickle

    grammar = generate_grammar()
    gs = pickle(grammar)
    g2 = unpickle(gs)
    p = Parser(g2, lam_sub)
    p.setup()
    p.addtoken(token.LPAR, "(", (1, 0))
    p.addtoken(token.NAME, "a", (1, 1))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NAME, "b", (1, 3))
    p.addtoken(token.RPAR, ")", (1, 4))
    p

# Generated at 2022-06-23 15:48:45.361367
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar())

    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(None, 2, (None, None, None, [('1', 'a', None, None)]))]
    p.shift(2, "b", 3, None)
    assert p.stack == [(None, 3, (None, None, None, [('1', 'a', None, None), ('2', 'b', None, None)]))]
    p.addtoken(1, "c", None)
    assert p.stack == [(None, 3, (None, None, None, [('1', 'a', None, None), ('2', 'b', None, None), ('1', 'c', None, None)]))]



# Generated at 2022-06-23 15:48:54.361421
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import token

    from . import pgen2

    gram = pgen2.driver.load_grammar("Grammar/Grammar")
    par = Parser(gram)
    par.setup()
    par.shift(token.NUMBER, "1", -1, None)
    assert par.stack == [
        (gram.dfas[gram.start], -1, (gram.start, None, None, [Leaf(token.NUMBER, "1", None)]))
    ]


# Generated at 2022-06-23 15:49:04.403467
# Unit test for method push of class Parser
def test_Parser_push():
    def test_input():
        p = Parser(Grammar(), None)
        dfa1: DFAS = ([[(1, 1), (0, 1)]], {0: 1, 1: 1})
        dfa2: DFAS = ([[(2, 2), (0, 2)]], {0: 2, 2: 2})
        dfa3: DFAS = ([[(3, 3), (0, 3)]], {0: 3, 3: 3})
        p.stack = [(dfa1, 1, (1, None, None, None))]
        p.push(2, dfa2, 2, None)
        p.push(3, dfa3, 3, None)
        p.stack.pop()
        assert p.stack == [(dfa1, 1, (1, None, None, None))]

# Generated at 2022-06-23 15:49:07.415125
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from blib2to3.pgen2 import driver

    f = driver.load_grammar("Grammar.txt")
    g = grammar.Grammar(f)

    p = Parser(g)
    p.setup()
    p.addtoken(1, 'test', None)

# Generated at 2022-06-23 15:49:18.219426
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Unit test for method addtoken of class Parser

    """
    # Check for token too large
    from blib2to3.pgen2 import grammar
    g = grammar.Grammar()
    g.start = 257
    g.dfas = {257: ([[(258, 0)]], set([258]))}
    g.labels = [(258, (token.NUMBER, "3"))]
    p = Parser(g)
    p.setup()
    try:
        p.addtoken(token.NUMBER, "4", (0, 0))
    except ParseError:
        pass
    else:
        assert False, "Should have raised a ParseError"

    # Check for token that doesn't match the grammar
    g = grammar.Grammar()
    g.start = 257
    g.df

# Generated at 2022-06-23 15:49:25.539456
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    p = Parser(grammar, None)
    p.setup(1)  # 1 is stmt
    try:
        p.addtoken(token.NAME, "a", None)
    except ParseError:
        pass
    else:
        raise Exception("expected exception")

    p = Parser(grammar, None)
    p.setup(1)  # 1 is stmt
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NEWLINE, None, None)
    assert p.stack == [(([(12, 1)], {1: [(-2, 1), (15, 1), (1, 2)]}), 2, (1, None, None, [[(5, 'a', None, None)]]))]


# Local variables:
#

# Generated at 2022-06-23 15:49:36.994738
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    parserclass = gen_parser_class()
    parser = parserclass(grammar, None)
    parser.setup()
    parser.addtoken(1, 'token', 2)
    parser.addtoken(3, 'token', 2)
    parser.addtoken(1, 'token', 2)

# Generated at 2022-06-23 15:49:43.880869
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import driver
    grammar = grammar.grammar
    parser = Parser(grammar)
    parser.setup()
    parser.classify(token.NAME, "foo", None)
    parser.classify(token.NAME, "True", None)
    parser.classify(token.NAME, "False", None)
    parser.classify(token.NAME, "None", None)
    parser.classify(token.NAME, "__name__", None)
    try:
        parser.classify(token.NAME, "__file__", None)
    except ParseError as e:
        assert e.msg == "bad token"
        assert e.type == token.NAME
        assert e.value == "__file__"

# Generated at 2022-06-23 15:49:44.590765
# Unit test for method shift of class Parser
def test_Parser_shift():
    pass

# Generated at 2022-06-23 15:49:49.565856
# Unit test for constructor of class ParseError
def test_ParseError():
    # Verify the constructor sets attributes properly
    e = ParseError("foo", 1, 2, 3)
    assert e.msg == "foo"
    assert e.type == 1
    assert e.value == 2
    assert e.context == 3
    # Verify string representation
    assert str(e) == "foo: type=1, value=2, context=3"

# Generated at 2022-06-23 15:49:53.130394
# Unit test for method shift of class Parser
def test_Parser_shift():
    import os, sys, tempfile
    from blib2to3.pgen2 import driver
    from blib2to3.pgen2 import grammar, token, tokenize


# Generated at 2022-06-23 15:50:01.452514
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = object()
    convert = object()
    context = object()
    parser = Parser(grammar, convert)
    assert parser.grammar is grammar
    assert parser.convert is convert
    assert parser.stack is None
    assert parser.rootnode is None
    parser.shift(1, 'value', 2, context)
    assert parser.stack == [([([(0, 0)], {0: {0: 2}}), (1, 'value', context, None)], 2, [])]

# Generated at 2022-06-23 15:50:14.607338
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from ..tokenize import generate_tokens, tokenize, untokenize, NUMBER
    from . import grammar
    # With a non-conforming token sequence, addtoken must signal an exception
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    tgt = [
        (tokenize.ENCODING, "ISO-8859-1", (1, 0), (1, 0), ""),
        (token.ENDMARKER, "", (1, 0), (1, 0), ""),
    ]

# Generated at 2022-06-23 15:50:20.373422
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pprint
    import pickle
    import pickletools
    #p = Parser(pickle.grammar)
    #p.setup()
    #print("-" * 50)
    #for i in pickletools.genops(pickle.dumps(p)):
    #    print(i)
    #print("-" * 50)


# Convenience function

# Generated at 2022-06-23 15:50:24.183235
# Unit test for method classify of class Parser
def test_Parser_classify():
    g = Grammar("""
        start: foo
        foo: NAME
        """)
    p = Parser(g)
    p.setup()
    try:
        p.classify(token.NAME, "foo", None)
    except ParseError:
        assert 0, "unexpected exception"


# Generated at 2022-06-23 15:50:36.591005
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver
    from . import generic

    def parse(str: Text) -> Sequence[int]:
        tokens = driver.generate_tokens(str)

        class fake_grammar(object):
            tokens = {token.NUMBER: 1, token.NAME: 2, token.STRING: 3}