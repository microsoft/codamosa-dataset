

# Generated at 2022-06-23 15:40:34.188271
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", token.PLUS, "+", None)
    except ParseError as exc:
        assert exc.msg == "msg"
        assert exc.type == token.PLUS
        assert exc.value == "+"
        assert exc.context is None
    else:
        raise AssertionError("Expected a ParseError exception")

# Generated at 2022-06-23 15:40:45.622684
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, token
    from .pgen import PgenGlobal

    p = Parser(PgenGlobal.grammar)
    p.setup()
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "else", None)
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "else", None)
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "else", None)
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "else", None)
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "else", None)
   

# Generated at 2022-06-23 15:40:46.214116
# Unit test for method push of class Parser
def test_Parser_push():
    assert 1 == 1

# Generated at 2022-06-23 15:40:56.737815
# Unit test for method pop of class Parser
def test_Parser_pop():
    # pgrammar.py doesn't define a ParseError
    try:
        from blib2to3.pgen2.pgen import ParseError
    except ImportError:
        ParseError = Exception
    p = Parser(Grammar())
    try:
        p.pop()
        assert False
    except ParseError:
        pass
    p.setup()
    for t in [(token.NUMBER, '1', 1), (token.NAME, 'a', 1), (token.ENDMARKER, '', 1)]:
        assert not p.addtoken(*t)
    assert p.stack
    p.pop()
    assert not p.stack
    assert p.rootnode.type == token.file_input

# Generated at 2022-06-23 15:41:06.715636
# Unit test for method push of class Parser
def test_Parser_push():
    """Test the method push of class Parser."""
    class MockedParser(Parser):

        def __init__(self, grammar, convert=None):
            self.stack = [[]]
            self.rootnode = None

        def convert(self, grammar, node):
            return node

    p = MockedParser(None)
    type = 42
    dfa = []
    newstate = 0
    context = None

    p.push(type, dfa, newstate, context)
    assert p.stack == [[], [(dfa, 0, (type, None, context, []))]]



# Generated at 2022-06-23 15:41:13.684157
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Setup a grammar with a single production and a single terminal
    from . import grammar

    g = grammar.Grammar()
    g.start = 256
    g.dfas = {}
    g.dfas[256] = (
        [
            [
                (257, 0),
            ],
            [
                (0, 1),
            ],
        ],
        {1: 257},
    )
    g.labels = [None, ("EOF", None)]
    g.keywords = {"EOF": 257}
    p = Parser(g, lam_sub)
    p.setup()
    # Test shift
    p.addtoken(0, "EOF", None)
    # Check added node
    assert p.rootnode.children == [Leaf(0, "EOF")]
    # Test shift of bad

# Generated at 2022-06-23 15:41:17.628929
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver
    from . import grammar

    gr = grammar.Grammar(
        grammar.parse_grammar("""
      int: INT;
      ws: WS;
      """, check=False)
    )
    pd = driver.Driver(gr, convert=None)
    pd.setup()
    pd.addtoken(token.INT, "123", None)
    pd.addtoken(token.WS, "", None)
    assert pd.rootnode == (
        257,
        None,
        None,
        [(258, None, None, [(token.INT, "123", None, None)])],
    )

# Generated at 2022-06-23 15:41:29.039087
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.driver as driver
    grammar = driver.load_grammar("Grammar.txt", convert=True)
    parser = Parser(grammar)  # type: Any
    tok = parser.classify(token.NAME, "foo", (1, 0))
    assert tok == driver.syms.name
    assert parser.used_names == {"foo"}
    tok = parser.classify(token.NAME, "print", (1, 0))
    assert tok == driver.syms.print_stmt

    tok = parser.classify(token.OP, "+", (1, 0))
    assert tok == driver.syms.plus

    assert token.NAME == 1
    assert driver.syms.name == 258

# Generated at 2022-06-23 15:41:32.277488
# Unit test for constructor of class Parser
def test_Parser():
    import blib2to3.pgen2.driver
    g = blib2to3.pgen2.driver.load_grammar()
    p = Parser(g)
    assert p
    assert isinstance(p, Parser)



# Generated at 2022-06-23 15:41:33.177485
# Unit test for method pop of class Parser
def test_Parser_pop():
    print(Parser.pop.__annotations__)

# Generated at 2022-06-23 15:41:35.549972
# Unit test for method classify of class Parser
def test_Parser_classify():
    def p(type: int) -> int:
        return Parser(Grammar(token.NT_OFFSET, [], {}, {}, {}, {}, {}, {}, {}))

    # Breakpoint here
    p(token.NAME)

# Generated at 2022-06-23 15:41:48.458376
# Unit test for function lam_sub
def test_lam_sub():
    # type: () -> None
    data = (
        ("bogus", (42, None, (1, 2), None), "NOTREACHED"),
        ("token", (42, "value", (1, 2), None), Leaf(42, "value", (1, 2))),
        ("empty", (42, None, (1, 2), []), Node(42, [], (1, 2))),
        ("nested", (42, None, (1, 2), [((3, None, (3, 4), None),)]), Node(42, [Leaf(3, None, (3, 4))], (1, 2))),
    )
    for descr, node, expected in data:
        actual = lam_sub(None, node)

# Generated at 2022-06-23 15:41:53.490928
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", token.PLUS, "+", (1, 0))
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == token.PLUS
        assert e.value == "+"
        assert e.context == (1, 0)
    else:
        assert False, "ParseError not raised"

# Generated at 2022-06-23 15:41:57.235436
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    p = Parser(grammar, lam_sub)
    p.setup()
    #print(p.stack)
    assert p.stack == [(([[(2, 1)]], {2: 0}), 0, (1, None, None, []))]



# Generated at 2022-06-23 15:42:06.198950
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    g = grammar.Grammar()
    x = lam_sub(g, (1, "2", 3, [[4, "5", 6, []], [], [7, "8", 9, []]]))
    assert isinstance(x, Node)
    assert x.type == 1
    assert x.children == [[4, "5", 6, []], [], [7, "8", 9, []]]
    assert x.prefix == "2"
    assert x.context == 3


# Generated at 2022-06-23 15:42:07.770093
# Unit test for method classify of class Parser
def test_Parser_classify():
    assert Parser(Grammar()).classify == Parser.classify

# Generated at 2022-06-23 15:42:14.199429
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .grammar import Grammar

    class MockNode(object):
        def append(self, newnode):
            self.newnode = newnode

    g = Grammar()
    p = Parser(g)
    p.setup()
    node = MockNode()
    newnode = MockNode()
    p.stack = [('dfa', 0, node)]
    p.convert = lambda g, x: newnode
    p.pop()
    assert node.newnode == newnode

# Generated at 2022-06-23 15:42:17.125990
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(None, None)

    p.setup(None)
    assert p.stack == [(None, 0, (None, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()

# Generated at 2022-06-23 15:42:18.506011
# Unit test for method pop of class Parser
def test_Parser_pop():
    result = Parser.pop(Parser)
    assert result is None, "Result should be none"

# Generated at 2022-06-23 15:42:29.599985
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from io import StringIO
    import sys

    def just_tokens(tokens: Sequence[Tuple[int, Text]]) -> Sequence[Token]:
        return [(type, None, val) for (type, val) in tokens]

    p = Parser(grammar)
    s = StringIO()
    oldstdout = sys.stdout

# Generated at 2022-06-23 15:42:36.421387
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        err1 = ParseError("Message for test", 1, "test", Context(1, 2, 3))
        assert err1.msg == "Message for test"
        assert err1.type == 1
        assert err1.value == "test"
        assert err1.context == Context(1, 2, 3)
        err2 = ParseError("Message for test", None, None, None)
        assert err2.msg == "Message for test"
        assert err2.type is None
        assert err2.value is None
        assert err2.context is None
    except Exception as err:
        print(err)
        raise

# Generated at 2022-06-23 15:42:48.646108
# Unit test for constructor of class Parser
def test_Parser():
    from .token import tokenize, untokenize, tok_name, NUMBER, OP

    def test_token(input_: str, output: Sequence[int]) -> None:
        if input_:
            assert tokenize(input_) == output, "tokens: %r" % (input_,)
            assert untokenize(output) == input_, "tokens: %r" % (input_,)
        else:
            assert tokenize(input_) == output, "tokens: ''"
            assert untokenize(output) == input_, "tokens: ''"

    test_token("def f(): pass", [313, NAME, OP, OP, OP, NAME])
    test_token("f(x)", [NAME, OP, NAME])
    test_token("", [])


# Generated at 2022-06-23 15:42:58.065366
# Unit test for method setup of class Parser
def test_Parser_setup():
    """Test method setup of class Parser"""
    # Build grammar
    from . import grammar, token


    class MyGrammar(grammar.Grammar):
        """Test grammar"""

        def __init__(self) -> None:
            grammar.Grammar.__init__(self, start="file_input")

# Generated at 2022-06-23 15:43:08.730597
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2 import parse
    from . import tokenize
    from .tokenize import untokenize, generate_tokens

    # Assume the grammar is already loaded
    grammar = parse.grammar

    # Get a parser
    p = Parser(grammar)
    p.setup()

    # Tokenize a program (or load it from a file, or whatever you like)
    readline = iter(["x = 25\n"]).__next__
    tokens = generate_tokens(readline)
    tokens = list(tokens)

    # Parse the program, converting tokens to NEWLINE and INDENT when needed
    indent = []
    parenlev = 0

# Generated at 2022-06-23 15:43:20.539116
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar, tokenize

    # Create a parser and prepare it for parsing
    p = Parser(grammar.grammar)
    p.setup()

    # This is the input program; it should succeed
    input_1 = "def f(): pass"
    g = tokenize.generate_tokens(input_1.splitlines(True))
    # Add each token to the parser, one at a time
    for (t, v, (srow, scol), (erow, ecol), _) in g:
        context = Context(srow, scol, erow, ecol, input_1)
        p.addtoken(t, v, context)

    # Check that the partial result is correct
    assert len(p.stack) == 1
    dfa, state, node = p.stack[0]
   

# Generated at 2022-06-23 15:43:25.425147
# Unit test for method pop of class Parser
def test_Parser_pop():
    class Grammar: dfas = {0: [[(1, 0)], [(1, 0)]]}
    p = Parser(Grammar())
    p.setup()
    p.addtoken(0, None, None)
    p.pop()
    p.addtoken(0, None, None)

# Generated at 2022-06-23 15:43:33.192009
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import io
    from . import tokenize
    from . import token

    source_data = io.BytesIO(b"a+b")
    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()
    tokens = tokenize.generate_tokens(source_data.readline)
    for tp in tokens:
        if tp.type == token.ENDMARKER:
            break
        if tp.type == token.NEWLINE:
            continue
        if parser.addtoken(tp.type, tp.string, tp.start):
            break

# Generated at 2022-06-23 15:43:38.245887
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("msg", 1, "value", (2, 3))
    assert exc.msg == "msg"
    assert exc.type == 1
    assert exc.value == "value"
    assert exc.context == (2, 3)

# Generated at 2022-06-23 15:43:48.370719
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    tokens = []
    p.addtoken(token.INDENT, "", Context(1, 0))
    p.addtoken(token.INDENT, "", Context(2, 0))
    p.addtoken(token.INDENT, "", Context(3, 0))
    p.addtoken(token.DEDENT, "", Context(4, 0))
    p.addtoken(token.DEDENT, "", Context(5, 0))
    p.addtoken(token.DEDENT, "", Context(6, 0))
    p.addtoken(token.INDENT, "", Context(7, 0))

# Generated at 2022-06-23 15:43:53.325841
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import collections
    from .token import tok_name, NUMBER, STRING
    from . import grammar, tokenize
    from .pgen import driver

    # StringIO is not defined on 2.6
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO

    try:
        # Py2.7+
        from unittest.mock import patch
    except ImportError:
        from mock import patch


# Generated at 2022-06-23 15:44:02.322062
# Unit test for method shift of class Parser
def test_Parser_shift():
    class DummyGrammar(grammar.Grammar):
        def __init__(self):
            if 0:
                super(DummyGrammar, self).__init__()
            self.nonterms = {}
            self.labels = {}
            self.dfas = {}
            self.start = None
            self.tokens = {}
            self.keywords = {}
            self.symbol2label = {}
            self.label2symbol = {}
    class DummyParser(Parser):
        def __init__(self, grammar, convert=None):
            if 0:
                super(DummyParser, self).__init__(grammar, convert)
            self.stack = []
            self.rootnode = None
            self.used_names = set()

# Generated at 2022-06-23 15:44:05.383846
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError("message", 1, "value", Context(None, 1, 1))
    assert p.msg == "message"
    assert p.type == 1
    assert p.value == "value"

# Generated at 2022-06-23 15:44:14.853405
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    class Checker(object):
        def __init__(self, convert):
            self.convert = convert
            self.stack = [([], 0, [])]
            self.stacks = []

        def classify(self, type, value, context):
            if type == token.NAME:
                self.stacks.append((list(self.stack), (type, value, context)))
            return self.convert(type, value, context)

        def shift(self, type, value, newstate, context):
            assert newstate >= 0
            seq = self.stack[-1]
            seq[0].append((type, value, context))
            seq[1] = newstate
            self.stack[-1] = seq


# Generated at 2022-06-23 15:44:17.827353
# Unit test for method push of class Parser
def test_Parser_push():
    parser = Parser(None)
    parser.push(1, 2, 3, 4)
    assert parser.stack == [(2, 0, (1, None, 4, []))]



# Generated at 2022-06-23 15:44:19.131124
# Unit test for method pop of class Parser
def test_Parser_pop():
    pass
    # x = tuple()
    # x[0]


# Generated at 2022-06-23 15:44:28.031164
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("msg", 1, "value", None)
    assert err.msg == "msg"
    assert err.type == 1
    assert err.value == "value"
    assert err.context is None
    try:
        raise err
    except ParseError as lerr:
        assert err.msg == lerr.msg
        assert err.type == lerr.type
        assert err.value == lerr.value
        assert err.context == lerr.context
    else:
        raise AssertionError("did not raise")

# Generated at 2022-06-23 15:44:29.057016
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    from . import driver


# Generated at 2022-06-23 15:44:39.415607
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2 import driver

    g = driver.load_grammar("Grammar/Grammar")
    p = Parser(g, convert=None)
    # Test the root node creation
    p.push(g.symbol2number["single_input"], g.dfas[g.symbol2number["single_input"]], 0, None)
    assert p.stack == [(g.dfas[g.symbol2number["single_input"]], 0, (17, None, None, []))]
    assert p.rootnode is None
    # Test the node creation
    p.push(g.symbol2number["stmt"], g.dfas[g.symbol2number["stmt"]], 0, None)

# Generated at 2022-06-23 15:44:43.520404
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.shift(1, "a", 2, Context)
    assert parser.stack[-1] == (grammar.dfas[1], 2, [1, "a", None, None])



# Generated at 2022-06-23 15:44:55.808120
# Unit test for constructor of class ParseError
def test_ParseError():
    import sys

    try:
        raise ParseError("test", token.NAME, "foo", Context(0, 1, 2))
    except ParseError as err:
        assert err.msg == "test"
        assert err.type == token.NAME
        assert err.value == "foo"
        assert err.context == Context(0, 1, 2)
    else:
        print("unexpected success!", file=sys.stderr)
    try:
        raise ParseError("test", token.NAME, "foo", None)
    except ParseError as err:
        assert err.msg == "test"
        assert err.type == token.NAME
        assert err.value == "foo"
        assert err.context is None
    else:
        print("unexpected success!", file=sys.stderr)

# Generated at 2022-06-23 15:45:06.443924
# Unit test for constructor of class Parser
def test_Parser():
    class MockGrammar:
        start = 2
        tokens = {
            token.NAME: 1,
            token.NUMBER: 2,
            token.STRING: 3,
            token.NEWLINE: 4,
        }
        keywords = {
            "12": 5,
            "def": 6,
            "if": 7,
        }
        labels = [
            (token.NAME, "NAME"),
            (token.NUMBER, "NUMBER"),
            (token.STRING, "STRING"),
            (token.NEWLINE, "NEWLINE"),
            (token.NAME, "12"),
            (token.NAME, "def"),
            (token.NAME, "if"),
        ]
        # Really (1, 2, 3)

# Generated at 2022-06-23 15:45:07.724641
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(Grammar())
    p.setup()



# Generated at 2022-06-23 15:45:13.878828
# Unit test for method classify of class Parser

# Generated at 2022-06-23 15:45:19.137123
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Arrange
    parser = Parser(Grammar())
    parser.stack = [
        (None, None, None),
    ]
    # Act
    parser.pop()
    # Assert
    assert parser.rootnode is None



# Generated at 2022-06-23 15:45:22.194690
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("msg", token.NAME, "name", None)
    assert str(err) == "msg: type=1, value='name', context=None"

# Generated at 2022-06-23 15:45:30.418905
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def check(grammar: Grammar, stmt: Sequence[Tuple[int, Any]], result: Results) -> NL:
        p = Parser(grammar)
        p.setup()
        for type, value in stmt:
            assert p.addtoken(type, value, (1, 1))
        return p.rootnode

    from . import grammar
    from . import token

    g = grammar.grammar
    n = (g.symbol2number["stmt"], None, None, [])
    assert check(g, [(token.NAME, "spam")], {"stmt": n}) == n

# Generated at 2022-06-23 15:45:35.234691
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar.txt")
    parser = Parser(grammar)
    parser.setup()

    parser.push(1, (((1, 1),), {1: 1}), 1, None)
    assert parser.stack[-1], (1, None, None, [])

# Generated at 2022-06-23 15:45:42.067705
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    def validate_results(result: List[Any]) -> None:
        pass

    def validate_convert(grammar: Grammar, node: RawNode) -> NL:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    def test_parser(start: int, input: Sequence[Tuple[int, Optional[Text], Context]]) -> None:
        parser = Parser(grammar, validate_convert)
        parser.setup(start)
        for t in input:
            if parser.addtoken(*t):
                break
        validate_results([parser.rootnode])


# Generated at 2022-06-23 15:45:45.886672
# Unit test for method setup of class Parser
def test_Parser_setup():

    import blib2to3.pgen2.grammar as grammar

    parser = Parser(grammar.grammar)
    parser.setup()



# Generated at 2022-06-23 15:45:55.620006
# Unit test for method pop of class Parser
def test_Parser_pop():
    class NewParser(Parser):
        def __init__(self, grammar, converter):
            super(NewParser, self).__init__(grammar, converter)
            self.tmp = None

        def convert(self, grammar, node):
            self.tmp = node
            return None

    mock_dfa = ([], {})
    mock_dfa2 = ([], {})

    p = NewParser(None, None)
    p.stack = [
        (mock_dfa, 0, (1, None, None, [])),
        (mock_dfa2, 0, (1, None, None, [])),
    ]
    p.pop()
    assert p.stack == [mock_dfa, 0, (1, None, None, [])]

# Generated at 2022-06-23 15:46:05.449352
# Unit test for method shift of class Parser

# Generated at 2022-06-23 15:46:09.042432
# Unit test for constructor of class Parser
def test_Parser():
    g = Grammar(open("Grammar.txt"))
    p = Parser(g)
    assert p.grammar is g
    assert p.convert is lam_sub

# Generated at 2022-06-23 15:46:15.765319
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from pytree import Leaf
    g = grammar.grammar
    src = b"+ foo 3\n"
    t = tokenize.tokenize(src)
    p = Parser(g)
    p.setup()
    for tp in t:
        if p.addtoken(*tp):
            break
    assert p.rootnode.children == [Leaf(3, "+"), Leaf(1, "foo"), Leaf(3, "3"), Leaf(4, "\n")]

# Generated at 2022-06-23 15:46:20.270440
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(Grammar())
    assert p.grammar == Grammar()
    assert p.convert == lam_sub
    p = Parser(Grammar(), lam_sub)
    assert p.grammar == Grammar()
    assert p.convert == lam_sub

# Generated at 2022-06-23 15:46:22.597241
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = Grammar('a: "a"\n')
    parser = Parser(grammar)
    parser.setup()
    parser.shift(4, 'a', 1, None)

# Generated at 2022-06-23 15:46:31.790202
# Unit test for method classify of class Parser
def test_Parser_classify():
    class DummyGrammar:
        tokens: Dict[int, int] = {}
        keywords: Dict[str, int] = {}

    p = Parser(DummyGrammar())
    # A NAME token is mapped to its value (itself)
    p.grammar.keywords["name"] = 10
    p.grammar.tokens[token.NAME] = 5
    rawnode = (token.NAME, "name", None, None)
    assert p.classify(token.NAME, "name", None) == 10
    # A NAME token is mapped to NAME if it's not a keyword
    p.grammar.keywords.clear()
    assert p.classify(token.NAME, "name", None) == 5
    # A token sets ParseError if it is not in the tokens table

# Generated at 2022-06-23 15:46:41.430143
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def f(**kwargs):
        s = Parser(None)
        s.stack = [(
            (
                [[(2, 3)], [(0, 3), (1, 4)]],
                {
                    1: 2,
                    2: 1,
                    }
            ),
            0,
            (0, 0, 0, []),
        )]
        s.pop = lambda: None
        s.shift = lambda *args: None
        s.push = lambda *args: None
        s.convert = lambda *args: None
        return s.addtoken(**kwargs)

    def test(f, argdict, expected):
        got = f(**argdict)
        if got != expected:
            print('%s != %s' % (got, expected))


# Generated at 2022-06-23 15:46:52.399784
# Unit test for method addtoken of class Parser

# Generated at 2022-06-23 15:47:02.229937
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest
    from blib2to3.pgen2 import tokenize

    def classify(type, value):
        return Parser(Grammar()).classify(type, value, None)

    def pytree(type, value, context=None, children=None):
        return (type, value, context, children)

    class TestParser(unittest.TestCase):
        def test_tokens(self):
            tokens = token.tok_name
            for tok, typ in tokens.items():
                if len(tok) == 3:
                    # Remove the trailing _
                    tok = tok[:-1]
                self.assertEqual(classify(typ, tok), typ, (typ, tok))
            # NAME and OP can be anything

# Generated at 2022-06-23 15:47:06.091138
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar()
    node = (1, None, None, [])
    assert lam_sub(grammar, node) == Node(type=1, children=[], context=None)

# Generated at 2022-06-23 15:47:13.039212
# Unit test for constructor of class Parser
def test_Parser():
    def p(I, E):
        assert I.grammar is E.grammar
        assert I.convert is E.convert
        assert I.stack == []
        assert I.rootnode is None

    class Dummy:
        pass

    g = Dummy()
    g.dfas = []
    g.keywords = {}
    g.labels = []
    g.start = 0
    g.tokens = {}
    c = Dummy()
    p(Parser(g), Parser(g, c))

# Generated at 2022-06-23 15:47:16.884055
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    p = Parser(grammar.grammar)
    p.setup()

    tok = token.ELSE
    val = "else"
    newstate = 3

    p.push(tok, newstate, newstate, (0, 0))

    assert p.stack[-1][0] == newstate

# Generated at 2022-06-23 15:47:19.378720
# Unit test for method setup of class Parser
def test_Parser_setup():
    from ..grammar import Grammar

    grammar = Grammar(Grammar.pgen_pytree_grammar)
    parser = Parser(grammar)
    parser.setup()



# Generated at 2022-06-23 15:47:29.272310
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import pytest # type: ignore

# Generated at 2022-06-23 15:47:38.910191
# Unit test for method push of class Parser
def test_Parser_push():
    import os
    import sys
    os.chdir("..")
    sys.path.append(".")
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.convert import convert
    from blib2to3.pgen2.pgen import generate_grammar
    g = Grammar("")
    g = generate_grammar("python", g)
    p = Parser(g)
    p.setup("expr_stmt")

# Generated at 2022-06-23 15:47:49.797218
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Test of method pop of class Parser"""

    class MyParser(Parser):
        """A class used for testing"""

        def __init__(self, grammar: Grammar, convert: Optional[Convert] = None) -> None:
            super().__init__(grammar, convert)
            self.stack: List[Tuple[DFAS, int, RawNode]] = []

    def get_set(obj: Text) -> Set[str]:
        """Return the set of new names.

        obj is an instance of Node.

        """
        return obj.used_names

    b = Grammar("b")
    b.add_nonterminal("S", [("b", 0), ("S", 0)])  # type: ignore
    b.add_nonterminal("S", [("a", 0)])  # type: ignore

   

# Generated at 2022-06-23 15:47:52.833180
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('test', 'type', 'value', 'context')
    except ParseError as err:
        assert err.msg == 'test'
        assert err.type == 'type'
        assert err.value == 'value'
        assert err.context == 'context'

# Generated at 2022-06-23 15:48:04.830115
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    class Node:
        def __init__(self, type_: int, value: Optional[str] = None, children: Sequence[NL] = []) -> None:
            self.type = type_
            self.value = value
            self.children = children

    class TestParser(unittest.TestCase):
        def test_base(self, parse_func: Callable[..., Any]):
            def lam_sub(grammar: Grammar, node: RawNode) -> Optional[NL]:
                return Node(node[0], node[1], node[3])

            def test_driver_func(p: Parser, type: int, value: str) -> None:
                p.addtoken(type, value, None)
                pass

            parse_func(lam_sub, test_driver_func)



# Generated at 2022-06-23 15:48:11.016628
# Unit test for method classify of class Parser
def test_Parser_classify():
    # check that unknown tokens are rejected
    class MockGrammar(object):
        def __init__(self, tokens: List[Tuple[int, int]]) -> None:
            self.tokens = tokens
    mock_grammar = MockGrammar([])
    mock_convert = lam_sub
    parser = Parser(mock_grammar, mock_convert)
    parser.setup()
    parser.classify(token.NUMBER, "5", None)
    
    # check that reserved words are recognized
    mock_grammar = MockGrammar([])
    mock_grammar.keywords = {'False': 0}
    mock_convert = lam_sub
    parser = Parser(mock_grammar, mock_convert)
    parser.setup()

# Generated at 2022-06-23 15:48:19.171501
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def convert(grammar: Grammar, node: RawNode) -> NL:
        return node[0]

    import io
    import os

    from .tokenizer import generate_tokens, untokenize

    from . import driver

    from blib2to3.fixer_base import token_type_re
    from testing.support import TempdirManager

    class _RecordTokens(driver.Driver):
        def parse_file(self, filename: Text, encoding: Optional[Text] = None) -> NL:
            c2py: Dict[int, str] = self.grammar.number2symbol
            with open(filename, "rb") as fp:
                tokens = generate_tokens(fp.readline)
            p = Parser(self.grammar, convert)
            p.setup()

# Generated at 2022-06-23 15:48:28.641760
# Unit test for method pop of class Parser
def test_Parser_pop():
    def convert(grammar, node):
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    p = Parser(Grammar("test/demo.grammar"), convert)
    p.setup()

    p.addtoken(3, "foo", None)
    p.addtoken(1, ":", None)
    p.addtoken(1, ":", None)

    p.pop()
    assert p.stack[0][2][-1][0] == 11
    p.pop()
    assert p.stack[0][2][-1][0] == 12
    p.pop()
    assert p.stack[0][2][-1][0] == 13
    assert p.rootnode.type == 13

# Generated at 2022-06-23 15:48:36.505302
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    from . import grammar
    import StringIO
    import sys

    grammar = grammar.parse_grammar(StringIO.StringIO(driver.grammar))
    p = Parser(grammar)
    p.setup()
    while True:
        tok = driver.generate_tokens(sys.stdin.readline)
        p.addtoken(*tok)

# Generated at 2022-06-23 15:48:44.101224
# Unit test for constructor of class Parser
def test_Parser():
    g = Grammar()
    # Check default constructor
    g.add_production(0, [])
    g.add_production(1, [1, 0])
    g.add_production(0, [])
    g.add_production(2, [2, 0])
    g.add_production(0, [])
    g.add_production(3, [3, 0])
    g.add_production(0, [])
    grammar = g.build_lritems()
    grammar.build_lr0()
    grammar.build_dfas()
    grammar.find_unreachable_symbols()
    grammar.build_character_sets()
    p = Parser(grammar)
    # Check alternate constructor
    p = Parser(grammar=grammar, convert=lam_sub)


# Unit test

# Generated at 2022-06-23 15:48:51.882436
# Unit test for method push of class Parser
def test_Parser_push():
    from pprint import pprint
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2 import tokenize

    def parse(inp) -> Sequence[Tuple[int, Text, Context]]:
        driver = Driver(convert=lam_sub)
        data = tokenize.untokenize(inp)
        return driver.parse_tokens(data)

    print("test_Parser_push()")
    pprint(parse("'''"))
    pprint(parse("""
    '''
    '''
    """))



# Generated at 2022-06-23 15:49:02.369899
# Unit test for method setup of class Parser
def test_Parser_setup():
    from .pgen2.driver import Driver
    from .pgen2.parse import parse_grammar
    driver = Driver()
    grammar = parse_grammar(driver, driver.grammar(), 'grammar.txt')
    p = Parser(grammar)
    p.setup()
    # The following is the grammar for the entire grammar used for parsing
    # Python source code.

# Generated at 2022-06-23 15:49:03.600747
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar(token.tok_name, {}), lam_sub)
    p.setup(0)



# Generated at 2022-06-23 15:49:06.401048
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Test for method pop of class Parser"""
    from . import driver

    grammar = driver.load_grammar()
    p = Parser(grammar)
    p.setup()
    assert p.pop() is None


# Generated at 2022-06-23 15:49:17.406166
# Unit test for constructor of class Parser
def test_Parser():
    from . import driver
    from . import grammar
    from . import tokens

    gr = grammar.Grammar(driver.GrammarData)
    pr = Parser(gr)

    assert gr == pr.grammar
    assert pr.convert is lam_sub
    assert pr.stack == []
    assert pr.rootnode is None

    def def_sub(gr, nd):
        """Convert a definition node to an integer."""
        return 1

    pr = Parser(gr, def_sub)
    assert gr == pr.grammar
    assert pr.convert is def_sub

    # Test classify() by checking a few tokens
    assert pr.classify(tokens.NAME, "<name>", None) == 95  # NAME
    assert pr.classify(tokens.NUMBER, "<number>", None)

# Generated at 2022-06-23 15:49:29.094069
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, pgen

    pg = pgen.ParserGenerator(grammar.grammar)
    pg.dump_grammar("Grammar.pickle")
    with open("Grammar.pickle") as f:
        pick_gram = grammar.Grammar(grammar.symbol2number, grammar.token2number)
        pick_gram.loads(f.read())
    p = Parser(pick_gram)
    p.setup()
    p.addtoken(token.STRING, "foo", Context(1, 0))
    p.addtoken(token.NEWLINE, "\n", Context(1, 0))

# Generated at 2022-06-23 15:49:39.339927
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    def check(s: str, type: int, value: Optional[Text], context: Context) -> NL:
        p = Parser(grammar.grammar)
        p.setup()
        from .pgen import driver

        driver.tokenize_keepends(s, p.addtoken)
        #print(s, p.rootnode)
        assert p.addtoken(type, value, context)
        return p.rootnode

    check("42", 0, "", (1, 0))
    check("42\n", 0, "", (1, 0))
    check("42\n", 0, "", (2, 0))
    check("42\n", token.STRING, "", (1, 0))
    check("42\n", token.STRING, "", (2, 0))
   

# Generated at 2022-06-23 15:49:45.238087
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Test the addtoken method of Grammar class"""
    def convert(grammar, node):
        return node
    # Test case 1
    grammar = Grammar(start=1)
    grammar.labels = {256: (256, None)}
    grammar.keywords = {}
    grammar.tokens = {1: 256}
    grammar.dfas = {1: ([[(0, 0)]], {})}
    parser = Parser(grammar, convert)
    parser.setup()
    parser.addtoken(1, '1', (1, 1))
    assert parser.rootnode[-1] == ['1']
    # Test case 2
    grammar = Grammar(start=1)
    grammar.labels = {256: (256, None), 257: (257, None)}
    grammar.keywords = {}
    grammar

# Generated at 2022-06-23 15:49:53.926976
# Unit test for method push of class Parser
def test_Parser_push():
    g = Grammar()
    class DummyDFA:
        def __init__(self):
            self.states = [(1, 1)]
    dummyDFA = DummyDFA()
    p = Parser(g)
    p.push(1, dummyDFA, 0, None)
    expected = [(dummyDFA, 0, (1, None, None, []))]
    if p.stack != expected:
        raise ValueError("Invalid value for p.stack returned by push")

# Generated at 2022-06-23 15:49:57.972849
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = Grammar("grammar.txt")
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NAME, "a", )

# Generated at 2022-06-23 15:50:05.614861
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2 import driver

    gr = driver.load_grammar("Grammar/Grammar")
    p = Parser(gr)
    p.setup()
    p.grammar.dfas[1] = ([], set())
    p.push(1, (), 1, None)
    assert len(p.stack) == 2
    assert p.stack[0][0] is () and p.stack[1][0] is ()
    assert p.stack[0][1] == 1 and p.stack[1][1] == 1
    assert p.stack[0][2][3] is not None and p.stack[1][2][3] is not None


# Generated at 2022-06-23 15:50:15.998765
# Unit test for function lam_sub
def test_lam_sub():
    # type: () -> None
    """Test lam_sub"""

    g = Grammar()
    # Concrete syntax tree -- base form:
    cst = (42, "foo", (1, 2), [(2, "bar", (3, 4), None), (3, None, (5, 6), [])])
    # Expected abstract syntax tree -- after lam_sub
    ast = Node(42, [Leaf(2, "bar", (3, 4)), Node(3, [], (5, 6))], (1, 2))

    # Call lam_sub
    new_cst = lam_sub(g, cst)

    # Check result
    assert new_cst == ast

# Generated at 2022-06-23 15:50:19.940140
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    p = Parser(grammar.grammar)
    p.setup()
    assert p.stack == [(grammar.grammar.dfas[grammar.grammar.start], 0, (1, None, None, []))]


# Generated at 2022-06-23 15:50:28.205448
# Unit test for method pop of class Parser

# Generated at 2022-06-23 15:50:38.462683
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import tokenize
    from . import python
    from . import parsers
    from random import seed, choice, random
    seed(1)  # Make tests reproducible
    vlist = [float(i) for i in range(3)]

    def gen_float():
        return f"{choice(vlist)}.{choice(vlist)}"

    def gen_int():
        return str(int(random() * 2 ** 32))
