

# Generated at 2022-06-23 15:40:38.407537
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver, token

    class A(object):
        def __init__(self):
            self.token = None  # type: Optional[Tuple[int, str]]

        def tok(self, type: int, token: Any, context: Context) -> None:
            self.token = type, token

    a = A()
    p = Parser(driver.get_grammar())

    def convert(grammar: Grammar, node: RawNode):
        return node

    p.convert = convert

    p.setup()
    p.addtoken(token.NAME, "child", None)
    p.push(token.NAME, (1, 2), 1, None)
    p.addtoken(token.NAME, "parent", None)

# Generated at 2022-06-23 15:40:41.515349
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("msg", token.NUMBER, "value", None)
    assert str(error).startswith("msg: type=NUMBER, value=value")

# Generated at 2022-06-23 15:40:49.403545
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = Grammar()
    grammar.load(["test.grammar"])
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NAME, "module", Context(1, 0))
    parser.addtoken(token.NAME, "foo", Context(1, 7))
    parser.addtoken(token.INDENT, None, Context(2, 0))
    parser.addtoken(token.NEWLINE, None, Context(2, 0))
    parser.addtoken(token.DEDENT, None, Context(3, 0))
    parser.addtoken(token.ENDMARKER, None, Context(3, 0))

# Generated at 2022-06-23 15:40:52.908919
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test ParseError constructor."""
    error = ParseError("abc", 123, "def", (1, 2))
    assert str(error)[0:43] == "ParseError: abc: type=123, value='def', context=(1, 2)"
    assert error.msg == "abc"
    assert error.type == 123
    assert error.value == "def"
    assert error.context == (1, 2)

# Generated at 2022-06-23 15:40:59.961163
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token
    from . import driver

    fl = driver.load_grammar("Python.asdl")
    g = grammar.Grammar(fl)
    p = Parser(g)
    p.setup()

    f2 = driver.load_grammar("Grammar.txt")
    g2 = grammar.Grammar(f2)
    p2 = Parser(g2)
    p2.setup(g2.start)

# Generated at 2022-06-23 15:41:04.076903
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    g = grammar.grammar("samples/simple.bnf")
    p = Parser(g)
    p.setup("expr")
    for t in tokenize("x + y"):
        if p.addtoken(t.type, t.value, t.context):
            break
    assert len(p.rootnode) == 3
    assert p.rootnode[0] == "expr"

# Generated at 2022-06-23 15:41:11.807191
# Unit test for method classify of class Parser
def test_Parser_classify():
    # This test is a bit of a fake.  It doesn't actually use a real
    # grammar object.
    p = Parser(None)
    # We test with an instance of a class that looks just like the
    # instance the driver creates (see driver.py).
    class FakeClass:
        tokens = {"STRING": 2, "NUMBER": 3}
        keywords = {"None": 1}
    p.__dict__["grammar"] = FakeClass()
    # Test lookup of a string
    assert p.classify(token.STRING, "s", None) == 2
    # Test lookup of a number
    assert p.classify(token.NUMBER, "42", None) == 3
    # Test lookup of a keyword
    assert p.classify(token.NAME, "None", None) == 1
    # Test error case


# Generated at 2022-06-23 15:41:24.832549
# Unit test for constructor of class Parser
def test_Parser():
    import sys
    from . import tokenize
    from .tokenize import detect_encoding, TokenInfo

    filename = "k.txt"
    title = "Test Docstring"
    f = open(filename, "r")
    encoding = detect_encoding(f.readline)[0]
    f = open(filename, "r", encoding=encoding)
    lines = f.read().split("\n")
    version = "A"
    tokens = []
    readline = f.readline
    encoding = "Test Encoding"
    num_blanklines = 1
    readline = f.readline
    tokens = []  # type: List[TokenInfo]

# Generated at 2022-06-23 15:41:33.750392
# Unit test for constructor of class Parser
def test_Parser():
    import unittest
    import pgen2.tokenize

    class TestParser(unittest.TestCase):

        def test_basic(self):
            import blib2to3.pgen2.grammar as grammar
            from blib2to3.pgen2 import driver
            import blib2to3.pgen2.parse as parse

            g = grammar.grammar
            d = driver.Driver(g, convert=parse.convert)
            # Test for expected exceptions

# Generated at 2022-06-23 15:41:41.470598
# Unit test for constructor of class ParseError
def test_ParseError():
    msg = "bad token"
    type = 3
    value = "foo"
    context = (2, 5)
    error = ParseError(msg, type, value, context)
    assert isinstance(error, Exception)
    assert error.msg == msg
    assert error.type == type
    assert error.value == value
    assert error.context == context

# Unit tests for class Parser

# Generated at 2022-06-23 15:41:52.088911
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import unittest

    class ParserTest(unittest.TestCase):
        def test_pop(self):
            import blib2to3.pgen2.driver
            grammar = blib2to3.pgen2.driver.load_grammar(sys.argv[1])
            parser = Parser(grammar)
            parser.setup()
            self.assertEqual(parser.rootnode, None)
            stack = parser.stack
            popdfa, popstate, popnode = stack.pop()
            newnode = parser.convert(parser.grammar, popnode)
            if newnode is not None:
                if stack:
                    dfa, state, node = stack[-1]
                    assert node[-1] is not None
                    node[-1].append(newnode)
               

# Generated at 2022-06-23 15:42:00.197709
# Unit test for method shift of class Parser
def test_Parser_shift():
    def convert(grammar: Grammar, node: Tuple[int, Optional[Text], Context, Sequence]) -> Any:
        # type: (...) -> Any
        type, value, context, children = node
        if children is None:
            return Leaf(value, context=context)
        else:
            return Node(type=type, children=children, context=context)

    p = Parser(Grammar(version="3.8"), convert)
    p.setup()
    t1 = token.NUMBER, '3', (1, 0)
    t2 = token.NUMBER, '4', (1, 1)
    p.addtoken(*t1)
    p.addtoken(*t2)
    # type: ignore

# Generated at 2022-06-23 15:42:11.835177
# Unit test for method shift of class Parser
def test_Parser_shift():

    from . import grammar

    # the input strings
    tokens = [
        ("INT", "123", 1),
        ("EQUAL", "=", 1),
        ("STRING", "asd", 1),
        ("SEMI", ";", 1),
    ]

    # the parser object
    p = Parser(grammar)

    # prepare the parser
    p.setup()

    # short vars
    shift = p.shift
    convert = p.convert

    # some variables we need
    type = 0
    value = None
    context = 1
    
    # the test begins
    t, v, c = tokens[0]
    type = token.tok_name[t]
    value = v
    shift(type, value, 0, context)
    shift(type, value, 0, context)


# Generated at 2022-06-23 15:42:20.559536
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .grammar import Grammar

    g = Grammar()
    start = g.add_nonterminal('START')
    name = g.add_nonterminal('NAME')
    end = g.add_nonterminal('END')
    g.add_production(start, (name,), None, False)
    g.add_production(name, (end,), None, False)
    g.add_production(end, [], None, True)
    g.start = start
    g.dfas = {
        name: ([[], [(0, 1)]], {0: 0}),
        end: ([[], [(0, 1)]], {0: 0}),
        start: ([[(1, 0), (1, 1)], [(0, 1)]], {0: 0, 1: 1}),
    }

# Generated at 2022-06-23 15:42:28.451293
# Unit test for method shift of class Parser
def test_Parser_shift():
    def run_test(type, value, state, context):
        p = Parser(Grammar())
        p.setup()
        p.shift(type, value, state, context)
        assert p.stack[-1][1] == state
    run_test(token.NUMBER, "123", 42, None)
    run_test(token.NUMBER, "123", 42, None)
    run_test(token.NUMBER, "123", 42, None)


# Generated at 2022-06-23 15:42:38.802109
# Unit test for method shift of class Parser
def test_Parser_shift():

    # Get token
    token: RawNode = (token.NAME, "x", None, None)

    # Set grammar
    grammar: Grammar = Grammar()

    # Set parser
    parser: Parser = Parser(grammar)

    # Get stack
    stack: List[Tuple[DFAS, int, RawNode]] = parser.stack

    # Get context
    context: Context = Context(0)

    # Update parser
    parser.shift(*token[0:3], newstate=0, context=context)
    dfa, state, node = stack[0]

    # Check
    assert node == (3, None, None, [])

# Generated at 2022-06-23 15:42:50.226586
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.tokenize import tokenize

    # This is the grammar used by Python 2.4.
    # Note that the number of symbols and rules is greater than
    # the number of states (423), due to some rules being combined
    # into a single state in the DFA construction (see the grammar
    # module).

# Generated at 2022-06-23 15:42:59.347191
# Unit test for method setup of class Parser
def test_Parser_setup():
    import collections
    import unittest
    from blib2to3.pgen2 import token

    class FakeGrammar(collections.namedtuple("FakeGrammar", "start dfas labels")):
        def __new__(
            cls,
            start: int = 256,
            dfas: Dict[int, DFAS] = {},
            labels: Optional[Sequence[Tuple[int, Any]]] = None,
        ):
            return super().__new__(cls, start, dfas, labels or [])

    class TestParser(unittest.TestCase):
        def test_setup(self):
            grammar = FakeGrammar(
                start=token.NAME, dfas={token.NAME: [[(0, 0), (0, 1)]],},
            )

# Generated at 2022-06-23 15:43:05.804096
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = Grammar()
    parser = Parser(grammar)
    assert parser.stack == []
    parser.push(0, 0, 0, None)
    assert parser.stack == [(0, 0, (0, None, None, []))]
    parser.shift(1, "a", 1, None)
    parser.push(2, 0, 0, None)
    parser.shift(1, "b", 1, None)
    assert parser.stack == [
        (0, 0, (0, None, None, [(0, "a", None, None)])),
        (0, 0, (2, None, None, [(1, "b", None, None)])),
    ]

# Generated at 2022-06-23 15:43:10.101418
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver

    grammar = driver.load_grammar("Grammar.txt", convert_unicode=True)
    parser = Parser(grammar)
    parser.setup()

    # with a non-empty stack
    token = Node(type=0, children=[], context=None)
    parser.stack.append(([(1,0),(0,0)] , 1 , token))
    # check the state of the stack before the pop
    assert parser.stack == [( [ (1,0), (0,0) ], 1, Node(type=0, children=[], context=None) )]
    # check the state of the rootnode before the pop
    assert parser.rootnode == None
    # check the state of the popnode befor the pop
    assert token.children == []
    parser.pop()
    # check the state

# Generated at 2022-06-23 15:43:14.441524
# Unit test for function lam_sub
def test_lam_sub():
    # TODO: Since lam_sub is just a wrapper around Node, and Node
    # tests are currently scattered around the test suite, we don't
    # have a test here.
    pass


# Generated at 2022-06-23 15:43:21.506496
# Unit test for method pop of class Parser
def test_Parser_pop():
    import blib2to3
    import unittest

    class TestParser(unittest.TestCase):
        def test_parser_pop(self):
            p = Parser(blib2to3.pgen2.parse.grammar)
            p.setup()
            for t in [token.NAME, token.NAME, token.EQUAL, token.NAME]:
                p.addtoken(t, '', blib2to3.pgen2.parse.Context())
            self.assertIsNone(p.pop())

    unittest.main()

# Generated at 2022-06-23 15:43:32.151908
# Unit test for constructor of class Parser
def test_Parser():
    """Simple unit test for Parser class."""
    # Simple example: just count the number of NAME tokens
    # (but don't print the number of reserved keywords!)
    from . import driver

    class Parser(blib2to3.pgen2.driver.Parser):
        tokens: int

        def __init__(self, **kwds):
            self.tokens = 0
            blib2to3.pgen2.driver.Parser.__init__(self, **kwds)

        def addtoken(self, type, value, context):
            if type == token.NAME:
                self.tokens += 1
            return blib2to3.pgen2.driver.Parser.addtoken(self, type, value, context)


# Generated at 2022-06-23 15:43:42.498472
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar)

    # empty initial state
    p._state = []
    p._addtoken(token.NAME, "s", None)
    assert p._state == [ ("NAME", "s") ]
    p._addtoken(token.NAME, "s", None)
    assert p._state == [ ("NAME", "s"), ("NAME", "s") ]

    # addtoken on non-empty state
    p._state = [ ("NAME", "s") ]
    p._addtoken(token.NAME, "s", None)
    assert p._state == [ ("NAME", "s"), ("NAME", "s") ]


# Generated at 2022-06-23 15:43:53.042426
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Labels are (token, symbol) pairs
    labels = {
        (token.NUMBER, None): 1,
        (token.NAME, None): 2,
        (token.NAME, "foo"): 3,
    }
    # Tokens are token numbers
    tokens = {
        token.NUMBER: 1,
        token.NAME: 2,
    }
    # Symbols are token numbers
    symbols = {
        "foo": 3,
    }
    # Keywords are token numbers
    keywords = {"foo": 3}
    grammar = Grammar(labels, tokens, symbols, keywords, symbols["foo"])
    parser = Parser(grammar, None)
    parser.setup()

# Generated at 2022-06-23 15:44:02.183897
# Unit test for method pop of class Parser
def test_Parser_pop():
    p = Parser(Grammar())
    p.stack = [
        (1, 2, (3, "1", 4, [])),
        (5, 6, (7, "2", 8, [])),
        (9, 10, (11, "3", 12, [])),
        (13, 14, (15, "4", 16, [])),
    ]

    p.pop()
    assert p.rootnode == (15, "4", 16, [])

# Generated at 2022-06-23 15:44:11.197591
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import pprint
    import timeit
    from . import driver, token

    if "--bench" in sys.argv:
        # Benchmark mode
        cmd = """if 1:
            from __main__ import Parser, test_Parser_addtoken
            p = Parser(test_Parser_addtoken.grammar)
            p.setup()
            for tok in test_Parser_addtoken.tokens:
                p.addtoken(tok[0], tok[1], tok[2])
            """
        print("timeit:", timeit.timeit(cmd, number=100))

    else:
        # Normal mode
        def test(p, expect_repl, *tokens):
            """Add tokens and compare the resulting tree to expect."""
            p.setup()

# Generated at 2022-06-23 15:44:19.798281
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    def ivy_classify(type: int, value: Any, *args: object) -> int:
        return type

    g = grammar.Grammar(ivy_classify)  # type: ignore
    p = Parser(g, lam_sub)
    p.setup(start=0)
    p.addtoken(0, None, None)
    p.addtoken(0, None, None)
    p.addtoken(0, None, None)
    p.addtoken(0, None, None)
    assert isinstance(p.rootnode, Node)  # type: ignore
    assert p.rootnode.type == 0

# Generated at 2022-06-23 15:44:28.958294
# Unit test for function lam_sub
def test_lam_sub():
    from .grammar import Grammar
    from blib2to3.pygram import python_grammar as Grammar
    g = Grammar()
    lam_sub(g, (1, None, None, []))
    lam_sub(g, (2, "hello", None, []))
    lam_sub(g, (3, None, None, [4]))
    try:
        lam_sub(g, (5, None, None, None))
    except AssertionError:
        pass
    else:
        assert 0, "AssertionError not raised"

# Generated at 2022-06-23 15:44:39.415726
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g: Grammar = grammar.grammar
    p: Union[Parser, Any] = Parser(g)
    p.setup()
    assert p.stack[0][0] is g.dfas[g.start]
    assert p.stack[0][1] == 0
    assert p.stack[0][2] == (g.start, None, None, [])
    p.setup()
    assert p.stack[0][0] is g.dfas[g.start]
    assert p.stack[0][1] == 0
    assert p.stack[0][2] == (g.start, None, None, [])

    p.setup(grammar.file_input)
    assert p.stack[0][0] is g.dfas[grammar.file_input]
    assert p

# Generated at 2022-06-23 15:44:41.951013
# Unit test for constructor of class Parser
def test_Parser():
    import sys

    try:
        grammar = Grammar(sys.stdin)
    except Exception:
        raise
    else:
        Parser(grammar)

# Generated at 2022-06-23 15:44:51.418860
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.parse as parse
    import blib2to3.pgen2.token as token

    p = parse.Parser(parse.test_grammar)
    assert p.classify(token.NUMBER, "3", None) == 3
    assert p.classify(token.PLUS, None, None) == 11
    assert p.classify(token.NAME, "a", None) == 13
    assert p.classify(token.NAME, "foo", None) == 13
    try:
        p.classify(token.NAME, "moo", None)
    except parse.ParseError:
        pass

# Generated at 2022-06-23 15:45:00.405422
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token
    p = Parser(grammar.Grammar(grammar.grammar_nts, grammar.grammar_dfas))
    p.setup(1)
    p.push(2, p.grammar.dfas[2], 1, token.TokenInfo())
    assert p.stack[0] == (p.grammar.dfas[1], 0, ((1, None, None, []),))
    assert p.stack[1] == (p.grammar.dfas[2], 1, ((2, None, token.TokenInfo(), []),))

# Generated at 2022-06-23 15:45:02.187035
# Unit test for method setup of class Parser
def test_Parser_setup():
    # Assume that the grammar has been loaded.
    assert Parser(Grammar())


# Generated at 2022-06-23 15:45:12.274790
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from pprint import pprint
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.grammar import grammar
    from blib2to3.pytree import Leaf, Node

    gram = grammar.Grammar("Grammar")
    isl = {'test': 'test', 'test2': 'test2', 'test3': 'test3', 'test4': 'test4'}
    gram.keywords = isl

    class MyParser(Parser):
        def convert(self, grammar, node):
            # print("Doing convert", node)
            return node

    def test(gram):
        p = MyParser(gram)


# Generated at 2022-06-23 15:45:17.551463
# Unit test for method classify of class Parser
def test_Parser_classify():
    def tclassify(t, w):
        p = Parser(Grammar())
        return p.classify(t, w, (1, 0))

    assert 1 == tclassify(token.NAME, "class")
    assert 2 == tclassify(token.NAME, "foo")
    assert 3 == tclassify(token.NAME, "def")
    assert 4 == tclassify(token.NUMBER, "4")
    assert 4 == tclassify(token.NUMBER, "4")
    assert 5 == tclassify(token.NUMBER, "0o11")
    assert 5 == tclassify(token.NUMBER, "0o11")
    assert 6 == tclassify(token.NUMBER, "0x1F")
    assert 6 == tclassify(token.NUMBER, "0x1F")


# Generated at 2022-06-23 15:45:22.621898
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test that the ParseError constructor properly formats the exception."""
    e = ParseError("error", 1, "value", (2, 3))
    assert e.msg == "error"
    assert e.type == 1
    assert e.value == "value"
    assert e.context == (2, 3)

# Generated at 2022-06-23 15:45:25.979486
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("test", token.PLUS, '+', (1, 0))
    assert str(e) == "test: type='+', value='+', context=(1, 0)"


# Generated at 2022-06-23 15:45:34.951442
# Unit test for method shift of class Parser
def test_Parser_shift():
    class MockGrammar:
        def __init__(self):
            self.dfas = {1: [[(1, 1)], {}]}
            self.tokens = {1: 1, 2: 2}

    class MockConvert:
        def __init__(self):
            self.calls = []

        def __call__(self, grammar: Grammar, node: RawNode) -> Union[Node, Leaf]:
            self.calls.append(node)
            return node

    grammar = MockGrammar()
    convert = MockConvert()

    # Empty input
    parser = Parser(grammar, convert)
    parser.setup()
    assert parser.rootnode is None
    assert convert.calls == []
    # One token
    parser = Parser(grammar, convert)
    parser.setup()


# Generated at 2022-06-23 15:45:37.105656
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.classify(token.INDENT, "", "")
    p.classify(token.NAME, "if", "")


# Generated at 2022-06-23 15:45:41.286160
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("this is a test", 1, "testvalue", ("testfile", 1, 8))
    except ParseError as e:
        assert e.msg == "this is a test"
        assert e.type == 1
        assert e.value == "testvalue"
        assert e.context == ("testfile", 1, 8)
    else:
        assert 0, "didn't catch exception"

# Generated at 2022-06-23 15:45:52.683406
# Unit test for constructor of class ParseError
def test_ParseError():
    class Source(object):
        def __init__(self, source: Sequence[int]) -> None:
            self.source = source
            self.lines = source
            self._index = 0
        def readline(self) -> Optional[Text]:
            try:
                line = self.lines[self._index]
            except IndexError:
                return None
            self._index += 1
            if isinstance(line, str):
                return line + '\n'
            else:
                return line
    class Context(object):
        source = Source([])

        def __init__(self, source: Optional[int], node: Optional[int]) -> None:
            if source is not None:
                self.source = source
            if node is not None:
                self.node = node

# Generated at 2022-06-23 15:46:04.337042
# Unit test for constructor of class Parser
def test_Parser():
    from .grammar import Grammar
    from . import token

    grammar = Grammar(testgrammar[1])
    p = Parser(grammar)
    p.setup()

    def feed(input):
        for type, val, context in input:
            result = p.addtoken(type, val, context)
            if result:
                return

    p.addtoken(token.NUMBER, "0", None)
    p.addtoken(token.DOT, ".", None)
    p.addtoken(token.NUMBER, "0", None)
    p.addtoken(token.NEWLINE, "\n", None)

    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NEWLINE, "\n", None)


# The following test grammar produces an

# Generated at 2022-06-23 15:46:13.355840
# Unit test for function lam_sub
def test_lam_sub():
    from . import pygram
    from blib2to3.pytree import Leaf, Node

    g = pygram.python_grammar
    n = (1, None, None, [])
    lam_sub(g, n)
    expected_str = """\
python_grammar
"""
    assert str(n) == expected_str
    assert n[-1] is None
    n = (1, None, None, [(1, None, None, [(1, "foo", None, None)])])
    lam_sub(g, n)
    assert str(n) == expected_str

# Unit test

# Generated at 2022-06-23 15:46:18.678533
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("foo", 0, "x", None)
    except ParseError as e:
        assert str(e) == (
            "foo: type=0, value='x', context=None"
        ), "str(ParseError) not as expected"
        if str(e) != "foo: type=0, value='x', context=None":
            raise RuntimeError("test_ParseError() failed")

# Generated at 2022-06-23 15:46:29.395477
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammars
    from .parse import ParseError
    from .tokenize import tokenize
    from .token import NAME
    from .driver import Driver
    from . import dgld_driver
    p = Parser(grammars.Grammar())
    p.setup()
    pdrv = dgld_driver.Driver()
    scan_func = pdrv.scan_func
    test_str = "a = 1"
    tokens = tokenize.generate_tokens(test_str.__iter__().__next__)
    # tokens = tokenize.generate_tokens(test_str.__iter__().__next__)
    for t in tokens:
        print(t)
        t = scan_func(t)
        print(t)

# Generated at 2022-06-23 15:46:40.341482
# Unit test for method pop of class Parser
def test_Parser_pop():
    class TestParser(Parser):
        def __init__(self, grammar, convert):
            super().__init__(grammar, convert)
            self.stack = [('1', 1, None)]

    class TestGrammar(object):
        def __init__(self):
            self.start = 1
            self.labels = {'1': (1, None), '2': (2, None), '3': (3, None)}
            self.keywords = {'4': 4}
            self.tokens = {5: 5, 6: 6}

# Generated at 2022-06-23 15:46:50.178036
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2.grammar import grammar
    import io
    from blib2to3.pgen2.tokenize import tokenize_func

    g = grammar.Grammar(io.StringIO(grammar.python_grammar))
    p = Parser(g)
    p.setup()
    for type, value, context in tokenize_func("f()"):
        p.addtoken(type, value, context)
    assert p.rootnode.children == [Leaf(type=token.NAME, value='f')]
    assert p.rootnode.children[0].context.offset == 0


# Generated at 2022-06-23 15:46:57.660914
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("test", token.LBRACE, None, None)

    # Check for correct construction and members
    assert exc.msg == "test"
    assert exc.type == token.LBRACE
    assert exc.value is None
    assert exc.context is None

    # Check repr
    repr_exc = repr(exc)
    expected = "ParseError('test', " \
               "type=1, " \
               "value=None, " \
               "context=None)"
    assert repr_exc == expected

# Generated at 2022-06-23 15:47:05.884562
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .runtime import Grammar
    from .tokenize import generate_tokens
    from io import BytesIO
    import pytest

    # Test data
    testdata = BytesIO(b"hello world")

    # Create parser
    grammar = Grammar()
    parser = Parser(grammar, lam_sub)
    parser.setup()

    # Convert tokens
    tokens: Sequence[Tuple[int, Text, Context]]
    tokens = list(generate_tokens(testdata.readline))

    # Shift tokens
    for token in tokens:
        parser.addtoken(token[0], token[1], token[2])

# Generated at 2022-06-23 15:47:13.558999
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.classify(token.NAME, "foo", None) > 256
    assert p.classify(token.NAME, "and", None) < 256
    p2 = Parser(g)
    p2.setup()
    p2.addtoken(token.NAME, "and", None)
    assert p2.classify(token.NAME, "and", None) < 256


if __name__ == "__main__":
    import sys

    test_Parser_classify()

# Generated at 2022-06-23 15:47:16.912991
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar
    import sys
    driver.setup_grammar()
    driver.setup_pgen()
    driver.main(sys.argv[1:])



# Generated at 2022-06-23 15:47:23.284594
# Unit test for method shift of class Parser
def test_Parser_shift():
    # class ParseError(Exception):
    # token(type, flags, *values)
    # NAME = 1
    # NUMBER = 2
    # STRING = 3
    # NEWLINE = 4
    e1 = ParseError('invalid syntax', NAME, 'a', None)
    # test case 1
    p1 = Parser(grammar, convert)
    token1 = token(NAME, 0, 'a')
    p1.shift(token1.type, token1.value, 1, token1.context)
    assert p1.stack == [(dfa, 1, (1, 'a', None, None))]
    # test case 2
    p2 = Parser(grammar, convert)
    token2 = token(NAME, 0, 'a')
    p2.shift(2, 3, 4, None) #

# Generated at 2022-06-23 15:47:31.814145
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .grammar import Grammar

    from . import driver

    grammar = Grammar(driver.grammar)
    p = Parser(grammar)

    # Method setup of class Parser
    p.setup()

    # Method addtoken of class Parser
    p.addtoken(1, "def", (1, 0))
    p.addtoken(54, "blabla", (1, 4))
    p.addtoken(54, "blabla", (1, 11))
    p.addtoken(54, "blabla", (1, 18))
    p.addtoken(54, "blabla", (1, 25))
    p.addtoken(16, ":", (1, 32))
    p.addtoken(1, "def", (2, 4))

# Generated at 2022-06-23 15:47:39.321999
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver

    # Start with a simple grammar with keywords
    grammar = driver.load_grammar("data/simple3.pgen")
    # Create a parser
    parser = Parser(grammar)
    # Create a token
    tk = token.Token("NAME", "test", (1, 0), (1, 4), "")
    # Check that the token was classified correctly
    assert parser.classify(tk.type, tk.string, tk.context) == 2
    # Check that the name "test" was added to the used_name set
    assert "test" in parser.used_names

# Generated at 2022-06-23 15:47:43.201884
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("expected 'foo'", 3, "bar", "baz")
    assert exc.msg == "expected 'foo'"
    assert exc.type == 3
    assert exc.value == "bar"
    assert exc.context == "baz"

# Generated at 2022-06-23 15:47:52.520422
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.tokenize import tokenize

    from blib2to3.pgen2 import driver

    input = '''def one(a=1, *b, c=2, **d):
    return a+c
'''
    tokens = tokenize(input)

    stderr = driver.stderr
    driver.stderr = TextIOWrapper(BytesIO())
    p = driver.Driver(convert=driver.convert_parse3)
    driver.stderr = stderr

    p.setup()
    for t in tokens:
        if p.addtoken(*t):
            break
    tree = p.rootnode
    assert tree.leaves()[-1].value == "return"


# Generated at 2022-06-23 15:47:57.025639
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("msg", 1, "value", Context(('file', 1, 1, None)))
    assert err.msg == "msg"
    assert err.type == 1
    assert err.value == "value"
    assert err.context == Context(('file', 1, 1, None))

# Generated at 2022-06-23 15:48:02.641311
# Unit test for constructor of class ParseError
def test_ParseError():
    msg, type, value, context = "msg", token.INDENT, "value", Context(None, "file")
    e = ParseError(msg, type, value, context)
    assert e.msg == msg
    assert e.type == type
    assert e.value == value
    assert e.context == context

# Generated at 2022-06-23 15:48:10.225184
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .grammar import Grammar
    from .pgen import tokenize
    from .driver import Driver
    from io import StringIO

    s = '''# test_Parser_shift
    
    # this should fail
    a = 1
    '''
    driver = Driver(Grammar, "file_input", convert=lam_sub)
    try:
        driver.parse_tokens(tokenize(StringIO(s)))
        raise AssertionError('this test should fail')
    except ParseError:
        pass
    # no error if here



# Generated at 2022-06-23 15:48:18.682752
# Unit test for method setup of class Parser
def test_Parser_setup():
    class C(object):
        def __init__(self) -> None:
            self.a = 1
            self.b = -1
    class G(object):
        start = 122
        dfas = {
            122: ([([(1, 0), (2, 1)], {0: 0, 1: 1}), ([(1, 0), (2, 1)], {0: 1, 1: 1})], {0: 0, 1: 1}),
        }
    g = G()
    p = Parser(g)
    p.setup()
    assert p.grammar == g
    assert p.convert is lam_sub
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None

# Generated at 2022-06-23 15:48:25.532547
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    pygram = grammar.grammar
    pygram.load_grammar()
    nod = (2, "class", None, [(3, "name", None, None), (4, ":", None, None)])
    res = lam_sub(pygram, nod)
    a = res.children[0]
    assert a.type == 3
    assert a.value == "name"
    assert a.context is None
    assert a.children is None
    assert len(res.children) == 2

# Generated at 2022-06-23 15:48:29.624955
# Unit test for method setup of class Parser
def test_Parser_setup():
    # Data
    grammar: Grammar = Grammar()
    start: int = 10
    # Test
    parser: Parser = Parser(grammar)
    parser.setup(start)
    # Assert
    assert parser.stack == [(grammar.dfas[10], 0, (10, None, None, []))]

# Generated at 2022-06-23 15:48:38.450341
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2 import token
    import blib2to3.pgen2.grammar

    grammar = blib2to3.pgen2.grammar.Grammar()
    parser = Parser(grammar)
    token_type = token.COMMENT
    value = "1234567890"
    context = None
    ilabel = parser.classify(token_type, value, context)
    assert ilabel == 1
    token_type = token.COMMENT
    value = "123456789"
    context = None
    ilabel = parser.classify(token_type, value, context)
    assert ilabel == 1
    token_type = token.COMMENT
    value = "123456789 "
    context = None

# Generated at 2022-06-23 15:48:45.000517
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import python
    from blib2to3.pgen2 import token
    p = Parser(python)
    p.setup()
    p.addtoken(token.NAME, "x", Context(1, 0))
    p.addtoken(token.PLUS, "+", Context(1, 2))
    p.addtoken(token.NAME, "y", Context(1, 0))

# Generated at 2022-06-23 15:48:54.496165
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from pdb import set_trace

    class UnitTestGrammar(Grammar):
        """Testbed grammar for class Parser method addtoken"""

        def __init__(self) -> None:
            super().__init__()
            self.keywords = {
                "foo": 1,
                "bar": 2,
                "baz": 3,
            }
            self.tokens = {
                token.NAME: 4,
                token.NUMBER: 5,
                token.STRING: 6,
                token.NEWLINE: 7,
                token.INDENT: 8,
                token.DEDENT: 9,
            }

# Generated at 2022-06-23 15:49:02.991006
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import token

    p = Parser(grammar.Grammar(grammar.grammar, grammar.syms, grammar.tokens, {}, {}))
    p.setup()

    # Pop a nonterminal
    seq = [(token.NAME, "1", (1, 0)), (token.LPAR, "", (1, 2)), (token.RPAR, "", (1, 3))]
    for t in seq:
        p.addtoken(t[0], t[1], Context(t[2], t[2]))
    assert p.rootnode is not None



# Generated at 2022-06-23 15:49:07.620798
# Unit test for method shift of class Parser
def test_Parser_shift():
    import io
    from . import tokenize

    f = io.BytesIO(b"ab\n")
    tokens = tokenize.generate_tokens(f.readline)
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    while True:
        token = tokens.__next__()
        if not p.addtoken(token.type, token.string, token.context):
            break

# Generated at 2022-06-23 15:49:09.163966
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser.__init__.__doc__ is not None


# Unit tests for methods of class Parser

# Generated at 2022-06-23 15:49:20.312385
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from .token import NAME, NUMBER, STRING, NEWLINE
    from .syms import funcdef, parameters, atom

    def testit(t):
        print(t)
        print(t.children)
        assert len(t) == 1

    g = grammar.load_grammar(r"Grammar/Grammar")
    p = Parser(g)
    p.setup()
    p.addtoken(NAME, "foo", None)
    p.addtoken(NAME, "(", None)
    p.addtoken(NAME, "bar", None)
    p.addtoken(NAME, ")", None)
    p.addtoken(COLON, ":", None)
    p.addtoken(NEWLINE, "\n", None)
    p.addtoken(INDENT, "", None)

# Generated at 2022-06-23 15:49:22.804875
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("message", token.STRING, "hello", (1,0))


# Generated at 2022-06-23 15:49:29.237679
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .pgen_test_data import simple_grammar as grammar
    from .pgen_test_data import simple_tokens as tokens
    from .pgen_test_data import simple_ast as ast
    p = Parser(grammar)
    p.setup()
    for type, value in tokens:
        p.addtoken(type, value, None)
    assert p.rootnode == ast


# Generated at 2022-06-23 15:49:39.447532
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    from . import grammar

    # A JSON parser
    #
    #  # A JSON parser
    #
    #  # From RFC 4627
    #
    #  start = 'json'
    #    # A JSON text is a serialized object or array.
    #
    #  ?json
    #    : object
    #    | array
    #    ;
    #
    #  ?object
    #    : '{' '}'           # empty object
    #    : '{' members '}'   # non-empty object
    #    ;
    #
    #  ?array
    #    : '[' ']'           # empty array
    #    : '[' elements ']'  # non-empty array
    #    ;
    #
    #  ?members
    #    : pair

# Generated at 2022-06-23 15:49:44.361446
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError("m", 1, "v", (2, 3))
    assert p.msg == "m"
    assert p.type == 1
    assert p.value == "v"
    assert p.context == (2, 3)

# Generated at 2022-06-23 15:49:46.661132
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    f = lambda a, b: (a, b)
    assert Parser(f).addtoken(None, None, None)

# Generated at 2022-06-23 15:49:57.500796
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver

    g: Grammar = driver.load_grammar("Grammar/Python.gram")
    p: Parser = Parser(g)
    stack: List[Tuple[DFAS, int, RawNode]] = []
    stack.append((g.dfas[2], 0, (2, None, None, [])))  # "file_input"
    stack.append((g.dfas[8], 0, (8, None, None, [])))  # "stmt"
    stack.append((g.dfas[24], 0, (24, None, None, [])))  # "simple_stmt"
    stack.append((g.dfas[26], 0, (26, None, None, [])))  # "small_stmt"

# Generated at 2022-06-23 15:50:02.902848
# Unit test for method pop of class Parser
def test_Parser_pop():
    """
    >>> grammar = Grammar.from_string(
    ... '''
    ... S: x=NAME;
    ... '''
    ... )
    >>> tree = RawNode(0, u'', None, None)
    >>> parser = Parser(grammar=grammar)
    >>> parser.stack = [(None, None, tree)]
    >>> parser.pop()

    // no exception
    """

# Generated at 2022-06-23 15:50:06.091317
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()



# Generated at 2022-06-23 15:50:18.508038
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2 import driver, parse

    # The test grammar
    text = """
    start: foo | bar ;
    foo: "foo" ;
    bar: "bar" ;
    """

    # Parse test grammar
    names = {}
    g = driver.load_grammar("test.txt", text, names)
    # Parse a string
    with open("test.txt", "w") as f:
        f.write("foo")
    p = parse.Parser(g)
    p.setup()
    tok = driver.tokenize_str("foo", names)
    tok.next()
    while True:
        if p.addtoken(tok.type, tok.value, tok.context):
            break
        tok.next()

# Generated at 2022-06-23 15:50:27.120960
# Unit test for method push of class Parser
def test_Parser_push():

    class Grammar(object):
        def __init__(self, start: int, dfas: Dict[int, DFAS]) -> None:
            self.start = start
            self.dfas = dfas

    class DFA(object):
        def __init__(self, states: Sequence[Union[List[Tuple[int, int]], Tuple[int, int]]]) -> None:
            self.states = states

    start = 0
    dfas = {}
    dfas[0] = (([(105, 1), (103, 2)], (0, 0)), {})
    dfas[1] = (([(106, 1)], (0, 1)), {})
    dfas[2] = (([(106, 2)], (0, 2)), {})

# Generated at 2022-06-23 15:50:32.973740
# Unit test for function lam_sub
def test_lam_sub():
    newnode = Node(type=1, children=[], context=None)
    lam_sub(None, (1, None, None, [newnode]))
    try:
        lam_sub(None, (1, None, None, None))
    except AssertionError:
        pass
    else:
        raise RuntimeError