

# Generated at 2022-06-23 15:40:30.664745
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver as driver_mod

    driver = driver_mod.Driver(None, None)
    parser = Parser(driver.grammar)
    parser.setup()
    parser.shift(token.NAME, "NAME", 1, 1)

# Generated at 2022-06-23 15:40:41.815074
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from . import token

    gram = grammar.Grammar([], [], {})
    p = Parser(gram)
    p.setup()

    # test case taken from Grammar/Grammar/python.g
    test_node = (
        token.STRING,
        '"string"',
        None,  # context
        [],
    )

    # make sure we have the right type of node
    new_node = lam_sub(gram, test_node)
    assert isinstance(new_node, Leaf)

    # make sure it has the right contents
    assert new_node.value == '"string"'
    assert new_node.type == token.STRING

    # make sure it has the right children
    assert new_node.children == []

# Generated at 2022-06-23 15:40:51.543315
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Unit test for method addtoken of class Parser.

    This must be run before calling addtoken the first time.

    """
    p = Parser(stream_start, [lam_sub])
    p.setup()
    for i in range(10):
        p.addtoken(i, str(i), -i)
    assert len(p.stack) == 1
    assert len(p.stack[0][2][3]) == 10
    for i in range(9, -1, -1):
        p.addtoken(-i, -str(i), i)
    assert len(p.stack) == 1
    assert len(p.stack[0][2][3]) == 20
    p.setup()  # reset the parser

# Generated at 2022-06-23 15:40:54.821302
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(None, None)     # type: ignore
    p.setup()


# Generated at 2022-06-23 15:41:03.803468
# Unit test for method push of class Parser
def test_Parser_push():
    # Run this code with coverage to ensure it gets executed.
    # (This is a function because coverage counts line coverage
    # within functions.)
    from .grammar import tokenmap
    from . import parsetok
    from .grammar import Grammar
    from blib2to3.pgen2.parse import ParseError
    from .parser import Parser
    from . import token
    from . import driver

    try:
        p = Parser(Grammar(parsetok.pgen), driver.convert)
    except ParseError:
        pass
    tok_name = tokenmap.tok_name
    list(tok_name.items())
    repr(tok_name)
    repr(token.token_map)
    repr(token.tokens)
    str(token.tokens)


# Generated at 2022-06-23 15:41:11.808804
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .token import tokenize
    from .grammar import Grammar

    # The grammar
    g = r"""
    program: function_decl*
    function_decl: NAME NAME parameters block
    # Note that NAME NAME means 'NAME NAME'
    # The special name LPAR is reserved for '('
    parameters: LPAR parameters RPAR | NAME NAME parameters | NAME
    block: LBRACE stmts RBRACE
    stmts: stmt+
    stmt: NAME EQUAL NAME | NAME LPAR NAME RPAR NAME | NAME
    """
    g = Grammar(g)

    # The parser
    p = Parser(g)
    p.setup()

    # The program
    p1 = "draw text(a, b, c);"

    # The tokens
    tokens = list(tokenize(p1))

    #

# Generated at 2022-06-23 15:41:24.832612
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import parser  # Avoid shadowing by local imports
    from . import driver

    if __debug__:
        # This is a unit test for the method addtoken of the class Parser
        test = """\
        x = 5 + y
        """
        import io
        from . import tokenize

        encoding = "utf-8"
        f = io.BytesIO(test.encode(encoding))
        tokens = list(tokenize.generate_tokens(f.readline))
        p = parser.Parser(driver.parse_grammar())
        p.setup()
        for type, value, span, context in tokens:
            if p.addtoken(type, value, context):
                break
        assert p.rootnode
        assert p.rootnode[0] == "file_input"

# Generated at 2022-06-23 15:41:25.927247
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = Grammar('raise')
    p = Parser(grammar)
    assert p.classify(token.NAME, "raise", None) == grammar.keywords["raise"]

# Generated at 2022-06-23 15:41:34.480147
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import io
    import unittest
    class ParserTestCase(unittest.TestCase):
        def setUp(self):
            import blib2to3.pgen2.driver as b2pdriver
            self.grammar = b2pdriver.load_grammar('Python.g3')
            self.parser = Parser(self.grammar, lam_sub)
            self.parser.setup()
            self.buffer = io.StringIO()
            self.readline = sys.stdin.readline
            sys.stdin = self.buffer
        def tearDown(self):
            sys.stdin = self.readline
        def test_normal(self):
            self.buffer.write('1')
            self.buffer.seek(0) # Rewind the buffer for the next input

# Generated at 2022-06-23 15:41:47.798016
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    import StringIO
    from blib2to3.pgen2.driver import Driver
    import blib2to3.pgen2.tokenize as tokenize

    class Test(unittest.TestCase):
        g = None

        def setUp(self):
            # Initialize things used by all tests
            if self.g is None:
                g = Grammar("""
                    start: NAME NAME
                    """)
                g.add_production("""
                    start: NAME NAME
                    """)
                self.g = g

        def test1(self):
            with self.assertRaises(ParseError) as cm:
                p = Parser(self.g)
                p.setup(start="start")
                p.addtoken(token.NAME, "abcde", (1, 1))
           

# Generated at 2022-06-23 15:41:48.816363
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from blib2to3.pgen2.parse import test_Parser_addtoken
    test_Parser_addtoken(Parser)

# Generated at 2022-06-23 15:41:52.744405
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("test msg", 0, "test value", None)
    assert str(pe) == "test msg: type=0, value='test value', context=None"

# Generated at 2022-06-23 15:42:00.658598
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def check(p, type, value, context, end=0, stack=None):
        if stack is not None:
            assert len(p.stack) == len(stack)
            for (dfa1, state1, node1), (dfa2, state2, node2) in zip(p.stack, stack):
                assert len(dfa1) == len(dfa2)
                for a1, a2 in zip(dfa1, dfa2):
                    assert len(a1) == len(a2)
                    for (ilabel1, nextstate1), (ilabel2, nextstate2) in zip(a1, a2):
                        assert ilabel1 == ilabel2
                        assert nextstate1 == nextstate2
                assert state1 == state2
                assert node1 == node2

# Generated at 2022-06-23 15:42:12.533693
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from .pgen2 import tokenize

    g = grammar.Grammar(tokenize.generate_tok_strings())

    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, '1', (1, 0))
    p.addtoken(token.NUMBER, '2', (1, 2))
    p.addtoken(token.PLUS, '+', (1, 4))
    p.addtoken(token.NAME, 'foo', (1, 6))
    p.addtoken(token.EQUAL, '=', (1, 10))
    p.addtoken(token.NAME, 'bar', (1, 12))
    p.addtoken(token.EQUALS, '==', (1, 16))

# Generated at 2022-06-23 15:42:14.559502
# Unit test for method pop of class Parser
def test_Parser_pop():
    assert (1, 2) == pop(__class__, 'a', 2, 1, 2)



# Generated at 2022-06-23 15:42:21.907017
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar


# Generated at 2022-06-23 15:42:33.042834
# Unit test for method classify of class Parser
def test_Parser_classify():
    # test parser method's classification of tokens to labels

    # Mangle the grammar's tables.  This allows testing of class Parser
    # because it too accesses the tables.
    from . import pgen2 as grammar

    # Create a grammar object from the grammar's tables
    grammar_obj = grammar.Grammar(grammar.pgen.pgen.grammar)

    # Create a parser object from the grammar
    parser_obj = Parser(grammar_obj)

    # Create an object for the start rule, just to verify the call.
    # The object is not used by this test.
    start_obj = parser_obj.convert(grammar_obj, (0, None, None, []))

    # Assume we want to test on token NAME.
    # We need to know its label.

# Generated at 2022-06-23 15:42:36.614377
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .pgen2 import driver
    import sys
    g = driver.load_grammar(sys.argv[1])
    p = Parser(g)
    p.setup()
    p.pop()



# Generated at 2022-06-23 15:42:38.964299
# Unit test for method setup of class Parser
def test_Parser_setup():
    g = Grammar()
    p = Parser(g)
    p.setup()


# Generated at 2022-06-23 15:42:50.338870
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest

    class TestParser(unittest.TestCase):
        # Unit test for method shift of class Parser
        def test_shift(self):
            from .pgen2 import driver as pgen

            g = pgen.load_grammar(__file__)
            p = Parser(g)
            p.setup()

            # Check that the node is unchanged
            p.shift(token.NAME, "x", 0, None)
            self.assertEqual(p.stack[0][2][3], [])

        def test_parse_error(self):
            from .pgen2 import driver as pgen

            g = pgen.load_grammar(__file__)
            p = Parser(g)
            p.setup()
            # Check that a SyntaxError is raised
            self.assertRa

# Generated at 2022-06-23 15:42:52.200736
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError("foo", None, None, "bar")

# Generated at 2022-06-23 15:43:03.694687
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.parse import Parser
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.pgen import Lark
    from blib2to3.pgen2.tokenize import driver
    from blib2to3.pgen2.dump import dump_grammar
    from blib2to3.pytree import Leaf
    import sys
    data = """
        a : NAME
          | NAME '->' NAME
          ;
        """
    l = Lark(data)
    d = dump_grammar(l.grammar)
    print(d, file=sys.stderr)
    p = Parser(l.grammar)
    p.setup()
    f = driver.FileStream("a.c")
   

# Generated at 2022-06-23 15:43:08.885743
# Unit test for function lam_sub
def test_lam_sub():
    """Unit test for function lam_sub."""
    g = Grammar("lam_grammar", [], [])
    # Test whether lam_sub() assumes that node[3] is not None
    try:
        lam_sub(g, (1, 2, 3, None))
    except AssertionError:
        pass
    else:
        assert False, "expected AssertionError"

# Generated at 2022-06-23 15:43:20.701396
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import parser
    from . import tokenize
    from . import symbol

    t = tokenize.generate_tokens(open("/dev/null").readline)
    p = parser.Parser(driver.Driver().grammar)
    p.setup()

    for tok in t:
        if tok[0] in [tokenize.ENDMARKER, tokenize.ENCODING]:
            # do not need to reduce
            pass
        elif tok[0] in [tokenize.COMMENT, tokenize.NL]:
            # do not need to lookahead
            pass
        else:
            # need to lookahead
            try:
                while True:
                    if p.addtoken(*tok):
                        break
            except parser.ParseError:
                p.setup()
                p

# Generated at 2022-06-23 15:43:28.820964
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar, tokenize

    # Initialize the parser
    g = grammar.grammar
    p = Parser(g)

    # Check the default start symbol
    assert p.grammar.start == g.start

    # Check that not all symbols are legal start symbols
    try:
        p.setup(1)
        assert False # Should have raised an exception
    except ValueError as e:
        assert str(e) == "NoDFADefined: Symbol #1"

    # Check that the grammar's start symbol is
    p.setup()



# Generated at 2022-06-23 15:43:35.893005
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    c = Context(0, 0, "fname")
    p = Parser(Grammar(r"x: NAME\n| NAME+"), lam_sub)
    p.setup()
    assert not p.addtoken(token.NAME, "x", c)
    assert not p.addtoken(token.NAME, "y", c)
    assert p.addtoken(token.NEWLINE, "\n", c)
    assert not p.addtoken(token.NAME, "x", c)
    assert not p.addtoken(token.NAME, "y", c)
    assert not p.addtoken(token.NAME, "z", c)
    assert p.addtoken(token.NEWLINE, "\n", c)

# Generated at 2022-06-23 15:43:47.307994
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Test whether classify raises ParseError when it should
    grammar = Grammar("""
        # *** Test cases ***
        bad_token: bad_token_1 bad_token_2
        bad_token_1: "1"
        bad_token_2: "2"
    """)
    parser = Parser(grammar)
    parser.setup()
    # A bad token should raise ParseError
    try:
        parser.addtoken(token.ENDMARKER, "", Context(-1, -1))
        assert 0, "ParseError should have been raised"
    except ParseError as e:
        assert e.msg == "bad token", e.msg  # type: ignore
        assert e.type == token.ENDMARKER, e.type  # type: ignore
        assert e.value == "", e.value

# Generated at 2022-06-23 15:43:50.266627
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar(b''))
    class DummyClass:
        pass
    dummy1 = DummyClass()
    dummy1.a = 2
    p.stack = [(1, dummy1, 3)]
    p.shift(4, 5, 6, 7)
    assert p.stack == [(1, 6, 3)]


# Generated at 2022-06-23 15:43:57.940482
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from . import tokenize

    # Create a simple grammar
    f = io.StringIO()

# Generated at 2022-06-23 15:44:09.502296
# Unit test for method push of class Parser
def test_Parser_push():
    class MockGrammar(object):
        # For testing:  return break_labels if token is break
        def __init__(self):
            self.break_labels = []
            self.tokens = {}
            self.keywords = {}
            self.dfas = {}

    # Constructor
    grammar = MockGrammar()
    parser = Parser(grammar)
    test_value = "some_value"
    test_type = "some_type"
    test_context = "some_context"
    test_newdfa = "some_newdfa"
    test_newstate = "some_newstate"

    parser.push(tokens=test_value, newdfa=test_newdfa, newstate=test_newstate, context=test_context)


# Generated at 2022-06-23 15:44:18.997494
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from . import token

    # Set up parser
    pgen = grammar.pgen()
    g = pgen.parse_grammar(g_py)
    p = Parser(g, lam_sub)

    # Set up test input
    p.setup()
    p.addtoken(token.NUMBER, "9", None)
    p.addtoken(token.PLUS, "+", None)
    p.addtoken(token.NUMBER, "9", None)
    assert p.rootnode is not None


# Parser test suite for the Python grammar


# Generated at 2022-06-23 15:44:21.574810
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("foo", token.NAME, "bar", None)
    except ParseError as err:
        assert err.msg == "foo"
        assert err.type == token.NAME
        assert err.value == "bar"
        assert err.context is None



# Generated at 2022-06-23 15:44:32.486715
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .token import NAME, NUMBER
    from .grammar import Grammar
    import os

    if os.path.isfile("Python.grammar"):
        test_grammar = Grammar()
    else:
        test_grammar = Grammar((0, NAME, "False", 5),
                               (1, NAME, "None", 5),
                               (2, NAME, "True", 5),
                               (3, NAME, "def", 5),
                               (4, NAME, "if", 5),
                               (5, NAME, "while", 5),
                               (6, NUMBER, "5", 5))

    test_context = (1,2)

# Generated at 2022-06-23 15:44:39.021834
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar

    _driver = driver.Driver()
    _grammar = grammar.grammar

    _py_grammar = _grammar.pgen

    _driver.load_grammar(_grammar)
    _driver.prepare_grammar(_py_grammar)
    test_Parser = _driver.parser
    assert test_Parser.addtoken(1, 'func', 1) is True
    assert test_Parser.addtoken(1, 'func', 1) is False

# Generated at 2022-06-23 15:44:41.684723
# Unit test for method push of class Parser
def test_Parser_push():
    # Verify that the class Parser has the expected methods
    grammar = Grammar()
    parser = Parser(grammar)
    assert parser.push(0, 0, 0, 0) is None

# Generated at 2022-06-23 15:44:48.725028
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from typing import Union, List, Tuple, Any, Optional, Text
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pytree import Node, Leaf
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pytree import Context
    from io import StringIO

    g = Grammar()

# Generated at 2022-06-23 15:44:55.557534
# Unit test for method setup of class Parser
def test_Parser_setup():
    # pylint: disable=missing-docstring

    class X(object):
        a = None

    p = Parser(X())
    p.setup()
    assert p.stack[-1][0] is X.a

    class Y(object):
        b = None

    p = Parser(Y())
    p.setup()
    assert p.stack[-1][0] is Y.b



# Generated at 2022-06-23 15:45:06.241371
# Unit test for method setup of class Parser

# Generated at 2022-06-23 15:45:07.132650
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(None)


# Generated at 2022-06-23 15:45:12.387605
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    new_g = grammar.Grammar()
    assert new_g.start == 0
    test_parser = Parser(new_g)
    test_parser.setup()
    assert test_parser.stack == [([], 0, (0, None, None, []))]
    assert test_parser.rootnode is None

# This test is a dummy since addtoken and classify both have their
# own unit tests to ensure they work properly.

# Generated at 2022-06-23 15:45:14.664211
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .token import Token
    from .grammar import Grammar

    P = Parser(Grammar())
    P.setup()
    P.shift(Token.NAME, "name", 1)
    assert P.stack[-1][2][3][0] is None


# Generated at 2022-06-23 15:45:27.160393
# Unit test for function lam_sub
def test_lam_sub():
    class LamGrammar(Grammar):
        def __init__(self) -> None:
            super().__init__()
            self.dfas = {
                1: (
                    [[(3, 1)]],
                    {0: 0, 1: 0, 2: 0, 3: 0},
                )
            }
            self.dfas[2] = (
                [[(4, 2)]],
                {0: 0, 1: 0, 2: 0, 3: 0, 4: 0},
            )
            self.lhs = {1: 0, 2: 1}
            self.labels = [(0, 0), (0, 0), (1, None), (0, 0), (0, 0)]
            self.start = 1
    grammar = LamGrammar()
    convert = lam_sub

# Generated at 2022-06-23 15:45:35.569779
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)

    token.type_to_name[token.NAME] = "NAME"
    token.type_to_name[token.NUMBER] = "NUMBER"
    token.type_to_name[token.NEWLINE] = "NEWLINE"

    class C(object):
        def __init__(self):
            self.lineno = 1
            self.offset = 2

    def classify(meth, type, value, context):
        r = meth(type, value, context)
        print(type, value, context, r)
        return r

    c = C()
    print(classify(p.classify, token.NAME, "foo", c))

# Generated at 2022-06-23 15:45:43.923298
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    from . import driver
    from . import grammar
    from . import token

    # Test the parser
    if len(sys.argv) > 1 and sys.argv[1] == "-g":
        print("Generating grammar...")
        f = open("Grammar.txt", "w")
        f.write("%s" % grammar.grammar)
        f.close()
        sys.exit(0)

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    t = driver.Driver(g, p.addtoken)
    if len(sys.argv) > 1:
        source = open(sys.argv[1]).read()
    else:
        source = sys.stdin.read()

# Generated at 2022-06-23 15:45:48.551978
# Unit test for constructor of class ParseError
def test_ParseError():
    # If this fails, all of the locations must be
    # explicitly set to None
    err = ParseError('', None, None, None)
    assert err.type is None
    assert err.value is None
    assert err.context is None
    assert err.msg

# Generated at 2022-06-23 15:45:52.777154
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from .pgen import driver

    p = driver.load_grammar("Grammar/Grammar")

    with open("Grammar/Grammar") as f:
        fstr = f.read()
    p.parse(fstr)
    lam_sub(p.grammar, [])

# Generated at 2022-06-23 15:46:04.371069
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import token

    # Test function
    def test(
        classifier: Callable[[int, Optional[Text], Context], int],
        tok_type: int,
        tok_value: Text,
        expected: int,
    ) -> None:
        result = classifier(tok_type, tok_value, None)
        if result != expected:
            print(
                f"ERROR: test(classifier, {tok_type}, {tok_value}) returned {result}, expected {expected}"
            )

    # Construct a parser
    grammar = Grammar()

# Generated at 2022-06-23 15:46:15.724967
# Unit test for method push of class Parser
def test_Parser_push():
    # a simple push
    p = Parser(Grammar())
    p.push(1, [(0, (1, 2))], 0, Context(0, 0))
    assert len(p.stack) == 2

    # a push with a convert
    p = Parser(Grammar())

    def lam_sub(grammar, node):
        return Node(type=node[0], children=node[-1], context=node[2])

    p.convert = lam_sub
    p.push(1, [(0, (1, 2))], 0, Context(0, 0))
    assert len(p.stack) == 2
    assert p.stack[-1][-1].type == 1
    assert p.stack[-1][-1].value is None

    # correct parentage

# Generated at 2022-06-23 15:46:27.019692
# Unit test for method push of class Parser
def test_Parser_push():
    # This tests the code in the push method of class Parser.
    class FakeDFA:
        def __init__(self) -> None:
            self.first = {1: 2}
    class FakeGrammar:
        def __init__(self) -> None:
            self.start = 1
            self.dfas = {0: FakeDFA(), 1: FakeDFA(), 2: FakeDFA()}
        def classify(self, type: int, value: Optional[Text], context: Context) -> int:
            return 1
    grammar = FakeGrammar()
    parser = Parser(grammar)
    parser.setup()
    parser.stack = [(None, None, (1, None, None, []))]
    parser.used_names = set()
    parser.push(2, 3, 4, 5)
   

# Generated at 2022-06-23 15:46:33.480937
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test constructor's calling sequence
    try:
        raise ParseError("msg", 1, "val", (2, 3))
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == 1
        assert e.value == "val"
        assert e.context == (2, 3)
    else:
        raise AssertionError



# Generated at 2022-06-23 15:46:40.494852
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", 1, "value", "foo")
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == 1
        assert e.value == "value"
        assert e.context == "foo"
        s = str(e)
    assert (
        "msg: type=1, value='value', context='foo'" in s
    ), "str(ParseError): %r not in %r" % (
        "msg: type=1, value='value', context='foo'",
        s,
    )

# Generated at 2022-06-23 15:46:47.705781
# Unit test for constructor of class Parser
def test_Parser():
    grammar = Grammar()
    parser = Parser(grammar)
    assert parser.grammar is grammar
    assert parser.convert is lam_sub
    assert parser.stack is None
    assert parser.rootnode is None
    parser = Parser(grammar, lam_sub)
    assert parser.grammar is grammar
    assert parser.convert is lam_sub
    assert parser.stack is None
    assert parser.rootnode is None



# Generated at 2022-06-23 15:46:49.578362
# Unit test for constructor of class Parser
def test_Parser():
    from .grammar import Grammar

    g = Grammar()
    print(g)
    p = Parser(g)
    print(p)

# Generated at 2022-06-23 15:46:59.791593
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = Grammar(r"""
        begin -> ...
        begin -> begin ...
        """)
    parser = Parser(grammar)
    parser.setup()
    parser.push(
        1,
        ([[(2, 0), (0, 0)], [(0, 2)]], {0: 0, 2: 1}),
        0,
        Context(None, None),
    )

# Generated at 2022-06-23 15:47:10.614829
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import token
    from . import gram
    import sys

    # Create a parser instance
    p = Parser(gram)

    # Define a helper function to parse one token
    p.setup()

# Generated at 2022-06-23 15:47:21.635075
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.pgen import generate_grammar
    import pprint
    grammar = generate_grammar(False)
    #pprint.pprint(grammar.labels)
    parser = Parser(grammar)
    #pprint.pprint(parser.grammar.keywords)
    #pprint.pprint(parser.grammar.tokens)
    print(parser.classify(token.NAME, "and", None))
    print(parser.classify(token.NAME, "and", None))
    print(parser.classify(token.NAME, "and", None))
    print(parser.classify(token.NAME, "and", None))
    print(parser.classify(token.NAME, "and", None))


# Generated at 2022-06-23 15:47:30.903127
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class myParser(Parser):
        def __init__(self, *args: Any) -> None:
            super().__init__(*args)
            self.tokens: List[Tuple[int, Optional[Text], Context]] = []
            self.classify_called = 0

        def classify(self, *args: Any) -> int:
            self.classify_called += 1
            return super().classify(*args)

        def addtoken(self, type: int, value: Optional[Text], context: Context) -> bool:
            for arg in (type, value, context):
                if arg is None:
                    raise ValueError("Unexpected None")
            self.tokens.append((type, value, context))
            return super().addtoken(type, value, context)


# Generated at 2022-06-23 15:47:39.524925
# Unit test for method pop of class Parser

# Generated at 2022-06-23 15:47:50.227358
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    # Test basic arithmetic expression
    t = driver.Driver("(5 - 3) * 7", "calc-arith.txt")
    p = Parser(t.grammar)
    p.setup()
    while not p.addtoken(t.token()):
        pass
    assert len(p.rootnode) == 3
    assert repr(p.rootnode[0]) == "Leaf(NUMBER,'5',1)"
    assert repr(p.rootnode[1]) == "Leaf(MINUS,'-',1)"
    assert repr(p.rootnode[2]) == "Leaf(NUMBER,'3',1)"
    assert repr(p.rootnode[3]) == "Leaf(TIMES,'*',1)"

# Generated at 2022-06-23 15:47:56.474218
# Unit test for constructor of class Parser
def test_Parser():
    from . import driver, wordtoken

    def convert(grammar, node):
        return node

    p = Parser(driver.grammar, convert)
    p.setup()
    for t in driver.word_tokenize():
        if p.addtoken(t.type, t.string, t.start):
            break


if __name__ == "__main__":
    test_Parser()

# Generated at 2022-06-23 15:47:58.529923
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser(Grammar(None, None, None, None, None, None)).stack is None

# Generated at 2022-06-23 15:48:03.863480
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Arrange
    p = Parser(None, None)

    type = "type"
    value = "value"
    state = "state"
    context = "context"

    # Act
    p.shift(type, value, state, context)

    # Assert
    assert p.stack[0][0] == None
    assert p.stack[0][1] == state
    assert p.stack[0][2][0] == type
    assert p.stack[0][2][1] == value
    assert p.stack[0][2][2] == context
    assert p.stack[0][2][3] == None

# Generated at 2022-06-23 15:48:13.930830
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver

    raw_grammar = driver.parse_grammar(
        """
        start: stmt
        stmt: NAME '=' test
        test: NAME
        test: NUMBER
    """
    )
    from .grammar import Grammar

    grammar = Grammar(raw_grammar)
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NAME, "a", None)
    parser.addtoken(token.EQUAL, "=", None)
    parser.addtoken(token.NAME, "b", None)
    parser.addtoken(token.NEWLINE, "\n", None)
    assert parser.rootnode[0] == grammar.symbol2number["stmt"]
    stmt = parser.rootnode[1]
    assert stmt[0]

# Generated at 2022-06-23 15:48:26.388154
# Unit test for method shift of class Parser
def test_Parser_shift():
  import sys
  sys.stderr.write("test_Parser_shift...")
  p = Parser(None)
  root: Node
  node: Node
  p.rootnode = root = Node('root', [])
  p.stack = [
    (None, 0, (None, None, None, root.children))
  ]
  p.shift(token.NAME, 'foo', 1, None)
  assert len(root.children) == 1
  assert type(root.children[0]) is Leaf
  assert root.children[0].type == token.NAME
  assert root.children[0].value == 'foo'
  node = Node('foo', [])
  p.shift(token.NAME, 'bar', 1, None)
  assert len(root.children) == 1

# Generated at 2022-06-23 15:48:34.296538
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    pygram = grammar.python_grammar

    p = Parser(pygram)
    p.setup()
    assert p.classify(1, "abc", (1, 0)) == 1
    assert p.classify(0, "abc", (1, 0)) == 6
    assert p.classify(2, "abc", (1, 0)) == 17
    assert p.classify(1, "if", (1, 0)) == 37
    try:
        assert p.classify(1, "abc", (1, 0)) == 9999
    except ParseError:
        pass

    p = Parser(pygram)
    p.setup()
    p.shift(1, "abc", 1, (1, 0))

# Generated at 2022-06-23 15:48:42.637050
# Unit test for function lam_sub
def test_lam_sub():
    import lib2to3.pgen2.parse
    import lib2to3.pgen2.token
    p = lib2to3.pgen2.parse.Parser(lib2to3.pgen2.parse.Grammar(
        """
        file_input: (NEWLINE | stmt)* ENDMARKER
        stmt: simple_stmt | compound_stmt
        simple_stmt: expr NEWLINE
        compound_stmt: pass_stmt
        pass_stmt: PASS NEWLINE
        expr: NAME
        """))
    p.setup()
    assert p.addtoken(lib2to3.pgen2.token.NAME, 'x', (1, 0))
    assert p.addtoken(lib2to3.pgen2.token.NEWLINE, '\n', (1, 2))
   

# Generated at 2022-06-23 15:48:44.257669
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver


# Generated at 2022-06-23 15:48:54.128126
# Unit test for method shift of class Parser
def test_Parser_shift():
    import pickle
    mp = pickle.load(open("blib2to3/pgen2/python.pickle", "rb"))
    s = Parser(mp)
    s.setup()
    leaf = Leaf
    node = Node
    nl = NL

# Generated at 2022-06-23 15:48:55.810707
# Unit test for constructor of class Parser
def test_Parser():
    g = Grammar()
    p = Parser(g)

# Generated at 2022-06-23 15:49:04.694587
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import pgen2
    from . import token
    import io

    def test_Parser_addtoken(text, expected_token_type, expected_token_value):
        grammar = pgen2.grammar.Grammar(io.StringIO(text))
        p = Parser(grammar)
        p.setup(start="start")
        p.addtoken(expected_token_type, expected_token_value, None)

    test_Parser_addtoken("""
                          start: "a" NAME "b"
                          """,
                          token.NAME,
                          "testname")
    test_Parser_addtoken("""
                          start: INT NUMBER
                          """,
                          token.INT,
                          "123")

# Generated at 2022-06-23 15:49:08.407970
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError(msg="msg", type=2, value="value", context="context")
    assert str(e) == "msg: type=2, value='value', context='context'"
    # Verify the ParseError method fields are the same as on the instance
    for name in "msg", "type", "value", "context":
        assert getattr(ParseError, name) is getattr(e, name)


# Generated at 2022-06-23 15:49:19.444851
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver

    def test_shift(toks: Sequence[Any], nexttoks: Sequence[Any], tok: Any):
        p = driver.Parser(toks)

        # get next token (not shifted)
        t = p.gettok()
        assert t == tok
        # shift token
        p.shift()
        # new peek should be nexttok
        t = p.gettok()
        assert t == nexttoks[0]
        toks = tokens = nexttoks[:]

        # check that remaining tokens are as expected
        while 1:
            try:
                t = p.gettok()
                assert t == toks[0]
                p.shift()
                toks = toks[1:]
            except driver.TokenError:
                return


# Generated at 2022-06-23 15:49:20.814693
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("foo", None, None, None)
    assert e.msg == "foo"



# Generated at 2022-06-23 15:49:30.740799
# Unit test for constructor of class Parser
def test_Parser():
    """Unit test for class Parser."""
    # Import this module's grammar
    import blib2to3.pgen2.grammar as pgen2_grammar
    g = pgen2_grammar
    # Construct the parsing engine
    p = Parser(g)
    # Check it
    assert g is p.grammar
    assert p.convert is lam_sub
    # This must work:
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.DEDENT, "", Context(2, 0))
    p.addtoken(token.NEWLINE, "", Context(2, 0))

# Generated at 2022-06-23 15:49:38.907026
# Unit test for constructor of class Parser
def test_Parser():
    # Verify that the constructor doesn't blow up
    import sys
    import os
    import blib2to3.pgen2.driver
    import blib2to3.pygram
    here = os.path.dirname(__file__) or os.curdir
    driver = blib2to3.pgen2.driver.Driver(blib2to3.pygram.python_grammar_no_print_statement,
                                          convert=blib2to3.pygram.convert_grammar,
                                          logger=sys.stderr)
    driver.load_grammar(os.path.join(here, "Grammar.txt"))

# ____________________________________________________________
# Main program for testing


# Generated at 2022-06-23 15:49:45.314556
# Unit test for function lam_sub

# Generated at 2022-06-23 15:49:55.650963
# Unit test for method push of class Parser
def test_Parser_push():
    import re
    import sys
    from . import token

    # Set up a Parser
    class DummyGrammar:
        def __init__(self) -> None:
            # Fake a DFA
            self.dfas = {0: ([[(0, 0)], [(1, 1), (3, 2)], [(3, 2)], [(3, 2)]], {0: 0, 1: 1, 2: 2, 3: 3})}

    dummy_grammar = DummyGrammar()

    # Test 1: push with label 0
    parser = Parser(dummy_grammar)
    parser.setup()
    parser.stack = [(dummy_grammar.dfas[0], 0, (0, None, None, []))]

# Generated at 2022-06-23 15:50:00.183238
# Unit test for function lam_sub
def test_lam_sub():
    class g(object):
        class labels(object):
            def __getitem__(self, name):
                return name
    gr = g()
    def convert(gr, node):
        return None
    assert lam_sub(gr, (1, 2, 3, [4])) is None

# Generated at 2022-06-23 15:50:07.577400
# Unit test for method classify of class Parser
def test_Parser_classify():
    from unittest import makeSuite, TestCase, TestLoader
    import sys

    class TestParser(TestCase):
        def test_classify(self):
            from . import parsetok
            from . import token
            from . import symbol
            from . import grammar
            from .pgen import generate_grammar

            g: Grammar = generate_grammar(sys.stdin)

            p = Parser(g)

            tokens = parsetok.generate_tokens(sys.stdin.readline)
            for _, value, _, _, _ in tokens:
                p.classify(token.NAME, value, str(1))

    return makeSuite(TestParser)

__all__ = ["Parser", "ParseError", "lam_sub"]

# Generated at 2022-06-23 15:50:13.452725
# Unit test for constructor of class Parser
def test_Parser():
    try:
        from . import driver
        from .pgen import grammar
    except ImportError:
        print("Can not test class Parser; pgen.driver or pgen.grammar not found")
        return

    parser = Parser(grammar)
    parser.setup()
    driver.tokenize_file(parser, "try_stmt.py")

# Generated at 2022-06-23 15:50:23.852039
# Unit test for function lam_sub
def test_lam_sub():
    from .grammar import Grammar

    g = Grammar()
    p = g.p
    p.addRule("file_input", [ "(", "stmt", ")" ], None)
    p.addRule("stmt", [ "expr" ], None)
    p.addRule("expr", [ "x" ], None)
    p.start = "file_input"
    p.symbol2number = { "file_input": 256, "stmt": 257, "expr": 258, "x": 259 }
    p.number2symbol = { 256: "file_input", 257: "stmt", 258: "expr", 259: "x" }

# Generated at 2022-06-23 15:50:24.756407
# Unit test for method setup of class Parser
def test_Parser_setup():
    assert True

# Generated at 2022-06-23 15:50:37.103387
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import tokenize
    from . import grammar

    # Create some mock grammar, token, and tokenizer data to test with
    mock_grm = grammar.Grammar()
    mock_grm.start = 256
    mock_grm.tokens = {3: 2}
    mock_grm.keywords = {}
    mock_grm.dfas = {
        256: ([[], []], {"\n": 0, "#": 1}),
        3: ([[], []], {"\n": 0, "#": 1}),
    }
    mock_grm.labels = ((3, "NL"), (3, "COMMENT"))

    mock_tokens = [(3, "\n"), (3, "COMMENT")]
