

# Generated at 2022-06-23 15:40:33.126204
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    assert grammar.Grammar()
    Parser(grammar.Grammar())

# Generated at 2022-06-23 15:40:36.828713
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(None)

if __name__ == "__main__":
    import unittest

    unittest.main("blib2to3.pgen2.driver_test", verbosity=2)

# Generated at 2022-06-23 15:40:47.464344
# Unit test for method setup of class Parser
def test_Parser_setup():
    import os.path
    import sys
    import blib2to3.pgen2.grammar as pgen
    import blib2to3.pgen2.parse as parse
    import blib2to3.pygram as token
    from . import driver
    from . import pytree

    # Load the pickled grammar
    grammar = pgen.grammar
    assert isinstance(grammar, pgen.Grammar)

    # Create a new parser
    p = parse.Parser(grammar, pytree.convert)

    # Parse a start rule from the grammar file itself
    path = os.path.join(os.path.dirname(__file__), "Grammar.txt")
    with open(path, encoding="utf-8") as f:
        test = f.read(100)

# Generated at 2022-06-23 15:40:51.889239
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver, tokenize
    from .pgen_grammar import pgen_grammar

    d = driver.Driver(pgen_grammar, convert=lam_sub)
    for t in tokenize.generate_tokens(open('../blib2to3/Grammar.txt')):
        print(t)
        d.addtoken(t)
    print(d.rootnode)

# Generated at 2022-06-23 15:40:57.763310
# Unit test for constructor of class Parser
def test_Parser():
    g = Grammar()
    p = Parser(g)
    assert p.grammar == g
    assert p.convert is lam_sub
    def convert(grammar, node):
        return node
    p = Parser(g, convert)
    assert p.grammar == g
    assert p.convert is convert

# Generated at 2022-06-23 15:41:09.735328
# Unit test for method shift of class Parser
def test_Parser_shift():
    t = token
    import sys
    p = Parser(sys.modules[__name__].__dict__["grammar"])
    p.setup()
    p.addtoken(t.NAME, "NAME1", (1, 1))
    p.addtoken(t.NAME, "NAME2", (1, 1))
    p.addtoken(t.NAME, "NAME3", (1, 1))
    p.addtoken(t.NAME, "NAME4", (1, 1))
    p.addtoken(t.NAME, "NAME5", (1, 1))
    p.addtoken(t.NAME, "NAME6", (1, 1))
    p.addtoken(t.NAME, "NAME7", (1, 1))
    p.addtoken(t.NAME, "NAME8", (1, 1))
   

# Generated at 2022-06-23 15:41:22.479831
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    class TestGrammar(grammar.Grammar):
        tokens = {}

    class TestNode(Node):
        pass

    def lam_sub(grammar, node):
        return TestNode(type=node[0], children=node[3], context=node[2])

    test_grammar = TestGrammar(
        """foo: bar baz
                   | bar
                   ;
                """
    )
    parser = Parser(test_grammar, lam_sub)
    parser.setup()
    parser.addtoken(1, "bar", None)
    parser.addtoken(2, "baz", None)
    assert isinstance(parser.rootnode, TestNode)
    assert parser.rootnode.type == "foo"

# Generated at 2022-06-23 15:41:31.040491
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .pgen2 import driver

    g = driver.load_grammar("Grammar/Grammar", convert=lam_sub)
    p = Parser(g)
    assert p.classify(token.NAME, "x", None) == 1
    assert p.classify(token.NAME, "def", None) == 261
    assert p.classify(token.STRING, "x", None) == 8
    assert p.classify(token.STRING, "...", None) == 9
    try:
        p.classify(token.NAME, "abc", None)
    except ParseError:
        pass
    else:
        assert False, "expected ParseError"

# Generated at 2022-06-23 15:41:37.724433
# Unit test for method push of class Parser
def test_Parser_push():
    """
    Test method push of class Parser.
    """

    # This is a very simplified variant of the grammar used to test the
    # push method of class Parser. The grammar, which is given in [[abstract_grammar_syntax]],
    # contains only three symbols:
    # 'A', which is the start symbol, 'a', a terminal and 'b', a non-terminal.
    # The states 0, 1 and 2 of the DFA corresponding to A are
    #  0: (0,0) (1,1) and
    #  1: (1,1) (0,1) and
    #  2: (2,2)
    # The states 0 and 1 of the DFA corresponding to b are
    #  0: (0,0) (1,1) and
    #  1: (1,

# Generated at 2022-06-23 15:41:49.931697
# Unit test for method setup of class Parser
def test_Parser_setup():
    import unittest
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    try:
        from blib2to3.pgen2 import tokenize
        from blib2to3.refactor import get_fixers_from_package
        from blib2to3.pgen2 import driver
        from blib2to3.pygram import python_symbols as syms
        from blib2to3.pgen2 import grammar
        from blib2to3.pgen2.parse import ParseError
        from blib2to3 import pytree
        from blib2to3.fixer_base import FixerError
    finally:
        sys.path.pop(0)

# Generated at 2022-06-23 15:41:55.401053
# Unit test for constructor of class Parser
def test_Parser():
    class FakeGrammar:
        start = 34
        dfas = {}
    from . import driver
    from . import converter

    grammar = driver.load_grammar("Grammar.txt")
    p = Parser(grammar, converter.convert)
    p.setup()

    assert isinstance(p.grammar, Grammar)
    assert p.convert is converter.convert

test_Parser()

# Generated at 2022-06-23 15:42:02.057749
# Unit test for method classify of class Parser
def test_Parser_classify():
    from textwrap import dedent

    from . import grammar, tokenize, token

    from .uniflat import format_grammar, find_categories

    from .uniflat import _C as C

    from .patcomp import compile_uniflat_grammar

    from .pgen2 import driver

    # Format grammar
    formatted_grammar = format_grammar(grammar)

    # Write formatted grammar to disk
    filename = 'test_Parser_classify_g.py'
    with open(filename, 'w') as f:
        f.write(dedent(formatted_grammar).rstrip() + '\n')

    # Compile grammar
    driver.run_pgen(filename)
    # Read compiled grammar
    with open(filename + 'c', 'rb') as f:
        c = f.read()



# Generated at 2022-06-23 15:42:09.143357
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar as G

    g = G.Grammar(grammar_nts=[0, 1], grammar_dfas={0: [[(0, 0), (0, 1)], [(1, 1)]], 1: [[(0, 2), (0, 3)], [(2, 3)], [(0, 0)]]})

    lam_sub(g, [1, None, None, [[0, None, None, []]]]) == [[1, None, None, [0]]]

# Generated at 2022-06-23 15:42:10.997272
# Unit test for method setup of class Parser
def test_Parser_setup():
    parser = None
    assert parser.stack == None
    assert parser.rootnode == None
    assert parser.used_names == set()


# Generated at 2022-06-23 15:42:18.689884
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import pprint
    import blib2to3.pgen2.driver
    print("Test Parser.addtoken")
    grammar = blib2to3.pgen2.driver.load_grammar("Examples/Calc/Grammar.txt")
    p = Parser(grammar)
    s = "2 + 3 * (4 - 5)"
    p.setup()
    for t in blib2to3.pgen2.driver.tokenize(s):
        print(repr(t))
        if p.addtoken(t.type, t.string, t.context):
            print("Result:")
            pprint.pprint(p.rootnode)
            break

# Generated at 2022-06-23 15:42:29.853679
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Unit test for method pop of class Parser"""
    import blib2to3.pgen2.grammar, blib2to3.pgen2.parse
    parse = blib2to3.pgen2.parse

    # Processing of an empty list
    g = blib2to3.pgen2.grammar.Grammar()
    g.add_nonterminal('start', [])
    g.add_terminal('end', '', 'pass')
    p = blib2to3.pgen2.parse.Parser(g)
    p.setup()
    p.pop()
    assert p.rootnode == (1, 'start', None, [])

    # Base case with just one non-empty list
    g = blib2to3.pgen2.grammar.Grammar()
    g

# Generated at 2022-06-23 15:42:37.740804
# Unit test for method push of class Parser
def test_Parser_push():
    class TestGrammar(Grammar):
        symbols = {'a': 3}
        states = {
            0: [[(1, 1), (2, 1)], [(3, 1), (0, 2)]],
            1: [[(0, 1)]],
            2: [[(0, 1)]],
        }
        start = 0
    test_grammar = TestGrammar()
    parser = Parser(test_grammar)
    parser.setup(start=0)
    parser.stack = [(test_grammar.dfas[0], 0, (0, None, None, [])),
                    (test_grammar.dfas[1], 0, (1, None, None, []))]
    parser.push(0, test_grammar.dfas[0], 2, Context(3))

# Generated at 2022-06-23 15:42:49.809021
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    tokenize = token.tokenize
    untokenize = token.untokenize
    parse_tokens = Parser(grammar.grammar).parse_tokens

    def test(input: Text, next_token: Sequence[int] = [-1, -1]) -> int:
        tokens, _ = tokenize(iter([input + "\n"]).__next__, "exec")
        if next_token[0] >= 0:
            tokens.append((next_token[0], next_token[1]))
        print("tokens:")
        print("\n".join("%r" % t[1] for t in tokens))
        p = Parser(grammar.grammar)
        p.setup()

# Generated at 2022-06-23 15:42:55.719314
# Unit test for method push of class Parser
def test_Parser_push():
    from . import tokenize
    from . import driver

    from . import grammar
    from .grammar import Grammar
    from typing import Dict, Any, List, Tuple, Set

    Tree = Dict[Text, Any]

    class pgenParser(Parser):
        def __init__(self, grammar: Grammar, convert=None) -> None:
            Parser.__init__(self, grammar, convert)

        def classify(self, type, value, context):
            return self.grammar.tokens[type]

    def test_Parser_push_1() -> None:
        "Test method push of class Parser"


# Generated at 2022-06-23 15:43:02.558702
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import token

    # When the token is NAME, value is a string
    p = Parser(Grammar())
    p.setup()
    p.addtoken(token.NAME, "x", None)
    # Type error if the value is not a string
    try:
        p.shift(token.NAME, 42, 0, None)
    except AssertionError: 
        pass
    else:
        assert False  # Unexpectedly did not get an AssertionError



# Generated at 2022-06-23 15:43:08.325389
# Unit test for function lam_sub
def test_lam_sub():
    from . import example
    from . import driver

    # Load the grammar and create a parser
    p = Parser(example.example_grammar, lam_sub)
    # Parse an input string
    p.setup()
    for t in driver.tokenize("a = 3"):
        p.addtoken(*t)
    t = driver.tokenize("b = 4")
    p.addtoken(-1, "", (0, 0))
    # Get the tree
    tree = p.rootnode
    # tree should be ((file_input, NL, (1, 0), [(((4, (1, 4), (1, 4), [((4, (1, 4), (1, 4), [((4, (1, 4), (1, 4), [((2, (1, 4), (1, 4), [((7,

# Generated at 2022-06-23 15:43:16.655032
# Unit test for method shift of class Parser
def test_Parser_shift():
    import pprint
    from pprint import pprint
    from . import token
    from . import grammar
    import logging
    import os
    from .token import string_to_tokens
    from .pgen2 import generate_grammar
    from . import driver

    logging.basicConfig(format="%(levelname)s:%(message)s", level=logging.INFO)

    g = generate_grammar()
    a = Parser(g)


# Generated at 2022-06-23 15:43:22.563933
# Unit test for method classify of class Parser
def test_Parser_classify():
    from pytree_builder import PyTreeBuilder
    from blib2to3.pgen2.driver import Driver

    driver = Driver(
        PyTreeBuilder,
        convert=PyTreeBuilder.convert,
        verbose=True
    )
    grammar = driver.load_grammar("Python.gram")
    parser = Parser(grammar)
    assert parser.classify(token.NAME, "a", None) == 2
    assert parser.classify(token.BREAK, None, None) == 1


# Generated at 2022-06-23 15:43:33.013870
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest

    class TestParser(unittest.TestCase):
        def setUp(self):
            self.parser = Parser(grammar=None, convert=lam_sub)
            self.parser.stack = []

        # Function to be tested
        def test_shift(self):
            self.parser.shift(type=1, value='2', newstate=3, context=4)
            self.assertEqual(len(self.parser.stack), 1)

            self.assertEqual(self.parser.stack[0][0], None)
            self.assertEqual(self.parser.stack[0][1], 3)
            self.assertEqual(self.parser.stack[0][2][0], 1)
            self.assertEqual(self.parser.stack[0][2][1], '2')

# Generated at 2022-06-23 15:43:44.528802
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from blib2to3.pgen2 import driver

    g = driver.load_grammar("Grammar/Grammar")
    p = Parser(g)
    p.setup()
    p.addtoken(token.STRING, '"hi"', (1, 0))
    p.addtoken(token.NEWLINE, '\n', (1, 4))
    p.addtoken(token.ENDMARKER, '', (2, 4))
    expected = [("STRING", '"hi"'), ("NEWLINE", '\n'), ("ENDMARKER", '')]
    result = [(t.type, t.value) for t in p.rootnode.leaves()]
    assert result == expected

# Generated at 2022-06-23 15:43:55.458882
# Unit test for function lam_sub
def test_lam_sub():
    g = Grammar()
    class DummyNode(object):
        def __init__(self, type, children):
            self.type = type
            self.children = children
    # Token
    node = DummyNode(type=1, children=None)
    assert lam_sub(g, node) is None
    # Symbol
    node = DummyNode(type=257, children=None)
    assert lam_sub(g, node) is None
    # Symbol with children
    node = DummyNode(type=257, children=[DummyNode(1, None), DummyNode(2, None)])
    res = lam_sub(g, node)
    assert isinstance(res, Node)
    assert res.type == 257

# Generated at 2022-06-23 15:44:06.219961
# Unit test for method setup of class Parser
def test_Parser_setup():
    # From Lib/test/test_grammar.py
    from . import driver
    from . import tokenize


# Generated at 2022-06-23 15:44:06.771592
# Unit test for method shift of class Parser
def test_Parser_shift():
    pass

# Generated at 2022-06-23 15:44:13.936545
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import parser, token

# Generated at 2022-06-23 15:44:22.784654
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import parser
    from . import tokenize
    from . import symbol
    from . import token

    # Set up the parser.
    grammar = parser.expr_grammar
    parser.Parser(grammar)
    # Create an example string.
    s = "1+1"
    # Tokenize it.
    gen = tokenize.tokenize(s.encode("utf-8").splitlines(True))
    tokens = [(ttype, tstr) for ttype, tstr, _, _, _ in gen]
    # Should be [NUMBER('1'), OP('+'), NUMBER('1')]
    # Parse it.
    p = parser.Parser(grammar)
    p.setup(symbol.expr)

# Generated at 2022-06-23 15:44:29.531030
# Unit test for constructor of class Parser
def test_Parser():
    """Test the Parser constructor.

    >>> g = Grammar()
    >>> p = Parser(g)
    >>> p.convert is None
    True
    >>> def myconvert(grammar, node):
    ...     assert grammar is g
    ...     assert node == (0, None, None, [])
    ...     return node
    >>> p = Parser(g, convert=myconvert)
    >>> p.convert is myconvert
    True
    """



# Generated at 2022-06-23 15:44:39.514435
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar
    import os.path

    # This is the grammar used by the 2.3 compiler package
    g = grammar.Grammar(os.path.join(os.path.dirname(__file__), "Grammar.txt"))

    # Test 1: parse a file
    file_name = os.path.join(os.path.dirname(__file__), "../Lib/compiler/__init__.py")
    from .tokenize import tokenize

    p = Parser(g)
    p.setup()
    f = open(file_name, "rb")

# Generated at 2022-06-23 15:44:47.724834
# Unit test for method push of class Parser
def test_Parser_push():
    from . import token
    from . import parsetok

    def lam_sub(grammar: Grammar, node: RawNode) -> Node:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    p = Parser(parsetok.Grammar, lam_sub)
    p.setup()
    p.push(parsetok.NAME, parsetok.Grammar.dfas[parsetok.NAME], 4, None)

# Generated at 2022-06-23 15:44:50.239057
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.Grammar(grammar.DEFAULT_GRAMMAR)
    p = Parser(g)

# Generated at 2022-06-23 15:44:55.708462
# Unit test for method push of class Parser
def test_Parser_push():
    gram = Grammar([], [], [], [], [], [], [], [], [])
    par = Parser(gram)
    par.push(token.LPAR, gram.dfas[token.LPAR], 0, Context(0))
    assert par.stack == [(gram.dfas[token.LPAR], 0, (token.LPAR, None, Context(0), []))]

# Generated at 2022-06-23 15:45:06.363409
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import pgen2
    from .pgen2 import driver
    from shutil import copy
    copy("Parser/Python.asdl", ".")
    copy("Parser/Python-ast.cfg", ".")
    g = driver.load_grammar("blib2to3.pgen2.Python-ast.cfg")
    p = Parser(g)
    p.setup()
    t = p.grammar.token2number
    assert t is not None
    l = token.NAME
    c = (1,0)
    p.shift(l, p.grammar.tokens[l], l, c)
    node1 = (t[l], p.grammar.tokens[l], c, None)
    dfa, state, node2 = p.stack[-1]
    assert node2 == node

# Generated at 2022-06-23 15:45:12.042941
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .pgen import driver

    gram = driver.load_grammar("Grammar/Grammar")
    p = Parser(gram)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.DOT, ".", (1, 0))
    p.addtoken(token.ENDMARKER, None, (0, 0))

# Generated at 2022-06-23 15:45:19.227026
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.grammar as grammar
    from . import token
    from blib2to3.pytree import Leaf, RawNode, Node
    from . import driver

    grammar = grammar.Grammar()
    d = driver.Driver(grammar, convert=lam_sub)
    d.setup()

    # Shift a token; we're done with it
    d.shift(token.NAME, 'a', -1, None)
    assert d.stack == [(None, -1, RawNode(None, None, None, []))]

    # Shift a token; we're done with it
    d.stack = [(None, -1, RawNode(None, None, None, []))]
    d.shift(token.NAME, 'a', -1, None)

# Generated at 2022-06-23 15:45:30.330901
# Unit test for method setup of class Parser
def test_Parser_setup():
    import inspect
    import sys
    import os
    from .. import pytree
    script_name=sys.argv[0]
    dir_name=os.path.dirname(script_name)
    parent_dir=os.path.dirname(dir_name)
    sys.path.insert(0,parent_dir)
    pytree_name=parent_dir+'/pytree/test/test_pytree.py'
    pytree_file=open(pytree_name,"r")
    pytree_string=pytree_file.read()
    tree = pytree.PyTree(grammar='2to3')
    tree.setup()

# Generated at 2022-06-23 15:45:31.757353
# Unit test for constructor of class Parser
def test_Parser():
    g = Grammar()
    p = Parser(g)


# Generated at 2022-06-23 15:45:34.423598
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("msg", 1, "value", "context")
    assert e.msg == "msg"
    assert e.type == 1
    assert e.value == "value"
    assert e.context == "context"


# Generated at 2022-06-23 15:45:38.678324
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("msg", 2, "val", 3)
    assert err.msg == "msg"
    assert err.type == 2
    assert err.value == "val"
    assert err.context == 3

    err = ParseError(
        "msg",
        type=2,
        value="val",
        context=3,
    )
    assert err.msg == "msg"
    assert err.type == 2
    assert err.value == "val"
    assert err.context == 3



# Generated at 2022-06-23 15:45:46.947373
# Unit test for method push of class Parser
def test_Parser_push():
    # Parser.push(self, type: int, newdfa: list, newstate: int, context: Context) -> None
    # wrapper around pgenparser used in the parser module
    def build_parser(grammar: Grammar, start: int) -> Parser:
        return Parser(grammar, lam_sub)


# Generated at 2022-06-23 15:45:49.203314
# Unit test for method setup of class Parser
def test_Parser_setup():
    import blib2to3.pgen2.grammar as grammar
    Parser(grammar.Grammar(), None).setup()

# Generated at 2022-06-23 15:45:57.293524
# Unit test for method setup of class Parser
def test_Parser_setup():
    import pickle
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pygram import python_grammar_no_print_statement
    d = Driver(python_grammar_no_print_statement, convert=lam_sub)
    p = d.parser
    p.setup()
    assert p.stack == [(p.grammar.dfas[p.grammar.start], 0, (p.grammar.start, None, None, []))]
    assert p.rootnode is None
    assert p.classify(token.NAME, "print", None) == python_grammar_no_print_statement.keywords["print"]


# Generated at 2022-06-23 15:46:04.084580
# Unit test for method push of class Parser
def test_Parser_push():
    class MyParser(object):
        def __init__(self, grammar: Grammar, convert: Optional[Convert] = None) -> None:
            self.grammar = grammar
            self.convert = convert or lam_sub

    p = MyParser(Grammar())
    p.stack = []
    p.push(1, ([[(1, 0)]], {0: 1}), 0, Context(None, 1, 1))
    assert p.stack == [(1, 0, [])]

# Generated at 2022-06-23 15:46:15.469142
# Unit test for method pop of class Parser
def test_Parser_pop():
    class G(Grammar):
        labels = "A B C".split()
        terminals = [(0, "*"), (1, "B")]
        nonterminals = [(2, "C"), (3, "D")]
        dfas = Dict[int, DFAS]()

# Generated at 2022-06-23 15:46:26.750414
# Unit test for method push of class Parser
def test_Parser_push():

    def parse_grammar(s: str) -> Grammar:
        import io
        import blib2to3.pgen2.driver

        parser_driver = blib2to3.pgen2.driver.Driver(grammar=None, convert=None, log=None)
        parser = blib2to3.pgen2.driver.load_grammar(io.StringIO(s))
        return parser

    gr = parse_grammar(
        """\
        grm: rule+
        rule: NAME':' alt+
        alt: atom ('|' atom)*
        atom: ('[')? NAME (']')?
        """
    )

    p = Parser(gr)

    p.setup()
    assert p.stack == [(gr.dfas[0], 0, (0, None, None, []))]



# Generated at 2022-06-23 15:46:31.017151
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar(grammar.grammar, symbols=list(grammar.symbol2number.keys()))
    p = Parser(g)
    p.setup()
    assert p.rootnode is None
    assert p.stack == [(g.dfas[1], 0, (1, None, None, []))]

# Generated at 2022-06-23 15:46:40.985839
# Unit test for method pop of class Parser
def test_Parser_pop():
    class TestParser(Parser):
        def __init__(self):
            self.lst = []
            self.convert = self.my_convert
        def my_convert(self, grammar, node):
            self.lst.append(node)
    p = TestParser()
    popdfa = (id(1), id(1))
    popstate = id(2)
    popnode = id(3)
    p.stack = [(id(4), id(5), id(6)), (popdfa, popstate, popnode)]
    p.pop()
    assert p.lst == [popnode]
    assert p.stack == [(id(4), id(5), id(6))]
    p.pop()
    assert p.lst == [popnode, id(6)]
    assert p.stack

# Generated at 2022-06-23 15:46:44.034388
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar
    g = grammar.Grammar()
    p = Parser(g)

# Generated at 2022-06-23 15:46:49.370402
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2 import driver

    parser = driver.make_parser("test/test3.gram")
    parser.setup()
    parser.addtoken(token.NAME, "x", "test")
    assert parser.stack[-1][-1][-1][0] == "NAME"
    assert parser.used_names == {"x"}



# Generated at 2022-06-23 15:46:56.108693
# Unit test for constructor of class Parser
def test_Parser():
    from . import driver
    from . import grammar

    driver.test()
    g = grammar.Grammar(driver.grammar, driver.symbol2number)
    p = Parser(g)
    p.setup()
    # This is the end of the program
    assert p.addtoken(0, "", (1, 0))
    # This is an unfinished program
    p.setup()
    assert not p.addtoken(0, "", (1, 0))

# Generated at 2022-06-23 15:47:04.322404
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """ Unit test for method addtoken of class Parser """
    class Token:
        def __init__(self, type: int, string: Text) -> None:
            self.type = type
            self.string = string

    from . import driver

    from . import grammar

    from . import token

    from . import tree

    from . import pygram

    # We use the Python 2.6 grammar (though the parser itself is the
    # Python 3 parser, so the tokens have a different meaning)
    pygram.init_grammar(grammar)
    pg = pygram.python_grammar

    p = Parser(pg, tree.transform)
    p.setup()


# Generated at 2022-06-23 15:47:05.125124
# Unit test for constructor of class Parser
def test_Parser():
    pass


# Unit test

# Generated at 2022-06-23 15:47:11.378120
# Unit test for method shift of class Parser
def test_Parser_shift():
    def converter(grammar, node):
        return node
    from . import grammar
    g = grammar.Grammar()
    p = Parser(g, converter)
    p.setup()
    # Initial test
    dfa = [[(1, 1)], [(1, 2)]]
    state = 0
    node = (None, None, None, [])
    p.stack.append((dfa, state, node))
    token = (1, "test", None)
    newstate = 2
    p.shift(*token, newstate)
    assert p.stack[0] == ((dfa, newstate, node),)
    # Test first transition
    p.setup()
    dfa = [[(1, 1), (2, 2)], [(1, 2), (2, 3)]]
    state = 0
    node

# Generated at 2022-06-23 15:47:19.499569
# Unit test for method setup of class Parser

# Generated at 2022-06-23 15:47:29.371845
# Unit test for method setup of class Parser
def test_Parser_setup():
    class MockGrammar(object):
        # All we need is: dfas, labels, start
        def __init__(self, dfas, labels, start):
            self.dfas = dfas
            self.labels = labels
            self.start = start
        def __repr__(self):
            return 'MockGrammar(%r, %r, %r)' % (
                self.dfas, self.labels, self.start)

    # Example from Python 2.4 grammar tables.
    # 33 -- '<'
    # 47 -- '<>'
    # 82 -- '>'
    labels = [
        (33, None),
        (47, None),
        (82, None),
        ]
    start = 5
    # 0 -- nothing
    # 1 -- '<'
    # 2

# Generated at 2022-06-23 15:47:38.915277
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest
    import io
    import io

    class Test_Parser(unittest.TestCase):
        # Unit test for method Parser.shift
        def test_shift(self):
            import blib2to3.pgen2.grammar as pgen2grammar
            import blib2to3.pgen2.driver as pgen2driver
            from . import driver
            from . import pgen
            from typing import List
            from .token import NAME
            from blib2to3.pygram import python_grammar
            from blib2to3.pytree import Leaf

            grammar = pgen2grammar.Grammar(python_grammar, 'blib2to3/Grammar.txt')
            self.assertTrue(isinstance(grammar, pgen2grammar.Grammar))
           

# Generated at 2022-06-23 15:47:49.742103
# Unit test for function lam_sub
def test_lam_sub():
    import pytest
    from blib2to3.pgen2.token import Token

    test_tokens = [
        Token(token.NAME, "foo", (1, 0)),
        Token(token.EQUAL, "=", (1, 3)),
        Token(token.NAME, "bar", (1, 4)),
        Token(token.NEWLINE, "", (1, 6)),
        Token(token.ENDMARKER, "", (2, 0)),
    ]

    # Test with a non-literal grammar

# Generated at 2022-06-23 15:48:01.469402
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    with grammar.Grammar() as g:

        # Test the ParseError exception
        p = Parser(g)
        p.setup()
        try:
            p.addtoken(token.NAME, "spam", Context(1, 1))
            pytest.fail("Didn't raise ParseError")
        except ParseError as e:
            assert e.type == token.NAME
            assert e.value == "spam"

        # Test correct operation
        p = Parser(g)
        p.setup()
        assert not p.addtoken(token.LPAR, "(", Context(1, 1))
        assert not p.addtoken(token.NAME, "f", Context(1, 2))
        assert p.addtoken(token.RPAR, ")", Context(1, 3))
       

# Generated at 2022-06-23 15:48:12.406104
# Unit test for method classify of class Parser
def test_Parser_classify():
    import io

    from .tokenizer import generate_tokens

    from . import token, parsetok

    from . import grammar

    # The following is not a complete program, but it contains
    # all tokens
    s = """\
    def f(x):
        return lambda y: y
    """
    tokens = generate_tokens(io.StringIO(s).readline)

    # Create a grammar
    g = grammar.grammar(token.tok_name)

    # Create a parser
    p = Parser(g)
    p.setup()

    # Find the labels for all tokens
    for type, value, context, newstate in tokens:
        if type == token.OP:
            # Special case for this test only!
            type = parsetok.expr_context(value)
            value = None
       

# Generated at 2022-06-23 15:48:21.254315
# Unit test for method setup of class Parser
def test_Parser_setup():
    def isinstance_Parser(cls: type, x: Any) -> bool:
        return isinstance(x, cls)
    assert isinstance_Parser(Parser, Parser(Grammar()))
    p = Parser(Grammar())
    assert p.grammar is not None
    assert p.convert is not None
    assert p.stack is not None
    assert p.rootnode is None
    assert p.used_names is not None


# Generated at 2022-06-23 15:48:23.553624
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()



# Generated at 2022-06-23 15:48:30.993704
# Unit test for function lam_sub
def test_lam_sub():
    g = Grammar()
    g.start = 1
    g.labels = {0: (token.NAME, "a"), 1: (token.NAME, "b")}
    g.dfas = {1: ([[(0, 0), (1, 1)]], {})}
    sub_tuple = (1, None, None, [("b", None, None, None)])
    result = lam_sub(g, sub_tuple)
    assert isinstance(result, Node)
    assert result.type == 1
    assert result.children == ["b"]
    assert result.context is None

# Generated at 2022-06-23 15:48:39.782088
# Unit test for constructor of class Parser
def test_Parser():
    from . import driver, grammar

    # See if the parse tree matches what we expect
    def checktree(tree):
        assert tree[0] == "file_input"
        assert len(tree[1]) == 1
        suite = tree[1][0]
        assert suite[0] == "suite"
        assert len(suite[1]) == 1
        simple_stmt = suite[1][0]
        assert simple_stmt[0] == "simple_stmt"
        assert len(simple_stmt[1]) == 1
        small_stmt = simple_stmt[1][0]
        assert small_stmt[0] == "small_stmt"
        assert len(small_stmt[1]) == 1
        assert small_stmt[1][0][0] == "print_stmt"

   

# Generated at 2022-06-23 15:48:45.819689
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar, token
    from .token import tok_name
    from .pgen import driver
    from blib2to3.pytree import Leaf, Node, type_repr
    g = grammar.grammar
    p = Parser(g, lam_sub)
    p.setup(g.start)
    for x in driver.parse_string("a = b"):
        p.addtoken(*x)
    assert p.rootnode == Node(
        type_repr(g.number2symbol[g.start]),
        [Leaf(token.EQUAL, "="), Leaf(token.NAME, "a"), Leaf(token.NAME, "b")],
    )
    p.setup(g.start)
    for x in driver.parse_string("a = b // comment\n"):
        p

# Generated at 2022-06-23 15:48:54.856267
# Unit test for method shift of class Parser
def test_Parser_shift():
    import sys
    import blib2to3.pgen2.tokenize as tokenize
    from . import grammar, token
    from blib2to3.pytree import Leaf, Node
    from blib2to3.pgen2.driver import Driver
    from blib2to3.fixer_base import BaseFix
    d = Driver(grammar, convert=None)
    d.load_grammar(force=True)

    def lam_shift(grammar, node):
        return Node(type=node[0], children=node[3], context=node[2])

    parser = Parser(d.grammar, lam_shift)
    parser.setup()
    parser.addtoken(token.INDENT, "    ", (1, 1, 0, 0))

# Generated at 2022-06-23 15:49:04.768481
# Unit test for constructor of class Parser
def test_Parser():
    import io
    from .readgrammar import read_grammar
    from . import driver
    from . import tokenize
    from . import tree
    # Read a sample grammar

# Generated at 2022-06-23 15:49:09.608499
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize

    t = untokenize(generate_tokens("G = 'a' | 'b' c d | 'e'"))
    assert Parser(t).classify(token.NAME, "c", 3) == 5
    assert Parser(t).classify(token.STRING, "a", 3) == 1

# Generated at 2022-06-23 15:49:18.173962
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_stack = [[(1, 0), [(0, 0)]], [(2, 0), [(0, 0)]]]
    test_node = (2, 0, [(0, 0)])
    test_token = 1
    test_newstate = 0
    p = Parser([])
    p.stack = test_stack
    p.addtoken(test_token, test_newstate)
    actual = p.stack
    expected = [[(1, 0), [(0, 0)]], [(2, 0), [(1, 0), (0, 0)]]]
    assert actual == expected

# Generated at 2022-06-23 15:49:29.909550
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammars

    g = grammars.Grammar()
    # A grammar with a single rule: file_input: NEWLINE | file_input stmt NEWLINE
    g.symbol2number = {
        "STMT": 2,
        "file_input": 1,
        "NEWLINE": 3,
        "ENDMARKER": 4,
    }
    g.number2symbol = {
        2: "STMT",
        1: "file_input",
        3: "NEWLINE",
        4: "ENDMARKER",
    }
    g.start = 1
    g.tokens = {3: 6, 4: 7}
    g.keywords = {}
    g.symbols = set("file_input STMT ENDMARKER".split())
    g.dfas

# Generated at 2022-06-23 15:49:39.977230
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, tokenize

    class Parser(object):
        def __init__(self, grammar: Grammar, convert: Optional[Convert] = None) -> None:
            self.grammar = grammar
            self.convert = convert or lam_sub
    class TestTokenizer(object):
        def __init__(self, type: int, value: Optional[Text], context: Context) -> None:
            self.type = type
            self.value = value
            self.context = context
            self.start = 1
            self.end = 2

    def test_parse(code: str, error: Optional[Text] = None) -> None:
        """Tests that the given string leads to an error, if error is given,
        otherwise tests that the parse succeeds and gives the expected AST.
        """
        tokens = []
       

# Generated at 2022-06-23 15:49:47.686665
# Unit test for method pop of class Parser
def test_Parser_pop():
    g = Grammar("""
    start: A | B
    A: 'a'
    B: 'a'
    """)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (None, 0))
    p.pop()
    p.pop()
    p.addtoken(token.NAME, "a", (None, 0))
    p.pop()
    p.pop()

# Generated at 2022-06-23 15:49:49.939229
# Unit test for constructor of class Parser
def test_Parser():
    g = Grammar()
    p = Parser(g)

# Generated at 2022-06-23 15:49:53.002612
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.driver as driver
    import blib2to3.pgen2.parse as parse
    import blib2to3.pgen2.tokenize as tokenize
    import io

    grammar = driver.load_grammar("Grammar.txt")
    parser = parse.Parser(grammar)
    parser.setup()
    f = io.StringIO("name")
    parser.addtoken(tokenize.NAME, "name", (1, 0))

# Generated at 2022-06-23 15:50:04.413039
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Test case for Parser.addtoken()."""
    # The following grammar accepts programs of the form:
    #   a: 's' { b }+
    #   b: 'x' 'y'
    #   b: 'z'
    #
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.token as token

    # The following tokens are recognized:
    symbolname_token = grammar.Symbol("SYMBOLNAME", 0)
    letter_token = grammar.Symbol("LETTER", 1)
    letter_x_token = grammar.Symbol("LETTER_X", 2)
    letter_y_token = grammar.Symbol("LETTER_Y", 3)
    letter_z_token = grammar.Symbol("LETTER_Z", 4)

# Generated at 2022-06-23 15:50:09.875143
# Unit test for constructor of class Parser
def test_Parser():
    try:
        Parser('oops; this is not a grammar instance')
    except TypeError:
        pass
    else:
        assert 'constructor did not fail'
    import blib2to3.pgen2.grammar as g
    import blib2to3.pgen2.driver as d
    g = g.Grammar(d.pgen('blib2to3/Grammar.txt'))
    Parser(g)



# Generated at 2022-06-23 15:50:20.449681
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import pgen
    from .parse import driver
    grammar = pgen.pgen().grammar
    p = Parser(grammar)
    source = "from mod import *"
    p.setup()
    tokgen = driver.tokenize(source, grammar.sym_name)
    while True:
        try:
            type, value, start, end, line = next(tokgen)
            context = (file, line)
            done = p.addtoken(type, value, context)
        except token.TokenError as e:
            print(e)
            break
        except ParseError:
            print("Parse error")
            break
        if done:
            print("Success")
            break

# Generated at 2022-06-23 15:50:24.266973
# Unit test for method shift of class Parser
def test_Parser_shift():
    dumper = lambda grammar, node: node
    parser = Parser(Grammar(token), dumper)
    parser.setup(0)
    assert parser.addtoken(1, None, None)
    assert parser.rootnode == (0, None, None, [(1, None, None, None)])



# Generated at 2022-06-23 15:50:30.508732
# Unit test for constructor of class Parser
def test_Parser():
    # import grammar
    # g = grammar.Grammar()
    # g.parse_grammar(grammar.grammar_tokens, grammar.grammar_dfas,
    #                 grammar.grammar_start)
    # p = Parser(g)
    pass

# Generated at 2022-06-23 15:50:35.210954
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest
    import blib2to3.pgen2.driver
    import blib2to3.pgen2.token

    class FakeGrammar(object):
        def __init__(self):
            self.tokens = {"+": 1, "*": 3, "-": 7, "x": 567, "y": 568, "z": 569}
            self.keywords = {"if": 2, "then": 4, "if": 4, "else": 6, "elsif": 8}

        def __getattr__(self, name):
            raise AttributeError("%r object has no attribute %r" %
                                 (self.__class__.__name__, name))

    class TestParser(unittest.TestCase):
        def setUp(self):
            g = FakeGrammar