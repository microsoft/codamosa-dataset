

# Generated at 2022-06-23 15:40:42.207675
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, tokenize

    grammar_path = "./blib2to3/pgen2/grammar/Grammar.txt"

    g = grammar.grammar(grammar_path)
    p = Parser(g)
    p.setup()

    name = "def"
    context = (1, 0)
    tokens = tokenize.generate_tokens(open(__file__).readline)
    for (token_id, txt, start, end, line) in tokens:
        if (start == context):
            break
    assert token_id == token.NAME
    assert txt == name
    type = token_id
    value = txt
    ilabel = p.classify(type, value, context)
    assert ilabel == g.keywords["def"]

# Generated at 2022-06-23 15:40:45.298774
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test", 1, "a", None)
    except ParseError:
        pass
    else:
        raise RuntimeError("ParseError not raised")



# Generated at 2022-06-23 15:40:56.557375
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    from blib2to3.pgen2.grammar import grammar

    # The example from the Python docs (see test_pgen) is used here
    example = "for i in range(10): print i**2"
    tokens = generate_tokens(example.splitlines(True))

    parser = Parser(grammar)
    parser.setup()
    for type, value, start, ep, line in tokens:
        print("type = {0} value = {1} line = {2}".format(
            token.tok_name[type], value, line))
        parser.addtoken(type, value, Context(line, start))

    print(parser.rootnode)

# Generated at 2022-06-23 15:41:00.005324
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver, grammar

    g = grammar.Grammar(grammar.test_grammar)
    p = Parser(g)
    p.setup()
    tt = token.tok_name      # Get token names
    return 'ok'



# Generated at 2022-06-23 15:41:10.570768
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, token

    # Create a grammar for testing
    gr = grammar.grammar(token.tok_name)
    gr.add_symbol("root", ("expr",))
    gr.add_symbol("expr", ("term", "expr_rest"))
    gr.add_symbol("expr_rest", ("PLUS", "term", "expr_rest"))
    gr.add_symbol("expr_rest", ("",))
    gr.add_symbol("term", ("factor", "term_rest"))
    gr.add_symbol("term_rest", ("TIMES", "factor", "term_rest"))
    gr.add_symbol("term_rest", ("",))
    gr.add_symbol("factor", ("NUMBER",))

# Generated at 2022-06-23 15:41:22.731128
# Unit test for method pop of class Parser
def test_Parser_pop():
    class M(Grammar):
        class p_start(Grammar.Prod):
            def p_start(self, p):
                return p.start, p.blank, p.expr

        class p_start_start(Grammar.Prod):
            def p_start_start(self, p):
                return p.start, p.expr, p.blank

    m = M()
    start_expr = m.symbol2number[(m.start.str, m.expr.str)]
    start_start = m.symbol2number[(m.start.str, m.start.str)]

    def fn(grammar, node):
        return Node(type=node[0], children=node[3], context=None)

    p = Parser(m, fn)

# Generated at 2022-06-23 15:41:27.814016
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError('foo', 1, '1', Context(1, 2))
    assert str(exc) == "foo: type=1, value='1', context=(1, 2)"
    assert exc.msg == 'foo'
    assert exc.type == 1
    assert exc.value == '1'
    assert exc.context == Context(1, 2)

# Generated at 2022-06-23 15:41:33.985716
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    _, the_grammar = Grammar.ps1_grammar()
    parser = Parser(the_grammar)
    parser.setup()
    # A simple sequence of 4 tokens
    tokens = [(token.NAME, "a"), (token.PLUS, "+"), (token.NAME, "b"), (token.EQUAL, "=")]
    for tok in tokens:
        assert not parser.addtoken(*tok)
    assert parser.rootnode is not None
    assert "a" in parser.rootnode.used_names
    assert "b" in parser.rootnode.used_names

# Generated at 2022-06-23 15:41:47.050030
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.grammar as grammar
    from . import token

    def test(p, t, v):
        return p.classify(t, v, (1, 0))

    g = grammar.grammar
    p = Parser(g)

    def test_tokens():
        assert test(p, token.NUMBER, "42") == g.token2symbol["NUMBER"]
        assert test(p, token.NAME, "abc") == g.token2symbol["NAME"]

    def test_labels():
        i = g.token2symbol["NUMBER"]
        t, v = g.labels[i]
        assert (t, v) == (token.NUMBER, None)
        i = g.token2symbol["NAME"]

# Generated at 2022-06-23 15:41:48.391285
# Unit test for method push of class Parser
def test_Parser_push():
    g = Grammar("Grammar/Grammar.txt")
    p = Parser(g)
    p.setup()
    p.push("abc", "abc", 10, "context")

# Generated at 2022-06-23 15:41:57.852894
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar, token
    from .tokenize import generate_tokens, untokenize

    tokens: Results = {}
    g = grammar.Grammar()
    with open("Grammar/Grammar", "r") as f:
        g.parse(f.read())
    p = Parser(g)
    p.setup()
    with open("Grammar/Grammar", "r") as f:
        tokengen = generate_tokens(f.readline)
        for tok in tokengen:
            if p.addtoken(*tok):
                break
    tree = p.rootnode
    tokens = tree.totuple(line_prefix=":: ")
    print(untokenize(tokens))


# Generated at 2022-06-23 15:42:03.106469
# Unit test for function lam_sub
def test_lam_sub():
    # Just check if the function works; more extensive tests are in
    # test_grammar.py
    t1 = (1, "a", None, [])
    assert lam_sub(None, t1) == ([], 1, "a")


# Generated at 2022-06-23 15:42:08.124201
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("bar", token.ADD, "+", None)
    except ParseError as pe:
        assert pe.msg == "bar"
        assert pe.type == token.ADD
        assert pe.value == "+"
        assert pe.context is None
    else:
        raise AssertionError("ParseError not raised")

# Generated at 2022-06-23 15:42:16.964761
# Unit test for method shift of class Parser
def test_Parser_shift():
    # return is not allowed in a lambda function
    def lam_sub(grammar: Grammar, node: RawNode) -> NL:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    from . import grammar

    g: Grammar = grammar.Grammar()
    g.load("<test>")

    p = Parser(g)
    p.setup()

    p.shift(token.NAME, "a", 0, None)
    p.shift(token.NAME, "b", 0, None)
    p.shift(token.NAME, "c", 0, None)
    p.shift(token.NAME, "d", 0, None)

# Generated at 2022-06-23 15:42:21.592685
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    grammar.load_grammar("2to3/Grammar.txt")
    parser = Parser(grammar)
    assert parser.classify(token.NAME, "foo", (1, 0)) == 57
    assert parser.classify(token.NAME, "class", (1, 0)) == 13
    assert parser.classify(token.NAME, "def", (1, 0)) == 14

# Generated at 2022-06-23 15:42:25.234422
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    g = grammar.Grammar("""
    word: WORD
    atom: word
    """)
    p = Parser(g)
    p.setup()
    # SEQ is the token type for a WORD token
    p.addtoken(g.tokens["WORD"], "foo", None)
    p.addtoken(0, "", None)  # endmarker
    assert p.rootnode.children[0].children[0].value == "foo"
    assert p.rootnode.children[0].children[0].type == "word"

# Generated at 2022-06-23 15:42:34.223454
# Unit test for method push of class Parser
def test_Parser_push():
    from .driver import driver
    from . import grammar
    #pylint: disable=C0301
    g = grammar.parse_grammar(r'''
    start: '+' '1'
    ''')
    p = Parser(g)
    p.setup()
    assert p.addtoken(43, "+", driver.line_offset_context(1, 0))
    assert p.addtoken(token.LITERAL, "1", driver.line_offset_context(1, 1))
    (type, value, context, children), = p.stack[0][2][-1]
    assert type == g.symbol2number["start"]
    assert value is None
    (type, value, context, children), = children
    assert type == 43
    assert value == "+"
    assert context.lineno == 1

# Generated at 2022-06-23 15:42:42.622072
# Unit test for method shift of class Parser
def test_Parser_shift():
    import sys
    import os
    import tempfile
    import blib2to3.pygram
    import blib2to3.pgen2.parse
    from . import token

    if "--debug" not in sys.argv[1:]:
        print("Use --debug flag to run this test")
        return

    temp_dir = tempfile.gettempdir()
    test_file = os.path.join(temp_dir, "parser.test")

    expected_lines = ["1 + 2 * 3 / 4 + 5 * 6"]

# Generated at 2022-06-23 15:42:52.053394
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import io
    import sys
    import unittest
    import blib2to3.pgen2.parse

    # This test has to run in the same context as the tested code.
    class TestContext:
        def __init__(self) -> None:
            self.Paste = type(
                "Paste", (object,), {"__init__": lambda self, *x: None}
            )
            self.Ellipsis = type(
                "Ellipsis", (object,), {"__init__": lambda self, *x: None}
            )
            self.infile = None
            self.grammar = None
            self.convert = None

    TestContext = TestContext()

    TestContext.infile = io.StringIO("a = 1\n")

# Generated at 2022-06-23 15:42:59.213236
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('foo', 10, 'bar', Context(0, 0))
    except ParseError as e:
        assert e.msg == 'foo'
        assert e.type == 10
        assert e.value == 'bar'
        assert e.context.line == 0
        assert e.context.column == 0
    try:
        raise ParseError
    except ParseError as e:
        assert str(e) == '<unprintable ParseError object>'

# Generated at 2022-06-23 15:43:04.580606
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", 1, "value", "context")
    except ParseError as err:
        assert err.msg == "msg"
        assert err.type == 1
        assert err.value == "value"
        assert err.context == "context"
        assert str(err) == "msg: type=1, value='value', context='context'"



# Generated at 2022-06-23 15:43:12.804143
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    from . import tokenize
    from . import grammar
    from . import driver
    from . import pytree

    if sys.argv[1:]:
        filename = sys.argv[1]
    else:
        filename = "Grammar/Grammar"

    f = open(filename, "r")
    driver.parse_file(filename, f)
    f.close()

    f = open(filename, "r")
    tokens = tokenize.generate_tokens(f.readline)
    f.close()

    p = Parser(grammar.grammar)
    p.setup()
    for type, value, context, _ in tokens:
        p.addtoken(type, value, context)

    p.rootnode.show()

# Generated at 2022-06-23 15:43:21.654268
# Unit test for function lam_sub
def test_lam_sub():
    # type: () -> None
    class FakeGrammar:
        labels = {0: (token.NUMBER, "NUMBER")}

    assert lam_sub(FakeGrammar, (token.NUMBER, "42", None, None)) is None
    assert lam_sub(FakeGrammar, (0, None, None, [])) == Node(type=0, children=[])
    assert lam_sub(FakeGrammar, (0, None, None, [("a", "b", None, None)])) == Node(
        type=0, children=[Leaf(type="a", value="b", context=None)]
    )



# Generated at 2022-06-23 15:43:32.193385
# Unit test for method shift of class Parser
def test_Parser_shift():
    token.LPAR = 1
    token.RPAR = 2
    from . import grammar

    def test_1():
        p = Parser(grammar, lam_sub)
        p.setup()
        p.addtoken(token.LPAR, "(", None)
        assert p.stack[-1][2][-1] == [Node(None, [])]
    test_1()

    def test_2():
        p = Parser(grammar, lam_sub)
        p.setup()
        p.addtoken(token.LPAR, "(", None)
        p.addtoken(token.RPAR, ")", None)
        assert p.stack[-1][2][-1] == [
            Node(None, []),
            Node(None, []),
        ]
    test_2()

# Unit

# Generated at 2022-06-23 15:43:44.787704
# Unit test for method setup of class Parser
def test_Parser_setup():
    import os
    import textwrap
    import unittest
    import blib2to3.pgen2.parse as parse
    import blib2to3.pgen2.driver as driver

    class ParserTest(unittest.TestCase):
        def setUp(self):
            path = os.path.join(os.path.dirname(__file__), "Grammar.txt")
            self.grammar = driver.load_grammar(path)
            self.parser = parse.Parser(self.grammar)

        def test_setup(self):
            orig_len = len(self.parser.stack)
            self.parser.setup()
            self.assertEqual(len(self.parser.stack), orig_len)

        def test_setup_with_start_symbol(self):
            self.parser

# Generated at 2022-06-23 15:43:49.762095
# Unit test for constructor of class ParseError
def test_ParseError():
    """Verify that the constructor of ParseError operates correctly."""
    pe = ParseError("msg", token.NAME, "blah", (1,2))
    assert pe.msg == "msg"
    assert pe.type == token.NAME
    assert pe.value == "blah"
    assert pe.context == (1,2)

# Generated at 2022-06-23 15:43:57.760622
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver, token
    from .tokenize import generate_tokens, untokenize
    from . import n_grammar, n_pgen

    g = n_grammar.grammar


# Generated at 2022-06-23 15:44:09.467923
# Unit test for method push of class Parser
def test_Parser_push():
    class FakeGrammar:
        def __init__(self):
            self.dfas = {}

    def FakeDFA():
        return [
            [
                (TOKEN_A, 0),
                (TOKEN_A, 0),
                (TOKEN_e, 1),
                (TOKEN_e, 1),
                (TOKEN_a, 2),
                (TOKEN_e, 1),
                (TOKEN_e, 1),
                (TOKEN_a, 2),
            ],
            [],
            [],
            [],
            [(0, 6)],
            [(0, 6)],
            [(0, 4)],
        ]

    class Parser:
        def __init__(self):
            self.grammar = FakeGrammar()
            self.stack = []

# Generated at 2022-06-23 15:44:21.087341
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .tokenize import untokenize
    from .parse import Parser, sequence2st
    from blib2to3.pgen2 import token, tokenize
    from .pygram import python_grammar

    _parser = Parser(python_grammar)

# Generated at 2022-06-23 15:44:31.897378
# Unit test for method shift of class Parser
def test_Parser_shift():
    import pdb
    #import pprint

    # 1. Read the grammar
    grammar = Grammar("Grammar.txt")
    # 2. Create the parser
    parser = Parser(grammar)
    # 3. Create the parser for the start symbol
    parser.setup()

    # 4. Tokenize the input string
    from .tokenize import generate_tokens
    from io import StringIO
    from collections import namedtuple
    Token = namedtuple("Token", "type str lineno col")
    for token in generate_tokens(StringIO("1 + 2").readline):
        parser.addtoken(token.type, token.string, (token.start[0], token.start[1]))

    pdb.set_trace()
    pass

# Generated at 2022-06-23 15:44:35.539174
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    g.load(open(g.pgen_grammar_file, "rb"))
    p = Parser(g)
    p.setup()
    p.addtoken(token.STRING, "test", Context(0, 1))

# Generated at 2022-06-23 15:44:44.767530
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.parse_grammar("""
        sum_expr ::= DIVIDE expr.
        expr ::= INT.
        """)

    parser = Parser(g)
    parser.setup()

    tokens = []
    alltokens = [(token.INT, "1"), (token.DIVIDE, "/"), (token.INT, "2")]
    for token in tokenize.generate_tokens(iter(alltokens).__next__):
        parser.addtoken(token[0], token[1], token[2])

    assert len(parser.stack) == 1
    stack = parser.stack.pop()
    assert len(stack) == 3

    state = stack[1]
    assert state == 1

    node = stack[2]

# Generated at 2022-06-23 15:44:56.543986
# Unit test for method pop of class Parser
def test_Parser_pop():
    import unittest
    import numpy as np
    from blib2to3.pgen2 import driver
    from blib2to3.pgen2 import token
    from blib2to3.pygram import python_symbols


    class TestParserPop(unittest.TestCase):
        def test_pop(self):
            # Test that pop produces the right result
            pgen = driver.Driver("Python.asdl", "Python.txt")
            g = pgen.grammar
            p = Parser(g)
            p.setup(python_symbols.file_input)

# Generated at 2022-06-23 15:45:07.046186
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.token import Token, tok_name

    def classify_token(t, v: Any) -> int:
        p = Parser(Grammar)
        assert(p is not None)
        p.setup()
        return p.classify(t, v, (None, None))

    for tok in Token:
        if tok >= 256:
            # Not a token
            continue
        t = tok_name[tok]
        assert(t is not None)
        assert(t != '')
        print(tok, t)
        if t != "NAME":
            assert(classify_token(tok, t) == tok)
        assert(classify_token(tok, t + "Z") == tok)

# Generated at 2022-06-23 15:45:14.824033
# Unit test for method shift of class Parser
def test_Parser_shift():
    class TestGrammar(Grammar):
        """Parser for test."""
        dfas: Dict[int, DFAS] = {}
        labels: Dict[int, Tuple[int, Text]] = {}
        tokens: Dict[int, int] = {}
        keywords: Dict[Text, int] = {}
        start: int = None
    test_grammar = TestGrammar()
    type, value = token.COMMENT, '#'
    context = Context(previous_leaf=None, parent=None)
    test_parser = Parser(test_grammar)
    test_parser.setup()
    test_parser.shift(type, value, 1, context)

# Generated at 2022-06-23 15:45:19.137335
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(None)
    p.shift(1, 'a', 2, None)
    assert p.stack[0] == (None, 2, [1, 'a', None, None])

# Generated at 2022-06-23 15:45:20.965440
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    _grammar = grammar.grammar

    _convert = lam_sub

    p = Parser(_grammar, _convert)

    p.setup()



# Generated at 2022-06-23 15:45:31.570374
# Unit test for method addtoken of class Parser

# Generated at 2022-06-23 15:45:34.900666
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2 import driver

    grm = driver.load_grammar("blib2to3.pgen2.simple")
    parse = Parser(grm)
    parse.setup()



# Generated at 2022-06-23 15:45:40.194915
# Unit test for method pop of class Parser
def test_Parser_pop():
  p = Parser(Grammar())
  p.push(1, None, 0, None)
  assert len(p.stack) == 2
  assert p.stack[-1] == (None, 0, (1, None, None, []))
  p.pop()
  assert len(p.stack) == 1
  assert p.rootnode is not None
  assert p.rootnode.type == 1
  assert p.rootnode.value is None
  assert p.rootnode.context is None
  assert p.rootnode.children == []

# Generated at 2022-06-23 15:45:51.515381
# Unit test for method classify of class Parser

# Generated at 2022-06-23 15:46:03.471628
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import simple
    from . import tokenize

    p = Parser(simple.grammar, convert=None)
    p.setup()

    # Classify an integer constant (assuming there is a label for it in
    # simple.grammar)
    p.classify(tokenize.NUMBER, 42, None)

    # Classify a NAME; see if it gets associated with a symbol
    p.classify(tokenize.NAME, "true", None)

    # Now try some bad input
    try:
        p.classify(tokenize.NAME, "XXX", None)
    except ParseError as e:
        assert e.msg == "bad token"
        assert e.type == tokenize.NAME
        assert e.value == "XXX"
    else:
        raise RuntimeError("ParseError not raised")

# Generated at 2022-06-23 15:46:14.783659
# Unit test for function lam_sub
def test_lam_sub():
    from .grammar import Grammar
    g = Grammar()
    p = Parser(g, lam_sub)
    p.setup()
    p.addtoken(token.NAME, "x", None)
    assert p.rootnode._children == [Leaf(token.NAME, "x")]
    p = Parser(g, lam_sub)
    p.setup()
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "1", None)
    assert p.rootnode._children == [
        Node(g.symbol2number["testlist"], [Leaf(token.NAME, "x"), Leaf(token.NUMBER, "1")])
    ]

# Generated at 2022-06-23 15:46:25.766115
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import re
    import unittest
    import io, os

    from . import parser
    from . import driver

    from . import grammar
    from blib2to3.pytree import Leaf, Node

    from . import tokenize

    # Create an instance of the generic test case class.  (Don't use
    # the instance returned by TestParser, as it uses a custom TestCase
    # subclass.)
    class TestCase(unittest.TestCase):
        pass

    # Create the support functions that return tokens and parse trees

    def get_tokens(
        source: Sequence[str], source_encoding: str, *, return_type: int, start_pos: int
    ) -> Sequence[Any]:
        stream = io.StringIO(source)
        tokenize_kwargs = {"start": start_pos}

# Generated at 2022-06-23 15:46:33.675533
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Test classification of tokens by method Parser.classify."""
    import pprint
    import sys
    # Load the grammar
    g = Grammar(sys.argv[1])
    p = Parser(g)
    # Parse the input file
    class Classifier(object):

        def token(self):
            """Tokenize and classifies the input.

            Reads a line from stdin, tokenizes it using the grammar's
            tokenize() method, and writes the resulting token type,
            token string, and label to stdout.  Returns None if the
            input stream is exhausted.  Blank lines and lines
            beginning with # are ignored.

            """
            while True:
                line = input()
                if line == "" or line[0] == "#":
                    continue
                # Extract the token info
                type, value, context

# Generated at 2022-06-23 15:46:40.033322
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("foo", "bar", "baz", "qux")
    except ParseError as e:
        pass
    else:
        raise Exception("Failed at raising ParseError")
    assert e.msg == "foo"
    assert e.type == "bar"
    assert e.value == "baz"
    assert e.context == "qux"

# This test must come after the class defs, since the latter rely on the
# former.

# Generated at 2022-06-23 15:46:51.839053
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import token
    from . import parsetok

    # Define some useful functions for the unit test
    def t_str(str):
        return str if str else ''

    def t_int(int):
        return str(int) if int else ''

    def t_bool(bool):
        return '1' if bool else '0'

    # Read the grammar from the file 'Grammar/Grammar'
    f = open(grammar.__file__.rstrip('c'), "r")
    g = Grammar(f)
    f.close()

    # Create a parser
    p = Parser(g)

    # Check the parser's attributes
    # Note: The grammar has 395 symbols and 350 labels
    assert p.grammar == g
    assert p.convert == lam_sub

# Generated at 2022-06-23 15:47:01.788428
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .pgen import driver as drv

    g = drv.load_grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", Context(1, 0, "", (0, 0)))
    p.addtoken(token.NEWLINE, "\n", Context(1, 1, "", (0, 1)))
    p.addtoken(token.INDENT, "  ", Context(2, 0, "", (1, 0)))
    p.addtoken(token.NAME, "bar", Context(2, 2, "  ", (1, 2)))
    p.addtoken(token.DEDENT, "", Context(2, 3, "  ", (1, 3)))

# Generated at 2022-06-23 15:47:13.292875
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import token
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.driver import Driver

    def _test(input, expected):
        driver = Driver(convert=lam_sub)
        driver.grammar = grammar
        p = driver.parser
        p.setup()
        g = generate_tokens(input.splitlines(True))
        tokens = []
        for t in g:
            type, value, start, end, line = t
            if value == '\n':
                value = "\n"
            context = Context(start, end, line)
            tokens.append((type, value, context))
        for t in tokens:
            if p.addtoken(*t):
                break
        assert expected == p.rootnode.t

# Generated at 2022-06-23 15:47:16.520609
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("hello", 1, "world", None)
    assert exc.msg == "hello"
    assert exc.type == 1
    assert exc.value == "world"
    assert exc.context is None

# Generated at 2022-06-23 15:47:27.614026
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar, token
    from .pgen import driver

    # test case from Optik's test_optionparser
    grammar1 = driver.load_grammar("Optik", "conflict-handling")
    p = Parser(grammar1)
    p.setup(grammar1.start)
    assert p.stack == [
        (
            grammar1.dfas[grammar1.start],
            0,
            (grammar1.start, None, None, []),
        )
    ]

    # test case from grammar docs
    grammar2 = driver.load_grammar("GrammarTests", "file_input")
    p = Parser(grammar2)
    p.setup(grammar2.start)

# Generated at 2022-06-23 15:47:34.212445
# Unit test for method setup of class Parser
def test_Parser_setup():
    Parser
    import blib2to3.pgen2.grammar as grammar
    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, [None]))]
    assert not p.used_names
    assert not p.rootnode



# Generated at 2022-06-23 15:47:39.204085
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", "type", "value", "context")
    except ParseError as err:
        assert err.msg == "msg" and err.type == "type" and err.value == "value" and err.context == "context"
        assert str(err).startswith("msg: type=") and str(err).endswith("context=context")
    else:
        raise ValueError("ParseError constructor failed to work")

# Generated at 2022-06-23 15:47:49.972649
# Unit test for method pop of class Parser

# Generated at 2022-06-23 15:47:54.987829
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("foo", 1, "bar", Context(None, "blah", (1, 2)))
    except ParseError as e:
        assert str(e) == 'foo: type=1, value=\'bar\', context=Context(None, "blah", (1, 2))'

# Generated at 2022-06-23 15:47:57.742779
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Check if classify returns the right values."""
    p = Parser(Grammar())
    assert p.classify(token.LPAR, None, None) == token.LPAR
    assert p.classify(token.NAME, "name", None) == token.NAME
    assert p.classify(token.NAME, "None", None) == token.NAME

# Generated at 2022-06-23 15:47:59.704725
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    gr = grammar.Grammar()
    p = Parser(gr)

# Generated at 2022-06-23 15:48:04.873104
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("msg", token.POUND, "#", Context(None, None))
    assert pe.msg == "msg"
    assert pe.type == token.POUND
    assert pe.value == "#"
    assert pe.context == Context(None, None)

# Generated at 2022-06-23 15:48:11.043491
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    gr1 = grammar.Grammar()
    gr1.start = 256
    gr1.add_nonterminal("file_input", (257, 260, "stmt+"))
    gr1.add_nonterminal("stmt", (262, 263, "simple_stmt"))
    gr1.start = 256
    gr1.tokens[token.NEWLINE] = 257
    gr1.tokens[token.INDENT] = 258
    gr1.tokens[token.DEDENT] = 259
    gr1.tokens[token.NAME] = 260
    gr1.tokens[token.NUMBER] = 261
    gr1.tokens[token.STRING] = 262
    gr1.tokens[token.ENDMARKER] = 263

    gr

# Generated at 2022-06-23 15:48:14.892106
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("foo", 42, "bar", "baz")
    except ParseError as v:
        assert v.msg == "foo"
        assert v.type == 42
        assert v.value == "bar"
        assert v.context == "baz"



# Generated at 2022-06-23 15:48:22.862344
# Unit test for method pop of class Parser
def test_Parser_pop():
    first = {1, 2}
    last = {4, 5}
    newnode = FakeNode(0, {first, last})
    stack = [FakeStack(1, [newnode])]
    dfa = FakeDFA(2, [3])
    state = 0
    node = FakeNode(0, [])
    p = Parser(None)
    p.stack = stack
    p.pop()
    assert p.rootnode == newnode



# Generated at 2022-06-23 15:48:27.999430
# Unit test for method setup of class Parser
def test_Parser_setup():
    import unittest.mock as mock

    parser = Parser(mock.Mock(spec=Grammar))
    parser.setup()
    assert parser.stack == [(None, 0, (None, None, None, []))]
    assert parser.rootnode is None
    assert parser.used_names == set()


# Generated at 2022-06-23 15:48:36.220371
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar(Text("""
%start S
%%
S: x="foo"
  | x="bar"
x:
  | "foo"
  | "bar"
"""))
    p = Parser(grammar)
    p.setup("x")
    assert p.stack == [(Grammar.dfas["x"], 0, (0, None, None, []))]
    assert p.rootnode == None
    assert p.used_names == set()
    

# Generated at 2022-06-23 15:48:43.866299
# Unit test for method pop of class Parser
def test_Parser_pop():
    import unittest
    import blib2to3.pgen2.driver

    class TestParser(unittest.TestCase):

        def setUp(self) -> None:
            self.driver = blib2to3.pgen2.driver.Driver("blib2to3.pgen2.grammar", convert=None)
            self.parser = Parser(self.driver.grammar, convert=None)
            self.context = Context(1,0)

        def test_pop(self):
            self.parser.setup()
            self.parser.addtoken(0, "import", self.context)
            self.parser.addtoken(1, "a", self.context)
            self.parser.addtoken(2, ".", self.context)

# Generated at 2022-06-23 15:48:53.876159
# Unit test for method push of class Parser
def test_Parser_push():
    import re
    from . import grammar, token
    from .pgen2 import tokenize

    grammar = grammar.Grammar()
    EXPR_CONTEXT = 1
    tokens = [
        (token.NAME, "x"),
        (token.PLUS, "+"),
        (token.NAME, "y"),
    ]
    symbols = [
        "x",
        "PLUS",
        "y",
    ]
    def convert(grammar, node):
        return tuple(node)
    parser = Parser(grammar, convert)
    parser.setup()
    # Stack should initially have one entry representing the start symbol
    assert parser.stack == [(grammar.dfas[symbols.index("file_input")], 0, [(0, None, None, [])])]

# Generated at 2022-06-23 15:49:02.058406
# Unit test for method setup of class Parser
def test_Parser_setup():
    # Note: the test fails if we use the actual grammar.Grammar instance
    # in the Python stdlib, because it has an "assert 0" at the end.
    from blib2to3.pgen2.grammar import Grammar

    class MockGrammar(Grammar):
        def __init__(self) -> None:
            self.start = 2
            self.dfas = {}

    g = MockGrammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[2], 0, (2, None, None, []))]

# Generated at 2022-06-23 15:49:06.791245
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("test", "a", "'b'", (3, 4))
    assert str(err) == "test: type='a', value='b', context=(3, 4)"
    assert err.msg == "test"
    assert err.type == "a"
    assert err.value == "b"
    assert err.context == (3, 4)

# Generated at 2022-06-23 15:49:17.901564
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test the constructor of class ParseError

    The constructor is documented as accepting the following arguments
        msg -- the error message
        type -- the token type
        value -- the token value
        context -- the context in the input

    The constructor should then put these values in the appropriate members

    """
    class test:
        def __init__(self):
            self.msg = None
            self.type = None
            self.value = None
            self.context = None

    pe = ParseError("Test message", "Test type", "Test value", test())
    assert pe.msg == "Test message"
    assert pe.type == "Test type"
    assert pe.value == "Test value"
    assert pe.context is not None
    assert pe.context.msg == "Test message"
    assert pe.context.type == "Test type"


# Generated at 2022-06-23 15:49:25.123831
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .grammar import DEFAULT_GRAMMAR

    gram = DEFAULT_GRAMMAR
    # grammar is modified in place; this is sufficient to test the method
    gram.check_consistency()

    # Construct a small parser instance
    p = Parser(gram)
    p.setup()

    # Optionally, push a symbol
    # p.push(symbol, newdfa, newstate, context)

    # Pop a symbol
    p.pop()

# Generated at 2022-06-23 15:49:34.763902
# Unit test for method classify of class Parser
def test_Parser_classify():
    token_list = [
        ("NUMBER", "3"),
        ("PLUS", "+"),
        ("MINUS", "-"),
        ("MULTIPLY", "*"),
        ("DIVIDE", "/"),
        ("LPAR", "("),
        ("RPAR", ")"),
    ]
    grammar = Grammar()
    token_dict = dict()
    for name, value in token_list:
        token_dict[grammar.tokens[name]] = getattr(token, name)
    test_parser = Parser(grammar)
    for label, value in token_dict.items():
        assert test_parser.classify(value, None, Context()) == label



# Generated at 2022-06-23 15:49:37.063153
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for ParseError."""
    exc = ParseError("msg", -1, "value", "context")
    assert str(exc) == "msg: type=-1, value='value', context='context'"
    assert exc.msg == "msg"
    assert exc.type == -1
    assert exc.value == "value"
    assert exc.context == "context"

# Generated at 2022-06-23 15:49:43.479954
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2 import generate_grammar
    from blib2to3.pgen2 import tokenize
    from . import token

    grammar = generate_grammar('Grammar.txt')
    parser = Parser(grammar)
    parser.setup()

    tokens = tokenize.generate_tokens(open('Grammar.txt', 'r'))
    for type, value, context in tokens:
        r = parser.addtoken(type, value, context)
        if r:
            break

    print(parser.rootnode)
    assert parser.rootnode.__class__.__name__=='Leaf'
    assert parser.rootnode.value=='Grammar'


# Generated at 2022-06-23 15:49:47.080469
# Unit test for method setup of class Parser
def test_Parser_setup():
    # Use parser module to get the grammar
    grammar = Parser(None).grammar
    # Create a parser
    parser = Parser(grammar)

    # Exercise method setup of the parser
    parser.setup()

# Generated at 2022-06-23 15:49:51.620978
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError("message", 1, "value", None)
    assert p.msg == "message"
    assert p.type == 1
    assert p.value == "value"
    assert p.context is None

# Generated at 2022-06-23 15:49:56.530519
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(Grammar())
    p.setup()
    p.push(1, [(2, 3), (3, 4)], 0, None)
    assert p.stack == [(p.grammar.dfas[1], 0, (0, None, None, []))], p.stack

# Generated at 2022-06-23 15:50:05.862331
# Unit test for method pop of class Parser
def test_Parser_pop():
    # test code
    class EmptyParser(Parser):
        def __init__(self, grammar, convert=None):
            Parser.__init__(self, grammar, convert)
        def classify(self, type, value, context):
            return 0
    class EmptyGrammar(Grammar):
        def __init__(self):
            self.dfas = {0: ([[(0, 0)]], {}), 1: ([[(0, 0)]], {}),\
                         2: ([[(0, 0)]], {}), 3: ([[(0, 0)]], {})}
            self.labels = [(0, 0)]
            self.start = 0

    # test case
    pgm = EmptyGrammar()
    pc = EmptyParser(pgm)
    pc.setup()
    import pytest

# Generated at 2022-06-23 15:50:13.035972
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("error", "type", "value", "context")
    except ParseError as err:
        # assert err.args[0] == "error"
        assert "error" in err.msg
        assert err.type == "type"
        assert err.value == "value"
        assert err.context == "context"
    else:
        assert False, "Expected exception"



# Generated at 2022-06-23 15:50:23.807486
# Unit test for method push of class Parser
def test_Parser_push():
    Parser = Parser
    test1 = [
        1,
        1,
        0,
    ]
    test2 = [
        2,
        2,
        2,
    ]
    test3 = [
        (1, 2),
        (1, 1, 0),
        (2, 2, 2),
    ]
    test4 = [
        (1, 2),
        (1, 1, 0),
        (2, 2, 2),
    ]
    test5 = [
        (1, 2),
        (1, 1, 0),
        (2, 2, 2),
    ]
    test6 = [
        (1, 2),
        (1, 1, 0),
        (2, 2, 2),
    ]

# Generated at 2022-06-23 15:50:36.029314
# Unit test for method pop of class Parser
def test_Parser_pop():
    class TestGrammar(Grammar):
        def __init__(self) -> None:
            self.keywords = {"x": 1, "y": 2}
            self.tokens = {1: 1, 2: 2}
            self.start = 3
            self.dfas = {3: ([[(1, 1), (2, 2)], [(0, 1)]], {0: 1})}

    g = TestGrammar()
    g.dfas[3] = ([[(1, 1), (2, 2)], [(1, 1), (0, 2)]], {0: 1, 1: 1, 2: 2})
    p = Parser(g)
    p.setup()
    p.addtoken(1, "x", (1, 0))