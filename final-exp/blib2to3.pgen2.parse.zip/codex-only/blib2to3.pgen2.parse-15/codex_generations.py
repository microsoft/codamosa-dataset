

# Generated at 2022-06-23 15:40:43.609069
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.pgen import Grammar
    from blib2to3.pgen2.tokenize import generate_tokens

    def test(code: str, trace: int = 0) -> None:
        g = Grammar()
        p = Parser(g, None)
        p.setup()
        tokens = list(generate_tokens(iter(code).__next__))
        for token in tokens:
            if p.addtoken(token[0], token[1], token[2]):
                break
        assert p.rootnode is not None
        if trace:
            print("tokens:")
            for token in tokens:
                print(token)
            print("tree:")
            print(p.rootnode)

    test("a = 1 + 2")


# Unit

# Generated at 2022-06-23 15:40:54.666910
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver

    gr_file = "../Grammar/Grammar"
    gs = driver.grammar_state_from_file(gr_file)
    p = driver.Parser(gs.grammar, None)
    p.setup()
    cur_node = None
    for i in range(10):
        dfa0 = list(range(1, 11))
        dfa1 = list(range(101, 111))
        cur_node = (dfa0, dfa1, 0, (i, None, None, [cur_node]))
        p.stack.append(cur_node)
    p.pop()
    stack = p.stack
    assert len(stack) == 1
    assert stack[0][-1][-1] == [cur_node]

# Generated at 2022-06-23 15:41:03.705511
# Unit test for method addtoken of class Parser

# Generated at 2022-06-23 15:41:11.764643
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    pg = grammar.Grammar()
    with open("Grammar/Grammar", "rb") as gf:
        pg.load_grammar(gf)
    p = Parser(pg)
    p.setup()
    with open("Grammar/Grammar", "rb") as gf:
        for token_type, token_string, start, end, line in pg.tokenize(gf):
            p.addtoken(token_type, token_string, (start, end))
    assert len(p.stack) == 0
    assert isinstance(p.rootnode, pg.Node)
    #assert p.rootnode == 1

# Generated at 2022-06-23 15:41:14.762728
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar())
    p.setup()
    assert p.grammar
    assert p.stack


# Generated at 2022-06-23 15:41:19.528279
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("abc", "def", "ghi", None)
    except ParseError as e:
        assert e.msg == "abc"
        assert e.type == "def"
        assert e.value == "ghi"
        assert e.context is None

# Generated at 2022-06-23 15:41:25.185487
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", 1, "value", None)
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == 1
        assert e.value == "value"
        assert e.context is None
    else:
        raise ValueError("Didn't get an exception")

# Generated at 2022-06-23 15:41:29.090586
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("message", 1, 2, 3)
    except Exception as e:
        assert isinstance(e, ParseError)
        assert e.msg == "message"
        assert e.type == 1
        assert e.value == 2
        assert e.context == 3

# Generated at 2022-06-23 15:41:36.587215
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Test shift method of class Parser

    From boost.python.errors.test_ParseError
    """
    import types
    import unittest
    import pgen2
    import pgen2.parser
    import pgen2.pgen

    def shift(self, type, value, newstate, context):
        self.stack[-1] = (self.stack[-1][0], newstate, self.stack[-1][2])

    def setup(self, start=None):
        if start is None:
            start = self.grammar.start
        newnode = (start, None, None, [])
        stackentry = (self.grammar.dfas[start], 0, newnode)
        self.stack = [stackentry]
        self.rootnode = None


# Generated at 2022-06-23 15:41:49.180768
# Unit test for method shift of class Parser
def test_Parser_shift():

    def convert(grammar: Grammar, node: RawNode) -> Union[Leaf, Node]:
        return RawNode(type=node[0], children=node[3], context=node[2])

    class ParserEngine(Parser):
        """Parser engine, modified to use rule shift."""

        def __init__(self, grammar: Grammar) -> None:
            Parser.__init__(self, grammar, convert)

        def shift(
            self, type: int, value: Optional[Text], newstate: int, context: Context
        ) -> None:
            """Shift a token by rule shift."""
            Parser.shift(self, type, value, newstate, context)
            node = self.stack[-1][2]
            assert node[-1] is not None

# Generated at 2022-06-23 15:41:57.930314
# Unit test for method push of class Parser
def test_Parser_push():
    """ The method push of class Parser generates an assertion error,
    if the second parameter is None.
    TODO: remove this test once the bug is fixed in
    blib2to3.pgen2.Tokenizer.

    Here is the bug report:
    http://bugs.python.org/issue3023
    """
    from . import grammar

    g1 = grammar.Grammar()
    # Create a Parser instance
    p = Parser(g1)
    # initialize the Parser by calling setup
    p.setup()
    # Push a nonterminal with a parameter which is (None, None)
    p.push(None, None, None, None)

# Generated at 2022-06-23 15:42:10.353872
# Unit test for method push of class Parser
def test_Parser_push():
    def convert_to_ast(grammar, node):
        return Node(type=node[0], children=node[3], context=node[2])


# Generated at 2022-06-23 15:42:15.759497
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("foobar", token.INDENT, " ", ('file', 1, 0))
    assert str(err) == "foobar: type=INDENT, value=' ', context=('file', 1, 0)"
    assert err.msg == "foobar"
    assert err.type == token.INDENT
    assert err.value == " "
    assert err.context == ("file", 1, 0)

# Generated at 2022-06-23 15:42:26.069297
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # provided by test_parser_grammar at the bottom
    parser = Parser(grammar)
    parser.setup("start")

    # set up a stack entry
    dfa = [[(0, 1)], [(1, 2), (2, 1)], [(0, 3)]]
    state = 0
    node = (123, None, None, [])
    stackentry = (dfa, state, node)

    # set up a token
    type, value, context = 100, "tokenvalue", "context"


# Generated at 2022-06-23 15:42:35.527936
# Unit test for constructor of class ParseError
def test_ParseError():
    """Constructor of ParseError

    Canonicalize a line/column pair for error reporting.

    :type line: int
    :param line: Line number
    :type column: int
    :param column: Position within the line
    :type msg: str
    :param msg: Error message
    :rtype: tuple
    :return: A pair of numbers that can be passed to the error reporting
             functions of this module.

    """
    try:
        raise ParseError("test", token.NAME, "name", (5, 10))
    except ParseError as err:
        assert (err.msg, err.type, err.value, err.context) == ("test", token.NAME, "name", (5, 10))

# Generated at 2022-06-23 15:42:37.748298
# Unit test for method setup of class Parser
def test_Parser_setup():
    evaluate = Parser(Grammar())
    evaluate.setup()


# Generated at 2022-06-23 15:42:49.808816
# Unit test for method shift of class Parser
def test_Parser_shift():
    # From shift_test.py
    import pprint
    import sys
    from . import driver, token, symbols

    class Circle():

        def __init__(self, obj):
            self.obj = obj

        def __repr__(self):
            return self.obj.__repr__()

        def __iter__(self):
            return iter([self.obj, self.obj])
    tokens = [
        (symbols.int_lit, u'1'), (token.NEWLINE, '\n'), (symbols.int_lit, u'2'),
        (token.NEWLINE, '\n'), (token.ENDMARKER, ''), (symbols.int_lit, u'3')
    ]

# Generated at 2022-06-23 15:42:53.155919
# Unit test for method classify of class Parser
def test_Parser_classify():
    import pgen2.grammar
    import pgen2.token

    parser = Parser(pgen2.grammar.Grammar())
    parser.classify(pgen2.token.NAME, "if", None)

# Generated at 2022-06-23 15:42:56.494908
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)

    # should not raise exceptions
    p.push(4, 5, 6, [7, 8])

# Generated at 2022-06-23 15:43:01.737973
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("oops", 1, "python", "file")
    except ParseError as e:
        assert str(e) == "oops: type='python', value=1, context='file'"
        assert e.msg == "oops"
        assert e.type == "python"
        assert e.value == 1
        assert e.context == "file"
    else:
        raise

# Generated at 2022-06-23 15:43:04.484564
# Unit test for constructor of class Parser
def test_Parser():  # htest #
    from .grammar import Grammar

    g = Grammar()
    p = Parser(g)
    p.setup()

# Generated at 2022-06-23 15:43:08.486949
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar(__file__)
    parse_start = token.ORDERED_DICT
    min_arity = 5
    r = Parser(grammar).setup(parse_start)
    assert (r is None), "Unexpected return value"



# Generated at 2022-06-23 15:43:20.414551
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    start = grammar.symbol("start")
    alist = grammar.symbol("alist")
    an_a = grammar.symbol("an_a")
    end = grammar.symbol("end")
    EMPTY = grammar.Empty

    gr = grammar.Grammar(start)
    gr.add_production(alist, [alist, an_a], None, "left")
    gr.add_production(alist, [EMPTY], None, "left")
    gr.add_production(start, [alist, end], None, "left")
    gr.add_production(an_a, [grammar.token("NAME")], None, "left")
    gr.add_production(end, [grammar.token("NAME")], None, "left")

    pars = Parser(gr)
    pars.setup

# Generated at 2022-06-23 15:43:29.993272
# Unit test for method pop of class Parser
def test_Parser_pop():
    # From file '../a.out'
    it = iter([(10, 'x', (1, 0)), (4, None, (1, 2)), (1, None, (1, 3))])
    grammar = Grammar('../a.out')
    parser = Parser(grammar)
    parser.setup(1)
    t, v, c = next(it)
    parser.addtoken(t, v, c)
    t, v, c = next(it)
    parser.addtoken(t, v, c)
    t, v, c = next(it)
    parser.addtoken(t, v, c)
    root = parser.rootnode

# Generated at 2022-06-23 15:43:34.414076
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = Grammar()
    #test chars
    parser = Parser(grammar=grammar)
    parser.classify(type=token.STRING, value="'single quotes'", context=Context(1, 1))
    parser.classify(type=token.STRING, value='"double quotes"', context=Context(1, 1))
    parser.classify(type=token.NUMBER, value="3", context=Context(1, 1))
    parser.classify(type=token.NUMBER, value="0x2A", context=Context(1, 1))
    parser.classify(type=token.NUMBER, value="0o17", context=Context(1, 1))
    parser.classify(type=token.NUMBER, value="0b00101010", context=Context(1, 1))

# Generated at 2022-06-23 15:43:37.532635
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(Grammar())
    p = Parser(Grammar(), lam_sub)

# Generated at 2022-06-23 15:43:40.452033
# Unit test for constructor of class Parser
def test_Parser():
    from . import driver
    from . import grammar
    from . import pytree
    from .tokenize import generate_tokens
    import io
    import sys


# Generated at 2022-06-23 15:43:49.438175
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from blib2to3.pgen2.driver import Driver

    # Test of a simple parser
    class TestParser(unittest.TestCase):
        def test_simple(self):
            driver = Driver()
            driver.parse_string(
                """\
                a: 'a'+ 'b'
                b: 'z'
                """
            )
            p = Parser(driver.grammar)
            p.setup()
            self.assertEqual(False, p.addtoken(token.STRING, "a", None))
            self.assertEqual(False, p.addtoken(token.STRING, "a", None))
            self.assertEqual(False, p.addtoken(token.STRING, "b", None))

# Generated at 2022-06-23 15:43:55.748487
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, token
    p = Parser(grammar.parse_grammar("Grammar.txt"))
    p.setup()
    ilabel = p.classify(token.NAME, "for", Context())
    assert ilabel == grammar.symbol2number["for_stmt"]
    ilabel = p.classify(token.NAME, "foo", Context())
    assert ilabel == grammar.symbol2number["NAME"]
    ilabel = p.classify(token.PLUS, "+", Context())
    assert ilabel == grammar.symbol2number["PLUS"]

# Generated at 2022-06-23 15:44:03.390389
# Unit test for function lam_sub
def test_lam_sub():
    # A type will be instantiated and used only once, so we use a dict
    # and a counter to make types that won't be reused.
    types: Dict[int, Any] = {}

    def mktype() -> Any:
        n = len(types)
        types[n] = n
        return n

    testcases = (
        ((mktype(), None, None, []), None),
        ((mktype(), "value", (1, 2), []), None),
        ((mktype(), "value", (1, 2), [3, 4]), None),
        ((mktype(), "value", None, [3, 4]), None),
    )

    for node, result in testcases:
        assert lam_sub(object(), node) is result

# Generated at 2022-06-23 15:44:06.122955
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    p = Parser(grammar.python_grammar)
    assert p.grammar is grammar.python_grammar
    assert p.convert is lam_sub



# Generated at 2022-06-23 15:44:12.038465
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import token
    from . import grammar, driver
    from .pytree import PyTreeBuilder

    def test():
        driver.parse_tokens(
            [
                (token.NAME, "x"),
                (token.NAME, "y"),
                (token.NAME, "z"),
                (token.ENDMARKER, ""),
            ],
            grammar,
            PyTreeBuilder,
        )

    test()

# Generated at 2022-06-23 15:44:19.327982
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError('msg', 42, 'value', 'context')
    assert err.msg == 'msg'
    assert err.type == 42
    assert err.value == 'value'
    assert err.context == 'context'
    # Initialization of ParseError doesn't call the constructor of
    # its superclass, so we have to write the following ugly code
    # instead of just "assert str(err) == 'msg: type=42, value=value, context=context'"
    assert str(err) == err.__class__.__init__.__func__(err, *err.args).__repr__()

# Generated at 2022-06-23 15:44:26.863286
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test case for ParseError."""
    e = ParseError("msg", token.NAME, "value", (1, 2))
    assert e.msg == "msg"
    assert e.type == token.NAME
    assert e.value == "value"
    assert e.context == (1, 2)
    assert str(e) == "msg: type=1, value='value', context=(1, 2)"

# Generated at 2022-06-23 15:44:29.434160
# Unit test for constructor of class Parser
def test_Parser():
    # pylint: disable=unused-variable
    p = Parser(None)
    p = Parser(None, None)
    p = Parser(None, lambda: None)

# Generated at 2022-06-23 15:44:39.426347
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, parse

    test_grammar = r'''
        start: a c b
        a: "a"
        b: "b"
        c: "c"
    '''

    def parse_grammar(grammar_str: str) -> Dict[Text, NL]:
        parse(tokenize.tokenize(grammar_str), my_Grammar)

    try:
        import StringIO
    except ImportError:
        import io as StringIO

    my_Grammar = grammar.Grammar(StringIO.StringIO(test_grammar))
    results = parse_grammar(test_grammar)
    parser = Parser(my_Grammar, lam_sub)
    parser.setup(0)
    assert not parser.addtoken(1, "a", None)

# Generated at 2022-06-23 15:44:47.673671
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest
    import pickle
    from blib2to3.pgen2 import driver

    # Read the grammar
    gr = driver.load_grammar("Python.gram")
    # This is the "dummy" token, an extra token beyond what the
    # grammar knows
    tok_dummy = len(gr.tokens) + 1

    class TestParser(unittest.TestCase):
        def assert_node(
            self,
            stack,
            state,
            node,
            children,
            type,
            value=None,
            lineno=1,
            column=0,
            offset=0,
            keywords={},
            tokens={},
            labels=None,
            type_ignores_case=False,
        ):
            self.assertIsInstance(stack, list)
           

# Generated at 2022-06-23 15:44:54.348918
# Unit test for method shift of class Parser
def test_Parser_shift():
    def conv(grammar: Grammar, node: RawNode) -> Optional[Leaf]:
        return Leaf(type=node[0], value=node[1], context=node[2])

    g = Grammar()
    p = Parser(g, conv)
    p.setup(0)
    p.addtoken(token.NUMBER, "42", Context(line=1))
    assert p.stack[-1][2][-1].value == "42"

# Generated at 2022-06-23 15:45:05.064261
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.grammar import Symbol

    def tok(t: int) -> int:
        return t

    def sym(s: str) -> Symbol:
        return Symbol(s)


# Generated at 2022-06-23 15:45:06.843774
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()

# Generated at 2022-06-23 15:45:14.711572
# Unit test for method classify of class Parser
def test_Parser_classify():
    class MockGrammar(object):
        def __init__(self, dfas=None, labels=None, tokens=None, keywords=None):
            self.dfas = dfas or {}
            self.labels = labels or {}
            self.tokens = tokens or {}
            self.keywords = keywords or {}

    grammar = MockGrammar(
        dfas={1: ([], {1: 1, 2: 1})},
        labels={3: (256, 1), 4: (256, 2), 5: (token.NAME, "NAME")},
        tokens={token.NAME: 5},
        keywords={"NAME": 4},
    )
    parser = Parser(grammar)
    assert parser.classify(token.NAME, "NAME", None) == 4

# Generated at 2022-06-23 15:45:25.452795
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("blah", 1, "x", None)
    except ParseError as err:
        assert err.msg == "blah"
        assert err.type == 1
        assert err.value == "x"
        assert err.context is None
        return
    assert False

# Test the Parser class.  This will only run when the module is
# executed as the main module.
if __name__ == "__main__":
    from . import driver, grammar

    p = Parser(grammar.grammar, grammar.transform)
    p.setup("file_input")

# Generated at 2022-06-23 15:45:32.809484
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.Grammar(grammar.pgen_grammar)
    # _type_store() is a hidden method from types.py
    p = Parser(g)
    p.setup()
    assert p.stack == [(
        g.dfas[256], 0, (256, None, None, []))]

    p = Parser(g)
    p.setup(token.STRING)
    assert p.stack == [(
        g.dfas[token.STRING], 0, (token.STRING, None, None, []))]


# Generated at 2022-06-23 15:45:40.622650
# Unit test for method classify of class Parser
def test_Parser_classify():
    import os

    # change directory to the Python distribution directory
    old_cwd = os.getcwd()
    python_cwd = os.path.dirname(os.__file__)
    os.chdir(python_cwd)


# Generated at 2022-06-23 15:45:51.964248
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest
    import io

    import blib2to3.pgen2.parse

    class TestParserClassify(unittest.TestCase):
        def test_classify(self) -> None:
            grammar = blib2to3.pgen2.parse.make_grammar(
                io.StringIO(
                    """
    from __future__ import nested_scopes
    start: NAME
    %import common.CNAME -> NAME
    """
                ),
                "testgrammar.txt",
            )
            p = Parser(grammar)
            self.assertEqual(p.classify(token.NAME, "from", None), 1)
            self.assertEqual(p.classify(token.NAME, "__future__", None), 1)

# Generated at 2022-06-23 15:46:03.852127
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver

    def lam_convert(grammar: Grammar, node: RawNode) -> Union[Node, Leaf]:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    grammar = driver.load_grammar("Python.g")
    parser = Parser(grammar, lam_convert)


# Generated at 2022-06-23 15:46:07.656772
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(token)
    p.setup()
    assert p.rootnode is None
    assert p.stack == []
    assert p.used_names == set()


# Generated at 2022-06-23 15:46:10.088086
# Unit test for method classify of class Parser
def test_Parser_classify():
    test_parser = Parser(Grammar(open('Python.g')))
    test_parser.classify(token.NAME, 'try', None)

# Generated at 2022-06-23 15:46:14.884637
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    try:
        p.classify(token.NAME, "blah", (1, 1))
    except ParseError:
        pass
    else:
        assert False, "expected ParseError"

# Generated at 2022-06-23 15:46:25.977753
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Python 2
    # >>> import __future__
    # >>> import sys
    # >>> py3k = __future__.absolute_import.__module__ == "__future__"
    # >>> exec("if py3k: ... else: ...")
    py3k = 3
    source = "import __future__\nimport sys\npy3k = __future__.absolute_import.__module__ == '__future__'\nexec('if py3k: ... else: ...')"
    # >>> from pgen2.driver import load_grammar, parse_tokens, tokenize_lines
    # >>> grammar = load_grammar("Grammar/Grammar")
    from .driver import load_grammar, parse_tokens, tokenize_lines

# Generated at 2022-06-23 15:46:30.436306
# Unit test for method setup of class Parser
def test_Parser_setup():
    import sys

    class Dummy:
        pass

    d = Dummy()
    d.__class__ = Parser
    d.setup()
    d.__class__ = Parser
    d.setup()

    d.__class__ = Parser
    d.setup(256)
    d.__class__ = Parser
    d.setup(256)



# Generated at 2022-06-23 15:46:39.375064
# Unit test for method shift of class Parser
def test_Parser_shift():
    # testing a shift with no conversion
    p = Parser(None, None)
    p.setup()
    newnode = ('temp','temp','temp',None)
    p.stack.append((None,0,newnode))
    p.shift(None, None, None, None)
    assert(p.stack[0] == (None,None,newnode))
    # testing a shift with conversion
    newnode = ('temp','temp','temp',[])
    p.stack.append((None,0,newnode))
    p.shift(None, None, None, None)
    assert(p.stack[0] == (None,None,newnode))

# Generated at 2022-06-23 15:46:43.871917
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import token
    grammar = driver.load_grammar("Grammar/Grammar")
    parser = Parser(grammar)
    parser.setup()
    parser.stack = [(None, 0, (None, None, None, None))]
    parser.shift(token.COMMENT, "foo", 1, (1, 0))
    assert parser.stack == [(None, 1, (None, None, None, None))]

# Generated at 2022-06-23 15:46:49.600300
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from .pgen import tokenize

    p = Parser(grammar.grammar)
    stream = tokenize.generate_tokens(open("test.py"))
    p.setup()
    try:
        for token in stream:
            p.addtoken(token[0], token[1], token[2])
    except ParseError:
        assert False



# Generated at 2022-06-23 15:46:59.908844
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .token import TokenInfo

    class MockGrammar:
        start = 10

# Generated at 2022-06-23 15:47:05.577266
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("error", token.NUMBER, '1', (1, 1))
    assert pe.msg == "error"
    assert pe.type == token.NUMBER
    assert pe.value == '1'
    assert pe.context == (1, 1)
    assert str(pe) == "error: type=38, value='1', context=(1, 1)"

# Generated at 2022-06-23 15:47:10.566990
# Unit test for constructor of class Parser
def test_Parser():
    import blib2to3.pgen2.parse as pgen2_parse
    import blib2to3.pgen2.driver as pgen2_driver

    grammar = pgen2_driver.load_grammar(pgen2_parse.grammar)
    assert grammar.start == 269
    # Test the constructor of class Parser
    p = Parser(grammar)

# Generated at 2022-06-23 15:47:14.144316
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Unit test for method classify of class Parser."""
    from blib2to3.pgen2 import tokenize

    grammar = Grammar()
    parser = Parser(grammar)
    tokens = tokenize.generate_tokens(open("Grammar.txt", "rb"))
    for type, value, context in tokens:
        parser.classify(type, value, context)


if __name__ == "__main__":
    test_Parser_classify()

# Generated at 2022-06-23 15:47:25.498852
# Unit test for function lam_sub
def test_lam_sub():
    raw = [
        (1, "a", None, None),
        (2, "b", None, [
            (3, "c", None, None),
            (4, "d", None, None),
        ]),
        (5, "e", None, [
            (6, "f", None, None),
            (7, "g", None, None),
            (8, "h", None, None)
        ])
    ]
    raw = tuple(raw)
    expected = Node(
        type = 1,
        children = [
            Leaf(type = 3, value = "c"),
            Leaf(type = 4, value = "d")
        ],
        context = None
    )
    assert lam_sub(None, raw[1]) == expected

# Generated at 2022-06-23 15:47:31.695769
# Unit test for function lam_sub
def test_lam_sub():
    g = Grammar()
    assert lam_sub(g, (1, None, None, [2, 3])) == ([2, 3], 1, None)
    assert lam_sub(g, (1, None, None, None)) == ([], 1, None)
    assert lam_sub(g, (1, "foo", None, None)) == (["foo"], 1, None)
    assert lam_sub(g, (1, "foo", "bar", None)) == (["foo"], 1, "bar")
    assert lam_sub(g, (1, "foo", "bar", [2, 3])) == ("foo", 1, "bar")

# Generated at 2022-06-23 15:47:40.671148
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar
    from . import tokenize
    from . import driver
    import io

    g = grammar.Grammar()
    g.start = 257
    g.tokens = {
        token.ENDMARKER: 0,
        token.NAME: 1,
        token.NEWLINE: 2,
        token.NUMBER: 3,
        token.STRING: 4,
    }
    g.keywords = {
        "print": 5
    }
    g.nonterminals = {}
    g.symbol2label = [
        "endmarker",
        "NAME",
        "NEWLINE",
        "NUMBER",
        "STRING",
        "print",
    ]

# Generated at 2022-06-23 15:47:44.510823
# Unit test for method setup of class Parser
def test_Parser_setup():
    # Prototype __init__ argument type
    grammar: Grammar
    convert: Optional[Convert]
    # Prototype setup method argument type
    start: Optional[int]
    # Prototype return type
    parser: Parser

