

# Generated at 2022-06-23 15:40:37.052067
# Unit test for constructor of class ParseError
def test_ParseError():
    l = []
    try:
        raise ParseError("msg", 1, "value", l)
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == 1
        assert e.value == "value"
        assert e.context == l

# Generated at 2022-06-23 15:40:47.674921
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.pgen
    import blib2to3.pgen2.parse
    import blib2to3.pgen2.driver
    import blib2to3.pygram
    grammar = blib2to3.pgen2.parse.grammar()
    driver = blib2to3.pgen2.driver.Driver(
        grammar, convert=blib2to3.pgen2.pgen.convert_tree, logger=None
    )
    parser = Parser(grammar)

# Generated at 2022-06-23 15:40:54.696587
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar
    from . import tokenize
    from . import pickletools

    with open("Grammar/Grammar") as f:
        grammar = f.read()
    pickler = pickletools.PyParsingPickler()
    p = Parser(pickler.load_grammar("Grammar"))
    try:
        p.setup()
    except AttributeError as e:
        assert "no attribute 'tokens' or 'dfas'" in str(e)
    p = Parser(pickler.load_grammar("Grammar"), lam_sub)
    p.setup()
    p.addtoken(token.NAME, "<IDENTIFIER>", (1, 0))
    p.addtoken(token.NAME, "(" , (1, 0))

# Generated at 2022-06-23 15:41:03.705477
# Unit test for method classify of class Parser
def test_Parser_classify():
    # No need to run this while running lib2to3 tests.
    global GRAMMAR, Parser
    try:
        from . import pygram
    except ImportError:
        return
    GRAMMAR = pygram.python_grammar_no_print_statement
    Parser = Parser

    p = Parser(GRAMMAR)
    ilabel = p.classify(0, '', 0)
    assert ilabel == 259

    p = Parser(GRAMMAR)
    ilabel = p.classify(token.NAME, 'foo', 0)
    assert ilabel == 259

    p = Parser(GRAMMAR)
    ilabel = p.classify(token.NAME, 'print', 0)
    assert ilabel == GRAMMAR.keywords['print']

    p = Parser(GRAMMAR)
   

# Generated at 2022-06-23 15:41:06.669863
# Unit test for constructor of class ParseError
def test_ParseError():
    PE = ParseError("test", 99, "test", None)
    assert PE.msg == "test"
    assert PE.type == 99
    assert PE.value == "test"
    assert PE.context is None



# Generated at 2022-06-23 15:41:13.667262
# Unit test for method classify of class Parser
def test_Parser_classify():
    import pprint

    g = Grammar(r"blib2to3\pgen2\Parser\Grammar.txt")
    p = Parser(g)
    for name, label in g.keywords.items():
        g.labels[label] = name, name
    for token, label in g.tokens.items():
        t = getattr(token, "tok_name", None)
        if t is None:
            t = repr(token)
        g.labels[label] = token, t
    for _, dfa in g.dfas.items():
        for state, arcs in enumerate(dfa[0]):
            pprint.pprint(
                (state, [(g.labels[i], j) for i, j in arcs])# type: ignore
            )



# Generated at 2022-06-23 15:41:26.338688
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    from . import ddl_grammar as g
    p = Parser(g)
    p.setup()

# Generated at 2022-06-23 15:41:30.643506
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, driver

    grammar = grammar.grammar
    p = Parser(grammar, convert=lam_sub)
    p.setup(start=grammar.start)

    def check_node(node, type, value, lineno, offset, children):
        # type: (Any, int, Text, int, int, Sequence[Any]) -> None
        assert node.type == type
        assert node.value == value
        assert node.context == (lineno, offset)
        assert node.children == children

    p.addtoken(0, "foo", Context(0, 0))
    check_node(p.rootnode, 0, None, 0, 0, [])

    p.addtoken(1, "foo", Context(0, 0))

# Generated at 2022-06-23 15:41:32.227272
# Unit test for constructor of class Parser
def test_Parser():
    from . import sample_grammar

    p = Parser(sample_grammar)



# Generated at 2022-06-23 15:41:38.384805
# Unit test for method setup of class Parser
def test_Parser_setup():
    # We create an empty grammar.Grammar object for this test.
    # No start symbol is set.
    # This object won't actually be used for parsing,
    # but quite a lot of parsing structures from grammar.Grammar
    # are used by the 'Parser' class.
    g = Grammar()
    g.keywords = {}

    # We initialize a Parser object with this empty grammar.
    p = Parser(g)
    first_result = p.stack
    first_expected = []
    assert first_result == first_expected, (first_result, first_expected)
    first_result = p.rootnode
    assert first_result is None

    p.setup(1)
    second_result = p.stack
    second_expected = [(None, 0, (1, None, None, []))]

# Generated at 2022-06-23 15:41:48.631957
# Unit test for method setup of class Parser
def test_Parser_setup():

    # Verify that setup() sets the right instance vars
    import unittest

    class PgenParserTest(unittest.TestCase):
        def test_setup(self):
            from . import pgen2

            p = pgen2.driver.load_grammar(
                "Grammar/Grammar", convert=pgen2.convert_grammar
            )
            parser = Parser(p)
            parser.setup()
            self.assertEqual(parser.stack, [(parser.grammar.dfas[1], 0, (1, None, None, []))])
            self.assertEqual(parser.rootnode, None)

    unittest.main()

# Generated at 2022-06-23 15:41:51.015573
# Unit test for method classify of class Parser
def test_Parser_classify():
    t = token
    assert (Parser(Grammar(version="3.6")).classify(t.NAME, "y", None) == t.NAME)

# Generated at 2022-06-23 15:41:57.317825
# Unit test for constructor of class Parser
def test_Parser():
    # If we need to construct unit test for a class, we should tell pytype
    # that the class has to have a module in order to be used.
    from blib2to3.pgen2 import grammar
    from blib2to3.pgen2 import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    d = driver.Driver(p, g)
    d.parse_tokens([(token.NAME, "True", (1, 0))])

# Generated at 2022-06-23 15:42:09.234302
# Unit test for method setup of class Parser
def test_Parser_setup():
    import sys
    import blib2to3.pgen2.parse as parse
    reload(parse)
    g = parse.read_grammar(sys.modules[__name__])
    p = parse.Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    p.setup(parse.tokenize.tok_name['NUMBER'])
    assert p.stack == [(g.dfas[parse.tokenize.tok_name['NUMBER']], 0, (parse.tokenize.tok_name['NUMBER'], None, None, []))]
    assert p.rootnode is None


# Generated at 2022-06-23 15:42:11.921389
# Unit test for function lam_sub
def test_lam_sub():
    assert lam_sub(None, ('a', None, None, [1, 2, 3])) == Node(
        type='a', children=[1, 2, 3], context=None
    )

# Generated at 2022-06-23 15:42:20.612291
# Unit test for method pop of class Parser
def test_Parser_pop():
    # This test needs some refactoring, because there are much more
    # special cases now, see below.

    # How to test:
    # 1. Remove the 2to3 patching and the indirection
    # 2. Adapt the import statement to the original location
    # 3. Execute directly with pytest

    # Why not automated?
    # 1. There are no unittest.mock in Python3.3
    # 2. I tried to patch Parser.convert to do nothing and then stop
    #    convert from entering the recursion. It didn't work out.
    # 3. Other approches how to decouple from the pytree package are
    #    welcome.

    # Step zero: Remove this and the following comments.

    from . import parser
    g = parser.Grammar()
    p = parser.Parser(g)



# Generated at 2022-06-23 15:42:32.516501
# Unit test for method push of class Parser
def test_Parser_push():
    import blib2to3.pgen2.parser

    class TestParser(blib2to3.pgen2.parser.Parser):
        def __init__(self, grammar: Grammar) -> None:
            self.stack: List[Tuple[DFA, int, RawNode]] = []
            self.push_count: int = 0

        def push(self, type: int, newdfa: DFAS, newstate: int, context: Context) -> None:
            self.push_count += 1
            self.stack.append(('push', type, newdfa, newstate, context))

    parser = TestParser(blib2to3.pgen2.parser.Grammar())
    assert parser.push_count == 0
    context = ('fake-context',)

# Generated at 2022-06-23 15:42:36.419910
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    def test(text: str) -> None:
        from . import driver

        p = Parser(grammar.grammar, None)
        p.setup()
        for t in driver.tokenize(text):
            assert p.addtoken(t.type, t.string, t.context)

    test("")
    test("spam")
    test("spam eggs")

# Generated at 2022-06-23 15:42:38.507556
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar("")
    p = Parser(grammar)
    p.setup()



# Generated at 2022-06-23 15:42:50.187872
# Unit test for method push of class Parser
def test_Parser_push():

    class FakeGrammar:
        def __init__(self):
            self.start = 0
            self.dfas = {0: ([[(1, 0)], [(0, 0), (0, 0)], [(2, 0)], [(0, 0)]], {})}

    class FakeLabel:
        def __init__(self, val):
            self.val = val

    class FakeParser:
        def __init__(self):
            self.rootnode = None
            self.used_names = set()
            self.convert = None
            self.grammar = FakeGrammar()
            self.labels = {
                1: FakeLabel(1),
                2: FakeLabel((2, 2)),
                3: FakeLabel(3),
            }
            self.keywords = {'foo': 2}
            self

# Generated at 2022-06-23 15:42:54.689189
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3 import pygram
    from blib2to3.pgen2.grammar import Grammar

    grammar = Grammar(pygram.python_grammar, pygram.python_grammar_consts, "root")
    Parser(grammar).classify(token.PLUS, "+", Context(0, 0))



# Generated at 2022-06-23 15:43:02.559084
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar(grammar.n_grammar_rules, grammar.n_grammar_dfas,
                        grammar.labels, grammar.n_terminals, grammar.__all__)
    p = Parser(g)
    p.setup()
    assert p.grammar == g
    assert p.convert == lam_sub
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-23 15:43:07.892711
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError('message', token.NAME, 'value', None)
    assert str(e) == 'message: type=1, value=value, context=None'
    e = ParseError('message', token.NAME, 'value', (1, 2))
    assert str(e) == 'message: type=1, value=value, context=(1, 2)'

# Generated at 2022-06-23 15:43:14.717520
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .token import tok_name

    g = Grammar("atom", "", "", "", "")
    p = Parser(g)

    # Simulate the Parser.shift method
    for i in range(0, 1000):
        assert i == g.keywords[i]
        assert i == g.tokens[i]
    assert g.keywords[42] == g.tokens[42]

    assert p.stack == []
    dfa = g.dfas[g.start]
    state = 0
    node = (g.start, None, None, [])
    p.stack.append((dfa, state, node))
    assert p.stack[-1] == (dfa, state, node)


# Generated at 2022-06-23 15:43:19.269060
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", token.NUMBER, "123", "context")
    except ParseError as p:
        assert p.msg == "msg"
        assert p.type == token.NUMBER
        assert p.value == "123"
        assert p.context == "context"



# Generated at 2022-06-23 15:43:23.814315
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("message", 1, "value", 3)
    except ParseError as e:
        assert (e.msg, e.type, e.value, e.context) == (
            "message",
            1,
            "value",
            3,
        )
    else:
        assert False, "Failed to raise ParseError exception"


if __name__ == "__main__":
    import driver
    driver.driver()

# Generated at 2022-06-23 15:43:27.682613
# Unit test for method push of class Parser
def test_Parser_push():
    from . import pgen2

    grammar = pgen2.Grammar()
    parser = Parser(grammar)
    parser.push(2, 3, 4, 5)
    assert parser.stack == [(3, 4, (2, None, 5, []))]


# Generated at 2022-06-23 15:43:31.254213
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("msg", 1, "two", (3, 4))
    assert e.msg == "msg"
    assert e.type == 1
    assert e.value == "two"
    assert e.context == (3, 4)

# Generated at 2022-06-23 15:43:33.248327
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("msg", token.NUMBER, "10", (1, 0))
    assert type(e) is ParseError
    assert e.msg == "msg"
    assert e.type == token.NUMBER
    assert e.value == "10"
    assert e.context == (1, 0)

# Generated at 2022-06-23 15:43:40.500079
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    import warnings
    warnings.filterwarnings("ignore", "The grammar")

    p = Parser(grammar)
    p.setup()
    for t in tokenize.generate_tokens("1 + 2 + 3"):
        print(t)
        p.addtoken(t[0], t[1], (t[2], t[3]))

# Generated at 2022-06-23 15:43:48.587538
# Unit test for function lam_sub
def test_lam_sub():
    g = Grammar()
    g.add_symbol(type=1, dfas={0: [[(2, 1)], [(0, 1)]]})
    g.add_symbol(type=2, dfas={0: [[(0, 1)]]})
    g.set_start(0)
    n = lam_sub(g, (1, None, None, None))
    assert n.type == 1
    assert n.children == []
    n = lam_sub(g, (1, None, None, [(2, None, None, None)]))
    assert n.type == 1
    assert n.children == [Node(type=2, children=[], context=None)]

# Generated at 2022-06-23 15:43:58.848791
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import tokenize

    # Test data is a pair of (input, expected_output) tuples

# Generated at 2022-06-23 15:44:06.879762
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import literals, grammar


# Generated at 2022-06-23 15:44:11.263929
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2.grammar import Grammar

    g = Grammar()
    p = Parser(g)
    p.setup(g.start)

    assert len(p.stack) == 1
    assert p.rootnode is None
    assert p.used_names == set()

    assert p.stack[-1][0] == g.dfas[g.start]


# Generated at 2022-06-23 15:44:18.020638
# Unit test for function lam_sub
def test_lam_sub():
    import sys
    import StringIO
    import pickle
    grammar = pickle.load(open(sys.argv[1]))
    # Construct a concrete parse tree for "print 1, 2"
    node = (
        grammar.symbol2number["print_stmt"],
        None,
        None,
        [
            (grammar.symbol2number["atom"], None, None, []),
            (token.NAME, "print", None, None),
            (token.COMMA, ",", None, None),
            (token.NUMBER, "1", None, None),
            (token.COMMA, ",", None, None),
            (token.NUMBER, "2", None, None),
            (token.ENDMARKER, "", None, None),
        ],
    )
    # Build a fake grammar

# Generated at 2022-06-23 15:44:18.709540
# Unit test for method pop of class Parser
def test_Parser_pop():
    p = Parser()
    p.pop()

# Generated at 2022-06-23 15:44:21.048954
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser()
    assert str(p) == "<<class 'Parser'>>"

    # Exists from start?
    assert hasattr(p, 'push')

    # Checks types of attributes.
    assert type(p.push) is int



# Generated at 2022-06-23 15:44:32.260151
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Method classify of class Parser"""
    # pylint: disable=no-self-use,unused-argument,expression-not-assigned
    from . import driver
    from . import grammar

    # Get parser & tokenizer
    p = Parser(grammar.Grammar())
    t = driver.Driver(p.grammar)

    # Classify a number
    assert p.classify(t.number_tok, "42") == 1

    # Classify a name
    assert p.classify(t.name_tok, "foo") == 54

    # Classify a name that is a keyword
    assert p.classify(t.name_tok, "from") == 31

    # Classify a bad token
    got_exception = False

# Generated at 2022-06-23 15:44:37.066133
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar())
    p.setup()
    p.shift(token.NAME, 'n', 0, (1,2))
    assert p.stack == [(
            ([[(0, 0)]], set([0])),
            0,
            (1, None, (1, 2), [Leaf(token.NAME, 'n')]))]

# Generated at 2022-06-23 15:44:45.937550
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Unit test for method shift of class Parser"""
    from blib2to3.pgen2 import driver as pgen2_driver
    from blib2to3.pgen2 import token as pgen2_token
    from blib2to3.pgen2.grammar import Grammar

    # Read the Python grammar
    grammar_file = "/home/schirmer/usr/lib64/python3.7/Lib/lib2to3/Grammar.txt"
    with open(grammar_file, "r") as gfile:
        gdata = gfile.read()
        gfile.close()

    # Create a grammar instance
    grammar = Grammar(gdata, pgen2_driver.PgenParser("Parser/Python.grammar", "Parser/tokenizer.txt"))
    p = Parser(grammar)

# Generated at 2022-06-23 15:44:49.720913
# Unit test for constructor of class Parser
def test_Parser():
    from .pgen import driver

    files = ["Grammar/Grammar"]
    driver.load_grammar(files)

    p = driver.Parser(driver.grammar, driver.convert)



# Generated at 2022-06-23 15:44:59.415813
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    import logging

    logging.basicConfig(level=logging.DEBUG, format="%(message)s")
    g = grammar.Grammar("""#! ./foo
    start : A
    A : 'a'
    B : 'a'
    """)
    P = Parser(g)
    P.setup(1)
    P.push(0, g.dfas[4], g.dfas[4][0][0], (1, 0))
    print("P.stack[-1]:", P.stack[-1])
    assert P.stack[-1] == (([], {0: [(0, 0)]}), 0, (1, None, (1, 0), []))

# Generated at 2022-06-23 15:45:07.791364
# Unit test for function lam_sub
def test_lam_sub():
    class Grammar(object):
        dfas = {0: ([[(1, 1)], [(2, 2)], [(0, 2), (-1, -1)]], ((0, 1, 2), (1, 2)))}
        labels = {1: (256, "num"), 2: (257, "none")}

    node = (0, None, None, [(1, '1', None, None), (2, None, None, [])])
    conv = lam_sub
    assert conv(Grammar, node).children == [Node(type='num', value='1', context=None),
                                            Node(type='none', value=None,
                                                 context=None, children=[])]

# Generated at 2022-06-23 15:45:11.315746
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Initialize fields
    grammar = None
    convert = None
    p = Parser(grammar, convert)

    # Set fields
    type = 1
    value = "a"
    newstate = 1
    context = None

    # Test
    p.shift(type, value, newstate, context)
    assert p.stack[0][0][0] == [(1, 1)]
    assert p.stack[0][0][1] == []

# Generated at 2022-06-23 15:45:16.884921
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .tokenize import generate_tokens
    from .grammar import grammar

    g = grammar()
    p = Parser(g)
    p.setup()

    # Create a fake token list from a source code string
    import StringIO
    source = StringIO.StringIO('''\
if 1:
    def f(x): pass
''')
    for type, value, start, end, line in generate_tokens(source.readline):
        if type == token.ENDMARKER:
            break
        p.addtoken(type, value, start)

    assert isinstance(p.rootnode, Leaf)
    assert p.rootnode.type == token.NEWLINE
    assert p.rootnode.value == '\n'
    assert p.rootnode.prefix == ''
    assert p.rootnode.lin

# Generated at 2022-06-23 15:45:24.869655
# Unit test for method classify of class Parser
def test_Parser_classify():
    import re
    import blib2to3.parse
    from .token import tok_name as token_name
    pat = re.compile(r"^([A-Z_]+)\d*$")
    for name, value in token_name.items():
        m = pat.match(name)
        if m:
            g = m.group(1)
            tok = getattr(token, g)
            if tok is not None:
                yield Parser, tok, None, None



# Generated at 2022-06-23 15:45:35.024592
# Unit test for method push of class Parser
def test_Parser_push():
    from . import parser

    class MockGrammar(object):
        """Mock a Grammar object."""
        dfas = {
            1: ([(1, 1)], {1: 1}),
            2: ([(None, None)], {})
        }

    gr: MockGrammar = MockGrammar()
    p: parser.Parser = parser.Parser(gr)
    p.setup()
    p.push(2, gr.dfas[2], 0, None)
    assert p.stack == [(gr.dfas[1], 0, (1, None, None, [])),
                       (gr.dfas[2], 0, (2, None, None, []))]

# Generated at 2022-06-23 15:45:42.928831
# Unit test for method pop of class Parser
def test_Parser_pop():
    class TestConvert(object):
        def __init__(self):
            self.converted_nodes = []
            self.converted_nodes_types = []

        def __call__(self, grammar, node):
            if node == (0, None, None, [1]):
                return None
            else:
                self.converted_nodes.append(node)
                self.converted_nodes_types.append(node[0])
                return (node)

    class TestNode(object):
        def __init__(self, type, children):
            self.type = type
            self.children = children

    p = Parser(Grammar(), None)
    p.rootnode = TestNode(0, ())
    p.stack = [(None, None, (0, None, None, []))]


# Generated at 2022-06-23 15:45:45.569839
# Unit test for method setup of class Parser
def test_Parser_setup():
    parser = Parser(Grammar(''))
    parser.setup()
    assert parser.stack == []



# Generated at 2022-06-23 15:45:57.191464
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    class MockGrammar(object):
        def __init__(self):
            self.start = 5

# Generated at 2022-06-23 15:46:02.576674
# Unit test for constructor of class Parser
def test_Parser():
    gram1 = Grammar()
    gram1.labels = [('', ''),
                 ('a', ''),
                 ('b', ''),
                 ('c', '')]
    gram1.keywords = {}
    gram1.start = 1
    gram1.tokens = {}

# Generated at 2022-06-23 15:46:04.360922
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    assert p

# Generated at 2022-06-23 15:46:09.203167
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test", 1, 2, 3)
    except ParseError as p:
        if p.msg != "test" or p.type != 1 or p.value != 2 or p.context != 3:
            print("Failed ParseError__init__()")

# Generated at 2022-06-23 15:46:19.375811
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize
    import StringIO

    g = grammar.grammar

    p = Parser(g)
    p.setup()
    t = p.addtoken
    r = p.rootnode

    # The following should work

    p.setup()
    data = "print 123"
    t.__self__.used_names
    t(token.NAME, "print", Context(1, 0, data))
    t(token.NUMBER, "123", Context(1, 5, data))
    t(token.ENDMARKER, "", Context(1, 8, data))
    assert r.type == g.symbol2number["file_input"]
    assert len(r) == 1
    assert r[0].type == g.symbol2number["stmt"]

# Generated at 2022-06-23 15:46:25.710390
# Unit test for method push of class Parser
def test_Parser_push():
    """Method push should not modify dfa and state members."""
    def test_stack_empty():
        """is stack empty"""
        return (not p2.stack)
    def test_classify_throw():
        """classify throw exception"""
        try:
            p2.classify(token.NAME, 'test', None)
            return False
        except ParseError:
            return True
    def test_shift_modify_stack():
        """shift modify stack"""
        p2.shift(token.NAME, 'test', 1, None)
        return (p2.stack[0] == (dfa, 1, node))
    def test_push_modify_stack():
        """push modify stack"""
        p2.push(token.NAME, dfa, 2, None)

# Generated at 2022-06-23 15:46:33.229468
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    import os


    def is_dfas_type(obj: Any) -> bool:
        return type(obj) is tuple
    p = Parser(grammar)
    p.setup()
    assert type(p.stack) is list
    assert len(p.stack) == 1
    assert type(p.stack[0]) is tuple
    assert len(p.stack[0]) == 3
    assert is_dfas_type(p.stack[0][0])
    assert type(p.stack[0][1]) is int
    assert type(p.stack[0][2]) is tuple
    assert len(p.stack[0][2]) == 4
    p.setup(grammar.start)


# Generated at 2022-06-23 15:46:35.340580
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()



# Generated at 2022-06-23 15:46:40.654323
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammars, converters

    for gr in grammars.grammars:
        for co in converters.converters:
            p = Parser(gr, co)
            p.setup()
            assert p.pop() is None
            assert p.rootnode is None
            assert p.stack == []

# Generated at 2022-06-23 15:46:52.145427
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test for no exception
    ParseError("msg", 2, "end", Context(None, 1))
    # Test for TypeError: ParseError() takes exactly 4 arguments (5 given)
    try:
        ParseError("msg", 2, "end", Context(None, 1), "wrong")
    except TypeError:
        pass  # Ok
    # Test for TypeError: __init__() should return nothing
    try:
        class MyParseError(ParseError):
            def __init__(self):
                return 42
        MyParseError().__init__()
    except TypeError:
        pass  # Ok
    # Test for TypeError: __init__() takes at least 3 arguments (2 given)

# Generated at 2022-06-23 15:47:02.085579
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, tokenize

    p = Parser(grammar.grammar)
    classify = p.classify

    # Classify each keyword token
    for type, value in token.__dict__.items():
        if isinstance(value, int):
            if value >= 256 and value <= 315:
                assert classify(value, None, None) == value

    # Classify NAME tokens
    for type, value in token.__dict__.items():
        if isinstance(value, int):
            if value == token.NAME:
                assert classify(value, 'name', None) == value

    # Classify NEWLINE token
    assert classify(tokenize.NL, None, None) == token.NEWLINE

    # Classify ENCODING token
    assert classify(tokenize.ENCODING, None, None) == token.ENCOD

# Generated at 2022-06-23 15:47:13.516669
# Unit test for method shift of class Parser
def test_Parser_shift():
    class fake_grammar:
        def __init__(self):
            self.keywords = {}
            self.labels = {}
            self.tokens = {}
            self.start = None
            self.dfas = {}
    class fake_context:
        def __init__(self):
            self.line_offset = 0
            self.line = 0
    fg = fake_grammar()
    fc = fake_context()
    fc.line = 1
    fc.line_offset = 2
    p = Parser(fg, None)

# Generated at 2022-06-23 15:47:25.106148
# Unit test for function lam_sub
def test_lam_sub():
    # type: () -> None
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)

# Generated at 2022-06-23 15:47:32.626436
# Unit test for method push of class Parser
def test_Parser_push():
    from .. import pgen2

    grammar = pgen2.load_grammar("test/pgen2/test1.g")
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(1, "hello", None)
    # Expected type for parser.stack:
    # List[Tuple[Tuple[List[List[Tuple[int, int]]], Dict[int, int]], int, Tuple[int, NoneType, NoneType, List[NoneType]]]]
    # Actual type:
    # List[Tuple[List[List[Tuple[int, int]]], int, Tuple[int, NoneType, NoneType, List[NoneType]]]]
    #  fail: {0}
    #  fail: {0}.1
    #  fail: {0}.2
    #

# Generated at 2022-06-23 15:47:39.684044
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = Grammar()
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    parser = Parser(grammar)
    try:
        parser.classify(1, None, None)
    except ParseError as exc:
        assert exc.type == 1
        assert exc.value is None
        assert exc.context is None
    else:
        assert False, "Illegal token should have caused an exception"
    assert grammar.keywords == {}
    assert grammar.tokens == {}

# Generated at 2022-06-23 15:47:46.483532
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import token
    from . import grammar
    from . import parse
    from . import grammar as grammar

    g = grammar.Grammar(grammar.DEFAULT_GRAMMAR)
    p = parse.Parser(g)
    p.setup()
    stack = p.stack
    dfa, state, node = stack[-1]
    node = node[2]
    p.pop()
    assert node == None



# Generated at 2022-06-23 15:47:54.822768
# Unit test for function lam_sub
def test_lam_sub():
    class Grammar(object):
        labels = {
            1: (0, 0),
            2: (0, 1),
            3: (1, 2),
            4: (1, 3),
            5: (1, 4),
            6: (1, 5),
        }
        dfas = {
            0: (
                [
                    [(1, 1), (2, 2)],
                    [(3, 3)],
                    [(4, 4)],
                ],
                1,
            ),
            1: (
                [
                    [(5, 5), (6, 6)],
                    [(3, 3)],
                    [(4, 4)],
                    [(0, 0)],
                    [(0, 0)],
                    [(0, 0)],
                ],
                1,
            ),
        }
        tokens

# Generated at 2022-06-23 15:48:06.415453
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import tokenize
    from . import grammar
    import io

    # Testing method shift of class Parser
    text = "print('Hello, world!')"
    filename = '<test string>'
    stream = io.StringIO(text)
    encoding = 'utf-8'
    p = Parser(grammar, None)
    p.setup()
    tokengen = tokenize.generate_tokens(stream.readline)

# Generated at 2022-06-23 15:48:16.065255
# Unit test for method setup of class Parser
def test_Parser_setup():
    import sys
    import blib2to3.pgen2.pgen

    if len(sys.argv) == 1:
        print("usage: python -m blib2to3.pgen2.parser filename ...")
        sys.exit(2)

    for filename in sys.argv[1:]:
        f = open(filename, "rb")
        encoding, lines = blib2to3.pgen2.tokenize.detect_encoding(f.readline)
        f = open(filename, "r", encoding=encoding)
        blib2to3.pgen2.pgen.generate_grammar("blib2to3/pgen2/Grammar.txt")

# Generated at 2022-06-23 15:48:26.912844
# Unit test for method classify of class Parser
def test_Parser_classify():
    def make_parser(start: Optional[str]) -> Parser:
        from . import driver

        r = driver.load_grammar("python3")
        p = Parser(r, None)
        if start:
            p.setup(r.symbol2number[start])
        else:
            p.setup()
        return p

    p = make_parser(None)
    assert p.classify(token.NUMBER, "3", None) == 3
    assert p.classify(token.PLUS, "+", None) == 36
    assert p.classify(token.NAME, "if", None) == 4
    assert p.classify(token.NAME, "__name__", None) == 1

    p = make_parser("testlist")

# Generated at 2022-06-23 15:48:32.005314
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        # test all branches of exception raising
        raise ParseError(
            "test_Parser.test_ParseError", token.ENDMARKER, "", Context(Preceding=(), Origin="")
        )
    except ParseError as e:
        assert e.msg == "test_Parser.test_ParseError"
        assert e.type == token.ENDMARKER
        assert e.value == ""
        assert e.context == Context(Preceding=(), Origin="")

# Generated at 2022-06-23 15:48:40.736478
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .grammar import Grammar
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pygram import python_grammar_no_print_statement
    from .token import tok_name
    from .driver import Driver

    def convert(grammar, node):
        n = node[1]
        if n == "int":
            # Convert int to string
            node[1] = "int-as-string"
        elif n == "float":
            # Convert float to string
            node[1] = "float-as-string"
        return node

    gr = Grammar(python_grammar_no_print_statement)
    pg = Parser(gr, convert=convert)
    dr = Driver(pg)
    dr.tokenize("1")

# Generated at 2022-06-23 15:48:50.513899
# Unit test for function lam_sub
def test_lam_sub():
    testcases = [
        ([], []),
        ([1], [1]),
        ([1, 2], [1, 2]),
        ([1, 2, 3], [1, [2, 3]]),
        ([1, 2, 3, 4], [1, [2, 3, 4]]),
        ([1, 2, 3, 4, 5], [1, [2, [3, 4, 5]]]),
    ]
    for tc in testcases:
        inp, outp = tc
        token = ("", "", None, inp)
        result = lam_sub(None, token)
        assert result == outp

# Generated at 2022-06-23 15:48:56.334339
# Unit test for constructor of class ParseError
def test_ParseError():
    # Check that creating the exception works
    pe = ParseError("test", 0, "token", (1, 20))
    assert pe.msg == "test"
    assert pe.type == 0
    assert pe.value == "token"
    assert pe.context == (1, 20)
    # Check that it prints nicely
    assert str(pe) == "test: type=0, value='token', context=(1, 20)"

# Generated at 2022-06-23 15:49:06.514905
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from .grammar import Grammar
    from .parser import Parser
    from blib2to3.pgen2.token import Token
    grammar_grammar = Grammar(open(grammar.__file__.rstrip("c")).read(), "exec")
    p = Parser(grammar_grammar)
    p.setup()
    # del() statements are ignored by the exec grammar, so let's make sure
    # the parser doesn't kill del() statements by accident.
    p.addtoken(Token.NAME, "del", None)
    p.addtoken(Token.NAME, "x", None)
    # We should never get a ParseError from the above input sequence.
    node = p.rootnode
    assert node.type == grammar_grammar.symbol2number["expr_stmt"]


# Generated at 2022-06-23 15:49:09.628458
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("msg", 1, "value", "context")
    assert exc.msg == "msg"
    assert exc.type == 1
    assert exc.value == "value"
    assert exc.context == "context"

# Generated at 2022-06-23 15:49:14.379719
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Issue #22648: Check that shift() doesn't fail if rootnode is None
    p = Parser(Grammar())
    p.rootnode = None
    p.shift(0, '', 0, Context(0, 0))



# Generated at 2022-06-23 15:49:16.926672
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test for Issue #14632 - ParseError should be Exception subclass
    try:
        raise ParseError("", 0, "", None)
    except Exception:
        pass

# Generated at 2022-06-23 15:49:28.598083
# Unit test for method push of class Parser
def test_Parser_push():
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.tokenize import generate_tokens
    driver = Driver()
    grammar = driver.load_grammar('python3.gram')
    parser = Parser(grammar)
    try:
        parser.setup()
    except ParseError as e:
        assert False
    parser.push(0, (1, (2, 3)), 0, 4)
    parsed = parser.stack[1]
    assert parsed == (1, (2, 3)), parsed

# Generated at 2022-06-23 15:49:38.964821
# Unit test for method push of class Parser
def test_Parser_push():
    from unittest import TestCase, main as ut_main

    class ParserTest(TestCase):
        # Unit test for method push of class Parser
        def test_push(self):
            from blib2to3.pgen2.grammar import Grammar
            from blib2to3.pgen2 import token


# Generated at 2022-06-23 15:49:45.142755
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser = Parser(object())
    dfa = object()
    state = object()
    raw_node = (object(), object(), object(), object())

    def convert(grammar: Grammar, node: RawNode) -> Node:
        return Node(type=node[0], children=node[3], context=node[2])

    parser.stack = [(dfa, state, raw_node)]
    parser.convert = convert

    parser.pop()
    assert parser.rootnode == Node(type=raw_node[0], children=raw_node[3], context=raw_node[2])


# Local Variables:
# tab-width:4
# indent-tabs-mode:nil
# End:
# vim: set expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-23 15:49:48.456821
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("test", 1, "abc", (7, 0))
    assert err.msg == "test"
    assert err.type == 1
    assert err.value == "abc"
    assert err.context == (7, 0)

# Generated at 2022-06-23 15:49:59.877420
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest
    from . import grammar, tokenizer, driver

    class TestParser(unittest.TestCase):
        def test_classify(self):
            self.assertEqual(self.p.classify(token.NAME, "for", (1, 0)), self.for_)
            self.assertTrue(self.p.classify(token.NAME, "a", (1, 0)) > 256)

    g = grammar.parse_grammar(driver.grammar)
    p = Parser(g)
    t = tokenizer.tokenize_file("Grammar/Grammar", g.syms)
    p.setup()
    for type, value, start, end in t:
        p.addtoken(type, value, (start[0], start[1]))
    TestParser.p = p


# Generated at 2022-06-23 15:50:09.399704
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest


    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            # Test that calling addtoken on a Parser instance gives
            # the same results as calling addtoken on a Parser_1
            # instance.

            # Get the unmodified grammar.
            f = open("Grammar/Grammar", "r")
            g = Grammar(f)
            f.close()
            # Get the modified grammar.
            from .driver import load_grammar

            g1 = load_grammar(g)
            # Create a Parser and a Parser_1 from the same grammar.
            p = Parser(g)
            p1 = Parser_1(g1)
            # Parse the sample program.
            f = open("Sam/sample.txt", "r")

# Generated at 2022-06-23 15:50:21.679531
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest
    from . import driver
    from .token import NAME

    class ParserClassifyTest(unittest.TestCase):
        def test_classify(self):
            """Testing classify()"""
            parser = driver.get_parser()
            # Check for reserved words
            self.assertEqual(
                parser.classify(NAME, "and", (1, 1)), parser.grammar.keywords["and"]
            )
            # Check for tokens
            self.assertEqual(
                parser.classify(NAME, "and", (1, 1)), parser.classify(NAME, "x", (1, 1))
            )

    unittest.main()

if __name__ == "__main__":
    test_Parser_classify()

# Generated at 2022-06-23 15:50:35.018541
# Unit test for constructor of class Parser
def test_Parser():
    import sys

    from . import grammar, driver, token

    if __name__ == '__main__':
        g = Grammar(sys.modules[__name__])
        gram = grammar.Grammar(g)
        p = Parser(gram)
        p.setup()

    def tok_token(tok) -> Tuple[int, Optional[Text]]:
        toktype, tokvalue = token.tok_name[tok.type], tok.string
        return toktype, tokvalue

    def run_parser(input: str) -> None:
        driver.Driver(gram, Parser).run_parser(input, tok_token)

    def test(input, expected_output) -> None:
        import difflib
        from io import StringIO
        actual_output = StringIO()
        sys