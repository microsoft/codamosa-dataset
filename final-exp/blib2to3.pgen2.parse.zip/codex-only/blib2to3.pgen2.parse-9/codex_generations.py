

# Generated at 2022-06-23 15:40:36.784804
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .token import tok_map
    from . import grammar
    from . import driver
    from . import pytree
    from . import pygram
    from .pygram import python_symbols
    driv = driver.Driver(grammar.grammar, convert=pytree.convert)
    driv.setup_parser(start=python_symbols.file_input)
    # Shift a token
    type, value, context = tok_map['NAME'], 'foo', (2, 3)
    driv.parser.shift(type, value, 1, context)

# Generated at 2022-06-23 15:40:47.418210
# Unit test for method setup of class Parser
def test_Parser_setup():
    # pylint: disable=unreachable
    # Test code setup in class Parser
    # In this test, we only test the initilization of stacks
    # in class Parser
    # We will create a dfa with start state 0 and end state 1
    # and a label with index 0
    dfa = [[(0, 0), (1, 1)]]
    labels = {0: (token.NAME, None)}
    dfas = {'test': (dfa, labels)}
    # Then we create a grammar with the above dfa list
    grammar = Grammar(dfas, {}, {})
    # Then we create an instance of class Parser
    parser = Parser(grammar)
    # Prepare for parsing
    parser.setup()
    # Now we test if the stacks is correctly generated
    # We manually set up a stack

# Generated at 2022-06-23 15:40:53.693995
# Unit test for method setup of class Parser
def test_Parser_setup():
    import lib2to3.pgen2.pgen
    import lib2to3.pgen2.token
    p = lib2to3.pgen2.parser.Parser(lib2to3.pgen2.pgen.get_grammar())

    def checkfunc(p):
        assert p.grammar is not None
        assert p.convert is not None
        assert p.stack == []
        assert p.rootnode is None
        assert p.used_names == set()

    checkfunc(p)
    p.setup()
    checkfunc(p)
    p.setup(start=lib2to3.pgen2.token.STRING)
    checkfunc(p)

# Generated at 2022-06-23 15:41:02.916593
# Unit test for method push of class Parser
def test_Parser_push():
    import unittest
    class ParserTest(unittest.TestCase):
        def test_push(self):
            teststate: int = 0
            testtype: int = 9998
            testdfa: DFAS = ([[(0, 9997)]], {9999: 9999})
            testcontext: Context = None
            teststack: List[Tuple[DFAS, int, RawNode]] = [
                (testdfa, teststate, (testtype, None, testcontext, []))
            ]
            testParser: Parser = Parser(Grammar())
            testParser.stack = teststack
            testParser.push(testtype, testdfa, teststate, testcontext)
            self.assertEqual(testParser.stack, teststack)

    unittest.main()

# Generated at 2022-06-23 15:41:09.573067
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Arrange
    class Fakeparser:
        stack = [
            ([1,2], 3, None),
            ([1,2], 3, None),
            ([1,2], 3, None),
        ]

    parser = Fakeparser()
    # Act
    parser.pop()
    # Assert
    assert parser.stack == [
        ([1,2], 3, None),
        ([1,2], 3, None),
    ]

# Generated at 2022-06-23 15:41:22.427912
# Unit test for method push of class Parser
def test_Parser_push():
    def lam_sub(grammar, node):
        return Node(type=node[0], children=node[3], context=node[2])

    grammar = Grammar('''
        start: "a" bar "c"
        bar: "d" "e"
        ''')

    filename = 'a'

    parser = Parser(grammar, lam_sub)
    parser.setup()
    parser.addtoken(token.STRING, 'a', Context(filename, 1, 0, 1))
    parser.addtoken(token.STRING, 'd', Context(filename, 1, 1, 2))
    parser.addtoken(token.STRING, 'e', Context(filename, 1, 2, 3))
    parser.addtoken(token.STRING, 'c', Context(filename, 1, 3, 4))

# Generated at 2022-06-23 15:41:32.351883
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    from pprint import pprint
    from . import driver
    from . import token
    from . import grammar
    from . import parser

    def validate(grm: Grammar, node: Union[Node, Leaf]) -> None:
        if node.type == token.NEWLINE:
            return
        type = node.type
        if type >= 256 and type not in grm.symbols:
            print(node, type, grm.symbols)
            assert 0, "invalid symbol"
        if not node.children:
            return
        for child in node.children:
            validate(grm, child)

    def parse_file(filename: Text, debug: int, convert: Optional[Convert] = None) -> None:
        f = open(filename, "rb")
        source = f.read()
       

# Generated at 2022-06-23 15:41:44.482108
# Unit test for method push of class Parser
def test_Parser_push():
    class Grammar(object):
        def __init__(self):
            self.start = 257
            self.dfas = {257: ([[(1, 258)], [(0, 1), (0, 2)], [(0, 2)], []], {1: 2})}

    p = Parser(Grammar())
    p.setup()
    # The test is for the 'push' method of Parser
    # The method uses a callback 'convert' to convert a value from
    # the parser stack to a value that is to be pushed to the stack.
    # The way the 'convert' method is used is an assumption;
    # see 'blib2to3.pgen2.driver.py' for details.
    # The test is for the case when a Leaf is created using 'convert',
    # which is assigned to the

# Generated at 2022-06-23 15:41:51.310952
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar())
    p.stack = [(p.grammar.dfas[0], 0, ((0, None, None, None), None, None, []))]
    p.shift(0, "0", 1, Context(3, 7))
    assert p.stack == [(p.grammar.dfas[0], 1, ((0, None, None, [((0, "0", Context(3, 7), None), None, None, None)]), None, None, []))]


# Generated at 2022-06-23 15:41:54.475207
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver, token, symbol
    grammar = driver.load_grammar("Grammar/Grammar")
    p = Parser(grammar)
    p.setup(symbol.file_input)

# Generated at 2022-06-23 15:41:57.479545
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("abc", 1, "def", (7, 8))
    assert err.msg == "abc"
    assert err.type == 1
    assert err.value == "def"
    assert err.context == (7, 8)



# Generated at 2022-06-23 15:42:03.001382
# Unit test for method classify of class Parser
def test_Parser_classify():
    parser = Parser(None)
    assert parser.classify(token.LPAR, '(', None) == 1
    assert parser.classify(token.RPAR, ')', None) == 2
    assert parser.classify(token.NAME, 'NAME', None) == 0

# Generated at 2022-06-23 15:42:13.095567
# Unit test for method setup of class Parser
def test_Parser_setup():
    class Grammar:
        dfas = {0: ([[(1, 1), (2, 1)], [(0, 1)]], {0: 0, 1: 1}), 1: ([[(0, 1)]], {0: 0, 1: 1})}
        start = 0
        labels = [(1, (token.NAME, "test"))]
        tokens = {token.NAME: 1}
        keywords = {}

    for arg in (None, Grammar()):
        parser = Parser(Grammar())
        parser.setup()
        assert parser.stack == [(Grammar.dfas[Grammar.start], 0, (Grammar.start, None, None, []))]
        assert parser.rootnode is None


# Generated at 2022-06-23 15:42:20.581928
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar(open('Python.asdl')))
    p.setup()
    assert p.stack == []
    p.shift(1, '+', 0, None)
    assert p.stack == [(None, 0, ([], []))]
    p.shift(1, '+', 0, None)
    assert p.stack == [(None, 0, ([], [('+', None, None, None)]))]
    p.shift(1, '+', 0, None)
    assert p.stack == [(None, 0, ([], [('+', None, None, None), ('+', None, None, None)]))]

if __name__ == "__main__":
    test_Parser_shift()

# Generated at 2022-06-23 15:42:24.338003
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("message", 1, "value", Context(1, 0, "<string>", NL))
    assert isinstance(exc.args[0], str)


# Generated at 2022-06-23 15:42:34.814345
# Unit test for constructor of class ParseError
def test_ParseError():
    # Check that instantiating ParseError with all bad things throws
    # TypeError
    raises(TypeError, ParseError, None, None, None, None)
    raises(TypeError, ParseError, '', None, None, None)
    raises(TypeError, ParseError, '', [], None, None)
    raises(TypeError, ParseError, '', [], [], None)
    raises(TypeError, ParseError, '', [], [], [])
    raises(TypeError, ParseError, '', [], '', [])
    raises(TypeError, ParseError, '', '', [], [])

    # Check that instantiating ParseError with all good things
    # functions correctly
    foo = ParseError('', 1, "", ())
    assert foo.msg == ''
    assert foo.type

# Generated at 2022-06-23 15:42:36.205754
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import pytree, tree

# Generated at 2022-06-23 15:42:43.278920
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from blib2to3.pgen2 import parse

    # The following grammar is from Hello.grammar:
    #
    #  start: name NEWLINE     $name.set_name_lineno(lineno, 0);
    #  name: NAME
    #  NEWLINE: '\n'
    #
    # In addition, the following tokens are recognized:
    #
    #  TOKEN: NL
    #
    # token.NL is mapped to the label '\n', and so on.
    #
    p = Parser(parse)
    p.setup(start="start")
    t = driver.Driver(p.addtoken, [])
    t.setup()
    t.input("Hello")
    t.inputline('world"\n')
    t.inputline()
    t

# Generated at 2022-06-23 15:42:52.289824
# Unit test for method classify of class Parser
def test_Parser_classify():
    import sys
    import blib2to3.pygram
    import blib2to3.pytree
    pt = blib2to3.pytree
    tree = pt.fromstring(
        """from sys import *\nfrom foo import *\n"""
    )  # type: Sequence[Node]
    grammar = blib2to3.pygram.python_grammar
    tokens = blib2to3.pygram.python_grammar_nt.tokens
    keywords = blib2to3.pygram.python_grammar_nt.keywords
    labels = blib2to3.pygram.python_grammar_nt.labels
    p = Parser(grammar)
    p.setup()
    assert p.addtoken(tokens['NAME'], "from", tree[0].children[0])

# Generated at 2022-06-23 15:43:01.116015
# Unit test for method classify of class Parser
def test_Parser_classify():
    import pkgutil
    import sys
    import os
    from . import driver

    # Look for grammar.py in the directory above this one
    path = os.path.dirname(os.path.abspath(driver.__file__))
    path = os.path.dirname(path)
    sys.path.insert(0, path)
    # pylint: disable=wrong-import-position
    from . import grammar

    # pylint: disable=import-error,no-name-in-module
    gram = grammar.Grammar(pkgutil.get_data("blib2to3.pgen2.driver", "Grammar.txt"))
    p = Parser(gram)
    # Test a few labels
    assert p.classify(token.NAME, "foo", None) == 1

# Generated at 2022-06-23 15:43:08.025842
# Unit test for method pop of class Parser
def test_Parser_pop():
    class Grammar:
        pass
    class Context:
        pass
    parser = Parser(Grammar())
    parser.stack = [('dfa', 1, ('A', 'value', 'context', []))]
    parser.stack.append(('dfa', 1, ('B', 'value', 'context', [])))
    parser.pop()
    assert parser.stack[0][-1][-1] == [Node(type='B', children=[], context='context')]

# Generated at 2022-06-23 15:43:20.195050
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Verify the class Parser can pop a nonterminal."""

    # Create a Parser
    from . import grammar, token
    from .parse import Parser

    g = grammar.Grammar()
    t_ID = g.add_terminal("ID", 0)
    t_PLUS = g.add_terminal("PLUS", 1)
    n_a_b = g.add_nonterminal("a_b", 0)
    n_a_b_c = g.add_nonterminal("a_b_c", 1)

    g.add_production(n_a_b, [n_a_b_c], None, None)
    g.add_production(n_a_b_c, [t_ID], None, None)

    # Add stuff to the parser
    p = Parser

# Generated at 2022-06-23 15:43:24.464658
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Test that Parser.shift does not break when no convert function has
    # been supplied.
    parser = Parser(Grammar())
    parser.setup()
    parser.shift(token.NAME, "foobar", 0, Context(1, 0))

# Generated at 2022-06-23 15:43:34.239335
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from .token import token
    g = grammar.Grammar()
    p = Parser(g)
    lam_sub(g, (token.LPAR, None, (1, 0), []))
    lam_sub(g, (token.RPAR, None, (1, 4), []))
    node = lam_sub(g, (grammar.suite, None, (1, 0), [
        (token.NEWLINE, None, (1, 0), None),
        (grammar.simple_stmt, None, (2, 0), None)
    ]))
    assert node.__class__.__name__ == "Node"
    assert node.type == grammar.suite

# Generated at 2022-06-23 15:43:46.631727
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from .driver import Driver, GenericASTBuilder

    # tree_grammar is the grammar for the trees we're going to parse
    tree_grammar = grammar.grammar()
    tree_driver = Driver(tree_grammar, GenericASTBuilder())
    tree_parser = tree_driver.parser

    # ast_grammar is the grammar for the ASTs we're going to produce
    ast_grammar = grammar.grammar()
    ast_driver = Driver(ast_grammar, GenericASTBuilder())
    ast_parser = ast_driver.parser


    # Parser(grammar, [converter])
    # The parser is not ready yet for parsing; must call setup()
    # The converter argument is a function mapping concrete
    # syntax tree nodes to abstract syntax tree nodes.

# Generated at 2022-06-23 15:43:57.423906
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2 import driver, tokenize
    from blib2to3.pgen2.parse import ParseError, Parser

    # Create a Parser instance
    grammar = driver.load_grammar("Python.g3")
    parser = Parser(grammar)
    # Test NAME tokens
    parser.setup()
    parser.addtoken(token.NAME, "x", None)
    parser.addtoken(token.NAME, "y", None)
    parser.addtoken(token.NAME, "z", None)
    parser.addtoken(token.NAME, "and", None)
    parser.addtoken(token.NAME, "assert", None)
    parser.addtoken(token.NAME, "break", None)
    parser.addtoken(token.NAME, "while", None)

# Generated at 2022-06-23 15:44:09.158649
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    import blib2to3.pgen2.grammar

    # instantiate a parser
    p = Parser(blib2to3.pgen2.grammar.Grammar())

    # create tokens
    tok1 = token.NUMBER, '1', (1, 0)
    tok2 = token.PLUS, '+', (1, 2)
    tok3 = token.NUMBER, '2', (1, 4)

    # create the parse tree
    p.setup()
    assert not p.addtoken(tok1[0], tok1[1], tok1[2])
    assert not p.addtoken(tok2[0], tok2[1], tok2[2])

# Generated at 2022-06-23 15:44:13.736765
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        x = ParseError("test error", 1, "test value", Context(None, 1, 1, "test context"))
    except ParseError:
        assert 0, "unexpected ParseError"
    else:
        assert x.msg == "test error"
        assert x.type == 1
        assert x.value == "test value"
        assert x.context == "test context"

# Generated at 2022-06-23 15:44:15.551054
# Unit test for method push of class Parser
def test_Parser_push():
    assert hasattr(Parser, "push")
    assert isinstance(Parser.push, types.MethodType)


# Generated at 2022-06-23 15:44:23.566187
# Unit test for method classify of class Parser
def test_Parser_classify():
    ll = [
        (1, "x", "NAME"),
        (1, "y", "NAME"),
        (1, "z", "NAME"),
    ]
    p = Parser(Grammar(ll, {}), None)
    p.setup()
    assert p.classify(token.NAME, "x", "") == 0
    assert p.classify(token.NAME, "y", "") == 0
    assert p.classify(token.NAME, "z", "") == 0
    assert p.classify(token.NAME, "a", "") == 1
    assert p.classify(token.NUMBER, "5", "") == 1
    assert p.classify(token.NUMBER, "5", "") == 1



# Generated at 2022-06-23 15:44:33.708825
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize


    def parse(s: str) -> Results:
        clauses = {}
        for typ, val, x, y, z in untokenize(generate_tokens(s.encode())):
            if typ == 5:
                clauses[val] = NL(typ, val, x, [])
        return clauses


    def _test(s: str) -> Results:
        g = Grammar()
        p = Parser(g)
        p.setup()
        for typ, val, x, y, z in untokenize(generate_tokens(s.encode())):
            if typ == 5:
                p.push(5, None, 0, (0,0))

# Generated at 2022-06-23 15:44:35.696385
# Unit test for constructor of class Parser
def test_Parser():
    # Does this do anything?
    Parser(Grammar())

# Generated at 2022-06-23 15:44:44.880698
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import pgen

    # Get a grammar
    g = pgen.generate_grammar("Grammar.txt")

    # Create a parser
    p = Parser(g)

    # Start parsing
    p.setup()
    # Add tokens

# Generated at 2022-06-23 15:44:49.298893
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError('message', 42, 'value', (1, 2))
    assert pe.msg == 'message'
    assert pe.type == 42
    assert pe.value == 'value'
    assert pe.context == (1, 2)

# Generated at 2022-06-23 15:44:58.529353
# Unit test for method push of class Parser
def test_Parser_push():
    # Create the grammar.
    from .grammar import Grammar
    from .token import Token
    from .token import NAME, NUMBER, ZERO, LPAR, RPAR, EOF
    from .token import INDENT, DEDENT, NEWLINE, ENDMARKER
    from .syms import sym_name, sym_or_expr, sym_symbol_expr
    from .syms import sym_atom_expr, sym_factor, sym_term, sym_or_test, sym_and_test
    from .syms import sym_not_test, sym_comparison, sym_arith_expr, sym_term
    from .syms import sym_factor, sym_atom, sym_power, sym_xor_expr, sym_and_expr

# Generated at 2022-06-23 15:45:08.397013
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, pgen

    # Generate a grammar
    pg = pgen.Grammar(grammar.grammar)
    pg.parse_grammar()
    pl1 = pg.produce_parsing_table()
    pl2 = pg.optimize_parsing_table()
    pl3 = pg.create_parsing_table()
    p = Parser(pl3)

    def test_classify(expected_ilabel: int, type: int, value: str) -> None:
        # Test method classify of class Parser
        p.setup(grammar.symbol.file_input)
        ilabel = p.classify(type, value, None)
        assert ilabel == expected_ilabel

    # Test token.NAME
    value = "and"

# Generated at 2022-06-23 15:45:15.594886
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .grammar import Grammar
    from .pgen import driver

    g = Grammar()
    p = Parser(g)
    p.setup()
    d = driver.Driver(g, p)
    d.parse_tokens(
        [
            (1, "def", (3, 0)),
            (1, "foo", (3, 4)),
            (53, "(", (3, 7)),
            (53, ")", (3, 8)),
            (58, ":", (3, 9)),
            (4, "pass", (4, 0)),
        ]
    )
    assert p.addtoken(3, "pass", (4, 4))
    tree = p.rootnode
    assert tree.type == 1
    assert tree.children[1].value == "foo"
    assert tree.children

# Generated at 2022-06-23 15:45:21.755711
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", 1, "value", "context")
    except ParseError as p:
        assert p.msg == "msg"
        assert p.type == 1
        assert p.value == "value"
        assert p.context == "context"
    else:
        assert 0, "Did not catch exception"

# Generated at 2022-06-23 15:45:32.093890
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.parse import Parser
    from blib2to3.pgen2.grammar import Grammar, pickle
    import blib2to3.pgen2.token as token

    class MyGrammar(Grammar):
        def __init__(self):
            """
            1. Adds terminal "A" to the list of known tokens
            2. Adds production "E : A" to the list of productions
            """
            super().__init__()
            self.token('A', "\x00")
            self.add_production("E : A")
            self.add_production("S : E")
            self.start = "S"
    g = MyGrammar()
    p = Parser(g)
    p.setup()

# Generated at 2022-06-23 15:45:38.757806
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)

    assert p.classify(token.NAME, "x", None) == 1

    assert p.classify(token.NUMBER, "31337", None) == 48

    assert p.classify(token.INDENT, "", None) == 4

    assert p.classify(token.DOUBLESTAR, "**", None) == 2

    assert p.classify(token.NEWLINE, "\n", None) == 0

    try:
        p.classify(token.DOUBLESTAR, "**", None)
    except ParseError as e:
        assert e.msg == "bad token"
        assert e.type == token.DOUBLESTAR
        assert e.value == "**"

# Generated at 2022-06-23 15:45:46.946732
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .grammar import Grammar

    def test(s, expect, stack=None):
        grammar = Grammar()
        if isinstance(s, str):
            s = s.replace(" ", "").replace("\n", "")
        tokens = [(type, value, (1, 1)) for type, value in s]
        p = Parser(grammar, ())
        p.setup()
        for token in tokens:
            p.addtoken(*token)
        pstack = [(dfa, state, node[0:3]) for dfa, state, node in p.stack]
        if stack is not None:
            if pstack != stack:
                raise ValueError("Unexpected stack %r (expecting %r)" % (pstack, stack))

# Generated at 2022-06-23 15:45:51.489361
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(Grammar())
    p.setup()
    p.push(1, (1, 1), 2, None)
    assert p.stack == [((1, 1), 0, (None, None, None, [])), ((1, 1), 2, (1, None, None, []))]

# Generated at 2022-06-23 15:45:54.620833
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("message", 1, "value", (1,1))
    except ParseError as e:
        pass



# Generated at 2022-06-23 15:46:03.594663
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("/home/juan/dev/sharppy/sharppy/blib2to3/Grammar.txt")
    parser = Parser(grammar=grammar)
    parser.setup()
    assert parser.stack == [(grammar.dfas[grammar.start], 0, (0, None, None, []))]
    parser.stack.clear()
    parser.setup()
    assert parser.stack == [(grammar.dfas[grammar.start], 0, (0, None, None, []))]


# Generated at 2022-06-23 15:46:06.675092
# Unit test for constructor of class ParseError
def test_ParseError():
    # Verify that ParseError can be instantiated with no arguments.
    e = ParseError("message")
    assert str(e) == "message: type=None, value=None, context=None"


# Generated at 2022-06-23 15:46:13.222203
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import tokenize
    import sys
    import io

    assert sys.version_info >= (3, 0)

    p = Parser(grammar.expr_grammar)
    p.setup()
    count = 0
    with tokenize.tokenize(io.BytesIO(b"foo").readline) as gen:
        for _ in range(4):  # tokenize.tokenize yields 4 tokens
            type, token, (srow, scol), (erow, ecol), line = next(gen)
            if p.addtoken(type, token, (srow, scol)):
                break
            if type == tokenize.NAME:
                count += 1
                assert token == "foo"
    assert count == 1


# Generated at 2022-06-23 15:46:23.616445
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import simple1grammar

    class DummyGrammar(object):
        pass

    class DummyConvert(object):
        pass

    def new_Parser(convert):
        dummy_grammar = DummyGrammar()
        dummy_grammar.dfas = {
            simple1grammar.start:
                ([[(1, 2)], [(1, 2)], [(1, 2)]],
                 {0: 51, 1: 51, 2: 51}),
            simple1grammar.NEWLINE:
                ([[(1, 2)], [(1, 2)], [(1, 2)]],
                 {0: 51, 1: 51, 2: 51}),
        }

        p = Parser(dummy_grammar, convert)
        p.setup()
        return p


# Generated at 2022-06-23 15:46:24.603030
# Unit test for method shift of class Parser
def test_Parser_shift():
    pass


# Generated at 2022-06-23 15:46:33.116779
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import tokenize
    from .grammar import Grammar

    g2 = Grammar()
    p2 = Parser(g2)
    g3 = Grammar()
    p3 = Parser(g3)

    def get_p3_stack() -> List[Tuple[DFAS, int, RawNode]]:
        return [
            (
                g3.dfas[start],
                0,
                (start, None, None, []),
            )
        ]

    # p3.setup()
    p3.setup(start=None)
    assert p3.stack == get_p3_stack()

    start = g3.symbol2number["single_input"]
    p3.setup(start)
    assert p3.stack == get_p3_stack()

    start = g3.symbol

# Generated at 2022-06-23 15:46:34.826037
# Unit test for method setup of class Parser
def test_Parser_setup():
    # No error message reported so far
    assert len(ParseError.__doc__) == 0

# Generated at 2022-06-23 15:46:38.911283
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from . import token

    g = grammar.Grammar(token.tok_name, {})
    n = (1, "foo", None, [])
    x = lam_sub(g, n)[-1][0]
    assert x == "foo"
    return x



# Generated at 2022-06-23 15:46:44.935070
# Unit test for method push of class Parser
def test_Parser_push():
    class Grammar(object):
        tokens = {token.NUMBER: 1, token.NAME: 2}
        start = "START"
        keywords = {"(": 3, ")": 3}

        labels = [
            (token.NAME, 1),
            (token.NUMBER, 1),
            (token.NAME, 2),
            (token.NAME, 3),
            (token.NAME, 4),
            (token.NAME, 5),
        ]
        dfas = {
            "START": (
                [[(1, 1)], [(2, 2), (1, 4)], [(3, 3)], [(3, 3), (4, 0)]],
                set([1, 2]),
            ),
        }

    class Context(object):
        pass

    grammar = Grammar()

# Generated at 2022-06-23 15:46:55.972342
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Inputs
    class MockGrammar:
        dfas = {
            100: ([[(None, None) for _ in range(4)] for _ in range(4)], {1: None, 2: None})}  # noqa: E501
        labels = None
        keywords = None
        tokens = None
        start = None

    def mock_convert(grammar, node):
        # print("mock_convert", node)
        return str(node)

    parser = Parser(MockGrammar(), mock_convert)
    parser.setup()
    parser.addtoken(token.TYPE_ID, token.TYPE_ID, None)
    parser.addtoken(token.NAME, "Foo", None)
    parser.addtoken(token.NAME, "Bar", None)

    # Exercise the SUT

# Generated at 2022-06-23 15:46:59.737208
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("foo", 1, "bar", (1, 0))
    except ParseError as e:
        assert e.msg == "foo"
        assert e.type == 1
        assert e.value == "bar"
        assert e.context == (1, 0)
    else:
        assert False, "did not raise"

# Generated at 2022-06-23 15:47:10.520961
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize
    from .tokenize import TokenInfo
    from itertools import chain
    from textwrap import dedent
    import sys
    import os

    # Skip the test if Python is not built with universal newlines support
    if not os.linesep:
        return

    g = grammar.grammar
    p = Parser(g)
    t = tokenize.generate_tokens
    i = iter
    s = TokenInfo(token.STRING, "foo", (1, 0), (1, 3), "\n")
    n = TokenInfo(token.NEWLINE, "\n", (1, 3), (1, 4), "\n")

    p.setup(g.symbol2number["file_input"])
    p.addtoken(token.INDENT, "", (1, 0))
   

# Generated at 2022-06-23 15:47:12.379300
# Unit test for constructor of class Parser
def test_Parser():
    # Create instance
    p = Parser(3, 4)
    del p



# Generated at 2022-06-23 15:47:16.616297
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    gr = grammar.Grammar(grammar.DEFAULT_GRAMMAR)
    p = Parser(gr)
    p.setup()

    assert p.rootnode is None
    p.shift(token.STRING, None, 0, None)

    assert p.rootnode.type == token.STRING
    assert not p.rootnode.children



# Generated at 2022-06-23 15:47:20.944539
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.grammar
    assert g.start == 256
    p = Parser(g)
    assert p.grammar is g
    assert p.convert is lam_sub


# Generated at 2022-06-23 15:47:25.395459
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("spam", 6, "foo", (1, 3))
    except ParseError as e:
        assert str(e) == (
            "spam: type=6, value='foo', context=(1, 3)"
        ), "ParseError has wrong repr"

# Generated at 2022-06-23 15:47:28.412107
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser = Parser(Grammar())
    parser.stack = [
        (None, 0, (None, None, None, [])),
        (None, 0, (None, None, None, [])),
    ]
    parser.pop()
    assert parser.stack == [(None, 0, (None, None, None, [None]))]
    parser.pop()
    assert parser.stack == []



# Generated at 2022-06-23 15:47:37.123520
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = Grammar()
    grammar.start = 258
    grammar.labels = {0: (token.NAME, "name")}
    parser = Parser(grammar)
    parser.setup()
    assert parser.classify(258, "***") == 0
    try:
        parser.classify(token.NAME, "name", 0)
    except ParseError as e:
        assert e.args[0] == "bad token"
        assert e.args[1] == token.NAME
        assert e.args[2] == "name"
        assert e.args[3] == 0
    else:
        raise AssertionError

# Generated at 2022-06-23 15:47:42.885303
# Unit test for function lam_sub
def test_lam_sub():
    tree = lam_sub(Grammar(), (1, None, None, [(2, None, None, None), (3, None, None, None)]))
    assert len(tree) == 3
    assert all(isinstance(x, Leaf) for x in tree)
    assert tree[0].value == '2' and tree[2].value == '3'


# Generated at 2022-06-23 15:47:47.732825
# Unit test for method pop of class Parser
def test_Parser_pop():
    from unittest import mock
    from blib2to3.tests.test_grammar import make_grammar
    from blib2to3.pgen2.parse import convert_node
    p = Parser(make_grammar(), convert_node)
    p.setup()
    case = mock.MagicMock()
    p.stack = [(1,2,case)]
    p.pop()
    case.assert_called_once_with(make_grammar(),case)

# Generated at 2022-06-23 15:47:49.949774
# Unit test for constructor of class Parser
def test_Parser():
    from .grammar import Grammar

    p = Parser(Grammar(version="2.1"), lam_sub)

# Generated at 2022-06-23 15:47:54.944750
# Unit test for constructor of class ParseError
def test_ParseError():
    msg = 'Error message'
    type = token.COMMENT
    value = 'Comment'
    context = Context()
    err = ParseError(msg, type, value, context)
    assert err.msg == msg
    assert err.type == type
    assert err.value == value
    assert err.context == context

# Generated at 2022-06-23 15:48:00.962596
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, driver

    g = grammar.Grammar(grammar_tokens)
    p = Parser(g)
    p.setup()
    for t in tokens:
        if p.addtoken(*t):
            break
    #assert p.rootnode is not None
    if not driver.dump_tree:
        return
    driver.dump_tree(p.rootnode)



# Generated at 2022-06-23 15:48:11.919026
# Unit test for method setup of class Parser
def test_Parser_setup():
    from .pgen2.token import classify

    class TestDriver(object):

        def __init__(self):
            self.type = token.NAME
            self.value = "y"
            self.context = Context("", 0, (0, 0))

        def next(self) -> Tuple[int, str, Context]:
            return self.type, self.value, self.context

        def classify(self, type: int, value: str) -> int:
            context = self.context
            self.type = token.NAME
            self.value = "z"
            return classify(type, value)


    from .pgen2 import (
        tokenize as tokenize_,
        driver as driver_,
    )
    from .pgen2.tokenize import generate_tokens


# Generated at 2022-06-23 15:48:19.712987
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    format = "%(type)s %(value)s %(context)s"
    def display(**kwds):
        assert len(kwds) == 3
        return format % kwds
    class FakeToken(object):
        def __init__(self, type: int, value: Text, lineno: int, offset: int):
            self.type = type
            self.value = value
            self.lineno = lineno
            self.offset = offset
        def __getitem__(self, key):
            return getattr(self, key)
        def __repr__(self):
            return display(**self.__dict__)

# Generated at 2022-06-23 15:48:22.912699
# Unit test for constructor of class ParseError
def test_ParseError():
    x = ParseError("test", 1, "foo", (2, 3))
    assert str(x) == "test: type=1, value='foo', context=(2, 3)"



# Generated at 2022-06-23 15:48:29.166829
# Unit test for method shift of class Parser
def test_Parser_shift():
    # the following input value must be defined and must be a valid token type
    token_type = token.ENDMARKER
    # the following input value must be defined and must be a valid token type
    token_type2 = token.NAME
    myParser = Parser(Grammar())
    myParser.setup()
    myParser.shift(token_type, None, 0, None)
    myParser.shift(token_type2, None, 0, None)

# Generated at 2022-06-23 15:48:38.220370
# Unit test for method push of class Parser
def test_Parser_push():
    # Parsing is a bit tricky because type numbers will differ between
    # different grammars.  The following sequence of tokens is suitable
    # for testing all grammars:
    #     NAME NAME OPEN_PAREN NAME NAME NAME NAME NAME NAME NAME NAME
    #     NAME NAME NAME NAME CLOSE_PAREN NAME NAME NAME NAME
    from . import driver, grammar

    pg = driver.load_grammar("Grammar.txt")

# Generated at 2022-06-23 15:48:39.816874
# Unit test for function lam_sub
def test_lam_sub():
    _ = 1, 2
    lam_sub(grammar=Grammar(), node=_)

# Generated at 2022-06-23 15:48:44.301870
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import token

    p = Parser(Grammar(version="3.7"))
    p.setup()
    p.addtoken(token.PLUS, "+", Context(1, 0))



# Generated at 2022-06-23 15:48:51.100607
# Unit test for constructor of class Parser
def test_Parser():
    from . import driver
    from . import parser
    from . import pygram

    g = pygram.python_grammar_no_print_statement
    p = parser.Parser(g)
    p.setup()
    for t in driver.Driver(g, "print 'Hello '"):
        p.addtoken(t.type, t.value, t.context)
    p.addtoken(token.ENDMARKER, "", p.stack[0][2][2])



# Generated at 2022-06-23 15:49:01.606959
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest
    import sys
    import blib2to3
    import blib2to3.pgen2.grammar
    import blib2to3.pgen2.token
    import blib2to3.pgen2.parse
    import blib2to3.pgen2.convert
    import blib2to3.pygram
    import blib2to3.pygram.python_symbols
    import blib2to3.pytree

    from . import token

    from .driver import Driver
    from .parse import ParseError
    from .convert import pytree_convert
    from .pyparse import PyTreeVisitor

    # Monkey-patch PyTreeVisitor to remove the default
    # implementation of skip_children to make sure that
    # pytree_convert uses the skip_children method

# Generated at 2022-06-23 15:49:04.800910
# Unit test for constructor of class Parser
def test_Parser():
    g = Grammar([], {}, {}, {}, start="toplevel")
    p = Parser(g)
    assert p.grammar == g
    assert p.convert == lam_sub

# Generated at 2022-06-23 15:49:07.952815
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    g = grammar.Grammar()
    lam_sub(g, ("simple_stmt", None, None, [("small_stmt", None, None, [])]))



# Generated at 2022-06-23 15:49:13.236741
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser = Parser(Grammar())
    parser.shift(1, "a", 2, 3)
    s = str(parser.stack)
    assert s == "[(([(1, 0)], {1: 0}), 2, (None, None, None, []))]"


# Generated at 2022-06-23 15:49:13.991052
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("msg", 1, "value", "context")

# Generated at 2022-06-23 15:49:17.924224
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar
    from .tokenize import generate_tokens
    from .parse import Parser

    gr = grammar.Grammar()
    gr.parse_grammar(generate_tokens(open("Grammar/Grammar", encoding="ISO-8859-1")))
    pa = Parser(gr)

    assert pa.grammar == gr
    assert pa.convert is gr.convert
    assert pa.stack == []

    pa = Parser(gr, lam_sub)

    assert pa.grammar == gr
    assert pa.convert is lam_sub
    assert pa.stack == []



# Generated at 2022-06-23 15:49:22.290710
# Unit test for method setup of class Parser
def test_Parser_setup():
    # pylint: disable=unused-variable,unused-argument
    from ..pgen2 import driver

    grammar = driver.load_grammar("blib2to3/Grammar.txt")
    parser = Parser(grammar)



# Generated at 2022-06-23 15:49:31.552316
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver
    from . import parse

    gr = driver.load_grammar("Grammar.txt")
    pg = parse.Parser(gr)
    pg.setup()

    pg.push(8, ([[(1, 2), (1, 5)], [(8, 1), (9, 1)]], {1: 3, 2: 3}), 0, None)
    assert pg.stack == [(
        ([[(1, 2), (1, 5)], [(8, 1), (9, 1)]], {1: 3, 2: 3}),
        0,
        (8, None, None, [])
    )]

# Generated at 2022-06-23 15:49:37.461988
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test case for constructor of class ParseError"""

    pe = ParseError("testmessage", token.PLUS, "testvalue", None)
    assert pe.msg == "testmessage"
    assert pe.type == token.PLUS
    assert pe.value == "testvalue"
    assert pe.context is None


if __name__ == "__main__":
    test_ParseError()

# Generated at 2022-06-23 15:49:49.401733
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import blib2to3.pgen2
    import blib2to3.pygram

    grammar = blib2to3.pgen2.parse_grammar(
        blib2to3.pygram.python_grammar_no_print_statement
    )
    blib2to3.pgen2.driver.load_grammar(grammar)
    p = Parser(grammar)
    p.setup()
    tok = blib2to3.pgen2.driver.generate_tokens(sys.stdin.readline)
    for token in tok:
        p.addtoken(token.type, token.string, token.context)
    assert p.rootnode is not None
    print(p.rootnode.leaves())

# Generated at 2022-06-23 15:50:00.061751
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser = Parser(None)
    parser.stack: List[Tuple[DFAS, int, RawNode]] = [
        None,
        None,
        (None, None, (1, None, None, None)),
    ]
    parser.rootnode = None
    parser.pop()
    assert parser.rootnode is None
    assert len(parser.stack) == 1
    assert parser.stack[0] is None
    parser.stack: List[Tuple[DFAS, int, RawNode]] = [
        None,
        None,
        (None, None, (1, None, None, [])),
    ]
    parser.pop()
    assert parser.rootnode is not None
    assert len(parser.stack) == 0

# Generated at 2022-06-23 15:50:07.703169
# Unit test for method push of class Parser

# Generated at 2022-06-23 15:50:19.764526
# Unit test for method shift of class Parser
def test_Parser_shift():
    def testShift(inputTokens):
        p = Parser(Grammar(), None)
        p.setup(1)
        for token in inputTokens:
            p.shift(Grammar.tokens['NAME'], token, 0, Context())
        return p.stack
    assert testShift([]) == [(Grammar.dfas[1], 0, (1, None, None, []))]
    assert testShift(['foo']) == [(Grammar.dfas[1], 0, (1, None, None, [(3, 'foo', None, None)]))]
    assert testShift(['foo', 'bar']) == [(Grammar.dfas[1], 0, (1, None, None, [(3, 'foo', None, None), (3, 'bar', None, None)]))]


# Generated at 2022-06-23 15:50:28.080320
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .driver import Driver
    import sys

    driver = Driver(grammar_file="Python.asdl", debug=0)
    driver.prepare()
    parser = Parser(driver.grammar)
    parser.setup()
    print(parser.classify(driver.symbol2number['SEMI'], None, None))
    print(parser.classify(driver.symbol2number['SEMI'], None, None))
    print(parser.classify(token.INDENT, '', None))
    print(parser.classify(token.INDENT, '', None))
    print(parser.classify(token.INDENT, '', None))
    print(parser.classify(token.INDENT, '', None))
    print(parser.classify(token.INDENT, '', None))

# Generated at 2022-06-23 15:50:38.462047
# Unit test for method pop of class Parser
def test_Parser_pop():
    class TestGrammar(object):
        def __init__(self):
            self.dfas = {1:([{1: [(0, 1)]}],[{1}])}
            self.labels = {0: (1, None)}
        start = 1
    class TestGrammarWithConverter(TestGrammar):
        def convert(self, grammar, node):
            return TestNode(node)
    class TestNode(object):
        def __init__(self, node):
            self.node = node
    g = TestGrammar()
    g_with_converter = TestGrammarWithConverter()
    p = Parser(g)
    p.setup()
    p_with_converter = Parser(g, g.convert)