

# Generated at 2022-06-23 15:40:41.306419
# Unit test for method setup of class Parser
def test_Parser_setup():
    """
    >>> from . import grammar
    >>> g = grammar.Grammar()
    >>> p = Parser(g, None)
    >>> p.setup()
    >>> p.stack
    [(([(1, 0), (2, 0)], None), 1, (0, None, None, []))]
    >>> p.setup(1)
    >>> p.stack
    [(([(1, 0), (2, 0)], None), 1, (1, None, None, []))]
    >>> p.rootnode
    >>> p.stack
    [(([(1, 0), (2, 0)], None), 1, (1, None, None, []))]
    """



# Generated at 2022-06-23 15:40:47.590124
# Unit test for function lam_sub
def test_lam_sub():
    raw = (4, None, None, [
        (1, "abc", None, None),
        (2, "def", None, None),
    ])
    node = lam_sub(None, raw)
    assert node.type == 4
    assert node.children == [
        Leaf(1, "abc"),
        Leaf(2, "def"),
    ]
    assert node.children[0].value == "abc"
    assert node.children[1].value == "def"

# Generated at 2022-06-23 15:40:58.719087
# Unit test for method push of class Parser
def test_Parser_push():
    from . import pygram
    from .driver import Driver
    driver = Driver(pygram, convert=lam_sub)
    p = Parser(driver.grammar)
    p.setup()
    assert p.stack == [(p.grammar.dfas[1], 0, (1, None, None, []))]
    p.push(2, p.grammar.dfas[2], 0, Context(1, 0, 1))
    assert p.stack == [
        (p.grammar.dfas[1], 0, (1, None, None, [])),
        (p.grammar.dfas[2], 0, (2, None, Context(1, 0, 1), [])),
    ]
    p.push(3, p.grammar.dfas[3], 0, Context(2, 0, 2))

# Generated at 2022-06-23 15:41:00.689677
# Unit test for method classify of class Parser
def test_Parser_classify():
    """test_Parser_classify()
    """
    #
    # Currently this is a test stub.
    #
    pass

# Generated at 2022-06-23 15:41:07.013736
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.grammar import Grammar

    def test(g, t, v, expect):
        p = Parser(g)
        found = p.classify(t, v, None)
        assert found == expect, (found, expect, t, v)

    g = Grammar()
    g.symbol2number["foo"] = 10
    g.labels[10] = (255, "foo")
    g.tokens = {token.NUMBER: 31, token.STRING: 32}
    g.keywords = {"pass": 41, "and": 42, "elif": 43, "global": 44}
    test(g, token.NAME, "and", 42)
    test(g, token.NAME, "elif", 43)

# Generated at 2022-06-23 15:41:14.111541
# Unit test for function lam_sub
def test_lam_sub():
    import sys
    import io

    def _test_lam_sub(s: str, expected: str, grammar: Grammar) -> None:
        from . import driver

        result = _parse_string(s, grammar)
        assert result.totext(error=0, indent=0) == expected

    def _parse_string(s: str, grammar: Grammar) -> NL:
        f = io.StringIO(s)
        d = driver.Driver(grammar, convert=lam_sub, logger=sys.stdout)
        return d.parse_file(f)

    if __name__ == '__main__':
        # Generate a new grammar instance every time since this is just a test
        import os
        import tempfile
        from io import StringIO
        from blib2to3.pgen2.generate import generate

# Generated at 2022-06-23 15:41:23.962974
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar, tokenize

    grammar = grammar.Grammar('Grammar/Grammar')
    parser = Parser(grammar)
    parser.setup()
    stack = [
        (
            (
                [
                    [(1, 0), (2, 1), (0, 0)],
                    [(0, 0)],
                    [(0, 0)],
                ],
                {0: 1},
            ),
            0,
            (grammar.START, None, None, []),
        )
    ]
    assert stack == parser.stack
    assert parser.rootnode is None



# Generated at 2022-06-23 15:41:33.116512
# Unit test for method push of class Parser
def test_Parser_push():
    from .pgen2 import token

    class TestGrammar:
        def __init__(self):
            self.type = token.NT_OFFSET + 1  # An integer pointing to a type
            self.dfas = {}
        start = self.type
        dfas = {
            self.type: (
                (
                    (
                        (self.type + 1, 0),
                        (self.type + 1, 1),
                    ),
                    {self.type: 0, self.type + 1: 1},
                ),
                {self.type: 1},
            )
        }
        labels = [
            (token.SPACE, self.type + 1),
            (self.type, self.type + 2),
            (token.NEWLINE, self.type + 3),
        ]  # Index is label name; value is

# Generated at 2022-06-23 15:41:37.410188
# Unit test for constructor of class Parser
def test_Parser():
    from . import driver

    d = driver.Driver()
    d.grammar.token_map
    d.grammar.labels
    d.grammar.keywords
    d.grammar.dfas
    p = d.parser
    #driver.tokenize_file(filename)


# Generated at 2022-06-23 15:41:43.578096
# Unit test for constructor of class Parser
def test_Parser():
    g = Grammar()
    p = Parser(g)
    assert p.stack is None
    assert p.rootnode is None
    assert p.convert is None
    try:
        p.addtoken(1, None, None)
        raise AssertionError
    except AttributeError:
        pass

# Generated at 2022-06-23 15:41:45.679731
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("msg", 1, "value", (2, 3))
    assert type(e) == ParseError
    assert str(e) == "msg: type=1, value='value', context=(2, 3)"
    assert e.msg == "msg"
    assert e.type == 1
    assert e.value == "value"
    assert e.context == (2, 3)

# Generated at 2022-06-23 15:41:54.091810
# Unit test for method classify of class Parser
def test_Parser_classify():
    def check(type, value, context, ilabel):
        assert ilabel == p.classify(type, value, context)

    def check2(type1, type2, label):
        assert label == p.grammar.keywords.get(type1)
        assert label == p.grammar.tokens.get(type2)

    check2(token.NAME, token.NAME, label=0)
    p = Parser(Grammar())
    check(token.NAME, u"a", Context(1, 2), label=1)
    check(token.NUMBER, u"0", Context(2, 3), label=2)

# Generated at 2022-06-23 15:41:55.095249
# Unit test for constructor of class Parser
def test_Parser():
    pass


# Generated at 2022-06-23 15:42:01.854204
# Unit test for method shift of class Parser
def test_Parser_shift():
    d = {1: {0: [(0, 1)]}, 2: {0: [(0, 2)]}}
    dfa1 = (d[1], {0: 1})
    dfa2 = (d[2], {0: 2})
    type = 1
    value = "a"
    context = "context"
    p = Parser([], [])
    p.stack.append((dfa1, 0, (type, value, context, [])))
    p.shift(type, value, 1, context)
    assert p.stack == [(dfa1, 1, (type, value, context, []))]
    p.stack.append((dfa2, 0, (type, value, context, [])))
    p.shift(type, value, 2, context)

# Generated at 2022-06-23 15:42:13.010348
# Unit test for method classify of class Parser
def test_Parser_classify():
    import io
    import sys
    import tokenize
    from . import driver

    # Make sure we have an encoding.  Default is utf-8.
    if not sys.stdin.encoding:
        import locale
        sys.stdin.encoding = locale.getpreferredencoding()

    parser = driver.Driver(grammar, convert, None)
    python_tokens = tokenize.tokenize(io.BytesIO(b"class classclass: pass").readline)

    parser.setup()
    for type, value, context in python_tokens:
        # TODO: Move this line to where it actually belongs.
        if type == token.NAME and value in ['class', 'def', 'if', 'elif', 'else']:
            type = token.INDENT

# Generated at 2022-06-23 15:42:16.757167
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("blabla", None, None, None)
    except ParseError as e:
        assert str(e) == "blabla: type=None, value=None, context=None"
    except:  # noqa: E722
        raise AssertionError

# Generated at 2022-06-23 15:42:18.752489
# Unit test for function lam_sub
def test_lam_sub():
    n = ("Hello", None, None, ["world"])
    assert lam_sub(None, n)[1] == ["world"]

# Generated at 2022-06-23 15:42:23.246843
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("message", token.NAME, "name", (1, 0))
    assert e.msg == "message"
    assert e.type == token.NAME
    assert e.value == "name"
    assert e.context == (1, 0)

# Generated at 2022-06-23 15:42:27.400485
# Unit test for constructor of class Parser
def test_Parser():
    # Just test that we can instantiate the class with a dummy grammar
    p = Parser(Grammar(b"", {}, {}, {}, {}, {}, {}, {}))
    p.setup()
    p.addtoken(0, "foo", (1, 2))

# Generated at 2022-06-23 15:42:33.159554
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.pgen import Driver

    p = Parser(Grammar())
    p.setup()
    p.addtoken(None, None, None)
    assert p.stack == [(p.grammar.dfas[p.grammar.start], 0, (None, None, None, []))]



# Generated at 2022-06-23 15:42:41.957087
# Unit test for method push of class Parser
def test_Parser_push():
    def test_converter(grammar: Grammar, node: RawNode) -> NL:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    pgm = Grammar()
    pgm.start = 256  # symbol
    pgm.dfas = {
        256: ([[(257, 0), (5, 1)], [(0, 2)]], {257: 0, 5: 1}),
        257: ([[(258, 3)], [(0, 4)]], {258: 3}),
        258: ([[(260, 1)], [(4, 2)], [(3, 3)], [(0, 4)]], {260: 1, 4: 2, 3: 3}),
    }

# Generated at 2022-06-23 15:42:51.670970
# Unit test for constructor of class Parser
def test_Parser():
    "Unit test for constructor of class Parser."
    import _testcapi
    import sys
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_init(self):
            # Just make sure that the module object is in place and that
            # we can access its (empty) symbol and token tables.
            self.assert_(sys.modules.get("_testcapi"))
            self.assert_(hasattr(_testcapi, "syms"))
            self.assert_(hasattr(_testcapi, "tokens"))
            self.assertEqual(len(_testcapi.syms), 0)
            self.assertEqual(len(_testcapi.tokens), 0)

# Generated at 2022-06-23 15:43:03.364807
# Unit test for method push of class Parser
def test_Parser_push():
    import sys
    import blib2to3.pgen2.grammar as grammar
    from .driver import Driver
    from . import token

    # The driver produces a (type, value, context, children) tuples.
    # The grammar is used to convert these tuples to an abstract
    # syntax tree.
    g = grammar.Grammar('Grammar/Grammar')
    p = Parser(g)
    p.setup(g.start)

    # The driver produces a (type, value, context, children) tuple.
    # The grammar is used to convert these tuples to an abstract
    # syntax tree.
    p = Parser(g)
    p.setup(g.start)

    d = Driver(g, convert=g.convert)
    d.setup()
    root = d.parse_tok

# Generated at 2022-06-23 15:43:05.587684
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = Grammar()
    parser = Parser(grammar)
    parser.push(grammar.dfas[0])


# Generated at 2022-06-23 15:43:09.898819
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    p = Parser(grammar.grammar)
    p.setup()
    node = (grammar.syms["test"], None, None, [(1, "2"), (2, "3")])
    assert lam_sub(p.grammar, node) == [[[1, "2"], [2, "3"]]]

# Generated at 2022-06-23 15:43:19.566311
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(Grammar(), None)
    p.push(1,([(5,5)], {5:5}), 0, Context(1,1))
    p.push(1,([(5,5)], {5:5}), 0, Context(1,1))
    assert len(p.stack) == 2
    assert p.stack[1] == ([(5,5)], 0, (1, None, Context(1,1), []))
    assert p.stack[0] == ([(5,5)], 0, (1, None, Context(1,1), []))


# Generated at 2022-06-23 15:43:24.828427
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import pprint
    import io
    import blib2to3.pgen2.tokenize

    class MockGrammar:
        start = "file_input"
        dfas = {
            "file_input": (
                [
                    # State 0
                    [
                        (1, 1),
                        (2, 2),
                    ],
                    # State 1
                    [(1, 1), (2, 2)],
                    # State 2
                    [(2, 3), (0, 2)],
                    # State 3
                    [(3, 4), (4, 5)],
                    # State 4
                    [(4, 5)],
                    # State 5
                    [(0, 5)],
                ],
                {}
            )
        }

# Generated at 2022-06-23 15:43:33.932762
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Unit test for method addtoken of class Parser"""

    import unittest
    import grammar
    import tokenize

    class ParserTest(unittest.TestCase):
        def _test_addtoken(self, src: Text) -> None:
            g = grammar.Grammar()
            p = Parser(g)
            f = tokenize.StringIO(src)
            p.setup()
            for tok in iter(f.readline, ""):
                type, value, _, _, _ = tokenize.generate_tokens(lambda: tok).__next__()
                p.addtoken(type, value, (1, 0))

    unittest.main(ParserTest("_test_addtoken"), exit=False)

# Generated at 2022-06-23 15:43:37.546513
# Unit test for method classify of class Parser
def test_Parser_classify():
    p = Parser(Grammar())

    assert p.classify(token.NAME, "test", context=None) == 0

# Generated at 2022-06-23 15:43:47.941071
# Unit test for method pop of class Parser
def test_Parser_pop():

    class MyParser(Parser):
        def pop(self):
            super().pop()
            if self.stack:
                dfa, state, node = self.stack[-1]
                assert node[-1] is not None
                node[-1].append(self.rootnode)

    grammar = Grammar()

    def convert(grammar, node):
        return None

    p = MyParser(grammar, convert)

    p.setup()
    p.pop()
    assert p.stack == []
    assert p.rootnode == []

    def convert2(grammar, node):
        return [node]

    p = MyParser(grammar, convert2)

    p.setup()
    p.pop()
    assert p.stack == []
    assert p.rootnode == [[0, None, None, None]]

   

# Generated at 2022-06-23 15:43:58.600112
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class Node(object):
        def __init__(self):
            self.children = []


# Generated at 2022-06-23 15:44:09.748142
# Unit test for constructor of class Parser
def test_Parser():
    parse = Parser(Grammar(open("/home/vilson/PP/blib2to3/pgen2/Grammar.txt", "r")))
    parse.setup(start=57)

# Generated at 2022-06-23 15:44:14.140636
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.Grammar(grammar.gram)
    p = Parser(g)
    p.setup()
    return p

# Generated at 2022-06-23 15:44:22.938769
# Unit test for method pop of class Parser
def test_Parser_pop():

    def convert(grammar, node):
        if node[0] == type_:
            return node[1]
        else:
            return None

    class MockGrammar:
        pass

    grammar = MockGrammar()
    grammar.dfas = {type_: ([[(0, 0)]], {0: 0})}
    parser = Parser(grammar, convert)
    parser.setup()
    parser.push(type_, grammar.dfas[type_], 0, None)
    assert len(parser.stack) == 2
    assert parser.stack[0] == (
        grammar.dfas[type_],
        0,
        ([],),
    )
    assert parser.stack[1] == (
        grammar.dfas[type_],
        0,
        ([],),
    )
    parser

# Generated at 2022-06-23 15:44:33.495797
# Unit test for method shift of class Parser
def test_Parser_shift():
    import sys
    import os
    import StringIO
    import blib2to3.pgen2.driver

    if sys.version_info[0] < 3 or sys.version_info[1] < 3:
        return
    else:
        from blib2to3.pygram import python_symbols
        from blib2to3.pgen2.pgen import Grammar

        from blib2to3.pgen2.tokenize import generate_tokens, tokenize, TokenError


        def main(args: Sequence[Any]) -> None:
            # Parse a Python grammar file and write it out to a new file
            file = args[1]
            g = Grammar()
            g.parse_grammar(file)
            p = Parser(g)
            p.setup()

# Generated at 2022-06-23 15:44:36.137352
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver

    driver.main("blib2to3.pgen2.parser", "none", "shift")



# Generated at 2022-06-23 15:44:42.671227
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("testing", 123, "somevalue", ())
    assert err.msg == "testing"
    assert err.type == 123
    assert err.value == "somevalue"
    assert err.context == ()
    try:
        raise ParseError("testing", 123, "somevalue", ())
    except ParseError as err:
        assert err.msg == "testing"
        assert err.type == 123
        assert err.value == "somevalue"
        assert err.context == ()
    else:
        assert False

# Generated at 2022-06-23 15:44:47.213781
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2 import token
    g = Grammar(Token=token)
    lam_sub(g, (1, "a", None, [(2, "b", None, None)]) )


# Generated at 2022-06-23 15:44:57.705016
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class TestToken(object):
        # class TestToken is only necessary until we have used_names in pgen2 to test
        def __init__(self, type, value):
            self.type = type
            self.value = value
    class TestContext(object):
        def __init__(self, line_number, offset):
            self.line_number = line_number
            self.offset = offset

    # Test some valid Python programs
    from pgen2 import driver
    from blib2to3.pgen2 import parse

# Generated at 2022-06-23 15:45:07.883811
# Unit test for method push of class Parser
def test_Parser_push():
    import os
    import sys
    import unittest

    from . import grammar
    from . import token

    class ParserTestCase(unittest.TestCase):
        def setUp(self) -> None:
            name = os.path.join("Grammar", "Grammar")
            self.grammar = grammar.grammar(name)
            self.start = self.grammar.start
            self.tokens = token.tok_name
            self.dfas = self.grammar.dfas

        def test_push(self) -> None:
            p = Parser(self.grammar)
            p.setup(self.start)
            for i in range(10):
                p.push(i, self.dfas[i], 0, None)

# Generated at 2022-06-23 15:45:14.017341
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from .driver import parse_string

    t = parse_string("def f(x): print x")
    p = Parser(driver.grammar)
    p.setup()
    for ttype, value, context in t:
        p.addtoken(ttype, value, context)
    root = p.rootnode
    assert root is not None
    assert root[0] == symbol.file_input
    assert root[1][0] == symbol.simple_stmt
    assert root[1][1][0] == symbol.small_stmt
    assert root[1][1][1][0] == symbol.expr_stmt
    assert root[1][1][1][1][0] == symbol.testlist
    assert root[1][1][1][1][1][0] == symbol.test
   

# Generated at 2022-06-23 15:45:20.682386
# Unit test for constructor of class ParseError
def test_ParseError():
    # This is a very simple test, to ensure the message contains all relevant
    # information and has the right type.
    pe = ParseError("test", None, None, None)
    assert isinstance(pe.msg, str)
    assert pe.msg == "test"
    assert pe.type is None
    assert pe.value is None
    assert pe.context is None

# Generated at 2022-06-23 15:45:31.320623
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2 import tokenize

    def check_classify(grammar, tok_type, tok_string, expected_label):
        unclassified_tokens = [(tok_type, tok_string)]
        p = Parser(grammar)
        p.setup()
        for t in unclassified_tokens:
            if p.addtoken(*t):
                break

        def classify(tokens):
            for t in tokens:
                yield p.classify(*t)

        assert list(classify(tokenize.untokenize(unclassified_tokens))) == [
            expected_label
        ]

    from blib2to3.pgen2 import grammar

    assert grammar.grammar is not None  # A grammar object should be initialized

    # Sample invocation
    check_

# Generated at 2022-06-23 15:45:37.564792
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Construct a dummy grammar
    g = Grammar(start=2, labels=[[1, 'NUMBER'], [2, 'NAME']], tokens={1: 1, 3: 2}, keywords={})
    p = Parser(g)
    # Test classify on a "normal" token
    p.addtoken(1, '123', None)
    # Test classify on a token with a special name
    p.addtoken(3, 'def', None)
    # Test classify on a token with an unknown name
    p.addtoken(3, 'xyz', None)

# Generated at 2022-06-23 15:45:43.322879
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar()
    leaf = Leaf(type=1, value="a", context=None)
    tree = Node(type=2, children=[leaf], context=None)
    treedict = {2: tree}
    node: RawNode = (2, None, None, [leaf])
    assert lam_sub(grammar, node) == tree



# Generated at 2022-06-23 15:45:55.235214
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import imp, unittest.mock

    def convert(a: Any, b: Any, c: Any) -> Any: pass

    p = Parser(imp.new_module("frob"), convert)

    # check that addtoken raises ParseError when stack is empty

# Generated at 2022-06-23 15:46:05.415686
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .grammar import Grammar
    from .token import TokenInfo

    # yapps grammar
    class ws_grammar:
        def ws(self, input):
            ws, start_pos, end_pos = self._parse(input, 0)
            return ws

        def _scan_regex(self, regex, input, pos):
            match = regex.match(input, pos)
            if match is None:
                raise ParseError
            return match.group(), match.end()

        def _parse(self, input, pos):
            # ws = wschar*,
            node = None
            children = []
            while True:
                try:
                    child, pos = self.wschar(input, pos)
                    children.append(child)
                except ParseError:
                    break
            return node,

# Generated at 2022-06-23 15:46:11.240699
# Unit test for constructor of class ParseError
def test_ParseError():
    msg = "test message"
    type = token.PLUS  # type: ignore
    value = "+"
    context = Context(None, 0, 0)
    exc = ParseError(msg, type, value, context)
    assert exc.msg == msg
    assert exc.type == type
    assert exc.value == value
    assert exc.context is context

# Generated at 2022-06-23 15:46:20.806147
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import tokenize, untokenize
    from test.support import (
        captured_stdout,
        captured_stderr,
        check_syntax_error,
        test_grammar,
    )

    # Test expected keywords
    for kw in {'True', 'False', 'None'}:
        check_syntax_error(
            untokenize(
                '@' # noqa
                + kw
            ),
            'unexpected token',
            lineno=1,
            exact_match=False,
        )

    # Test expected keywords

# Generated at 2022-06-23 15:46:30.979229
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2 import parse
    r = parse(textwrap.dedent("""\
      foo: 'foo'
      bar: 'bar'
      baz: 'baz'
      qux: foo bar baz
      """))
    assert tuple(t.type for t in r.tokens) == (1, 2, 3)
    assert tuple((x, tuple(y.type for y in x[-1])) for x in r.symbols.values()) == (
        (1, (), 'foo', 4),
        (2, (), 'bar', 4),
        (3, (), 'baz', 4),
        (4, (1, 2, 3), 'qux', 0),
    )

# Generated at 2022-06-23 15:46:34.730256
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.grammar
    p = Parser(g, lam_sub)
    p.setup()
    p.addtoken(token.NUMBER, '1', (1, 1))
    assert p.rootnode is not None

# Generated at 2022-06-23 15:46:41.691866
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import symbol

    def _main():
        import sys
        import tokenize

        g = grammar.Grammar(sys.argv[1])
        p = Parser(g)
        p.setup(symbol.file_input)
        for type, token, start, end, line in tokenize.generate_tokens(sys.stdin.readline):
            context = end[0], end[1] - len(token)
            print(p.classify(type, token, context))
            p.addtoken(type, token, context)

    _main()

# Generated at 2022-06-23 15:46:43.871120
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar())
    p.setup()

# Generated at 2022-06-23 15:46:51.132813
# Unit test for method shift of class Parser
def test_Parser_shift():
    import pprint, tempfile
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.pgen as pgen
    import blib2to3.pgen2.driver as driver
    g = grammar.Grammar(grammar.DEFAULT_GRAMMAR)
    p = pgen.Pgen()
    p.generate_grammar(g)
    filename = tempfile.mktemp()
    driver.write_grammar_file(g, filename)
    del g
    g = driver.load_grammar(filename)
    del pgen, driver
    p = Parser(g)
    # Parse the smallest possible Python file
    p.setup()
    p.addtoken(token.ENDMARKER, '', (1,0))
    stree

# Generated at 2022-06-23 15:46:53.598906
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("No way", 1, "*", None)
    assert str(e) == "No way: type=1, value='*', context=None"

# Generated at 2022-06-23 15:46:59.667115
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver

    # Create a tokenizer
    d = driver.Driver(convert=None)
    # Create a parser
    p = Parser(d.grammar, convert=None)
    # Shift a token
    p.shift(token.NAME, "name", 1, (1, 2))
    # Check the stack
    assert p.stack == [(([[(0, 1)], []], {}), 1, (1, "name", (1, 2), []))]

# Generated at 2022-06-23 15:47:06.458020
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", 1, "value", (1, 1))
    except ParseError as err:
        assert str(err) == "msg: type=1, value='value', context=(1, 1)"
        assert err.msg == "msg"
        assert err.type == 1
        assert err.value == "value"
        assert err.context == (1, 1)
    else:
        raise AssertionError("expected exception")

# Generated at 2022-06-23 15:47:13.683155
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, 'a', (1, 0))
    p.addtoken(token.NEWLINE, '\n', (1, 1))
    # p.addtoken(token.NAME, 'a', (1, 2))
    # p.addtoken(token.NEWLINE, '\n', (1, 3))
    # p.addtoken(token.ENDMARKER, '', (1, 4))


# Generated at 2022-06-23 15:47:25.345802
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from .token import NUMBER

    g = grammar.grammar
    g.add_rule("lam_stmt", "lam_expr", None)
    g.add_rule("lam_expr", [NUMBER], None)
    lam_stmt = g.number2symbol["lam_stmt"]
    lam_expr = g.number2symbol["lam_expr"]
    lam_expr_rule = g.symbol2number[lam_expr]
    lam_stmt_rule = g.symbol2number[lam_stmt]

    input = [(lam_stmt_rule, None, None, [(lam_expr, "1", None, None)])]
    output = lam_sub(g, input[0])
    assert output.type == lam_stmt

# Generated at 2022-06-23 15:47:28.066504
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    p = Parser(grammar.grammar)
    p.classify(token.NAME, "while", Context(None, 0))
    assert p.used_names == {"while"}

# Generated at 2022-06-23 15:47:38.496089
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar(
        """
        expr: x=expr op=("+"|"-") y=expr  {[$x, $op, $y]}
        """
    )
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(grammar.tokens["NUMBER"], "42", None)
    parser.addtoken(grammar.tokens["PLUS"], None, None)
    parser.addtoken(grammar.tokens["NUMBER"], "49", None)
    parser.addtoken(token.ENDMARKER, None, None)
    tree = parser.rootnode
    assert len(tree) == 3
    assert len(tree[0]) == 1 and tree[0][0].value == "42"
    assert tree[1].value == "+"
    assert len

# Generated at 2022-06-23 15:47:49.405364
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pickle
    import pgen2.grammar as grammar
    import pgen2.token as token

    print("loading grammar and pickles")
    g = grammar.Grammar()
    with open("Grammar/Grammar.p") as f:
        g.load_pgen(f)
    with open("grammar_pickle", "rb") as f:
        p = pickle.load(f)

    print("creating Parser")
    p = Parser(g)
    p.setup()

    print("parsing pickle tokens")
    for t in pgen_tokens:
        print(f"t[0] = {t[0]}, t[1] = {t[1]}")
        p.addtoken(t[0], t[1], (0, 0))

   

# Generated at 2022-06-23 15:47:56.585513
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver

    import sys

    fname = sys.argv[1]
    if not fname:
        fname = "driver.py"

    with open(fname) as f:
        contents = f.read()

    grammar = driver.parse_grammar(driver.grammar)
    p = Parser(grammar)
    p.setup()
    t = driver.tokenize(fname, contents)
    try:
        while True:
            type, value, context = t.next()
            if p.addtoken(type, value, context):
                break
    except ParseError as e:
        print(type(e), e)
        print(e.msg)
        print(e.context)
        print(e.value)
        print(e.type)

# Generated at 2022-06-23 15:48:08.499454
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from . import token

    def test(concrete):
        p = Parser(grammar, lam_sub)
        p.setup()
        for t in concrete:
            p.addtoken(*t)
        assert p.rootnode == concrete[0][-1]

    # XXX Need tests for left- or right-recursive rules!

    def k(t: int, v: Text = "", c: Union[int, Tuple[int, int]] = None) -> RawNode:
        if c is None:
            c = (t - token.LAST_TOKEN, 0)
        return (t, v, c, [])


# Generated at 2022-06-23 15:48:11.729210
# Unit test for function lam_sub
def test_lam_sub():
    n = lam_sub(None, (1, None, None, [2, 3]))
    assert n.type == 1
    assert n.children == [2, 3]
    assert n.context == None



# Generated at 2022-06-23 15:48:14.488655
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from . import token

    g = grammar.Grammar(token.tok_name)
    lam_sub(g, (1, None, None, [3, 4, 5]))

# Generated at 2022-06-23 15:48:26.593396
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(Grammar())
    with pytest.raises(AssertionError):
        p.push(0, [], 0, Context(0, 0))
    with pytest.raises(AssertionError):
        p.push(1, ((), {}), 0, Context(0, 0))
    with pytest.raises(AssertionError):
        p.push(1, ([[(0, 0)], []], {}), 0, Context(0, 0))
    with pytest.raises(AssertionError):
        p.push(1, ([[(0, 0)], []], {0: 0}), 0, Context(0, 0))
    p.push(1, ([[(0, 0)], []], {0: 1}), 0, Context(0, 0))

# Generated at 2022-06-23 15:48:33.699266
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2 import driver

    g = driver.load_grammar("Grammar.txt")
    p = Parser(g)
    p.setup()
    p.addtoken(1, "a", (0, "foo"))
    p.addtoken(2, "b", (0, "foo"))
    p.addtoken(3, "c", (0, "foo"))
    p.addtoken(4, "d", (0, "foo"))



# Generated at 2022-06-23 15:48:39.893522
# Unit test for function lam_sub
def test_lam_sub():
    from .pgen2 import driver
    from .pgen2 import token
    # Load grammar
    g = driver.load_grammar("Grammar/Grammar")
    # Create a token
    t = (token.NAME, "foo", (1, 0))
    # Create a node and convert it
    n = (1, None, None, [t])
    node = lam_sub(g, n)
    # Check results
    assert node.type == 1
    assert node.children == [t]
    assert node.value is None



# Generated at 2022-06-23 15:48:49.314368
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = Grammar("parse")
    p = Parser(grammar)
    p.setup()
    def run(tokens: Sequence[Tuple[int, Text, int]]) -> None:
        for type, value, lineno in tokens:
            p.addtoken(type, value, (lineno, 0))
    run([(token.NAME, "foo", 1), (token.EQUAL, "=", 1), (token.NAME, "bar", 1)])
    assert p.rootnode[0] == "file_input", p.rootnode[0]


# Generated at 2022-06-23 15:48:54.931275
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", 1, "value", "context")
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == 1
        assert e.value == "value"
        assert e.context == "context"
    else:
        raise AssertionError("did not raise")

# Generated at 2022-06-23 15:49:04.839274
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar()
    p = Parser(grammar)

    p.stack = [(0, 0, (1, None, 1, [])), (1, 2, (3, None, 2, []))]

    p.pop()

    assert p.stack == [(0, 0, (1, None, 1, [])), (1, 2, (3, None, 2, []))]

    grammar.labels = {0: (0, 0), 1: (0, 1), 2: (1, 1)}
    grammar.dfas = {1: ([[(0, 0)], [(2, 3), (-1, 0)], [(2, 3), (-1, 1)], [(1, 2)]], 6),
    3: ([[(0, 0)], [(0, 1)], [(1, 2)]], 3)}



# Generated at 2022-06-23 15:49:12.537999
# Unit test for method setup of class Parser
def test_Parser_setup():
    class Parser:
        def __init__(self, grammar: Grammar, convert: Optional[Convert] = None) -> None:
            self.grammar = grammar
            self.convert = convert or lam_sub

        def setup(self, start: Optional[int] = None) -> None:
            if start is None:
                start = self.grammar.start
            stackentry = (self.grammar.dfas[start], 0, (start, None, None, []))
            self.stack = [stackentry]
            self.rootnode = None
            self.used_names = set()

    Pass = False
    try:
        # Any exception is fine
        Parser(grammar=None).setup(start=None)
    except:
        # Catch all exceptions
        Pass = True
    # Check if exception was raised


# Generated at 2022-06-23 15:49:15.484880
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    assert p.grammar is g
    assert p.convert is lam_sub



# Generated at 2022-06-23 15:49:24.506767
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.Grammar()
    g.add_terminal("x", "x")
    g.add_terminal("y", "y")
    g.add_symbol("S", "x S y", (1,))
    g.compile()
    p = Parser(g)
    p.setup()
    p.addtoken(0, "x", (-1, -1))
    p.addtoken(0, "x", (-1, -1))
    p.addtoken(0, "y", (-1, -1))
    p.addtoken(0, "y", (-1, -1))
    p.addtoken(0, "y", (-1, -1))

# Generated at 2022-06-23 15:49:30.005708
# Unit test for method setup of class Parser
def test_Parser_setup():  # pragma: no cover
    import sys
    import blib2to3.pgen2.driver as driver
    import blib2to3.pgen2.parse
    p = Parser(driver.load_grammar(sys.argv[1]), blib2to3.pgen2.parse.convert)
    p.setup()
    print("# Ready to parse.")

# Generated at 2022-06-23 15:49:39.994414
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest

    class ParserTestCase(unittest.TestCase):
        @unittest.skip("todo")
        def test_Parser(self):
            # Create a test parser
            from . import driver

            def get_input():
                import shutil, sys

                src = """\
                    if True:
                        pass
                    if False:
                        pass
                    if 3:
                        pass
                """
                return driver.Driver(src, convert=None).tokenize()

            g = driver.load_grammar("Grammar.txt")
            p = Parser(g, convert=None)
            p.setup()
            for (type, value, start, end, line) in get_input():
                if p.addtoken(type, value, (0, 0)):
                    break
            rootnode = p

# Generated at 2022-06-23 15:49:50.588691
# Unit test for method push of class Parser
def test_Parser_push():
    test_list = []
    assert Parser.push(test_list, token.NAME, "newstate", "context") is None
    assert test_list == [(token.NAME, "newstate", "context", [])]
    assert Parser.push(test_list, token.NAME, "newstate1", "context1") is None
    assert Parser.push(test_list, token.NAME, "newstate2", "context2") is None
    assert test_list == [(token.NAME, "newstate", "context", []),
                         (token.NAME, "newstate1", "context1", []),
                         (token.NAME, "newstate2", "context2", [])]


# Generated at 2022-06-23 15:50:01.066366
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Tests method Parser.classify"""

    import unittest
    from . import token
    from blib2to3.pgen2.grammar import Grammar

    class TestParser(unittest.TestCase):
        def setUp(self):
            grammar = Grammar()

# Generated at 2022-06-23 15:50:09.937011
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import io
    import pprint
    import blib2to3.pgen2.driver
    g = blib2to3.pgen2.driver.load_grammar(sys.argv[1])
    p = Parser(g)
    p.setup()
    # The following test assumes Python source with spaces after all
    # commas, semicolons and colons, and around all operators,
    # parentheses and brackets, with one statement per line, and all
    # lines indented the same distance.
    s = '''
a = 3 + (4,)
b = [
    5,
    6,
    ]
c = {
    7: 8,
    }
d = {}
e = (9, 10)
'''
    t = blib2to3.pgen2.driver.token

# Generated at 2022-06-23 15:50:22.128717
# Unit test for method classify of class Parser
def test_Parser_classify():
    import sys
    import tokenize
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pgen2.parse import Parser as Pgen2Parser
    from blib2to3.pygram import python_grammar, python_symbols
    # Based on unit test for method classify of class Grammar
    grammar = python_grammar
    parser = Pgen2Parser(grammar)
    parser.setup(python_symbols.file_input)
    for _test_file in ('unit_test.py', 'unit_test2.py'):
        tokens = tokenize.generate_tokens(open(_test_file, encoding='utf-8'))

# Generated at 2022-06-23 15:50:35.084273
# Unit test for method pop of class Parser
def test_Parser_pop():
    class MockGrammar(object):
        def __init__(self):
            self.labels = []
            self.dfas = {}

    class MockNode(object):
        def __init__(self):
            self.children = []

    g = MockGrammar()
    tup = (["a", "b"], ["c", "d"])
    tup1 = (["a1", "b1"], ["c1", "d1"])
    g.labels.extend(tup[0])
    g.labels.extend(tup1[0])

    for i in tup[0]:
        g.dfas[i] = MockNode()
        g.dfas[i].states = ["temp", i]
        g.dfas[i].first = [i]
