

# Generated at 2022-06-23 15:40:34.229647
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("msg", "type", "value", "context")
    assert err.msg == "msg"
    assert err.type == "type"
    assert err.value == "value"
    assert err.context == "context"

# Generated at 2022-06-23 15:40:37.575594
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.Grammar()
    Parser(g)._Parser__classify(token.NUMBER, "1", None)



# Generated at 2022-06-23 15:40:39.446453
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(grammar)
    p.setup()

setup = test_Parser_setup

# Generated at 2022-06-23 15:40:42.636323
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test creation of ParseError objects and assignments to attributes
    e = ParseError("Message", token.NAME, "value", (1,1))
    assert e.msg == "Message"
    assert e.type == token.NAME
    assert e.value == "value"
    assert e.context == (1,1)
    assert str(e) == "Message: type='NAME', value='value', context=(1, 1)"


# Generated at 2022-06-23 15:40:46.341450
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("bad token", token.NAME, "airport", (1, 0))
    assert exc.msg == "bad token"
    assert exc.type == token.NAME
    assert exc.value == "airport"
    assert exc.context == (1, 0)

# Generated at 2022-06-23 15:40:51.904144
# Unit test for function lam_sub
def test_lam_sub():
    parser = Parser(None)
    grammar = Grammar(sequences={"stmts": ([1], [])}, tokens={}, keywords={}, labels=[])
    grammar.dfas["stmts"] = ([[(1, 1)]], set([0]))
    node = Node(type="stmts", children=[NL(type=1, value="x")], context=Context(1, 0))
    assert parser.convert(grammar, node) == node

# Generated at 2022-06-23 15:41:02.738527
# Unit test for method setup of class Parser

# Generated at 2022-06-23 15:41:12.516397
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.grammar
    g.load()
    p = Parser(g)

    # test parsing a simple assignment expression
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NEWLINE, "\n", None)
    assert p.rootnode is not None

    # test parsing a simple function definition
    p.setup()
    p.addtoken(token.NAME, "def", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.LPAR, "(", None)
    p.addtoken(token.NAME, "x", None)

# Generated at 2022-06-23 15:41:25.473773
# Unit test for constructor of class Parser
def test_Parser():
    import sys
    import pprint
    from . import grammar, token, driver, pytree

    g = grammar.Grammar(sys.modules[__name__.split('.')[-1]].__dict__)
    convert = pytree.convert
    parser = Parser(g, convert)
    # parser.log = sys.stdout
    pprint.pprint(parser.grammar.dfas)
    parser.setup(g.start)
    pprint.pprint(parser.stack)
    pprint.pprint(parser.dfas)
    pprint.pprint(parser.labels)
    parser.addtoken(token.NUMBER, "0", (1, 0))
    pprint.pprint(parser.stack)
    parser.addtoken(token.COMMA, None, (1, 0))
   

# Generated at 2022-06-23 15:41:27.894907
# Unit test for function lam_sub
def test_lam_sub():
    assert lam_sub(None, (3, '3', None, ['lambda', 'x', ':', 'x'])) == Leaf(3, '3')


# Generated at 2022-06-23 15:41:30.521205
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.parse as parse

    grammar = parse.get_grammar()

    p = parse.Parser(grammar)

    p.classify(token.NAME, 'xxx', None)
    assert not p.used_names

    p.classify(token.NAME, 'def', None)
    assert p.used_names

    p.classify(token.NAME, 'lambda', None)
    assert p.used_names

# Generated at 2022-06-23 15:41:32.759792
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("message", token.NAME, "value", "context")
    assert str(e) == "message: type='NAME', value='value', context='context'"


# Generated at 2022-06-23 15:41:36.063174
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2.driver import Driver

    d = Driver()
    g = d.grammar
    assert g.keywords[token.AND] == "and"
    assert g.tokens[token.AND] == token.AND



# Generated at 2022-06-23 15:41:46.373969
# Unit test for method push of class Parser
def test_Parser_push():
    class MyParser(Parser):
        def push(self, type, newdfa, newstate, context):
            print(type, newdfa[0], newstate, context)
            Parser.push(self, type, newdfa, newstate, context)
    g = Grammar()
    p = MyParser(g)
    p.push(1, ('newdfa', {}), 3, 'context')
    p.push(1, ('newdfa', {}), 3, 'context')
    p.pop()
    p.push(1, ('newdfa', {}), 3, 'context')

# Generated at 2022-06-23 15:41:50.392597
# Unit test for constructor of class ParseError
def test_ParseError():
    import sys
    try:
        raise ParseError("test", 42, "foo", (1, 0))
    except ParseError as x:
        assert x.msg == "test"
        assert x.type == 42
        assert x.value == "foo"
        assert x.context == (1, 0)
    else:
        raise AssertionError("no ParseError raised")

    try:
        raise ParseError("test", 42, "foo", None)
    except ParseError as x:
        assert x.msg == "test"
        assert x.type == 42
        assert x.value == "foo"
        assert x.context is None
    else:
        raise AssertionError("no ParseError raised")


# Generated at 2022-06-23 15:41:56.964587
# Unit test for method push of class Parser
def test_Parser_push():
    class Parser(object):
        def __init__(self) -> None:
            self.stack: List[Tuple[DFAS, int, RawNode]] = [
                (None, 0, None)
            ]  # type: ignore

    parser = Parser()

    parser.push('', None, 0, None)
    assert len(parser.stack) == 2
    assert parser.stack[0][-1] is None
    assert parser.stack[1][-1] == ('', None, None, [])



# Generated at 2022-06-23 15:42:09.234767
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Test pop method, in particular adding Node to children of Node"""
    # Prepare input tree
    dfa = [[(0, 0)]]
    state = 0
    node = [[], []]
    stack = [[dfa, state, node]]
    # Run the method
    popdfa = dfa
    popstate = state
    popnode = node
    newnode = node
    stack.pop()
    dfa, state, node = stack[-1]
    node[-1].append(newnode)
    # Check result
    assert stack == [[dfa, state, node]]
    assert dfa == [[(0, 0)]]
    assert state == 0
    assert node == [[], [node]]
    assert popdfa == dfa
    assert popstate == state
    assert popnode == node
    assert newnode == node

# Generated at 2022-06-23 15:42:18.208495
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(Grammar.from_string("""
        x: 'foo';
        y: 'bar' x;
        z: 'baz' y;
    """))

    p.push("y", p.grammar.dfas["y"], 0, None)
    assert p.stack == [("y", 0, None)]

    p.push("x", p.grammar.dfas["x"], 0, None)
    assert p.stack == [("y", 0, None), ("x", 0, None)]

    p.push("y", p.grammar.dfas["y"], 0, None)
    assert p.stack == [("y", 0, None), ("x", 0, None), ("y", 0, None)]

    p.push("x", p.grammar.dfas["x"], 0, None)

# Generated at 2022-06-23 15:42:25.284120
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.parse import tokenize
    from blib2to3.pgen2.grammar import Grammar, dfa

    gr = Grammar(dict(
        a = (["x", "y", "z"], None),
        x = (["a", "b"], None),
        b = (["x"], None),
        z = (["b"], None),
    ))
    gr.dfas = dict(
        a = dfa([(0, 1), (1, 2)], 2),
        x = dfa([(2, 3), (3, 4)], 0),
        b = dfa([(4, 1)], 1),
        z = dfa([(5, 2)], 0),
    )

    p = Parser(gr, None)
    p.setup()
   

# Generated at 2022-06-23 15:42:28.847358
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("message", 1, 2, 3)
    assert str(exc).startswith("message: type=1, value=2, context=")
    assert exc.msg == "message"
    assert exc.type == 1
    assert exc.value == 2
    assert exc.context == 3

# Generated at 2022-06-23 15:42:33.808407
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("msg", token.NUMBER, "5", (1, 0))
    assert str(e) == "msg: type=50, value='5', context=(1, 0)"
    assert e.msg == "msg"
    assert e.type == token.NUMBER
    assert e.value == "5"
    assert e.context == (1, 0)



# Generated at 2022-06-23 15:42:36.150419
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2.grammar import Grammar

    g = Grammar("Grammar/Grammar", "Grammar/Python.grammar", "Grammar/Python.gensus")
    p = Parser(g)

# Generated at 2022-06-23 15:42:40.798611
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("msg", token.PLUS, "+", None)
    assert pe.msg == "msg"
    assert pe.type == token.PLUS
    assert pe.value == "+"
    assert pe.context is None
    try:
        raise pe
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type == token.PLUS
        assert e.value == "+"
        assert e.context is None
    assert str(pe) == "msg: type='+', value='+', context=None"
    if not support.check_impl_detail(pypy=True):  # pragma: no cover
        assert pe.args == ("msg", token.PLUS, "+", None)


# Generated at 2022-06-23 15:42:51.539895
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Unit test for method shift of class Parser"""
    grammar = Grammar()
    grammar.tokens = {0: 0, 1: 1, 2: 2}
    class Convert:
        def __init__(self, grammar: Grammar) -> None:
            self.grammar = grammar
        def __call__(self, node: RawNode) -> Optional[Node]:
            type, value, context, children = node
            assert children is None
            if type == 2:
                return Node(type=type, children=[Leaf(0, 'x'), Leaf(1, 'y')])
            else:
                return None
    converter = Convert(grammar)
    parser = Parser(grammar, converter)
    parser.setup()
    assert parser.addtoken(0, 'x', None) is False
    assert parser.addtoken

# Generated at 2022-06-23 15:43:03.364472
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    id = token.NAME
    plus = token.PLUS
    minus = token.MINUS

    grammar = grammar.grammar
    g = grammar.Grammar(grammar_str)
    p = Parser(g)
    s = "a + b - c"
    f = open(tokenize.StringIO(s))
    # This is a hack: use the standard tokenize to get input tokens
    p.addtoken(token.INDENT, "", (1, 0))
    for token in tokenize.generate_tokens(f.readline):
        p.addtoken(*token, context=(1, 0))
    p.addtoken(token.ENDMARKER, "", (1, 0))
    print(p.rootnode)
    return True




# Generated at 2022-06-23 15:43:07.525398
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammars
    from . import convert

    grammar = grammars.get_grammar("2.7")
    parser = Parser(grammar)
    parser.setup()

    parser = Parser(grammar, convert.convert)
    parser.setup()

# Generated at 2022-06-23 15:43:19.702320
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2 import tokenize, driver, convert
    from blib2to3.pgen2.grammar import Grammar


    # Get the grammar
    g = Grammar("Grammar.txt")

    # Mapping from token to label
    mapping = dict([(v, k) for k, v in g.tokens.items()])

    # Create the parser engine
    p = Parser(g, convert)

    def parse(s):
        # Tokenize the string
        tokens = tokenize.generate_tokens(iter(s).__next__)

        # Parse the tokens
        p.setup()
        for x in tokens:
            if p.addtoken(x, mapping):
                break
       

# Generated at 2022-06-23 15:43:24.923942
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .parser_lextab import lextab
    from .parser_parsetab import parsetab
    from .grammar import grammar

    grammar = grammar(lextab=lextab, parsetab=parsetab)
    p = Parser(grammar)
    p.setup()
    
    assert p.classify(1, "simple_stmt", "simple_stmt") == 1
    p.shift(1, "simple_stmt", 1, "simple_stmt")
    assert p.classify(3, ":", ":") == 2
    p.shift(3, ":", 2, ":")
    assert p.classify(4, "NEWLINE", "NEWLINE") == 3
    p.shift(4, "NEWLINE", 3, "NEWLINE")

# Generated at 2022-06-23 15:43:34.497583
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    sample = b'class Pair:\n    def __init__(self, x, y):\n        self.x = x\n        self.y = y\n'
    tokens = tokenize.generate_tokens(io.BytesIO(sample).readline)
    parser = Parser(grammar)
    parser.setup()
    for type, value, context in tokens:
        if type == token.OP:
            if value == "=":
                type = token.EQUALS
        parser.addtoken(type, value, context)
    # The following test is very weak, it only serves to verify that
    # the parser did not crash.  The tree constructed by driver.py
    # contains a redundant stmt node, which should be eliminated.
    assert parser.rootnode
    assert parser.rootnode[0] == symbol.file

# Generated at 2022-06-23 15:43:46.779967
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .pgen import driver, tokenize

    # The abstract syntax tree is a tuple: (type, [child, ...]), where
    # type is a symbol.

    class Converter(object):
        """Convert concrete syntax tree nodes to abstract syntax tree."""

        def __call__(self, grammar, node):
            type, value, context, children = node
            if value is not None:
                return None  # Don't return leaf nodes
            elif type == grammar.symbol2number["file_input"]:
                newchild = []
                for child in children:
                    if child is not None:
                        newchild.append(child)
                return (type, newchild)
            else:
                return (type, children)

    grammar = driver.load_grammar("Grammar/Grammar")
    converter = Converter()

# Generated at 2022-06-23 15:43:54.868653
# Unit test for method setup of class Parser
def test_Parser_setup():
    f = open("../pgen/Python.asdl")
    g = Grammar(f, "Python.asdl")

    def convert(grammar, node):
        """Unit test for method convert of class Parser"""
        print(node)
        assert node[0] is not None
        assert node[1] is not None
        assert node[2] is not None
        assert node[3] is not None
        return None

    p = Parser(g, convert)
    p.setup(0)

if __name__ == "__main__":
    test_Parser_setup()

# Generated at 2022-06-23 15:43:59.144215
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test instantiation of ParseError
    e = ParseError('msg', 1, 'value', Context())
    assert isinstance(e, Exception)
    assert e.msg == 'msg'
    assert e.type == 1
    assert e.value == 'value'
    assert isinstance(e.context, Context)



# Generated at 2022-06-23 15:44:10.129496
# Unit test for method push of class Parser

# Generated at 2022-06-23 15:44:21.125566
# Unit test for method shift of class Parser
def test_Parser_shift():
    # We do not run this function during normal running,
    # it is only run when we do "python3 -m"
    from . import pgen
    from .tokenize import generate_tokens
    from .tokenize import untokenize

    # Read in the grammar
    with open("Python.asdl", "r", encoding="utf-8") as f:
        # Use 'exec' to read the grammar file.
        # The file is Python source code and it defines
        # several names due to the 'from' statement at the top.
        # We want those names to end up in our module.
        # Here is a possible way to do that:
        #   Save and then restore the names we want to keep
        names = {}

# Generated at 2022-06-23 15:44:22.977300
# Unit test for method setup of class Parser
def test_Parser_setup():
    pass



# Generated at 2022-06-23 15:44:28.901931
# Unit test for function lam_sub
def test_lam_sub():
    # Test correct conversion of all node types
    g, m, s, t, n, r, c = range(7)
    grammar = Grammar(start=s, labels=[(t, "x"), (n, "y"), (r, "z")], dfas={s: ([[(1, 1)], [(2, 2)], [(3, 3)], [(0, 4)]], {0: 1, 1: 2, 2: 3, 3: 4})})
    # pylint: disable=unbalanced-tuple-unpacking
    expected = Node(1, [Node(2, [Node(3, [])])])
    actual = lam_sub(grammar, (s, None, None, [(n, None, None, [(r, None, None, [])])]))
    assert actual == expected
    actual = lam_sub

# Generated at 2022-06-23 15:44:34.733697
# Unit test for function lam_sub
def test_lam_sub():
    class fake_grammar:
        pass
    fake_grammar.symbol2number = lambda s: s
    g = fake_grammar()
    n = (1, 2, 3, 4)
    assert lam_sub(g, n) == Node(type=1, value=2, context=3, children=4)
    n = (1, None, None, None)
    assert lam_sub(g, n) == Node(type=1)

# Generated at 2022-06-23 15:44:38.165018
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup(1)
    parser.shift(1, "X", 1, "X")
    assert parser.stack[0][2][-1] == ["X"]


# Generated at 2022-06-23 15:44:46.847571
# Unit test for constructor of class Parser
def test_Parser():
    class G(object):
        def __init__(self, **kwds):
            self.__dict__.update(kwds)

        def __eq__(self, other):
            return self.__dict__ == other.__dict__

        def __ne__(self, other):
            return self.__dict__ != other.__dict__

    p = Parser(G(start=3, dfas={3:([[(1, 0), (2, 1)], [(2, 1)], [(0, 2)]], {0: 2})}))
    assert p.grammar == G(start=3, dfas={3:([[(1, 0), (2, 1)], [(2, 1)], [(0, 2)]], {0: 2})})
    assert p.convert.__name__ == 'lam_sub'

# Generated at 2022-06-23 15:44:57.513109
# Unit test for constructor of class Parser
def test_Parser():
    from . import driver, grammar, token
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    d = driver.Driver(g, p.addtoken)
    d.set_str("b = a*2")
    d.parse_tokens()
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode[0].type == g.symbol2number["stmt"]
    assert p.rootnode[0][1].type == token.EQUAL
    assert p.rootnode[0][0].type == g.symbol2number["power"]
    assert p.rootnode[0][0][0].type == g.symbol2number["atom"]

# Generated at 2022-06-23 15:45:07.755475
# Unit test for method push of class Parser
def test_Parser_push():
    # This checks that the assertion in self.push() does not fail.
    from . import grammar

    g = grammar.Grammar()
    g.labels = [
        (1, 3),
        (1, 0),
        (2, 1),
        (3, 2),
        (3, 0),
        (2, 3),
        (4, 2),
        (4, 1),
        (4, 0),
    ]
    g.keywords = {}
    g.start = 1

# Generated at 2022-06-23 15:45:10.130293
# Unit test for constructor of class Parser
def test_Parser():
    class MyGrammar(Grammar):
        pass

    g = MyGrammar()
    p = Parser(g)
    assert p.grammar is g
    assert p.convert is None
    p.convert = lam_sub



# Generated at 2022-06-23 15:45:12.196338
# Unit test for constructor of class ParseError
def test_ParseError():
    context = (1, 0)
    err = ParseError("msg", token.NAME, "name", context)
    assert err.type == token.NAME
    assert err.value == "name"
    assert err.context == context

# Generated at 2022-06-23 15:45:19.245308
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    # Disabling division checking for this test
    from __future__ import division

    from . import driver

    parser = driver.Parser()
    # Tuple entries are: (type, value, context, is_end)
    tokens = [
        (tokenize.NAME, "abc", None, False),
        (tokenize.NUMBER, "1", None, False),
        (tokenize.NEWLINE, "", None, False),
        (tokenize.NAME, "efg", None, False),
        (tokenize.NUMBER, "2", None, False),
        (tokenize.NEWLINE, "", None, True),
    ]
    iter_tokens = iter(tokens)

    def next_token() -> Tuple[int, Optional[Text], Context, bool]:
        return next(iter_tokens)

   

# Generated at 2022-06-23 15:45:21.153683
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.pgen2.grammar as grammar

    g = grammar.grammar()
    p = Parser(g)
    p.addtoken(token.NUMBER, "12", (1, 1))



# Generated at 2022-06-23 15:45:31.362669
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar()
    grammar.keywords = {}  # type: ignore
    grammar.start = "start"  # type: ignore
    grammar.tokens = {}  # type: ignore
    grammar.labels = []  # type: ignore
    grammar.dfas = {
        "start": ([[(1, 0), (2, 0), (0, 1)], [(0, 2)]], {0: 1, 1: 2})
    }  # type: ignore
    n = lam_sub(grammar, ("start", None, None, [(1, "a", None, None), (2, "b", None, None)]))
    assert n.type == "start"
    assert n.children == [Leaf(1, "a"), Leaf(2, "b")]

# Generated at 2022-06-23 15:45:39.897334
# Unit test for method addtoken of class Parser

# Generated at 2022-06-23 15:45:51.467178
# Unit test for method shift of class Parser
def test_Parser_shift():
    class MockDFA:
        def __init__(self) -> None:
            self.states = [
                [(0, 0),
                 (1, 1),
                 (2, 2)],
                [(0, 1)],
                [(0, 2)],
            ]

    class MockGrammar:
        def __init__(self) -> None:
            self.dfas = {0: MockDFA()}
            self.labels = [(0, "ENDMARKER"),
                           (1, "NAME"),
                           (2, "NUMBER")]
            self.keywords = {"None": 1}
            self.tokens = {token.NAME: 1,
                           token.NUMBER: 2,
                           token.ENDMARKER: 0}

    p = Parser(MockGrammar())

# Generated at 2022-06-23 15:45:55.029639
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", 1, 2, 3)
    except ParseError:
        pass
    else:
        raise TestFailed("ParseError constructor failed")

# Generated at 2022-06-23 15:45:57.594631
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Unit test for Parser.classify()."""
    from . import driver

    p = driver.make_parse_function()
    parser = p.parse_tokens.__self__
    assert parser.classify(0, "", Context(None, 0, 0)) == 255
    assert parser.classify(token.NAME, "NAME", Context(None, 0, 0)) == 256
    assert parser.classify(token.NUMBER, "NUMBER", Context(None, 0, 0)) == 258


# Generated at 2022-06-23 15:46:06.613397
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class TestParser(Parser):
        def __init__(self, grammar, tokens, convert=None, debug=0):
            Parser.__init__(self, grammar, convert)
            self.tokens = iter(tokens)
            self.debug = debug

        def addtoken(self, type, value, context):
            if self.debug:
                print("addtoken:", self.grammar.tok_name[type], repr(value), context)
            return Parser.addtoken(self, type, value, context)

    def p(s, altstart=None, debug=0):
        from . import driver
        t = driver.parse_tokens(s)

# Generated at 2022-06-23 15:46:16.049371
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.driver

    d = blib2to3.pgen2.driver.Driver()
    g = d.load_grammar(blib2to3.pgen2.driver.grammar_path)
    p = Parser(g)
    p.classify(token.NUMBER, 42, None)

    try:
        p.classify(token.NUMBER, None, None)
    except ParseError as e:
        assert e.msg == "bad token"
        assert e.type == token.NUMBER
        assert e.value is None
    else:
        assert 0, "expected ParseError"


# Generated at 2022-06-23 15:46:27.259005
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar(grammar.DEFAULT_GRAMMAR)
    p = Parser(g)
    p.setup()
    assert p.rootnode is None
    p.push(g.symbol2number["file_input"], g.dfas[g.symbol2number["file_input"]], 0, None)
    assert len(p.stack) == 2
    p.push(g.symbol2number["stmt"], g.dfas[g.symbol2number["stmt"]], 0, None)
    assert len(p.stack) == 3
    p.push(g.symbol2number["small_stmt"], g.dfas[g.symbol2number["small_stmt"]], 0, None)
    assert len(p.stack) == 4
    p

# Generated at 2022-06-23 15:46:37.867307
# Unit test for method push of class Parser
def test_Parser_push():
    # This form of Parser.push works
    stack = []
    stack.append(((('type', 'value', [], None),
                   ('type', 'value', [], None)),
                  0,
                  ('type', 'value', [], None)))
    stack.append(((('type', 'value', [], None),
                   ('type', 'value', [], None)),
                  0,
                  ('type', 'value', [], None)))
    stack.append(((('type', 'value', [], None),
                   ('type', 'value', [], None)),
                  0,
                  ('type', 'value', [], None)))
    stack.append(((('type', 'value', [], None),
                   ('type', 'value', [], None)),
                  0,
                  ('type', 'value', [], None)))

# Generated at 2022-06-23 15:46:40.577256
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver
    p = driver.Parser()
    p.push(1, 2, 3, 4)
    assert p.stack == [(2, 3, (1, None, 4, []))]



# Generated at 2022-06-23 15:46:46.545886
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError(
        "msg", token.NAME, "value", Context(1, 2, "fname")
    )  # type: ignore
    assert e.msg == "msg"
    assert e.type == token.NAME
    assert e.value == "value"
    assert e.context == Context(1, 2, "fname")

# Generated at 2022-06-23 15:46:55.555218
# Unit test for method setup of class Parser
def test_Parser_setup():
    def lam_sub(grammar, node):
        assert node[3] is not None
        return node[3]
    g = Grammar()
    g.add_nonterminal('a')
    g.add_rule('a', [['a', 'a'], []])
    g.start = 'a'
    p = Parser(g, lam_sub)
    p.setup()
    import blib2to3.tokenize
    blib2to3.tokenize.tokenize_loop(blib2to3.StringIOTokenizer(b'""'), p.addtoken)
    assert p.rootnode==[]

# Generated at 2022-06-23 15:47:05.494730
# Unit test for constructor of class Parser
def test_Parser():
    from . import tokenize, token, grammar

    g = grammar.Grammar()

# Generated at 2022-06-23 15:47:07.778275
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(Grammar())
    assert p.stack == []
    assert p.rootnode is None
    assert p.convert is lam_sub

# Generated at 2022-06-23 15:47:16.720372
# Unit test for method shift of class Parser

# Generated at 2022-06-23 15:47:24.640326
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2 import literals, operator

    g = Grammar([])
    n = literals.NUMBER
    o = operator.PLUS

    assert lam_sub(g, (n, '1', None, None)) == Leaf(n, '1')
    assert lam_sub(g, (o, None, None, [(n, '1', None, None), (n, '2', None, None)])) == (
        Node(o, [Leaf(n, '1'), Leaf(n, '2')])
    )

# Generated at 2022-06-23 15:47:29.689738
# Unit test for constructor of class ParseError
def test_ParseError():
    import StringIO
    try:
        raise ParseError("message", token.PLUS, "+", (1, 0))
    except ParseError as err:
        stream = StringIO.StringIO()
        print(err, file=stream)
        assert stream.getvalue() == 'message: type=304, value=u\'+\', context=(1, 0)\n'

if __name__ == "__main__":
    test_ParseError()

# Generated at 2022-06-23 15:47:39.090713
# Unit test for method push of class Parser
def test_Parser_push():
    # Success case
    p = Parser(Grammar())
    p.setup()
    newnode: RawNode = (0, None, None, [])
    p.push(0, (
        (0, 1)
    ), 0, None)
    assert p.stack == [
        (((
            (0, 1)
        ), 1), 0, newnode)
    ]
    # Now let us see if it works with a symbol that has to be converted
    p = Parser(Grammar())
    p.setup()
    newnode: RawNode = (0, None, None, [])
    p.push(0, (
        (0, 1)
    ), 0, None)

# Generated at 2022-06-23 15:47:43.437623
# Unit test for constructor of class Parser
def test_Parser():
    class DummyGrammar(object):
        dfas = {}
        start = 256

    p = Parser(DummyGrammar())
    p.setup()
    p.rootnode == None  # Must be None before calling addtoken()
    success = p.addtoken(1, 'a', (1, 0))
    assert success == False

# Generated at 2022-06-23 15:47:46.661859
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("test error", token.PLUS, "+", None)
    assert err.msg == "test error"
    assert err.type == token.PLUS
    assert err.value == "+"
    assert err.context is None

# Generated at 2022-06-23 15:47:53.131257
# Unit test for constructor of class Parser
def test_Parser():
    """Test class Parser.

    Create a parser and assert that the instance variables are set
    correctly.  Subsequently, call the parser's methods and assert
    that they work correctly.

    """
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    assert len(p.stack) == 0
    assert p.rootnode is None
    assert p.grammar == g
    assert p.convert is None
    p.setup()
    assert len(p.stack) == 1
    assert p.rootnode is None



# Generated at 2022-06-23 15:48:00.707196
# Unit test for method push of class Parser
def test_Parser_push():
    from . import parsetok

    from . import grammar

    g = parsetok.parse_grammar(grammar.grammar, "single")

    p = Parser(g)

    p.setup()

    p.stack = [None]

    p.push(3, [([(1, 2)], {1: 1})], 4, None)

    assert p.stack == [None, ([([(1, 2)], {1: 1})], 0, (3, None, None, []))]

# Generated at 2022-06-23 15:48:11.683399
# Unit test for method push of class Parser
def test_Parser_push():
    class TestContext(Context):
        def get_line(self):
            return 0
        def get_column(self):
            return 0
        def get_source_line(self):
            return 0
    test_context = TestContext()
    grammar = Grammar(grammar=open("parser.out", "rb"))
    parser = Parser(grammar=grammar, convert=lam_sub)
    parser.setup()
    parser.addtoken(type=token.NAME, value="for", context=test_context)
    parser.addtoken(type=token.NAME, value="x", context=test_context)
    parser.addtoken(type=token.NAME, value="in", context=test_context)
    parser.addtoken(type=token.NAME, value="range", context=test_context)
    parser.addtoken

# Generated at 2022-06-23 15:48:19.573075
# Unit test for method push of class Parser
def test_Parser_push():
    # create a parser
    from . import pgen2
    p = pgen2.driver.load_grammar("python2.7")
    parser = Parser(p)
    # p.labels is a tuple which contains the tuples (type, value)
    def token_number(name):
        if name in p.keywords:
            num = p.keywords[name]
        else:
            num = p.tokens[name]
        return num

    newstate = 1
    assert parser.labels[0] == (-1, 0)
    assert parser.labels[1] == (token.NAME, 'simple_stmt')
    assert parser.labels[2] == (token.NAME, 'small_stmt')

# Generated at 2022-06-23 15:48:27.999261
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar(gr_spec="""
        S: XXX E
        S: XXX E E
        S: XXX E F
        """)
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NAME, "XXX", None)
    parser.addtoken(token.NAME, "E", None)
    parser.addtoken(token.NAME, "F", None)
    parser.addtoken(token.NAME, "E", None)


# Generated at 2022-06-23 15:48:35.729084
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .grammar import Grammar

    p = Parser(Grammar())
    dfa, state, node = [(4, 5)], 0, [1, 2, 3]
    p.stack = [(dfa, state, node)]
    p.shift(10, "test", 4, 0)

    assert p.stack == [(dfa, 4, node)]
    assert node == [1, 2, 3, (10, "test", 0, None)]


# Generated at 2022-06-23 15:48:43.386076
# Unit test for method push of class Parser
def test_Parser_push():
    import os
    fname = os.path.join(os.path.dirname(__file__), "..", "Grammar/Grammar")
    g = Grammar(open(fname))
    p = Parser(g)
    p.setup()
    p.stack = [(g.dfas['file_input'], 0, None)]
    p.push('file_input', g.dfas['decorated'], 0, None)
    p.push('decorated', g.dfas['decorators'], 0, None)
    p.push('decorators', g.dfas['decorator'], 0, None)
    p.shift(1, '@', 1, None)
    p.push('decorator', g.dfas['dotted_name'], 0, None)
   

# Generated at 2022-06-23 15:48:53.615811
# Unit test for method classify of class Parser
def test_Parser_classify():
    import sys
    import imp
    import unittest
    import types

    # Copy the grammar module in place
    sys.path.insert(0, ".")

# Generated at 2022-06-23 15:49:03.789726
# Unit test for method shift of class Parser
def test_Parser_shift():

    def test_converter(grammar, node):
        type, value, context, children = node
        if children is not None:
            return type, value, context, children
        return None

    from . import grammar

    parser = Parser(grammar, test_converter)

    parser.setup()
    parser.addtoken(token.NAME, "while", None)
    parser.addtoken(token.NAME, "x", None)
    parser.addtoken(token.NAME, "is", None)
    parser.addtoken(token.NAME, "True", None)
    parser.addtoken(token.NAME, "foo", None)


# Generated at 2022-06-23 15:49:09.410694
# Unit test for method push of class Parser
def test_Parser_push():
    import pprint
    from pprint import pformat
    from . import grammar

    p = Parser(grammar)
    p.setup()
    input = [('NAME', 'a', '1,1', None),
             ('EQUAL', '=', '1,3', None),
             ('NAME', 'b', '1,5', None),
             ('NEWLINE', '\n', '1,6', None),
             tokens.ENDMARKER]
    for type, value, start, end in input:
        assert p.addtoken(type, value, start) is False

    # pprint.pprint(p.rootnode)
    # assert False



# Generated at 2022-06-23 15:49:14.907923
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", None, None, None)
    except ParseError as e:
        assert e.msg == "msg"
        assert e.type is None
        assert e.value is None
        assert e.context is None
        return
    assert 0, "didn't raise ParseError"

# Generated at 2022-06-23 15:49:25.896506
# Unit test for method shift of class Parser
def test_Parser_shift():
    with open("Grammar.txt", "rt") as f:
        from . import pgen

        # Parse the grammar file into a collection of DFAs
        mydfas, mylabels = pgen.dfas(f)
    # Construct the complete set of DFAs and labels
    mygrammar = Grammar(mydfas, mylabels)
    # Create a parser instance
    myparser = Parser(mygrammar)
    # Start parsing with the start symbol
    myparser.setup()
    # Add tokens
    while True:
        if myparser.addtoken(token.NAME, "x", "context"):
            break
    # Check root node
    assert myparser.rootnode is not None
    assert myparser.rootnode[0] == "file_input"
    # Check children

# Generated at 2022-06-23 15:49:37.342818
# Unit test for method push of class Parser
def test_Parser_push():
    # Testing configuration
    Grammar = blib2to3.pgen2.grammar

    def test_func(type: int, newdfa: DFAS, newstate: int, context: Context) -> None:
        # Arrange
        input_arguments = type, newdfa, newstate, context
        parser_instance = Parser(Grammar.Grammar())

        # Act
        try:
            parser_instance.push(*input_arguments)
        except Exception as exception_instance:
            print(f'Exception thrown for input arguments {input_arguments!r}.')
            raise exception_instance

    # Call the unit test

# Generated at 2022-06-23 15:49:44.125720
# Unit test for method shift of class Parser
def test_Parser_shift():
    import tokenize

    from io import StringIO

    # Read the "Hello World!" program
    s = StringIO("print('Hello World!')\n")
    tokens = tokenize.generate_tokens(s.readline)
    # Create a parser instance
    p = Parser(grammar)

    # Prepare for parsing
    p.setup()

    # Parse all the tokens from the program
    for token in tokens:
        type, value, start, _, _ = token
        if p.addtoken(type, value, Context(*start)):
            break


if __name__ == "__main__":
    from . import grammar

    import sys

    grammar = grammar.grammar

    # Unit test for __init__
    print("Testing __init__")
    p = Parser(grammar)

    # Unit test

# Generated at 2022-06-23 15:49:49.607615
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from . import tokenize
    from . import symbols

    from . import python_grammar

    p = Parser(grammar.Grammar(python_grammar.grammar), lam_sub)
    p.setup()
    tokenize.tokenize_file(open("/tmp/blib2to3/test.py"), p.addtoken)
    print(p.rootnode)

# Generated at 2022-06-23 15:49:52.322436
# Unit test for function lam_sub
def test_lam_sub():
    # assert lam_sub()

    import unittest
    import doctest

    suite = unittest.TestSuite()
    suite.addTests(doctest.DocTestSuite())
    return suite

# Generated at 2022-06-23 15:49:54.283489
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)

# Generated at 2022-06-23 15:50:04.697689
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest
    import blib2to3.pgen2.pgen as pgen

    class FakeGrammar:
        def __init__(self):
            self.keywords = {}
            self.tokens = {token.NAME: 0}

    class FakeConvert:
        def __init__(self):
            self.called = 0
        def __call__(self, grammar: Grammar, node: RawNode) -> Leaf:
            self.called += 1
            return Leaf(type=node[0], value=node[1], context=node[2])

    class TestParser(unittest.TestCase):
        def test_shift(self):
            fg = FakeGrammar()
            fc = FakeConvert()
            p = Parser(fg, fc)
            p.setup()
           

# Generated at 2022-06-23 15:50:17.018805
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from blib2to3.pgen2 import token

    try:
        lam_sub(None, None)
        assert False
    except AssertionError:
        pass

    gr = grammar.Grammar()
    assert lam_sub(gr, (1, ("x", "x"), None, None)) is None
    gr.add_token("x", "x")
    assert lam_sub(gr, (1, ("x", "x"), None, None)) is None
    gr.add_token("y", "y")
    assert lam_sub(gr, (1, ("x", "x"), None, None)) is None
    gr.add_token("z", "z")
    assert lam_sub(gr, (1, ("x", "x"), None, None)) is None
    assert lam_sub

# Generated at 2022-06-23 15:50:20.205581
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("error", 10, "value", 1)
    assert e.msg == "error"
    assert e.type == 10
    assert e.value == "value"
    assert e.context == 1

# Generated at 2022-06-23 15:50:28.386104
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .token import tok_name
    from . import python_grammar

    def _convert(grammar: Grammar, node: RawNode) -> Leaf:
        """Convert a concrete syntax tree node to an abstract syntax tree node."""
        assert node[3] is None
        if node[0] < 256:
            return Leaf(type=node[0], value=node[1], context=node[2])
        return Leaf(node[0], [], node[2])

    def _test(input : Sequence[Any]) -> Node:
        p = Parser(python_grammar, _convert)
        p.setup()
        tok = token.generate_tokens(input)

# Generated at 2022-06-23 15:50:33.326641
# Unit test for constructor of class Parser
def test_Parser():
    from .token import tokenize
    import io

    import blib2to3.fixer_base
    import blib2to3.pgen2.grammar
    import blib2to3.pgen2.parse
    import blib2to3.pgen2.pgen

    # TODO: How can we get the pickle module to support Python 3?
    #import pickle

    # Try parsing a simple program using the Python grammar
    sample = "a = 3\nb = 4\nc = 5\n"
    tabfile = "Python.tab"
    pgen = blib2to3.pgen2.pgen.Pgen()
    if not pgen.generate(tabfile):
        print("Could not load grammar", file=sys.stderr)
        sys.exit(1)
    g = blib