

# Generated at 2022-06-23 15:40:29.197641
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    raise NotImplementedError


# Generated at 2022-06-23 15:40:39.414863
# Unit test for method addtoken of class Parser

# Generated at 2022-06-23 15:40:45.255171
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar(open('Grammar.txt')))
    p.setup()
    assert p.shift(3, "Hello", 6, 0) == None
    assert p.shift(1, None, 3, 1) == None
    assert p.shift(4, "Goodbye", 4, 1) == None
    assert p.shift(1, None, 5, 2) == None

# Generated at 2022-06-23 15:40:50.013047
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import token

    def e(type, value):
        print('type = %r, value = %r' % (type, value))

    p = Parser(grammar.grammar)
    p.setup()
    assert p.classify(token.NUMBER, "1", None) == grammar.syms.NUMBER
    p.addtoken(token.NUMBER, "1", None)

# Generated at 2022-06-23 15:41:00.307994
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2.tokenize import detect_future

    p = Parser(Grammar(open(detect_future.__code__.co_filename).read()))
    
    def test1(method):
        p.setup()
        assert p.stack
        method(p)
        p.setup()
        assert p.stack
        method(p)
        p.setup(None)
        assert p.stack
        method(p)
        p.setup(257)
        assert p.stack
        method(p)
        p.setup(258)
        assert p.stack
        method(p)
    test1(lambda p: None)
    p.setup()

# Generated at 2022-06-23 15:41:06.584976
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("a", 1, "b", Context("file", 1, 2))
    except ParseError as err:
        assert err.msg == "a"
        assert err.type == 1
        assert err.value == "b"
        assert err.context == Context("file", 1, 2)
    else:
        assert 0, "ParseError not raised"

# Generated at 2022-06-23 15:41:16.044417
# Unit test for constructor of class Parser
def test_Parser():
    import io
    import sys
    import blib2to3.pgen2.generate
    import pgen
    fp = io.StringIO(textwrap.dedent("""if 1:
    pass
"""))
    # Create a parser instance
    p = pgen.Parser(blib2to3.pgen2.generate.pgen(fp), blib2to3.pgen2.generate.driver)
    # Prepare for parsing
    p.setup()
    # Parse some input
    for t in blib2to3.pgen2.generate.tokenize(fp):
        print(t)
        p.addtoken(t[0], t[1], t[2])
    # Get the tree from the parser (the last token was EOF)
    tree = p.rootnode

# Generated at 2022-06-23 15:41:21.145219
# Unit test for method shift of class Parser
def test_Parser_shift():
    import _testcapi
    try:
        Parser._Parser__shift()
    except AttributeError:
        assert 0, "_testcapi.test_Parser_shift fails"
    else:
        assert _testcapi.test_Parser_shift() == 0, "_testcapi.test_Parser_shift fails"

# Generated at 2022-06-23 15:41:31.553167
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar, token

    g = grammar.Grammar(grammar.parse(grammar.grammar))

    p = Parser(g)

    stack, nodes, labels = [], [], []

    def cn(p: Parser, t: raw) -> Optional[Node]:
        stack.append(t)
        return None

    p.convert = cn

    # We don't call setup() because it would reset stack
    p.grammar = g
    p.stack = [(g.dfas[g.start], 0, None)]

    p.push(g.symbol2number["expr_stmt"], g.dfas[g.symbol2number["expr_stmt"]], 0, None)

# Generated at 2022-06-23 15:41:34.795963
# Unit test for function lam_sub
def test_lam_sub():
    assert lam_sub(None, (None, None, None, [])) is None
    assert lam_sub(None, (None, None, None, [1])) == 1
    assert lam_sub(None, (None, None, None, [1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-23 15:41:48.265282
# Unit test for method shift of class Parser
def test_Parser_shift():
    L = token
    p = Parser(Grammar())
    p.setup()

    # Test shift(self, type: int, value: Optional[Text], newstate: int, context: Context) -> None
    p.stack = [([[(0, 0)]], 0, ([0, 0, 0, []]))]
    p.shift(0, 0, 0, 0)
    assert p.stack == [([[(0, 0)]], 0, ([0, 0, 0, []]))]
    p.stack = [([[(0, 0)]], 0, ([0, 0, 0, []]))]
    p.shift(0, "", 0, "")
    assert p.stack == [([[(0, 0)]], 0, ([0, "", "", []]))]

# Generated at 2022-06-23 15:41:58.041023
# Unit test for method push of class Parser
def test_Parser_push():
    from ._tokenize import generate_tokens, group


# Generated at 2022-06-23 15:42:08.021543
# Unit test for method classify of class Parser
def test_Parser_classify():
    class FakeGrammar(object):
        def __init__(self):
            self.keywords = dict(foo=257, bar=258)
            self.tokens = dict(NAME=259, NUMBER=260)
    parser = Parser(FakeGrammar())
    assert parser.classify(token.NAME, "foo", None) == 257
    assert parser.classify(token.NAME, "bar", None) == 258
    assert parser.classify(token.NAME, "baz", None) == 259
    assert parser.classify(token.NUMBER, None, None) == 260

# Generated at 2022-06-23 15:42:17.637063
# Unit test for method push of class Parser
def test_Parser_push():

    class DFA(object):
        labels = [0, 1, 2, 3, 4, 5]
        tokens = {
            token.NAME: 1,
            token.PLUS: 2,
            token.MULT: 3,
            token.LPAR: 4,
            token.RPAR: 5,
        }

# Generated at 2022-06-23 15:42:24.918899
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.pgen import parse_grammar

    g = parse_grammar(Grammar, "Grammar.txt")
    p = Parser(g)
    p.setup(1)
    p.addtoken(token.NAME, "expr", Context(1, 0))
    p.addtoken(token.NAME, "xor_expr", Context(1, 0))
    p.addtoken(token.NAME, "and_expr", Context(1, 0))
    p.addtoken(token.NAME, "shift_expr", Context(1, 0))
    p.addtoken(token.NAME, "arith_expr", Context(1, 0))

# Generated at 2022-06-23 15:42:29.916358
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar
    g = grammar.Grammar("arith")
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.ENDMARKER, "", (2, 0))

# Generated at 2022-06-23 15:42:37.794657
# Unit test for constructor of class Parser
def test_Parser():
    import unittest
    import blib2to3.pgen2.grammar as grammar, blib2to3.pgen2.tokenize as tokenize

    class TestGrammar(grammar.Grammar):
        """A minimal test grammar."""

        def __init__(self) -> None:
            super().__init__(
                r"""
            start: t1 t2 t3
            t1: tok1 t3
            t2: tok2
            t3: TOK3
            """,
                [
                    ("TOK1", r"1"),
                    ("TOK2", r"2"),
                    ("TOK3", r"3"),
                ],
            )

    class ParserTestCase(unittest.TestCase):
        """Unit test for the Parser class."""


# Generated at 2022-06-23 15:42:39.339741
# Unit test for method pop of class Parser
def test_Parser_pop():
    Parser.pop(1)

# Generated at 2022-06-23 15:42:50.636019
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    # The grammar that will be tested -- very simple, just two productions
    grammar_str = b"""
$start: a
a: NUMBER
NUMBER: /[0-9]*([.][0-9]*)?/
"""

    # Method that will be passed as the second argument to the constructor
    def convert(grammar, node):
        type, value, ctx, children = node
        if children:
            # Return a tuple for the arguments of method Node
            return type, children, ctx
        # Return the original node
        else:
            return node

    # Fuzzy tests :

    # This is the list of test cases

# Generated at 2022-06-23 15:43:03.148184
# Unit test for method shift of class Parser
def test_Parser_shift():
    import pprint

    grammar = Grammar()
    test_Parser_shift.convert_called = 0

    def convert(grammar, node):
        test_Parser_shift.convert_called += 1
        return node

    def raise_ParseError():
        raise ParseError("fail", None, None, None)

    p = Parser(grammar, convert)
    p.setup()

    dfa = [
        [(0, 0), (1, 1)],
        [(2, 4)],
        [(0, 3), (2, 2)],
        [(0, 4)],
        [(0, 0), (1, 1), (3, 5)],
        [(4, 4)],
    ]
    p.stack[0] = (dfa, 0, ([], None, None, []))

# Generated at 2022-06-23 15:43:09.040813
# Unit test for constructor of class Parser
def test_Parser():
    import unittest

    class ParserTest(unittest.TestCase):

        def setUp(self):
            self.x = Parser(None, None)
            self.assertFalse(hasattr(self.x, 'dfa'))

        def test_setup(self):
            self.x.setup()
            self.assertTrue(hasattr(self.x, 'dfa'))

    unittest.main()

# Generated at 2022-06-23 15:43:17.722245
# Unit test for method classify of class Parser
def test_Parser_classify():
    import io
    import sys
    import blib2to3.pgen2.pgen

    def test_parse(grammar, input):
        """Parse the input string, return the AST."""
        parser = blib2to3.pgen2.pgen.make_parser(grammar)
        return parser.parse(input, sys.stdin.encoding)

    x = "\nimport re\nx=0\n"
    ast = test_parse("Grammar.txt", x)
    print(ast)

# Generated at 2022-06-23 15:43:25.143204
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    class NoNameContext(Context):
        def __init__(self, *args):
            pass

    class DummyGrammar(object):
        tokens = {
            token.NUMBER: 0,
            token.NAME: 1,
            token.STRING: 2,
            token.NEWLINE: 3,
            token.INDENT: 4,
            token.DEDENT: 5,
        }
        keywords = {
            "if": 6,
            "elif": 7,
            "else": 8,
        }

# Generated at 2022-06-23 15:43:34.638756
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.token import Token

    class FakeGrammar:
        class Dummy:
            pass

        labels = Dummy()
        labels.labels = {
            1: (
                Token.LBRACE,
                None,
            ),
            2: (
                Token.RBRACE,
                None,
            ),
        }
        tokens = Dummy()
        tokens.tokens = {}

    class FakeConvert(Callable[[Any, RawNode], Optional[NL]]):
        def __call__(self, *args, **kwargs) -> None:
            pass

    class FakeContext(Context):
        pass

    parser = Parser(FakeGrammar(), FakeConvert())
    parser.setup(1)

# Generated at 2022-06-23 15:43:35.789391
# Unit test for constructor of class Parser
def test_Parser():
    pass

# Generated at 2022-06-23 15:43:47.307965
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest
    import sys
    # I would like to import the previous parser in a test, but
    # I don't know how to do.

    class ParserTestCase(unittest.TestCase):
        def test_shift(self):
            p = Parser(Grammar())
            p.setup()
            p.shift(token.NAME, "VALUE", 0, Context(0, 0))
            self.assertEqual(p.stack, [(p.grammar.dfas[p.grammar.start], 0, (1, None, None, [Leaf(token.NAME, "VALUE", Context(0, 0))]))])
    
    unittest.main("blib2to3.pgen2.parser", verbosity=2, exit=False)
    # The one in PyPy is not exhaustive, so

# Generated at 2022-06-23 15:43:51.088129
# Unit test for constructor of class Parser
def test_Parser():
    from . import driver

    with open("Grammar.txt", "r") as f:
        contents = f.read()
    gr = driver.load_grammar(contents)
    p = Parser(gr)
    del p



# Generated at 2022-06-23 15:43:58.141333
# Unit test for method classify of class Parser
def test_Parser_classify():
    """This tests the classify method of the Parser class
    by  creating a parser and passing it the generate_grammar function
    object.

    """
    from . import driver

    parser = Parser(driver.generate_grammar())
    assert parser.classify(token.DOUBLESTAR, "**", 0) == driver.N_OP
    assert parser.classify(token.DOUBLESLASH, "//", 0) == driver.N_OP
    assert parser.classify(token.EQUAL, "=", 0) == driver.N_OP
    assert parser.classify(token.NAME, "test", 0) == driver.N_NAME
    assert parser.classify(token.NEWLINE, None, 0) == driver.N_NEWLINE



# Generated at 2022-06-23 15:44:09.502374
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    my_grammar = grammar.Grammar(grammar_str)
    parser = Parser(my_grammar)
    assert parser.classify(token.NAME, 'x', None) == 0
    assert parser.classify(token.PLUS, None, None) == 1


# Test data
grammar_str = """
# Sample grammar

start: expr
expr: term ('+' term)*
term: factor ('*' factor)*
factor: name | number
number: '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '0'
name: 'x' | 'y' | 'z'
"""

test_data = """\
x + y * z
"""

# Generated at 2022-06-23 15:44:21.050185
# Unit test for method shift of class Parser
def test_Parser_shift():
    class Grammar2(Grammar):
        dfas: Dict[int, DFAS] = {
            1: (
                [
                    [(1, 1), (2, 3)],
                    [(2, 3)],
                    [(1, 3), (2, 3)],
                    [],
                ],
                set([1]),
            )
        }

        tokens = {1: 1, 2: 2}
        symbols = [1]
        start = 1

    class Dummy:
        def __init__(self, context, node):
            self.context = context
            self.node = node

    def sub(grammar, node):
        assert node[3] is not None
        return Dummy(node[2], node[3])

    parser = Parser(Grammar2(), sub)
    parser.setup()


# Generated at 2022-06-23 15:44:32.257160
# Unit test for method pop of class Parser
def test_Parser_pop():
    from tupy.driver import Driver
    from tupy.Typing import Type, TypeTemplate
    d = Driver(convert=None, print_tree=False) # type: Driver
    tupy_grammar = d.grammar
    p = Parser(tupy_grammar)
    p.setup()
    p.addtoken(token.NAME, "i", Context(1,1))
    p.addtoken(token.COLON, ":", Context(1,1))
    p.addtoken(token.NAME, "j", Context(1,1))
    p.addtoken(token.COLON, ":", Context(1,1))
    p.addtoken(token.NAME, "int", Context(1,1))

# Generated at 2022-06-23 15:44:41.859361
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from .token import INDENT, DEDENT, NAME, tokenize, tok_name
    from .pytree import Leaf, Node

    pygrammar = grammar.grammar
    p = Parser(pygrammar)
    p.setup()
    for type, value, line, column in tokenize("x = 1"):
        p.addtoken(type, value, Context(line, column))
    assert p.stack == []
    assert p.rootnode.type == FILE_INPUT
    assert p.rootnode.children == [
        Node(
            type=stmt,
            children=[Leaf(type=NAME, value="x", context=Context(1, 0)),],
            context=Context(1, 0),
        )
    ]

# Generated at 2022-06-23 15:44:54.298122
# Unit test for constructor of class Parser
def test_Parser():
    import unittest
    import blib2to3.pgen2.driver
    import blib2to3.pygram

    class Driver(blib2to3.pgen2.driver.Driver):
        def __init__(self) -> None:
            self.grammar = blib2to3.pygram.python_grammar
            self.convert = lam_sub

    class ParserTest(unittest.TestCase):
        def test_Parser(self) -> None:
            p = Parser(blib2to3.pygram.python_grammar)
            self.assertRaises(Exception, p.addtoken, 0, None, None)
            p.setup()
            self.assertRaises(Exception, p.converter, 0, None, [])

    unittest.main()

# Generated at 2022-06-23 15:45:01.911500
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar, tokenize

    # Test set up
    g = grammar.grammar
    driver = Parser(g)
    driver.setup()
    # State: 0; input:
    f = open("Grammar.txt", "rb")
    try:
        tokenize.tokenize(f.readline, driver.addtoken)
    finally:
        f.close()
    # end_state: 1; input:
    # Parse result:
    assert driver.rootnode is not None
    # Start state: 0



# Generated at 2022-06-23 15:45:12.223209
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import pgen
    import token
    g = pgen.ParserGenerator("a.g")
    g.add_token("a", "a", True)
    g.add_token("b", "b", True)
    g.add_token("c", "c", True)
    g.start("S")
    g.production("S", "S a S")
    g.production("S", "S b S")
    g.production("S", "S c S")
    g.production("S", "a")
    g.production("S", "b")
    g.production("S", "c")
    g.finish()
    p = Parser(g.grammar)
    p.setup()
    # a
    type = token.NAME
    value = "a"
    context = []


# Generated at 2022-06-23 15:45:15.938372
# Unit test for method setup of class Parser
def test_Parser_setup():
    """Test the setup method of the Parser class"""
    def test_Parser_setup_helper(
        grammar: Grammar,
        convert: Optional[Convert],
        start: int = None,
    ) -> None:
        p = Parser(grammar, convert)
        p.setup(start)

    grammar = Grammar()
    test_Parser_setup_helper(grammar, None, 0)
    test_Parser_setup_helper(grammar, lam_sub, 0)


# Generated at 2022-06-23 15:45:24.869695
# Unit test for method pop of class Parser
def test_Parser_pop():
    def lam_dfa(grammar, node):
        return node[-1]

    from . import graminit

    parser = Parser(graminit.grammar, lam_dfa)
    parser.setup()
    parser.addtoken(0, 'a', None)
    parser.addtoken(0, 'b', None)
    parser.addtoken(0, 'c', None)
    parser.addtoken(0, 'd', None)
    assert parser.rootnode == ['a', 'b', 'c', 'd']



# Generated at 2022-06-23 15:45:34.250592
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver

    # Get a parser
    grammar = driver.load_grammar("Grammar.txt")
    p = Parser(grammar)

    # Test for the following input
    input = (
        (token.NAME, "a", (1, 0)),
        (token.NEWLINE, "\n", (2, 0)),
        (token.NAME, "if", (3, 0)),
        (token.NEWLINE, "\n", (4, 0)),
        (token.NAME, "return", (5, 0)),
        (token.NEWLINE, "\n", (6, 0)),
        (token.NAME, "print", (7, 0)),
        (token.NEWLINE, "\n", (8, 0)),
    )
    # See what the right labels are

# Generated at 2022-06-23 15:45:35.539515
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    gr = grammar.Grammar()
    p = Parser(gr)
    p.setup()

# Generated at 2022-06-23 15:45:38.583236
# Unit test for method pop of class Parser
def test_Parser_pop():
    def dummy_convert(grammar, node):
        return node

    p = Parser(Grammar(), dummy_convert)
    try:
        p.pop()
        raise AssertionError("Expected IndexError")
    except IndexError:
        pass

# Generated at 2022-06-23 15:45:42.015331
# Unit test for constructor of class ParseError
def test_ParseError():
    exc: ParseError
    exc = ParseError("test", 1, "A", (1, 0))
    assert exc.msg == "test"
    assert exc.type == 1
    assert exc.value == "A"
    assert exc.context == (1, 0)

# Generated at 2022-06-23 15:45:45.409588
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test simple exception
    try:
        raise ParseError("", 0, "", 0)
    except ParseError:
        pass


# Generated at 2022-06-23 15:45:51.595262
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.pgen2.grammar, blib2to3.pgen2.parse
    g = blib2to3.pgen2.grammar.grammar
    g.load("./Python.gram")
    p = blib2to3.pgen2.parse.Parser(g)
    g.start = 'file_input'
    p.setup()
    p.addtoken(1, "esto", {"lineno": 1, "column": 5})

# Generated at 2022-06-23 15:45:59.162918
# Unit test for method setup of class Parser
def test_Parser_setup():
    # Test the setup() method of class Parser
    # XXX Doesn't test very much right now.
    p = Parser(Grammar())
    P = p.__class__
    # Call it before and after initialization
    f = p.setup
    f()
    p.setup()
    # Try with arguments
    f(1)
    f(1, 2)
    f(1, 2, 3)


# Generated at 2022-06-23 15:46:07.403232
# Unit test for constructor of class Parser
def test_Parser():
    from . import driver, pgen

    g = pgen.generate_grammar("test/test_grammar.txt")
    assert g.start == 256

# Generated at 2022-06-23 15:46:08.563202
# Unit test for method setup of class Parser
def test_Parser_setup():
    _default_constructor(Parser)

# Generated at 2022-06-23 15:46:18.708821
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import codecs
    from . import driver, token

    # Load the grammar.
    g = driver.load_grammar("Grammar.txt")

    # Load the input file.
    # There are two blank lines at the end that force a 3-token lookahead.

    with codecs.open("input", "r", "latin-1") as f:
        text = f.read()
    text = text.replace("\r\n", "\n")

    # Create a tokenizer for the grammar.
    driver.tokenize_lines(text, g)

    # Create a parser and feed it all the tokens.
    p = Parser(g)
    p.setup()
    while True:
        type, value, context = driver.get_last_token()

# Generated at 2022-06-23 15:46:29.436454
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar

    # A trivial grammar for testing
    GRAMMAR1 = grammar.Grammar(
        start="start",
        dfas={
            "start": ([[(2, 1), (1, 1)], [(0, 2)]], {1: 1, 2: 2}),
            "name": ([[(2, 1), (1, 1)], [(0, 2)]], {1: 1, 2: 2}),
        },
        labels=[
            (257, "NAME"),
            (258, "NUMBER"),
            (259, "start"),
            (260, "name"),
        ],
        tokens={257: 2, 258: 2},
        keywords={},
    )

    p = Parser(GRAMMAR1)
    p.setup()  # prepare for parsing
    assert not p.addtoken

# Generated at 2022-06-23 15:46:35.385648
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar(r"""
    x : foo ;
    foo : bar ;
    bar : ID ;
    """)
    p = Parser(g)
    p.setup()
    assert p.addtoken(token.ID, "1", (0, 0))
    assert p.rootnode.type == grammar.symbol("x")

# Generated at 2022-06-23 15:46:45.167226
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import tokenize, untokenize

    from . import grammar, symbols, driver

    # Build a simple example grammar
    g = grammar.Grammar()
    g.symbol2number = symbols.sym_name
    g.symbol2label = symbols.sym_name
    g.symbol2label[0] = 'EOF'
    # Nonterminals
    g.add_symbol("start", 256)
    g.add_symbol("expr", 257)
    g.add_symbol("term", 258)
    # Terminals
    g.add_symbol("PLUS", token.PLUS)
    g.add_symbol("STAR", token.STAR)
    g.add_symbol("NUMBER", token.NUMBER)
    g.add_symbol("NAME", token.NAME)
    #

# Generated at 2022-06-23 15:46:47.836567
# Unit test for method push of class Parser
def test_Parser_push():
    # parse.Parser.push is not tested because it is not used by mypy and I could not
    # modify it to make it run without errors
    raise RuntimeError("test failed")

# Generated at 2022-06-23 15:46:58.044682
# Unit test for function lam_sub
def test_lam_sub():
    from . import symbol, token

    # Construct a dummy grammar for use in this test
    grammar = Grammar()
    grammar.start = symbol.expr
    grammar.labels[token.NAME] = (token.NAME, None)
    grammar.labels[token.NUMBER] = (token.NUMBER, None)
    grammar.labels[token.PLUS] = (token.PLUS, None)
    grammar.labels[symbol.expr] = (symbol.expr, None)
    grammar.labels[symbol.term] = (symbol.term, None)
    # Construct a dummy concrete syntax tree
    cst = (symbol.expr, 1, (2, 3), [(symbol.term, 1, (4, 5), [(token.NAME, 6)])])
    # Convert it
    ast = lam_sub

# Generated at 2022-06-23 15:47:04.129523
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2.grammar import grammar

    grammar.parse_grammar(grammar.start)
    p = Parser(grammar, lam_sub)
    p.setup()
    assert p.stack == [
        (
            ([], {0: 0}),
            0,
            (13, None, None, []),
        )
    ]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-23 15:47:14.314228
# Unit test for function lam_sub
def test_lam_sub():
    import pgen2.grammar
    g = pgen2.grammar.Grammar()
    g.symbol2number = {'SYM': 1}
    g.number2symbol = {1: 'SYM'}
    t = (1, None, None, [(3, 'foo', None, None), (4, 'bar', None, None)])
    u = lam_sub(g, t)
    assert u.type == 1
    assert u.value is None
    assert u.context is None
    assert u.children == [Leaf(3, 'foo', None), Leaf(4, 'bar', None)]
    t = (1, None, (2, 3), [])
    u = lam_sub(g, t)
    assert u.type == 1
    assert u.value is None
    assert u

# Generated at 2022-06-23 15:47:24.957781
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    class FakeGrammar(grammar.Grammar):
        def __init__(self) -> None:
            self.tokens: Dict[int, int] = dict()

    g = FakeGrammar()
    g.tokens[100] = 1
    g.tokens[101] = 2
    p = Parser(g)
    assert p.classify(100, None, None) == 1
    assert p.classify(101, None, None) == 2
    try:
        p.classify(102, None, None)
    except ParseError:
        pass
    else:
        raise Exception("expected a ParseError")


# Generated at 2022-06-23 15:47:29.583545
# Unit test for method setup of class Parser
def test_Parser_setup():
    import doctest
    from . import driver
    from . import grammar
    from . import parse

    g = grammar.grammar
    p = Parser(g, parse.convert)
    p.setup()

    # Test a subset of the doctests for grammar module
    import doctest
    count, _ = doctest.testmod(driver)
    count, _ = doctest.testmod(grammar)


# Generated at 2022-06-23 15:47:39.032530
# Unit test for method setup of class Parser

# Generated at 2022-06-23 15:47:45.896812
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test unit for constructor of class ParseError"""
    msg = "Error for ParseError"
    type = 1
    value = "aa"
    context = Context("C", "D", 123, 456)
    parse_error = ParseError(msg, type, value, context)
    assert parse_error.msg == msg
    assert parse_error.type == type
    assert parse_error.value == value
    assert parse_error.context == context


# Generated at 2022-06-23 15:47:54.400731
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser = Parser(Grammar(1))

    # when popnode is None
    popnode = None
    parser.stack = [(1, 2, 3)]
    parser.convert = None
    parser.rootnode = None
    parser.pop()
    assert parser.rootnode == 3

    # when popnode isn't None
    popnode = (1, 2, 3, 4, 5)
    newnode = (4, 5, 6, 7)
    parser.stack = [(1, 2, 3)]
    parser.convert = None
    parser.rootnode = None
    parser.pop()
    assert parser.rootnode == (1, 2, 3, 4, 5)

    # when popnode isn't None and convert returns value
    parser.stack = [(1, 2, 3)]

# Generated at 2022-06-23 15:47:58.777888
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('test', 'blah', 'value', 'context')
    except ParseError as e:
        assert e.msg == 'test'
        assert e.type == 'blah'
        assert e.value == 'value'
        assert e.context == 'context'

# Generated at 2022-06-23 15:48:01.109932
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    p = driver.Driver().parser
    p.setup()



# Generated at 2022-06-23 15:48:12.068155
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Unit test for method classify of class Parser"""
    # Tests for Parser class and method classify
    from os import path
    from .api import driver
    from . import grammar

    basename = "1_2-2.7"
    # Fullpath to the directory where this module resides.
    this_dir = path.abspath(path.dirname(__file__))
    # Fullpath to the directory containing the grammar files.
    grammar_dir = path.join(this_dir, "../..")
    # Fullpath to the directory containing the test data files.
    data_dir = path.join(this_dir, "..")
    # Fullpath to the file containing the Python 1.5 grammar.
    grammar_file = path.join(grammar_dir, basename + ".txt")
    # Fullpath to the file containing the

# Generated at 2022-06-23 15:48:14.768653
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2.driver import Driver
    driver = Driver(convert=lam_sub)
    p = Parser(driver.grammar)
    assert p



# Generated at 2022-06-23 15:48:20.159495
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.grammar
    import blib2to3.pgen2.parse

    g = blib2to3.pgen2.grammar.Grammar(
        """
        start:
            NAME NAME
        """
    )
    p = blib2to3.pgen2.parse.Parser(g)

    assert p.classify(token.NAME, "a", None) == 1
    assert p.classify(token.NAME, "a", None) == 1

if __name__ == "__main__":
    test_Parser_classify()

# Generated at 2022-06-23 15:48:23.635259
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("foo", 1, "one", "two")
    assert e.msg == "foo"
    assert e.type == 1
    assert e.value == "one"
    assert e.context == "two"

# Generated at 2022-06-23 15:48:30.762758
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError(
            "test",
            type=2,
            value="value",
            context=((token.INDENT, 0), token.ERRORTOKEN, (token.DEDENT, 0)),
        )
    except ParseError as e:
        assert e.msg == "test"
        assert e.type == token.ERRORTOKEN
        assert e.value == "value"
        assert e.context == ((token.INDENT, 0), (token.ERRORTOKEN, 0), (token.DEDENT, 0))
    else:
        assert False, "did not raise ParseError"

# Generated at 2022-06-23 15:48:32.964190
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser(None)  # Just test that the constructor accepts a None argument
    assert not Parser(None).stack  # and that it initializes properly

# End of unit test

# Generated at 2022-06-23 15:48:35.830251
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError('msg', 1, 'value', 'context')
    assert exc.msg == 'msg'
    assert exc.type == 1
    assert exc.value == 'value'
    assert exc.context == 'context'


# Generated at 2022-06-23 15:48:40.293663
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Unit test for method classify of class Parser"""
    import blib2to3.pgen2.grammar as grammar
    p = Parser(grammar.grammar, None)
    p.setup()
    try:
        p.classify(token.NAME, "name", None)
    except ParseError:
        pass
    else:
        raise AssertionError("Expecting exception")



# Generated at 2022-06-23 15:48:43.967472
# Unit test for constructor of class Parser
def test_Parser():
    g = Grammar()
    p = Parser(g)
    assert p.grammar is g
    assert p.convert is g.convert
    class MyNode(object):
        pass

    def convert(grammar, node):
        n = MyNode()
        n.node = node
        return n

    p = Parser(g, convert)
    assert p.convert is convert

# Unit tests for class Parser

# Generated at 2022-06-23 15:48:45.146115
# Unit test for method setup of class Parser
def test_Parser_setup():
    pass


# Generated at 2022-06-23 15:48:48.952946
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("foo", None, None, (1, 2))
    assert error.msg == "foo"
    assert error.type is None
    assert error.value is None
    assert error.context == (1, 2)

# Generated at 2022-06-23 15:48:58.706410
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar(
        """
    input: charlist
    charlist: charlist char | NL
    char: 'A' | 'B' | 'a' | 'b'
    """
    )
    p = Parser(g)
    p.setup()
    p.addtoken(g.symbol2number["'a'"] + 256, "a", (1, 0))
    p.addtoken(g.symbol2number["NL"] + 256, "b", (1, 0))
    p.addtoken(g.symbol2number["'b'"] + 256, "b", (1, 0))
    assert p.rootnode is not None



# Generated at 2022-06-23 15:49:01.148957
# Unit test for method setup of class Parser
def test_Parser_setup():
    from .pgen2 import driver as dr
    result = dr.parse_file(__file__, 'exec')
    assert result == 1

# Generated at 2022-06-23 15:49:09.924000
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    s = """while True:
        pass"""

    class driver:
        def __init__(self, s: Text) -> None:
            self.string = s
            self.pos = 0

        def get_token(self) -> Tuple[int, Text, Context]:
            from blib2to3.pgen2.tokenize import generate_tokens, TokenInfo

            for type, value, start, end, state, context in generate_tokens(self.token):
                yield TokenInfo(type, value, start, end, state, context)

            yield TokenInfo(token.ENDMARKER, "", (0, 0), (0, 0), 0, "")

        def token(self) -> Text:
            s = self.string
            i = self.pos
            j = s.find("\n", i)


# Generated at 2022-06-23 15:49:17.016010
# Unit test for constructor of class Parser
def test_Parser():
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.token as token

    g = grammar.grammar
    p = Parser(g)

    p.addtoken(token.NUMBER, "1", (0, "", 0, 0))
    p = Parser(g)
    p.addtoken(token.NAME, "print", (0, "", 0, 0))

# Generated at 2022-06-23 15:49:28.697247
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Function to test addtoken of class Parser
    def test_Parser_addtoken(
        grammar: Grammar, p: Parser, type: int, value: Optional[Text], context: Context
    ) -> None:
        p.setup()
        while True:
            # Keep adding tokens until no more input
            try:
                if p.addtoken(type, value, context):
                    break
            except ParseError as err:
                print(err)
                break
        print("p.rootnode =", p.rootnode)

    from . import driver
    from .token import *

    def demo_convert(grammar: Grammar, node: RawNode) -> Optional[NL]:
        type, value, context, kids = node

# Generated at 2022-06-23 15:49:36.050846
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar, token

    g = grammar.Grammar()
    p = Parser(g)
    assert p.grammar is g
    assert p.convert
    p = Parser(g, lam_sub)
    assert p.grammar is g
    assert p.convert is lam_sub
    try:
        p = Parser(g, "foo")
    except TypeError:
        pass
    else:
        assert 0, "expected TypeError"



# Generated at 2022-06-23 15:49:43.509459
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import tokenize
    from . import driver
    from . import grammar
    from . import pygram
    from .parse import Parser

    p = Parser(pygram.python_grammar, driver.convert)
    # Create a fake Python "file"
    tokengen = tokenize.generate_tokens(
        iter(["x=1"]).__next__
    )  # type: ignore
    # Set up parser
    p.setup()
    # Fill p.stack
    for token in tokengen:
        if token.type == tokenize.ENDMARKER:
            break
        tokentype = token.type
        if tokentype == tokenize.OP and token.string == "=":
            tokentype = token.exact_type

# Generated at 2022-06-23 15:49:44.644893
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = None #type: Any
    p.setup()

# Generated at 2022-06-23 15:49:55.357002
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .tokenize import generate_tokens
    from .grammar import Grammar
    from .pgen import driver
    from . import token

    from . import parse

    driver.parse_grammar(parse.grammar, parse.grammar_name)
    p = parse.Parser(parse.grammar)
    p.setup()

    tokens = generate_tokens(open('/tmp/blib2to3/tests/data/test_grammar.py').readline)
    tokens = [(t[0], t[1], Context(t[2], t[3])) for t in tokens]
    while tokens:
        tok = tokens.pop(0)
        if p.addtoken(tok[0], tok[1], tok[2]):
            break
    
    p.pop()

# Generated at 2022-06-23 15:50:05.307252
# Unit test for method pop of class Parser
def test_Parser_pop():
    class MyGrammar:
        def __init__(self):
            self.start = 256
            self.dfas = {256: ([[(0, 1)], [(0, 1)], [(0, 1), (0, 1)]], {1: 0}), 257: ([], {})}
            self.labels: Dict[int, Tuple[int, Text]] = {
                0: (0, None),
                1: (1, None),
                2: (2, None),
            }

    class MyConvert:
        def __init__(self):
            self.converted = []

        def __call__(
            self, grammar: Grammar, node: RawNode
        ) -> Union[Node, Leaf]:
            self.converted.append(node)
            return node


# Generated at 2022-06-23 15:50:09.109177
# Unit test for constructor of class Parser
def test_Parser():
    from . import grammar
    from . import driver

    g = grammar.Grammar(grammar.parse(driver.GRAMMAR))
    p = Parser(g)
    assert p.grammar is g
    assert p.convert is lam_sub

# Generated at 2022-06-23 15:50:21.797450
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.tokenize as tokenize
    from blib2to3.pygram import python_grammar

    # Get the grammar
    # This is the same grammar we use for the tokenizer,
    # so we use it for the parser too.
    grammar = python_grammar

    # Create parser and feed it some input
    p = Parser(grammar)
    p.setup()
    input = "a = b + c\ndef f(x): return x + 1\n"
    for type, value, context in tokenize.generate_tokens(input):
        p.addtoken(type, value, context)

    # Check the result
    import blib2to3.pgen2.driver as driver
    root = driver.parse_string(input, python_grammar)
   

# Generated at 2022-06-23 15:50:35.044875
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2.grammar import Symbol, Alternative, Sequence, \
        OneOrMore, Optional, ZeroOrMore
    from blib2to3.pgen2.token import Token
    grammar = Grammar(None, None, None, None, None)
    grammar.symbol2number = {
        "foo": 0, "bar": 1, "baz": 2, "spam": 3, "eggs": 4, "cheese": 5, "ham": 6
    }
    grammar.number2symbol = {
        0: "foo", 1: "bar", 2: "baz", 3: "spam", 4: "eggs", 5: "cheese", 6: "ham"
    }
    grammar.start = "start"
    foo = Symbol("foo", (0,3))