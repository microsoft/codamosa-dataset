

# Generated at 2022-06-23 15:40:42.035795
# Unit test for method pop of class Parser
def test_Parser_pop():

    from .pgen2 import pgen
    from .token import NAME
    from . import pytree

    gram = pgen.driver.load_grammar(
        "Python.asdl", "grammar_nt.pickle", "grammar_pk.pickle"
    )

    par = Parser(gram, pytree.convert)
    par.setup()
    par.addtoken(NAME, "MOD_NAME", pytree.PythonNode)
    par.addtoken(NAME, "FUNC_NAME", pytree.PythonNode)
    par.addtoken(NAME, "PARAM_NAME", pytree.PythonNode)
    par.pop()
    par.pop()



# Generated at 2022-06-23 15:40:49.825250
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = Grammar(
        """
        start: FILE_INPUT ENDMARKER
        FILE_INPUT: ( stmt | NEWLINE )* ENDMARKER
        stmt: pass_stmt
        pass_stmt: PASS

        NEWLINE: /[ \\t\\n]+/
        PASS: 'pass'
        ENDMARKER: 'END'
        """
    )
    parser = Parser(grammar)

    parser.setup()
    for s in "pass END END".split():
        parser.addtoken(token.NAME, s, None)

    # Check that the parser recognized the keywords
    assert parser.used_names == set()

# Generated at 2022-06-23 15:41:00.813678
# Unit test for function lam_sub
def test_lam_sub():
    import blib2to3.pgen2.driver
    from blib2to3.pygram import python_symbols

    grammar = blib2to3.pgen2.driver.load_grammar("Grammar.txt")
    parser = Parser(grammar, lam_sub)
    parser.setup(start=python_symbols.file_input)
    parser.addtoken(token.STRING, '"hi"', None)
    parser.addtoken(token.NEWLINE, "\n", None)
    parser.addtoken(0, "", None)
    assert len(parser.rootnode) == 2
    s = parser.rootnode[1]
    assert isinstance(s, Leaf)
    assert s.value == '"hi"'


# Generated at 2022-06-23 15:41:04.703975
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", token.NAME, "value", (1, 1))
    except ParseError as e:
        assert e is not None


# Generated at 2022-06-23 15:41:08.582528
# Unit test for constructor of class Parser
def test_Parser():
    class FakeGrammar(object):
        pass

    grammar = FakeGrammar()
    p = Parser(grammar)
    assert p.grammar is grammar
    assert p.stack == []
    assert p.rootnode is None
    assert p.used_names == set()

# Generated at 2022-06-23 15:41:14.857023
# Unit test for method pop of class Parser
def test_Parser_pop():
    import unittest
    from pgen2.tokenize import generate_tokens

    class ParseError(RuntimeError):
        """An exception to signal the parser is stuck."""

    grammar = Grammar(generate_tokens)
    parser = Parser(grammar)
    parser.setup()
    for msg in [
        "pop: There was nothing to pop",
        "pop: There was nothing to pop (after 2 shifts)",
        "pop: There was nothing to pop (after 10 shifts)",
        "pop: There was nothing to pop (after 20 shifts)",
    ]:
        def test(value):
            parser.addtoken(token.STRING, value, Context(1, 0))

        with unittest.assertRaisesRegex(ParseError, msg):
            test('"single quoted string"')

# Generated at 2022-06-23 15:41:26.978547
# Unit test for method setup of class Parser
def test_Parser_setup():
    from io import StringIO
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2.parse import parse_grammar
    from blib2to3.pgen2.grammar import Grammar

    driver = Driver(StringIO(grammar_file), convert)
    g = parse_grammar(driver, "main", debug=False)
    p = Parser(g)
    p.setup()
    # print p.grammar
    # print repr(p.stack)
    # print repr(p.rootnode)
    assert isinstance(p.grammar, Grammar)
    assert p.stack == [(p.grammar.dfas[324], 0, (324, None, None, []))]
    assert p.rootnode is None


# Generated at 2022-06-23 15:41:28.486781
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("hi!", 1, "x", (1, 2))
    assert pe.msg == "hi!"
    assert pe.type == 1
    assert pe.value == "x"
    assert pe.context == (1, 2)

# Generated at 2022-06-23 15:41:31.083968
# Unit test for constructor of class Parser
def test_Parser():
    grammar = Grammar("", {}, {}, {}, {}, {})
    test = Parser(grammar)
    assert test.grammar is grammar
    assert test.convert is lam_sub


# Generated at 2022-06-23 15:41:34.446278
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2.grammar import load_grammar

    grammar = load_grammar(args=(__file__,))
    grammar.classify_symbol(token.NAME)
    # Test the method __init__
    p = Parser(grammar)
    p.setup()

# Generated at 2022-06-23 15:41:47.749348
# Unit test for method push of class Parser
def test_Parser_push():
    import blib2to3.pgen2.driver
    myDRIVER = blib2to3.pgen2.driver
    import blib2to3.pgen2.token
    myTOKEN = blib2to3.pgen2.token
    import blib2to3.pgen2.grammar
    myGRAMMAR = blib2to3.pgen2.grammar
    myPARSER = Parser
    myNODE = Node
    myCONVERT = lam_sub
    myGRAMMAR1 = myGRAMMAR.Grammar(myGRAMMAR.grammar, myGRAMMAR.syms, myGRAMMAR.labels)
    myPARSER1 = myPARSER(myGRAMMAR1, myCONVERT)
    myDFAS = myGRAMMAR.dfas

# Generated at 2022-06-23 15:41:57.631321
# Unit test for method shift of class Parser
def test_Parser_shift():
    g = Grammar()
    # So, we need to create a "Grammar" instance and a "Parser" instance
    # to test the "shift()" method.
    # I'm just doing a minimal "Grammar" instance here and
    # a "Parser" instance with default value.
    # Because we are only testing the "shift()" method,
    # it doesn't matter what we put into the "Parser" instance.
    p = Parser(g)
    # "type" and "value" can be anything.
    type = 2
    value = "abc"
    # "context" also can be anything.
    # Here I just created a "Context" object with an empty filename.
    context = Context('', 0)
    newstate = 1
    # Assume we are not in an accepting state.
    # So, there's

# Generated at 2022-06-23 15:42:10.035474
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = Grammar(
        [
            "",
            "a",
            "A: 'a'",
            "B: 'b'",
            "C: 'c'",
            "X: 'x'",
            "Y: 'y'",
            "_A: 'a'",
            "_B: 'b'",
            "_C: 'c'",
            "_X: 'x'",
            "_Y: 'y'",
            "S: A B C",
            "_S: _A _B _C",
            "S: A B C X Y",
            "_S: _A _B _C _X _Y",
        ]
    )
    parser = Parser(grammar)

    parser.setup()
    parser.push(10, grammar.dfas[10], 0, None)
   

# Generated at 2022-06-23 15:42:19.110859
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    def test(symbols: Sequence[Tuple[int, str, Any, Optional[Text]]]) -> Parser:
        dfa = [
            [
                (grammar.labels["ID"], 1),
                (grammar.labels["+"], 2),
            ],
            [(0, 1)],
            [(0, 2)],
        ]
        dfas = {
            "file_input": (dfa, {0: 0, 1: 0, 2: 0})
        }
        tokens = {grammar.terminals["ID"]: 0, grammar.terminals["+"]: 1}
        start = "file_input"
        g = grammar.Grammar(dfas, tokens, symbols, start)
        p = Parser(g)
        p.setup()
        return p

   

# Generated at 2022-06-23 15:42:30.431096
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import pgen

    def prepare(grammar: Grammar) -> Parser:
        p = Parser(grammar)
        p.setup()
        return p

    def test(input: Text, expected: Sequence[Sequence[int]]) -> None:
        tokens = driver.tokenize(input)
        grammar = pgen.buildGrammar("".join(t.value for t in tokens))
        p = prepare(grammar)
        for t in tokens:
            p.addtoken(t.type, t.value, t.context)
        if p.rootnode is None:
            assert not expected
        else:
            assert [(n.type, len(n.children)) for n in p.rootnode.children] == expected


# Generated at 2022-06-23 15:42:38.012581
# Unit test for method push of class Parser
def test_Parser_push():
    # data for the test
    grammar = Grammar()
    type = grammar.tokens.get(token.NAME)
    value = "name"
    context = Context(0, 0)
    newdfa = grammar.dfas.get(type)
    newstate = 0

    # push a nonterminal
    def push1(type, newdfa, newstate, context):
        parser = Parser(grammar)
        parser.push(type, newdfa, newstate, context)
        return parser.stack

    # push a token
    def push2(type, value, newstate, context):
        parser = Parser(grammar)
        parser.push(type, newdfa, newstate, context)
        parser.shift(type, value, newstate, context)
        return parser.stack

    # the stack

# Generated at 2022-06-23 15:42:49.893922
# Unit test for function lam_sub
def test_lam_sub():
    import sys
    import blib2to3.pgen2.token as token
    from blib2to3.pgen2 import driver

    gram = driver.load_grammar("Grammar.txt")
    parser = Parser(gram)
    parser.setup()
    parser.addtoken(token.NAME, "a", Context(1, 0))
    parser.addtoken(token.PLUS, "+", Context(1, 2))
    parser.addtoken(token.NAME, "b", Context(1, 4))
    parser.addtoken(token.NEWLINE, "", Context(1, 5))
    parser.addtoken(token.ENDMARKER, "", Context(1, 6))
    ast = parser.rootnode
    print(ast)
    assert ast.type == gram.symbol2number["file_input"]

# Generated at 2022-06-23 15:42:59.082313
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver, grammar, tokenize

    # Create a grammar
    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", ("NEWLINE | stmt",))
    g.add_nonterminal("stmt", ("expr",))
    g.add_nonterminal("expr", ("NUMBER",))
    g.add_terminal("NUMBER", token.NUMBER)
    g.add_terminal("NEWLINE", token.NEWLINE)
    g.build()

    # Create a driver
    d = driver.Driver(g, convert=lam_sub)

    # Create a parser
    p = Parser(g, convert=lam_sub)

    p.setup(start="expr")

# Generated at 2022-06-23 15:43:06.262206
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2 import (
        generate_grammar,
    )

    # Use the grammar's "syntax" attribute to define a special addnode
    # function to convert a node to a leaf
    def addnode(grammar: Grammar, node: RawNode) -> Union[Node, Leaf]:
        if node[0] == grammar.syntax:
            return Leaf(node[1], node[2])
        else:
            assert node[3] is not None
            return Node(type=node[0], children=node[3], context=node[2])

    # Generate a grammar for the Python language
    grammar = generate_grammar()

    # Create a Parser instance
    parser = Parser(grammar, addnode)

    # Prepare for parsing
    parser.setup()

    # See the driver.

# Generated at 2022-06-23 15:43:18.562738
# Unit test for method pop of class Parser
def test_Parser_pop():
    class TestConvert:
        def __init__(self):
            self.parent = None

        def __call__(self, grammar, node):
            type, value, context, children = node
            if type != 1:
                return None
            else:
                return TestConvert()

    class TestGrammar:
        def __init__(self):
            self.labels = {1: (1, "1"), 2: (2, "2")}
            self.dfas = {1: (DFA([[(1, 0)], [(1, 1), (2, 0)]], set([(0, 1)])), 0)}

    parser = Parser(TestGrammar(), TestConvert())
    parser.setup()
    parser.addtoken(1, "1", None)

# Generated at 2022-06-23 15:43:23.844992
# Unit test for method shift of class Parser
def test_Parser_shift():
    import pprint
    from blib2to3.pgen2 import driver
    p = driver.make_parser()
    p.setup()
    # Hardwired for parsing a string of 'f', '(' and ')'
    p.shift(token.NAME, 'f', 3, (1, 0))
    p.shift(token.OP, '(', 0, (1, 1))
    p.shift(token.OP, ')', 0, (1, 2))
    p.pop()
    assert p.rootnode == Node(
        symbol="fpdef",
        children=[Leaf(type=token.NAME, value="f", context=(1, 0))],
        context=None,
    )
    p.push(token.NAME, None, None, None)

# Generated at 2022-06-23 15:43:31.543992
# Unit test for method push of class Parser
def test_Parser_push():

    class MyParser(Parser):
        def __init__(self):
            self.stack = []

    p = MyParser()
    p.push(256, ('ALPHABET', 'BRAVO', 'CHARLIE', 'DELTA'), 0, 'CONTEXT')
    assert p.stack == [((('ALPHABET', 'BRAVO', 'CHARLIE', 'DELTA'),
                         {0: [(0, 0)]}),
                        0,
                        (256, None, 'CONTEXT', []))], \
        f"p.stack={p.stack!r}"

# Generated at 2022-06-23 15:43:43.415110
# Unit test for method setup of class Parser
def test_Parser_setup():
    # From Lib/test/test_parser.py
    import unittest
    import tokenize
    from TokenClassifier import TokenClassifier

    class TestParser(unittest.TestCase):
        def test_grammar_attributes(self):
            from blib2to3.pgen2 import parse
            self.assertTrue(hasattr(parse, "grammar"))
            self.assertTrue(hasattr(parse.grammar, "start"))
            self.assertTrue(hasattr(parse.grammar, "keywords"))
            self.assertTrue(hasattr(parse.grammar, "tokens"))

        def test_parse_partial(self):
            from blib2to3.pgen2 import parse
            parser = Parser(parse.grammar, parse.convert)
            parser.setup()
            tokens = list

# Generated at 2022-06-23 15:43:54.325704
# Unit test for method setup of class Parser
def test_Parser_setup():
    test_locals = locals()
    test_locals['Call'] = Call
    test_locals['Token'] = Token
    test_locals['Nonterminal'] = Nonterminal
    test_locals['number2symbol'] = number2symbol

# Generated at 2022-06-23 15:44:00.134308
# Unit test for method push of class Parser

# Generated at 2022-06-23 15:44:10.267004
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import pprint
    from blib2to3.pgen2.parse import Driver
    from blib2to3.pgen2 import tokenize
    from . import token, grammar

    def usage():
        print("Usage: python3 -m blib2to3.pgen2.parser test_Parser_addtoken [<filename>]")
        sys.exit(1)

    if len(sys.argv) != 2:
        usage()
    if sys.argv[1] == "-":
        filename = "<stdin>"
        f = sys.stdin
    else:
        filename = sys.argv[1]
        try:
            f = open(filename, "rU")
        except IOError:
            print("Cannot open {0}".format(filename))
            sys.exit(2)


# Generated at 2022-06-23 15:44:21.126934
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar(token)
    p = Parser(grammar)
    p.setup()

    node_1 = (4, None, None, [])
    node_2 = (3, None, None, [])
    node_3 = (token.NAME, "a", None, [])

    nodes_1 = []
    nodes_1.append(node_2)

    node_1[-1] = nodes_1
    assert node_1[-1] is not None
    assert node_1[-1] == [node_2]

    nodes_2 = []
    nodes_2.append(node_3)

    node_2[-1] = nodes_2
    assert node_2[-1] is not None
    assert node_2[-1] == [node_3]

    p.stack

# Generated at 2022-06-23 15:44:32.349014
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.translate import fixers, refactor
    import blib2to3.pgen2.driver
    valid_grammar = blib2to3.pgen2.driver.load_grammar("Python3.grammar")
    valid_fixers = fixers.get_fixers_from_package(fixers.__name__)
    fixer_names = {fixer.name for fixer in valid_fixers}
    valid_refactorings = refactor.get_refactors_from_package(refactor.__name__)
    refactor_names = {refactoring.name for refactoring in valid_refactorings}
    assert fixer_names == set(valid_grammar.keywords)
    assert refactor_names == set(valid_grammar.keywords)


test_

# Generated at 2022-06-23 15:44:37.806555
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2 import tokenize, driver

    gram = driver.load_grammar('python2')
    tok = tokenize.generate_tokens(driver.string_to_file("x"))
    parse = Parser(gram)
    parse.setup()
    for toktype, t, s, e, line in tok:
        if parse.addtoken(toktype, t, s):
            break

# Generated at 2022-06-23 15:44:46.539639
# Unit test for function lam_sub
def test_lam_sub():
    # Create a grammar table
    test_grammar = Grammar(
        start=2,
        labels=[[1, 1], [2, 2], [3, 3], [4, 4]],
        nonterminals=[2, 3, 4],
        dfas=[
            ([[], [], [[(3, 2), (1, 1)]], [[(1, 1)]]], 0),
            ([[(1, 1), (2, 2)], [(2, 2)], [(2, 2)], [(2, 2)]], 0),
            ([[], [(1, 1), (2, 2)], [(1, 1), (3, 2), (4, 3)], [(4, 3)]], 0),
        ],
    )
    # Create a concrete syntax tree

# Generated at 2022-06-23 15:44:57.450846
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # If a syntax error occurs, addtoken() raises the ParseError
    # exception; there is no error recovery; the parser cannot be used
    # after a syntax error was reported (but it can be reinitialized
    # by calling setup()).
    g = Grammar()
    p = Parser(g)
    p.setup()
    try:
        p.addtoken(token.PLUS, '+', (1, 1))
    except ParseError:
        pass
    else:
        assert False, "Should have raised"
    # Getting started:
    # A concrete syntax tree node is a (type, value, context, nodes)
    # tuple, where type is the node type (a token or symbol number),
    # value is None for symbols and a string for tokens, context is
    # None or an opaque value used for error reporting (typically

# Generated at 2022-06-23 15:45:05.064206
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    g = grammar.grammar
    node = (
        1,
        None,
        None,
        [
            (3, "Hi", None, None),
            (12, None, None, [(5, ",", None, None), (5, ",", None, None)]),
            (5, ".", None, None),
        ],
    )
    result = lam_sub(g, node)
    assert result.type == token.NAME
    assert result.children == ["Hi", ",", ",", "."]

# Generated at 2022-06-23 15:45:13.333058
# Unit test for method push of class Parser
def test_Parser_push():
    class MockGrammar:
        pass

    mockgrammar = MockGrammar()
    mockgrammar.start = 257
    mockgrammar.dfas = {257: ([[(0, 1)]], {0: 0, 1: 1}), 258: ([[(0, 1)]], {0: 0, 1: 1})}
    mockgrammar.labels = [(258, None)]

    parser = Parser(mockgrammar)
    parser.setup()
    parser.push(258, ([[(0, 1)]], {0: 0, 1: 1}), 0, None)
    assert parser.stack == [([[(0, 1)]], {0: 0, 1: 1}), 0, (257, None, None, [])]

# Generated at 2022-06-23 15:45:26.498685
# Unit test for method pop of class Parser
def test_Parser_pop():
    class FakeGrammar(object):
        def __init__(self):
            self.dfas = {}  # type: Dict[int, DFAS]
            self.labels = {}  # type: Dict[int, Tuple[int, Optional[Text]]]
        def __getitem__(self, key: int) -> DFAS:
            return self.dfas[key]

    class FakeNode(object):
        def __init__(self, type: int, context: Optional[Context], children: Sequence[Any]):
            self.type = type
            self.context = context
            self.children = children
            self.used_names = None

    def convert(grammar: FakeGrammar, node: FakeNode) -> FakeNode:
        return node

    grammar = FakeGrammar()

# Generated at 2022-06-23 15:45:35.199976
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .tokenize import generate_tokens
    from .grammar import Grammar

    g = Grammar()
    p = Parser(g)

    def check_classify(input: Text, expected: int) -> None:
        p.setup()
        for type, value, context, token in generate_tokens(input):
            if type == token.ENDMARKER:
                break
            p.addtoken(type, value, context)
        assert p.stack[-1][1] == expected

    check_classify("lambda", 1)

    check_classify("def f(x):\n\treturn x", 8)

    # Hm, token classification and error reporting are quite different
    # with the new tokenizer because it allows strings with embedded
    # newlines...

# Generated at 2022-06-23 15:45:36.618422
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(Grammar)
    p.setup()
    p.addtoken(token.ENDMARKER, "", Context(0, 0))

# Generated at 2022-06-23 15:45:46.418720
# Unit test for method classify of class Parser
def test_Parser_classify():
    # setup
    grammar = Grammar(
        start=1,
        keywords={},
        tokens={},
        labels=[],
        symbols={},
        dfas={},
        stateset={},
        productions=[],
    )
    context = type(
        "", (object,), {"line": -1, "column": -1, "filename": None, "encoding": None}
    )
    test = Parser(grammar)

    # tests
    # positive test case for grammar.NAME with label in grammar.tokens
    grammar.tokens = {token.NAME: 1}  # label 1
    test.classify(token.NAME, "import", context)

    # negative test case for grammar.NAME with label not in grammar.tokens
    grammar.tokens = {}  # Empty dict

# Generated at 2022-06-23 15:45:58.250774
# Unit test for function lam_sub
def test_lam_sub():
    class T(object):
        def __eq__(self, other):
            return self.__dict__ == other.__dict__

    g = Grammar()
    g.symbol2number["test"] = "test"
    g.number2symbol["test"] = "test"
    node = (T(), T(), T(), [T(), T(), T()])
    result = lam_sub(g, node)
    assert result.prefix == "test "
    assert result.kids == ()
    assert result.changed == 0
    assert len(result.children) == 3
    assert result.children[0].prefix == "test "
    assert result.children[0].kids == ()
    assert result.children[0].changed == 0
    assert result.children[0].children == ()

# Generated at 2022-06-23 15:46:02.025568
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    class MyParser(Parser):
        pass

    myparser = MyParser(grammar=Grammar(grammar=None), convert=None)
    myparser.setup()
    assert myparser.addtoken(type=None, value=None, context=None)

# Generated at 2022-06-23 15:46:13.611537
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2.pgen import generate_grammar

    grammar = generate_grammar(
        filter(None, open("spam2to3/Grammar").readlines()),
        "Grammar",
    )

    p = Parser(grammar)
    p.setup()
    assert p.addtoken(1, "foo", None)
    assert p.addtoken(2, "bar", None)
    assert p.addtoken(3, "baz", None)
    assert p.addtoken(4, "spam", None)
    assert p.addtoken(0, None, None)
    assert len(p.rootnode) == 1
    tree = p.rootnode[0]
    assert tree.type == "single_input"

# Generated at 2022-06-23 15:46:18.920290
# Unit test for method shift of class Parser
def test_Parser_shift():
    """
    >>> p = Parser(Grammar())
    >>> p.setup()
    >>> p.shift(0, "foo", 1, None)
    Traceback (most recent call last):
    ...
    AssertionError

    """

# Run tests in docstrings
# Run tests in docstrings
if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=1)

# Generated at 2022-06-23 15:46:29.602141
# Unit test for method setup of class Parser
def test_Parser_setup():
    # Imports
    import sys
    from . import token, tokenize
    from .pgen import driver
    # Create a parser instance
    d = driver.Driver(gendefs=False, convert=False)
    g = d.build_grammar("Grammar/Grammar")
    p = Parser(g, None)
    # Prepare for parsing
    p.setup("file_input")
    # Accept one token
    with open("Grammar/Grammar", "rb") as f:
        f.readline()  # Skip the encoding line
        tt = tokenize.generate_tokens(f.readline)
        for t in tt:
            if p.addtoken(token.NAME, t[1], Context(tt, 1)):
                # Done parsing
                break
    # Check the

# Generated at 2022-06-23 15:46:40.528113
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    p = Parser(grammar.grammar, None)
    p.setup()

    # First test
    p.push(256, ([[(3, 0), (4, 1)]], {0: 0, 1: 1}), 1, None)
    assert p.stack == [([[(3, 0), (4, 1)]], {0: 0, 1: 1}), (0, (256, None, None, []))]

    # Second test
    p.push(257, ([[(1, 0), (2, 1)]], {0: 0, 1: 1}), 0, None)

# Generated at 2022-06-23 15:46:52.009638
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    import pprint
    import os

    class ParserAddTokenTestCase(unittest.TestCase):
        def setUp(self):
            import blib2to3.pgen2.parse
            import blib2to3.pgen2.token

            self.grammar = blib2to3.pgen2.parse.load_grammar(
                os.path.join(os.path.dirname(blib2to3.pgen2.parse.__file__), "Grammar")
            )
            self.parser = blib2to3.pgen2.parse.Parser(self.grammar)
            self.parser.setup()

            self.token_names = {}

            tokennum = 0

# Generated at 2022-06-23 15:46:58.420292
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import compiler
    import sys

    print("test_Parser_addtoken...", end="")
    p = Parser(compiler.Grammar)
    p.setup()
    tks = compiler.tokenize.generate_tokens(sys.stdin.readline)
    for type, val, spos, epos, line in tks:
        if p.addtoken(type, val, 0):
            break
    print("done")

# Generated at 2022-06-23 15:47:06.074774
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import pickletools
    from . import pygram
    import io

    pdict = {}
    for modname in pygram.python_grammar:
        pdict[modname] = pygram.python_grammar[modname]
    pdict['start'] = "file_input"
    pdict['single_input'] = ("NEWLINE | simple_stmt | compound_stmt NEWLINE",
                             ("NEWLINE",))
    pdict['eval_input'] = ("testlist NEWLINE* ENDMARKER", ("NEWLINE", "ENDMARKER"))
    pdict['file_input'] = ("(NEWLINE | stmt)* ENDMARKER",
                           ("NEWLINE", "ENDMARKER"))

# Generated at 2022-06-23 15:47:09.078012
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar()
    p = Parser(grammar)
    p.setup()
    p.setup(start=42)
    # This should fail if setup is not a method.
    p.setup()

# Generated at 2022-06-23 15:47:12.139302
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("Test error", None, None, None)
    assert err.msg == "Test error"
    assert err.type is None
    assert err.value is None
    assert err.context is None

# Generated at 2022-06-23 15:47:19.977873
# Unit test for method setup of class Parser
def test_Parser_setup():
    class Parser(object):

        def setup(self, start=None):
            """Prepare for parsing.

            This *must* be called before starting to parse.

            The optional argument is an alternative start symbol; it
            defaults to the grammar's start symbol.

            You can use a Parser instance to parse any number of
            programs; each time you call setup() the parser is reset to
            an initial state determined by the (implicit or explicit)
            start symbol.

            """
            if start is None:
                start = self.grammar.start
            # Each stack entry is a tuple: (dfa, state, node).
            # A node is a tuple: (type, value, context, children),
            # where children is a list of nodes or None, and context may be None.
            newnode = (start, None, None, [])


# Generated at 2022-06-23 15:47:22.933545
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Tests addtoken().

    This is used by the Python regression test.

    """
    import doctest

    doctest.testmod(verbose=False)
    #print('XXX doctest done')

# Generated at 2022-06-23 15:47:31.604206
# Unit test for constructor of class Parser
def test_Parser():
    import pprint
    from . import symbol, token
    from . import grammar

    class DebugConvert(object):
        def __init__(self, grammar: Grammar) -> None:
            self.grammar = grammar
            self.out_file = open("debug.out", "w")

        def __call__(self, grammar: Grammar, node: RawNode) -> Node:
            assert grammar == self.grammar
            print("CONVERT", file=self.out_file)
            pprint.pprint(("NODE", node), self.out_file)
            return Node(type=node[0], children=node[3], context=node[2])

    p = Parser(grammar, DebugConvert)
    p.setup()


# Generated at 2022-06-23 15:47:33.031866
# Unit test for method pop of class Parser
def test_Parser_pop():
    p = None
    # FIXME Implement this
    assert False


# Generated at 2022-06-23 15:47:37.520090
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("bad token", 1, "1", (1, 0))
    except ParseError as err:
        assert err.msg == "bad token"
        assert err.type == 1
        assert err.value == "1"
        assert err.context == (1, 0)
    else:
        assert False, "didn't raise ParseError"

# Generated at 2022-06-23 15:47:48.413650
# Unit test for method classify of class Parser
def test_Parser_classify():
    import sys

    import lib2to3.pgen2.driver as driver
    import lib2to3.pgen2.parse as parse
    import lib2to3.pgen2.token as token

    if sys.argv[1:]:
        filename = sys.argv[1]
    else:
        filename = "Lib/lib2to3/Grammar.txt"
    f = open(filename)
    input = f.read()
    f.close()
    grammar = driver.load_grammar(filename)
    if not grammar:
        raise ValueError("Couldn't load grammar")
    tokens = parse.tokenize(input, grammar)
    p = Parser(grammar)

# Generated at 2022-06-23 15:47:54.217023
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import pgen2
    p = pgen2.load_parser('Python2.g2')[0]
    p.setup()
    assert p.stack == [(p.grammar.dfas[p.grammar.start], 0, (1, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()
    p.setup()
    assert p.stack == [(p.grammar.dfas[p.grammar.start], 0, (1, None, None, []))]



# Generated at 2022-06-23 15:47:56.518528
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.grammar
    p = Parser(g, lam_sub)
    p.setup()



# Generated at 2022-06-23 15:48:08.412963
# Unit test for method push of class Parser
def test_Parser_push():
    # build a simple test tree
    p = Parser(None, None)
    p.used_names = set()
    p.stack = [
        (None, 0, ((None, None, None, []), None, None, None)),
        (None, 0, ((None, None, None, []), None, None, None)),
    ]
    tree = (1, None, None, [])
    # push the node
    p.push(1, None, 0, None)
    # check if the tree is correct
    assert p.stack[-2][2][-1].append(tree) == [tree]

# Generated at 2022-06-23 15:48:09.021640
# Unit test for constructor of class Parser
def test_Parser():
    pass

# Generated at 2022-06-23 15:48:12.257497
# Unit test for function lam_sub
def test_lam_sub():
    from blib2to3.pgen2 import driver
    driver.initialize_grammar()
    grammar = driver.grammar
    assert lam_sub(grammar, (0, None, None, [1, 2])) == [1, 2]

# Generated at 2022-06-23 15:48:19.900713
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    _lambda = grammar._lambda
    _if = grammar._if
    _else = grammar._else

    g = grammar.grammar
    p = Parser(g, lam_sub)
    p.setup()


# Generated at 2022-06-23 15:48:29.050138
# Unit test for method shift of class Parser
def test_Parser_shift():
    class FakeGrammar:
        def __init__(self, labels: Sequence[str]) -> None:
            self.labels = labels
            self.tokens = {1:0, 2:1, 3:2}
    class FakeGrammarWithConverter(FakeGrammar):
        def __init__(self, labels: Sequence[str], converter: Convert) -> None:
            FakeGrammar.__init__(self, labels)
            self.converter = converter
    class FakeNode(object):
        def __init__(self, type: int, value: Text, context: Any, children: Any) -> None:
            self.type = type
            self.value = value
            self.context = context
            self.children = children

# Generated at 2022-06-23 15:48:30.555879
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("err", 1, "val", (1, 2))

# Generated at 2022-06-23 15:48:39.480409
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Test with a simple grammar inducing a parse tree
    g = Grammar(
        """
        start: A B C;
        A: '1' | '2';
        B: '3' | '4';
        C: '5' | '6';
        """
    )
    p = Parser(g)
    p.setup()
    assert p.addtoken(token.NUMBER, "1", (1, 0)) is False
    assert p.addtoken(token.NUMBER, "3", (1, 0)) is False
    assert p.addtoken(token.NUMBER, "5", (1, 0)) is True
    assert p.rootnode.type == g.symbol2number["start"]
    assert p.rootnode.children[0].type == g.symbol2number["A"]

# Generated at 2022-06-23 15:48:50.686475
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys

    import lib2to3.pgen2.driver, lib2to3.pgen2.parse

    # Generic parser test: parse a Python file
    def test_parse(filename: Text) -> None:
        # Print some informational stuff
        print("=" * 20)
        print("Parsing", filename)
        # Create driver and parse
        d = lib2to3.pgen2.driver.Driver(lib2to3.pgen2.parse.MyGrammar(), convert=None)
        p = d.parse_tokens(lib2to3.pgen2.driver.tokenize_file(filename))
        # Print some informational stuff
        print("Done:", filename)
        print("=" * 20)

    test_parse(sys.argv[1])

# Generated at 2022-06-23 15:48:57.981296
# Unit test for constructor of class Parser
def test_Parser():
    class MyParser(Parser):
        def __init__(self, grammar, convert=None):
            Parser.__init__(self, grammar, convert)  # noqa

    my = MyParser(Grammar())
    assert my.grammar is not None
    assert my.convert is None
    assert my.rootnode is None
    my.setup()
    assert my.stack == [(my.grammar.dfas[my.grammar.start], 0, (0, None, None, []))]
    assert my.rootnode is None

# Generated at 2022-06-23 15:48:58.838867
# Unit test for constructor of class ParseError
def test_ParseError():
    # __init__
    raise ParseError("error", 1, 2, 3)



# Generated at 2022-06-23 15:49:01.839344
# Unit test for constructor of class ParseError
def test_ParseError():
    assert str(ParseError("bad input", 1, "x", None)) == (
        "bad input: type=1, value='x', context=None"
    )

# Generated at 2022-06-23 15:49:09.206746
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    g = grammar.Grammar()
    p = Parser(g)
    p.addtoken(g.tokens['a'], 'atom', None)
    p.addtoken(g.tokens['b'], 'b', None)
    p.addtoken(g.tokens['c'], 'c', None)
    p.addtoken(g.tokens['a'], 'atom', None)
    node = p.rootnode
    assert node == Node(grammar.syms['abc'], [
        Leaf(token.NAME, 'atom'),
        Leaf(token.NAME, 'b'),
        Leaf(token.NAME, 'c'),
        Leaf(token.NAME, 'atom'),
    ])
    node.prefix = 'some prefix'
    node.used_names = set

# Generated at 2022-06-23 15:49:20.371021
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import syms

    # Initialize grammar
    gram = grammar.Grammar(grammar.DEFAULT_GRAMMAR)
    # Initialize parser
    p = Parser(gram)

    # Create dummy tokens
    # Tuple of type, value, context
    token1 = (syms.test, None, None)
    token2 = (syms.test2, None, None)
    token3 = (syms.test3, None, None)

    # Create stack
    stack = [(gram.dfas[0], 0, token1),
             (gram.dfas[0], 1, token2),
             (gram.dfas[0], 2, token3)]

    # Initialize parser
    p.stack = stack
    p.shift(1, None, 0, None)

# Generated at 2022-06-23 15:49:32.487542
# Unit test for function lam_sub
def test_lam_sub():
    from . import pgen
    from .driver import Driver
    from .tokenizer import generate_tokens
    from .fixer_util import Name

    class FauxGrammar:
        def __init__(self, *args, **kwargs):
            pass

    g = FauxGrammar()

    def test(node):
        n = lam_sub(g, node)
        assert str(n) == "Leaf(1, 'a')"

    if not isinstance(token, Name):
        test( [1, 'a', None, None] )
    else:
        test( [token.NUMBER, 'a', None, None] )

    # Test a fake node
    node = [1, None, None, [[1, 'a', None, None], [1, 'b', None, None]]]
   

# Generated at 2022-06-23 15:49:40.699907
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import unittest

    import blib2to3.pgen2.driver
    import blib2to3.pgen2.tokenize
    import blib2to3.pgen2.parse
    import blib2to3.pgen2.convert
    import blib2to3.pgen2.grammar

    class TestParserMethods(unittest.TestCase):
        def test_test(self):
            grammar = blib2to3.pgen2.grammar.Grammar("x foo")
            parser = Parser(grammar)
            parser.setup(type("foo", (object,), {})())
            self.assertEqual(type("foo", (object,), {})(), parser.addtoken("foo", None))

    unittest.main()

# Generated at 2022-06-23 15:49:46.518255
# Unit test for method classify of class Parser
def test_Parser_classify():
    assert Parser(Grammar()).classify(token.NAME, "foo", None) == 1
    assert Parser(Grammar()).classify(token.NUMBER, "123", None) == 2
    assert Parser(Grammar()).classify(token.STRING, "bar", None) == 3

# Generated at 2022-06-23 15:49:57.420804
# Unit test for method push of class Parser

# Generated at 2022-06-23 15:50:01.275413
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test", 1, "1", None)
    except ParseError as err:
        assert err.msg == "test"
        assert err.type == 1
        assert err.value == "1"
        assert err.context is None

# Generated at 2022-06-23 15:50:14.441252
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from .grammar_indentation import (
        CLASS,
        INDENT,
        DEDENT,
        NEWLINE,
        ENDMARKER,
        ASYNC,
        AWAIT,
        COROUTINE,
        EXCEPT,
        FOR,
        FROM,
        IF,
        IMPORT,
        LAMBDA,
        NONLOCAL,
        RETURN,
        TRY,
        WHILE,
        WITH,
        YIELD,
        ELSE,
        FINALLY,
    )
    grammar = driver.load_grammar("Grammar/Grammar")

# Generated at 2022-06-23 15:50:21.911806
# Unit test for function lam_sub
def test_lam_sub():
    node = (1, None, (1, 0), [])
    node[-1].append(RawNode(type=1, children=None, context=(1, 0)))
    node[-1].append(RawNode(type=2, children=[], context=(2, 0)))
    assert lam_sub(None, node)[0] == [Node(type=1, children=None, context=(1, 0)),
                                      Node(type=2, children=[], context=(2, 0))]

# Generated at 2022-06-23 15:50:29.469380
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .driver import parse_string
    from . import driver
    from . import parse
    import sys

    g = driver.load_grammar("Grammar.txt", "GrammarTables.py")
    p = parse.Parser(g)
    p.setup()
    for token in parse_string("#", g):
        p.addtoken(*token)

    p.setup()
    for token in parse_string("a", g):
        p.addtoken(*token)

    # XXX: ParseError are currently not caught by the test suite

    #########################################
    # Test cases for the "if_stmt" rule
    p.setup()
    for token in parse_string("a", g):
        try:
            p.addtoken(*token)
        except ParseError as e:
            sys.stderr

# Generated at 2022-06-23 15:50:37.394810
# Unit test for constructor of class ParseError
def test_ParseError():
    from blib2to3.pygram import python_symbols

    msg = "syntax error message"
    type = python_symbols.name
    value = "x"
    context = Context("", 1, 1, 2)
    try:
        raise ParseError(msg, type, value, context)
    except ParseError as e:
        assert str(e) == (
            "syntax error message: type=python_symbols.name, "
            + "value='x', context=(1, 2)"
        )
    except Exception:
        assert False, "test_ParseError: unexpected exception raised"

