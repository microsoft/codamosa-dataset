

# Generated at 2022-06-23 15:40:42.688897
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import token, symbols

    def parsestring(s: str, type: int) -> NL:
        from . import driver

        p = driver.Driver(grammar)
        fil = p.parse_string(s)
        return p.pgen.parsesuite(fil, type)[0].children[0].children[0]

    assert parsestring("while :\n pass", symbols.file_input)
    try:
        parsestring("while :\n pass", symbols.eval_input)
    except ParseError:
        pass
    else:
        assert 0, "did not detect error"
    try:
        parsestring("while :\n pass", symbols.single_input)
    except ParseError:
        pass
    else:
        assert 0, "did not detect error"

# Generated at 2022-06-23 15:40:52.200656
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from .tokenize import generate_tokens

    # Test data and expected answers
    albrk = "\u00e4\u00f6\u00fc"
    testcases = [
        ("", []),
        ("a", [("NAME", "a")]),
        ("_", [("NAME", "_")]),
        ("A", [("NAME", "A")]),
        ("_A", [("NAME", "_A")]),
        (albrk, [("NAME", albrk)]),
        ("a_", [("NAME", "a_")]),
        (albrk + "_", [("NAME", albrk + "_")]),
        (albrk + "_" + albrk, [("NAME", albrk + "_" + albrk)]),
    ]
    # Test data

# Generated at 2022-06-23 15:41:00.184449
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar, token

    grammar_data = grammar.grammar
    grammar = grammar.Grammar(grammar_data)
    tokens = token.tokens
    parser = Parser(grammar)
    parser.setup()

    assert parser.stack == [(grammar.dfas[1], 0, [1, None, None, []])], parser.stack
    assert parser.rootnode is None, parser.rootnode
    assert parser.used_names == set(), parser.used_names


# Generated at 2022-06-23 15:41:03.986049
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2.pgen import generate_grammar

    grammar = generate_grammar("Grammar.txt")
    p = Parser(grammar)
    p.setup()
    assert p.stack == [(grammar.dfas[grammar.start], 0, (grammar.start, None, None, []))]

# Generated at 2022-06-23 15:41:07.349526
# Unit test for method shift of class Parser
def test_Parser_shift():
    class MyGrammar(Grammar):
        pass
    g = MyGrammar({}, {}, [], [], {})
    p = Parser(g)
    p.stack = [(None, 0, None)]
    p.shift(1, 1, 2, 3)
    assert p.stack == [(None, 2, None)]

# Generated at 2022-06-23 15:41:10.238872
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Tests the Parser's pop method.

    @returns {void}
    """
    raise NotImplementedError("TODO: auto-generated function.")

# Generated at 2022-06-23 15:41:15.301885
# Unit test for function lam_sub
def test_lam_sub():
    # This could be any grammar instance
    g = Grammar()
    n = ("symbol", None, None, [("token", "x", "context", None)])
    assert lam_sub(g, n) == Node(type="symbol", children=[Leaf(type="token", value="x")])

# Generated at 2022-06-23 15:41:23.697352
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = Grammar(grammar1)
    parser = Parser(grammar)
    parser.setup()
    dfa = parser.grammar.dfas[grammar.symbol2number["stmt"]]
    parser.push(grammar.symbol2number["stmt"], dfa, 0, None)
    assert parser.stack == [(dfa, 0, (None, None, None, [])), (dfa, 0, (286, None, None, []))]



# Generated at 2022-06-23 15:41:26.102145
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(None)
    assert p.grammar is None
    assert p.convert is None


# Generated at 2022-06-23 15:41:28.102627
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(token.type)
    p.setup()
    dummy = object()
    p.shift(0, 'Hello', 1, dummy)

# Generated at 2022-06-23 15:41:35.965231
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    from blib2to3.pgen2.grammar import parse_grammar
    from .driver import tokenize_func

    # Scan an input string and return a list of tokens.
    def scan(input: Text) -> Sequence[Tuple[int, Text]]:
        tokens: List[Tuple[int, Text]] = []
        gen = generate_tokens(tokenize_func(input).get_token)
        for token in gen:
            tokens.append((token.type, token.string))
        return tokens

    # Build a table of all tokens and symbols.
    def build_table(tokens: Sequence[Tuple[Any, Any]]) -> List[int]:
        tok = set()
        sym = set

# Generated at 2022-06-23 15:41:38.736513
# Unit test for method classify of class Parser
def test_Parser_classify():
    assert str(Parser.classify.__doc__).startswith('Turn a token into a label')



# Generated at 2022-06-23 15:41:44.740696
# Unit test for method setup of class Parser
def test_Parser_setup():
    import blib2to3.pgen2.grammar as grammar
    from . import driver
    gram = grammar.grammar
    p = Parser(gram, None)
    p.setup(grammar.START)
    p.addtoken(token.NAME, "import", Context(1, 0, "<stdin>", ""))

# Generated at 2022-06-23 15:41:54.826496
# Unit test for method classify of class Parser
def test_Parser_classify():
    class MockParser(Parser):
        def __init__(self, grammar, convert=None, classify=None):
            Parser.__init__(self, grammar, convert)
            self.classify = classify
    def classify(type, value, context):
        print("type=", type, "value=", value, "context=", context)
        if type == token.NAME:
            if value == 'endif':
                return grammar.tokens['ENDIF']
            else:
                return grammar.tokens['NAME']
        else:
            return grammar.tokens[str(type)]
    grammar = Grammar(token)
    p = MockParser(grammar, classify=classify)
    p.addtoken(token.ENDIF, 'endif', (1, 3))

# Generated at 2022-06-23 15:41:58.370987
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", 0, "value", "context")
    except ParseError as ValueError:
        assert ValueError.msg == "msg"
        assert ValueError.type == 0
        assert ValueError.value == "value"
        assert ValueError.context == "context"

# Generated at 2022-06-23 15:42:04.096798
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test", None, None, None)
    except ParseError as value:
        assert value.msg == "test"
        assert value.type is None
        assert value.value is None
        assert value.context is None



# Generated at 2022-06-23 15:42:09.411903
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = Grammar()
    convert = lambda grammar, node: node
    p = Parser(grammar, convert)
    p._Parser__push(1, ([], {0: (0, 1)}), 0, (1, 1))
    assert p.stack == [([], {0: (0, 1)}, (1, None, (1, 1), []))]



# Generated at 2022-06-23 15:42:18.357234
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Make sure that the reserved word list works
    class FakeGrammar:
        def __init__(self, keywords):
            self.keywords = keywords

    grammar = FakeGrammar({"foo": 1, "bar": 2, "baz": 3})
    p = Parser(grammar)
    assert p.classify(token.NAME, "foo", Context(1, 0)) == 1
    assert p.classify(token.NAME, "bar", Context(1, 0)) == 2
    assert p.classify(token.NAME, "baz", Context(1, 0)) == 3
    assert p.classify(token.NAME, "spam", Context(1, 0)) == None
    assert p.classify(token.STRING, "foo", Context(1, 0)) == None

# Generated at 2022-06-23 15:42:22.182071
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    # Empty grammar
    g = grammar.Grammar(token.LPAR, token.RPAR)
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]


# Generated at 2022-06-23 15:42:26.579962
# Unit test for method setup of class Parser
def test_Parser_setup():
    import unittest
    import blib2to3.pgen2.pgen
    import blib2to3.pgen2.driver

    class TestParser(unittest.TestCase):
        def test_setup(self):
            grammar = blib2to3.pgen2.pgen.driver.load_grammar(
                "Grammar/Grammar", "test2"
            )
            parser = blib2to3.pgen2.driver.Parser(grammar)
            parser.setup()

# Generated at 2022-06-23 15:42:37.513127
# Unit test for method push of class Parser
def test_Parser_push():
    def convert(grammar, node):
        type, value, context, children = node
        return Node(type=type, children=children, context=context)
    grammar = Grammar(Grammar.START, Grammar.START, {}, {}, {}, {}, {}, {}, {}, {}, {})
    parser = Parser(grammar, convert)
    parser.setup()
    parser.addtoken(tokenize.NAME, 'foobar', (1, 0))
    parser.addtoken(tokenize.OP, '=', (1, 5))
    parser.push(Grammar.START, (DFA, {}), 0, (1, 0))
    # tree = parser.rootnode
    # tree.pretty_print(sys.stdout)


# Generated at 2022-06-23 15:42:48.599956
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("msg", 1, "value", (2, 3))
    assert str(err) == "msg: type=1, value='value', context=(2, 3)"


if __name__ == "__main__":
    import sys
    import blib2to3.pgen2.parse_grammar

    grammar = blib2to3.pgen2.parse_grammar.parse_grammar(sys.stdin.read())
    parser = Parser(grammar)
    parser.setup()
    for tok in grammar.symbol2number:
        parser.addtoken(grammar.symbol2number[tok], tok, (1, 1))
    print(parser.rootnode)

# Generated at 2022-06-23 15:42:50.550793
# Unit test for method classify of class Parser
def test_Parser_classify():
    class myParser(Parser): pass
    myParser.classify(token.NAME, 'def', None)

# Generated at 2022-06-23 15:42:59.608381
# Unit test for constructor of class Parser
def test_Parser():
    import unittest
    import sys
    import blib2to3.pgen2.driver

    class TestParser(unittest.TestCase):
        def setUp(self):
            self.grammar = blib2to3.pgen2.driver.load_grammar(sys.argv[1])
            self.p = Parser(self.grammar)
            self.p.setup()

        def test_parsing(self):
            import pprint
            stderr = sys.stderr
            sys.stderr = sys.stdout

# Generated at 2022-06-23 15:43:05.749531
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver

    gram = driver.load_grammar_file("Grammar")
    parser = Parser(gram)
    parser.setup()

    token1 = token.NAME
    value1 = "and"
    context1 = Context(line=1, column=1)

    label1 = parser.classify(type=token1, value=value1, context=context1)
    assert label1 == 256

    token2 = token.NAME
    value2 = "def"
    context2 = Context(line=1, column=1)

    label2 = parser.classify(type=token2, value=value2, context=context2)
    assert label2 == 79

# Generated at 2022-06-23 15:43:10.064026
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def test_case(
        expected_err: Optional[ParseError],
        tokens: Sequence[Tuple[int, Optional[Text], Context]],
        *,
        test_function: Callable[
            [Parser, List[Tuple[int, Optional[Text], Context]]], None
        ]
    ) -> None:
        # Test the parser against a sequence of tokens
        # Token values are (type, value, context) tuples
        # Expected results are 0 for no error, 1 if a ParserError is
        # expected, and 2 if other errors are expected.

        try:
            p = Parser(Grammar(gfile))
        except ParseError:
            return  # Cannot continue testing

        try:
            p.setup()
        except ParseError:
            return  # Cannot continue testing

        # Copy tokens

# Generated at 2022-06-23 15:43:15.021375
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar()
    parser = Parser(grammar)
    # Check default values
    assert parser.grammar == grammar
    assert parser.convert == lam_sub
    assert parser.stack == []
    assert parser.rootnode is None

# Generated at 2022-06-23 15:43:18.223394
# Unit test for constructor of class Parser
def test_Parser():
    from . import driver

    try:
        g = driver.load_grammar(convert=None)
    except IOError as e:
        return

    p = Parser(g, convert=None)

# Generated at 2022-06-23 15:43:20.082395
# Unit test for function lam_sub
def test_lam_sub():
    # type: () -> None
    r = lam_sub(None, (1, 'heh', None, [2, 3]))
    assert r.type == 1
    assert r[0] == 2
    assert r[1] == 3

# Generated at 2022-06-23 15:43:31.499318
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver

    grammar = driver.load_grammar('Grammar.txt')
    parser = Parser(grammar)
    parser.setup()
    parser.stack = [([([(0, 0), (0, 0)], {0: 0}), (0, 1, None)],
                     0,
                     (2, None, None, [])),
                    ([([(0, 0), (0, 0)], {0: 0}), (0, 1, None)],
                     0,
                     (3, None, None, []))]
    parser.pop()

# Generated at 2022-06-23 15:43:34.873080
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError('foo', token.NAME, 'bar', (1,2))
    assert str(err).startswith('foo: type=')
    assert str(err).endswith('context=(1, 2)>')



# Generated at 2022-06-23 15:43:42.104462
# Unit test for constructor of class Parser
def test_Parser():
    # Test existence of attributes
    p = Parser(None)
    assert p.grammar is None
    assert p.convert == lam_sub
    assert p.stack is None
    assert p.used_names is None
    # Test the constructor
    g = Grammar()
    p = Parser(g)
    assert p.grammar is g
    assert p.convert == lam_sub



# Generated at 2022-06-23 15:43:43.458741
# Unit test for constructor of class ParseError
def test_ParseError():
    raw_input("You should have gotten a Fatal Python error dialog.  Hit return.")

# Generated at 2022-06-23 15:43:48.624405
# Unit test for constructor of class Parser
def test_Parser():
    import sys
    import blib2to3.pgen2.driver

    p = blib2to3.pgen2.driver.load_grammar(sys.argv[1])  # type: ignore
    blib2to3.pgen2.driver.parse_file(sys.argv[2], p, blib2to3.pgen2.tokenize)


if __name__ == "__main__":
    test_Parser()

# Generated at 2022-06-23 15:43:53.488095
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # We need a grammar
    import blib2to3.pgen2.grammar
    gr = blib2to3.pgen2.grammar
    g = gr.Grammar()
    # A simple parser
    p = Parser(g)
    # We'll parse a single token
    p.setup()
    # Add a token to the parser
    token = "a", "/", (1, 1)
    p.addtoken(*token)
    # We should now have a rootnode
    assert p.rootnode is not None
    # And it's a Node
    assert isinstance(p.rootnode, Node)
    # The type should be the same as what we gave
    assert p.rootnode.type == token[0]
    # It should have no children
    assert not p.rootnode.children
    # The

# Generated at 2022-06-23 15:43:58.477997
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("bad input", None, None, None)
    except ParseError as e:
        assert str(e) == "bad input: type=None, value=None, context=None"
        assert e.msg == "bad input"
        assert e.type is None
        assert e.value is None
        assert e.context is None

# Generated at 2022-06-23 15:44:08.052101
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    from . import grammar
    from . import tokenize
    from io import StringIO

    assert expected in parser.used_names

    num = len(sys.modules)

    if __name__ == '__main__':
        parser = Parser(grammar.grammar, lam_sub)
        expected = '__name__'
        parser.setup()
        fp = StringIO("x = 1; y = 2; z = 3\n")
        tokenize.tokenize(
            fp.readline,
            lambda *args: parser.addtoken(*args)  # type: ignore
        )
        print(parser.rootnode)

# Generated at 2022-06-23 15:44:15.884023
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Method addtoken(self, type, value, context) is tested.
    import tokenize

    # The following code to get the grammar and compute the NFA is taken
    # from blib2to3.pgen2.driver.

    from .tokenize import generate_tokens

    from .pgen import Grammar, driver

    from .parse import Parser

    version = driver.version
    if version == 2.6:
        from .pgen_26 import grammar
    elif version == 2.7:
        from .pgen_27 import grammar
    elif version == 3.3:
        from .pgen_33 import grammar
    elif version == 3.4:
        from .pgen_34 import grammar
    elif version == 3.5:
        from .pgen_35 import grammar

# Generated at 2022-06-23 15:44:21.672281
# Unit test for constructor of class Parser
def test_Parser():
    from .tokenize import generate_tokens
    from .token import INDENT, DEDENT, ENDMARKER, NAME, NUMBER, STRING
    from .pgen2 import driver
    import StringIO

    grammar = driver.load_grammar("Grammar.txt")
    p = Parser(grammar)
    lines = ["name = 1", "string = 'x'"]
    tokens = generate_tokens(StringIO.StringIO(str.join("\n", lines) + "\n").readline)
    p.setup()
    for t in tokens:
        if p.addtoken(t[0], t[1], t[4]):
            break
    # See what we've got
    root = p.rootnode
    assert len(root) == 1
    assign = root[0]
    assert assign

# Generated at 2022-06-23 15:44:32.486285
# Unit test for method push of class Parser
def test_Parser_push():
    def lam_sub(grammar: Grammar, node: RawNode) -> NL:
        return node
    grammar = Grammar(dict(dfas={
        1: ([[(1, 1), (2, 5)], [(0, 1), (2, 4)], [(0, 2)], [(0, 3)], [(0, 4)], [(0, 5)]],
            {1: 0, 2: 0, 3: 4, 4: 3, 5: 2}),
        2: ([[(2, 5), (3, 8)], [(0, 6), (3, 7)], [(0, 7)], [(0, 8)]],
            {6: 0, 7: 2, 8: 1})
        }))  # type: Grammar
    parser = Parser(grammar, lam_sub)
    assert parser.stack == []

# Generated at 2022-06-23 15:44:35.529222
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError('message', 1, 'value', (1, 2))
    assert e.args == ('message: type=1, value=value, context=(1, 2)',)

# Generated at 2022-06-23 15:44:44.726824
# Unit test for method pop of class Parser
def test_Parser_pop():
    import io
    import sys
    import tempfile
    import unittest
    import blib2to3.pgen2.pgen
    import blib2to3.pgen2.tokenize
    import blib2to3.pgen2.driver
    import blib2to3.pygram
    import blib2to3.pytree

    class TestParserPop(unittest.TestCase):
        def setUp(self):
            self.p = Parser(blib2to3.pygram.python_grammar, blib2to3.pytree.convert)

        def _test_pop(self, input):
            input = io.StringIO(input)
            tokens = blib2to3.pgen2.tokenize.generate_tokens(input.readline)

# Generated at 2022-06-23 15:44:56.503136
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from .token import NAME
    if test_Parser_pop.__module__ == "__main__":
        g = grammar.Grammar()
        g.parse_grammar(test_Parser_pop.__doc__)
        convert = lambda grammar, node: node
        p = Parser(g, convert)
        p.setup()
        for t in tokenize.generate_tokens("x = 1\n"):
            p.addtoken(*t)
        assert p.rootnode[0] == NAME


# Generated at 2022-06-23 15:45:07.010943
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    def convert(grammar: Grammar, node: RawNode) -> Optional[Node]:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    class Dummy:
        def __init__(self, name: Text) -> None:
            self.name = name

        def __repr__(self) -> Text:
            return self.name

    g = grammar.Grammar()
    g.start = "start"
    g.add_nonterminal("start", ())
    g.add_terminal("NAME", "foo")
    g.add_terminal("NUMBER", "5")
    g.add_terminal("NAME", "bar")
    g.add_terminal("NL", "\\n")
   

# Generated at 2022-06-23 15:45:12.847861
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar()
    grammar.start = "foo"
    grammar.dfas["foo"] = dfa = ([[(0, 1), (2, 2)], [(0, 2)]], {2: 1})
    grammar.labels = [(1, "a"), (2, "b")]
    p = Parser(grammar)
    p.setup()
    assert p.addtoken(1, "a", None)
    assert isinstance(p.rootnode, Leaf)
    assert p.rootnode.value == "a"

# Generated at 2022-06-23 15:45:21.817988
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from blib2to3.pgen2 import tokenize

    p = Parser(grammar.grammar, lam_sub)
    p.setup()
    for q in tokenize.generate_tokens(open(grammar.__file__)):
        if p.addtoken(q[0], q[1], q[2]):
            break
    assert p.rootnode
    if __name__ == "__main__":
        p.rootnode.pretty_print()

# Generated at 2022-06-23 15:45:32.172796
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .unpacking_checker import checker

    Lexer = checker.grammar.dfas[0][2]["lexer"]
    t = Token(0, "the_name", (1, 1))
    assert 0 == Parser(checker.grammar).classify(t.type, t.value, t.context)
    t = Token(0, "if", (1, 1))
    assert 1 == Parser(checker.grammar).classify(t.type, t.value, t.context)
    t = Token(0, "else", (1, 1))
    assert 3 == Parser(checker.grammar).classify(t.type, t.value, t.context)
    t = Token(0, "True", (1, 1))

# Generated at 2022-06-23 15:45:38.807518
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    # Test case: no conversion
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in g.symbol2number:
        p.addtoken(token.NAME, t, Context(0, 0))
        if p.stack[-1][1] > 1:
            p.addtoken(token.OP, "|", Context(0, 0))

    p.addtoken(token.ENDMARKER, "", Context(0, 0))
    assert p.stack[-1][1] == 2
    assert len(p.rootnode) == len(g.symbol2number)

    # Test case: conversion
    g = grammar.grammar
    p = Parser(g, lam_sub)
    p.setup()

# Generated at 2022-06-23 15:45:49.971523
# Unit test for constructor of class ParseError
def test_ParseError():
    from blib2to3.pgen2.token import tok_name

    def parse_error(msg: str, type: Optional[int], value: Optional[str], context: Any):
        e = ParseError(msg, type, value, context)
        assert str(e) == "%s: type=%r, value=%r, context=%r" % (
            msg, tok_name.get(type, type), value, context
        )
        assert e.msg == msg
        assert e.type == type
        assert e.value == value
        assert e.context == context

    parse_error("msg", 1, "value", "context")
    parse_error("msg", None, None, "context")
    parse_error("msg", 1, None, None)

# Generated at 2022-06-23 15:45:56.441138
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser = Parser(Grammar())

    parser.stack = [(None, None, None), ("foo" , "bar")]
    parser.stack.pop()
    assert 1 == len(parser.stack)


# Note: Parser is not thread-safe; if you want to use it in a
# multithreaded environment you'll have to add locking.



# Generated at 2022-06-23 15:46:05.945749
# Unit test for method push of class Parser
def test_Parser_push():
    # one sequence of states
    seq1 = [(0, 0), (0, 1), (0, 2), (0, 3), (0, 4)]
    dfn1 = [seq1]
    dfa_0 = dfn1
    dfa_0_start = 0
    dfa_0_first = set(seq1)
    dfa_0_dfas = {0: (dfa_0, dfa_0_start), 1: (dfa_0, dfa_0_start),
                  2: (dfa_0, dfa_0_start), 3: (dfa_0, dfa_0_start),
                  4: (dfa_0, dfa_0_start)}
    dfa_0_dfas = dfa_0_dfas
    # other sequence of states

# Generated at 2022-06-23 15:46:17.297952
# Unit test for method push of class Parser
def test_Parser_push():
    # type: () -> None
    import pgen2.grammar
    import pgen2.pgen
    from . import pytree
    from . import python_grammar

    # Create a Parser instance
    g = pgen2.grammar.Grammar(python_grammar.grammar)
    p = Parser(g)

    # Parse something; results are in p.rootnode, an abstract syntax tree
    # that is a list of nodes.
    p.setup()
    p.addtoken(token.NAME, "f", pytree.Leaf(1, "f"))
    p.addtoken(token.LPAR, "(", pytree.Leaf(1, "("))
    p.addtoken(token.NAME, "x", pytree.Leaf(1, "x"))

# Generated at 2022-06-23 15:46:28.234082
# Unit test for constructor of class ParseError
def test_ParseError():
    # All 3 arguments are used.
    try:
        raise ParseError("foo", token.STRING, "bar", "baz")
    except ParseError as e:
        assert str(e) == (
            "foo: type=59 (STRING), value='bar', context='baz'"
        )
        assert e.msg == "foo"
        assert e.type == token.STRING
        assert e.value == "bar"
        assert e.context == "baz"

    # No value.
    try:
        raise ParseError("foo", token.STRING, None, "baz")
    except ParseError as e:
        assert str(e) == (
            "foo: type=59 (STRING), value=None, context='baz'"
        )
        assert e.msg == "foo"

# Generated at 2022-06-23 15:46:39.095059
# Unit test for method pop of class Parser
def test_Parser_pop():
    import os

    import unittest
    import warnings

    from . import token, tokenize
    from .pgen2 import driver, grammar

    from .pyparse import conseq

    from . import pytree

    # Suppress irrelevant ResourceWarnings under Python 3
    warnings.simplefilter("ignore", ResourceWarning)

    class TestParserMethods(unittest.TestCase):
        """Unit tests for class Parser."""

        def setUp(self):
            gendir = os.path.dirname(__file__)
            if gendir:
                gendir = os.path.dirname(gendir)
            if not gendir:
                gendir = "."
            self.gr_file = gendir + "/Grammar/Grammar"

# Generated at 2022-06-23 15:46:41.852405
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("illegal input", token.PLUS, "+", None)
    assert exc.msg == "illegal input"
    assert exc.type == token.PLUS
    assert exc.value == "+"
    assert exc.context is None

# Generated at 2022-06-23 15:46:52.659510
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .token import tok_name

    grammar_path = "c.grammar"

    grammar = Grammar(grammar_path)
    parser = Parser(grammar)
    parser.setup()


# Generated at 2022-06-23 15:47:02.337096
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar


# Generated at 2022-06-23 15:47:09.665143
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Unit test for method classify of class Parser"""
    from . import grammar, token

    p = Parser(grammar.grammar)  # type: ignore
    #test_Simple_Stmt
    p.setup(grammar.syms.simple_stmt)
    p.addtoken(token.NAME, "a", Context())
    p.addtoken(token.EQUAL, "=", Context())
    p.addtoken(token.NUMBER, "0", Context())

# Generated at 2022-06-23 15:47:18.517656
# Unit test for method shift of class Parser
def test_Parser_shift():
    import driver
    import blib2to3.fixer_base as fb
    import blib2to3.fixers.fix_print as fp
    grammar = driver.load_grammar()
    class Fixer(fb.BaseFix):
        # extend the class in order to provide a perform method
        pass
    class RemovePrintFixer(Fixer):
        pass
    fixer = RemovePrintFixer(grammar, (), {})
    node = Leaf(token.NAME, "print", None)
    newnode = fp.FixPrint(fixer, [node])
    p = Parser(grammar)
    p.setup()
    token.NAME
    context = Context(line=1)
    p.shift(token.NAME, "print", 0, context)

# Generated at 2022-06-23 15:47:28.739950
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import driver

    def get_tokenizer(text):
        return driver.Driver(grammar.grammar, convert=lam_sub).tokenize(text)

    p = Parser(grammar.grammar)
    p.setup()

    def parse(tokens, name):
        for type, value, context in tokens:
            p.addtoken(type, value, context)
        assert p.rootnode is not None
        if p.rootnode.type != grammar.syms[name]:
            return "ERROR"
        else:
            return "OK"

    def parse_success(tokens, name):
        assert parse(tokens, name) == "OK"


# Generated at 2022-06-23 15:47:31.131779
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar())
    p.setup()

# Generated at 2022-06-23 15:47:35.570334
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import re
    import sys

    import blib2to3.pgen2.tokenize as tokenize

    from blib2to3.pgen2 import token, driver
    from blib2to3.pgen2.parse import Parser
    from blib2to3.pygram import python_grammar


# Generated at 2022-06-23 15:47:40.218961
# Unit test for function lam_sub
def test_lam_sub():
    # Function lam_sub assumes nodes are RawNodes, and asserts that
    # the fourth slot is not None.  This test verifies that the slot
    # is not None.
    assert lam_sub(None, (0, 1, 2, 3))[3] is not None

# Generated at 2022-06-23 15:47:48.953874
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar()
    node = ('file_input', None, None, [])
    parent = ('x', None, None, [])
    parent[3].append(node)
    grammar.dfas = {}  # type: Dict[int, DFAS]
    result = lam_sub(grammar, parent)
    assert result[0] == 'x'
    assert result[2] is None
    assert len(result.children) == 1
    assert len(result.children[0].children) == 0
    assert result.children[0][0] == 'file_input'
    assert result.children[0][1] == 'file_input'

# Generated at 2022-06-23 15:48:01.061436
# Unit test for method shift of class Parser
def test_Parser_shift():
    import pickle

    g = pickle.load(open("Grammar/Grammar.pickle", "rb"))
    p = Parser(g)
    p.setup(start=1)
    if p.addtoken(3, "def", None):
        raise Exception("p.addtoken(3, 'def', None) = True")
    if p.addtoken(1, "f", None):
        raise Exception("p.addtoken(1, 'f', None) = True")
    if p.addtoken(10, ":", None):
        raise Exception("p.addtoken(10, ':', None) = True")
    if p.addtoken(4, "return", None):
        raise Exception("p.addtoken(4, 'return', None) = True")

# Generated at 2022-06-23 15:48:12.021771
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from . import token
    from .pgen import tokenize
    from .pygram import python_grammar

    p = Parser(python_grammar)
    p.setup()
    for (t, v, x, y) in tokenize.generate_tokens(iter(["return", "x", "*", "5"]).__next__):
        # print("Adding token:", token.tok_name[t], repr(v))
        p.addtoken(t, v, (0, 0))
    root = p.rootnode
    def dmp(root, indent):
        print(" " * indent + str(root))
        for child in root.children:
            dmp(child, indent + 4)
    dmp(root, 0)

# Generated at 2022-06-23 15:48:13.710846
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("foo", token.NAME, "abc", context=None)


# Generated at 2022-06-23 15:48:26.300967
# Unit test for method shift of class Parser
def test_Parser_shift():
    from pprint import pprint

    class Dummy:
        pass

    dummy = Dummy()

    # Test normal operation
    p = Parser(dummy)
    p.setup()
    dfa = ([(0, 1), (2, 3)], {0: [(0, 1)], 1: [(0, 1)], 2: [(0, 3)]})
    node = (1, 2, 3, [])
    p.stack = [(dfa, 0, node)]
    p.shift(4, 5, 1, 6)
    assert p.stack == [(([(0, 1), (2, 3)], {0: [(0, 1)], 1: [(0, 1)], 2: [(0, 3)]}), 1, (1, 2, 3, [5]))]

    # Test Error: type is not defined

# Generated at 2022-06-23 15:48:32.400605
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    from . import pgen

    # Construct a Parser object
    g = pgen.parse_grammar("Grammar/Grammar")
    p = Parser(g)

    # Call setup
    p.setup()

    # Call addtoken until it returns True
    t = driver.tokenize_file("Lib/inspect.py")
    try:
        while True:
            if p.addtoken(*next(t)):
                break
    except ParseError as e:
        print(e.msg)

if __name__ == "__main__":
    test_Parser_setup()

# Generated at 2022-06-23 15:48:34.549082
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar("""
        start: 's'
        """, "start")
    p = Parser(grammar)
    p.setup()


# Generated at 2022-06-23 15:48:40.548719
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(None)
    p.stack = [(None,None,None)]
    p.grammar = Grammar()
    p.grammar.dfas = {0: ([[(0, 0), (0, 0)]], set())}
    p.push(0, p.grammar.dfas[0], 0, None)
    assert str(p.stack[1]) == '(([[(0, 0), (0, 0)]], set()), 0, (0, None, None, []))'

# Generated at 2022-06-23 15:48:46.317458
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    import tempfile
    import sys
    import os
    import io

    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.tokenize import tokenize, generate_tokens
    from blib2to3.pytree import Leaf, LeafNode

    from . import driver as driver_mod
    from . import token, tokenize as tokenize_mod
    from .pygram import python_symbols as symbols
    

# Generated at 2022-06-23 15:48:58.300230
# Unit test for constructor of class Parser
def test_Parser():
    class GrammarX(Grammar):
        """A grammar with only two terminal symbols."""

        tokens = {
            token.PLUS: "PLUS",
            token.NUMBER: "NUMBER",
        }

        def p_a_b(self, args):
            """a : b"""
            # Do nothing

        def p_b_NUMBER_PLUS(self, args):
            """b : NUMBER PLUS"""

    g = GrammarX(None)
    p = Parser(g)
    p.setup()
    assert not p.addtoken(token.NUMBER, "1", (1, 0))
    assert not p.addtoken(token.PLUS, "+", (1, 2))
    assert p.addtoken(token.NUMBER, "2", (1, 4))

# Generated at 2022-06-23 15:49:02.369884
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError('test', 1, 2, 3)
    assert exc.type == 1
    assert exc.value == 2
    assert exc.context == 3
    # Test getattr
    assert getattr(exc, 'msg') == 'test'



# Generated at 2022-06-23 15:49:08.922900
# Unit test for method setup of class Parser
def test_Parser_setup():
    class DummyGrammar:
        start = 42
        dfas = (
            [[(0, 42)], [(0, 42)]],
            {
                42: 0,
                43: 1,
                44: 2,
            },
        )
        labels = [
            (256, None),
            (257, None),
            (258, None),
            (259, None),
        ]

    g = DummyGrammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas, 0, (42, None, None, []))]
    p.setup(43)
    assert p.stack == [(g.dfas, 1, (43, None, None, []))]

# Generated at 2022-06-23 15:49:13.902778
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("some error", token.NUMBER, "17", (1, 8))
    assert str(pe) == "some error: type=NUMBER, value='17', context=(1, 8)"


if __name__ == "__main__":
    test_ParseError()

# Generated at 2022-06-23 15:49:24.949158
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = Grammar()
    p = Parser(grammar)
    assert p.classify(token.NAME, 'a', None) == 255
    assert p.classify(token.NAME, 'x', None) == 255
    assert p.classify(token.NAME, 'xyzzy', None) == 255
    assert p.classify(token.NAME, 'if', None) == 1
    assert p.classify(token.NAME, 'elif', None) == 65
    assert p.classify(token.NAME, 'else', None) == 5
    assert p.classify(token.NAME, 'while', None) == 53
    assert p.classify(token.NAME, 'for', None) == 53
    assert p.classify(token.NAME, 'and', None) == 87

# Generated at 2022-06-23 15:49:29.677426
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    p = Parser(Grammar(grammar.Grammar, [], [], {}), {})
    p.setup()
    p.shift(1, 2, 3, 4)
    assert p.stack == [(None, None, (None, None, None, None))]

# Generated at 2022-06-23 15:49:39.778273
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class Mock(object):
        def __init__(self):
            self.addtoken = Parser.addtoken

    def test(seq, expected):
        seq = [("add", value) for value, ctx in seq]
        seq += [("end", None, None)]
        p = Mock()
        p.setup()
        actual = []
        while True:
            try:
                cmd, token, context = seq.pop(0)
            except IndexError:
                break
            if cmd == "add":
                done = p.addtoken(token, token, context)
            elif cmd == "end":
                done = p.addtoken(token, None, None)
            actual.append((cmd, token, done))
        assert actual == expected


# Generated at 2022-06-23 15:49:51.519076
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import pprint
    import pprint_data
    import sys

    # Adapted from test_output of test_2to3.py

    # Test data used to be in the files test.{input,output}
    # in the Tools/2to3/ directory.

    expected_output = pprint_data.expected_output.split('\n')[:-1]
    input = open(sys.path[-1] + '/test.input').read()

    from . import grammar
    from . import tokenize

    pg = grammar.grammar
    p = Parser(pg)
    p.setup()
    g = tokenize.generate_tokens(input)

    # In the old C output, we got the (1, ENDMARKER) from the lexer

# Generated at 2022-06-23 15:50:02.219806
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, tokenize

    def check_parse(input_):
        from . import driver
        from . import parse

        driver.run_driver(input_, parse, None, None, None, None, None)
    def convert(gram, node):
        """Not a real parser test so doesn't need to be real"""
        return None
    input = "foo"
    input_ = ["print(%s)" % input]

# Generated at 2022-06-23 15:50:12.238438
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2.driver import Driver
    import sys

    fn = sys.argv[1]
    d = Driver(fn, convert=lam_sub)
    p = Parser(d.grammar, d.convert)
    p.setup()
    for t in d.tokenize():
        p.addtoken(t[0], t[1], t[2])
    root = p.rootnode
    print(root)
    print(root.leaves())
    print(root.used_names)


if __name__ == "__main__":
    test_Parser()

# Generated at 2022-06-23 15:50:21.643025
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import os
    here = os.path.dirname(__file__) or os.curdir
    grammar = Grammar(os.path.join(here, "Grammar.txt"))
    p = Parser(grammar)
    p.setup()
    while 1:
        try:
            if p.addtoken(*raw_input().split(",")):
                break
        except ParseError as e:
            print("ParseError:", e)
            break
    print("Done with input.")

if __name__ == "__main__":
    test_Parser_addtoken()

# Generated at 2022-06-23 15:50:29.319585
# Unit test for method shift of class Parser
def test_Parser_shift():
  from blib2to3.pgen2.tokenize import detect_encoding
  from blib2to3.pgen2.parse import ParseError, Parser
  from blib2to3.pgen2.token import LPAR, RPAR
  from blib2to3.pgen2 import driver
  from blib2to3.pgen2.grammar import Grammar
  # Parse a program that contains only a parentheses
  # (taken from sys.argv[1])
  with open(sys.argv[1], 'r') as fp:
    # Get encoding
    encoding = detect_encoding(fp.readline)
    # Parse program
    grammar = driver.load_grammar('Grammar/Grammar', 'exec', '')
    parser = Parser(grammar)
    parser

# Generated at 2022-06-23 15:50:38.596796
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert g.start in g.symbol2number
    assert g.dfas[g.start]
    assert not p.stack
    assert p.addtoken(3, 'foo', (1, 0))
    assert not p.stack
    assert p.addtoken(1, 'bar', (2, 3))
    assert len(p.stack) == 1
    assert p.stack[0][:2] == (g.dfas[g.start], 0)
    assert p.stack[0][2][:3] == (g.start, None, None)