

# Generated at 2022-06-23 15:40:43.523586
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    def convert(grammar: Grammar, node: RawNode) -> Optional[Node]:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    _, symbols = grammar.parse_grammar(grammar.grammar)
    p = Parser(grammar.Grammar(grammar.start, symbols), convert)
    p.setup()
    tokens = [
        (token.NUMBER, "1", (1, 0)),
        (token.PLUS, "+", (1, 2)),
        (token.NUMBER, "2", (1, 4)),
        (token.NEWLINE, "\n", (1, 5)),
    ]

# Generated at 2022-06-23 15:40:51.582560
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import pickle

    t = pickle.load(open("Python.tbl", "rb"))
    p = Parser(t)
    p.setup()
    for line in sys.stdin:
        for type, value, begin, end, line in tokenize.generate_tokens(StringIO(line).readline):
            try:
                end_of_program = p.adddtoken(type, value, (begin[0], begin[1]))
            except tokenize.TokenError as msg:
                sys.stderr.write("%s\n" % msg)
            if end_of_program:
                break
        else:
            continue
        break

# Generated at 2022-06-23 15:41:02.556451
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .driver import Driver
    import sys
    from .pgen import generate_grammar

    driver = Driver(generate_grammar, convert=lam_sub)
    parser = Parser(driver.grammar)

    # Test parser with a sequence of tokens
    parser.setup()
    ttype = token.NT_OFFSET
    value = None
    context = Context(1, 0)
    while True:
        ttype, value, context = driver.get_next_token()
        if ttype == token.ENDMARKER:
            break
        parser.addtoken(ttype, value, context)

    # The test sequence is a single literal
    assert parser.rootnode[0] == SYM.file_input
    literal: Leaf = parser.rootnode[1][0]
    assert literal.type == token.STRING


# Generated at 2022-06-23 15:41:06.541255
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser(Grammar())


if __name__ == "__main__":
    # Run the unit tests
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 15:41:10.721569
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .tokenize import generate_tokens, STRING

    text = "'''abc'''\n"
    result: Sequence[Tuple[int, Text, int, int, Text]] = []
    for t in generate_tokens(iter(text).__next__, None):
        result.append(t)

    assert result[0][0] == STRING



# Generated at 2022-06-23 15:41:22.891817
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Test pop() method.
    # Make the grammar object with a single nonterminal.
    # The nonterminal has several productions,
    # and the parser state stacks might be nested 1 deep.
    # If a tree node is created, it should be added to a parent node's children
    # list, and that parent node should be returned as the converted node.
    from . import grammar
    from . import driver
    from . import tokenize
    from blib2to3.pygram import python_symbols
    
    t = token.TokenInfo("", token.NAME, "foo", None, 1, 0, "")
    t.parent = tokenize.Untokenizer(None) # type: ignore
    

# Generated at 2022-06-23 15:41:32.681291
# Unit test for method shift of class Parser
def test_Parser_shift():
    g = Grammar(r"""
    start: NAME
    NAME: 'name'
    """)
    p = Parser(g)
    p.setup()
    p.addtoken(1, "name", (1, 0))
    assert p.rootnode.type == g.symbol2number["start"]
    assert isinstance(p.rootnode.children[0], Leaf)
    assert p.rootnode.children[0].type == 1
    assert p.rootnode.children[0].value == "name"
    assert p.rootnode.children[0].context == (1, 0)

    # Using the optional convert argument of the Parser constructor
    def my_convert(g, node):
        # Don't convert the NAME tokens
        if node[0] == g.symbol2number["NAME"]:
            return None

# Generated at 2022-06-23 15:41:38.653357
# Unit test for method push of class Parser
def test_Parser_push():
    gp = Grammar()
    gp.syms = [0, 1, 2, 3]
    gp.start = 1
    gp.dfas = {
        1: (
            [(0, 0), (2, 1), (0, 5)],
            [(0, 5), (2, 1)],
            [(0, 1), (2, 2)],
            [(2, 3)],
            [(0, 2), (1, 4), (3, 1)],
            [(0, 4), (3, 5)],
        ),
        2: (
            [(2, 1)],
            [(0, 1), (1, 2), (3, 3)],
            [(2, 3)],
        ),
    }
    p = Parser(gp)
    p.setup()

# Generated at 2022-06-23 15:41:50.256777
# Unit test for function lam_sub
def test_lam_sub():
    """Test that the lam_sub function works as expected."""
    from . import grammar

    if not isinstance(grammar, Grammar):
        grammar.load_grammar(None)

    assert isinstance(grammar, Grammar)

    g = Parser(grammar)
    g.setup()
    g.addtoken(token.INDENT, "    ", (0, 20))
    g.addtoken(token.NEWLINE, "\n", (0, 20))
    g.addtoken(token.INDENT, "    ", (1, 20))
    g.addtoken(token.RETURN, "return", (1, 20))
    g.addtoken(token.NEWLINE, "\n", (1, 20))
    g.addtoken(token.DEDENT, "", (2, 20))

# Generated at 2022-06-23 15:41:59.164138
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver as DRIVER

    gr = DRIVER.load_grammar("Grammar.txt")
    pa = Parser(gr)
    pa.setup()
    ctx = Context(1, 0)

    for ttype in token.__all__:
        if isinstance(getattr(token, ttype), int):  # if ttype is a token constant
            pa.classify(getattr(token, ttype), ttype, ctx)
    assert pa.classify(token.INDENT, "INDENT", ctx) == 0
    assert pa.classify(token.DEDENT, "DEDENT", ctx) == 1

    pa.setup()
    context = Context(1, 1)
    assert pa.classify(token.NEWLINE, "\n", context) == 16
    assert pa.classify

# Generated at 2022-06-23 15:42:05.112548
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import Driver
    from . import tokens # import token
    import sys

    # Create grammar instance
    grammar = Driver.make_grammar()

    # Create parser instance
    parser = Parser(grammar)

    # Call method setup of instance parser
    parser.setup()

    # Create a list of tuples
    save: List[Tuple[int, Text, Context]] = []

    # Create an alias for the function addtoken of instance parser
    myaddtoken = parser.addtoken

    def addtoken(type: int, value: Text, context: Context) -> bool:
        save.append((type, value, context))
        return myaddtoken(type, value, context)

    # Assign alias to method addtoken of instance parser
    parser.addtoken = addtoken

    # Create an alias for the function pop of instance parser
   

# Generated at 2022-06-23 15:42:14.694391
# Unit test for method push of class Parser

# Generated at 2022-06-23 15:42:20.676229
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver

    p = driver.Parser()
    p.setup()
    assert p.stack == [p.stack[0]]
    assert p.stack[0][0] == 0
    assert p.stack[0][1] == 0
    assert p.stack[0][2][0] == 257
    assert p.stack[0][2][1] is None
    assert p.stack[0][2][2] is None
    assert p.stack[0][2][3] == []
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-23 15:42:32.568494
# Unit test for function lam_sub
def test_lam_sub():
    from . import token

    types = [token.NAME, token.NAME, token.NUMBER, token.ADD, token.ADD, token.LPAR]
    values = ['a', 'b', '42', '+', '+', '(']
    contexts = [None, None, None, None, None, None]
    nodes = [None, None, None, None, None, None]
    node = (2, 'expr', None, [])
    node[-1] = nodes
    assert lam_sub(None, node) == Node(
        type=2,
        children=(Leaf(1, 'a', None), Leaf(1, 'b', None)),
        context=None,
    )
    assert lam_sub(None, (3, 'add', None, None)) == Leaf(3, '+', None)

# Generated at 2022-06-23 15:42:41.553754
# Unit test for method pop of class Parser
def test_Parser_pop():
    Converter = Callable[[Grammar, RawNode], Union[Node, Leaf]]
    convert: Converter = lam_sub
    grammar: Grammar = Grammar()
    p: Parser = Parser(grammar, convert)
    p.setup()
    dfa: DFA = [
        [(0, 0)],
        [(0, 2)],
        [(0, 2)],
    ]
    dfas: DFAS = (dfa, {})
    type: int = token.NAME
    value: str = "print"
    context: Context = Context("example.py", 1, 2)
    p.push(type, dfas, 0, context)
    # Test if there is a Token to pop
    p.pop()
    # Test without Token to pop
    p.pop()

# Generated at 2022-06-23 15:42:49.133809
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = Grammar()
    con = Parser(grammar)
    con.setup()
    con.shift(1, 2, 3, 4)
    assert len(con.stack) == 1
    assert con.stack[0][0][0] == [(0, 0)]
    assert con.stack[0][1] == 3
    assert con.stack[0][2][0] == 1
    assert con.stack[0][2][1] == 2
    assert con.stack[0][2][2] == 4


# Generated at 2022-06-23 15:42:55.375120
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Tests that Parser.pop() doesn't mutate its arguements in place."""
    gr = Grammar('''
        start = foo
        foo = bar
        bar = baz
        baz = "baz"
        ''')
    conv = lambda g, n : n
    p = Parser(gr, conv)
    # The parts of a stack entry
    dfa = conv = state = node = object()
    # A lambda function which sets the global variables to the stack entry
    def foo() :
        global dfa, conv, state, node
        dfa, state, node = p.stack[-1]
    # Set up the parser stack
    p.push(gr.symbol2number['foo'], conv, 0, None)
    foo()

# Generated at 2022-06-23 15:42:56.722767
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    global ParseError, Parser
    import pytest

# Generated at 2022-06-23 15:43:07.525011
# Unit test for function lam_sub
def test_lam_sub():
    from . import token

    def convert(grammar, node):
        assert node[3] is not None
        ret = Node(type=node[0], children=node[3])
        return ret

    grammar = Grammar()
    grammar.symbol2number = {"keyword": 1, "name": 2, "num": 3}
    grammar.start = 1
    grammar.keywords = {"rhs": 3}
    grammar.dfas = {
        1: ([[(2, 1)], [(2, 3), (1, 11), (0, 16)], [(0, 16)], [(1, 4)]], {0: 16, 1: 4, 2: 3}),
        2: ([[(2, 3), (4, 4)]], {4: 4, 2: 3}),
    }

# Generated at 2022-06-23 15:43:14.518852
# Unit test for method setup of class Parser
def test_Parser_setup():
    import unittest
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.pgen import generate_grammar
    from blib2to3.pgen2 import token

    test_grammar = Grammar(generate_grammar("""
        (!!! at-rule)
        ;
        at-rule: "at" name "{" S* "}"
        ;
        name: /[a-z]+/
    """))

    test_case = unittest.TestCase()
    test_parser = Parser(test_grammar)
    test_parser.setup()


# Generated at 2022-06-23 15:43:19.811280
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .tokenize import generate_tokens, untokenize
    from . import grammar, tokenizer
    from blib2to3.pgen2.parse import parse_grammar

    g = parse_grammar(grammar, "file.grammar")
    p = Parser(g)

    def parse(s: str) -> NL:
        """Parse a Python source string and return the abstract syntax tree."""
        istr = io.StringIO(s)
        tokengen = generate_tokens(istr.readline)
        p.setup()
        for token in tokenizer.untokenize(tokengen):
            if p.addtoken(*token):
                break  # done
        else:
            raise ParseError("unexpected EOF")
        return p.rootnode


# Generated at 2022-06-23 15:43:31.452783
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .grammar import Grammar

    grammar = Grammar()
    p = Parser(grammar, convert=lam_sub)
    p.setup()
    assert p.addtoken(token.NAME, "if", None)
    assert p.addtoken(token.NAME, "x", None)
    assert p.addtoken(token.EQEQUAL, "==", None)
    assert p.addtoken(token.NUMBER, "10", None)
    assert p.addtoken(token.COLON, ":", None)

# Generated at 2022-06-23 15:43:35.730097
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver
    from . import grammar

    # Set up some test data
    num_states = 11

    # Create a parser object
    p = Parser(grammar.Grammar())
    p.classify = lambda *args: 1
    p.stack = [
        (
            (
                [],
                {
                    10: [
                        (
                            1,
                            1,
                        ),
                        (
                            1,
                            1,
                        ),
                        (
                            1,
                            1,
                        ),
                        (
                            1,
                            1,
                        ),
                        (
                            1,
                            1,
                        ),
                    ]
                },
            ),
            10,
            None,
        )
    ]

    # Call the method under test
    popnode

# Generated at 2022-06-23 15:43:46.705649
# Unit test for method push of class Parser
def test_Parser_push():
    if not __debug__:
        pytest.skip("parser tests are only run in debug mode")
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Python.gram")
    parser = Parser(grammar)
    parser.setup("file_input")
    parser.stack = [(grammar.dfas[10], 2, (10, None, None, []))]
    parser.push(1, grammar.dfas[1], 0, None)
    assert parser.stack == [
        (grammar.dfas[10], 2, (10, None, None, [])),
        (grammar.dfas[1], 0, (1, None, None, [])),
    ]

# Generated at 2022-06-23 15:43:57.471359
# Unit test for constructor of class Parser
def test_Parser():
    class DummyGrammar:

        def __init__(self) -> None:
            self.start = 23  # DUMMY

        def __getitem__(self, name: Text) -> Any:
            return getattr(self, name)

    dummy_grammar = DummyGrammar()
    p = Parser(dummy_grammar)
    assert p.grammar is dummy_grammar
    assert p.convert is lam_sub

    def myconvert(grammar: DummyGrammar, node: RawNode) -> NL:
        assert grammar is dummy_grammar
        return Node(type=node[0], children=node[3], context=node[2])

    p = Parser(dummy_grammar, myconvert)
    assert p.grammar is dummy_grammar
    assert p.con

# Generated at 2022-06-23 15:44:04.598647
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = Grammar()
    parse_tab = "testdata/parse_tab.py"
    grammar.load(parse_tab)
    parser = Parser(grammar)
    parser.setup()
    for token in tokenize(parse_tab):
        parser.addtoken(token.type, token.string, token.start)

# Generated at 2022-06-23 15:44:08.532118
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("dummy", 2, "dummy", None)
    assert err.msg == "dummy"
    assert err.type == 2
    assert err.value == "dummy"
    assert err.context is None
    assert str(err) == "dummy: type=2, value='dummy', context=None"

# Generated at 2022-06-23 15:44:11.921850
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg", None, None, None)
    except ParseError as exc:
        assert exc.msg == "msg"
        assert exc.type is None
        assert exc.value is None
        assert exc.context is None
    else:
        assert False

# Generated at 2022-06-23 15:44:13.863439
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver, grammar

    # Parse a single newline
    driver.run_parser("\n", "single_input", grammar, debug=False)

# Generated at 2022-06-23 15:44:22.753647
# Unit test for method push of class Parser
def test_Parser_push():
    class DummyDFAS:
        def __init__(self, t: int):
            self.dfa = [(0, 0), [(t, 1), (t, 2)]]
            self.labels = {t: t}

    d1 = DummyDFAS(3)
    d2 = DummyDFAS(4)
    grammar = Grammar({3: d1, 4: d2}, {2: d1})
    p = Parser(grammar, None)
    p.setup()
    p.push(3, d1, 0, None)
    assert p.stack == [(d1.dfa, 0, (0, None, None, [])), (d1.dfa, 0, (3, None, None, []))]
    p.push(4, d2, 0, None)
    assert p

# Generated at 2022-06-23 15:44:33.077427
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Arrange
    tokens = {
        token.NEWLINE: 1,
        token.NAME: 4,
        token.NUMBER: 4,
        token.STRING: 4,
    }
    grammar = Grammar(tokens, {}, [], [], [])
    parser = Parser(grammar)
    parser.setup()
    data = (("1+1", False), ("1+1\n", True))
    for data, expected in data:
        for i, t in enumerate(data):
            token_value = t
            token_type = tokens[token.NUMBER] if t.isdigit() else token.NAME
            context = token.string_to_context("f", 1, i)
            actual = parser.addtoken(token_type, token_value, context)
        # Assert
       

# Generated at 2022-06-23 15:44:35.738516
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError(None, None, None, None)
    assert err.args == ("None: type=None, value=None, context=None",)

# Generated at 2022-06-23 15:44:39.488778
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("msg", 1, "value", (2, 3))
    assert e.type == 1
    assert e.value == "value"
    assert e.context == (2, 3)
    assert str(e) == "msg: type=1, value='value', context=(2, 3)"

# Generated at 2022-06-23 15:44:45.978329
# Unit test for method shift of class Parser
def test_Parser_shift():
    # First we create an object of the class Parser
    from blib2to3.pgen2 import driver

    g = driver.load_grammar("Grammar.txt")
    p = Parser(g, lam_sub)
    # Then we invoke the method we want to test
    p.shift(0, "hello", 0, Context(0, 0))
    expected = [(0, "hello", None, None)]
    # Finally, we check that the result is what we expect
    assert p.stack[-1][2][3] == expected



# Generated at 2022-06-23 15:44:57.225589
# Unit test for constructor of class Parser
def test_Parser():
    import unittest
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.driver as driver

    grammar_path = "blib2to3/pgen2/Grammar.txt"
    g = grammar.Grammar()
    g.load(grammar_path)

    test_grammar = """
        a: 'a' b
        b: 'b'
        """
    td = driver.Driver(g, convert=lam_sub)
    td.parse_string(test_grammar, "test_grammar")

    class TestParser(unittest.TestCase):
        def test_display(self):
            p = Parser(td.g, convert=lam_sub)
            self.assertEqual(p.convert, lam_sub)

# Generated at 2022-06-23 15:45:07.565710
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    from pprint import pprint

    from . import driver, token

    p = driver.load_grammar()
    t = driver.Driver(p.grammar, Leaf(token.NL, "\n", p.context))
    try:
        while True:
            ttype, tvalue, lineno, offset = t.token()
            d = "\n    "
            print("tok: type=%r%svalue=%r%sline=%d%soffset=%d" % (
                ttype, d, tvalue, d, lineno, d, offset))
            if p.addtoken(ttype, tvalue, (lineno, offset)):
                break
    except ParseError as err:
        print("parse error")
        print("  message: %r" % err.msg)
       

# Generated at 2022-06-23 15:45:09.953914
# Unit test for function lam_sub
def test_lam_sub():
    grammar = Grammar()
    grammar.add_symbol("S", 1)
    node = ("S", None, None, [])
    result = lam_sub(grammar, node)
    assert isinstance(result, Node)
    assert result.type == "S"



# Generated at 2022-06-23 15:45:16.182714
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver
    from . import grammar
    from . import token

    def test_push(input: Text, expected: Sequence[Any]) -> None:
        p = Parser(grammar.Grammar())
        # Set start symbol
        p.setup(5)
        # Test tokenizer
        driver.ParserDriver(p, input).test()
        assert expected == p.stack

    test_push("2 + 3", [(grammar.Grammar().dfas[5], 0, (5, None, None, []))])
    test_push("(1 + 2", [(grammar.Grammar().dfas[5], 0, (5, None, None, [])), (grammar.Grammar().dfas[6], 0, (6, None, None, []))])

# Generated at 2022-06-23 15:45:28.546878
# Unit test for method push of class Parser
def test_Parser_push():
    from .token import NAME, NEWLINE
    from .grammar import Grammar, Nonterminal
    from .dfa import DFA
    import blib2to3.pgen2

    # Create a sample grammar
    start = Nonterminal('START', 1)
    nt_stmt = Nonterminal('stmt', 2)
    nt_expr = Nonterminal('expr', 3)
    nt_atom = Nonterminal('atom', 4)
    nl = (None, None, True)

# Generated at 2022-06-23 15:45:38.403386
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import token, grammar, pygram

    # Process a simple grammar
    p = Parser(pygram.python_grammar)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(pygram.tokens["PLUS"], "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(pygram.tokens["!="], "!=", (1, 6))
    p.addtoken(token.NUMBER, "3", (1, 9))
    p.addtoken(token.ENDMARKER, "", (1, 10))

    # Get the root node
    root = p.rootnode
    assert root.type == pygram.syms.file_

# Generated at 2022-06-23 15:45:43.791260
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .pgen import driver

    r = driver.parse_tokens("if")
    p = Parser(r)
    p.setup()
    p.addtoken(token.IF, "if", (1, 1))
    assert p.classify(token.IF, "if", (1, 1)) == 0

    r = driver.parse_tokens("x")
    p = Parser(r)
    p.setup()
    p.addtoken(token.NAME, "x", (1, 1))
    assert p.classify(token.NAME, "x", (1, 1)) == 1

    r = driver.parse_tokens("x")
    p = Parser(r, convert=None)
    p.setup()
    p.addtoken(token.NAME, "x", (1, 1))

# Generated at 2022-06-23 15:45:48.398388
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("random error", 3, "my test error", 3)
    except ParseError as exc:
        assert exc.type == 3
        assert exc.value == "my test error"
        assert exc.msg == "random error"
        assert exc.context == 3

# Generated at 2022-06-23 15:46:00.351391
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from blib2to3.pgen2.parse import load_grammar

    gr_file = "blib2to3/Python.g"
    gr = load_grammar(gr_file)

    text = "foo = '''This is a string'''"
    tok = tokenize.tokenize(StringIO(text).readline)
    p = Parser(gr.grammar)
    p.setup()
    for tokinfo in tok:
        type, value, context, _ = tokinfo
        if p.addtoken(type, value, context):
            break

    assert p.rootnode[0].value == "file_input"
    assert p.rootnode[1][0].value == "stmt"

# Generated at 2022-06-23 15:46:03.688813
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2 import grammartest

    # Use the parser module's test grammar
    g = grammartest.Grammar()
    p = Parser(g)
    p.setup()

# Generated at 2022-06-23 15:46:15.034062
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import python_grammar

    p = Parser(python_grammar)

    # A test list with (type, value, expected_classify) tuples.
    # type is the token type.
    # value is the token value.
    # expected_classify is the expected result of classify(type, value).

# Generated at 2022-06-23 15:46:26.127747
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.parse import ParseError
    from io import BytesIO
    from ast import Module, Name, Assign, Add, Sub, Div, Mult, Pow

    class Parser(Parser):
        def convert(self, grammar, node):
            # Arithmetic conversions
            if node[0] == token.PLUS:
                return node[1]
            elif node[0] == token.MINUS:
                if len(node[3]) == 1:
                    Arg1 = node[3][0]  # type: Any

# Generated at 2022-06-23 15:46:37.157703
# Unit test for method shift of class Parser
def test_Parser_shift():
    # From https://github.com/python/cpython/pull/12644/
    stack = []
    parser = Parser(None)

    parser.shift(1, "a", 0, None)
    stack[-1][-1][-1].append("Shift")
    assert stack == [(0, 0, (1, "a", None, ["Shift"]))]

    parser.shift(2, "a", 0, None)
    stack[-1][-1][-1].append("Shift")
    assert stack == [(0, 0, (2, "a", None, ["Shift"]))]

    parser.shift(3, "a", 0, None)
    stack[-1][-1][-1].append("Shift")
    assert stack == [(0, 0, (3, "a", None, ["Shift"]))]

# Generated at 2022-06-23 15:46:42.637222
# Unit test for method setup of class Parser
def test_Parser_setup():
    from pprint import pprint

    from blib2to3.pgen2 import driver

    def convert(g: Grammar, node: RawNode) -> NL:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    p = Parser(driver.load_grammar(), convert)
    pprint(p.grammar.dfas)
    p.setup()
    pprint(p.stack)
    # Done with the unit test

# Generated at 2022-06-23 15:46:48.755379
# Unit test for method shift of class Parser
def test_Parser_shift():
    dfa = []
    grammar = Grammar(dfa, [], {})
    parser = Parser(grammar)
    parser.stack.append((dfa, 0, ("%type", None, None, [])))
    parser.shift(token.PLUS, "+", 1, None)
    assert parser.stack == [(dfa, 1, ("%type", None, None, [("PLUS", "+", None, None)]))]



# Generated at 2022-06-23 15:46:57.004334
# Unit test for method setup of class Parser
def test_Parser_setup():
    import sys
    import unittest
    import blib2to3.pgen2.driver
    import blib2to3.pgen2.parse

    class TestParser(unittest.TestCase):
        def test_basic(self):
            import blib2to3.pgen2.grammar
            grammar = blib2to3.pgen2.grammar.Grammar()
            p = blib2to3.pgen2.parse.Parser(grammar)
            p.setup()

    unittest.main(argv=[sys.argv[0]])



# Generated at 2022-06-23 15:47:04.322247
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from . import token
    from . import driver
    from . import pgen
    from . import pgen2

    data = "a1"

    g = grammar.Grammar(pgen.pgen(pgen2.grammar, pgen2.syms))
    p = Parser(g, lam_sub)
    p.setup()
    for t in driver.tokenize_by_type(data):
        if p.addtoken(*t):
            break
    root = p.rootnode

# Generated at 2022-06-23 15:47:10.640705
# Unit test for method push of class Parser
def test_Parser_push():
    from .pygram import python_grammar_no_print_statement

    p = Parser(python_grammar_no_print_statement)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    assert p.stack == [(([[(4, 1), (3, 0)], [(3, 0)]], {4: 0}, 1), 0, (2, None, None, [('NAME', 'a', (1, 0), None)]))]
    p.push(1, ([[(1, 1)]], {}), 0, (1, 0))

# Generated at 2022-06-23 15:47:16.859597
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar.txt")
    p = Parser(grammar)
    p.setup("file_input")
    assert p.stack[-1] == (
        grammar.dfas["file_input"],
        0,
        (
            "file_input",
            None,
            None,
            [],
        ),
    )

# Generated at 2022-06-23 15:47:27.818244
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .token import tok_name
    from .pgen import driver

    g = driver.load_grammar("Grammar/Grammar")
    p = Parser(g)
    p.setup()

    # Test parser.shift with default tok_name
    def test(tok, type, val, state, ctx, name):
        tok.type = type
        tok.string = val
        p.stack[-1] = (g.dfas[0], state, (0, None, None, []))
        p.shift(type, val, state, ctx)
        print(f"{tok_name[type]} -> {name}")

    test(_tok(0, ""), 2, "in", 16, None, "NAME")

# Generated at 2022-06-23 15:47:32.509704
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("msg", 0, "val", Context)
    assert "msg" == pe.msg
    assert 0 == pe.type
    assert "val" == pe.value
    assert Context == pe.context



# Generated at 2022-06-23 15:47:41.353419
# Unit test for constructor of class Parser
def test_Parser():
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2 import tokenize, driver
    from blib2to3.pgen2.grammar import Grammar

    grammar = """
    S: NAME dots | NAME
    dots: NAME '.' dots | NAME
    %ignore '\\n'
    """
    d = driver.Driver(grammar, convert=lam_sub)
    t = tokenize.generate_tokens(d.grammar)
    try:
        t.send(None)
    except BaseException:
        pass
    p = Parser(d.grammar)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 1))
    p.addtoken(token.NAME, "b", (1, 1))

# Generated at 2022-06-23 15:47:51.541645
# Unit test for method pop of class Parser
def test_Parser_pop():
    # test f_1()
    class A:
        def f_1(self, i):
            def f_2(self, i):
                def f_3(self, i):
                    pass
                pass
            pass
    
    def f_1(self, i):
        def f_2(self, i):
            def f_3(self, i):
                pass
            pass
        pass

    # test f_1()
    class A:
        def f_1(self, i):
            def f_2(self, i):
                def f_3(self, i):
                    pass
                pass
            pass
    
    def f_1(self, i):
        def f_2(self, i):
            def f_3(self, i):
                pass
            pass
        pass

   

# Generated at 2022-06-23 15:48:03.573661
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar
    from .driver import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    driver(p, g, [("NAME", "a", (1, 0)), ("NAME", "b", (1, 1))], 1)
    r = p.rootnode
    assert r.type == g.symbol2number["file_input"]
    assert str(r) == "file_input([stmt([expr_stmt([testlist_gexp(test([or_test([and_test([not_test([comparison([expr([xor_expr([and_expr([shift_expr([arith_expr([term([factor([power([atom([NAME('a')])])])])])])])])])])]), 'b')])])])])"



# Generated at 2022-06-23 15:48:13.711287
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # This is a port of the parser module's test_Parser_addtoken().
    import unittest
    import io
    import operator


    class TestCase(unittest.TestCase):

        def setUp(self):
            self.grammar = grammar = Grammar()
            grammar.start = 256
            grammar.dfas = {
                256: ([[(1, 256), (2, 256)], [(0, 1), (3, 256), (2, 256)]], {0: 2}),
                258: ([[(4, 258)], [(4, 258)], [(4, 258)], [(0, 3), (4, 258)]], {0: 3}),
            }

# Generated at 2022-06-23 15:48:17.131215
# Unit test for method setup of class Parser
def test_Parser_setup():
    from .pgen2.driver import Driver
    driver = Driver()
    driver.load_grammar("./Examples/doctest/Grammar.txt")
    res = driver.parse_tokens([(1, 'def')])
    assert res == [], res


# Generated at 2022-06-23 15:48:27.490674
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest
    import unittest.mock
    class MockGrammar(object):
        tokens = {1: 10, 2: 11}
        dfas = {}
        tokens = {1: 10, 2: 11}

    class MockDFS(object):
        def __init__(self, states: List[List[Tuple[int, int]]], first: Dict[int, int]) -> None:
            self.states = states
            self.first = first

    test = Parser(MockGrammar())

    GRAMMAR_TUPLE = tuple(MockGrammar())
    DFS_TUPLE = tuple(MockDFS([[(1, 1), (2, 2)], [(0, 1), (3, 2)]], {1: 1, 0: 1}))
    test.stack

# Generated at 2022-06-23 15:48:35.728248
# Unit test for method classify of class Parser
def test_Parser_classify():
    P = Parser(Grammar())
    assert P.classify(token.NAME, "abc", None) == 1
    assert P.classify(token.NAME, "and", None) == 4
    assert P.classify(token.NAME, "or", None) == 5
    assert P.classify(token.NAME, "not", None) == 6
    try:
        P.classify(token.NAME, "xxx", None)
    except ParseError:
        pass
    else:
        assert 0, "failed to raise ParseError"

# Generated at 2022-06-23 15:48:42.566061
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import tokenize
    import os

    pgen_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'Parser', 'Grammar_pgen.py')
    if not os.path.isfile(pgen_path):
        print("Skipping test_Parser_classify as Grammar_pgen.py is missing")
        return

    p = Parser(grammar.Grammar(open(pgen_path, 'rb').read()))
    p.setup()

    tokens = []
    for token_in in tokenize.generate_tokens_convert(open(pgen_path, 'rb').readline):
        tokens.append(token_in)

    for token_in in tokens:
        p.classify

# Generated at 2022-06-23 15:48:52.111477
# Unit test for function lam_sub
def test_lam_sub():
    g = Grammar()
    g.add_symbol("foo", 43)
    g.add_symbol("bar", 44)
    g.add_symbol("baz", 45)
    g.add_token("NAME", 46)
    g.add_token("NUMBER", 47)
    g.set_root("foo")
    g.make_dfas()
    n = lam_sub(g, ("foo", None, None, [("bar", "b", None, [("baz", None, None, None)]), ("NAME", "x", None, None)]))
    assert n.type == 43
    assert len(n.children) == 2
    assert n.children[0].type == 44
    assert n.children[1].type == 46

# Generated at 2022-06-23 15:49:02.621992
# Unit test for function lam_sub
def test_lam_sub():
    from .grammar import Grammar
    import sys

    # Realistic test grammar

# Generated at 2022-06-23 15:49:06.368464
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test", 0, "foo", None)
    except ParseError as e:
        assert e.msg == "test"
        assert e.type == 0
        assert e.value == "foo"
        assert e.context is None
    else:
        raise Exception("ParseError constructor failed to raise exception")

# Generated at 2022-06-23 15:49:10.500018
# Unit test for method classify of class Parser
def test_Parser_classify():
    p = Parser(Grammar)
    assert p.classify(token.NAME, "print", None) == 9
    assert p.classify(token.LPAR, None, None) == 2
    assert p.classify(token.NUMBER, "1", None) == 1
    try:
        p.classify(token.STRING, "''", None)
        assert False, "didn't raise exception"
    except ParseError:
        pass

# Generated at 2022-06-23 15:49:22.338227
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    # Test grammar for simple addition and subtraction expressions
    # (from http://effbot.org/zone/simple-top-down-parsing.htm)
    V = token.NAME  # token type for variables
    ADDOP = token.PLUS  # token type for +
    SUBOP = token.MINUS  # token type for -
    LPAR = token.LPAR  # token type for (
    RPAR = token.RPAR  # token type for )

    # Create a Grammar instance and parse the grammar
    grammar = Grammar(
        """
        e : e ADDOP t
          | e SUBOP t
          | t
        t : LPAR e RPAR
          | V
        """
    )
    grammar.parse()

    # Create a Parser instance and call the setup method
    parser = Parser(grammar)

# Generated at 2022-06-23 15:49:25.081036
# Unit test for function lam_sub
def test_lam_sub():
    from . import grammar

    g = grammar.Grammar()
    lam_sub(g, (1, "a", (1, 0), None))

# Generated at 2022-06-23 15:49:35.746292
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar(r'blib2to3/pgen2/Grammar.txt'), lam_sub)
    p.setup()
    assert p.stack == [(
        ([[(3, 1), (4, 1)], [(6, 2), (0, 1)], [(0, 2)], [(9, 3), (0, 3)],
         [(0, 4)], [(0, 5)], [(0, 6)], [(0, 7)], [(0, 8)], [(0, 9)], [(0, 10)],
         [(0, 11)]],
        {3: 0, 4: 0, 6: 1, 9: 3}),
        0,
        (1, None, None, []))]



# Generated at 2022-06-23 15:49:42.298325
# Unit test for method classify of class Parser
def test_Parser_classify():
    import pytest

    class MockGrammar(object):
        def __init__(self) -> None:
            self.tokens = {token.NAME: 1, token.NUMBER: 2}
            self.keywords = {}

    mock_grammar = MockGrammar()
    p = Parser(mock_grammar)

    expected = 1
    actual = p.classify(token.NAME, "abc", None)
    assert actual == expected
    actual = p.classify(token.NAME, "def", None)
    assert actual == expected

    with pytest.raises(ParseError):
        p.classify(token.NUMBER, "", None)

# Generated at 2022-06-23 15:49:52.714811
# Unit test for method pop of class Parser
def test_Parser_pop():
    class Grammar(object):
        def __init__(self, r):
            self.dfas = r

    class TestNode(object):
        def __init__(self, *args):
            self.args = args

    class TestParser(Parser):
        def __init__(self, *args):
            self.grammar = Grammar(args[0])

        def convert(self, *args):
            return TestNode(*args)

    np = TestParser(None, None)
    np.stack = [(None, None, None), (1, 2, 3)]
    assert np.pop() is None
    assert np.stack == [(None, None, TestNode(None, None, (1, None, None, 3)))], np.stack
    np.stack = [(1, 2, 3)]
    assert np.pop() is None

# Generated at 2022-06-23 15:50:02.677410
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = Grammar()
    grammar.parse(b"""
    start: a b
    a: 'a'
    b: 'b'
    """)
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.STRING, "a", (1, 0))
    parser.addtoken(token.STRING, "b", (1, 0))
    node = parser.rootnode
    assert node[0] == "start"
    assert len(node) == 3
    node = node[2][0]
    assert node[0] == "a"
    assert len(node) == 3
    node = node[2][0]
    assert node[0] == "b"
    assert len(node) == 3

# Generated at 2022-06-23 15:50:13.247527
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import parsetok  # type: ignore

    def convert(grammar, node):
        return node

    def parse_string(s):
        grammar = parsetok.Grammar()
        p = Parser(grammar, convert)
        p.setup()
        for token in p.grammar.tokenize(s):
            p.addtoken(token[0], token[1], token[2])
        return p.rootnode

    s = "hello there"
    assert parse_string(s) is not None
    # Testing issue 4442 - check no infinite loop.
    Parser(parsetok.Grammar(), convert)

# Generated at 2022-06-23 15:50:23.851234
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import (
        driver,
        pgen,
        pytree,
        tokenize,
    )

    from .pgen2 import (
        parse,
        tokenize as tokenize_pgen,
    )

    driver.compile("""if True:
        x = ''
        def f():
            if True:
                pass
        if True:
            pass
    if True:
        pass
    """)
    driver.compile("""if True:
        pass
    else:
        pass
    """)

    grammar: Grammar = pgen.grammar()
    parser: Parser = Parser(grammar)

    def _parse(s: str) -> None:
        parser.setup()

# Generated at 2022-06-23 15:50:30.412915
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar())
    p.setup()
    p.shift(token.NAME, 'x', 1, (1, 1))
    assert p.stack == [(Grammar().dfas[Grammar().start], 1, [(Grammar().start, None, (1, 1), [])])]

# Generated at 2022-06-23 15:50:36.771137
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    program = "for i in [1, 2, 3]: print(i)"

    # Mock tokenizer
    class MockTokenizer:
        def __init__(self, program: Text) -> None:
            self.program = program.split()
            self.index = 0

        def tokenize(self) -> tokenize.TokenInfo:
            result = self.program[self.index]
            self.index += 1
            return tokenize.TokenInfo(-1, result, (0, 0), (0, 0))

    # Create a parser, and prepare it to parse
    p = Parser(driver.grammar)
    p.setup()

    # Feed tokens to the parser
    tokenizer = MockTokenizer(program)
    for expected in program.split():
        t = tokenizer.tokenize()