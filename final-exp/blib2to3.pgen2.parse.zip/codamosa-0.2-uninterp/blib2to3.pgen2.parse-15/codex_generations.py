

# Generated at 2022-06-17 16:50:18.156556
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar
    from . import tokenize
    import io
    import sys

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Parse a simple expression
    p.setup()
    for t in tokenize.generate_tokens(io.StringIO("1+2").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1
    assert p.rootnode.children

# Generated at 2022-06-17 16:50:29.427378
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    g.start = 256
    g.dfas = {256: ([[(1, 1), (0, 2)], [(0, 2)]], {1: 1, 2: 1})}
    p = Parser(g)
    p.setup()
    p.push(256, p.grammar.dfas[256], 0, None)
    assert p.stack == [(p.grammar.dfas[256], 0, (256, None, None, []))]
    p.shift(token.NAME, "foo", 1, None)

# Generated at 2022-06-17 16:50:39.839514
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))
    p.addtoken

# Generated at 2022-06-17 16:50:52.394655
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test/input/future1.txt")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1

# Generated at 2022-06-17 16:50:59.242442
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break
    # Check the result
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["expr_stmt"]

# Generated at 2022-06-17 16:51:12.218246
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "def", (1, 0))
    p.addtoken(token.NAME, "f", (1, 4))
    p.addtoken(token.OP, "(", (1, 5))
    p.addtoken(token.OP, ")", (1, 6))
    p.addtoken(token.OP, ":", (1, 7))
    p.addtoken(token.NEWLINE, "\n", (1, 8))
    p.addtoken(token.INDENT, "    ", (2, 0))
    p.addtoken(token.NAME, "return", (2, 4))
    p.addtoken(token.NAME, "x", (2, 10))

# Generated at 2022-06-17 16:51:22.493451
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Tokenize a program
    s = "x = 1"
    t = tokenize.generate_tokens(s.__iter__().__next__)

    # Feed the tokens to the parser
    for type, value, context in t:
        if p.addtoken(type, value, context):
            break

    # Get the result
    print(p.rootnode)

# Generated at 2022-06-17 16:51:34.458744
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(token.NAME, "a", 0, (1, 0))
    p.shift(token.NAME, "b", 0, (1, 0))
    p.shift(token.NAME, "c", 0, (1, 0))
    p.shift(token.NAME, "d", 0, (1, 0))
    p.shift(token.NAME, "e", 0, (1, 0))
    p.shift(token.NAME, "f", 0, (1, 0))
    p.shift(token.NAME, "g", 0, (1, 0))
    p.shift(token.NAME, "h", 0, (1, 0))
   

# Generated at 2022-06-17 16:51:43.272868
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 3))
    p.addtoken(token.EQUAL, "=", (1, 5))
    p.addtoken(token.NUMBER, "42", (1, 7))
    p.addtoken(token.NEWLINE, "\n", (1, 10))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.root

# Generated at 2022-06-17 16:51:49.982087
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [1, "a"]))]

# Generated at 2022-06-17 16:52:07.558218
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    g.start = "file_input"

# Generated at 2022-06-17 16:52:18.497108
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import grammar

    class TestParser(unittest.TestCase):
        def setUp(self):
            self.p = Parser(grammar.Grammar())

        def test_addtoken(self):
            self.p.setup()
            self.assertFalse(self.p.addtoken(token.NAME, "a", None))
            self.assertFalse(self.p.addtoken(token.EQUAL, "=", None))
            self.assertFalse(self.p.addtoken(token.NUMBER, "1", None))
            self.assertTrue(self.p.addtoken(token.NEWLINE, "\n", None))

    unittest.main()

# Generated at 2022-06-17 16:52:26.856856
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)
    p

# Generated at 2022-06-17 16:52:36.506091
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.shift(token.NAME, "foo", 0, None)
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, [Leaf(token.NAME, "foo")]))]
    p.shift(token.NAME, "bar", 0, None)
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, [Leaf(token.NAME, "foo"), Leaf(token.NAME, "bar")]))]
    p.shift(token.NAME, "baz", 0, None)

# Generated at 2022-06-17 16:52:51.847335
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.token import Token
    from blib2to3.pytree import Leaf
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2.convert import convert_tree
    from blib2to3.pgen2.pgen import tokenize
    from blib2to3.pgen2.pgen import generate_grammar
    from blib2to3.pgen2.pgen import generate_grammar_pickle
    from blib2to3.pgen2.pgen import generate_grammar_zip
    from blib2to3.pgen2.pgen import generate

# Generated at 2022-06-17 16:52:54.293353
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None



# Generated at 2022-06-17 16:53:07.215608
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:53:18.945705
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Test the parser on a simple expression
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["expr"]
    assert len(p.rootnode.children[0].children) == 3
    assert p.rootnode.children[0].children[0].type == token.NUMBER
    assert p.rootnode.children[0].children[1].type

# Generated at 2022-06-17 16:53:31.007930
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.classify(token.NAME, "foo", None)
    p.classify(token.NAME, "None", None)
    p.classify(token.NAME, "True", None)
    p.classify(token.NAME, "False", None)
    p.classify(token.NAME, "and", None)
    p.classify(token.NAME, "or", None)
    p.classify(token.NAME, "not", None)
    p.classify(token.NAME, "is", None)
    p.classify(token.NAME, "in", None)
    p.classify(token.NAME, "lambda", None)

# Generated at 2022-06-17 16:53:43.024440
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2 import driver
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pytree import Leaf, Node
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.pgen import generate_grammar

    # Generate a grammar
    grammar = Grammar(generate_grammar("Grammar.txt"))

    # Create a parser
    parser = Parser(grammar)

    # Prepare for parsing
    parser.setup()

    # Parse a token
    parser.shift(token.NAME, "a", 1, (1, 0))

    # Check the result

# Generated at 2022-06-17 16:54:03.181599
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(token.NUMBER, "1", 1, Context(1, 0))
    assert p.stack == [(g.dfas[g.start], 1, (g.start, None, None, [Leaf(token.NUMBER, "1", Context(1, 0))]))]
    p.shift(token.NUMBER, "2", 2, Context(1, 0))
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(token.NUMBER, "1", Context(1, 0)), Leaf(token.NUMBER, "2", Context(1, 0))]))]


# Generated at 2022-06-17 16:54:15.166562
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()

    # Test for a simple expression
    s = "1 + 2"
    for type, value, start, end, line in tokenize.generate_tokens(s):
        p.addtoken(type, value, (start, end))
    assert p.rootnode.type == g.symbol2number["expr"]
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[1].value == "+"
    assert p.rootnode.children[2].type == token.NUMBER

# Generated at 2022-06-17 16:54:27.290631
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Parse a simple expression
    p.setup()
    for t in tokenize.generate_tokens(driver.expr("1+2")):
        if p.addtoken(t.type, t.string, t.start):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["testlist"]
    assert len(p.rootnode.children[0].children) == 1

# Generated at 2022-06-17 16:54:35.098198
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.pgen import driver

    g = Grammar()
    g.load_grammar(driver.grammar)
    p = Parser(g)
    p.setup()
    for type, value, context in generate_tokens(
        "x = 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10"
    ):
        if p.addtoken(type, value, context):
            break
    assert p.rootnode.type == g.symbol2number["file_input"]

# Generated at 2022-06-17 16:54:50.085913
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver

    def convert(grammar, node):
        return node

    p = Parser(driver.grammar, convert)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:55:01.779813
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:55:12.166307
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import tokenize

    # Create a parser
    p = driver.Driver(grammar, convert)

    # Create a tokenizer
    t = tokenize.generate_tokens(StringIO("abc").readline)

    # Feed the parser with tokens
    p.setup()
    for type, value, context in t:
        if p.addtoken(type, value, context):
            break

    # Check the result
    assert p.rootnode.type == symbol.file_input
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == token.NAME
    assert p.rootnode.children[0].value == "abc"


# Generated at 2022-06-17 16:55:24.047599
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.PLUS, "+", (1, 6))
    p.addtoken(token.NUMBER, "3", (1, 8))
    p.addtoken(token.PLUS, "+", (1, 10))
    p.addtoken(token.NUMBER, "4", (1, 12))
    p.addtoken(token.PLUS, "+", (1, 14))

# Generated at 2022-06-17 16:55:28.924532
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import token

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)
    # Create a node
    popnode = (token.NAME, "test", None, [])
    # Create a stack
    stack = [(None, None, None)]
    # Call the method
    p.stack = stack
    p.pop()
    # Check the result
    assert p.stack == []
    assert p.rootnode == popnode

# Generated at 2022-06-17 16:55:36.267703
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for type, value, start, end, line in tokenize.generate_tokens(open("test.py")):
        if p.addtoken(type, value, (start, end)):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:55:49.149565
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, 2, 3, 4)
    assert p.stack == [(2, 0, (1, None, 4, []))]

# Generated at 2022-06-17 16:55:54.700340
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import os
    import unittest
    from . import driver
    from . import grammar
    from . import token


# Generated at 2022-06-17 16:56:06.144618
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(1, "a")]))]
    p.shift(2, "b", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [Leaf(1, "a"), Leaf(2, "b")]))]
    p.shift(3, "c", 4, None)

# Generated at 2022-06-17 16:56:18.784834
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 1))
    p.addtoken(token.NAME, "c", (1, 2))
    p.addtoken(token.NAME, "d", (1, 3))
    p.addtoken(token.NAME, "e", (1, 4))
    p.addtoken(token.NAME, "f", (1, 5))
    p.addtoken(token.NAME, "g", (1, 6))
    p.addtoken(token.NAME, "h", (1, 7))

# Generated at 2022-06-17 16:56:30.410236
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, []))]
    p.push(3, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, [])), (None, 0, (3, None, None, []))]


# Generated at 2022-06-17 16:56:42.670273
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "def", (1, 0))
    p.addtoken(token.NAME, "f", (1, 4))
    p.addtoken(token.OP, "(", (1, 5))
    p.addtoken(token.OP, ")", (1, 6))
    p.addtoken(token.OP, ":", (1, 7))
    p.addtoken(token.NEWLINE, "\n", (1, 8))
    p.addtoken(token.INDENT, "    ", (2, 0))
    p.addtoken(token.NAME, "return", (2, 4))
    p.addtoken(token.NAME, "x", (2, 10))

# Generated at 2022-06-17 16:56:53.288480
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    def convert(grammar, node):
        return node

    p = Parser(grammar.grammar, convert)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test/test_grammar.py")):
        if t.type == token.ENDMARKER:
            break
        p.addtoken(t.type, t.string, t.start)
    assert p.rootnode is not None
    assert p.rootnode[0] == grammar.syms.file_input
    assert len(p.rootnode[1]) == 1
    assert p.rootnode[1][0][0] == grammar.syms.stmt

# Generated at 2022-06-17 16:56:58.699365
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import os
    import unittest
    from . import driver
    from . import grammar
    from . import token

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            # Create a parser
            g = grammar.Grammar()
            p = Parser(g)
            # Add a token
            p.setup()
            p.addtoken(token.NAME, "foo", (1, 0))
            # Check the result
            self.assertEqual(p.rootnode.type, token.NAME)
            self.assertEqual(p.rootnode.value, "foo")
            self.assertEqual(p.rootnode.context, (1, 0))
            self.assertEqual(p.rootnode.children, [])

    # Run the unit tests
   

# Generated at 2022-06-17 16:57:09.335530
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.shift(token.NAME, "foo", 1, None)
    assert p.stack == [(g.dfas[g.start], 1, (g.start, None, None, [Leaf(token.NAME, "foo")]))]
    p.shift(token.NAME, "bar", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(token.NAME, "foo"), Leaf(token.NAME, "bar")]))]


# Generated at 2022-06-17 16:57:21.590325
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import token
    from . import tokenize

    p = Parser(grammar.grammar)
    p.setup()
    # Test for a simple program
    test_program = "a = 1"
    tokens = tokenize.generate_tokens(test_program)
    for type, value, start, end, line in tokens:
        if p.addtoken(type, value, (start, end)):
            break
    assert p.rootnode.children[0].children[0].value == "a"
    assert p.rootnode.children[0].children[1].value == "="
    assert p.rootnode.children[0].children[2].value == "1"
    # Test for a program with an error

# Generated at 2022-06-17 16:57:53.349699
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            # Test the addtoken method of class Parser
            p = driver.Parser()
            p.setup()
            p.addtoken(token.NAME, "a", (1, 0))
            p.addtoken(token.NAME, "b", (1, 0))
            p.addtoken(token.NAME, "c", (1, 0))
            p.addtoken(token.NAME, "d", (1, 0))
            p.addtoken(token.NAME, "e", (1, 0))
            p.addtoken(token.NAME, "f", (1, 0))
            p.addtoken(token.NAME, "g", (1, 0))
            p.addtoken

# Generated at 2022-06-17 16:58:04.197639
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    g.load_grammar("Grammar/Grammar")
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.COLON, ":", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.INDENT, "", None)
    p.addtoken(token.NAME, "pass", None)
    p.addtoken(token.DEDENT, "", None)
    p.addtoken(token.ENDMARKER, "", None)
    assert p.rootnode is not None
    assert p.rootnode.type

# Generated at 2022-06-17 16:58:15.898679
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar

    # Load the grammar
    g = grammar.grammar

    # Create a parser
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    driver.addtoken(p, token.NUMBER, "1", (1, 0))
    driver.addtoken(p, token.PLUS, "+", (1, 2))
    driver.addtoken(p, token.NUMBER, "2", (1, 4))
    driver.addtoken(p, token.NEWLINE, "\n", (1, 5))

    # Check the result
    assert p.rootnode is not None
    assert len(p.rootnode) == 3
    assert p.rootnode[0].type == token.NUMBER

# Generated at 2022-06-17 16:58:25.740439
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:58:38.359395
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))
    p.addtoken(token.NAME, "garply", (1, 0))

# Generated at 2022-06-17 16:58:52.693397
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 2
    assert p.rootnode.children[0].type == g.symbol2number["expr"]

# Generated at 2022-06-17 16:59:04.974465
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, 2, 3, 4)
    assert p.stack == [(2, 0, (1, None, 4, []))]
    p.push(5, 6, 7, 8)
    assert p.stack == [(2, 0, (1, None, 4, [])), (6, 0, (5, None, 8, []))]
    p.push(9, 10, 11, 12)
    assert p.stack == [(2, 0, (1, None, 4, [])), (6, 0, (5, None, 8, [])), (10, 0, (9, None, 12, []))]
    p.pop()

# Generated at 2022-06-17 16:59:12.297048
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, 2, 3, 4)
    assert p.stack == [(2, 0, (1, None, 4, []))]
    p.push(5, 6, 7, 8)
    assert p.stack == [(2, 0, (1, None, 4, [])), (6, 0, (5, None, 8, []))]
    p.pop()
    assert p.stack == [(2, 0, (1, None, 4, [(5, None, 8, [])]))]
    p.pop()
    assert p.stack == []
    assert p.rootnode == (1, None, 4, [(5, None, 8, [])])


# Generated at 2022-06-17 16:59:18.572148
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode.type == g.symbol2number["expr_stmt"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["expr"]
    assert len(p.rootnode.children[0].children) == 3
    assert p.rootnode.children[0].children[0].type == token.NUMBER

# Generated at 2022-06-17 16:59:28.417574
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)
   