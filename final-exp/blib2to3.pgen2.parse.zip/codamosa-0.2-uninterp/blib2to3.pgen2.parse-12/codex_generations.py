

# Generated at 2022-06-17 16:50:18.049562
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 3))
    p.addtoken(token.EQUAL, "=", (1, 5))
    p.addtoken(token.NAME, "y", (1, 7))
    p.addtoken(token.NEWLINE, "\n", (1, 8))
    p.addtoken(token.INDENT, "", (2, 0))
    p.addtoken(token.NAME, "print", (2, 4))
    p.addtoken(token.NAME, "x", (2, 9))

# Generated at 2022-06-17 16:50:29.353731
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    def test(s: str, expected: Sequence[Any]) -> None:
        p = Parser(driver.grammar)
        p.setup()
        for t in driver.tokenize(s):
            if p.addtoken(*t):
                break
        assert p.rootnode.children == expected

    test("1", [1])
    test("1+2", [1, "+", 2])
    test("1+2+3", [1, "+", 2, "+", 3])
    test("1+2*3", [1, "+", [2, "*", 3]])
    test("1*2+3", [[1, "*", 2], "+", 3])
    test("1*(2+3)", [1, "*", [2, "+", 3]])

# Generated at 2022-06-17 16:50:33.028965
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (([(0, 0)], [(0, 0)]), {}), 0, None)
    assert p.stack == [(
        (([(0, 0)], [(0, 0)]), {}),
        0,
        (1, None, None, []),
    )]

# Generated at 2022-06-17 16:50:38.523972
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    p.setup()

    # Create a tokenizer
    t = tokenize.generate_tokens(open("Grammar/Grammar").readline)

    # Parse the grammar
    driver.parse_tokens(t, p)

    # Check the result
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1
    assert p

# Generated at 2022-06-17 16:50:51.955202
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    import io
    import sys
    import unittest

    class TestParserPop(unittest.TestCase):
        def test_pop(self):
            # Test that the root node is set correctly
            # when the parser is popped
            g = grammar.grammar
            p = Parser(g)
            p.setup()
            # Create a fake file-like object
            f = io.StringIO("print(1)")
            # Create a fake tokenizer
            t = tokenize.generate_tokens(f.readline)
            # Create a fake driver
            d = driver.Driver(p, t)
            # Run the parser
            d.run()
            # Check that the root node is set

# Generated at 2022-06-17 16:51:00.939124
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    # Create a parser instance
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Create a tokenizer
    t = tokenize.generate_tokens(open("test/test_grammar.py"))
    # Feed the tokens to the parser
    for type, value, start, end, line in t:
        p.addtoken(type, value, (start, end))
    # Get the root node
    root = p.rootnode
    # Print the abstract syntax tree
    print(root)

# Generated at 2022-06-17 16:51:12.985867
# Unit test for method shift of class Parser
def test_Parser_shift():
    class MockGrammar(object):
        def __init__(self):
            self.dfas = {1: ([[(1, 1)], [(0, 1)]], {1: 1})}
            self.labels = {1: (1, "a")}
            self.tokens = {1: 1}
            self.keywords = {}

    class MockContext(object):
        def __init__(self):
            self.node = None

    class MockNode(object):
        def __init__(self):
            self.children = []

    mock_grammar = MockGrammar()
    mock_context = MockContext()
    mock_node = MockNode()
    parser = Parser(mock_grammar)

# Generated at 2022-06-17 16:51:26.416553
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)
   

# Generated at 2022-06-17 16:51:34.027744
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "def", (1, 0))
    p.addtoken(token.NAME, "f", (1, 4))
    p.addtoken(token.OP, "(", (1, 5))
    p.addtoken(token.OP, ")", (1, 6))
    p.addtoken(token.OP, ":", (1, 7))
    p.addtoken(token.NEWLINE, "\n", (1, 8))
    p.addtoken(token.INDENT, "\t", (2, 0))
    p.addtoken(token.NAME, "return", (2, 1))
    p.addtoken(token.NAME, "None", (2, 7))

# Generated at 2022-06-17 16:51:46.614050
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import driver
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))

# Generated at 2022-06-17 16:52:01.219218
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar/Grammar")
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NAME, "foo", (1, 0))
    parser.addtoken(token.NAME, "bar", (1, 0))
    parser.addtoken(token.NAME, "baz", (1, 0))
    parser.addtoken(token.NAME, "qux", (1, 0))
    parser.addtoken(token.NAME, "quux", (1, 0))
    parser.addtoken(token.NAME, "corge", (1, 0))
    parser.addtoken(token.NAME, "grault", (1, 0))

# Generated at 2022-06-17 16:52:07.292264
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, (1, 0))
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [("a", "a", (1, 0), None)]))]


# Generated at 2022-06-17 16:52:16.295323
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.expr("1 + 2")):
        if p.addtoken(t.type, t.string, t.start):
            break

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS

# Generated at 2022-06-17 16:52:19.744369
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-17 16:52:23.783794
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar/Grammar")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:52:27.231242
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-17 16:52:39.285078
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, (1, 2))
    p.shift(2, "b", 3, (2, 3))
    p.shift(3, "c", 4, (3, 4))
    assert p.rootnode is None
    p.shift(4, "d", 5, (4, 5))
    assert p.rootnode is not None
    assert p.rootnode.type == 1

# Generated at 2022-06-17 16:52:53.911162
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[1].value == "+"

# Generated at 2022-06-17 16:53:06.827294
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:53:18.617259
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "print", (1, 0))
    p.addtoken(token.LPAR, "(", (1, 5))
    p.addtoken(token.STRING, '"Hello, world"', (1, 6))
    p.addtoken(token.RPAR, ")", (1, 20))
    p.addtoken(token.NEWLINE, "\n", (1, 21))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode is not None
    assert p.rootnode[0] == "file_input"
    assert p

# Generated at 2022-06-17 16:53:33.775742
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:53:46.774903
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    # Test for issue #11
    # https://github.com/python/blib2to3/issues/11
    #
    # The issue is that the parser was not properly handling the
    # case where the last token in the input is a NAME token.
    #
    # The test case is a Python program that contains only a single
    # NAME token.  The parser should not raise an exception, and
    # the root node should be a Leaf node with type NAME.
    #
    # The test case is a Python program that contains only a single
    # NAME token.  The parser should not raise an exception, and
    # the root node should be a Leaf node with type NAME.
    #
    # The test case is a Python program that contains only a single
    # NAME token.  The parser should not raise an exception, and


# Generated at 2022-06-17 16:53:51.869389
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.classify(token.NAME, "foo", None)
    p.classify(token.NAME, "def", None)
    p.classify(token.NAME, "bar", None)
    p.classify(token.NAME, "class", None)
    p.classify(token.NAME, "baz", None)
    p.classify(token.NAME, "return", None)
    p.classify(token.NAME, "quux", None)
    p.classify(token.NAME, "if", None)
    p.classify(token.NAME, "elif", None)
    p.classify(token.NAME, "else", None)

# Generated at 2022-06-17 16:54:03.097228
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    def convert(grammar, node):
        return node

    p = Parser(grammar.grammar, convert)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:54:15.015264
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", driver.FileInput("foo", "foo"))
    p.addtoken(token.NAME, "bar", driver.FileInput("bar", "bar"))
    p.addtoken(token.NAME, "baz", driver.FileInput("baz", "baz"))
    p.addtoken(token.NAME, "qux", driver.FileInput("qux", "qux"))
    p.addtoken(token.NAME, "quux", driver.FileInput("quux", "quux"))
    p.addtoken(token.NAME, "corge", driver.FileInput("corge", "corge"))

# Generated at 2022-06-17 16:54:23.225033
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import driver
    import sys

    # Create a parser
    p = Parser(grammar.grammar)

    # Parse a simple expression
    p.setup()
    for t in driver.tokenize(sys.stdin):
        if p.addtoken(t.type, t.string, t.context):
            break

    # Print the abstract syntax tree
    print(p.rootnode)

# Generated at 2022-06-17 16:54:27.446195
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [1, "a", None, None]))]

# Generated at 2022-06-17 16:54:37.517053
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:54:51.935557
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import io
    import blib2to3.pgen2.tokenize as tokenize
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.pgen import generate_grammar

    # Create a parser
    grammar = Grammar(generate_grammar(sys.stdin))
    parser = Parser(grammar)
    # Parse a simple file
    parser.setup()
    with io.StringIO("a = 1\n") as f:
        for type, value, context, _ in tokenize.generate_tokens(f.readline):
            if parser.addtoken(type, value, context):
                break
    # Test the pop method
    parser

# Generated at 2022-06-17 16:54:57.627121
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [("a", None, None, None)]))]

# Generated at 2022-06-17 16:55:08.434337
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:55:15.433354
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.ENDMARKER, None, Context(1, 0))
    p.pop()
    assert p.rootnode is not None
    assert p.rootnode.type == g.start
    assert p.rootnode.children == []
    assert p.rootnode.context is None
    assert p.rootnode.used_names == set()

    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p

# Generated at 2022-06-17 16:55:26.164086
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    import io
    import sys
    import unittest

    class TestParser(unittest.TestCase):
        def test_pop(self):
            # Test that the root node is set correctly
            # when the stack is popped.
            g = grammar.grammar
            p = Parser(g)
            p.setup()
            # Create a fake token stream

# Generated at 2022-06-17 16:55:38.677657
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(1, "a")]))]
    p.shift(1, "b", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [Leaf(1, "a"), Leaf(1, "b")]))]
    p.shift(1, "c", 4, None)

# Generated at 2022-06-17 16:55:49.139040
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, 2, 3, 4)
    assert p.stack == [(2, 0, (1, None, 4, []))]
    p.push(5, 6, 7, 8)
    assert p.stack == [(2, 0, (1, None, 4, [])), (6, 0, (5, None, 8, []))]


# Generated at 2022-06-17 16:55:51.554423
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]

# Generated at 2022-06-17 16:56:04.526595
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        p.addtoken(t[0], t[1], t[2])
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER

# Generated at 2022-06-17 16:56:17.858399
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:56:29.876619
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2.grammar import Grammar


# Generated at 2022-06-17 16:56:36.038703
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)
   

# Generated at 2022-06-17 16:56:56.945788
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p

# Generated at 2022-06-17 16:57:09.382269
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "spam", None)
    p.addtoken(token.NAME, "eggs", None)
    p.addtoken(token.NAME, "ham", None)
    p.addtoken(token.NAME, "lunch", None)
    p.addtoken(token.NAME, "dinner", None)
    p.addtoken(token.NAME, "supper", None)
   

# Generated at 2022-06-17 16:57:21.678378
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)
    p

# Generated at 2022-06-17 16:57:29.283248
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.load_grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.COLON, ":", None)
    p.addtoken(token.NAME, "pass", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.ENDMARKER, "", None)
    assert p.rootnode is not None

# Generated at 2022-06-17 16:57:39.436066
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))
    p.addtoken(token.NAME, "garply", (1, 0))

# Generated at 2022-06-17 16:57:42.731789
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar/Grammar")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None

# Generated at 2022-06-17 16:57:54.127471
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:58:04.282734
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    assert p.rootnode.children[0].value == "foo"
    assert p.rootnode.children[1].value == "bar"
    assert p.rootnode.children[2].value == "baz"
    assert p.rootnode.children[3].value == "qux"

# Generated at 2022-06-17 16:58:10.992009
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:58:16.992779
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    from . import driver
    from . import grammar
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse some tokens
    for type, value, context in driver.tokenize(sys.stdin):
        if type == token.ENDMARKER:
            break
        p.addtoken(type, value, context)

    # Get the root node
    root = p.rootnode

    # Print the abstract syntax tree
    print(root)

# Generated at 2022-06-17 16:58:45.119062
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)

# Generated at 2022-06-17 16:58:54.889810
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "spam", (1, 0))
    p.addtoken(token.NAME, "ham", (1, 0))
    p.addtoken(token.NAME, "eggs", (1, 0))
    p.addtoken(token.NAME, "foo", (1, 0))

# Generated at 2022-06-17 16:59:06.502546
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.token import Token
    from blib2to3.pytree import Leaf, Node
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2.convert import pytree_convert
    from blib2to3.pgen2.pgen import generate_grammar
    from blib2to3.pgen2.pgen import generate_grammar_pickle
    from blib2to3.pgen2.pgen import generate_grammar_convert
    from blib2to3.pgen2.pgen import generate_grammar_convert_pickle

# Generated at 2022-06-17 16:59:11.698447
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token
    from . import driver
    from . import parse
    from . import pytree
    from . import pygram
    from . import pytoken

    g = grammar.Grammar(grammar.DEFAULT_GRAMMAR)
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-17 16:59:18.259361
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, []))]
    p.push(3, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, [])), (None, 0, (3, None, None, []))]

# Generated at 2022-06-17 16:59:28.259495
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar.txt")
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NAME, "a", (1, 0))
    parser.addtoken(token.NAME, "b", (1, 0))
    parser.addtoken(token.NAME, "c", (1, 0))
    parser.addtoken(token.NAME, "d", (1, 0))
    parser.addtoken(token.NAME, "e", (1, 0))
    parser.addtoken(token.NAME, "f", (1, 0))
    parser.addtoken(token.NAME, "g", (1, 0))
    parser.addtoken(token.NAME, "h", (1, 0))


# Generated at 2022-06-17 16:59:38.398097
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar/Grammar")
    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 3))
    p.addtoken(token.EQUAL, "=", Context(1, 5))
    p.addtoken(token.NUMBER, "1", Context(1, 7))
    p.addtoken(token.NEWLINE, "\n", Context(1, 8))
    p.addtoken(token.NAME, "else", Context(2, 0))
    p.addtoken(token.COLON, ":", Context(2, 4))
    p.addtoken

# Generated at 2022-06-17 16:59:52.336614
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    stmt = p.rootnode.children[0]
    assert stmt.type == g.symbol2number["stmt"]
    assert len(stmt.children) == 1
    simple_stmt = stmt.children[0]
   

# Generated at 2022-06-17 17:00:01.351276
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Unit test for method addtoken of class Parser"""
    from . import driver
    from . import grammar
    from . import tokenize

    # Load the grammar
    g = grammar.grammar
    # Create a parser
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Tokenize a sample program
    f = open("sample.py")
    try:
        tokens = tokenize.generate_tokens(f.readline)
    finally:
        f.close()
    # Feed the tokens to the parser
    for type, value, start, end, line in tokens:
        if p.addtoken(type, value, (start, end)):
            break
    # Get the root node of the abstract syntax tree
    root = p.rootnode
    # Print the abstract syntax tree
   