

# Generated at 2022-06-17 16:50:15.691840
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("NEWLINE", "NEWLINE"), "file_input"])
    g.add_nonterminal("file_input", [])
    g.add_nonterminal("file_input", [("ENDMARKER", "ENDMARKER")])
    g.add_nonterminal("file_input", [("stmt", "stmt"), "file_input"])
    g.add_nonterminal("stmt", [("simple_stmt", "simple_stmt")])
    g.add_nonterminal("simple_stmt", [("small_stmt", "small_stmt"), ("NEWLINE", "NEWLINE")])
    g.add_non

# Generated at 2022-06-17 16:50:19.668068
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, []))]

# Generated at 2022-06-17 16:50:30.380873
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 3))
    p.addtoken(token.EQUAL, "=", Context(1, 5))
    p.addtoken(token.NUMBER, "0", Context(1, 7))
    p.addtoken(token.NEWLINE, "\n", Context(1, 8))
    p.addtoken(token.NAME, "else", Context(2, 0))
    p.addtoken(token.COLON, ":", Context(2, 5))
    p.addtoken(token.NEWLINE, "\n", Context(2, 6))
    p.add

# Generated at 2022-06-17 16:50:33.772842
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 1, None)
    assert p.stack == [(g.dfas[g.start], 1, (g.start, None, None, ["a"]))]

# Generated at 2022-06-17 16:50:42.020648
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("<test>", "a = 1").readline):
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode.children[0].children[0].value == "a"
    assert p.rootnode.children[0].children[1].value == "="
    assert p.rootnode.children[0].children[2].value == "1"

# Generated at 2022-06-17 16:50:53.242531
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test/test_parser.py")):
        if p.addtoken(t.type, t.string, t.start):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["simple_stmt"]
    assert p.rootnode.children[0].children[0].children[0].type

# Generated at 2022-06-17 16:50:57.806773
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]

# Generated at 2022-06-17 16:51:10.993213
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            p = driver.Parser()
            p.setup()
            self.assertFalse(p.addtoken(token.NAME, "a", (1, 0)))
            self.assertFalse(p.addtoken(token.EQUAL, "=", (1, 2)))
            self.assertFalse(p.addtoken(token.NUMBER, "1", (1, 4)))
            self.assertTrue(p.addtoken(token.NEWLINE, "\n", (1, 5)))
            self.assertEqual(p.rootnode.type, symbol.file_input)
            self.assertEqual(p.rootnode.children[0].type, symbol.stmt)
            self.assertE

# Generated at 2022-06-17 16:51:24.928317
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver

    p = Parser(driver.grammar)
    p.setup()
    assert p.classify(token.NAME, "foo", None) == driver.grammar.tokens[token.NAME]
    assert p.classify(token.NAME, "if", None) == driver.grammar.keywords["if"]
    assert p.classify(token.NAME, "while", None) == driver.grammar.keywords["while"]
    assert p.classify(token.NAME, "def", None) == driver.grammar.keywords["def"]
    assert p.classify(token.NAME, "class", None) == driver.grammar.keywords["class"]
    assert p.classify(token.NAME, "return", None) == driver.grammar.keywords["return"]

# Generated at 2022-06-17 16:51:29.631311
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, token

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    assert p.rootnode.children == ["foo", "bar", "baz"]

# Generated at 2022-06-17 16:51:52.784358
# Unit test for method pop of class Parser
def test_Parser_pop():
    class MockGrammar:
        def __init__(self):
            self.dfas = {
                1: ([[(0, 1)], [(0, 1)], [(0, 1)], [(0, 1)], [(0, 1)], [(0, 1)]], {1: 1})
            }

    class MockConvert:
        def __init__(self):
            self.converted = []

        def __call__(self, grammar, node):
            self.converted.append(node)
            return node

    grammar = MockGrammar()
    convert = MockConvert()
    parser = Parser(grammar, convert)
    parser.setup()
    parser.addtoken(1, "a", (1, 1))
    parser.addtoken(1, "b", (1, 1))

# Generated at 2022-06-17 16:52:01.218029
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    g.start = 'file_input'
    g.add_nonterminal('file_input', [('stmt', 'file_input')])
    g.add_nonterminal('stmt', [('simple_stmt',)])
    g.add_nonterminal('simple_stmt', [('small_stmt', 'NEWLINE')])
    g.add_nonterminal('small_stmt', [('expr_stmt',)])
    g.add_nonterminal('expr_stmt', [('testlist',)])
    g.add_nonterminal('testlist', [('test', 'testlist_star')])

# Generated at 2022-06-17 16:52:11.836486
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]

# Generated at 2022-06-17 16:52:16.037064
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-17 16:52:24.677974
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", (("NEWLINE", "stmt", "file_input"),))
    g.add_nonterminal("stmt", (("simple_stmt",), ("compound_stmt",)))
    g.add_nonterminal("simple_stmt", (("small_stmt", "NEWLINE"),))
    g.add_nonterminal("small_stmt", (("expr_stmt",),))
    g.add_nonterminal("expr_stmt", (("testlist",),))
    g.add_nonterminal("testlist", (("test",),))

# Generated at 2022-06-17 16:52:31.217463
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        p.addtoken(t[0], t[1], t[2])
    print(p.rootnode)

# Generated at 2022-06-17 16:52:41.181461
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 3))
    p.addtoken(token.NAME, "baz", (1, 6))
    p.addtoken(token.NAME, "qux", (1, 9))
    p.addtoken(token.NAME, "quux", (1, 12))
    p.addtoken(token.NAME, "corge", (1, 17))
    p.addtoken(token.NAME, "grault", (1, 23))
    p.addtoken(token.NAME, "garply", (1, 30))

# Generated at 2022-06-17 16:52:49.069939
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar/Grammar")
    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 0))
    p.addtoken(token.NAME, "g", Context(1, 0))

# Generated at 2022-06-17 16:53:01.828423
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Grammar
    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [
        ("NEWLINE", "NEWLINE"),
        ("file_input", "stmt", "file_input"),
        ("file_input", "NEWLINE", "file_input"),
        ("file_input", "ENDMARKER", ""),
        ("file_input", "stmt", "NEWLINE", "file_input"),
        ("file_input", "stmt", "NEWLINE", "NEWLINE", "file_input"),
    ])
    g.add_nonterminal("stmt", [
        ("simple_stmt",),
        ("compound_stmt",),
    ])

# Generated at 2022-06-17 16:53:13.426126
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import tokenize

    # Create a parser
    p = Parser(grammar.grammar, driver.convert)
    # Parse a simple expression
    p.setup()
    for t in tokenize.generate_tokens("1 + 2"):
        p.addtoken(t[0], t[1], t[2])
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS

# Generated at 2022-06-17 16:53:27.766982
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None



# Generated at 2022-06-17 16:53:32.150343
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        p.addtoken(t[0], t[1], t[2])
    print(p.rootnode)

# Generated at 2022-06-17 16:53:44.034423
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.token import Token
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pytree import Leaf
    from blib2to3.pgen2.convert import pytree_convert
    from blib2to3.pgen2.pgen import generate_grammar
    from blib2to3.pgen2.pgen import generate_grammar_pickle
    from blib2to3.pgen2.pgen import generate_grammar_zip
    from blib2to3.pgen2.pgen import generate_grammar_tar

# Generated at 2022-06-17 16:53:53.191496
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "name", (1, 3))
    p.addtoken(token.NAME, "else", (1, 8))
    p.addtoken(token.NAME, "name", (1, 13))
    p.addtoken(token.NEWLINE, "\n", (1, 18))
    p.addtoken(token.NAME, "name", (2, 0))
    p.addtoken(token.NEWLINE, "\n", (2, 4))
    p.addtoken(token.ENDMARKER, "", (3, 0))
    assert p.rootnode is not None

# Generated at 2022-06-17 16:54:02.964302
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token
    from . import pgen2

    g = grammar.Grammar(pgen2.pgen2.parse_grammar(driver.grammar, "exec"))
    p = Parser(g)
    p.setup()
    tokens = tokenize.generate_tokens(driver.grammar)
    for t in tokens:
        if t.type == token.ENDMARKER:
            break
        p.addtoken(t.type, t.string, t.start)
    assert p.rootnode is not None
    assert p.rootnode.used_names == set()

# Generated at 2022-06-17 16:54:14.861205
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2 import token
    from blib2to3.pytree import Leaf
    from blib2to3.pytree import Node
    from blib2to3.pytree import type_repr
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pygram import python_grammar

    def convert(grammar, node):
        if node[1] is None:
            return Node(type=node[0], children=node[3], context=node[2])
        else:
            return Leaf(type=node[0], value=node[1], context=node[2])

    grammar = driver.load_gram

# Generated at 2022-06-17 16:54:27.300091
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    # Create a parser instance
    p = Parser(grammar)
    # Prepare for parsing
    p.setup()
    # Add a token
    p.addtoken(token.NAME, "foo", (1, 0))
    # Add a token
    p.addtoken(token.NAME, "bar", (1, 0))
    # Add a token
    p.addtoken(token.NAME, "baz", (1, 0))
    # Add a token
    p.addtoken(token.NAME, "qux", (1, 0))
    # Add a token
    p.addtoken(token.NAME, "quux", (1, 0))
    # Add a token
    p.addtoken(token.NAME, "corge", (1, 0))
    # Add a token
    p.add

# Generated at 2022-06-17 16:54:37.266450
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import pytree

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    p.setup()

    # Create a tokenizer
    t = tokenize.generate_tokens(open("test/input/future1.txt").readline)

    # Feed the parser
    for type, value, start, end, line in t:
        if type == token.OP:
            type = driver.keyword_tokens.get(value, type)
        p.addtoken(type, value, pytree.Leaf(type, value, start, end, line))

    # Get the result
    tree = p.rootnode
    assert tree.type == g.symbol2number["file_input"]
   

# Generated at 2022-06-17 16:54:50.576880
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 3))
    p.addtoken(token.EQEQUAL, "==", Context(1, 5))
    p.addtoken(token.NUMBER, "1", Context(1, 8))
    p.addtoken(token.NEWLINE, "\n", Context(1, 9))
    p.addtoken(token.ENDMARKER, "", Context(2, 0))
    assert p.rootnode is not None

# Generated at 2022-06-17 16:55:02.737172
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            import blib2to3.pgen2.driver
            import blib2to3.pgen2.tokenize

            class Dummy:
                pass

            context = Dummy()
            context.__dict__.update(
                {
                    "filename": "",
                    "encoding": "utf-8",
                    "lines": [],
                    "flags": blib2to3.pgen2.tokenize.COMMENT,
                }
            )
            driver = blib2to3.pgen2.driver.Driver(
                blib2to3.pgen2.grammar.Grammar(), convert=lam_sub
            )
            driver.grammar.keywords["and"] = 1
           

# Generated at 2022-06-17 16:55:20.781784
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [("a", "a", None, None)]))]
    p.shift(2, "b", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [("a", "a", None, None), ("b", "b", None, None)]))]


# Generated at 2022-06-17 16:55:29.200404
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:55:37.785554
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, tokenize

    p = Parser(grammar)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode is not None
    assert p.rootnode.type == grammar.syms.file_input
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == token.ENDMARKER

# Generated at 2022-06-17 16:55:51.565561
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))
    p.addtoken(token.NAME, "garply", (1, 0))

# Generated at 2022-06-17 16:55:57.747286
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:56:07.017200
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    p.addtoken(token.NAME, "a", None)
    assert p.stack == [(g.dfas[g.start], 1, (g.start, None, None, [("NAME", "a", None, None)])),
                      (g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None


# Generated at 2022-06-17 16:56:20.105807
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token
    from . import pgen2
    from . import pytree

    # Set up the parser
    p = Parser(grammar.grammar)
    p.setup()
    # Set up the tokenizer
    tokengen = tokenize.generate_tokens(open("test_pgen2.py"))
    # Feed the parser
    for type, value, start, end, line in tokengen:
        if type == token.OP and value == ".":
            type = token.DOT
        p.addtoken(type, value, (start, end, line))
    # Get the tree
    tree = p.rootnode
    # Print the tree
    print(pytree.type_repr(tree))


# Generated at 2022-06-17 16:56:30.731980
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    driver.addtoken(p, token.NUMBER, "1", (1, 0))
    driver.addtoken(p, token.PLUS, "+", (1, 2))
    driver.addtoken(p, token.NUMBER, "2", (1, 4))
    driver.addtoken(p, token.NEWLINE, "\n", (1, 5))
    # Check the result
    assert p.rootnode.type == grammar.syms.file_input
    assert len(p.rootnode.children) == 1
    stmt = p.rootnode.children[0]

# Generated at 2022-06-17 16:56:36.234904
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    # Create a parser instance
    g = grammar.grammar
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Tokenize a string
    s = "x = 1 + 2"
    tokens = tokenize.generate_tokens(s)

    # Parse the tokens
    for type, value, start, end, line in tokens:
        if p.addtoken(type, value, (start, end)):
            break

    # Get the root of the abstract syntax tree
    root = p.rootnode

    # Print the tree
    from . import pytree

    print(pytree.tree2str(root))



# Generated at 2022-06-17 16:56:50.817499
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))

# Generated at 2022-06-17 16:57:18.256863
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.PLUS, "+", None)
    p.addtoken(token.NUMBER, "2", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.ENDMARKER, "", None)
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1
    assert p.rootnode

# Generated at 2022-06-17 16:57:27.149633
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    assert p.addtoken(token.NAME, "a", (1, 0))
    assert p.addtoken(token.NAME, "b", (1, 0))
    assert p.addtoken(token.NAME, "c", (1, 0))
    assert p.addtoken(token.NAME, "d", (1, 0))
    assert p.addtoken(token.NAME, "e", (1, 0))
    assert p.addtoken(token.NAME, "f", (1, 0))
    assert p.addtoken(token.NAME, "g", (1, 0))
    assert p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:57:38.322860
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Add some tokens
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 1))
    p.addtoken(token.NAME, "c", (1, 2))

    # Pop a nonterminal
    p.pop()

    # Check the result
    assert p.rootnode.type == token.NAME
    assert p.rootnode.value == "c"
    assert p.rootnode.children == []

    # Add some more tokens

# Generated at 2022-06-17 16:57:52.485154
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    # Test the parser on the grammar file itself
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    f = open(g.grammar_file, "rb")
    try:
        for type, token, start, end, line in tokenize.generate_tokens(f.readline):
            if type == tokenize.COMMENT:
                continue
            if type == tokenize.OP and token == "@":
                type = tokenize.NAME
            if p.addtoken(type, token, (start, end)):
                break
    except ParseError as err:
        print(err)
        print("Last token:", type, token)
        print("Context:", start, end)
        print("Line:", line)


# Generated at 2022-06-17 16:58:03.275112
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test_grammar.py").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == token.NAME

# Generated at 2022-06-17 16:58:15.292911
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:58:25.170712
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:58:31.361590
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    g.start = "start"
    g.add_nonterminal("start", [("a", "b")])
    g.add_nonterminal("a", [("b",)])
    g.add_nonterminal("b", [("c",)])
    g.add_nonterminal("c", [("d",)])
    g.add_nonterminal("d", [("e",)])
    g.add_nonterminal("e", [("f",)])
    g.add_nonterminal("f", [("g",)])
    g.add_nonterminal("g", [("h",)])
    g.add_nonterminal("h", [("i",)])

# Generated at 2022-06-17 16:58:42.854341
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:58:54.356998
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.grammar import Grammar

    grammar = Grammar()
    grammar.start = 256

# Generated at 2022-06-17 16:59:37.433966
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:59:51.869032
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.shift(token.NUMBER, "1", 0, None)
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, [1]))]
    p.shift(token.PLUS, "+", 0, None)
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, [1, 2]))]
    p.shift(token.NUMBER, "2", 0, None)
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, [1, 2, 3]))]
    p.shift

# Generated at 2022-06-17 17:00:01.070524
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import driver
    from . import tokenize
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in driver.tokenize("def f(x): pass"):
        p.addtoken(t.type, t.string, t.start)
    assert p.rootnode.type == symbol.file_input
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == symbol.funcdef
    assert len(p.rootnode.children[0].children) == 4
    assert p.rootnode.children[0].children[0].type == token.NAME
    assert p.rootnode.children[0].children[0].value == "def"