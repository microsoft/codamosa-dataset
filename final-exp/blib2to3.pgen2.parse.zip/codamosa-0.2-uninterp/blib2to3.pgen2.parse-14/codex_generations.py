

# Generated at 2022-06-17 16:50:15.890266
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("NEWLINE", None), ("stmt", "stmts")])
    g.add_nonterminal("stmt", [("simple_stmt", None)])
    g.add_nonterminal("simple_stmt", [("small_stmt", "small_stmts")])
    g.add_nonterminal("small_stmt", [("expr_stmt", None)])
    g.add_nonterminal("expr_stmt", [("testlist", "testlists")])
    g.add_nonterminal("testlist", [("test", "tests")])

# Generated at 2022-06-17 16:50:26.331944
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser instance
    g = grammar.grammar
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Tokenize a string
    s = "if 1: pass"
    tokens = tokenize.generate_tokens(s)

    # Feed the tokens to the parser
    for type, value, start, end, line in tokens:
        if p.addtoken(type, value, (start, end)):
            break

    # Get the parse tree
    tree = p.rootnode

    # Print the parse tree
    driver.treetransform(tree)
    print(tree)

# Generated at 2022-06-17 16:50:35.018150
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar
    from . import tokenize

    # Test the parser
    p = Parser(grammar.grammar)
    p.setup()
    # Test the driver
    d = driver.Driver(p.grammar, p.addtoken)
    d.set_filename("<test>")
    d.set_debuglevel(1)
    d.input("x = 1")
    d.input("y = 2")
    d.input("z = 3")
    d.input("if x: y = 2")
    d.input("if x: y = 2; z = 3")
    d.input("if x: y = 2; z = 3;")
    d.input("if x: y = 2; z = 3; x = 0")

# Generated at 2022-06-17 16:50:43.637417
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "elif", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "else", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "while", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "for", None)
    p.addtoken(token.NAME, "spam", None)

# Generated at 2022-06-17 16:50:47.891378
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:50:52.147458
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-17 16:50:59.089378
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    def test(s: Text, expected: Sequence[int]) -> None:
        p = Parser(grammar.grammar)
        p.setup()
        for t in tokenize.generate_tokens(s.splitlines(True)):
            if p.addtoken(t[0], t[1], t[2]):
                break
        assert p.rootnode.type == expected[0]
        assert p.rootnode.children[0].type == expected[1]
        assert p.rootnode.children[0].children[0].type == expected[2]

    test("a = 1\n", [syms.file_input, syms.stmt, token.NAME])

# Generated at 2022-06-17 16:51:12.133619
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)
    p

# Generated at 2022-06-17 16:51:25.263175
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import driver
    import sys

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", (("stmt", "file_input"),))
    g.add_nonterminal("stmt", (("simple_stmt",), ("compound_stmt",)))
    g.add_nonterminal("simple_stmt", (("small_stmt", "NEWLINE"),))
    g.add_nonterminal("small_stmt", (("expr_stmt",),))
    g.add_nonterminal("expr_stmt", (("testlist",),))
    g.add_nonterminal("testlist", (("test",),))

# Generated at 2022-06-17 16:51:37.078088
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar

    # Create a parser
    p = Parser(grammar.grammar)
    # Parse a simple expression
    p.setup()
    for t in driver.tokenize("1 + 2"):
        if p.addtoken(t.type, t.string, t.context):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[1].value == "+"

# Generated at 2022-06-17 16:51:54.953780
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    assert p.stack[-1][2][-1][-1][0].value == "foo"
    p.addtoken(token.NAME, "bar", (1, 0))
    assert p.stack[-1][2][-1][-1][0].value == "bar"
    p.addtoken(token.NAME, "baz", (1, 0))
    assert p.stack[-1][2][-1][-1][0].value == "baz"
    p.addtoken(token.NAME, "qux", (1, 0))

# Generated at 2022-06-17 16:52:06.469193
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("NEWLINE", "NEWLINE", "NEWLINE", "NEWLINE")])
    g.add_nonterminal("NEWLINE", [("NEWLINE", "NEWLINE", "NEWLINE", "NEWLINE")])
    g.add_nonterminal("NEWLINE", [("NEWLINE", "NEWLINE", "NEWLINE", "NEWLINE")])
    g.add_nonterminal("NEWLINE", [("NEWLINE", "NEWLINE", "NEWLINE", "NEWLINE")])
    g.add_nonterminal("NEWLINE", [("NEWLINE", "NEWLINE", "NEWLINE", "NEWLINE")])

# Generated at 2022-06-17 16:52:15.787943
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar/Grammar")):
        if t[0] == token.ENDMARKER:
            break
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["simple_stmt"]

# Generated at 2022-06-17 16:52:22.791886
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import token

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    driver.driver(p, tokenize.generate_tokens(iter(["1", "+", "2"]).__next__))
    # Check the result
    assert p.rootnode.type == g.symbol2number["expr_stmt"]
    assert p.rootnode.children[0].type == g.symbol2number["expr"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["term"]
    assert p.rootnode.children[0].children[0].children[0].type

# Generated at 2022-06-17 16:52:30.526276
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()



# Generated at 2022-06-17 16:52:41.079776
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    g.load_grammar(driver.grammar)
    p = Parser(g)
    p.setup()
    for type, value, context in tokenize.generate_tokens(open("test/test_grammar.py")):
        if p.addtoken(type, value, context):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == token.NAME

# Generated at 2022-06-17 16:52:55.109966
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, []))]
    p.push(3, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, [])), (None, 0, (3, None, None, []))]


# Generated at 2022-06-17 16:53:08.020489
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Create a parser instance
    g = grammar.Grammar()
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for type, value, start, end, line in tokenize.generate_tokens(
        "1 + 2"
    ):  # type: ignore
        p.addtoken(type, value, (start, end))

    # Check the result
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["eval_input"]
    assert len(p.rootnode.children[0].children) == 1
    assert p.rootnode

# Generated at 2022-06-17 16:53:14.931473
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.StringIO("1+2").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.file_input
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == grammar.syms.eval_input
    assert len(p.rootnode.children[0].children) == 1

# Generated at 2022-06-17 16:53:23.234608
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver

    class ParserTestCase(unittest.TestCase):
        def test_addtoken(self):
            # Test the Parser class
            p = Parser(driver.grammar)
            p.setup()
            p.addtoken(token.NAME, "a", (1, 0))
            p.addtoken(token.EQUAL, "=", (1, 2))
            p.addtoken(token.NUMBER, "1", (1, 4))
            p.addtoken(token.NEWLINE, "\n", (1, 5))
            p.addtoken(token.NAME, "b", (2, 0))
            p.addtoken(token.EQUAL, "=", (2, 2))

# Generated at 2022-06-17 16:53:47.102850
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize

    grammar = grammar.Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NAME, "a", (1, 0))
    parser.addtoken(token.NAME, "b", (1, 0))
    parser.addtoken(token.NAME, "c", (1, 0))
    parser.addtoken(token.NAME, "d", (1, 0))
    parser.addtoken(token.NAME, "e", (1, 0))
    parser.addtoken(token.NAME, "f", (1, 0))
    parser.addtoken(token.NAME, "g", (1, 0))
    parser.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:53:58.154679
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:54:04.862522
# Unit test for method setup of class Parser
def test_Parser_setup():
    import unittest
    from . import driver

    class TestParser(unittest.TestCase):
        def test_setup(self):
            p = driver.Parser(driver.Grammar())
            p.setup()
            self.assertEqual(p.stack, [(p.grammar.dfas[p.grammar.start], 0, (1, None, None, []))])
            self.assertEqual(p.rootnode, None)

    unittest.main()


# Generated at 2022-06-17 16:54:16.258806
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Parse a simple expression
    p.setup()
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode.type == g.symbol2number["expr_stmt"]
    assert p.rootnode.children[0].type == g.symbol2number["expr"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["term"]
    assert p.rootnode.children[0].children[0].children[0].type == token.NUMBER

# Generated at 2022-06-17 16:54:22.993377
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test.py").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:54:31.951908
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].value == "+"
    assert p.rootnode.children[2].value == "2"

# Generated at 2022-06-17 16:54:40.573025
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.StringIO("1 + 2").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS

# Generated at 2022-06-17 16:54:51.719774
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import token

    g = grammar.Grammar(driver.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:55:03.994929
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [
        ("NEWLINE", None),
        ("stmt", "stmts"),
        ("NEWLINE", None),
        ("ENDMARKER", None),
    ])
    g.add_nonterminal("stmts", [
        ("stmt", "stmts"),
        ("stmt", None),
    ])
    g.add_nonterminal("stmt", [
        ("simple_stmt", None),
    ])
    g.add_nonterminal("simple_stmt", [
        ("small_stmt", "small_stmts"),
        ("NEWLINE", None),
    ])
    g.add_

# Generated at 2022-06-17 16:55:13.194539
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in driver.tokenize("1 + 2"):
        if p.addtoken(t.type, t.string, t.context):
            break

    # Check the result
    assert p.rootnode.type == g.symbol2number["expr"]
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER
    assert p.rootnode.children

# Generated at 2022-06-17 16:55:38.246081
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))
    p.addtoken(token.NAME, "garply", (1, 0))

# Generated at 2022-06-17 16:55:51.628468
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, [], 0, None)
    assert p.stack == [(None, 0, None), ([], 0, (1, None, None, []))]
    p.push(2, [], 0, None)
    assert p.stack == [
        (None, 0, None),
        ([], 0, (1, None, None, [])),
        ([], 0, (2, None, None, [])),
    ]
    p.pop()
    assert p.stack == [(None, 0, None), ([], 0, (1, None, None, [2]))]
    p.pop()
    assert p.stack == [(None, 0, None)]

# Generated at 2022-06-17 16:56:04.569232
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))
    p.addtoken(token.NAME, "garply", (1, 0))

# Generated at 2022-06-17 16:56:14.152253
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        p.addtoken(t[0], t[1], t[2])
    # Convert the syntax tree
    driver.convert(p.rootnode)
    # Print the abstract syntax tree
    print(p.rootnode)

# Generated at 2022-06-17 16:56:20.355336
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-17 16:56:30.187236
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, []))]
    p.pop()
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.pop()
    assert p.stack == []

# Generated at 2022-06-17 16:56:42.587237
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("NEWLINE", "NEWLINE", "file_input"), ("stmt", "stmt", "file_input")])
    g.add_nonterminal("stmt", [("simple_stmt", "simple_stmt", "stmt")])
    g.add_nonterminal("simple_stmt", [("small_stmt", "small_stmt", "simple_stmt")])
    g.add_nonterminal("small_stmt", [("expr_stmt", "expr_stmt", "small_stmt")])

# Generated at 2022-06-17 16:56:53.233243
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"

# Generated at 2022-06-17 16:56:59.848717
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))
    p.addtoken(token.NAME, "garply", (1, 0))

# Generated at 2022-06-17 16:57:12.411809
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar
    from . import tokenize
    import io
    import unittest

    class TestParser(unittest.TestCase):
        def test_shift(self):
            # Test for method shift of class Parser
            # Create a parser
            g = grammar.Grammar()
            p = Parser(g)
            # Create a token
            type = token.NAME
            value = "test"
            context = (1, 1)
            # Shift the token
            p.shift(type, value, 0, context)
            # Check the stack
            self.assertEqual(p.stack, [(g.dfas[g.start], 0, (g.start, None, None, [None]))])
            # Check the root node

# Generated at 2022-06-17 16:57:38.204292
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.driver import Driver
    from io import StringIO
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pygram import python_grammar
    from blib2to3.pytree import Leaf, Node
    from blib2to3.pgen2.convert import pytree_convert
    from blib2to3.pgen2.pgen import tokenize
    from blib2to3.pgen2.pgen import _parse_grammar

# Generated at 2022-06-17 16:57:44.077679
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]

# Generated at 2022-06-17 16:57:54.577758
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver
    from . import grammar

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            p = Parser(grammar.grammar)
            p.setup()
            p.addtoken(token.NAME, "a", (1, 0))
            p.addtoken(token.NAME, "b", (1, 0))
            p.addtoken(token.NAME, "c", (1, 0))
            p.addtoken(token.NAME, "d", (1, 0))
            p.addtoken(token.NAME, "e", (1, 0))
            p.addtoken(token.NAME, "f", (1, 0))
            p.addtoken(token.NAME, "g", (1, 0))

# Generated at 2022-06-17 16:58:05.375659
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:58:15.899342
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("test/test_grammar.txt")):
        if p.addtoken(t[0], t[1], driver.FileInput("test/test_grammar.txt")):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == token.ENDMARKER


# Generated at 2022-06-17 16:58:21.215106
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [("a", None, None, None)]))]


# Generated at 2022-06-17 16:58:26.176772
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for type, value, context in tokenize.generate_tokens(open("Grammar.txt")):
        if p.addtoken(type, value, context):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:58:38.524098
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))
    p.addtoken(token.NAME, "garply", (1, 0))

# Generated at 2022-06-17 16:58:52.766666
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break

    # Check the result
    assert p.rootnode.type == g.symbol2number["expr_stmt"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["expr"]
    assert len(p.rootnode.children[0].children) == 3
    assert p.rootnode.children[0].children[0].type == token

# Generated at 2022-06-17 16:59:05.057710
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, g.dfas[1], 0, None)
    assert p.stack == [(g.dfas[1], 0, (1, None, None, []))]
    p.push(2, g.dfas[2], 0, None)
    assert p.stack == [(g.dfas[1], 0, (1, None, None, [])), (g.dfas[2], 0, (2, None, None, []))]
    p.push(3, g.dfas[3], 0, None)

# Generated at 2022-06-17 16:59:37.546466
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:59:47.639063
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()

    # Test that the parser is ready to parse
    tok = tokenize.generate_tokens(open("Grammar/Grammar"))
    for type, value, start, end, line in tok:
        if p.addtoken(type, value, (start, end)):
            break
    assert p.rootnode is not None

# Generated at 2022-06-17 16:59:57.799875
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.expr("1+2")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type