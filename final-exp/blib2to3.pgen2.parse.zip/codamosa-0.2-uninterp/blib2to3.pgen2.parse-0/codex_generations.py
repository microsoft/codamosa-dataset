

# Generated at 2022-06-17 16:50:18.793088
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.PLUS, "+", None)
    p.addtoken(token.NUMBER, "2", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.ENDMARKER, "", None)
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]

# Generated at 2022-06-17 16:50:25.291916
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()



# Generated at 2022-06-17 16:50:33.028494
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:50:42.745072
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "y", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "2", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p

# Generated at 2022-06-17 16:50:53.483741
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    # Test that the root node is set correctly
    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)

# Generated at 2022-06-17 16:51:02.323149
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[1], 2, (1, None, None, ["a"]))]
    p.shift(1, "b", 3, None)
    assert p.stack == [(g.dfas[1], 3, (1, None, None, ["a", "b"]))]



# Generated at 2022-06-17 16:51:13.498319
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    # Parse a simple expression
    p.setup()
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    stmt = p.rootnode.children[0]
    assert stmt.type == g.symbol2number["stmt"]
    assert len(stmt.children) == 1
    expr = stmt.children[0]

# Generated at 2022-06-17 16:51:26.802396
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 3))
    p.addtoken(token.EQUAL, "=", Context(1, 5))
    p.addtoken(token.NUMBER, "0", Context(1, 7))
    p.addtoken(token.NEWLINE, "\n", Context(1, 8))
    p.addtoken(token.INDENT, "", Context(2, 0))
    p.addtoken(token.NAME, "print", Context(2, 4))
    p.addtoken(token.NAME, "x", Context(2, 10))

# Generated at 2022-06-17 16:51:34.054290
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 0))
    p.addtoken(token.NAME, "g", Context(1, 0))
    p.addtoken(token.NAME, "h", Context(1, 0))

# Generated at 2022-06-17 16:51:43.058494
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "for", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 4))
    p.addtoken(token.NAME, "in", Context(1, 6))
    p.addtoken(token.NAME, "range", Context(1, 9))
    p.addtoken(token.LPAR, "(", Context(1, 15))
    p.addtoken(token.NUMBER, "1", Context(1, 16))
    p.addtoken(token.COMMA, ",", Context(1, 17))
    p.addtoken(token.NUMBER, "10", Context(1, 19))

# Generated at 2022-06-17 16:52:02.636760
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test/input/future1.txt")):
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1
    assert p.rootnode.children[0].children[0].type == token.NAME


# Generated at 2022-06-17 16:52:13.083834
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, (1, 2))
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(1, "a")]))]
    p.shift(2, "b", 3, (2, 3))
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [Leaf(1, "a"), Leaf(2, "b")]))]
    p.shift(3, "c", 4, (3, 4))

# Generated at 2022-06-17 16:52:21.849262
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 3))
    p.addtoken(token.NAME, "y", Context(1, 5))
    p.addtoken(token.NAME, "z", Context(1, 7))
    p.addtoken(token.NAME, "else", Context(1, 9))
    p.addtoken(token.NAME, "x", Context(1, 14))
    p.addtoken(token.NAME, "y", Context(1, 16))
    p.addtoken(token.NAME, "z", Context(1, 18))

# Generated at 2022-06-17 16:52:28.641855
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.NAME, "y", (1, 0))
    p.addtoken(token.NAME, "z", (1, 0))
    p.addtoken(token.NAME, "elif", (1, 0))
    p.addtoken(token.NAME, "else", (1, 0))
    p.addtoken(token.NAME, "while", (1, 0))
    p.addtoken(token.NAME, "for", (1, 0))

# Generated at 2022-06-17 16:52:37.213875
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver
    from . import grammar
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Push a nonterminal
    p.push(token.NAME, p.grammar.dfas[token.NAME], 0, None)

    # Pop a nonterminal
    p.pop()

    # Push a nonterminal
    p.push(token.NAME, p.grammar.dfas[token.NAME], 0, None)

    # Pop a nonterminal
    p.pop()

    # Push a nonterminal
    p.push(token.NAME, p.grammar.dfas[token.NAME], 0, None)

    # Pop a nonterminal
    p.pop()

    # Push a nontermin

# Generated at 2022-06-17 16:52:52.015893
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("NEWLINE", "NEWLINE"), "file_input"], [])
    g.add_nonterminal("file_input", [], [])
    g.add_terminal("NEWLINE", token.NEWLINE)
    g.make_labels()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NEWLINE, "\n", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (2, 0))
    p.addtoken(token.NEWLINE, "\n", (3, 0))

# Generated at 2022-06-17 16:52:57.128223
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    g.load_grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == token.NAME
    assert p.rootnode.children

# Generated at 2022-06-17 16:53:09.963344
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    from . import grammar
    from . import tokenize
    import io

    # Test setup()
    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    p.setup(g.start + 1)
    assert p.stack == [(g.dfas[g.start + 1], 0, (g.start + 1, None, None, []))]
    assert p.rootnode is None

    # Test addtoken()
    p.setup()
    assert p.addtoken(token.NAME, "a", (1, 0)) == False

# Generated at 2022-06-17 16:53:20.889526
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [
        ("NEWLINE", "NEWLINE"),
        ("file_input", "stmt", "NEWLINE"),
        ("file_input", "stmt", "file_input"),
        ("file_input", "NEWLINE"),
    ])
    g.add_nonterminal("stmt", [
        ("simple_stmt",),
        ("compound_stmt",),
    ])

# Generated at 2022-06-17 16:53:32.116144
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse a token sequence
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    # Check the result

# Generated at 2022-06-17 16:53:53.671750
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import tokenize

    # Create a parser instance
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        p.addtoken(t.type, t.string, t.start)

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[1].value == "+"

# Generated at 2022-06-17 16:54:04.778414
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar
    from . import token

    # Load the grammar table
    g = grammar.grammar
    # Create a parser
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in driver.tokenize("1 + 2"):
        p.addtoken(t.type, t.string, t.context)
    # Check the result
    assert p.rootnode.type == g.symbol2number["expr_stmt"]
    assert len(p.rootnode.children) == 1
    expr = p.rootnode.children[0]
    assert expr.type == g.symbol2number["expr"]
    assert len(expr.children) == 3
    assert expr.children[0].type == token.NUMBER


# Generated at 2022-06-17 16:54:11.387147
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, []))]
    p.push(3, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, [])), (None, 0, (3, None, None, []))]


# Generated at 2022-06-17 16:54:20.154339
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.StringIO("1 + 2").readline):
        p.addtoken(t.type, t.string, t.start)
    # Check the result
    assert p.rootnode.children == [
        Leaf(type=token.NUMBER, value="1", context=(1, 0)),
        Leaf(type=token.PLUS, value="+", context=(1, 2)),
        Leaf(type=token.NUMBER, value="2", context=(1, 4)),
    ]

# Generated at 2022-06-17 16:54:28.782046
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.ENDMARKER, None, (1, 5))
    assert p.rootnode.children == [
        Leaf(token.NUMBER, "1", (1, 0)),
        Leaf(token.PLUS, "+", (1, 2)),
        Leaf(token.NUMBER, "2", (1, 4)),
    ]

# Generated at 2022-06-17 16:54:38.522003
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import token
    from . import driver
    from . import pytree
    from . import pygram
    from . import pytoken

    # Create a parser
    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)

    # Parse a string
    p.setup()
    for t in tokenize.generate_tokens(StringIO("1+2").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    root = p.rootnode
    assert root.type == pygram.file_input
    assert len(root.children) == 1
    assert root.children[0].type == pygram.simple_stmt

# Generated at 2022-06-17 16:54:51.169112
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 0))
    p.addtoken(token.NAME, "g", Context(1, 0))
    p.addtoken(token.NAME, "h", Context(1, 0))
   

# Generated at 2022-06-17 16:55:00.742265
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    s = "a = 1"
    for t in tokenize.generate_tokens(s):
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode.children[0].children[0].value == "a"
    assert p.rootnode.children[0].children[1].value == "="
    assert p.rootnode.children[0].children[2].value == "1"

# Generated at 2022-06-17 16:55:11.805122
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar(grammar.DEFAULT_GRAMMAR)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:55:23.401574
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import driver
    from . import tokenize

    g = grammar.Grammar(driver.grammar)
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("test/input/future1.txt")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1
    assert p.rootnode.children[0].children[0].type == g.symbol2

# Generated at 2022-06-17 16:55:56.557831
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token
    from . import pgen2

    # Create a parser
    g = grammar.Grammar(pgen2.grammar)
    p = Parser(g)

    # Parse a simple program
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test_grammar.py")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None

    # Check the result
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol

# Generated at 2022-06-17 16:56:07.070595
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.convert import fix_missing_locations
    from blib2to3.pgen2.convert import convert_tree
    from blib2to3.pytree import Leaf
    from blib2to3.pytree import Node
    from blib2to3.pytree import type_repr
    from blib2to3.pytree import dump
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pygram import python_grammar
    from blib2to3.pygram import python_grammar_no_print_

# Generated at 2022-06-17 16:56:11.406907
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p

# Generated at 2022-06-17 16:56:17.233393
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for type, value, context in tokenize.generate_tokens(open("Grammar.txt")):
        if p.addtoken(type, value, context):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:56:29.295071
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)
    # Create a tokenizer
    t = tokenize.generate_tokens(driver.FileInput("test/test_grammar.txt"))
    # Prepare for parsing
    p.setup()
    # Parse
    while True:
        try:
            tok = t.next()
        except StopIteration:
            break
        if tok[0] == token.ENDMARKER:
            break
        if p.addtoken(tok[0], tok[1], tok[2]):
            break
    # Test

# Generated at 2022-06-17 16:56:35.645881
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import unittest
    from . import driver

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            p = Parser(driver.grammar)
            p.setup()
            p.addtoken(token.NUMBER, "1", (1, 0))
            p.addtoken(token.PLUS, "+", (1, 2))
            p.addtoken(token.NUMBER, "2", (1, 4))
            p.addtoken(token.NEWLINE, "\n", (1, 5))
            p.addtoken(token.ENDMARKER, "", (2, 0))
            self.assertEqual(p.rootnode.type, driver.grammar.symbol2number["file_input"])

# Generated at 2022-06-17 16:56:46.046933
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.classify(token.NAME, "if", (1, 0))
    p.classify(token.NAME, "foo", (1, 0))
    p.classify(token.NAME, "if", (1, 0))
    p.classify(token.NAME, "foo", (1, 0))
    p.classify(token.NAME, "if", (1, 0))
    p.classify(token.NAME, "foo", (1, 0))
    p.classify(token.NAME, "if", (1, 0))
    p.classify(token.NAME, "foo", (1, 0))
    p.classify(token.NAME, "if", (1, 0))

# Generated at 2022-06-17 16:56:57.397773
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.expr("1+2")):
        if p.addtoken(*t):
            break
    # Check the result
    assert p.rootnode.type == g.symbol2number["expr"]
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER

# Generated at 2022-06-17 16:57:09.466957
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar
    from . import token

    # Test a simple grammar

# Generated at 2022-06-17 16:57:21.732984
# Unit test for method addtoken of class Parser

# Generated at 2022-06-17 16:57:55.820260
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    g.start = 256
    g.dfas = {256: ([[(1, 0), (0, 1)], [(0, 1)]], {0: 0, 1: 1})}
    g.labels = [(0, 0), (1, 0)]
    p = Parser(g)
    p.setup()
    p.push(256, g.dfas[256], 0, None)
    assert p.stack == [(g.dfas[256], 0, (256, None, None, [])), (g.dfas[256], 0, (256, None, None, []))]
    p.pop()
    assert p.stack == [(g.dfas[256], 0, (256, None, None, []))]

# Generated at 2022-06-17 16:58:02.384969
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.addtoken(token.NAME, "a", None)
    assert p.addtoken(token.NAME, "b", None)
    assert p.addtoken(token.NAME, "c", None)
    assert p.addtoken(token.NAME, "d", None)
    assert p.addtoken(token.NAME, "e", None)
    assert p.addtoken(token.NAME, "f", None)
    assert p.addtoken(token.NAME, "g", None)
    assert p.addtoken(token.NAME, "h", None)
    assert p.addtoken(token.NAME, "i", None)

# Generated at 2022-06-17 16:58:10.063488
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    g.load_grammar(grammar.DEFAULT_GRAMMAR)
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["simple_stmt"]

# Generated at 2022-06-17 16:58:18.005824
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar

    # Test data
    g = grammar.Grammar(driver.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))


# Generated at 2022-06-17 16:58:27.038821
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver

    class Test(unittest.TestCase):
        def test_addtoken(self):
            # Test method addtoken of class Parser
            # This is a simple test, but it's better than nothing
            g = driver.load_grammar("Grammar/Grammar")
            p = Parser(g)
            p.setup()
            p.addtoken(token.NAME, "if", (1, 0))
            p.addtoken(token.NAME, "x", (1, 3))
            p.addtoken(token.COLON, ":", (1, 4))
            p.addtoken(token.NEWLINE, "\n", (1, 5))
            p.addtoken(token.INDENT, "", (2, 0))

# Generated at 2022-06-17 16:58:39.687365
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", driver.FileInput("a").get_token())
    p.addtoken(token.NAME, "b", driver.FileInput("b").get_token())
    p.addtoken(token.NAME, "c", driver.FileInput("c").get_token())
    p.addtoken(token.NAME, "d", driver.FileInput("d").get_token())
    p.addtoken(token.NAME, "e", driver.FileInput("e").get_token())
    p.addtoken(token.NAME, "f", driver.FileInput("f").get_token())

# Generated at 2022-06-17 16:58:53.336544
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import driver

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("NEWLINE", "NEWLINE"), "file_input"])
    g.add_nonterminal("file_input", [])
    g.add_nonterminal("file_input", [("stmt", "stmt"), "file_input"])
    g.add_nonterminal("stmt", [("simple_stmt", "simple_stmt")])
    g.add_nonterminal("simple_stmt", [("small_stmt", "small_stmt"), ("NEWLINE", "NEWLINE")])
    g.add_nonterminal("small_stmt", [("expr_stmt", "expr_stmt")])

# Generated at 2022-06-17 16:59:05.999614
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NAME, "y", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.INDENT, "", None)
    p.addtoken(token.NAME, "print", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.DEDENT, "", None)

# Generated at 2022-06-17 16:59:11.116273
# Unit test for method classify of class Parser
def test_Parser_classify():
    import sys
    from . import grammar, tokenize

    # Create a parser instance
    g = grammar.grammar
    p = Parser(g)

    # Create a tokenizer
    t = tokenize.generate_tokens(sys.stdin.readline)

    # Feed the parser
    p.setup()
    for type, value, start, end, line in t:
        if p.addtoken(type, value, (start, end)):
            break

    # Print the result
    print(p.rootnode)

# Generated at 2022-06-17 16:59:18.069715
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 0))
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))
    p.addtoken(token.NAME, "else", (1, 0))
    p.addtoken(token.COLON, ":", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))