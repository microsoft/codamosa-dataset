

# Generated at 2022-06-17 16:50:18.752279
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar
    from . import tokenize
    import io

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    p.setup()

    # Tokenize a simple expression
    f = io.StringIO("1 + 2")
    t = tokenize.generate_tokens(f.readline)
    for type, value, start, end, line in t:
        if p.addtoken(type, value, (start, end)):
            break

    # Check the result
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    stmt = p.rootnode.children[0]

# Generated at 2022-06-17 16:50:29.991112
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 3))
    p.addtoken(token.EQUAL, "=", (1, 5))
    p.addtoken(token.NUMBER, "1", (1, 7))
    p.addtoken(token.NEWLINE, "\n", (1, 8))
    p.addtoken(token.NAME, "if", (2, 0))
    p.addtoken(token.NAME, "y", (2, 3))
    p.addtoken(token.EQUAL, "=", (2, 5))

# Generated at 2022-06-17 16:50:39.868586
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            g = driver.load_grammar("Grammar.txt")
            p = Parser(g)
            p.setup()
            p.addtoken(token.NAME, "a", (1, 0))
            p.addtoken(token.NAME, "b", (1, 0))
            p.addtoken(token.NAME, "c", (1, 0))
            p.addtoken(token.NAME, "d", (1, 0))
            p.addtoken(token.NAME, "e", (1, 0))
            p.addtoken(token.NAME, "f", (1, 0))
            p.addtoken(token.NAME, "g", (1, 0))

# Generated at 2022-06-17 16:50:52.424826
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, g.dfas[1], 0, None)
    assert p.stack == [(g.dfas[1], 0, (1, None, None, []))]
    p.push(2, g.dfas[2], 0, None)
    assert p.stack == [
        (g.dfas[1], 0, (1, None, None, [])),
        (g.dfas[2], 0, (2, None, None, [])),
    ]
    p.pop()
    assert p.stack == [(g.dfas[1], 0, (1, None, None, [(2, None, None, [])]))]
    p.pop()


# Generated at 2022-06-17 16:50:59.242907
# Unit test for method setup of class Parser
def test_Parser_setup():
    import unittest
    from . import grammar, token

    class ParserTest(unittest.TestCase):
        def test_setup(self):
            g = grammar.grammar
            p = Parser(g)
            p.setup()
            self.assertEqual(len(p.stack), 1)
            self.assertEqual(p.stack[0][0], g.dfas[g.start])
            self.assertEqual(p.stack[0][1], 0)
            self.assertEqual(p.stack[0][2][0], g.start)
            self.assertEqual(p.stack[0][2][1], None)
            self.assertEqual(p.stack[0][2][2], None)

# Generated at 2022-06-17 16:51:12.220621
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"

# Generated at 2022-06-17 16:51:25.307685
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("NEWLINE", "NEWLINE"), "file_input"])
    g.add_nonterminal("file_input", [])
    g.add_nonterminal("file_input", [("stmt", "stmt"), "file_input"])
    g.add_nonterminal("stmt", [("simple_stmt", "simple_stmt")])
    g.add_nonterminal("simple_stmt", [("small_stmt", "small_stmt"), ("NEWLINE", "NEWLINE")])
    g.add_nonterminal("small_stmt", [("expr_stmt", "expr_stmt")])

# Generated at 2022-06-17 16:51:37.120693
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver, token, symbol

    # Create a parser
    p = driver.Parser()
    # Add a token
    p.addtoken(token.NAME, "foo", (1, 0))
    # Check the result
    assert p.stack == [(p.grammar.dfas[symbol.file_input], 0, (symbol.file_input, None, None, []))]
    # Add another token
    p.addtoken(token.NEWLINE, "\n", (2, 0))
    # Check the result
    assert p.stack == [(p.grammar.dfas[symbol.file_input], 0, (symbol.file_input, None, None, [(token.NAME, "foo", (1, 0), None)]))]
    # Add another token

# Generated at 2022-06-17 16:51:51.709764
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(0, (0, 0), 0, 0)
    assert p.stack == [(0, 0, (0, None, 0, []))]
    p.push(1, (0, 0), 0, 0)
    assert p.stack == [(0, 0, (0, None, 0, [])), (0, 0, (1, None, 0, []))]
    p.push(2, (0, 0), 0, 0)
    assert p.stack == [(0, 0, (0, None, 0, [])), (0, 0, (1, None, 0, [])), (0, 0, (2, None, 0, []))]


# Generated at 2022-06-17 16:52:00.438069
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    # Load the grammar
    g = grammar.grammar

    # Create a parser
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))

    # Check the result
    assert p.rootnode.type == symbol.file_input
    assert len(p.rootnode.children) == 1
    stmt = p.rootnode.children[0]
    assert stmt.type == symbol.stmt

# Generated at 2022-06-17 16:52:14.883178
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import grammar
    from . import token

    class TestParser(unittest.TestCase):
        def setUp(self):
            self.grammar = grammar.grammar
            self.parser = Parser(self.grammar)

        def test_addtoken(self):
            self.parser.setup()
            self.parser.addtoken(token.NAME, "a", None)
            self.parser.addtoken(token.NAME, "b", None)
            self.parser.addtoken(token.NAME, "c", None)
            self.parser.addtoken(token.NAME, "d", None)
            self.parser.addtoken(token.NAME, "e", None)
            self.parser.addtoken(token.NAME, "f", None)

# Generated at 2022-06-17 16:52:20.018694
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for type, value, start, end, line in tokenize.generate_tokens(open("test.py")):
        if p.addtoken(type, value, (start, end)):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:52:27.468086
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.PLUS, "+", None)
    p.addtoken(token.NUMBER, "2", None)
    p.addtoken(token.ENDMARKER, "", None)
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["testlist"]
    assert len(p.rootnode.children[0].children) == 3
    assert p.rootnode.children[0].children[0].type == token.NUMBER
   

# Generated at 2022-06-17 16:52:36.703043
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("NEWLINE", "NEWLINE"), "file_input", ("ENDMARKER", "ENDMARKER")])
    g.add_nonterminal("file_input", [])
    g.add_nonterminal("file_input", [("stmt", "stmt"), "file_input"])
    g.add_nonterminal("stmt", [("simple_stmt", "simple_stmt")])
    g.add_nonterminal("simple_stmt", [("small_stmt", "small_stmt"), ("NEWLINE", "NEWLINE")])

# Generated at 2022-06-17 16:52:49.415545
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    g = grammar.Grammar()
    g.load_grammar(driver.grammar)
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("test/test_grammar.py")):
        if t[0] == token.NEWLINE:
            continue
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None

# Generated at 2022-06-17 16:53:02.133400
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver

    class ParserTest(unittest.TestCase):
        def test_addtoken(self):
            # Test the addtoken() method of the Parser class.
            # This is a bit tricky because the parser is a finite state
            # machine, and we have to feed it the right sequence of tokens.
            # We use the grammar module to get the grammar for Python,
            # and then we use the driver module to get the tokens from a
            # Python source file.
            from . import grammar

            g = grammar.grammar
            p = Parser(g)
            p.setup()
            d = driver.Driver(g, p.addtoken)
            d.set_sst_builder(g.sst_builder)

# Generated at 2022-06-17 16:53:13.737265
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 0))
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))
    p.addtoken(token.INDENT, "", (1, 0))
    p.addtoken(token.NAME, "print", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))

# Generated at 2022-06-17 16:53:22.481865
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    def parse(text: str) -> Node:
        p = Parser(grammar.grammar, grammar.convert)
        p.setup()
        for type, value, context in tokenize.generate_tokens(iter([text]).__next__):
            p.addtoken(type, value, context)
        return p.rootnode

    def check(text: str, expected: str) -> None:
        root = parse(text)
        assert str(root) == expected

    check("x = 1", "[expr_stmt: '=' [name: 'x'] [number: '1']]")

# Generated at 2022-06-17 16:53:33.340136
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver
    from . import grammar

    # Create a parser
    p = Parser(grammar.Grammar())

    # Test classify
    assert p.classify(token.NAME, "foo", None) == grammar.syms.name
    assert p.classify(token.NAME, "def", None) == grammar.syms.funcdef
    assert p.classify(token.NAME, "class", None) == grammar.syms.classdef
    assert p.classify(token.NAME, "async", None) == grammar.syms.ASYNC
    assert p.classify(token.NAME, "await", None) == grammar.syms.AWAIT
    assert p.classify(token.NAME, "non", None) == grammar.syms.name

    # Test classify with a bad token

# Generated at 2022-06-17 16:53:46.364307
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Add tokens
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    # Check the result
    assert p.rootnode.type == grammar.syms.simple_stmt
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == grammar.syms.small_stmt

# Generated at 2022-06-17 16:54:06.899142
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "x", Context(1, 0))
    p.addtoken(token.NAME, "y", Context(1, 0))
    p.addtoken(token.NAME, "z", Context(1, 0))
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p

# Generated at 2022-06-17 16:54:15.897163
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [("a", None, None, None)]))]
    p.shift(2, "b", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [("a", None, None, None), ("b", None, None, None)]))]


# Generated at 2022-06-17 16:54:26.378569
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    def convert(grammar, node):
        return node

    p = Parser(grammar, convert)
    p.setup()
    p.shift(token.NAME, "a", 1, None)
    assert p.stack == [(grammar.dfas[grammar.start], 1, (grammar.start, None, None, [('NAME', 'a', None, None)]))]
    p.shift(token.NAME, "b", 2, None)
    assert p.stack == [(grammar.dfas[grammar.start], 2, (grammar.start, None, None, [('NAME', 'a', None, None), ('NAME', 'b', None, None)]))]


# Generated at 2022-06-17 16:54:36.642428
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:54:51.593939
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", driver.FileInput("a").get_token())
    p.addtoken(token.NAME, "b", driver.FileInput("b").get_token())
    p.addtoken(token.NAME, "c", driver.FileInput("c").get_token())
    p.addtoken(token.NAME, "d", driver.FileInput("d").get_token())
    p.addtoken(token.NAME, "e", driver.FileInput("e").get_token())
    p.addtoken(token.NAME, "f", driver.FileInput("f").get_token())

# Generated at 2022-06-17 16:55:03.874018
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "NAME", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 4))
    p.addtoken(token.NAME, "NAME", (2, 0))
    p.addtoken(token.NEWLINE, "\n", (2, 4))
    p.addtoken(token.NAME, "NAME", (3, 0))
    p.addtoken(token.NEWLINE, "\n", (3, 4))
    p.addtoken(token.NAME, "NAME", (4, 0))
    p.addtoken(token.NEWLINE, "\n", (4, 4))

# Generated at 2022-06-17 16:55:15.600723
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.token as token
    import blib2to3.pytree as pytree
    import blib2to3.pgen2.parse as parse

    g = grammar.grammar
    p = parse.Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", pytree.Leaf(1, "foo"))
    p.addtoken(token.NAME, "bar", pytree.Leaf(1, "bar"))
    p.addtoken(token.NAME, "baz", pytree.Leaf(1, "baz"))
    p.addtoken(token.NAME, "quux", pytree.Leaf(1, "quux"))

# Generated at 2022-06-17 16:55:26.309206
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    tokens = tokenize.generate_tokens("x = 1")
    for type, value, context in tokens:
        p.addtoken(type, value, context)
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["simple_stmt"]
    assert p.rootnode.children[0].children[0].children[0].type == g.symbol2number["expr_stmt"]
    assert p.rootnode.children[0].children[0].children

# Generated at 2022-06-17 16:55:37.093736
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()
    p.setup(token.NUMBER)
    assert p.stack == [(g.dfas[token.NUMBER], 0, (token.NUMBER, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-17 16:55:44.309498
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None



# Generated at 2022-06-17 16:56:03.452057
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None

    p.setup(token.NUMBER)
    assert p.stack == [(g.dfas[token.NUMBER], 0, (token.NUMBER, None, None, []))]
    assert p.rootnode is None


# Generated at 2022-06-17 16:56:17.049345
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 3))
    p.addtoken(token.EQEQUAL, "==", Context(1, 5))
    p.addtoken(token.NUMBER, "0", Context(1, 8))
    p.addtoken(token.COLON, ":", Context(1, 9))
    p.addtoken(token.NEWLINE, "\n", Context(1, 10))
    p.addtoken(token.INDENT, "", Context(2, 0))
    p.addtoken(token.NAME, "print", Context(2, 4))

# Generated at 2022-06-17 16:56:29.171708
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.addtoken(token.NAME, "foo", (1, 0))
    assert p.addtoken(token.NAME, "bar", (1, 0))
    assert p.addtoken(token.NAME, "baz", (1, 0))
    assert p.addtoken(token.NEWLINE, "\n", (1, 0))
    assert p.addtoken(token.NAME, "qux", (1, 0))
    assert p.addtoken(token.NEWLINE, "\n", (1, 0))
    assert p.addtoken(token.NAME, "quux", (1, 0))
    assert p.addtoken(token.NEWLINE, "\n", (1, 0))

# Generated at 2022-06-17 16:56:35.592611
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:56:41.061429
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar/Grammar")):
        p.addtoken(t[0], t[1], t[2])

# Generated at 2022-06-17 16:56:52.632012
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver, token

    class ParserTestCase(unittest.TestCase):
        def test_addtoken(self):
            p = driver.Parser()
            p.setup()
            self.assertFalse(p.addtoken(token.NAME, "foo", (1, 0)))
            self.assertFalse(p.addtoken(token.EQUAL, "=", (1, 3)))
            self.assertFalse(p.addtoken(token.NUMBER, "42", (1, 5)))
            self.assertTrue(p.addtoken(token.NEWLINE, "\n", (1, 7)))
            self.assertEqual(p.rootnode.type, token.file_input)
            self.assertEqual(len(p.rootnode.children), 1)
            self.assertEqual

# Generated at 2022-06-17 16:56:59.579043
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:57:12.183026
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar, driver.convert)
    # Parse a simple expression
    p.setup()
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(*t):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[1].value == "+"

# Generated at 2022-06-17 16:57:23.300293
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.StringInput("1 + 2").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token

# Generated at 2022-06-17 16:57:34.917076
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "y", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "2", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p

# Generated at 2022-06-17 16:58:06.020009
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.parse import parse_grammar
    from blib2to3.pytree import Leaf
    from io import StringIO
    from blib2to3.pgen2.pgen import driver
    from blib2to3.pgen2.pgen import tokenize
    from blib2to3.pgen2.pgen import Parser

    # Create a grammar
    g = parse_grammar(StringIO(driver.grammar), "exec")
    # Create a parser
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse a token

# Generated at 2022-06-17 16:58:16.448675
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, tokenize
    from .pgen2.parse import ParseError
    from .pgen2.driver import Driver
    from .pytree import Leaf, Node

    def test(input, expected):
        driver = Driver(grammar.grammar, convert=grammar.convert)
        driver.setup()
        for t in tokenize.generate_tokens(input):
            if driver.addtoken(t.type, t.string, (t.start, t.end)):
                break
        assert driver.rootnode == expected

    test("1", Leaf(1, "1", (0, 1)))

# Generated at 2022-06-17 16:58:26.270943
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:58:35.879487
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.ENDMARKER, "", None)
    assert p.rootnode is not None

# Generated at 2022-06-17 16:58:42.210306
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    tok = tokenize.generate_tokens(iter(["1"]).__next__)
    t = next(tok)
    p.addtoken(t[0], t[1], t[2])
    assert p.stack[0][2][3][0].value == "1"

# Generated at 2022-06-17 16:58:54.126507
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 2))
    p.addtoken(token.NAME, "y", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode.children[0].children[0].value == "x"
    assert p.rootnode.children[0].children[1].value == "="
    assert p.rootnode.children[0].children[2].value == "y"

# Generated at 2022-06-17 16:59:06.416094
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 0, None)
    assert p.stack == [(g.dfas[1], 0, (1, "a", None, None))]
    p.shift(2, "b", 0, None)
    assert p.stack == [(g.dfas[1], 0, (1, "a", None, None)), (g.dfas[2], 0, (2, "b", None, None))]
    p.shift(3, "c", 0, None)

# Generated at 2022-06-17 16:59:13.183568
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:59:24.440387
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))
    p.addtoken

# Generated at 2022-06-17 16:59:31.941244
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()