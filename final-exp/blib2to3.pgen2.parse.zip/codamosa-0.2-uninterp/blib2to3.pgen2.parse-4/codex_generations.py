

# Generated at 2022-06-17 16:50:11.723075
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    tokens = tokenize.generate_tokens(open("Grammar.txt"))
    for type, value, start, end, line in tokens:
        if p.addtoken(type, value, (start, end)):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:50:19.122465
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar
    from . import tokenize

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Tokenize a string
    tokens = tokenize.generate_tokens(driver.StringIO("x = 1").readline)
    # Feed the tokens to the parser
    for type, value, start, end, line in tokens:
        p.addtoken(type, value, (start, end))
    # Get the abstract syntax tree
    ast = p.rootnode
    # Check the abstract syntax tree
    assert ast.type == grammar.syms.file_input
    assert len(ast.children) == 1
    stmt = ast.children[0]
    assert stmt.type == grammar.syms.stmt


# Generated at 2022-06-17 16:50:25.995843
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-17 16:50:32.446868
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar)

    # Create a tokenizer
    t = tokenize.generate_tokens(open("test.py"))

    # Feed tokens to the parser
    p.setup()
    for type, value, start, end, line in t:
        if p.addtoken(type, value, (start, end)):
            break

    # Print the abstract syntax tree
    driver.tokens(p.rootnode)

# Generated at 2022-06-17 16:50:38.855481
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()



# Generated at 2022-06-17 16:50:52.024553
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in driver.tokenize("a = 1"):
        if p.addtoken(t.type, t.string, t.context):
            break
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1
    assert p.rootnode.children[0].children[0].type == g.symbol2number["simple_stmt"]
    assert len(p.rootnode.children[0].children[0].children)

# Generated at 2022-06-17 16:50:55.850508
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, tokenize

    g = grammar.Grammar()
    g.load_grammar(grammar.DEFAULT_GRAMMAR)
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open(__file__)):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None

# Generated at 2022-06-17 16:51:08.740887
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)

    # Create a tokenizer
    t = tokenize.Tokenizer()

    # Create a driver
    d = driver.Driver(p, t)

    # Test

# Generated at 2022-06-17 16:51:16.779295
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("NEWLINE",), ("stmt", "file_input")])
    g.add_nonterminal("stmt", [("simple_stmt",)])
    g.add_nonterminal("simple_stmt", [("small_stmt", "NEWLINE")])
    g.add_nonterminal("small_stmt", [("expr_stmt",)])
    g.add_nonterminal("expr_stmt", [("testlist",)])
    g.add_nonterminal("testlist", [("test",)])
    g.add_nonterminal("test", [("or_test",)])
    g.add_nonterminal

# Generated at 2022-06-17 16:51:29.013977
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test_grammar.py").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == token.NAME
    assert p.rootnode.children[0].children[0].value == "x"

# Generated at 2022-06-17 16:51:42.853116
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    g.load_grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "print", (1, 0))
    p.addtoken(token.LPAR, "(", (1, 5))
    p.addtoken(token.STRING, "hello", (1, 6))
    p.addtoken(token.COMMA, ",", (1, 12))
    p.addtoken(token.STRING, "world", (1, 14))
    p.addtoken(token.RPAR, ")", (1, 19))
    p.addtoken(token.NEWLINE, "\n", (1, 20))
    assert p.rootnode is not None
    assert p.rootnode

# Generated at 2022-06-17 16:51:54.429844
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.convert import convert_tree
    from blib2to3.pytree import Leaf, Node
    from blib2to3.pgen2.token import TokenInfo
    from blib2to3.pgen2.grammar import Grammar
    from io import StringIO
    from typing import List
    import sys
    import os

    # Create a grammar object

# Generated at 2022-06-17 16:52:05.843324
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:52:12.534512
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(token.NAME, "x", 0, None)
    p.shift(token.NAME, "y", 0, None)
    p.shift(token.NAME, "z", 0, None)
    assert p.rootnode.children == ["x", "y", "z"]


# Generated at 2022-06-17 16:52:21.818943
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:52:25.520412
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:52:30.976215
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    def test(s: Text, type: int, value: Optional[Text], context: Context) -> None:
        p = Parser(driver.grammar)
        p.setup()
        for t in driver.tokenize(s):
            if p.addtoken(*t):
                break
        assert (type, value, context) == (t.type, t.value, t.context)

    test("1", token.NUMBER, "1", (1, 0))
    test("1+1", token.NUMBER, "1", (1, 0))
    test("1+1", token.OP, "+", (1, 1))
    test("1+1", token.NUMBER, "1", (1, 2))

# Generated at 2022-06-17 16:52:41.145828
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar

    # Create a parser
    p = Parser(grammar.grammar)

    # Parse a simple expression
    p.setup()
    for t in driver.tokenize("1 + 2"):
        if p.addtoken(*t):
            break
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER

    # Parse a simple expression, using a different start symbol
    p.setup(grammar.syms.term)

# Generated at 2022-06-17 16:52:49.005862
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    def convert(grammar, node):
        if node[0] == grammar.symbol2number["test"]:
            return node[3]
        return node

    p = Parser(grammar.Grammar(grammar.grammar, grammar.symbol2number), convert)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)

# Generated at 2022-06-17 16:53:01.784895
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver

    g = driver.load_grammar("Grammar.txt")
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))
   

# Generated at 2022-06-17 16:53:13.528943
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        p.addtoken(t[0], t[1], t[2])

    # Check the result
    assert p.rootnode.type == g.symbol2number["expr_stmt"]
    assert p.rootnode.children[0].type == g.symbol2number["expr"]
    assert p.rootnode.children[0].children[0].type == token.NUMBER
    assert p.rootnode.children[0].children[0].value == "1"

# Generated at 2022-06-17 16:53:22.387766
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break

    # Get the result
    root = p.rootnode

    # Check the result
    assert root.type == grammar.syms.expr
    assert len(root.children) == 3
    assert root.children[0].type == token.NUMBER
    assert root.children[0].value == "1"
    assert root.children[1].type == token.PLUS

# Generated at 2022-06-17 16:53:33.279713
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import driver
    from . import tokenize
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.FileInput("1 + 2").readline):
        if p.addtoken(t.type, t.string, t.start):
            break

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token

# Generated at 2022-06-17 16:53:46.278152
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    # Create a parser
    p = Parser(grammar.grammar)
    # Parse a simple expression
    p.setup()
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[1].value == "+"
    assert p.root

# Generated at 2022-06-17 16:53:53.715413
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import driver
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.StringInput("1 + 2").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1

# Generated at 2022-06-17 16:54:04.819160
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    def test(s: Text) -> None:
        print("Testing", repr(s))
        p = Parser(driver.grammar)
        p.setup()
        for t in driver.tokenize(s):
            if p.addtoken(t.type, t.string, t.context):
                break
        print(p.rootnode)

    test("a = 1")
    test("a = 1 + 2")
    test("a = 1 + 2 + 3")
    test("a = 1 + 2 + 3 + 4")
    test("a = 1 + 2 + 3 + 4 + 5")
    test("a = 1 + 2 + 3 + 4 + 5 + 6")
    test("a = 1 + 2 + 3 + 4 + 5 + 6 + 7")

# Generated at 2022-06-17 16:54:11.436983
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:54:21.159160
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Parse a simple expression
    p.setup()
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1

# Generated at 2022-06-17 16:54:25.061174
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, 2, 3, 4)
    assert p.stack == [(2, 0, (1, None, 4, []))]

# Generated at 2022-06-17 16:54:35.440361
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Create a parser
    p = Parser(grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[1].value == "+"
    assert p.rootnode

# Generated at 2022-06-17 16:54:53.846456
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.StringInput("1 + 2").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS

# Generated at 2022-06-17 16:55:05.547961
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    def test(input: Text, expected: Results) -> None:
        p = Parser(grammar.grammar)
        p.setup()
        for type, value, context in tokenize.generate_tokens(input):
            if p.addtoken(type, value, context):
                break
        assert p.rootnode is not None
        for key, value in expected.items():
            assert p.rootnode[key] == value

    test("1", {"type": "file_input", "children": [Leaf(1, "1", (1, 0))]})
    test("1\n", {"type": "file_input", "children": [Leaf(1, "1", (1, 0))]})

# Generated at 2022-06-17 16:55:13.794458
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)
   

# Generated at 2022-06-17 16:55:19.281977
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    import io

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))
    p.addtoken

# Generated at 2022-06-17 16:55:28.581608
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.classify(token.NAME, "if", None) == g.keywords["if"]
    assert p.classify(token.NAME, "spam", None) == g.tokens[token.NAME]
    assert p.classify(token.PLUS, "+", None) == g.tokens[token.PLUS]
    assert p.classify(token.NEWLINE, "\n", None) == g.tokens[token.NEWLINE]
    assert p.classify(token.INDENT, "", None) == g.tokens[token.INDENT]

# Generated at 2022-06-17 16:55:40.062371
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))
    p.addtoken(token.NAME, "garply", (1, 0))

# Generated at 2022-06-17 16:55:49.454824
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 0))
    p.addtoken(token.NAME, "g", Context(1, 0))
    p.addtoken(token.NAME, "h", Context(1, 0))
    p.addtoken

# Generated at 2022-06-17 16:56:01.768657
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.NAME, "y", (1, 0))
    p.addtoken(token.NAME, "z", (1, 0))
    p.addtoken(token.NAME, "elif", (1, 0))
    p.addtoken(token.NAME, "elif", (1, 0))
    p.addtoken(token.NAME, "else", (1, 0))
    p.addtoken(token.NAME, "else", (1, 0))

# Generated at 2022-06-17 16:56:07.345778
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 2, None)
    assert p.stack == [(None, 2, (1, None, None, []))]
    p.push(2, (None, None), 3, None)
    assert p.stack == [(None, 2, (1, None, None, [])), (None, 3, (2, None, None, []))]


# Generated at 2022-06-17 16:56:20.404047
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))
    p.addtoken(token.NAME, "i", (1, 0))

# Generated at 2022-06-17 16:56:38.184744
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [("a", "a", None, None)]))]

# Generated at 2022-06-17 16:56:51.678496
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [("a", None, None, None)]))]
    p.shift(2, "b", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [("a", None, None, None), ("b", None, None, None)]))]
    p.shift(3, "c", 4, None)

# Generated at 2022-06-17 16:56:57.748096
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break
    # Get the abstract syntax tree
    ast = p.rootnode
    # Convert it to Python code
    print(driver.tostring(ast))

# Generated at 2022-06-17 16:57:09.551695
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.pgen import generate_grammar
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pygram import python_grammar
    from blib2to3.pytree import Leaf
    from blib2to3.fixer_util import Name
    from blib2to3.fixer_util import Comma
    from blib2to3.fixer_util import Newline
    from blib2to3.fixer_util import Number
    from blib2to3.fixer_util import String

# Generated at 2022-06-17 16:57:21.822869
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 3))
    p.addtoken(token.EQUAL, "=", Context(1, 5))
    p.addtoken(token.NUMBER, "0", Context(1, 7))
    p.addtoken(token.NEWLINE, "\n", Context(1, 8))
    p.addtoken(token.NAME, "print", Context(2, 0))
    p.addtoken(token.NAME, "x", Context(2, 6))
    p.addtoken(token.NEWLINE, "\n", Context(2, 7))
    p.addtoken

# Generated at 2022-06-17 16:57:29.366356
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)
   

# Generated at 2022-06-17 16:57:36.975795
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar, driver.convert)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Get the abstract syntax tree
    ast = p.rootnode
    # Check the result
    assert ast.type == grammar.syms.expr
    assert ast.children[0].type == token.NUMBER
    assert ast.children[0].value == "1"
    assert ast.children[1].type == token.PLUS
    assert ast.children[2].type == token.NUMBER

# Generated at 2022-06-17 16:57:52.076917
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:58:02.951138
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import driver

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, (1, 0))
    p.shift(2, "b", 3, (1, 1))
    p.shift(3, "c", 4, (1, 2))
    p.shift(4, "d", 5, (1, 3))
    p.shift(5, "e", 6, (1, 4))
    p.shift(6, "f", 7, (1, 5))
    p.shift(7, "g", 8, (1, 6))
    p.shift(8, "h", 9, (1, 7))
    p.shift(9, "i", 10, (1, 8))


# Generated at 2022-06-17 16:58:14.815306
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver

    class ParserTestCase(unittest.TestCase):
        def test_addtoken(self):
            # Test the addtoken() method of the Parser class.
            # This is a bit tricky because we need to create a
            # Parser instance and a Grammar instance.
            # The Grammar instance is created by parsing a
            # small grammar file.
            import io
            from . import grammar

            # Create a grammar instance
            g = grammar.Grammar()
            g.parse_grammar(io.StringIO("""
            start: a
            a: 'a'
            """))
            # Create a parser instance
            p = Parser(g)
            # Prepare for parsing
            p.setup()
            # Add a token

# Generated at 2022-06-17 16:58:45.191565
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    g = grammar.grammar

    p = Parser(g)
    p.setup()
    p.push(g.symbol2number["file_input"], g.dfas[g.symbol2number["file_input"]], 0, None)
    assert p.stack[-1][0] == g.dfas[g.symbol2number["file_input"]]
    assert p.stack[-1][1] == 0
    assert p.stack[-1][2][0] == g.symbol2number["file_input"]
    assert p.stack[-1][2][1] is None
    assert p.stack[-1][2][2] is None

# Generated at 2022-06-17 16:58:51.137159
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)
   

# Generated at 2022-06-17 16:58:55.295378
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open(__file__)):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]

# Generated at 2022-06-17 16:59:06.749366
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Create a tokenizer
    t = tokenize.tokenize("x = 1")

    # Feed the tokenizer to the parser
    p.setup()
    for type, value, context in t:
        p.addtoken(type, value, context)

    # Check the result
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    stmt = p.rootnode.children[0]
    assert stmt.type == g.symbol2number["stmt"]
    assert len(stmt.children) == 1
    simple_stmt = stmt.children[0]
    assert simple

# Generated at 2022-06-17 16:59:17.093089
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.pgen import generate_grammar

    g = Grammar(generate_grammar(open("Grammar/Grammar")))
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 3))
    p.addtoken(token.COLON, ":", Context(1, 4))
    p.addtoken(token.NEWLINE, "\n", Context(1, 5))
    p.addtoken(token.INDENT, "", Context(2, 0))
    p.addtoken(token.NAME, "print", Context(2, 4))


# Generated at 2022-06-17 16:59:27.597001
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 3))
    p.addtoken(token.NAME, "bar", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 7))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    stmt = p.rootnode.children[0]
    assert stmt.type == g.symbol2number["stmt"]
    assert len(stmt.children) == 1
    expr = stmt.children[0]

# Generated at 2022-06-17 16:59:38.003896
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:59:52.101750
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 3))
    p.addtoken(token.NAME, "baz", (1, 6))
    p.addtoken(token.NAME, "qux", (1, 9))
    p.addtoken(token.NAME, "quux", (1, 12))
    p.addtoken(token.NAME, "corge", (1, 17))
    p.addtoken(token.NAME, "grault", (1, 23))

# Generated at 2022-06-17 17:00:01.251451
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar

    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.stack = [
        (
            (
                [
                    [(1, 1), (2, 2), (3, 3)],
                    [(0, 1)],
                    [(0, 2)],
                    [(0, 3)],
                ],
                {1: 0, 2: 1, 3: 2},
            ),
            0,
            (1, None, None, []),
        )
    ]
    parser.pop()
    assert parser.stack == []
    assert parser.rootnode.type == 1
    assert parser.rootnode.children == []
    assert parser.rootnode.context is None
    assert parser.rootnode.value is None

