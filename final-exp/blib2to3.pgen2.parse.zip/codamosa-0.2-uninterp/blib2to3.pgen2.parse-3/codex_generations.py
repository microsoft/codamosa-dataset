

# Generated at 2022-06-17 16:50:13.867597
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 0, None)
    p.shift(2, "b", 0, None)
    p.shift(3, "c", 0, None)
    assert p.rootnode == [Leaf(1, "a"), Leaf(2, "b"), Leaf(3, "c")]


# Generated at 2022-06-17 16:50:20.396228
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break
    assert p.rootnode.type == grammar.syms.expr
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER
    assert p.rootnode.children[2].value == "2"



# Generated at 2022-06-17 16:50:30.483952
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    d = driver.Driver(g, p.convert)
    d.set_parser(p)
    d.parse_tokens(tokenize.generate_tokens(open("test/input/future1.txt")))
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1

# Generated at 2022-06-17 16:50:39.928726
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Push a nonterminal
    p.push(1, (None, None), 0, None)

    # Pop a nonterminal
    p.pop()

    # Push a nonterminal
    p.push(1, (None, None), 0, None)

    # Pop a nonterminal
    p.pop()

    # Push a nonterminal
    p.push(1, (None, None), 0, None)

    # Pop a nonterminal
    p.pop()

    # Push a nonterminal
    p.push(1, (None, None), 0, None)

    # Pop a nonterminal
    p.pop()

    # Push a nontermin

# Generated at 2022-06-17 16:50:52.455879
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 0))
    p.addtoken(token.NAME, "g", Context(1, 0))
    p.addtoken(token.NAME, "h", Context(1, 0))

# Generated at 2022-06-17 16:51:04.612754
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", Context(1, 0))
    p.addtoken(token.NAME, "bar", Context(1, 0))
    p.addtoken(token.NAME, "baz", Context(1, 0))
    p.addtoken(token.NAME, "qux", Context(1, 0))
    p.addtoken(token.NAME, "quux", Context(1, 0))
    p.addtoken(token.NAME, "corge", Context(1, 0))
    p.addtoken(token.NAME, "grault", Context(1, 0))
    p.addtoken(token.NAME, "garply", Context(1, 0))
    p.add

# Generated at 2022-06-17 16:51:12.132454
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    import sys

    g = grammar.Grammar()
    g.load_grammar(sys.modules[__name__])
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(sys.stdin.readline):
        if p.addtoken(t[0], t[1], t[2]):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:51:25.263347
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import driver

    g = grammar.Grammar()
    g.load_grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "x", driver.Context(1, 0))
    p.addtoken(token.EQUAL, "=", driver.Context(1, 2))
    p.addtoken(token.NAME, "y", driver.Context(1, 4))
    p.addtoken(token.NEWLINE, "\n", driver.Context(1, 5))
    p.addtoken(token.ENDMARKER, "", driver.Context(1, 6))
    assert p.rootnode.type == g.syms["file_input"]

# Generated at 2022-06-17 16:51:37.077640
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    g.load_grammar("Grammar/Grammar")
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 1, None)
    assert p.stack == [(g.dfas[1], 1, (1, None, None, [Leaf(1, "a", None)]))]
    p.shift(2, "b", 2, None)
    assert p.stack == [(g.dfas[1], 2, (1, None, None, [Leaf(1, "a", None), Leaf(2, "b", None)]))]
    p.shift(3, "c", 3, None)

# Generated at 2022-06-17 16:51:51.703011
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 1, None)
    assert p.stack == [(g.dfas[g.start], 1, (g.start, None, None, [Leaf(1, "a")]))]
    p.shift(1, "b", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(1, "a"), Leaf(1, "b")]))]
    p.shift(1, "c", 3, None)

# Generated at 2022-06-17 16:52:04.120106
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", (("stmt", "file_input"),))
    g.add_nonterminal("stmt", (("simple_stmt",), ("compound_stmt",)))
    g.add_nonterminal("simple_stmt", (("small_stmt", "NEWLINE"),))
    g.add_nonterminal("small_stmt", (("expr_stmt",),))
    g.add_nonterminal("expr_stmt", (("testlist",),))
    g.add_nonterminal("testlist", (("test",), ("test", "COMMA", "testlist")))
    g.add_nonterminal

# Generated at 2022-06-17 16:52:14.390988
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (0, 0))
    p.addtoken(token.NAME, "b", (0, 0))
    p.addtoken(token.NAME, "c", (0, 0))
    p.addtoken(token.NAME, "d", (0, 0))
    p.addtoken(token.NAME, "e", (0, 0))
    p.addtoken(token.NAME, "f", (0, 0))
    p.addtoken(token.NAME, "g", (0, 0))
    p.addtoken(token.NAME, "h", (0, 0))

# Generated at 2022-06-17 16:52:20.731499
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.NAME, "y", (1, 0))
    p.addtoken(token.NAME, "z", (1, 0))
    p.addtoken(token.NAME, "elif", (1, 0))
    p.addtoken(token.NAME, "else", (1, 0))
    p.addtoken(token.NAME, "while", (1, 0))
    p.addtoken(token.NAME, "for", (1, 0))

# Generated at 2022-06-17 16:52:27.819552
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)

# Generated at 2022-06-17 16:52:36.859619
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Parse a simple expression
    p.setup()
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break
    assert p.rootnode.type == g.symbol2number["expr_stmt"]
    assert p.rootnode.children[0].type == g.symbol2number["expr"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["xor_expr"]

# Generated at 2022-06-17 16:52:51.975261
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Create a parser
    p = Parser(grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[1].value == "+"
    assert p.rootnode

# Generated at 2022-06-17 16:53:05.125651
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)

# Generated at 2022-06-17 16:53:17.042457
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.shift(token.NAME, "foo", 1, (1, 0))
    assert p.stack == [(g.dfas[g.start], 1, (g.start, None, None, [Leaf(token.NAME, "foo", (1, 0))]))]
    p.shift(token.NAME, "bar", 2, (1, 3))
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(token.NAME, "foo", (1, 0)), Leaf(token.NAME, "bar", (1, 3))]))]


# Generated at 2022-06-17 16:53:29.370759
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        p.addtoken(t.type, t.string, t.start)
    # Check the result
    assert p.rootnode.type == g.symbol2number["expr_stmt"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["expr"]
    assert len(p.rootnode.children[0].children) == 3
    assert p.rootnode.children[0].children[0].type == token.NUMBER

# Generated at 2022-06-17 16:53:42.306544
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.classify(token.NAME, "if", None)
    p.classify(token.NAME, "else", None)
    p.classify(token.NAME, "elif", None)
    p.classify(token.NAME, "while", None)
    p.classify(token.NAME, "for", None)
    p.classify(token.NAME, "in", None)
    p.classify(token.NAME, "def", None)
    p.classify(token.NAME, "class", None)
    p.classify(token.NAME, "yield", None)
    p.classify(token.NAME, "return", None)

# Generated at 2022-06-17 16:54:00.694041
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.load_grammar(driver.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 2))
    p.addtoken(token.NUMBER, "3", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    assert p.rootnode.children[0].children[0].value == "x"
    assert p.rootnode.children[0].children[1].value == "="
    assert p.rootnode.children[0].children[2].value == "3"

# Generated at 2022-06-17 16:54:09.079176
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 3))
    p.addtoken(token.EQUAL, "=", Context(1, 5))
    p.addtoken(token.NUMBER, "1", Context(1, 7))
    p.addtoken(token.NEWLINE, "\n", Context(1, 8))
    p.addtoken(token.NAME, "else", Context(2, 0))
    p.addtoken(token.COLON, ":", Context(2, 4))
    p.addtoken(token.NEWLINE, "\n", Context(2, 5))
    p.add

# Generated at 2022-06-17 16:54:18.353562
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    # Test the parser on a simple expression
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode.type == g.symbol2number["expr_stmt"]
    assert p.rootnode.children[0].type == g.symbol2number["expr"]
    assert p.rootnode.children[0].children[0].type == token.NUMBER
    assert p.rootnode.children[0].children[0].value == "1"
    assert p.rootnode.children[0].children[1].type == token.PLUS

# Generated at 2022-06-17 16:54:28.665726
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:54:38.452783
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar
    from . import token
    from . import tokenize
    from . import symbol
    from . import parse
    from . import pytree
    from . import pygram
    from . import pytoken

    # Create a parser
    p = Parser(grammar.grammar)

    # Set up the parser
    p.setup()

    # Create a token
    tok = token.Token()
    tok.type = token.NAME
    tok.string = "NAME"
    tok.start = (1, 0)
    tok.end = (1, 4)
    tok.line = "NAME"

    # Shift the token
    p.shift(tok.type, tok.string, 0, tok.start)

    # Check the result
    assert p.stack

# Generated at 2022-06-17 16:54:44.493131
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token
    from . import driver
    from . import parse
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pygram


# Generated at 2022-06-17 16:54:50.788303
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()



# Generated at 2022-06-17 16:55:02.940614
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 0))
    p.addtoken(token.NAME, "g", Context(1, 0))
    p.addtoken(token.NAME, "h", Context(1, 0))

# Generated at 2022-06-17 16:55:13.665708
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Test a simple grammar
    g = grammar.Grammar(
        """
        start: NAME
        """
    )
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (2, 0))
    assert p.rootnode.type == token.NAME
    assert p.rootnode.value == "foo"
    assert p.rootnode.context == (1, 0)
    assert p.rootnode.children == []

    # Test a grammar with a rule
    g = grammar.Grammar(
        """
        start: NAME NAME
        """
    )
    p = Parser(g)
    p.setup()
    p.add

# Generated at 2022-06-17 16:55:25.501242
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 3))
    p.addtoken(token.EQUAL, "=", (1, 5))
    p.addtoken(token.NAME, "y", (1, 7))
    p.addtoken(token.NEWLINE, "\n", (1, 8))
    p.addtoken(token.INDENT, "", (2, 0))
    p.addtoken(token.NAME, "print", (2, 4))
    p.addtoken(token.NAME, "x", (2, 9))

# Generated at 2022-06-17 16:55:41.414510
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:55:50.222791
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    def convert(grammar, node):
        return node

    p = Parser(grammar.grammar, convert)
    p.setup()
    for t in tokenize.generate_tokens(open("../../../Lib/test/input/tokenize_tests.txt")):
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode[0] == grammar.syms.file_input
    assert p.rootnode[1] is None
    assert p.rootnode[2] is None
    assert len(p.rootnode[3]) == 1
    assert p.rootnode[3][0][0] == grammar.syms.stmt
    assert p.rootnode[3][0][1] is None
    assert p

# Generated at 2022-06-17 16:55:56.147277
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import grammar
    from . import tokenize


# Generated at 2022-06-17 16:56:04.781321
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    g.load_grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("../../../../Lib/test/badsyntax_3.py")):
        if t[0] == token.ENDMARKER:
            break
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode is not None

# Generated at 2022-06-17 16:56:17.859687
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert len(p.stack) == 1
    assert p.stack[0][0] == g.dfas[g.start]
    assert p.stack[0][1] == 0
    assert p.stack[0][2][0] == g.start
    assert p.stack[0][2][1] is None
    assert p.stack[0][2][2] is None
    assert p.stack[0][2][3] == []
    p.setup(token.NAME)
    assert len(p.stack) == 1
    assert p.stack[0][0] == g.dfas[token.NAME]
    assert p.stack[0][1] == 0

# Generated at 2022-06-17 16:56:24.461448
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-17 16:56:33.025789
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver

    class TestCase(unittest.TestCase):
        def test_addtoken(self):
            p = Parser(driver.grammar)
            p.setup()
            p.addtoken(token.NAME, "a", (1, 0))
            p.addtoken(token.NAME, "b", (1, 0))
            p.addtoken(token.NAME, "c", (1, 0))
            p.addtoken(token.NAME, "d", (1, 0))
            p.addtoken(token.NAME, "e", (1, 0))
            p.addtoken(token.NAME, "f", (1, 0))
            p.addtoken(token.NAME, "g", (1, 0))

# Generated at 2022-06-17 16:56:44.676615
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:56:52.698199
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-17 16:56:59.601049
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 3))
    p.addtoken(token.EQUAL, "=", Context(1, 5))
    p.addtoken(token.NUMBER, "0", Context(1, 7))
    p.addtoken(token.NEWLINE, "\n", Context(1, 8))
    p.addtoken(token.INDENT, "", Context(2, 0))
    p.addtoken(token.NAME, "print", Context(2, 4))
    p.addtoken(token.NAME, "x", Context(2, 9))

# Generated at 2022-06-17 16:57:22.001781
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import token

    # Test the parser by parsing a simple expression grammar
    #
    # expr: expr '+' expr
    #      | expr '*' expr
    #      | '(' expr ')'
    #      | NUMBER
    #
    # and feeding it the token stream 1 + 2 * 3
    #
    # The parse tree is:
    #
    #       expr
    #        |
    #        +
    #       / \
    #      1   *
    #          |
    #          2
    #          |
    #          3
    #
    # The concrete syntax tree is:
    #
    # (expr, None, None,
    #   [(expr, None, None,
    #      [(expr, None

# Generated at 2022-06-17 16:57:29.467944
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:57:37.064966
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"
    g.tokens = {
        token.NAME: "NAME",
        token.NEWLINE: "NEWLINE",
        token.INDENT: "INDENT",
        token.DEDENT: "DEDENT",
        token.ENDMARKER: "ENDMARKER",
    }
    g.labels = {
        "NAME": (token.NAME, None),
        "NEWLINE": (token.NEWLINE, None),
        "INDENT": (token.INDENT, None),
        "DEDENT": (token.DEDENT, None),
        "ENDMARKER": (token.ENDMARKER, None),
    }

# Generated at 2022-06-17 16:57:52.114335
# Unit test for method pop of class Parser
def test_Parser_pop():
    def lam_sub(grammar: Grammar, node: RawNode) -> NL:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])
    p = Parser(Grammar(), lam_sub)
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 0))
    p.add

# Generated at 2022-06-17 16:58:02.950083
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        p.addtoken(t[0], t[1], t[2])

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS

# Generated at 2022-06-17 16:58:10.366016
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 2))
    p.addtoken(token.NAME, "y", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children

# Generated at 2022-06-17 16:58:22.158400
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    import io
    import sys
    import unittest

    class ParserTestCase(unittest.TestCase):
        def setUp(self):
            self.grammar = grammar.Grammar()
            self.parser = Parser(self.grammar)
            self.parser.setup()


# Generated at 2022-06-17 16:58:29.597513
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver
    from . import grammar

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            g = grammar.Grammar()
            p = Parser(g)
            p.setup()
            self.assertRaises(ParseError, p.addtoken, token.NUMBER, "1", (1, 0))
            self.assertRaises(ParseError, p.addtoken, token.NAME, "a", (1, 0))
            self.assertRaises(ParseError, p.addtoken, token.NEWLINE, "", (1, 0))
            self.assertRaises(ParseError, p.addtoken, token.ENDMARKER, "", (1, 0))

# Generated at 2022-06-17 16:58:41.872833
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import driver
    from . import tokenize
    from . import token

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)

    # Create a tokenizer
    t = tokenize.tokenize(b"a = 1")
    t.next()

    # Setup the parser
    p.setup()

    # Add a token
    p.addtoken(token.NAME, "a", (1, 0))

    # Pop a nonterminal
    p.pop()

    # Add a token
    p.addtoken(token.EQUAL, "=", (1, 2))

    # Pop a nonterminal
    p.pop()

    # Add a token
    p.addtoken(token.NUMBER, "1", (1, 4))

    #

# Generated at 2022-06-17 16:58:54.017052
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import tokenize

    # Test setup()
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    # Test addtoken()
    for type, value, start, end, line in tokenize.generate_tokens(
        open(__file__).readline
    ):
        if type == tokenize.COMMENT:
            continue
        if type == tokenize.OP and value == "@":
            type = token.AT
        elif type == token.OP and value == "*":
            type = token.STAR
        elif type == token.OP and value == "**":
            type = token.DOUBLESTAR
        elif type == token.OP and value == ",":
            type = token.COMMA

# Generated at 2022-06-17 16:59:29.165691
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.grammar

    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None

    p.setup(token.NUMBER)
    assert p.stack == [(g.dfas[token.NUMBER], 0, (token.NUMBER, None, None, []))]
    assert p.rootnode is None

    p.setup(token.NAME)
    assert p.stack == [(g.dfas[token.NAME], 0, (token.NAME, None, None, []))]
    assert p.rootnode is None

    p.setup(g.start)

# Generated at 2022-06-17 16:59:38.818910
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)
   

# Generated at 2022-06-17 16:59:52.706742
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    g.load_grammar("Grammar/Grammar")
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 2))
    p.addtoken(token.NAME, "y", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode

# Generated at 2022-06-17 17:00:01.539610
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p