

# Generated at 2022-06-17 16:50:17.622910
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, tokenize

    g = grammar.Grammar()
    g.load_grammar(grammar.DEFAULT_GRAMMAR)
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode is not None

# Generated at 2022-06-17 16:50:28.958394
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, []))]
    p.push(3, (None, None), 0, None)

# Generated at 2022-06-17 16:50:35.500665
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 0))
    p.addtoken(token.NAME, "g", Context(1, 0))
    p.addtoken(token.NAME, "h", Context(1, 0))

# Generated at 2022-06-17 16:50:43.656755
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:50:53.948988
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Test the parser by parsing a simple arithmetic expression
    # and comparing the result to a hand-built abstract syntax tree.

    # The grammar
    g = grammar.grammar
    # The parser
    p = Parser(g)
    # The tokens
    tokens = [
        (token.NUMBER, "1", (1, 0)),
        (token.PLUS, "+", (1, 2)),
        (token.NUMBER, "2", (1, 4)),
        (token.STAR, "*", (1, 6)),
        (token.NUMBER, "3", (1, 8)),
        (token.ENDMARKER, "", (1, 9)),
    ]
    # The expected abstract syntax tree

# Generated at 2022-06-17 16:51:07.398545
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import os
    import unittest
    from . import driver
    from . import grammar


# Generated at 2022-06-17 16:51:12.945906
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test.py").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:51:26.416553
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar/Grammar")):
        if t[0] == token.ENDMARKER:
            break
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children is not None
    assert len(p.rootnode.children) > 0
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children is not None
    assert len

# Generated at 2022-06-17 16:51:34.028642
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import os
    import unittest
    from . import driver
    from . import grammar
    from . import token

    class ParserTestCase(unittest.TestCase):
        def setUp(self):
            self.p = Parser(grammar.Grammar())
            self.p.setup()

        def test_pop(self):
            self.p.stack = [(None, None, (None, None, None, [])),
                            (None, None, (None, None, None, []))]
            self.p.pop()
            self.assertEqual(self.p.stack, [(None, None, (None, None, None, []))])

# Generated at 2022-06-17 16:51:43.029976
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.classify(token.NAME, "if", None)
    p.classify(token.NAME, "foo", None)
    p.classify(token.NAME, "elif", None)
    p.classify(token.NAME, "else", None)
    p.classify(token.NAME, "while", None)
    p.classify(token.NAME, "for", None)
    p.classify(token.NAME, "try", None)
    p.classify(token.NAME, "except", None)
    p.classify(token.NAME, "finally", None)
    p.classify(token.NAME, "with", None)

# Generated at 2022-06-17 16:51:58.822136
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    driver.driver(p, "1 + 2")
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER
    assert p.rootnode.children[2].value == "2"

# Generated at 2022-06-17 16:52:09.825178
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar


# Generated at 2022-06-17 16:52:19.131772
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()
    p.setup(token.NUMBER)
    assert p.stack == [(g.dfas[token.NUMBER], 0, (token.NUMBER, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-17 16:52:31.127877
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 3))
    p.addtoken(token.EQUAL, "=", Context(1, 5))
    p.addtoken(token.NUMBER, "1", Context(1, 7))
    p.addtoken(token.NEWLINE, "\n", Context(1, 8))
    p.addtoken(token.NAME, "else", Context(2, 0))
    p.addtoken(token.COLON, ":", Context(2, 4))
    p.addtoken(token.NEWLINE, "\n", Context(2, 5))
    p.add

# Generated at 2022-06-17 16:52:41.178193
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Shift a token
    p.shift(token.NAME, "a", 1, (1, 0))

    # Shift another token
    p.shift(token.NAME, "b", 2, (1, 1))

    # Shift a third token
    p.shift(token.NAME, "c", 3, (1, 2))

    # Shift a fourth token
    p.shift(token.NAME, "d", 4, (1, 3))

    # Shift a fifth token
    p.shift(token.NAME, "e", 5, (1, 4))

    # Shift a sixth token

# Generated at 2022-06-17 16:52:55.166099
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 0))
    p.addtoken(token.NAME, "g", Context(1, 0))

# Generated at 2022-06-17 16:53:08.064339
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    g.load_grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NAME, "y", None)
    p.addtoken(token.NEWLINE, "\n", None)
    assert p.rootnode is not None
    assert p.rootnode.type == symbol.stmt
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NAME
    assert p.rootnode.children[1].type == token.EQUAL
    assert p.rootnode.children[2].type

# Generated at 2022-06-17 16:53:19.562210
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import token

    # Load the grammar
    g = grammar.grammar
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.expr("1+2")):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == g.symbol2number["expr"]
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode

# Generated at 2022-06-17 16:53:31.176786
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar
    import sys

    def parse(s: Text) -> None:
        p = Parser(grammar.grammar)
        p.setup()
        for t in driver.tokenize(s):
            if p.addtoken(*t):
                break

    parse("")
    parse("1")
    parse("1+1")
    parse("1+1+1")
    parse("1+1+1+1")
    parse("1+1+1+1+1")
    parse("1+1+1+1+1+1")
    parse("1+1+1+1+1+1+1")
    parse("1+1+1+1+1+1+1+1")

# Generated at 2022-06-17 16:53:43.110647
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            # Test the method addtoken of class Parser
            p = driver.Parser()
            p.setup()
            self.assertFalse(p.addtoken(token.NAME, "x", (1, 0)))
            self.assertFalse(p.addtoken(token.EQUAL, "=", (1, 2)))
            self.assertFalse(p.addtoken(token.NUMBER, "1", (1, 4)))
            self.assertTrue(p.addtoken(token.NEWLINE, "\n", (1, 5)))
            self.assertEqual(p.rootnode.type, symbol.file_input)

# Generated at 2022-06-17 16:54:05.022893
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:54:16.288862
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 3))
    p.addtoken(token.NAME, "y", (1, 5))
    p.addtoken(token.NAME, "z", (1, 7))
    p.addtoken(token.NAME, "else", (1, 9))
    p.addtoken(token.NAME, "x", (1, 14))
    p.addtoken(token.NAME, "y", (1, 16))
    p.addtoken(token.NAME, "z", (1, 18))

# Generated at 2022-06-17 16:54:27.408413
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import token

    g = grammar.Grammar()
    g.load_grammar(g.grammar_file)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]

# Generated at 2022-06-17 16:54:37.472013
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.NAME, "else", None)
    p.addtoken(token.COLON, ":", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.INDENT, "", None)
    p.addtoken(token.NAME, "pass", None)
    p.add

# Generated at 2022-06-17 16:54:51.899758
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    g.start = 257

# Generated at 2022-06-17 16:55:02.597867
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:55:13.324673
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:55:25.205249
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import grammar, tokenize

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            p = Parser(grammar.grammar)
            p.setup()
            t = tokenize.generate_tokens(iter(["x = 1 + 2"]).__next__)
            for token in t:
                if p.addtoken(token.type, token.string, token.start):
                    break
            self.assertEqual(p.rootnode.type, grammar.syms.file_input)
            self.assertEqual(len(p.rootnode.children), 1)
            self.assertEqual(p.rootnode.children[0].type, grammar.syms.stmt)

# Generated at 2022-06-17 16:55:35.328038
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar

    grammar = Grammar(
        """
        start: a b
        a: 'a'
        b: 'b'
        """
    )
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NAME, "a", None)
    parser.addtoken(token.NAME, "b", None)
    assert parser.rootnode.type == "start"
    assert parser.rootnode.children[0].type == "a"
    assert parser.rootnode.children[1].type == "b"

# Generated at 2022-06-17 16:55:43.081492
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    # Test that the parser can handle a simple program
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for type, value, context in tokenize.generate_tokens(
        "x = 1 + 2\n",
        "<string>",
        tokenize.detect_encoding,
        tokenize.Untokenizer,
    ):
        if p.addtoken(type, value, context):
            break
    assert p.rootnode is not None
    assert p.rootnode[0] == "file_input"
    assert p.rootnode[1] is None
    assert p.rootnode[2] is None
    assert len(p.rootnode[3]) == 2

# Generated at 2022-06-17 16:56:18.928873
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)

# Generated at 2022-06-17 16:56:30.469024
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.push(g.symbol2number["file_input"], g.dfas[g.symbol2number["file_input"]], 0, None)
    assert p.stack == [(g.dfas[g.symbol2number["file_input"]], 0, (257, None, None, []))]
    p.push(g.symbol2number["stmt"], g.dfas[g.symbol2number["stmt"]], 0, None)

# Generated at 2022-06-17 16:56:33.892593
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None

# Generated at 2022-06-17 16:56:45.196400
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)
    p.setup()

    # Set up a stack
    p.stack = [
        (
            ([[(0, 0)], [(0, 0)]], {0: 0}),
            0,
            (1, None, None, [2, 3]),
        ),
        (
            ([[(0, 0)], [(0, 0)]], {0: 0}),
            0,
            (2, None, None, [4, 5]),
        ),
        (
            ([[(0, 0)], [(0, 0)]], {0: 0}),
            0,
            (3, None, None, [6, 7]),
        ),
    ]

    # Pop a nonterminal

# Generated at 2022-06-17 16:56:56.792749
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in driver.tokenize("1 + 2"):
        p.addtoken(t.type, t.string, t.start)
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[1].value == "+"
    assert p

# Generated at 2022-06-17 16:57:09.381801
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, token

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"

# Generated at 2022-06-17 16:57:21.634371
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:57:29.252862
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Create a parser instance
    g = grammar.grammar
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Tokenize a simple expression
    tokens = tokenize.generate_tokens("1 + 2")

    # Parse the tokens
    for type, value, context in tokens:
        if p.addtoken(type, value, context):
            break

    # Check the result
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    stmt = p.rootnode.children[0]
    assert stmt.type == g.symbol2number["stmt"]
    assert len(stmt.children) == 1
    simple_stmt = stmt

# Generated at 2022-06-17 16:57:39.434174
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:57:50.508884
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Create a parser
    p = Parser(grammar)

    # Prepare for parsing
    p.setup()

    # Tokenize a string
    g = tokenize.generate_tokens("x = 1")

    # Feed the tokens to the parser
    for type, value, context in g:
        if p.addtoken(type, value, context):
            break

    # Get the root of the abstract syntax tree
    root = p.rootnode

    # Print the root node
    print(root)

# Generated at 2022-06-17 16:59:02.881992
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Parse a simple program
    p.addtoken(token.NAME, "print", None)
    p.addtoken(token.LPAR, "(", None)
    p.addtoken(token.STRING, "Hello, world!", None)
    p.addtoken(token.RPAR, ")", None)
    p.addtoken(token.NEWLINE, "\n", None)
    assert p.rootnode is not None

    # Parse a program with an error
    p.setup()
    p.addtoken(token.NAME, "print", None)
    p.addtoken(token.LPAR, "(", None)

# Generated at 2022-06-17 16:59:10.777018
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "foo", 1, None)
    assert p.stack == [(g.dfas[g.start], 1, (g.start, None, None, [1]))]
    p.shift(2, "bar", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [1, 2]))]
    p.shift(3, "baz", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [1, 2, 3]))]


# Generated at 2022-06-17 16:59:17.996037
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:59:28.065429
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            p = driver.Parser()
            p.setup()
            p.addtoken(token.NAME, "foo", (1, 0))
            p.addtoken(token.NAME, "bar", (1, 0))
            p.addtoken(token.NAME, "baz", (1, 0))
            p.addtoken(token.NAME, "quux", (1, 0))
            p.addtoken(token.NAME, "spam", (1, 0))
            p.addtoken(token.NAME, "eggs", (1, 0))
            p.addtoken(token.NAME, "ham", (1, 0))

# Generated at 2022-06-17 16:59:38.275361
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(driver.NAME, "print", (1, 0))
    p.addtoken(driver.OP, "(", (1, 5))
    p.addtoken(driver.STRING, '"Hello, world!"', (1, 6))
    p.addtoken(driver.OP, ")", (1, 21))
    p.addtoken(driver.NEWLINE, "\n", (1, 22))
    p.addtoken(driver.ENDMARKER, "", (2, 0))
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1

# Generated at 2022-06-17 16:59:52.290628
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "def", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 4))
    p.addtoken(token.OP, "(", Context(1, 5))
    p.addtoken(token.NAME, "x", Context(1, 6))
    p.addtoken(token.OP, ")", Context(1, 7))
    p.addtoken(token.OP, ":", Context(1, 8))
    p.addtoken(token.NEWLINE, "\n", Context(1, 9))
    p.addtoken(token.INDENT, "", Context(2, 0))

# Generated at 2022-06-17 17:00:01.346872
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    # Create a parser
    p = driver.Parser()

    # Prepare for parsing
    p.setup()

    # Parse a token
    p.addtoken(token.NAME, "a", (1, 0))

    # Parse another token
    p.addtoken(token.NAME, "b", (1, 0))

    # Parse a third token
    p.addtoken(token.NAME, "c", (1, 0))

    # Get the root node
    root = p.rootnode

    # Check the root node
    assert root.type == symbol.file_input