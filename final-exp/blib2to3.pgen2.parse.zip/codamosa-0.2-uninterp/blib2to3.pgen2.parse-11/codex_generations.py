

# Generated at 2022-06-17 16:50:15.795047
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)
   

# Generated at 2022-06-17 16:50:21.361767
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 0))
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))
    p.addtoken(token.NAME, "else", (1, 0))
    p.addtoken(token.COLON, ":", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))

# Generated at 2022-06-17 16:50:30.724142
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, []))]
    p.push(3, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, [])), (None, 0, (3, None, None, []))]
    p.pop()


# Generated at 2022-06-17 16:50:36.720150
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:50:51.260917
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    assert p.rootnode.children == [
        Leaf(token.NUMBER, "1", (1, 0)),
        Leaf(token.PLUS, "+", (1, 2)),
        Leaf(token.NUMBER, "2", (1, 4)),
        Leaf(token.NEWLINE, "\n", (1, 5)),
    ]




# Generated at 2022-06-17 16:51:03.615918
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.classify(token.NAME, "if", None) == g.keywords["if"]
    assert p.classify(token.NAME, "and", None) == g.keywords["and"]
    assert p.classify(token.NAME, "foo", None) == g.tokens[token.NAME]
    assert p.classify(token.PLUS, "+", None) == g.tokens[token.PLUS]
    assert p.classify(token.MINUS, "-", None) == g.tokens[token.MINUS]
    assert p.classify(token.STAR, "*", None) == g.tokens[token.STAR]
    assert p.classify

# Generated at 2022-06-17 16:51:12.421073
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    g = grammar.Grammar()
    g.parse_grammar(driver.grammar)
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("../../../Lib/test/regrtest.py")):
        if t[0] == token.ENDMARKER:
            break
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode is not None

# Generated at 2022-06-17 16:51:25.488346
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", (("stmt",),))
    g.add_nonterminal("stmt", (("simple_stmt",),))
    g.add_nonterminal("simple_stmt", (("small_stmt",),))
    g.add_nonterminal("small_stmt", (("expr_stmt",),))
    g.add_nonterminal("expr_stmt", (("testlist",),))
    g.add_nonterminal("testlist", (("test",),))
    g.add_nonterminal("test", (("or_test",),))

# Generated at 2022-06-17 16:51:37.247552
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 0))
    p.addtoken(token.NAME, "g", Context(1, 0))
    p.addtoken(token.NAME, "h", Context(1, 0))
    p

# Generated at 2022-06-17 16:51:45.278475
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", driver.FileInput("<test>").get_token().context)
    p.addtoken(token.NAME, "b", driver.FileInput("<test>").get_token().context)
    p.addtoken(token.NAME, "c", driver.FileInput("<test>").get_token().context)
    p.addtoken(token.NAME, "d", driver.FileInput("<test>").get_token().context)
    p.addtoken(token.NAME, "e", driver.FileInput("<test>").get_token().context)

# Generated at 2022-06-17 16:51:54.504926
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 3))
    p.addtoken(token.COLON, ":", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(token.INDENT, "", (2, 0))
    p.addtoken(token.NAME, "pass", (2, 4))
    p.addtoken(token.NEWLINE, "\n", (2, 8))
    p.addtoken(token.DEDENT, "", (3, 0))

# Generated at 2022-06-17 16:52:05.947066
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:52:15.469291
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"

# Generated at 2022-06-17 16:52:22.629449
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    g.load_grammar(grammar.DEFAULT_GRAMMAR)
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["simple_stmt"]

# Generated at 2022-06-17 16:52:32.246816
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test/test_grammar.py")):
        if p.addtoken(t.type, t.string, t.start):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]

# Generated at 2022-06-17 16:52:41.608573
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 2, None)
    assert p.stack == [(None, 2, (1, None, None, []))]
    p.push(2, (None, None), 3, None)
    assert p.stack == [(None, 2, (1, None, None, [])), (None, 3, (2, None, None, []))]
    p.push(3, (None, None), 4, None)
    assert p.stack == [(None, 2, (1, None, None, [])), (None, 3, (2, None, None, [])),
                       (None, 4, (3, None, None, []))]

# Unit test

# Generated at 2022-06-17 16:52:55.453873
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Test method addtoken of class Parser."""
    import sys
    from . import driver
    from . import tokenize
    from . import grammar

    # Parse a simple expression
    g = grammar.Grammar()
    g.parse_grammar(sys.stdin)
    p = Parser(g)
    p.setup()
    d = driver.Driver(p.addtoken, g)
    d.set_parser_debug(True)
    d.set_driver_debug(True)
    d.driver()
    # Test tokenizing a string
    p.setup()
    d.set_parser_debug(False)
    d.set_driver_debug(False)
    d.tokenize(tokenize.generate_tokens("1 + 2"))
    # Test tokenizing a file
    p.setup

# Generated at 2022-06-17 16:53:08.384267
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    p.push(2, (None, None), 0, None)
    p.push(3, (None, None), 0, None)
    assert len(p.stack) == 4
    assert p.stack[0] == (None, 0, (0, None, None, []))
    assert p.stack[1] == (None, 0, (1, None, None, []))
    assert p.stack[2] == (None, 0, (2, None, None, []))
    assert p.stack[3] == (None, 0, (3, None, None, []))
    p.pop()

# Generated at 2022-06-17 16:53:19.787839
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse some input
    driver.parse_tokens(p, tokenize.generate_tokens(open("Grammar/Grammar").readline))
    # Get the result
    r = p.rootnode
    # Check the result
    assert r[0] == g.symbol2number["file_input"]
    assert len(r) == 1
    s = r[0]
    assert s[0] == token.NEWLINE
    assert s[1] == "\n"
    assert s[2] == (1, 0)

# Generated at 2022-06-17 16:53:31.339436
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import driver
    from . import tokenize
    import io
    import sys

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    # Parse a simple expression
    p.setup()
    f = io.StringIO("1 + 2")
    t = tokenize.generate_tokens(f.readline)
    for type, value, start, end, line in t:
        p.addtoken(type, value, (start, end))
    # Check the result
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    stmt = p.rootnode.children[0]
    assert stmt.type == g.symbol2number["stmt"]

# Generated at 2022-06-17 16:53:44.949680
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (1, None, None, []))]

# Generated at 2022-06-17 16:53:50.536757
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [("a", None, None, None)]))]

# Generated at 2022-06-17 16:53:56.330695
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, (1, 2))
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(1, "a")]))]

# Generated at 2022-06-17 16:54:06.608174
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number

# Generated at 2022-06-17 16:54:14.163417
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    p.shift(1, "b", 3, None)
    p.shift(1, "c", 4, None)
    assert p.stack == [(g.dfas[g.start], 4, (g.start, None, None, [1, 1, 1]))]


# Generated at 2022-06-17 16:54:25.185667
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 0))
    p.addtoken(token.NUMBER, "42", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))
    p.addtoken(token.ENDMARKER, "", (1, 0))
    assert p.rootnode is not None

# Generated at 2022-06-17 16:54:33.548361
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 0, None)
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, [1, "a", None, None]))]
    p.shift(2, "b", 0, None)
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, [1, "a", None, None]))]
    assert p.rootnode is None


# Generated at 2022-06-17 16:54:41.612042
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "def", (1, 0))
    p.addtoken(token.NAME, "f", (1, 4))
    p.addtoken(token.OP, "(", (1, 5))
    p.addtoken(token.OP, ")", (1, 6))
    p.addtoken(token.OP, ":", (1, 7))
    p.addtoken(token.NEWLINE, "\n", (1, 8))
    p.addtoken(token.INDENT, "    ", (2, 0))
    p.addtoken(token.NAME, "return", (2, 4))
    p.addtoken(token.NAME, "None", (2, 11))

# Generated at 2022-06-17 16:54:53.321807
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    # Create a parser
    p = Parser(grammar.grammar)
    p.setup()

    # Tokenize a string
    s = "x = 1 + 2"
    g = tokenize.generate_tokens(s)
    for type, value, context in g:
        p.addtoken(type, value, context)

    # Check the result
    assert p.rootnode.type == grammar.syms.file_input
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == grammar.syms.stmt
    assert len(p.rootnode.children[0].children) == 1
    assert p.rootnode.children[0].children[0].type == grammar.syms.simple_stmt

# Generated at 2022-06-17 16:55:05.360039
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    g.load_file("Grammar/Grammar")
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "print", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 6))
    p.addtoken(token.NEWLINE, "\n", Context(1, 7))
    assert p.rootnode.type == symbol.file_input
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == symbol.stmt
    assert len(p.rootnode.children[0].children) == 1
    assert p.rootnode.children[0].children[0].type == token.NAME
    assert p.root

# Generated at 2022-06-17 16:55:25.374442
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    tok = tokenize.generate_tokens(iter(["x", "y", "z"]).__next__)
    for t in tok:
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode.children == [
        Leaf(type=token.NAME, value="x", context=None),
        Leaf(type=token.NAME, value="y", context=None),
        Leaf(type=token.NAME, value="z", context=None),
    ]

# Generated at 2022-06-17 16:55:36.501069
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(token.NAME, "foo", 1, (1, 0))
    assert p.stack == [(g.dfas[g.start], 1, (g.start, None, None, [("foo", 1, 0)]))]
    p.shift(token.NAME, "bar", 2, (1, 3))
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [("foo", 1, 0), ("bar", 2, 3)]))]


# Generated at 2022-06-17 16:55:51.091408
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "def", (1, 0))
    p.addtoken(token.NAME, "f", (1, 4))
    p.addtoken(token.OP, "(", (1, 5))
    p.addtoken(token.OP, ")", (1, 6))
    p.addtoken(token.OP, ":", (1, 7))
    p.addtoken(token.NEWLINE, "\n", (1, 8))
    p.addtoken(token.INDENT, "", (2, 0))
    p.addtoken(token.NAME, "return", (2, 4))
    p.addtoken(token.NAME, "None", (2, 11))


# Generated at 2022-06-17 16:56:03.995323
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    # Create a parser
    p = Parser(grammar.grammar)

    # Test the parser on a simple expression
    p.setup()
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(*t):
            break
    assert p.rootnode.type == grammar.syms.expr
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER
    assert p.rootnode.children[2].value == "2"

    # Test the parser on a simple assignment
    p.setup

# Generated at 2022-06-17 16:56:17.279109
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:56:29.345688
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, []))]
    p.push(3, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, [])), (None, 0, (3, None, None, []))]
    p.pop()


# Generated at 2022-06-17 16:56:31.978467
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, 2, 3, 4)
    assert p.stack == [(2, 0, (1, None, 4, []))]

# Generated at 2022-06-17 16:56:44.285388
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pytree import Leaf, Node
    import io
    import sys
    import unittest


# Generated at 2022-06-17 16:56:53.850804
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.NAME, "y", (1, 0))
    p.addtoken(token.NAME, "z", (1, 0))
    p.addtoken(token.NAME, "elif", (1, 0))
    p.addtoken(token.NAME, "else", (1, 0))
    p.addtoken(token.NAME, "while", (1, 0))
    p.addtoken(token.NAME, "for", (1, 0))

# Generated at 2022-06-17 16:57:01.895905
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token
    from . import pgen2
    from . import pytree
    from . import pygram
    from . import pytoken

    g = grammar.Grammar(pgen2.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "print", (1, 0))
    p.addtoken(token.LPAR, "(", (1, 5))
    p.addtoken(token.STRING, "Hello, world!", (1, 6))
    p.addtoken(token.RPAR, ")", (1, 21))
    p.addtoken(token.NEWLINE, "\n", (1, 22))

# Generated at 2022-06-17 16:57:22.676420
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    import io

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    f = io.StringIO("x = 1")
    t = tokenize.generate_tokens(f.readline)
    for type, value, start, end, line in t:
        if p.addtoken(type, value, (start, end, line)):
            break
    assert p.rootnode.children[0].children[0].value == "x"
    assert p.rootnode.children[0].children[1].value == "="
    assert p.rootnode.children[0].children[2].value == "1"

# Generated at 2022-06-17 16:57:29.926452
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "print", Context(1, 0))
    p.addtoken(token.LPAR, "(", Context(1, 0))
    p.addtoken(token.STRING, "Hello, world!", Context(1, 0))
    p.addtoken(token.RPAR, ")", Context(1, 0))
    p.addtoken(token.NEWLINE, "\n", Context(1, 0))
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1

# Generated at 2022-06-17 16:57:39.400431
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (1, 2), 3, 4)
    assert p.stack == [(1, 2), (1, 2, 3, 4)]
    p.push(5, (5, 6), 7, 8)
    assert p.stack == [(1, 2), (1, 2, 3, 4), (5, 6), (5, 6, 7, 8)]
    p.pop()
    assert p.stack == [(1, 2), (1, 2, 3, 4)]
    p.pop()
    assert p.stack == [(1, 2)]
    p.pop()
    assert p.stack == []


# Generated at 2022-06-17 16:57:52.942187
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:58:03.757254
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pytree import Leaf, Node
    from blib2to3.pgen2.token import Token
    from blib2to3.pgen2.driver import Driver
    from io import StringIO
    from typing import List, Tuple, Dict, Text

    def lam_sub(grammar: Grammar, node: Tuple[int, Optional[Text], Context, List[Any]]) -> Union[Node, Leaf]:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])


# Generated at 2022-06-17 16:58:10.752678
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar, driver.convert)
    # Parse a simple expression
    p.setup()
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(*t):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER
    assert p.rootnode.children[2].value == "2"

# Generated at 2022-06-17 16:58:22.775573
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 0))
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))
    p.addtoken(token.NAME, "print", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))

# Generated at 2022-06-17 16:58:34.961156
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, token

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)

# Generated at 2022-06-17 16:58:44.937991
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Create a parser
    p = Parser(grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[1].value == "+"
    assert p.rootnode

# Generated at 2022-06-17 16:58:51.071405
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(1, "a")]))]
    p.shift(2, "b", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [Leaf(1, "a"), Leaf(2, "b")]))]
    p.shift(3, "c", 4, None)

# Generated at 2022-06-17 16:59:32.096199
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("NEWLINE", "NEWLINE"), "file_input", ("ENDMARKER", "ENDMARKER")])
    g.add_nonterminal("file_input", [])
    g.add_nonterminal("file_input", [("stmt", "stmt"), "file_input"])
    g.add_nonterminal("stmt", [("simple_stmt", "simple_stmt")])
    g.add_nonterminal("simple_stmt", [("small_stmt", "small_stmt"), ("NEWLINE", "NEWLINE")])

# Generated at 2022-06-17 16:59:41.068271
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    g.start = "file_input"

# Generated at 2022-06-17 16:59:50.736794
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)
   

# Generated at 2022-06-17 17:00:00.051880
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))