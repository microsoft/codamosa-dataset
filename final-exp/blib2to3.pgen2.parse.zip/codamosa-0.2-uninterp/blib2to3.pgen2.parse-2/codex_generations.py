

# Generated at 2022-06-17 16:50:18.181988
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test_Parser_shift.py").readline):
        p.addtoken(t.type, t.string, t.start)
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["simple_stmt"]

# Generated at 2022-06-17 16:50:22.919987
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    import blib2to3.pgen2.token as token
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.parse as parse

    class TestParser(unittest.TestCase):

        def test_addtoken(self):
            g = grammar.grammar
            p = parse.Parser(g)
            p.setup()
            self.assertFalse(p.addtoken(token.NAME, "a", (1, 0)))
            self.assertFalse(p.addtoken(token.NAME, "b", (1, 0)))
            self.assertFalse(p.addtoken(token.NAME, "c", (1, 0)))
            self.assertTrue(p.addtoken(token.NAME, "d", (1, 0)))

   

# Generated at 2022-06-17 16:50:31.419902
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Test classify
    assert p.classify(token.NAME, "if", None) == g.keywords["if"]
    assert p.classify(token.NAME, "foo", None) == g.tokens[token.NAME]
    assert p.classify(token.NUMBER, "42", None) == g.tokens[token.NUMBER]
    assert p.classify(token.STRING, "foo", None) == g.tokens[token.STRING]
    assert p.classify(token.NEWLINE, "\n", None) == g.tokens[token.NEWLINE]

# Generated at 2022-06-17 16:50:37.214136
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:50:51.330984
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "print", (1, 0))
    p.addtoken(token.OP, "(", (1, 5))
    p.addtoken(token.STRING, "Hello, world!", (1, 6))
    p.addtoken(token.OP, ")", (1, 21))
    p.addtoken(token.NEWLINE, "\n", (1, 22))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]

# Generated at 2022-06-17 16:50:54.291955
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [1, "a"]))]



# Generated at 2022-06-17 16:51:07.733443
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test/test_grammar.py")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == token.NAME
    assert p.rootnode.children[0].children[0].value == "print"
    assert p.rootnode.children[0].children[1].type

# Generated at 2022-06-17 16:51:13.981094
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    g.load_grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar/Grammar")):
        if t.type == token.ENDMARKER:
            break
        p.addtoken(t.type, t.string, t.start)
    assert p.rootnode is not None

# Generated at 2022-06-17 16:51:27.327785
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(token.NAME, "a", 0, None)
    p.shift(token.NAME, "b", 0, None)
    p.shift(token.NAME, "c", 0, None)
    p.shift(token.NAME, "d", 0, None)
    p.shift(token.NAME, "e", 0, None)
    p.shift(token.NAME, "f", 0, None)
    p.shift(token.NAME, "g", 0, None)
    p.shift(token.NAME, "h", 0, None)
    p.shift(token.NAME, "i", 0, None)

# Generated at 2022-06-17 16:51:34.054815
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar
    from . import tokenize
    import io

    # Test the parser by parsing a simple expression
    text = "1 + 2"
    tokens = tokenize.generate_tokens(io.StringIO(text).readline)
    p = Parser(grammar.expr_grammar)
    p.setup()
    for type, value, context in tokens:
        if p.addtoken(type, value, context):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == grammar.expr_grammar.symbol2number["expr"]
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[1].type == token.PLUS

# Generated at 2022-06-17 16:51:49.938398
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a token
    p.shift(token.NAME, "a", 0, (0, 0))

    # Check the result
    assert p.stack == [(grammar.grammar.dfas[grammar.grammar.start], 0, (1, None, None, [Leaf(1, 'a', (0, 0))]))]



# Generated at 2022-06-17 16:52:01.322218
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()

    p.setup(g.symbol2number["funcdef"])
    assert p.stack == [(g.dfas[g.symbol2number["funcdef"]], 0, (
        g.symbol2number["funcdef"], None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()

    p.setup()

# Generated at 2022-06-17 16:52:06.799506
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Load the grammar
    g = grammar.grammar

    # Create a parser
    p = Parser(g)

    # Parse a simple expression
    p.setup()
    for t in tokenize.generate_tokens("1+2"):
        if p.addtoken(*t):
            break

    # Check the result
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    stmt = p.rootnode.children[0]
    assert stmt.type == g.symbol2number["stmt"]
    assert len(stmt.children) == 1
    expr = stmt.children[0]
    assert expr.type == g.symbol2number["expr"]

# Generated at 2022-06-17 16:52:16.002294
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "def", (1, 0))
    p.addtoken(token.NAME, "f", (1, 4))
    p.addtoken(token.OP, "(", (1, 5))
    p.addtoken(token.OP, ")", (1, 6))
    p.addtoken(token.OP, ":", (1, 7))
    p.addtoken(token.NEWLINE, "\n", (1, 8))
    p.addtoken(token.INDENT, "\t", (2, 0))
    p.addtoken(token.NAME, "return", (2, 1))

# Generated at 2022-06-17 16:52:19.721328
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()



# Generated at 2022-06-17 16:52:27.261813
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)
    p

# Generated at 2022-06-17 16:52:33.684790
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-17 16:52:39.809247
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.push(g.symbol2number["file_input"], g.dfas[g.symbol2number["file_input"]], 0, None)
    assert p.stack == [(g.dfas[g.symbol2number["file_input"]], 0, (257, None, None, []))]

# Generated at 2022-06-17 16:52:49.776747
# Unit test for method setup of class Parser
def test_Parser_setup():
    import unittest
    from . import grammar

    class TestParser(unittest.TestCase):
        def test_setup(self):
            p = Parser(grammar)
            p.setup()
            self.assertEqual(p.stack, [(p.grammar.dfas[p.grammar.start], 0, (1, None, None, []))])
            self.assertEqual(p.rootnode, None)

    unittest.main()


# Generated at 2022-06-17 16:53:02.519861
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 3))
    p.addtoken(token.EQUAL, "=", Context(1, 5))
    p.addtoken(token.NUMBER, "1", Context(1, 7))
    p.addtoken(token.NEWLINE, "\n", Context(1, 8))
    p.addtoken(token.NAME, "else", Context(2, 0))
    p.addtoken(token.COLON, ":", Context(2, 4))
    p.addtoken(token.NEWLINE, "\n", Context(2, 5))
    p.add

# Generated at 2022-06-17 16:53:21.411076
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:53:32.532080
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)
   

# Generated at 2022-06-17 16:53:41.694931
# Unit test for method setup of class Parser
def test_Parser_setup():
    import unittest
    from . import grammar

    class TestParser(unittest.TestCase):
        def test_setup(self):
            p = Parser(grammar.Grammar())
            p.setup()
            self.assertEqual(p.stack, [(p.grammar.dfas[p.grammar.start], 0, (1, None, None, []))])
            self.assertEqual(p.rootnode, None)
            self.assertEqual(p.used_names, set())

    unittest.main()

# Generated at 2022-06-17 16:53:51.404750
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [("a", None, None, None)]))]
    p.shift(1, "b", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [("a", None, None, None), ("b", None, None, None)]))]


# Generated at 2022-06-17 16:54:02.655899
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver, token, grammar

    class ParserTest(unittest.TestCase):
        def test_addtoken(self):
            g = grammar.Grammar()
            p = Parser(g)
            p.setup()
            p.addtoken(token.NAME, "a", (1, 0))
            p.addtoken(token.NAME, "b", (1, 0))
            p.addtoken(token.NAME, "c", (1, 0))
            p.addtoken(token.NAME, "d", (1, 0))
            p.addtoken(token.NAME, "e", (1, 0))
            p.addtoken(token.NAME, "f", (1, 0))
            p.addtoken(token.NAME, "g", (1, 0))
           

# Generated at 2022-06-17 16:54:14.416763
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Parse a simple expression
    p.setup()
    for t in tokenize.generate_tokens(driver.expr("1+2")):
        p.addtoken(t[0], t[1], t[2])

    # Check the result
    assert p.rootnode.type == g.symbol2number["expr"]
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children

# Generated at 2022-06-17 16:54:27.210804
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:54:32.028791
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()



# Generated at 2022-06-17 16:54:37.719892
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.StringIO("1+2").readline):
        if p.addtoken(t.type, t.string, t.start):
            break

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token

# Generated at 2022-06-17 16:54:50.790237
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    p = Parser(grammar)
    p.setup()
    p.shift(1, "a", 0, None)
    assert p.stack[0][2][3] == [Leaf(1, "a")]
    p.shift(1, "b", 0, None)
    assert p.stack[0][2][3] == [Leaf(1, "a"), Leaf(1, "b")]
    p.shift(1, "c", 0, None)
    assert p.stack[0][2][3] == [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")]


# Generated at 2022-06-17 16:55:10.539546
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 0))
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))
    p.addtoken(token.NAME, "else", (1, 0))
    p.addtoken(token.COLON, ":", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))

# Generated at 2022-06-17 16:55:22.250924
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.addtoken(token.NUMBER, "1", None)
    assert p.addtoken(token.PLUS, "+", None)
    assert p.addtoken(token.NUMBER, "2", None)
    assert p.addtoken(token.ENDMARKER, "", None)
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["testlist"]
    assert len(p.rootnode.children[0].children) == 3

# Generated at 2022-06-17 16:55:29.990103
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            from . import grammar, token

            # Create a parser
            p = Parser(grammar)

            # Prepare for parsing
            p.setup()

            # Parse a simple expression
            p.addtoken(token.NUMBER, "1", (1, 0))
            p.addtoken(token.PLUS, "+", (1, 2))
            p.addtoken(token.NUMBER, "2", (1, 4))
            p.addtoken(token.NEWLINE, "\n", (1, 5))
            p.addtoken(token.ENDMARKER, "", (2, 0))

            # Check the result

# Generated at 2022-06-17 16:55:39.834188
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.shift(token.NAME, "a", 1, None)
    assert p.stack == [(g.dfas[g.start], 1, (g.start, None, None, [Leaf(token.NAME, "a")]))]
    p.shift(token.NAME, "b", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")]))]


# Generated at 2022-06-17 16:55:52.084852
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", Context(1, 0))
    p.addtoken(token.PLUS, "+", Context(1, 2))
    p.addtoken(token.NUMBER, "2", Context(1, 4))
    p.addtoken(token.NEWLINE, "\n", Context(1, 6))
    p.addtoken(token.ENDMARKER, "", Context(1, 7))

# Generated at 2022-06-17 16:56:05.021962
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver
    import io
    import sys

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(io.StringIO("1+2").readline):
        p.addtoken(t.type, t.string, t.start)
    # Get the abstract syntax tree
    ast = p.rootnode
    # Print the abstract syntax tree
    driver.tostring(ast)
    # Print the abstract syntax tree
    driver.todot(ast)
    # Print the abstract syntax tree
    driver.todot(ast, True)
    # Print the abstract syntax tree

# Generated at 2022-06-17 16:56:17.904450
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    g.start = 256

# Generated at 2022-06-17 16:56:29.915994
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.classify(token.NAME, "foo", None)
    p.classify(token.NAME, "None", None)
    p.classify(token.NAME, "True", None)
    p.classify(token.NAME, "False", None)
    p.classify(token.NAME, "and", None)
    p.classify(token.NAME, "or", None)
    p.classify(token.NAME, "not", None)
    p.classify(token.NAME, "is", None)
    p.classify(token.NAME, "in", None)
    p.classify(token.NAME, "lambda", None)

# Generated at 2022-06-17 16:56:37.105275
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in driver.tokenize_file(open("Grammar/Grammar")):
        if p.addtoken(t.type, t.string, t.context):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:56:51.348583
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "def", Context(0, 0))
    p.addtoken(token.NAME, "f", Context(0, 0))
    p.addtoken(token.OP, "(", Context(0, 0))
    p.addtoken(token.OP, ")", Context(0, 0))
    p.addtoken(token.OP, ":", Context(0, 0))
    p.addtoken(token.NEWLINE, "\n", Context(0, 0))
    p.addtoken(token.INDENT, "  ", Context(0, 0))
    p.addtoken(token.NAME, "return", Context(0, 0))

# Generated at 2022-06-17 16:57:05.742151
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    def convert(grammar, node):
        return node

    p = Parser(grammar.grammar, convert)
    p.setup()
    for type, value, start, end, line in tokenize.generate_tokens(open("test.py")):
        p.addtoken(type, value, (start, end))
    assert p.rootnode is not None

# Generated at 2022-06-17 16:57:18.437118
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Test the parser by parsing a simple expression
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode.type == g.symbol2number["expr"]
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER
    assert p.rootnode.children[2].value == "2"

# Generated at 2022-06-17 16:57:27.244885
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    g.symbol2number = {'a': 1, 'b': 2, 'c': 3}
    g.number2symbol = {1: 'a', 2: 'b', 3: 'c'}
    g.start = 1
    g.dfas = {
        1: ([[(1, 2), (2, 3)], [(3, 4)]], {1: 1, 2: 1, 3: 1, 4: 1}),
        2: ([[(1, 5), (2, 6)], [(3, 7)]], {5: 1, 6: 1, 7: 1}),
        3: ([[(1, 8), (2, 9)], [(3, 10)]], {8: 1, 9: 1, 10: 1}),
    }

# Generated at 2022-06-17 16:57:38.361823
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()

    # Test that the parser is in the right state
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None

    # Test that the parser can be reset
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None

    # Test that the parser can be reset to a different start symbol
    p.setup(g.symbol2number["file_input"])

# Generated at 2022-06-17 16:57:52.521749
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    stmt = p.rootnode.children[0]
    assert stmt.type == g.symbol2number["stmt"]
    assert len(stmt.children) == 1
    expr = stmt.children[0]

# Generated at 2022-06-17 16:58:03.321652
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, 2, 3, 4)
    assert p.stack == [(2, 0, (1, None, 4, []))]
    p.push(5, 6, 7, 8)
    assert p.stack == [(2, 0, (1, None, 4, [])), (6, 0, (5, None, 8, []))]
    p.pop()
    assert p.stack == [(2, 0, (1, None, 4, [(5, None, 8, [])]))]
    p.pop()
    assert p.stack == []
    assert p.rootnode == (1, None, 4, [(5, None, 8, [])])



# Generated at 2022-06-17 16:58:10.555769
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.grammar import Grammar


# Generated at 2022-06-17 16:58:18.239187
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.tokenize import generate_tokens
    from io import StringIO
    from blib2to3.pytree import Leaf, Node
    from blib2to3.pgen2.pgen import driver

    grammar = Grammar(StringIO(driver.grammar))
    parser = Parser(grammar)
    parser.setup()
    for type, value, context in generate_tokens(StringIO("a = 1").readline):
        parser.addtoken(type, value, context)

# Generated at 2022-06-17 16:58:29.909573
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[1].value == "+"

# Generated at 2022-06-17 16:58:42.116182
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    # Add a token
    p.addtoken(token.NAME, "x", (1, 0))
    # Pop a nonterminal
    p.pop()
    # Add a token
    p.addtoken(token.NAME, "y", (1, 0))
    # Pop a nonterminal
    p.pop()
    # Add a token
    p.addtoken(token.NAME, "z", (1, 0))
    # Pop a nonterminal
    p.pop()
    # Add a token
    p.addtoken(token.NAME, "a", (1, 0))
    # Pop a nonterminal
   

# Generated at 2022-06-17 16:58:55.201406
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse a token sequence
    tokens = driver.tokenize("a = 1 + 2")
    for type, value, context in tokens:
        if p.addtoken(type, value, context):
            break
    # Get the root of the abstract syntax tree
    root = p.rootnode
    # Print the abstract syntax tree
    print(root)

# Generated at 2022-06-17 16:59:06.682407
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    from . import grammar
    from . import token

    # Test setup()
    p = Parser(grammar.grammar)
    p.setup()
    p.setup(grammar.grammar.start)
    p.setup(token.NAME)
    p.setup(token.NUMBER)
    p.setup(token.STRING)
    p.setup(token.NEWLINE)
    p.setup(token.INDENT)
    p.setup(token.DEDENT)
    p.setup(token.LPAR)
    p.setup(token.RPAR)
    p.setup(token.LSQB)
    p.setup(token.RSQB)
    p.setup(token.COLON)
    p.setup(token.COMMA)

# Generated at 2022-06-17 16:59:15.174577
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        p.addtoken(t.type, t.string, t.start)
    # Get the abstract syntax tree
    ast = p.rootnode
    # Print it
    driver.tostring(ast)

# Generated at 2022-06-17 16:59:25.797220
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p

# Generated at 2022-06-17 16:59:37.616699
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    # Test setup()
    p = Parser(grammar.grammar)
    p.setup()
    assert p.stack == [(grammar.grammar.dfas[grammar.grammar.start], 0, (1, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()

    # Test setup() with an alternative start symbol
    p = Parser(grammar.grammar)
    p.setup(grammar.sym.file_input)
    assert p.stack == [(grammar.grammar.dfas[grammar.sym.file_input], 0, (1, None, None, []))]
    assert p.rootnode is None
    assert p.used_

# Generated at 2022-06-17 16:59:48.374204
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", Context(1, 0))
    assert p.rootnode.children[0].value == "foo"
    p.addtoken(token.NAME, "bar", Context(1, 0))
    assert p.rootnode.children[0].value == "foo"
    assert p.rootnode.children[1].value == "bar"

# Generated at 2022-06-17 16:59:53.811554
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        if t.type == token.ENDMARKER:
            break
        p.addtoken(t.type, t.string, t.start)

# Generated at 2022-06-17 17:00:02.185254
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)