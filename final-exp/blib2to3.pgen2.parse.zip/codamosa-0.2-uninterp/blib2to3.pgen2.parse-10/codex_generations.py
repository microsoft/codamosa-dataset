

# Generated at 2022-06-17 16:50:15.692429
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.NEWLINE, "\n", None)
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1

# Generated at 2022-06-17 16:50:27.247246
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver

    g = driver.load_grammar("Grammar.txt")
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))
   

# Generated at 2022-06-17 16:50:34.372751
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 0))
    p.addtoken(token.NAME, "g", Context(1, 0))
    p.addtoken(token.NAME, "h", Context(1, 0))
   

# Generated at 2022-06-17 16:50:43.525229
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import token
    from . import driver
    from . import convert
    from . import pytree
    from . import pygram
    from . import pytoken

    g = grammar.grammar
    p = Parser(g, convert.convert)
    p.setup()
    t = driver.Driver(g, convert.convert)
    t.setup()
    t.tokenize("x = 1")
    while True:
        type = t.get_token()
        if type == token.ENDMARKER:
            break
        value = t.token.string
        context = t.token.context
        p.addtoken(type, value, context)
    assert isinstance(p.rootnode, pytree.Node)
    assert p.rootnode.type == pygram.single_input
   

# Generated at 2022-06-17 16:50:53.802578
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import tokenize

    # Load the grammar
    g = grammar.grammar
    # Create a parser
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.StringInput("1+2").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == g.symbol2number["expr_stmt"]
    assert p.rootnode.children[0].type == g.symbol2number["expr"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["xor_expr"]


# Generated at 2022-06-17 16:51:06.965201
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import token

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Tokenize a program
    prog = "x = 1 + 2"
    tokgen = tokenize.generate_tokens(prog.splitlines(True))
    tokgen = list(tokgen)
    # Add the endmarker
    tokgen.append((token.ENDMARKER, "", (1, 0), (1, 0), ""))

    # Parse the program
    for (type, value, start, end, line) in tokgen:
        if p.addtoken(type, value, (start, end)):
            break
   

# Generated at 2022-06-17 16:51:15.326493
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 3))
    p.addtoken(token.NAME, "bar", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 7))

# Generated at 2022-06-17 16:51:28.155958
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 2))
    p.addtoken(token.NUMBER, "1", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    assert p.rootnode.children[0].value == "a"
    assert p.rootnode.children[1].value == "="
    assert p.rootnode.children[2].value == "1"
    assert p.rootnode.children[3].type == token.NEWLINE


# Generated at 2022-06-17 16:51:39.747041
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER

# Generated at 2022-06-17 16:51:45.604282
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 3))
    p.addtoken(token.EQUAL, "=", (1, 5))
    p.addtoken(token.NUMBER, "1", (1, 7))
    p.addtoken(token.NEWLINE, "\n", (1, 8))
    p.addtoken(token.NAME, "else", (2, 0))
    p.addtoken(token.COLON, ":", (2, 5))
    p.addtoken(token.NEWLINE, "\n", (2, 6))

# Generated at 2022-06-17 16:52:02.733028
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 1))
    p.addtoken(token.NUMBER, "1", (1, 2))
    p.addtoken(token.NEWLINE, "\n", (1, 3))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["expr_stmt"]
    assert p.rootnode

# Generated at 2022-06-17 16:52:13.170147
# Unit test for method setup of class Parser
def test_Parser_setup():
    import blib2to3.pgen2.driver
    import blib2to3.pgen2.parse
    import blib2to3.pgen2.tokenize
    import blib2to3.pgen2.convert
    import blib2to3.pgen2.grammar
    import blib2to3.pygram
    import blib2to3.pytree
    import blib2to3.fixer_util
    import blib2to3.fixer_base
    import blib2to3.fixer_util
    import blib2to3.fixer_base
    import blib2to3.fixer_util
    import blib2to3.fixer_base
    import blib2to3.fixer_util
    import blib2to3.fixer_base


# Generated at 2022-06-17 16:52:22.340789
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "def", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 4))
    p.addtoken(token.OP, "(", Context(1, 5))
    p.addtoken(token.OP, ")", Context(1, 6))
    p.addtoken(token.OP, ":", Context(1, 7))
    p.addtoken(token.NEWLINE, "\n", Context(1, 8))
    p.addtoken(token.INDENT, "    ", Context(2, 0))
    p.addtoken(token.NAME, "return", Context(2, 4))

# Generated at 2022-06-17 16:52:34.858515
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))
    p.addtoken(token.NAME, "garply", (1, 0))

# Generated at 2022-06-17 16:52:43.181837
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)

    assert p.classify(token.NAME, "foo", None) == g.keywords.get("foo")
    assert p.classify(token.NAME, "foo", None) == g.tokens.get(token.NAME)
    assert p.classify(token.NAME, "foo", None) == g.labels.index((token.NAME, "foo"))

    assert p.classify(token.NAME, "None", None) == g.keywords.get("None")
    assert p.classify(token.NAME, "None", None) == g.tokens.get(token.NAME)

# Generated at 2022-06-17 16:52:56.323855
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize
    import io

    # Test the parser by parsing a simple expression
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    s = "1 + 2"
    tokengen = tokenize.generate_tokens(io.StringIO(s).readline)
    for type, value, context in tokengen:
        if p.addtoken(type, value, context):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["expr"]
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS

# Generated at 2022-06-17 16:53:09.226597
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, None, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [(None, None, (1, None, None, [])), (None, None, (2, None, None, []))]
    p.push(3, (None, None), 0, None)
    assert p.stack == [(None, None, (1, None, None, [])), (None, None, (2, None, None, [])), (None, None, (3, None, None, []))]


# Generated at 2022-06-17 16:53:20.402341
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 3))
    p.addtoken(token.EQUAL, "=", Context(1, 5))
    p.addtoken(token.NUMBER, "1", Context(1, 7))
    p.addtoken(token.NEWLINE, "\n", Context(1, 8))
    p.addtoken(token.NAME, "else", Context(2, 0))
    p.addtoken(token.COLON, ":", Context(2, 4))
    p.addtoken(token.NEWLINE, "\n", Context(2, 5))
    p.add

# Generated at 2022-06-17 16:53:31.820548
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver
    from . import grammar

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Test classify
    p.setup()
    assert p.classify(token.NAME, "if", None) == g.keywords["if"]
    assert p.classify(token.NAME, "spam", None) == g.tokens[token.NAME]
    assert p.classify(token.NUMBER, "42", None) == g.tokens[token.NUMBER]
    assert p.classify(token.STRING, "foo", None) == g.tokens[token.STRING]
    assert p.classify(token.NEWLINE, "\n", None) == g.tokens[token.NEWLINE]

# Generated at 2022-06-17 16:53:43.730749
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 0))
    p.addtoken(token.NAME, "g", Context(1, 0))
    p.addtoken(token.NAME, "h", Context(1, 0))
    p.addtoken

# Generated at 2022-06-17 16:54:00.368029
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, token
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pytree import Leaf, Node
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2.convert import pytree_convert
    from blib2to3.pgen2.pgen import generate_grammar
    from blib2to3.pgen2.tokenize import generate_tokens
    from io import StringIO
    import sys
    import os
    import unittest
    import tempfile

    class TestParser(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

# Generated at 2022-06-17 16:54:08.900144
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.NAME, "y", None)
    p.addtoken(token.NAME, "z", None)
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)

# Generated at 2022-06-17 16:54:18.241378
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, []))]
    p.push(3, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, [])), (None, 0, (3, None, None, []))]

# Generated at 2022-06-17 16:54:28.635251
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    import sys
    import os
    import io
    import tokenize
    import blib2to3.pgen2.driver
    import blib2to3.pgen2.parse
    import blib2to3.pgen2.token


# Generated at 2022-06-17 16:54:36.120530
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    def test(s: Text) -> None:
        print("\n" + s)
        p = driver.Parser()
        p.setup()
        for t in p.tokenize(s):
            if p.addtoken(t.type, t.string, t.context):
                break
        print(p.rootnode)

    test("a = 1")
    test("a = 1 + 2")
    test("a = 1 + 2 + 3")
    test("a = 1 + 2 + 3 + 4")
    test("a = 1 + 2 + 3 + 4 + 5")
    test("a = 1 + 2 + 3 + 4 + 5 + 6")
    test("a = 1 + 2 + 3 + 4 + 5 + 6 + 7")

# Generated at 2022-06-17 16:54:51.362399
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:54:59.932546
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2.grammar import Grammar

    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.push(0, 0, 0, 0)
    parser.push(1, 1, 1, 1)
    parser.push(2, 2, 2, 2)
    assert parser.stack == [(0, 0, (0, None, 0, [])), (1, 1, (1, None, 1, [])), (2, 2, (2, None, 2, []))]

# Generated at 2022-06-17 16:55:04.486606
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None



# Generated at 2022-06-17 16:55:13.226180
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break

    # Check the result
    assert p.rootnode.type == g.symbol2number["expr_stmt"]
    assert p.rootnode.children[0].type == g.symbol2number["expr"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["xor_expr"]
    assert p.rootnode.children[0].children[0].children[0].type

# Generated at 2022-06-17 16:55:25.132804
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar

    def test(s: Text, expected: Sequence[int]) -> None:
        g = grammar.Grammar()
        p = Parser(g)
        p.setup()
        for t in driver.tokenize(s):
            if p.addtoken(t.type, t.string, t.context):
                break
        assert p.rootnode.type == expected[0]
        assert len(p.rootnode.children) == expected[1]

    test("1", (1, 1))
    test("1+2", (2, 3))
    test("1+2*3", (2, 3))
    test("1*2+3", (2, 3))
    test("1+2+3", (2, 3))

# Generated at 2022-06-17 16:55:42.716659
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", driver.FileInput("a"))
    p.addtoken(token.NAME, "b", driver.FileInput("b"))
    p.addtoken(token.NAME, "c", driver.FileInput("c"))
    p.addtoken(token.NAME, "d", driver.FileInput("d"))
    p.addtoken(token.NAME, "e", driver.FileInput("e"))
    p.addtoken(token.NAME, "f", driver.FileInput("f"))
    p.addtoken(token.NAME, "g", driver.FileInput("g"))

# Generated at 2022-06-17 16:55:52.965706
# Unit test for method pop of class Parser
def test_Parser_pop():
    import blib2to3.pgen2.driver
    import blib2to3.pgen2.parse
    import blib2to3.pytree
    import blib2to3.pgen2.token
    import blib2to3.pgen2.grammar
    import blib2to3.pgen2.pgen
    import blib2to3.pgen2.convert
    import blib2to3.pgen2.pgen2
    import blib2to3.pgen2.pgen
    import blib2to3.pgen2.pgen2
    import blib2to3.pgen2.pgen
    import blib2to3.pgen2.pgen2
    import blib2to3.pgen2.pgen

# Generated at 2022-06-17 16:56:05.548253
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar
    from . import tokenize

    # Test the parser by parsing a simple expression grammar
    g = grammar.Grammar(
        """
        expr: term ('+' term)*;
        term: factor ('*' factor)*;
        factor: NAME | '(' expr ')';
        """
    )
    p = Parser(g)
    p.setup()
    # Tokenize a simple expression
    s = "a + b * (c + d)"
    g = tokenize.generate_tokens(s.__iter__().__next__)
    for type, value, start, end, line in g:
        if p.addtoken(type, value, (start, end)):
            break
    # Check the result
    assert p.rootnode.type == g.sy

# Generated at 2022-06-17 16:56:17.990107
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import grammar, token

    class ParserTestCase(unittest.TestCase):
        def setUp(self):
            self.g = grammar.Grammar()
            self.p = Parser(self.g)

        def test_addtoken(self):
            self.p.setup()
            self.p.addtoken(token.NAME, "a", (1, 0))
            self.p.addtoken(token.NAME, "b", (1, 0))
            self.p.addtoken(token.NAME, "c", (1, 0))
            self.p.addtoken(token.NAME, "d", (1, 0))
            self.p.addtoken(token.NAME, "e", (1, 0))

# Generated at 2022-06-17 16:56:26.035948
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.shift(2, "foo", 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, "foo", None, None))]
    p.pop()
    assert p.stack == [(None, 0, (1, None, None, [(2, "foo", None, None)]))]

# Generated at 2022-06-17 16:56:33.735084
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    def convert(grammar, node):
        return node

    p = Parser(grammar.Grammar(), convert)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))

# Generated at 2022-06-17 16:56:45.077451
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)

    # Create a tokenizer
    t = tokenize.generate_tokens(driver.FileInput("test/test_grammar.py").readline)

    # Feed tokens to the parser
    p.setup()
    for type, value, context in t:
        if p.addtoken(type, value, context):
            break

    # Check the result
    assert p.rootnode.type == grammar.syms.file_input
    assert p.rootnode.children[0].type == token.NAME
    assert p.rootnode.children[0].value == "x"
    assert p.rootnode.children[1].type == grammar.syms

# Generated at 2022-06-17 16:56:56.960880
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import grammar, token

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            # Test the addtoken() method of the Parser class
            g = grammar.Grammar()
            g.start = "file_input"
            g.add_nonterminal("file_input", (("NEWLINE", "NEWLINE", "NEWLINE"),))
            g.add_nonterminal("file_input", (("stmt",),))
            g.add_nonterminal("file_input", (("file_input", "stmt"),))
            g.add_nonterminal("stmt", (("expr",),))
            g.add_nonterminal("expr", (("NAME",),))

# Generated at 2022-06-17 16:57:09.382500
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test/input/simple.py")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["simple_stmt"]

# Generated at 2022-06-17 16:57:21.635682
# Unit test for method setup of class Parser
def test_Parser_setup():
    import unittest
    from . import grammar
    from . import token

    class TestParser(unittest.TestCase):
        def setUp(self):
            self.g = grammar.Grammar()
            self.p = Parser(self.g)

        def test_setup(self):
            self.p.setup()
            self.assertEqual(self.p.stack, [(self.g.dfas[self.g.start], 0, (1, None, None, []))])
            self.assertEqual(self.p.rootnode, None)

        def test_setup_start(self):
            self.p.setup(2)
            self.assertEqual(self.p.stack, [(self.g.dfas[2], 0, (2, None, None, []))])

# Generated at 2022-06-17 16:58:05.689743
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 0))
    p.addtoken(token.NAME, "g", Context(1, 0))
    p.addtoken(token.NAME, "h", Context(1, 0))

# Generated at 2022-06-17 16:58:11.162115
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in driver.tokenize("x = 1"):
        p.addtoken(t.type, t.string, t.context)

# Generated at 2022-06-17 16:58:19.558136
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 0))
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 0))

# Generated at 2022-06-17 16:58:27.978891
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)
   

# Generated at 2022-06-17 16:58:40.268187
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [
        (None, 0, (1, None, None, [])),
        (None, 0, (1, None, None, [])),
        (None, 0, (2, None, None, [])),
    ]
    p.push(3, (None, None), 0, None)

# Generated at 2022-06-17 16:58:53.492592
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "def", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.OP, "(", None)
    p.addtoken(token.OP, ")", None)
    p.addtoken(token.OP, ":", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.INDENT, "  ", None)
    p.addtoken(token.NAME, "return", None)
    p.addtoken(token.NAME, "None", None)
    p.addtoken(token.NEWLINE, "\n", None)

# Generated at 2022-06-17 16:59:06.164661
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break

    # Check the result
    assert p.rootnode.type == g.symbol2number["expr_stmt"]
    assert len(p.rootnode.children) == 1
    expr = p.rootnode.children[0]
    assert expr.type == g.symbol2number["expr"]
    assert len(expr.children) == 3
    assert expr.children[0].type == token.NUMBER

# Generated at 2022-06-17 16:59:13.029254
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    p = Parser(g)
    assert p.classify(token.NAME, "foo", None) == g.symbol2number["NAME"]
    assert p.classify(token.NAME, "def", None) == g.symbol2number["DEF"]
    assert p.classify(token.NAME, "class", None) == g.symbol2number["CLASS"]
    assert p.classify(token.NAME, "if", None) == g.symbol2number["IF"]
    assert p.classify(token.NAME, "else", None) == g.symbol2number["ELSE"]
    assert p.classify(token.NAME, "elif", None) == g.symbol2number["ELIF"]
    assert p

# Generated at 2022-06-17 16:59:24.129109
# Unit test for method classify of class Parser
def test_Parser_classify():
    import sys
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 0))
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))
    p.addtoken(token.NAME, "else", (1, 0))
    p.addtoken(token.COLON, ":", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))
    p

# Generated at 2022-06-17 16:59:36.418188
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    # Parse a simple expression
    p.setup()
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == g.symbol2number["expr_stmt"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["expr"]
    assert len(p.rootnode.children[0].children) == 3
    assert p.rootnode.children[0].children[0].type == token.NUMBER
   