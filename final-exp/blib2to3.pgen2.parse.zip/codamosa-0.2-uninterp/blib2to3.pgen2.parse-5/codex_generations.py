

# Generated at 2022-06-17 16:50:27.168592
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    driver.parse_tokens(p, tokenize.generate_tokens(open("test/input/future1.py")))
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == token.ENCODING
    assert p.rootnode.children[1].type == token.NEWLINE
    assert p.rootnode.children[2].type == g.symbol2number["stmt"]
    assert p.rootnode.children[3].type == token.ENDMARKER
    assert p.root

# Generated at 2022-06-17 16:50:31.078494
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        if p.addtoken(t.type, t.string, t.start):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:50:34.019612
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()



# Generated at 2022-06-17 16:50:42.254748
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [1, "a", None, None]))]
    p.shift(2, "b", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [1, "a", None, None, 2, "b", None, None]))]


# Generated at 2022-06-17 16:50:53.333305
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, token
    from .pgen2.parse import ParseError

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:50:57.896608
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, 2, 3, 4)
    assert p.stack == [(2, 0, (1, None, 4, []))]

# Generated at 2022-06-17 16:51:11.037423
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break

    # Get the result
    tree = p.rootnode

    # Check the result
    assert tree.type == grammar.syms.expr
    assert len(tree.children) == 3
    assert tree.children[0].type == token.NUMBER
    assert tree.children[0].value == "1"
    assert tree.children[1].type == token.PLUS

# Generated at 2022-06-17 16:51:24.927755
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:51:36.769847
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "x", Context(1, 3))
    p.addtoken(token.EQUAL, "=", Context(1, 5))
    p.addtoken(token.NUMBER, "1", Context(1, 7))
    p.addtoken(token.NEWLINE, "\n", Context(1, 8))
    p.addtoken(token.INDENT, "", Context(2, 0))
    p.addtoken(token.NAME, "print", Context(2, 4))
    p.addtoken(token.NAME, "x", Context(2, 9))

# Generated at 2022-06-17 16:51:51.544810
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pytree import Leaf
    from io import StringIO
    from blib2to3.pgen2.pgen import driver

    def lam_sub(grammar, node):
        assert node[3] is None
        return Leaf(type=node[0], value=node[1], context=node[2])

    grammar = Grammar(StringIO(driver.grammar))
    parser = Parser(grammar, lam_sub)
    parser.setup()

# Generated at 2022-06-17 16:52:07.852467
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.shift(token.NAME, "a", 1, None)
    assert p.stack == [(g.dfas[g.start], 1, (g.start, None, None, [Leaf(token.NAME, "a")]))]
    p.shift(token.NAME, "b", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(token.NAME, "a"), Leaf(token.NAME, "b")]))]
    p.shift(token.NAME, "c", 3, None)

# Generated at 2022-06-17 16:52:19.451732
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 3))
    p.addtoken(token.NUMBER, "42", (1, 5))
    p.addtoken(token.NEWLINE, "\n", (1, 7))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    stmt = p.rootnode.children[0]
    assert stmt.type == g.symbol2number["stmt"]
    assert len(stmt.children) == 1

# Generated at 2022-06-17 16:52:22.892178
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(1, "a")]))]

# Generated at 2022-06-17 16:52:35.253258
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("NEWLINE", "NEWLINE"), "file_input"])
    g.add_nonterminal("file_input", [])
    g.add_nonterminal("file_input", [("stmt", "stmt"), "file_input"])
    g.add_nonterminal("stmt", [("simple_stmt", "simple_stmt")])
    g.add_nonterminal("stmt", [("compound_stmt", "compound_stmt")])
    g.add_nonterminal("simple_stmt", [("small_stmt", "small_stmt"), ("NEWLINE", "NEWLINE")])
    g

# Generated at 2022-06-17 16:52:43.383238
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "def", (1, 0))
    p.addtoken(token.NAME, "f", (1, 4))
    p.addtoken(token.OP, "(", (1, 5))
    p.addtoken(token.OP, ")", (1, 6))
    p.addtoken(token.OP, ":", (1, 7))
    p.addtoken(token.NEWLINE, "\n", (1, 8))
    p.addtoken(token.INDENT, "", (2, 0))
    p.addtoken(token.NAME, "return", (2, 4))
    p.addtoken(token.NAME, "None", (2, 10))


# Generated at 2022-06-17 16:52:50.735207
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            p = driver.Parser()
            p.setup()
            p.addtoken(token.NAME, "a", (1, 0))
            p.addtoken(token.NAME, "b", (1, 0))
            p.addtoken(token.NAME, "c", (1, 0))
            p.addtoken(token.NAME, "d", (1, 0))
            p.addtoken(token.NAME, "e", (1, 0))
            p.addtoken(token.NAME, "f", (1, 0))
            p.addtoken(token.NAME, "g", (1, 0))

# Generated at 2022-06-17 16:52:56.125001
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            p = Parser(driver.grammar)
            p.setup()
            p.addtoken(token.NAME, "foo", (1, 0))
            p.addtoken(token.EQUAL, "=", (1, 3))
            p.addtoken(token.NAME, "bar", (1, 4))
            p.addtoken(token.NEWLINE, "\n", (1, 7))
            self.assertEqual(p.rootnode.type, driver.grammar.symbol2number["file_input"])
            self.assertEqual(len(p.rootnode.children), 1)

# Generated at 2022-06-17 16:53:09.044793
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.shift(token.NAME, "a", 0, None)
    p.shift(token.NAME, "b", 0, None)
    p.shift(token.NAME, "c", 0, None)
    p.shift(token.NAME, "d", 0, None)
    p.shift(token.NAME, "e", 0, None)
    p.shift(token.NAME, "f", 0, None)
    p.shift(token.NAME, "g", 0, None)
    p.shift(token.NAME, "h", 0, None)
    p.shift(token.NAME, "i", 0, None)

# Generated at 2022-06-17 16:53:18.783593
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 0))
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))
    p.addtoken(token.ENDMARKER, "", (1, 0))
    assert p.rootnode is not None

# Generated at 2022-06-17 16:53:26.912024
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.classify(token.NAME, "if", None)
    p.classify(token.NAME, "foo", None)
    p.classify(token.NAME, "bar", None)
    p.classify(token.NAME, "baz", None)
    assert p.used_names == {"if", "foo", "bar", "baz"}

# Generated at 2022-06-17 16:53:50.939066
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 0))
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))
    p.addtoken(token.NAME, "print", (1, 0))
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 0))

# Generated at 2022-06-17 16:54:00.079328
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [("a", None, None, None)]))]
    p.shift(1, "b", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [("a", None, None, None), ("b", None, None, None)]))]


# Generated at 2022-06-17 16:54:08.730322
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("test/input/future1.py")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1

# Generated at 2022-06-17 16:54:11.386891
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()



# Generated at 2022-06-17 16:54:15.964022
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.FileInput("1+2").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS

# Generated at 2022-06-17 16:54:27.369931
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:54:37.471954
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)
   

# Generated at 2022-06-17 16:54:51.931053
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    g.start = "file_input"

# Generated at 2022-06-17 16:55:01.423155
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 0, None)
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, [1, "a", None, None]))]
    p.shift(2, "b", 0, None)
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, [1, "a", None, None]))]
    assert p.rootnode is None


# Generated at 2022-06-17 16:55:05.794005
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.grammar import Grammar

    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.shift(1, "a", 1, None)
    assert parser.stack == [(None, 1, (None, None, None, [Leaf(1, "a")]))]

# Generated at 2022-06-17 16:55:24.229947
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:55:28.398737
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "spam", (1, 0))
    p.addtoken(token.NAME, "eggs", (1, 0))
    p.addtoken(token.NAME, "ham", (1, 0))
    p.addtoken(token.NAME, "lobster", (1, 0))

# Generated at 2022-06-17 16:55:40.032634
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import driver

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]

# Generated at 2022-06-17 16:55:52.111932
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, tokenize
    from .pygram import python_symbols as syms
    from .pygram import python_grammar

    g = grammar.Grammar(python_grammar)
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open(__file__)):
        if p.addtoken(t.type, t.string, t.context):
            break
    assert p.rootnode.type == syms.file_input
    assert p.rootnode.children[0].type == syms.simple_stmt
    assert p.rootnode.children[0].children[0].type == syms.small_stmt
    assert p.rootnode.children[0].children[0].children[0].type == syms.expr_st

# Generated at 2022-06-17 16:56:05.019715
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.expr("1+2")):
        p.addtoken(t[0], t[1], t[2])

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER

#

# Generated at 2022-06-17 16:56:17.537669
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(token.NAME, g.dfas[token.NAME], 0, None)
    p.push(token.NAME, g.dfas[token.NAME], 0, None)
    p.push(token.NAME, g.dfas[token.NAME], 0, None)
    assert len(p.stack) == 4
    p.pop()
    assert len(p.stack) == 3
    p.pop()
    assert len(p.stack) == 2
    p.pop()
    assert len(p.stack) == 1
    p.pop()
    assert len(p.stack) == 0

# Generated at 2022-06-17 16:56:24.552455
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("test_grammar.txt")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None

# Generated at 2022-06-17 16:56:33.079350
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize
    from . import token

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)

    # Create a tokenizer
    t = tokenize.generate_tokens(iter(["1", "2", "3"]).__next__)

    # Create a token
    tok = t.__next__()

    # Create a context
    ctx = Context(1, 0)

    # Create a new dfa
    newdfa = ([[(0, 0), (1, 1)], [(0, 1), (1, 1)]], {0: 0, 1: 1})

    # Create a new state
    newstate = 1

    # Create a new node

# Generated at 2022-06-17 16:56:44.675425
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    d = driver.Driver(g, p.addtoken)

# Generated at 2022-06-17 16:56:54.699910
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 1))
    p.addtoken(token.NAME, "c", (1, 2))
    p.addtoken(token.NAME, "d", (1, 3))
    p.addtoken(token.NAME, "e", (1, 4))
    p.addtoken(token.NAME, "f", (1, 5))
    p.addtoken(token.NAME, "g", (1, 6))
    p.addtoken(token.NAME, "h", (1, 7))

# Generated at 2022-06-17 16:57:29.810248
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, []))]
    p.push(3, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, [])), (None, 0, (3, None, None, []))]


# Generated at 2022-06-17 16:57:39.601119
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test/input/future1.py")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1
    assert p.rootnode.children[0].children[0].type

# Generated at 2022-06-17 16:57:52.971793
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    def classify(type, value):
        p = Parser(grammar.Grammar())
        return p.classify(type, value, None)

    assert classify(token.NAME, "if") == grammar.syms.if_stmt
    assert classify(token.NAME, "True") == grammar.syms.test
    assert classify(token.NAME, "foo") == grammar.syms.NAME
    assert classify(token.NUMBER, "42") == grammar.syms.test
    assert classify(token.NUMBER, "42") == grammar.syms.test
    assert classify(token.STRING, "foo") == grammar.syms.test
    assert classify(token.STRING, "foo") == grammar.syms.test
    assert classify(token.NEWLINE, "\n") == grammar.sy

# Generated at 2022-06-17 16:58:03.803132
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    import io

    def convert(grammar, node):
        return node

    p = Parser(grammar.grammar, convert)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(token.ENDMARKER, "", (2, 0))

# Generated at 2022-06-17 16:58:15.824822
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    # Test setup()
    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    p.setup(g.start + 1)
    assert p.stack == [(g.dfas[g.start + 1], 0, (g.start + 1, None, None, []))]

    # Test addtoken()
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))

# Generated at 2022-06-17 16:58:25.703515
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)
    p

# Generated at 2022-06-17 16:58:38.357666
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver
    from . import grammar


# Generated at 2022-06-17 16:58:49.076766
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import tokenize

    def convert(grammar, node):
        return node

    p = Parser(grammar.grammar, convert)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test/test_grammar.py")):
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode is not None

# Generated at 2022-06-17 16:58:56.223816
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            # Test the addtoken method of class Parser
            p = driver.Parser()
            p.setup()
            self.assertFalse(p.addtoken(token.NAME, "a", (1, 0)))
            self.assertFalse(p.addtoken(token.EQUAL, "=", (1, 2)))
            self.assertFalse(p.addtoken(token.NAME, "b", (1, 4)))
            self.assertTrue(p.addtoken(token.NEWLINE, "\n", (1, 6)))
            self.assertEqual(p.rootnode.type, symbol.file_input)
            self.assertEqual(len(p.rootnode.children), 1)

# Generated at 2022-06-17 16:59:07.499915
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.classify(token.NAME, "if", None)
    p.classify(token.NAME, "foo", None)
    p.classify(token.NAME, "bar", None)
    p.classify(token.NAME, "baz", None)
    p.classify(token.NAME, "elif", None)
    p.classify(token.NAME, "else", None)
    p.classify(token.NAME, "except", None)
    p.classify(token.NAME, "finally", None)
    p.classify(token.NAME, "for", None)
    p.classify(token.NAME, "from", None)

# Generated at 2022-06-17 16:59:50.736238
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, tokenize
    from .pgen import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar/Grammar")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == token.NAME
    assert p.rootnode.children[0].children[0].value == "print"
    assert p.rootnode.children[0].children

# Generated at 2022-06-17 16:59:55.405386
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 17:00:03.149733
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("NEWLINE", "NEWLINE", "file_input")])
    g.add_nonterminal("file_input", [])
    g.add_nonterminal("file_input", [("stmt", "stmt", "file_input")])
    g.add_nonterminal("stmt", [("simple_stmt", "simple_stmt")])
    g.add_nonterminal("simple_stmt", [("small_stmt", "small_stmt", "NEWLINE")])
    g.add_nonterminal("small_stmt", [("expr_stmt", "expr_stmt")])