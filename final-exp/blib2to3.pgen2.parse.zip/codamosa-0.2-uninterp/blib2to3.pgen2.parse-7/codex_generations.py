

# Generated at 2022-06-17 16:50:29.546757
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test_Parser_shift.py")):
        if p.addtoken(t.type, t.string, t.start):
            break
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode[0].type == g.symbol2number["stmt"]
    assert p.rootnode[0][0].type == g.symbol2number["simple_stmt"]
    assert p.rootnode[0][0][0].type == g.symbol2number["small_stmt"]

# Generated at 2022-06-17 16:50:39.840540
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:50:52.393809
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Add a token
    p.addtoken(token.NAME, "a", (1, 0))

    # Pop a nonterminal
    p.pop()

    # Add a token
    p.addtoken(token.NAME, "b", (1, 0))

    # Pop a nonterminal
    p.pop()

    # Add a token
    p.addtoken(token.NAME, "c", (1, 0))

    # Pop a nonterminal
    p.pop()

    # Add a token
    p.addtoken(token.NAME, "d", (1, 0))

    # Pop a nonterminal

# Generated at 2022-06-17 16:50:57.511719
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()


# Generated at 2022-06-17 16:51:10.672982
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    g.start = 257
    g.labels = [
        (257, "start"),
        (258, "expr"),
        (259, "term"),
        (260, "factor"),
        (261, "NAME"),
        (262, "NUMBER"),
        (263, "PLUS"),
        (264, "TIMES"),
        (265, "LPAR"),
        (266, "RPAR"),
    ]
    g.keywords = {}
    g.tokens = {
        token.NAME: 261,
        token.NUMBER: 262,
        token.PLUS: 263,
        token.TIMES: 264,
        token.LPAR: 265,
        token.RPAR: 266,
    }
    g.dfas

# Generated at 2022-06-17 16:51:17.537115
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NEWLINE, "\n", (1, 3))
    p.addtoken(token.NAME, "bar", (2, 0))
    p.addtoken(token.NEWLINE, "\n", (2, 3))
    p.addtoken(token.NAME, "baz", (3, 0))
    p.addtoken(token.NEWLINE, "\n", (3, 3))
    p.addtoken(token.ENDMARKER, "", (4, 0))

# Generated at 2022-06-17 16:51:22.126749
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    # Test for issue #15
    # https://bitbucket.org/blais/beautifulsoup/issue/15/
    #
    # The problem was that the parser was not properly handling
    # the case where the last token was a symbol.
    #
    # The test case is a simple HTML document with a single
    # <html> tag.
    #
    # The parser was not properly handling the case where the
    # last token was a symbol.  This is because the method pop
    # was not properly handling the case where the stack was
    # empty.
    #
    # The test case is a simple HTML document with a single
    # <html> tag.

    # Create a parser
    p = Parser(grammar.grammar)

   

# Generated at 2022-06-17 16:51:34.074137
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:51:46.725949
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", Context(1, 0))
    p.addtoken(token.NAME, "foo", Context(1, 3))
    p.addtoken(token.NAME, "and", Context(1, 6))
    p.addtoken(token.NAME, "or", Context(1, 10))
    p.addtoken(token.NAME, "not", Context(1, 13))
    p.addtoken(token.NAME, "is", Context(1, 17))
    p.addtoken(token.NAME, "in", Context(1, 20))
    p.addtoken(token.NAME, "assert", Context(1, 23))

# Generated at 2022-06-17 16:51:58.543193
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver
    from . import grammar


# Generated at 2022-06-17 16:52:14.883857
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    # Test with a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode.type == g.symbol2number["expr"]
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER
    # Test with a simple assignment
    p.setup()

# Generated at 2022-06-17 16:52:22.313501
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver

    def test_shift(input, expected):
        p = Parser(driver.grammar)
        p.setup()
        for t in input:
            p.addtoken(t[0], t[1], t[2])
        assert p.rootnode == expected

    test_shift([(token.NAME, "a", (1, 0))], Leaf(token.NAME, "a", (1, 0)))
    test_shift(
        [(token.NAME, "a", (1, 0)), (token.NAME, "b", (1, 0))],
        Node(
            symbol.file_input,
            [Leaf(token.NAME, "a", (1, 0)), Leaf(token.NAME, "b", (1, 0))],
            (1, 0),
        ),
    )
    test

# Generated at 2022-06-17 16:52:33.848726
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    from . import driver
    from . import token

    # Create a parser
    p = driver.Driver(grammar, convert=convert)
    # Feed it some input
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.EQUAL, "=", (1, 3))
    p.addtoken(token.NUMBER, "42", (1, 5))
    p.addtoken(token.NEWLINE, "\n", (1, 7))
    # Get the result
    tree = p.rootnode
    # Print the result in a form that can be parsed back
    print(tree.totuple())



# Generated at 2022-06-17 16:52:42.553538
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)
    p

# Generated at 2022-06-17 16:52:56.045917
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    t = driver.Driver(g, p.addtoken)
    t.set_s("a")
    assert p.rootnode.type == 1
    assert p.rootnode.children == [Leaf(1, "a")]
    p.setup()
    t.set_s("a b")
    assert p.rootnode.type == 1
    assert p.rootnode.children == [Leaf(1, "a"), Leaf(1, "b")]
    p.setup()
    t.set_s("a b c")
    assert p.rootnode.type == 1

# Generated at 2022-06-17 16:53:08.955342
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, 2, 3, 4)
    assert p.stack == [(2, 0, (1, None, 4, []))]
    p.push(5, 6, 7, 8)
    assert p.stack == [(2, 0, (1, None, 4, [])), (6, 0, (5, None, 8, []))]
    p.pop()
    assert p.stack == [(2, 0, (1, None, 4, [(5, None, 8, [])]))]
    p.pop()
    assert p.stack == []

# Generated at 2022-06-17 16:53:20.213970
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.pgen import generate_grammar
    from blib2to3.pytree import Leaf
    from io import StringIO


# Generated at 2022-06-17 16:53:31.662794
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        if p.addtoken(t[0], t[1], t[2]):
            break

    # print(p.rootnode)
    # print(p.rootnode.leaves())
    # print(p.rootnode.pretty())
    # print(p.rootnode.pretty(indent="  "))
    # print(p.rootnode.pretty(indent="  ", offset=2))
    # print(p.rootnode.pretty(indent="  ", offset=2, linesep="\r\n"))
    # print(p.rootnode.pretty(ind

# Generated at 2022-06-17 16:53:43.571043
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    def test(type, value, expected):
        p = Parser(grammar.Grammar())
        p.setup()
        ilabel = p.classify(type, value, None)
        assert ilabel == expected

    test(token.NAME, "if", grammar.syms.if_stmt)
    test(token.NAME, "foo", grammar.tokens.NAME)
    test(token.NAME, "and", grammar.syms.and_expr)
    test(token.NAME, "or", grammar.syms.or_expr)
    test(token.NAME, "not", grammar.syms.not_test)
    test(token.NAME, "in", grammar.syms.comp_op)
    test(token.NAME, "is", grammar.syms.comp_op)

# Generated at 2022-06-17 16:53:53.002227
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar/Grammar")
    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))

# Generated at 2022-06-17 16:54:10.622319
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()



# Generated at 2022-06-17 16:54:19.632214
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import tokenize
    from . import token

    # Load the grammar
    g = grammar.grammar

    # Create a parser
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Create a tokenizer
    t = tokenize.generate_tokens(open("test/test_grammar.py"))

    # Feed the parser
    for type, value, start, end, line in t:
        if type == token.OP and value == ".":
            # Replace "." with "DOT"
            type = token.NAME
            value = "DOT"
        if type == tokenize.ENCODING:
            continue
        if type == token.OP and value == "@":
            # Replace "@" with "AT"
            type = token.NAME
           

# Generated at 2022-06-17 16:54:29.165469
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.NAME, "else", None)
    p.addtoken(token.COLON, ":", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.INDENT, "", None)
    p.addtoken(token.NAME, "pass", None)
    p.add

# Generated at 2022-06-17 16:54:38.788699
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    assert p.addtoken(token.NAME, "print", (1, 0))
    assert p.addtoken(token.LPAR, "(", (1, 5))
    assert p.addtoken(token.NAME, "x", (1, 6))
    assert p.addtoken(token.RPAR, ")", (1, 7))
    assert p.addtoken(token.NEWLINE, "\n", (1, 8))
    assert p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode is not None
    assert p.rootnode.type == grammar.syms.file_input
    assert len(p.rootnode.children)

# Generated at 2022-06-17 16:54:51.169186
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, []))]
    p.push(3, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, [])), (None, 0, (3, None, None, []))]


# Generated at 2022-06-17 16:55:03.404401
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:55:13.372473
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children

# Generated at 2022-06-17 16:55:25.247372
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))
    p.addtoken(token.NAME, "garply", (1, 0))

# Generated at 2022-06-17 16:55:36.595163
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 0, (1, 1))
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, [1, "a", (1, 1), None]))]
    p.shift(2, "b", 0, (1, 2))
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, [1, "a", (1, 1), None, 2, "b", (1, 2), None]))]


# Generated at 2022-06-17 16:55:51.127322
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.driver import Driver
    from io import StringIO
    import sys

    # Test the method pop of class Parser
    # This test is based on the test test_parse_file of class Driver
    # in the file test_driver.py
    # The test is modified to test the method pop of class Parser
    # instead of the method parse_file of class Driver
    # The test is modified to test the method pop of class Parser
    # instead of the method parse_file of class Driver
    # The test is modified to test the method pop of class Parser
   

# Generated at 2022-06-17 16:56:26.348019
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    # Read the grammar
    g = grammar.grammar
    # Create a parser
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Tokenize a string
    tokengen = tokenize.generate_tokens(
        "x = 3 + 4 + y",
        ("", "", 1),
        {"x": token.NAME, "y": token.NAME},
        {"+": token.OP},
    )
    # Parse the tokens
    for type, value, start, end, line in tokengen:
        p.addtoken(type, value, (start, end))
    # Get the result
    root = p.rootnode
    # Print the result
    print(root)
    # Check the result
   

# Generated at 2022-06-17 16:56:32.206780
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        p.addtoken(t[0], t[1], t[2])

    # Get the result
    tree = p.rootnode

    # Print the result
    driver.treetransform(tree)
    print(tree)

# Generated at 2022-06-17 16:56:44.284230
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    import io

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))
    p.addtoken

# Generated at 2022-06-17 16:56:49.698219
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:56:58.500699
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar(grammar.DEFAULT_GRAMMAR)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)

# Generated at 2022-06-17 16:57:10.245598
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import grammar

    class TestParser(unittest.TestCase):
        def test_addtoken(self):
            g = grammar.Grammar()
            p = Parser(g)
            p.setup()
            p.addtoken(token.NAME, "a", None)
            p.addtoken(token.NAME, "b", None)
            p.addtoken(token.NAME, "c", None)
            p.addtoken(token.NAME, "d", None)
            p.addtoken(token.NAME, "e", None)
            p.addtoken(token.NAME, "f", None)
            p.addtoken(token.NAME, "g", None)
            p.addtoken(token.NAME, "h", None)

# Generated at 2022-06-17 16:57:17.299086
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Parser/Grammar.txt")):
        p.addtoken(t[0], t[1], t[2])
    print(p.rootnode)

# Generated at 2022-06-17 16:57:21.959439
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(1, "a")]))]

# Generated at 2022-06-17 16:57:28.972825
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar/Grammar")):
        if p.addtoken(t.type, t.string, t.start):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == token.NAME
    assert p.rootnode.children[0].children[0].value == "print"

# Generated at 2022-06-17 16:57:36.349407
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar)

    # Parse a string
    p.setup()
    for t in tokenize.generate_tokens("x = 1"):
        p.addtoken(t[0], t[1], t[2])

    # Check the result
    assert p.rootnode.type == grammar.syms.file_input
    assert len(p.rootnode.children) == 1
    stmt = p.rootnode.children[0]
    assert stmt.type == grammar.syms.stmt
    assert len(stmt.children) == 1
    simple_stmt = stmt.children[0]
    assert simple_stmt.type == grammar.syms.simple_

# Generated at 2022-06-17 16:58:15.861446
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    # Test case:
    #   def f(x):
    #       return x
    #
    #   f(1)
    #
    # The parser should return the following AST:
    #   Module(
    #       body=[
    #           FunctionDef(
    #               name='f',
    #               args=arguments(
    #                   args=[arg(arg='x', annotation=None)],
    #                   vararg=None,
    #                   kwonlyargs=[],
    #                   kw_defaults=[],
    #                   kwarg=None,
    #                   defaults=[]),
    #               body=[
    #                   Return(
    #                       value=Name(id='x', ctx=Load()))],
    #

# Generated at 2022-06-17 16:58:25.701699
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import driver
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Parse a simple expression
    p.setup()
    for t in tokenize.generate_tokens(driver.expr("2+3")):
        if p.addtoken(*t):
            break
    assert p.rootnode.type == g.symbol2number["expr"]
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "2"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER
    assert p.rootnode.children[2].value == "3"

# Generated at 2022-06-17 16:58:36.022805
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    tok = tokenize.generate_tokens(iter(["x"]).__next__)
    t = next(tok)
    p.addtoken(t[0], t[1], t[2])
    assert p.rootnode.children[0].value == "x"
    assert p.rootnode.children[0].type == token.NAME
    assert p.rootnode.children[0].context == (1, 0)



# Generated at 2022-06-17 16:58:45.845240
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import pytree
    from . import pygram

    # Create a parser
    g = grammar.Grammar(pygram.python_grammar)
    p = Parser(g)
    p.setup()

    # Tokenize a string
    s = "a = 1"
    tokengen = tokenize.generate_tokens(StringIO(s).readline)
    for type, value, start, end, line in tokengen:
        if p.addtoken(type, value, (start, end)):
            break

    # Check the result
    assert p.rootnode.children[0].type == pytree.expr_stmt

# Generated at 2022-06-17 16:58:51.504596
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token
    from . import driver
    from . import pgen2
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import pygram
    from . import pytoken
    from . import pytree
    from . import py

# Generated at 2022-06-17 16:59:03.035417
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", Context(1, 0))
    p.addtoken(token.NAME, "bar", Context(1, 0))
    p.addtoken(token.NAME, "baz", Context(1, 0))
    p.addtoken(token.NAME, "None", Context(1, 0))
    p.addtoken(token.NAME, "True", Context(1, 0))
    p.addtoken(token.NAME, "False", Context(1, 0))
    p.addtoken(token.NAME, "and", Context(1, 0))
    p.addtoken(token.NAME, "or", Context(1, 0))

# Generated at 2022-06-17 16:59:11.116725
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    import io

    def convert(grammar, node):
        return node

    p = Parser(grammar.grammar, convert)
    p.setup()
    f = io.StringIO("x = 1")
    for type, value, context in tokenize.generate_tokens(f.readline):
        p.addtoken(type, value, context)
    assert p.rootnode[0] == grammar.syms.file_input
    assert p.rootnode[1] is None
    assert p.rootnode[2] is None
    assert p.rootnode[3][0][0] == grammar.syms.stmt
    assert p.rootnode[3][0][1] is None
    assert p.rootnode[3][0][2] is None


# Generated at 2022-06-17 16:59:16.178826
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1
    assert p.rootnode.children[0].children[0].type == token.NAME

# Generated at 2022-06-17 16:59:22.742879
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver
    from . import grammar

    class ParserTestCase(unittest.TestCase):
        def test_addtoken(self):
            g = grammar.Grammar()
            p = Parser(g)
            p.setup()
            self.assertRaises(ParseError, p.addtoken, token.NAME, "a", (1, 0))

    unittest.main()

# Generated at 2022-06-17 16:59:27.401621
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    p = Parser(grammar.grammar)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test_Parser_shift.py")):
        p.addtoken(t[0], t[1], t[2])
    print(p.rootnode)

# Generated at 2022-06-17 17:00:04.403270
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)