

# Generated at 2022-06-17 16:50:16.786878
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open(__file__)):
        if p.addtoken(t[0], t[1], t[2]):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:50:28.231799
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver


# Generated at 2022-06-17 16:50:31.635975
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()



# Generated at 2022-06-17 16:50:35.175425
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.ENDMARKER, "", driver.FileInput.EOF)
    assert p.rootnode is not None
    assert p.rootnode.type == g.start
    assert p.rootnode.children == []
    assert p.rootnode.used_names == set()

# Generated at 2022-06-17 16:50:43.637330
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Create a parser instance
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[1].value == "+"
   

# Generated at 2022-06-17 16:50:53.950895
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"

# Generated at 2022-06-17 16:51:06.052567
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import pytree
    from . import pygram

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.expr("1+2")):
        if p.addtoken(t.type, t.string, (t.start, t.end)):
            break
    # Get the abstract syntax tree
    tree = p.rootnode
    # Convert it to a Python AST
    ast = pytree.convert(tree)
    # Check the result
    assert ast == pygram.python_grammar.number3

# Generated at 2022-06-17 16:51:15.393114
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    # Test shift of a token
    p.addtoken(token.NAME, "a", (1, 0))
    assert p.stack == [(g.dfas[g.start], 1, (g.start, None, None, [Leaf(1, "a", (1, 0))]))]
    # Test shift of a symbol
    p.addtoken(token.EQUAL, "=", (1, 2))

# Generated at 2022-06-17 16:51:28.658882
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "def", (1, 0))
    p.addtoken(token.NAME, "f", (1, 4))
    p.addtoken(token.OP, "(", (1, 5))
    p.addtoken(token.OP, ")", (1, 6))
    p.addtoken(token.OP, ":", (1, 7))
    p.addtoken(token.NEWLINE, "\n", (1, 8))
    p.addtoken(token.INDENT, "    ", (2, 0))
    p.addtoken(token.NAME, "return", (2, 4))
    p.addtoken(token.NAME, "None", (2, 10))

# Generated at 2022-06-17 16:51:30.108442
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.setup(1)

# Generated at 2022-06-17 16:51:51.336513
# Unit test for method pop of class Parser
def test_Parser_pop():
    class TestGrammar(Grammar):
        def __init__(self):
            self.dfas = {
                "a": ([[(1, 1), (2, 2)], [(0, 1), (2, 2)], [(0, 2), (2, 2)]], {1: 1, 2: 2}),
                "b": ([[(1, 1), (2, 2)], [(0, 1), (2, 2)], [(0, 2), (2, 2)]], {1: 1, 2: 2}),
                "c": ([[(1, 1), (2, 2)], [(0, 1), (2, 2)], [(0, 2), (2, 2)]], {1: 1, 2: 2}),
            }
            self.start = "a"

# Generated at 2022-06-17 16:52:00.128688
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a token
    p.shift(token.NAME, 'a', 1, (1, 0))

    # Parse a token
    p.shift(token.NAME, 'b', 2, (1, 1))

    # Parse a token
    p.shift(token.NAME, 'c', 3, (1, 2))

    # Parse a token
    p.shift(token.NAME, 'd', 4, (1, 3))

    # Parse a token
    p.shift(token.NAME, 'e', 5, (1, 4))

    # Parse a token
   

# Generated at 2022-06-17 16:52:05.801191
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 1))
    p.addtoken(token.NAME, "c", (1, 2))
    p.addtoken(token.NAME, "d", (1, 3))
    p.addtoken(token.NAME, "e", (1, 4))
    p.addtoken(token.NAME, "f", (1, 5))
    p.addtoken(token.NAME, "g", (1, 6))
    p.addtoken(token.NAME, "h", (1, 7))

# Generated at 2022-06-17 16:52:10.933685
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar/Grammar")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:52:19.929875
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar
    from . import tokenize

    # Build a parser
    g = grammar.grammar
    p = Parser(g)
    p.setup()

    # Read a file
    f = open("Parser/parser.out")
    try:
        driver.tokenize_loop(f.readline, p.addtoken)
    finally:
        f.close()

    # Print the abstract syntax tree
    print(p.rootnode)

    # Test tokenize_loop
    f = open("Parser/parser.out")
    try:
        driver.tokenize_loop(f.readline, tokenize.printtoken)
    finally:
        f.close()


if __name__ == "__main__":
    test_Parser_addtoken()

# Generated at 2022-06-17 16:52:27.410692
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar.txt")
    parser = Parser(grammar)
    parser.setup()
    parser.shift(token.NAME, "a", 0, None)
    assert parser.stack == [(grammar.dfas[grammar.start], 0, (grammar.start, None, None, [Leaf(token.NAME, "a", None)]))]
    parser.shift(token.NAME, "b", 0, None)
    assert parser.stack == [(grammar.dfas[grammar.start], 0, (grammar.start, None, None, [Leaf(token.NAME, "a", None), Leaf(token.NAME, "b", None)]))]

# Generated at 2022-06-17 16:52:36.670788
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(1, "a")]))]
    p.shift(2, "b", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [Leaf(1, "a"), Leaf(2, "b")]))]
    p.shift(3, "c", 4, None)

# Generated at 2022-06-17 16:52:51.932431
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"

# Generated at 2022-06-17 16:53:05.126297
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    driver.add_tokens(p, [
        (token.NUMBER, "1", (1, 0)),
        (token.PLUS, "+", (1, 2)),
        (token.NUMBER, "2", (1, 4)),
        (token.NEWLINE, "\n", (1, 5)),
        (token.ENDMARKER, "", (2, 0)),
    ])

    # Check the result
    assert p.rootnode.type == grammar.syms.file_input
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == grammar

# Generated at 2022-06-17 16:53:17.587798
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [Leaf(1, "a")]))]
    p.shift(2, "b", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [Leaf(1, "a"), Leaf(2, "b")]))]
    p.shift(3, "c", 4, None)

# Generated at 2022-06-17 16:53:29.002389
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("test_grammar.txt")):
        p.addtoken(t[0], t[1], t[2])

# Generated at 2022-06-17 16:53:33.836418
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize, token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for type, value, start, end, line in tokenize.generate_tokens(open("Grammar.txt")):
        if type == token.OP and value == "|":
            type = token.NAME
        p.addtoken(type, value, (start, end))
    print(p.rootnode)

# Generated at 2022-06-17 16:53:46.775698
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)

    # Create a tokenizer
    t = driver.Driver(g, p)

    # Test the parser
    p.setup()
    t.set_code("x = 1")
    for type, value, context in t.tokenize():
        if p.addtoken(type, value, context):
            break
    assert p.rootnode is not None
    assert p.rootnode.children[0].type == grammar.syms.expr_stmt
    assert p.rootnode.children[0].children[0].type == grammar.syms.power
    assert p.rootnode.children[0].children[0].children[0].type == grammar.syms.atom
    assert p

# Generated at 2022-06-17 16:53:51.225383
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.shift(token.NAME, "name", 0)
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, [Leaf(token.NAME, "name")]))]
    p.shift(token.NAME, "name", 0)
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, [Leaf(token.NAME, "name"), Leaf(token.NAME, "name")]))]


# Generated at 2022-06-17 16:54:02.522369
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    g = grammar.Grammar()
    p = Parser(g)

    # Create a tokenizer
    t = tokenize.generate_tokens(driver.FileInput(""))

    # Create a fake token
    type = token.NAME
    value = "test"
    context = (1, 1)

    # Create a fake node
    node = (type, value, context, None)

    # Create a fake dfa
    dfa = [[(0, 0)]]
    newdfa = (dfa, {})

    # Create a fake state
    newstate = 0

    # Push the fake node
    p.push(type, newdfa, newstate, context)

    # Check the result
    assert p

# Generated at 2022-06-17 16:54:14.207123
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    p.setup()

    # Tokenize a program
    f = open("test/test_grammar.py")
    tokens = tokenize.generate_tokens(f.readline)
    f.close()

    # Feed the tokens to the parser
    for type, value, start, end, line in tokens:
        if type == token.OP:
            type = driver.keyword_tokens.get(value, type)
        p.addtoken(type, value, (start, end))

    # Get the parse tree
    tree = p.rootnode

    # Print the parse tree
    print(tree)

# Generated at 2022-06-17 16:54:26.965143
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    # Test a simple grammar
    grammar = driver.load_grammar("Grammar/Grammar")
    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NAME, "print", (1, 0))
    p.addtoken(token.NAME, "x", (1, 5))
    p.addtoken(token.NEWLINE, "\n", (1, 6))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode is not None
    assert p.rootnode.type == symbol.file_input
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == symbol.stmt
    assert len(p.rootnode.children[0].children)

# Generated at 2022-06-17 16:54:34.006415
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    # Create a parser instance
    g = grammar.grammar
    p = Parser(g)

    # Prepare for parsing
    p.setup()

    # Parse a token
    p.shift(token.NAME, "a", 1, (1, 0))

    # Check the result
    assert p.stack == [(g.dfas[g.start], 1, (g.start, None, None, [Leaf(1, "a", (1, 0))]))]



# Generated at 2022-06-17 16:54:41.895968
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)
   

# Generated at 2022-06-17 16:54:52.332444
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "spam", None)
    p.addtoken(token.NAME, "eggs", None)
    p.addtoken(token.NAME, "ham", None)
    p.addtoken(token.NAME, "sausage", None)
    p.addtoken(token.NAME, "beans", None)
    p.addtoken(token.NAME, "and", None)
    p.add

# Generated at 2022-06-17 16:55:15.826965
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar/Grammar")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    print(p.rootnode)

# Generated at 2022-06-17 16:55:24.888649
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.shift(token.NAME, "a", 1, None)
    p.shift(token.NAME, "b", 2, None)
    p.shift(token.NAME, "c", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [Leaf(1, "a"), Leaf(1, "b"), Leaf(1, "c")]))]
    assert p.rootnode is None


# Generated at 2022-06-17 16:55:37.227046
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    p.push(2, (None, None), 0, None)
    p.push(3, (None, None), 0, None)
    p.push(4, (None, None), 0, None)
    p.push(5, (None, None), 0, None)
    p.push(6, (None, None), 0, None)
    p.push(7, (None, None), 0, None)
    p.push(8, (None, None), 0, None)
    p.push(9, (None, None), 0, None)

# Generated at 2022-06-17 16:55:51.337571
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [("a", None, None, None)]))]
    p.shift(2, "b", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [("a", None, None, None), ("b", None, None, None)]))]
    p.shift(3, "c", 4, None)

# Generated at 2022-06-17 16:56:04.265761
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import driver
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.StringIO("1 + 2").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Get the result
    root = p.rootnode
    assert root.type == g.symbol2number["file_input"]
    assert len(root.children) == 1
    stmt = root.children[0]
    assert stmt.type == g.symbol2number["stmt"]
    assert len(stmt.children) == 1
    simple_

# Generated at 2022-06-17 16:56:12.059574
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.shift(token.NAME, "foo", 1, None)
    assert p.stack == [(g.dfas[g.start], 1, (g.start, None, None, [Leaf(token.NAME, "foo")]))]


# Generated at 2022-06-17 16:56:24.652014
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", Context(1, 0))
    p.addtoken(token.NAME, "b", Context(1, 0))
    p.addtoken(token.NAME, "c", Context(1, 0))
    p.addtoken(token.NAME, "d", Context(1, 0))
    p.addtoken(token.NAME, "e", Context(1, 0))
    p.addtoken(token.NAME, "f", Context(1, 0))
    p.addtoken(token.NAME, "g", Context(1, 0))
    p.addtoken(token.NAME, "h", Context(1, 0))
    p

# Generated at 2022-06-17 16:56:33.130848
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    from . import grammar
    from . import tokenize

    # Create a parser
    g = grammar.grammar
    p = Parser(g)

    # Parse a simple program
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("a = 1").readline):
        if p.addtoken(t.type, t.string, t.start):
            break

    # Check the result
    assert p.rootnode is not None
    assert p.rootnode[0] == g.symbol2number["file_input"]
    assert len(p.rootnode[1]) == 1
    assert p.rootnode[1][0][0] == g.symbol2number["stmt"]

# Generated at 2022-06-17 16:56:43.661900
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None

    p.setup(g.symbol2number["funcdef"])
    assert p.stack == [(g.dfas[g.symbol2number["funcdef"]], 0, (
        g.symbol2number["funcdef"], None, None, []))]
    assert p.rootnode is None

    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None



# Generated at 2022-06-17 16:56:53.642475
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)

# Generated at 2022-06-17 16:57:22.633782
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.push(g.symbol2number["expr"], g.dfas[g.symbol2number["expr"]], 0, None)
    assert p.stack == [(g.dfas[g.symbol2number["file_input"]], 0, (257, None, None, [])),
                       (g.dfas[g.symbol2number["expr"]], 0, (264, None, None, []))]
    p.push(g.symbol2number["expr"], g.dfas[g.symbol2number["expr"]], 0, None)

# Generated at 2022-06-17 16:57:29.896532
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("NEWLINE", "NEWLINE"), "file_input"])
    g.add_nonterminal("file_input", [])
    g.add_nonterminal("file_input", [("stmt", "stmt"), "file_input"])
    g.add_nonterminal("stmt", [("simple_stmt", "simple_stmt")])
    g.add_nonterminal("simple_stmt", [("small_stmt", "small_stmt"), ("NEWLINE", "NEWLINE")])
    g.add_nonterminal("small_stmt", [("expr_stmt", "expr_stmt")])

# Generated at 2022-06-17 16:57:39.648320
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    g.load_grammar("Grammar.txt")
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens("x = 1"):
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1
    assert p.rootnode.children[0].children[0].type == g.symbol2number["simple_stmt"]


# Generated at 2022-06-17 16:57:45.708841
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import driver
    from . import tokenize

    g = grammar.Grammar()
    g.load_grammar("Grammar.txt")
    p = Parser(g)
    p.setup()
    p.shift(token.NAME, "a", 1, (1, 0))
    p.shift(token.NAME, "b", 2, (1, 0))
    p.shift(token.NAME, "c", 3, (1, 0))
    p.shift(token.NAME, "d", 4, (1, 0))
    p.shift(token.NAME, "e", 5, (1, 0))
    p.shift(token.NAME, "f", 6, (1, 0))
    p.shift(token.NAME, "g", 7, (1, 0))


# Generated at 2022-06-17 16:57:55.284508
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Tokenize a string
    tokens = tokenize.generate_tokens("a = 1")
    # Feed the tokens to the parser
    for type, value, context in tokens:
        p.addtoken(type, value, context)
    # Check the result
    assert p.rootnode.type == grammar.syms.file_input
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == grammar.syms.stmt
    assert len(p.rootnode.children[0].children) == 1
    assert p.rootnode.children[0].children[0].type == grammar.sy

# Generated at 2022-06-17 16:58:05.949008
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:58:16.448752
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        p.addtoken(t.type, t.string, t.start)

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[1].value == "+"
    assert p

# Generated at 2022-06-17 16:58:26.232311
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import token
    from . import driver
    from . import convert
    from . import pytree
    from . import pygram
    from . import pytoken
    import sys
    import io
    import unittest
    import unittest.mock

    class TestParser(unittest.TestCase):
        def test_shift(self):
            # Test the method shift of class Parser
            # Create a mock object for the method convert
            mock_convert = unittest.mock.Mock(return_value=None)
            # Create a mock object for the class Grammar
            mock_grammar = unittest.mock.Mock(spec=grammar.Grammar)
            # Create a mock object for the class DFAS
            mock_dfas = unittest.mock.M

# Generated at 2022-06-17 16:58:38.564764
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[1], 2, (1, None, None, [Leaf(1, "a", None)]))]
    p.shift(2, "b", 3, None)
    assert p.stack == [(g.dfas[1], 3, (1, None, None, [Leaf(1, "a", None), Leaf(2, "b", None)]))]
    p.shift(3, "c", 4, None)

# Generated at 2022-06-17 16:58:52.773961
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))
    p.addtoken(token.NAME, "garply", (1, 0))

# Generated at 2022-06-17 16:59:44.212519
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Test the parser on a simple expression
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for type, value, start, end, line in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(type, value, (start, end)):
            break
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["expr"]
    assert len(p.rootnode.children[0].children) == 3
    assert p.rootnode.children[0].children[0].type == token.NUMBER

# Generated at 2022-06-17 16:59:53.525055
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    t = tokenize.generate_tokens(iter(["1", "2", "3"]).__next__)
    for type, value, context in t:
        p.addtoken(type, value, context)
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].value == "2"
    assert p.rootnode.children[2].value == "3"



# Generated at 2022-06-17 16:59:58.087804
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import tokenize

    # Test the classify method of the Parser class
    p = Parser(grammar.grammar)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar/Grammar")):
        p.addtoken(t[0], t[1], t[2])

# Generated at 2022-06-17 17:00:07.017178
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in driver.tokenize("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[1].value == "+"