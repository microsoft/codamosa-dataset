

# Generated at 2022-06-17 16:50:27.452597
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import tokenize

    # Test setup()
    p = Parser(grammar.grammar)
    p.setup()
    p.setup(grammar.grammar.start)
    p.setup(grammar.grammar.start + 1)
    p.setup(grammar.grammar.start - 1)
    p.setup(0)
    p.setup(1)
    p.setup(2)
    p.setup(3)
    p.setup(4)
    p.setup(5)
    p.setup(6)
    p.setup(7)
    p.setup(8)
    p.setup(9)
    p.setup(10)
    p.setup(11)
    p.setup(12)
    p.setup(13)

# Generated at 2022-06-17 16:50:34.517871
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:50:43.618904
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.ENDMARKER, "", (1, 5))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["expr"]
    assert len(p.rootnode.children[0].children) == 3
    assert p.root

# Generated at 2022-06-17 16:50:53.829390
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.addtoken(token.NAME, "e", None)
    p.addtoken(token.NAME, "f", None)
    p.addtoken(token.NAME, "g", None)
    p.addtoken(token.NAME, "h", None)
    p.addtoken(token.NAME, "i", None)
    p.addtoken(token.NAME, "j", None)
    p

# Generated at 2022-06-17 16:51:05.165273
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, (1, 2))
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [("a", "a", (1, 2), None)]))]
    p.shift(1, "b", 3, (1, 3))
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [("a", "a", (1, 2), None), ("b", "b", (1, 3), None)]))]


# Generated at 2022-06-17 16:51:15.163906
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import driver


# Generated at 2022-06-17 16:51:28.333189
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.ENDMARKER, "", (1, 5))
    assert p.rootnode[0] == "file_input"
    assert len(p.rootnode[1]) == 1
    assert p.rootnode[1][0][0] == "stmt"
    assert len(p.rootnode[1][0][1]) == 1
    assert p.rootnode[1][0][1][0][0] == "expr"

# Generated at 2022-06-17 16:51:37.845177
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    p.setup(g.symbol2number["funcdef"])
    assert p.stack == [(g.dfas[g.symbol2number["funcdef"]], 0, (g.symbol2number["funcdef"], None, None, []))]
    assert p.rootnode is None


# Generated at 2022-06-17 16:51:51.738369
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)
    p.addtoken(token.NAME, "fred", None)
   

# Generated at 2022-06-17 16:51:55.412678
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()



# Generated at 2022-06-17 16:52:08.145577
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import driver
    from . import tokenize
    from . import token

    g = grammar.Grammar()
    g.parse_grammar(driver.grammar)
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar.txt")):
        if t[0] == token.ENDMARKER:
            break
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode is not None

# Generated at 2022-06-17 16:52:18.908053
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    # Read a file and tokenize it
    f = open("Grammar/Grammar", "r")
    tokens = tokenize.generate_tokens(f.readline)
    # Feed the tokens to the parser
    for type, value, start, end, line in tokens:
        if p.addtoken(type, value, (start, end)):
            break
    # Get the parse tree
    tree = p.rootnode
    # Print the parse tree in a nice way
    driver.treetransform(tree)
    print(tree)

# Generated at 2022-06-17 16:52:25.057474
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    grammar = grammar.grammar
    parser = Parser(grammar)

    # Prepare for parsing
    parser.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if parser.addtoken(t[0], t[1], t[2]):
            break

    # Get the parse tree
    tree = parser.rootnode

    # Print the parse tree
    driver.printtree(tree)

# Generated at 2022-06-17 16:52:35.983535
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "if", None)
    p.addtoken(token.NAME, "x", None)
    p.addtoken(token.EQUAL, "=", None)
    p.addtoken(token.NAME, "y", None)
    p.addtoken(token.COLON, ":", None)
    p.addtoken(token.NEWLINE, "\n", None)
    p.addtoken(token.INDENT, "", None)
    p.addtoken(token.NAME, "pass", None)
    p.addtoken(token.DEDENT, "", None)
    p.addtoken(token.ENDMARKER, "", None)
    assert p

# Generated at 2022-06-17 16:52:43.022303
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import os
    import io
    import unittest
    from . import tokenize


# Generated at 2022-06-17 16:52:56.227148
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2 import driver

    g = driver.load_grammar("Grammar.txt")
    p = Parser(g)
    p.setup()
    p.addtoken(1, "a", (1, 0))
    assert p.stack[-1][2][3][0].value == "a"
    p.addtoken(2, "b", (1, 1))
    assert p.stack[-1][2][3][1].value == "b"
    p.addtoken(3, "c", (1, 2))
    assert p.stack[-1][2][3][2].value == "c"
    p.addtoken(4, "d", (1, 3))
    assert p.stack[-1][2][3][3].value == "d"
   

# Generated at 2022-06-17 16:53:09.133629
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)

    # Parse a simple expression
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(0, "", (2, 0))
    assert p.rootnode.type == grammar.syms.file_input
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == grammar.syms.stmt


# Generated at 2022-06-17 16:53:20.342708
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import token
    import io

    # Create a parser
    g = grammar.grammar
    p = Parser(g)
    p.setup()

    # Create a tokenizer
    readline = io.StringIO('x = 1\n').readline
    tok = tokenize.generate_tokens(readline)

    # Feed tokens to the parser
    for type, value, start, end, line in tok:
        if type == token.ENDMARKER:
            break
        p.addtoken(type, value, (start, end))

    # Check the result
    assert p.rootnode.children[1].value == '='
    assert p.rootnode.children[2].value == '1'

# Generated at 2022-06-17 16:53:31.782096
# Unit test for method push of class Parser
def test_Parser_push():
    """Test method push of class Parser"""
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, []))]
    p.push(2, (None, None), 0, None)
    assert p.stack == [(None, 0, (1, None, None, [])), (None, 0, (2, None, None, []))]
    p.push(3, (None, None), 0, None)

# Generated at 2022-06-17 16:53:43.692837
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", Context(1, 0, ""))
    p.addtoken(token.NAME, "bar", Context(1, 0, ""))
    p.addtoken(token.NAME, "baz", Context(1, 0, ""))
    p.addtoken(token.NAME, "qux", Context(1, 0, ""))
    p.addtoken(token.NAME, "quux", Context(1, 0, ""))
    p.addtoken(token.NAME, "corge", Context(1, 0, ""))
    p.addtoken(token.NAME, "grault", Context(1, 0, ""))

# Generated at 2022-06-17 16:53:59.984226
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.classify(token.NAME, "if", (1, 0))
    p.classify(token.NAME, "foo", (1, 0))
    p.classify(token.NAME, "foo", (1, 0))
    p.classify(token.NAME, "foo", (1, 0))
    p.classify(token.NAME, "foo", (1, 0))
    p.classify(token.NAME, "foo", (1, 0))
    p.classify(token.NAME, "foo", (1, 0))
    p.classify(token.NAME, "foo", (1, 0))
    p.classify(token.NAME, "foo", (1, 0))

# Generated at 2022-06-17 16:54:05.939121
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.push(g.symbol2number["file_input"], g.dfas[g.symbol2number["file_input"]], 0, None)
    assert p.stack == [(g.dfas[g.symbol2number["file_input"]], 0, (256, None, None, []))]

# Generated at 2022-06-17 16:54:12.051960
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:54:21.374172
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"
    g.keywords = {}
    g.tokens = {
        token.NAME: "NAME",
        token.NEWLINE: "NEWLINE",
        token.INDENT: "INDENT",
        token.DEDENT: "DEDENT",
        token.ENDMARKER: "ENDMARKER",
    }
    g.labels = {
        "NAME": (token.NAME, None),
        "NEWLINE": (token.NEWLINE, None),
        "INDENT": (token.INDENT, None),
        "DEDENT": (token.DEDENT, None),
        "ENDMARKER": (token.ENDMARKER, None),
    }
    g

# Generated at 2022-06-17 16:54:31.012086
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", (1, 0))
    p.addtoken(token.NAME, "bar", (1, 0))
    p.addtoken(token.NAME, "baz", (1, 0))
    p.addtoken(token.NAME, "qux", (1, 0))
    p.addtoken(token.NAME, "quux", (1, 0))
    p.addtoken(token.NAME, "corge", (1, 0))
    p.addtoken(token.NAME, "grault", (1, 0))
    p.addtoken(token.NAME, "garply", (1, 0))
    p.add

# Generated at 2022-06-17 16:54:34.689900
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Build a parser
    g = grammar.grammar
    p = Parser(g)

    # Test it
    p.setup()
    for type, value, context in tokenize.generate_tokens(open("Parser/parser.c")):
        if p.addtoken(type, value, context):
            break
    assert p.rootnode is not None

# Generated at 2022-06-17 16:54:40.351110
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    g.load_grammar("Grammar.txt")
    p = Parser(g)
    p.setup()
    # Test that pop() works correctly when the stack is empty
    p.pop()
    # Test that pop() works correctly when the stack is not empty
    p.push(g.symbol2number["file_input"], g.dfas[g.symbol2number["file_input"]], 0, None)
    p.pop()

# Generated at 2022-06-17 16:54:49.604822
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test/test_parser.py")):
        if p.addtoken(t.type, t.string, t.start):
            break
    assert p.rootnode is not None

# Generated at 2022-06-17 16:54:54.817799
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    def convert(grammar, node):
        return node

    p = Parser(grammar.grammar, convert)
    p.setup()
    for t in tokenize.generate_tokens(open("test.py")):
        p.addtoken(t[0], t[1], t[2])
    print(p.rootnode)

# Generated at 2022-06-17 16:55:01.058043
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.grammar

    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None

    p.setup(token.NAME)
    assert p.stack == [(g.dfas[token.NAME], 0, (token.NAME, None, None, []))]
    assert p.rootnode is None



# Generated at 2022-06-17 16:55:21.874917
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "a", (1, 0))
    p.addtoken(token.NAME, "b", (1, 0))
    p.addtoken(token.NAME, "c", (1, 0))
    p.addtoken(token.NAME, "d", (1, 0))
    p.addtoken(token.NAME, "e", (1, 0))
    p.addtoken(token.NAME, "f", (1, 0))
    p.addtoken(token.NAME, "g", (1, 0))
    p.addtoken(token.NAME, "h", (1, 0))

# Generated at 2022-06-17 16:55:29.786458
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "print", (1, 0))
    p.addtoken(token.LPAR, "(", (1, 5))
    p.addtoken(token.STRING, '"Hello, world"', (1, 6))
    p.addtoken(token.RPAR, ")", (1, 21))
    p.addtoken(token.NEWLINE, "\n", (1, 22))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode is not None
    assert p.rootnode.type == driver.syms.file_input

# Generated at 2022-06-17 16:55:41.213799
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.StringInput("1 + 2").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token

# Generated at 2022-06-17 16:55:47.023222
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Test for issue #15
    from . import grammar
    from . import tokenize

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("test/badsyntax.py")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None

# Generated at 2022-06-17 16:55:57.112075
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.FileInput("test/test_grammar.py")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert p.rootnode.children[0].children[0].type == g.symbol2number["simple_stmt"]

# Generated at 2022-06-17 16:56:07.346271
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    g.start = 257

# Generated at 2022-06-17 16:56:20.403913
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pygram import python_grammar
    from blib2to3.pytree import Leaf, Node
    from io import StringIO
    from typing import List, Tuple

    def lam_sub(grammar: Grammar, node: RawNode) -> Union[Node, Leaf]:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

   

# Generated at 2022-06-17 16:56:31.297361
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in driver.tokenize("1 + 2"):
        if p.addtoken(t.type, t.string, t.context):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER
    # Try another expression
    p.setup()

# Generated at 2022-06-17 16:56:44.015416
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar, tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.ENDMARKER, "", (1, 0))
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children == []

    p.setup()
    p.addtoken(token.NAME, "x", (1, 0))
    p.addtoken(token.ENDMARKER, "", (1, 0))
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1

# Generated at 2022-06-17 16:56:52.111476
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize
    from . import driver

    # Create a parser
    p = Parser(grammar.grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t[0], t[1], t[2]):
            break

    # Convert the syntax tree to Python objects
    driver.convert(p.rootnode)

    # Print the result of the conversion
    print(p.rootnode)

# Generated at 2022-06-17 16:57:17.862551
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Create a parser instance
    p = Parser(grammar)

    # Prepare for parsing
    p.setup()

    # Parse a simple expression
    for t in tokenize.generate_tokens("1 + 2"):
        if p.addtoken(t.type, t.string, t.start):
            break

    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[1].type == token.PLUS
    assert p.rootnode.children[2].type == token.NUMBER



# Generated at 2022-06-17 16:57:26.909364
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import driver

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]

# Generated at 2022-06-17 16:57:37.998102
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.push(1, (([(0, 0)], set([0])), {}), 0, None)
    assert p.stack == [(([(0, 0)], set([0])), {}), (0, 0, (1, None, None, []))]
    p.push(2, (([(0, 0)], set([0])), {}), 0, None)

# Generated at 2022-06-17 16:57:52.304337
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", (1, 0))
    p.addtoken(token.PLUS, "+", (1, 2))
    p.addtoken(token.NUMBER, "2", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    p.addtoken(token.ENDMARKER, "", (2, 0))

# Generated at 2022-06-17 16:58:03.090354
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    g = grammar.Grammar()
    g.parse_grammar(driver.grammar)
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(driver.sample_input):
        p.addtoken(t[0], t[1], t[2])
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].type == g.symbol2number["stmt"]
    assert len(p.rootnode.children[0].children) == 1

# Generated at 2022-06-17 16:58:15.013772
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"

# Generated at 2022-06-17 16:58:17.324319
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()


# Generated at 2022-06-17 16:58:26.600292
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar/Grammar")
    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    p.addtoken(token.NAME, "baz", None)
    p.addtoken(token.NAME, "qux", None)
    p.addtoken(token.NAME, "quux", None)
    p.addtoken(token.NAME, "corge", None)
    p.addtoken(token.NAME, "grault", None)
    p.addtoken(token.NAME, "garply", None)
    p.addtoken(token.NAME, "waldo", None)

# Generated at 2022-06-17 16:58:39.488644
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("NEWLINE", "NEWLINE"), "file_input"])
    g.add_nonterminal("file_input", [])
    g.add_nonterminal("file_input", [("stmt", "stmt"), "file_input"])
    g.add_nonterminal("stmt", [("simple_stmt", "simple_stmt")])
    g.add_nonterminal("simple_stmt", [("small_stmt", "small_stmt"), ("NEWLINE", "NEWLINE")])
    g.add_nonterminal("small_stmt", [("expr_stmt", "expr_stmt")])

# Generated at 2022-06-17 16:58:53.243062
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from blib2to3.pgen2 import tokenize

    class TestParser(unittest.TestCase):
        def setUp(self):
            from blib2to3.pgen2 import driver

            self.grammar = driver.load_grammar("Grammar.txt")
            self.parser = Parser(self.grammar)

        def test_addtoken(self):
            self.parser.setup()
            for type, value, start, end, line in tokenize.generate_tokens(
                "x = 1"
            ):
                self.parser.addtoken(type, value, (start, end, line))
            self.assertEqual(self.parser.rootnode.type, 1)

# Generated at 2022-06-17 16:59:42.173696
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize
    from . import token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in tokenize.generate_tokens(open("Grammar/Grammar")):
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None
    assert p.rootnode.type == g.symbol2number["file_input"]
    assert p.rootnode.children[0].type == token.INDENT
    assert p.rootnode.children[1].type == g.symbol2number["stmt"]
    assert p.rootnode.children[2].type == token.DEDENT

# Generated at 2022-06-17 16:59:53.111303
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(g.dfas[g.start], 0, (g.start, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()

    p.setup(g.start + 1)
    assert p.stack == [(g.dfas[g.start + 1], 0, (g.start + 1, None, None, []))]
    assert p.rootnode is None
    assert p.used_names == set()



# Generated at 2022-06-17 17:00:01.757951
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import tokenize
    from . import driver
    from . import token

    # Create a parser
    p = Parser(grammar.grammar)
    # Prepare for parsing
    p.setup()
    # Parse a simple expression
    for t in tokenize.generate_tokens(driver.FileInput("1+1").readline):
        if p.addtoken(t.type, t.string, t.start):
            break
    # Check the result
    assert p.rootnode.type == grammar.syms.expr
    assert len(p.rootnode.children) == 3
    assert p.rootnode.children[0].type == token.NUMBER
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].type == token

# Generated at 2022-06-17 17:00:08.950940
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 2, None)
    assert p.stack == [(g.dfas[g.start], 2, (g.start, None, None, [1, "a", None]))]
    p.shift(2, "b", 3, None)
    assert p.stack == [(g.dfas[g.start], 3, (g.start, None, None, [1, "a", None, 2, "b", None]))]
