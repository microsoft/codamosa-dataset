

# Generated at 2022-06-11 19:46:07.490326
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    import os
    import sys

    sys.path[0] = os.path.abspath(os.path.join(sys.path[0], ".."))
    try:
        from blib2to3.pgen2 import tokenize
    except ImportError:
        from .pgen2 import tokenize

    from . import driver

    class SliceTestCase(unittest.TestCase):
        # Use __slots__ to save memory.
        __slots__ = "grammar", "driver", "slices"


# Generated at 2022-06-11 19:46:16.641788
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.token import Parser
    from blib2to3.pytree import Leaf
    from blib2to3.pgen2.parse import ParseError

    g = Grammar(r"""
    root: a
    foo: NAME
    a: foo
        | NAME
    """)

    p = Parser(g)
    p.setup()

# Generated at 2022-06-11 19:46:18.775560
# Unit test for method push of class Parser
def test_Parser_push():
    print("# Unit test for method push of class Parser")
    print('# End of unit test')


# Generated at 2022-06-11 19:46:19.407859
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    raise NotImplemented

# Generated at 2022-06-11 19:46:30.511984
# Unit test for method pop of class Parser
def test_Parser_pop():
    import unittest

    class parser_pop_TestCase(unittest.TestCase):

        def test_0(self):
            # From test_grammar.
            from blib2to3.pgen2.grammar import _parse_grammar

            grammar = _parse_grammar(test_grammar, 'test_grammar')

            from blib2to3.pgen2 import driver, parse

            p = Parser(grammar)
            t = driver.Driver(grammar, convert=lam_sub)
            p.setup(start='atom')


# Generated at 2022-06-11 19:46:39.150813
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar.txt")
    p = Parser(grammar)

    # Test case 1
    token_list_1 = [
        (None, None, '(', '(', 1, 0, '', ''),
        (None, None, 'x', 'x', 1, 2, '', ''),
        (None, None, ')', ')', 1, 3, '', ''),
        (None, None, '\n', '\n', 2, 0, '', ''),
    ]

    # Simulate tokenizer
    for token in token_list_1:
        p.addtoken(token[0], token[1], token[2:6])


# Generated at 2022-06-11 19:46:43.618172
# Unit test for method setup of class Parser
def test_Parser_setup():
    import blib2to3.pgen2.driver

    g = blib2to3.pgen2.driver.load_grammar("Python.gram")
    g.start = "file_input"
    p = Parser(g)

    p.setup()
    assert p.stack == [(g.dfas["file_input"], 0, (256, None, None, []))]


# Generated at 2022-06-11 19:46:54.694039
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import symbol

    g = grammar.grammar
    p = Parser(g)
    p.setup(symbol.stmt)

    # The stack must be empty
    assert len(p.stack) == 0

    # Push a nonterminal
    p.push(symbol.testlist, g.dfas[symbol.testlist], 0, None)

    # The stack has the expected length
    assert len(p.stack) == 1

    # The stack has the expected contents
    assert p.stack[0][0][0] == g.dfas[symbol.testlist][0]
    assert p.stack[0][1] == 0

    # The value of p.rootnode is None
    assert p.rootnode is None

# Generated at 2022-06-11 19:46:58.150452
# Unit test for method push of class Parser
def test_Parser_push():
    # Define variables
    grammar = None
    convert = None
    start = None
    # Create an instance of class Parser
    self = Parser(grammar, convert)
    # Invoke method
    self.push(type, newdfa, newstate, context)



# Generated at 2022-06-11 19:46:59.474732
# Unit test for method classify of class Parser
def test_Parser_classify():
    # TODO: Implement it
    pass


# Generated at 2022-06-11 19:47:17.572709
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.pgen

    # Get a grammar instance
    grammar = blib2to3.pgen2.pgen.parse_grammar("Python", "3.6")

    # Create a parser instance
    parser = Parser(grammar)

    # Setup the parser to accept the given start symbol
    parser.setup(start=grammar.start)

    # Add a token
    token1 = (10, None, None) # 'def'
    parser.shift(token1[0], token1[1], 0, token1[2])

    # Expect the internal stack to contain the shifted token
    assert parser.stack == [(grammar.dfas[grammar.start], 0, (1, None, None, [Leaf(10, 'def', None)]))]

# Generated at 2022-06-11 19:47:30.579775
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest
    import unittest.mock

    class MockGrammar(unittest.TestCase):
        """Mock Grammar class for testing."""

# Generated at 2022-06-11 19:47:36.715899
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar, tokenize
    from .driver import Driver
    filename = "Grammar.txt"
    t = tokenize.generate_tokens(open(filename).readline)
    g = grammar.grammar
    p = Parser(g)
    d = Driver(t, g, p)
    d.wpprint()

if __name__ == "__main__":
    test_Parser_push()

# Generated at 2022-06-11 19:47:48.407409
# Unit test for method push of class Parser
def test_Parser_push():
    from pprint import pformat

    class Supergrammar(Grammar):
        symbol2number: Dict[Union[int, str], int]
        number2symbol: Dict[int, Union[int, str]]
        keywords: Dict[Text, int]

        def __init__(
            self,
            symbol2number: Dict[Union[int, str], int],
            number2symbol: Dict[int, Union[int, str]],
            keywords: Dict[Text, int],
            dfas: Sequence[Sequence[Sequence[Tuple[int, int]]]],
        ) -> None:
            self.symbol2number = symbol2number
            self.number2symbol = number2symbol
            self.keywords = keywords
            self.dfas = dfas

    grammar = Supergrammar

# Generated at 2022-06-11 19:47:57.745840
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Unit test for method addtoken of class Parser"""
    from ..pgen2.pgen import generate_grammar

    try:
        generate_grammar.write_tables("Grammar.txt", "Grammar.pickle")
    except FileExistsError as e:
        print(e)

    import pickle

    grammar = pickle.load(open("Grammar.pickle", "rb"))
    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NAME, "spam", Context(1, 4))
    assert p.rootnode
    assert p.rootnode[0].value == "spam"

# Generated at 2022-06-11 19:48:04.066084
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    p = Parser(grammar)
    p.setup()
    p.addtoken(1, 'spam', (1, 0))
    p.addtoken(4, '+', (1, 4))
    p.addtoken(1, 'eggs', (1, 5))
    p.addtoken(0, None, (1, 9))
    assert len(p.rootnode) == 3
    assert isinstance(p.rootnode, Node)
    assert p.rootnode.type == grammar.symbol2number['file_input']

# Generated at 2022-06-11 19:48:12.458313
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Input:
    #  q = '"', d = '%'
    #  def convert(grammar, node):
    #    assert node[3] is not None
    #    return Node(type=node[0], children=node[3], context=node[2])
    #  p = Parser(grammar, convert)
    #  p.setup()
    #  p.addtoken(token.ENDMARKER, None, (1,0))
    # Output:
    #  newnode = Node(2, [], (1,0))
    assert True

# Generated at 2022-06-11 19:48:22.776195
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import pprint
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.pgen as pgen

    p = pgen.ParserGenerator("Grammar.txt", "Grammar.pickle")
    p.generate_grammar(write_tables = 0)
    g = grammar.Grammar(p.grammar)
    #g.dump()
    p = Parser(g)
    p.setup()


# Generated at 2022-06-11 19:48:33.594123
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    def _pop(symbol: int) -> Sequence[Optional[Any]]:
        """Unit test for method pop of class Parser."""
        # If this is the first time, import the grammar.
        global _g
        if not _g:
            _g = grammar.Grammar()
        #
        p = Parser(_g)
        p.setup()
        while symbol >= 256:
            p.shift(symbol, None, 0, None)
            symbol = _g.dfas[symbol][1][0]
        else:
            p.shift(symbol, None, 0, None)
            p.pop()
        return p.stack

    _g = None

# Generated at 2022-06-11 19:48:45.543675
# Unit test for method setup of class Parser
def test_Parser_setup():
    """Test method setup of class Parser."""
    import io
    from . import grammar

    tokenize = token.tokenize(io.StringIO('foo = 5').readline)
    tokens = list(tokenize)
    gr = grammar.grammar
    p = Parser(gr)
    p.setup()
    for type, value, begin, end, line in tokens:
        p.addtoken(type, value, begin)
    result = p.rootnode
    assert result.value == 'file_input'
    assert result.children[0].value == 'stmt'
    assert result.children[0].children[0].value == 'simple_stmt'
    assert result.children[0].children[0].children[0].value == 'small_stmt'

# Generated at 2022-06-11 19:49:10.094458
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    class MyParser(Parser):
        def __init__(self, grammar: Grammar) -> None:
            self.grammar = grammar

    g = grammar.Grammar()
    g.labels = {}
    dfa = [[]]
    g.dfas = {"start": (dfa, set())}
    g.start = "start"
    p = MyParser(g)
    p.setup()
    p.push(12, dfa, 0, None)
    assert p.stack == [(dfa, 0, (None, None, None, [])), (dfa, 0, (12, None, None, []))], \
        'stack: %s' % (p.stack,)

# Generated at 2022-06-11 19:49:21.004700
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.parse import parse_grammar
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2 import token
    from io import StringIO
    from blib2to3.pytree import Leaf, Node
    g = parse_grammar(StringIO("""
      file_input: (NEWLINE | stmt)* ENDMARKER
      stmt: simple_stmt | compound_stmt
      simple_stmt: expr NEWLINE
      expr: NAME
      compound_stmt: if_stmt
      if_stmt: 'if' NAME ':' suite
      suite: simple_stmt
    """), Driver())
    p = Parser(g)
    p.setup()

# Generated at 2022-06-11 19:49:28.044391
# Unit test for method shift of class Parser
def test_Parser_shift():

    from .driver import Driver
    from . import pgen2_parse, pgen2_token

    driver = Driver(
        pgen2_parse.Parser, pgen2_token.Tokenizer, pgen2_token.NL_TOKEN, None
    )

    driver.setup()
    driver.addtoken(pgen2_token.NL_TOKEN, None, (1, 0))




# Generated at 2022-06-11 19:49:39.674364
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Tests if shifting of tokens is equivalent to the original grammar.

    This test is not completely accurate. We don't check if the lexer has
    correctly read in the tokens, only if the parser correctly recognizes
    the token types.

    """
    import os
    from . import driver

    # Each input string should generate exactly the same tokens as the
    # output string. The following string was obtained with the --dump
    # option of the original parser.py and should be the same for all
    # Python versions starting from Python 2.6

# Generated at 2022-06-11 19:49:46.199083
# Unit test for method pop of class Parser
def test_Parser_pop():
    from textwrap import dedent
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2 import parse
    from blib2to3.pgen2.grammar import Grammar
    drv = Driver()
    mod = parse(dedent("""\
    def f():
        is_python = True
    """), grammar=Grammar(drv.grammar, drv.symbol2label), start="file_input")
    assert str(mod) == "[file_input, [3, [[2, [def, [NAME, ['f'], [1, 4]], "

# Generated at 2022-06-11 19:49:50.192041
# Unit test for method pop of class Parser
def test_Parser_pop():
    # The following demonstrates the failure of method pop.
    p = Parser(Grammar())
    # The following demonstrates the failure of method pop
    p = Parser(Grammar())
    # The following demonstrates the failure of method pop.
    p = Parser(Grammar())

# Generated at 2022-06-11 19:50:00.908539
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest

    class ParseInvokeTokens(unittest.TestCase):
        def test_addtoken(self):
            p = Parser.Parser(Grammar.Grammar())
            p.setup()
            # Add a bad token
            self.assertRaises(Parser.ParseError, p.addtoken, -1, "spam", "context")
            # Add a good token
            self.assertFalse(p.addtoken(token.NAME, "name", "context"))
            # Add the endmarker
            self.assertTrue(p.addtoken(token.ENDMARKER, "", "context"))
            # Add a token after completion
            self.assertRaises(Parser.ParseError, p.addtoken, token.NAME, "spam", "context")

    unittest.main()

# Generated at 2022-06-11 19:50:09.734528
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import parse

    g = Grammar(parse.grammar_string)
    p = Parser(g)
    assert p.classify(token.NAME, "hello", (1, 0)) == p.grammar.keywords["hello"]
    assert p.classify(token.COMMENT, "hello", (1, 0)) == p.grammar.tokens[token.COMMENT]
    try:
        p.classify(token.NAME, "hello2", (1, 0))
    except ParseError:
        pass
    else:
        assert False, "expected ParseError"

# Generated at 2022-06-11 19:50:19.039699
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.pgen2.driver as driver

    def test(s: Text) -> Results:
        """Parse a simple expression and return the results."""
        result = driver.parse_string(s, True)
        assert (
            result is not None
        ), "Failed trying to parse {!r}.\nPgen output:\n{}".format(
            s, driver.dump_grammar()
        )
        return result

    assert test("x") == {"x": []}

    assert test("x + y") == {"x": [], "y": []}
    assert test("x + y - z") == {"x": [], "y": [], "z": []}

# Generated at 2022-06-11 19:50:29.156287
# Unit test for method push of class Parser
def test_Parser_push():
    from . import pgen2

    p = pgen2.load_grammar("Grammar/Grammar")
    py = pgen2.load_grammar("Grammar/Python.gram")

    samples = [
        "a=0",
        "a=1|b=2",
        "a = 3&b = 4",
    ]

    for s in samples:
        # Parse expression
        result = py.parse(s)
        assert result
        # Build abstract syntax tree
        p.setup()
        p.addtoken(token.INDENT, None, None)
        p.addtoken(token.EQUAL, None, None)
        p.addtoken(token.EQUAL, None, None)
        p.addtoken(token.DEDENT, None, None)
        # Must have exactly

# Generated at 2022-06-11 19:51:03.716048
# Unit test for method shift of class Parser
def test_Parser_shift():
    class DummyGrammar:
        def __init__(self, dfa):
            self.dfas = {0: dfa}

    class DummyConvert:
        def __call__(self, grammar, node):
            return node[0]

    p = Parser(DummyGrammar(([(1, 1)], {})), DummyConvert())
    p.setup()
    p.addtoken(0, 'hi', None)
    assert p.rootnode == 0

# Generated at 2022-06-11 19:51:08.051481
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver
    import io

    input_src = r"""
if a:
    pass
"""
    output_src = r"""
if a:
    pass
"""
    f = io.StringIO(input_src)
    g = driver.Driver(f, "xxx.py")
    p = Parser(g.grammar)
    p.setup()
    try:
        while True:
            if p.addtoken(*g.get_token()):
                break
    except ParseError as e:
        print(e)
        raise SystemExit(1)
    assert str(p.rootnode) == output_src

# Generated at 2022-06-11 19:51:17.931473
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import io
    import unittest
    import unittest.mock

    class _ParseError(unittest.TestCase):
        def test(self):
            with self.assertRaises(ParseError):
                p = Parser(unittest.mock.Mock())
                p.setup()
                self.assertNotRaises(ParseError, lambda: p.addtoken(0, None, Context(1)))
    fake_dfas = {0: (((0, 1),), {1: ((0, 1),)})}
    fake_labels = {0: (0, None)}
    p = Parser(unittest.mock.Mock(dfas=fake_dfas, labels=fake_labels))
    with io.StringIO() as f:
        f.write("")
       

# Generated at 2022-06-11 19:51:26.383861
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver
    from .grammar import Grammar
    from .pgen import generate_grammar

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    out = StringIO()
    driver.main("", ["-h"], out)
    output = out.getvalue()
    out.close()
    assert output.startswith("usage")

    out = StringIO()
    driver.main("", ["-m", "blib2to3", "-o", "NUL"], out)
    output = out.getvalue()
    out.close()
    assert output.startswith("Generating LALR")

    # read the grammar file
    grammar = Grammar(generate_grammar())

    p = Parser(grammar)

# Generated at 2022-06-11 19:51:34.919067
# Unit test for method push of class Parser
def test_Parser_push():
    from . import parser, tokenize, grammar
    from io import StringIO
    gr = grammar.Grammar()
    gr.dfas[0] = dfa
    gr.labels = grammardata.dfas[0][1]
    gr.keywords = getattr(grammardata, "keywords", {})
    gr.tokens = grammardata.tokens
    p = parser.Parser(gr)
    p.setup()
    f = StringIO("def test():\n    pass\n")
    p.tokenizer = tokenize.generate_tokens(f.readline)
    token = p.tokenizer.send(None)

# Generated at 2022-06-11 19:51:41.029028
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.grammar

    p = Parser(g)
    p.setup()
    p.addtoken(token.LBRACE, "{", None)
    p.addtoken(token.RBRACE, "}", None)

    assert p.rootnode[0] == symbol.file_input
    assert len(p.rootnode) == 1
    assert p.rootnode[0][0] == symbol.stmt
    assert len(p.rootnode[0]) == 1
    assert p.rootnode[0][0][0] == token.LBRACE
    assert p.rootnode[0][0][1] == "{"
    assert p.rootnode[0][0][2] is None
    assert p.rootnode[0][0][3] is None

# Generated at 2022-06-11 19:51:50.073110
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import unittest

    class ParserTestCase(unittest.TestCase):
        # This test case checks a trivial example to ensure the parser
        # functions as expected.
        grammar = r"""
        test: {print "Hello world!"}
        """

        def setUp(self):
            global tokenizer
            import blib2to3.pgen2.tokenize as tokenize

            def tokenize_func(s: Union[Text, bytes]) -> Sequence[Any]:
                # Create a generator which returns (type, value, start, end, line).
                return tokenize.generate_tokens(s)

            tokenizer = tokenize_func


# Generated at 2022-06-11 19:52:00.543920
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .grammar1 import Grammar

    def verify(
        tokens,
        expected_stack,  # type: Sequence[Sequence[Union[int, Text, Text]]]
        expected_result,  # type: Text
    ):
        g = Grammar(tokens, "", "")
        p = Parser(g)
        p.setup(1)
        for t, v, c in tokens:
            p.addtoken(t, v, c)
        assert p.stack == expected_stack
        assert str(p.stack) == expected_result

    # When adding a token, the stack is reduced to a single entry
    # with the new token included, and the corresponding node includes
    # the token.  The node is converted by the converter.

# Generated at 2022-06-11 19:52:12.562339
# Unit test for method push of class Parser
def test_Parser_push():
    from . import token
    from . import grammar

    def convert(grammar: Grammar, node: RawNode) -> Union[Node, Leaf]:
        """Convert a raw node and all its children to an abstract node."""
        newnode: Union[Node, Leaf] = None
        type, value, context, children = node
        if children:
            newchildren = []
            for child in children:
                newchild = convert(grammar, child)
                if newchild is None:
                    continue
                newchildren.append(newchild)
            if newchildren:
                newnode = Node(type=type, children=newchildren, context=context)
        else:
            newnode = Leaf(type=type, value=value, context=context)
        return newnode


# Generated at 2022-06-11 19:52:23.404809
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import symbols

    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "x", (1, 3))
    p.addtoken(token.COLON, ":", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (2, 0))
    p.addtoken(token.NAME, "print", (2, 0))
    p.addtoken(token.NUMBER, "42", (2, 6))
    p.addtoken(token.NEWLINE, "\n", (3, 0))
    p.addtoken(token.ENDMARKER, "", (4, 0))
    assert p.rootnode.type == symbols.file_

# Generated at 2022-06-11 19:53:41.160658
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Unit test for method addtoken of class Parser.

    See the module doc string for a standard usage sequence.

    """
    from . import grammar, token, driver

    g = grammar.Grammar()
    g.set_grammar(grammar.grammar)

    p = Parser(g)

    driver.driver(g, p)

    p.setup()
    p.addtoken(token.NAME, "myname", (1, 0))
    p.addtoken(token.LPAR, "(", (1, 5))
    p.addtoken(token.NAME, "spam", (1, 6))
    p.addtoken(token.NAME, "ham", (1, 11))
    p.addtoken(token.RPAR, ")", (1, 14))

# Generated at 2022-06-11 19:53:54.252287
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    import token

    def converter(grammar, node):
        if node[0] == grammar.symbol2number['funcdef']:
            name = node[3][0][1]  # The ast.FunctionDef is name[0]
            node = functiondef(name, node[3][1:-1], node[2])
            node.used_names = []  # Give the ast.FunctionDef a new name
            return node
        elif node[0] == grammar.symbol2number['arguments']:
            args, defaults, vararg, kwarg = node[3]
            node = arguments(args[0::2], node[2])
            node.used_names = []  # Give the ast.FunctionDef a new name
            return node
        else:
            return node


# Generated at 2022-06-11 19:54:05.833987
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, token

    # Create a grammar
    g = grammar.Grammar()
    g.start = "file_input"
    g.dfas = {
        "file_input": ([[(1, 1), (0, 1)], [(1, 2), (0, 2)], [(2, 3), (0, 3)]], {1: 1}),
        "stmt": ([[(3, 1)]], {1: 1}),
        "simple_stmt": ([[(2, 1)]], {1: 1}),
    }

# Generated at 2022-06-11 19:54:06.654472
# Unit test for method setup of class Parser
def test_Parser_setup():
    pass


# Generated at 2022-06-11 19:54:14.179297
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .pgen import generate_grammar
    from .driver import Driver

    grammar: Grammar = generate_grammar("Grammar.txt")
    parser: Parser = Parser(grammar)
    driver: Driver = Driver(None, parser)
    parser.setup()
    tok = token.NAME("foo")
    parser.addtoken(tok.exact_type, tok.string, tok.start)
    parser.pop()

# Generated at 2022-06-11 19:54:22.593075
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize
    import io

    p = Parser(grammar, lam_sub)
    p.setup()
    tokens = tokenize.generate_tokens(io.StringIO("1 + 2").readline)
    while True:
        try:
            t = next(tokens)
        except tokenize.TokenError:
            break
        if p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode.children[0].value == "1"
    assert p.rootnode.children[1].value == "+"
    assert p.rootnode.children[2].value == "2"


if __name__ == "__main__":
    import sys

    test_Parser_addtoken()

# Generated at 2022-06-11 19:54:34.217211
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.grammar import Grammar

    g = Grammar()
    g.add_production("S", ["a", "b", "c", "d", "e"])
    p = Parser(g)
    p.setup()
    p.addtoken(sym.a, None, None)
    assert p.stack == [(g.dfas[sym.S], 1, (sym.S, None, None, [('a', None, None, None)]))]
    p.addtoken(sym.b, None, None)
    assert p.stack == [(g.dfas[sym.S], 2, (sym.S, None, None, [('a', None, None, None), ('b', None, None, None)]))]
    p.addtoken(sym.c, None, None)

# Generated at 2022-06-11 19:54:45.684983
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import token
    from . import gram_3_4_8 as pgen

    def addtoken(p, type, value, context):
        try:
            if p.addtoken(type, value, context):
                print(p.rootnode)
        except ParseError as exc:
            print(exc.context)
            print(exc)

    p = Parser(pgen.grammar, pgen.convert)
    p.setup()
    addtoken(p, token.NUMBER, '1', (1, 1))
    addtoken(p, token.NUMBER, '2', (1, 1))
    addtoken(p, token.NUMBER, '3', (1, 1))
    addtoken(p, token.NEWLINE, '\n', (1, 1))

    p

# Generated at 2022-06-11 19:54:54.477277
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver

    grammar = Grammar(driver.grammar)
    p = Parser(grammar)
    p.setup()
    assert p.stack == [([[[(17, 1), (20, 3)], [(14, 4), (15, 5), (16, 6)], [(6, 7)],
                         [(0, 0)], [(0, 0)], [(0, 0)], [(0, 0)], [(0, 0)]], {1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6}], 0, (3, None, None, []))]
    p.setup()

# Generated at 2022-06-11 19:55:06.544351
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from blib2to3.pgen2.pgen import Grammar
    from . import driver
    from . import tokenize
    # Compute the first set for each rule
    grammar = Grammar()
    first = {}
    for k, v in grammar.dfas.items():
        states, first_ = v
        first[k] = first_
    # Create a tokenizer
    tokengen = tokenize.generate_tokens(open("test.py"))
    # Prepare the parser
    parser = Parser(grammar)
    parser.setup()
    tokenlist = []
    # Parse the tokens
    for type, value, start, end, line in tokengen:
        result = parser.addtoken(type, value, (start, end))