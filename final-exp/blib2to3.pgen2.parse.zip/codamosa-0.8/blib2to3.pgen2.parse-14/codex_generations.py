

# Generated at 2022-06-11 19:45:58.940629
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pytest
    from blib2to3.pgen2.token import INDENT, NAME
    from blib2to3.pgen2.grammar import Grammar

    def test_func(self):
        # This method is equivalent to the original pop method
        # This method tests with a grammar, not with the python grammar
        # First, the grammar is build
        tokens = {NAME:1}
        labels = {0: (INDENT, "<INDENT>"), 1:(NAME, "NAME")}
        symbols = {'name': 1}
        keyword = {'name': 1}
        dfas = {'name': ([[], [(0,0)], [(0,0)]], {0:0})}
        start = 'name'
        grammar = Grammar(tokens, labels, symbols, keyword, dfas, start)


# Generated at 2022-06-11 19:46:10.543032
# Unit test for method setup of class Parser
def test_Parser_setup():
    class Grammar_tee(Grammar):
        """Faked-up grammar to test with."""
        dfas: Sequence[DFAS] = []
        labels: Sequence[Tuple[int, Text]] = []
        keywords: Dict[Text, int] = {}
        tokens: Dict[int, int] = {}
        start: int = 0
    class Context_tee(Context):
        """Faked-up context to test with."""
        def get_lineno(self) -> int:
            return 0
        def get_end_lineno(self) -> int:
            return 0
        def get_column(self) -> int:
            return 0
    gram = Grammar_tee()
    #
    p = Parser(gram)
    #
    p.setup()
    #

# Generated at 2022-06-11 19:46:18.024581
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import sample_grammar

    g = sample_grammar.grammar
    p = Parser(g)
    p.setup()
    assert p.addtoken(token.IF, "if", (1, 1))
    assert p.addtoken(token.NAME, "x", (1, 1))
    assert p.addtoken(token.NAME, "y", (1, 1))
    assert p.addtoken(token.NAME, "z", (1, 1))
    assert p.addtoken(token.NAME, "z", (1, 1))
    assert p.addtoken(token.NAME, "z", (1, 1))
    assert p.addtoken(token.EQUAL, "=", (1, 1))
    assert p.addtoken(token.NUMBER, "0", (1, 1))
   

# Generated at 2022-06-11 19:46:21.102307
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser = Parser(Grammar())
    try:
        parser.pop()
    except IndexError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-11 19:46:25.016365
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver
    import sys

    driver.main(["-c", "from __future__ import print_function; print(3 + 3)"])
    result = sys.stdout.getvalue()
    assert result.strip() == "6"



# Generated at 2022-06-11 19:46:35.087595
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .tokenize import detect_encoding, generate_tokens

    def run_addtoken(self):
        # Concrete syntax tree node with a list of children
        tree = [2, 3, 4, [5, 6, 7]]
        stack = [(3, 0, tree)]
        # Shift a token
        type = 1
        value = "value"
        context = (1, 1)
        newstate = 5
        self.shift(type, value, newstate, context)
        stack[-1] = (stack[-1][0], newstate, stack[-1][2])
        tree.append([type, value, context, None])
        # Push a nonterminal
        type = 8
        newdfa = (3, 4, 5)
        newstate = 6

# Generated at 2022-06-11 19:46:43.697916
# Unit test for method pop of class Parser
def test_Parser_pop():
    class TestConvert(object):
        def __init__(self):
            self.called = 0
        def __call__(self, grammar, node):
            self.called += 1
            return None

    path = "blib2to3/pgen2/grammar.txt"
    with open(path, "rb") as f:
        g = Grammar(f)
    c = TestConvert()
    p = Parser(g, convert=c)

    p.setup()
    p.stack = [(g.dfas[g.start], 0, (g.start, None, None, []))]
    p.convert = c
    assert c.called == 0
    p.pop()
    assert c.called == 1

# Generated at 2022-06-11 19:46:55.232758
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import unittest
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.parse import ParseError

    class ParserTest(unittest.TestCase):
        def testPop(self):
            parser = Parser(Grammar(sys.version_info))
            statements = [
                "for thing in [1, 2, 3]: print(thing, end=' ') ; print()",
                "for thing in [1, 2, 3]: print(thing, end=' ')\n",
            ]
            for line in statements:
                parser.setup()
                tokens = generate_tokens(line)

# Generated at 2022-06-11 19:47:06.849605
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import tokenize, token
    from . import grammar

    import io

    # Verify that rootnode is set, and points to a leaf node
    def test_pop(source: Text) -> None:
        p = Parser(grammar.word_grammar)
        p.setup()
        for ttype, value, _, _, _ in tokenize.generate_tokens(io.StringIO(source).readline):
            p.addtoken(ttype, value, (0, 0))
        assert len(p.stack) == 0
        assert p.rootnode is not None
        assert isinstance(p.rootnode, Leaf)
        assert p.rootnode.type == token.NAME

    test_pop('if')
    test_pop('for')
    test_pop('dog')
    test_pop('cat')

# Generated at 2022-06-11 19:47:17.073023
# Unit test for method shift of class Parser
def test_Parser_shift():
    g = Grammar()
    p = Parser(g)
    p.setup()
    p.shift(1, 2, 3, 4)
    assert p.stack == [(None, 3, (None, None, None, None))]
    p.shift(1, 2, 3, 4)
    assert p.stack == [(None, 3, (None, None, None, None))]
    try:
        p.shift(5, 6, 7, 8)
    except ParseError:
        pass
    else:
        assert False, "should have raised ParseError"


# Generated at 2022-06-11 19:47:32.279502
# Unit test for method push of class Parser
def test_Parser_push():
    import sys
    import blib2to3.pgen2.driver

    src = """
for i in []:
    pass
    """.strip()

    driver = blib2to3.pgen2.driver.Driver(debug=False)
    driver._parse_grammar(sys.stdin, sys.stderr)
    print("printer.print_grammar(print_ptn)",
          file=sys.stderr)
    driver.grammar.printer.print_grammar(print_ptn=True)

    parser = Parser(driver.grammar, lam_sub)
    parser.setup()
    driver._parse_tokens(src, parser, sys.stderr)
    ast = parser.rootnode
    print(ast)

# Generated at 2022-06-11 19:47:41.330717
# Unit test for method setup of class Parser
def test_Parser_setup():
    import unittest
    import os
    import sys
    from .tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP, tokenize

    from . import grammar, token
    from io import StringIO

    class ParserTestCase(unittest.TestCase):
        """Unit tests for the Parser class."""

        def test_pickle(self):
            import pickle
            for proto in range(pickle.HIGHEST_PROTOCOL + 1):
                dfa = pickle.loads(
                    pickle.dumps(self.g.dfas[self.g.start], protocol=proto)
                )
                dfa[0][0] == [(0, 0)]


# Generated at 2022-06-11 19:47:53.723428
# Unit test for method pop of class Parser

# Generated at 2022-06-11 19:47:59.052279
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import dfa
    from . import tokens

    g = dfa.grammar
    p = Parser(g)
    tokens = tokens.tokens
    p.setup()
    for i in range(len(tokens)):
        t = tokens[i]
        while p.addtoken(t[0], t[1], t[2]):
            break
    assert p.rootnode is not None
    print(p.rootnode)

# Generated at 2022-06-11 19:48:06.337891
# Unit test for method shift of class Parser
def test_Parser_shift():
    import pgen2
    import pgen2.parse
    import pgen2.tokenize
    import pgen2.grammar

    sample = "block   : stmt+"
    f = open("sample_parser.txt", "w")
    print(sample, file=f)
    f.close()

    g = pgen2.parse.generate_grammar("sample_parser.txt")
    gr = pgen2.grammar.Grammar(g)
    tok = pgen2.tokenize.generate_tokens("sample_parser.txt")
    p = pgen2.parse.Parser(gr)
    p.setup()
    for t in tok:
        print(t)
        print(p.stack)
        p.addtoken(t[0], t[1], t[2])

# Generated at 2022-06-11 19:48:17.875555
# Unit test for method classify of class Parser
def test_Parser_classify():

    def testit(pattern):
        p = Parser(Grammar())
        type, value, context = pattern
        i = p.classify(type, value, context)
        assert 0 <= i < len(p.grammar.labels)
        t, v = p.grammar.labels[i]
        # print type, value, "->", t, v
        assert t == type
        if t != token.NAME:
            assert v == value

    for t in [
        token.NT_OFFSET,
        token.NEWLINE,
        token.INDENT,
        token.DEDENT,
        token.NAME,
        token.NUMBER,
        token.STRING,
        token.ENDMARKER,
    ]:
        testit((t, "", (1, 0)))


# Generated at 2022-06-11 19:48:30.345103
# Unit test for method pop of class Parser
def test_Parser_pop():
    import error
    import grammar, token, driver

    # Load the grammar
    g = grammar.Grammar(grammar.grammar, grammar.syms)
    p = Parser(g)
    p.setup()
    p.stack = [([[(0, 1)]], 0, 3)]
    p.stack.append(([[(0, 1)]], 0, 3))
    p.stack.append(([[(0, 1)]], 0, 3))
    p.stack.append(([[(0, 1)]], 0, 3))

    def test_nodes(nodes, value, context):
        assert value == nodes[0].value
        assert context == nodes[0].context

    def test_nodes2(nodes, value, context):
        assert value == nodes[0].children[0].value

# Generated at 2022-06-11 19:48:40.642025
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Testing method shift of class Parser"""
    test_grammar = Grammar()
    test_grammar.start = 1
    test_grammar.tokens = {1: 2, 2: 3}
    test_grammar.labels = [(1, "comment"), (2, "NAME"), (3, "NUMBER")]
    test_grammar.keywords = {}
    test_grammar.states = {
        0: [(1, 1), (2, 2), (1, 3), (2, 4)],
        1: [(0, 1)],
        2: [(0, 2)],
        3: [(0, 3)],
        4: [(0, 4)],
    }

# Generated at 2022-06-11 19:48:46.487622
# Unit test for method pop of class Parser
def test_Parser_pop():
    def lam_sub(grammar: Grammar, node: RawNode) -> NL:
        if node[0] == "test":
            raise ValueError("test")
        return Node(type=node[0], children=node[3], context=node[2])
    grammar = Grammar(grammar_def="""
        start: "test" | "test" "test"
    """)
    parser = Parser(grammar, lam_sub)
    parser.setup()
    parser.addtoken(token.NAME, "test", (1, 0))
    parser.addtoken(token.NAME, "test", (1, 0))
    pytree = parser.rootnode
    assert pytree is not None
    assert pytree.type == "start"
    assert pytree.children[0].type == "test"
    assert pytree

# Generated at 2022-06-11 19:48:56.096684
# Unit test for method push of class Parser
def test_Parser_push():
    import blib2to3.pgen2.driver as driver
    driver.main(['--no-python-mtime-check', '-o', '/tmp/test.pickle', '-n', 'test'])
    from blib2to3.pgen2.parse import load_grammar, test_grammar

    grammar = load_grammar('/tmp/test.pickle')
    parser = Parser(grammar)
    parser.setup()

    parser.push(260, parser.grammar.dfas[260], 0, Context(None, None))

    parser.push(261, parser.grammar.dfas[261], 0, Context(None, None))



# Generated at 2022-06-11 19:49:13.738851
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar(token))
    p.setup()
    x = RawNode(token.NAME, 'x', (1, 1), None)
    node = p.convert(p.grammar, x)
    assert isinstance(node, Leaf)
    assert node.value == 'x'
    assert node.context == (1, 1)
    assert node.type == token.NAME
    raise Exception("Parser class is not ready yet")

# Generated at 2022-06-11 19:49:23.097207
# Unit test for method push of class Parser
def test_Parser_push():
    import sys
    import os.path
    import blib2to3.pgen2.tracer as tracer
    import blib2to3.pygram as pygram

    def init(test_file_path: str) -> None:
        g = pygram.python_grammar
        g.update_abstract_token("NAME", "NAME", "name")
        tracer.trace_grammar(g, test_file_path)

    test_file_path = os.path.join(os.path.dirname(__file__),
                                  "test_Parser", "Python.trc")
    init(test_file_path)
    import blib2to3.pgen2.driver as driver
    from .tokenize import generate_tokens, TokenInfo
    import io


# Generated at 2022-06-11 19:49:33.367662
# Unit test for method shift of class Parser
def test_Parser_shift():
    g = Grammar()
    idents = g.symbol("identifier")
    names = g.symbol("name")
    tokens = g.symbol("token")
    g.add_production(idents, [names], None)
    g.add_production(idents, [], None)
    g.add_production(names, [tokens], None)
    g.add_production(names, [g.newline], None)
    g.add_production(tokens, [g.endmarker], None)
    p = Parser(g)
    p.setup(idents)
    p.addtoken(g.endmarker, "", None)
    assert p.rootnode[1] == [Leaf(g.endmarker, "", None)]

# Generated at 2022-06-11 19:49:38.413866
# Unit test for method classify of class Parser
def test_Parser_classify():
    p = Parser(Grammar())  # type: ignore
    p.grammar.keywords = {}
    p.grammar.tokens = {}
    p.grammar.tokens[token.NAME] = 2
    p.grammar.tokens[token.NEWLINE] = 3
    assert p.classify(token.NAME, "foo", Context(1, 1)) == 2
    assert p.classify(token.NEWLINE, "", Context(1, 1)) == 3
    assert p.classify(token.INDENT, "", Context(1, 1)) == 0

# Generated at 2022-06-11 19:49:49.357409
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar, token


# Generated at 2022-06-11 19:49:59.374966
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    g = driver.load_grammar()
    t = driver.load_tokens(['/*foo*/\n', 'while', '\n', '1'])
    p = Parser(g)
    p.setup()
    while t:
        res = p.addtoken(t.type, t.value, t.context)
        t.pop()
        if res:
            break
    assert len(p.rootnode[1]) == 1
    assert p.rootnode[1][0][0] == token.WHILE
    assert p.rootnode[1][0][1] is None
    assert not p.rootnode[1][0][2]
    assert len(p.rootnode[1][0][3]) == 1

# Generated at 2022-06-11 19:50:11.690811
# Unit test for method push of class Parser
def test_Parser_push():
    class FakeGrammar:
        def __init__(self):
            self.start = 0
            self.tokens = {}  # type: ignore
            self.symbols = {}  # type: ignore
            self.keywords = {}  # type: ignore
            self.dfas = {}  # type: ignore
            self.labels = {}  # type: ignore
            self.num_labels = 0

    class FakeNode:
        def __init__(self, value):
            self.value = value

    # A fake grammar and one fake Terminal node
    grammar = FakeGrammar()
    node1 = FakeNode(1)

    # A class with a fake method convert
    class FakeParser(Parser):
        def convert(self, grammar, node):
            return node

    p = FakeParser(grammar)
   

# Generated at 2022-06-11 19:50:19.936821
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import pgen2

    grammar = pgen2.driver.load_grammar("Grammar/Grammar")
    p = Parser(grammar)

    # Too few input tokens; error
    p.setup()
    try:
        p.addtoken(token.MINUS, "-", Context(1, 0))
    except ParseError as e:
        assert e.msg == "too much input"
        assert e.type == token.MINUS
        assert e.value == "-"
        assert e.context.lineno == 1

    # Illegal input token; error
    p.setup()
    try:
        p.addtoken(token.MINUS, "-", Context(1, 0))
    except ParseError as e:
        assert e.msg == "bad input"
        assert e.type == token.MIN

# Generated at 2022-06-11 19:50:26.853538
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from . import token

    class TestParserAddToken(unittest.TestCase):
        def setUp(self):
            self.parser = Parser(None)
            self.parser.grammar = Grammar(token)
            self.parser.setup()

        def test_doing_nothing(self):
            with self.assertRaises(ParseError):
                self.parser.addtoken(0, "", None)

    unittest.main()

# Generated at 2022-06-11 19:50:33.685128
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    gr = grammar.Grammar()
    p = Parser(gr)
    # The following token types are not checked and are assumed to work.
    # They are not checked because they are non-terminals.
    # NEWLINE, INDENT, DEDENT.
    # The following token types are not checked and are not assumed to
    # work.  They are not checked because they are trivial.  They are not
    # assumed to work because the token table does not have an entry for
    # them.
    # ENCODING, COMMENT, ERRORTOKEN, N_TOKENS

# Generated at 2022-06-11 19:51:14.595268
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, tokenize

    import io
    import sys

    type_map = {}
    for name, value in tokens.__dict__.items():
        if name[:2] != "T_":
            continue
        name = name[2:].lower()
        type_map[value] = name

    def parse(input):
        grammar = grammar.grammar
        p = Parser(grammar, lam_sub)
        p.setup()
        print("-" * 60)
        print("parse:", input)
        # s = StringIO.StringIO(input)
        # t = tokenize.generate_tokens(s.readline)
        t = tokenize.generate_tokens(io.BytesIO(input.encode("utf-8")).readline)

# Generated at 2022-06-11 19:51:20.197019
# Unit test for method classify of class Parser
def test_Parser_classify():
    class MockGrammar(object):
        start = 256
        tokens = {token.NAME: 257}
        labels = [
            (257, (token.NAME, "NAME")),
            (256, (token.NAME, "NAME")),
        ]
        keywords = {}
        dfas = {}

    grammar = MockGrammar()

    parser = Parser(grammar)
    assert parser.classify(token.NAME, "a", 0) == 257
    assert parser.classify(token.NAME, "NAME", 0) == 256
    assert parser.classify(token.NAME, "a", 0) == 257

# Generated at 2022-06-11 19:51:32.394147
# Unit test for method classify of class Parser
def test_Parser_classify():
    class MockGrammar(object):
        def __init__(self) -> None:
            self.tokens: Dict[int, int] = {}
            self.keywords: Dict[Text, int] = {}

    class MockContext(object):
        def __init__(self) -> None:
            self.__dict__ = {
                "node": None,
                "offset": None,
                "parent": None,
                "root": None,
            }

    context = MockContext()
    grammar = MockGrammar()
    grammar.tokens = {token.NAME: 258}
    grammar.keywords = {"name": 258}
    test_parser = Parser(grammar)
    # This should return a 258
    assert 258 == test_parser.classify(token.NAME, "name", context)

# Generated at 2022-06-11 19:51:40.588479
# Unit test for method setup of class Parser
def test_Parser_setup():
    import blib2to3.pgen2.driver
    d = blib2to3.pgen2.driver.Driver()
    g = d.load_grammar(d.grammar(), "blib2to3/pytree.gram")

    p = Parser(g, lam_sub)
    p.setup()
    assert len(p.stack) == 1

    p.setup(2)
    assert len(p.stack) == 1

# Generated at 2022-06-11 19:51:49.882025
# Unit test for method push of class Parser
def test_Parser_push():
    # Type information for the tests below
    from blib2to3 import pygram
    from blib2to3.pgen2 import driver
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2 import token

    grammar = pygram.python_grammar_no_print_statement
    tokens: Tuple[int, Sequence[str]] = (
        token.NAME,
        "foo",
        token.NEWLINE,
        "bar",
        token.NEWLINE,
    )
    type_token_to_label: Dict[int, int] = {
        token.NAME: grammar.tokens[token.NAME],
        token.NEWLINE: grammar.tokens[token.NEWLINE],
    }

# Generated at 2022-06-11 19:51:59.743139
# Unit test for method shift of class Parser
def test_Parser_shift():
    class MockConverter(object):
        def __init__(self) -> None:
            self.converted = []

        def __call__(self, grammar: Grammar, node: RawNode) -> Leaf:
            self.converted.append((grammar, node))
            return Leaf(node[0], node[1])

    gram = Grammar()
    conv = MockConverter()
    p = Parser(gram, conv.__call__)
    p.setup()
    p.shift(1, "a", 0, Context(0, 0))
    assert (p.stack[0][2][-1] == [Leaf(1, "a")])
    assert (conv.converted == [(gram, (1, "a", Context(0, 0), None))])

# Generated at 2022-06-11 19:52:08.510914
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .driver import Driver
    from . import parsetok

    # Build a parser
    p = Parser(Driver.make_grammar(), Driver.convert)
    p.setup()
    # Fake token and tokenizer
    tok_data = [
        # tok_type, tok_str, (tok_start, tok_end), tok_line
        (token.NAME, "__file__", (0, 0), 0),
        (token.NAME, "__name__", (0, 0), 0),
        (token.NAME, "__doc__", (0, 0), 0),
        (token.NAME, "__main__", (0, 0), 0),
        (token.NAME, "__file__", (0, 0), 0),
    ]


# Generated at 2022-06-11 19:52:17.447152
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import pgen, token
    from .driver import Driver
    from .convert import pickle_grammar, unpickle_grammar

    # Load the grammar
    driver = Driver(pgen.Parser('Grammar.txt'), token.tok_name)
    g = driver.grammar

    # Build a parser, which uses method classify in its constructor
    parser = Parser(g)
    # Verify the parser
    p = parser  # type: ignore
    assert p.classify(token.NAME, 'abc', None) == 1
    assert p.classify(token.NAME, 'for', None) == 5
    assert p.classify(token.NAME, 'or', None) == 1
    assert p.classify(token.EQUAL, '=', None) == 21

# Generated at 2022-06-11 19:52:26.233514
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import token
    from blib2to3.pygram import python_grammar_no_print_statement
    from . import driver as tokenize_driver

    driver = tokenize_driver.Driver()
    parser = Parser(python_grammar_no_print_statement)
    parser.setup()
    for _ in driver.tokenize_file('../Tests/Grammar/pass0.py'):
        token = next(driver)
        parser.addtoken(token.type, token.string, token.context)

# Generated at 2022-06-11 19:52:31.461122
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2 import tokenize
    from . import driver

    # Sample usage

    p = Parser(driver.grammar1)
    p.setup()
    for t in tokenize.generate_tokens(driver.sample_input1.__iter__()):
        if p.addtoken(t[0], t[1], t[2]):
            break
    if p.rootnode is not None:
        driver.dump_tree(p.rootnode)

# Generated at 2022-06-11 19:53:35.539180
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import os
    from . import grammar, tokenize
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    fname = os.path.join(os.path.dirname(os.path.dirname(__file__)), "test", "grammar1.txt")
    with open(fname, "rb") as f:
        data = f.read()
    tokens = list(tokenize.tokenize(BytesIO(data).readline))
    for i, t in enumerate(tokens):
        # print(p.stack)
        if p.addtoken(t.type, t.string, t.start):
            break
    else:
        assert 0, "too few tokens"

# Generated at 2022-06-11 19:53:42.339060
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)

    def to_node(type: int, value: Text, context: Context) -> Leaf:
        return Leaf(type=type, value=value, context=context)

    p.setup()

    for ttype, tstring, start, end, line in tokenize.generate_tokens(
        "print(x)"
    ):
        p.addtoken(ttype, tstring, (start, end, line))
    assert isinstance(p.rootnode, Leaf)

# Generated at 2022-06-11 19:53:54.573250
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import sample
    p = Parser(sample.grammar)
    n = sample.grammar.dfas[sample.grammar.start][0][sample.grammar.dfas[sample.grammar.start][1]][0][1]
    pause_on_shift = False
    for t in sample.tokens:
        p.shift(t[0], t[1], n, None)
        if t[1] == 'class':
            pause_on_shift = True
        if pause_on_shift:
            pause_on_shift = False
            assert p.stack[-1][2] == (sample.sym.classdef, None, None, [])
            assert p.stack[-1][1] == n

# Generated at 2022-06-11 19:53:58.015844
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar("test.cfg")
    p = Parser(g)
    p.setup()



# Generated at 2022-06-11 19:54:08.060024
# Unit test for method pop of class Parser
def test_Parser_pop():
    def convert(grammar, node):
        if node[0] == type:
            return ("root", node[3])
        else:
            return node
    type = 3

# Generated at 2022-06-11 19:54:19.726650
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Exercise addtoken and check for memory leaks"""
    from . import driver, tokenize

    def convert(grammar, node):
        """A simple converter, that only converts numbers"""
        if node[0] == 1:
            return token.NUMBER
        return node

    for _ in range(10):
        # Get the grammar
        g = driver.load_grammar("Python.asdl", convert)
        # Create parser for this grammar
        parser = Parser(g)
        # Prepare for parsing; syntax tree starts at symbol file_input
        parser.setup()  # setup() uses the default start symbol file_input
        # Tokenize input string
        tokens = tokenize.generate_tokens("1 + 2")
        # Parse tokens, convert to abstract nodes where possible
        for _, token, context in tokens:
            parser

# Generated at 2022-06-11 19:54:26.742877
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    g = grammar.grammar
    p = Parser(grammar=g)
    p.setup()

    p.addtoken(token.NAME, '', None)
    p.addtoken(token.OP, '', None)
    p.addtoken(token.NAME, '', None)
    p.addtoken(token.NEWLINE, '', None)

# Generated at 2022-06-11 19:54:36.754292
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    class MockGrammar():
        def __init__(self):
            self.dfas: List[DFAS] = []
            self.labels: List[Text] = []
            self.keywords: Dict[Text, int] = {}
            self.tokens: Dict[int, int] = {}
            self.start = 0

    mock_grammar = MockGrammar()
    mock_grammar.dfas = [
        ([[(1, 2)], [(2, 3)], [(3, 4)], [(4, 5)], [(5, 6)], [(6, 7)], [(0, 7)]], {})
    ]
    mock_grammar.labels = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"]
   

# Generated at 2022-06-11 19:54:44.425101
# Unit test for method shift of class Parser
def test_Parser_shift():
    par = Parser(Grammar())
    par.setup()
    par.shift(token.NAME, "name", 0, None)
    par.shift(token.NAME, "name", 0, None)
    par.shift(token.NAME, "name", 0, None)
    par.shift(token.NAME, "name", 0, None)
    par.shift(token.NAME, "name", 0, None)
    print(par.stack)


# Generated at 2022-06-11 19:54:53.374415
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import pprint
    from . import token, tokenize

    # Test data
    value = (
        "a = b + c\n"
        "d = e + f\n"
        "g = h + i\n"
        "j = k + l"
    )
    # Run tokenizer
    tokengen = tokenize.tokenize(io.BytesIO(value.encode("utf-8")).readline)
    # Get tokens
    tokens: Sequence[Tuple[int,Text]] = [(t[0],t[1]) for t in tokengen]
    grammar = Grammar(sys.modules[__name__].__file__.replace(".py", ".txt"))
    parse = Parser(grammar)
    parse.setup()