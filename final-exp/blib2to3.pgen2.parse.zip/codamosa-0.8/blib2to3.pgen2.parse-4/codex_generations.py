

# Generated at 2022-06-11 19:45:59.562142
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar(grammar_string)
    p = Parser(g)
    import pdb;pdb.set_trace()
    p.setup()
    print(p)



# Generated at 2022-06-11 19:46:11.251216
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    import pprint


    class FakeDriver:
        def __init__(self) -> None:
            self.token = token.NT_OFFSET + 1
            self.type = self.token


        def nexttok(self) -> Optional[Tuple[int, Text, Context]]:
            if self.token < token.NT_OFFSET + 5:
                self.token += 1
                self.type += 1
                return (self.type, None, None)
            else:
                return None


        def setgrammar(self, grammar) -> None:
            pass


    #    p = Parser(Grammar())
    #    p.setup()
    #    p.stack[-1] = (p.grammar.dfas[p.grammar.start],
    #                   0,

# Generated at 2022-06-11 19:46:17.225302
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    import io

    g = grammar.Grammar(io.StringIO(grammar.lark_samples))
    p = Parser(g)
    p.setup()
    p.addtoken(token.NEWLINE, '\n', (1, 0, ''))
    p.addtoken(token.NAME, "foo", (1, 0, ''))
    assert p.stack[0][2][3][0].value == "foo"
    p.addtoken(token.NEWLINE, '\n', (1, 0, ''))
    assert p.rootnode.value == "foo"

# Generated at 2022-06-11 19:46:28.479081
# Unit test for method classify of class Parser
def test_Parser_classify():
    #
    # Test that classify method of Parser maps tokens to labels
    #
    # Verify the method raises ParseError on unknown token
    #
    p = Parser(None);
    try:
        p.classify(0, 0, None)
        assert False # Should not be reached
    except ParseError:
        pass
    #
    # Define dummy token-to-label mapping (this is what Grammar.tokens would be)
    #
    p.grammar.tokens = {token.NUMBER:1}
    #
    # Verify known token is mapped to label
    #
    assert p.classify(token.NUMBER, 0, None) == 1
    #
    # Define dummy keyword-to-label mapping (this is what Grammar.keywords would be)
    #

# Generated at 2022-06-11 19:46:37.487814
# Unit test for method shift of class Parser
def test_Parser_shift():
    class MockConverter(object):
        def __init__(self, grammar, node):
            self.grammar = grammar
            self.node = node

        def __repr__(self):
            return "MockConvert({}, {})".format(self.grammar, self.node)

    class MockGrammar(object):
        def __init__(self, dfas: Dict[int, DFAS]):
            self.dfas = dfas

    class MockDFA(object):
        def __init__(self, states: Dict[int, List[Tuple[int, int]]]):
            self.states = states

    class MockContext(object):
        def __init__(self, lineno, offset):
            self.lineno = lineno
            self.offset = offset


# Generated at 2022-06-11 19:46:49.799726
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize
    from blib2to3.pgen2.tokenize import STRING, ENDMARKER, ERRORTOKEN, NEWLINE

    def shift_tokens(tokens: Sequence[Tuple[int, Text]], grammar: Grammar):
        """Shift the tokens and return the resulting root node.

        The tokens include:
        - terminal symbols and literals (strings without " or ')
        - tokens of type NAME
        - all other tokens are ignored.

        """
        parser = Parser(grammar)
        # Prepare to parse
        parser.setup()
        # Shift the tokens
        for type, value in tokens:
            # Shift the next token
            if type == NAME:
                # Check for reserved words
                pvalue

# Generated at 2022-06-11 19:46:56.229082
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from .pgen2 import tokenize
    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for type, value, context in tokenize.generate_tokens(open("Grammar.txt")):
        if p.addtoken(type, value, context):
            break
    assert p.rootnode

# Generated at 2022-06-11 19:47:07.493225
# Unit test for method push of class Parser
def test_Parser_push():
    # for string "A"
    grammar = Grammar()
    grammar.keywords = {'A': 3}
    grammar.labels = [(0, (0, None)), (1, (3, None)), (2, (1, None)), (3, (2, None))]
    grammar.start = 1
    grammar.tokens = {1: 2}
    grammar.dfas = {1: ([[(1, 0), (2, 0)], [(0, 1), (2, 0)]], {0: 0, 1: 1}), 3: ([[(1, 0), (2, 0)], [(0, 1), (2, 0)]], {0: 0, 1: 1})}
    parser = Parser(grammar)
    parser.setup(start=1)

    # The above should have set up the following,

# Generated at 2022-06-11 19:47:11.408178
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(Grammar(), None)
    p.push(1, 2, 3, 4)
    assert p.stack == [(2, 0, (1, None, 4, []))]

# Generated at 2022-06-11 19:47:12.657833
# Unit test for method shift of class Parser
def test_Parser_shift():
    pass

# Generated at 2022-06-11 19:47:24.170009
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import parser, grammar

    parser_instance = parser.Parser(grammar.parse_grammar('Python', 'Python-3.7'))
    parser_instance.setup()

    assert parser_instance.stack == []
    assert parser_instance.stack == []
    assert parser_instance.rootnode is None

# Generated at 2022-06-11 19:47:33.821762
# Unit test for method pop of class Parser
def test_Parser_pop():
    p = Parser(Grammar(
        start="start",
        dfas={
            "start": ([[(1, 1), (0, 2)], [(0, 3), (0, 3)], [(2, 3), (2, 3)],
                [(2, -1), (2, -1)]], {}),
            "x": ([[(3, 1), (3, -1)]], {}),
            "y": ([[(4, 1), (4, -1)]], {}),
        },
        labels={1: (256, "x"), 2: (256, "y"), 3: (token.NAME, None), 4: (token.NAME, None)},
        tokens={token.NAME: 3},
        keywords={},
    ))
    p.setup()

# Generated at 2022-06-11 19:47:40.914619
# Unit test for method shift of class Parser
def test_Parser_shift():
    class MyGrammar(Grammar):
        _tree_type = list
        _leaf_type = int

    grammar = MyGrammar("""
    start: a b c
    a: "a"
    b: "b"
    c: "c"
    """)
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(0, 'a', None)
    parser.addtoken(1, 'b', None)
    parser.addtoken(2, 'c', None)

# Generated at 2022-06-11 19:47:53.192693
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver
    from . import token

    # Stub for wrapper around dfa
    class DFA(object):
        def __init__(self, states, first) -> None:
            self.states = states
            self.first = first

    # Stub for a grammar
    class Grammar(object):
        def __init__(self, dfas) -> None:
            self.dfas = dfas

    # A dfa with one accepting state
    states = [(0, 1)]
    dfa = DFA(states, [])
    grammar = Grammar({1: dfa})

    # Create a Parser instance
    parser = Parser(grammar)
    parser.setup()

    # Test method push
    # Push a nonterminal
    parser.push(1, dfa, 0, None)
    # Pop a non

# Generated at 2022-06-11 19:48:02.297102
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest
    import os
    import sys
    from . import driver

    class TestParser(unittest.TestCase):
        def test_classify(self):
            grammar = driver.load_grammar("Python.g3")
            parser = Parser(grammar)
            parser.setup()
            self.assertEqual(1, parser.classify(token.NAME, "True", None))
            self.assertEqual(1, parser.classify(token.NAME, "False", None))
            self.assertEqual(-2, parser.classify(token.NAME, "None", None))
            self.assertEqual(-1, parser.classify(token.NAME, "OTHER", None))
            self.assertEqual(-1, parser.classify(token.NAME, "UNKNOWN", None))

# Generated at 2022-06-11 19:48:08.552559
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    p = Parser(None)
    p.grammar = {"start": 1, "labels": {1: (1, "foo")}, "keywords": {},
                 "dfas": {1: ([[(0, 1), (1, 1)]], {1: 1})}, "tokens": {1: 1}}
    p.setup()
    # XXX Very bogus test!
    assert p.addtoken(1, "foo", None) == True

# Generated at 2022-06-11 19:48:19.896513
# Unit test for method addtoken of class Parser

# Generated at 2022-06-11 19:48:33.196282
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token

    gram = grammar.Grammar()
    gram.symbol2number = {
        "<dummy>": 0,
        "<dummy2>": 1,
        "<dummy3>": 2,
        "<dummy4>": 3,
        "<dummy5>": 4,
    }
    gram.number2symbol = {
        0: "<dummy>",
        1: "<dummy2>",
        2: "<dummy3>",
        3: "<dummy4>",
        4: "<dummy5>",
    }
    gram.start = 0
    parser = Parser(gram)
    parser.stack = [(None, None, None)]
    parser.stack[0] = (None, 0, None)


# Generated at 2022-06-11 19:48:41.592619
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest
    import sys

    from . import grammar

    class ParserTest(unittest.TestCase):
        def setUp(self):
            self.p = Parser(grammar)
            self.p.setup()

        def test_keyword(self):
            for keyword in token.N_TOKENS:
                if isinstance(keyword, str):
                    s = keyword
                elif keyword in (token.INDENT, token.DEDENT):
                    s = "<INDENT>"
                elif keyword == token.ENDMARKER:
                    s = "<ENDMARKER>"
                else:
                    s = keyword[3:]

                if keyword in (token.INDENT, token.DEDENT):
                    continue


# Generated at 2022-06-11 19:48:52.555896
# Unit test for method pop of class Parser
def test_Parser_pop():

    class Grammar(object):
        def __init__(self):
            self.start = 1
            self._dfas = {
                1: None,
                2: (
                    [[(1, 0), (2, 1)], [(0, 0)], [(0, 1)]],
                    {0: 0, 1: 1},
                ),
            }
        @property
        def dfas(self) -> Dict[int, DFAS]:
            return self._dfas

    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.shift(1, "a", 1, None)

# Generated at 2022-06-11 19:49:01.073387
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Test method classify"""
    import sys

    def check(expected: int, value: Text, context=None) -> None:
        nonlocal ok
        ilabel = p.classify(token.NAME, value, context)
        print(ilabel)
        if ilabel == expected:
            ok = True
        else:
            ok = False

    p = Parser(sys.modules[__name__].__dict__["test_grammar"])
    check(1, "def")
    check(0, "print")
    check(0, "print", 0)



# Generated at 2022-06-11 19:49:09.908511
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    pgen = grammar.pgen

    p = Parser(pgen)
    p.setup(1)
    p.addtoken(0, "x", "")
    p.addtoken(2, "", "")
    p.addtoken(0, "y", "")
    p.addtoken(3, "", "")
    assert p.rootnode.type == 1
    assert p.rootnode[0].type == 0
    assert p.rootnode[1].type == 0
    assert p.rootnode[0].value == "x"
    assert p.rootnode[1].value == "y"

# Generated at 2022-06-11 19:49:15.728808
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = Grammar()
    parser = Parser(grammar)

    class dummy_context(object):
        pass

    token = dummy_context()
    token.type = 1
    token.value = "1"
    token.context = "context"

    assert parser.classify(token.type, token.value, token.context) == 1

# Generated at 2022-06-11 19:49:22.233745
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver

    tokenize = driver.tokenize
    parser = Parser(driver.grammar)
    parser.setup()

    # Shift a token
    parser.shift(token.NAME, 'foo', 0, Context(1, 0))
    # Shift a token that is not in the token list
    try:
        parser.shift(token.ERRORTOKEN, 'bar', 0, Context(1, 0))
    except ParseError:
        pass
    else:
        raise AssertionError("Invalid token was not detected")


# Generated at 2022-06-11 19:49:33.284123
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class DummyGrammar:
        pass
    dfa = DummyGrammar()
    dfa0 = ([(1, 1)], [])
    dfa1 = ([(2, 2)], [])
    dfa2 = ([(3, 3)], [])
    g = DummyGrammar()
    g.dfas = {1: dfa0, 2: dfa1, 3: dfa2}
    g.start = 1
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "1", None)
    p.addtoken(token.ADD, "+", None)

# Generated at 2022-06-11 19:49:35.997924
# Unit test for method push of class Parser
def test_Parser_push():
    from . import parser
    from . import dglloader

    p = parser.Parser(dglloader.load_grammar("Grammar/Grammar"))
    p.push(10, 0, 0, 0)

# Generated at 2022-06-11 19:49:46.531731
# Unit test for method shift of class Parser
def test_Parser_shift():
    import sys
    import blib2to3.pgen2.pgen

    def make_token(dfa, ctx):
        return dfa[0], dfa[1], ctx


# Generated at 2022-06-11 19:49:57.110191
# Unit test for method shift of class Parser
def test_Parser_shift():
    class TestConvert(object):
        def __init__(self, grammar):
            self.grammar = grammar

        def __call__(self, node):
            value = node[1]
            if node[0] == self.grammar.symbol2number["atom"]:
                return Leaf(type=token.STRING, value=str(value))
            return None  # pragma: no cover

    class TestGrammar(object):
        def __init__(self):
            self.labels = [
                (token.STRING, "test"),
                (token.NAME, "atom"),
                (0, "EOF"),
            ]
            self.keywords = {}
            self.symbol2number = {"atom": 1}
            self.dfas = {}

# Generated at 2022-06-11 19:50:02.077795
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .pgen import driver

    gr = driver.load_grammar("blib3")
    p = Parser(gr)
    s = 'blib foo\n'
    g = tokenize.generate_tokens(StringIO(s).readline)
    for tok in g:
        p.classify(tok[0], tok[1], Context(tok[2], tok[3]))

# Generated at 2022-06-11 19:50:03.349595
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(get_grammar_instance())
    p.setup()
    p.setup()
    p.setup()



# Generated at 2022-06-11 19:50:18.149034
# Unit test for method shift of class Parser
def test_Parser_shift():
    pygram = Grammar.from_file(tokenize.__file__.replace(".py", ".grammar"))
    pygram2 = Grammar.from_file(tokenize.__file__.replace(".py", ".grammar"))
    p = Parser(pygram)
    p.setup()
    x = []
    y = []
    with open(tokenize.__file__) as f:
        for type, value, start, end, line in tokenize.generate_tokens(f.readline):
            print((type, value, start, end, line))
            p.addtoken(type, value, start)
            x.append((type, value, start))
        for type, value, start, end, line in reversed(x):
            p.addtoken(type, value, start)
            y.append

# Generated at 2022-06-11 19:50:28.682943
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest

    from . import grammar
    from . import token

    g = grammar.Grammar(grammar.parse_grammar(grammar.start, grammar.dfas))

    p = Parser(g, lam_sub)
    p.setup()
    p.shift(token.INT, "1", 1, ('', 0))
    assert p.stack == [(g.dfas[g.start], 1, (g.start, None, None, [Node(type=token.INT, children=[Leaf(type=token.INT, value="1", context=('', 0))], context=('', 0))]))]

    p = Parser(g, lam_sub)
    p.setup()
    p.shift(token.INT, "1", 1, ('', 0))

# Generated at 2022-06-11 19:50:41.344343
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import unittest

    from . import grammar, tokenize

    def test_print_tokens(tokens: List[token.TokenInfo]) -> None:
        for t in tokens:
            print(t.type, repr(t.string), t.start, t.end, t.line)

    class TestParser(unittest.TestCase):
        def test_print(self) -> None:
            # Import the grammar module to get it initialized
            import os.path

            g = grammar.grammar
            p = Parser(g, convert=None)
            p.setup()
            # Build a list of input tokens
            src = r"""print(1, 2, 3, 4, 5, 6, 7, 8, 9, 0)"""

# Generated at 2022-06-11 19:50:51.775094
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import grammar

    # Make sure the test covers all relevant code.
    test_includes = ["def foo(x, y):", "  pass"]
    test_grammar = grammar.parse_grammar(grammar.grammar)

    parser = Parser(test_grammar)
    parser.setup()

    tokengen = tokenize.generate_tokens(("foo.py", "\n".join(test_includes)))
    while True:
        token_type, token_value, _, _, _ = next(tokengen)
        if token_type == token.ENDMARKER:
            break
        parser.addtoken(token_type, token_value, Context(("foo.py", 1, 0)))
    assert parser.rootnode is not None

# Generated at 2022-06-11 19:50:59.866981
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenizer

    parser = Parser(grammar.grammar)
    node: Leaf
    parser.setup()
    for t in tokenizer.tokenize("f(1)"):
        parser.addtoken(*t)
    root = parser.rootnode
    assert isinstance(root, Node)
    root.assert_valid()
    assert root.type == grammar.syms.power
    assert len(root.children) == 2
    node, = root.children
    assert isinstance(node, Leaf)
    assert node.type == token.NAME
    assert node.value == "f"
    node, = root.children[1]
    assert isinstance(node, Node)
    assert node.type == grammar.syms.trailer
    assert len(node.children) == 2
    node,

# Generated at 2022-06-11 19:51:01.591957
# Unit test for method setup of class Parser
def test_Parser_setup():
    assert Parser.setup(Helper("\n"))

# Generated at 2022-06-11 19:51:13.868226
# Unit test for method shift of class Parser
def test_Parser_shift():  # noqa
    import blib2to3.pgen2.grammar

    grammar = blib2to3.pgen2.grammar.Grammar(
        grammardata, symbol2number,  # type: ignore
    )
    parser = Parser(grammar)
    parser.setup()

    token_names = {
        # 'token1': 0,
        "token2": 1,
        "token3": 2,
        "token4": 3,
        "token5": 4,
        "token6": 5,
    }
    parser.grammar.tokens = token_names

    parser.shift(1, "token2", 0, Context(lineno=0, column=0))


# Generated at 2022-06-11 19:51:19.152585
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser = Parser(Grammar())
    parser.setup()
    parser.shift(2, 3, 4, 5)
    (t, n) = parser.stack[0]
    assert t[0] == 4
    assert n == (2, 3, 5, None)

# Generated at 2022-06-11 19:51:25.394282
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.token

    test_grammar = grammar.grammar(
        """
        s: i NAME
        """
    )

    test_token = blib2to3.pgen2.token

    p = Parser(test_grammar)
    p.setup()
    test_token.NAME = 1
    if p.addtoken(test_token.NAME, "hello", None):
        print("hey")
    else:
        print("you")

# Generated at 2022-06-11 19:51:33.784739
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    _grammar = grammar.grammar
    class converter:
        def __init__(self):
            self.num_calls = 0
        def __call__(self, _, node):
            self.num_calls += 1
            return node

    # Test that rootnode is set properly
    p = Parser(_grammar, converter())
    p.setup(start=1)
    p.addtoken(token.NEWLINE, '\n', None)

    node = p.stack.pop()[2]
    assert node[0] == 1
    assert node[3] == []

    assert p.rootnode == node

    # Test that rootnode is not set to None by calling pop
    p = Parser(_grammar, converter())
    p.setup(start=1)


# Generated at 2022-06-11 19:51:51.113085
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2 import driver, token

    def parse(grammar, start, tokenize, flags=0):
        p = driver.Driver(grammar, convert, flags)
        p.setup(start)
        results = {}
        for type, value, context in tokenize(sys.stdin):
            try:
                done = p.addtoken(type, value, context)
            except ParseError as err:
                print(err)
                break
            if done:
                results = p.rootnode
                break
        assert results
        return results

    convert = driver.Convert()
    grammar = driver.load_grammar("Grammar.txt")
    start = "file_input"


# Generated at 2022-06-11 19:52:01.155666
# Unit test for method shift of class Parser
def test_Parser_shift():
    import inspect
    import sys
    from .pgen2 import driver

    def type_text(text: str) -> Sequence[Tuple[int, Text]]:
        return [(token.STRING, t) for t in text.split()]

    def unparse(grammar: Grammar, tree: NL) -> str:
        return "".join(
            "".join(t) for t in driver.Driver(grammar, tree, convert=lam_sub).output
        )

    def test_parser(grammar_text: str, output_text: str, input_text: str) -> None:
        grammar = driver.load_grammar(inspect.cleandoc(grammar_text))
        parser = Parser(grammar, convert=lam_sub)
        parser.setup()

# Generated at 2022-06-11 19:52:08.546044
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver as pgen

    # Load parser
    grammar = pgen.load_grammar("Grammar.txt")
    parser = Parser(grammar)

    # Setup
    parser.setup()

    # We'll call the Parser's shift method manually from here
    # The shift method expects 3 parameters
    # 1) token type
    # 2) token value
    # 3) token context
    type = token.STRING
    value = "test"
    context = pgen.Ctx(1, 0)
    parser.shift(type, value, 0, context)
    s = parser.stack
    assert(s[0][1] == 1)

# Generated at 2022-06-11 19:52:17.472193
# Unit test for method push of class Parser
def test_Parser_push():
    # faked data for testing
    grammar = Grammar()
    newdfa = [
        [(0, 0)],
        [(0, 2)],
        [(1, 1)],
        [(0, 2)],
    ]
    newstate = 1
    context = Context(None, None)

    # create an instance
    p = Parser(grammar, lam_sub)
    p.setup()
    p.push(2, newdfa, newstate, context)
    assert p.stack == [(
        [
            [(0, 0)],
            [(0, 2)],
            [(0, 1)],
            [(1, 1), (1, 2)],
            [(0, 3)],
        ],
        0,
        (2, None, None, [])
    )]

# Generated at 2022-06-11 19:52:29.392915
# Unit test for method push of class Parser
def test_Parser_push():
    def shift(type: int, value: Optional[Text], newstate: int, context: Context) -> None:
        pass
    
    def pop() -> None:
        pass
    
    def convert(grammar: Grammar, node: RawNode) -> Sequence[Node]:
        pass
    
    class DFAS:
        def __init__(self, states: List[List[Tuple[int, int]]], first: Dict[int, int], labels: Dict[int, Tuple[int, Text]]) -> None:
            self.states = states
            self.first = first
            self.labels = labels
    
    class Grammar:
        pass
    
    class Context:
        pass
    
    # Setup
    grammar = Grammar()
    parser = Parser(grammar, convert)
    parser.shift

# Generated at 2022-06-11 19:52:42.638737
# Unit test for method push of class Parser
def test_Parser_push():
    class TmpGrammar:
        labels = [(1, None)]
        dfas = {
            2: ([[(0, 0)], [(1, 1), (0, 1)]], frozenset([1]))
        }  # type: Dict[int, Tuple[DFA, Set[int]]]
    g = TmpGrammar()
    p = Parser(g)
    p.setup(2)
    p.push(2, g.dfas[2], 1, None)

# Generated at 2022-06-11 19:52:49.009135
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Test method addtoken of class Parser
    from .parse import make_grammar

    gr = make_grammar()
    p = Parser(gr)

    # Test for the case where sequence of tokens is accepted by parser
    # and the sequence of tokens is read upto end
    p.setup()
    assert not p.addtoken(token.NUMBER, '1', None)
    assert not p.addtoken(token.PLUS, '+', None)
    assert not p.addtoken(token.NUMBER, '2', None)
    assert p.addtoken(token.ENDMARKER, '', None)
    assert p.rootnode is not None

    # Test for the case where sequence of tokens is accepted by parser
    # and the sequence of tokens is read upto end
    p.setup()
    assert not p.add

# Generated at 2022-06-11 19:52:53.542257
# Unit test for method setup of class Parser
def test_Parser_setup():
    class Foo(Parser):
        def __init__(self, grammar, convert=None):
            Parser.__init__(self, grammar, convert)

        def addtoken(self, type, value, context):
            pass  # stifle PyPy3

    foo = Foo(None)
    foo.setup()
    assert foo.rootnode is None
    assert foo.used_names == set()
    assert len(foo.stack) == 1


# Generated at 2022-06-11 19:53:03.291556
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Note: this needs to be updated if the _addtoken method changes
    class _Grammar:
        def __init__(self, start, dfas, dfa_states, labels, tokens, keywords):
            self.start = start
            self.dfas = dfas
            self.dfa_states = dfa_states
            self.labels = labels
            self.tokens = {1: 0, 2: 1, 3: 2, 4: 3}
            self.keywords = {'a': 4, 'if': 5, 'in': 6, 'input': 7, 'is': 8,
                             'while': 9, 'write': 10}

    def _convert(grammar, node):
        return None

# Generated at 2022-06-11 19:53:09.942392
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    raise p.pop()
    # p.addtoken(token.NAME, 'print', None)
    # p.addtoken(token.RPAR, ')', None)
    # Set object is mutable, and thus it is not hashable
    # in python dict
    # len(p.rootnode.used_names) == 1
    # assert 'print' in p.rootnode.used_names



# Generated at 2022-06-11 19:53:49.467973
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    p = Parser(grammar)
    node1 = (1, None, None, [])
    node2 = (2, None, None, [])
    node3 = (3, None, None, [])

    p.stack.append((0, 0, node1))
    p.stack.append((0, 1, node2))
    p.stack.append((1, 2, node3))
    p.rootnode = node1
    p.pop()

    assert p.stack == [(0, 0, node1)]
    assert p.rootnode == node2



# Generated at 2022-06-11 19:53:52.106873
# Unit test for method shift of class Parser
def test_Parser_shift():
    pass


# Generated at 2022-06-11 19:53:56.530431
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.pgen import generate_grammar
    g = generate_grammar("grammar.txt")

    p = Parser(g)
    p.setup()
    # Adding a token should call `shift`
    assert p.addtoken(token.NUMBER, 123, (1, 2))



# Generated at 2022-06-11 19:54:06.893653
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import token, tokenize
    from . import driver
    import io

    r = io.StringIO("a = b")
    tokens = tokenize.generate_tokens(r.readline)
    parser = driver.Driver(
        pgen.Grammar(grammar_file), convert=pgen.convert_node, log=None
    )
    for type, value, context in tokens:
        if parser.addtoken(type, value, context):
            break

    assert parser.rootnode.children == [Leaf(49, "a"), Leaf(52, "="), Leaf(49, "b")]
    assert parser.rootnode.used_names == {'b', 'a'}

# Generated at 2022-06-11 19:54:19.267788
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    import sys

    class MockContext(object):
        def __init__(self, lineno: int, offset: int) -> None:
            self.lineno = lineno
            self.offset = offset

        def __repr__(self) -> Text:
            return 'MockContext(lineno=%d, offset=%d)' % (self.lineno, self.offset)

    def test(token: List[Any], expected_node: Optional[Any]) -> None:
        g = grammar.Grammar()
        g.keywords = {'and': g.symbol2number('and_keyword')}

# Generated at 2022-06-11 19:54:26.833524
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Test case for a bug in the method pop of class Parser

    Check whether or not the root node is set
    """
    from . import grammar
    from . import driver

    p = Parser(grammar.op_grammar)
    p.setup()
    # add the endmarker
    p.addtoken(token.ENDMARKER, '', Context(1, 0, ''))
    p.pop()
    assert p.rootnode is not None, "Root node not set"

# Generated at 2022-06-11 19:54:36.831296
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from blib2to3.pgen2.tokenize import tokenize

    class TestTokenizer:
        def __init__(self, iterable):
            self.iterable = iterable

        def __iter__(self):
            return self

        def __next__(self):
            return next(self.iterable)

    def make_token(type, string, start, end, line):
        return (
            type,
            string,
            start,
            end,
            line,
        )

    grammar = Grammar(r"""hello: NAME NAME NAME
                           | hi NAME NAME
                           | hello NAME NAME NAME NAME
                           | name NAME NAME NAME
        """)

# Generated at 2022-06-11 19:54:46.513972
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pytest
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.parse import ParseError

    grammar = Grammar(grammar_pgen_output)
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.LPAR, "(", Context(1, 0))
    parser.addtoken(token.NAME, "x", Context(1, 1))
    parser.addtoken(token.RPAR, ")", Context(1, 2))
    parser.pop()
    parser.pop()
    parser.pop()
    with pytest.raises(ParseError):
        parser.pop()


# Generated at 2022-06-11 19:54:50.467348
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import pygram
    from . import pytree

    grammar = pygram.python_grammar_no_print_statement
    driver.ParserDriver(pygram.python_grammar_no_print_statement, pytree.convert).parse_string("print ('hello world')")

# Generated at 2022-06-11 19:54:53.621468
# Unit test for method push of class Parser
def test_Parser_push():
    # Test input
    newdfa = (((1, 1), ), {1: [(1, 0)]})
    newstate = 1
    context = Context(preceding=None, file="")
    # Test output
    dfa, state, node = Parser.push(None, newdfa, newstate, context)