

# Generated at 2022-06-11 19:45:58.485221
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = Grammar("")
    grammar.load("Grammar.txt")
    parser = Parser(grammar, convert=lam_sub)
    parser.setup()
    assert parser.classify(token.NAME, "a", (1, 0)) == 1
    assert parser.classify(token.NEWLINE, "b", (1, 0)) == 2
    assert parser.classify(token.INDENT, "c", (1, 0)) == 3
    assert parser.classify(token.DEDENT, "d", (1, 0)) == 4
    assert parser.classify(token.ENDMARKER, "e", (1, 0)) == 5
    assert parser.classify(token.ERROR_DEDENT, "f", (1, 0)) == 6

# Generated at 2022-06-11 19:46:08.898999
# Unit test for method shift of class Parser
def test_Parser_shift():
    class ParseError(Exception):
        pass
    class ErrorReportingParser(Parser):
        def shift(self, *args):
            "test for shift"
            try:
                super().shift(*args)
            except ParseError:
                t, v = args[:2]
                raise SyntaxError(t, v) from None
    def classify(type: int, value: Text, context: Context) -> int:
        pass
    def lam_sub(grammar, node):
        pass
    grammar = Grammar("")
    p = ErrorReportingParser(grammar, lam_sub)
    p.stack = [(None, 1, None)]
    p.shift("a", "b", 1, None)

# Generated at 2022-06-11 19:46:17.375376
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .driver import Driver, parse_tokens
    driver = Driver(convert=lam_sub)
    driver.prepare(r"""
        r = '\n'
        n = r'\n'
        print('ok')
    """.splitlines(True))
    grammar = driver.grammar
    convert = driver.convert

    def f(s: str) -> Results:
        tokens: Sequence[Tuple[int, Text, Context]] = parse_tokens(s)
        parser = Parser(grammar, convert)
        parser.setup()
        for type, value, context in tokens:
            parser.addtoken(type, value, context)
        return parser.rootnode.children


# Generated at 2022-06-11 19:46:24.864488
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = Grammar('test.pgen')
    parser = Parser(grammar)
    parser.setup()
    assert parser.addtoken(1, "2", (1, 0)) == False
    assert parser.addtoken(2, "3", (2, 0)) == False
    assert parser.addtoken(3, "4", (3, 0)) == False
    assert parser.addtoken(3, "5", (4, 0)) == True


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-11 19:46:35.046795
# Unit test for method shift of class Parser
def test_Parser_shift():
    import pytest

    # test 1
    # p.addtoken(...) -> p.classify(...); p.classify(...) -> p.grammar.tokens.get(...)
    with pytest.raises(ParseError, match=r"bad token"):
        pg = Grammar(token.tok_name)
        p = Parser(pg)
        p.shift(token.NUMBER, "0", 1, Context(None, None))
    # test 2
    with pytest.raises(ParseError, match=r"bad token"):
        pg = Grammar(token.tok_name)
        p = Parser(pg)
        p.shift(token.NAME, "abc", 1, Context(None, None))
    # test 3

# Generated at 2022-06-11 19:46:40.837622
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from blib2to3.pgen2.parse import ParseError

    p = Parser(Grammar())
    p.setup(1)
    try:
        p.addtoken(3, "3", (1, 0))
        assert 0, "Expected a ParseError"
    except ParseError as exc:
        assert exc.msg == "bad token"
        assert exc.type == 3
        assert exc.value == "3"
        assert exc.context == (1, 0)
    else:
        assert 0, "Expected a ParseError"

# Generated at 2022-06-11 19:46:53.443468
# Unit test for method push of class Parser
def test_Parser_push():  # for mypy (see followup issue in mypy tracker)
    class DummyGrammar(object):
        def __init__(self, dfas: Dict[int, DFAS], labels: Sequence[int]) -> None:
            self.dfas = dfas
            self.labels = labels
            self.start = 0

    cfg = DummyGrammar({1: ([[(0, 0), (1, 1)], [(0, 1)]], set([1]))}, [1])
    parser = Parser(cfg)
    parser.setup()
    parser.addtoken(1, 'name', Context(1, 0))
    assert parser.stack[-1] == (cfg.dfas[1], 1, (0, None, None, [Leaf(1, 'name', Context(1, 0))]))

# Generated at 2022-06-11 19:46:56.693027
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = Grammar()
    parser = Parser(grammar)
    type = token.NAME
    value = "name"
    context = None
    parser.classify(type, value, context)
    return True

# Generated at 2022-06-11 19:47:07.804672
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import blib2to3.pgen2.convert as convert
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.token as token
    from . import driver
    from . import tokenize
    from . import pytree
    from blib2to3.pgen2.tokenize import Untokenizer

    c = convert.Converter(convert.Driver(grammar.Grammar(sys.stdin), convert.MakeFakeRoot()))

    filename = "./blib2to3/pgen2/test_driver.py"
    fp = open(filename, "rb")
    #encoding = token.detect_encoding(fp.readline)
    (cltokens, _) = tokenize.generate_tokens

# Generated at 2022-06-11 19:47:15.718080
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver

    words = "abc def".split()
    p = Parser(driver.Grammar())
    p.setup()
    for w in words:
        p.addtoken(token.NAME, w, Context(1, 0))
    assert len(p.stack) == 1
    assert len(p.stack[0][2][3]) == len(words)
    assert p.rootnode is not None


# Testing functions

# Generated at 2022-06-11 19:47:33.090680
# Unit test for method pop of class Parser
def test_Parser_pop():
    class FakeGrammar:
        def __init__(self):
            pass


# Generated at 2022-06-11 19:47:41.583531
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # The test here is not very meaningful at this point; it just
    # parses a trivial grammar and checks that no exception is raised.
    # This test should be expanded to more thoroughly check the
    # parsing engine.  (The debugging support in the implementation
    # also should be removed as soon as the parser is known to be
    # working correctly.)
    from . import grammar

    class TreeGrammar(grammar.Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2label.update({
                "expr": self.new_symbol(),
                "term": self.new_symbol(),
                "factor": self.new_symbol(),
                "power": self.new_symbol(),
            })

    gr = TreeGrammar()

# Generated at 2022-06-11 19:47:54.044467
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from . import driver
    from . import tokenize

    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pygram.python_symbols import (
        varargslist,
        dotted_name,
        test,
        funcdef,
        classdef,
        import_as_name,
        atom,
        NAME,
        STRING,
        NUMBER,
    )
    import io

    d = {}
    # This test uses the grammar directly, because the test needs to
    # be able to modify the token values, but the Driver instance
    # created by driver.Parser() will give value as None.
    g = grammar.grammar

    # Build a list of tokens with a given type

# Generated at 2022-06-11 19:48:02.634257
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.parse import Parser
    from blib2to3.pgen2.tokenize import generate_tokens, COMMENT

    g = Grammar(r'''
    stmts: stmt+
    stmt: 'print' STRING
    ''')
    p = Parser(g)
    p.setup()
    for type, token, _, _, _ in generate_tokens(lambda L=iter('print "Hello World"'): next(L)):
        if type == COMMENT: continue
        p.addtoken(type, token, None)
    assert p.rootnode[0] == 'stmts'
    print(p.rootnode, repr(p.rootnode))

# Generated at 2022-06-11 19:48:13.667478
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .tokenize3 import generate_tokens, untokenize
    from . import driver

    def parse_one(text, convert=lam_sub):
        tokens = generate_tokens(text)
        parser = Parser(driver.grammar, convert)
        parser.setup()
        for type, value, context in tokens:
            parser.addtoken(type, value, Context(context))
        return parser.rootnode

    node = parse_one("x = 3")
    print(node)
    assert node.children[0].type == token.NAME
    assert node.children[0].value == "x"
    assert node.children[1].type == token.EQUAL
    assert node.children[2].type == token.NUMBER
    assert node.children[2].value == "3"


# Generated at 2022-06-11 19:48:23.534026
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    class MyParser(Parser):
        def __init__(self, *args):
            Parser.__init__(self, *args)
            self.addtoken = driver.log(self.addtoken)

    grammar = driver.load_grammar('Grammar/Grammar')
    start = grammar.symbol2number['single_input']
    p = MyParser(grammar)
    p.setup(start)
    p.addtoken(token.INDENT, None, Context(0, 0))
    p.addtoken(token.NEWLINE, None, Context(0, 0))
    p.addtoken(token.INDENT, None, Context(0, 0))
    p.addtoken(token.NEWLINE, None, Context(0, 0))

# Generated at 2022-06-11 19:48:33.687090
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    import unittest


# Generated at 2022-06-11 19:48:45.543254
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import pprint

    class GrammarStub(object):
        # Sample attributes required by Parser
        labels = [None, 'ID', 'EQ', 'annassign', 'NAME', 'COLON', 'COMMA', 'STAR', 'RPAR', 'RBRACK', 'LSQB', 'RSQB', 'PLUS', 'MINUS', 'SLASH', 'VBAR']

# Generated at 2022-06-11 19:48:56.352674
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    from . import grammar

    # Grammar from Python 2.2's Grammar/Grammar
    grammar.parse_grammar("Grammar.txt")
    # Test from Python 2.2's Lib/test/test_parser.py

# Generated at 2022-06-11 19:49:07.706216
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from blib2to3.pgen2.parse import ParseError
    p = driver.ParserDriver(driver.Grammar, True)
    p.setup()
    p.addtoken(1, "a", None)
    p.addtoken(2, "b", None)
    p.addtoken(3, "c", None)
    p.addtoken(4, "d", None)
    p.addtoken(5, "e", None)
    p.addtoken(4, "d", None)
    p.addtoken(5, "e", None)
    try:
        p.addtoken(5, "e", None)
        assert False, "Exception expected"
    except ParseError:
        pass
    assert p.rootnode is None


# Generated at 2022-06-11 19:49:27.759036
# Unit test for method pop of class Parser
def test_Parser_pop():
    from ..pgen2.parse import ParseError
    from ..pgen2.tokenize import generate_tokens, tokenize

    def parse_test(test_str: str) -> Node:
        tokens = list(tokenize(test_str))
        parser = Parser(Grammar())
        parser.setup()
        for type, val, context in tokens:
            if parser.addtoken(type, val, context):
                break
        return parser.rootnode

    assert parse_test("a = 1") == "a = 1"
    assert parse_test("a = 1 + 2") == "a = 1 + 2"
    assert parse_test("a = 1 +\n2 + 3") == "a = 1 +\n2 + 3"

# Generated at 2022-06-11 19:49:31.140196
# Unit test for method shift of class Parser
def test_Parser_shift():
    try:
        p = Parser(None)
        p.shift(1, 2, 3, None)
    except Exception as e:
        assert str(e) == "AttributeError: 'Parser' object has no attribute 'convert'"

# Generated at 2022-06-11 19:49:38.524645
# Unit test for method push of class Parser
def test_Parser_push():
    class Grammar:
        labels = [[1, x] for x in "abcd"]
        dfas: Dict[int, DFAS] = {
            0: ([[], [], [], [], []], {1: 0, 2: 1, 3: 2, 4: 3}),
            1: ([[(1, 4)], [(1, 4)]], {0: 1, 1: 2}),
            2: ([[(2, 4)], [(2, 4)]], {0: 1, 2: 2}),
        }

    p = Parser(Grammar())
    p.setup(0)
    p.addtoken(1, "a", 0)
    p.push(1, p.grammar.dfas[1], 1, 0)

# Generated at 2022-06-11 19:49:47.787550
# Unit test for method push of class Parser
def test_Parser_push():
    def add_ut_Parser_push_sub(subnode: RawNode) -> NL:
        subnode[3] = [RawNode(2, None, None, None), RawNode(3, None, None, None)]
        return Node(subnode[0], subnode[3], subnode[2])

    p = Parser(Grammar(token.NT_OFFSET), add_ut_Parser_push_sub)
    p.setup()
    p.addtoken(token.NAME, "NAME", None)
    p.addtoken(token.COLON, ":", None)
    p.addtoken(token.NAME, "NAME", None)
    assert p.rootnode[-1][-1][0] == 2

# Generated at 2022-06-11 19:49:58.148276
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import pgen2
    from . import token

    grammar = pgen2.driver.load_grammar("Parsing/Grammar/Grammar")
    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NAME, "def", Context(1, 0))
    p.addtoken(token.NAME, "func1", Context(1, 4))
    p.addtoken(token.LPAR, "(", Context(1, 9))
    p.addtoken(token.NAME, "a", Context(1, 10))
    p.addtoken(token.COMMA, ",", Context(1, 12))
    p.addtoken(token.NAME, "b", Context(1, 14))
    p.addtoken(token.RPAR, ")", Context(1, 16))


# Generated at 2022-06-11 19:50:10.100432
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Create a dummy instance of Table and grammar.Grammar
    class Table:
        dfas = {0: ([[(1, 1)]], {1: 0})}
        labels = [(256, 0)]
    grammar = Grammar(Table, None)
    # No convert argument
    p = Parser(grammar)
    # Call the method
    p.push(0, grammar.dfas[0], 1, None)
    p.pop()
    # The root node is the converted popnode
    assert p.rootnode is not None
    assert p.rootnode[0] == 256
    # The stack is empty
    assert not p.stack
    # Convert argument specified
    def convert(g: Grammar, n: RawNode) -> Optional[Node]:
        assert n[-1] is None

# Generated at 2022-06-11 19:50:19.256711
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Create the parser
    from . import pygram

    parser = Parser(pygram.python_grammar)
    # Prepare it for parsing (required)
    parser.setup()

    # Input tokens are:
    # EOS, NAME, NEWLINE, NUMBER
    # EOS is the end-of-statement token; it should be distinct from
    # the end-of-file token.  NUMBER is a number; NEWLINE is a blank
    # line.  NAME is an (unqualified) name.

    # Successfully parse a single-line statement
    parser.addtoken(token.NAME, "x", (1, 0))
    parser.addtoken(token.EQ, "=", (1, 2))
    parser.addtoken(token.NUMBER, "42", (1, 4))

# Generated at 2022-06-11 19:50:29.269136
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    from . import driver

    p = Parser(driver.grammar, driver.convert)
    p.setup()
    # Shift two tokens
    for i in range(2):
        p.addtoken(token.NAME, "x%s" % i, (1, i))
    # Push a node
    p.addtoken(token.PERCENT, "%", (1, 10))
    p.addtoken(token.NAME, "y0", (1, 11))
    p.addtoken(token.EQUAL, "=", (1, 13))
    # Shift another token
    p.addtoken(token.NAME, "z", (1, 15))
    # Reduce the pushed node
    p.addtoken(token.RPAR, ")", (1, 16))
    # Reduce the first production

# Generated at 2022-06-11 19:50:42.099274
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    from . import tokenize_rb
    from io import BytesIO

    def build_tokens(s):
        return list(
            tokenize_rb.tokenize(BytesIO(s.encode("utf-8")).readline)
        ) + [(0, "")]

    parser: Parser = Parser(grammar.grammar, driver.tuple2tree)
    parser.setup()
    #parser.stack = [(dfa, 0, (type, None, context, []))]
    parser.stack = [(None, 0, (None, None, Context(1, 1), []))]
    parser.pop()
    assert parser.rootnode is None

    # rootnode is set to newnode when the stack is empty

# Generated at 2022-06-11 19:50:52.658255
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class _Grammar(Grammar):
        labels = "ab"

        tokens = {"a": 1, "b": 2}

        dfas = {"a": ([[(2, 1)], [(0, 1), (1, 2)], [(0, 2)]], {1: 0, 2: 1}), "b": ([], {})}

        nonterminals = {}

        start = "a"

        symbols = {"a": 0, "b": 1}

    def _DummyConvert(grammar: Grammar, node: RawNode) -> NL:
        pass

    p = Parser(_Grammar(), _DummyConvert)
    p.setup()
    assert p.addtoken("a", None, None) is False
    assert p.addtoken("b", None, None) is True

# Generated at 2022-06-11 19:51:11.537647
# Unit test for method shift of class Parser

# Generated at 2022-06-11 19:51:15.675944
# Unit test for method pop of class Parser
def test_Parser_pop():
    p = Parser(Grammar())
    node = Node(type=1, children=[])
    p.stack.append(([], 0, node))
    assert p.stack == [([], 0, node)]
    p.pop()
    assert p.stack == []
    assert p.rootnode is node

# Generated at 2022-06-11 19:51:25.152993
# Unit test for method shift of class Parser
def test_Parser_shift():
    import array
    import StringIO
    from . import token, grammar, driver, parse

    # Convert a Grammar instance to a Parser instance
    pg = parser.Parser(grammar.grammar)
    # Convert a list of tokens to a tree.  This is the main entry point,
    # and all the goodness is there.
    tree = parse.parse(pg, "(1 + 2) * 3")
    print("tree", repr(tree))
    assert repr(tree) == 'Module(stmt=[Expr(value=BinOp(left=Num(n=1), op=Add(), right=Num(n=2)))])'

    # For unit-testing, the basic use case is:
    # Convert a list of tokens to a tree.  This is the main entry point,
    # and all the goodness is there.
    tokgen

# Generated at 2022-06-11 19:51:33.751011
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import grammar

    g = grammar.Grammar()
    drv = driver.Driver(g, g.dfas)
    p = Parser(g)

    # Good input
    teststr = "def f():\n\tpass\n"
    p.setup()
    for type, value, context in drv.tokenize(teststr):
        try:
            if p.addtoken(type, value, context):
                break
        except ParseError as err:
            raise SystemExit(err)
    else:
        assert False, "parse ended early"
    print(p.rootnode)

    # Bad input

# Generated at 2022-06-11 19:51:40.142051
# Unit test for method pop of class Parser
def test_Parser_pop():
    import unittest
    import textwrap
    class TestParser(unittest.TestCase):
        def setUp(self):
            from tools.fix2to3 import main as fix2to3
            from tools.grammar import get_grammar
            self.grammar = get_grammar('python')
            self.convert = fix2to3

        def tearDown(self):
            self.grammar = None
            self.convert = None

        # test the simplest possible case of an assign_stmt
        def test_simple_assign(self):
            from tools.driver import tokenize
            from io import StringIO
            from tools.pgen2 import token
            source = "a = 5\n"
            tokens = tokenize(StringIO(source))

# Generated at 2022-06-11 19:51:49.805748
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pytest
    from . import grammar, tokenize
    from . import pgen

    def test(input):
        # Setup
        pgen.generate_grammar("Python.asdl", "Python.txt")
        grammar = grammar.parse_grammar("Python.txt")
        parser = Parser(grammar)
        # Parse
        parser.setup()
        for ttype, value, context in tokenize.generate_tokens(input):
            parser.addtoken(ttype, value, context)
        return parser.rootnode
    def test2(input):
        # Setup
        pgen.generate_grammar("Python.asdl", "Python.txt")
        grammar = grammar.parse_grammar("Python.txt")
        parser = Parser(grammar)
        # Parse
        parser.setup

# Generated at 2022-06-11 19:51:57.866876
# Unit test for method shift of class Parser
def test_Parser_shift():
    class MockParser(Parser):
        def __init__(self, grammar: Grammar, convert: Optional[Convert] = None) -> None:
            self.grammar = grammar
            self.convert = convert or lam_sub
            self.stack = []
    from . import grammar

    g = grammar.Grammar(parser_.grammar)
    p = MockParser(g)
    assert p.stack == []
    p.shift(token.NUMBER, '3', 17, (3, 4))
    assert p.stack == [(g.dfas[257], 17, (257, None, (3, 4), []))]


# Generated at 2022-06-11 19:52:07.538314
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .driver import parse_tokens
    from . import grammar
    from . import pgen

    grammar = grammar.Grammar(pgen.parse_grammar(grammar.grammar_file))

    # an example of Parser.pop() use for parsing a simple input
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(1, 'a', 0) # push
    parser.addtoken(1, 'b', 0) # shift
    parser.addtoken(1, 'c', 0) # shift
    parser.addtoken(1, 'a', 0) # shift
    parser.addtoken(2, ';', 0) # pop
    parser.addtoken(3, '\n', 0) # shift
    assert parser.pop() == None
    print()
    assert parser.rootnode

# Generated at 2022-06-11 19:52:12.644422
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver

    g = driver.load_grammar("Grammar.txt")
    p = Parser(g)
    p.setup()
    p.addtoken(1, "print", None)

if __name__ == "__main__":
    test_Parser_shift()

# Generated at 2022-06-11 19:52:22.276516
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import grammar
    start = "file_input"
    grammar = grammar.grammar
    tokens = driver.Driver(grammar, None, None)
    tokens.add_special_cases(grammar)
    tokens.add_future(grammar)
    parser = Parser(grammar)
    parser.setup(start)
    tokens.set_parser(parser, start)
    with open("python/grammar.txt", "r", encoding="utf-8") as file:
        tokens.input(file.read())
    while True:
        try:
            tokens.token()
        except token.StopTokenizing:
            break
    assert tokens.rootnode is not None

# Generated at 2022-06-11 19:52:44.843420
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    def tokenize(input: str) -> Sequence[Tuple[int, str, Context]]:
        from .tokenize import generate_tokens

        tokens: List[Tuple[int, str, Context]] = []
        for t in generate_tokens(input.__iter__().__next__):
            tokens.append((t.type, t.string, t.start))
        return tokens

    # Parse a simple expression to check the parser engine
    p = Parser(Grammar())
    p.setup()
    for type, value, context in tokenize("1 + 2"):
        p.addtoken(type, value, context)
    rv = p.rootnode
    assert rv.type == 1  # number
    assert rv.children[0].value == "1"

# Generated at 2022-06-11 19:52:54.348656
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Unit test for method pop of class Parser."""
    # from pgen2 import parse
    from . import tokenize
    from . import driver
    from . import grammar

    #read and parse the grammar
    with open('../../../Grammar/Python.asdl', 'r') as f_asdl:
        gr = grammar.Grammar(f_asdl)
    #compile and test
    g = grammar.Grammar(grammar.compile_grammar(gr))
    text = 'if a: pass'
    dfa = g.dfas['file_input']
    state = 0
    nodes = []
    p = Parser(g)
    p.setup()
    t = tokenize.generate_tokens(text)

# Generated at 2022-06-11 19:53:03.663497
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # pylint: disable=unused-variable,unused-argument,redefined-argument-from-local
    def lam_sub(grammar, node):
        type, value, context, children = node
        if type == 1:  # "KEYWORD1"
            return Leaf(type=1, value=value, context=context)
        return Node(type=type, children=children, context=context)

    grammar = Grammar([], [0], ["1", "2", "3", "4"], [], [], ["KEYWORD1"], [])

    p = Parser(grammar, convert=lam_sub)
    assert p.stack == []
    assert p.rootnode is None
    assert p.used_names == set()

    # The parser has not yet been set up; p.addtoken should fail

# Generated at 2022-06-11 19:53:11.260236
# Unit test for method setup of class Parser
def test_Parser_setup():
    class DummyClass:
        "Dummy class for unit testing"
        pass
    x = DummyClass()
    x.grammar = DummyClass()
    x.grammar.start = 99
    x.grammar.keywords = {}
    x.grammar.tokens = {}
    x.grammar.dfas = {}
    x.grammar.labels = {}
    x.convert = None
    x.setup()
    assert x.stack[0][0] == ()
    assert x.stack[0][1] == 0
    assert x.stack[0][2][0] == 99


# Generated at 2022-06-11 19:53:21.366554
# Unit test for method classify of class Parser
def test_Parser_classify():
    import collections as cls
    from . import grammar

    g = grammar.Grammar(grammar.pgen_grammar)
    p = Parser(g)
    p.setup()

    assert p.classify(token.NUMBER, "1234", None) == cls.namedtuple(
        "Symbol", "name type"
    )._make(["NUMBER", 256])
    assert p.classify(token.NAME, "True", None) == cls.namedtuple(
        "Symbol", "name type"
    )._make(["NAME", 258])
    p.addtoken(token.NAME, "True", None)
    assert p.used_names == {"True"}


# Generated at 2022-06-11 19:53:30.009883
# Unit test for method pop of class Parser
def test_Parser_pop():

    def classify(t, v, c):
        return 7

    def convert(g, n):
        return n
    aParser = Parser(Grammar(), convert)
    aParser.stack = [[(1, 2), 3, [1, 2, 3]], [(5, 6), 7, [5, 6, 7]]]
    try:
        aParser.pop()
    except:
        assert False
    assert aParser.convert(1, 2) == 2
    assert aParser.stack == [[(1, 2), 3, [1, 2, [5, 6, 7]]]]

# Generated at 2022-06-11 19:53:40.877605
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in range(256):
        if t in g.tok_values:
            assert p.classify(t, None, None) == g.tok_values[t] == g.tokens[t]
        else:
            try:
                p.classify(t, None, None)
            except ParseError:
                pass
            else:
                assert 0  # Should have raised an exception
    rw = """
    False None True and as assert break class continue def
    del elif else except exec finally for from global if
    import in is lambda nonlocal not or pass raise return
    try while with yield
    """.split()
    for w in rw:
        assert p.classify

# Generated at 2022-06-11 19:53:54.000903
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    import warnings
    import pickle
    import sys
    import copy
    import os.path
    import operator

    import blib2to3.pgen2.driver
    import blib2to3.pgen2.parse
    import blib2to3.pgen2.pgen

    skip_files = ["badsyntax_3.7.py", "badsyntax_3.8.py", "badsyntax_future.py"]
    n_badsyntax = n_badindent = n_empty = n_skipped = 0

    class TestCase(unittest.TestCase):
        def work_it_all(this):
            for f in parser.grammar.symbol2number:
                if f not in skip_files:
                    this.check_file(f)


# Generated at 2022-06-11 19:53:57.032967
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar())
    p.shift("foo", "bar", "baz", "quux")
    assert p.stack == [("foo", "bar", "baz", None)]



# Generated at 2022-06-11 19:54:07.771489
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.conv import make_tree
    from blib2to3.pgen2 import driver

    parser = driver.make_parser()
    parser.setup()
    parser.addtoken(token.COLON, ":", Context(0, 0))
    parser.addtoken(token.WHITESPACE, " ", Context(0, 0))
    parser.addtoken(token.NEWLINE, "\n", Context(0, 0))
    parser.addtoken(token.INDENT, "", Context(0, 0))
    parser.addtoken(token.NAME, "a", Context(0, 0))
    parser.addtoken(token.NEWLINE, "\n", Context(0, 0))
    parser.addtoken(token.DEDENT, "", Context(0, 0))
    parser.add

# Generated at 2022-06-11 19:54:34.228074
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    s = """\
    aa = 'a'+
    bb = 'b'+
    ab = aa bb
    """
    from . import driver
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    tokens = driver.tokenize(s)
    for t in tokens:
        if p.addtoken(*t):
            break

# Generated at 2022-06-11 19:54:45.747598
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Extracted from test_Parser_addtoken of blib2to3/pgen2/driver.py"""
    from . import pgen

    grammar = pgen.read_grammar(pgen.DEFAULT_GRAMMAR)
    # Set up a simple validation function to test the tokens
    class Validate(object):

        def __init__(self, grammar: Grammar, test_tokens: Sequence[Any]) -> None:
            self.grammar = grammar
            self.test_tokens = test_tokens

        def convert(self, grammar: Grammar, node: RawNode) -> Optional[NL]:
            # Validate the token sequence
            assert self.test_tokens

# Generated at 2022-06-11 19:54:52.468857
# Unit test for method shift of class Parser
def test_Parser_shift():
    d = tree = Parser(Grammar())
    d.stack = [(d.grammar.dfas[1], 0, (1, None, None, [])),
               (d.grammar.dfas[2], 0, (2, None, None, []))]
    d.shift(2, 3, 4, 5)
    d.stack == [(d.grammar.dfas[1], 0, (1, None, None, [])),
                (d.grammar.dfas[2], 4, (2, None, None, []))]
    assert not d.stack[1][2][3][:]


# Generated at 2022-06-11 19:54:56.868066
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver

    g = driver.parse_grammar("Grammar/Grammar")

    p = Parser(g)
    p.setup()
    p.pop()

# Generated at 2022-06-11 19:55:05.248839
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar)
    p.used_names = set(['foo'])
    type = 1
    value = 'foo'
    newstate = 2
    context = Context(0, 1)
    node = (1, 2, 3, 4)
    stack = [(5, 6, node)]
    p.stack = stack
    p.shift(type, value, newstate, context)
    assert p.stack == stack
    assert p.used_names == set(['foo'])


# Generated at 2022-06-11 19:55:07.714916
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2.grammar import Grammar
    grammar = Grammar()
    parser = Parser(grammar)
    parser.push(1, [], 1, ())

# Generated at 2022-06-11 19:55:13.846521
# Unit test for method shift of class Parser
def test_Parser_shift():
    stack = [('dfa', 0, ('node', None, None, []))]
    global_convert = None
    parser = Parser(None, global_convert)
    parser.stack = stack
    parser.shift(token.NAME, 'func', 1, 'context')
    assert parser.stack == [('dfa', 1, ('node', None, None, [('NAME', 'func', 'context', None)]))]

# Generated at 2022-06-11 19:55:22.722454
# Unit test for method push of class Parser
def test_Parser_push():
    # Create a test grammar
    import pgen2.grammar
    import pgen2.token
    import pgen2.driver
    import io
    import sys
    import blib2to3.pgen2.parse as parse

    grmode = pgen2.driver.Expr("grmode = file('Grammar.txt')")
    grfile = grmode.file
    raw_grammar = pgen2.grammar.Grammar(grfile)
    grfile.close()

    # State 0 is a goal
    # State 1 has symbol 'spam'
    # State 2 has symbol 'eggs'
    # State 3 is a goal
    # State 4 is a goal
    T = pgen2.token
    state_stack = [(0, 0), (0, 0)]

# Generated at 2022-06-11 19:55:29.797680
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .pgen2 import generate_grammar, literals
    from . import grammar, tokenize

    with open("Grammar/Grammar.text") as f:
        g = generate_grammar(f)
    g.start = g.symbol2number["file_input"]
    p = Parser(g)
    p.setup()
    tokens = tokenize.generate_tokens(f)
    for tok in tokens:
        if tok[0] == token.ENDMARKER:
            break
        p.addtoken(*tok)
    assert g.number2symbol[p.rootnode.type] == "file_input"

# Generated at 2022-06-11 19:55:37.434416
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .driver import parse_string
    from .syms import SYM, token_map
    from . import grammar
    from . import pytree
    from . import tokenize
    from . import pgen
    from .pytree import Leaf

    import unittest
    import sys

    class TestParserPop(unittest.TestCase):
        def setUp(self):
            self.p = pgen.ParserGenerator("Grammar/Grammar")
            self.parser = Parser(self.p.build_grammar(convert=pytree.convert))
            self.parser.setup()
            self.driver = parse_string("", self.parser)
            #self.driver = Driver("", self.parser)
            self.grammar = self.parser.grammar