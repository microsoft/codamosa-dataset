

# Generated at 2022-06-11 19:45:53.470073
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, token
    from .pygram import python_grammar as p
    from .pygram import grammar_tokens as t

    p.setup_grammar()

    # Normal case
    g = grammar.Grammar(grammar=p.grammar, symbols=p.symbols, labels=p.labels)
    parse = Parser(g)
    parse.setup()

    a = (t.NAME, "a")
    b = (t.NAME, "b")
    c = (t.NAME, "c")

    parse.addtoken(a[0], a[1], None)
    parse.addtoken(p.grammar[1], None, None)
    parse.addtoken(b[0], b[1], None)

# Generated at 2022-06-11 19:46:00.607354
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    token_map = {
        1: 2,
        2: 3,
        3: 4,
        4: 5,
        5: 6,
        6: 7,
        7: 8,
    }
    parser = Parser(grammar, None)
    parser.setup()
    parser.shift(1, "1", 0, (1, 1))
    parser.shift(2, "2", 0, (2, 1))
    parser.shift(3, "3", 0, (3, 1))
    parser.shift(4, "4", 0, (4, 1))
    parser.shift(5, "5", 0, (5, 1))
    parser.shift(6, "6", 0, (6, 1))

# Generated at 2022-06-11 19:46:12.827524
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, tokenize
    from .driver import Driver
    from .parse import ParseError

    # Create a grammar instance
    g = grammar.grammar.copy()

    # Create a driver class
    class TestDriver(Driver):
        def __init__(self) -> None:
            Driver.__init__(self, g, convert=g.convert)

        def parse_tokens(self, input: Sequence[Any]) -> Node:
            self.setup()
            for t in input:
                if self.addtoken(t[0], t[1], (0, 0)):
                    break
            else:
                raise ParseError("not done yet", None, None, None)
            return self.rootnode

    drv = TestDriver()

    # Test #1: check raise error if bad token is input
   

# Generated at 2022-06-11 19:46:24.862602
# Unit test for method pop of class Parser
def test_Parser_pop():  # noqa: D401
    from . import driver as pgen
    import os
    import sys
    import pickle
    import io

    # Extract the grammar from the compiled parser module
    with open(pgen.__file__, "rb") as fp:
        header = fp.read(4)
        pyc = fp.read()
    if header != b"\x03\xf3\r\n":
        raise ValueError("Unsupported bytecode version.")
    code = pickle.loads(pyc[8:])
    # The driver module uses the built-in dir() function, so we need
    # to simulate an environment similar to the one under which it
    # runs.

# Generated at 2022-06-11 19:46:26.225557
# Unit test for method setup of class Parser
def test_Parser_setup():
    assert 1


# Generated at 2022-06-11 19:46:31.342756
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest
    import sys

    class Test(unittest.TestCase):
        def __init__(self, value):
            super().__init__()
            self.value = value

        def test_Parser_shift(self):
            # Test for method shift of class Parser
            self.assertEqual(self.value, 0)

    Test(0)

# Generated at 2022-06-11 19:46:34.963544
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.pgen import tokenize

    parser = Parser(Grammar())
    parser.setup()

    for ttype, value, context in tokenize():
        parser.addtoken(ttype, value, context)
    assert parser.rootnode is not None

# Generated at 2022-06-11 19:46:39.758240
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .driver import Driver
    from .parse import ParseError

    d = Driver()
    try:
        d.process_grammar(open("Grammar/Grammar", "r"))
    except ParseError:
        # For now, just move on if the grammar fails to parse
        pass
    p = Parser(d.grammar)
    p.setup()
    p.shift(1, "a", 0, "other")

# Generated at 2022-06-11 19:46:52.508081
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest

    class TestParser(unittest.TestCase):
        # Trivial test
        def test_trivial(self):
            from . import grammar, token
            p = Parser(grammar.Grammar())
            p.setup()
            self.assertEqual(p.addtoken(token.ENDMARKER, "", (1, 0)), True)
            self.assertIsNotNone(p.rootnode)

        # Test number tokens
        def test_numbers(self):
            from . import grammar, token
            p = Parser(grammar.Grammar())
            p.setup()
            self.assertEqual(p.addtoken(token.NUMBER, "1", (1, 0)), False)

# Generated at 2022-06-11 19:47:00.839614
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest
    import pprint
    from . import grammar
    from . import token

    class TestShift(unittest.TestCase):

        def test_shift(self):
            p = Parser(grammar.example)
            p.setup()
            p.addtoken(token.NAME, "this", None)
            p.addtoken(token.EQUAL, "=", None)
            p.addtoken(token.NAME, "that", None)
            p.addtoken(token.ENDMARKER, "", None)
            pprint.pprint(p.rootnode)

    unittest.main()

# Generated at 2022-06-11 19:47:16.636592
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    gr = grammar.Grammar()
    gr.load(['Parser', 'start', 'atom', 'atom_expr', 'power', 'term', 'expr', 'file_input'])
    ParseError = Parser.ParseError

    parser = Parser(gr, None)
    parser.setup()
    parser.shift(1, 'a', 1, None)
    parser.shift(2, 'b', 2, None)
    parser.shift(3, 'c', 3, None)



# Generated at 2022-06-11 19:47:23.220437
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = Grammar("mod_suite")
    p = Parser(grammar)
    p.setup()
    assert not p.addtoken(0, "", NL)
    assert p.addtoken(0, "", NL)
    assert not p.addtoken(0, "", NL)

# Generated at 2022-06-11 19:47:33.191000
# Unit test for method classify of class Parser
def test_Parser_classify():
    import pgen2.grammar
    import pgen2.tokenize
    import io
    import sys

    ref_grammar = pgen2.grammar.Grammar()
    p = Parser(ref_grammar)

    py_grammar = pgen2.grammar.Grammar(io.StringIO(pgen2.grammar.__file__))
    sys.modules[py_grammar.__name__] = py_grammar
    py_grammar.load(py_grammar.__name__)
    p = Parser(py_grammar)


# Generated at 2022-06-11 19:47:42.978447
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2.grammar import (
        Grammar,
        EmptyLabel,
        EmptyProduction,
        Nonterminal,
        Production,
        Symbol,
    )
    from blib2to3.pgen2.pgen import generate_grammar

    grammar: Grammar = generate_grammar("Grammar/Grammar", "test")
    parser = Parser(grammar)
    parser.setup()

    # test for symbols without equal symbols in the labels list
    dfa_0: DFA = [
        [(2, 0), (3, 2)],
        [(0, 1)],
        [(1, 2)],
        [(0, 3)],
    ]


# Generated at 2022-06-11 19:47:55.423360
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Create a parser instance
    grammar = Grammar(dedent('''
    options = comma_opt =
    options = comma_opt = assignment
    comma_opt = ','
    comma_opt =
    assignment = vars '=' testlist
    vars = NAME
    vars = '*'
    testlist = test
    testlist = test ','
    test = NUMBER
    '''))
    p = Parser(grammar)

    # Prepare for parsing
    p.setup()

    # Synthesize some tokens
    type, value, context = token.NUMBER, "42", (1, 1)
    type, value, context = token.NEWLINE, "", (1, 1)
    type, value, context = token.ENDMARKER, "", (1, 1)

    # Parse the tokens


# Generated at 2022-06-11 19:48:02.693453
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import tokenize
    from .grammar import grammar

    test_case = """
while 1:
    print 5
"""

    tokens = tokenize.generate_tokens(test_case)
    p = Parser(grammar)
    p.setup()
    for (type, value, start, end, line) in tokens:
        p.addtoken(type, value, (start, end))

    from blib2to3.pgen2 import tree

    t = tree.build_tree(p.rootnode)
    print(t)

# Generated at 2022-06-11 19:48:13.663422
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import tokenize
    import blib2to3.pgen2.driver
    # Get a grammar
    driver = blib2to3.pgen2.driver.Driver("Parser/Python.gram", "Grammar/Grammar")
    grammar = driver.grammar
    # Prepare a parser
    parser = Parser(grammar)
    # Use the same input as in test_tokenize
    with open("Lib/test/badsyntax_3131.py") as f:
        source = f.read()
        # Tokenize!
        tokens = list(tokenize.generate_tokens(lambda _: source))
    parser.setup()
    for t in tokens:
        if parser.addtoken(t[0], t[1], (t[2], t[3])):
            break

# Generated at 2022-06-11 19:48:23.558150
# Unit test for method shift of class Parser
def test_Parser_shift():
    from collections import namedtuple
    from . import grammar

    class ConcreteNode(namedtuple("_", "type value context children")):
        """Set children to None for tokens, list for symbols"""

    class AbstractNode(namedtuple("_", "type value context children")):
        """Set children to None for tokens, list for symbols"""

    def convert(grammar: grammar.Grammar, node: ConcreteNode) -> Optional[AbstractNode]:
        if node.children is not None:
            return AbstractNode(
                type=node.type,
                value=node.value,
                context=node.context,
                children=node.children,
            )
        elif node.type != token.ENDMARKER:
            return AbstractNode(type=node.type, value=node.value, context=node.context, children=[])

# Generated at 2022-06-11 19:48:26.977077
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .grammar import Grammar
    from . import token

    g = Grammar("""
    grammar: 'foo' bar
    bar: 'bar'
    """)

    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", None)
    p.addtoken(token.NAME, "bar", None)
    assert p.rootnode == Node("grammar", [Leaf("foo", None), Node("bar", [Leaf("bar", None)])])

# Generated at 2022-06-11 19:48:35.087356
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.token as token

    # Create a simple grammar
    symbols = '''
        expr: mulexpr ('+' mulexpr)*
        mulexpr: atom ('*' atom)*
        atom: '(' expr ')' | NAME
    '''
    gr = grammar.Grammar(symbols)

    # Initialize the parser engine
    p = Parser(gr)
    p.setup()
    p.addtoken(token.LPAR, '(', (1, 0))
    p.addtoken(token.NAME, 'a', (1, 1))
    p.addtoken(token.RPAR, ')', (1, 2))

# Generated at 2022-06-11 19:48:50.910534
# Unit test for method shift of class Parser
def test_Parser_shift():
    global g
    g = Grammar()
    p = Parser(g)
    p.setup()
    p.shift(2, 'VALUE', 4, 'CONTEXT')
    assert p.stack == [(g.dfas[1], 4, (1, None, None, ['VALUE']))]


# Generated at 2022-06-11 19:49:02.452792
# Unit test for method pop of class Parser
def test_Parser_pop():
    import unittest
    import sys
    from . import grammar
    from . import tokenize
    from . import driver
    from . import config

    class ParserTestCase(unittest.TestCase):
        def test_pop(self):
            parser = Parser(grammar)
            parser.setup()
            parser.addtoken(token.NAME, 'print', (1, 0))
            parser.addtoken(token.LPAR, '(', None)
            parser.addtoken(token.STRING,
                            "'hi'",
                            (1, 0)
                            )
            parser.addtoken(token.COMMA, ',', (1, 0))
            parser.addtoken(token.NEWLINE, '\n', (1, 0))
            parser.addtoken(token.NAME, 'x', (2, 0))

# Generated at 2022-06-11 19:49:10.876479
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, token
    from .pgen import driver

    g = driver.load_grammar("Grammar/Grammar", "Grammar/Grammar.txt")
    p = Parser(g, lambda g, t: t)
    p.setup()
    p.addtoken(token.NAME, "a", None)
    p.addtoken(token.NAME, "b", None)
    p.addtoken(token.NAME, "c", None)
    p.addtoken(token.NAME, "d", None)
    p.pop()

    print(p.rootnode)

# Generated at 2022-06-11 19:49:21.579773
# Unit test for method pop of class Parser
def test_Parser_pop():
    class TestGrammar:
        """Grammar with a single nonterminal.

        This is a minimal grammar for testing purposes.

        """


# Generated at 2022-06-11 19:49:32.848947
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .pgen import (
        generate_grammar,
        driver,
        load_grammar,
        load_grammar_lines,
        tokenmap_build,
    )
    from .parse import (
        ParseError,
        Parser,
        lam_sub,
        lam_nop,
        ParseTreeBuilder,
        ParseTreePrinter,
    )
    from .pygram import python_grammar
    from .pygram import python_symbols as syms
    from .pytoken import generate_tokens, tokenize_by_version, TokenInfo
    from .pytokenize import generate_tok_name, indentation_error
    import os
    import warnings

    #From test_Parser
    g = load_grammar(python_grammar)
    p = Parser(g)


# Generated at 2022-06-11 19:49:44.728378
# Unit test for method pop of class Parser
def test_Parser_pop():
    check = [
        # t, value, type, node_type, node_value, children
        [(0, 1, 256, 256, None, [])],
        [(0, 1, 257, 257, None, [])],
        [(0, 1, 257, 257, None, [(1, None, None, [(2, None, None, [])])])],
    ]
    FromList = lambda lst: [tuple([Node(type=n[0], children=n[3]) for n in row]) for row in lst]
    p = Parser(Grammar())
    for row in check:
        p.stack = FromList([row])
        p.pop()
        assert p.stack == FromList(check[:row.index(row[-1])])

# Generated at 2022-06-11 19:49:56.204511
# Unit test for method pop of class Parser
def test_Parser_pop():
    # This test is mostly useful for testing static type checking.  It
    # is forked off from an existing test, so it has some cruft in it
    # (e.g., the variable x), but that doesn't hurt anything.
    class MockGrammar:
        def __init__(self, labels: Sequence[Tuple[int, int]], start: int) -> None:
            assert labels
            self.start = start
            self.labels = [(type, None) for type, alt in labels]
            self.dfas = {start: ([(i, i) for i in range(len(labels))], set(labels))}

    # Make sure that if we try to shift a token right after reducing,
    # we don't end up in the wrong state
    # Don't shift the token, just reduce the rule
    m_

# Generated at 2022-06-11 19:50:04.090386
# Unit test for method classify of class Parser

# Generated at 2022-06-11 19:50:15.286961
# Unit test for method pop of class Parser
def test_Parser_pop():
    def test_convert(grammar, raw_node):
        # type: (Grammar, RawNode) -> Optional[Node]
        type, value, context, children = raw_node
        return Node(type, children, context)


    p = Parser(Grammar(open("Grammar.txt")))
    p.setup()
    p.push(4, ([[(4, 0), (9, 1)], [(0, 0)]], {0: 1}), 0, None)
    p.push(7, ([[(8, 0)], [(0, 0)]], {0: 1}), 0, None)
    p.shift(3, "bork", 1, None)
    p.shift(3, "bork", 1, None)
    p.shift(5, "+", 1, None)


# Generated at 2022-06-11 19:50:27.059762
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from .pgen import generate_grammar, Grammar
    import sys
    import os

    if sys.argv[1:]:
        grammarfile = sys.argv[1]
    else:
        grammarfile = os.path.join(os.path.split(driver.__file__)[0],
                                   'Grammar.txt')
        if not os.path.exists(grammarfile):
            grammarfile = os.path.join(os.path.split(__file__)[0],
                                       'Grammar.txt')
    modname, symbol, tokens, patterns, pdict, ndict = \
        generate_grammar(grammarfile)
    g = Grammar(modname, symbol, tokens, patterns, pdict, ndict,
                {}, {}, {}, {})


# Generated at 2022-06-11 19:50:57.435403
# Unit test for method push of class Parser

# Generated at 2022-06-11 19:51:10.925414
# Unit test for method push of class Parser
def test_Parser_push():
    from . import pygram, pytoken
    from . import pytree

    grammar = pygram.python_grammar
    p = Parser(grammar)
    t = pytoken.Token
    #
    p.setup(grammar.start)
    context = pytree.error_node_context

    # Use method push to push a nonterminal
    # p.push(type, newdfa, newstate, context)
    p.push(
        type=pygram.tokens.NAME,
        newdfa=grammar.dfas["NAME"],
        newstate=1,
        context=context,
    )

    # Check that the new nonterminal is on top of the stack
    assert p.stack[-1][0] == grammar.dfas["NAME"]



# Generated at 2022-06-11 19:51:14.338190
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = Grammar(token)
    parser = Parser(grammar)
    parser.setup()
    # Check that the first thing on the stack is a node
    assert parser.stack[0][2][-1] == []



# Generated at 2022-06-11 19:51:25.048884
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import tokenize, token

    class MyParser(Parser):
        def __init__(self):
            super().__init__(Grammar())
            self.add_production("start_symbol: 'a'", "")
        def classify(self, type: int, value: Optional[Text], context: Context) -> int:
            if type == token.DEDENT:
                return 1
            else:
                assert False, "Invalid type"
    t = tokenize.TokenInfo
    my_parser = MyParser()
    my_parser.setup()
    assert not my_parser.addtoken(token.DEDENT, " ", t(0, 0, 1, 0, ""))
    assert my_parser.addtoken(token.DEDENT, " ", t(0, 0, 1, 0, ""))
    assert my

# Generated at 2022-06-11 19:51:34.367183
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import tokenize
    from . import driver
    from . import grammar

    dfa = [
        [[(1, 0), (2, 0), (4, 0)], [(12, 0), (13, 0), (15, 0)]],
        [],
        [],
        [[(3, 0), (6, 0), (9, 0), (13, 0), (16, 0)]],
        [[(5, 0), (8, 0), (10, 0)]],
        [],
        [],
        [[(7, 0), (11, 0), (14, 0), (17, 0)]],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
    ]

# Generated at 2022-06-11 19:51:46.638478
# Unit test for method shift of class Parser
def test_Parser_shift():
    global result
    global i
    global newstate
    global node
    global rawnode
    global newnode
    result = []
    i = 0
    newstate = 0
    node = (1, 1, 1, 1)
    rawnode = (1, 1, 1, 1)

    def convert(grammar, rawnode):
        global result
        global i
        global newstate
        global node
        global rawnode
        result.append(raw_input(str(newstate)))
        i += 1
        newstate = 1

    p = Parser(None, convert)
    p.stack = [1, 2, 3]
    p.shift(1, 1, 1, 1)



# Generated at 2022-06-11 19:51:47.646722
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    pass


# Generated at 2022-06-11 19:51:52.282426
# Unit test for method pop of class Parser
def test_Parser_pop():
    p = Parser(Grammar())
    p.stack.append((None, None, None))
    # Method pop needs to be able to work with empty self.stack
    p.pop()
    assert p.stack == []

# Generated at 2022-06-11 19:51:54.347793
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Make sure we can instantiate this class
    assert Parser(Grammar())


# The test suite for this class

# Generated at 2022-06-11 19:51:56.794595
# Unit test for method pop of class Parser
def test_Parser_pop():
    p = Parser(Grammar())
    p.setup()
    p.pop()


# Generated at 2022-06-11 19:53:03.995698
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.token import tok_name
    from blib2to3.pytree import Leaf
    from blib2to3.pgen2 import tokenize

    def lam_sub(grammar, node):
        type, value, context, children = node
        return Leaf(tok_name[type], value or "")

    with open("Grammar.txt") as g:
        grammar = Grammar(g.read())
    parser = Parser(grammar, lam_sub)
    parser.setup()
    assert parser.stack == [
        (grammar.dfas[grammar.start], 0, (grammar.start, None, None, []))
    ]
    tokens = list(tokenize.generate_tokens("1 + 2"))

# Generated at 2022-06-11 19:53:06.749059
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import io
    import unittest

    import blib2to3.pgen2.tokenize

    from . import grammar


# Generated at 2022-06-11 19:53:13.458196
# Unit test for method classify of class Parser
def test_Parser_classify():
    import sys

    if sys.version_info >= (3, 8, 0):
        import blib2to3.pgen2.tokenize as tokenize
    else:
        import tokenize as tokenize

    from . import grammar, token

    p = Parser(grammar.grammar)

    def f(s):
        return p.classify(*next(tokenize.generate_tokens(iter(s).__next__)))

    assert f('pass\n') == token.PASS
    assert f('PASS\n') == token.NAME
    assert f('pass') == token.NAME



# Generated at 2022-06-11 19:53:22.588219
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar
    import os

    f = os.path.join(
        os.environ['srcdir'],
        'Modules',
        'blib2to3',
        'pgen2',
        'Grammar.txt',
    )
    g = Grammar(f)
    p = Parser(g)
    p.setup()
    # test invalid type
    try:
        p.pop()
    except AssertionError:
        pass
    # test valid type
    p.stack.append(([], 0, (17, None, None, [token.NAME, "foo"])))
    p.pop()


# Generated at 2022-06-11 19:53:27.173056
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Test unit test
    prs = Parser(Grammar())
    prs.setup()
    assert prs.addtoken(3, "", Context("", 1, 1))
    assert not prs.addtoken(3, "", Context("", 1, 1))
    assert not prs.addtoken(4, "", Context("", 1, 1))
    try:
        prs.addtoken(3, "", Context("", 1, 1))
        assert False, "should raise ParseError"
    except ParseError:
        pass

# Generated at 2022-06-11 19:53:38.860097
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from .pgen2.pgen import driver

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    # Push "expr"
    p.push(g.symbol2number['expr'], g.dfas[g.symbol2number['expr']], 0, Context())
    # Push a token
    p.addtoken(g.number2token[g.symbol2number['NAME']], 'A', Context())
    # Push "simple_stmt"
    p.push(g.symbol2number['simple_stmt'], g.dfas[g.symbol2number['simple_stmt']], 0, Context())
    # Pop "simple_stmt"
    p.pop()
    # Push a token

# Generated at 2022-06-11 19:53:45.196842
# Unit test for method pop of class Parser
def test_Parser_pop():
    g = Grammar()
    p = Parser(g, None)
    assert p.rootnode is None
    assert p.stack == []

# Generated at 2022-06-11 19:53:56.564028
# Unit test for method shift of class Parser
def test_Parser_shift():
    class DummyGrammar(object):
        tokens = {1: 10}

    def DummyConvert(grammar, node):
        return node

    p = Parser(DummyGrammar(), DummyConvert)
    p.setup()
    p.shift(1, 'a', 1, (1, 0))
    dfa1, state1, node1 = p.stack[-1]
    assert dfa1 == ()
    assert state1 == 1
    assert node1 == (None, None, None, [])
    p.shift(1, 'a', 2, (2, 0))
    dfa2, state2, node2 = p.stack[-1]
    assert dfa2 == ()
    assert state2 == 2
    assert node2 == (None, None, None, [])
    p.shift

# Generated at 2022-06-11 19:54:07.740130
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import parselib
    from . import tokenize
    from . import grammar
    from .pgen2 import token, parse

    start = 'file_input'

    grammar_str: Text = open('Grammar/Grammar', 'rb').read()
    grammar: Grammar = grammar.Grammar(grammar_str, start)

    p = Parser(grammar, parselib.convert)
    p.setup(start)

    f: TextIO = open('Lib/test/badindent.py', 'r')
    tokens = tokenize.generate_tokens(f.readline)
    first = True

# Generated at 2022-06-11 19:54:19.464369
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import os.path
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    from blib2to3.pgen2 import driver
    grammar = driver.load_grammar(
        os.path.join(
            os.path.dirname(__file__), "..", "blib2to3", "Grammar.txt"
        )
    )
    parser = Parser(grammar)
    parser.stack = [(([([(1, 2), (0, 0)], {}), ([(1, 2), (3, 3)], {})]), 0, (3, None, None, [])), ([([(1, 1), (0, 0)], {})], 0, (4, None, None, []))]

# Generated at 2022-06-11 19:55:15.419286
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver, tokenize

    g = driver.load_grammar("Grammar.txt")
    p = Parser(g)
    p.setup()

    p.setup(g.symbol2number["file_input"])

    p.setup(g.symbol2number["eval_input"])


# Generated at 2022-06-11 19:55:24.497798
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.generate
    import blib2to3.pgen2.parse
    import blib2to3.pygram
    grammar = blib2to3.pygram.python_grammar
    p = Parser(blib2to3.pgen2.generate.pgen(grammar), None)
    p.setup()
    p.addtoken(1, "a", None)
    assert p.stack == [(grammar.dfas[grammar.start], 2,
                        (grammar.start, None, None, [('STRING', 'a', None)]))]
    p.addtoken(2, "b", None)

# Generated at 2022-06-11 19:55:32.372326
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import grammar
    import driver
    import token

    def lam_sub(grammar, node):
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    g = grammar.Grammar()
    p = Parser(g, lam_sub)
    # Start processing
    p.setup()

# Generated at 2022-06-11 19:55:44.051603
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    import random

    class DummyGrammar(grammar.Grammar):
        def __init__(self) -> None:
            self.dfas: List[DFAS] = []
            self.keywords: Dict[str, int] = {}
            self.labels: List[Text] = []
            self.start = 0
            self.tokens: Dict[int, int] = {}

    class DummyGrammarInstance(object):
        def __init__(self) -> None:
            self.start = 0
            self.dfas: List[DFAS] = []
            self.labels: List[Text] = []
            self.keywords: Dict[str, int] = {}
            self.tokens: Dict[int, int] = {}

    # Build