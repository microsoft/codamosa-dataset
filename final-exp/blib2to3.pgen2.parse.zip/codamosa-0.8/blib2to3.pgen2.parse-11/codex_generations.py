

# Generated at 2022-06-11 19:45:56.541747
# Unit test for method shift of class Parser
def test_Parser_shift():
    def classify(type, value, context):
        if type == token.NAME:
            # Keep a listing of all used names
            assert value is not None
            self.used_names.add(value)
            # Check for reserved words
            ilabel = self.grammar.keywords.get(value)
            if ilabel is not None:
                return ilabel
        ilabel = self.grammar.tokens.get(type)
        if ilabel is None:
            raise ParseError("bad token", type, value, context)
        return ilabel

    def convert(grammar, node):
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    class Grammar(object):
        start = 1
        keywords = {}

# Generated at 2022-06-11 19:46:07.671374
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from tests.test_grammar import test_grammar

    # Test simple grammar with a single rule
    test_grammar.add_production(
        "foo", ["bar"],
    )
    parser = Parser(test_grammar)
    parser.setup()
    # Successfully parse
    assert not parser.addtoken(
        token.NAME, "bar", Context(1, 0),
    )
    assert parser.rootnode is not None
    # Check result
    node = parser.rootnode
    assert isinstance(node, Node)
    assert node.type == 1
    assert node.children == [Leaf(token.NAME, "bar", Context(1, 0))]
    # Too much input
    parser.setup()

# Generated at 2022-06-11 19:46:16.746610
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import os
    import tokenize
    from parser import (
        Grammar,
        STORE_TOKENS,
        set_grammar,
        driver,
        generate_tokens,
    )
    g = Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", [("stmt*", True)])
    g.add_nonterminal("stmt", [("simple_stmt", False), ("compound_stmt", False)])
    g.add_nonterminal("simple_stmt", [("small_stmt", True), ("NEWLINE", False)])
    g.add_nonterminal("small_stmt", [("expr_stmt", False), ("pass_stmt", False)])

# Generated at 2022-06-11 19:46:27.807479
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import textwrap

    from blib2to3 import pytree
    from blib2to3.pgen2 import driver, tokenize, grammar, parse

    def check(src: str, used_names: Sequence[Text]) -> None:
        """Parse the given string and check the rootnode and used_names"""
        stream = tokenize.tokenize(iter(src).__next__)
        try:
            list(parse.parse(stream, debug=False))
        except parse.ParseError as e:
            raise AssertionError("%s\n%s" % (src, e))
        infile = textwrap.dedent(src).strip()

# Generated at 2022-06-11 19:46:37.220190
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # This test uses a small hand-written grammar, to avoid loading
    # a large grammar at test time.
    import copy


# Generated at 2022-06-11 19:46:49.523845
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # Build the grammar which maps { symbol to DFA }
    g = grammar.Grammar()

    g.add_dfa(3, 'a', 'c', [0, -1, 1, 2])
    g.add_dfa(4, 'd', 'd', [0, -1, 1, 1])
    g.add_dfa(5, 'a', 'b', [0, -1, 1, 1])
    g.add_dfa(3, 'b', 'c', [0, -1, 1, 2])
    g.add_dfa(5, 'c', 'd', [0, -1, 1, 1])
    g.add_dfa(3, 'd', 'd', [0, -1, 1, 1])
    g.add

# Generated at 2022-06-11 19:46:57.629839
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .grammar import Grammar
    gr = Grammar()
    p = Parser(gr)
    c = p.classify
    assert c(1, "A", None) == 1
    assert c(1, None, None) == 1
    assert c(3, "else", None) == 3
    assert c(1, "else", None) == 4
    try:
        c(-1, None, None)
    except ParseError as e:
        assert e.type == -1
    else:
        assert False


# Generated at 2022-06-11 19:47:04.194344
# Unit test for method push of class Parser
def test_Parser_push():
    class _ParseError(ParseError):

        def __init__(self, p: Parser) -> None:
            pass

    class _Push(Parser):

        def __init__(self, p: Parser) -> None:
            p.push(1, 2, 3, 4)

    try:
        parser = Parser(0)
        _Parser_push(parser)
    except ParseError:
        raise _ParseError(parser)

# Generated at 2022-06-11 19:47:16.769397
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    # Label and state number classes
    class Label:
        def __init__(self, value):
            self.value = value

    class State:
        def __init__(self, value):
            self.value = value

    # Test data
    stack = [
        Label("A"),
        Label("B"),
        Label("C"),
        Label("D"),
        Label("E"),
        Label("F"),
        State(1),
        State(2),
        State(3),
        State(4),
    ]
    type = "G"
    value = "G"
    context = "G"
    parser = Parser(None, None)

    # Run test
    parser.addtoken(type, value, context)

    # Check results

# Generated at 2022-06-11 19:47:29.794729
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver

    g = driver.load_grammar(r"C:\Users\tatiana\PycharmProjects\blib2to3_test\Lib\Lib\blib2to3\pgen2\grammar.txt")
    p = Parser(g)
    p.setup()
    p.addtoken(1, 1, None)
    p.addtoken(2, 2, None)
    p.addtoken(3, 3, None)
    p.addtoken(4, 4, None)
    p.addtoken(5, 5, None)
    p.addtoken(6, 6, None)
    expected_output = p.rootnode.leaves()
    p.pop()
    actual_output = p.rootnode.leaves()
    assert expected_output != actual_output

#

# Generated at 2022-06-11 19:47:48.458619
# Unit test for method classify of class Parser
def test_Parser_classify():
    import sys
    import os
    from . import driver, token

    grammar = driver.load_grammar(os.path.join(sys.prefix, 'Grammar/Grammar'))
    parser = Parser(grammar)

    # First case
    token = token.Token(driver.INTNUMBER, '6')
    parser.classify(token.type, token.string, token.context)

    # Second case
    token = token.Token(driver.STRING, '6')
    parser.classify(token.type, token.string, token.context)

    # Third case
    token = token.Token(token.NAME, '6')
    parser.classify(token.type, token.string, token.context)

    # Fourth case
    token = token.Token(token.BACKQUOTE, '6')


# Generated at 2022-06-11 19:47:59.121603
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    g = grammar.parser_grammar.grammar
    p = Parser(g)
    p.setup(g.start)
    for item in (
        (token.NAME, "x", "x"),
        (token.MINUS, "-", "x-"),
        (token.NAME, "y", "x-y"),
        (token.PLUS, "+", "x-y+"),
        (token.NAME, "z", "x-y+z"),
    ):
        assert not p.addtoken(item[0], item[1], item[2])
    assert p.addtoken(token.ENDMARKER, "", "x-y+z")
    assert p.rootnode is not None
    assert len(p.rootnode) == 3

# Generated at 2022-06-11 19:48:06.357377
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, tokenizer
    from .pgen2 import tokenize
    from . import driver
    import sys

    g = grammar.grammar
    # Create a parser
    p = Parser(g, driver.convert)
    t = tokenizer.tokenize('1+2*3')
    #prime the pump
    p.setup()
    while True:
        tok, _, _ = t.get_token()
        if p.addtoken(tok, '', None):
            break


# Generated at 2022-06-11 19:48:17.874063
# Unit test for method shift of class Parser
def test_Parser_shift():
    class TestNode:
        pass
    class TestGrammar:
        def __init__(self, node_class):
            self.nonterminals = {}
            self.tokens = {}
            self.start = 1
            self.dfas = {}
            self.dfas[1] = (dfa_states, dfa_first)
            self.labels = {}
            self.keywords = {}
            self.node_class = node_class

        def convert(self, grammar, token):
            return self.node_class

    def convert(self, grammar, token):
        return self.node_class

    dfa_states = [(0, 1), (0, 1), (0, 1)]
    dfa_first = set()
    grammar = TestGrammar(TestNode)

# Generated at 2022-06-11 19:48:21.498589
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    from . import driver as pgen
    grammar = pgen.pgen(sys.stdin)
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(1, None, None)
    parser.push(2, None, None, None)
    parser.pop()

# Generated at 2022-06-11 19:48:33.422921
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import unittest
    import fractions
    import textwrap
    import io
    import tokenize
    from blib2to3.pgen2.token import tokenize as b2t_tokenize
    import blib2to3.pgen2.pgen
    import blib2to3.pgen2.driver
    import blib2to3.pgen2.parse

    # Verify that method pop makes leaf nodes for all tokens.
    # This should not happen when the input is a valid program.
    # Method pop is called when there are no more tokens.
    # How can that happen with a valid program?
    # When the program ends with a keyword like 'in',
    # for example, as in 'blah if blah else blah in blah'.
    # We should see a leaf node for 'in'.
    # This leaf

# Generated at 2022-06-11 19:48:45.502386
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Unit test for method shift of class Parser"""
    from . import grammar, token
    from .token import INDENT, DEDENT, NEWLINE, NAME, NUMBER, STRING

    p = Parser(grammar, lam_sub)
    p.setup()
    p.addtoken(INDENT, None, (1, 1))
    p.addtoken(NAME, 'x', (1, 1))
    p.addtoken(NEWLINE, None, (2, 1))
    p.addtoken(DEDENT, None, (2, 2))
    assert p.rootnode.children[0].type == INDENT
    assert p.rootnode.children[1].value == 'x'
    assert p.rootnode.children[2].type == NEWLINE
    assert p.rootnode.children[3].type == DEDENT

# Generated at 2022-06-11 19:48:56.317346
# Unit test for method push of class Parser
def test_Parser_push():
    from .token import Token, tok_name
    from .pgen2 import driver

    _, tok, _, _ = driver.parse_grammar(
        """
    start: toto
    toto: 'titi'
        """,
        "Parser/test_toto.txt",
    )


# Generated at 2022-06-11 19:49:04.657337
# Unit test for method shift of class Parser
def test_Parser_shift():
    class MyParser(Parser):
        def __init__(self, new_stack, new_convert):
            self.stack = new_stack
            self.convert = new_convert

    new_stack = [('dfa', 'state', 'node')]
    new_convert = 'convert'
    my_parser_object = MyParser(new_stack, new_convert)
    my_parser_object.shift('type', 'value', 'newstate', 'context')
    assert my_parser_object.stack == [('dfa', 'newstate', 'node')]

# Generated at 2022-06-11 19:49:14.165048
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    testgrammar = grammar.grammar
    testgrammar.labels = {"('x', 1)": 0, ("a", 2): 1, ("b", 3): 2, ("c", 4): 3}
    testgrammar.dfas = {0: ([[(1, 1)], [(2, 2)], [(3, 3)]], {0: 1, 1: 2, 2: 3}), 3: ([[(0, 4)]], {4: 4})}
    testgrammar.keywords = {}
    testgrammar.tokens = {1: 0, 2: 1, 3: 2, 4: 3}
    testgrammar.start = 3
    p = Parser(testgrammar)

    p.setup(3)
    # Test the case of a token

# Generated at 2022-06-11 19:49:35.351138
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver
    from . import tokenize

    import io
    import token
    from .tokenize import TokenInfo

    def parse(text: Text, convert: Optional[Convert] = None) -> Node:
        lines = text.split("\n")
        # Avoid tokenizing the entire input file.
        tokens_to_parse = []
        for line in lines:
            tokens_to_parse.extend(
                tokenize.generate_tokens(io.StringIO(line).readline)
            )

        tokens = []
        for (type, value, begin, end, line) in tokens_to_parse:
            if type == token.ERRORTOKEN:
                raise driver.ParseError("tokenize error", type, value, line)

# Generated at 2022-06-11 19:49:45.927715
# Unit test for method addtoken of class Parser

# Generated at 2022-06-11 19:49:56.727677
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import parsetok

    g = grammar.Grammar()
    p = Parser(g)
    t = parsetok.Tokenizer()
    p.setup()
    t.setinput("1+2*3")
    #
    assert p.stack == [(g.dfas[g.start], 0, (1, None, None, []))]
    assert p.addtoken(1, "1", (1,0)) is False
    assert p.stack == [(g.dfas[g.start], 1, (1, None, None, [1])), (g.dfas[5], 0, (5, None, None, []))]
    assert p.addtoken(47, "+", (1,1)) is False

# Generated at 2022-06-11 19:50:04.335086
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import token
    from . import grammar
    import sys
    import io
    import pickle
    import pprint

    # Read a grammar description for the current Python version
    file = io.StringIO(grammar.grammar)
    driver.parse_grammar(file, "exec", sys.modules[__name__], verbose=False)
    file.close()
    driver.pgen = driver.PickleGrammar(r"Grammar/Grammar", driver)

    # Construct a parser
    pg = driver.pgen
    parser = Parser(pg.grammar)
    # Read a Python source file and tokenize it
    data = open("Grammar/Grammar", "r").read()

# Generated at 2022-06-11 19:50:06.582019
# Unit test for method push of class Parser
def test_Parser_push():
    g = Grammar(start=1, symbols={1: ("A", 1, 2, 0), 2: ("B",)}, labels={})
    p = Parser(g)
    assert p.stack == []
    p.push(1, g.dfas[1], 0, "foo")
    assert p.stack == [(g.dfas[1], 0, (1, None, "foo", []))]

# Generated at 2022-06-11 19:50:12.679936
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pprint
    from . import grammar, tokenize

    # Re-generate the grammar
    g = Grammar(grammar.pgen_grammar)

    # Test data
    test1 = "def foo(x):\n    return x + 1"

    def converttree(grammar, node):
        if node[0] == grammar.syms.stmt and len(node[3]) == 1:
            return node[3][0]
        else:
            return node

    p = Parser(g, converttree)
    p.setup()
    for t in tokenize.generate_tokens(test1.splitlines(True)):
        p.addtoken(t[0], t[1], t[2])
    pprint.pprint(p.rootnode)



# Generated at 2022-06-11 19:50:20.476757
# Unit test for method shift of class Parser
def test_Parser_shift():
    class test_grammar(Grammar):
        def __init__(self):
            Grammar.__init__(self, {})
        @staticmethod
        def classify(type: int, value: Optional[Text], context: Context) -> int:
            return type

    # instance with no converter
    testparser = Parser(test_grammar())
    # test input
    type = 3
    value = 'testvalue'
    context = Context(1, 2, None)
    newstate = 4
    # init stack
    rawnode: RawNode = (1, None, None, [])
    stackentry = (test_grammar.dfas[1], 0, rawnode)
    testparser.stack = [stackentry]
    # call shift()
    testparser.shift(type, value, newstate, context)


# Generated at 2022-06-11 19:50:27.061791
# Unit test for method classify of class Parser
def test_Parser_classify():
    g = Grammar(None)
    g.labels = [("class", 1), ("def", 2)]
    g.tokens = {token.NAME: 1}
    p = Parser(g)
    assert p.classify(token.NAME, "class", "xxx") == 1
    assert p.classify(token.NAME, "def", "xxx") == 2
    assert p.classify(token.NAME, "xyz", "xxx") == 1

# Generated at 2022-06-11 19:50:38.940583
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # This is a "pure" unit test (no dependencies outside this module).
    class MockGrammar(object):
        labels = [
            (257, "NAME"),
            (258, "NUMBER"),
            (259, "start"),
            (260, "expr"),
            (261, "term"),
            (262, "factor"),
            (263, "power"),
        ]
        tokens = {257: 257, 258: 258, 259: 259}

# Generated at 2022-06-11 19:50:44.537175
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.token as token
    import blib2to3.pgen2.grammar as grammar

    g = grammar.Grammar('\n'.join([
        'foo: bar',
        'bar: NAME',
    ]))
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, 'bar', None)
    p.addtoken(token.NAME, 'baz', None)


# Generated at 2022-06-11 19:51:00.273499
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar())
    p.stack = [(None, None, None)]
    p.shift(1, "a", 2, None)
    assert p.stack == [(None, 2, None)]

# Generated at 2022-06-11 19:51:12.943347
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import pgen2

    def lam_sub(grammar: Grammar, node: RawNode) -> NL:
        assert node[3] is None
        return "leaf!"

    p = Parser(pgen2.expr_grammar, convert=lam_sub)

# Generated at 2022-06-11 19:51:15.588157
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    def convert(grammar: Grammar, node: RawNode) -> NL:
        children = node[3]

# Generated at 2022-06-11 19:51:25.152677
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.tokenize import tokenize
    from blib2to3.pgen2.driver import Driver
    from io import StringIO

    def check_pop(code: str) -> None:
        """Unit test for method pop of class Parser

        This function is called from test_Parser_pop.
        """
        s_io = StringIO(code)
        driver = Driver()
        try:
            driver.parse_tokens(tokenize(s_io.readline))
        except ParseError as e:
            # Once a parse error occurs, the parser is no longer usable,
            # but we'll call pop() anyway just to exercise it.
            driver.parser.pop()

# Generated at 2022-06-11 19:51:32.390518
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    import sys

    g = grammar.Grammar()
    g.generate_grammar(sys.stdin)
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "hi", (1, 0))
    p.push(g.symbol2number["addition"], g.dfas["addition"], 0, (1, 0))
    p.addtoken(token.PLUS, "+", (1, 0))
    p.pop()
    p.addtoken(token.NAME, "world", (1, 0))
    print(p.rootnode)


# Generated at 2022-06-11 19:51:45.447274
# Unit test for method shift of class Parser
def test_Parser_shift():
    import pprint as ppr

    from . import grammar
    from .token import NAME
    from .tokenize import tokenize, untokenize
    from .tree import fancy_repr

    with open(grammar.__file__) as f:
        encoding = f.encoding
    with open(grammar.__file__, encoding=encoding) as f:
        lines = tuple(f)
    tokens = tuple(tokenize(lines))

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for type, value, start, end, line in tokens:
        print(p.addtoken(type, value, (start, end, line)))

    if p.rootnode:
        print(untokenize(fancy_repr(p.rootnode)))

# Generated at 2022-06-11 19:51:56.504165
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver

    grammar = driver.load_grammar()
    parse = Parser(grammar)

    parse.setup()
    new_token = (4, "def", (1, 0))
    parse.addtoken(*new_token[:3])
    assert(parse.stack[0][2][3][1][1] == "def")
    new_token = (4, "callee", (1, 4))
    callee = parse.addtoken(*new_token[:3])
    assert(parse.stack[0][2][3][1][1] == "callee")
    assert(parse.stack[0][2][3][0] == 57)
    # after one name is added, the stack is shifted, so the second name should
    # be added to the end of the stack

# Generated at 2022-06-11 19:52:06.407922
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver

    opts = driver.OptimizeOptions()
    p = driver.Parser(opts)
    p.compile("1+2", "no file")

    def lam_sub(grammar: Grammar, node: RawNode) -> Node:
        return Node(type=node[0], children=node[3], context=node[2])

    parser = Parser(p.grammar, convert=lam_sub)
    parser.setup()
    for (type, value, context) in p.input_tokens:
        parser.addtoken(type, value, context)

    dfa, state, node = parser.stack[-1]
    assert dfa == parser.grammar.dfas[1]

    parser.pop()
    dfa, state, node = parser.stack[-1]

# Generated at 2022-06-11 19:52:16.228726
# Unit test for method shift of class Parser
def test_Parser_shift():
    import io
    import tokenize
    from blib2to3.pgen2.driver import Driver

    # See also test_grammar.py for a grammar test.
    s = io.StringIO(
        "a=1;b=2;c=3\n"
        "a = 1; b = 2; c = 3\n"
    )
    tokengen = tokenize.generate_tokens(s.readline)
    d = Driver()
    d.parse_tokens(tokengen)
    print()
    print(d.convert.grammar.dump())
    print()
    print(d.convert.grammar.dump_rules())
    p = Parser(d.convert.grammar, d.convert.convert)
    p.setup()
    indent

# Generated at 2022-06-11 19:52:18.653725
# Unit test for method push of class Parser
def test_Parser_push():
    g = Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "3", None)



# Generated at 2022-06-11 19:52:52.331950
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Unit test for method pop of class Parser."""
    from . import grammar
    from . import tokenize
    p = Parser(grammar) # type: ignore
    for text in ("""\
1
""", """\
print(1)
"""):
        p.setup()
        for type, _, s, _, _, _ in tokenize.generate_tokens(StringIO(text).readline):
            if p.addtoken(type, s, None):
                break
        #print(p.rootnode.pretty())



# Generated at 2022-06-11 19:53:02.888481
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Some mocks of the attributes of a grammar.Grammar instance
    start = 0
    labels = [(257, 'Name')]
    keywords = keymap = tokens = {}
    labelsmap = {257: 0}
    # A mocks of a DFA
    dfas: Dict[int, DFAS] = {
        0: (
            [[(0, 0)]],
            {0: 257},
        ),
        257: (
            [[(0, 0)]],
            {0: 257},
        ),
    }
    # Create a Parser instance and set it up for parsing
    grammar = Grammar(start, dfas, labels, keymap, tokens, labelsmap)
    parser = Parser(grammar)
    parser.setup()
    # Create a mock token
    type = token.NAME

# Generated at 2022-06-11 19:53:11.824822
# Unit test for method push of class Parser
def test_Parser_push():
    from . import parse
    from . import grammar

    src = """
    '''docstring'''
    x = 1
    """

    g = parse.Parser(grammar.python_grammar_no_print_statement)
    g.setup()
    t1 = token.STRING
    t2 = token.NAME
    t3 = token.EQUAL
    t4 = token.NUMBER
    g.addtoken(t1, "docstring", Context(1, 0))
    g.addtoken(t2, "x", Context(1, 0))
    g.addtoken(t3, "=", Context(1, 0))
    g.addtoken(t4, "1", Context(1, 0))

# Generated at 2022-06-11 19:53:19.654936
# Unit test for method pop of class Parser
def test_Parser_pop():
    stack = [
        (
            ([([(256, 0)], set()), ([(258, 1), (0, 1)], set()), ([(0, 2)], set())], set()),
            (1, "", []),
        )
    ]
    newnode = (258, "", [])
    parser = Parser(None, None)
    parser.stack = stack
    parser.pop()
    assert parser.stack == stack and parser.rootnode == newnode

# Generated at 2022-06-11 19:53:26.891044
# Unit test for method classify of class Parser

# Generated at 2022-06-11 19:53:38.616403
# Unit test for method push of class Parser
def test_Parser_push():
    from . import Driver, token

    g = Driver.load_grammar("Python", "2.7")
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "def", Context(1, 0, 1, 3))
    p.addtoken(token.NAME, "f", Context(1, 4, 1, 5))
    p.addtoken(token.OP, "(", Context(1, 5, 1, 6))
    p.addtoken(token.OP, ")", Context(1, 6, 1, 7))
    p.addtoken(token.OP, ":", Context(1, 7, 1, 8))
    p.addtoken(token.NEWLINE, "\n", Context(1, 8, 2, 0))

# Generated at 2022-06-11 19:53:46.065557
# Unit test for method push of class Parser
def test_Parser_push():
    def assert_push(p: Parser, type: int, newdfa: DFAS, newstate: int, context: Context) -> None:
        assert isinstance(p, Parser)
        assert isinstance(type, int)
        assert isinstance(newdfa, DFAS)
        assert isinstance(newstate, int)
        assert isinstance(context, Context)
        p.push(type, newdfa, newstate, context)
        assert isinstance(p.stack, List)


# Generated at 2022-06-11 19:53:56.301442
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .pgen2 import driver

    g = Grammar(driver.parse_grammar(driver.grammar, convert=driver.convert))

    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "spam", Context(1, 0, ''))
    assert p.rootnode.children[0].children[0].value == 'spam'
    p.addtoken(token.EQUAL, "=", Context(1, 0, ''))
    p.addtoken(token.NUMBER, "1", Context(1, 0, ''))
    assert p.rootnode.children[0].children[1].value == '1'


# Generated at 2022-06-11 19:54:07.610702
# Unit test for method pop of class Parser
def test_Parser_pop():
    class MockConvert:
        def __init__(self) -> None:
            self.convert = [
                (0, (1, '1', None, None)),
                (1, (2, '2', None, None)),
            ]
        def __call__(self, _: Grammar, node: RawNode) -> Node:
            return self.convert.pop(0)

    node = (0, '0', None, [])
    stack = [
        ((([(1, 1)], [0])), 0, node),
        ((([(2, 2)], [0])), 0, (1, '1', None, None)),
        ((([(3, 3)], [0])), 0, (2, '2', None, None)),
    ]
    used_names = set()
    rootnode = None

# Generated at 2022-06-11 19:54:19.347190
# Unit test for method setup of class Parser
def test_Parser_setup():
    from unittest import TestCase
    from bold.util import get_test_full_python_grammar
    from .grammar import Grammar
    from .driver import Driver
    from .tokenizer import Tokenizer
    from .pygram import python_grammar

    class TestParser(TestCase):
        def test_Parser_setup(self):
            grammar_file = get_test_full_python_grammar()
            g = Grammar(grammar_file)
            p = Parser(g, convert=lam_sub)

            test_str = "1"
            d = Driver(grammar=g, convert=lam_sub, lexer=Tokenizer(test_str))
            d.setup()
            assert d.parse_toplevel()

# Generated at 2022-06-11 19:55:20.558986
# Unit test for method pop of class Parser
def test_Parser_pop():
    class Grammar(object):
        @property
        def dfas(self) -> DFAS:
            return ([0], [0])

        labels = [(257, "INT"), (258, "NAME")]
        start = 258
        tokens = {258: 257}

    p = Parser(Grammar())
    p.setup()
    p.shift(258, "name", 0, None)
    p.shift(257, "42", 0, None)
    p.pop()
    p.pop()



# Generated at 2022-06-11 19:55:29.510285
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver

    class MyConvert(object):
        def __init__(self):
            self.tup = []

        def __call__(self, grammar: Grammar, node: RawNode) -> Any:
            self.tup.append(node)
            return None

    grammar = driver.load_grammar("Grammar.txt")
    parser = Parser(grammar, None)
    parser.setup(0)
    parser.shift(1, "1", 0, None)
    assert parser.stack[0][2] == (0, None, None, [])
    # Check that sublists don't interfere with each other
    parser.setup(0)
    parser.shift(1, "1", 0, None)
    assert parser.stack[0][2] == (0, None, None, [])



# Generated at 2022-06-11 19:55:37.220028
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest
    import os
    from tempfile import NamedTemporaryFile
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2.pgen import generate_grammar
    from . import token

    class ParserTestCase(unittest.TestCase):

        def setUp(self) -> None:
            f = NamedTemporaryFile(delete=False)
            f.write(b'1\n2\n3\n4\n')
            f.close()
            self.filename = f.name

        def tearDown(self) -> None:
            os.unlink(self.filename)


# Generated at 2022-06-11 19:55:50.345752
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from . import driver

    import unittest

    class TestCase(unittest.TestCase):

        def setUp(self):
            self.grammar = grammar.grammar
            self.dfa = self.grammar.dfas[self.grammar.symbol2number["compound_stmt"]]
            self.parser = Parser(self.grammar)
            self.driver = driver.Driver(self.grammar, self.parser.convert)

        def assert_pop_ok(self, input_text: Text, expected_node: Node) -> None:
            self.parser.setup()
            for tt in tokenize.generate_tokens(input_text):
                if self.parser.addtoken(*tt):
                    break