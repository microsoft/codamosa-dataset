

# Generated at 2022-06-11 19:45:59.560711
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    gr = grammar.Grammar()
    p = Parser(gr)

    # Set up the Parser instance to parse the following program:
    #
    #    a = 1
    #
    # by pretending the symbols have already been parsed and the
    # input tokens are the following:
    #
    #    NAME(a) OP(=) NUM(1) NEWLINE(None) ENDMARKER(None)
    #
    # Take special note of the ENDMARKER token.
    #
    # Simulate the parsing of the following nonterminals:
    #
    #    file_input = (NEWLINE | stmt)* ENDMARKER
    #    stmt = simple_stmt | compound_stmt
    #    simple_stmt = small_stmt (';' small_stmt)* NEW

# Generated at 2022-06-11 19:46:01.083768
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar(None, None)
    Parser(grammar).setup()

# Generated at 2022-06-11 19:46:13.218741
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Create a small grammar
    keywords = {}
    tokens = {token.NUMBER: "NUMBER"}
    labels = [
        (token.NAME, "NAME"),
        (token.NUMBER, "NUMBER"),
        (0, "S"),
        (1, "A"),
        (2, "B"),
    ]
    dfas = {}
    dfa = [
        [(1, 1), (2, 1)],
        [(1, 1), (3, 1)],
        [(0, 1)],
        [(0, 1)],
    ]
    dfas[1] = dfa, {0}
    symbols = [
        "S",
        "A",
        "B",
    ]
    grammar = Grammar(keywords, tokens, labels, dfas, symbols)
    # Test pop method of

# Generated at 2022-06-11 19:46:17.856932
# Unit test for method setup of class Parser
def test_Parser_setup():
    parser = Parser(None)

    parser.setup()
    assert parser.stack == [(None, 0, (None, None, None, []))]
    assert parser.rootnode is None



# Generated at 2022-06-11 19:46:29.134880
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    #
    # This tests a few of the error conditions in addtoken().
    #
    from .token import Whitespace, Name, Newline
    from . import parse

    grammar = parse.grammar

    p = Parser(grammar)
    p.setup()

    # Test a normal input sequence
    p.addtoken(Whitespace, " ", Context(1, 0))
    p.addtoken(Name, "x", Context(1, 1))
    assert p.stack == [(grammar.dfas[grammar.start], 2, (52, None, None, [None]))]
    p.addtoken(Whitespace, " ", Context(1, 2))
    p.addtoken(Name, "=", Context(1, 3))
    p.addtoken(Whitespace, " ", Context(1, 4))
   

# Generated at 2022-06-11 19:46:37.889670
# Unit test for method classify of class Parser

# Generated at 2022-06-11 19:46:50.209057
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Unit test for method addtoken of Parser."""
    import tokenize
    from . import driver
    # Open the input and prepare it for parsing
    f = open("../Drivers/tests/input/decorators.py", "U")
    p = Parser(driver.driver.grammar, driver.driver.convert)
    p.setup()
    # Use the tokenizer to produce all tokens in the file
    while 1:
        try:
            token = tokenize.next()
        except StopIteration:
            token = None
        if token is None:
            break
        if isinstance(token, tuple):
            type, value, lineno, start, end, line = token
        else:
            continue
        # Let the Parser see the token

# Generated at 2022-06-11 19:46:53.912689
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(Grammar(None))
    p.push(4711, ([[(4712, 1)]], {4712: 1}), 0, None)
    assert p.stack == [(([[(4712, 1)]], {4712: 1}), 0, (4711, None, None, []))]

# Generated at 2022-06-11 19:47:02.622589
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import os
    import unittest
    STORAGE_DIR = "test_ParseError.storage"
    if os.path.exists(STORAGE_DIR):
        os.rmdir(STORAGE_DIR)

    class ParseErrorTestCase(unittest.TestCase):
        def test_setup(self):
            def test_setup():
                import pprint
                import sys
                import os
                import unittest
                import pickle
                from blib2to3.pgen2 import token
                from blib2to3.pgen2 import driver
                from blib2to3.pgen2 import parse
                from blib2to3.pgen2 import grammar

                ##########################
                # Test Parser.setup()
                ##########################

# Generated at 2022-06-11 19:47:10.714034
# Unit test for method setup of class Parser
def test_Parser_setup():
    # This test was originally in the module driver.
    # See comments there for explanation.
    import os
    import sys
    import grammar
    import tokenize
    from io import BytesIO

    sys.setrecursionlimit(2000)

    # In Python 3.2, the grammar structure changed slightly,
    # in particular it added the start symbol.
    # The version of the grammar module we import must match
    # the version of the Python interpreter.
    gram_name = "Grammar.txt"
    if sys.version_info >= (3, 2):
        gram_name = "Grammar3.2.txt"

    g = grammar.grammar
    g_start = g.start
    p = Parser(g)
    p.setup()
    here = os.path.split(__file__)[0]
    f

# Generated at 2022-06-11 19:47:27.164991
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import parse

    # Note that the grammar for Python 3.8 includes a trailing newline,
    # which is not part of the string "b'hello'". We catch this with
    # the used_names test.
    code = "b'hello'"
    tree = parse(code)
    assert len(tree.children) == 1
    assert tree.children[0].value == "b'hello'"
    assert "hello" not in tree.used_names
    assert "b" in tree.used_names
    assert tree.errors == []

# Generated at 2022-06-11 19:47:36.803043
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .grammar import _test_grammar

    p = Parser(_test_grammar)
    p.setup()
    t1 = tokenize([("NUMBER", "1"), ("NUMBER", "2"), ("PLUS", "+"), ("NUMBER", "3")])
    p.addtoken(t1[0][0], t1[0][1], Context(0, 1))
    p.addtoken(t1[1][0], t1[1][1], Context(0, 2))
    p.addtoken(t1[2][0], t1[2][1], Context(0, 3))
    p.addtoken(t1[3][0], t1[3][1], Context(0, 4))

# Generated at 2022-06-11 19:47:44.253906
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()
    assert parser.stack == [(([[(1, 1)]], set()), 0, (100, None, None, []))]
    parser.setup()
    assert parser.stack == [(([[(1, 1)]], set()), 0, (100, None, None, []))]
    parser.setup(0)
    assert parser.stack == [(([[(1, 1)]], set()), 0, (0, None, None, []))]


# Generated at 2022-06-11 19:47:49.264019
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    value: Optional[List[Text]] = ['a', 'b']
    type: Optional[List[int]] = [1, 2]
    context: Context = Context()
    result: bool = Parser.addtoken(type, value, context)
    assert (type is not None) == result

# Generated at 2022-06-11 19:48:00.163710
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .token import NAME
    from . import grammar, symbols

    p = Parser(grammar, None)
    p.setup()
    p.addtoken(grammar.tokens[NAME], "c", None)
    assert p.rootnode.children == [Leaf(NAME, "c")]
    p.addtoken(grammar.tokens[NAME], "c", None)
    assert p.rootnode.children == [Leaf(NAME, "c"), Leaf(NAME, "c")]
    assert p.rootnode.children[0] == p.rootnode.children[1]
    assert p.rootnode.children[0] is not p.rootnode.children[1]
    p.addtoken(grammar.tokens[NAME], "d", None)

# Generated at 2022-06-11 19:48:11.349640
# Unit test for method push of class Parser
def test_Parser_push():
    from .pgen2 import driver
    from .pgen2 import token
    from . import grammar

    g = driver.load_grammar("Grammar/Grammar")
    p = Parser(g)
    p.setup()
    p.addtoken(token.LPAR, "(", (1, 0))
    p.addtoken(token.NAME, "a", (1, 1))
    p.addtoken(token.COMMA, ",", (1, 2))
    p.addtoken(token.NAME, "b", (1, 3))
    p.addtoken(token.RPAR, ")", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 5))
    if not p.stack:
        raise Exception("stack is empty")

# Generated at 2022-06-11 19:48:21.878348
# Unit test for method pop of class Parser
def test_Parser_pop():
    import blib2to3.pgen2.parse2 as parse2
    import blib2to3.pgen2.driver as driver
    import sys

    with open(sys.argv[1]) as f:
        s = f.read(20)
    g = driver.load_grammar("Grammar.txt")
    p = Parser(g)
    p.setup()
    p.addtoken(token.NUMBER, "0", Context(1,0))
    p.addtoken(token.NEWLINE, "\n", Context(1,2))
    p.addtoken(token.NUMBER, "1", Context(2,0))
    p.addtoken(token.NEWLINE, "\n", Context(2,2))
    p.pop()
    p.pop()
    assert len(p.stack)

# Generated at 2022-06-11 19:48:33.459919
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver
    from . import grammar
    from . import tokenize
    from . import token
    from .pytree import Leaf, Node

    p = Parser(grammar.grammar, driver.convert)
    p.setup()
    for type, value, start, end, line in tokenize.generate_tokens(open("../Lib/parser.py", encoding="utf-8")):
        if type == token.OP and value == "+":
            break
        p.addtoken(type, value, (start[0], start[1]))
    assert p.rootnode is not None
    assert len(p.rootnode) == 1

# Generated at 2022-06-11 19:48:42.273719
# Unit test for method shift of class Parser
def test_Parser_shift():
    def test_func(type, value, context):
        p1 = Parser(Grammar())
        p1.setup()

        class test_context:
            pass

        for i in range(4):
            tcontext = test_context()
            tcontext.__dict__['lineno'] = i
            tcontext.__dict__['offset'] = i
            p1.shift(type, value, 1, tcontext)

    test_func(1, "value", 1)

# Generated at 2022-06-11 19:48:53.205674
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.grammar

    p = Parser(g)
    p.setup()
    p.addtoken(token.LPAR, "(", (1, 0))
    p.addtoken(token.NAME, "x", (1, 1))
    p.addtoken(token.RPAR, ")", (1, 2))
    assert p.rootnode.children == [Leaf(token.LPAR, "(", (1, 0)), Leaf(token.NAME, "x", (1, 1)), Leaf(token.RPAR, ")", (1, 2))]

    p.setup()
    p.addtoken(token.NAME, "x", (1, 0))
    assert p.rootnode.children == [Leaf(token.NAME, "x", (1, 0))]

    p.setup()


# Generated at 2022-06-11 19:49:14.163206
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    class FakeGrammar(object):
        pass

    grammar = FakeGrammar()
    grammar.start = 9
    grammar.keywords = {'name':257}
    grammar.tokens = {1:258}

# Generated at 2022-06-11 19:49:22.637668
# Unit test for method addtoken of class Parser

# Generated at 2022-06-11 19:49:33.814893
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Works on Python 2.6, 2.7 and 3.1
    number_of_tokens = 5  # token.NUMBER
    number_of_symbols = 11  # sym.file_input
    expected_nodekind = number_of_symbols
    expected_token_nodekind = number_of_tokens
    expected_value = "3"
    expected_context = 3
    expected_used = ["3"]  # Used names

    parser = Parser(Grammar(number_of_tokens, number_of_symbols))
    parser.setup()

    # Create a fake token list
    tokens = []

# Generated at 2022-06-11 19:49:45.085069
# Unit test for method push of class Parser
def test_Parser_push():
    import os
    import sys
    from . import grammar
    from . import token
    from . import symbol
    from . import driver
    from . import convert
    from . import pygram
    from . import pytree

    if sys.argv[1:2] == ['push']:
        gram = pygram.python_grammar
        p = Parser(gram)
        p.setup()
        p.addtoken(token.NAME, 'x', pytree.new_context('x', 4, 1))
        p.push(symbol.term, gram.dfas[symbol.term], 0, pytree.new_context('x', 4, 1))
    else:
        grammar.main(r'..\grammar\Grammar')
        token.main(r'..\grammar\Tokens')

# Generated at 2022-06-11 19:49:56.473111
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    import types
    import re

    class TestCase(unittest.TestCase):
        def test_udt_pl1(self):
            # Test case generated by tst_udt_pl1.py
            g = Grammar(udt_pl1)
            p = Parser(g)
            p.setup()
            p.addtoken(1, None, (1, 0))
            p.addtoken(5, None, (1, 6))
            p.addtoken(6, "a", (1, 7))
            p.addtoken(7, None, (1, 8))
            p.addtoken(5, None, (1, 9))
            p.addtoken(6, "abc", (1, 10))
            p.addtoken(7, None, (1, 13))


# Generated at 2022-06-11 19:50:02.184790
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import pygram, pytree
    p = Parser(pygram.python_grammar)
    tr = pytree.BaseTreeBuilder()
    p.convert = tr.convert
    p.setup()
    p.stack = [(None, None, (1, None, (1, 1), []))]
    assert p.stack.pop() == (None, None, (1, None, (1, 1), []))
    assert p.stack == []


# Generated at 2022-06-11 19:50:13.750015
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Merge the context class into the token type
    ttype_or_context = Union[int, Context]
    # Concrete syntax trees
    CST_TYPE = Tuple[ttype_or_context, Optional[Text], Optional[Context], Sequence[Any]]
    # Abstract syntax trees
    AST_TYPE = Sequence[Any]
    # Parse trees, concrete or abstract
    PT_TYPE = Union[CST_TYPE, AST_TYPE]

    # A method to convert concrete syntax trees to abstract syntax trees
    def cst_to_ast(grammar: Grammar, cst: CST_TYPE) -> AST_TYPE:
        if cst[0] == grammar.symbol2number["foo"]:
            # Convert a foo node by reversing its children list
            assert cst[-1] is not None

# Generated at 2022-06-11 19:50:21.038352
# Unit test for method shift of class Parser
def test_Parser_shift():
    def shift(state):
        return state + 1

    def shift_and_pop(state):
        return state + 1, True

    def pop(state):
        return state, True

    def reduce_two(state):
        return state - 2

    def reduce_three(state):
        return state - 3

    def reduce_four(state):
        return state - 4

    def reduce_five(state):
        return state - 5

    def reduce_six(state):
        return state - 6

    def reduce_seven(state):
        return state - 7

    def reduce_eight(state):
        return state - 8

    def reduce_nine(state):
        return state - 9

    def reduce_ten(state):
        return state - 10

    def reduce_eleven(state):
        return state - 11


# Generated at 2022-06-11 19:50:28.971787
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import token
    from . import grammar
    from blib2to3.pgen2 import parse, convert

    mygrammar = grammar.Grammar()
    parser = Parser(mygrammar)
    parser.setup()
    for tok in parse(textwrap.dedent("""\
        start: ENDMARKER
    """), mygrammar):
        r = parser.addtoken(tok.type, tok.value, tok.context)
        assert isinstance(r, bool)
    root = convert(mygrammar, parser.rootnode)
    print(root.leaves())
    assert root.leaves() == ['endmarker']


# Generated at 2022-06-11 19:50:41.810863
# Unit test for method shift of class Parser
def test_Parser_shift():
    import pprint
    from . import grammar
    p = Parser(grammar.grammar)
    p.setup()
    p.shift(token.NAME, 'def', 1, (1, 0))
    p.shift(token.NAME, 'g', 2, (1, 4))
    p.shift(token.LPAR, '(', 3, (1, 6))
    p.shift(token.NAME, 'xxx', 4, (1, 7))
    p.shift(token.RPAR, ')', 5, (1, 11))
    p.shift(token.COLON, ":", 6, (1, 13))
    p.shift(token.NEWLINE, "\n", 7, (2, 0))
    p.shift(token.NAME, 'return', 8, (3, 0))

# Generated at 2022-06-11 19:51:16.074227
# Unit test for method shift of class Parser
def test_Parser_shift():
    # The unit test is a simplified version of the pgen_main() method in
    # the Python distribution.
    # The expected output is:
    #   <Node: module at 0x7f907b89e050>
    #   <Leaf: NAME[print] at 0x7f907b895a58>
    #   <Leaf: LPAR at 0x7f907b895a90>
    #   <Leaf: STRING[Hello, World!] at 0x7f907b895ac8>
    #   <Leaf: RPAR at 0x7f907b895b00>
    from . import driver
    from . import grammar

    grammar = grammar.grammar
    test_text = "print (\"Hello, World!\")\n"

# Generated at 2022-06-11 19:51:25.288768
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import pprint
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pgen2.driver import load_grammar, parse_tokens
    from blib2to3.pgen2.parse import ParseError

    # Load the grammar
    grammar = load_grammar(Text)

    # Parse a program; use an imaginary file name so we can be compared
    # with Python's parse tree
    toknum = 0
    toktext = []
    for tokens in generate_tokens(Text):
        for type, value, start, stop, line in tokens:
            toknum += 1
            toktext.append((type, value, start, stop, line))

    parser = Parser(grammar)
    parser.setup()

# Generated at 2022-06-11 19:51:33.188262
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    # Sample grammar
    gr = grammar.parse_grammar(SAMPLE_GRAMMAR)
    # Instantiate Parser
    prs = Parser(gr)
    # Prepare for parsing
    prs.setup()
    # Push a nonterminal
    prs.push(2, prs.grammar.dfas[2], 0, None)
    # Check results
    assert len(prs.stack) == 2
    assert prs.stack[0] == [(None, 0)]
    assert prs.stack[1] == ((None, 0), 0, (2, None, None, []))


# Generated at 2022-06-11 19:51:46.593396
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    from blib2to3.pgen2.grammar import Grammar

    class ParserTest(unittest.TestCase):
        def setUp(self):
            self.grammar = Grammar()
            self.grammar.start = "start"
            self.grammar.dfas[0] = DFA(
                [(0, 1), (0, 2)],
                {0: [(0, 1), (0, 2)], 1: [(0, 3)], 2: [(0, 3)], 3: [(0, 3)]},
            )
            self.grammar.dfas[1] = DFA([(0, 1)], {0: [(0, 1)], 1: [(0, 1)]})

# Generated at 2022-06-11 19:51:57.572908
# Unit test for method push of class Parser
def test_Parser_push():
    import sys
    import os
    import blib2to3.pgen2
    import blib2to3.pygram
    import blib2to3.pytree

    p = blib2to3.pgen2.parse(sys.argv[1], "exec", blib2to3.pygram.python_grammar)
    dfa = blib2to3.pgen2.dfa.from_node(p, 0)
    dfa.graph(os.path.splitext(sys.argv[1])[0])
    # Convert to my own DFAS format (handles augmented grammar)
    dfa2 = blib2to3.pgen2.dfa.to_dfas(dfa)

# Generated at 2022-06-11 19:52:07.290263
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar(grammar.DEFAULT_GRAMMAR)
    p = Parser(g)
    p.setup()
    p.push(1, (([[(2, 3)], 1]  # dfa of test.1
                , {0:0, 1:1, 2:3, 3:3}  # dfa states
                )
                , {1:0, 2:1, 3:0}  # first set
                )
            , 0, None)

# Generated at 2022-06-11 19:52:16.825813
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Test __init__"""
    from . import driver
    from . import grammartest

    grammar = driver.load_grammar(grammartest.grammar)
    # Create test Parser
    test_parser = Parser(grammar, None)
    assert test_parser.grammar == grammar
    # Create test stack
    dfas, labels = grammar.dfas, grammar.labels
    dfa, state, node = (dfas[1], 0, (0, None, None, [])),
    test_parser.stack = [dfa]
    # Create test pop
    dfa, state, node = dfa
    popdfa, popstate, popnode = (dfas[2], 0, (0, None, None, []))
    test_parser.pop()
    assert test_parser.stack == []

# Generated at 2022-06-11 19:52:28.835011
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3 import pygram
    from .tokenize import generate_tokens, untokenize

    # Shift tokens until a SyntaxError is hit
    from io import StringIO
    s = StringIO()
    g = pygram.python_grammar_no_print_statement
    p = Parser(g)
    p.setup()
    toks = generate_tokens(s.readline)
    line = 0
    type = toknum = 0
    try:
        while 1:
            tok = next(toks)
            type, value = tok[0:2]
            line = tok[2][0]
            toknum += 1
            if p.addtoken(type, value, tok[2]): break
    except ParseError:
        pass
    s.close()

# Generated at 2022-06-11 19:52:42.340476
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize
    from . import driver

    g = Grammar()
    p = Parser(g)
    p.setup()
    p.addtoken(token.NAME, "foo", Context("", 1, 0, 1))
    assert p.rootnode == Token("foo", Context("", 1, 0, 1))
    p.setup()
    p.addtoken(token.NAME, "foo", Context("", 1, 0, 1))
    p.addtoken(token.NAME, "bar", Context("", 1, 0, 1))
    assert p.rootnode == Token("foo", Context("", 1, 0, 1))
    p.setup()
    p.addtoken(token.NAME, "foo", Context("", 1, 0, 1))

# Generated at 2022-06-11 19:52:48.545026
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import py

    from . import driver
    import test_grammar_1

    grammar = test_grammar_1.grammar
    p = Parser(grammar)
    p.setup()
    d = driver.Driver(p.grammar)
    d.setup_parser(p)
    d.process_tokens([(token.NAME, "foo", (1, 0))])
    py.test.raises(ParseError, d.process_tokens, [(token.NAME, "bar", (1, 3))])
    d.setup_parser(p)
    d.process_tokens([(token.NAME, "foo", (1, 0)), (token.NAME, "bar", (1, 3))])



# Generated at 2022-06-11 19:53:47.023525
# Unit test for method shift of class Parser
def test_Parser_shift():
    class CheckParser(Parser):
        def shift(self, type, value, newstate, context):
            assert type == token.NAME
            assert value == "foobar"
            assert newstate == 42
            assert context.offset == 100
            assert context.line == 200

    p = CheckParser(None)
    p.shift(token.NAME, "foobar", 42, Context(100, 200))

# Generated at 2022-06-11 19:53:57.478934
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import pgen2.driver

    driver = pgen2.driver.Driver(pgen2.driver.grammar, convert=lam_sub)
    p = Parser(driver.grammar, convert=lam_sub)
    p.setup()
    input = [('NAME', 'x', (1, 0))]
    p.addtoken(*input[0])
    assert p.rootnode.children == [['NAME', 'x', (1, 0), None]]
    p.setup()
    input.append(('OP', '+', (1, 2)))
    input.append(('NAME', 'x', (1, 3)))
    for t in input:
        p.addtoken(*t)

# Generated at 2022-06-11 19:54:07.801260
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .tokenize import generate_tokens

    from . import grammar
    from . import token

    from .parse import Parser

    from . import pytree

    from .pgen2 import driver

    from . import pgen2

    lexer = driver.load_grammar()
    parser = Parser(lexer)
    parser.setup()

    origin = 'test'
    with open(origin, 'r') as f:
        tokens = generate_tokens(f.readline)

    def gen():
        for t in tokens:
            yield t
            return

    for typ, value, start, end, _ in gen():
        if typ == token.NAME:
            t = parser.classify(typ, value, start)
            parser.shift(typ, value, t, start)

# Generated at 2022-06-11 19:54:16.554264
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .driver import Driver
    d = Driver()
    d.init_grammar()
    p = Parser(d.grammar)
    p.setup()
    p.addtoken(token.OP, "(" , d.new_context(0, 0))
    p.addtoken(token.NAME, "x" , d.new_context(0, 1))
    p.addtoken(token.OP, ")" , d.new_context(0, 2))
    p.addtoken(token.NEWLINE, "\n", d.new_context(0, 3))
    print(p.rootnode)

# Generated at 2022-06-11 19:54:27.236032
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Arrange
    import blib2to3.pgen2.driver


# Generated at 2022-06-11 19:54:37.060784
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import tokenize
    from . import token

    # Parse the grammar from file
    import sys
    import os.path
    from . import pickle
    if sys.version_info[0] != 2:
        print("Skip test for Python 3")
        return
    g = pickle.load(open(os.path.join(os.path.split(__file__)[0], "Grammar.pkl"), "rb"))
    p = Parser(g)
    p.setup()
    # Read the program to parse
    with open(__file__, "r") as f:
        data = f.read()
    # Tokenize the program
    gen = tokenize.generate_tokens(StringIO(data).readline)
    # Feed tokens to the parser

# Generated at 2022-06-11 19:54:45.753574
# Unit test for method addtoken of class Parser

# Generated at 2022-06-11 19:54:54.508631
# Unit test for method setup of class Parser
def test_Parser_setup():
    class TestParser(Parser):
        def __init__(self):
            class TestGrammar(Grammar):
                start = 'symbol0'
                terminaldefs = {'token0': True, 'token1': True}
                defs = {'symbol0': [[('token0', None), ('symbol1', None)]],
                        'symbol1': [[('token1', None), ('symbol0', None)]]}

# Generated at 2022-06-11 19:55:05.127151
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    r"""Test method addtoken of class Parser.

    >>> from blib2to3.pgen2 import driver, token
    >>> g = driver.load_grammar('Python.g')
    >>> p = driver.make_pgen(g, convert=lam_sub)
    >>> p.setup()
    >>> p.addtoken(token.NUMBER, "0", (1, 0))
    False
    >>> p.addtoken(token.NEWLINE, "\n", (1, 1))
    False
    >>> p.addtoken(token.ENDMARKER, "\n", (2, 0))
    True

    """
    pass



# Generated at 2022-06-11 19:55:11.790588
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import grammar
    # Get a Grammar instance by parsing the grammar
    p = driver.load_grammar(grammar.grammar)
    # Populate the Parser instance
    gr = p.parse_grammar(grammar.grammar)
    gr.find_all()
    p = Parser(gr)
    p.setup()
    # Check that class Parser has the required attribute shift
    assert hasattr(p, "shift")
    assert isinstance(p.shift, Callable)
    # Get the definition of shift
    p.shift(0, None, 0, None)
    # Check that the definition of shift is not None
    assert not (p.shift(0, None, 0, None) is None)