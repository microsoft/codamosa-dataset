

# Generated at 2022-06-11 19:45:53.169074
# Unit test for method pop of class Parser
def test_Parser_pop():
    class TestParser(Parser):
        def call_pop(self):
            dfa, state, node = self.stack.pop()
            self.pop()
    
    p = TestParser(Grammar(), lam_sub)
    p.stack.append((None, None, (1, None, None, [])))
    p.stack.append((None, None, (2, None, None, [3])))
    p.call_pop()
    assert p.stack[0][2] == (1, None, None, [2])

# Generated at 2022-06-11 19:46:00.404705
# Unit test for method classify of class Parser
def test_Parser_classify():

    class FakeGrammar(object):
        tokens = {token.NUMBER: 1}
        keywords = {'class': 2, 'def': 3}

    p = Parser(FakeGrammar())
    assert p.classify(token.NUMBER, '7', None) == 1
    assert p.classify(token.NAME, 'class', None) == 2
    assert p.classify(token.NAME, 'def', None) == 3
    try:
        p.classify(token.NAME, 'xyzzy', None)
    except ParseError as e:
        assert e.msg == 'bad token'
        assert e.type == token.NAME
        assert e.value == 'xyzzy'
    else:
        assert False, 'Expected ParseError'



# Generated at 2022-06-11 19:46:02.172999
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar(), None)
    p.setup()
    return


# Generated at 2022-06-11 19:46:14.055021
# Unit test for method pop of class Parser
def test_Parser_pop():
    import blib2to3.pgen2.parse as parse
    import blib2to3.pgen2.driver as driver
    from . import token

    # Test when stack is empty
    pars = parse.Parser(driver.load_grammar("Grammar.txt"))
    popnode = [1, "abc", (1, None), []]
    pars.stack = []
    pars.pop()
    assert pars.stack == []
    assert pars.rootnode is None

    # Test when stack is not empty
    pars = parse.Parser(driver.load_grammar("Grammar.txt"))
    popnode = [1, "abc", (1, None), []]
    pars.stack = [(0, 1, [1, "a", (1, None), []])]
    pars.pop()
    assert pars.stack

# Generated at 2022-06-11 19:46:26.894027
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.pgen import generate_grammar
    from blib2to3.pgen2.parse import convert_tree

    def check_shift(grammar, type, value, newstate, context, expected):
        p = Parser(grammar)
        p.setup()
        p.shift(type, value, newstate, context)

# Generated at 2022-06-11 19:46:36.357558
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    from .nodes import *
    from . import python_grammar, python_grammar_no_print_statement
    from blib2to3.pgen2 import driver, tokenize

    # The assert checks are not quite correct, because the dicts
    # contain more items than the assert checks for.

    def check_tokenizer(
        grammar: Grammar,
        source: Text,
        expected_tokens: Sequence[Any],
        check_dfas: bool = True,
    ) -> None:
        tokens = list(tokenize.generate_tokens(source))
        assert 3 <= len(tokens) <= len(expected_tokens) + 2
        for token in tokens[:-2]:
            assert token in expected_tokens, token


# Generated at 2022-06-11 19:46:43.013493
# Unit test for method shift of class Parser
def test_Parser_shift():
    def classify(type: int, value: Text, context: Context) -> int:
        ilabel = self.grammar.tokens.get(type)
        return ilabel

    def convert(grammar: Grammar, node: Sequence[Any]) -> Node:
        return Node(type=node[0], children=node[3], context=node[2])

    p = Parser(Grammar, convert)
    p.shift(1, 2, 3, 4)
    p.shift(10, 20, 30, 40)
    p.shift(100, 200, 300, 400)



# Generated at 2022-06-11 19:46:54.550386
# Unit test for method pop of class Parser
def test_Parser_pop():
    class Grammar(object):
        def __init__(self):
            self.labels = {
                0: (1, ""),
                1: (2, ""),
                2: (3, ""),
                3: (4, ""),
                4: (5, ""),
            }
            self.keywords = {}
            self.tokens = {
                6: 0,
                7: 1,
                8: 2,
                9: 3,
                10: 4
            }

# Generated at 2022-06-11 19:46:57.441152
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    p = Parser(grammar.grammar, None)
    label = p.classify(token.NAME, 'with', None)
    assert label == grammar.syms.with_stmt



# Generated at 2022-06-11 19:47:07.881473
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Create a parser
    grammar = Grammar()
    parser = Parser(grammar)

    # Update the grammar
    grammar.labels = {
        0: (257, 0),
        1: (token.NUMBER, 3),
        2: (token.NUMBER, 4),
        3: (token.NUMBER, 5),
        4: (token.NUMBER, 6),
        5: (token.NUMBER, 7),
    }
    grammar.keywords = {
    }
    grammar.tokens = {
        token.NUMBER: 1,
    }

    # Create a context
    context = Context(0, 1)

    # Test
    assert parser.classify(token.NUMBER, "3", context) == 1

# Generated at 2022-06-11 19:47:20.680669
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver
    from io import StringIO

    parser = driver.load_grammar("Grammar/Grammar")
    c = Parser(parser)
    c.setup()
    for token_info in driver.tokenize("1+2", "exec"):
        c.addtoken(*token_info)
    assert c.pop() is None
    assert c.rootnode is not None
    assert str(c.rootnode) == "Module(Expr(+))"

# Generated at 2022-06-11 19:47:31.718294
# Unit test for method shift of class Parser
def test_Parser_shift():
    import unittest
    import unittest.mock as mock

    class TestParser(unittest.TestCase):
        def setUp(self):
            self.parser = Parser(grammar=mock.sentinel.grammar)
            self.type = None
            self.value = None
            self.newstate = None
            self.context = None

        def tearDown(self):
            del self.parser
            del self.type
            del self.value
            del self.newstate
            del self.context

        @mock.patch('blib2to3.pgen2.driver.Parser.shift')
        def testStandard(self, my_shift):
            self.parser.shift(
                self.type, self.value, self.newstate, self.context)

# Generated at 2022-06-11 19:47:39.075004
# Unit test for method push of class Parser
def test_Parser_push():
    # Initialize the parser
    p = Parser(Grammar())
    # Get the parser (stack) ready for parsing
    p.setup(1)
    # Push a symbol
    p.push(1, (None, None), 0, None)
    # Pop a symbol
    p.pop()
    # Push a symbol
    p.push(1, (None, None), 0, None)
    # Push a symbol
    p.push(1, (None, None), 0, None)
    # Pop a symbol
    p.pop()
    # Pop a symbol
    p.pop()



# Generated at 2022-06-11 19:47:44.702882
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from io import StringIO

    _ = StringIO("1+1")
    grammar_object = grammar.Grammar(_)
    parser_object = Parser(grammar_object)
    parser_object.setup()
    for token in "1+1":
        parser_object.addtoken("DIGITS", token, 0)
    assert parser_object.rootnode.__class__.__name__ == "Node"

# Generated at 2022-06-11 19:47:56.740467
# Unit test for method shift of class Parser
def test_Parser_shift():
    _1 = (0, 0)
    _2 = (0, 1)
    _3 = (0, 2)
    _4 = (0, 3)
    _5 = (0, 4)
    _6 = (0, 5)
    _7 = (0, 6)
    _8 = (0, 7)
    _9 = (0, 8)
    _10 = (0, 9)
    _11 = (1, 0)
    _12 = (1, 1)
    _13 = (1, 2)
    _14 = (1, 3)
    _15 = (1, 4)
    _16 = (1, 5)
    _17 = (1, 6)
    _18 = (1, 7)
    _19 = (1, 8)
    _20 = (1, 9)

# Generated at 2022-06-11 19:47:59.546108
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(object())
    p.stack = []
    assert p.stack == []
    p.push(2, 3, 4, 5)
    assert p.stack[-1][0] == 4

# Generated at 2022-06-11 19:48:05.276274
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .driver import Driver
    import sys
    import io

    # Setup
    text = "a * b"
    d = Driver()
    p = d.parser
    p.setup()
    # Parse input
    for type, value, context in d.tokenize(text):
        if p.addtoken(type, value, context):
            break
    # Test
    assert p.rootnode
    print(p.rootnode)

# Generated at 2022-06-11 19:48:17.126805
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .tokenize import generate_tokens, untokenize

    def test_pop(text: Text) -> None:
        """Test that the parser pops the root node correctly"""
        parser = Parser(grammar, convert)
        converter = convert
        parser.setup()

        tokens = generate_tokens(text)
        for _token in tokens:
            parser.addtoken(_token[0], _token[1], Context(0, 0))
        assert untokenize(parser.rootnode) == text

    grammar = Grammar(
        """
        atom: "'"
        atom: '"'
    """
    )
    parser = Parser(grammar)
    parser.setup()
    parser.pop()
    assert not parser.stack
    assert parser.rootnode == None


# Generated at 2022-06-11 19:48:24.959206
# Unit test for method push of class Parser
def test_Parser_push():  # commonly used by other tests
    import os
    import sys
    from . import driver
    from . import pytree_utils
    from . import pygram
    from . import pytree
    from . import pytokenizer
    from . import pytoken

    # Create a parser
    # This __init__ is needed for type checking and should
    # be removed as soon as the stub file is updated
    p = Parser()
    p.setup(pygram.python_grammar.start)
    # Create a token
    t = pytoken.generate_tokens("abc")[0]
    t = pytoken.TokenInfo("abc", pytoken.NAME, (1, 0), (1, 3), 1)
    # Invoke method
    p.push(t.type, (1, 2), (1, 3), t.context)


# Generated at 2022-06-11 19:48:33.559966
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2.grammar import empty_grammar
    from blib2to3.pgen2.token import tok_name

    grammar = empty_grammar

    parser = Parser(grammar)
    parser.setup()
    parser.push(1, grammar.dfas[1], 1, None)
    assert parser.stack
    dfa, state, (type, value, context, children) = parser.stack.pop()
    assert grammar.dfas[1] == dfa
    assert state == 1
    assert type == 1
    assert tok_name[type] == 'file_input'
    assert value is None
    assert context is None
    assert children == []

# Generated at 2022-06-11 19:48:45.282549
# Unit test for method pop of class Parser
def test_Parser_pop():
    pass

# Generated at 2022-06-11 19:48:56.097933
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import token, grammar, driver
    import io, unittest

    class TestCase(unittest.TestCase):
        """Test case for the method addtoken of class Parser."""

        def test_addtoken(self):
            """Test case for the method addtoken of class Parser."""

            def build_converter(grammar):
                def converter(grammar, node):
                    """Convert a node.

                    Each converter returns a node, tree, or None.
                    """
                    type, value, context, children = node
                    if children is not None:
                        return tuple(children)
                    return None
                return converter


# Generated at 2022-06-11 19:49:01.413210
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(Grammar())
    try:
        p.push(0, ((), {}), 0, None)
    except AssertionError:
        raise AssertionError('Parser.push(0, ((), {}), 0, None) raised AssertionError unexpectedly!')


# Generated at 2022-06-11 19:49:12.735236
# Unit test for method pop of class Parser
def test_Parser_pop():
    # TODO: This test is not meaningful without a grammar
    p = Parser(None)
    p.stack = []

    # Test method pop without a rootnode
    with pytest.raises(IndexError):
        p.pop()

    # Test method pop with a rootnote
    dfa_state0 = [(0, 0)]
    dfa_state1 = [(0, 1)]
    dfa_state2 = [(0, 2)]
    dfa = (
        [dfa_state0, dfa_state1, dfa_state2],
        {0: 0, 1: 0, 2: 0},
    )
    newnode = (0, None, 3, [])
    p.stack.append((dfa, 2, newnode))

    p.pop()
    assert p.rootnode == newnode

# Generated at 2022-06-11 19:49:15.608844
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver, grammar, token
    test_grammar = grammar.Grammar(open("Python.asdl"))
    test_parser = Parser(test_grammar)
    drv = driver.Driver(test_grammar, convert=lam_sub, parser=test_parser)

# Generated at 2022-06-11 19:49:17.318349
# Unit test for method shift of class Parser
def test_Parser_shift():
    pass  # To be implemented or nothing to test()



# Generated at 2022-06-11 19:49:22.158593
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .test.test_grammar import test_grammar
    from . import token

    p = Parser(test_grammar, lam_sub)
    p.setup()
    p.addtoken(token.TYPE_IGNORE, "", Context(1, 0))
    p.addtoken(token.LCURLY, "{", Context(1, 0))
    p.addtoken(token.RCURLY, "}", Context(1, 0))

# Generated at 2022-06-11 19:49:33.284254
# Unit test for method addtoken of class Parser

# Generated at 2022-06-11 19:49:44.810241
# Unit test for method pop of class Parser
def test_Parser_pop():
    # This reproduces a bug caught by test_pytree
    grammar = Grammar(
        """
        start: NAME EQUALS expr
        expr: NAME EQUALS expr | NUMBER
        """
    )

    pytree = Node(
        symbol=grammar.symbol2number["start"],
        children=[
            Leaf(token.NAME, "a"),
            Leaf(token.EQUALS, "="),
            Node(
                symbol=grammar.symbol2number["expr"],
                children=[
                    Leaf(token.NAME, "b"),
                    Leaf(token.EQUALS, "="),
                    Node(
                        symbol=grammar.symbol2number["expr"],
                        children=[
                            Leaf(token.NUMBER, "1"),
                        ]
                    )
                ]
            )
        ]
    )

    #

# Generated at 2022-06-11 19:49:54.064792
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar as G, driver

    print('Testing method addtoken of class Parser...')
    p = Parser(G.grammar, lam_sub)
    p.setup()
    for type, value, context in driver.tokenize_file('test/test-input'):
        if p.addtoken(type, value, context):
            break
    if p.rootnode is None:
        print('Error: Abstract syntax tree was not built')
    else:
        print('Abstract syntax tree =', p.rootnode)


if __name__ == "__main__":
    test_Parser_addtoken()

# Generated at 2022-06-11 19:50:15.675574
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import token
    from .tokenize import generate_tokens
    from .pgen import driver
    from .driver import parse_tokens

    # parse_tokens() calls _parse_tokens() which calls __init__() of class Parser
    # and invokes the method parse() which in turn calls the method setup()
    # and finally the method addtoken() which in turns calls the method pop()
    # which we are testing here.
    def testParse():
        try:
            parse_tokens(list(generate_tokens('if 1:')))
        except ParseError:
            print('ParseError')
    testParse()


if __name__ == "__main__":
    # Testing code
    from . import grammar
    from . import token

    g

# Generated at 2022-06-11 19:50:28.154470
# Unit test for method setup of class Parser

# Generated at 2022-06-11 19:50:33.934538
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import ast
    import os
    import sys
    import tempfile

    grammar = Grammar(__file__)
    source = """
        if 1:
            2
        if 3:
            4
    """

    parser = Parser(grammar)
    parser.setup()
    users_site = tempfile.mkdtemp()
    if sys.path[-1] == '':
        # Use the current working dir instead of an empty string when
        # compiling the input source, so the resulting code object has
        # the correct filename.
        sys.path[-1] = os.getcwd()
    tokenizer = tokenize.tokenize(iter(source.splitlines(keepends=True)).__next__)

# Generated at 2022-06-11 19:50:44.631263
# Unit test for method classify of class Parser

# Generated at 2022-06-11 19:50:52.826783
# Unit test for method pop of class Parser
def test_Parser_pop():
    class T(object):
        def convert(self, grammar: Grammar, node: RawNode) -> Node:
            assert node[3] is not None
            return Node(type=node[0], children=node[3], context=node[2])
    
    g = Grammar()
    g.start = 1
    g.labels = self.grammar.labels
    p = Parser(g, T().convert)
    p.setup()
    p.addtoken(1, "a", None)
    p.addtoken(2, "b", None)

# Generated at 2022-06-11 19:51:00.346680
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver

    def convert(grammar, node):
        return node

    parser = Parser(driver.get_grammar(), convert)
    parser.setup()

    nodes = []
    i = parser.grammar.tokens["NAME"]
    nodes.append((i, "a", None, None))
    nodes.append((i, "b", None, None))
    nodes.append((i, "c", None, None))
    parser.push(i, parser.grammar.dfas[i], 0, None)
    assert parser.stack[-1] == (parser.grammar.dfas[i], 0, nodes[0])
    parser.pop()
    assert parser.stack[-1] == (parser.grammar.dfas[i], 0, nodes[1])
    parser.pop()

# Generated at 2022-06-11 19:51:01.642973
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import doctest
    return doctest.DocTestSuite(optionflags=(doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE))

# Generated at 2022-06-11 19:51:03.384953
# Unit test for method setup of class Parser
def test_Parser_setup():
    assert Parser.setup.__defaults__ == (None,)

# Generated at 2022-06-11 19:51:10.864802
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, token

    g = grammar.grammar
    p = Parser(g)
    assert p.classify(token.NAME, "for", None) == token.NAME
    assert p.classify(token.NAME, "def", None) == token.NAME
    assert p.classify(token.NAME, "as", None) == token.NAME
    assert p.classify(token.NAME, "foobar", None) is None

# Generated at 2022-06-11 19:51:20.882612
# Unit test for method pop of class Parser
def test_Parser_pop():
    def convert(grammar, node):
        return node

    from blib2to3.pgen2 import driver
    parser = Parser(driver.load_grammar('Python', verbose=False), convert)
    parser.setup()
    parser.addtoken(257, 'x', Context(0, 0))
    parser.addtoken(258, 'y', Context(0, 0))
    parser.addtoken(259, 'z', Context(0, 0))
    parser.addtoken(260, 'a', Context(0, 0))
    parser.addtoken(261, 'b', Context(0, 0))
    parser.addtoken(262, 'c', Context(0, 0))
    parser.addtoken(262, 'c', Context(0, 0))

# Generated at 2022-06-11 19:51:48.836923
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pygram import grammar
    from blib2to3.pgen2 import driver
    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    tok = driver.Tok(0, 0, 0, "a")
    p.shift(tok.type, tok.string, 10, tok.context)
    assert p.stack[0] == (g.dfas[g.start], 10, (g.start, None, None, []))

# Generated at 2022-06-11 19:51:59.331831
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_grammar: Grammar = Grammar()
    test_grammar.symbols = {
        "test_symbol_1": 0,
        "test_symbol_2": 1,
        "test_symbol_3": 2,
        "test_symbol_4": 3,
        "test_symbol_5": 4,
        "test_symbol_6": 5,
        "test_symbol_7": 6,
        "test_symbol_8": 7,
    }
    test_grammar.keywords = {"def": 1, "from": 2, "import": 3}
    test_grammar.nonterminals = {
        test_symbol: index for index, test_symbol in enumerate(test_grammar.symbols)
    }
    test_grammar.lab

# Generated at 2022-06-11 19:52:08.271491
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import io
    from . import tokenize
    from . import dfa
    from . import grammar
    from blib2to3.pgen2.parse import driver

    g = grammar.grammar
    d = dfa.dfas
    p = Parser(g, driver.convert)

    p.setup()
    p.addtoken(tokenize.ENCODING, "utf-8", (0, 0))
    p.addtoken(tokenize.NEWLINE, "\n", (1, 0))
    p.addtoken(token.INDENT, "\n", (2, 0))
    p.addtoken(tokenize.NAME, "def", (3, 0))
    p.addtoken(tokenize.NAME, "foo", (3, 4))

# Generated at 2022-06-11 19:52:12.099050
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver

    p = driver.Parser()
    p.setup()
    p.setup(start=2)
    p.setup(start="foo")
    p.setup(start="file_input")

# Generated at 2022-06-11 19:52:22.754123
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from .pgen2 import tokenize

    def parse(text: str) -> RawNode:
        with open(grammar.__file__) as f:
            g = grammar.Grammar(f.read())
        p = Parser(g)
        p.setup()
        for t in tokenize.generate_tokens(lambda: text):
            if p.addtoken(t.type, t.string, t.start):
                break
        return p.rootnode

    def check(text: str) -> bool:
        bad = False
        node = parse(text)
        print(node)
        if node:
            (type, value, context, children) = node
            assert type == 1
            assert value is None
            assert context is None
            assert children is not None

# Generated at 2022-06-11 19:52:30.579228
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    from . import tokenize
    sys.path.append("../")

    grammar_file = "Grammar/Grammar"
    grammar = Grammar(grammar_file)
    parser = Parser(grammar)
    parser.setup()

    file = "test_files/test_47.py"
    with open(file, "r") as file:
        tokens = tokenize.generate_tokens(file.readline)
    for token in tokens:
        parser.addtoken(token[0], token[1], token[2])

# Generated at 2022-06-11 19:52:40.444145
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # For back-compatibility, this test should raise an exception
    p = None  # type: Optional[Parser]
    try:
        p = Parser(None, None)
        p.addtoken(0, None, None)
    except ParseError:
        pass

    if p and p.stack is not None:
        print("Parser.addtoken not raising exception on empty stack")

# Local variables:
# tab-width: 4
# indent-tabs-mode: nil
# End:
# vim: set expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-11 19:52:49.187507
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    # Load the grammar
    gr = grammar.grammar("Python.g")

    # Create a parser
    parser = Parser(gr)

    # Parse an expression
    parser.setup("expr")
    for tok in [[token.LPAR, "("], [token.NAME, "x"], [token.RPAR, ")"]]:
        parser.addtoken(*tok)

    # And another one
    parser.setup("expr")
    for tok in [[token.LPAR, "("], [token.NAME, "y"], [token.RPAR, ")"]]:
        parser.addtoken(*tok)

    # Get the syntax tree
    tree = parser.rootnode
    assert tree.type == "expr"

    # Print it
    print(tree)

    # Convert it to an expression


# Generated at 2022-06-11 19:52:52.430801
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2 import driver

    p = Parser(driver.load_grammar("Grammar/Grammar"))
    assert p.grammar.start is not None
    assert p.convert is not None
    p.setup()

# Generated at 2022-06-11 19:53:02.918974
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    p = Parser(grammar.grammar)
    assert p.convert(grammar.grammar, (1, 'value', None, None)) is None
    assert len(p.stack) == 0

    gp = p.convert(grammar.grammar, (1, None, None, []))
    assert isinstance(gp, list)
    assert len(gp) == 0

    leaf = Leaf(1, 'value', None)
    assert p.convert(grammar.grammar, (1, 'value', None, None)) == leaf

    node_empty = Node(1, [], None)
    assert p.convert(grammar.grammar, (1, None, None, [])) == node_empty

    node_leaf = Node(1, [leaf], None)
    assert p.con

# Generated at 2022-06-11 19:53:40.813742
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import token

    class MockedGrammar(object):
        def __init__(self, labels):
            self.labels = labels
            self.keywords = {}
            self.tokens = {token.NAME: 1}

    labels = [
        (token.NAME, None),  # 0
        (token.STRING, None),  # 1
    ]
    mocked_grammar = MockedGrammar(labels)

    parser = Parser(mocked_grammar)

    parser.classify(token.NAME, "foo", None)
    parser.classify(token.STRING, "foo", None)

    try:
        parser.classify(token.NUMBER, "foo", None)
    except ParseError:
        import sys
        import traceback

        _

# Generated at 2022-06-11 19:53:54.002618
# Unit test for method pop of class Parser
def test_Parser_pop():
    def convert(grammar, node):
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    gram = Grammar()
    gram.token('NAME')
    gram.token('EQUAL', r'=')
    gram.token('NL')
    gram.start = 'file_input'
    gram.rule('file_input', [], [
        ('statement', 'file_input', None, 0, -1),
    ])
    gram.rule('statement', [], [
        ('NAME', 'EQUAL', None, 1, 0),
    ])
    gram.dfa = [(0, 1), [(0, 3), (1, 2)], [], [(0, 4)], [(0, 4)]]

# Generated at 2022-06-11 19:54:03.122535
# Unit test for method setup of class Parser
def test_Parser_setup():
    # Verify that the setup method sets the stack to length 1 and
    # that the first element of the stack has the correct values
    # for each of its elements.
    # Note that the grammar.Grammar instance is not checked since
    # this method is in the same file as the grammar instance.
    p = Parser(object)
    p.setup(1)
    assert len(p.stack) == 1
    assert p.stack[0] == (p.grammar.dfas[1], 0, (1, None, None, []))
    assert p.rootnode is None


# Generated at 2022-06-11 19:54:13.264529
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def addtoken(type, value, context):
        """Helper method.

        Adds a token and returns True if the token
        signifies the end of the program.

        """
        return p.addtoken(type, value, context)

    class MockGrammar:
        """Mock class.

        Used to test the Parser's ability to handle
        Grammars with no keywords or tokens.

        """
        start = 258
        keywords = {}
        tokens = {}
        labels = [(0, 1), (256, 2)]

    g = MockGrammar()
    exception_raised = False
    p = Parser(g)
    p.setup()

    try:
        addtoken(0, 0, 0)
    except ParseError:
        exception_raised = True

    assert exception_raised


# Generated at 2022-06-11 19:54:20.893022
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import tokenize

    with open("Grammar/Grammar") as gramf:
        gr = grammar.Grammar(gramf)
    pr = Parser(gr)
    pr.setup()

    with open("Grammar/Grammar") as gramf:
        lines = list(gramf)
    tok = tokenize.generate_tokens(iter(lines).__next__)
    for toknum, tokval, start, end, line in tok:
        if pr.addtoken(toknum, tokval, start):
            break



# Generated at 2022-06-11 19:54:33.217576
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Don't test on a real grammar; we're testing addtoken, not the
    # whole parsing process.  (We're testing only the inner loop here.)
    labels = [
        ("LPAR", "(", 1),
        ("RPAR", ")", 2),
        ("PLUS", "+", 3),
        ("MINUS", "-", 4),
        ("NAME", "a", 5),
        ("NAME", "b", 6),
    ]
    keywords = {}
    tokens = {
        token.LPAR: "LPAR",
        token.RPAR: "RPAR",
        token.PLUS: "PLUS",
        token.MINUS: "MINUS",
        token.NAME: "NAME",
    }

# Generated at 2022-06-11 19:54:44.815101
# Unit test for method pop of class Parser
def test_Parser_pop():
    class TestGrammar(object):

        dfas: Dict[int, List[List[Tuple[int, int]]]] = {
            1: [
                [],
                [(0, 0)],
                [(1, 2), (1, 3), (0, 0)],
                [(2, 4), (0, 0)],
            ]
        }

    class TestParser(Parser):

        grammar = TestGrammar()

    p = TestParser(TestGrammar)
    p.setup()

# Generated at 2022-06-11 19:54:52.941107
# Unit test for method pop of class Parser
def test_Parser_pop():
    p = Parser(None,None)
    p.stack=[(None, None, (3, None, None, [])),
             (None, None, (2, None, None, [])),
             (None, None, (1, None, None, []))]
    p.pop()
    assert(p.stack==[(None, None, (3, None, None, [])),
             (None, None, (2, None, None, []))])
    assert(p.rootnode.type==1)
    p.pop()
    assert(p.stack==[(None, None, (3, None, None, []))])
    assert(p.rootnode.type==2)
    assert(p.rootnode.children==[])
    p.pop()
    assert(p.stack==[])
   

# Generated at 2022-06-11 19:55:00.728664
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = Grammar()
    
    parser = Parser(grammar)
    parser.push(3, None, 1, None)
    
    assert parser.stack[-1][0] == None
    assert parser.stack[-1][1] == 1
    assert parser.stack[-1][2][0] == 3



# Generated at 2022-06-11 19:55:09.434724
# Unit test for method pop of class Parser
def test_Parser_pop():
    import time
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2 import token
    time_0 = time.clock()
    p = Driver().make_parser("blib2to3/Grammar.txt")
    time_1 = time.clock()
    print("time to create parser:", time_1 - time_0)
    time_0 = time.clock()
    p.setup()
    time_1 = time.clock()
    print("time to set up parser:", time_1 - time_0)
    p.addtoken(token.NAME, "Parser", (1, 0))
    p.addtoken(token.NAME, "test_Parser", (1, 0))
    p.addtoken(token.NAME, "pop", (1, 0))
   

# Generated at 2022-06-11 19:55:45.428506
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver, tokenize, token

    from tests.test_blib2to3 import lib2to3_grammar_file, lib2to3_grammar_pgen_driver

    tokens: Sequence[Tuple[int, Optional[Text], Context]] = []

    def addtoken(type: int, value: Optional[Text], context: Context) -> bool:
        print("Token:", token.tok_name[type], value)
        tokens.append((type, value, context))
        if type == token.ENDMARKER:
            return True  # Done
        return False
