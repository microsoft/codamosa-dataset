

# Generated at 2022-06-11 19:45:59.028492
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.driver as driver
    p = Parser(driver.load_grammar())
    p.setup()
    p.shift(1, "x", 2, (1, 2))
    p.shift(2, "y", 1, (2, 4))
    assert not p.stack
    assert p.rootnode is not None
    assert p.rootnode.children[0].type == "x"
    assert p.rootnode.children[1].type == "y"
    # Check caching of DFA transitions
    assert p.stack[0][0][0] is p.stack[0][0][0]
    assert p.stack[0][0] is not p.stack[1][0]

# Generated at 2022-06-11 19:46:10.620903
# Unit test for method setup of class Parser
def test_Parser_setup():
    from .tokenize import generate_tokens

    def print_tokens(tokens):
        for type, value, (srow, scol), (erow, ecol), line in tokens:
            print("     Token type:", type, token.tok_name[type])
            print("      Token text:", repr(value))
            print("  Token position:", (srow, scol), "-", (erow, ecol))

    print("Simple expression")
    # lexer - convert characters to tokens
    src = "2 + 3 + 4"
    gen = generate_tokens(src)

    p = Parser(Grammar())
    p.setup()

# Generated at 2022-06-11 19:46:14.160392
# Unit test for method shift of class Parser
def test_Parser_shift():
    g = Grammar()
    p = Parser(g)
    p.setup()
    t = token.NT_OFFSET + 1
    p.shift(token.NT_OFFSET, "test", 0, Context(0, 0, ""))

# Generated at 2022-06-11 19:46:26.894236
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.token as token
    from . import convert

    g = grammar.grammar
    p = Parser(g, convert.convert)
    p.setup()

    for t, v, c in [
        (token.NAME, "x", "i1"),
        (token.EQUAL, "=", "i2"),
        (token.NAME, "y", "i3"),
        (token.PLUS, "+", "i4"),
        (token.NAME, "z", "i5"),
        (token.NEWLINE, "\n", "i6"),
        (token.NAME, "a", "i7"),
    ]:
        assert not p.addtoken(t, v, c)


# Generated at 2022-06-11 19:46:36.358109
# Unit test for method classify of class Parser
def test_Parser_classify():
    class MockGrammar:
        def __init__(self) -> None:
            self.tokens = {
                -2: 256,
                -1: 257,
                1: 258,
                2: 259,
                3: 260,
            }

            self.keywords = {
                "keyword1": 2,
                "keyword2": 3,
            }

    class MockContext:
        def __init__(self, value) -> None:
            self.value = value

        def __str__(self) -> Text:
            return repr(self.value)

    ctx = MockContext('ctx')
    grammar = MockGrammar()
    parser = Parser(grammar)
    # Test for invalid token
    invalid_token = 999

# Generated at 2022-06-11 19:46:48.788821
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class MockParser(Parser):
        def __init__(self, grammar: Grammar) -> None:
            super().__init__(grammar)
            self.stack = []

    def make_dfa(
        states: Sequence[Tuple[Sequence[Tuple[int, int]], bool]]
    ) -> List[List[Tuple[int, int]]]:
        dfas = []
        for arcs, accept in states:
            dfa = []
            dfas.append(dfa)
            if accept:
                dfa.append((0, len(dfas) - 1))
            for label, nextstate in arcs:
                dfa.append((label, nextstate))
        return dfas


# Generated at 2022-06-11 19:47:00.645055
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .driver import Driver
    from .pgen import load_grammar

    def test(source: Text, flags: int) -> NL:
        tree, _ = load_grammar(Driver(parser_driver=None), flags)
        driver = Driver(tree, parse_input=True)
        root, _ = driver.parse_string(source)
        assert root
        return root

    res = test("foo", None)
    assert isinstance(res, Leaf), res
    assert res.value == "foo", res.value

    res = test("foo.bar", None)
    assert isinstance(res, Node), res
    assert len(res.children) == 3, res.children
    assert res.children[-1].value == "bar", res.children[-1].value

    res = test("foo()", None)

# Generated at 2022-06-11 19:47:10.158120
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import tokenize
    from blib2to3.pgen2.grammar import Grammar
    g = Grammar()
    p = Parser(g)
    p.setup()
    def get_node(tok, nexttok):
        p.addtoken(tok, nexttok.string, nexttok)
        dfa, state, node = p.stack[-1]
        return node
    for t in tokenize.generate_tokens(BytesIO("a = 1").readline):
        node = get_node(t.type, t)
        assert node[0] == token.NAME
        assert node[1] == "a"
        break

# Generated at 2022-06-11 19:47:20.862528
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(Grammar())
    p.setup()
    p.push(3, [(0, 0)], 0, ((1, 2), (3, 4)))
    p.push(9, [(0, 0)], 0, ((1, 2), (3, 4)))
    assert p.stack == [(((0, 0), (0, 0)), 0, (1, None, None, [])),
                       (((0, 0), (0, 0)), 0, (9, None, ((1, 2), (3, 4)), []))]

if __name__ == "__main__":
    import sys
    from . import driver

    driver.main("../Grammar/Grammar", sys.argv[1:])

# Local variables:
# tab-width: 4
# fill-column: 78
#

# Generated at 2022-06-11 19:47:24.295198
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Test method Parser.classify"""
    pg = Grammar()
    pg.load_data(grammar_data)
    p = Parser(pg)

    test_value = "test_value"
    test_tokens = [p.classify(token.NAME, test_value, Context())]
    assert test_tokens == [1]



# Generated at 2022-06-11 19:47:37.433693
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Unit test for method classify of class Parser."""
    import pprint
    from blib2to3.pgen2 import tokenize
    from blib2to3.pygram import python_grammar

    g = python_grammar
    p = Parser(g)
    input = "def f(): pass\n"
    tokens = tokenize.generate_tokens(input.__iter__().__next__)
    p.setup()
    for type, value, context in tokens:
        ilabel = p.classify(type, value, context)
        print("type=%s, value=%s, context=%s, ilabel=%s" % (
            type, repr(value), pprint.pformat(context), ilabel))



# Generated at 2022-06-11 19:47:49.013320
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = Grammar()
    def parse(grammar, string):
        p = Parser(grammar)
        for tok in string:
            p.shift(ord(tok), tok, 1, (1,1))
        return p.stack
    def test(string, start, s):
        assert parse(grammar, string) == [(start, 0, (s, None, None, []))]
    start = [(0,0),(0,1),(1,1)]
    stack = [(start, 0, (0, None, None, [])), (start, 0, (0, None, None, [])),
             (start, 1, (1, None, None, []))]
    test('1', start, 1)
    assert parse(grammar, '11') == stack

# Generated at 2022-06-11 19:47:59.825580
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    def lam_sub(grammar: Grammar, node: RawNode) -> NL:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    p = Parser(grammar.grammar, lam_sub)
    p.setup()

    st = tokenize.generate_tokens(
        "import sys\nimport os\na = 1 + 2 + 3\n"
        "print(a)\nif a == 6:\n  print(a)\n"
        "b = {'a': 1, 'b': 2, 'c': 3}\nprint(b)\n"
    )

# Generated at 2022-06-11 19:48:07.347092
# Unit test for method shift of class Parser
def test_Parser_shift():
    cache = {}
    def load_grammar(filename: Text) -> Grammar:
        try:
            return cache[filename]
        except KeyError:
            g = Grammar()
            g.load(filename)
            cache[filename] = g
            return g

    p = Parser(load_grammar("Grammar.txt"))
    p.setup()
    p.shift(1, 0, 0, None)
    p.shift(1, 0, 0, None)
    p.shift(1, 0, 0, None)

# Generated at 2022-06-11 19:48:18.807523
# Unit test for method pop of class Parser
def test_Parser_pop():
    class DummyGrammar:
        def __init__(self):
            self.conversion = {}

    class DummyParser(Parser):
        def convert(self, grammar: Grammar, node: RawNode) -> Union[Node, Leaf]:
            return grammar.conversion[node[0]]

    a = DummyGrammar()
    b = DummyParser(a)
    a.conversion[0] = 0
    a.conversion[1] = 1
    b.stack = [(0, 0, (0, None, None, [(1, None, None, [])])), (1, 0, (1, None, None, []))]
    b.pop()
    assert b.stack == [(0, 0, (0, None, None, [1]))]
    b.pop()

# Generated at 2022-06-11 19:48:32.010669
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    import io

    class TestCase(unittest.TestCase):
        """Unit tests for addtoken."""

        def setUp(self):
            """A simple Python grammar."""
            from . import grammar

            self.grammar = g = grammar.Grammar()
            g.start = "stmt"
            g.tokens = {
                256: 1,
                257: 2,
                258: 3,
                259: 4,
                260: 5,
                261: 6,
                262: 7,
                263: 8,
                264: 9,
                265: 10,
                266: 11,
                267: 12,
                268: 13,
                269: 14,
                270: 15,
                271: 16,
            }

# Generated at 2022-06-11 19:48:41.244354
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.token import tokenize, generate_tokens
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2 import driver

    g = driver.load_grammar('blib2to3/pytree.grammar')


# Generated at 2022-06-11 19:48:46.121923
# Unit test for method shift of class Parser
def test_Parser_shift():
    def test(
        arg_type: int, arg_value: Optional[Text], arg_newstate: int, arg_context: Context
    ) -> bool:
        p = Parser(Grammar())
        try:
            p.shift(arg_type, arg_value, arg_newstate, arg_context)
        except IndexError:
            return True
        return False

    assert test(None, None, None, None)


# Generated at 2022-06-11 19:48:56.893125
# Unit test for method pop of class Parser
def test_Parser_pop():
    class MockGrammar(object):
        def __init__(self,
                     dfas=[[(0, 1), (1, 1), (2, 1)],
                           [(0, 2), (1, 2), (2, 2)]],
                     labels={0: 'fake',
                             1: 'fake',
                             2: 'fake'}
        ):
            self.dfas = dfas
            self.labels = labels

    grammar = MockGrammar()
    p = Parser(grammar)
    p.setup()
    p.stack = [(grammar.dfas[0], 0, (0, None, None, [])),
               (grammar.dfas[1], 1, (1, None, None, []))]
    p.pop()

# Generated at 2022-06-11 19:49:06.736768
# Unit test for method pop of class Parser
def test_Parser_pop():
    import unittest

    class Test_Parser_pop(unittest.TestCase):
        def test_empty_stack(self):
            p = Parser(None)
            p.stack = []
            p.rootnode = "test"
            p.pop()
            self.assertEqual(p.rootnode, "test")

        def test_not_empty_stack(self):
            p = Parser(None)
            p.stack = [(None, None, ("", None, None, []))]
            p.rootnode = "test"
            p.pop()
            self.assertEqual(p.rootnode, [])

    unittest.main()



# Generated at 2022-06-11 19:49:19.364156
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import drivers
    p = drivers.get_parser()
    p.setup()
    assert p.stack == [(([([(9, 0)], None), ([(5, 1), (8, 2), (12, 1), (14, 3)], None), ([(9, 4)], None)], {0: 0, 4: 0}), 0, (20, None, None, []))]


# Generated at 2022-06-11 19:49:31.017302
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import literals
    from . import operator_
    from . import parsing_extras

    from .grammar import Grammar

    from .pygram import python_grammar
    from .pygram import python_symbols
    from .pygram import python_operators

    from .pgen import tokenize

    pygram = Grammar(python_grammar, python_symbols, python_operators)
    pygram.dfadict = driver.dfas

    test_Parser_shift.p = Parser(pygram, parsing_extras.convert)

    test_Parser_shift.p.setup()

    # test case 1: the token is NOT in pygram.tokens
    test_Parser_shift.p.addtoken(tokenize.NUMBER, '1', (1, 0))



# Generated at 2022-06-11 19:49:38.442905
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class TestParser(Parser):
        def __init__(self, compiled_grammar, convert=None):
            self.labels = compiled_grammar.labels
            self.keywords = compiled_grammar.keywords
            self.tokens = compiled_grammar.tokens
            self.start = compiled_grammar.start
            self.dfas = compiled_grammar.dfas

    from . import grammar, token

    class TestResult:
        def __init__(self):
            pass

        def get_token_ids(self):
            return self.token_ids

        def get_labels(self):
            return self.labels

        def get_keywords(self):
            return self.keywords

        def get_tokens(self):
            return self.tokens


# Generated at 2022-06-11 19:49:49.362885
# Unit test for method shift of class Parser

# Generated at 2022-06-11 19:49:56.725989
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import parser
    from . import tokenizer
    from . import grammar

    text = "1"
    g = grammar.parse_grammar(grammar.grammar_nt)
    p = parser.Parser(g)
    t = tokenizer.generate_tokens(text)
    for type, value, context, start in t:
        p.addtoken(type, value, context)
    assert p.stack == [((g.dfas[g.start], 1, (g.start, None, None, [1])))]

# Generated at 2022-06-11 19:50:02.528746
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Unit test for method classify of class Parser"""
    assert Parser(Grammar).classify(token.NAME, "NAME", (0, 0)) == 2
    assert Parser(Grammar).classify(token.NAME, "not", (0, 0)) == 1
    assert Parser(Grammar).classify(token.NAME, "and", (0, 0)) == 4
    assert Parser(Grammar).classify(token.NAME, "while", (0, 0)) == 3


# Generated at 2022-06-11 19:50:14.022690
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pytest
    from . import _test_grammar

    # Test with a mixture of abstract and concrete trees
    def convert(grammar: Grammar, node: RawNode) -> Optional[NL]:
        if node[0] == 0:  # BOF
            root = Node(type=0, children=node[-1], context=node[2])
            root.yy = "yy"
            return root
        elif node[0] == 1:  # BOF
            root = Leaf(type=1, value=node[1], context=node[2])
            root.yy = "yy"
            return root
        return None

    parser = Parser(_test_grammar, convert)
    parser.setup()
    parser.addtoken(2, "x", "abc")  # BOF

# Generated at 2022-06-11 19:50:23.979796
# Unit test for method classify of class Parser
def test_Parser_classify():
    class MockGrammar(object):
        def __init__(self):
            self.tokens = {}
            self.labels = {}
            self.keywords = {}

        def get_keyword(self, keyword: Any) -> Any:
            return self.keywords[keyword]

    from blib2to3 import pygram
    from blib2to3.pgen2 import tokenize
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pygram import python_operators as ops
    from blib2to3 import pytree

    g = MockGrammar()
    g.tokens[tokenize.NUMBER] = 1
    g.labels[1] = (tokenize.NUMBER, "3")


# Generated at 2022-06-11 19:50:30.232840
# Unit test for method push of class Parser
def test_Parser_push():
    # dummy Grammar instance
    tokens = []
    labels = []
    states = [[]]
    nttype = 0
    dfas = {nttype: (states, [])}
    keywords = {}
    grammar = Grammar(tokens, labels, states, nttype, dfas, keywords)

    # dummy newdfa
    newdfa = (states, [])

    parser = Parser(grammar, None)
    parser.stack = []
    parser.push(nttype, newdfa, 0, None)

    assert parser.stack == [(newdfa, 0, (nttype, None, None, []))]

# Generated at 2022-06-11 19:50:42.885542
# Unit test for method pop of class Parser
def test_Parser_pop():
    class Grammar1(Grammar):
        dfas: Dict[int, DFAS] = {}
        labels = [
            [None, None],
            [token.NUMBER, None],
            ["expr", None],
            [";", None],
            [None, "2"],
            [";", None],
        ]

    g = Grammar1()
    # expr
    g.dfas[3] = [[(0, 1), (0, 2), (1, 3), (2, 0)], {0: 1, 1: 2, 2: 3, 3: 0}]
    # ;
    g.dfas[4] = [[(0, 4)], {0: 4}]

    p: Parser = Parser(g)
    p.setup()

# Generated at 2022-06-11 19:51:00.303576
# Unit test for method push of class Parser
def test_Parser_push():

    class MyGrammar(Grammar):
        tokens = [
            "NUMBER",
            "PLUS",
            "TIMES",
            "LPAR",
            "RPAR",
        ]
        symbols = ["expr"]
        start = "expr"

        left = [["PLUS"]]
        right = []


# Generated at 2022-06-11 19:51:12.945279
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Simulate addtoken() getting to the point where it needs "foo" to
    # enter the state labelled by "pop".  We create a new token
    # called "pop" and give it the literal "foo", and then fool
    # addtoken() into pushing a state with that new token in it.

    # The fake tokenizer
    def tokenizer(f):
        yield 1, "foo", (1, 0)
        yield 0, "", (1, 0)

    # The fake grammar
    class G:
        def __init__(self):
            self.start = 256
            self.dfas: Dict[int, Dict[int, Dict[Any, int]]] = {}
            self.labels = [(256, None)]
            self.keywords = {}

    # Fake-load the grammar
    g = G()


# Generated at 2022-06-11 19:51:14.969555
# Unit test for method pop of class Parser
def test_Parser_pop():
    p = Parser(Grammar())
    p.setup(start=0)
    p.pop()

# Generated at 2022-06-11 19:51:21.620248
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    g = grammar.grammar

    p = Parser(g)
    p.setup(start=g.symbol2number["file_input"])
    
    p.shift(token.NAME, "string", state=0, context=Context(None, (1, 1), (2, 3)))

    assert p.stack[-1][2][3][0].value == "string"



# Generated at 2022-06-11 19:51:27.778362
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(Grammar(grammar_file=None))
    p.stack = [(0, 0, 0)]
    p.push(0, 0, 0, 0)
    assert p.stack == [(0, 0, 0), (0, 0, 0)]


# Generated at 2022-06-11 19:51:35.256396
# Unit test for method pop of class Parser
def test_Parser_pop():
    class myGrammar:
        num_labels = 3
        labels = [
            (token.T_TEST_VALUE, "T_TEST_VALUE"),
            (token.T_TEST_LABEL, "T_TEST_LABEL"),
            (token.T_TEST_2_LABEL, "T_TEST_2_LABEL"),
        ]
        start = token.T_TEST_VALUE

    class myRawNode:
        pass

    class myNode:
        pass

    def convert(blah: Grammar, blah2: RawNode) -> Node:
        return myNode()

    parser = Parser(myGrammar(), convert)

    # push a symbol

# Generated at 2022-06-11 19:51:46.684959
# Unit test for method shift of class Parser
def test_Parser_shift():
    import sys
    import io
    from pprint import pprint

    grammar = Grammar(sys.modules[__name__].__dict__)
    parser = Parser(grammar, lam_sub)
    parser.setup(0)

    s = io.StringIO("[1]")
    t = token.generate_tokens(s.readline)
    for tok in t:
        if tok[0] != token.ENCODING:
            parser.addtoken(tok[0], tok[1], tok[2])

    print(parser.stack)
    print(parser.rootnode)


if __name__ == '__main__':
    test_Parser_shift()

# Generated at 2022-06-11 19:51:53.280645
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .grammar import Grammar

    grammar = Grammar()
    p = Parser(grammar)
    p.setup()
    assert p.classify(token.NAME, "if", Context()) == 5  # should be the 'if' token
    assert p.classify(token.NAME, "if2", Context()) == 1  # should be the 'NAME' token



# Generated at 2022-06-11 19:52:04.050963
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3 import pygram
    from blib2to3.pgen2.parse import ParseError, Parser
    from blib2to3.pgen2.tokenize import generate_tokens, TokenInfo
    from itertools import chain

    # Get token list
    source = "a = (1, 2, 3)\nb = [4, 5, 6]\nc = {7, 8, 9}\n"
    token_info_gen = generate_tokens(chain([source], TokenInfo(source, 1, 0)))
    tokens = list(token_info_gen)
    # Create parser
    parser = Parser(pygram.python_grammar)
    # Parse
    parser.setup()
    while True:
        token_info = tokens.pop(0)

# Generated at 2022-06-11 19:52:14.746490
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .token import tok_name

    def get_labels(g, tp):
        if tp in g.tokmap:
            return [g.tokmap[tp]]
        elif tp in g.keywords:
            return [g.keywords[tp]]
        assert tp == token.NAME
        return list(g.keywords.values()) + g.tokens.values()

    def test_addtoken(src, g, tps):
        # src is a sequence of (type, value) pairs
        # g is a grammar
        # tps is a sequence of possible terminals for a name token
        seq = []
        for tp, val in src:
            labels = get_labels(g, tp)

# Generated at 2022-06-11 19:52:45.285313
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from blib2to3.pgen2.tokenize import generate_tokens
    from sys import argv
    from io import StringIO
    from .driver import Driver
    from . import parse
    from .pygram import python_grammar
    from . import pytree

    Program = argv[1]
    s = StringIO(Program)

    for _ in range(len(argv)):
        argv.pop()
    p = Parser(python_grammar)
    p.setup()

    for type, value, context, _ in generate_tokens(s.readline):
        type, value = Driver(type, value, context)
        if type == token.ENDMARKER:
            break
        if type == token.ENCODING:
            continue

# Generated at 2022-06-11 19:52:54.427960
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .pgen import driver

    class MyParser(Parser):
        def __init__(self, grammar, driver):
            Parser.__init__(self, grammar, driver.transform)

    driver = driver.Driver(MyParser, "grammar.pickle", {"p": "mypars", "symbols": "syms"})
    # Test method pop()
    # Note: method pop() depends on the code of method shift() and method push()
    # Test parser with simple grammar
    inp = """\
    name : NAME
    names : name names
    """
    symbols = ("NAME", "names", "name")
    syms = {}
    for sym in symbols:
        syms[sym] = sym
    mypars = driver.pgen(inp, "simple_grammar")
    mypars.setup

# Generated at 2022-06-11 19:53:03.708462
# Unit test for method push of class Parser
def test_Parser_push():
    """ Unit test for method push of class Parser """
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pgen2 import grammar

    the_grammar = grammar.grammar
    # the_grammar.symbol2label = {key:value for (key,value) in the_grammar.symbol2label.items() if value[0] != 'STORE_'}
    # the_grammar.labels = {value:key for (key,value) in the_grammar.symbol2label.items()}
    # the_grammar.symbol2number = {k:v for k,v in the_grammar.symbol2number.items() if type(v) == int}
    # the_grammar.symbol2number[None] = 0
   

# Generated at 2022-06-11 19:53:13.229770
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.driver as driver
    import sys

    def test(gr: Grammar, type: int, tok: Optional[Text]) -> None:
        if tok is None:
            print(type, ":", gr.labels[type])
        else:
            print(tok, "->", gr.labels[type])
        p = Parser(gr)
        p.setup()
        n = driver.token2tuple(type, tok)
        p.addtoken(n[0], n[1], n[2])

    grammarname = sys.argv[1]
    # Deal with a metagrammar.
    if grammarname == "metagrammar.txt":
        grammarname = "grammar.txt"

# Generated at 2022-06-11 19:53:23.407541
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    P = Parser(grammar.grammar)
    P.setup()
    grammar.tokens(P.addtoken, "1 + 2")
    assert P.rootnode.leaf.value == "1 + 2"

    P = Parser(grammar.grammar)
    P.setup()
    grammar.tokens(P.addtoken, "while 1:\n    # Comment\n    a = b + c\n")
    assert P.rootnode.leaf.value == "while 1:\n    # Comment\n    a = b + c\n"

    try:
        grammar.tokens(P.addtoken, "- 1")
    except ParseError:
        pass
    else:
        assert 0, "Should have raised an exception"


# Generated at 2022-06-11 19:53:30.309602
# Unit test for method classify of class Parser
def test_Parser_classify():
    from .. import driver

    gr = driver.load_grammar("Grammar/Grammar")
    gr.add_keywords("print", "x")
    pars = Parser(gr)
    pars.setup()
    # Check that print is recognized as a NAME and x as a keyword
    pars.addtoken(token.NAME, "print", None)
    pars.addtoken(token.NAME, "x", None)
    # print should be added to used_names
    assert pars.used_names == set(["print"])

# Generated at 2022-06-11 19:53:41.099392
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import driver
    import sys

    p2grammar = grammar.grammar
    p2driver = driver.Driver(p2grammar, convert=None, logger=None)
    p2_parser = p2driver.parser

    t = token.NT_OFFSET + 1
    v = None

    from . import parsetok
    from . import token

    new_tok = token.TokenInfo(t,v,t)
    context = parsetok.TokenContext(1,1,1,1)
    new_enc = parsetok.encode_utf8(context)
    ilabel = new_tok.type + new_enc[-1]

    newnode = (t,v,context,[])

    state = 0
    newstate = 0

    # dfa, state, node

# Generated at 2022-06-11 19:53:54.169419
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2 import tokenize

    p: Parser
    g: Grammar
    g = Grammar()
    p = Parser(g)
    ilabel: int
    i: int
    i = 256
    for t in token.tok_name:
        if not t:
            continue
        g.add_token(i, t)
        i += 1
    ilabel = p.classify(token.NAME, "True", None)
    assert g.labels[ilabel] == (g.keywords["True"], None), (
        "Unexpected label after adding True to keywords: %s" % g.labels[ilabel],
    )
    ilabel = p.classify(token.NAME, "False", None)

# Generated at 2022-06-11 19:54:02.938372
# Unit test for method shift of class Parser
def test_Parser_shift():
    a = Parser(Grammar())
    a.push(3, (3, [1, (0, 3), (1, 7)], 6), 3, Context(0, 0))
    a.shift(6, "x", 7, Context(0, 0))
    assert a.stack == [(3, [1, (0, 3), (1, 7)], 6), (0, 7, (3, None, None, [Leaf(type=6, value='x', context=Context(0, 0))]))]

# Generated at 2022-06-11 19:54:07.185597
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar(grammar.grammar)
    g.parse_grammar(grammar.grammar)
    p = Parser(g)
    p.setup()
    p.push(g.symbol2number['file_input'], g.dfas[g.symbol2number['file_input']], 0, None)

# Generated at 2022-06-11 19:54:54.102484
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver

    g = driver.load_grammar("Grammar.txt")
    p = Parser(g)
    # Dummy context - unused here
    c = (0, 0)

    # Simple tokens
    assert p.classify(token.NAME, None, c) == 256
    assert p.classify(token.COMMENT, "hi", c) == 59
    assert p.classify(token.STRING, "hi", c) == 39

    # Keywords
    assert p.classify(token.NAME, "and", c) == 257
    assert p.classify(token.NAME, "assert", c) == 258
    assert p.classify(token.NAME, "exec", c) == 259

    # Error cases
    # Invalid token

# Generated at 2022-06-11 19:55:06.455215
# Unit test for method push of class Parser
def test_Parser_push():
    g = Grammar()
    ilabel_1_1 = g.addtoken()
    g.dfas[ilabel_1_1] = [[(0,1)]], {0: 0, 1: 1}
    ilabel_1_2 = g.addtoken()
    g.dfas[ilabel_1_2] = [[(0,1)]], {0: 0, 1: 1}
    ilabel_3_3 = 3
    g.dfas[ilabel_3_3] = [[(0,1)]], {0: 0, 1: 1}
    g.symbol_name[ilabel_1_1] = 'token_1_1'
    g.symbol_name[ilabel_1_2] = 'token_1_2'

# Generated at 2022-06-11 19:55:18.592853
# Unit test for method push of class Parser
def test_Parser_push():
    class TestClass(Parser):
        def __init__(self, grammar, convert=None):
            super().__init__(grammar, convert)

        def push(self, type, newdfa, newstate, context):
            self.newdfa = newdfa
            self.newstate = newstate
            self.context = context
            super().push(type, newdfa, newstate, context)

    # test type
    grammar = Grammar(__file__)
    p = TestClass(grammar)
    p.stack = [(0, 1, 2)]
    p.push(3, 4, 5, 6)

    # test newdfa
    assert p.newdfa == 4

    # test newstate
    assert p.newstate == 5

    # test context
    assert p.context == 6

    # test

# Generated at 2022-06-11 19:55:24.711969
# Unit test for method classify of class Parser
def test_Parser_classify():
    p = Parser(Grammar(token.__dict__, {}))
    p.setup()
    assert p.classify(token.NAME, "class", Context(0, 0)) == 1
    assert p.classify(token.NAME, "__name__", Context(0, 0)) == 3
    assert p.classify(token.NUMBER, "0", Context(0, 0)) == 2

# Generated at 2022-06-11 19:55:32.044749
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar
    from . import token

    # Generate a parser for the Python grammar
    parser = Parser(grammar.grammar)
    # Start parsing at the start symbol for stmt, which is simple_stmt
    parser.setup(grammar.sym.file_input)

    # Set up for simple_stmt parsing
    parser.addtoken(token.BEGIN, None, None)

    # Build a simple_stmt symbol
    parser.addtoken(token.NAME, "a", None)
    parser.addtoken(token.NEWLINE, None, None)

    # End of simple_stmt
    parser.addtoken(token.ENDMARKER, None, None)

    assert parser.rootnode[0].value == "a"

# Generated at 2022-06-11 19:55:38.874132
# Unit test for method pop of class Parser

# Generated at 2022-06-11 19:55:51.485591
# Unit test for method shift of class Parser
def test_Parser_shift():
    def p_a(p): return p

    def p_b(p): return p

    PT = Node("PT", [Leaf(1, "lf")], prefix="")
    r = Parser(Grammar(
        {
            "a": [([("a", 1), ("NAME", None), ("b", 2)], p_a)],
            "b": [([("b", 1), ("NUMBER", None), ("EQUAL", "=")], p_b)],
        }
    ))
    r.setup()
    r.addtoken(1, "lf", "ty")
    r.addtoken(2, "nr", "ty")
    r.addtoken(3, "=", "ty")
    assert r.rootnode == PT
