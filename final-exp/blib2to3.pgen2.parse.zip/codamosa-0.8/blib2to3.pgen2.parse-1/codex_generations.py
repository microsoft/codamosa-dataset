

# Generated at 2022-06-11 19:45:56.430448
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver
    from . import token

    import sys
    from blib2to3.pygram import python_symbols as syms
    from blib2to3.pgen2.tokenize import generate_tokens, untokenize

    class MockFile:
        def __init__(self, s: Text) -> None:
            self.readline = s.splitlines().__getitem__

    def tokgen(s: Text, *, encoding: Text = "iso-8859-1") -> Any:
        return generate_tokens(MockFile(s).readline)

    def _test(input: Text, *, encoding: Text = "iso-8859-1") -> Any:
        # Create a Parser instance
        p = Parser(driver.grammar, driver.convert)
        #

# Generated at 2022-06-11 19:46:06.982725
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    from .tokenize import generate_tokens
    from .grammar import Grammar, DEFAULT_DEBUG as DFA_DEBUG

    grammar = Grammar(driver.pgen_grammar_file(), DFA_DEBUG)
    parser = Parser(grammar)
    parser.setup()
    data = open('../Lib/sre_compile.py').read()
    tokens = generate_tokens(data)
    for token in tokens:
        print(token)
        if parser.addtoken(token.type, token.string, token.start):
            assert parser.rootnode
            tree = parser.rootnode
            parser.setup(driver.start_symbols["file_input"])
            print(tree.pretty())



# Generated at 2022-06-11 19:46:16.448375
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    from .grammar import Grammar
    from . import parse

    grammar = Grammar()
    driver.load_grammar(grammar)

    parser = Parser(grammar)
    parser.setup()
    assert parser.used_names == set()
    assert parser.rootnode is None
    assert len(parser.stack) == 1
    assert len(parser.stack[0]) == 3
    assert isinstance(parser.stack[0][0], tuple)
    assert len(parser.stack[0][0]) == 2
    assert isinstance(parser.stack[0][0][0], list)
    assert parser.stack[0][0][1] == {}
    assert isinstance(parser.stack[0][0][0][0], list)

# Generated at 2022-06-11 19:46:27.678235
# Unit test for method addtoken of class Parser

# Generated at 2022-06-11 19:46:37.115507
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar, token

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    p.addtoken(token.IF, 'if', None)
    p.addtoken(token.NAME, 'x', None)
    p.addtoken(token.COLON, ':', None)
    p.addtoken(token.NEWLINE, '\n', None)
    p.addtoken(token.INDENT, '\n', None)
    p.addtoken(token.NAME, 'y', None)
    p.addtoken(token.NEWLINE, '\n', None)
    p.addtoken(token.DEDENT, '\n', None)
    p.addtoken(token.ELSE, 'else', None)

# Generated at 2022-06-11 19:46:40.871130
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar(grammar, symbols, start))
    assert p.stack == []
    assert p.rootnode is None
    p.setup()
    assert isinstance(p.stack[0], tuple)
    assert len(p.stack) == 1
    assert p.rootnode is None


# Generated at 2022-06-11 19:46:53.482581
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Using the example grammar from the pgen docs.
    from .grammar import Grammar
    from . import driver

    # The "E -> E '+' E" rule's DFA

# Generated at 2022-06-11 19:47:02.120093
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar, tokenize

    g = grammar.Grammar(tokenize.grammar)
    p = Parser(g)
    p.push(grammar.NT_expression, g.dfas[grammar.NT_expression], 0, None)
    assert p.stack[0][0] == g.dfas[grammar.NT_expression]
    p.push(grammar.NT_atom, g.dfas[grammar.NT_atom], 0, None)
    assert p.stack[1][0] == g.dfas[grammar.NT_atom]
    assert p.stack[0][0] == g.dfas[grammar.NT_expression]
    assert p.stack[0][1] == 0


# Generated at 2022-06-11 19:47:10.468180
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest
    import sys
    import types

    from . import pgen

    test_prefix = b"_test_"

    if sys.version_info[0] >= 3:

        def test_prefix_func(token):
            return token.startswith(test_prefix)

    else:

        def test_prefix_func(token):
            return token[: len(test_prefix)] == test_prefix

    class TestParser(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            unittest.TestCase.__init__(self, *args, **kwargs)
            self.tokenized = None
            self.module = None
            self.grammar = None
            self.tokens = None
            self.parser = None
            self.keywords = None

# Generated at 2022-06-11 19:47:20.895838
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Unit test for method pop of class Parser"""
    from pgen2.grammar import tokenize_grammar
    from pgen2.pgen import generate_grammar
    from pgen2.parse import ParseError
    from pgen2.token import Token
    from pgen2.driver import Driver
    from ..pgen2 import test_pgen

    # Test the parser
    # Read the grammar
    with open(test_pgen.get_grammar_file(), "rb") as grammar_file:
        grammar_str = grammar_file.read().decode("utf-8")
    tokenize_grammar(grammar_str)
    # This will run pgen and read the generated Python code into
    # module grammar.  It also fixes the alphabet for Python 3 and
    # records the mapping from token numbers to names in the Type

# Generated at 2022-06-11 19:47:34.743032
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import pgen
    from .token import token
    from .symbol import sym


# Generated at 2022-06-11 19:47:40.455182
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from blib2to3.pgen2.driver import Driver

    src = "hello(1, world(*args, **kwargs))"
    d = Driver()
    g = d.grammar
    p = Parser(g)
    p.setup()
    for t in d.tokenize(src):
        p.addtoken(t.type, t.string, t.context)
    # XXX more tests

# Generated at 2022-06-11 19:47:52.545159
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import sample_grammar

    def classify(token: Tuple[int, Any, Context]) -> int:
        type, value, context = token
        return type

    sample = sample_grammar.grammar

    p = Parser(sample)
    p.setup()
    p.addtoken(token.NUMBER, "5", Context(line=1, column=0))
    p.addtoken(token.STAR, "*", Context(line=1, column=2))
    p.addtoken(token.NUMBER, "3", Context(line=1, column=3))

# Generated at 2022-06-11 19:48:01.989870
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .pgen2 import driver
    from . import token

    def tokens():
        yield token.STRING, '"hello"'
        for i in range(10):
            yield token.NEWLINE, '\n'
        yield token.INDENT, ' ' * 4
        yield token.NAME, 'def'
        yield token.NAME, 'f'
        yield token.OP, '('
        yield token.OP, ')'
        yield token.OP, ':'
        yield token.NEWLINE, '\n'
        yield token.INDENT, ' ' * 4
        yield token.NAME, 'pass'
        yield token.NEWLINE, '\n'
        yield token.DEDENT, ''
        yield token.NEWLINE, '\n'

    p = driver.Parser(driver.Grammar())
    p.setup()

# Generated at 2022-06-11 19:48:09.743573
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    grammar = driver.load_grammar("Grammar.txt")
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NAME, "foo", None)
    parser.addtoken(token.EQUAL, "foo", None)
    parser.addtoken(token.NAME, "foo", None)
    assert parser.addtoken(token.ENDMARKER, "foo", None)

if __name__ == "__main__":
    test_Parser_addtoken()

# Generated at 2022-06-11 19:48:20.832853
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar, tokenize
    from .pgen2 import driver
    from .pygram import python_symbols as syms
    from .pgen2.parse import ParseError

    # XXX this test breaks if the pgen grammar is changed;
    # XXX it assumes the following tokens are keywords:

# Generated at 2022-06-11 19:48:29.587283
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    gr = grammar.Grammar()
    gr.parse(['root_rule: a_rule'])
    pr = Parser(gr)
    pr.setup()
    assert pr.addtoken(0, 'a_rule', None)
    assert pr.rootnode is not None
    assert pr.addtoken(0, 'a_rule', None)


# Generated at 2022-06-11 19:48:38.520168
# Unit test for method pop of class Parser
def test_Parser_pop():

    # Test that pop correctly handles the no-parent case
    p = Parser(Grammar())
    p.setup()
    p.pop()
    assert p.rootnode is None

    # Test that pop correctly handles the null parent case
    p = Parser(Grammar())
    p.setup()
    newnode = Node(type=1, children=[Leaf(type=1, value="me")])
    p.addtoken(token.ENDMARKER, None, None)
    p.pop()
    assert p.rootnode.children == newnode.children

# Generated at 2022-06-11 19:48:47.273147
# Unit test for method pop of class Parser
def test_Parser_pop():
    from contextlib import contextmanager
    from blib2to3.pgen2.parse import parse_grammar

    p = parse_grammar(
        """
    expr:
        | expr '+' term
        | term
    term:
        | term '*' factor
        | factor

    factor:
        | '(' expr ')'
        | NAME
    """.strip()
    )
    result = p.parse()
    assert result is not None
    parser = Parser(result)
    parser.setup()
    with Parser_pop_tokenizer(parser):
        parser.addtoken(token.NAME, "x", None)
        parser.addtoken(token.PLUS, "+", None)
        parser.addtoken(token.NAME, "y", None)

# Generated at 2022-06-11 19:48:57.225740
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.grammar import Grammar

    class TestParser(Parser):
        def shift(self, type, value, newstate, context):
            assert type == 1
            assert value == 'value'
            assert newstate == 1
            assert context == 'context'
            assert self.grammar == grammar

    grammar = Grammar()
    grammar._add_token(token.NAME.string, 'name')
    grammar.dfas = {
        1: [[(1, 1)], [(1, 1), (0, 1)]]
    }
    grammar.labels = [(1, token.NAME)]
    parser = TestParser(grammar)
    parser.setup()

    parser.addtoken(token.NAME, 'value', 'context')

# Generated at 2022-06-11 19:49:18.798667
# Unit test for method push of class Parser
def test_Parser_push():
    class TestParser(Parser):
        """Derived class ofParser to test method push"""
        def __init__(self, grammar, convert = None):
            super(TestParser, self).__init__(grammar, convert)
            self.stack: List[Tuple[DFAS, int, RawNode]] = []
            self.rootnode: Optional[NL] = None

        def push(self, type, newdfa, newstate, context):
            """call method push of Parser"""
            super(TestParser, self).push(type, newdfa, newstate, context)

    grammar = Grammar({}, set(), {}, {}, {}, {}, {}, {}, {}, {}, {}, {})
    testParser = TestParser(grammar, None)

# Generated at 2022-06-11 19:49:29.559761
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar, token

    # Unit test for method setup of class Parser

    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NAME, "def", (1, 0))
    p.addtoken(token.NAME, "f", (1, 2))
    p.addtoken(token.OP, "(", (1, 3))
    p.addtoken(token.OP, ")", (1, 4))
    p.addtoken(token.OP, ":", (1, 5))
    p.addtoken(token.NEWLINE, "", (1, 6))
    p.addtoken(token.INDENT, "", (2, 0))



# Generated at 2022-06-11 19:49:42.057781
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import os.path
    import inspect
    import unittest
    import blib2to3.pgen2.parse

    # Find the location of the blib2to3.pgen2 module
    blib2to3_py = sys.modules["blib2to3.pgen2"].__file__
    blib2to3_dir = os.path.dirname(blib2to3_py)

    # Load the sample grammar
    mod = "blib2to3.pgen2.sample_grammar"
    sample_dir = os.path.join(blib2to3_dir, "sample_grammar")
    sys.path.append(sample_dir)
    exec("import %s" % mod)
    sys.path.remove(sample_dir)
    g = sys.modules

# Generated at 2022-06-11 19:49:54.769485
# Unit test for method addtoken of class Parser

# Generated at 2022-06-11 19:50:07.466310
# Unit test for method setup of class Parser
def test_Parser_setup():
    # Create sample Grammar
    term = Grammar()
    term.dfas = {'VALUE': ([[(1, 1), (0, 0)], [(0, 0)]], {'VALUE': 0}),
                 'TERM': ([[(1, 1), (0, 0)], [(0, 0)]], {'TERM': 0}),
                 }
    term.labels = [(x, 1) for x in ('VALUE', 'TERM')]
    term.keywords = {}
    term.start = 'TERM'
    # Create Parser object using start symbol TERM
    parser = Parser(term)
    parser.setup()
    assert parser.stack == [(term.dfas['TERM'], 0, ('TERM', None, None, []))]
    assert parser.rootnode is None
    # Create Parser

# Generated at 2022-06-11 19:50:17.468133
# Unit test for method push of class Parser

# Generated at 2022-06-11 19:50:26.351285
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar(r"""
    a: 'a' | 'aa';
    """)
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NAME, "a", Context)
    assert None is parser.rootnode
    parser.addtoken(token.NAME, "a", Context)
    assert 2 == len(parser.rootnode.children)
    parser.addtoken(token.NAME, "a", Context)
    assert "a" == parser.rootnode.children[0].value
    assert 2 == len(parser.rootnode.children)


# Generated at 2022-06-11 19:50:33.664121
# Unit test for method push of class Parser
def test_Parser_push():
    import sys
    import os.path
    dirname = os.path.dirname(__file__) or os.curdir
    dirname = os.path.join(dirname, os.pardir, os.pardir, os.pardir)
    dirname = os.path.abspath(dirname)
    dirname = os.path.join(dirname, "Lib", "test")
    sys.path.insert(0, dirname)
    from test_grammar import get_sample_grammar, get_sample_grammar_no_print_statement
    from test_grammar import get_sample_grammar_2  # noqa: F401

    def tokenize(text):
        from blib2to3.pgen2.tokenize import generate_tokens


# Generated at 2022-06-11 19:50:37.699333
# Unit test for method classify of class Parser
def test_Parser_classify():
    import _testcapi
    # test _PyPegen_Parser_addtoken_token_NAME
    _testcapi.test_Parser_classify_token_NAME()


# Generated at 2022-06-11 19:50:47.357717
# Unit test for method push of class Parser
def test_Parser_push():
    gram = Grammar('g')
    dfas = {0: ([[(-2, 0), (-1, 0)]], {-1: 0, -2: 0})}
    gram.dfas = dfas
    pp = Parser(gram)
    pp.setup()
    pp.push(256, ([[(0, 0)], [(-1, 0)]], {-1: 0}), 0, {'lineno': 0, 'column': 0})
    assert pp.stack == [(dfas[0], 0, (0, None, {'lineno': 0, 'column': 0}, [])),
                        ([[(0, 0)], [(-1, 0)]], {-1: 0}, 0, {'lineno': 0, 'column': 0})]


# Generated at 2022-06-11 19:51:19.675226
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver, tokenize

    def runtest(code, sym, result):
        p = Parser(driver.grammar)
        p.setup(sym)
        for t in tokenize.generate_tokens(StringIO(code).readline):
            if p.addtoken(t.type, t.string, (0, 0)):
                break
        assert p.rootnode.children == [result]

    # Test tokenizing
    runtest("x = 1\n", "file_input", Leaf(type=token.NAME, value="x", context=None))
    runtest("1\n", "testlist", Leaf(type=token.NUMBER, value="1", context=None))

# Generated at 2022-06-11 19:51:29.682392
# Unit test for method shift of class Parser
def test_Parser_shift():
    print("test_Parser_shift()")
    cls = Parser
    p = cls(None)
    p.stack = [(([([(1, 0), (2, 1)]), [(2, 2)]], {1: 0}), 0, (0, "parent", None, []))]
    p.shift(1, "child", 1, None)
    assert p.stack[0][2] == (0, "parent", None, [(1, "child", None, None)])
    print("ok")



# Generated at 2022-06-11 19:51:37.193609
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Below, we have three different types of tokens.
    # The first type is the ones we care about.
    # The second type is identifiers.
    # The third are tokens that don't appear in the grammar.

    # First we construct a set containing all of the tokens we care about to
    # use in our tests.
    grammar = Grammar()
    tokens = grammar.tokens.keys()
    token_list = []
    for token in tokens:
        token_list.append(token)
    token_set = set(token_list)

    # We then construct a set containing all of the identifiers we care about
    # to use in our tests.
    keywords = grammar.keywords
    keyword_list = []
    for keyword in keywords:
        keyword_list.append(keyword)

# Generated at 2022-06-11 19:51:48.744047
# Unit test for method pop of class Parser
def test_Parser_pop():
    class TestClass:

        grammar: Grammar
        p: Parser

        def __init__(self):
            self.grammar = Grammar()
            self.p = Parser(self.grammar)

        def test_Parser_pop(self):
            self.p.setup()

# Generated at 2022-06-11 19:51:59.303167
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver
    from . import tokenizer
    from . import grammar
    import sys
    import os

    def convert(g: grammar.Grammar, n: RawNode) -> NL:
        assert n[3] is not None
        return Node(type=n[0], children=n[3], context=n[2])

    # Read in the grammar specification
    fp = open(os.path.join(driver.GRAMMAR_DIR, driver.GRAMMAR_FILE))
    g = grammar.Grammar(fp, driver.CONVERSION)
    fp.close()
    g.add_keywords()
    # Construct a parser
    p = Parser(g, convert)
    # Parser is not yet ready to parse
    assert p.stack is None
    assert p.rootnode is None
    # Prepare

# Generated at 2022-06-11 19:52:07.353547
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # A parser for the meta-grammar is hardcoded here
    from . import metaparser

    # The following is a bit of a hack...
    metaparser.Parser.addtoken = addtoken

    # Create a parser instance which parses the meta-grammar
    p = metaparser.Parser(metaparser.Grammar())

    # Prepare for parsing; note that the start symbol is given explicitly
    p.setup(start="start")

    # Parse a single token: 'start'
    p.addtoken(token.NAME, "start", (0, "unknown"))

    # Done, get the syntax tree
    print(p.rootnode)



# Generated at 2022-06-11 19:52:16.913922
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    # The grammar for test_Parser_classify.
    gr = grammar.Grammar()
    gr.start = 256
    gr.dfas[256] = gr.dfas[257] = gr.dfas[258] = gr.dfas[259] = ([[(0, 1)]], [])
    gr.dfas[259] = ([[(0, 1)], [(0, 2)]], [])
    gr.labels = (
        (257, None),
        (258, None),
        (259, None),
        (260, "a"),
        (261, "b"),
        (262, None),
    )
    gr.keywords = {"a": 260, "b": 261}
    gr.tokens = {257: 259, 258: 260}
    # Test items

# Generated at 2022-06-11 19:52:28.877661
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.token as token

    class Context(object):
        def __init__(self, n, o):
            self.n = n
            self.o = o

    g = grammar.Grammar(grammar.gram)
    p = Parser(g)
    p.setup()
    for t, v in [(token.NAME, "a"), (token.NAME, "="), (token.NAME, "b"),
                 (token.NEWLINE, "\n")]:
        p.addtoken(t, v, Context(1, 1))
    assert p.rootnode.children[0].children[0].value == "a"

if __name__ == "__main__":
    test_Parser_addtoken()

# Generated at 2022-06-11 19:52:38.588696
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import io
    import blib2to3.pgen2.driver
    driver = blib2to3.pgen2.driver
    p = driver.Driver("python")
    parser = p.parser
    f = io.StringIO("[a]")
    t = driver.tokenize_str(f)
    while 1:
        tok = next(t)
        if parser.addtoken(tok.type, tok.string, tok.context):
            break

# Generated at 2022-06-11 19:52:46.951335
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest

    from . import grammar

    class ClassifyTestCase(unittest.TestCase):
        def test_classify(self):
            from . import token

            gram = grammar.Grammar(grammar.parse1)
            p = Parser(gram)
            p.setup()
            # Keywords
            self.assertEqual(p.classify(token.NAME, "if", None), gram.keywords["if"])
            self.assertEqual(
                p.classify(token.NAME, "while", None), gram.keywords["while"]
            )
            self.assertEqual(
                p.classify(token.NAME, "elif", None), gram.labels[gram.keywords["elif"]]
            )
            # Tokens

# Generated at 2022-06-11 19:54:07.186901
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import io
    import pypy.interpreter.pyparser.pgen
    import pypy.interpreter.pyparser.pythonparser

    def t(f, s):
        g = pypy.interpreter.pyparser.pgen.ParserGenerator("Python", "3.6")
        g.parse_grammar(pypy.interpreter.pyparser.pythonparser, "Grammar.txt")
        g.create_tables(outputdir=None, optimize=0, write_tables=False)
        p = Parser(
            pypy.interpreter.pyparser.pgen.Grammar(g.symbol2number, g.number2symbol, g.dfa, g.start)
        )
        p.setup()


# Generated at 2022-06-11 19:54:19.307983
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from io import StringIO
    import tokenize
    from blib2to3.pgen2.token import generate_tokens
    from . import driver

    # Sample use of Parser
    def print_ast(node):
        print(node)
        if node.type in ("file_input", "eval_input"):
            for pos, child in node.children():
                print_ast(child)
    text = "1 + 2"
    grammar = driver.load_grammar("Grammar.txt")
    parser = Parser(grammar)
    parser.setup()
    stream = StringIO(text)

# Generated at 2022-06-11 19:54:31.539178
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import tokenize
    from .driver import parse_string
    from .grammar import Grammar
    import typing as T
    import sys

    print("Test parsing a string...")

    # Use the driver to generate some trees for us
    test_program1 = "a=1"
    test_program2 = "a=2\nprint('Hello World!')"

    # Come up with a grammar, any grammar
    pgen_input = "a: 'a'\nprint: 'print'"
    grammar = Grammar.from_string(pgen_input)

    # Load the tables from the grammar
    with open("Parser/Grammar.pickle") as f:
        grammar = Grammar.load(f)

# Generated at 2022-06-11 19:54:39.986198
# Unit test for method shift of class Parser
def test_Parser_shift():
    def dfa(labels: Sequence[Union[int, Text]]) -> DFAS:
        """A simple DFA generator.  (Internal)"""
        size = len(labels)
        states = []  # type: List[List[Tuple[int, int]]]
        for i in range(size):
            arc = []
            for j, label in enumerate(labels[i]):
                label = str(label)
                if label == "0":
                    # Accept state
                    arc.append((0, j))
                elif label is not "-":
                    arc.append((j, j))
            states.append(arc)
        return states, dict.fromkeys(range(size), 0)

    p = Parser(Grammar(dfa(["abc", "d", "e"])), lam_sub)
   

# Generated at 2022-06-11 19:54:48.689406
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Test method shift of class Parser"""
    import blib2to3.pygram as gram

    # Setup
    par = Parser(gram.python_grammar)
    token.tok_name[token.NAME] = "NAME"
    ilabel = par.classify(token.NAME, "print", (1, 54))

    # Test
    stackentry = (gram.python_grammar.dfas[1], 1, [])
    par.stack.append(stackentry)
    par.shift(token.NAME, "print", ilabel, (1, 54))
    assert par.stack[0] == (gram.python_grammar.dfas[1], 2, [])
    assert par.stack[0][2] == [["print", None, (1, 54), None]]

# Generated at 2022-06-11 19:54:55.226002
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.tokenize import generate_tokens
    from blib2to3.pygram.python_grammar import python_grammar as grammar
    my_C = grammar.symbol2number["C"]
    my_D = grammar.symbol2number["D"]

    def toks(s):
        return generate_tokens(iter([s]).next)

    # Reference data
    my_D_dfa = grammar.dfas[my_D]
    my_D_labels = grammar.labels
    my_D_keywords = grammar.keywords
    my_D_tokens = grammar.tokens
    my_C_dfa = grammar.dfas[my_C]

    parser

# Generated at 2022-06-11 19:55:06.777731
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    g = grammar.grammar
    p = Parser(g)
    type_map = tokenize.tok_name
    #  Input:  if 1:
    #  Output: <if_stmt>
    p.setup()
    p.addtoken(type_map['NAME'], 'if', (1, 0))
    p.addtoken(type_map['NUMBER'], '1', (1, 3))
    p.addtoken(type_map[':'], ':', (1, 4))
    assert p.stack == [
        ([([(0, 0), (1, 1), (2, 1)], {0: 0, 1: 1, 2: 1})], 0, (257, None, None, []))
    ]
    assert p.rootnode[0]

# Generated at 2022-06-11 19:55:15.419046
# Unit test for method pop of class Parser
def test_Parser_pop():
    class DummyGrammar:
        keys = {}
        tokens = {}
        dfas = {0: [[(0, 0)]]}
        labels = [(-1, "undefined")]
        start = 0

    dg = DummyGrammar()
    dp = Parser(dg)
    dp.setup()
    dp.push(0, dg.dfas[0], 0, None)
    dp.pop()
    assert dp.stack == []
    assert dp.rootnode is not None


# Generated at 2022-06-11 19:55:24.460517
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.tokenize
    from . import driver

    src = """\
a = 1
"""
    tokens = blib2to3.pgen2.tokenize.generate_tokens(src)
    p = driver.Driver(blib2to3.pgen2.grammar, "../../Grammar/Grammar", convert=lam_sub)
    p.setup()
    while True:
        try:
            if p.addtoken(next(tokens)):
                break
        except blib2to3.pgen2.tokenize.TokenError as e:
            print(e)
            continue
    assert str(p.rootnode) == "file_input: [[]]"

    tokens = blib2to3.pgen2.tokenize.generate_t

# Generated at 2022-06-11 19:55:26.013728
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar('''
    start: 'a'
    '''))
    p.setup()