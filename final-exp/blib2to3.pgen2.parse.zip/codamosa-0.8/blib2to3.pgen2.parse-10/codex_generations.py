

# Generated at 2022-06-11 19:46:00.201819
# Unit test for method classify of class Parser
def test_Parser_classify():
    import _testcapi
    parser = _testcapi.parser_new()
    classify = parser.classify
    assert classify(0, "") == 0
    assert classify(0, "and") == 1
    assert classify(0, "def") == 2
    assert classify(0, "return") == 3
    assert classify(2, None) == 4
    assert classify(3, None) == 5
    assert classify(4, None) == 6
    assert classify(5, None) == 7
    assert classify(6, None) == 8
    assert classify(7, None) == 9
    assert classify(8, None) == 10
    assert classify(9, None) == 11
    assert classify(10, None) == 12
    assert classify(11, None) == 13
    assert classify(12, None) == 14
    assert classify

# Generated at 2022-06-11 19:46:02.086686
# Unit test for method setup of class Parser
def test_Parser_setup():
    g = Grammar()
    p = Parser(g)
    p.setup()


# Generated at 2022-06-11 19:46:10.305101
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    parser = Parser(Grammar())
    parser.setup()
    parser.stack = [
        (
            ([[(0, 0)]], {}),
            0,
            (2, None, None, [[Leaf(type=57, value="x", context=None)]]),
        )
    ]
    node = Node(type=2, children=[Leaf(type=57, value="x", context=None)])
    parser.pop()
    assert parser.rootnode is node

# Generated at 2022-06-11 19:46:17.919327
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, driver

    # Create parser
    with open("Python.grammar", "rb") as f:
        g = grammar.Grammar(f.read())
    p = Parser(g)
    # Prepare for parsing
    p.setup()
    # Get tokens; we just end after the first non-comment token
    t = driver.Driver(p.grammar, optimize=1)
    t.set_input("from _ast import * # Doesn't matter")
    while True:
        tok = t.token()
        if tok is None:
            # EOF
            break
        if tok.type != tokenize.COMMENT:
            p.addtoken(tok.type, tok.string, (tok.start, tok.end, tok.line))
            # We're done, after

# Generated at 2022-06-11 19:46:29.193070
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver
    from . import token

    def convert(grammar, node):
        type = node[0]
        if type == grammar.symbol2number["expr_stmt"]:
            return node[3]

    grammar = driver.load_grammar("Grammar/Grammar")

    parser = Parser(grammar, convert)
    parser.setup()

    parser.addtoken(token.NUMBER, "1", context="(1,0)")
    parser.addtoken(token.NEWLINE, None, context="(1,3)")

    parser.addtoken(token.NAME, "print", context="(2,0)")
    parser.addtoken(token.LPAR, None, context="(2,5)")

# Generated at 2022-06-11 19:46:37.919103
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Create a mock Grammar
    mock_labels = {0: (256, "NT0"), 1: (257, "NT1")}
    mock_dfas = {
        256: ([[(0, 0), (1, 1)]], {0: {1}, 1: {0}}),
        257: ([[(0, 0)]], {0: {0}}),
    }
    mock_start = 256
    mock_tokens = {257: 1}
    mock_keywords = {"x": 1}
    mock_grammar = Grammar(
        labels=mock_labels,
        dfas=mock_dfas,
        start=mock_start,
        tokens=mock_tokens,
        keywords=mock_keywords,
    )
    # Create a Parser instance
   

# Generated at 2022-06-11 19:46:50.253834
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import dfa
    from . import driver

    # Parser.classify() uses the grammar.keywords dictionary to
    # map token.NAME tokens to other token values when appropriate
    # (for example, the token.NAME 'None' is mapped to token.NONE).
    # Here's the pygram.pygram object, which contains the
    # dictionary.  We'll create a grammar object and then we'll
    # make a Parser object use it.
    g = Grammar(driver.pygram)
    p = Parser(g)
    p.setup()

    # Add a token.NAME token, pass it to the classify method, and see
    # what we get.
    p.addtoken(token.NAME, "None", (1, 0))

# Generated at 2022-06-11 19:46:58.902026
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import parse
    from . import pygram
    from . import pytree
    from . import token

    g = pygram.python_grammar_no_print_statement
    p = parse.Parser(g)

    p.setup()
    p.addtoken(token.LPAR, '(', (1, 0))
    p.addtoken(token.NAME, 'x', (1, 1))
    p.addtoken(token.RPAR, ')', (1, 2))

    assert isinstance(p.rootnode, pytree.Node)
    assert p.rootnode.type == grammar.syms.file_input
    assert isinstance(p.rootnode[0], pytree.Leaf)
    assert p.rootnode[0].value == 'x'

    p.setup()
    p

# Generated at 2022-06-11 19:47:00.143593
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar())
    p.setup()



# Generated at 2022-06-11 19:47:09.861543
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    g = grammar.NontermGrammar()
    p = Parser(g)
    p.setup()
    # Shift a NAME token
    p.stack = [(g.dfas[grammar.NONTERM], 0, (grammar.NONTERM, None, None, []))]
    p.shift(token.NAME, "foo", 1, (1, 2))
    assert p.stack == [(g.dfas[grammar.NONTERM], 1,
                        (grammar.NONTERM, None, None, [Leaf(token.NAME, "foo",
                                                           (1, 2))]))]
    p.stack = [(g.dfas[grammar.NONTERM], 0, (grammar.NONTERM, None, None, []))]
   

# Generated at 2022-06-11 19:47:17.200493
# Unit test for method setup of class Parser
def test_Parser_setup():
    from .pgen import Driver

    grammar = Driver().parse_grammar("Grammar/Grammar")
    parser = Parser(grammar)
    parser.setup()

# Generated at 2022-06-11 19:47:30.354875
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pickle
    from . import pgen2

    g = pgen2.load_grammar("Parser/Python.grammar")
    s = "def f(): x(1, 2)"

    p = Parser(g)
    p.setup()
    for t in pgen2.tokenize(s):
        p.addtoken(t.type, t.string, t.context)
    p.addtoken(token.ENDMARKER, "", t.context)

    assert p.stack == []
    assert p.rootnode.type == SYMBOL.file_input
    assert p.rootnode.value is None
    assert p.rootnode.children
    assert p.rootnode.children[0].type == SYMBOL.stmt
    assert p.rootnode.children[0].value is None

# Generated at 2022-06-11 19:47:39.991034
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import pgen2

    g = grammar.Grammar()
    pgen = pgen2.pgen(g, token.tok_name, token.EXACT_TOKEN_TYPES)
    p = Parser(g,convert=None)
    p.setup(start=1)
    # pop non-empty tree
    p.stack.append(([([(0,0),(0,0)],[1,2,3])], 0, (1, None, None, [(2, 'bob', None, None), (3, 'dave', None, None)])))
    p.pop()

# Generated at 2022-06-11 19:47:49.610932
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Check that addtoken() doesn't mutate the passed-in context object
    import copy
    import blib2to3.pgen2.token

    ctx = blib2to3.pytree.Context(1, 2)
    ctx_copy = copy.deepcopy(ctx)
    assert ctx_copy == ctx
    p = Parser(blib2to3.pgen2.grammar.Grammar(blib2to3.pgen2.grammar.graminit.grammars))
    p.setup()
    p.addtoken(blib2to3.pgen2.token.NAME, "foo", ctx)
    assert ctx_copy == ctx

# Generated at 2022-06-11 19:48:00.645568
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    if sys.version_info[0] >= 3:
        from pgen import driver
        return

    from test.test_support import run_unittest
    from test.test_support import nested_scopes

    from . import driver
    from . import token
    from . import grammar
    try:
        from . import pgen

        have_pgen = True
    except ImportError:
        have_pgen = False

    class TestParserAddToken(unittest.TestCase):
        def test_shift(self):
            p = Parser(grammar, lam_sub)
            p.setup()
            self.assertTrue(p.addtoken(token.NUMBER, "42", (1, 0)))
            root = p.rootnode
            self.assertEqual(root.type, grammar.start)


# Generated at 2022-06-11 19:48:06.881436
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import driver

    # The following test string is taken from test_grammar.
    # See test_driver.test_tokenize for how such a string is tokenized.
    test_string = "def f(x):\n    return 2 * x\n"
    # Find the grammar file, which is in the same directory as this file.
    import os, sys
    grammar_file = os.path.join(
        os.path.dirname(os.path.abspath(sys.modules[__name__].__file__)),
        "Grammar.txt",
    )
    # Load the grammar file and construct a parser instance.
    g = driver.load_grammar(grammar_file)
    p = Parser(g)
    p.setup()
    # Test the method setup.
    # The use of None

# Generated at 2022-06-11 19:48:17.964616
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import parse, python_grammar_no_print_statement
    from .tokenize import generate_tokens
    import sys
    from blib2to3.pgen2.parse import ParseError

    p = parse.Parser(python_grammar_no_print_statement, parse.convert_node_to_ast)
    p.setup()

    tokenizer = generate_tokens(sys.stdin.readline)
    try:
        while True:
            #tokenizer = generate_tokens(next(input_gen))
            tok = next(tokenizer)
            if p.addtoken(tok.type, tok.string, tok.start):
                break
    except ParseError as e:
        print(e)

# Generated at 2022-06-11 19:48:24.334060
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import unittest
    import blib2to3.pgen2.grammar as grammar
    import blib2to3.pgen2.driver as driver
    import blib2to3.pgen2.tokenize as tokenize

    class ParserTestCase(unittest.TestCase):

        def parse(self, file, start=None):
            p = driver.load_grammar(file)
            p.parse_tokens(tokenize.generate_tokens(open(file).readline))

    unittest.main()

if __name__ == "__main__":
    test_Parser_addtoken()

# Generated at 2022-06-11 19:48:33.963308
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import makegrammar
    import sys
    import tempfile
    sys.path.insert(0, "/home/csagan/py3k/3.3/lib/python3.3")
    sys.path.insert(0, "/home/csagan/py3k/3.3")
    import blib2to3.pgen2.parse as parse
    file = tempfile.NamedTemporaryFile(mode="w")
    file.write('import abc\na = "abc"\n')
    file.flush()
    grammar = parse.make_grammar(parse.parse_grammar(file.name), parse.parse_generation(file.name))
    parser = parse.Parser(grammar)
    parser.setup()

# Generated at 2022-06-11 19:48:45.577327
# Unit test for method pop of class Parser
def test_Parser_pop():
    from typing import cast
    from blib2to3.pgen2.grammar import Symbol

    class MockDFA(tuple):
        def __init__(self) -> None:
            super().__init__()
        def __str__(self) -> Text:
            return '<MockDFA>'

    start = Symbol(name='START')

    dfa = MockDFA()
    type = token.NAME
    value = '3'
    context = Context()
    state = 0

    p = Parser(cast(Grammar, None))
    p.push(start, dfa, state, context)
    p.shift(type, value, state, context)
    p.push(start, dfa, state, context)
    p.shift(type, value, state, context)
    p.pop()

# Generated at 2022-06-11 19:48:58.248703
# Unit test for method shift of class Parser
def test_Parser_shift():
    def check_shift(grammar, tokens, convert=None):
        def check_shift_helper():
            p = Parser(grammar, convert)
            p.setup()
            for t in tokens:
                p.addtoken(*t)
            if p.rootnode is None:  # pragma: no cover
                raise AssertionError("p.addtoken() did not return True")
            return p.rootnode
        return check_shift_helper()

    def check_shift_raises(grammar, tokens, expected_exc, convert=None):
        def check_shift_raises_helper():
            p = Parser(grammar, convert)
            p.setup()
            for t in tokens:
                p.addtoken(*t)

# Generated at 2022-06-11 19:49:03.297887
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Unit test for method addtoken of class Parser."""
    grammar = Grammar()
    p = Parser(grammar)
    p.setup()
    tokentype = grammar.tokens['NUMBER']
    assert p.addtoken(tokentype, "3", None)

# Generated at 2022-06-11 19:49:14.026698
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2 import driver

    test_string = "this is a test"
    fp = driver.string_to_file(test_string)
    tokens = tokenize.generate_tokens(fp.readline)
    g = driver.load_grammar("Grammar/Grammar")
    p = Parser(g)
    p.setup()

    for token in tokens:
        p.addtoken(token[0], token[1], token[2])


# Generated at 2022-06-11 19:49:23.171659
# Unit test for method pop of class Parser
def test_Parser_pop():
    class TestParser(Parser):
        def pop(self):
            Parser.pop(self)

    grammar = Grammar()
    grammar.symbols = ['symbol']
    grammar.dfas = {
        'symbol': (
            [
                [
                    (0, 0),  # (label, state)
                    (0, 1),
                    (0, 2),
                    (0, 3),
                ]
            ],  # states
            {
                0: 0,  # (label, position)
            },
        )
    }
    parser = TestParser(grammar)
    parser.rootnode = None

# Generated at 2022-06-11 19:49:27.398206
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .driver import Driver
    from . import token
    from . import pgen
    from . import parse
    import sys

    driver = Driver(parse.convert35, pgen.driver_grammar_pickle, convert=parse.convert)
    driver.setup()
    driver.addtoken(1, "class", token.NAME)
    driver.addtoken(1, "A", token.NAME)
    driver.addtoken(14, ":", token.COLON)
    driver.addtoken(0, "", token.ENDMARKER)
    driver.addtoken(0, "", token.ENDMARKER)
    assert driver.rootnode.type == 1
    assert driver.rootnode.children[1] == "A"

# Generated at 2022-06-11 19:49:38.684805
# Unit test for method pop of class Parser
def test_Parser_pop():
    import sys
    import blib2to3.pgen2.tokenize
    from blib2to3.pgen2.parse import Parser

    def _preparse(input: Sequence[Text], *args, **kwargs) -> NL:
        p = Parser(None, *args, **kwargs)
        p.setup()
        for t in input:
            if not p.addtoken(t[0], t[1], t[2]):
                continue
            break
        return p.rootnode

    def test(
        input: Sequence[Text],
        expected: Sequence[Tuple[int, Any, Any, Any]],
        *args,
        **kwargs
    ) -> None:
        result = _preparse(input, *args, **kwargs)
        assert result.children == expected

    # Unit test

# Generated at 2022-06-11 19:49:49.421813
# Unit test for method addtoken of class Parser

# Generated at 2022-06-11 19:49:53.818128
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.Grammar()
    g.parse_grammar(SourceToken)

    p = Parser(g)
    p.setup()

    p.classify(token.NAME, 'abc', None)
    try:
        p.classify(token.NAME, 'def', None)
    except ParseError:
        print('ParseError')
    p.classify(token.NAME, 'None', None)
    p.addtoken(token.NAME, 'None', None)


# Generated at 2022-06-11 19:49:57.064362
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    assert p.stack == [(([[(0, 1)]], set()), 0, (1, None, None, []))]

# Generated at 2022-06-11 19:50:01.568267
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    g = grammar.Grammar(tokenize.tok_name, tokenize.tok_name.values())
    p = Parser(g)
    p.setup()
    assert p.stack[0] == (g.dfas[262], 0, (262, None, None, []))


# Generated at 2022-06-11 19:50:13.884291
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import pgen

    grammar = pgen.load_grammar()
    parser = Parser(grammar)
    parser.setup()
    assert parser.shift(token.PLUS, '+', 1, Context(None, 1)) is None
    assert parser.stack[-1] == (grammar.dfas[257], 1, (257, None, None, None))



# Generated at 2022-06-11 19:50:21.108078
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.g = Grammar("test", "test", None, None)
            self.p = Parser(self.g)

        def test_init_dfas(self):
            dfa = (
                # states
                (((1,0),),),
                # labels
                {0: (token.NUMBER, u"1")},
            )
            self.p.dfas = {u"test": dfa}
            self.p.stack = []
            self.p.rootnode = None
            self.p.used_names = set()

# Generated at 2022-06-11 19:50:24.931683
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2 import (
        token,
        grammar,
        driver,
        parse_grammar,
    )
    from blib2to3.pgen2.parse import ParseError

    with open("Python.asdl", "rb") as fp:
        python_asdl = fp.read()
    the_grammar = parse_grammar(python_asdl, "Python.asdl", "exec")
    p = Parser(the_grammar)
    p.setup()
    with open("python.py", "rb") as fp:
        p_python_py = fp.read()

    # This code would be better if it called driver.parse_file, but that
    # doesn't work until setup has finished, and the code below wants
    # to test the intermediate state.

# Generated at 2022-06-11 19:50:29.689813
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = Grammar()
    grammar.keywords["name"] = 1
    parser = Parser(grammar)
    parser.setup()
    assert parser.stack == [(([[(1, 0)]], set([1])), 0, (None, None, None, []))]
    parser.setup(start=2)
    assert parser.stack == [(([[(1, 0)]], set([1])), 0, (2, None, None, []))]

# Generated at 2022-06-11 19:50:42.473780
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import tokenize
    from .parse import Parser

    # Generate the grammar
    g = grammar.Grammar()
    g.start = "file_input"
    g.add_nonterminal("file_input", ["(", "newline", "|", "stmt", ")"])
    g.add_nonterminal("stmt", ["small_stmt", "|", "compound_stmt"])
    g.add_nonterminal("small_stmt", ["'pass'"])
    g.add_nonterminal("compound_stmt", ["if_stmt", "|", "while_stmt"])
    g.add_nonterminal("if_stmt", ["'if'", "test", "':'", "suite"])

# Generated at 2022-06-11 19:50:53.122701
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver

    class TestParser(Parser):
        def classify(self, type, value, context):
            return Parser.classify(self, type, value, context)

    P = TestParser(driver.grammar)
    P.setup()

    # Test 1: Check that all the tokens are present and appropriately
    # mapped in P.grammar.tokens and P.grammar.keywords

    for tokenattr in dir(token):
        if tokenattr.startswith('NT_OFFSET'):
            break
        elif tokenattr[:3] == 'tok' and tokenattr != 'tok_hack':
            tok_id = getattr(token, tokenattr)
            tok_str = tokenattr[3:]

# Generated at 2022-06-11 19:51:00.468328
# Unit test for method push of class Parser
def test_Parser_push():
    d = {"a": [[(1, 0), (2, 1)], {0: {0: 1, 1: 2}, 1: {0: 2, 1: 2}}]}
    g = Grammar(d, {}, {}, {}, {}, {})
    p = Parser(g)
    p.push(0, g.dfas[0], 0, None)
    p.push(0, g.dfas[0], 0, None)
    p.pop()
    p.push(1, g.dfas[1], 0, None)
    p.pop()
    p.pop()
    # This should not raise an AssertionError
    p.push(0, g.dfas[0], 0, None)
    p.push(0, g.dfas[0], 0, None)

# Generated at 2022-06-11 19:51:06.094595
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import driver
    from . import token
    from . import parsetok

    def convert(grammar, t):
        grammar, dfa, state, node = t
        return node[3]

    with open('data/new_grammar.txt') as f:
        text = f.read()
    s = '\n'.join(text.split('\n')[1:])
    g = driver.pgen(s)
    p = Parser(g, convert)
    p.setup()
    p.addtoken(token.NUMBER, '1', Context(2,3))
    assert p.rootnode == ['+', [1]]
    p.addtoken(token.PLUS, '+', Context(2,4))
    p.addtoken(token.NUMBER, '2', Context(2,6))

# Generated at 2022-06-11 19:51:12.152910
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar

    # Test arguments
    g = grammar.Grammar(start=0, symbols={}, defs={}, keywords={}, labels=[])
    # Run method
    p = Parser(g)
    p.setup()
    # Check
    assert p.grammar is g
    assert p.convert is lam_sub
    assert not p.stack
    assert p.rootnode is None



# Generated at 2022-06-11 19:51:20.170854
# Unit test for method classify of class Parser
def test_Parser_classify():
    import pgen2.parse
    import token
    import unittest

    class TokenizeTestCase(unittest.TestCase):
        def test_classify(self):
            # NAME tests
            p = pgen2.parse.Parser(pgen2.parse.Grammar(version='3.5'))
            self.assertEqual(
                p.classify(token.NAME, "if", None), pgen2.parse.IF
            )
            self.assertEqual(
                p.classify(token.NAME, "def", None), pgen2.parse.DEF
            )
            self.assertEqual(
                p.classify(token.NAME, "class", None), pgen2.parse.CLASS
            )

# Generated at 2022-06-11 19:51:34.578351
# Unit test for method setup of class Parser
def test_Parser_setup():
    pass



# Generated at 2022-06-11 19:51:46.818942
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import tokenize
    from . import symbols
    from .grammar import WhitespaceAwareGrammar

    gr = WhitespaceAwareGrammar()
    with open("blib2to3/pgen2/Grammar.txt") as f:
        gr.create_grammar(f)
    p = Parser(gr)
    p.setup(symbols.file_input)

    with open("blib2to3/__init__.py") as f:
        tokengen = tokenize.generate_tokens(f.readline)
        for tok in tokengen:
            p.addtoken(tok[0], tok[1], tok[2])
        root = p.rootnode

# Generated at 2022-06-11 19:51:57.800708
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3 import pygram

    class DummyGrammar(object):
        def __init__(self):
            self.labels = {1: (1, None)}
            self.dfas = {1: ([[(0, 1), (1, 2)], [(0, 1)]], {1: 2})}

    class DummyConverter(object):
        def __init__(self, grammar, node):
            pass

    dummygrammar = DummyGrammar()
    dummyconverter = DummyConverter
    parser = Parser(dummygrammar, convert=dummyconverter)
    parser.setup(start=1)
    assert parser.addtoken(token.NAME, "test", None)

# Generated at 2022-06-11 19:52:07.479198
# Unit test for method pop of class Parser
def test_Parser_pop():
    class DummyGrammar:
        def __init__(self):
            self.dfas = {
                "A": [
                    [
                        (
                            1,
                            0,
                        ),
                        (0, 0),
                    ],
                    [(2, 1), (0, 1)],
                    [(1, 2)],
                ],
                "B": [
                    [
                        (
                            1,
                            0,
                        ),
                        (0, 0),
                    ],
                    [(2, 1), (0, 1)],
                    [(1, 2)],
                ],
            }
            self.labels = {
                1: (
                    1,
                    None,
                ),
                2: (
                    2,
                    None,
                ),
            }

# Generated at 2022-06-11 19:52:16.970459
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .tokenize import tokenize

    def _maketokens(readline):
        for (type, value, (srow, scol), (erow, ecol), line) in tokenize(readline):
            yield type, value, Context(srow, scol, erow, ecol, line)

    from . import python_grammar

    from . import pgen2

    pg = pgen2.driver.load_grammar("Grammar.txt", python_grammar)
    p = pgen2.parser.Parser(pg)

    def _display_tree(tree: NL) -> None:
        print("%s" % pgen2.parser.node2tuple(tree, pg.symbol2label))

    import StringIO

    input = StringIO.StringIO("x")
    p.setup()



# Generated at 2022-06-11 19:52:28.957074
# Unit test for method push of class Parser
def test_Parser_push():
    # The following input is used for the test.
    # The output is the visual representation of the stack with 2 nodes.
    # The stack = [(dfa, state, [type, value, context, [nodes]])]
    # The context = None because it is not used in this test
    thrift = Grammar(open("test/thrift.tok", "rb"))
    thrift_parser = Parser(thrift)

    # type and value of the tokens
    idt = token.NAME
    ident = "test"
    le = token.OP
    less = "<"
    be = token.OP
    bigger = ">"
    me = token.OP
    minus = "-"
    pe = token.OP
    plus = "+"
    se = token.OP
    semicolon = ";"

    # given
    thrift

# Generated at 2022-06-11 19:52:36.637390
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar(raw_grammar)
    p = Parser(grammar, convert)
    p.setup()

    dfa, state, node = p.stack.pop()
    newnode = p.convert(p.grammar, node)
    p.stack[-1] = (dfa, state, newnode)

# Generated at 2022-06-11 19:52:46.014085
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Test that transformation is performed on the newly created node"""
    from .tokenize import generate_tokens
    from .grammar import Grammar
    import io

    source = io.StringIO("1+2")
    tokens = generate_tokens(source.readline)
    p = Parser(Grammar())
    p.setup()

    for t in tokens:
        if p.addtoken(*t):
            break

    # Look at the transformed structure of the root node
    children = p.rootnode.children
    assert len(children) == 3
    assert children[0].type == "NUMBER"
    assert children[0].children == ["1"]
    assert children[1].type == "PLUS"
    assert children[1].children == ["+"]
    assert children[2].type == "NUMBER"
   

# Generated at 2022-06-11 19:52:54.484448
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.driver import load_grammar
    from blib2to3.pgen2.parse import ParseError
    from blib2to3.pytree import Leaf
    import sys
    import unittest

    if sys.version_info[0] == 3:
        class TestParserShift(unittest.TestCase):

            def test_shift(self):
                # Setup
                p = Parser(load_grammar("Grammar.txt"))
                p.setup()
                type, value, context = (0, "", None)
                newstate = 0
                # Test
                p.shift(type, value, newstate, context)
                # Verify
                self.assertEqual(Leaf(0, "", None), p.rootnode)

# Generated at 2022-06-11 19:53:02.675405
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Test method classify of class Parser"""
    g = Grammar(r"""
        grammar_foo:
          bar*
          (bar+ baz)+
        bar: 'bar'
        baz: 'baz'
        """)

# Generated at 2022-06-11 19:53:39.243014
# Unit test for method shift of class Parser
def test_Parser_shift():
    assert Parser.shift(token, 'a', 1, 1) == ((token, 'a', 1), (1, 1))

# Generated at 2022-06-11 19:53:41.231034
# Unit test for method shift of class Parser
def test_Parser_shift():
    p = Parser(Grammar())
    p.shift(1, "word", 0, (0, 0))



# Generated at 2022-06-11 19:53:47.944048
# Unit test for method setup of class Parser
def test_Parser_setup():
    import builtins
    from . import pytree
    builtins.__dict__["grammar"] = pytree.PythonGrammar()
    builtins.__dict__["p"] = Parser(grammar.Grammar())
    builtins.__dict__["p"].setup()
    p = Parser(grammar.Grammar())
    p.setup()
    p.setup(1)

# Generated at 2022-06-11 19:53:57.648281
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar

    def convert(grammar, node):
        # type: (Grammar, RawNode) -> NL
        """Convert concrete to abstract syntax tree.

        This is a docstring.
        """
        pass

    grammar_ = grammar.Grammar(grammar.DEFAULT_GRAMMAR)
    parser_ = Parser(grammar_, convert)

    assert parser_.stack == []

    parser_.stack = [(1, 2, "node"), (3, 4, "node2")]
    parser_.pop()
    assert parser_.stack == [(1, 2, "node")]

    parser_.stack = [(5, 6, "node3")]
    parser_.pop()
    assert parser_.stack == []
    assert parser_.rootnode == None



# Generated at 2022-06-11 19:54:07.831332
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import pytree
    from .tokenize import generate_tokens

    # A very simple class to return a token
    class TokenList:
        def __init__(self, tklist: Sequence[Tuple[int, Text, Any, Any, Any]]) -> None:
            self.tklist = tklist

        def __call__(self) -> Tuple[int, int, Optional[Text], Any, Any]:
            if self.tklist:
                return self.tklist.pop(0)
            else:
                raise StopIteration()

    # A very simple class to test the tree returned by the parser
    # This class is a simple tree walker
    class TestParser:
        def __init__(self, tree: pytree.Leaf) -> None:
            self.tree = tree

# Generated at 2022-06-11 19:54:13.406422
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Unit test for method shift of class Parser."""
    p = Parser(Grammar())
    p.setup()
    p.shift(1, 'a', 0, (1,0))
    assert p.stack[-1] == (([],{}), 0, (1, 'a', (1,0), None))



# Generated at 2022-06-11 19:54:20.751570
# Unit test for method pop of class Parser
def test_Parser_pop():

    # create an empty node 
    a_node = (0, None, None, [])
    # create a non-empty node
    b_node = (1, None, None, [a_node])
    # create a parser
    gram = _setup_parser()
    p = Parser(gram)
    # create a stack
    p.stack = [((gram.dfas[0]), 1, b_node)]
    # pop both nodes of the stack
    p.pop()
    p.pop()
    # check that the stack is empty
    assert not p.stack



# Generated at 2022-06-11 19:54:30.238160
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import token
    from . import driver
    from . import parse
    from . import pickle
    from . import type_conv
    token_map, symbols, dfas = pickle.load(open('Grammar.dump', 'rb'))
    g = grammar.Grammar(token_map, symbols, dfas)
    p = Parser(g)
    p.setup()
    p.classify(token.NAME, 'test', None)
    assert p.used_names == {'test'}

# Generated at 2022-06-11 19:54:38.715969
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pytest
    from . import grammar as Grammar
    from . import token as Token
    test_grammar = Grammar.Grammar()

# Generated at 2022-06-11 19:54:48.971883
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Test that shift works"""
    p = Parser(grammar.Grammar(), lam_sub)
    p.setup()
    p.addtoken(token.NAME, 'f', '(3, 0)')
    p.addtoken(token.OP, '=', '(3, 2)')
    p.addtoken(token.NAME, 'g', '(4, 0)')
    p.addtoken(token.NEWLINE, '\n', '(4, 2)')
    p.addtoken(token.NAME, 'h', '(5, 0)')
    assert p.rootnode is not None
    assert p.rootnode[2] == '(3, 0)'
    assert p.rootnode[3][1] == '(3, 2)'
    assert p.rootnode[3][3][0] == '(4, 0)'

