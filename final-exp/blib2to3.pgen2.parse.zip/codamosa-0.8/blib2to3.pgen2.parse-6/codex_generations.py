

# Generated at 2022-06-11 19:46:14.231540
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Grammar.txt")
    p = Parser(grammar)
    p.setup("file_input")

    def addtok(t):
        # type: (int) -> None
        p.addtoken(t, "", (1, 0))

    # First, a test sequence that fails:
    addtok(token.NEWLINE)
    addtok(token.DEDENT)
    try:
        addtok(token.NEWLINE)
    except ParseError:
        pass
    else:
        assert 0, "expected ParseError"

    # And now a test sequence that succeeds:
    p.setup("file_input")
    addtok(token.NEWLINE)

# Generated at 2022-06-11 19:46:25.479925
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import tokenize

    class TestConverter(object):

        def __init__(self, testcase) -> None:
            self.testcase = testcase

        def convert(self, grammar, node) -> NL:
            self.testcase.assertEqual((1, None, None, [None]), node)
            return None

    import unittest

    class TestParser(unittest.TestCase):
        def test_Parser_pop(self):
            g = Grammar(tokenize.grammar)
            p = Parser(g, TestConverter(self))
            p.setup()
            p.addtoken(tokenize.NAME, "test", (1, 0))
            p.pop()

# Generated at 2022-06-11 19:46:35.376244
# Unit test for method pop of class Parser
def test_Parser_pop():
    yacc = Grammar("test_Parser_pop", [], [], [], [], [], {})
    parser = Parser(yacc, None)
    parser.stack = [None]

    def pop():
        parser.pop()

    def check_popnode(popnode):
        assert popnode == (1, None, None, ["a"]), popnode
        assert parser.stack == [None], parser.stack

    # No rootnode, no conversion, no children
    parser.stack.append((None, 1, (1, None, None, None)))
    check_popnode(parser.stack[-1])
    pop()

    # No rootnode, no conversion, has children
    parser.stack.append((None, 1, (1, None, None, [])))
    check_popnode(parser.stack[-1])


# Generated at 2022-06-11 19:46:43.707355
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Unit test for method addtoken of class Parser"""
    from . import grammar, tokenize, token
    g = grammar.Grammar()
    g.start = "s"
    g.add_nonterminal("s", [])
    g.add_nonterminal("s", ["s", "s"])
    g.add_rule("s", [["NUMBER"]])
    g.add_rule("s", [["NAME"]])
    g.add_token("NUMBER", r"\d+")
    g.add_token("NAME", r"[A-Za-z]+")
    p = Parser(g)
    p.setup()
    t = tokenize.Tokenizer(g.symbol2label)
    # No tokens

# Generated at 2022-06-11 19:46:55.232762
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .grammar import Grammar
    from .dfa import DFA

    class MockDFA(DFA):
        def __init__(self) -> None:
            self.state = 0
            self.states = [{(0, 1): (1, 2)}, {(0, 0): (2, 3)}, {(1, 4): (3, 5)}]
            self.labels = {0: (token.NUMBER, "1"), 1: (token.NAME, "a"),
                           2: (token.NAME, "b"), 3: (token.NAME, "c"),
                           4: (token.NAME, "d")}

# Generated at 2022-06-11 19:47:06.849998
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pytree, pickle, sys
    from blib2to3.pgen2 import pgen, driver, tokenize

    # Pickle a Parser, pop a node, and verify that popping works.
    # XXX This test should probably be moved to a test file.

    f = open('/home/naji/lib2to3/blib2to3/pgen2/Python.tbl', 'rb')
    tbl = f.read()
    f.close()

    with open(sys.executable, 'rb') as f:
        encoding, lines = tokenize.detect_encoding(f.readline)
        f.seek(0)

    dfa, labels = pgen.generate_grammar(tbl)
    pickle.dumps(dfa)  # This should not raise an exception

# Generated at 2022-06-11 19:47:09.689114
# Unit test for method pop of class Parser
def test_Parser_pop():
    assert Parser(Grammar()).pop.__doc__

parse = Parser(Grammar()).parse

# Generated at 2022-06-11 19:47:20.500593
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.pgen

# Generated at 2022-06-11 19:47:24.966205
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2 import parsetok
    from blib2to3.pgen2 import driver

    # Create the parser
    parser = cpython_parser()
    # Parse the code
    r: Results
    r = parse_file(parser, 'test/test2to3.py')
    parser.setup()
    r = parse_file(parser, 'test/testall.py')

#--------------------------------------------------------

# Generated at 2022-06-11 19:47:26.267581
# Unit test for method shift of class Parser
def test_Parser_shift():
    pass


# Generated at 2022-06-11 19:47:43.918254
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import driver
    from typing import List

    class MyNode(Node):
        pass

    class MyLeaf(Leaf):
        pass

    def build_tree(type: int, children: Optional[List[RawNode]], context: Context):
        if type == token.NAME:
            return MyLeaf(value, context, children)
        else:
            return MyNode(type, children, context)

    def to_tree(grammar: Grammar, node: RawNode):
        return build_tree(node[0], node[-1], node[2])

    g = driver.load_grammar("Grammar.txt")
    p = Parser(g, to_tree)
    p.setup()

# Generated at 2022-06-11 19:47:49.498317
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .grammar65 import Grammar

    g = Grammar(grammar65)
    p = Parser(g)
    p.setup()
    for type, value in tokens:
        assert not p.addtoken(type, value, (0, 0))
    assert p.rootnode is not None


# Generated at 2022-06-11 19:48:00.482188
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .token import token as token_module
    from .pgen2 import driver
    import os
    import sys

    grammar = driver.load_grammar(os.path.join(sys.prefix, "Grammar/Grammar"))

    class Foo:
        def __init__(self, type: int, value: Optional[Text], context: Context) -> None:
            self.type = type
            self.value = value
            self.context = context

        def get_token(self) -> Foo:
            return self

        def __repr__(self) -> Text:
            if self.value is None:
                return token_module.tok_name[self.type]
            return "'%s'" % self.value

    def make_token(tok: Foo) -> Foo:
        print(tok)
        return

# Generated at 2022-06-11 19:48:11.731368
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    # A simple test
    g = driver.load_grammar("Grammar/Grammar")
    p = Parser(g)
    p.setup()
    p.addtoken(token.STRING, "abc", (1, 0))
    p.addtoken(token.STRING, "def", (1, 4))
    p.addtoken(token.NEWLINE, "\n", (1, 8))
    p.addtoken(token.ENDMARKER, "", (2, 0))
    assert p.rootnode.type == symbol.file_input
    assert p.rootnode[0].type == token.STRING
    assert p.rootnode[0].value == "abc"
    assert p.rootnode[1].type == token.STRING
    assert p.rootnode[1].value

# Generated at 2022-06-11 19:48:22.173401
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest

    class TestParser(unittest.TestCase):
        def test_basic(self):
            grammar = Grammar()
            grammar.parse(
                """
            start: "a" | start "b"
            """
            )

            parser = Parser(grammar)

            parser.setup()
            parser.addtoken(token.NAME, "a", (1, 0))
            parser.addtoken(token.NAME, "a", (1, 0))
            parser.addtoken(token.NAME, "b", (1, 0))
            parser.addtoken(token.NAME, "b", (1, 0))
            parser.addtoken(token.NAME, "b", (1, 0))


# Generated at 2022-06-11 19:48:33.494631
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    p = Parser(grammar)
    p.setup()
    assert p.stack == [(p.grammar.dfas[256], 0, (256, None, None, []))]
    p.shift(3, "a", 1, Context(1, 0))
    assert p.stack == [(p.grammar.dfas[256], 1, (256, None, None, [Leaf(3, "a", Context(1, 0))]))]
    p.shift(4, "b", 1, Context(1, 1))
    assert p.stack == [(p.grammar.dfas[256], 1, (256, None, None, [Leaf(3, "a", Context(1, 0)), Leaf(4, "b", Context(1, 1))]))]

# Generated at 2022-06-11 19:48:45.543239
# Unit test for method pop of class Parser

# Generated at 2022-06-11 19:48:56.352498
# Unit test for method push of class Parser
def test_Parser_push():
    import os
    import sys
    from . import driver, token, symbol

    from . import _testcapi
    from . import grammar
    from . import pygram

    for mod in 'test', 'test_pep263', 'test_grammar':
        p = driver.ParserDriver(mod)
        p.parse_tokens([(token.ENDMARKER, "")])
        assert p.p.rootnode

    p = driver.ParserDriver("test", convert_unicode_literals=False)
    p.parse_tokens([(token.ENDMARKER, "")])
    assert p.p.rootnode

    def test_unicode(filename):
        p = driver.ParserDriver(filename, convert_unicode_literals=False)

# Generated at 2022-06-11 19:49:05.866521
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # class blib2to3.pgen2.driver.Driver.VerboseFileParser
    parser = None # type: Any
    # Function blib2to3.pgen2.driver.Driver.VerboseFileParser.parse_file
    def parse_file(self, filename):
        while True:
            token = self.tokengen.get_token()
            if self.addtoken(token): break
    # Function blib2to3.pgen2.driver.Driver.VerboseFileParser.addtoken
    def addtoken(self, token):
        type, value, context = token
        return self.parser.addtoken(type, value, context)

# Generated at 2022-06-11 19:49:13.038336
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar
    from blib2to3.fixes.fix_paren import Parens

    g = grammar.Grammar(Parens().diff_grammar)
    p = Parser(g)

    p.setup()
    p.shift(token.INDENT, "    ", 0, Context(1, 1))
    p.shift(token.INDENT, "    ", 0, Context(2, 1))
    p.shift(token.DEDENT, "", 0, Context(2, 5))
    p.shift(token.DEDENT, "", 0, Context(2, 5))

    p.stack[0][-1][3]

# Generated at 2022-06-11 19:49:34.705488
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.driver import Driver
    from blib2to3.pgen2.parse import ParseError
    # These tests rely on some of the properties of the Python grammar

# Generated at 2022-06-11 19:49:45.702989
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    # simple test for a grammar without reserved words
    g = grammar.grammar
    p = Parser(g)
    assert p.classify(token.NAME, "foo", (1, 2)) == 1  # token.NAME
    assert p.classify(token.NUMBER, None, None) == 3  # token.NUMBER
    assert p.classify(token.OP, "+", None) == 4  # token.PLUS

    # load the real Python grammar
    g2 = grammar.Grammar(grammar.pgen_grammar)
    p2 = Parser(g2)
    assert p2.classify(token.NAME, "None", (1, 2)) == 2  # NAME
    assert p2.classify(token.NAME, "none", (1, 2)) == 4  #

# Generated at 2022-06-11 19:49:56.683577
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Test the classify() method of class Parser"""
    from . import grammar, tokenize
    import pprint
    # Load the grammar
    p = Parser(grammar, None)
    # Run the parser

# Generated at 2022-06-11 19:50:02.048645
# Unit test for method push of class Parser
def test_Parser_push():
    token_type = 0
    newdfa: DFAS = ([[(0, 1), (2, 3)]], {})
    newstate = 0
    context = Context(line=1, col=1)
    p = Parser(Grammar())
    p.push(token_type, newdfa, newstate, context)
    assert p.stack == [(newdfa, newstate, (token_type, None, context, []))]

# Generated at 2022-06-11 19:50:13.660056
# Unit test for method pop of class Parser
def test_Parser_pop():
    # From Parser/parser.py, test_Parser_pop()
    class FakeGrammar(object):
        start = 256
        dfas = {
            256: (
                [  # start
                    [(257, 1)],  # 0
                    [(258, 2), (0, 2)],  # 1
                ],
                {0: 1, 1: 1, 2: 0},
            ),
            257: ([[(0, 1)]], {1: 0}),
            258: ([[(0, 1)]], {1: 0}),
        }


    class DummyConverter(object):
        def __init__(self):
            self.stack = []

        def __call__(self, grammar: Grammar, node: RawNode) -> NL:
            assert node[3] is not None

# Generated at 2022-06-11 19:50:20.993187
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pgen2.parse

    st = pgen2.parse.parse_string("a\nqfdsqf\nb", start="var")
    assert st.type == "var"
    assert len(st.nodes) == 2
    assert st.nodes[0].type == "line"
    assert len(st.nodes[0].nodes) == 2
    assert st.nodes[0].nodes[0].type == "word"
    assert st.nodes[0].nodes[1].type == "word"
    assert st.nodes[1].type == "line"
    assert len(st.nodes[1].nodes) == 1
    assert st.nodes[1].nodes[0].type == "word"


# Generated at 2022-06-11 19:50:29.853454
# Unit test for method shift of class Parser
def test_Parser_shift():
    # testing shift of a new node
    p = Parser(Grammar, lam_sub)
    p.setup()
    node = p.addtoken(token.NAME, 'hello', Context(0, 0))
    assert node == False
    node = p.addtoken(token.NAME, 'world', Context(1, 0))
    assert node == True

    # testing shift of a new node with None value
    p = Parser(Grammar, lam_sub)
    p.setup()
    node = p.addtoken(token.COLON, None, Context(0, 0))
    assert node == False
    node = p.addtoken(token.NAME, 'world', Context(1, 0))
    assert node == True

    # testing shift of a new node raises error

# Generated at 2022-06-11 19:50:34.652222
# Unit test for method setup of class Parser
def test_Parser_setup():
    class DummyGrammar:
        dfas = {}

    p = Parser(DummyGrammar())
    p.setup()
    assert p.stack
    assert not p.rootnode


# Generated at 2022-06-11 19:50:45.250746
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    # The following test program is expected to parse successfully
    prog = "for i in range(10): print i"
    for tok in tokenize.generate_tokens(prog.__iter__().__next__):
        type, value, start, end, line = tok

        # Map from token to label
        ilabel = classify(type, value, Context(start[0], start[1], start[2]))

        # Loop until the token is shifted; may raise exceptions
        while True:
            dfa, state, node = stack[-1]
            states, first = dfa
            arcs = states[state]
            # Look for a state with this label
            for i, newstate in arcs:
                t, v = grammar.labels[i]

# Generated at 2022-06-11 19:50:55.866665
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import os
    import unittest
    from . import driver
    from . import token
    from ..pygram import python_grammar_no_print_statement

    with open(os.path.join(os.path.dirname(__file__), 'Parser_addtoken_program.txt')) as f:
        program = f.read()

    def readline(buf=''):
        for c in program:
            if c == '\n':
                break
            buf += c
        else:
            return '', False  # EOF
        return buf, True  # not EOF

    class MockTokenizer(object):
        source = ''
        filename = '<string>'
        encoding = 'utf-8'


# Generated at 2022-06-11 19:51:19.412129
# Unit test for method push of class Parser

# Generated at 2022-06-11 19:51:32.320541
# Unit test for method push of class Parser

# Generated at 2022-06-11 19:51:45.818578
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys, getopt
    try:
        opts, args = getopt.getopt(sys.argv[1:], "", ["debug"])
    except getopt.error:
        print("usage: %s [--debug] inputfile" % sys.argv[0])
        sys.exit(2)

    debug = 0
    for o, a in opts:
        if o == "--debug":
            debug = debug + 1

    if not args:
        print("usage: %s [--debug] inputfile" % sys.argv[0])
        sys.exit(2)

    from .pgen import driver
    from .pgen import tokenize as pgen_tokenize

    filename = args[0]
    f = open(filename)
    input = f.read()  # type: Any
    f

# Generated at 2022-06-11 19:51:54.478580
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Relies on test_token_classify()
    from .driver import pgen
    grammar = pgen.parse_grammar(open(pgen.grammar_filename, "rb"))
    parser = Parser(grammar)
    parser.setup()
    parser.classify(token.NAME, "if", (1, 0))
    parser.classify(token.OP, "<", (2, 1))
    parser.classify(token.STRING, "abc", (3, 2))
    parser.classify(token.OP, "+", (4, 3))


# Generated at 2022-06-11 19:51:57.660248
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2 import driver

    grammar = driver.load_grammar("Parser/Python.gram")
    p = Parser(grammar)
    p.setup()

# Generated at 2022-06-11 19:52:03.277378
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .pgen import driver
    g = driver.load_grammar("Grammar/Grammar")
    p = Parser(g)
    p.setup()
    p.addtoken(1, "a", (1, 0))
    assert p.stack[-1] == (g.dfas[1], 1, (1, "a", (1, 0), None))


# Generated at 2022-06-11 19:52:14.392771
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pprint
    p = Parser(Grammar('', {0:0, 1:1}, {}, {0: 0, 1:1}, {}))
    p.setup()
    p.pop()
    assert p.rootnode is None
    p.shift(0, '1', 0, None)
    p.pop()
    assert p.rootnode.value == '1'
    p.push(0, (0,1), 0, None)
    p.shift(0, '2', 0, None)
    p.pop()
    assert p.rootnode.value == '1'
    assert len(p.rootnode.children) == 1
    assert p.rootnode.children[0].value == '2'

# Generated at 2022-06-11 19:52:26.461588
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar(r"""
    start: e
    e: e "+" t | t
    t: t "*" f | f
    f: "(" e ")" | "0"
    """)
    parser = Parser(grammar, lam_sub)
    parser.setup()
    parser.addtoken(token.NUMBER, '0', Context(1, 2, ""))
    parser.addtoken(41, None, Context(1, 2, ""))
    parser.addtoken(42, None, Context(1, 3, ""))
    parser.addtoken(token.NUMBER, '1', Context(1, 3, ""))
    parser.addtoken(42, None, Context(1, 4, ""))
    parser.addtoken(token.NAME, 'b', Context(1, 4, ""))
    parser

# Generated at 2022-06-11 19:52:33.574622
# Unit test for method pop of class Parser
def test_Parser_pop():
    def test(s, expect):
        p = Parser(None)
        p.stack = s
        p.stack.append((None, None, (None, None, None, [])))
        try:
            result = p.pop()
        except:
            result = "Execption"
        assert result == expect, "expected %s, got %s" %(expect, result)

    test([], None)
    test([(None, None)], None)
    test([(None, None, [])], None)
    test([(None, None, [], 1)], None)
    test([(None, None, [1], 1)], None)

    def test_convert(grammar, node):
        return node[0]

    test([(None, None, (None, None, None, []))], None)

# Generated at 2022-06-11 19:52:44.923252
# Unit test for method push of class Parser
def test_Parser_push():
    global ParseError

    class Foo(Exception):
        pass

    class Parser:
        def __init__(self, grammar, convert=None):
            self.type = None
            self.value = None
            self.newdfa = None
            self.newstate = None
            self.context = None
            self.stack: List[Tuple[DFAS, int, RawNode]] = []

        def push(self, type, newdfa, newstate, context):
            self.type = type
            self.newdfa = newdfa
            self.newstate = newstate
            self.context = context
            raise Foo

    type = 0
    value = None
    newstate = 14
    context = None
    newdfa = ([], {})
    p = Parser(None)

# Generated at 2022-06-11 19:54:20.222385
# Unit test for method shift of class Parser
def test_Parser_shift():

    import unittest, copy
    class Test_Parser_shift(unittest.TestCase):

        def setUp(self):
            from blib2to3.pgen2.grammar import Grammar
            from blib2to3.pgen2 import token 
            self.Grammar = Grammar
            self.token = token

# Generated at 2022-06-11 19:54:32.644849
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, tokenize

    with open("Grammar.txt") as grammar_file:
        gram = grammar.Grammar(grammar_file.read())
    p = Parser(gram)
    p.setup()
    s = "if 1: pass"
    # Convert string to list of token tuples
    tokens = tokenize.generate_tokens(s.splitlines(True))
    # Add them to the parser all at once
    for type, value, context in tokens:
        if p.addtoken(type, value, context):
            break
    # Check that the parse tree is what we expect it to be
    print(p.rootnode)  # Should print "file_input([stmt(if, ...)])"
    # Build a new string from the token list, by simple string concatenation
    s

# Generated at 2022-06-11 19:54:38.939010
# Unit test for method push of class Parser
def test_Parser_push():
    # Test for a bug that occurred when pushing a token with value = "else"
    # onto the stack
    from .pgen2 import driver

    parser = driver.load_grammar("Grammar.txt", "Grammar", "Parser", "pgen")
    parser.setup()
    print(parser.addtoken(1, "else", (1, 1)))

# Generated at 2022-06-11 19:54:46.078067
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    def get_tokens(s: Sequence[Tuple[int, Any]]) -> Sequence[Tuple[int, Text]]:
        return [(t, v) for t, v in s]

    g = grammar.grammar
    p = Parser(g)
    p.setup()
    for t in get_tokens(g.token2number):
        p.addtoken(t[0], t[1], (1, 1))
    p.addtoken(token.NAME, "some", (1, 1))

# Generated at 2022-06-11 19:54:54.760355
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import token

    g = grammar.Grammar()
    g.add_nonterminal("foo", (10,))
    p = Parser(g, None)
    assert p.stack == []
    assert p.rootnode is None
    p.setup()
    assert p.stack == [(g.dfas[10], 0, ((10, None, None, []),))]
    state = p.grammar.dfas[10][0][0]
    assert p.stack == [(g.dfas[10], 0, ((10, None, None, []),))]
    type = token.PLUS
    value = "+"
    context = None
    ilabel = token.PLUS
    assert p.classify(type, value, context) == ilabel

# Generated at 2022-06-11 19:55:06.664913
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    from .pgen2 import driver

    from io import StringIO

    import os

    import sys

    import unittest

    testdir = os.path.dirname(__file__) or "."
    grammardir = os.path.join(testdir, "..", "Grammar")
    grammardir = os.path.normpath(grammardir)
    testgrammar = os.path.join(grammardir, "Grammar")
    testdriver = os.path.join(testdir, "driver.py")


# Generated at 2022-06-11 19:55:11.714051
# Unit test for method push of class Parser
def test_Parser_push():
    parser = Parser(Grammar())
    parser.setup()
    parser.push(10, ((), {}), 0, None)
    assert parser.stack[1] == ((((), {}), 0, (10, None, None, [])))

# Generated at 2022-06-11 19:55:21.237079
# Unit test for method push of class Parser
def test_Parser_push():
    # Should successfully return a new Parser instance
    assert isinstance(Parser(Grammar()), Parser)

    # Should successfully return a new Parser instance from int_grammar
    from . import int_grammar
    assert isinstance(Parser(int_grammar), Parser)

    p = Parser(int_grammar)
    p.setup()

    # '3' should successfully be pushed onto the stack
    p.push(int_grammar.symbol2number['child'],p.grammar.dfas[307],1, (0,0))

    assert p.stack[1][0] == p.grammar.dfas[307]
    assert p.stack[1][1] == 1
    assert p.stack[1][2][0] == int_grammar.symbol2number['child']
    assert p

# Generated at 2022-06-11 19:55:29.870930
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Test method addtoken of class Parser."""
    from .pgen2 import driver
    from ..pytree import Leaf

    # Mock the Parser class
    class ParserMock(Parser):

        def __init__(self, grammar, convert):
            super(ParserMock, self).__init__(grammar, convert)
            self.stack_verify = []
            self.stack_addtoken = []

        def shift(self, type, value, newstate, context):
            self.stack_addtoken.append((type, value, context))

        def push(self, type, newdfa, newstate, context):
            self.stack_addtoken.append((type, None, context))

        def pop(self):
            self.stack_addtoken.append(None)

        def setup(self, start):
            self

# Generated at 2022-06-11 19:55:37.433449
# Unit test for method pop of class Parser
def test_Parser_pop():

    from . import driver

    from blib2to3.pgen2 import grammar

    class MyParser(Parser):

        def __init__(self, grammar: grammar.Grammar) -> None:
            Parser.__init__(self, grammar, None)
            self.s = ''

        def convert(self, grammar: grammar.Grammar, node: RawNode) -> None:
            self.s += str(node[0])

    driver.main('blib2to3.pgen2.grammar', 'tokens', 'grammar', None)
    gr = grammar.Grammar('tokens', 'grammar')
    p = MyParser(gr)
    p.setup()