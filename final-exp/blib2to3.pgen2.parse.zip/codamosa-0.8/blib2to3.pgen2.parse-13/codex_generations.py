

# Generated at 2022-06-11 19:45:52.731589
# Unit test for method pop of class Parser
def test_Parser_pop():
    import re
    import io
    import sys
    import unittest
    import pgen2.parse
    import pgen2.driver
    import pgen2.grammar

    class ParseTest(unittest.TestCase):
        pgen2.parse.Parser = Parser

        def test_pop(self):
            sys.stdin = io.StringIO("""def f(x=1, *args):
    pass
""")
            gp = pgen2.driver.load_grammar("Grammar/Grammar", "Grammar/Tokens", debug=1)
            p = pgen2.driver.Driver(gp, convert=gp.convert)
            p.parse_tokens(sys.stdin.readline())
            p.parse_tokens(sys.stdin.readline())
           

# Generated at 2022-06-11 19:45:58.608820
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver

    grammar = driver.load_grammar()
    parser = Parser(grammar)
    parser.setup(1)
    for tok in token.tok_name:
        parser.grammar.keywords[tok] = tok
    for tok in token.tok_name:
        parser.grammar.tokens[tok] = tok

    for i in range(257):
        parser.addtoken(i, "", Context(0, 0))



# Generated at 2022-06-11 19:46:10.425843
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import parser
    from . import grammar, token

    # Run the method with all tokens, so that a coverage
    # tool can test all branches of the method.

    def method(grammar, token, value, context):
        P = parser.Parser(grammar)
        ilabel = P.classify(token, value, context)
        return ilabel

    # Prepare the parameters
    # Use a default grammar
    g = grammar.Grammar()
    # Use a dummy context
    context = "context"
    # Use a dummy value
    value = "value"

    # Run the method for all tokens.
    # When new tokens are added to the token module,
    # you need to add them here, or just comment out
    # the exception.

# Generated at 2022-06-11 19:46:17.973538
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Unit test for method addtoken of class Parser."""

    class ParserTC(Parser):
        def __init__(self, grammar):
            Parser.__init__(self, grammar)

        def shift(self, type, value, newstate, contex):
            print(f"shift({type}, {value}, {newstate}, {contex})")

        def pop(self):
            print(f"pop()")

        def push(self, type, dfa, newstate, contex):
            print(f"push({type}, {dfa}, {newstate}, {contex})")

    grammar = """
    S: B
    B: 'b' '+' B | 'b'
    """

    from . import pgen2

    p = pgen2.driver.load_grammar(grammar)

   

# Generated at 2022-06-11 19:46:23.971193
# Unit test for method pop of class Parser
def test_Parser_pop():
    a = Parser (Grammar(), None)
    a.setup ()
    state = 0
    popnode = (1,2,3,4)
    a.stack = [(5,6,7)]
    a.stack.append ((5, state, popnode))
    a.stack.append ((5, state, popnode))
    a.pop ()
    assert (a.stack.pop() == (5, state, popnode))

# Generated at 2022-06-11 19:46:31.548735
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import grammar
    from . import dfa
    from . import parse

    grammar = grammar.Grammar()
    dfa = dfa.DFA(grammar)
    parse = parse.Parser(grammar)
    parse.setup()
    assert type(parse) is parse.Parser
    assert parse.grammar is grammar
    assert parse.convert == parse.lam_sub
    assert parse.stack is not None
    assert parse.rootnode is None
    assert parse.used_names == set()

# Generated at 2022-06-11 19:46:37.292282
# Unit test for method push of class Parser
def test_Parser_push():
    import blib2to3.pytree
    from . import pygram, token

    pygram.init_grammar(blib2to3.pytree)
    p = Parser(pygram, lam_sub)
    p.setup(pygram.start)
    p.addtoken(token.NAME, "if", (1, 0))
    p.addtoken(token.NAME, "int", (1, 3))

# Generated at 2022-06-11 19:46:43.895195
# Unit test for method shift of class Parser
def test_Parser_shift():
    def convert(grammar, node):
        return node[1]

    grammar = Grammar()
    grammar.labels = {0: (1, None), 1: (2, None), 2: (3, None)}
    p = Parser(grammar, convert)
    p.setup()
    p.addtoken(1, None, None)
    p.addtoken(1, None, None)
    assert p.addtoken(1, None, None)
    assert p.rootnode == 3



# Generated at 2022-06-11 19:46:51.643601
# Unit test for method push of class Parser
def test_Parser_push():
    def test_method(type: int, newdfa: DFAS, newstate: int, context: Context) -> None:
        """Test a new Parser instance."""
        p = Parser(Grammar())
        p.setup()
        newnode = p.push(type, newdfa, newstate, context)
    test_method(type=int(), newdfa=DFAS(DFA(), {}), newstate=int(), context=Context())

# Generated at 2022-06-11 19:47:01.948204
# Unit test for method classify of class Parser
def test_Parser_classify():
    import unittest

    from . import grammar, tokenize
    from .tokenize import generate_tokens

    class T(unittest.TestCase):
        # pylint: disable=missing-docstring
        def test(self):
            g = grammar.Grammar()
            g.start = 256
            g.labels = g.symbol2label = {}  # type: ignore
            g.keywords = g.token2label = {token.NAME: 256}  # type: ignore
            s = "x = 3"
            p = Parser(g)
            tok = generate_tokens(iter([s]).__next__)
            t1 = tok.__next__()
            r = p.classify(t1.type, t1.string, t1.start)
            self.assertE

# Generated at 2022-06-11 19:47:19.740402
# Unit test for method pop of class Parser
def test_Parser_pop():
    class FakeGrammar(object):
        dfas = { 1: ([[(2, 3)]], {0, 1, 1}),
                 2: ([[(0, 0)]], {0, 1, 1})
               }
        labels = [ ('a', 'b'), ('a', None) ]
        tokens = { 'a': 0, 'b': 1, 'c': 2 }
        keywords = { 'a': 0, 'b': 1, 'c': 2 }
        start = 1

    grammar = FakeGrammar()
    parser = Parser(grammar)

    def foo_sub(grammar, node):
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])

    parser.setup()

# Generated at 2022-06-11 19:47:31.516263
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Test Parser.addtoken() by parsing a simple arithmetic expression."""
    import pprint
    from pprint import pformat
    from . import driver, grammar, token

    # Here's our grammar, in a readable format
    start = "expr"
    grammar = """
        expr: term ('+' term)*
        term: factor ('*' factor)*
        factor: ('+'|'-')? atom
        atom: '(' expr ')' | NUMBER
        """

    # We need a function to convert token names to labels
    tok_name = driver.Driver(grammar, convert=None).tok_name

    # Now we build a parser using our grammar
    p = Parser(grammar.Grammar(grammar), convert=None)

    # It is not ready yet!

# Generated at 2022-06-11 19:47:40.734725
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver as D

    D.setup_driver()
    g: Grammar = D.driver.grammar
    p = Parser(g)
    p.setup()

    type = token.NAME
    value = "foo"
    context = Context(1, 0)  # lineno and offset
    newstate = 1

    p.shift(type, value, newstate, context)

    assert len(p.stack) == 1
    assert (g.dfas[g.start], 0) == p.stack[0][:2]
    node = p.stack[0][2]
    assert g.start == node[0]
    assert None == node[1]
    assert context == node[2]
    assert len(node) == 4
    assert node[3] == []
    assert p.rootnode is None



# Generated at 2022-06-11 19:47:41.966311
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # FIXME:  Write this test.
    pass


# Generated at 2022-06-11 19:47:54.501056
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Create dummy grammar and a parser
    class TestGrammar(Grammar):
        def __init__(self):
            self.dfas = dict(a=[[[(1, 1), (1, 2)], [(1, 3), (1, 4)]],
                                [[], [(1, 4)]], [[(1, 4)], []], [], []])
            self.labels = [(1, None), (1, None), (1, None), (2, None)]
            self.start = 'a'
    class TestConverter:
        def __init__(self):
            self.converted = Leaf(5, '', None)
        def __call__(self, grammar, node):
            return self.converted
    dummygrammar = TestGrammar()
    converter = TestConverter()
   

# Generated at 2022-06-11 19:48:04.329799
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    gram = Grammar(textwrap.dedent("""
        atoms: NAME NUMBER STRING
        """))
    parser = Parser(gram)
    parser.setup()
    parser.addtoken(NAME, "foo", None)
    parser.addtoken(NUMBER, "42", None)
    parser.addtoken(STRING, "bar", None)
    assert parser.rootnode[0] == 1
    assert parser.rootnode[1] == []
    for n in parser.rootnode[1]:
        assert n[0] == NAME
        assert n[1] == "foo"
    assert parser.rootnode[1][1][0] == NUMBER
    assert parser.rootnode[1][1][1] == "42"
    assert parser.rootnode[1][2][0] == STRING
    assert parser.root

# Generated at 2022-06-11 19:48:07.298371
# Unit test for method setup of class Parser
def test_Parser_setup():
    """Test the setup method of Parser."""
    p = Parser(Grammar())
    p.setup()



# Generated at 2022-06-11 19:48:18.763579
# Unit test for method pop of class Parser
def test_Parser_pop():
    import unittest

    import blib2to3.pgen2.grammar as grammar
    from blib2to3.pgen2 import token

    import blib2to3.pgen2.driver as driver

    class TestParser(unittest.TestCase):

        def setUp(self):
            file = driver.load_grammar("Grammar.txt")
            # print(open(file.name).read())
            self.gram = grammar.parse_grammar(file)
            self.assertIsNone(self.gram.check_all())

        def test_pop(self):
            p = Parser(self.gram)
            # p.setup()

# Generated at 2022-06-11 19:48:30.304462
# Unit test for method shift of class Parser
def test_Parser_shift():
    from blib2to3.pgen2.grammar import Grammar

    grammar = Grammar('', {})
    parser = Parser(grammar)
    parser.setup()

    # Shift a token
    parser.shift(1, '', 0)
    stack_after_shift = [(None, 0, (None, '', None, None))]
    assert parser.stack == stack_after_shift

    # Shift a token of the end of the program
    parser.shift(1, '', 0)
    stack_after_shift = [(None, 0, (None, '', None, [None]))]
    assert parser.stack == stack_after_shift

# Generated at 2022-06-11 19:48:40.646706
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .tokenize import generate_tokens

    class FakeInput(object):
        def __init__(self, token_list: Sequence[Tuple[int, Any, Any, Any, Any]]) -> None:
            self.token_list = token_list
            self.token_iter = iter(token_list)

        def token(self) -> Tuple[int, Any, Any, Any, Any]:
            return next(self.token_iter)

    class FakeGrammar(object):
        def __init__(
            self,
            start: int,
            dfas: Dict[int, DFA],
            labels: Sequence[Tuple[int, Optional[int]]],
            tokens: Dict[int, int],
            keywords: Dict[Text, int],
        ) -> None:
            self.start = start

# Generated at 2022-06-11 19:48:56.563069
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import pytree
    from . import symbol

    g = grammar.grammar
    p = Parser(g)
    p.setup(symbol.file_input)
    p.addtoken(token.ENDMARKER, "", pytree.new_context("", 1))
    p.pop()
    p.pop()

# Generated at 2022-06-11 19:49:02.223312
# Unit test for method pop of class Parser
def test_Parser_pop():
    class MockGrammar:
        class MockGrammar2:
            start = 0
            dfas = {0: ([[(1, 0)], [(0, 0)]], {0: 0, 1: 0})}
            labels = {1: (1, None)}
            keywords = {}
            tokens = {1: 1}

        start = 0
        dfas = {0: ([[(1, 0)], [(0, 0)]], {0: 0, 1: 0})}
        labels = {1: (1, None)}
        keywords = {}
        tokens = {1: 1}

    class MockNode:
        pass

    def MockConvert(grammar, node):
        return MockNode()

    from blib2to3.pgen2.grammar import Grammar


# Generated at 2022-06-11 19:49:13.504789
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2 import grammar
    import blib2to3.pgen2.parse

    def convert_leaf(
        grammar_: Grammar, node: RawNode
    ) -> Union[Node, Leaf]:
        converted = blib2to3.pgen2.parse.convert_leaf(grammar_, node)
        assert isinstance(converted, Leaf)
        return converted

    gram = grammar.Grammar("Python.asdl", "Python/Python.asdl", "Python.grammar")

    p = Parser(gram, convert_leaf)
    p.setup()

    p.addtoken(token.ID, "x", None)
    p.addtoken(token.SEMI, ":", None)
    p.addtoken(token.ID, "y", None)
    p

# Generated at 2022-06-11 19:49:22.505633
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Sanity check: test that Parser.classify works"""
    # Create a Parser instance
    import blib2to3.pgen2.grammar as grammar
    g = grammar.grammar
    p = Parser(g)
    # Start an imaginary parsing run
    p.setup()
    # Create a token
    type = token.NAME
    value = "beer"
    context = None  # Doesn't really matter
    # Classify it
    ilabel = p.classify(type, value, context)
    label = g.labels[ilabel]
    # Message
    print("Token type %s classified as %s" % (type, label))


if __name__ == "__main__":
    test_Parser_classify()

# Generated at 2022-06-11 19:49:24.226380
# Unit test for method shift of class Parser
def test_Parser_shift():
    assert 0



# Generated at 2022-06-11 19:49:33.325735
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from blib2to3.pgen2.grammar import driver

    grammar = driver.load_grammar(
        """
        simple: NAME
        """
    )

    p = Parser(grammar)
    p.setup()
    assert p.addtoken(token.NAME, "hello", None)
    assert p.rootnode.type == 257
    assert p.rootnode.children[0].type == token.NAME
    assert p.rootnode.children[0].value == "hello"
    p.setup()
    assert p.addtoken(token.NAME, "hello", None)
    assert p.addtoken(token.NAME, "world", None)
    assert p.rootnode is None

# Generated at 2022-06-11 19:49:41.096226
# Unit test for method push of class Parser
def test_Parser_push():
    from blib2to3.pgen2 import driver

    # This is a simple test that the code does not crash even if the
    # grammar contains a cycle.

    g = driver.load_grammar("Grammar/Grammar")
    # pgen also creates a cycle, but it's not present in the pickled
    # version we can get...
    g.dfas["expr"][0][0][0] = g.dfas["atom"][0][0][0]
    p = Parser(g)
    p.setup()
    p.shift(1, "a", 1, None)
    p.push(2, p.grammar.dfas[2], 0, None)
    p.pop()
    p.pop()

test_Parser_push()

# Generated at 2022-06-11 19:49:44.744934
# Unit test for method setup of class Parser
def test_Parser_setup():
    """Method setup of class Parser"""
    p = Parser(Grammar())
    p.setup()
    assert p.stack == [(({}, {}), 0, (257, None, None, []))]
    assert p.rootnode is None

    p.setup(258)
    assert p.stack == [(({}, {}), 0, (258, None, None, []))]
    assert p.rootnode is None


# Generated at 2022-06-11 19:49:56.212997
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # type: () -> None
    import unittest

    class ParseTest(unittest.TestCase):
        def setUp(self):
            # type: () -> None
            from . import driver

            self.p = driver.Parser()
            self.p.setup()

        def test_addtoken_empty(self):
            # type: () -> None
            self.assertRaises(ParseError, self.p.addtoken, token.ENDMARKER, "", None)

        def test_addtoken_good(self):
            # type: () -> None
            self.p.addtoken(token.NAME, "foo", None)
            self.p.addtoken(token.NEWLINE, "\n", None)
            self.p.addtoken(token.INDENT, "\n", None)

# Generated at 2022-06-11 19:50:04.260576
# Unit test for method shift of class Parser
def test_Parser_shift():
    pgen = Parser(Grammar, None)
    test_tokens = [
        (token.NAME, "test", (1, 0)),
        (token.NAME, "test", (2, 0)),
        (token.NAME, "test", (3, 0)),
        (token.NAME, "test", (4, 0)),
    ]
    pgen.setup()
    for token in test_tokens:
        pgen.addtoken(token[0], token[1], token[2])



# Generated at 2022-06-11 19:50:28.972303
# Unit test for method shift of class Parser
def test_Parser_shift():
    import StringIO
    import blib2to3.pgen2.tokenize as tokenize_mod
    from blib2to3.pgen2 import driver

    import blib2to3.pgen2.parse as parse_mod
    import blib2to3.pygram as pygram
    import blib2to3.pytree as pytree

    # Grammar to parse a python source file
    py_grammar = pygram.python_grammar

    # Tokenize from a file
    with open("test/test_driver.py") as myfile:
        mystream = myfile.read()
    stringio = StringIO.StringIO(mystream)
    program_tokens = tokenize_mod.generate_tokens(stringio.readline)

    # Parser

# Generated at 2022-06-11 19:50:41.762198
# Unit test for method shift of class Parser
def test_Parser_shift():
    import pytest

    grammar = Grammar.from_string("""
        start = @add2
        add2 = 'sum' `(` @number `,` @number `)` -> sum2
        number = '[0-9]+' -> int
        """)

    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NAME, 'sum', (1, 1))
    p.addtoken(token.LPAR, '(', (1, 5))
    p.addtoken(token.NUMBER, '12', (1, 6))
    p.addtoken(token.COMMA, ',', (1, 8))
    p.addtoken(token.NUMBER, '2', (1, 10))
    p.addtoken(token.RPAR, ')', (1, 11))

# Generated at 2022-06-11 19:50:52.176256
# Unit test for method pop of class Parser
def test_Parser_pop():
    from textwrap import dedent
    from .driver import Driver
    from . import grammar, tokenize

    pgen = Driver(grammar, convert=lam_sub)
    pgen.parse_tokens(tokenize.generate_tokens(dedent("""\
    def f():
        if a:
            def g(x):
                return x+1
            return g(1)
        else:
            return 0
    """)))

    p = Parser(pgen.grammar, convert=lam_sub)
    p.setup()
    stack = []

# Generated at 2022-06-11 19:50:57.789419
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = Grammar()
    parse = Parser(grammar)
    parse.setup()
    assert parse.addtoken(1, 'test', None)
    assert parse.rootnode is not None
    assert parse.rootnode.children[0].type == 1
    assert parse.rootnode.children[0].value == 'test'
    assert parse.rootnode.children[0].children == []
    assert parse.rootnode.children[0].used_names == set()

# Generated at 2022-06-11 19:51:11.190141
# Unit test for method push of class Parser
def test_Parser_push():
    # test1
    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.push(2, 0, 0, Context(0, 0))
    assert len(parser.stack) == 2

# Generated at 2022-06-11 19:51:19.619005
# Unit test for method shift of class Parser
def test_Parser_shift():
    t = token.tok_name
    fake_grammar = {
        "start": 256,
        "dfas": {256: ([[(257, 0)], [(0, 1)]], {256: 0, 257: 1})},
        "labels": [
            (257, None),
            (258, None),
            (t.DOT, None),
            (t.PLUS, None),
            (t.MINUS, None),
        ],
        "keywords": {},
        "tokens": {
            t.DOT: 2,  # DOT
            t.PLUS: 3,  # PLUS
            t.MINUS: 4,  # MINUS
        },
        "errorfunc": None,
    }
    fake_grammar = Grammar(fake_grammar)
    p = Parser

# Generated at 2022-06-11 19:51:30.395771
# Unit test for method pop of class Parser
def test_Parser_pop():
    print("Begin testing method pop of class Parser")
    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup(start =  -17)

# Generated at 2022-06-11 19:51:43.466880
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import driver
    from . import symbol as sy

    class PartialParser(Parser):
        def __init__(self, *args, **kwds):
            Parser.__init__(self, *args, **kwds)
            self.newnode: Optional[Node] = None

        def shift(self, type: int, value: Optional[Text], newstate: int, context: Context) -> None:
            Parser.shift(self, type, value, newstate, context)
            dfa, state, node = self.stack[-1]
            assert node[-1] is not None
            self.newnode = node[-1][-1]

    parser = PartialParser(driver.get_grammar())
    parser.setup()
    parser.addtoken(token.NAME, "a", (0, 0))

# Generated at 2022-06-11 19:51:50.139458
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import blib2to3.pgen2.grammar as grammar

    g = grammar.grammar_from_file(sys.argv[1])  # Read grammar from file

    p = Parser(g)
    p.setup()
    while 1:
        s = sys.stdin.readline()
        if not s: break
        tok = blib2to3.pgen2.tokenize.generate_tokens(StringIO(s).readline)
        tok = list(tok)[0]
        p.addtoken(int(tok[0]), tok[1], (1, 0))

# Generated at 2022-06-11 19:51:50.863481
# Unit test for method shift of class Parser
def test_Parser_shift():
    assert Parser(Grammar("")).shift("", "", 1, Context(""))

# Generated at 2022-06-11 19:52:26.372641
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest, blib2to3.pgen2.driver, blib2to3.pgen2.parse, blib2to3.pytree

    class TestParser(unittest.TestCase):

        def __init__(self, *args):
            unittest.TestCase.__init__(self, *args)
            self.driver = blib2to3.pgen2.driver.Driver("(test_grammar)", "test_tokens")
            self.parser = blib2to3.pgen2.parse.Parser(
                self.driver.grammar, None
            )
            self.parser.setup()

        def tokenize(self, input):
            return self.driver.tokenize_str(input)

        def expect_parse_error(self, input):
            self.parser.setup

# Generated at 2022-06-11 19:52:33.532140
# Unit test for method classify of class Parser
def test_Parser_classify():
    import io
    import os
    import random
    import re
    from . import driver

    # Generate random strings, weighted towards short ones with
    # alphanumerics and underscores
    def generate_random_string():
        rnd = random.random
        rndint = random.randrange
        if rnd() < 0.05:
            # Returns a longish random string
            chars = "abcdefghijklmnopqrstuvwxyz"
            chars = chars + chars.upper() + "0123456789_"
            s = "".join([chars[rndint(0, len(chars))] for i in range(5 + rndint(5, 20))])

# Generated at 2022-06-11 19:52:44.924070
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Test method pop of class Parser."""

    def get_test_stack(test_objects: Sequence[Any]) -> List[Tuple[Any, int, Any]]:
        """Generate a stack according to objects in test_objects.

        (dfa, state, node) is the tuple that is used to construct a test stack.
        """
        stack: List[Tuple[DFAS, int, RawNode]] = []
        for obj in test_objects:
            if isinstance(obj, Tuple) and len(obj) == 3:
                stack.append(obj)
            else:
                assert isinstance(obj, List)
                for alt in obj:
                    assert isinstance(alt, Tuple) and len(alt) == 3
                    stack.append(alt)
        return stack


# Generated at 2022-06-11 19:52:54.348390
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, token_utils

    parser = Parser(grammar.Grammar(token_utils.tokenize("""
        grammar test;
        start: x;
        x: "name" | "num";
    """)))
    parser.setup()
    assert not parser.addtoken(token.NAME, "test", None)
    assert not parser.addtoken(token.NAME, "test2", None)
    assert parser.addtoken(token.NAME, "test4", None)
    assert parser.rootnode is not None
    assert parser.rootnode[0] == "start"
    assert len(parser.rootnode[1]) == 1
    assert parser.rootnode[1][0][0] == "x"
    assert len(parser.rootnode[1][0][1]) == 2
    assert parser.rootnode

# Generated at 2022-06-11 19:52:59.636966
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import driver

    grammar = driver.load_grammar("Grammar.txt")
    parser = Parser(grammar)
    classify = parser.classify
    classify(token.NUMBER, "123", None)
    classify(token.NAME, "abc", None)

# Generated at 2022-06-11 19:53:02.975697
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . driver import Driver
    from . import grammar

    d = Driver()
    p = Parser(grammar.grammar, d.driver.convert)
    p.setup()
    for i in range(15):
        p.pop()
        assert p.rootnode is None
        assert p.stack == []
    p.pop()



# Generated at 2022-06-11 19:53:06.402827
# Unit test for method setup of class Parser
def test_Parser_setup():
    p = Parser(Grammar.from_file("Python.g", "2.5"))
    p.setup()
    print(p.stack)
    print(p.rootnode)
    print(p.used_names)


# Generated at 2022-06-11 19:53:14.261351
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Create a small grammar to test it with
    g = Grammar()
    g.keywords["else"] = g.keywords["if"] = g.keywords["return"] = 10
    g.keywords["pass"] = g.keywords["while"] = g.keywords["print"] = 20
    g.tokens[token.NUMBER] = 30
    g.tokens[token.NAME] = 40
    g.tokens[token.PLUS] = g.tokens[token.MINUS] = 50
    # Create the following DFA:
    #
    #          2
    #    s ----------> s
    #    |     |       |
    #    v     |       |
    #   50+   50-      |
    #   s      s       |
    #   |      |       |

# Generated at 2022-06-11 19:53:23.911113
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    tests = [
        (token.NUMBER, "13", 257),
        (token.NAME, "and", 260),
        (token.NAME, "and_", 261),
        (token.NAME, "TruE", 262),
        (token.NAME, "TrUe", 262),
        (token.NAME, "TRUE", 262),
        (token.NAME, "true", 262),
        (token.NAME, "foobar", 261),
    ]
    p = Parser(grammar.grammar, None)
    for type, value, expected in tests:
        assert p.classify(type, value, None) == expected
    p.addtoken(token.NAME, "foobar", None)



# Generated at 2022-06-11 19:53:34.470182
# Unit test for method classify of class Parser
def test_Parser_classify():
    def dummy_convert(grammar: Grammar, node: RawNode) -> NL:
        assert node[3] is not None
        return Node(type=node[0], children=node[3], context=node[2])
    import io
    import contextlib

    @contextlib.contextmanager
    def captured_output() -> Text:
        # https://stackoverflow.com/questions/16571150/how-to-capture-stdout-output-from-a-python-function-call
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr

# Generated at 2022-06-11 19:54:31.963441
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    grm = grammar.Grammar()
    grm.parse(grammar.grammar)
    prs = Parser(grm)
    prs.setup()
    print("Testing Parser.classify()...")
    for token in token.tok_name.values():
        try:
            ilabel = prs.classify(token, None, None)
        except ParseError:
            print("No label for token %r" % token.__name__)
        else:
            print("Token %r has label %s" % (token.__name__, ilabel))
    print("Done testing Parser.classify().")


if __name__ == "__main__":
    test_Parser_classify()

# Generated at 2022-06-11 19:54:40.282082
# Unit test for method shift of class Parser
def test_Parser_shift():

    class TestGrammar(Grammar):
        """A grammar where all labels are unique, but only these tokens
         are relevant:
        NUMBER = r'(\d+)'
        NAME = r'(\w+)'
        """


# Generated at 2022-06-11 19:54:49.909389
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    # This is run as a stand-alone program

    # Set up logging
    def error(msg: Any) -> None:
        print(msg)

    import sys
    import os
    import bz2
    import gzip

    default_target = sys.version[:3]
    try:
        from importlib.metadata import version
    except ImportError:
        from importlib_metadata import version
    if version(__package__) != default_target:
        print(
            f"Warning: this version of the parser package is for Python {default_target}, "
            f"and you are running Python {version(__package__)}"
        )
    from . import driver
    from . import pgen2

    # Get target version from command line, if present
    target = default_target

# Generated at 2022-06-11 19:54:57.016254
# Unit test for method push of class Parser
def test_Parser_push():
    start = 1
    grammar = Grammar(start=start)
    start_dfas: DFA = []
    # The list of start_dfas entries is interpreted as a DFA by the functions of
    # Parser: push, pop and classify. The first tuple is the start state.
    start_dfas.append([(1, 2), (2, 3), (3, 4)])
    start_dfas.append([(2, 6), (3, 7)])
    start_dfas.append([(1, 5)])
    start_dfas.append([(2, 8)])
    start_dfas.append([(0, 4)])
    start_dfas.append([(0, 5)])
    start_dfas.append([(0, 6)])

# Generated at 2022-06-11 19:54:59.747811
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import driver

    token_list = driver.tokenize("x += 1")
    grammar = Grammar("Grammar.txt")
    p = Parser(grammar)
    p.setup("file_input")
    for typ, value, begin, end, line in token_list:
        if p.addtoken(typ, value, (begin, end)):
            break
    if p.addtoken(typ, value, (begin, end)):
        pass


# Generated at 2022-06-11 19:55:09.082749
# Unit test for method pop of class Parser
def test_Parser_pop():
    test_Parser_pop.num_calls = 0
    test_Parser_pop.num_calls += 1

    class Grammar:
        def __init__(self):
            self.start = 0
            self.labels = []
            self.labels.append(('', ''))
            self.labels.append(('', ''))
            self.dfas = []
            self.dfas.append(([(0, 0), ], []))

    class DFAS:
        def __init__(self, states:list, first:list):
            self.states = states
            self.first = first

        def __getitem__(self, key):
            if key == 0:
                return self.states
            else:
                return self.first

    grammar = Grammar()

# Generated at 2022-06-11 19:55:19.357761
# Unit test for method shift of class Parser
def test_Parser_shift():
    class MockNode:
        def __init__(self, type, value, context, children):
            self.type = type
            self.value = value
            self.context = context
            self.children = children

    class MockParser:
        def __init__(self):
            self.stack = [(0, 0, (0, None, None, []))]

        def convert(self, grammar, node):
            return MockNode(node[0], node[1], node[2], node[3])

    parser = MockParser()
    parser.shift(1, "token", 1, "context")

    (type, value, context, children) = parser.stack[-1][-1]
    assert type == 0
    assert value is None
    assert context is None

# Generated at 2022-06-11 19:55:24.130282
# Unit test for method push of class Parser
def test_Parser_push():
    import random
    import unittest
    import grammar

    class TestParser(unittest.TestCase):

        def test_push(self):
            parser = Parser(grammar.grammar)
            parser.setup()
            parser.push(0, parser.grammar.dfas[0], 0, (0,0))

# Generated at 2022-06-11 19:55:32.115589
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2.tokenize import detect_encoding
    from blib2to3.pgen2 import driver
    import io
    import sys

    s = "def f(x):\n  return x + 1\n"
    f = io.BytesIO(s.encode("utf-8"))
    r = detect_encoding(f.readline)
    f.seek(0)
    t = driver.Tokenizer(f, r[0])
    p = Parser(driver.load_grammar("Python.gram"), None)
    p.setup()
    for tp, value, context in t:
        if value is None:
            continue
        if p.addtoken(tp, value, context):
            break


# Generated at 2022-06-11 19:55:37.769884
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar

    g = grammar.grammar
    p = Parser(g)
    assert p.classify(token.COMMENT, "") == g.labels.index(("token.COMMENT", ""))
    assert p.classify(token.NAME, "if") == g.labels.index(("keyword", "if"))
    assert p.classify(token.NAME, "true") == g.labels.index(("NAME", "true"))
    assert p.classify(token.NAME, "xxx") == g.labels.index(("NAME", "xxx"))

