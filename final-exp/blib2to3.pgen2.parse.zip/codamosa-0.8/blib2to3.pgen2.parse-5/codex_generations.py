

# Generated at 2022-06-11 19:45:52.076798
# Unit test for method classify of class Parser
def test_Parser_classify():
    for (type, value, context) in (
        (token.NAME, "def", "c"),
        (token.NAME, "from", "c"),
        (token.NAME, "froms", "c"),
    ):
        assert Parser(Grammar()).classify(type, value, context) == token.NAME

# Generated at 2022-06-11 19:46:00.279656
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import grammar
    from . import parse

    g = grammar.Grammar("blib2to3.pgen2.test.test_grammar")
    p = parse.Parser(g)
    assert p.classify(token.STRING, "foo", "ctx") == g.tokens.get(token.STRING)
    assert p.classify(token.NAME, "foo", "ctx") == g.tokens.get(token.NAME)
    assert p.classify(token.NAME, "foo", "ctx") != None
    assert p.classify(token.NAME, "print", "ctx") == g.keywords["print"]
    assert p.classify(token.NAME, "print", "ctx") != None
    assert p.classify(token.NAME, "foo", "ctx") != None


# Generated at 2022-06-11 19:46:02.129155
# Unit test for method shift of class Parser
def test_Parser_shift():
    print(Parser.shift)


if __name__ == "__main__":
    test_Parser_shift()

# Generated at 2022-06-11 19:46:14.022119
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar, tokenize

    # Create a custom parser.
    # This parser must take into account a new input token that does nothing.
    class NewParser(Parser):
        def __init__(self, grammar):
            super().__init__(grammar)

        def classify(self, type, value, context):
            if type == token.NT_OFFSET + 1:
                # Value doesn't matter, we don't care about the token.
                return self.grammar.tokens[type]
            return super().classify(type, value, context)

    # Create a custom grammar that adds this token.
    class NewGrammar(grammar.Grammar):
        def __init__(self):
            super().__init__()
            self.tokens = dict(self.tokens)
            self.t

# Generated at 2022-06-11 19:46:26.894373
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import grammar

    grammar = grammar.parse_grammar(
        "blib2to3.pgen2.grammar", "Test-Expr ::= foo:NAME ':' bar:NAME"
    )

    def convert(g, node):
        return node

    p = Parser(grammar, convert)
    p.setup()
    p.shift(token.NAME, "foo", 0, None)
    p.shift(token.COLON, ":", 1, None)
    p.shift(token.NAME, "bar", 2, None)

    foo = p.rootnode[1]
    assert foo[0] == token.NAME
    assert foo[1] == "foo"

    colon = foo[2]
    assert colon[0] == token.COLON
    assert colon[1] == ":"

   

# Generated at 2022-06-11 19:46:36.358539
# Unit test for method pop of class Parser
def test_Parser_pop():
    import os.path
    import _ast
    from blib2to3.pgen2 import driver

    test_root = os.path.dirname(__file__)
    grammar_file = os.path.join(test_root, 'Python.grammar')
    g = driver.load_grammar(grammar_file)
    p = Parser(g)

    # Attribute not set at first
    assert p.rootnode is None

    # AssertionError: pop from empty list
    try:
        p.pop()
    except AssertionError:
        pass
    else:
        assert False, 'Expected AssertionError'

    # The stack is populated with a dummy entry
    p.stack = [(DFA(), 0, RawNode(47, None, None, []))]
    # Now we can pop successfully

# Generated at 2022-06-11 19:46:42.977960
# Unit test for method pop of class Parser
def test_Parser_pop():
    import pprint
    p = Parser(Grammar())
    p.push(0, None, 0, None)
    n = p.rootnode
    assert n == None and p.rootnode == None and p.used_names == set()
    p.push(2, None, 0, None)
    p.push(2, None, 0, None)
    assert p.rootnode == None
    p.pop()
    assert p.rootnode == None
    p.pop()
    assert p.rootnode == None
    p.pop()
    assert p.rootnode == None and p.used_names == set()

# Generated at 2022-06-11 19:46:53.603322
# Unit test for method shift of class Parser
def test_Parser_shift():

    class MyGrammar(Grammar):
        def __init__(self):
            super(MyGrammar, self).__init__()
            self.dfas = {1: ([[(0, 1), (2, 1)], [(0, 1), (1, 1), (2, 1)]], None)}
            self.labels = (None, "NAME", "NUMBER")

    parser = Parser(MyGrammar())
    parser.setup()
    for i in range(1, 3):
        parser.addtoken(i, "VALUE", Context(1))
    assert parser.rootnode.children == [Leaf(1, "VALUE", context=Context(1))] * 2


# Generated at 2022-06-11 19:46:55.431950
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar(token)

    Parser.pop('')

# Generated at 2022-06-11 19:47:04.506417
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import tokenize


    parser = Parser(Grammar({"start": [['', 'add'], ['a', 'add', 'b']]}, {}, {}), None)
    def test(s, label):
        tokens = tokenize.generate_tokens(iter(s).__next__)
        next(tokens)
        token = next(tokens)
        assert parser.classify(*token[0:3]) == label
    test("+", token.ADD)
    test("a", token.NAME)



# Generated at 2022-06-11 19:47:31.184448
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Set up
    import blib2to3.pgen2.driver as driver

    # Test
    grammar = driver.load_grammar("Grammar/Python.gram")
    p = Parser(grammar)
    p.setup()
    # Pop and test that parser is empty
    p.pop()
    assert not p.stack
    # Pop and test that popnode was added to rootnode
    p.push(token.NAME, p.grammar.dfas[token.NAME], 0, Context(0, 0))
    p.pop()
    assert len(p.rootnode[1]) == 1
    # Pop and test that popnode was added to node
    p.setup()
    p.push(token.NAME, p.grammar.dfas[token.NAME], 0, Context(0, 0))

# Generated at 2022-06-11 19:47:40.591319
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import parser, driver, pygram
    from . import token
    import sys

    if len(sys.argv) > 1:
        driver.parse_file(sys.argv[1])
        sys.exit(0)

    p = Parser(pygram.python_grammar)
    p.setup()

    def parse(src: Text) -> None:
        s = iter(src.split())
        while True:
            try:
                t = next(s)
            except StopIteration:
                tok = token.ENDMARKER, "", (1, 1)
            else:
                t = t.lower()
                if t == "async":
                    tok = getattr(token, t.upper(), pygram.python_grammar.tokens[t])
                else:
                    tok

# Generated at 2022-06-11 19:47:51.305026
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar(r"""
    aaa: 'a' bbb;
    bbb: 'b';
    """)
    convert = lambda grammar, node: node
    p = Parser(grammar, convert)
    p.setup()
    p.addtoken(grammar.symbol2number['aaa'], None, None)
    p.addtoken(grammar.symbol2number['bbb'], None, None)
    assert p.stack[-1] == (grammar.dfas[grammar.symbol2number['aaa']], 1, (1, None, None, [2, None]))
    p.pop()
    assert p.stack == []
    assert p.rootnode == (1, None, None, [2, None])

# Generated at 2022-06-11 19:47:52.498893
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    assert True

# Generated at 2022-06-11 19:47:59.565411
# Unit test for method pop of class Parser
def test_Parser_pop():
    from .driver import Driver
    from .grammar import Grammar
    import sys
    import io

    def print_tree(root):
        print(root.type)
        for child in root.children:
            print_tree(child)

    grammar = Grammar()
    driver = Driver(grammar)
    driver.parse_file(sys.argv[1])
    parser = Parser(grammar)
    parser.setup()
    for t in driver.gen_tokens():
        parser.addtoken(*t)
    print_tree(parser.rootnode)

# Generated at 2022-06-11 19:48:10.351948
# Unit test for method pop of class Parser
def test_Parser_pop():
    stmt = 0
    grammar = Grammar()

    gr_item = [
        (
            [
                (2, NL, 'ANY_EXPR'),
                (3, NL, 'ANY_EXPR'),
                (1, NL, ('ANY_EXPR', 'ANY_EXPR'), ([0], [1])),
            ],
            [
                (1, (gr_item, 0)),
                (1, (gr_item, 1)),
                (0, ()),
            ],
            [
                (2, 'ANY_EXPR'),
                (3, 'ANY_EXPR'),
            ]
        ),
    ]

# Generated at 2022-06-11 19:48:21.106861
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()

    pil_tree = []
    p.stack = [([[(0, 0), (0, 1)], [(1, 1), (2, 1)]], (0, "{"), pil_tree)]
    p.push(3, ([[(0, 0), (0, 1)], [(1, 1), (2, 1)]], 4), 0, (0, 0))

    # expected stack
    pil_tree1 = [1, 2]
    stack1 = [([[(0, 0), (0, 1)], [(1, 1), (2, 1)]], (0, "{"), pil_tree1),
              ([[(0, 0)], [(1, 1)]], 0, pil_tree)]

# Generated at 2022-06-11 19:48:26.192007
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(Grammar())
    with pytest.raises(PytestAssertRewriteWarning):
        p.push(0, 0, 0, 0)

# Generated at 2022-06-11 19:48:34.045111
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .grammar import Grammar

    gr = Grammar()
    gr.start = 256
    gr.tokens = {"START": 256, "NAME": 257}
    gr.dfas = {
        256: (((257, 1),), (1,).__contains__),
        257: (((1, 1),), (0,).__contains__),
    }
    gr.labels = ((0, 0), ("NAME", None))

    p = Parser(gr)
    p.setup()
    p.addtoken("NAME", "foo", ((0, 0), (0, 0)))
    assert p.rootnode == "foo"


# Generated at 2022-06-11 19:48:44.053368
# Unit test for method setup of class Parser
def test_Parser_setup():
    from .token import tok_name
    from . import parsetok
    from . import parsetok_grammar
    parser = Parser(parsetok_grammar, parsetok.convert)

    parser.setup()

    assert parser.stack == [(parsetok_grammar.dfas[parsetok_grammar.start], 0, [0, None, None, []])]
    assert parser.rootnode == None
    assert parser.used_names == set()
    assert parser.stack[0][0] == (parsetok_grammar.dfas[parsetok_grammar.start])


# Generated at 2022-06-11 19:49:06.060393
# Unit test for method push of class Parser
def test_Parser_push():
    from .driver import parse_string
    from .pgen import generate_grammar
    grammar = generate_grammar(parse_string("a: '2' '3'", start="file_input"))
    p = Parser(grammar)
    p.setup()
    p.addtoken(token.NUMBER, "2", (1, 0))
    p.addtoken(token.NUMBER, "3", (1, 0))

# Generated at 2022-06-11 19:49:08.675696
# Unit test for method pop of class Parser
def test_Parser_pop():
    p = Parser(Grammar())
    p.push(1, None, 0, None)
    p.pop()




# Generated at 2022-06-11 19:49:16.920838
# Unit test for method setup of class Parser
def test_Parser_setup():
    import unittest
    import unittest.mock as mock

    class MockGrammar:
        start = 1
        dfas = mock.Mock()

    def testit(start=None, expected=1):
        p = Parser(MockGrammar())
        p.setup(start)
        assert p.stack[0] == (MockGrammar.dfas[expected], 0, (expected, None, None, []))

    testit()
    testit(0, 0)

# Generated at 2022-06-11 19:49:26.871103
# Unit test for method pop of class Parser
def test_Parser_pop():
    import os
    import blib2to3.pgen2.token as token
    import blib2to3.pgen2.parse as parse
    import blib2to3.pytree as pytree
    from blib2to3.pgen2 import driver
    from blib2to3.pgen2 import convert
    from blib2to3.pgen2.grammar import Grammar

    grammars_dir = os.path.join(os.path.dirname(__file__), "..", "grammars", "2.7")
    driver.Driver(parse.Parser, convert.make_tree,
                  grammars_dir, "Python.asdl").run_tests()

# Generated at 2022-06-11 19:49:35.773504
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    state = (
        (
            (
                (
                    (0, "a"),
                    (1, "b"),
                ),
            ),
        ),
        {
            "a": 0,
            "b": 1,
        },
    )
    dfa = state
    grammar = Grammar()
    grammar.dfas = {
        "a": dfa,
        "b": dfa,
    }
    grammar.start = "a"
    parser = Parser(grammar)
    parser.setup()
    assert parser.stack == [(dfa, 0, ("a", None, None, []))]
    assert parser.addtoken(1, "a", Context(None, 0, 1, 1)) is False

# Generated at 2022-06-11 19:49:46.307823
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2.parse import parse_grammar

    grammar = parse_grammar(
        """
        !start: x=. y=!
        """
    )
    p = Parser(grammar)

    # Unit test for method setup of class Parser
    def setup(start, x, y):
        p.setup(start)
        assert bool(p.stack) == x
        assert bool(p.rootnode) == y

    # Test: Setup initializes the Parser object (and sets this.stack
    # to an empty Stack).
    setup(grammar.start, True, False)

    # Test: Setup initializes the Parser object (and sets this.stack
    # to an empty Stack).
    setup(None, True, False)



# Generated at 2022-06-11 19:49:56.924161
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Test for classify"""

# Generated at 2022-06-11 19:50:03.065799
# Unit test for method push of class Parser
def test_Parser_push():
    class grammar(object):
        labels = ['a', 'b', 'c']

    class Grammar(object):
        dfas: Dict[int, DFAS] = {0: ([[(1, 1), (2, 2)], [(1, 3)], [(0, 2)]], {0: 0}),
                                 1: ([[(1, 3)], [(0, 3)]], {3: 0}),
                                 }
        start = 1

    grammar = Grammar()
    Parser(grammar).push(0, grammar.dfas[0], 0, None)

# Generated at 2022-06-11 19:50:09.782801
# Unit test for method classify of class Parser
def test_Parser_classify():
    import pgen2.grammar as grammar
    import pgen2.token as token
    import pgen2.driver as driver

    g = grammar.grammar('Grammar.txt')
    p = Parser(g)

    t = driver.tokenize_file('test.py')
    p.setup()
    for (type, value, context) in t:
        print(p.classify(type, value, context))

# Generated at 2022-06-11 19:50:19.074003
# Unit test for method shift of class Parser
def test_Parser_shift():
    # type: () -> None
    from . import driver, token

    class Driver(driver.Driver):
        def __init__(self, *args, **kwargs):
            # type: (*Any, **Any) -> None
            super(Driver, self).__init__(*args, **kwargs)
            self.stack: List[Tuple[Sequence[Tuple[int, int]], int, RawNode]] = []

        def shift(self, type, value, newstate):
            # type: (int, Optional[Text], int) -> None
            from .pgen2 import generate

            dfa, state, node = self.stack[-1]
            rawnode = (type, value, None, None)
            newnode = generate.convert_leaf(self.grammar, rawnode)

# Generated at 2022-06-11 19:50:53.000675
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = Grammar()
    convert = None
    p = Parser(grammar, convert)
    p.setup()
    type = 0
    value = None
    newstate = 0
    context = Context()
    p.shift(type, value, newstate, context)
    # The above code should have worked.

# Generated at 2022-06-11 19:50:56.694950
# Unit test for method setup of class Parser
def test_Parser_setup():
    from . import test_grammar2

    p = Parser(test_grammar2)
    try:
        p.rootnode
    except:
        pass
    else:
        raise AssertionError
    p.setup()
    assert p.rootnode is None


# Generated at 2022-06-11 19:51:09.967299
# Unit test for method push of class Parser
def test_Parser_push():
    from .grammar import Grammar
    from . import driver

    # Create a frozen parser for Python 2.4
    # src = open(sys.executable).read()
    src = open("../Python-2.4/Parser/grammar.c").read()
    gr = driver.load_grammar(src)
    parser = Parser(gr)
    parser.setup()
    # Test symbol pushing
    # parser.push(270, 7, 0, (0, 0))
    parser.push(270, (7, 0), 0, (0, 0))
    assert parser.stack == [(7, 0, (270, None, None, []))]
    parser.push(270, (7, 0), 0, (0, 0))

# Generated at 2022-06-11 19:51:12.055166
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar

    # Create a grammar.Grammar instance
    gr = grammar.Grammar()
    parse = Parser(gr)
    parse.push(gr.syms["NAME"], gr.dfas["NAME"], 1, None)

# Generated at 2022-06-11 19:51:14.337907
# Unit test for method pop of class Parser
def test_Parser_pop():
    # TODO: Remove this unit test
    try:
        Parser_pop()
    except Exception:
        pass



# Generated at 2022-06-11 19:51:25.048909
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Verify that addtoken() is able to handle all types of transitions

    (shift, push, and pop)."""

    # First create a dummy grammar
    from . import grammar

    # Create a dummy token map
    from . import token

    dummy_token_map: Dict[Text, int] = {
        "DUMMY": token.DUMMY,
        "NAME": token.NAME,
        "NUMBER": token.NUMBER,
    }

    # Create a dummy symbol map
    dummy_symbol_map: Dict[Text, int] = {
        "expr": 256,
        "x": 257,
        "y": 258,
    }

    # Create a dummy label map

# Generated at 2022-06-11 19:51:33.535200
# Unit test for method push of class Parser
def test_Parser_push():
    p = Parser(Grammar())
    p.setup()
    p.push(100, [], 0, "Test")
    assert p.stack[1][0] == [], p.stack[1][0]
    assert p.stack[1][1] == 0, p.stack[1][1]
    assert p.stack[1][2][0] == 100, p.stack[1][2][0]
    assert p.stack[1][2][1] is None, p.stack[1][2][1]
    assert p.stack[1][2][2] == "Test", p.stack[1][2][2]
    assert p.stack[1][2][3] == [], p.stack[1][2][3]


if __name__ == "__main__":
    import sys

# Generated at 2022-06-11 19:51:46.819545
# Unit test for method push of class Parser
def test_Parser_push():
    from . import driver, grammar
    from .token import NAME
    gram = grammar.parse_grammar(driver.grammar)
    p = Parser(gram)
    p.setup()
    p.addtoken(NAME, "def", Context(1, 0))
    p.addtoken(NAME, "f", Context(1, 0))
    p.addtoken(token.LPAR, "(", Context(1, 0))
    p.addtoken(token.RPAR, ")", Context(1, 0))
    p.addtoken(token.COLON, ":", Context(1, 0))

# Generated at 2022-06-11 19:51:57.800973
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    # Test that the parser does not recurse infinitely when a reduce is
    # possible, but no shift is possible, because there is no nonterminal
    # with a first token.

    from . import driver, token

    g = driver.load_grammar("Grammar/Grammar")

    # Parse a simple grammar
    t = [
        (token.LBRACE, (1, 0), (1, 1)),
        (token.NAME, "a", (2, 3)),
        (token.RBRACE, (2, 4), (2, 5)),
        (token.ENDMARKER, None, None),
    ]

    p = Parser(g)
    p.setup()


# Generated at 2022-06-11 19:52:07.509240
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = Grammar()
    grammar.tokens = {1:1}
    parser = Parser(grammar)
    parser.setup(1)
    parser.shift(1, 'name', 1, None)
    assert parser.rootnode.type == 1
    assert parser.rootnode.value == 'name'
    parser.setup(1)
    parser.shift(1, 'name', 1, None)
    assert parser.rootnode.type == 1
    assert parser.rootnode.value == 'name'
    parser.shift(1, 'name', 1, None)
    assert parser.rootnode.type == 1
    assert parser.rootnode.value == 'name'
    assert parser.rootnode.children[0].type == 1
    assert parser.rootnode.children[0].value == 'name'
    parser.shift

# Generated at 2022-06-11 19:53:12.714331
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pgen2.tokenize import detect_encoding, tokenize

    g = Grammar()
    p = Parser(g)
    # Set up the parser
    p.setup()
    # Test the parser on one expression
    text = b"1 + 2"
    encoding, lines = detect_encoding(text.splitlines(keepends=True))
    gen = tokenize(text.splitlines(keepends=True))
    for t in gen:
        if p.addtoken(t.type, t.string, Context(t.start, t.end, lines)):
            break

# Generated at 2022-06-11 19:53:17.323185
# Unit test for method setup of class Parser
def test_Parser_setup():
    import pgen2.grammar
    from pgen2.pgen import Parser
    grammar = pgen2.grammar.Grammar()
    parser = Parser(grammar)
    parser.setup()

# Generated at 2022-06-11 19:53:29.302584
# Unit test for method shift of class Parser
def test_Parser_shift():
    from .parser import Parser
    from .tokenize import generate_tokens
    from .token import INDENT, DEDENT, ERRORTOKEN, NAME, NUMBER
    from .pgen2 import tokenize

    p = Parser(tokenize.grammar)
    p.setup()
    for x in generate_tokens(iter(['if', 'a', ':'])):
        p.addtoken(x[0], x[1], x[2])

# Generated at 2022-06-11 19:53:40.475890
# Unit test for method shift of class Parser
def test_Parser_shift():
    import io
    import sys
    import unittest

    from blib2to3.pgen2 import driver, tokenize

    from . import grammar

    class Test(unittest.TestCase):
        def test_shift(self):
            filename = grammar.__file__
            if filename.endswith(".pyc"):
                filename = filename[:-1]

            # -1 is the (undocumented) way to read the whole file.
            # See tokenize.c.
            tokens = tokenize.generate_tokens(io.open(filename, "rb").readline)
            # Make sure its a generator
            readline = tokens.__next__
            tokens = list(tokens)
            # Just to be on the safe side.

# Generated at 2022-06-11 19:53:52.355420
# Unit test for method classify of class Parser
def test_Parser_classify():
    # For each test case, the token number and token value for a token
    # are passed as arguments to the classify method.  The expected
    # result for that call is the return value of the classify method.

    # Set up the data for testing
    grammar = Grammar()
    grammar.start = 100
    grammar.tokens = {1: 1, 2: 2}
    grammar.keywords = {'as': 3}

# Generated at 2022-06-11 19:54:02.185151
# Unit test for method push of class Parser
def test_Parser_push():
    from . import pgen

    def test_pgen(g: Grammar, type: int, value: Optional[Text], context: Context) -> None:
        p = Parser(g)
        p.setup()
        p.addtoken(type, value, context)

    gramfile = "Grammar.txt"
    with open(gramfile, "r", encoding="ascii") as f:
        string = f.read()
    g = pgen.pgen(string, gramfile)
    test_pgen(g, token.NUMBER, "5", Context(5, "hi"))

# Generated at 2022-06-11 19:54:04.949626
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2.driver import Driver
    driver = Driver()
    grammar = driver.load_grammar()
    parser = Parser(grammar)
    parser.setup()


# Generated at 2022-06-11 19:54:16.294023
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class PyTreeGrammar(Grammar):
        def __init__(
            self,
            start: Text,
            labels: Sequence[Tuple[int, Optional[Union[Text, int]]]],
            tokens: Dict[int, int],
            keywords: Dict[Text, int],
            dfas: Dict[int, DFAS],
        ) -> None:
            Grammar.__init__(self, start, labels, tokens, keywords, dfas)
            self.converters = {}
        def add_dfa(self, name: Text, dfa: DFA) -> None:
            for state in dfa:
                for index, (tok, newstate) in enumerate(state):
                    if not tok:
                        newstate = 0
                    state[index] = (tok, newstate)


# Generated at 2022-06-11 19:54:16.806201
# Unit test for method pop of class Parser
def test_Parser_pop():
    pass

# Generated at 2022-06-11 19:54:24.866257
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar

    g = grammar.Grammar()
    p = Parser(g)
    p.setup()
    for token, value in [("a", 1), ("b", 2), ("c", 3)]:
        assert not p.addtoken("a", value, None)
    assert p.addtoken("a", 4, None)
    assert not p.addtoken("a", 1, None)
    assert not p.addtoken("b", 2, None)
    assert not p.addtoken("c", 3, None)
    assert p.addtoken("a", 4, None)


# This demonstrates how to use the parser

# Generated at 2022-06-11 19:55:21.408304
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.pgen2.parse

    # This test is the same in Python 2.7 and 3.7 and uses the same test grammar
    # (Python3.7's grammar.txt). However, the Python3.7 grammar does not
    # produce the same results for `print "a"` as the Python 2.7 grammar does
    # and will probably need to be changed.
    import io
    import sys
    import tokenize
    from token import OP

    from . import driver
    from . import parse

    driver.setup_grammar()
    parse.ParserError
    parse.ParseError
    Parser = parse.Parser
    tokenize.NL
    tokenize.TokenInfo
    a = tokenize.NL
    a.type
    a.string
    a.start
    a.end
    a.line

# Generated at 2022-06-11 19:55:29.086733
# Unit test for method classify of class Parser
def test_Parser_classify():
    import blib2to3.pgen2.pgen as pgen
    from StringIO import StringIO

    # Parse a simple grammar
    f = StringIO(
        """
    start: NAME
    """
    )
    g = pgen.generate_grammar(f)

    # Test the classify method
    p = Parser(g)
    ilabel = p.classify(token.NAME, "name", None)
    assert ilabel == g.labels.index(("start", None))
    ilabel = p.classify(token.NAME, "break", None)
    assert ilabel is None
    ilabel = p.classify(token.LPAR, None, None)
    assert ilabel is None

# Generated at 2022-06-11 19:55:34.320159
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar()
    grammar.dfas = {'single_input': ([[(2, 1), (0, 1)], [(0, 1), (2, 0)], [(0, 0)]], {1: 0}), 'file_input': ([[(2, 1), (0, 1)], [(0, 1), (2, 0)], [(0, 0)]], {1: 0})}
    grammar.labels = [(0, 1), (token.ENDMARKER, token.ENDMARKER)]
    p = Parser(grammar)
    p.setup()
    p.addtoken(token.ENDMARKER, None, None)
    p.pop()

# Generated at 2022-06-11 19:55:46.079353
# Unit test for method pop of class Parser
def test_Parser_pop():
    class MockGrammar(object):
        def __init__(self):
            self.start = 1
            self.dfas = {1: ([[(1, 1), (3, 5)], [(0, 2)]], {1: 0}), 2: ([[(2, 3)]], {2: 0})}
            self.labels = [(1, None), (2, None)]

    p = Parser(MockGrammar())
    p.setup()
    p.stack = [(p.grammar.dfas[1], 0, (1, None, None, [])),
               (p.grammar.dfas[2], 0, (2, None, None, []))]
    node = (1, None, None, [])
    p.convert = lambda g, n: node
    p.pop()
