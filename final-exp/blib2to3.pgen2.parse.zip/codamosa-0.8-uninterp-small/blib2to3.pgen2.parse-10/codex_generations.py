

# Generated at 2022-06-25 14:48:15.573064
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    str_0 = 'x#y'
    parser_0 = Parser(grammar_0, str_0)
    parser_0.pop()


# Generated at 2022-06-25 14:48:26.705202
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    parser_0.setup(10.16845)
    grammar_1 = module_0.Grammar()
    str_1 = ':&g1o v4q'
    parser_1 = Parser(grammar_1, str_1)
    parser_1.setup(10.16845)
    grammar_2 = module_0.Grammar()
    str_2 = ':&g1o v4q'
    parser_2 = Parser(grammar_2, str_2)
    parser_2.setup(10.16845)
    grammar_3 = module_0.Grammar()
    str

# Generated at 2022-06-25 14:48:36.556350
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    converter_0 = module_0.converter
    type_0 = 7
    value_0 = 'w  '
    newstate_0 = 8
    context_0 = ';1%,D'
    parser_0 = Parser(grammar_0, converter_0)
    parser_0.stack = [[[], 0, []]]
    parser_0.shift(type_0, value_0, newstate_0, context_0)
    assert parser_0.stack == [[[], 8, [7, 'w  ', ';1%,D', None]]]
    assert parser_0.rootnode is None


# Generated at 2022-06-25 14:48:37.480131
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    raise Exception('Test not implemented!')


# Generated at 2022-06-25 14:48:43.337304
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    int_0 = -1
    str_1 = '-1'
    context_0 = tuple()
    assert parser_0.addtoken(int_0, str_1, context_0)


# Generated at 2022-06-25 14:48:52.511355
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = blib2to3.pgen2.grammar.Grammar()
    parser_0 = Parser(grammar_0)
    newdfa_0 = [(0, 2)]
    newstate_0 = 2
    context_0 = Context(('', (0, 1)))
    parser_0.push(256, newdfa_0, newstate_0, context_0)
    newdfa_1 = [(0, 2)]
    newstate_1 = 2
    context_1 = Context(('', (0, 1)))
    parser_0.push(256, newdfa_1, newstate_1, context_1)
    newdfa_2 = [(0, 2)]
    newstate_2 = 2
    context_2 = Context(('', (0, 1)))
    parser_0

# Generated at 2022-06-25 14:48:53.269914
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    pass


# Generated at 2022-06-25 14:48:56.487571
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    int_0 = 0
    int_1 = 0
    assert parser_0.addtoken(int_0, int_0, int_1) == False, "addtoken did not return False"


# Generated at 2022-06-25 14:49:00.771774
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    int_0 = 0
    int_1 = 0
    parser_0 = Parser(grammar_0, str_0)
    parser_0.push(int_0, int_1)


# Generated at 2022-06-25 14:49:06.215639
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    str_0 = '0%2 _94a'
    parser_0 = Parser(grammar_0, str_0)
    type_0 = token.IMPORT
    value_0 = '0%2 _94a'
    context_0 = Context.from_token(token.IMPORT, '0%2 _94a', 0, 0)
    newstate_0 = 0
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:49:14.874454
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar
    grammar_0 = Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:49:21.116810
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    int_0 = parser_0.setup()
    str_1 = 'sd \t'
    int_1 = parser_0.addtoken(int_0, int_0, str_1)
    int_2 = parser_0.push(str_1, int_0, str_0, int_0)

# Generated at 2022-06-25 14:49:27.184393
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    int_0 = 65
    str_1 = '$'
    tuple_0 = (1, 1)
    class_0 = ParseError
    with pytest.raises(class_0):
        parser_0.classify(int_0, str_1, tuple_0)


# Generated at 2022-06-25 14:49:31.584358
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = Grammar()
    parser_1 = Parser(grammar_1)
    int_0 = 0
    (
        int_1,
        int_2,
    ) = parser_1.addtoken(int_0)
    assert ((str(int_1), str(int_2)) == ('None', 'None'))


# Generated at 2022-06-25 14:49:35.369313
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    parser_0.setup(str_0)


# Generated at 2022-06-25 14:49:44.610847
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    test_ParseError_0 = ParseError('bad input', 5, '1', {'1':'4q'})
    try:
        parser_0.addtoken(5, '', {'1':'4q'})
    except ParseError as e:
        test_ParseError_1 = e
    test_bool_0 = id(test_ParseError_0) == id(test_ParseError_1)
    assert test_bool_0


# Generated at 2022-06-25 14:49:51.562263
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    str_1 = '28t>vu;4p4;4p4;4p4;4p4'
    int_0 = 0
    context_0 = Context(int_0)
    str_2 = None
    bool_0 = True
    while bool_0:
        bool_0 = parser_0.addtoken(str_1, str_2, context_0)


# Generated at 2022-06-25 14:49:54.703675
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = blib2to3.pgen2.grammar.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(0, None, None)


# Generated at 2022-06-25 14:49:58.827748
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    # Test: pop a nonterminal 

    # Unit test for method push of class Parser

# Generated at 2022-06-25 14:50:03.108533
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar()
    stack_entry = (grammar.dfas[0], 0, None)
    stack = [stack_entry]
    parser = Parser(grammar, None)
    parser.stack = stack
    parser.pop()
    return


# Generated at 2022-06-25 14:50:23.433650
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    grammar_0.name_1 = 'g1o'
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    parser_0.name_1 = 'g1o'
    str_1 = ':&g1o v4q'
    int_0 = 0
    int_1 = token.NAME
    value_0 = ':&g1o v4q'
    context_0 = ':&g1o v4q'
    bool_0 = parser_0.addtoken(int_0, value_0, context_0)
    def test_case_1():
        grammar_0.name_1 = 'g1o'

# Generated at 2022-06-25 14:50:26.274265
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    parser_0.pop()


# Generated at 2022-06-25 14:50:29.327491
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.shift(int_0, str_0_0, int_0, context_0)


# Generated at 2022-06-25 14:50:31.651899
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    parser_0.pop()


# Generated at 2022-06-25 14:50:33.777339
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    parser_0.pop()


# Generated at 2022-06-25 14:50:36.226617
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = module_0.Grammar()
    str = ':&g1o v4q'
    parser = Parser(grammar, str)
    parser.shift(
        type = token.NAME,
        value = 'test',
        newstate = 13,
        context = leaf(1, 2, "test"),
    )


# Generated at 2022-06-25 14:50:40.926072
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    str_1 = ':&g1o v4q'
    parser_1 = Parser(grammar_1, str_1)
    type_1 = parser_1.addtoken(grammar_1, str_1)


# Generated at 2022-06-25 14:50:48.068982
# Unit test for method push of class Parser
def test_Parser_push():
  parser_0 = Parser(Parser.grammar, Parser.convert)
  parser_0.push(int(Parser.grammar), Parser.grammar.dfas[int(Parser.grammar)], Parser.grammar.labels[int(Parser.grammar)], Parser.grammar.start)
  parser_0.push(int(Parser.grammar), Parser.grammar.dfas[int(Parser.grammar)], Parser.grammar.labels[int(Parser.grammar)], Parser.grammar.start)


# Generated at 2022-06-25 14:50:55.339163
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    int_0 = 2
    str_1 = '9Y5_'
    class_0 = DummyClass()
    class_0.val = 251
    class_0.attr = 'm9~nV'
    class_0.fld_1 = '%8W7,|'
    class_0.mthd_1 = ',&$A,|'
    class_0.fld_2 = 'xhF6z'
    class_0.mthd_2 = 'aZdD6'
    class_0.attr_1 = '}02s'
    int_1 = parser_0

# Generated at 2022-06-25 14:51:03.464885
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import sys
    import StringIO

    old_stdout = sys.stdout
    sys.stdout = StringIO.StringIO()
    try:
        grammar_0 = module_0.Grammar()
        str_1 = ':&g1o v4q'
        parser_1 = Parser(grammar_0, str_1)
        int_0 = 1
        str_2 = 'a'
        int_1 = 1
        parser_1.addtoken(int_0, str_2, int_1)
        assert (sys.stdout.getvalue() == '')
    finally:
        sys.stdout = old_stdout


# Generated at 2022-06-25 14:51:25.944866
# Unit test for method pop of class Parser
def test_Parser_pop():
    # No check
    pass


# Generated at 2022-06-25 14:51:31.647035
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Test for method shift of class Parser"""
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    parser_0.shift(token.NAME, ':&g1o', token.NEWLINE, 0)


# Generated at 2022-06-25 14:51:33.506272
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 123
    value_0 = '3>Z,aL-bo|tR@'
    context_0 = Context()
    parser_0.classify(type_0, value_0, context_0)


# Generated at 2022-06-25 14:51:37.079620
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    str_1 = 'A'
    parser_1 = Parser(grammar_1, str_1)
    parser_1.setup()
    parser_1.addtoken(1, 'A', None)
    parser_1.addtoken(2, 'B', None)


# Generated at 2022-06-25 14:51:46.588377
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    parser_1 = Parser(grammar_0, str_0)
    parser_2 = Parser(grammar_0, str_0)
    parser_3 = Parser(grammar_0, str_0)
    parser_3.setup(':&r9e 3a2')
    parser_3.addtoken(':&r9e 3a2', ':&r9e 3a2', ':&r9e 3a2')
    parser_3.addtoken(':&r9e 3a2', ':&r9e 3a2', ':&r9e 3a2')
    parser_2

# Generated at 2022-06-25 14:51:53.536731
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = module_0.Grammar()
    str = ':&g1o v4q'
    parser = Parser(grammar, str)
    newstate = 0
    context = object()
    rawnode = (0, 0, 0, None)
    def lam_sub_1(grammar, node):
        pass
    assert parser.shift(0, None, newstate, context) == lam_sub_1(grammar, rawnode)

# Generated at 2022-06-25 14:51:56.419427
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    parser = Parser(blib2to3.pgen2.grammar.Grammar())
    result = parser.addtoken(str(), str(), str())
    assert result is None


# Generated at 2022-06-25 14:52:01.908505
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    node_0 = '4E-B[c('
    state_0 = 15
    context_0 = ':&g1o v4q'
    parser_0.push(node_0, state_0, context_0)


# Generated at 2022-06-25 14:52:07.734484
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NUMBER, '3', None)
    parser.addtoken(token.NEWLINE, None, None)
    parser.addtoken(token.NUMBER, '7', None)
    parser.pop()
    parser.pop()
    parser.pop()
    parser.pop()
    parser.pop()
    parser.pop()


# Generated at 2022-06-25 14:52:14.083941
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)

    name_0 = grammar_0.keywords
    assert name_0 is not None
    name_0 = name_0['for']
    type_0 = name_0
    assert type_0 is not None
    name_0 = parser_0.addtoken(type_0, 'for', str_0)
    assert name_0 is not None
    name_0 = parser_0.addtoken(type_0, 'for', str_0)
    assert name_0 is not None
    name_0 = parser_0.addtoken(type_0, 'for', str_0)
    assert name_0 is not None
   

# Generated at 2022-06-25 14:52:46.723121
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    parser_0.setup()
    parser_0.pop()


# Generated at 2022-06-25 14:52:51.687867
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    test_0 = ()
    int_0 = 0
    newstate_0 = 0
    context_0 = ''
    parser_0.push(test_0, int_0, newstate_0, context_0)


# Generated at 2022-06-25 14:53:00.341673
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.addtoken(1, 'F3q', Context(0,0)) == False
    assert parser_0.addtoken(0, 'jv9', Context(0,1)) == False
    assert parser_0.addtoken(0, 'O7z', Context(1,0)) == False
    assert parser_0.addtoken(0, 'A7g', Context(0,2)) == False
    assert parser_0.addtoken(0, 'D8t', Context(1,1)) == True
    assert parser_0.addtoken(0, 'P4b', Context(0,1)) == True

# Generated at 2022-06-25 14:53:01.918649
# Unit test for method pop of class Parser
def test_Parser_pop():
    from test.test_support import run_unittest
    run_unittest(test_case_0)

# Generated at 2022-06-25 14:53:04.816286
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    s_0 = 't'
    parser_0 = Parser(grammar_0, s_0)
    parser_0.setup()


# Generated at 2022-06-25 14:53:08.887041
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    str_1 = 'j4xki'
    str_2 = ':&g1o v4q'
    str_3 = 'j4xki'
    int_0 = parser_0.classify(str_1, str_2, str_3)


# Generated at 2022-06-25 14:53:10.873091
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    parser_0.pop()



# Generated at 2022-06-25 14:53:14.345957
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    parser_0.setup()
    # Test method push of class Parser
    result_0 = parser_0.push(0, 0, 0, 0)
    assert result_0 is None

# Generated at 2022-06-25 14:53:15.649208
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:53:17.842694
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    str_0 = '8bw`&'
    parser_0 = Parser(grammar_0, str_0)
    parser_0.pop()


# Generated at 2022-06-25 14:54:30.392081
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)

    assert parser_0.classify(202, '*', 'V%#') == 328
    assert parser_0.classify(343, '^', ';4b') == 112
    assert parser_0.classify(444, 'U', '6q3') == 658
    assert parser_0.classify(52, 'y', '0/D') == 498
    assert parser_0.classify(808, 'N', 'N]~') == 8


# Generated at 2022-06-25 14:54:36.239533
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    int_0 = 69
    int_1 = 20
    bool_0 = bool(int_0)
    bool_1 = bool(int_1)
    bool_2 = bool(grammar_0)
    bool_3 = bool(bool_2)
    parser_0 = Parser(grammar_0, bool_2)
    parser_0.pop()


# Generated at 2022-06-25 14:54:43.704349
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    int_0 = 1
    dict_0 = {}
    dict_0 = {int_0: dict_0}
    int_1 = 1
    int_2 = 1
    tuple_0 = (int_1, int_2)
    int_3 = 0
    tuple_1 = (int_3, tuple_0)
    list_0 = [tuple_1]
    str_1 = ':&g1o v4q'
    tuple_2 = (list_0, dict_0, list_0, str_1)

# Generated at 2022-06-25 14:54:46.064771
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    start_0 = 2
    parser_0.setup(start_0)



# Generated at 2022-06-25 14:54:49.088462
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser_0 = Parser(None, None)
    str_0 = 'y'
    context_0 = Context()
    parser_0.shift(0, str_0, 0, context_0)


# Generated at 2022-06-25 14:54:56.815497
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    int_0 = 256
    str_1 = 'f k'
    any_2 = None
    context_0 = Context()
    int_1 = parser_0.classify(int_0, str_1, any_2)
    assert int_1 == 0


if __name__ == "__main__":
    test_case_0()
    test_Parser_classify()

# Generated at 2022-06-25 14:54:59.960407
# Unit test for method setup of class Parser
def test_Parser_setup():
    from blib2to3.pgen2.token import Token
    str_0 = '7G|f\x03V'
    parser_0 = Parser(str_0)
    parser_0.setup()


# Generated at 2022-06-25 14:55:04.539162
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)
    int_0 = 1
    str_1 = '4'
    context_0 = Context(int_0, int_0)
    bool_0 = parser_0.addtoken(int_0, str_1, context_0)


# Generated at 2022-06-25 14:55:05.215293
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    pass



# Generated at 2022-06-25 14:55:13.019186
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    str_0 = ':&g1o v4q'
    parser_0 = Parser(grammar_0, str_0)

    token_0 = parser_0.shift(0, '1', 2)

    assert parser_0 is not None
    assert grammar_0 is not None
    assert str_0 is not None
    assert token_0 is not None
