

# Generated at 2022-06-25 14:48:09.595727
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(start=None)
    parser_0.addtoken(type=1, value='1', context=None)

# Generated at 2022-06-25 14:48:19.148509
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = blib2to3.pgen2.grammar.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert parser_0.stack == [(grammar_0.dfas[1], 0, (1, None, None, [])),]
    assert parser_0.rootnode is None
    assert parser_0.used_names == set()
    parser_0.push(None, None, None, None)
    assert parser_0.stack[-1][2][3] == []


# Generated at 2022-06-25 14:48:23.479733
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    def test_func0(arg0, arg1):
        return arg0
    def test_func1(arg0, arg1):
        return arg0
    def test_func2(arg0, arg1):
        return arg0
    test_func2("", "")
    parser_0.addtoken("", "", Context())
    assert False


# Generated at 2022-06-25 14:48:26.755981
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.test_addtoken(None, None, None)


# Generated at 2022-06-25 14:48:34.946630
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    # assert <ConditionalExpressionNode(test=<FalseNode>, body=<ReturnNode(test=<Name(id='False')>), else_body=<FalseNode>)> == parser_0.rootnode

# Generated at 2022-06-25 14:48:38.183086
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(0, None, 0, None)


# Generated at 2022-06-25 14:48:43.738827
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 1
    value_0 = ""
    newstate_0 = 8
    context_0 = Context(previous_context=None, filename="", tokens=None)
    parser_0.shift(type_0,value_0,newstate_0,context_0)


# Generated at 2022-06-25 14:48:46.465773
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:48:52.008470
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    # Call method on an instance of the class
    grammar_1 = blib2to3.pgen2.grammar.Grammar()
    parser_1 = Parser(grammar_1)

    try:
        parser_1.addtoken(
            token.NEWLINE, token.NEWLINE, blib2to3.pytree.Context(0, 0)
        )
    except ParseError:
        pass
    else:
        raise Exception("Expected exception not raised")


# Generated at 2022-06-25 14:48:53.914630
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_case_0(parser_0)


# Generated at 2022-06-25 14:49:07.409614
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import token

    grammar_0 = grammar.Grammar()
    parser_0 = Parser(grammar_0)
    noop_0 = parser_0.pop()


# Generated at 2022-06-25 14:49:14.012965
# Unit test for method shift of class Parser
def test_Parser_shift():

    # Create a Parser instance
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    
    
    # Get Parser.stack
    stack_0 = parser_0.stack
    
    # Assign a tuple to the Parser.stack
    stack = (dfa, state, node)
    
    stack_0 = stack
    assert stack == (dfa, state, node)


# Generated at 2022-06-25 14:49:16.641293
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(0, 1, 2, 3)

# Generated at 2022-06-25 14:49:23.063052
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_method_name = 'Parser.addtoken'
    try:
        grammar_0 = module_0.Grammar()
        parser_0 = Parser(grammar_0)
        try:
            parser_0.addtoken()
        except AssertionError:
            pass
        else:
            raise AssertionError('%s: AssertionError not raised' % test_method_name)
    except AssertionError:
        print('%s: AssertionError raised' % test_method_name)


# Generated at 2022-06-25 14:49:24.525657
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)


# Generated at 2022-06-25 14:49:29.491286
# Unit test for method push of class Parser
def test_Parser_push():
    test_case_0()
    """
    Method push is a private member of class Parser.  It is defined on line 54 of the file blib2to3/pgen2/parse.py.
    
    It is tested by test case 0 of test file blib2to3/pgen2/test_parse.py.
    
    """
    pass


# Generated at 2022-06-25 14:49:32.614736
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(0, 0, 0)


# Generated at 2022-06-25 14:49:35.826536
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(4, '4', 2, '2')


# Generated at 2022-06-25 14:49:44.082736
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    converter_0 = None
    parser_0.convert(grammar_0, converter_0)
    converter_1 = None
    parser_0.convert(grammar_0, converter_1)
    converter_2 = None
    parser_0.convert(grammar_0, converter_2)
    context_0 = Context()
    # Invoke method
    parser_0.addtoken(type=None, value=None, context=context_0)
    # Assertions
    assert True


# Generated at 2022-06-25 14:49:45.673935
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = []
    parser_0.shift(0, None, 0, None)


# Generated at 2022-06-25 14:50:06.337381
# Unit test for method pop of class Parser
def test_Parser_pop():
    from typing import Callable
    from blib2to3.pygram import python_symbols as symbols
    from blib2to3.pgen2.token import Token
    from blib2to3.pgen2.grammar import (
        Grammar, DFA, State, Arc, Label, Nonterminal, Terminals
    )

    # Grammar definition

# Generated at 2022-06-25 14:50:09.752286
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = Parser(module_0.Grammar())
    try:
        parser_0.pop()
    except IndexError:
        pass
    else:
        raise RuntimeError


# Generated at 2022-06-25 14:50:11.458848
# Unit test for method pop of class Parser
def test_Parser_pop():
    # ARRANGE
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

# Generated at 2022-06-25 14:50:15.099238
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = module_0.Grammar()
    parser = Parser(grammar)

    assert parser.stack == []
    parser.stack = [1]
    parser.pop()
    assert parser.stack == []

# Generated at 2022-06-25 14:50:18.584710
# Unit test for method pop of class Parser
def test_Parser_pop():
    popdfa, popstate, popnode = None, None, None
    parser_0 = Parser(None)
    parser_0.stack = [(popdfa, popstate, popnode)]
    parser_0.pop()


# Generated at 2022-06-25 14:50:21.963470
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = Parser(Grammar())
    stack_0 = [1,2,3]
    parser_0.stack = stack_0
    parser_0.pop()
    assert parser_0.stack == [1,2]


# Generated at 2022-06-25 14:50:25.011586
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    type = 0
    value = ""
    context = Context()
    parser.addtoken(type, value, context)


# Generated at 2022-06-25 14:50:28.098661
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    ilabel_0 = parser_0.classify(256, (None, ''), '')

    assert ilabel_0 == 0


# Generated at 2022-06-25 14:50:28.915900
# Unit test for method classify of class Parser
def test_Parser_classify():
    test_case_0()


# Generated at 2022-06-25 14:50:35.237322
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.tokenize as module_1
    from io import StringIO
    file_0 = StringIO('# comment\nfrom\n')
    gen_0 = module_1.generate_tokens(file_0.readline)
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    l_tuple_0 = next(gen_0)
    type_0 = l_tuple_0[0]
    value_0 = l_tuple_0[1]
    context_0 = l_tuple_0[2]
    l_bool_0 = parser_0.addtoken(type_0, value_0, context_0)

# Generated at 2022-06-25 14:50:47.199454
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0
    assert parser_0.pop() == None


# Generated at 2022-06-25 14:50:48.630478
# Unit test for method setup of class Parser
def test_Parser_setup():
    test_case_0()
    assert 1 == 0


# Generated at 2022-06-25 14:50:57.759322
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()
    assert parser_0.rootnode is None, "Expected parser_0.rootnode to be None, got %r" % parser_0.rootnode
    assert parser_0.grammar is grammar_0, "Expected parser_0.grammar to be grammar_0, got %r" % parser_0.grammar
    assert parser_0.stack == [], "Expected parser_0.stack to be [], got %r" % parser_0.stack
    


# Generated at 2022-06-25 14:51:01.326798
# Unit test for method push of class Parser
def test_Parser_push():

    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    parser_0.setup()
    parser_0.addtoken(3, "(", None)
    parser_0.addtoken(5, "*", None)
    parser_0.addtoken(4, ")", None)
    parser_0.addtoken(0, "EOF", None)
    # Unit test for method push of class Parser
    parser_0.push(1, (1, 2), 0, 0)


# Generated at 2022-06-25 14:51:05.248081
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    grammar_1 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_1 = Parser(grammar_1)
    parser_1.push(int(), (list(), int()), int(), Context())


# Generated at 2022-06-25 14:51:15.690085
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    # Test case 1:
    try:
        parser_0.addtoken(4, 'x', NL(4))
    except ParseError:
        pass

    # Test case 2:
    try:
        parser_0.addtoken(1, 'x', None)
    except ParseError:
        pass

    # Test case 3:
    try:
        parser_0.addtoken(1, None, None)
    except ParseError:
        pass

    # Test case 4:
    try:
        parser_0.addtoken(1, None, NL(1))
    except ParseError:
        pass

    # Test case 5:

# Generated at 2022-06-25 14:51:17.053324
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:51:17.872597
# Unit test for method shift of class Parser
def test_Parser_shift():
    pass



# Generated at 2022-06-25 14:51:21.177584
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    rawnode_0 = None
    parser_0.shift(token.NAME, "fe", 1, rawnode_0)


# Generated at 2022-06-25 14:51:24.068143
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    parser_1.addtoken(1, None, None)

# Generated at 2022-06-25 14:51:45.028298
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:51:53.028991
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(1)
    # Test case: parser_0.addtoken[int, int, None](1, 1, None)
    # Test case: parser_0.addtoken[int, int, None](1, 1, None)
    # Test case: parser_0.addtoken[int, int, None](1, 1, None)
    # Test case: parser_0.addtoken[int, int, None](1, 1, None)


# Generated at 2022-06-25 14:51:59.776559
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Test for function shift of class Parser.
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup() # private
    parser_0.shift(1, '', 0)
    parser_0.shift(1, '', 0)
    parser_0.shift(1, '', 0)
    parser_0.shift(1, '', 0)
    parser_0.shift(1, '', 0)
    assert parser_0.stack == [(([([(1, 0), (1, 0)], set()), ([(1, 0), (1, 0)], set())], {}), 0, (1, None, None, []))]


# Generated at 2022-06-25 14:52:06.322489
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type = 2
    value = None
    newstate = 2
    context = (0, 0)
    parser_0.stack = [(grammar_0.dfas[1], 0, (1, None, None, []))]
    parser_0.shift(type, value, newstate, context)
    assert parser_0.stack[0][1] == 2


# Generated at 2022-06-25 14:52:09.176784
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    token_0 = token.token()
    context_0 = Context()
    parser_1.shift(token_0, None, 0, context_0)


# Generated at 2022-06-25 14:52:18.442159
# Unit test for method push of class Parser
def test_Parser_push():
    parser_0 = Parser(module_0.Grammar())
    parser_0.setup()
    assert parser_0.stack == [(0, 0, (1, None, None, []))]
    parser_0.push(2, 0, 1, 0)
    assert parser_0.stack == [(0, 0, (1, None, None, [])), (0, 1, (2, None, 0, []))]
    parser_0.push(3, 0, 2, 0)
    assert parser_0.stack == [(0, 0, (1, None, None, [])), (0, 1, (2, None, 0, [])), (0, 2, (3, None, 0, []))]


# Generated at 2022-06-25 14:52:23.640728
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 1
    newdfa_0 = None
    newstate_0 = 1
    context_0 = None
    try:
        parser_0.push(type_0, newdfa_0, newstate_0, context_0)
    except TypeError:
        pass

# Generated at 2022-06-25 14:52:32.106394
# Unit test for method shift of class Parser
def test_Parser_shift():
    # NOTE: This is a simple unit test
    # To test this method of the class you need to verify that the
    # following conditions are satisfied:
    # - The method shift of an object of class Parser has been called
    # - The method shift must return None
    # - The method shift must not throw any exceptions

    # NOTE:
    # This unit test has been created by a tool
    # For more information about this tool, visit
    #   http://www.open.com.au/open/bin/view/Main/UtestQueryTool
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)

# Generated at 2022-06-25 14:52:34.854553
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Call Parser.setup with the positional arguments 'start'
    parser_0.setup()


# Generated at 2022-06-25 14:52:36.633661
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Test for arm (1) of if statement
    assert True

    # Test for arm (2) of if statement
    assert True


# Generated at 2022-06-25 14:53:18.406327
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Empty method test
    assert True


# Generated at 2022-06-25 14:53:21.401385
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    try:
        parser_0.addtoken(0, None, None)
        assert False
    except ParseError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 14:53:24.852582
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    popdfa = None
    popstate = None
    popnode = None
    parser_0.stack.append((popdfa, popstate, popnode))
    parser_0.pop()


# Generated at 2022-06-25 14:53:28.444653
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = grammar_0.start
    newdfa_0 = None
    newstate_0 = 0
    parser_0.push(type_0, newdfa_0, newstate_0, None)


# Generated at 2022-06-25 14:53:32.439218
# Unit test for method shift of class Parser
def test_Parser_shift():
  # Setup Parser
  grammar_0 = module_0.Grammar()
  parser_0 = Parser(grammar_0)

  # Unit test Method shift
  parser_0.shift(token.NAME, 'test_value', 1, 'test_value')


# Generated at 2022-06-25 14:53:38.851052
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = [(([[(0, 11)]], {0: 11}), 0, None)]
    parser_0.push(0, parser_0.grammar.dfas[0], 0, None)
    assert parser_0.stack == [(([[(0, 11)]], {0: 11}), 0, None), (([[(0, 11)]], {0: 11}), 0, ([0, None, None, []]))]


# Generated at 2022-06-25 14:53:46.977501
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    popnode_1 = (('IDENTIFIER', None, ('1.8', '4'), []))
    popstate_1 = 0
    popdfa_1 = ({0: [(0, 1), (4, 2)], 1: [(0, 1)], 2: [(0, 1)], 3: [(0, 2)], 4: [(0, 2)]}, 5)
    parser_1.stack.append((popdfa_1, popstate_1, popnode_1))
    parser_1.stack.append((popdfa_1, popstate_1, popnode_1))
    parser_1.pop()

# Generated at 2022-06-25 14:53:51.586688
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    token = 0
    value = 'value'
    context = Context('filename', 1, 1)

    def test_suite_0():
        try:
            parser.addtoken(token, value, context)
        except ParseError:
            pass

    def test_suite_1():
        parser.setup()
        parser.addtoken(token, value, context)


# Generated at 2022-06-25 14:53:56.878872
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack.append((parser_0.grammar.dfas[parser_0.grammar.start], 0, (None, None, None, [])))
    parser_0.stack.append((parser_0.grammar.dfas[parser_0.grammar.start], 0, (None, None, None, [])))
    parser_0.pop()


# Generated at 2022-06-25 14:53:59.988121
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:54:57.143616
# Unit test for method pop of class Parser
def test_Parser_pop():
    obj_0 = Parser(Grammar(), None)
    obj_0.pop()


# Generated at 2022-06-25 14:54:59.075581
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()

# Generated at 2022-06-25 14:55:03.035279
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

# Generated at 2022-06-25 14:55:05.035371
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(0, '', None)

# Generated at 2022-06-25 14:55:08.398217
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.pop()


# Generated at 2022-06-25 14:55:12.894435
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    try:
        parser_0.pop()
    except AssertionError:
        pass


# Generated at 2022-06-25 14:55:15.052461
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.pop()
    parser.pop()
    parser.pop()


# Generated at 2022-06-25 14:55:23.866830
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = [(parser_0.grammar.dfas[1], 0, (1, None, None, [])), (parser_0.grammar.dfas[257], 0, (257, None, None, [])), (parser_0.grammar.dfas[258], 0, (258, None, None, [])), (parser_0.grammar.dfas[259], 0, (259, None, None, [])), (parser_0.grammar.dfas[260], 0, (260, None, None, []))]
    parser_0.addtoken(0, '', Context())


# Generated at 2022-06-25 14:55:28.317015
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    parser_1.addtoken(token.ENDMARKER, None, Context(None, None))
    parser_1.pop()


# Generated at 2022-06-25 14:55:32.364057
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert parser_0.classify(0, None, Context(None, 1)) == 0


# Generated at 2022-06-25 14:57:25.802885
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Test case for method classify of class Parser

    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    parser_1.addtoken(1, 'def', (1, 0))
    parser_1.addtoken(1, 'abc', (0, 1))
    # <create parser>
    # <addtoken>
    # <addtoken>
    # <classify>


# Generated at 2022-06-25 14:57:27.773384
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.pop()


# Generated at 2022-06-25 14:57:30.790981
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # add these lines:
    parser_0.setup()
    parser_0.pop()


# Generated at 2022-06-25 14:57:35.358953
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    # Testing with a string 'value'
    parser_0.addtoken(1, 'value', RawNode)

    # Testing with a string 'value' and an int 'type'
    parser_0.addtoken(1, 'value', RawNode)


# Generated at 2022-06-25 14:57:39.921040
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.ENCODING
    value_0 = "\x1b\xef\xbf\xbd"
    context_0 = Context(previous_type=token.NEWLINE, type=type_0, start=0, end=1, line=0)
    value_0 = token.ENCODING
    assert parser_0.classify(type_0, value_0, context_0) == value_0


# Generated at 2022-06-25 14:57:45.199825
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0 is not None
    parser_0.setup(1)
    assert parser_0 is not None
    assert parser_0.stack[-1] == (0, 0, (1, None, None, [])), 'parser_0.stack[-1] == (0, 0, (1, None, None, []))'
    result_0 = parser_0.shift(None, None, 0, None)
    assert parser_0.stack[-1] == (0, 0, (1, None, None, [])), 'parser_0.stack[-1] == (0, 0, (1, None, None, []))'
    assert result_0 is None

# Generated at 2022-06-25 14:57:48.518276
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.pop()


# Generated at 2022-06-25 14:57:50.254412
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser = Parser(module_0.Grammar())
    parser.shift(1, 'test_0', 0, None)

test_case_0()
test_Parser_shift()

# Generated at 2022-06-25 14:57:53.077548
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assertRaises(ParseError, parser_0.shift, (1), None, (2), None)


# Generated at 2022-06-25 14:57:55.277623
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()

