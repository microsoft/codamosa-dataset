

# Generated at 2022-06-25 14:48:17.412819
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = int()
    value_0 = ''
    context_0 = blib2to3.pytree.Context()
    def method_0(type_0, value_0, context_0):
        return Parser.addtoken(parser_0, type_0, value_0, context_0)
    method_0(type_0, value_0, context_0)


# Generated at 2022-06-25 14:48:20.558572
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()

    start_1 = None
    parser_1.setup(start_1)


# Generated at 2022-06-25 14:48:24.694086
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    with raises(ParseError):
        parser_0.setup()


# Generated at 2022-06-25 14:48:28.327395
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()

    # Test for a condition
    assert parser_0.stack != 0, '''assert parser_0.stack != 0'''


# Generated at 2022-06-25 14:48:31.518022
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(1, 2, 3, 4)
    parser_0.stack.append((5,6,7))
    parser_0.shift(1, 2, 3, 4)


# Generated at 2022-06-25 14:48:35.625607
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    test_0 = Parser(grammar_0)
    test_1 = (1,)
    test_0.push(4, test_1, test_1, test_1)


# Generated at 2022-06-25 14:48:38.506692
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert not parser_0.addtoken(0, None, None)


# Generated at 2022-06-25 14:48:41.493632
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    parser_0.pop()


# Generated at 2022-06-25 14:48:47.023196
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newstate_0 = 0
    context_0 = Context()
    type_0 = 1
    newdfa_0 = (None, None)
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:48:51.222431
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    from blib2to3.pgen2.tokenize import generate_tokens
    for i in generate_tokens:
        parser_1.setup()
        parser_1.push(i, i, i, i)
        parser_1.setup()


# Generated at 2022-06-25 14:49:02.434886
# Unit test for method push of class Parser
def test_Parser_push():
    import inspect
    import sys
    import unittest

    class UnitTestParserPush(unittest.TestCase):
        def test_push_0(self):
            grammar_0 = module_0.Grammar()
            parser_0 = Parser(grammar_0)

            parser_0.push(8, 2, 0, 2)
            self.assertEqual(parser_0.stack, [(2, 0, (8, None, 2, []))])
    unittest.main()

# Generated at 2022-06-25 14:49:06.409600
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(token.INDENT, None, 0, None)


# Generated at 2022-06-25 14:49:16.514053
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    try:
        parser_0.addtoken()
    except:
        assert True
    else:
        assert False

    # Unit test for method push of class Parser
    def test_Parser_push():
        pass

        # Unit test for method pop of class Parser
        def test_Parser_pop():
            pass

            # Unit test for method shift of class Parser
            def test_Parser_shift():
                pass

                # Unit test for method setup of class Parser
                def test_Parser_setup():
                    pass

                    # Unit test for method classify of class Parser
                    def test_Parser_classify():
                        pass

# Generated at 2022-06-25 14:49:19.155332
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:49:21.830908
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    start_0 = int()
    parser_0.setup(start_0)


# Generated at 2022-06-25 14:49:24.231453
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert parser_0.grammar == grammar_0


# Generated at 2022-06-25 14:49:28.119087
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.push(
        "test_parser.py",
        int(),
        int(),
        "test_parser.py",
    )



# Generated at 2022-06-25 14:49:32.193786
# Unit test for method pop of class Parser
def test_Parser_pop():
    # constructor test
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    # method test
    try:
        parser_0.pop()
        raise Exception("pop raises exception: %s" % repr(parser_0.pop()))
    except:
        pass



# Generated at 2022-06-25 14:49:33.800880
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    parser = Parser(*args) # type: ignore
    parser.setup()
    parser.addtoken()

# Generated at 2022-06-25 14:49:37.469082
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    assert parser_1.addtoken(
        1, 2, (3, 4)
    ) == False


# Generated at 2022-06-25 14:49:53.663229
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Test with a simple stack
    import blib2to3.pgen2.grammar as module_0
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    stackentry_0 = (parser_0.grammar.dfas[parser_0.grammar.start], 0, (None, None, None, [None]))
    parser_0.stack = [stackentry_0]
    parser_0.pop()
    assert parser_0.stack == []


# Generated at 2022-06-25 14:49:55.608305
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:50:06.253564
# Unit test for method pop of class Parser
def test_Parser_pop():
    import blib2to3.pgen2.grammar as module_0
    import blib2to3.pytree as module_1
    _value_0 = module_1.Node
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    _value_2 = parser_0.pop
    assert _value_2 == module_1.Node
    parser_0.setup()
    parser_0.addtoken(1, "", Context(1, 0))
    _value_2 = parser_0.pop
    assert _value_2 == module_1.Node
    parser_0.setup()
    parser_0.addtoken(2, "", Context(2, 0))
    _value_2 = parser_0.pop
    assert _value_2 == module_

# Generated at 2022-06-25 14:50:11.069997
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = -1
    newdfa_0 = module_0.dfas
    newstate_0 = 0
    context_0 = Context()
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)

# Generated at 2022-06-25 14:50:14.113652
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()


# Generated at 2022-06-25 14:50:19.100355
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    type_1 = token.NAME
    value_1 = "untokenize"
    context_1 = Context()
    assert_0 = parser_1.classify(type_1, value_1, context_1)
    assert assert_0 == 258


# Generated at 2022-06-25 14:50:28.179618
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.stack == []
    assert parser_0.rootnode is None

    parser_0.stack.append((35, 0, (51, None, None, [])))
    parser_0.stack.append((17, 0, (76, None, None, [])))
    parser_0.stack.append((51, 0, (27, None, None, [])))
    parser_0.stack.append((31, 0, (35, None, None, [])))
    parser_0.stack.append((59, 0, (30, None, None, [])))
    parser_0.stack.append((57, 0, (21, None, None, [])))

# Generated at 2022-06-25 14:50:30.968432
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()
    try:
        parser_0.pop()
    except IndexError:
        return
    raise RuntimeError()


# Generated at 2022-06-25 14:50:38.178491
# Unit test for method shift of class Parser
def test_Parser_shift():
    # From test case 0
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = parser_0.grammar.dfas[0]
    state_0 = 0
    node_0 = (0, None, None, [])
    parser_0.push(0, dfa_0, state_0, node_0)
    type_0 = 0
    value_0 = 0
    newstate_0 = 0
    context_0 = 0
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:50:42.875147
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    try:
        type_1 = None
        value_1 = None
        context_1 = None
        parser_1.addtoken(type_1, value_1, context_1)
        assert False
    except ParseError as e:
        assert str(e) == "bad token: type=None, value=None, context=None"
    # Add a token with type: 0, value: foo, context: 
    parser_2 = Parser(grammar_1)
    type_2 = 0
    foo_2 = "foo"
    value_2 = foo_2
    context_2 = None

# Generated at 2022-06-25 14:50:57.760091
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    push_0 = parser_0.push
    push_0(1, (1, 1), 2)


# Generated at 2022-06-25 14:51:00.758502
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_0 = parser_0.pop()
    assert test_0 is None


# Generated at 2022-06-25 14:51:01.689674
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_case_0()

# Generated at 2022-06-25 14:51:06.503592
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Setup
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type = token.NAME
    value = 'continue'
    context = Context()
    # Invocation
    ilabel = parser_0.classify(type, value, context)
    # Verification
    assert ilabel == 5


# Generated at 2022-06-25 14:51:09.991186
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Create a new instance
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Call method pop
    parser_0.pop()


# Generated at 2022-06-25 14:51:13.185843
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_value = parser_0.addtoken(2, 3, 4)
    assert test_value


# Generated at 2022-06-25 14:51:16.540630
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(137)
    parser_0.addtoken(1, None, Context(2, 3))
    parser_0.pop()


# Generated at 2022-06-25 14:51:18.062328
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:51:20.377904
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    parser_0.classify(token.NAME, " ", Context(prec=0, flags=0))


# Generated at 2022-06-25 14:51:32.146247
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import token
    from .driver import Driver
    from .tokenize import generate_tokens
    from io import StringIO
    from blib2to3.fixer_util import eval_escape
    import io
    import types
    import re

    text = '"\\x41"'
    lexer = generate_tokens(StringIO(text).readline)
    parser = Parser(grammar_0)
    driver = Driver(parser, token.INDENT, token.DEDENT)
    with re.replaces:
        type = token.STRING
        value = 'x41'
        context_0 = Context(0, 0, '', lexer, None)
        with parser.classify(type, value, context_0) as value:
            assert value is None

# Generated at 2022-06-25 14:51:45.381798
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(9)


# Generated at 2022-06-25 14:51:48.640603
# Unit test for method shift of class Parser
def test_Parser_shift():
    token_0_value = "token_0_value"
    parser_0 = Parser(None)
    parser_0.stack = [[1, 0, None]]
    parser_0.shift(token.NAME, token_0_value, 1, Context(None, None))
    assert [1, 1, None] == parser_0.stack[-1]


# Generated at 2022-06-25 14:51:54.543787
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    token_1 = token.NAME
    value_1 = ""
    context_1 = Context(0, 0)
    result_1 = parser_1.addtoken(token_1, value_1, context_1)
    assert result_1 is False


# Generated at 2022-06-25 14:51:56.803011
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(None)  # None


# Generated at 2022-06-25 14:51:59.959072
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.pop() == None
    assert parser_0.pop() == None


# Generated at 2022-06-25 14:52:02.914655
# Unit test for method push of class Parser
def test_Parser_push():
    # Test case for method push of class Parser
    parser_0 = Parser(Grammar())
    parser_0.push(0, [(0, 0)], 0, Context(None, None))


# Generated at 2022-06-25 14:52:06.360827
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(4, '4', Context(3, None))


# Generated at 2022-06-25 14:52:08.658874
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.classify(2, 3, 4)


# Generated at 2022-06-25 14:52:14.797917
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.pgen2._parse as module_0
    import blib2to3.pgen2._tokenize as module_1
    import blib2to3.pygram as module_2
    import blib2to3.pytree as module_3
    python_grammar = module_2.python_grammar
    python_grammar_0 = module_2.python_grammar
    python_grammar_0 = module_0.pgen._generate_grammar(python_grammar_0, False)
    python_grammar_1 = module_1._build_tokenizer(python_grammar_0)
    type_0 = module_1.tokenize.tok_name.get('NAME')
    value_0 = 'print'
    context_0 = (1, 1)
    parser

# Generated at 2022-06-25 14:52:20.079568
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_3 = module_0.Grammar()
    parser_3 = Parser(grammar_3)
    token_type_11 = 1
    token_value_8 = "test_token"
    token_context_7 = Context(line=None, col=None, offset=None)
    new_state_10 = 42
    parser_3.shift(token_type_11, token_value_8, new_state_10, token_context_7)


# Generated at 2022-06-25 14:52:33.179131
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(None)


# Generated at 2022-06-25 14:52:37.122479
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_addtoken = module_0.Grammar()
    parser_addtoken = Parser(grammar_addtoken)
    parser_addtoken.setup()
    result_grammar_addtoken = grammar_addtoken
    result_parser_addtoken = (parser_addtoken,result_grammar_addtoken)
    return result_parser_addtoken


# Generated at 2022-06-25 14:52:38.849409
# Unit test for method setup of class Parser
def test_Parser_setup():
    stmt_grammar = blib2to3.pgen2.grammar.Grammar()
    stmt_parser = Parser(stmt_grammar)
    stmt_parser.setup()


# Generated at 2022-06-25 14:52:41.157801
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    parser_0 = Parser(Grammar({'START': {'S'}, 'S': {'S', 'S', 'S'}}), None)
    parser_0.addtoken(256, None, Context())


# Generated at 2022-06-25 14:52:45.315586
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(256, None, None)
    parser_0.rootnode


# Generated at 2022-06-25 14:52:50.471368
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    def raise_exception_0():
        raise NotImplementedError()
    parser_0.pop = raise_exception_0
    try:
        parser_0.pop()
    except NotImplementedError:
        pass
    else:
        raise AssertionError('Exception expected')


# Generated at 2022-06-25 14:52:53.190086
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Create a Grammar
    grammar_0 = module_0.Grammar()
    
    # Create a Parser
    parser_0 = Parser(grammar_0)
    
    # Call the method
    parser_0.pop()


# Generated at 2022-06-25 14:52:56.530979
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(1, 2, 3, 4)


# Generated at 2022-06-25 14:52:58.825152
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:53:01.881527
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, None, None)


# Generated at 2022-06-25 14:53:29.984577
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()



# Generated at 2022-06-25 14:53:35.311339
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = -1
    value_0 = None
    context_0 = None
    newstate_0 = -4
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:53:39.509089
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    sequence_0 = []
    
    assert parser_0.addtoken(0, None, None) == False
    sequence_0.append(1)
    assert parser_0.addtoken(0, None, None) == False


# Generated at 2022-06-25 14:53:41.049016
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()

# Generated at 2022-06-25 14:53:43.331779
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:53:50.337635
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    str_0 = parser_0.classify(256, 'TYPE', Context(preceding=[]))
    assert str_0 == 257
    str_1 = parser_0.classify(256, 'TYPE', Context(preceding=[]))
    assert str_1 == 257
    str_2 = parser_0.classify(256, 'TYPE', Context(preceding=[]))
    assert str_2 == 257
    str_3 = parser_0.classify(256, 'TYPE', Context(preceding=[]))
    assert str_3 == 257
    str_4 = parser_0.classify(256, 'TYPE', Context(preceding=[]))
    assert str_4 == 257
   

# Generated at 2022-06-25 14:53:53.562058
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    token_0 = token.NAME
    value_0 = 'test'
    context_0 = Context(0, 0)
    assert parser_1.addtoken(token_0, value_0, context_0) is False

# Generated at 2022-06-25 14:53:55.953851
# Unit test for method classify of class Parser
def test_Parser_classify():
    def test_case_0():
        grammar = blib2to3.pgen2.grammar.Grammar()
        Parser(grammar)



# Generated at 2022-06-25 14:53:59.988001
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Construct instance
    grammar_2 = module_0.Grammar()
    parser_0 = Parser(grammar_2)
    # Method call
    parser_0.pop()
    # Assertions
    assert parser_0 != None


# Generated at 2022-06-25 14:54:05.781984
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(token.NEWLINE, None, 7, None)
    parser_0.shift(token.INDENT, None, 6, None)
    parser_0.shift(token.INDENT, None, 6, None)


# Generated at 2022-06-25 14:54:47.300986
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_1 = Parser(grammar_0)
    parser_1.grammar = module_0.Grammar()
    parser_1.convert = (lambda grammar_0, node_0: None)
    parser_1.setup()
    parser_1.stack = []
    parser_1.rootnode = None
    parser_1.used_names = set()
    res_1 = parser_1.shift(0, None, 1, None)
    assert res_1 == None, res_1
    res_2 = parser_1.shift(0, None, 1, [0])
    assert res_2 == None, res_2
    parser_1.stack = [[(0, 1), 0, [0, None, None, []]]]
    res_

# Generated at 2022-06-25 14:54:57.047537
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

# Generated at 2022-06-25 14:55:01.096826
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    parser_0.setup()

    assert parser_0.addtoken(token.ENDMARKER, None, Context(preceding_lines=[])) == True

    assert parser_0.rootnode == None

# Generated at 2022-06-25 14:55:03.561434
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Argument types
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Value
    parser_0.shift(0, 0, 0, 0)



# Generated at 2022-06-25 14:55:06.927246
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    parser_0.pop()


# Generated at 2022-06-25 14:55:17.407102
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert not parser_0.addtoken(1,None,Context(preceding_text='', parent=None, filename='', start_pos=None, white_chars=None, preceding_white_chars=None, end_pos=None))
    assert not parser_0.addtoken(1,None,Context(preceding_text='', parent=None, filename='', start_pos=None, white_chars=None, preceding_white_chars=None, end_pos=None))

# Generated at 2022-06-25 14:55:19.072573
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser_0 = Parser(Grammar())
    parser_0.shift(1, "", 1, Context())

# Generated at 2022-06-25 14:55:26.548831
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    addtoken_args = [
        (int, None, Context)
    ]

    def addtoken_mock(type, value, context):
        # First argument should be type:int
        assert isinstance(type, int)

        # Second argument should be value:None
        assert value is None

        # Third argument should be context:Context
        assert isinstance(context, Context)
        return True

    parser_0.addtoken = addtoken_mock
    parser_0.addtoken(*addtoken_args)


# Generated at 2022-06-25 14:55:28.969283
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.shift(0, "0", 1, Context(1, 1))


# Generated at 2022-06-25 14:55:35.633720
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.pgen2.grammar as module_0
    import blib2to3.pgen2.token as module_1
    import blib2to3.pytree as module_2
    import __builtin__ as module_3
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, 'a', module_2.Leaf(1, 'a', 'a'))


# Generated at 2022-06-25 14:56:44.282857
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 2
    newdfa_0 = ((0, 0), (0, 1), (0, 2))
    newstate_0 = 1
    context_0 = Context()
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)
    assert parser_0.stack == [(newdfa_0, 0, (2, None, context_0, [])), (newdfa_0, 1, (0, None, None, None))]

# Generated at 2022-06-25 14:56:47.689342
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    try:
        parser_0.pop()
    except Exception as exc_0:
        assert isinstance(exc_0, IndexError)
        assert str(exc_0) == 'pop from empty list'
    else:
        assert False, 'Should have thrown'


# Generated at 2022-06-25 14:56:50.561038
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_1 = Parser(grammar_0)
    type_0 = int()
    newdfa_0 = DFAS()
    newstate_0 = int()
    context_0 = Context()
    parser_1.push(type_0, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:56:56.234833
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = [[(0, 0),]]
    state_0 = 0
    node_1 = (0, None, None, [])
    parser_0._Parser__stack = [(dfa_0, state_0, node_1)]
    type_0 = 259
    value_0 = 259
    newstate_0 = 0
    context_0 = NL(0, '')
    parser_0.shift(type_0, value_0, newstate_0, context_0)
    assert parser_0._Parser__stack == [(dfa_0, newstate_0, node_1)]


# Generated at 2022-06-25 14:57:04.192435
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Preparation
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 256
    value_0 = 'b'
    context_0 = Context(previous_context=None, debug_format=None)
    context_1 = Context(previous_context=context_0, debug_format=None)
    context_1.previous_context = context_0
    
    # The test
    assert parser_0.classify(type_0, value_0, context_0) == 256
    
    
    
    
    
    
    

# Generated at 2022-06-25 14:57:06.320029
# Unit test for method pop of class Parser
def test_Parser_pop():
    module_0 = blib2to3.pgen2.grammar
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:57:13.364306
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()

    # Test case: No arguments.
    # Expected result: raises a TypeError exception.
    try:
        parser_0.shift()
    except TypeError:
        pass
    else:
        raise Exception("Could not detect missing arguments.")

    # Test case: one argument.
    # Expected result: raises a TypeError exception.
    try:
        parser_0.shift(0)
    except TypeError:
        pass
    else:
        raise Exception("Could not detect missing arguments.")

    # Test case: two arguments.
    # Expected result: raises a TypeError exception.

# Generated at 2022-06-25 14:57:16.717602
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = None
    value_0 = None
    context_0 = Context()
    newstate_0 = None
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:57:19.098198
# Unit test for method shift of class Parser
def test_Parser_shift():
    test_case_0()


# Generated at 2022-06-25 14:57:24.987913
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # add new grammar to test
    grammar_0 = module_0.Grammar()
    # create parser
    parser_0 = Parser(grammar_0)
    # create token (NAME, 'a')
    token_0 = 1
    token_name_0 = 'a'
    token_value_0 = token_name_0
    token_context_0 = None
    # call method addtoken on parser_0
    test_0 = parser_0.addtoken(token_0, token_value_0, token_context_0)