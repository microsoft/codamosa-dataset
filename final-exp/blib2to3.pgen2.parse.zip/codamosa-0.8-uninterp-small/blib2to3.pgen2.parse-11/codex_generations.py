

# Generated at 2022-06-25 14:48:16.992104
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(token.NAME, "a", Context(0, 0))
    parser_0.addtoken(token.NAME, "a", Context(0, 0))
    parser_0.classify(token.NAME, "a", Context(0, 0))


# Generated at 2022-06-25 14:48:18.729506
# Unit test for method push of class Parser
def test_Parser_push():
    # TODO: Add unit tests to ensure these functions work as expected.
    pass

# Generated at 2022-06-25 14:48:24.010431
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    try:
        parser_0.setup()
        parser_0.setup()
        parser_0.setup()
        parser_0.setup()
    except:
        raise AssertionError
    try:
        parser_0.setup(256)
    except:
        raise AssertionError
    try:
        parser_0.setup(256)
    except:
        raise AssertionError
    try:
        parser_0.setup()
    except:
        raise AssertionError


# Generated at 2022-06-25 14:48:26.578396
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:48:37.480153
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, "a", (1, "b"))
    parser_0.addtoken(2, "a", (1, "b"))
    parser_0.addtoken(3, "a", (1, "b"))
    parser_0.addtoken(4, "a", (1, "b"))
    parser_0.addtoken(5, "a", (1, "b"))
    parser_0.addtoken(6, "a", (1, "b"))
    parser_0.addtoken(7, "a", (1, "b"))
    parser_0.addtoken(8, "a", (1, "b"))
    parser_

# Generated at 2022-06-25 14:48:40.170373
# Unit test for method pop of class Parser
def test_Parser_pop():
    rootnode = "return statement"
    result = Parser._pop(self)
    assert result == rootnode


# Generated at 2022-06-25 14:48:45.117111
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    result_0 = parser_0.addtoken(token.DEDENT, "DEDENT", Context((1, 3), (2, 4)))

    assert result_0


# Generated at 2022-06-25 14:48:49.089768
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = [(0, 0, 0)]
    parser_0.shift(0, "", 0)
    assert len(parser_0.stack) == 1


# Generated at 2022-06-25 14:48:51.832392
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(token.NAME, 'name', (0, 0))


# Generated at 2022-06-25 14:48:55.183286
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NAME
    value_0 = 'ab'
    newstate_0 = 0
    context_0 = Context()
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:49:01.674521
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:49:05.283955
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:49:08.235468
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    token_0 = token.NAME
    value_1 = 'name'
    context_0 = Context('context_0')
    # Call method addtoken of class Parser
    Parser.addtoken(parser_0, token_0, value_1, context_0)

# Generated at 2022-06-25 14:49:12.964871
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    type_1 = 42
    newdfa_1 = ((), {})
    newstate_1 = 3
    context_1 = Context()
    parser_1.push(type_1, newdfa_1, newstate_1, context_1)
    dfa_1, state_1, node_1 = parser_1.stack[-1]
    assert (dfa_1, state_1, node_1) == ((), 3, (42, None, None, [])), (
        dfa_1,
        state_1,
        node_1,
    )


# Generated at 2022-06-25 14:49:15.697329
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    parser_0.setup()


# Generated at 2022-06-25 14:49:24.740759
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    converter_tuple_0 = (
        'elementary', 
        'a', 
        'b', 
        'c', 
        'd', 
        'e', 
        'f', 
        'g', 
        'h', 
        'i', 
        'j',
    )
    parser_0 = Parser(grammar_0, *converter_tuple_0)
    popnode_tuple_0 = (
        'elementary',
        'a',
        'b',
        'c',
        'd',
        'e',
        'f',
        'g',
        'h',
        'i',
        'j',
    )

# Generated at 2022-06-25 14:49:34.509133
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Program for testing
    test_program = ['\n', 'a', ' ', '=', ' ', '1', '\n', '\n', 'b', ' ', '=', ' ', '2', '\n', '\n', 'c', ' ', '=', ' ', '3', '\n', '\n', 'd', ' ', '=', ' ', '4', '\n', '\n']

    # Returns a DFA augmented with a default transition to return
    # -1 (for invalid inputs) and an initial state of 0.
    def build_dfa(dfa: Sequence[Any]) -> DFA:
        accept_states = [state for state, arcs in enumerate(dfa) if arcs == [(0, state)]]
        return [[(-1, 0)] + list(state) for state in dfa], accept_

# Generated at 2022-06-25 14:49:39.458978
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newstate_0 = 0
    type_0 = 0
    context_0 = Context((1,0))
    value_0 = ''
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:49:49.828459
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # data_0 = TestData()
    # data_0.addtoken(STATE)
    # data_0.addtoken(TYPE)
    # data_0.addtoken(VALUE)
    parser.addtoken()


if __name__ == "__main__":
    import unittest


    class Parser_TestCase(unittest.TestCase):
        def test_case_0(self):
            test_case_0()


    from unittest import TestLoader


    class Parser_TestSuite(unittest.TestSuite):
        def __init__(self) -> None:
            super().__init__()
            self.addTest(TestLoader().loadTestsFromTestCase(Parser_TestCase))


    def main():
        runner = unittest.TextTestRunner()

# Generated at 2022-06-25 14:49:54.026262
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newstate_0 = 0
    type_0 = 256
    newdfa_0 = None
    context_0 = None
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:50:17.107019
# Unit test for method setup of class Parser
def test_Parser_setup():
    # Create a Parser instance
    grammar = Grammar()
    parser = Parser(grammar)

    # Call setup(); this should not raise an exception
    parser.setup()

# Generated at 2022-06-25 14:50:19.404068
# Unit test for method classify of class Parser
def test_Parser_classify():
    parser_0 = Parser(module_0.Grammar())
    assert parser_0.classify(0, None, None) == 1


# Generated at 2022-06-25 14:50:28.455266
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.shift(38, '(((defun)))', 0, None)
    parser_0.shift(1, 'a', 0, None)
    parser_0.shift(58, None, 0, None)
    parser_0.classify(7, '(')
    parser_0.classify(2, ')')
    parser_0.classify(46, '-')
    parser_0.classify(46, '-')
    parser_0.classify(45, '+')
    parser_0.classify(2, ')')
    parser_0.shift(3, '*', 0, None)

# Generated at 2022-06-25 14:50:31.478795
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.push(None, None, None, None)


# Generated at 2022-06-25 14:50:32.693610
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = Parser(None)
    parser_0.pop()


# Generated at 2022-06-25 14:50:40.661155
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NAME
    value_0 = 'a'
    newstate_0 = 0
    context_0 = Context()

    # Call function
    parser_0.shift(type_0, value_0, newstate_0, context_0)
    # Check for correct exception
    try:
        assert False
    except ParseError as e:
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-25 14:50:43.673887
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type = parser_0.addtoken(type=1, value=None, context=None)
    assert type == False


# Generated at 2022-06-25 14:50:50.624873
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.pgen2.grammar as module_0
    import blib2to3.pytree as module_1
    import blib2to3.pgen2.token as module_2
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    token_0 = module_1.Leaf(11, "test", module_2.NUMBER)
    parser_0.addtoken(11, "test", token_0)


# Generated at 2022-06-25 14:50:57.367565
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    context_0 = Context()
    # Unit test for ParseError raise
    try:
        parser_0.addtoken(256, None, context_0)
    except ParseError:
        pass
    else:
        raise RuntimeError('Parsing failed')



# Generated at 2022-06-25 14:51:01.806344
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    context_0 = Context(None, 1, 1)
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, "", context_0)
    assert parser_0.rootnode


# Generated at 2022-06-25 14:51:13.651895
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    assert True



# Generated at 2022-06-25 14:51:16.041378
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.push()


# Generated at 2022-06-25 14:51:18.172283
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert not parser_0.addtoken(token.ENCODING, 'utf-8', ('test', 0))


# Generated at 2022-06-25 14:51:22.642188
# Unit test for method classify of class Parser
def test_Parser_classify():
    test_case_0()
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type = __int__(0)
    value = None
    context_0 = Context()
    result_0 = parser_0.classify(type, value, context_0)


# Generated at 2022-06-25 14:51:25.910533
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:51:30.728553
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NAME
    value_0 = None
    context_0 = lambda : None
    parser_0.addtoken(type_0, value_0, context_0)


# Generated at 2022-06-25 14:51:38.220101
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    type = 41
    value = "x"
    context = (1,2)
    parser.classify(type, value, context)
    type = 41
    value = "x"
    context = (1,2)
    parser.classify(type, value, context)
    type = 41
    value = "x"
    context = (1,2)
    parser.classify(type, value, context)


if __name__ == "__main__":
    test_case_0()
    test_Parser_classify()

# Generated at 2022-06-25 14:51:39.074073
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_case_0()


# Generated at 2022-06-25 14:51:42.595809
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    context_0 = Context()
    parser_0.addtoken(0, "a", context_0)


# Generated at 2022-06-25 14:51:46.320703
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = []
    state_0 = -1
    context_0 = Context(1, 1)
    parser_0.shift(0, None, state_0, context_0)


# Generated at 2022-06-25 14:52:14.292922
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    assert parser.addtoken('NAME', 'x', 'context_1') == False
    assert parser.addtoken('EQUAL', '=', 'context_2') == False
    assert parser.addtoken('NUMBER', '1', 'context_3') == True


# Generated at 2022-06-25 14:52:22.292599
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert parser_0.stack == [(grammar_0.dfas[1], 0, (1, None, None, []))]
    parser_0.addtoken(1, '', Context(0, 0))
    assert parser_0.rootnode is not None
    parser_1 = Parser(grammar_0)
    parser_1.setup()
    assert parser_1.stack == [(grammar_0.dfas[1], 0, (1, None, None, []))]
    parser_1.addtoken(2, '', Context(0, 0))

# Generated at 2022-06-25 14:52:25.593035
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Case 0
    parser_0.shift(0, '', 0, None)
    # Case 1
    parser_0.shift(0, '', 0, None)


# Generated at 2022-06-25 14:52:31.393225
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    # Helper function for method addtoken
    def test_addtoken_helper(self, type_arg, value_arg, context_arg):
        '''
        raise AssertionError("Bad input to test_addtoken_helper")
        '''
        # Add a token; return True iff this is the end of the program
        self.addtoken(type_arg, value_arg, context_arg)
    # Helper function for method addtoken
    def test_addtoken_helper(self, type_arg, value_arg, context_arg):
        '''
        raise AssertionError("Bad input to test_addtoken_helper")
        '''
        #

# Generated at 2022-06-25 14:52:37.568170
# Unit test for method classify of class Parser
def test_Parser_classify():
    global grammar_0
    try:
        _a_0 = grammar_0.tokens
    except AttributeError:
        pass
    else:
        raise AssertionError(
            " grammar_0.tokens should not exist yet. "
            "Are you running .setup() on the parser before running .classify()?"
        )
    parser_0.setup()
    _a_0 = parser_0.classify(1, "NAME")

# Generated at 2022-06-25 14:52:38.234407
# Unit test for method pop of class Parser
def test_Parser_pop():
    test_case_0()

# Generated at 2022-06-25 14:52:41.770678
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type = 1
    newdfa = (())
    newstate = 1
    context = 1
    parser_0.push(type, newdfa, newstate, context)


# Generated at 2022-06-25 14:52:46.888751
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NEWLINE
    value_0 = '\n'
    newstate_0 = 1
    context_0 = Context()
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:52:49.482431
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:52:52.625558
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Unit test for method addtoken of class Parser
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, "1", (1, 1))


# Generated at 2022-06-25 14:53:39.698666
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.pop()


# Generated at 2022-06-25 14:53:41.993418
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = test_case_0()
    # Setup
    parser_0.setup()
    # Test
    parser_0.pop()


# Generated at 2022-06-25 14:53:43.332783
# Unit test for method push of class Parser
def test_Parser_push():
    # Assert #1
    test_case_0()
    # Assert #2
    test_case_0()


# Generated at 2022-06-25 14:53:46.695248
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    context_0 = Context()
    parser_0.shift(None, None, 0, context=context_0)


# Generated at 2022-06-25 14:53:48.682455
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.pop()
    

# Generated at 2022-06-25 14:53:53.175102
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(1, None, 1, None)
    parser_0.shift(1, None, 1, None)
    parser_0.shift(1, None, 1, None)
    parser_0.shift(2, None, 2, None)
    parser_0.shift(3, None, 3, None)


# Generated at 2022-06-25 14:53:53.906395
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    print("Testing Parser.addtoken")


# Generated at 2022-06-25 14:53:59.054561
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 0
    value_0 = None
    context_0 = Context()
    expected_0 = True
    actual_0 = parser_0.addtoken(type_0, value_0, context_0)
    assert actual_0 == expected_0


# Generated at 2022-06-25 14:54:03.418257
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    stack_0 = []
    parser_0.push((0x100, 0x100), [], 0x100, (0, 0))
    assert parser_0.stack == stack_0


# Generated at 2022-06-25 14:54:07.983439
# Unit test for method push of class Parser
def test_Parser_push():
    test = Parser(None)
    test.stack = [1,2,3]
    test.push(1,2,3,4)
    assert test.stack == [1,2,3,(2, 0, (1, None, 4, []))]


# Generated at 2022-06-25 14:55:13.884734
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    grammar_2 = module_0.Grammar()
    parser_1 = Parser(grammar_2)
    grammar_1 = module_0.Grammar()
    parser_2 = Parser(grammar_1)


# Generated at 2022-06-25 14:55:17.590207
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Test method shift of class Parser."""
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # test with token.STRING
    parser_0.shift(token.STRING, "abc", 0, 0)


# Generated at 2022-06-25 14:55:19.987160
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_2 = module_0.Grammar()
    parser_2 = Parser(grammar_2)
    parser_2.shift(2, 'aaa', 4, ())
    parser_2.shift(1, 'aaa', 3, ())
    parser_2.shift(0, 'aaa', 2, ())
    parser_2.shift(0, 'aaa', 2, ())


# Generated at 2022-06-25 14:55:25.900617
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.pgen2.driver as module_0
    grammar_0 = module_0.load_grammar('/home/rmyers/src/3to2/lib2to3/Grammar.txt')
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = 1
    value_0 = None
    context_0 = Context()
    AddToken_0 = parser_0.addtoken(type_0, value_0, context_0)

# Generated at 2022-06-25 14:55:27.873818
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.push(0, (list(), dict()), 0, 0)


# Generated at 2022-06-25 14:55:32.600365
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0, convert=None)
    parser_0.setup()
    parser_0.shift(0, None, 0, None)
    parser_0.shift(0, None, 0, None)


# Generated at 2022-06-25 14:55:36.012219
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Test root node
    parser_0.pop()
    assert parser_0.rootnode is not None
    assert parser_0.rootnode != (1, None, None, [])


# Generated at 2022-06-25 14:55:39.209313
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(1, None, 2, None)


# Generated at 2022-06-25 14:55:41.622831
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:55:44.805877
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Setup
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    # Test
    parser_0.pop()



# Generated at 2022-06-25 14:57:56.193103
# Unit test for method classify of class Parser
def test_Parser_classify():
    # TODO : be sure that this unit test test really the method classify of class Parser
    parser_0 = Parser(grammar_0)
    parser_0.classify(type, value, context)

# Generated at 2022-06-25 14:58:00.568256
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 1
    value_0 = '{}'
    newstate_0 = 1
    context_0 = Context(prec=0, filename='', node=None, source_encoding='', flags=0)
    parser_0.shift(type_0, value_0, newstate_0, context_0)
