

# Generated at 2022-06-25 14:48:14.529877
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_value = parser_0.shift(123, "example", 456, Context(None, None, None))


# Generated at 2022-06-25 14:48:17.413690
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:48:19.344514
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    parser_1.shift(token.LPAR, "(", 0)

# Generated at 2022-06-25 14:48:30.555862
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_1 = Parser(grammar_0)
    grammar_2 = module_0.Grammar()
    parser_1.grammar = grammar_2
    
    parser_2 = Parser(grammar_2)
    grammar_1 = module_0.Grammar()
    parser_2.grammar = grammar_1
    
    parser_3 = Parser(grammar_2)
    grammar_2 = module_0.Grammar()
    parser_3.grammar = grammar_2
    grammar_2.start = 3

    type_0 = token.NAME
    value_0 = ""
    context_0 = Context()
    parser_3.classify(type_0, value_0, context_0)

    parser_4 = Parser

# Generated at 2022-06-25 14:48:33.755047
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(0)
    parser_0.addtoken()


# Generated at 2022-06-25 14:48:41.840696
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    _, state_0, node_0 = parser_0.stack[-1]
    type_0 = grammar_0.dfas
    newdfa_0 = grammar_0.dfas
    newstate_0 = 0
    context_0 = Context()
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)
    assert len(parser_0.stack) == 2
    _, state_1, node_1 = parser_0.stack[-1]
    assert node_1[2] is context_0


# Generated at 2022-06-25 14:48:44.469291
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:48:50.514322
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NAME
    value_0 = None
    context_0 = Context(previous_context=None, this_child_index=None, this_rule_name=None, this_parent=None, token=None, this_child=None)
    assert parser_0.classify(type_0, value_0, context_0) == 2


# Generated at 2022-06-25 14:48:56.385651
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    
    # Set the shift method of class Parser to the temporary function
    def temporary(token_type, token_value, newstate, context):
        parser_0.stack[-1] = (dfa, newstate, node)
        return
    parser_0.shift = temporary
    token_type = 0
    token_value = None
    newstate = 0
    context = 0
    parser_0.shift(token_type, token_value, newstate, context)
    
    # Now return it to the original one
    parser_0.shift = Parser.shift


# Generated at 2022-06-25 14:48:57.290515
# Unit test for method pop of class Parser
def test_Parser_pop():
    test_case_0()

# Generated at 2022-06-25 14:49:14.263675
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.shift(
        1,
        "",
        0,
        Context(preceding=[], parent=None, flags=0, newlines=0)
    )

if __name__ == "__main__":
    test_case_0()
    test_Parser_shift()

# Generated at 2022-06-25 14:49:18.649408
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    tkns = list(tokenize.generate_tokens(StringIO('1 + 1').readline))
    for tkn in tkns:
        parser_0.addtoken(*tkn)

# Generated at 2022-06-25 14:49:22.333261
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = []
    parser_0.stack.append('asdf')
    parser_0.shift(0, 'asdf', 0, 'asdf')


# Generated at 2022-06-25 14:49:24.678999
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(token.NAME, "test", 0, (1, 0))


# Generated at 2022-06-25 14:49:27.184051
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)


# Generated at 2022-06-25 14:49:30.550808
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.STRING
    assert parser_0.addtoken(type_0, "", Context(PRE_NEWLINE, (1, 0)))

# Generated at 2022-06-25 14:49:32.958709
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.stack == []


# Generated at 2022-06-25 14:49:38.103086
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    new_dfa = ([[(0, 0), (1, 1), (2, 2)]], {0: 0, 1: 1, 2: 2})  # type: DFAS
    parser.push(1, new_dfa, 0, None)


# Generated at 2022-06-25 14:49:43.590084
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NAME
    value_0 = None
    context_0 = Context(None, None)
    expected_0 = False
    returned_0 = parser_0.addtoken(type_0, value_0, context_0)
    assert returned_0 == expected_0


# Generated at 2022-06-25 14:49:49.348490
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    parser_0 = None
    grammar_0 = module_0.Grammar()
    try:
        parser_0 = Parser(grammar_0)
        parser_0.setup()
    except:
        assert False
    success_0 = False
    try:
        success_0 = parser_0.addtoken(3, None, None)
    except:
        assert False
    assert not success_0


# Generated at 2022-06-25 14:50:05.617542
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    token_type = token.NAME
    token_value = "test string"
    newstate = 0
    context = Context(preceding=[], step=1)
    parser_0.shift(token_type, token_value, newstate, context)


# Generated at 2022-06-25 14:50:12.044138
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 0
    value_0 = ''
    context_0 = 0
    if parser_0.addtoken(type_0, value_0, context_0):
        raise RuntimeError
    elif parser_0.addtoken(type_0, value_0, context_0):
        raise RuntimeError
    elif parser_0.addtoken(type_0, value_0, context_0):
        raise RuntimeError


# Generated at 2022-06-25 14:50:18.036236
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    popnode = (None, None, None, [])
    parser_0.stack.append((None, 0, popnode))
    parser_0.pop()
    assert len(parser_0.stack) == 0


# Generated at 2022-06-25 14:50:21.743610
# Unit test for method shift of class Parser
def test_Parser_shift():
    """Unit test for method shift of class Parser."""
    parser_0 = Parser(module_0.Grammar())
    parser_0.shift(1, "str_0", 0, module_0.Context("str_1", 0))


# Generated at 2022-06-25 14:50:25.142914
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(start=None)
    parser_0.addtoken(type=30, value=None, context=Context(None, None))


# Generated at 2022-06-25 14:50:29.137355
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = int()
    value_0 = None
    newstate_0 = int()
    context_0 = Context()
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:50:35.435750
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser_0 = Parser(module_0.Grammar())
    context_0 = None
    value_0 = None
    type_0 = None
    parser_0.shift(type_0, value_0, 1, context_0)
    parser_0.shift(1, None, 2, context_0)
    # Branch
    parser_0.shift(type_0, value_0, 3, context_0)
    # Branch
    parser_0.shift(type_0, value_0, 4, context_0)


# Generated at 2022-06-25 14:50:46.136621
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_1 = 0
    value_1 = "L"
    context_1 = Context()
    parser_0.addtoken(type_1, value_1, context_1)
    # Check attribute used_names
    expected_0 = set("L")
    assert expected_0 == parser_0.used_names
    # Check attribute rootnode
    expected_1 = None
    assert expected_1 == parser_0.rootnode
    # Check attribute stack

# Generated at 2022-06-25 14:50:48.919892
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    # Constructor test - verify that grammar is properly initialized
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.grammar == grammar_0

# Generated at 2022-06-25 14:50:50.003325
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Test of method pop of class Parser
    assert 1 == 1


# Generated at 2022-06-25 14:51:09.170792
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.addtoken(token.NAME, 'NAME', Context(1, 2)) == False
    assert parser_0.addtoken(token.NAME, 'NAME', Context(1, 2)) == False
    assert parser_0.addtoken(token.NAME, 'NAME', Context(1, 2)) == True
    assert parser_0.addtoken(token.NAME, 'NAME', Context(1, 2)) == True
    assert parser_0.addtoken(token.NAME, 'NAME', Context(1, 2)) == True


# Generated at 2022-06-25 14:51:13.973660
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    token_0 = token.NAME
    value_0 = "abc"
    newstate_0 = int()
    context_0 = Context()
    parser_0.shift(token_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:51:16.541538
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert not parser_0.addtoken(0, None, None)


# Generated at 2022-06-25 14:51:17.944463
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_case_0()


import blib2to3.pgen2.pgen as module_0


# Generated at 2022-06-25 14:51:19.528427
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    #fail("Test if the testcase is working.")
    assert True == True # TODO: implement your test here


# Generated at 2022-06-25 14:51:21.761740
# Unit test for method classify of class Parser
def test_Parser_classify():
    p = Parser(Grammar(), convert=None)
    p.classify(1, "2", 3)

# Generated at 2022-06-25 14:51:28.188877
# Unit test for method shift of class Parser
def test_Parser_shift():

    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = tokenize_0.ERRORTOKEN
    value_0 = None
    newstate_0 = 0
    context_0 = Context((1,1))
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:51:33.141587
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Setup
    grammar_2 = module_0.Grammar()
    parser_2 = Parser(grammar_2)
    # Test 1
    parser_2.classify(token.NAME, '-', '-')
    # Test 2
    parser_2.classify(token.NAME, '>=', '>=')


# Generated at 2022-06-25 14:51:36.750720
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.addtoken(0, None, 0)
    assert parser_0.addtoken(0, None, 0)
    assert parser_0.addtoken(0, None, 0)


# Generated at 2022-06-25 14:51:39.134015
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 256
    value_0 = "hello"
    context_0 = module_0.Context()
    result_0 = parser_0.classify(type_0, value_0, context_0)
    assert result_0 == 256


# Generated at 2022-06-25 14:51:59.525844
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    grammar_0.start = 31339
    grammar_0.dfas = {31339: ([[(0, 1), (31339, 1)], [(1, 2)], [(2, 3)]], {31339: 0})}
    parser_0.setup(31339)
    parser_0.addtoken(105, '0', (10, 10))
    parser_0.addtoken(105, '1', (20, 20))
    parser_0.addtoken(105, '2', (30, 30))
    parser_0.addtoken(105, '3', (40, 40))
    parser_0.addtoken(105, '4', (50, 50))

# Generated at 2022-06-25 14:52:04.441472
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 2
    value_0 = ''
    context_0 = Context()
    int_0 = parser_0.classify(type_0, value_0, context_0)
    assert int_0 == 2


# Generated at 2022-06-25 14:52:11.706754
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()

    # Example for an exception
    #
    try:
        parser_0.pop()
    except Exception as inst_0:
        print('  Exception caught:', end='')
        print(type(inst_0))
        print('  Message:', end='')
        print(inst_0)
        print('  Stack trace:', end='')
        print(inst_0.__traceback__)
        print('', end='')
        print('  Comments:', end='')
        print('Pop a nonterminal.')
        print('  ', end='')
    #


# Generated at 2022-06-25 14:52:17.525452
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    stack_0 = parser_0.stack
    type_0 = parser_0.type
    value_0 = parser_0.value
    newstate_0 = parser_0.newstate
    context_0 = parser_0.context
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:52:21.843310
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = [(0, 0, None)]
    type_0 = 0
    value_0 = None
    context_0 = None
    newstate_0 = 0
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:52:24.650874
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 0
    value_0 = ''
    newstate_0 = 0
    context_0 = Context()
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:52:29.202294
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(6)
    parser_0.addtoken(1, 'this', Context(1))
    parser_0.addtoken(15, 1, Context(2))
    parser_0.addtoken(1, 1, Context(3))
    parser_0.addtoken(15, -1, Context(4))
    parser_0.addtoken(1, 'this', Context(5))
    parser_0.addtoken(1, 'this', Context(6))
    parser_0.addtoken(7, 'this', Context(7))
    parser_0.addtoken(1, 1, Context(8))
    parser_0.addtoken(1, 1, Context(9))
    parser_

# Generated at 2022-06-25 14:52:37.724435
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NAME
    value_0 = None
    context_0 = Context(previous_context=None, parent=None, rpart=None)
    context_1 = None
    value_1 = 'a'
    type_1 = token.NAME
    context_2 = Context(previous_context=None, parent=None, rpart=None)
    assert parser_0.classify(type_0, value_0, context_0) == 24
    context_1 = Context(previous_context=None, parent=None, rpart=None)
    assert parser_0.classify(type_1, value_1, context_2) == -1


# Generated at 2022-06-25 14:52:40.232731
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()

# Generated at 2022-06-25 14:52:48.776550
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_tokens_0 = [
        ( 1, "test_value_0", (1, 1)), ( 2, "test_value_1", (1, 1)), ( 3, "test_value_2", (1, 1)), ( 4, "test_value_3", (1, 1)), ( 5, "test_value_4", (1, 1)),
    ]
    for type_0, value_0, context_0 in test_tokens_0:
        label_0 = parser_0.classify(type_0, value_0, context_0)


# Generated at 2022-06-25 14:53:19.091346
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()

    parser.shift(1, "a", 0, None)
    parser.shift(1, "b", 1, None)
    parser.shift(1, "c", 2, None)
    parser.shift(1, "d", 3, None)

    print("\n")

# Generated at 2022-06-25 14:53:26.121698
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    newstate_0 = 0
    type_0 = 0
    context_0 = Context(prec=0, assign_as_id=False)

# Generated at 2022-06-25 14:53:27.780183
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()

# Generated at 2022-06-25 14:53:37.337698
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(token.INDENT, None, None)
    parser_0.addtoken(token.INDENT, None, None)
    parser_0.addtoken(token.INDENT, None, None)
    parser_0.addtoken(token.INDENT, None, None)
    parser_0.addtoken(token.INDENT, None, None)
    parser_0.addtoken(token.INDENT, None, None)
    parser_0.addtoken(token.INDENT, None, None)
    parser_0.addtoken(token.INDENT, None, None)
    parser_0.addtoken(token.INDENT, None, None)
   

# Generated at 2022-06-25 14:53:39.221113
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:53:41.870541
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Actual test setup
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.pop() == None


# Generated at 2022-06-25 14:53:46.400539
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    try:
        parser_0.addtoken(0, None, Context(None, None))
        assert False
    except ParseError as e:
        assert str(e) == "bad token: type=0, value=None, context=Context(None, None)"


# Generated at 2022-06-25 14:53:53.752366
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    parser_0 = Parser(module_0.Grammar())
    grammar_0 = module_0.Grammar()
    parser_0.grammar = grammar_0
    context_0 = Context()
    parser_0.addtoken(0, '', context_0)
    parser_0.addtoken(1, '', context_0)
    parser_0.addtoken(2, '', context_0)
    parser_0.addtoken(3, '', context_0)
    parser_0.addtoken(4, '', context_0)
    parser_0.addtoken(5, '', context_0)
    parser_0.addtoken(6, '', context_0)
    parser_0.addtoken(7, '', context_0)

# Generated at 2022-06-25 14:53:57.470517
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    parser_0 = Parser(None)
    parser_1 = Parser(None)
    parser_1._stack.append(((0, None), 0, None))
    parser_0.addtoken(None, None, None)
    parser_1.addtoken(None, None, None)


# Generated at 2022-06-25 14:54:03.453406
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 2
    newdfa_0 = []
    newstate_0 = 0
    context_0 = Context()
    try:
        parser_0.push(type_0, newdfa_0, newstate_0, context_0)
        raise Exception("expected failure")
    except ParseError:
        pass


# Generated at 2022-06-25 14:54:48.958266
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import random
    import heapq
    def _test_addtoken(self, _maxsize=maxsize):
        for _ in range(_maxsize):
            _num = random.randint(0, 0)
            _ret = self.addtoken(_num, _num, _num)


# Generated at 2022-06-25 14:54:50.525079
# Unit test for method setup of class Parser
def test_Parser_setup():
    parser = Parser([])
    assert parser.dfas == None
    parser.setup()
    assert parser.dfas != None


# Generated at 2022-06-25 14:55:00.738108
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert parser_0.classify(1, "test") == 1
    assert parser_0.classify(7, "test") == 7
    assert parser_0.classify(9, "test") == 9
    assert parser_0.classify(12, "test") == 12
    assert parser_0.classify(15, "test") == 15
    assert parser_0.classify(16, "test") == 16
    assert parser_0.classify(19, "test") == 19
    assert parser_0.classify(22, "test") == 22
    assert parser_0.classify(25, "test") == 25

# Generated at 2022-06-25 14:55:06.927311
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Initialize parser
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()

    # Run all token types through the parser
    for i in range(num_tokens):
        token: Any
        parser_1.addtoken(token.type, token.value, token.context)
    # Add end of block
    parser_1.addtoken(token.NEWLINE, token.NEWLINE, token.NEWLINE)

# Generated at 2022-06-25 14:55:12.178046
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    context_0 = Context()
    parser_0.addtoken(
        type_0 = 1,
        value_1 = "",
        context_2 = context_0,
    )


# Generated at 2022-06-25 14:55:14.449546
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.pop()


# Generated at 2022-06-25 14:55:19.166453
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newnode_0: RawNode = (None, None, None, [])
    newstate_0 = 0
    parser_0.stack[-1] = (None, None, newnode_0)
    parser_0.push(newnode_0, None, newstate_0, None)
    newnode_1: RawNode = (None, None, None, [])
    newstate_1 = 0
    parser_0.stack[-1] = (None, None, newnode_1)
    parser_0.push(newnode_1, None, newstate_1, None)
    newnode_2: RawNode = (None, None, None, [])
    newstate_2 = 0
    parser

# Generated at 2022-06-25 14:55:21.617487
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser_0 = Parser(None)
    parser_0.shift(None, None, None, None)


# Generated at 2022-06-25 14:55:24.486972
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = Parser(module_0.Grammar())
    parser_0.rootnode = []
    parser_0.stack = [[(None, None), 0, ()]]
    parser_0.pop()


# Generated at 2022-06-25 14:55:28.945620
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert parser_0.stack == [(grammar_0.dfas[256], 0, (256, None, None, []))]
    # Call method shift
    parser_0.shift(1, 'hi', 1, Context(None, None))
    assert parser_0.stack == [(grammar_0.dfas[256], 1, (256, None, None, []))]

# Generated at 2022-06-25 14:56:44.525732
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(0)


# Generated at 2022-06-25 14:56:46.572027
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(0, None, None)


# Generated at 2022-06-25 14:56:49.937822
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0, lam_sub)
    parser_0.setup(57)
    parser_0.addtoken(3, None, None)
    parser_0.addtoken(1, None, None)
    parser_0.addtoken(4, None, None)
    assert True

if __name__ == '__main__':
  test_Parser_addtoken()

# Generated at 2022-06-25 14:56:54.722244
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = blib2to3.pgen2.grammar.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    def do_asserts(expected_0, expected_1):
        assert expected_0 == parser_0.rootnode
        assert expected_1 == parser_0.used_names

    parser_0.addtoken(1, NL, Context(None, None))
    do_asserts(None, set())
    # Make sure we can add comments
    parser_0.addtoken(1, COMMENT, Context(None, None))
    do_asserts(None, set())
    parser_0.addtoken(1, NL, Context(None, None))
    do_asserts(None, set())

# Generated at 2022-06-25 14:56:57.599522
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = ""
    newdfa_0 = ()
    newstate_0 = 0
    context_0 = Context()
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:57:02.194902
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = Parser(module_0.Grammar())
    parser_0.stack[:] = [(module_0.dfas[0], 0, (0, None, None, []))]
    parser_0.pop()
    assert parser_0.rootnode is not None


# Generated at 2022-06-25 14:57:07.482909
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    # Try calling classify on a class instance
    type_1 = 0
    value_1 = "Test"
    context_1 = Context(preceding=())
    try:
        assert parser_0.classify(type_1, value_1, context_1) is None
    except ParseError:
        pass
    else:
        print('Expected exception')

# func_name: Test of suite name: Parser

# Generated at 2022-06-25 14:57:09.123164
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:57:12.670350
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.stack = [[None, 1, None, None], [None, 2, None, None]]
    parser.pop()
    assert parser.stack == [[None, 1, None, None]]
    parser.pop()
    assert parser.stack == []


# Generated at 2022-06-25 14:57:16.507877
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    token_type_0 = token.DEDENT
    token_val_0 = None
    token_ctx_0 = Context(0)
    ilabel_0 = parser_0.classify(token_type_0, token_val_0, token_ctx_0)
