

# Generated at 2022-06-25 14:48:19.784605
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    type_1 = (1)
    newdfa_1 = (([(1, 0), (0, 1)], [(0, 1), (0, 1)]), {0: 1, 1: 0})
    newstate_1 = (1)
    context_1 = None
    parser_1.push(type_1, newdfa_1, newstate_1, context_1)
    parser_1.push(type_1, newdfa_1, newstate_1, context_1)
    parser_1.push(type_1, newdfa_1, newstate_1, context_1)

# Generated at 2022-06-25 14:48:22.114408
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    start_0 = module_0.Grammar()
    parser_0.setup(start_0)


# Generated at 2022-06-25 14:48:25.401705
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Create a test Parser
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Call the method
    parser_0.pop()

# Generated at 2022-06-25 14:48:29.140935
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # The following line raises TypeError: can only concatenate list (not "int") to list
    parser_0.stack = (0)


# Generated at 2022-06-25 14:48:30.532727
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)


# Generated at 2022-06-25 14:48:36.707037
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa, state, node = ((), 0, (1, None, None, []))
    parser_0.stack = [(dfa, state, node)]
    parser_0.shift(1, '', 0)
    # This test passes by NOT raising an exception


# Generated at 2022-06-25 14:48:40.949340
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = list([[(0, 0)]])
    parser_0.stack = [((dfa_0, dict({})), 0, (0, None, None, None))]
    parser_0.shift(1, '2', 1, None)


# Generated at 2022-06-25 14:48:42.742097
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:48:47.190810
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    context_0 = Context()
    parser_0.shift(1, None, 0, context_0)
    parser_0.shift(2, None, 0, context_0)


# Generated at 2022-06-25 14:48:49.468337
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:49:02.205538
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Instance of class Grammar
    grammar_0 = Grammar()
    # Instance of class Parser
    parser_0 = Parser(grammar_0)
    # TODO need examples


# Generated at 2022-06-25 14:49:08.661904
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar as module_1
    grammar_0 = module_1.Grammar()
    parser_0 = Parser(grammar_0)
    stackentry = (grammar_0.dfas[56], 0, None)
    parser_0.stack = [stackentry]
    parser_0.pop()
    assert parser_0.stack[0] == stackentry
    parser_0.pop()
    assert parser_0.stack[0] == stackentry
    parser_0.pop()
    assert parser_0.stack[0] == stackentry
    parser_0.pop()
    assert parser_0.stack[0] == stackentry
    parser_0.pop()
    assert parser_0.stack[0] == stackentry
    parser_0.pop()

# Generated at 2022-06-25 14:49:11.647907
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack.append(('', 0, ''))
    parser_0.pop()


# Generated at 2022-06-25 14:49:14.264433
# Unit test for method pop of class Parser
def test_Parser_pop():
    try:
        parser_var_0 = Parser()
    except:
        pass
    else:
        return


# Generated at 2022-06-25 14:49:18.991752
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NAME
    value_0 = 'print'
    context_0 = Context()
    boolean_0 = parser_0.addtoken(type_0, value_0, context_0)


# Generated at 2022-06-25 14:49:20.970908
# Unit test for method pop of class Parser
def test_Parser_pop():
  parser_0 = Parser(module_0.Grammar())
  parser_0.setup()
  # Try default case
  parser_0.pop()

# Generated at 2022-06-25 14:49:25.390291
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 0
    newdfa_0 = (0, 0, 0, 0)
    newstate_0 = 0
    context_0 = 0
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:49:28.950031
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.push(42, grammar_0.dfas[42], 0, ((42, 42), 42))


# Generated at 2022-06-25 14:49:32.390707
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_case_0()
    with pytest.raises(ParseError):
        parser_0.addtoken(1, "")


# Generated at 2022-06-25 14:49:35.369192
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.addtoken(0, None, None)


# Generated at 2022-06-25 14:49:48.452186
# Unit test for method setup of class Parser
def test_Parser_setup():
    return None


# Generated at 2022-06-25 14:49:54.372159
# Unit test for method classify of class Parser
def test_Parser_classify():
    # unit test for Parser.classify
    parser_1 = Parser(test_grammar_1)
    assert parser_1.classify(token.NAME, "abc", (1,2)) == 257
    assert parser_1.classify(token.PLUS, "+", (1,2)) == 258
    assert parser_1.classify(token.MULT, "*", (1,2)) == 259
    assert parser_1.classify(token.NUMBER, "4", (1,2)) == 260


# Generated at 2022-06-25 14:50:00.929918
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser_1 = Parser()
    parser_1.setup()
    type_0 = token.NAME
    value_0 = 'a'
    newstate_0 = 1
    parser_1.shift(type_0, value_0, newstate_0, None)

# Generated at 2022-06-25 14:50:02.730149
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = Parser()
    parser_0.pop()


# Generated at 2022-06-25 14:50:04.980931
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser = Parser()
    parser.shift(type, value, newstate, context)



# Generated at 2022-06-25 14:50:07.287547
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser0 = Parser()
    parser0.shift(1, '+', 2, None)
    # assert parser0.stack == [(1, 2, 1)]


# Generated at 2022-06-25 14:50:10.782040
# Unit test for method classify of class Parser
def test_Parser_classify():
    type = int
    value = None
    context = Context
    parser_0 = Parser()
    parser_0.classify(type, value, context)
    parser_0.classify(type, value, context)


# Generated at 2022-06-25 14:50:21.300971
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Classify a token.
    # Turn a token into a label.
    p = Parser(parser_0)
    results = {}
    results[token.NAME] = token.NAME
    results[token.STRING] = token.STRING
    results[token.NUMBER] = token.NUMBER
    results[token.NEWLINE] = token.NEWLINE
    results[token.INDENT] = token.INDENT
    results[token.DEDENT] = token.DEDENT
    results[token.LPAR] = token.LPAR
    results[token.RPAR] = token.RPAR
    results[token.LSQB] = token.LSQB
    results[token.RSQB] = token.RSQB
    results[token.COLON] = token.COLON

# Generated at 2022-06-25 14:50:24.557157
# Unit test for method push of class Parser
def test_Parser_push():
    parser_0 = Parser()
    type_0 = str
    newdfa_0 = list
    newstate_0 = int
    parser_0.push(type_0, newdfa_0, newstate_0)



# Generated at 2022-06-25 14:50:25.795760
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_1 = Parser()
    parser_1.pop()


# Generated at 2022-06-25 14:50:42.185780
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    parser_0 = Parser()
    parser_0.setup(start=0)
    assert parser_0.addtoken(1, 2, 3) is False


# Generated at 2022-06-25 14:50:45.400583
# Unit test for method push of class Parser
def test_Parser_push():
    stack = []
    stack.append(1)
    parser = Parser(stack)
    parser.push('3', 'd', 4, 'sample context')
    return parser


# Generated at 2022-06-25 14:50:51.068107
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = Parser()
    grammar_0 = Grammar()
    dfa_0 = Grammar()
    dfa_0 = (((((0, 2),), (1, 5)), (((2, 2),), (3, 6))), ((((4, 3),), (5, 7)),))
    parser_0.grammar = grammar_0
    grammar_0.dfas = dfa_0
    parser_0.pop()
    parser_0.pop()


# Generated at 2022-06-25 14:50:57.901436
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NAME
    value_0 = "NodeTransformer"
    context_0 = Context(None, None)
    label_0 = parser_0.classify(type_0, value_0, context_0)
    assert len(label_0) == 1


# Generated at 2022-06-25 14:51:02.236392
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Verify that addtoken() raises an exception if the token is
    unknown."""
    parser = Parser(Grammar())
    context = Context()
    try:
        parser.addtoken(token.NUMBER, "1", context)
    except ParseError:
        return
    assert False, "unexpected token was accepted"

# Generated at 2022-06-25 14:51:06.270322
# Unit test for method push of class Parser
def test_Parser_push():
    parser_1 = Parser()
    parser_1.setup()
    type_0 = int()
    newdfa_0 = DFAS()
    newstate_0 = int()
    context_0 = Context()
    parser_1.push(type_0, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:51:09.029061
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    parser_0 = Parser()
    parser_0.setup(None)
    parser_0.addtoken(1, str(), None)


# Generated at 2022-06-25 14:51:10.486302
# Unit test for method setup of class Parser
def test_Parser_setup():
    parser_0 = Parser()
    parser_0.setup()


# Generated at 2022-06-25 14:51:12.915960
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = Parser()
    parser_0.pop()
    assert parser_0.stack[0] == (parser_0.dfa[1],)


# Generated at 2022-06-25 14:51:14.608421
# Unit test for method push of class Parser
def test_Parser_push():
    parser_0 = Parser()
    parser_0.push(int(), DFAS(), int())


# Generated at 2022-06-25 14:51:46.809777
# Unit test for method push of class Parser
def test_Parser_push():
    expr = Grammar(
        """
    test_1 = atom {op atom}* [ "?" test_1 ":" test_1 ]
    test_2 = atom {op atom}+ [ "?" test_2 ":" test_2 ]
    test_3 = atom | "[" exprlist_star "]"
    test_4 = atom {op atom}* { "?" test_4 ":" test_4 }
    test_5 = atom {op atom}+ { "?" test_5 ":" test_5 }
    exprlist_star = exprlist [ "," ]
    """
    )
    raise NotImplementedError


# Generated at 2022-06-25 14:51:51.175317
# Unit test for method push of class Parser
def test_Parser_push():
    parser_0 = Parser()
    type =  'abc'
    newdfa =  'abc'
    newstate =  11
    context =  'abc'
    parser_0.push(type, newdfa, newstate, context)


# Generated at 2022-06-25 14:51:57.153448
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from . import grammar, driver
    from blib2to3 import pytree

    # FIXME: Write a better test
    try:
        g = grammar.grammar
        p = driver.Driver(g, driver.convert)
        source = "x + 1"
        p.parse_string(source)
    except pytree.BaseError as exc:
        assert isinstance(exc, pytree.BaseError)
    else:
        assert False



# Generated at 2022-06-25 14:52:01.188981
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    parser_1 = Parser()
    assert parser_1.addtoken(400, 400, 400) == True
    assert parser_1.addtoken(400, 400, 400) == True
    assert parser_1.addtoken(400, 400, 400) == True


# Generated at 2022-06-25 14:52:02.106952
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    pass



# Generated at 2022-06-25 14:52:05.807710
# Unit test for method classify of class Parser
def test_Parser_classify():
    parser_0 = Parser()
    type_0 = token.NAME
    value_0 = str()
    context_0 = Context()
    parser_0.classify(type_0, value_0, context_0)


# Generated at 2022-06-25 14:52:06.661546
# Unit test for method classify of class Parser
def test_Parser_classify():
    parser_1 = Parser()



# Generated at 2022-06-25 14:52:07.812001
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = Parser()
    parser_0.pop()


# Generated at 2022-06-25 14:52:10.302413
# Unit test for method classify of class Parser
def test_Parser_classify():
    parser_0 = Parser()
    type = None
    value = None
    context = Context()
    parser_0.classify(type, value, context)


# Generated at 2022-06-25 14:52:12.897563
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = Parser(Grammar())
    parser_0.push(0, tuple(), 0, None)
    parser_0.pop()



# Generated at 2022-06-25 14:52:49.942463
# Unit test for method pop of class Parser
def test_Parser_pop():
    try:
        import blib2to3.pgen2.grammar as module_1
    except ImportError:
        import sys
        import os
        import os.path as path
        path_0 = path.join(os.environ["HOME"], "blib2to3", "src", "lib2to3")
        sys.path.append(path_0)
        import blib2to3.pgen2.grammar as module_1
    grammar_1 = module_1.Grammar()
    parser_1 = Parser(grammar_1)
    try:
        import blib2to3.pgen2.token as module_2
    except ImportError:
        import sys
        import os
        import os.path as path

# Generated at 2022-06-25 14:52:55.822759
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.shift(token.ENDMARKER, '', 0)
    parser_0.addtoken(token.NAME, '', '')
    try:
        parser_0.addtoken(token.NAME, '', '')
        parser_0.addtoken(token.NAME, '', '')
    except ParseError as err:
        stderr.write(str(err))
    parser_0.addtoken(token.NAME, '', '')
    parser_0.addtoken(token.ENDMARKER, '', '')

test_case_0()
test_Parser_shift()

# Generated at 2022-06-25 14:53:00.427120
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NUMBER
    value_0 = None
    newstate_0 = 0
    context_0 = None
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:53:03.422029
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()
    return parser_0.rootnode


# Generated at 2022-06-25 14:53:10.143782
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    parser_1.addtoken(5, "(", (0, 0))
    parser_1.addtoken(5, ")", (0, 0))
    parser_1.addtoken(5, "(", (0, 0))
    parser_1.addtoken(5, ")", (0, 0))
    parser_1.addtoken(5, "(", (0, 0))
    parser_1.addtoken(5, ")", (0, 0))
    parser_1.addtoken(5, "(", (0, 0))
    parser_1.addtoken(5, ")", (0, 0))
    parser_1.addtoken(5, "(", (0, 0))
   

# Generated at 2022-06-25 14:53:15.530378
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 1
    newdfa_0 = module_0.Grammar()
    newstate_0 = 1
    context_0 = Context()
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:53:18.696463
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Case 0
    # Case 1
    # Case 2
    # Case 3
    # Case 4
    # Case 5
    # Case 6
    # Case 7
    # Case 8
    # Case 9


# Generated at 2022-06-25 14:53:23.786450
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    converter_0 = lam_sub
    parser_0 = Parser(grammar_0, converter_0)
    parser_0.setup()
    boolean_0 = parser_0.addtoken(token.NAME, "NAME", (0, 0))
    assert boolean_0 == False
    parser_0.setup()
    boolean_1 = parser_0.addtoken(token.NAME, "NAME", (0, 0))
    assert boolean_1 == False



# Generated at 2022-06-25 14:53:26.744848
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    token.tok_name[0]
    parser.addtoken(0, None, module_0.Context(None, None, None))


# Generated at 2022-06-25 14:53:30.375767
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Setup
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Operation
    parser_1 = parser_0.addtoken(0, None, None)
    # Verification
    verify_true(parser_1)
    # Cleanup - N/A


# Generated at 2022-06-25 14:54:47.046853
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import unittest
    import sys
    import random
    import blib2to3.pgen2.token as module_0
    import blib2to3.pytree as module_1
    import blib2to3.pgen2.grammar as module_2
    import unittest.mock as module_3
    import blib2to3.pgen2.driver as module_4
    import blib2to3.pgen2.parse as module_5
    import blib2to3.pygram as module_6
    import blib2to3.pytree_utils as module_7
    import blib2to3.fixer_util as module_8
    import blib2to3.pgen2.convert as module_9
    import blib2to3.refactor as module_10
   

# Generated at 2022-06-25 14:54:54.243348
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Parameter: token, token
    assert parser_0.addtoken(2, None, 2) == False
    # Parameter: token, token
    assert parser_0.addtoken(1, None, 1) == False
    # Parameter: token, token
    assert parser_0.addtoken(0, None, 0) == True
    # Parameter: token, token
    assert parser_0.addtoken(0, None, 0) == True


# Generated at 2022-06-25 14:54:58.479661
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = [ [(0, 0)] ]
    state_0 = 0
    node_0 = (0, None, None, [])
    assert parser_0.pop() == ()


# Generated at 2022-06-25 14:55:01.026602
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:55:03.764689
# Unit test for method classify of class Parser
def test_Parser_classify():
    # TODO: Fill in this test stub.
    # Make sure that all methods are tested.
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.classify(0, None, None)


# Generated at 2022-06-25 14:55:08.748935
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    token_0 = token.NAME()
    context_0 = Context()
    parser_0.shift(token_0, 's', 0, context_0)


# Generated at 2022-06-25 14:55:09.558857
# Unit test for method setup of class Parser
def test_Parser_setup():
    test_case_0()

# Generated at 2022-06-25 14:55:15.970963
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 1
    value_0 = "1"
    context_0 = Context(preceding=None, special=""
                        , line_offset=0, file_encoding=""
                        , lines=[])
    parser_0.addtoken(type_0, value_0, context_0)

# Generated at 2022-06-25 14:55:23.539262
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0, state_0, node_0 = parser_0.stack[-1]
    assert parser_0.stack[-1] == (parser_0.grammar.dfas[1], 0, (1, None, None, []))
    parser_0.shift(0, '__0', 0, None)
    assert parser_0.stack[-1] == (parser_0.grammar.dfas[1], 0, (1, None, None, None))


# Generated at 2022-06-25 14:55:27.220519
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    def f():
        return False
    def f():
        return True
    assert parser_0.addtoken(1, 2, 3) == f(), 'Unit test for method addtoken of class Parser'


# Generated at 2022-06-25 14:56:49.786211
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 1
    value_0 = "m"
    context_0 = Context(None, 0)
    parser_0.addtoken(type_0, value_0, context_0)
    type_1 = 1
    value_1 = "m"
    context_1 = Context(None, 0)
    parser_0.addtoken(type_1, value_1, context_1)
    type_2 = 1
    value_2 = "m"
    context_2 = Context(None, 0)
    parser_0.addtoken(type_2, value_2, context_2)
    type_3 = 1
    value_3 = "m"

# Generated at 2022-06-25 14:56:51.664566
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    start_0 = None
    parser_0.setup(start_0)


# Generated at 2022-06-25 14:56:57.412575
# Unit test for method pop of class Parser
def test_Parser_pop():
    import blib2to3.pgen2.grammar as module_0
    import blib2to3.pgen2.token as module_1
    import blib2to3.pytree as module_2
    import blib2to3.pgen2.parse as module_3
    import blib2to3.pgen2.convert as module_4
    import blib2to3.fixer_base as module_5
    import blib2to3.fixer_util as module_6
    import blib2to3.patcomp as module_7
    import blib2to3.fixer_util as module_8
    import blib2to3.fixer_util as module_9
    import blib2to3.fixer_util as module_10
    import blib2to3.fixer

# Generated at 2022-06-25 14:57:00.771294
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    type_1 = 0
    value_1 = None
    context_1 = Context(previous_context=Context(), token_stack=())
    ret_1 = parser_1.addtoken(type_1, value_1, context_1)
    assert ret_1 is False


# Generated at 2022-06-25 14:57:04.647154
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.stack.append((0, 0, 0))
    parser_1.pop()
    assert_equals([], parser_1.stack)


# Generated at 2022-06-25 14:57:08.982832
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    node_0 = ((18, None, None, []) if (18) else [])
    tuple_5 = (grammar_0.dfas[18], 0, node_0)
    parser_0.stack = [tuple_5]
    parser_0.shift(token.ENDMARKER, None, 1, None) #Call function
    assert parser_0.stack[-1][1] == 1

# Generated at 2022-06-25 14:57:11.040727
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.push(None, None, None, None)


# Generated at 2022-06-25 14:57:13.878026
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = [(2,3,4), (2,3,4)]
    parser_0.pop()


# Generated at 2022-06-25 14:57:14.593348
# Unit test for method push of class Parser
def test_Parser_push():
    test_case_0()


# Generated at 2022-06-25 14:57:20.535208
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    popdfa_0 = module_0.DFAS()
    popstate_0 = module_0.NFAState()
    popnode_0 = module_0.ParseTree()
    parser_0.stack.append((popdfa_0, popstate_0, popnode_0))
    parser_0.pop()
