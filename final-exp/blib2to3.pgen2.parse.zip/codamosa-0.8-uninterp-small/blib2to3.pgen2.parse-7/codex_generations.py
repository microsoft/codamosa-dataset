

# Generated at 2022-06-25 14:48:08.719210
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:48:13.078081
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_1 = Parser(grammar_0)
    parser_0.pop()
    parser_1.pop()


# Generated at 2022-06-25 14:48:22.464270
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()
    parser_0.setup()
    parser_1 = Parser(grammar_0)
    parser_1.pop()
    parser_1.setup()


# Generated at 2022-06-25 14:48:24.780130
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.pop()

# Generated at 2022-06-25 14:48:25.710583
# Unit test for method pop of class Parser
def test_Parser_pop():
    test_case_0()


# Generated at 2022-06-25 14:48:27.934315
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)


# Generated at 2022-06-25 14:48:30.137456
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.addtoken()



# Generated at 2022-06-25 14:48:32.551377
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:48:40.574191
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    token_type_0 = 4
    token_value_0 = "."
    parser_1.classify(token_type_0, token_value_0, Context(context_type=0))
    token_type_1 = 11
    token_value_1 = "NUMBER"
    parser_1.classify(token_type_1, token_value_1, Context(context_type=0))
    parser_1.addtoken(token_type_0, token_value_0, Context(context_type=0))


# Generated at 2022-06-25 14:48:46.160877
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def _test_Parser_addtoken_case_0(self, type_0, value_0, context_0):
        pass
    def _test_Parser_addtoken_case_1(self, type_1, value_1, context_1):
        pass
    def _test_Parser_addtoken_case_2(self, type_2, value_2, context_2):
        pass


# Generated at 2022-06-25 14:48:51.758231
# Unit test for method setup of class Parser
def test_Parser_setup():
    assert True


# Generated at 2022-06-25 14:48:57.650944
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from blib2to3.pgen2 import tokenize
    from blib2to3.pgen2 import driver
    from blib2to3.pytree import convert
    from blib2to3.pygram import python_grammar, python_symbols, python_grammar_no_print_statement
    from blib2to3.pgen2 import token

    driver_0 = driver.Driver(python_grammar, convert)
    driver_0.load_grammar(python_grammar)
    driver_0.load_grammar(python_grammar_no_print_statement)

    driver_0.parse_string('print 3.2')
    driver_0.parse_string('print(1+1)')
    driver_0.parse_string('print 3.2, 3.2')
    driver_0

# Generated at 2022-06-25 14:49:01.922857
# Unit test for method pop of class Parser
def test_Parser_pop():
    # A test case for the method pop of class Parser
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    #
    # Call parser_0.pop()
    parser_0.pop()

import blib2to3.pgen2.parse as module_1


# Generated at 2022-06-25 14:49:03.100086
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = Parser(Grammar())
    parser_0.pop()

# Generated at 2022-06-25 14:49:07.641389
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    ilabel_0 = parser_0.classify(0, 0, 0)
    parsererror_0 = ParseError("too much input", 0, 0, 0)
    expect_error_0 = False

# Generated at 2022-06-25 14:49:11.905116
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    token_0 = token.Token(2, 'foo')
    parser_0.addtoken(token_0.type, token_0.string, token_0.context)


# Generated at 2022-06-25 14:49:16.070918
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar
    from . import token

    grammar_0 = grammar.Grammar()

    parser_0 = Parser(grammar_0)

    parser_0.rootnode

    parser_0.stack

    parser_0.convert

    parser_0.addtoken(1, "asdf", (1, 1))

    parser_0.stack

    parser_0.addtoken(1, "asdf", (1, 1))

    parser_0.stack

    parser_0.addtoken(1, "asdf", (1, 1))

    parser_0.stack

    parser_0.addtoken(1, "asdf", (1, 1))

    parser_0.stack

    # Parser.pop big-O = O(1)
    parser_0.stack
    parser_0.pop()


# Generated at 2022-06-25 14:49:19.757198
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    results_0 = parser_0.classify(0, None, None)
    assert results_0 == 0


# Generated at 2022-06-25 14:49:22.457773
# Unit test for method pop of class Parser
def test_Parser_pop():
    from . import grammar as _Module_0
    grammar_2 = _Module_0.Grammar()
    parser_1 = Parser(grammar_2)
    parser_1.pop()

# Generated at 2022-06-25 14:49:27.830188
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()
    parser_0.pop()
    parser_0.pop()
    parser_0.pop()
    parser_0.pop()
    parser_0.pop()
    parser_0.pop()
    parser_0.pop()
    parser_0.pop()


# Generated at 2022-06-25 14:49:35.196332
# Unit test for method pop of class Parser
def test_Parser_pop():
    # For a method, the stack trace will show the last
    # function called.
    parser = Parser(None)
    parser.pop()



# Generated at 2022-06-25 14:49:39.673198
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type = 0
    newstate = 0
    value = "test_value"
    context = Context("test_context")
    parser_0.shift(type, value, newstate, context)


# Generated at 2022-06-25 14:49:43.424930
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    try:
        parser_0.addtoken(0, None, Context(0, 0))
    except:
        pass


# Generated at 2022-06-25 14:49:47.038260
# Unit test for method pop of class Parser
def test_Parser_pop():
    module_0 = blib2to3.pgen2.grammar
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:49:52.123351
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.grammar as module_1
    grammar_1 = module_1.Grammar()
    import blib2to3.pytree as module_2
    context_2 = module_2.Context(((0, 1), (0, 2)))
    parser_1 = Parser(grammar_1)
    parser_1.shift(0, 0, 0, context_2)


# Generated at 2022-06-25 14:49:54.884844
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    name_0 = (0, 0)
    parser_0.push(0, name_0, 0, 0)


# Generated at 2022-06-25 14:50:03.108353
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    token_0 = token.NAME
    token_1 = token.NAME
    parser_1.push(token_0, token_1, 1, None)
    token_2 = token.NAME
    token_3 = token.NAME
    parser_1.push(token_2, token_3, 1, None)
    token_4 = token.NAME
    token_5 = token.NAME
    parser_1.push(token_4, token_5, 1, None)


# Generated at 2022-06-25 14:50:04.689086
# Unit test for method pop of class Parser
def test_Parser_pop():
    test_case_0()

# Generated at 2022-06-25 14:50:10.372737
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    module_0 = import_module('blib2to3.pgen2.grammar')
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # test for TypeError: argument 2 must be None or str, not int
    with raises(TypeError):
        parser_0.addtoken(int, None, Context(prec='file.py', line=1))


# Generated at 2022-06-25 14:50:17.691703
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    token_0 = token
    type_0 = 1
    value_0 = None
    context_0 = Text()
    try:
        parser_0.classify(type_0, value_0, context_0)
    except ParseError as err_0:
        raise AssertionError(
            "Uncaught ParseError in parser.py: {}".format(err_0)
        )

# Generated at 2022-06-25 14:50:33.862306
# Unit test for method pop of class Parser
def test_Parser_pop():
    # First test case
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:50:37.268334
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 14:50:45.230801
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    assert grammar_0._dfas[256] == [[(1, 1)], {1: [(0, 1)]}]
    parser_0 = Parser(grammar_0)
    context_0 = Context()
    parser_0.setup()
    parser_0.addtoken(1, None, context_0)
    assert parser_0.stack == []
    assert parser_0.rootnode is None


if __name__ == "__main__":
    test_case_0()
    test_Parser_pop()

# Generated at 2022-06-25 14:50:53.349765
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    grammar_1.tokens = {0: 0, 1: 1}
    grammar_2 = module_0.Grammar()
    parser_2 = Parser(grammar_2)
    grammar_4 = module_0.Grammar()
    parser_4 = Parser(grammar_4)
    assert parser_4.classify(0, 1, 2) == -1
    grammar_5 = module_0.Grammar()
    parser_5 = Parser(grammar_5)
    grammar_5.keywords = {0: 0, 1: 1}
    grammar_

# Generated at 2022-06-25 14:50:59.519269
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()

    # Push a nonterminal
    type_0 = int()
    newstate_0 = int()
    context_0 = Context()
    newdfa_0 = DFAS()
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)

    # Push a nonterminal
    type_1 = int()
    newstate_1 = int()
    context_1 = Context()
    newdfa_1 = DFAS()
    parser_0.push(type_1, newdfa_1, newstate_1, context_1)

    # Push a nonterminal
    type_2 = int()
    newstate_2

# Generated at 2022-06-25 14:51:02.121670
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.addtoken(0, 0, 0)


# Generated at 2022-06-25 14:51:07.916340
# Unit test for method push of class Parser
def test_Parser_push():
    # Given
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    type_1 = str()
    newdfa_1 = [list(list())]
    newstate_1 = int()
    context_1 = tuple()

    # When
    parser_1.push(type_1, newdfa_1, newstate_1, context_1)

    # Then


# Generated at 2022-06-25 14:51:09.029325
# Unit test for method pop of class Parser
def test_Parser_pop():
    test_case_0()

# Generated at 2022-06-25 14:51:11.258399
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.pop()


# Generated at 2022-06-25 14:51:14.068701
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.push(0, 0, 0, 0)



# Generated at 2022-06-25 14:51:34.957441
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    try:
        print("Testing Parser.addtoken")
        print("TODO")
    except (e):
        if isinstance(e, AssertionError):
            print("AssertionError")
        elif isinstance(e, Exception):
            print("Exception")


# Generated at 2022-06-25 14:51:44.622779
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    grammar_1.tokens={1024: 0, 1025: 1}
    grammar_1.labels={0: (1024, None), 1: (1025, None)}
    grammar_1.start=257
    grammar_1.keywords={}
    grammar_1.dfas={257: [((0, 0),), ((1, 1), (0, 1))]}
    parser_1.setup()
    assert parser_1.addtoken(token.NAME, None, None) == False
    assert parser_1.addtoken(token.EQUAL, None, None) == True
    grammar_2 = module_0.Grammar()
    parser_2 = Parser(grammar_2)
    parser

# Generated at 2022-06-25 14:51:46.498612
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:51:49.936817
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.addtoken(-1, None, None)



# Generated at 2022-06-25 14:51:53.285058
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.shift(0, None, 0, None)


# Generated at 2022-06-25 14:51:56.764170
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    int_0 = parser_0.push(0, None, 0, None)
    assert type(int_0) == int


# Generated at 2022-06-25 14:51:59.521035
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(0)


# Generated at 2022-06-25 14:52:04.181696
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    context_0 = Context()
    parser_0 = Parser(grammar_0)

# Generated at 2022-06-25 14:52:06.044008
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = Grammar()
    parser_0 = Parser(grammar_0)
    # assert something

# Generated at 2022-06-25 14:52:08.626268
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def test_case_0():
        grammar_0 = module_0.Grammar()
        parser_0 = Parser(grammar_0)
        parser_0.addtoken(1, None, None)


# Generated at 2022-06-25 14:52:27.420777
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Arrange
    grammar_0 = None
    parser_0 = None

    # Act
    grammar_0 = Grammar()
    parser_0 = Parser(grammar_0)
    try:
        parser_0.pop()
    except IndexError as e_0:
        pass
    else:
        raise AssertionError('Expected IndexError exception.')


# Generated at 2022-06-25 14:52:29.150615
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.push(256, (1, 1), 0, 0)

# Generated at 2022-06-25 14:52:31.697045
# Unit test for method pop of class Parser
def test_Parser_pop():
    """ test_case_1"""

    # init
    parser_0 = Parser(Grammar())

    # call
    parser_0.pop()

    # cleanup


# Generated at 2022-06-25 14:52:34.474896
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    grammar_0.tokens[0] = 1
    parser_0 = Parser(grammar_0)
    parser_0.shift(0, "", 1, "")


# Generated at 2022-06-25 14:52:36.553134
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:52:41.124998
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.pop()
    assert parser_1.classify(token.ADD, None, None) == 1
    assert parser_1.classify(token.NAME, 'if', None) == 1
    assert parser_1.classify(token.NAME, 'for', None) == 1
    assert parser_1.classify(token.NAME, 'foo', None) == 3


# Generated at 2022-06-25 14:52:48.113557
# Unit test for method classify of class Parser
def test_Parser_classify():
    name_0 = 'test_case_0'
    method_name_0 = 'Parser.classify'
    row_0 = [name_0, method_name_0]
    test_cases = [row_0]
    for row in test_cases:
        name = row[0]
        method_name = row[1]
        print(('Running ' + '`' + name + '`' + ' for ' + '`' + method_name + '`'))
        exec(name + '()')

# Generated at 2022-06-25 14:52:50.362834
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.addtoken(0, None, None)



# Generated at 2022-06-25 14:52:52.615168
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()

import blib2to3.pgen2.driver as module_0


# Generated at 2022-06-25 14:52:54.119661
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    pass


# Generated at 2022-06-25 14:53:33.246975
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.push(
        256, [
        [
            (1, 0), (1, 0), (1, 0), (1, 0), (1, 0), (1, 0), (1, 0), (1, 0)
        ]
    ], 0, None)
    parser_0.shift(1, b'3', 0, None)
    parser_0.shift(1, b'3', 0, None)
    parser_0.shift(1, b'3', 0, None)

# Generated at 2022-06-25 14:53:40.321134
# Unit test for method push of class Parser
def test_Parser_push():
    import blib2to3.pgen2.grammar as module_0
    import blib2to3.pgen2.pgen as pgen_0

    # Create a Grammar instance and load the grammar into it
    grammar_0 = module_0.Grammar()
    pgen_0.driver(pgen_0.grammar, grammar_0)

    # Create a parser instance
    parser_0 = Parser(grammar_0)

    # Make the parser ready for parsing
    parser_0.setup()

    # Parse a literal
    assert parser_0.addtoken(3, "Hello", None) == True


# Generated at 2022-06-25 14:53:46.012571
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    # Unit test for ParseError in method addtoken of class Parser
    try:
        parser_0.addtoken(0, None, None)
    except ParseError as e_0:
        if str(e_0) == 'bad token':
            pass
        else:
            raise RuntimeError('Exception thrown: ' + str(e_0))
    else:
        raise RuntimeError('Expected exception not thrown')


# Generated at 2022-06-25 14:53:49.703673
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    ctx = Context(('main.c', 1, 1, 'test-data/test_parser.py', 1), [])
    result = parser_0.addtoken(1, 'test', ctx)
    assert result == False


# Generated at 2022-06-25 14:53:57.504545
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Line: 1
    parser_0.addtoken(56, '', '')
    # Line: 2
    parser_0.addtoken(1, '', '')
    # Line: 3
    parser_0.addtoken(56, '', '')
    # Line: 4
    parser_0.addtoken(3, '', '')
    # Line: 5
    parser_0.addtoken(56, '', '')
    # Line: 6
    parser_0.addtoken(2, '', '')
    # Line: 7
    parser_0.addtoken(56, '', '')
    # Line: 8
    parser_0.addtoken(49, '', '')
    # Line

# Generated at 2022-06-25 14:54:02.025262
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.addtoken(token.NAME, 'NAME', Context(None, (1, 0), (1, 3)))


import blib2to3.pgen2.driver as module_1



# Generated at 2022-06-25 14:54:06.921196
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.classify(token.INDENT, token.INDENT, Context(preceding_line='')) == 4


# Generated at 2022-06-25 14:54:08.256548
# Unit test for method pop of class Parser
def test_Parser_pop():
    test_case_0()

import blib2to3.pgen2.grammar as module_1


# Generated at 2022-06-25 14:54:10.986041
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.setup(1)


# Generated at 2022-06-25 14:54:12.484360
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()



# Generated at 2022-06-25 14:54:55.720397
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.addtoken(0, "", (1, 1))
    parser_0.pop()


# Generated at 2022-06-25 14:55:02.157479
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(None)
    parser_0.addtoken(1, "1", (1, 1))
    parser_0.addtoken(2, "2", (1, 2))
    parser_0.push(3, (), 0, (1, 1))
    parser_0.push(4, (), 0, (1, 3))
    parser_0.pop()
    parser_0.pop()


# Generated at 2022-06-25 14:55:03.196625
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    class_0 = Parser(1)
    class_0.addtoken(1,1,1)


# Generated at 2022-06-25 14:55:04.891932
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser_0 = Parser(module_0.Grammar())
    parser_0.shift(0, None, 0, None)


# Generated at 2022-06-25 14:55:14.413457
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0_item_0 = Parser(grammar_0)
    # test method classify of class Parser
    parser_0_item_1 = parser_0_item_0.classify(token.NAME, "module", module_0.Grammar())
    test_result_0 = parser_0_item_1
    del grammar_0
    del parser_0_item_0
    del parser_0_item_1
    # assert test_result_0 == 1
    return test_result_0 == 1


# Generated at 2022-06-25 14:55:23.825163
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.stack[0][0][0] == (1, [])
    parser_0.addtoken(23, 'kappa', ((0, 0), (0, 0)))
    assert parser_0.stack[0][0][0] == (0, [(0, 0)])
    parser_0.addtoken(23, 'kappa', ((0, 0), (0, 0)))
    assert parser_0.stack[0][0][0] == (1, [])
    assert parser_0.stack[0][2][1] == None

    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)

# Generated at 2022-06-25 14:55:27.475088
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()

if __name__ == "__main__":
    print(__import__(__name__))



# Generated at 2022-06-25 14:55:32.913993
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Constructor test
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)

    # Method addtoken test
    grammar_2 = module_0.Grammar()
    parser_2 = Parser(grammar_2)
    parser_2.addtoken(124, "124", (1, 6))


# Generated at 2022-06-25 14:55:35.106022
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0, None)
    parser_0.pop()


# Generated at 2022-06-25 14:55:43.927670
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    year_1 = 2013
    month_2 = 9
    day_3 = 21
    date_1 = (year_1, month_2, day_3)
    date_2 = (year_1, month_2, day_3)
    date_3 = [year_1, month_2, day_3]
    date_4 = (date_1, date_2, date_3)
    for date_5 in date_4:
        print(date_5, end=' ')
    print()
    print(*date_4)


# Generated at 2022-06-25 14:56:25.991413
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    grammar_1.keywords[1] = 1
    grammar_1.tokens[2] = 2
    ilabel_0 = parser_1.classify(3, 4, 5)
    assert ilabel_0 == 2


# Generated at 2022-06-25 14:56:26.637122
# Unit test for method pop of class Parser
def test_Parser_pop():
    test_case_0()


# Generated at 2022-06-25 14:56:28.570838
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert_equal(parser_0.classify(token.NAME, "hi", None), 3)


# Generated at 2022-06-25 14:56:32.396948
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.push(9, grammar.dfas[9], 4, 0)
    assert parser.stack == [(grammar.dfas[9], 0, (9, None, 0, []))]


# Generated at 2022-06-25 14:56:36.088801
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    try:
        parser_0.push(None, None, None, None)
    except ParseError:
        pass
    else:
        assert False


# Generated at 2022-06-25 14:56:43.768256
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    converter_0 = lam_sub
    # parser_0.addtoken(262, 0, 277359296, 257,
    # "", "", "", "", None, None, None, None, None,
    # None, None, None, None, None, "", "", "", "",
    # None, None, None, None, None, None, None, None,
    # None, None, None, None, None, None, None, None,
    # None, None, None, None, None, None, None, None,
    # None, None, None, None, None, None, None, None,
    # None, None, None, None, None, None, None, None,
    # None, None

# Generated at 2022-06-25 14:56:45.838013
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.addtoken(type=None, value=None, context=None)
    print('PASS')


# Generated at 2022-06-25 14:56:48.035792
# Unit test for method pop of class Parser
def test_Parser_pop():
    print('Testing method pop of class Parser')
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()

import blib2to3.pgen2.grammar as module_0


# Generated at 2022-06-25 14:56:50.014539
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.classify(1, '1', Context(None, None))


# Generated at 2022-06-25 14:56:54.201914
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Test for method addtoken(int, string , context)
    #
    from . import token
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.addtoken(3, 'string', None)
    parser_0.addtoken(2, 'string', None)
    parser_0.addtoken(0, 'string', None)
    parser_0.addtoken(1, 'string', None)
    parser_0.addtoken(3, 'string', None)
