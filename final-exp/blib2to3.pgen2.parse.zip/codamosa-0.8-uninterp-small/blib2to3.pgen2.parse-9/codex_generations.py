

# Generated at 2022-06-25 14:48:13.132629
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = None
    value_0 = None
    newstate_0 = 0
    context_0 = None
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:48:18.205097
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = []
    parser_0.shift(262144, None, 0, None)
    assert parser_0.stack[0][1] == 0


# Generated at 2022-06-25 14:48:25.764310
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = 42
    value_0 = None
    context_0 = None
    assert parser_0.addtoken(type_0, value_0, context_0) == False
    type_1 = 42
    value_1 = None
    context_1 = None
    assert parser_0.addtoken(type_1, value_1, context_1) == True


# Generated at 2022-06-25 14:48:30.345473
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    context_0 = []
    newstate_0 = 0
    type_0 = 0
    parser_0.push(type_0, grammar_0.dfas, newstate_0, context_0)


# Generated at 2022-06-25 14:48:33.542301
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    # Case 1
    parser_1.addtoken(4, 'A', 4)


# Generated at 2022-06-25 14:48:36.753138
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.classify()


# Generated at 2022-06-25 14:48:48.237883
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    type_0 = token.NAME
    value_1 = None
    context_0 = Context()
    pytest.raises(ParseError, parser_1.classify, type_0, value_1, context_0)
    # Test that value is not None
    type_1 = token.NAME
    value_2 = "test"
    context_1 = Context()
    ilabel_0 = parser_1.classify(type_1, value_2, context_1)
    # Test that it's a reserved word
    type_2 = token.NAME
    value_3 = "None"
    context_2 = Context()

# Generated at 2022-06-25 14:48:53.099488
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    node_0 = [None]
    dfa_0 = (None, None)
    node_0[0] = [None, None, None, []]
    assert parser_0.shift(0, 0, 0, 0) == None
    assert parser_0.stack == [(dfa_0, 0, node_0[0])]

# Generated at 2022-06-25 14:48:55.720368
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 1
    value_0 = None
    context_0 = 0
    value_0 = parser_0.addtoken(type_0, value_0, context_0)


# Generated at 2022-06-25 14:48:58.914939
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack[0].append(parser_0.stack)
    parser_0.shift((0), (0), (0), (0))


# Generated at 2022-06-25 14:49:14.264562
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Initialize a Parser instance and call pop
    test_grammar = module_0.Grammar()
    test_parser = Parser(test_grammar)
    test_parser.stack = [(0, 0, None), (1, 0, None), (2, 0, None)]
    test_parser.stack[0][-1] = (0, None, None, [])
    test_parser.stack[1][-1] = (1, None, None, [1])
    test_parser.stack[2][-1] = (2, None, None, [2])
    test_parser.pop()
    assert len(test_parser.stack[-1][-1][-1]) == 2


# Generated at 2022-06-25 14:49:15.146379
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    assert True

# Generated at 2022-06-25 14:49:21.357980
# Unit test for method pop of class Parser
def test_Parser_pop():
    import blib2to3.pgen2.grammar as module_0
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = []
    state_0 = 0
    node_0 = (0, None, None, [])
    stackentry_0 = (dfa_0, state_0, node_0)
    parser_0.stack = [stackentry_0]
    parser_0.pop()


# Generated at 2022-06-25 14:49:22.519838
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:49:24.561702
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:49:30.553053
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = Grammar()
    parser = Parser(grammar)
    parser.stack = [
        (
            ([[(3, 1), (4, 1), (5, 1), (6, 1), (7, 1), (8, 1), (9, 1), (10, 1), (0, 1)]], {}),
            0,
            (1, None, None, None),
        )
    ]
    parser.pop()
    assert parser.stack == []


# Generated at 2022-06-25 14:49:34.014106
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.addtoken(0, None, Context(0, 0))
    parser_0.classify(0, None, Context(0, 0))


# Generated at 2022-06-25 14:49:35.106657
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_case_0()


# Generated at 2022-06-25 14:49:37.800436
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:49:47.811872
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Test argument types (invalid value)
    type_0 = 'Q'
    newdfa_0 = (['mjK', 'mjK', 'mjK', 'mjK', 'mjK', 'mjK'], {'x': 'mjK', 'S': 0, 'C': 4})

# Generated at 2022-06-25 14:50:04.773951
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Create a Parser instance
    grammar_2 = module_0.Grammar()
    parser_3 = Parser(grammar_2)
    # Create a stack of length 1
    stack_1 = []
    stack_1.append([])
    stack_1.append([])
    stack_1.append([])
    stack_1.append([])
    stack_1.append([])
    stack_1[0] = 1
    stack_1[1] = 2
    stack_1[2] = 3
    stack_1[3] = 4
    stack_1[4] = 5
    parser_3.stack = stack_1
    # Call the method
    token_type = 4
    token_value = 4
    dfa_state = 8
    context = 1

# Generated at 2022-06-25 14:50:12.988631
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(None)
    parser_0.addtoken(0, None, Context(0, 0))
    parser_0.addtoken(0, None, Context(0, 0))
    parser_0.addtoken(0, None, Context(0, 0))
    parser_0.addtoken(0, None, Context(0, 0))
    parser_0.addtoken(0, None, Context(0, 0))
    parser_0.addtoken(0, None, Context(0, 0))
    parser_0.addtoken(0, None, Context(0, 0))
    parser_0.addtoken(0, None, Context(0, 0))


# Generated at 2022-06-25 14:50:14.397718
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    print("Called addtoken")


# Generated at 2022-06-25 14:50:17.288963
# Unit test for method classify of class Parser
def test_Parser_classify():
    try:
        Parser.classify(0, 0, 0)
    except TypeError:
        pass
    else:
        AssertionError()


# Generated at 2022-06-25 14:50:19.225108
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)


# Generated at 2022-06-25 14:50:22.390093
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(None, None, None, None)


# Generated at 2022-06-25 14:50:26.373075
# Unit test for method classify of class Parser
def test_Parser_classify():
    from blib2to3.pgen2.generator import generate_grammar
    import sys
    import datetime
    startTime = datetime.datetime.now()
    grammar = generate_grammar(sys.argv[1])
    parser = Parser(grammar)
    parser.setup()

test_Parser_classify()

# Generated at 2022-06-25 14:50:33.461659
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.classify(token.NAME, None, Context(None, None))
    parser_0.classify(token.NAME, "xyz", Context(None, None))
    parser_0.classify(token.NAME, "xyz", Context(1, None))
    parser_0.classify(token.NAME, "xyz", Context(1, 1))
    parser_0.classify(token.NAME, "xyz", Context())
    parser_0.classify(token.NAME, None, Context())
    parser_0.classify(token.NAME, None, Context(1, None))
    parser_0.classify(token.NAME, None, Context(1, 1))
    parser_

# Generated at 2022-06-25 14:50:35.184311
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.classify(1, '', '')


# Generated at 2022-06-25 14:50:37.426123
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()

# Generated at 2022-06-25 14:50:46.259318
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:50:49.045126
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    # Initialization of the instance
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:50:51.185754
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:51:02.471965
# Unit test for method pop of class Parser
def test_Parser_pop():
    from blib2to3.pgen2.grammar import Grammar
    from blib2to3.pytree import Leaf, Node
    grammar = Grammar()
    parser = Parser(grammar)
    parser.setup()
    
    for newnode in (None, Leaf("a", 0, "test"), Node("test", [Leaf("a", 0, "test")])):
        parser.stack = [(0, 0, newnode)]
        parser.pop()
        assert parser.stack == []
        assert parser.rootnode is newnode
    
    parser.stack = [(0, 0, Leaf("a", 0, "test")), (0, 0, Leaf("b", 1, "test"))]
    parser.pop()
    assert parser.stack == [(0, 0, Leaf("a", 0, "test"))]

# Generated at 2022-06-25 14:51:03.616444
# Unit test for method shift of class Parser
def test_Parser_shift():
    # FIXME: not implemented
    pass


# Generated at 2022-06-25 14:51:05.611245
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_1 = Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()


# Generated at 2022-06-25 14:51:10.284756
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    try:
        parser_0.addtoken(1, None, None)
    except ValueError:
        pass


# Generated at 2022-06-25 14:51:12.399720
# Unit test for method push of class Parser
def test_Parser_push():
    a = Parser(None)
    # No argument types declared
    a.push(1, 2, 3, 4)


# Generated at 2022-06-25 14:51:13.596824
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:51:17.511771
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    # call
    parser_1.shift(0, 0, 0, 0)
    assert parser_1.stack == [(0, 0, (0, 0, 0, []))]


# Generated at 2022-06-25 14:51:36.113796
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = token.NAME
    value_0 = 'some_string'
    context_0 = Context(prec=0, flags=0)
    result = parser_0.classify(type_0, value_0, context_0)
    assert result == 256
    parser_0.addtoken(type_0, value_0, context_0)


# Generated at 2022-06-25 14:51:37.411395
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:51:41.665108
# Unit test for method push of class Parser
def test_Parser_push():

    grammar_0 = module_0.Grammar()

    parser_0 = Parser(grammar_0)
    # Pop a nonterminal.  (Internal)
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    
    parser_0.pop()    

# Generated at 2022-06-25 14:51:45.587187
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Testing case 0
    parser_1 = Parser(grammar_0)
    parser_1.addtoken(int, None, Context())
    # Testing case 1


# Generated at 2022-06-25 14:51:50.224204
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Setup test case
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    # Execute test case
    parser.pop()

import blib2to3.pgen2.driver as module_0


# Generated at 2022-06-25 14:51:55.139729
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    # Test case: No argument
    parser_0.addtoken()
    # Test case: All arguments
    parser_0.addtoken((24,), (None,), (Context,))


# Generated at 2022-06-25 14:51:58.212119
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0, value_0, context_0 = 0, None, None
    return parser_0.classify(type_0, value_0, context_0)


# Generated at 2022-06-25 14:52:08.209284
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    grammar_0.start = 256
    grammar_0.keywords = {}
    grammar_0.labels = [0, 256, 259, 265, 257]
    grammar_0.tokens = {259: 259, 257: 257, 265: 265}
    grammar_0.dfas = {256: (
        [[(1, 1), (2, 2)], [(3, 2), (-1, -1)], [(1, 2), (-1, -1)], [(0, 1), (0, 2)]],
        {1: 1, 2: 2}
    )}
    parser_0.setup()
    parser_0.classify = lambda type, value, context: type

# Generated at 2022-06-25 14:52:11.631732
# Unit test for method shift of class Parser
def test_Parser_shift():
    """
    Method shift of class Parser was called at least one time. It was called with:
        Parser.shift(type= , value= , newstate= , context= )
    """
    raise Exception("Automatically generated test")


# Generated at 2022-06-25 14:52:17.453297
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.push(token.NAME, (1, 2), 1, (1, 2))
    parser_0.push(token.EQUAL, (1, 2), 1, (1, 2))
    parser_0.push(token.RSQB, (1, 2), 1, (1, 2))


# Generated at 2022-06-25 14:52:46.817364
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.shift(1, "abc", 1, Context(1, None)) is None


# Generated at 2022-06-25 14:52:50.285055
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    stack = parser_0.stack
    parser_0.pop()
    if len(stack) > 0:
        stack.pop()


# Generated at 2022-06-25 14:52:53.986465
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_case_0()
    test_token_0 = token.NAME
    test_value_0 = 'b'
    test_context_0 = token.TokenInfo(1,1)
    parser_0.classify(test_token_0, test_value_0, test_context_0)

# Generated at 2022-06-25 14:52:58.975239
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newstate_0 = 0
    type_0 = 0
    newdfa_0 = parser_0.push(type_0, parser_0.grammar.dfas[type_0], newstate_0, parser_0.stack[-1][2][2])



# Generated at 2022-06-25 14:53:01.386254
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:53:03.966987
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:53:06.186975
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert isinstance(parser_0.addtoken(0, None, None), bool)


# Generated at 2022-06-25 14:53:08.729121
# Unit test for method push of class Parser
def test_Parser_push():
    test_case_0()
    parser_0 = Parser(module_0.Grammar())
    grammar_0 = module_0.Grammar()
    newdfa_0 = parser_0.grammar.dfas[parser_0.grammar.start]
    parser_0.push(parser_0.grammar.start, newdfa_0, 0, parser_0.grammar.context)


# Generated at 2022-06-25 14:53:15.018562
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    node_0_int = randint(0, 4294967295)
    node_0_float = random()
    node_0_complex = complex(node_0_int, node_0_float)
    node_0_slice = slice(0, 2, 1)
    node_0_list = [node_0_int, node_0_float, node_0_complex, node_0_slice]
    node_0_tuple = (node_0_int, node_0_float, node_0_complex, node_0_slice, node_0_list)
    node_0_set = set(node_0_tuple)

# Generated at 2022-06-25 14:53:17.410446
# Unit test for method setup of class Parser
def test_Parser_setup():

    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    start_0 = 0

    try:
        parser_0.setup(start_0)
    except:
        assert False



# Generated at 2022-06-25 14:54:18.555285
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    converter_0 = unicode
    parser_0 = Parser(grammar_0, converter_0)
    type_0 = 42
    value_0 = 'jKoD'
    context_0 = RawNode
    result_0 = parser_0.addtoken(type_0, value_0, context_0)
    assert result_0 == False


# Generated at 2022-06-25 14:54:22.033780
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    assert parser_1.addtoken(1, "hoge", 12) is False
    assert parser_1.addtoken(1, "hoge", 12) is False
    assert parser_1.addtoken(1, "hoge", 12) is True


# Generated at 2022-06-25 14:54:23.447575
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:54:24.843309
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:54:27.331904
# Unit test for method shift of class Parser
def test_Parser_shift():
    mo_0_grammar_0 = module_0.Grammar()
    mo_0_parser_0 = Parser(mo_0_grammar_0)
    mo_0_parser_0.shift(u"lala", None, 0, Context(u"", u"", 1, 0))


# Generated at 2022-06-25 14:54:30.865218
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    type_1 = 0
    value_1 = "hello world"
    newstate_1 = 1
    context_1 = blib2to3.pytree.Context
    parser_1.shift(type_1, value_1, newstate_1, context_1)


# Generated at 2022-06-25 14:54:31.492658
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    pass


# Generated at 2022-06-25 14:54:36.839049
# Unit test for method pop of class Parser
def test_Parser_pop():
  grammar_0 = module_0.Grammar()
  parser_0 = Parser(grammar_0)
  parser_0.stack.append({'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4})
  parser_0.pop()


# Generated at 2022-06-25 14:54:44.043612
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    token_0 = module_0.Token(34, [], {})
    parser_0.classify(34, None, {})
    # Sorted by line number
    parser_0.classify(34, None, module_0.Context(1, 2))
    parser_0.classify(34, None, module_0.Context(1, 2))
    parser_0.classify(34, None, module_0.Context(3, 4))
    token_1 = module_0.Token(34, [], {})
    parser_0.classify(34, None, module_0.Context(5, 6))

# Generated at 2022-06-25 14:54:47.146094
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = [(256, 10), (258, 20), (0, 0)]
    newdfa_0 = (dfa_0, {})
    newstate_0 = 0
    context_0 = None
    parser_0.push(0, newdfa_0, newstate_0, context_0)



# Generated at 2022-06-25 14:55:43.888933
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Add here your code
    pass


# Generated at 2022-06-25 14:55:45.030999
# Unit test for method pop of class Parser
def test_Parser_pop():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 14:55:52.368821
# Unit test for method push of class Parser
def test_Parser_push():
    # Setup
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = 1
    newdfa_0 = [(0, 1)]
    newstate_0 = 0
    context_0 = blib2to3.pytree.Context()
    # Precall

# Generated at 2022-06-25 14:55:54.572925
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(0, None, 0, None)


# Generated at 2022-06-25 14:56:00.835466
# Unit test for method shift of class Parser
def test_Parser_shift():
    dfa_0 = [[(0, 0)], [(0, 0)], [(0, 0)]]
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = [(dfa_0, 0, (0, None, None, None))]
    parser_0.stack[-1] = (dfa_0, 0, (0, None, None, None))
    parser_0.shift(0, None, 0, None)


# Generated at 2022-06-25 14:56:02.767998
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    parser_0 = Parser()
    # addtoken(type, value, context)
    # Unhandled exceptions: ParseError
    pass

# Generated at 2022-06-25 14:56:10.363306
# Unit test for method addtoken of class Parser

# Generated at 2022-06-25 14:56:12.383302
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.shift(1, None, 0, None)


# Generated at 2022-06-25 14:56:13.164652
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_case_0()

# Generated at 2022-06-25 14:56:18.762007
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    popdfa_0, popstate_0, popnode_0 = parser_0.stack.pop()
    newnode_0 = parser_0.convert(parser_0.grammar, popnode_0)
    if newnode_0 is not None:
        if parser_0.stack:
            dfa_0, state_0, node_0 = parser_0.stack[-1]
            assert node_0[-1] is not None
            node_0[-1].append(newnode_0)
        else:
            parser_0.rootnode = newnode_0
            parser_0.rootnode.used_names = parser_0.used_names