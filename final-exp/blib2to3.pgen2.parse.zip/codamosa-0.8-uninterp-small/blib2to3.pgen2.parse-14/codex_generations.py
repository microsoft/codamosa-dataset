

# Generated at 2022-06-25 14:48:08.110660
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)


# Generated at 2022-06-25 14:48:09.596341
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)


# Generated at 2022-06-25 14:48:11.904408
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_case_0()


# Generated at 2022-06-25 14:48:16.678648
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    try:
        raise RuntimeError("No exception was raised")
    except EOFError:
        pass
    except Exception as exc_0:
        assert False, exc_0


# Generated at 2022-06-25 14:48:21.172152
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    type_1 = token.NAME
    value_1 = "foo"
    context_1 = Context(prec=2)
    assert parser_1.classify(type_1, value_1, context_1) == 256


# Generated at 2022-06-25 14:48:25.179216
# Unit test for method setup of class Parser
def test_Parser_setup():
    test_case_0()

import blib2to3.pgen2.parser as module_1
import blib2to3.json.decoder as module_2
import blib2to3.pgen2.grammar as module_3


# Generated at 2022-06-25 14:48:27.163622
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()

# Generated at 2022-06-25 14:48:34.027191
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_type_0 = token.NAME
    test_value_0 = 'test_value_0'
    test_context_0 = Context(1, 2)
    test_addtoken_0 = parser_0.addtoken(test_type_0, test_value_0, test_context_0)
    assert isinstance(test_addtoken_0, bool)


# Generated at 2022-06-25 14:48:40.070776
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.driver as driver_0
    import blib2to3.pgen2.grammar as grammar_1
    import blib2to3.pytree as pytree_0
    driver_1 = driver_0.Driver(grammar_1.Grammar(), pytree_0.Convert)
    parser_1 = driver_1.parser
    parser_1.shift(1, None, 1, None)


# Generated at 2022-06-25 14:48:50.081874
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert grammar_0.start == 256

# Generated at 2022-06-25 14:48:58.460948
# Unit test for method pop of class Parser
def test_Parser_pop():
    def test(data: Sequence[int], start: int, context: Context) -> None:
        toktype, value, context = data
        parser_0.test_case_0(data, start, context)

# Generated at 2022-06-25 14:49:02.950144
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_2 = module_0.Grammar()
    parser_2 = Parser(grammar_2)
    parser_2.setup()
    test_0 = grammar_2.dfas
    test_1 = 0
    test_2 = module_0.Context()
    parser_2.push(test_0, test_1, test_2)


# Generated at 2022-06-25 14:49:09.175607
# Unit test for method push of class Parser
def test_Parser_push():
    def test_inner_method_0():
        grammar_0 = module_0.Grammar()
        parser_0 = Parser(grammar_0)
        parser_1 = Parser(grammar_0)
        def test_inner_method_1():
            grammar_1 = module_0.Grammar()
            parser_2 = Parser(grammar_1)
            parser_3 = Parser(grammar_1)
            for arg_1 in [parser_2, parser_3]:
                for arg_0 in [parser_2, parser_3]:
                    arg_0.push(0, 0, 0, 0)
        test_inner_method_1()
        def test_inner_method_2():
            grammar_2 = module_0.Grammar()

# Generated at 2022-06-25 14:49:11.520476
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:49:21.872513
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Test for method Parser.addtoken."""
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    context_0 = Context("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "")
    parser_0.setup()
    str_0 = "single"
    value_0 = str_0
    tk_0 = token.NAME
    context_1 = Context("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "")

# Generated at 2022-06-25 14:49:23.681330
# Unit test for method shift of class Parser
def test_Parser_shift():
    # The initial state of the parser
    parser_0 = Parser(module_0.Grammar())
    parser_0.setup()

    # The initial state of the token
    token_0 = (2, 3, None)
    parser_0.addtoken(2, 3, None)


# Generated at 2022-06-25 14:49:26.558315
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert parser_0.addtoken(1, None, None), "Expected True."
    assert parser_0.addtoken(2, None, None), "Expected True."
    assert parser_0.addtoken(3, None, None), "Expected True."


# Generated at 2022-06-25 14:49:28.949141
# Unit test for method setup of class Parser
def test_Parser_setup():
    # Implementation details
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:49:38.726322
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.shift(1, "1", 2, None)
    parser_0.addtoken(1, "1", None)
    parser_0.push(0, "0", 0, None)
    parser_0.addtoken(1, "1", None)
    parser_0.addtoken(1, "1", None)
    parser_0.addtoken(1, "1", None)
    parser_0.push(0, "0", 0, None)
    parser_0.addtoken(1, "1", None)
    parser_0.addtoken(1, "1", None)
    parser_0.push(0, "0", 0, None)

# Generated at 2022-06-25 14:49:40.851084
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = Grammar()
    parser_0 = Parser(grammar_0)
    try:
        parser_0.push(0, (0, 0), 0, Context(0,0,0))
    except ParseError:
        pass


# Generated at 2022-06-25 14:49:57.470750
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    stack_1 = (([[(1, 0), (0, 1)], []], 1, ('', None, None, None)),)
    parser_0.stack = stack_1
    dfa = parser_0.stack[-1][0]
    state = parser_0.stack[-1][1]
    node = parser_0.stack[-1][2]
    type = parser_0.stack[-1][2][0]
    value = parser_0.stack[-1][2][1]
    context = parser_0.stack[-1][2][2]
    newstate = 1
    parser_0.shift(type, value, newstate, context)


# Generated at 2022-06-25 14:50:03.324053
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.rootnode = Node(type=grammar_0.start, children=[], context=None)

# Generated at 2022-06-25 14:50:06.981074
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import libfuturize.fixer_util as libfuturize_fixer_util
    grammar_0 = libfuturize_fixer_util.grammar
    parser_0 = Parser(grammar_0)

# Generated at 2022-06-25 14:50:10.546584
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.push(0,0,0,0)
    parser_0.shift(0,0,0,0)

# Generated at 2022-06-25 14:50:12.645580
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:50:17.016104
# Unit test for method pop of class Parser
def test_Parser_pop():

    # >> TEST: pop an empty stack
    grammar = Grammar()
    parser = Parser(grammar)

    try:
        parser.pop()
        assert False # Should never get here!
    except IndexError:
        pass


# Generated at 2022-06-25 14:50:20.204415
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, 1, 1)


# Generated at 2022-06-25 14:50:24.509021
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.STRING
    value_0 = ''
    context_0 = Context()
    assert not parser_0.addtoken(type_0, value_0, context_0)


# Generated at 2022-06-25 14:50:27.002045
# Unit test for method pop of class Parser
def test_Parser_pop():

    # Unit test setup
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    # unit test
    parser_0.pop()


# Generated at 2022-06-25 14:50:29.931872
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    result_0 = parser_0.pop()
    expect_0 = None
    assert result_0 == expect_0


# Generated at 2022-06-25 14:50:46.567291
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Test w/ empty parser stack
    # Expecting ValueError to be raised
    try:
        parser_0.shift(1, 2, 3, 4)
        assert False, "Expected ValueError to be raised"
    except ValueError as exc:
        assert str(exc) == 'invalid stack index', \
            "Expected ValueError to be raised"
    parser_0.setup()
    assert len(parser_0.stack) == 1, "AssertionError: {}".format(len(parser_0.stack))
    # Push a nonterminal
    parser_0.push(5, 6, 7, 8)

# Generated at 2022-06-25 14:50:49.326444
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # call to shift
    parser_0.shift(246, "test", 1, None)

# Generated at 2022-06-25 14:50:56.168964
# Unit test for method classify of class Parser
def test_Parser_classify():
    from . import token
    from .parser import Parser, ParseError
    from . import grammar
    from . import driver
    from blib2to3 import pytree
    # Get a token map for the builtin grammar
    tmap = dict((str(t), getattr(token, t)) for t in grammar.tok_name)
    p = Parser(grammar.builtin_grammars["python" + driver.PYTHON_VERSION[0:1]])
    g = p.grammar
    p.setup()
    # Test classification of names
    assert p.classify(tmap['NAME'], 'x', pytree.leaf("NAME", "x")) == g.labels[2][0]

# Generated at 2022-06-25 14:50:57.169342
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_case_0()


# Generated at 2022-06-25 14:51:01.242571
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type = int()
    value = None
    newstate = int()
    context = Context()
    parser_0.shift(type, value, newstate, context)


# Generated at 2022-06-25 14:51:11.400801
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    paren_0 = u'('
    type_0 = token.OP
    value_0 = paren_0
    newstate_0 = 0
    paren_0 = u'('
    type_0 = token.OP
    value_0 = paren_0
    newstate_0 = 0
    context_0 = Context(0, 1)
    parser_0.shift(type_0, value_0, newstate_0, context_0)
    paren_0 = u'('
    type_0 = token.OP
    value_0 = paren_0
    newstate_0 = 0
    context_0 = Context(0, 3)

# Generated at 2022-06-25 14:51:14.189752
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(type, value, newstate, context)

# Generated at 2022-06-25 14:51:16.726843
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    parser_0.push(None, None, None, None)


# Generated at 2022-06-25 14:51:21.802780
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.used_names = set()
    parser_0.rootnode = None

    parser_0.stack = []
    parser_0.shift(type=0, value=None, newstate=0, context=None)

    assert parser_0.rootnode is None
    assert len(parser_0.stack) == 0


# Generated at 2022-06-25 14:51:24.927066
# Unit test for method shift of class Parser
def test_Parser_shift():
    
    # Set-up code
    grammar_0 = module_0.Grammar(grammar_0)
    parser_0 = Parser(grammar_0)


# Generated at 2022-06-25 14:51:39.912846
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:51:42.956121
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = []
    parser_0.pop()


# Generated at 2022-06-25 14:51:47.083636
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NEWLINE
    value_0 = None
    context_0 = Context(previous_context=None, this_context=None)
    assert parser_0.addtoken(type=type_0, value=value_0, context=context_0) == False


# Generated at 2022-06-25 14:51:57.456350
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    grammar_0.dfas[0] = ((((), ()), (((), ()), ())), {0: 0, 1: 0})
    dict_0 = dict()
    dict_0[0] = ((((), ()), (((), ()), ())), {0: 0, 1: 0})
    dict_0[1] = ((((), ()), (((), ()), ())), {0: 0, 1: 0})
    dict_0[2] = ((((), ()), (((), ()), ())), {0: 0, 1: 0})
    dict_0[3] = ((((), ()), (((), ()), ())), {0: 0, 1: 0})

# Generated at 2022-06-25 14:52:07.552788
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    # First call for method push
    parser_1.push(3, (1, {}), 0, None)
    # First call for method shift
    parser_1.shift(7, 'ty', 1, None)
    # Second call for method shift
    parser_1.shift(7, 'ty', 1, None)
    # Third call for method shift
    parser_1.shift(7, 'ty', 1, None)
    # Second call for method push
    parser_1.push(3, (1, {}), 0, None)
    # First call for method pop
    parser_1.pop()
    # Call for method shift
    parser_1.shift(3, 'ty', 0, None)
    #

# Generated at 2022-06-25 14:52:12.180821
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = int()
    newdfa_0 = [(0, 0), (1, 0), (2, 0), (1, 1), (2, 1), (0, 1)]
    newstate_0 = int()
    context_0 = Context()
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:52:16.130960
# Unit test for method shift of class Parser
def test_Parser_shift():
    test_case_0()
    parser_0.shift(0,
        None,
        0,
        Context(prec=None,
            filename=None,
            flags=0,
            assign_column=-1,
            line_offset=0))


# Generated at 2022-06-25 14:52:23.622870
# Unit test for method push of class Parser
def test_Parser_push():
    
    # Setup the parser's state
    p = Parser(grammar_0, convert=None)
    p.setup(start=1)
    dfa = 1
    state = 2
    context = None
    newdfa = [(3, 4), (5, 6)]
    newstate = 7
    node = (1, 2, 3, 4)
    p.stack = [dfa, state, node]
    type = 8
    
    
    
    
    # Call the method
    try:
        p.push(type, newdfa, newstate, context)
    except ParseError:
        pass
    
    # Compare the parser's state to the expected state
    assert p.stack == [dfa, state, node, (newdfa, 0, (type, None, context, []))]

#

# Generated at 2022-06-25 14:52:30.135414
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = list()
    state_0 = 0
    node_0 = [0, None, None, []]
    parser_0.stack.append((dfa_0, state_0, node_0))
    type_0: int = 0
    value_0: Optional[str] = None
    newstate_0: int = 0
    context_0: Context = Context(0, '', '')
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:52:32.741459
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:52:47.695114
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 1
    value_0 = 'abc'
    context_0 = Context()
    assert False == parser_0.addtoken(type_0, value_0, context_0)


# Generated at 2022-06-25 14:52:51.499745
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup(None)

    # Call method
    parser_1.push(None, None, None, None)


# Generated at 2022-06-25 14:52:58.232461
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    def addtoken_0(type_0, value_0, context_0):
        return parser_0.addtoken(type_0, value_0, context_0)
    class dummy_context_0():
        def __init__(self):
            self.node_0 = None
        def __getattr__(self, name_0):
            return None
    addtoken_0(0, None, dummy_context_0())


# Generated at 2022-06-25 14:53:04.308700
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Test types for method addtoken of class Parser
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    token_0 = token.NUMBER
    value_0 = str()
    context_0 = Context(0)
    ret_0 = parser_0.addtoken(token_0, value_0, context_0)

    # Test whether the return value is of type bool
    assert ret_0 is bool()


# Generated at 2022-06-25 14:53:10.753535
# Unit test for method classify of class Parser

# Generated at 2022-06-25 14:53:15.602593
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = None
    value_0 = None
    context_0 = None
    # Expecting TypeError:
    try:
        parser_0.classify(type_0, value_0, context_0)
    except TypeError:
        pass


# Generated at 2022-06-25 14:53:17.363881
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:53:24.822255
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Create a Parser instance
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    # Check if shift() raises an error
    try:
        parser_1.shift(0, '', 1)
    except:
        pass
    # Setup the parser
    parser_1.setup()
    # Prepare for parsing
    dfa_0, first_0 = grammar_1.dfas[grammar_1.start]
    stackentry_0 = (dfa_0, 0, (grammar_1.start, None, None, []))
    parser_1.stack = [stackentry_0]
    # Call shift()
    parser_1.shift(1, 'hi', 1)
    # Verify the state of the parser

# Generated at 2022-06-25 14:53:30.297596
# Unit test for method pop of class Parser
def test_Parser_pop():
    """
    Provide a test case for method test_Parser.pop of class Parser.
    """
    start_0 = None
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(start_0)
    type_0 = None
    value_0 = None
    context_0 = module_0.Context()
    parser_0.addtoken(type_0, value_0, context_0)
    parser_0.pop()


# Generated at 2022-06-25 14:53:34.981414
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_case_0()

from typing import overload, Sequence, Any, Union
from blib2to3.pgen2.grammar import Grammar
from blib2to3.pytree import Context

from .token import Token
from .token import tok_name
from .tokenize import tokenize



# Generated at 2022-06-25 14:53:47.773132
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(1, None, 2, None)

# Generated at 2022-06-25 14:53:49.365715
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser_0 = Parser(module_0.Grammar())
    parser_0.shift(0, None, 0, None)


# Generated at 2022-06-25 14:53:51.868488
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.addtoken(1, None, Context(None, None))
    assert grammar_0 == grammar_0


# Generated at 2022-06-25 14:53:53.937509
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.shift(token.NUMBER, "NUMBER", 0, (1, 1))


# Generated at 2022-06-25 14:53:58.488128
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    dfa_0 = []
    newdfa_0 = (dfa_0, {})
    parser_0.push(None, newdfa_0, None, None)


# Generated at 2022-06-25 14:54:04.895342
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = grammar_0.tokens.get(token.NAME)
    newdfa_0 = grammar_0.dfas[type_0]
    context_0 = Context()
    parser_0.push(type_0, newdfa_0, 0, context_0)


# Generated at 2022-06-25 14:54:07.299831
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:54:08.079018
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_case_0()


# Generated at 2022-06-25 14:54:12.823469
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 0
    value_0 = ""
    context_0 = 0
    int_0 = parser_0.classify(type_0, value_0, context_0)
    if type_0 == 0 and value_0 == "" and context_0 == 0:
        assert int_0 == 0
    else:
        assert int_0 == 0



# Generated at 2022-06-25 14:54:18.144875
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def test_case_0():
        grammar_0 = module_0.Grammar()
        parser_0 = Parser(grammar_0)
        parser_0.setup()
        # The calling sequence for addtoken is addtoken(*token)
        # where token is a token tuple as returned by tokenize.generate_tokens().
        parser_0.addtoken(type=1, value="hi", context=None)
        parser_0.addtoken(type=0, value="hi", context=None)


# Generated at 2022-06-25 14:54:39.701834
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    stack_0 = []
    parser_0.push(0, None, 0, None, stack_0)


# Generated at 2022-06-25 14:54:41.214034
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:54:44.928127
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = int()
    newdfa_0 = DFAS()
    newstate_0 = int()
    context_0 = Context()
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)

# Generated at 2022-06-25 14:54:46.580088
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # TODO: Update to test
    # expected = 42
    # my_parser = Parser()
    # actual = my_parser.addtoken()
    # assert actual == expected
    assert True


# Generated at 2022-06-25 14:54:57.005491
# Unit test for method shift of class Parser
def test_Parser_shift():
    # from pgen2.parser import Parser
    # from pgen2.grammar import Grammar
    # from pgen2.token import token

    # NOTE: This test uses a hand-made, hard-coded grammar and parsing table.
    #       This should be replaced by a test with a real, generated table.

    # A hand-made grammar.
    # It has a single nonterminal 'start', which is expanded to an integer
    # or an expression. An expression is an additive combination of integers
    # ('+' integers).
    # An integer is a sequence of digits.

    grammar = Grammar()

# Generated at 2022-06-25 14:55:04.854253
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(8)
    parser_0.addtoken(token.INDENT, "INDENT", None)
    parser_0.addtoken(token.NAME, "NAME", None)
    parser_0.addtoken(token.NAME, "NAME", None)
    parser_0.addtoken(token.DOT, "DOT", None)
    parser_0.addtoken(token.NAME, "NAME", None)
    parser_0.addtoken(token.NAME, "NAME", None)
    parser_0.addtoken(token.DOT, "DOT", None)
    parser_0.addtoken(token.NAME, "NAME", None)

# Generated at 2022-06-25 14:55:15.895111
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Tests that the right number of nodes are popped off the stack given
    # a specific grammar and input.
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    parser_1.addtoken(1, '1', (1, 1))
    parser_1.addtoken(2, '2', (1, 2)) # test_case_1
    parser_1.addtoken(3, '3', (1, 3))
    parser_1.pop() #test_case_2
    parser_1.pop() #test_case_3
    parser_1.pop() #test_case_4

import blib2to3.pytree as module_1


# Generated at 2022-06-25 14:55:20.180289
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = [((1, 0),)]
    parser_0.stack = [((dfa_0, {}), 0, (0, None, None, []))]
    parser_0.pop()



# Generated at 2022-06-25 14:55:23.631887
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Setup
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Test columns
    assert parser_0.rootnode == None
    assert parser_0.stack == []

# Generated at 2022-06-25 14:55:26.511400
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Setup
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # AssertionError: None
    try:
        assert parser_0.shift == None
    except AssertionError:
        pass


# Generated at 2022-06-25 14:55:57.624711
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    int_0 = token.NAME
    str_0 = '3,4,5'
    context_0 = Context()
    try:
        parser_0.addtoken(int_0, str_0, context_0)
    except ParseError as error:
        print('Error: test_Parser_addtoken')
        print('ParseError: ' + error.msg)


# Generated at 2022-06-25 14:55:58.930447
# Unit test for method shift of class Parser
def test_Parser_shift():
    pass


# Generated at 2022-06-25 14:56:03.338127
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_17 = token.NAME
    value_17 = "a"
    newstate_17 = 0
    context_17 = "abc"
    parser_0.shift(type_17, value_17, newstate_17, context_17)


# Generated at 2022-06-25 14:56:07.593718
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Test 0:
    #   dfa = 0
    #   state = 0
    #   type = 0
    #   value = 0
    #   newstate = 0
    #   context = 0
    print(parser_0.shift(0, 0, 0, 0))

# Generated at 2022-06-25 14:56:08.749194
# Unit test for method pop of class Parser
def test_Parser_pop():
    class_under_test = Parser(None)
    class_under_test.pop()


# Generated at 2022-06-25 14:56:15.508902
# Unit test for method pop of class Parser
def test_Parser_pop():
    import unittest
    import sys
    import io

    class TestParser_pop(unittest.TestCase):
        def test_0(self):
            grammar_0 = module_0.Grammar()
            parser_0 = Parser(grammar_0)
            # Capturing stdout
            buffer_0 = io.StringIO()
            sys.stdout = buffer_0
            try:
                # Executing method pop of class Parser
                parser_0.pop()
            finally:
                # Recovering stdout
                sys.stdout = sys.__stdout__
            # Asserting stdout
            self.assertEqual(buffer_0.getvalue(), 'Exception: AssertionError()\n')
    # Running test case
    test_case_0 = TestParser_pop()
    test_case_

# Generated at 2022-06-25 14:56:18.343962
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:56:21.764590
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NAME
    assert parser_0.shift(type_0, "foobar", 1, Context(None, None)) == None


# Generated at 2022-06-25 14:56:24.852433
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newdfa_0 = None
    newstate_0 = 0
    context_0 = module_0.Context()
    type_0 = 0
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:56:25.519663
# Unit test for method push of class Parser
def test_Parser_push():
    test_case_0()


# Generated at 2022-06-25 14:57:20.497877
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:57:24.874257
# Unit test for method shift of class Parser
def test_Parser_shift():
    dfa_0 = []
    state_0 = 0
    node_0 = (None, None, None, None)
    stack_0 = [(dfa_0, state_0, node_0)]
    parser_0 = Parser(Grammar())
    parser_0.stack = stack_0
    parser_0.shift(1, None, 2, None)


# Generated at 2022-06-25 14:57:27.319755
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:57:29.439098
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.shift(4, 'test', 1, 'context')


# Generated at 2022-06-25 14:57:35.639890
# Unit test for method push of class Parser
def test_Parser_push():
    g = Grammar()
    p = Parser(g)
    p.setup()
    p.stack.append(((0,), 0, (0, None, None, [])))
    p.push(0, '', 0, None)
    assert len(p.stack) == 2
    # Check that there are no extra object references in the push() stack
    assert (len(p.stack[0]) == 3) == True
    assert (len(p.stack[1]) == 3) == True

# Generated at 2022-06-25 14:57:40.828051
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    dfa = [[(0, 1)], []]
    parser.stack = [(dfa, 0, (257, None, None, []))]
    parser.shift(token.ENDMARKER, "", 1)
    dfa = [[(1, 1), (0, 2)], [(0, 2)]]
    parser.stack = [(dfa, 1, (257, None, None, []))]
    parser.shift(token.ENDMARKER, "", 2)
    assert parser.stack == [(dfa, 2, (257, None, None, []))]


# Generated at 2022-06-25 14:57:45.040644
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(None)
    type_0 = 584
    value_0 = 'BOOL'
    newdfa_0 = DFA(newstate=0)
    stack_0 = Stack()
    popdfa_0 = DFA(newstate=0)
    popstate_0 = 0
    dfa_0 = DFA(newstate=0)
    assert newnode is ...  # TODO: implement this test
    assert parser_0.stack == [dfa_0]


# Generated at 2022-06-25 14:57:48.629792
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.push(3, None, 8, None)
    parser_1.pop()

# Generated at 2022-06-25 14:57:50.634197
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(0, None, 0, None)


# Generated at 2022-06-25 14:57:53.487825
# Unit test for method push of class Parser
def test_Parser_push():
  parser_0 = Parser(Grammar())
  parser_0.setup()
  parser_0.push(256,(([(256, 0)], set([256])), {}), 0, Context())
  pass
