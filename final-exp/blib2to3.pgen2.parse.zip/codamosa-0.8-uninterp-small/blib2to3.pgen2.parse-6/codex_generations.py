

# Generated at 2022-06-25 14:48:16.512205
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(token.PRINT, 'PRINT', (7, 0))
    parser_0.addtoken(token.NAME, 'print', (7, 6))
    parser_0.addtoken(token.RARROW, '->', (7, 12))
    parser_0.addtoken(token.NAME, 'print', (7, 15))
    parser_0.addtoken(token.DEDENT, 'DEDENT', (7, 21))
    parser_0.addtoken(token.ENDMARKER, 'ENDMARKER', (8, 0))


# Generated at 2022-06-25 14:48:19.230873
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert type(parser_0.pop()) is None


# Generated at 2022-06-25 14:48:22.743167
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()
    assert parser_0


# Generated at 2022-06-25 14:48:27.073050
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Call method classify of class Parser
    method_result_0 = parser_0.classify(0, None, None)
    assert method_result_0 == 0


# Generated at 2022-06-25 14:48:29.851421
# Unit test for method classify of class Parser
def test_Parser_classify():
    # test case 0
    test_case_0()


if __name__ == "__main__":
    # Run python tests
    # test_Parser_classify()
    pass

# Generated at 2022-06-25 14:48:32.294012
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser_0 = Parser(None, None)
    # test function
    parser_0.shift(1, None, None, None)


# Generated at 2022-06-25 14:48:34.989826
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:48:36.883525
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 14:48:48.280127
# Unit test for method shift of class Parser
def test_Parser_shift():

    # Test 1: shift a token as the only node
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup(256)
    parser_1.addtoken(1, "one", (1, 0))
    assert parser_1.rootnode.type == 256
    assert parser_1.rootnode[0].type == 1
    assert parser_1.rootnode[0].value == "one"

    # Test 2: shift two tokens as the only nodes
    grammar_2 = module_0.Grammar()
    parser_2 = Parser(grammar_2)
    parser_2.setup(256)
    parser_2.addtoken(1, "one", (1, 0))

# Generated at 2022-06-25 14:48:50.471434
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:48:58.955589
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:49:06.819738
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Unit test for method pop of class Parser
    parser_0.pop()
    # Unit test for method pop of class Parser
    parser_0.pop()
    # Unit test for method pop of class Parser
    parser_0.pop()
    # Unit test for method pop of class Parser
    parser_0.pop()
    # Unit test for method pop of class Parser
    parser_0.pop()
    # Unit test for method pop of class Parser
    parser_0.pop()
    # Unit test for method pop of class Parser
    parser_0.pop()
    # Unit test for method pop of class Parser
    parser_0.pop()
    # Unit test for method pop of class Parser

# Generated at 2022-06-25 14:49:09.490387
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:49:11.905277
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()



# Generated at 2022-06-25 14:49:13.124542
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.pop()


# Generated at 2022-06-25 14:49:15.393252
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)


# Generated at 2022-06-25 14:49:18.125305
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:49:20.801549
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.classify(5, None, None) == 0


# Generated at 2022-06-25 14:49:29.618343
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = blib2to3.pgen2.grammar.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, 'a', None)
    parser_0.addtoken(2, 'b', None)
    parser_0.addtoken(3, 'c', None)
    parser_0.addtoken(4, 'd', None)
    parser_0.addtoken(5, 'e', None)
    parser_0.stack.append(('value1', 'value2', 'value3'))
    parser_0.pop()

    assert(parser_0.stack == [('value1', 'value2', 'value3')])



# Generated at 2022-06-25 14:49:32.750756
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    context_1 = "context"
    parser_1.shift(1, "value", 1, context_1)


# Generated at 2022-06-25 14:50:01.095196
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    assert parser_1.addtoken(1, None, None) == False


# Generated at 2022-06-25 14:50:06.293899
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.rootnode = None
    parser_1.stack = [(8, 9, 32)]
    parser_1.pop()
    assert parser_1.stack == []
    assert parser_1.rootnode is None

# Generated at 2022-06-25 14:50:09.394915
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.pop()


# Generated at 2022-06-25 14:50:15.781867
# Unit test for method pop of class Parser
def test_Parser_pop():
    def side_effect():
        raise ParseError("pop", None, None, None)
    parser_0 = Parser(None)
    parser_0.pop = side_effect
    try:
        parser_0.pop()
    except ParseError:
        pass
    except:
        raise AssertionError("Expected exception type: %s" % 'ParseError')
    else:
        raise AssertionError("Expected exception type: %s" % 'ParseError')


# Generated at 2022-06-25 14:50:18.330779
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(0)


# Generated at 2022-06-25 14:50:23.224288
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    token_0 = token.NAME
    name_2 = 'value'
    context_0 = Context()
    newstate_0 = 0
    parser_0.shift(token_0, name_2, newstate_0, context_0)


# Generated at 2022-06-25 14:50:26.072940
# Unit test for method pop of class Parser
def test_Parser_pop():

    # Setup
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()

    # Test
    parser_0.pop()


# Generated at 2022-06-25 14:50:30.515769
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    #
    # Call target
    #
    def call_target(self, type, value, context):
        self.addtoken(type, value, context)

    #
    # Generate arguments
    #
    arg_0 = token.NAME
    arg_1 = None
    arg_2 = None
    #
    # Call
    #
    # call_target(arg_0, arg_1, arg_2)


# Generated at 2022-06-25 14:50:32.206737
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.addtoken(1, 2, 3)

# Generated at 2022-06-25 14:50:35.303925
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(0)
    parser_0.shift(1, "", 0)



# Generated at 2022-06-25 14:50:54.320203
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # set up objects needed by the method call
    parser_0 = Parser(Grammar())
    parser_0.setup()
    # call the method under test
    parser_0.addtoken(token.PLUS, "+", Context(None, 1, 0, 1, None))
    # see if it succeeded
    assert True


# Generated at 2022-06-25 14:50:56.402825
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.shift(0, None, 0, None)


# Generated at 2022-06-25 14:50:57.746989
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:50:59.494518
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.addtoken(token.NEWLINE, '\n', (None, None))


# Generated at 2022-06-25 14:51:05.079502
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    dfa_0 = [(0, 1), (0, 2), (1, 3), (1, 2), (2, 4), (2, 5), (3, 6), (3, 5), (4, 7), (5, 7)]
    dfa_1 = {1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7}
    test_dfa = (dfa_0, dfa_1)
    test_state = 0
    new_state = 0
    test_node = (0, None, None, [])
    parser.stack = [(test_dfa, test_state, test_node)]
    type = 0
    value = None
   

# Generated at 2022-06-25 14:51:10.786010
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newstate_0 = 0
    context_0 = Context(0, 0)
    type_0 = 0

# Generated at 2022-06-25 14:51:12.831218
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:51:19.920634
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0, lam_sub)
    parser_0.setup()
    parser_0.addtoken(token.COMMENT, ";", None)
    parser_0.addtoken(token.COMMENT, ";", None)
    parser_0.addtoken(token.NEWLINE, "\n", None)
    parser_0.addtoken(token.INDENT, "\n", None)
    parser_0.addtoken(token.INDENT, "\n", None)
    parser_0.addtoken(token.INDENT, "\n", None)
    parser_0.addtoken(token.INDENT, "\n", None)

# Generated at 2022-06-25 14:51:22.808528
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:51:30.904060
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type = 0
    value = None
    newstate = 0
    context = None
    parser_0.shift(type, value, newstate, context)

# Generated at 2022-06-25 14:52:08.066948
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    # Test a raise_stmt
    grammar_1.add_production('file_input', [('file_input', 'stmt', 'NEWLINE', 'stmt')])
    grammar_1.add_production('file_input', ['NEWLINE'])
    grammar_1.add_production('stmt', ['raise_stmt'])
    grammar_1.add_production('raise_stmt', [('RAISE', 'NAME')])
    grammar_1.add_production('raise_stmt', ['RAISE'])
    grammar_1.add_production('raise_stmt', [('RAISE', 'test', 'FROM', 'test')])
    parser_1.setup(1)

# Generated at 2022-06-25 14:52:10.779573
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:52:17.758107
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, "asdf", Context())
    parser_0.addtoken(1, "asdf", Context())
    parser_0.addtoken(1, "asdf", Context())
    parser_0.addtoken(1, "asdf", Context())
    parser_0.addtoken(1, "asdf", Context())

if __name__ == "__main__":
    test_Parser_classify()

# Generated at 2022-06-25 14:52:18.524507
# Unit test for method setup of class Parser
def test_Parser_setup():
    test_case_0()

# Generated at 2022-06-25 14:52:27.554689
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # grammar.keywords is empty
    # Pass an arbitrary token
    token_0 = token.STRING
    # grammar.tokens is empty
    try:
        try:
            parser_0.classify(token_0, None, None)
            assert False, "No exception raised"
        except ParseError:
            pass
    finally:
        pass
    try:
        try:
            parser_0.classify(None, None, None)
            assert False, "No exception raised"
        except ParseError:
            pass
    finally:
        pass
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    # grammar.key

# Generated at 2022-06-25 14:52:34.475613
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Initialize an instance of Parser and setup it
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    # Call the method under test
    parser_0.shift(token.NAME, "value", 1, Context(preceding=[]))
    # Verify the state of the instance
    assert 1 == len(parser_0.stack)
    dfa, state, node = parser_0.stack[0]
    assert 1 == state
    assert parser_0.rootnode is None
    assert {'value'} == parser_0.used_names


# Generated at 2022-06-25 14:52:36.223746
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.shift(1, 1, 1, 1)


# Generated at 2022-06-25 14:52:38.255057
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:52:44.493933
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    from .token import NAME
    from .driver import Context

    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    # Testing attribute grammar
    assert isinstance(parser_0.grammar, module_0.Grammar)
    # Testing attribute convert
    assert parser_0.convert is None
    assert parser_0.addtoken(NAME, 'if', Context(1, 0)) is False
    assert parser_0.addtoken(NAME, 'name', Context(1, 3)) is False
    assert parser_0.addtoken(NAME, 'name', Context(1, 8)) is False
    assert parser_0.addtoken(NAME, 'name', Context(1, 13)) is True

# Generated at 2022-06-25 14:52:52.901406
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # The proper usage sequence is:
    # 
    # p = Parser(grammar, [converter])  # create instance
    # p.setup([start])                  # prepare for parsing
    # <for each input token>:
    #     if p.addtoken(...):           # parse a token; may raise ParseError
    #         break
    # root = p.rootnode                 # root of abstract syntax tree
    # 
    # A Parser instance may be reused by calling setup() repeatedly.
    # 
    # A Parser instance contains state pertaining to the current token
    # sequence, and should not be used concurrently by different threads
    # to parse separate token sequences.
    # 
    # See driver.py

# Generated at 2022-06-25 14:53:28.258951
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NAME
    value_0 = 'x'
    context_0 = Context()
    assert parser_0.classify(type_0, value_0, context_0) == -1


# Generated at 2022-06-25 14:53:37.790124
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Parser.shift
    # unit test to verify if shift method works properly
    # test data and expected output
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    test_type = 2
    test_value = 'test_value'
    test_newstate = 1
    test_context = ((1,1),(1,1))
    stack = parser.stack
    stack[-1] = (parser.grammar.dfas[grammar.start], 0, (grammar.start, None, None, None))
    parser.shift(test_type, test_value, test_newstate, test_context)

# Generated at 2022-06-25 14:53:40.278412
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.addtoken(1, None, Context(1, 0))


# Generated at 2022-06-25 14:53:48.139221
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

# Generated at 2022-06-25 14:53:55.906747
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert isinstance(parser_0.stack[0][2][3], Sequence) 
    parser_0.shift(41, None, 7, None)
    assert isinstance(parser_0.stack[0][2][3], Sequence) 
    parser_0.shift(79, None, 20, None)
    assert isinstance(parser_0.stack[0][2][3], Sequence) 
    parser_0.shift(5, '2', 39, None)
    assert isinstance(parser_0.stack[0][2][3], Sequence) 
    parser_0.shift(4, 'from', 1, None)
    assert isinstance(parser_0.stack[0][2][3], Sequence) 


# Generated at 2022-06-25 14:53:58.450384
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:54:01.142311
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    print(repr(parser_0.pop()))


# Generated at 2022-06-25 14:54:05.701791
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, "", None)


# Generated at 2022-06-25 14:54:07.923576
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Tests:
    # parser_0.classify(1, "", "")



# Generated at 2022-06-25 14:54:10.718080
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Unit test for method pop of class Parser
    parser_0.pop()


# Generated at 2022-06-25 14:54:57.092879
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # XXX Figure out how to do this
    return



# Generated at 2022-06-25 14:54:59.881523
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser_0 = Parser(Grammar())
    parser_0.shift(1, 2, 3, 4)
    parser_0.shift(0, 2, 3, 4)


# Generated at 2022-06-25 14:55:01.913087
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:55:06.345670
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = None

    try:
        grammar_0 = module_0.Grammar()
    except Exception as err:
        pass

    parser_0 = Parser(grammar_0)

    type_0 = None
    value_0 = None
    context_0 = None
    ilabel_0 = None

    try:
        ilabel_0 = parser_0.classify(type_0, value_0, context_0)
        print(ilabel_0)
    except Exception as err:
        print(err)


# Generated at 2022-06-25 14:55:08.612934
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    grammar_1.tokens[1] = 1
    grammar_1.keywords['2'] = 2
    grammar_1.tokens[3] = 3
    parser_1.classify(1, '2', 3)

# Generated at 2022-06-25 14:55:12.406945
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()

# Generated at 2022-06-25 14:55:14.992304
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    assertEqual(4, parser_1.shift(0, 0, 1, 0))


# Generated at 2022-06-25 14:55:17.444791
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.shift(0, 0, 0, 0)

# Generated at 2022-06-25 14:55:23.737573
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.stack = [(4, 3, 3), (4, 2, 2), (4, 1, 1), (4, 0, 0)]
    parser.stack.append((4, 5, 5))
    parser.pop()
    assert (parser.stack == [(4, 3, 3), (4, 2, 2), (4, 1, 1), (4, 0, 0)]), "Parser.pop(): error"


# Generated at 2022-06-25 14:55:28.871520
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert parser_0.classify(1, '', '') == 1
    assert parser_0.classify(0, '', '') == 3
    assert parser_0.classify(0, '', '') == 3


# Generated at 2022-06-25 14:56:11.456430
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newdfa_0: blib2to3.pgen2.parser.DFAS = [tuple(), dict()]
    newstate_0: int = 0
    context_0 = object()
    # Call method 'push'
    parser_0.push(0, newdfa_0, newstate_0, context_0)



# Generated at 2022-06-25 14:56:14.258807
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    try:
        parser_0.addtoken(10, 10, 10)
        assert False
    except ParseError as e:
        assert e.msg == "too much input"
        assert e.type == 10
        assert e.value == 10
        assert e.context == 10


# Generated at 2022-06-25 14:56:15.826503
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(1, None, 1, Context())


# Generated at 2022-06-25 14:56:18.036850
# Unit test for method push of class Parser
def test_Parser_push():
    parser_0 = Parser(Grammar())
    parser_0.push(int(), DFAS(), int())

# Generated at 2022-06-25 14:56:25.311888
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, 'test_Parser_push_0', (1, 0))
    parser_0.addtoken(0, 'test_Parser_push_1', (1, 0))
    parser_0.addtoken(0, 'test_Parser_push_2', (1, 0))
    parser_0.addtoken(0, 'test_Parser_push_3', (1, 0))
    parser_0.addtoken(0, 'test_Parser_push_4', (1, 0))
    parser_0.addtoken(5, 'test_Parser_push_5', (1, 0))

# Generated at 2022-06-25 14:56:26.748919
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)

    parser_1.pop()


# Generated at 2022-06-25 14:56:28.425756
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.classify(token.NAME, b"test_token", Context(1, 0, ""))

# Generated at 2022-06-25 14:56:37.524025
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    start_1 = None
    parser_1.setup(start_1)
    (dfa_1, state_1, node_1) = parser_1.stack[0]
    # DFA state 0 has expected number of transitions
    assert len(dfa_1[0]) == 3
    # DFA state 0 transitions to state 1 on "expr"
    # DFA state 0 transitions to state 2 on "typedargslist"
    # DFA state 0 transitions to state 3 on "varargslist"
    # DFA state 3 is accept-only state
    assert dfa_1[3] == [(0,3)]
    # DFA state 2 is accept-only state

# Generated at 2022-06-25 14:56:42.177864
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newstate_0 = -2
    context_0 = Context()
    type_0 = 1
    newdfa_0 = [([(0, 0)], {})]
    assert parser_0.push(type_0, newdfa_0, newstate_0, context_0) == None


# Generated at 2022-06-25 14:56:46.187064
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    token_0 = token.NAME
    value_0 = 'abc'
    context_0 = Context()
    result_0 = parser_0.addtoken(token_0, value_0, context_0)
    assert result_0
    result_1 = parser_0.addtoken(token_0, value_0, context_0)
    assert result_1


# Generated at 2022-06-25 14:57:28.977324
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert False # replace with real tests



# Generated at 2022-06-25 14:57:34.998674
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar(start=1)
    parser_0 = Parser(grammar_0)
    parser_0.setup(start=1)
    assert parser_0.stack[-1] == (grammar_0.dfas[1], 0, (1, None, None, []))
    
    parser_0.pop()
    assert parser_0.rootnode is not None
    assert parser_0.stack == []


# Generated at 2022-06-25 14:57:37.053652
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.stack = []


# Generated at 2022-06-25 14:57:42.815361
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # test case added
    type = ALT
    value = ALT
    context = BLT
    assert parser_0.addtoken(type, value, context)
    # test case added
    type = ALT
    value = ALT
    context = BLT
    assert parser_0.addtoken(type, value, context)
    # test case added
    type = ALT
    value = ALT
    context = BLT
    assert parser_0.addtoken(type, value, context)
    # test case added
    type = ALT
    value = ALT
    context = BLT
    assert parser_0.addtoken(type, value, context)
    # test case added
    type = ALT

# Generated at 2022-06-25 14:57:49.094324
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = token.NAME
    value_0 = None
    context_0 = Context(pre_context=[], source_encoding="utf-8")
    label_0 = parser_0.classify(type_0, value_0, context_0)

    assert label_0 == -2, label_0

# Generated at 2022-06-25 14:57:56.517071
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    grammar_1.keywords = {'a': 3}
    grammar_1.tokens = {1: 2}
    type_0 = 'b'
    value_0 = 'c'
    context_0 = 'd'
    parser_1.classify(type_0, value_0, context_0)
    grammar_1.keywords = {'a': 3}
    grammar_1.tokens = {1: 2}
    type_1 = 'a'
    value_1 = 'c'
    context_1 = 'd'
    parser_1.classify(type_1, value_1, context_1)
