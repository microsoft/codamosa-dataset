

# Generated at 2022-06-25 14:48:12.370917
# Unit test for method classify of class Parser
def test_Parser_classify():
    global grammar_0, parser_0
    # Test for simple case
    parser_0.classify = Parser.classify
    # Put your code here


# Generated at 2022-06-25 14:48:19.582117
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import blib2to3.pgen2.grammar as module_0
    import blib2to3.pgen2.token as module_1
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = module_1.NAME
    value_0 = None
    context_0 = Context()
    result = parser_0.addtoken(type_0, value_0, context_0)
    assert (result == False)


# Generated at 2022-06-25 14:48:25.837739
# Unit test for method shift of class Parser
def test_Parser_shift():
    def test_case_0():
        grammar_0 = module_0.Grammar()
        parser_0 = Parser(grammar_0)
        parser_0.setup()
        parser_0.dfa = object()
        parser_0.state = object()
        parser_0.node = object()
        parser_0.shift(object(), object(), object(), object())


# Generated at 2022-06-25 14:48:30.428460
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    type_1 = int()
    value_1 = str()
    context_1 = Context()
    addtoken_1 = parser_1.addtoken(type_1, value_1, context_1)


# Generated at 2022-06-25 14:48:36.605901
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    start_0 = -217658363
    parser_0.setup(start_0)
    dfa_0, state_0, node_0 = parser_0.stack[-1]
    assert dfa_0[state_0] == [(0, 0)]


# Generated at 2022-06-25 14:48:40.328269
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    try:
        parser_0 = Parser(grammar_0)
        grammar_0 = module_0.Grammar()
        try:
            parser_0.addtoken(0, None, Context())
            assert False
        except ParseError:
            pass
    except ParseError:
        pass


# Generated at 2022-06-25 14:48:43.963159
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, '1', '1')


# Generated at 2022-06-25 14:48:46.716084
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    assert (parser_1.pop() == None)


# Generated at 2022-06-25 14:48:54.603533
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parsetokens_0 = []
    parsetokens_0.append(token.get("NAME"))
    parsetokens_0.append(token.get("EQUAL"))
    parsetokens_0.append(token.get("NAME"))
    parsetokens_0.append(token.get("EQUAL"))
    parsetokens_0.append(token.get("NAME"))
    parsetokens_0.append(token.get("EQUAL"))
    parsetokens_0.append(token.get("NAME"))
    parsetokens_0.append(token.get("EQUAL"))
    parsetokens_0.append

# Generated at 2022-06-25 14:49:00.411277
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = [(DFA((), {}), 0, (3, None, None, [])), (DFA((), {}), 0, (2, None, None, []))]
    parser_0.pop()
    parser_0.stack = [(DFA((), {}), 0, (2, None, None, []))]

# Generated at 2022-06-25 14:49:13.831634
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    context_0 = Context('test context', 2, 3)
    parser_0.addtoken(0, None, context_0)

test_case_0.setup = test_Parser_addtoken


# Generated at 2022-06-25 14:49:16.861442
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.shift(0, 0, 0, 0) is None


# Generated at 2022-06-25 14:49:21.277579
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    method_0 = parser_1.push
    t = 100
    newdfa = 1
    newstate = 2
    context = 0
    method_0(t, newdfa, newstate, context)


# Generated at 2022-06-25 14:49:23.448954
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:49:25.588354
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Setup test case
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Invoke method
    output = parser_0.pop()
    # Verify results
    assert output == None


# Generated at 2022-06-25 14:49:34.893632
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    # Receives: type=0, value=None, context=None
    # Throws exception: ParseError
    # Returns: False
    exception = None
    try:
        result = parser_0.addtoken(0, None, None)
    except ParseError as ex:
        exception = ex
    print("Expected exception: ParseError")
    print("Actual exception:", exception)
    print("ParseError:", exception.msg)
    print("ParseError: type=%r, value=%r, context=%r" % (exception.type, exception.value, exception.context))


# Generated at 2022-06-25 14:49:37.968955
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    parser_0.classify(int(), Optional[Text](), Context())



# Generated at 2022-06-25 14:49:40.883537
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    result_0 = parser_0.pop()
    assert result_0 == None


# Generated at 2022-06-25 14:49:45.563305
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, 'a', (1, 0))
    parser_0.addtoken(1, 'b', (1, 0))


# Generated at 2022-06-25 14:49:54.448252
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    popdfa_0, popstate_0, popnode_0 = (0, 0, 0)
    dfa_0, state_0, node_0 = popdfa_0, popstate_0, popnode_0
    parser_0.stack = [dfa_0, state_0, node_0]
    parser_0.rootnode = popnode_0
    parser_0.used_names = {}
    parser_0.pop()
    stack_0 = parser_0.stack
    assert stack_0 == [dfa_0, state_0, node_0]
    rootnode_0 = parser_0.rootnode
    assert rootnode_0 is popnode_0
    used_names_

# Generated at 2022-06-25 14:50:11.495822
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()

    parse_1(parser_0)
    assert parser_0.classify(1, "", Context(())) == 1


# Generated at 2022-06-25 14:50:16.635314
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    popnode_0 = ("test", None, None, [])
    parser_0.stack = [("test", "test", popnode_0)]
    parser_0.pop()


# Generated at 2022-06-25 14:50:25.958909
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newdfa_0 = (
        [
            (
                (
                    (
                        0,
                        1,
                    ),
                ),
                (
                    (
                        0,
                    ),
                ),
            ),
            (
                (
                    (
                        0,
                        0,
                    ),
                ),
                (
                    (
                        0,
                    ),
                ),
            ),
        ],
        {
            0: 0,
            1: 1,
        },
    )
    parser_0.push(
        0,
        newdfa_0,
        1,
        Context(
            lineno=1,
            offset=1,
        ),
    )

# Unit test

# Generated at 2022-06-25 14:50:28.414818
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert parser_0.pop() is None


# Generated at 2022-06-25 14:50:32.446347
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 0
    value_0 = "bla"
    context_0 = Context(None, None, None)
    assert parser_0.addtoken(type_0, value_0, context_0) == False


# Generated at 2022-06-25 14:50:34.444605
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:50:40.925570
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 1
    value_0 = "test"
    newstate_0 = 1
    context_0 = Context()
    assert value_0 is not None
    parser_0.shift(type_0, value_0, newstate_0, context_0)



# Generated at 2022-06-25 14:50:44.485057
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()

import blib2to3.pgen2.parse as module_1


# Generated at 2022-06-25 14:50:47.899465
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    context_0 = Context()
    assert parser_0.addtoken(1, '', context_0) == False


# Generated at 2022-06-25 14:50:50.996467
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
#    parser_0.push()
    print("Test passed")

# Test of Parser.__init__

# Generated at 2022-06-25 14:51:26.234797
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(start = 1, end = 2)


# Generated at 2022-06-25 14:51:30.643351
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup(start=None)

    parser_1.addtoken(type=None, value=None, context=None)


# Generated at 2022-06-25 14:51:39.764655
# Unit test for method push of class Parser
def test_Parser_push():
    # Local variables of method push
    dfa: DFAS = None
    newdfa: DFAS = None
    newnode: RawNode = None
    popdfa: DFAS = None
    popnode: RawNode = None
    state: int = 0
    newstate: int = 0
    context: Context = None
    type: int = 0
    node: RawNode = None
    # Setup of method push
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    type = 1
    newdfa = [None, None]
    newstate = 1
    context = 0
    dfa = [None, None]
    state = 0
    newnode = (1, None, 0, [])

# Generated at 2022-06-25 14:51:42.515038
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.setup(3)


# Generated at 2022-06-25 14:51:49.302203
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = [([([(0, 1), (0, 2)], {1: 'daf'}), ([(0, 3), (0, 4)], {4: 'daf'})], 0, (1, 'da', {2: 'daf'}, [1, 'fad']))]
    parser_0.push(('da', 'f'), ([([(0, 1), (0, 2)], {1: 'daf'}), ([(0, 3), (0, 4)], {4: 'daf'})], {4: 'daf'}), 0, {2: 'daf'})


# Generated at 2022-06-25 14:51:55.611901
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    converter_0 = lam_sub
    parser_0 = Parser(grammar_0, converter_0)
    context_0 = Context()
    type_0 = 0
    value_0 = ""
    newstate_0 = 0
    context_1 = Context()
    parser_0.shift(type_0, value_0, newstate_0, context_1)


# Generated at 2022-06-25 14:51:57.826901
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.push('type', 'newdfa', 'newstate', 'context')


# Generated at 2022-06-25 14:52:03.146281
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert parser_0.stack
    assert parser_0.rootnode is None
    assert parser_0.used_names == set()

if __name__ == '__main__':
    test_Parser_addtoken()

# Generated at 2022-06-25 14:52:11.251829
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_1 = Parser(grammar_0)
    parser_2 = Parser(grammar_0)
    parser_3 = Parser(grammar_0)
    parser_4 = Parser(grammar_0)
    parser_5 = Parser(grammar_0)
    parser_6 = Parser(grammar_0)
    parser_7 = Parser(grammar_0)
    parser_8 = Parser(grammar_0)
    parser_9 = Parser(grammar_0)
    parser_10 = Parser(grammar_0)
    parser_11 = Parser(grammar_0)
    parser_12 = Parser(grammar_0)
    parser_

# Generated at 2022-06-25 14:52:14.707723
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    # Call method pop of parser_0:
    parser_0.pop()

# Generated at 2022-06-25 14:53:27.239819
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0._Parser__shift() == None
    assert parser_0._Parser__push() == None
    assert parser_0._Parser__pop() == None


# Generated at 2022-06-25 14:53:33.164882
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.classify(token.NAME, 'test_1', Context(None, 1)) == parser_0.grammar.tokens['test_1']
    assert parser_0.classify(token.NUMBER, None, Context(None, 1)) == parser_0.grammar.tokens['NUMBER']


# Generated at 2022-06-25 14:53:34.002429
# Unit test for method pop of class Parser
def test_Parser_pop():
    test_case_0()



# Generated at 2022-06-25 14:53:38.730817
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = [[(-1, {}), 0, [0, None, None, None]]]
    parser_0.shift(2, 3, 4, 5)
    assert parser_0.stack == [[(-1, {}), 4, [0, None, None, []]]]


# Generated at 2022-06-25 14:53:46.878055
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    grammar_0.dfas = {0: ([[(1, 0)], [(1, 1)], [(2, 1)], [(3, 1)]], {0: 0, 1: 1, 2: 2, 3: 3, 4: 4})}
    type_0 = 0
    value_0 = ' '
    context_0 = 0
    newstate_0 = 0
    dfa_0, state_0, node_0 = parser_0.stack[-1]
    newnode_0 = (type_0, value_0, context_0, None)
    assert node_0[-1] is not None
    # node_0[-1].append(newnode_0)

# Generated at 2022-06-25 14:53:50.370382
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    token_0 = token.NAME
    value_0 = "name_0"
    context_0 = Context()
    assert parser_0.addtoken(token_0, value_0, context_0)


# Generated at 2022-06-25 14:53:52.798898
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    # Call method addtoken
    result = parser_0.addtoken(1, 'a', {'a'})



# Generated at 2022-06-25 14:53:58.932265
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = [(Parser.__init__, parser_0.grammar, parser_0.convert)]
    parser_0.stack.append((parser_0.convert, parser_0.grammar, parser_0.stack_0))
    parser_0.stack_0 = (parser_0.convert, parser_0.grammar, parser_0.stack_0)
    parser_0.pop()


# Generated at 2022-06-25 14:54:02.825339
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Setup
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Test
    parser_0.setup()
    with pytest.raises(ParseError):
        parser_0.addtoken(1, None, None)


# Generated at 2022-06-25 14:54:07.438600
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    start_0 = 0
    parser_0.setup(start_0)
    rootnode_0 = parser_0.rootnode


# Generated at 2022-06-25 14:55:35.496527
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Creating instance
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)

    # Creating instances of test data
    t_1 = token.NAME
    v_1 = str()
    c_1 = Leaf(0, ())
    n_1 = 0
    context_1 = Context(None, ())
    # Invoking method
    parser_1.shift(t_1, v_1, n_1, context_1)

# Generated at 2022-06-25 14:55:37.479384
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:55:47.605400
# Unit test for method pop of class Parser
def test_Parser_pop():

    parser_1 = Parser(grammar_0)

    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    parser_0.stack = [(DFAS, int, RawNode), (DFAS, int, RawNode)]
    parser_0.stack.pop()

    DFAS = Tuple[DFA, Dict[int, int]]
    DFA = List[List[Tuple[int, int]]]
    RawNode = Tuple[int, Optional[Text], Optional[Context], Sequence[NL]]

    # Test with no stack
    parser_0.stack = []
    parser_0.pop()

    # Test with stack
    parser_1.stack = [(DFAS, int, RawNode), (DFAS, int, RawNode)]
    parser_1.stack.pop

# Generated at 2022-06-25 14:55:50.374201
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Test method classify of class Parser using argument (1, '1', None)
    parser_0.classify(1, '1', None)


# Generated at 2022-06-25 14:55:55.157250
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_case_0()
    test_Parser_shift_1()
    test_Parser_shift_2()
    test_Parser_shift_3()

# Testing method shift
# Input:
# grammar: grammar_0, type: token.STRING, value: None, context: , newstate: 0, node:
# node: 3, type: token.STRING, value: '', context: None, children: None
#
# Output:
# Exception

# Generated at 2022-06-25 14:56:03.795849
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.addtoken(1, 'g', 'n')
    parser_0.addtoken(2, 'g', 'n')
    parser_0.addtoken(3, 'g', 'n')
    parser_0.addtoken(4, 'g', 'n')
    parser_0.addtoken(5, 'g', 'n')
    parser_0.addtoken(6, 'g', 'n')
    parser_0.addtoken(7, 'g', 'n')
    parser_0.addtoken(8, 'g', 'n')
    parser_0.addtoken(9, 'g', 'n')
    parser_0.addtoken(10, 'g', 'n')
   

# Generated at 2022-06-25 14:56:07.443272
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    a: Union[Tuple[int, int], Tuple[int, int, int]]
    a = (2, 3)
    parser_0.shift(1, "", 1, Context(a, a))


# Generated at 2022-06-25 14:56:11.611965
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    test_0_context = Context()
    test_0_value = "test_0_value"
    test_0_type = 0
    test_0_result = parser_0.classify(test_0_type, test_0_value, test_0_context)
    assert test_0_result is None


# Generated at 2022-06-25 14:56:14.167610
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    start = None
    type = None
    value = None
    context = None
    grammar = None
    convert = None
    parser = Parser( grammar, convert)
    parser.setup(start)
    parser.addtoken(type, value, context)


# Generated at 2022-06-25 14:56:17.936254
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, None, NL())
    parser_0.addtoken(1, None, NL())
    parser_0.addtoken(1, None, NL())
    parser_0.addtoken(1, None, NL())
    assert parser_0.rootnode is not None
    assert parser_0.rootnode.children == []


# Generated at 2022-06-25 14:57:58.991927
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    # Test with arguments: (1, 'l')
    # Test with arguments: (1, 'a')
    # Test with arguments: (1, 'm')
    # Test with arguments: (1, 'b')
    # Test with arguments: (1, 'd')
    # Test with arguments: (1, 'a')
    # Test with arguments: (0, '')
    assert parser_0.addtoken(1, '1', '1') == False
    assert parser_0.addtoken(1, ' ', '1') == False
    assert parser_0.addtoken(1, 'l', '1') == False

# Generated at 2022-06-25 14:58:02.318137
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = int()
    newdfa_0 = module_0.DFAS()
    newstate_0 = int()
    context_0 = Context()
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)
