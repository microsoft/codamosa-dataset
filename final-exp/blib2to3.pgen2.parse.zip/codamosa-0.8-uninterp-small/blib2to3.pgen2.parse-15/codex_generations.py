

# Generated at 2022-06-25 14:48:13.770928
# Unit test for method pop of class Parser
def test_Parser_pop():
    test = Parser([], [])  # Instantiation
    # Expected code :
    test._Parser__pop()


# Generated at 2022-06-25 14:48:15.615835
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_case_0()


# Generated at 2022-06-25 14:48:20.057642
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    symbol_0 = token.NUMBER
    symbol_1 = 5.0
    symbol_2 = Context(symbol_0)
    parser_0.addtoken(symbol_0, symbol_1, symbol_2)


# Generated at 2022-06-25 14:48:25.097253
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    grammar_0.start = 257
    try:
        parser_0.pop()
    except ParseError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-25 14:48:28.843787
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()

# Generated at 2022-06-25 14:48:29.803791
# Unit test for method push of class Parser
def test_Parser_push():
    test_case_0(test_case_0__test_case_push)



# Generated at 2022-06-25 14:48:36.745941
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(grammar_0.start)
    parser_0.shift()

test_module(__name__, __file__)

# Local Variables:
# # tab-width:4
# # indent-tabs-mode:nil
# # End:
# vim: set syntax=python expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-25 14:48:40.401723
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:48:50.280118
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Declarations
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0: DFA = list()
    state_0: int = 0
    node_0: Any = None
    type_0: int = 0
    value_0: Optional[Text] = None
    newstate_0: int = 0
    context_0: Context = None
    dfa_1: DFA = list()
    state_1: int = 0
    node_1: Any = None

    # Setup
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = list()
    state_0 = 0
    node_0 = None
    type_0 = 0
    value_0

# Generated at 2022-06-25 14:48:54.955018
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(grammar_0.tokens.get(pgen_grammar_token_NAME), None, None)
    assert parser_0.classify(grammar_0.tokens.get(pgen_grammar_token_NAME), None, None)==pgen_grammar_label_NAME


# Generated at 2022-06-25 14:49:09.282826
# Unit test for method classify of class Parser
def test_Parser_classify():
    """Unit test for method classifiy of class Parser.

    The tests cover the following cases:

    - (1) token.NAME: not a reserved word
    - (2) token.NAME: a reserved word
    - (3) token.NAME: a reserved word but not in the grammar
    - (4) token.NEWLINE
    - (5) token.NAME: a reserved word but not in the parser's grammar
    - (6) token.NEWLINE: not in the parser's grammar

    """
    # We'll need a token map
    token_map_0 = {
        token.NOT: 'NOT',
        token.STRING: 'STRING',
        token.NAME: 'NAME',
    }
    # The keyword map

# Generated at 2022-06-25 14:49:12.035976
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():

    grammar = module_0.Grammar()
    parser = Parser(grammar)


# Generated at 2022-06-25 14:49:15.564423
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(1, 2, 3, 4)


# Generated at 2022-06-25 14:49:22.456360
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = grammar_0.dfas[0]
    newdfa_0 = dfa_0
    node_0 = (0, None, None, [])
    parser_0.push(0, newdfa_0, 0, None)
    parser_0.stack[0] = (dfa_0, 0, node_0)
    parser_0.pop()
    assert len(parser_0.stack) == 1


# Generated at 2022-06-25 14:49:23.787873
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.shift(1, 'a', 2, 'c')


# Generated at 2022-06-25 14:49:28.595752
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_1 = Parser(grammar_0)
    assert parser_1.addtoken(token.INDENT, None, None) == False
    assert parser_1.addtoken(token.INDENT, None, None) == False
    assert parser_1.addtoken(token.INDENT, None, None) == False
    assert parser_1.addtoken(token.INDENT, None, None) == False
    assert parser_1.addtoken(token.INDENT, None, None) == False
    assert parser_1.addtoken(token.INDENT, None, None) == False
    assert parser_1.addtoken(token.INDENT, None, None) == False
    assert parser_1.addtoken(token.INDENT, None, None) == False
    assert parser

# Generated at 2022-06-25 14:49:32.003483
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    stack_0 = 3
    for i in range(stack_0):
        parser_0.push(t, newdfa, newstate, context)


# Generated at 2022-06-25 14:49:36.135467
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.shift(0, None, 0, None)

    if parser.stack.pop() != (0, 0, (0, None, None, None)):
        raise RuntimeError



# Generated at 2022-06-25 14:49:46.587345
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(token.NUMBER, '3', Context(1,1))
    parser.addtoken(token.PLUS, '+', Context(1,1))
    parser.addtoken(token.NUMBER, '3', Context(1,3))
    stack_0 = parser.stack
    dfa_0, state_0, node_0 = stack_0[-1]
    newdfa_0 = module_0.DFAs(dfa_0, grammar.dfas)
    stack_0.append((newdfa_0, state_0, node_0))
    parser.pop()
    stack_1 = parser.stack
    dfa_1, state_1, node_1 = stack

# Generated at 2022-06-25 14:49:50.781584
# Unit test for method pop of class Parser
def test_Parser_pop():
    '''
    Unit test for method pop of class Parser
    '''
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    # Call method pop of parser_1
    result_1 = parser_1.pop()
    assert result_1 is None


# Generated at 2022-06-25 14:50:14.249190
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    #   0: import sys
    #   1: if sys.version_info[0] > 2:
    #   2:     import io
    import io
    #   3:     in_str = io.StringIO(in_str)
    #   4: from blib2to3.pgen2 import driver
    #   5: tree = driver.parse_string(in_str, 'file_input', debug=debug)
    #   6: if tree is None:
    #   7:     return None
    #   8: if debug:
    #   9:     from blib2to3.pgen2 import tokenize
    #  10:     for t in tokenize.generate_tokens(in_str.readline):
    #  11:         print(t)
    #  12: from blib

# Generated at 2022-06-25 14:50:15.283501
# Unit test for method shift of class Parser
def test_Parser_shift():
    test_case_0()


# Generated at 2022-06-25 14:50:25.093881
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    # Test a shift on the stack from an accepting state
    parser_1.stack = [(([[(0, 3)], [(0, 3)]], {1: 0}), 0, (0, None, None, 0))]
    parser_1.shift(1, 2, 0, 3)
    assert parser_1.stack == [(({0: [(0, 0)]}, {1: 0}), 0, (0, 2, 3, 0))]
    # Test a shift on the stack from a non-accepting state
    parser_1.stack = [(([[(0, 3), (1, 0)], [(0, 3)]], {1: 0}), 0, (0, None, None, 0))]
    parser

# Generated at 2022-06-25 14:50:28.257897
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 1
    value_0 = None
    context_0 = (1, 2)
    assert parser_0.classify(type_0, value_0, context_0) == None


# Generated at 2022-06-25 14:50:30.515891
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Calling method pop of class Parser
    parser_0.pop()


# Generated at 2022-06-25 14:50:36.769599
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 104
    newdfa_0 = None # Unknown
    newstate_0 = 1
    context_0 = Context(None, None, None, None)
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)
    assert parser_0.stack == [(([[], {}], 1), 0, (104, None, None, []))]


# Generated at 2022-06-25 14:50:38.245460
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(token.NAME, "NAME", 0, Context)


# Generated at 2022-06-25 14:50:41.563448
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:50:50.924771
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # <class blib2to3.pytree.Leaf object at 0x7f15140f2978> type: int: 1
    # <class blib2to3.pytree.Leaf object at 0x7f15140f2978> type: int: 1
    # <class blib2to3.pytree.Leaf object at 0x7f15140f2978>
    # <class blib2to3.pytree.Leaf object at 0x7f15140f2978>
    expected_0 = 38
    # assert expected_0 == actual_0
    test_case_0()

    test_case_0()

    test_case_0()

    test_case_0()

# Generated at 2022-06-25 14:50:53.821133
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)


# Generated at 2022-06-25 14:51:04.658583
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser = Parser(module_0.Grammar())
    parser.pop()


# Generated at 2022-06-25 14:51:08.851687
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.shift(0, "", 0, "")


# Generated at 2022-06-25 14:51:09.941891
# Unit test for method pop of class Parser
def test_Parser_pop():
    pass



# Generated at 2022-06-25 14:51:18.647473
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1._refcount_0: int = 0
    parser_1.stack: list = []
    parser_1.convert: Callable[[module_0.Grammar, Tuple[int, Optional[str], Context, List[Union[Leaf, Node]]]], Union[Leaf, Node]] = None
    parser_1.grammar: module_0.Grammar = grammar_1
    parser_1.used_names: Set[str] = set()
    parser_1.rootnode: Optional[Union[Leaf, Node]] = None
    type: int = 0

# Generated at 2022-06-25 14:51:30.393262
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Create an instance of class Parser and set its grammar
    parser_1 = Parser(grammar_0)
    parser_1.grammar = grammar_1

    # Call method classify of class Parser
    parser_1.classify(
        type = 1,
        value = "test_value_2",
        context = Context()
    )

    # Call method classify of class Parser
    parser_1.classify(
        type = 2,
        value = "test_value_2",
        context = Context()
    )

    # Call method classify of class Parser
    parser_1.classify(
        type = 3,
        value = "test_value_3",
        context = Context()
    )

    # Call method classify of class Parser

# Generated at 2022-06-25 14:51:33.292863
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()

    assert(not parser_0.stack)


# Generated at 2022-06-25 14:51:37.153143
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    token_0 = 12
    token_1 = 11
    token_2 = 4
    newstate_0 = 0
    context_0 = Context(0, 1)
    parser_0.shift(token_0, token_1, newstate_0, context_0)

# Generated at 2022-06-25 14:51:43.477036
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(77)
    parser_0.addtoken(1, '', Context(1, 8))
    parser_0.addtoken(61, '', Context(1, 10))
    parser_0.addtoken(1, '', Context(1, 12))
    parser_0.addtoken(10, '', Context(1, 13))


# Generated at 2022-06-25 14:51:45.028438
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)

    parser_1.addtoken(1, "asd", None)
    return


# Generated at 2022-06-25 14:51:53.367128
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    dfa_1 = [[(10, 15)], {0: [(0, 15)]}, [(0, 15)]]
    newstate_1 = 15
    node_1: RawNode = (10, '//', 1, None)
    parser_1.stack = [(dfa_1, 0, node_1)]
    parser_1.shift(10, '//', newstate_1, 1)
    assert parser_1.stack == [(dfa_1, 15, node_1)]


# Generated at 2022-06-25 14:52:15.373798
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser_0 = Parser(module_0.Grammar())
    parser_0.shift(97, '97', 1, ((0, 0), 0))


# Generated at 2022-06-25 14:52:18.331770
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(None, None, 0, Context(prec=0))

# Generated at 2022-06-25 14:52:22.323875
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_1 = Parser(grammar_0)
    parser_1.setup()
    type_0 = 0
    value_0 = ""
    newstate_0 = 0
    context_0 = ""
    parser_1.shift(type_0, value_0, newstate_0, context_0)
    parser_1.stack

# Generated at 2022-06-25 14:52:25.883855
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.INDENT
    value_0 = None
    context_0 = Context([])
    parser_0.addtoken(type_0, value_0, context_0)
    assert True


# Generated at 2022-06-25 14:52:29.403362
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # AssertionError: AssertionError: 0 != 0 for (dfa, state, node) in self.stack:
    assert parser_0.stack[0][1] == 0


# Generated at 2022-06-25 14:52:31.985325
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:52:33.809356
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:52:41.158291
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack.append((parser_0.grammar.dfas[193], 0, (257, None, 'test/test_pgen.py', [])))
    parser_0.stack.append((parser_0.grammar.dfas[211], 0, (258, None, 'test/test_pgen.py', [])))
    parser_0.stack.append((parser_0.grammar.dfas[234], 0, (258, None, 'test/test_pgen.py', [])))
    parser_0.push(197, parser_0.grammar.dfas[197], 0, 'test/test_pgen.py')
    assert len(parser_0.stack) == 4



# Generated at 2022-06-25 14:52:44.624002
# Unit test for method shift of class Parser
def test_Parser_shift():
    parser_0 = Parser(module_0.Grammar())
    parser_0.setup()
    parser_0.shift(module_0.token.NAME, "", 0)


# Generated at 2022-06-25 14:52:49.511789
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.rootnode = None
    parser_0.used_names = set()
    parser_0.stack = [(0, 0, None)]
    parser_0.pop()


if __name__ == "__main__":
    import unittest

    unittest.main()

# Generated at 2022-06-25 14:53:32.921428
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(0, None, 0, None)


# Generated at 2022-06-25 14:53:36.007084
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    with pytest.raises(IndexError, match="pop index out of range"):
        parser_0.pop()


# Generated at 2022-06-25 14:53:40.157173
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    test_value = parser_1.addtoken(0, '', Context(0, 0))
    assert test_value is False
    parser_1.addtoken(1, '', Context(0, 1))


# Generated at 2022-06-25 14:53:45.567012
# Unit test for method push of class Parser
def test_Parser_push():
    test_case_0()
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 0
    newdfa_0 = None # Callable[[Grammar, RawNode], Tuple[int, int]]
    newstate_0 = 0
    context_0 = Context()
    parser_0.push(type_0, newdfa_0, newstate_0, context_0) # Expect no exception


# Generated at 2022-06-25 14:53:51.132321
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    # Sequence of (type, value, context)
    token_seq_0 = [
        (token.NAME, "n", RawNode(type=token.NAME, children=[], value="n", context=(0, 0))),
        (token.NAME, "a", RawNode(type=token.NAME, children=[], value="a", context=(0, 0))),
    ]
    for (type, value, context) in token_seq_0:
        parser_0.addtoken(type, value, context)


# Generated at 2022-06-25 14:53:54.119831
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    token = [token.INDENT]
    value = ['INDENT']
    context = [Context(0, 0)]
    for i in range(0, len(token)):
        parser.addtoken(token[i], value[i], context[i])

# Generated at 2022-06-25 14:53:57.046014
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 14:54:00.175622
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:54:08.501757
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = list()
    state_0 = 0
    type_0 = 0
    value_0 = None
    context_0 = None
    parser_0.stack = list([(dfa_0, state_0, (type_0, value_0, context_0, None))])
    parser_0.shift(type_0, value_0, 0, context_0)
    assert parser_0.stack == list([(dfa_0, 0, (type_0, value_0, context_0, None))])


# Generated at 2022-06-25 14:54:12.290380
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = None
    value_0 = None
    context_0 = None
    parser_0.push(type_0, grammar_0.dfas, 4, context_0)


# Generated at 2022-06-25 14:55:50.792600
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = None
    newdfa_0 = None
    assert parser_0.stack
    assert parser_0.pending
    assert parser_0.used_names
    assert parser_0.grammar


# Generated at 2022-06-25 14:55:55.014646
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0 = Parser(grammar_0)
    token_0 = token.NAME
    value_0 = 'spam'
    context_0 = Context()
    result_0 = parser_0.classify(token_0, value_0, context_0)
    assert result_0 == 1, 'result_0 = %s' % (result_0,)


# Generated at 2022-06-25 14:55:58.492833
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    popnode_0 = (0, 0, 0, 0)
    parser_0.stack.append((0, 0, popnode_0))
    parser_0.pop()


# Generated at 2022-06-25 14:56:04.999858
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(None)
    parser_0.addtoken(token.NAME, "a", (1, 0))
    parser_0.addtoken(token.OP, "(", (0, 5))
    parser_0.addtoken(token.OP, "+", (0, 8))
    parser_0.addtoken(token.NUMBER, "1", (0, 10))
    parser_0.addtoken(token.OP, ")", (0, 12))


# Generated at 2022-06-25 14:56:07.178461
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0 )
    parser_0.setup()


# Generated at 2022-06-25 14:56:09.406443
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.addtoken(type=0, value=0, context=None)


# Generated at 2022-06-25 14:56:13.914015
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NAME
    value_0 = u'if'
    context_0 = Context()
    parser_0.addtoken(type_0, value_0, context_0)
    type_1 = token.NAME
    value_1 = u'break'
    parser_0.addtoken(type_1, value_1, context_0)

# Generated at 2022-06-25 14:56:17.366654
# Unit test for method pop of class Parser
def test_Parser_pop():
    # arrange
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # act
    parser_0.pop()


# Generated at 2022-06-25 14:56:19.753776
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = []
    parser_0.addtoken(0, None, None)

# Generated at 2022-06-25 14:56:22.342403
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
