

# Generated at 2022-06-25 14:48:13.511567
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    optional_1 = None
    parser_1 = Parser(grammar_1, optional_1)
    optional_2 = None
    optional_3 = None
    context_1 = Context(optional_2, optional_3)
    try:
        parser_1.addtoken(token.PLUS, u'+', context_1)
        assert False
    except Exception:
        pass


# Generated at 2022-06-25 14:48:17.102923
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    parser_0.pop()


# Generated at 2022-06-25 14:48:20.951248
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
  grammar = Grammar()
  optional = None
  parser = Parser(grammar, optional)
  i = 0
  type = 0
  value = None
  context = Context()
  result = parser.addtoken(type, value, context)
  assert(result == False)


# Generated at 2022-06-25 14:48:27.301454
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    type_0 = int()
    value_0 = str()
    newstate_0 = int()
    context_0 = Context(int(), int())
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:48:37.141935
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    source_0 = module_0.LineNumberingStream()
    optional_1 = None
    tokenizer_0 = module_0.Tokenizer(source_0, optional_0, optional_1)
    type_0 = module_0.token.NAME
    value_0 = "insert"
    context_0 = module_0.Context()
    actual_0 = parser_0.addtoken(type_0, value_0, context_0)
    expected_0 = False
    assert expected_0 == actual_0


# Generated at 2022-06-25 14:48:41.288602
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    optional_1 = None
    parser_0 = Parser(grammar_0, optional_1)
    parser_0.pop()


# Generated at 2022-06-25 14:48:46.314682
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    type_0 = None
    value_0 = None
    context_0 = None
    result_0 = parser_0.classify(type_0, value_0, context_0)


# Generated at 2022-06-25 14:48:49.381152
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = blib2to3.pgen2.grammar.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    parser_0.pop()


# Generated at 2022-06-25 14:48:53.753036
# Unit test for method push of class Parser
def test_Parser_push():
    parser_1 = Parser(grammar_0, optional_0)
    integer_5 = 0
    integer_6 = -1
    type_1 = integer_5
    value_0 = None
    context_0 = Context()
    integer_7 = 0
    newstate_0 = integer_7
    parser_1.push(type_1, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:48:56.472146
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    var_0 = module_0.Context()
    var_1 = parser_0.classify(256, None, var_0)
    assert var_1 == 256


# Generated at 2022-06-25 14:49:06.555823
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Create an instance
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    # Method invocation
    parser_0.pop()


# Generated at 2022-06-25 14:49:12.120899
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = module_0.Grammar()
    optional = None
    parser_0 = Parser(grammar, optional)
    type_0 = token.NAME
    value_0 = 'addtoken'
    context_0 = Context(previous_context=None, filename=None, node=None, lineno=None)
    parser_0.addtoken(type_0, value_0, context_0)


# Generated at 2022-06-25 14:49:14.002842
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # TODO: not tested
    pass


# Generated at 2022-06-25 14:49:23.487917
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = module_0.Grammar()
    optional = None
    parser = Parser(grammar, optional)
    assert parser.classify(1, None, None) == 1
    assert parser.classify(1, "", None) == 1
    assert parser.classify(1, "", (1, 1)) == 1
    assert parser.classify(1, "", (2, 3)) == 1
    assert parser.classify(2, None, None) == 2
    assert parser.classify(2, "", None) == 2
    assert parser.classify(2, "", (1, 1)) == 2
    assert parser.classify(2, "", (2, 3)) == 2
    assert parser.classify(3, None, None) == 3

# Generated at 2022-06-25 14:49:27.290849
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    parser_0.used_names = set()
    class_0 = 1
    value_0 = "NAME"
    context_0 = Context()
    boolean_0 = parser_0.addtoken(class_0,value_0,context_0)
    bool_0 = bool(boolean_0)
    bool_1 = bool(True)
    assert (bool_0 == bool_1)


# Generated at 2022-06-25 14:49:30.293476
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_1 = module_0.Grammar()
    optional_1 = None
    parser_1 = Parser(grammar_1, optional_1)
    start_1 = None
    parser_1.setup(start_1)


# Generated at 2022-06-25 14:49:40.231821
# Unit test for method push of class Parser
def test_Parser_push():
    # Create a grammar and a parser
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    # Prepare for parsing
    parser_0.setup()
    # Push a symbol
    type_0 = 1
    newdfa_0 = (1, 2)
    newstate_0 = 1
    context_0 = Context(2, 4, 3)
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)
    # Extract stack
    stack_0 = parser_0.stack
    # Verify that the stack is correct
    assert stack_0[0] == (newdfa_0, 0, (type_0, '', context_0, []))


# Generated at 2022-06-25 14:49:44.081892
# Unit test for method pop of class Parser
def test_Parser_pop():
    tup_0 = test_case_0()
    test_object_0 = tup_0[2]
    result_0 = test_object_0.pop()
    assert result_0 is None, "Nothing returned"


# Generated at 2022-06-25 14:49:46.745036
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)

    dfa_0 = None
    state_0 = 0
    node_0 = None
    parser_0.stack = [(dfa_0, state_0, node_0)]
    parser_0.pop()
    assert parser_0.rootnode is None
    assert parser_0.stack == []


# Generated at 2022-06-25 14:49:51.883054
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    optional_1 = None
    optional_2 = None
    optional_3 = None
    optional_4 = None
    boolean_0 = parser_0.addtoken(optional_1, optional_2, optional_3, optional_4)
    assert boolean_0 == False


# Generated at 2022-06-25 14:50:03.024696
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = module_0.Grammar()
    optional = None
    parser = Parser(grammar, optional)
    type = 0
    value = "a"
    context = Context()
    newstate = 0
    parser.shift(type, value, newstate, context)
    parser.pop()
    parser.pop()


# Generated at 2022-06-25 14:50:09.828751
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    optional_1 = None
    optional_2 = None
    optional_3 = None

    try:
        parser_0.addtoken(optional_1, optional_2, optional_3)
        raise AssertionError("Should raise ParseError")
    except ParseError:
        pass


# Generated at 2022-06-25 14:50:11.569434
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = module_0.Grammar()
    optional = None
    parser = Parser(grammar, optional)
    parser.pop()

# Generated at 2022-06-25 14:50:22.484911
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    type_0 = None
    newdfa_0 = []
    newstate_0 = 0
    context_0 = Context(None, None)
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)
    type_1 = None
    newdfa_1 = []
    newstate_1 = 0
    context_1 = Context(None, None)
    parser_0.push(type_1, newdfa_1, newstate_1, context_1)
    type_2 = None
    newdfa_2 = []
    newstate_2 = 0
    context_2 = Context(None, None)
    parser_

# Generated at 2022-06-25 14:50:26.722528
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    integer_0 = 10
    optional_1 = None
    optional_2 = None
    parser_0.shift(integer_0, optional_1, integer_0, optional_2)


# Generated at 2022-06-25 14:50:32.540481
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Setup a parser object for testing
    grammar = Grammar()
    converter = None
    parser = Parser(grammar, converter)
    # Set stack to a known state
    parser.stack = [(("DFA0", {"0":[(0,0)]}), 0, (1, None, None, [])), (("DFA0", {"0":[(0,0)]}), 0, (1, None, None, []))]
    # Call the method
    parser.pop()
    # Assert returned results
    assert parser.stack == [(("DFA0", {"0":[(0,0)]}), 0, (1, None, None, []))]

# Generated at 2022-06-25 14:50:36.362607
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    try:
        parser_0.pop()
    except e:
        pass


# Generated at 2022-06-25 14:50:41.307309
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    in_0 = module_0.Grammar()
    in_1 = None
    in_2 = Parser(in_0, in_1)
    in_3 = None
    in_4 = None
    in_5 = None
    in_2.addtoken(in_3, in_4, in_5)


# Generated at 2022-06-25 14:50:47.240004
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    type_0 = 0x0
    value_0 = u"e"
    context_0 = Context(None, 0)
    addtoken__return_0 = parser_0.addtoken(type_0, value_0, context_0)
    assert (addtoken__return_0 == False)


# Generated at 2022-06-25 14:50:51.988519
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    # testmethod
    type_0 = 0
    value_0 = "test_string"
    newstate_0 = 0
    context_0 = Context()
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:51:07.969400
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    expected_0 = None
    exception_0 = None
    parser_0.pop()
    try:
        actual_0 = parser_0.rootnode
    except Exception as exception_0:
        pass
    assert exception_0 is None
    assert actual_0 is expected_0


# Generated at 2022-06-25 14:51:11.118740
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    try:
        test_case_0()
    except ParseError:
        assert True
    else:
        assert False

import blib2to3.pgen2.grammar as module_1


# Generated at 2022-06-25 14:51:16.313241
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # condense_import2_def
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)

    # condense_import2_call
    type_0 = 1
    value_0 = None
    context_0 = Context(None, None)
    parser_0.addtoken(type_0, value_0, context_0)


# Generated at 2022-06-25 14:51:17.141314
# Unit test for method pop of class Parser
def test_Parser_pop():
  assert False, "Test not implemented"

# Generated at 2022-06-25 14:51:19.863801
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    parser_0.setup(None)
    parser_0.addtoken(1, None, None)


# Generated at 2022-06-25 14:51:21.949975
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    optional_0 = None
    parser_0.setup(optional_0)


# Generated at 2022-06-25 14:51:33.415238
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    grammar_0._labels = [
     (
      2,
      "expr"), (
      5,
      "listmaker"), (
     10,
     "testlist_gexp"), (
     14,
     "testlist_safe"), (
     21,
     "list_iter"), (
     24,
     "list_for"), (
     33,
     "listmaker")]

# Generated at 2022-06-25 14:51:34.879399
# Unit test for method pop of class Parser
def test_Parser_pop():
    pop_0 = Parser(Grammar(), None)
    assert pop_0.pop() is None


# Generated at 2022-06-25 14:51:38.533078
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = module_0.Grammar()
    optional = None
    parser = Parser(grammar, optional)
    type = 0
    value = None
    context = 0
    result = parser.addtoken(type, value, context)
    assert result == 0


# Generated at 2022-06-25 14:51:42.954802
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    int_0 = 0
    str_0 = ""
    optional_1 = None
    parser_0.shift(int_0, str_0, optional_1)


# Generated at 2022-06-25 14:52:06.665893
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    expected_0 = Parser.Parser(0)
    # No argument here.
    actual_0 = Parser.Parser(0)
    assert expected_0 == actual_0


# Generated at 2022-06-25 14:52:16.510704
# Unit test for method push of class Parser
def test_Parser_push():
    # Test 1
    grammar_1 = module_0.Grammar()
    optional_1 = None
    parser_1 = Parser(grammar_1, optional_1)

    optional_1 = None
    try:
        parser_1.push(optional_1, optional_1, optional_1, optional_1)
    except ParseError:
        pass
    optional_1 = 0
    try:
        parser_1.push(optional_1, optional_1, optional_1, optional_1)
    except ParseError:
        pass
    optional_1 = 0
    try:
        parser_1.push(optional_1, optional_1, optional_1, optional_1)
    except ParseError:
        pass
    optional_1 = 0

# Generated at 2022-06-25 14:52:23.876746
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    optional_0 = None
    optional_1 = None
    optional_2 = None
    optional_3 = None
    optional_4 = None
    optional_5 = None
    optional_6 = None
    optional_7 = None
    optional_8 = None
    optional_9 = None
    optional_10 = None
    optional_11 = None
    optional_12 = None
    optional_13 = None
    optional_14 = None
    optional_15 = None
    optional_16 = None
    optional_17 = None
    optional_18 = None
    optional_19 = None
    optional_20 = None
    optional_21 = None
    optional_22 = None

# Generated at 2022-06-25 14:52:28.436416
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    optional_1 = None
    optional_2 = None
    try:
        test = parser_0.classify(optional_1, optional_2)
    except ParseError as e:
        pass
    else:
        raise AssertionError('Error expected')


# Generated at 2022-06-25 14:52:36.899673
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def test():
        grammar_0 = module_0.Grammar()
        optional_0 = None
        parser_0 = Parser(grammar_0, optional_0)
        def test_try_except_1_0(type_0, value_0, context_0):
            try:
                optional_1 = parser_0.addtoken(type_0, value_0, context_0)
                return optional_1
            except ParseError:
                return None
        optional_2 = test_try_except_1_0(token.STRING, '"', Context())
        optional_1 = parser_0.rootnode
    

# Generated at 2022-06-25 14:52:43.440686
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    grammar_1 = module_0.Grammar()
    optional_1 = None
    parser_1 = Parser(grammar_1, optional_1)
    grammar_2 = module_0.Grammar()
    optional_2 = None
    parser_2 = Parser(grammar_2, optional_2)
    grammar_3 = module_0.Grammar()
    optional_3 = None
    parser_3 = Parser(grammar_3, optional_3)
    grammar_4 = module_0.Grammar()
    optional_4 = None
    parser_4 = Parser(grammar_4, optional_4)
    grammar_5

# Generated at 2022-06-25 14:52:51.369524
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    optional_0 = None
    type_0 = 0
    value_0 = None
    newstate_0 = 0
    context_0 = None
    parser_0.shift(type_0, value_0, newstate_0, context_0)
    optional_0 = None
    type_1 = 0
    value_1 = None
    newstate_1 = 1
    context_1 = None
    parser_0.shift(type_1, value_1, newstate_1, context_1)


# Generated at 2022-06-25 14:52:54.952587
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    value_0 = 1
    context_0 = Context
    parser_0.shift(1, value_0, 1, context_0)


# Generated at 2022-06-25 14:52:58.220843
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    optional_1 = None
    parser_0.setup(optional_1)


# Generated at 2022-06-25 14:53:04.007380
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    optional_0 = None
    optional_1 = None
    optional_0 = Context(optional_0, optional_1)
    int_0 = 1
    optional_1 = None
    parser_0.shift(int_0, optional_1, int_0, optional_0)



# Generated at 2022-06-25 14:53:36.299916
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    try:
        int_0 = 1
        int_1 = 1
        optional_1 = None
        parser_0.push(int_0, int_1, optional_1)
    except Exception as e:
        str_0 = 'push: required ' + 'arg' + ' context not found'
        assert e.args[0] == str_0


# Generated at 2022-06-25 14:53:40.774704
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    optional_1 = None
    state_0 = parser_0.setup(optional_1)
    result = parser_0.shift(1, 'value_0', 2, 'context_0')
    assert result is None


# Generated at 2022-06-25 14:53:43.642410
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0, None)
    parser_0.setup()
    assert (parser_0.addtoken(1, None, None))


# Generated at 2022-06-25 14:53:47.877782
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    optional_1 = module_0.Grammar()
    optional_2 = 0
    optional_3 = blib2to3.pgen2.driver.Context(1, 1)
    parser_0.push(optional_1, optional_2, optional_3)


# Generated at 2022-06-25 14:53:52.697776
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    type_0 = 0
    value_0 = None
    newstate_0 = 0
    context_0 = None
    # Call the method with correct arguments and check the result (no exception)
    try:
        parser_0.shift(type_0, value_0, newstate_0, context_0)
    except:
        assert False


# Generated at 2022-06-25 14:53:57.435035
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    int_0 = 1
    optional_1 = None
    context_0 = Optional[Context]()
    test_result = parser_0.addtoken(int_0, optional_1, context_0)
    assert test_result == None
    return test_result


# Generated at 2022-06-25 14:54:02.668049
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    type_0 = 0
    value_0 = None
    newstate_0 = 0
    context_0 = Context()
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:54:10.332048
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser = Parser(module_0.Grammar())
    parser.stack.append(((0, ((2,),)), 0, (0, None, None, [])))
    parser.stack.append(((2, ((2,),)), 0, (3, None, None, [])))
    parser.pop()
    assert parser.stack.pop() == ((0, ((2,),)), 0, (0, None, None, []))


if __name__ == "__main__":
    # execute only if run as a script
    test_Parser_pop()

# Generated at 2022-06-25 14:54:11.897653
# Unit test for method shift of class Parser
def test_Parser_shift():
    with pytest.raises(ParseError):
        Parser._Parser__shift(None, None, None, None)


# Generated at 2022-06-25 14:54:15.532202
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    optional_1 = None
    parser_1 = Parser(grammar_1, optional_1)
    optional_2 = None
    optional_3 = None
    optional_4 = None
    parser_1.shift(optional_2, optional_3, optional_4)


# Generated at 2022-06-25 14:55:26.548467
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    arg0_0 = None
    arg1_0 = None
    arg2_0 = None
    test_Parser_addtoken_0 = Parser(arg0_0, arg1_0)
    test_Parser_addtoken_0.setup(arg2_0)
    # Line number: 2024
    optional_0 = None
    test_Parser_addtoken_0.addtoken(arg0_0, optional_0, optional_0)
    # Line number: 2029
    optional_1 = None
    test_Parser_addtoken_0.addtoken(arg0_0, optional_1, optional_1)
    # Line number: 2034
    optional_2 = None
    test_Parser_addtoken_0.addtoken(arg0_0, optional_2, optional_2)
    # Line number: 2045

# Generated at 2022-06-25 14:55:36.086690
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    optional_1 = None
    optional_2 = None
    optional_3 = None
    optional_4 = None
    optional_5 = None
    optional_6 = None
    optional_7 = None
    optional_8 = None
    try:
        parser_0.addtoken(optional_1, optional_2, optional_3)
    except ParseError:
        pass
    else:
        raise AssertionError
    try:
        parser_0.addtoken(optional_4, optional_5, optional_6)
    except ParseError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-25 14:55:46.327877
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    try:
        raise ParseError("bad input", None, None, None)
    except Exception as exception_0:
        print(exception_0)
    else:
        print("exception was not raised")
    try:
        raise ParseError("bad input", None, None, None)
    except Exception as exception_0:
        print(exception_0)
    else:
        print("exception was not raised")

    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    try:
        parser_0.addtoken(None, None, None)
        print("exception was not raised")
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 14:55:48.270900
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)


# Generated at 2022-06-25 14:55:52.873317
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    optional_1 = None
    parser_1 = Parser(grammar_1, optional_1)
    type_3 = 0
    value_3 = None
    newstate_3 = 0
    context_3 = Context(0,0)
    try:
        parser_1.shift(type_3, value_3, newstate_3, context_3)
    except ParseError as exception_4:
        pass


# Generated at 2022-06-25 14:55:57.108038
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    type_0 = 0
    value_0 = object()
    newstate_0 = 0
    context_0 = object()
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:56:02.005037
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    test_case_0()
    test_case_0()
    data_0 = parser_0
    result_0 = data_0.pop()
    assert result_0 is None


# Generated at 2022-06-25 14:56:06.152267
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    type_0 = token.DIVIDE
    value_0 = None
    newstate_0 = 11
    context_0 = None
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:56:09.389416
# Unit test for method pop of class Parser
def test_Parser_pop():
    """Test method pop of class Parser"""
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)

    # Testing the default value returned.
    if parser_0.pop() is None:
        print("Test PASSED")
    else:
        print("Test FAILED")


# Generated at 2022-06-25 14:56:12.590391
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    optional_1 = None
    parser_1 = Parser(grammar_1, optional_1)
    parser_1.setup()
    parser_1.addtoken("", "", "")
    parser_1.pop()
    parser_1.pop()


# Generated at 2022-06-25 14:57:48.705054
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    parser_0.pop()


# Generated at 2022-06-25 14:57:56.378709
# Unit test for method shift of class Parser
def test_Parser_shift():
    """
    The test case asserts that the method 'Parser.shift'
    returns what it is supposed to return.
    """
    grammar_0 = module_0.Grammar()
    optional_0 = None
    parser_0 = Parser(grammar_0, optional_0)
    raw_node_0 = (None, None, None, None)
    def convert_0(
        grammar_1: module_0.Grammar,
        node_0: raw_node_0
    ) -> Optional[Leaf]:
        return Leaf(type=raw_node_0[0], value=node_0[1], context=node_0[2])
    parser_0 = Parser(grammar_0, convert_0)
    token_0 = token.NAME
    value_0 = "test_value"
    context_

# Generated at 2022-06-25 14:58:00.505361
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_1 = module_0.Grammar()
    optional_1 = None
    parser_1 = Parser(grammar_1, optional_1)
    type_0 = token.NAME
    value_0 = None
    context_0 = None
    optional_2 = None
    output = parser_1.classify(type_0, value_0, context_0)
    assert output == optional_2
