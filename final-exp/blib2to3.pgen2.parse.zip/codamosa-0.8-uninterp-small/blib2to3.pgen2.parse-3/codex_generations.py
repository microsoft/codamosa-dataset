

# Generated at 2022-06-25 14:48:10.236073
# Unit test for method shift of class Parser
def test_Parser_shift():
    from . import token
    from . import grammar
    from . import driver
    from . import convert

    class MockContext():
        pass

    gram_0 = grammar.Grammar()
    state_0 = MockContext()
    parser_0 = Parser(gram_0)
    parser_0.shift(token.LPAR, '(', 1, state_0)



# Generated at 2022-06-25 14:48:19.538157
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    popdfa_0 = None
    popstate_0 = 0
    popnode_0 = (0, None, None, None)
    newnode_0 = popnode_0
    dfa_0 = None
    state_0 = 0
    node_0 = (0, None, None, [])
    assert parser_0.pop() == None
    assert parser_0.pop() == None
    assert parser_0.pop() == None


# Generated at 2022-06-25 14:48:24.181676
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    # Call shift
    # Call pop
    # Call push


# Generated at 2022-06-25 14:48:28.023073
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    # Get the root of abstract syntax tree
    root_0 = parser_0.rootnode

    # Check the root of abstract syntax tree
    assert root_0 is None

# Generated at 2022-06-25 14:48:30.920566
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    ## Input arguments
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.addtoken(1, value=None, context=None)


# Generated at 2022-06-25 14:48:40.766470
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert parser_0.grammar is grammar_0
    assert parser_0.convert is lam_sub
    assert parser_0.stack == [(grammar_0.dfas[1], 0, (1, None, None, []))]
    assert parser_0.rootnode is None
    assert parser_0.used_names == set()
    parser_0.addtoken(1, "a", (None, None))

# Generated at 2022-06-25 14:48:45.956848
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = [(([[(1, 1)], [(0, 1)]], {1: 0}), 0, (1, None, None, None))]
    parser_0.shift(1, 'a', 1, 'a')


# Generated at 2022-06-25 14:48:48.402921
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()



# Generated at 2022-06-25 14:48:50.593646
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:48:51.719932
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # 
    # 
    test_case_0()



# Generated at 2022-06-25 14:49:05.271824
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # previous test
    parser_0.setup()
    leaf_1 = Leaf(type=1, value='c', context=None)
    leaf_2 = Leaf(type=1, value='c', context=None)
    leaf_3 = Leaf(type=1, value='c', context=None)
    leaf_4 = Leaf(type=1, value='c', context=None)
    # input:
    #   [leaf_1, leaf_2, leaf_3, leaf_4]
    # output:
    #   [leaf_1, leaf_2, leaf_3, leaf_4]

# Generated at 2022-06-25 14:49:07.830937
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Calling shift method
    parser_0.shift(0, None, 0, None)



# Generated at 2022-06-25 14:49:12.454382
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    class_1 = 21
    value_1 = None
    context_1 = (1, 2)
    result_1 = parser_1.addtoken(class_1, value_1, context_1)


# Generated at 2022-06-25 14:49:15.958311
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.addtoken(0, 0, 0) is True


# Generated at 2022-06-25 14:49:25.011007
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newdfa = [[(0, 0)], {0: {0: [(1, 0)], 1: [(0, 0)]}, 1: {0: [(1, 0)], 1: [(0, 0)]}}]
    newstate = 1
    context = (1, 2)
    assert (
        parser_0.stack
        == [
            (
                newdfa,
                newstate,
                [
                    5,
                    None,
                    context,
                    [
                        [1, None, context, []],
                        [3, None, context, [3]],
                        [1, None, context, []],
                    ],
                ],
            )
        ]
    )


# Generated at 2022-06-25 14:49:31.035592
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    parser_0 = Parser()
    try:
        parser_0.addtoken(token.NAME, "foo", (1, 2))
    except Exception:
        pass
    try:
        parser_0.addtoken(token.NAME, "foo", (1, 2))
    except Exception:
        pass
    try:
        parser_0.addtoken(token.NAME, "foo", (1, 2))
    except Exception:
        pass


# Generated at 2022-06-25 14:49:38.416288
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    class context_0(object):
        __class__ = module_0.Context
        def __init__(self):
            self.end = 'end'
            self.node = module_0.Context()
            self.start = 'start'
        def __getattr__(self, arg):
            pass
    newstate_0 = 0
    parser_0.shift(0, '', newstate_0, context_0())


# Generated at 2022-06-25 14:49:42.754683
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Setup
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Test
    result = parser_0.addtoken(token.NAME, 'abc', Context('abc', 1, 0))
    # Verification
    assert result == False


# Generated at 2022-06-25 14:49:45.563826
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:49:52.801375
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert parser_0.addtoken(1, "value", Context(1,1)) == False
    assert parser_0.addtoken(1, "value", Context(1,1)) == False
    assert parser_0.addtoken(1, "value", Context(1,1)) == False
    assert parser_0.addtoken(1, "value", Context(1,1)) == False
    assert parser_0.addtoken(1, "value", Context(1,1)) == True


# Generated at 2022-06-25 14:50:03.065135
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, " ", None)
    parser_0.addtoken(1, " ", None)
    parser_0.addtoken(1, " ", None)


# Generated at 2022-06-25 14:50:09.228257
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0, state_0, node_0 = parser_0.stack[-1]
    rawnode_0: RawNode = (type, value, context, None)
    parser_0.stack[-1] = (dfa_0, newstate, node_0)


# Generated at 2022-06-25 14:50:18.974171
# Unit test for method pop of class Parser
def test_Parser_pop():
    import blib2to3.pgen2.grammar as module_0
    import blib2to3.pgen2.token as module_1
    import blib2to3.pytree as module_2
    import sys as module_3
    import typing as module_4
    import unittest as module_5
    import unittest.mock as module_6
    import __main__ as module_7
    import blib2to3.pgen2.pgen as module_8
    import blib2to3.pgen2.convert as module_9
    import re as module_10
    import tempfile as module_11
    import blib2to3.pgen2.parse as module_12
    import blib2to3.pgen2.pgen2_parse as module_13

    testcase

# Generated at 2022-06-25 14:50:21.259598
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)


# Generated at 2022-06-25 14:50:25.428961
# Unit test for method push of class Parser
def test_Parser_push():
    parser_0 = Parser(grammar_0)
    type_0 = int()
    newdfa_0 = DFAS()
    newstate_0 = int()
    context_0 = Context()
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:50:27.593027
# Unit test for method push of class Parser
def test_Parser_push():
    # Tests for correctness
    # TODO: Write tests for correctness
    # Tests for exceptions
    # TODO: Write tests for exceptions
    pass


# Generated at 2022-06-25 14:50:31.497861
# Unit test for method shift of class Parser
def test_Parser_shift():
    while True:
        grammar_0 = module_0.Grammar()
        parser_0 = Parser(grammar_0)
        type_0 = -99
        value_0 = "hello"
        newstate_0 = 33
        context_0 = Context(1, 100)
        parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:50:36.335741
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    token_0 = token.NAME
    value_0 = 'qefeb'
    context_0 = Context()
    assert_0 = False
    result_0 = parser_0.addtoken(token_0, value_0, context_0)
    assert result_0 == assert_0


# Generated at 2022-06-25 14:50:42.622029
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    str_0 = 'test_Parser_addtoken'
    str_1 = 'test_Parser_addtoken'
    str_2 = 'test_Parser_addtoken'
    parser_0 = Parser(grammar_0)
    context_0 = Context(str_0, str_1, str_2)
    parser_0.addtoken(1, '1', context_0)



# Generated at 2022-06-25 14:50:43.625554
# Unit test for method classify of class Parser
def test_Parser_classify():
    test_case_0()

# Generated at 2022-06-25 14:50:49.653500
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test_case_0()


# Generated at 2022-06-25 14:50:56.378834
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 5

# Generated at 2022-06-25 14:51:05.611157
# Unit test for method shift of class Parser
def test_Parser_shift():
    test_case_0()
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    grammar_0.tokens = {1: 1, 2: 2}
    grammar_0.dfas = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
    parser_0.stack = [[(1, 2, [1, 2, 3]), 4, 5], [(6, 7, [6, 7, 8]), 9, 10]]
    parser_0.stack[-1][2][2] = [1, 2, 3]
    parser_0.convert = lambda grammar, node: node
    parser_0.shift(1, 1, 2, 1)

# Generated at 2022-06-25 14:51:11.082119
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert len(parser_0.stack) == 1
    parser_0.shift(token.NEWLINE, None, 1, ((1, 0), (1, 0)))
    assert len(parser_0.stack) == 1


# Generated at 2022-06-25 14:51:18.892969
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = int()
    value_0 = Text()
    context_0 = Context(context=Context(context=Context()), lineno=1, col_offset=2)
    assert parser_0.addtoken(type_0, value_0, context_0) == False
    type_1 = int()
    value_1 = Text()
    context_1 = Context(context=Context(context=Context()), lineno=1, col_offset=3)
    assert parser_0.addtoken(type_1, value_1, context_1) == False


# Generated at 2022-06-25 14:51:30.816238
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    # Test case 1
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(0, None, None)
    parser_0.addtoken(1, None, None)
    parser_0.addtoken(2, None, None)
    parser_0.addtoken(3, None, None)

    # Test case 2
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(4, None, None)

# Generated at 2022-06-25 14:51:35.190653
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 1
    value_0 = 'def'
    context_0 = Context(0, '', 0, 0)
    assert not parser_0.addtoken(type_0, value_0, context_0)


# Generated at 2022-06-25 14:51:44.848215
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # See the grammar module for more information.
    from . import grammar
    from . import token
    from .token import ISTREAM
    from .tokenize import COMMENT
    from .pytokenize import tokenprog
    
    # Put in your test code here
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Constructor.
    # The grammar argument is a grammar.Grammar instance; see the
    # grammar module for more information.
    
    # The parser is not ready yet for parsing; you must call the
    # setup() method to get it started.
    
    # The optional convert argument is a function mapping concrete
    # syntax tree nodes to abstract syntax tree nodes.  If not
    # given, no conversion is done and the syntax tree produced is
    # the concrete

# Generated at 2022-06-25 14:51:47.903731
# Unit test for method pop of class Parser
def test_Parser_pop():
    p = Parser(grammar_0)
    p.pop()
    assert(isinstance(popdfa, DFAS))
    assert(isinstance(popstate, int))
    assert(isinstance(popnode, RawNode))

    raise NotImplementedError()


# Generated at 2022-06-25 14:51:55.860845
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    # Testing with the 0th item in the dict.
    parser_1.shift(270, None, 1, (1, 2))
    # Testing with the 0th item in the dict.
    parser_1.shift(270, None, 1, (1, 2))
    # Testing with the 0th item in the dict.
    parser_1.shift(270, None, 1, (1, 2))
    

# Generated at 2022-06-25 14:52:11.457110
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(0, 0, 0, 0)
    parser_0.shift(0, 0, 0, 0)
    parser_0.setup()
    parser_0.shift(0, 0, 0, 0)
    parser_0.shift(0, 0, 0, 0)
    parser_0.setup()


# Generated at 2022-06-25 14:52:16.735226
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type = token.STRING
    value = "\" 'asdf' \""
    newstate = 0
    context = Context()

    test_Parser_shift_expected = parser_0.shift(type, value, newstate, context)

    assert test_Parser_shift_expected == None


# Generated at 2022-06-25 14:52:19.845387
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    result = parser_1.pop()
    assert type(result) == None


# Generated at 2022-06-25 14:52:22.881492
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    grammar_0.start = 3
    grammar_0.keywords = {'if': 2}
    parser_0.addtoken(token.IF, 'if', Context(1, 0))
    parser_0.pop()


# Generated at 2022-06-25 14:52:24.914914
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    assert hasattr(parser_1, "pop")

# Generated at 2022-06-25 14:52:28.408017
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    token_0 = token.NAME
    value_0 = None
    context_0 = Context()
    newstate_0 = 1
    try:
        parser_0.shift(token_0, value_0, newstate_0, context_0)
    except ParseError:
        pass


# Generated at 2022-06-25 14:52:32.561628
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    module_1 = type(parser_1)
    method_0 = module_1.push
    assert not hasattr(method_0, "notcallable")


# Generated at 2022-06-25 14:52:38.290072
# Unit test for method shift of class Parser
def test_Parser_shift():
    import blib2to3.pgen2.grammar as module_0
    grammar_0 = module_0.Grammar()
    import blib2to3.pgen2.token as module_1
    parser_0 = Parser(grammar_0)
    type_0 = module_1.string_to_type("NAME")
    value_0 = "xxx"
    newstate_0 = 12
    context_0 = (0, 0)
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:52:41.611500
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = Parser(module_0.Grammar())
    parser_0.setup()
    parser_0.addtoken(1, "", "")
    parser_0.stack.append(("", 0, ()))
    parser_0.pop()


# Generated at 2022-06-25 14:52:51.333527
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    popdfa_0, popstate_0, popnode_0 = parser_0.stack.pop()
    newnode_0 = parser_0.convert(parser_0.grammar, popnode_0)
    if newnode_0 is not None:
        if parser_0.stack:
            dfa_0, state_0, node_0 = parser_0.stack[-1]
            assert node_0[-1] is not None
            node_0[-1].append(newnode_0)
        else:
            parser_0.rootnode = newnode_0
            parser_0.rootnode.used_names = parser_0.used_names


# Generated at 2022-06-25 14:53:15.192577
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    assert parser_0.addtoken(0, 0, 0) == False, "Bad return value"


# Generated at 2022-06-25 14:53:21.855216
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    try:
        parser_0.push(0, (None,), 0, None)
    except AssertionError as error:
        print("AssertionError: ", error.args)
    try:
        parser_0.push(0, (None,), 0, None)
    except AssertionError as error:
        print("AssertionError: ", error.args)
    try:
        parser_0.push(0, (None,), 0, None)
    except AssertionError as error:
        print("AssertionError: ", error.args)

# Generated at 2022-06-25 14:53:23.787478
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()

# Generated at 2022-06-25 14:53:27.885954
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NAME
    value_0 = "print"
    context_0 = Context()
    result_0 = parser_0.addtoken(type_0, value_0, context_0)
    assert result_0 == False


# Generated at 2022-06-25 14:53:30.023769
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:53:33.121136
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:53:36.257983
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    start_0 = None

    parser_0.setup(start_0)

    assert parser_0.rootnode is None


# Generated at 2022-06-25 14:53:43.142879
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    seq = [
        (1, "1", (1, 0)),
        (2, "2", (1, 2)),
        (3, "3", (1, 4)),
        (1, "1", (2, 0)),
        (2, "2", (2, 2)),
        (3, "3", (2, 4)),
    ]

    for type, value, context in seq:
        if parser_0.addtoken(type, value, context):
            break


# Generated at 2022-06-25 14:53:48.477458
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Setup
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    int_0 = 0
    str_0 = ""
    context_0 = Context(int_0, int_0)

    # Invocation
    result_0 = parser_0.addtoken(int_0, str_0, context_0)

    # Verification
    bool_0 = result_0 is False
    assert bool_0



# Generated at 2022-06-25 14:53:50.474167
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:54:54.527631
# Unit test for method shift of class Parser
def test_Parser_shift():
    # Tests whether adding of a token is done by shift()
    parser_0 = Parser(None)
    parser_0.rootnode = None
    parser_0.shift(None, None, None, None)
    assert parser_0.rootnode is None


# Generated at 2022-06-25 14:54:59.842847
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type = 3
    value = "\"\"\""""
    context = Context()
    parser_0.classify(type, value, context)
    type = 0
    value = "\"\"\""""
    parser_0.classify(type, value, context)


# Generated at 2022-06-25 14:55:06.576566
# Unit test for method pop of class Parser
def test_Parser_pop():
    def test_case_1():
        popdfa_0 = ((0, 2, 2), {0: [(1, 0), (1, 1)], 1: [(1, 1), (2, 1)]})
        popstate_0 = 2
        popnode_0 = (1, 5, 'Test', [])
        newnode_0 = None
        if newnode_0 is not None:
            if ((popdfa_0, popstate_0, popnode_0)):
                dfa_0, state_0, node_0 = ((popdfa_0, popstate_0, popnode_0))
                assert node_0[-1] is not None
                node_0[-1].append(newnode_0)

# Generated at 2022-06-25 14:55:08.943774
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:55:09.672951
# Unit test for method pop of class Parser
def test_Parser_pop():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 14:55:14.830924
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    #
    # Test method classify of class Parser
    assert parser_0.classify(1,1,1) == 1, "test_Parser_classify_0 failed"


# Generated at 2022-06-25 14:55:21.899476
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import random
    rnd_type = random.random
    rnd_value = random.random
    rnd_context = random.random
    rnd_p = Parser(rnd_grammar, rnd_convert)
    rnd_type = random.random
    rnd_value = random.random
    rnd_context = random.random
    rnd_result = rnd_p.addtoken(rnd_type, rnd_value, rnd_context)
    # Return boolean
    assert type(rnd_result) == bool


# Generated at 2022-06-25 14:55:25.333099
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_class_0 = module_0.Class()
    test_method_0 = module_0.Method()
    test_method_1 = module_0.Method()


# Generated at 2022-06-25 14:55:27.425895
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.addtoken(1, '', None)


# Generated at 2022-06-25 14:55:32.241298
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newstate_0 = 0
    type_0 = 0
    context_0 = Context()
    parser_0.shift(type_0, '', newstate_0, context_0)


# Generated at 2022-06-25 14:56:29.278929
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    assert parser.addtoken(1, 2, 3) == False


# Generated at 2022-06-25 14:56:32.182148
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar = blib2to3.pgen2.grammar.Grammar()
    parser_0 = Parser(grammar)
    parser_0.pop()


# Generated at 2022-06-25 14:56:35.901415
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.push(57, parser_0.grammar.dfas[57], 0, None)


# Generated at 2022-06-25 14:56:38.683668
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert_equals(True, parser_0.addtoken(None, None, None))


# Generated at 2022-06-25 14:56:43.050225
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0 = Parser(grammar_0)
    parser_0 = Parser(grammar_0)
    parser_0 = Parser(grammar_0)
    parser_0 = Parser(grammar_0)


# Generated at 2022-06-25 14:56:45.143815
# Unit test for method pop of class Parser
def test_Parser_pop():
    popdfa = module_0.Grammar()
    popstate = 0
    popnode = module_0.Grammar()
    parser_2 = Parser(popnode)
    parser_2.pop()


# Generated at 2022-06-25 14:56:47.469083
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    random_0 = int()
    random_1 = str()
    try:
        parser_0.pop()
    except Exception:
        raise RuntimeError


# Generated at 2022-06-25 14:56:51.173676
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_1 = Parser(grammar_0)
    parser_2 = Parser(grammar_0)
    parser_3 = Parser(grammar_0)

if __name__ == '__main__':
    import typing
    typing.no_type_check(test_case_0)
    typing.no_type_check(test_Parser_addtoken)

# Generated at 2022-06-25 14:56:52.362779
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)


# Generated at 2022-06-25 14:56:55.637608
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.push(1, (1, 2), 1, 1)
    assert parser_0.stack[0][0] == (1, 2)

