

# Generated at 2022-06-25 14:48:19.353582
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    var_0 = parser_0.addtoken(0, None, 0)
    assert var_0 == False, 'var_0'
    var_0 = parser_0.addtoken(0, None, 0)
    assert var_0 == False, 'var_0'
    var_0 = parser_0.addtoken(0, None, 0)
    assert var_0 == False, 'var_0'
    var_0 = parser_0.addtoken(0, None, 0)
    assert var_0 == False, 'var_0'
    var_0 = parser_0.addtoken(0, None, 0)
    assert var_0 == False, 'var_0'
    var_0 = parser

# Generated at 2022-06-25 14:48:27.246151
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = token.NAME
    value_0 = "name"
    context_0 = Context()
    ilabel_0 = parser_0.classify(type_0, value_0, context_0)
    ilabel_1 = parser_0.classify(type_0, value_0, context_0)
    assert ilabel_0 == ilabel_1


# Generated at 2022-06-25 14:48:30.428115
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert_raises(IndexError, parser_0.pop)


# Generated at 2022-06-25 14:48:38.307955
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    stackentry_0 = (0, 0, [])
    parser_0.stack = [stackentry_0]
    newdfa_0 = (0, {0: [(0, 0)]})
    newstate_0 = 0
    context_0 = Context()
    parser_0.push(0, newdfa_0, newstate_0, context_0)
    assert parser_0.stack[0] == (0, 0, [])


# Generated at 2022-06-25 14:48:42.297286
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    # No assertion
    parser_0 = Parser(grammar_0)
    # No assertion
    parser_0.setup()
    # No assertion
    parser_0.setup(255)


# Generated at 2022-06-25 14:48:45.458461
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    try:
        parser_1.pop()
    except :
        pass


# Generated at 2022-06-25 14:48:50.946882
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """
    Unit test for method addtoken of class Parser
    """
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # TODO: should be
    type_0 = token.NAME
    value_0 = "Mock"
    context_0 = Context()
    result_0 = parser_0.addtoken(type_0, value_0, context_0)
    assert result_0 == False


# Generated at 2022-06-25 14:48:53.201647
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_1 = Parser(grammar_0)
    parser_1.shift(int, int, int, int)


# Generated at 2022-06-25 14:48:56.631992
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    popdfa_0 = module_0.Grammar()
    popstate_0 = 0
    popnode_0 = module_0.Grammar()
    parser_0.stack = [(popstate_0, popdfa_0, popnode_0)]
    parser_0.pop()


# Generated at 2022-06-25 14:49:05.138472
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(256)
    parser_0.addtoken(0, None, None)
    assert parser_0.rootnode is None
    assert parser_0.classify(303, None, None) == 303
    parser_0.setup(257)

# Generated at 2022-06-25 14:49:13.367266
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    parser_1.shift(5, 'c', 0, 'a')


# Generated at 2022-06-25 14:49:15.262400
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:49:18.687808
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(None)
    parser_0.shift(1, None, 0, None)


# Generated at 2022-06-25 14:49:22.374613
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(token.ENDMARKER, create_string('$'), create_context(10, -1, -1))


# Generated at 2022-06-25 14:49:23.051554
# Unit test for method setup of class Parser
def test_Parser_setup():
    test_case_0()


# Generated at 2022-06-25 14:49:25.513155
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    parser_0.setup()
    parser_0.addtoken(value=0, context=0, type=1)
    # Assertion
    assert True


# Generated at 2022-06-25 14:49:32.389395
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = [(([[(1, 0)]], 0), 0, (None, None, None, None))]
    parser_0.shift(token.NAME, "abcd", 0, None)
    parser_0.stack = [(([[(1, 0)]], 0), 0, (None, None, None, None))]
    parser_0.shift(token.NAME, "abcd", 0, None)


# Generated at 2022-06-25 14:49:34.550946
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()

# Generated at 2022-06-25 14:49:36.955742
# Unit test for method pop of class Parser
def test_Parser_pop():
    test_case_0()
    test_case_0()

import blib2to3.pgen2.convert as module_1


# Generated at 2022-06-25 14:49:46.994988
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = module_0.DFA()
    state_0 = module_0.State()
    node_0 = module_0.Node()
    dfa_0.states.append(state_0)
    type_0 = module_0.TokenType()
    value_0 = module_0.TokenValue()
    context_0 = module_0.TokenContext()
    newstate_0 = module_0.TokenState()
    parser_0.stack.append((dfa_0, state_0, node_0))
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:50:07.369471
# Unit test for method shift of class Parser
def test_Parser_shift():
    test_case_0()
    global parser_0
    parser_0.shift(1, 'a', 2, 'foo')


# Generated at 2022-06-25 14:50:12.233792
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = DFA
    newdfa_0 = DFAS
    newdfa_0 = DFAS
    newstate_0 = 2
    context_0 = Context
    parser_0.push(newdfa_0, newdfa_0, newstate_0, context_0)



# Generated at 2022-06-25 14:50:16.684818
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.stack.pop() == ((), 0, (None, None, None, None))


# Generated at 2022-06-25 14:50:20.703859
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    token_0 = token.Token()
    context_0 = Context()
    parser_0.addtoken(token_0, token_0, context_0)


# Generated at 2022-06-25 14:50:24.890081
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 0
    value_0 = ""
    context_0 = Context(0, None, None, None)
    assert parser_0.addtoken(type_0, value_0, context_0) == False


# Generated at 2022-06-25 14:50:28.915151
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = token.NAME
    value_0 = "for"
    context_0 = Context(prec=7)
    parser_0.addtoken(type_0, value_0, context_0)


# Generated at 2022-06-25 14:50:38.064058
# Unit test for method pop of class Parser
def test_Parser_pop():
    # Create the instance
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    parse_stack = parser.stack
    parse_stack.append((1,3,1))
    parser.addtoken(type=0, value=0, context=0)
    parser.addtoken(type=0, value=0, context=0)
    parser.addtoken(type=0, value=0, context=0)
    parser.addtoken(type=0, value=0, context=0)
    parser.addtoken(type=0, value=0, context=0)
    parser.addtoken(type=0, value=0, context=0)
    parser.addtoken(type=0, value=0, context=0)

# Generated at 2022-06-25 14:50:47.457155
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Initialization of the testing variables
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    help(parser_0.addtoken)
    parser_0.setup()
    help(parser_0.addtoken)
    parser_0.addtoken(  )
    help(parser_0.addtoken)
    parser_0.addtoken( 1, 1, () )
    help(parser_0.addtoken)
    parser_0.addtoken( token.NAME, 'dummy', () )
    help(parser_0.addtoken)
    parser_0.addtoken( token.ENDMARKER, 'dummy', () )


# Generated at 2022-06-25 14:50:49.903494
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    optional_arg = None
    parser.setup(optional_arg)



# Generated at 2022-06-25 14:50:59.614762
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = [[[1, [1, 0], (1, 0)], 0, [1, 1, 0]]]
    parser_0.shift(1, 0, 0, 1)
    assert parser_0.stack == [[[1, [1, 0], (1, 0)], 0, [1, 1, 0]]]
    
    
    
    
    
    


if __name__ == '__main__':
    import sys
    sys.exit(pytest.main(args=[__file__]))

# Generated at 2022-06-25 14:51:24.196254
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = blib2to3.pgen2.grammar.Grammar()
    # testcase for method pop (line 137) of class Parser
    parser_1 = Parser(grammar_1)
    test_case_1(parser_1)


# Generated at 2022-06-25 14:51:29.780343
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type = token.ERRORTOKEN
    value = None
    newstate = 0
    context = Context()
    parser_0.shift(type, value, newstate, context)


# Generated at 2022-06-25 14:51:37.152643
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    # Line 446 of Grammar.txt
    parser_0.addtoken(1, "file_input", (3, 1))
    # Line 447 of Grammar.txt
    parser_0.addtoken(11, "{", (4, 0))
    # Line 448 of Grammar.txt
    parser_0.addtoken(8, "}", (5, 0))
    # Line 449 of Grammar.txt
    parser_0.addtoken(3, "ENDMARKER", (6, 0))


# Generated at 2022-06-25 14:51:43.153578
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.push(token.NAME, grammar_0.dfas[token.NAME], 0, Context(0, 0))
    parser_0.addtoken(token.NAME, 'Name', Context(0, 0))
    parser_0.addtoken(5, '', Context(0, 0))

# Generated at 2022-06-25 14:51:45.421738
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:51:48.704184
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = 3
    value_0 = 'test'
    context_0 = ()

    assert parser_0.classify(type_0, value_0, context_0) == 3


# Generated at 2022-06-25 14:51:53.326931
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(1)
    parser_0.addtoken(1, "", Context.from_token("token"))


# Generated at 2022-06-25 14:51:59.775973
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 1
    value_0 = None
    context_0 = Context(prec=0, start=(1, 1), end=(1, 2))
    try:
        assert parser_0.addtoken(type_0, value_0, context_0) == False
        assert False, "Expected ParseError"
    except ParseError:
        pass
    try:
        assert parser_0.addtoken(type_0, value_0, context_0) == False
        assert False, "Expected ParseError"
    except ParseError:
        pass


# Generated at 2022-06-25 14:52:02.762119
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.push(type, newdfa, newstate, context)


# Generated at 2022-06-25 14:52:09.681185
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_shift_0 = parser_0.shift(34, '34', 34, object())

    # check that if the move is valid the new state is pushed at the top is the parser stack
    assert parser_0.stack[-1][1] == 34

    # check that if the move is valid the node is inserted as a child of the parent node
    assert parser_0.stack[-2][2][-1][-1][-1][-1][0] == 34


# Generated at 2022-06-25 14:53:06.576258
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = -1
    value_0 = None
    context_0 = Context(1, 1)
    try:
        parser_0.addtoken(type_0, value_0, context_0)
        assert False, 'Expected exception not raised'
    except ParseError as e:
        assert e.msg == 'bad token'
        assert e.type == -1
        assert e.value is None
        assert e.context == Context(1, 1)


# Generated at 2022-06-25 14:53:08.015909
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_case_1()
    test_case_0()


# Generated at 2022-06-25 14:53:10.115192
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.stack = [(None, None, None), (None, None, None)]

 # Unit test for method classify of class Parser

# Generated at 2022-06-25 14:53:18.772918
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    parser_0 = Parser(Grammar())
    try:
        parser_0.addtoken(1, "", Context())
    except ParseError:
        pass
    parser_0 = Parser(Grammar())
    try:
        parser_0.addtoken(1, "", Context())
        parser_0.addtoken(2, "", Context())
    except ParseError:
        pass
    parser_0 = Parser(Grammar())
    try:
        parser_0.addtoken(1, "", Context())
        parser_0.addtoken(1, "", Context())
    except ParseError:
        pass
    parser_0 = Parser(Grammar())
    arg_1 = token.NEWLINE
    arg_2 = "\n"
    arg_3 = Context()
    assert parser

# Generated at 2022-06-25 14:53:21.190796
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    tokens_0 = dict()
    parser_0 = Parser(grammar_0)
    ilabel_0 = parser_0.classify(0, None, None)


# Generated at 2022-06-25 14:53:27.895606
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.NAME
    value_0 = 'foo'
    context_0 = (1, 1)
    ilabel_0 = parser_0.classify(type_0, value_0, context_0)
    print(ilabel_0)
    assert ilabel_0 == 3
    type_1 = 1
    value_1 = 'foo'
    context_1 = (1, 1)
    ilabel_1 = parser_0.classify(type_1, value_1, context_1)
    print(ilabel_1)
    assert ilabel_1 == 1
    type_2 = 1
    value_2 = 'foo'
    context_2 = (1, 1)


# Generated at 2022-06-25 14:53:32.162216
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(None)
    parser_0.addtoken(0, None, Context())
    parser_0.addtoken(0, None, Context())


# Generated at 2022-06-25 14:53:33.756901
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert_raises(ParseError, lambda: parser_0.addtoken(1, '', 1))


# Generated at 2022-06-25 14:53:36.880989
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(0, None, None)


# Generated at 2022-06-25 14:53:39.749391
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert parser_0.addtoken(0, None, None)



# Generated at 2022-06-25 14:55:01.982390
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    try:
        parser_0.pop()
    except Exception as exc:
        print(exc)


# Generated at 2022-06-25 14:55:04.856202
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.push(1, {},0, None)
    assert True # TODO: may fail on different versions of botocore


# Generated at 2022-06-25 14:55:08.435015
# Unit test for method pop of class Parser
def test_Parser_pop():
    test_case_0()


import blib2to3.pgen2.grammar as module_1
import blib2to3.pgen2.token as module_2


# Generated at 2022-06-25 14:55:18.892344
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    dfa_0, node_0 = parser_0.stack[-1]
    dfa_1, state_0, node_1 = parser_0.stack[-1]
    # Pop a nonterminal.  (Internal)
    parser_0.pop()
    # Unreachable since no return statement
    new_node_0 = parser_0.convert(parser_0.grammar, node_1)
    if parser_0.stack:
        dfa_2, state_1, node_2 = parser_0.stack[-1]
        # Unreachable since no return statement
        assert node_2[-1] is not None

# Generated at 2022-06-25 14:55:21.657294
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.addtoken(0, None, None)

# Generated at 2022-06-25 14:55:23.424696
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    state_0 = 0
    context_0 = Context()

# Generated at 2022-06-25 14:55:26.252781
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:55:28.403715
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    parser_0.pop()


# Generated at 2022-06-25 14:55:37.690486
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()

    # Test direct call of Parser.addtoken
    parser_1.addtoken(type=1, value='1', context=(1,2))
    parser_1.addtoken(type=2, value='1', context=(1,2))
    parser_1.addtoken(type=3, value='1', context=(1,2))
    parser_1.addtoken(type=4, value='1', context=(1,2))
    parser_1.addtoken(type=5, value='1', context=(1,2))
    parser_1.addtoken(type=6, value='1', context=(1,2))

# Generated at 2022-06-25 14:55:42.277694
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # case 0
    type_0 = grammar_0.tokens['NAME']
    value_0 = '__name__'
    context_0 = None
    parser_0.addtoken(type_0, value_0, context_0)
    # case 1: raise ParseError -> "bad token"
    # case 2: raise ParseError -> "too much input"
    # case 3: raise ParseError -> "bad input"
