

# Generated at 2022-06-25 14:48:17.946318
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = token.NAME
    value_0 = None
    newstate_0 = 3
    context_0 = None
    parser_0.shift(type_0, value_0, newstate_0, context_0)


# Generated at 2022-06-25 14:48:20.813710
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()

import blib2to3.pgen2.driver as module_1


# Generated at 2022-06-25 14:48:25.179471
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    import pickle
    grammar = pickle.load(open('test_grammar.pickle'))
    parser = Parser(grammar)
    parser.setup()
    assert parser.addtoken(1, 'a', None) == False

# Generated at 2022-06-25 14:48:31.570096
# Unit test for method classify of class Parser
def test_Parser_classify():
    tokens = {
        token.NAME: 10,
        token.NEWLINE: 12,
        token.NUMBER: 14,
        token.STRING: 16,
    }
    keywords = {
        "def": 18,
    }
    labels = {
        10: (token.NAME, None),
        12: (token.NEWLINE, None),
        14: (token.NUMBER, None),
        16: (token.STRING, None),
        18: (token.NAME, "def"),
    }
    start = 20
    dfas = {
        20: ([
            [(12, 1)],
            [(0, 1)],
        ], {
            0: 1,
        }),
    }

# Generated at 2022-06-25 14:48:40.181059
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # Test to see if it raises an exception
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    # This raises an exception
    def f():
        parser_1.setup()
        parser_1.addtoken()
    try:
        f()
    except TypeError:
        pass
    else:
        print("TypeError is not thrown as expected")
    # This raises an exception
    def g():
        parser_1.setup()
        parser_1.addtoken(1)
    try:
        g()
    except TypeError:
        pass
    else:
        print("TypeError is not thrown as expected")


# Generated at 2022-06-25 14:48:50.253854
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    for i in range(6):
        parser_0.addtoken(1, None, Context(prec=None, prefix=None, suffix=None))
    for i in range(7):
        parser_0.addtoken(0, None, Context(prec=None, prefix=None, suffix=None))
    for i in range(8):
        parser_0.addtoken(2, None, Context(prec=None, prefix=None, suffix=None))
    for i in range(8):
        parser_0.addtoken(2, None, Context(prec=None, prefix=None, suffix=None))

# Generated at 2022-06-25 14:48:53.411179
# Unit test for method push of class Parser
def test_Parser_push():
    from . import grammar
    from . import token
    grammar_0 = grammar.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(token.NAME, '', None)
    parser_0.used_names

# Generated at 2022-06-25 14:48:57.293959
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 16
    newdfa_0 = module_0.Grammar()
    newstate_0 = 18
    context_0 = module_0.Context
    # Set to None, because the method addtoken of class Parser accesses this property
    parser_0.rootnode = None
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:49:00.612828
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    try:
        parser_0.addtoken(256, 59, None)
    except RuntimeError:
        pass


# Generated at 2022-06-25 14:49:02.802696
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()


# Generated at 2022-06-25 14:49:18.772615
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    token_0 = token.Token(token.NAME, "v", None, None, 0)
    parser_1.addtoken(token_0.type, token_0.string, token_0.start)
    assert parser_1.stack[0][0] == parser_1.grammar.dfas[0]
    token_1 = token.Token(token.NEWLINE, "\n", None, None, 1)
    parser_1.addtoken(token_1.type, token_1.string, token_1.start)
    assert parser_1.stack[0][0] == parser_1.grammar.dfas[6]

# Generated at 2022-06-25 14:49:21.101553
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(1, None, 1, None)


# Generated at 2022-06-25 14:49:30.249582
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newstate_0 = 0
    parser_0.shift(0, None, newstate_0, None)
    parser_0.shift(0, None, newstate_0, None)
    parser_0.shift(0, None, newstate_0, None)
    parser_0.shift(0, None, newstate_0, None)
    parser_0.shift(0, None, newstate_0, None)
    parser_0.shift(0, None, newstate_0, None)
    parser_0.shift(0, None, newstate_0, None)
    parser_0.shift(0, None, newstate_0, None)


# Generated at 2022-06-25 14:49:33.382032
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-25 14:49:44.036727
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(start=1)
    parser_0.addtoken(type=1, value=None, context=Context(prec=1))
    parser_0.addtoken(type=2, value=None, context=Context(prec=2))
    parser_0.addtoken(type=3, value=None, context=Context(prec=3))
    parser_0.addtoken(type=4, value=None, context=Context(prec=4))
    parser_0.addtoken(type=5, value=None, context=Context(prec=5))
    parser_0.addtoken(type=6, value=None, context=Context(prec=6))
    parser_

# Generated at 2022-06-25 14:49:48.452269
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    def meth_0(type_0, value_0):
        return parser_0.classify(type_0, value_0, None)
    assert meth_0(module_0.token.NAME, None) == 1


# Generated at 2022-06-25 14:49:52.401388
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    assert parser_1.classify(1, None, None) == 0
    assert parser_1.classify(2, '', None) == 1
    assert parser_1.classify(3, '', None) == 2


# Generated at 2022-06-25 14:49:53.997592
# Unit test for method classify of class Parser
def test_Parser_classify():
    result = Parser.classify("inv", 1, 2)
    assert_equal(result, 3)


# Generated at 2022-06-25 14:50:01.612418
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    test0_0 = ParseError('too much input', 23, 'f', (1, 2))
    test0_1 = ParseError('bad input', 23, 'f', (1, 2))
    test0_2 = ParseError('bad token', 23, 'f', (1, 2))
    test1_0 = ParseError('too much input', 23, 'f', (1, 2))
    test1_1 = ParseError('bad input', 23, 'f', (1, 2))
    test1_2 = ParseError('bad token', 23, 'f', (1, 2))


# Generated at 2022-06-25 14:50:05.665240
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    int_0 = parser_0.addtoken( '#', '#=', None)
    assert int_0 == 0


# Generated at 2022-06-25 14:50:14.798695
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    assert parser_0.rootnode == None


# Generated at 2022-06-25 14:50:19.362445
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Classify a token
    ilabel = parser_0.classify(None, None, None)
    # Shift a token
    parser_0.shift(None, None, None, None)


# Generated at 2022-06-25 14:50:22.511021
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_1 = Parser(grammar_0)
    parser_1.setup('', '', '', '', '')


# Generated at 2022-06-25 14:50:28.950027
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    grammar_2 = module_0.Grammar()
    parser_2 = Parser(grammar_2)
    type_1 = token.NEWLINE
    value_1 = 'NEWLINE'
    context_1 = Context()
    result_1 = parser_1.addtoken(type_1, value_1, context_1)
    type_2 = token.ENDMARKER
    value_2 = 'ENDMARKER'
    context_2 = Context()
    result_2 = parser_2.addtoken(type_2, value_2, context_2)


# Generated at 2022-06-25 14:50:32.570777
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = arg(0)
    newdfa_0 = arg(1)
    newstate_0 = arg(2)
    context_0 = arg(3)
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:50:34.966977
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()


# Generated at 2022-06-25 14:50:45.707744
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    """Parse a small program"""
    from . import token
    import blib2to3.pgen2.parse as module_0
    import blib2to3.pgen2.driver as module_1
    import blib2to3.pgen2.tokenize as module_2
    import io
    # Test case 0: simple program
    input_0 = io.StringIO('import a\nimport b\n')
    result = module_2.tokenize(input_0.readline)
    # Test case 0: (input = 'import a\nimport b\n')
    # Read the first token
    try:
        token_0 = next(result)
    except StopIteration:
        token_0 = None
    # Read the second token

# Generated at 2022-06-25 14:50:48.161003
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()



# Generated at 2022-06-25 14:50:51.654999
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # import blib2to3.pgen2.grammar as module_0
    # import blib2to3.pgen2.token as module_1
    
    # grammar_0 = module_0.Grammar()
    # parser_0 = Parser(grammar_0)
    # type_0 = module_1.NAME
    # value_0 = "debug"
    # context_0 = object()
    # result_0 = parser_0.addtoken(type_0, value_0, context_0)
    # assert result_0 is True
    pass


# Generated at 2022-06-25 14:50:58.278201
# Unit test for method shift of class Parser
def test_Parser_shift():
    dummy_Token = token.STRING
    dummy_value = "dummy"
    dummy_newstate = 3
    dummy_context = Context(1,2)
    dummy_node = Node(type=dummy_Token,
        children=[Leaf(type=token.STRING, value=dummy_value,
        context=dummy_context)], context=dummy_context)

    p = Parser(Grammar())
    p.setup(dummy_Token)

    # Call shift for the first time
    p.shift(
        type=dummy_Token,
        value=dummy_value,
        newstate=dummy_newstate,
        context=dummy_context
    )

# Generated at 2022-06-25 14:51:07.818433
# Unit test for method pop of class Parser
def test_Parser_pop():

    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.rootnode = Node(type=token.NAME, children=[], context=Context(None, None))
    parser_0.pop()


# Generated at 2022-06-25 14:51:17.213835
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    try:
        parser_0.addtoken(type=0, value=None, context=None)
        assert False
    except ParseError:
        pass
    parser_0.setup()
    token_0 = token.Token
    context_0 = Context
    try:
        parser_0.addtoken(type=0, value=None, context=context_0(old_offset=0))
        assert False
    except ParseError:
        pass
    try:
        parser_0.addtoken(type=0, value=None, context=context_0(old_offset=0, lineno=1))
        assert False
    except ParseError:
        pass


# Generated at 2022-06-25 14:51:18.760150
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:51:30.559413
# Unit test for method pop of class Parser
def test_Parser_pop():
    print("testing method pop")
    # Make a Parser instance with a dummy grammar to get the basics working
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # This is the stack the parser will be using
    node_0 = ((1, "Hi", 7, None),)
    node_1 = ((2, None, 3, [node_0]),)
    stack_0 = [(grammar_0.dfas[2], 1, node_1), (grammar_0.dfas[1], 3, node_0)]
    # Initialize the stack
    parser_0.stack = stack_0
    # The expected resulting stack after popping
    node_4 = ((1, "Hi", 7, None),)

# Generated at 2022-06-25 14:51:35.267931
# Unit test for method push of class Parser
def test_Parser_push():

    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()

    # Case when type is integer
    parser_0.push(1, 1, 1, 1)
    assert True

    # Case when type is string
    parser_0.push('a', 1, 1, 1)
    assert True


# Generated at 2022-06-25 14:51:36.783708
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.shift(1,2,3,4)


# Generated at 2022-06-25 14:51:38.305515
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.shift(1, None, 0, None)


# Generated at 2022-06-25 14:51:43.388775
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newstate_0 = 0
    context_0 = Context()
    type_0 = 0
    newdfa_0 = module_0.DFAS()
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:51:44.950914
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    parser_1.setup(0)


# Generated at 2022-06-25 14:51:49.315009
# Unit test for method shift of class Parser
def test_Parser_shift():
    #
    # Test shift
    #
    #
    #
    # Test with grammar obtained from 
    # 
    grammar_1 = module_0.Grammar(grammar_str_1, 'single_input', 'file_input')
    parser_1 = Parser(grammar_1)
    #
    #
    # Test shift with no children.
    #
    node_2 = parser_1.shift(type = token.STRING, value = 'string', newstate = 0, context = 0)



# Generated at 2022-06-25 14:51:58.574431
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0: int = token.EQUAL
    value_0: str = '='
    context_0 = Context()
    parser_0.addtoken(type_0, value_0, context_0)


# Generated at 2022-06-25 14:52:00.920519
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    def addtoken():
        parser_0.addtoken(type, value, context)


# Generated at 2022-06-25 14:52:03.345762
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()



# Generated at 2022-06-25 14:52:09.040590
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # make sure there is a root node
    parser_0.setup(start=32)
    parser_0.addtoken(0, None, None)
    parser_0.pop()
    assert parser_0.stack == []
    assert parser_0.rootnode is not None
    parser_0.pop()
    parser_0.pop()
    assert parser_0.stack == []


# Generated at 2022-06-25 14:52:12.280889
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Test for TypeError
    try:
        parser_0.shift(type=module_0.DFA(), value=grammar_0, newstate=parser_0, context=parser_0)
    except TypeError: pass


# Generated at 2022-06-25 14:52:19.431201
# Unit test for method classify of class Parser
def test_Parser_classify():
    try:
        parser_0 = Parser(Grammar())
    except TypeError as e:
        assert False, "init error"
    parser_0.setup()
    try:
        assert parser_0.classify(token.NAME, "", Context()) == 5, "classify error"
    except ParseError as e:
        assert False, "classify error"
    try:
        parser_0.classify(None, None, None)
        assert False, "classify error"
    except ParseError as e:
        pass


# Generated at 2022-06-25 14:52:23.180207
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # Param 0: self
    # Param 1: type
    # Param 2: value
    # Param 3: context
    parser_0.addtoken(2, "", 0)


# Generated at 2022-06-25 14:52:27.489376
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    ilabel_0 = 'abc'
    type_0 = 'abc'
    value_0 = 'abc'
    context_0 = RawNode()
    # START TEST
    parser_0.addtoken(type_0, value_0, context_0)
    # END TEST


# Generated at 2022-06-25 14:52:35.336683
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    from blib2to3.pytree import Leaf as class_1

    parser_0.setup(57344)
    tokens = (
        (token.NAME, 'a', Context(line=0, column=0)),
        (token.NAME, 'b', Context(line=0, column=0)),
    )
    for type_0, value, context in tokens:
        leaf_0 = class_1(type=type_0, value=value, context=context)
        is_end = parser_0.addtoken(type=type_0, value=value, context=context)
        assert not is_end


# Generated at 2022-06-25 14:52:39.325046
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = token.ADD
    value_0 = 'ADD'
    context_0 = module_0.Grammar()
    ilabel_0 = parser_0.classify(type_0, value_0, context_0)
    assert ilabel_0 == 0


# Generated at 2022-06-25 14:52:51.653614
# Unit test for method pop of class Parser
def test_Parser_pop():
    parser_0 = test_case_0()
    assert isinstance(parser_0.pop(), object)

# Generated at 2022-06-25 14:52:53.682804
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    
    assert isinstance(parser_0.pop(), None.__class__)


# Generated at 2022-06-25 14:52:56.453311
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:53:00.418632
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    type_1 = 300
    value_1 = None
    context_1 = None
    result_1 = parser_1.addtoken(type_1, value_1, context_1)


# Generated at 2022-06-25 14:53:08.276668
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_test_0 = module_0.Grammar()
    parser_test_0 = Parser(grammar_test_0)
    newdfa_test_0 = (([(0, 2), (1, 6), (2, 8), (4, 10)], [(0, 1), (2, 6), (4, 8), (6, 10)]), {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, 10: 10})
    newstate_test_0 = 0
    context_test_0 = Context(allow_backslash_continuation=True, allow_implicit_encoding=True)

# Generated at 2022-06-25 14:53:10.363563
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, "v1", (1, 1))


# Generated at 2022-06-25 14:53:18.803738
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(0, None, None)

    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()
    parser_1.addtoken(1, '', None)

    grammar_2 = module_0.Grammar()
    parser_2 = Parser(grammar_2)
    parser_2.setup()
    parser_2.addtoken(2, '', ((None, None), (None, None)))

    # Test case where NG_LINE_YES
    grammar_3 = module_0.Grammar()
    parser_3 = Parser(grammar_3)

# Generated at 2022-06-25 14:53:21.703319
# Unit test for method classify of class Parser
def test_Parser_classify():
    # Setup Parser instance
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    # Assert call to classify with argument 'token.NAME', '___', (1, 0)
    assert parser_0.classify('token.NAME', '___', (1, 0)) == 0


# Generated at 2022-06-25 14:53:25.072943
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    # 1. Arrange
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    # 2. Act
    try:
        parser_0.addtoken(1, None, None)
    except ParseError:
        # 3. Assert
        pass


# Generated at 2022-06-25 14:53:29.335223
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = token.NAME
    value_0 = 'NAME'
    context_0 = Context()
    ilabel_0 = parser_0.classify(type_0, value_0, context_0)
    assert ilabel_0 == 256


# Generated at 2022-06-25 14:53:43.824004
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    node_0 = parser_0.shift(42, 'abc', 0, Context(1, 2))


# Generated at 2022-06-25 14:53:46.327535
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)


# Generated at 2022-06-25 14:53:48.331179
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:53:51.165623
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    new_token = None
    expected_value = False
    value = parser_0.addtoken(new_token)
    assert value == expected_value


# Generated at 2022-06-25 14:53:56.736340
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.used_names = set()
    parser_0.stack = [(([[(4, 2)], [(4, 3)]], {0: 2, 1: 2, 2: 2, 3: 2}), 4, (1, None, None, []))]
    parser_0.grammar = grammar_0
    parser_0.convert = lam_sub
    parser_0.pop()


# Generated at 2022-06-25 14:54:02.535190
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    popdfa_0, popstate_0, popnode_0 = ([-1], {0: 0}), 0, (None, None, None, None)
    assert parser_0.stack.append((popdfa_0, popstate_0, popnode_0))
    parser_0.pop()

test_Parser_pop()


# Generated at 2022-06-25 14:54:07.877305
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert not parser_0.stack
    
    parser_0.stack = [('DFA', 0, ('type', None, None, []))]
    parser_0.pop()
    assert not parser_0.stack



# Generated at 2022-06-25 14:54:10.464351
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.pop()


# Generated at 2022-06-25 14:54:13.260312
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    type_0 = None
    value_0 = None
    context_0 = None
    assert parser_0.addtoken(type_0, value_0, context_0) == False


# Generated at 2022-06-25 14:54:20.830858
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
  grammar_0 = module_0.Grammar()
  parser_0 = Parser(grammar_0)
  type_0 = token.AS
  value_0 = None
  context_0 = None
  assert not parser_0.addtoken(type_0, value_0, context_0)
  type_0 = token.RPAR
  value_0 = ''
  context_0 = Context(previous_context=None, filename='', line=1, column=1)
  assert not parser_0.addtoken(type_0, value_0, context_0)
  type_0 = token.MINUS
  value_0 = '-'
  context_0 = Context(previous_context=None, filename='', line=1, column=2)

# Generated at 2022-06-25 14:55:03.456335
# Unit test for method push of class Parser
def test_Parser_push():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.setup()
    parser.push(1, (1, None), 1, 1)
    method_name = "Parser.push"
    assert len(parser.stack)==2
    err_msg = "%s did not place the correct values on the stack"%method_name
    for i in parser.stack:
        if i[1]==1:
            assert i[0]==(1, None)
            assert i[2][0]==1
            assert i[2][1] is None
            assert i[2][2]==1
            assert i[2][3]==[]


# Generated at 2022-06-25 14:55:07.048886
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    module_0.init_grammar(grammar_0)
    module_0.start_grammar(grammar_0)
    type_0 = 0
    value_0 = 0
    context_0 = Context((0, 0))
    assert not parser_0.addtoken(type_0, value_0, context_0)


# Generated at 2022-06-25 14:55:12.175897
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup(None)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 14:55:13.227773
# Unit test for method pop of class Parser
def test_Parser_pop():

    # Test case 0
    parser_0 = Parser(grammar_0)
    parser_0.pop() # Should throw exception


# Generated at 2022-06-25 14:55:14.125543
# Unit test for method push of class Parser
def test_Parser_push():
    test_case_0()


# Generated at 2022-06-25 14:55:16.201833
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    parser_0.addtoken(0, None, None)

# Generated at 2022-06-25 14:55:19.497492
# Unit test for method addtoken of class Parser
def test_Parser_addtoken():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, None, None)


# Generated at 2022-06-25 14:55:23.030026
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, None, None)


# Generated at 2022-06-25 14:55:25.972593
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert_raises_regex(ParseError, "bad input", parser_0.classify, 3, None, Context)


# Generated at 2022-06-25 14:55:27.586330
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

# Generated at 2022-06-25 14:56:01.347224
# Unit test for method setup of class Parser
def test_Parser_setup():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()

    assert parser_1.stack == [(grammar_1.dfas[grammar_1.start], 0, (grammar_1.start, None, None, []))]
    assert parser_1.rootnode == None
    assert parser_1.used_names == set()


# Generated at 2022-06-25 14:56:04.854251
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_1 = token.NAME
    value_0 = "NAME"
    context_0 = Context()
    test_case_0(parser_0.classify(type_1, value_0, context_0), 1)


# Generated at 2022-06-25 14:56:05.810237
# Unit test for method classify of class Parser
def test_Parser_classify():
    pass


# Generated at 2022-06-25 14:56:10.367178
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    grammar_2 = module_0.Grammar()
    parser_2 = Parser(grammar_2)
    grammar_3 = module_0.Grammar()
    parser_3 = Parser(grammar_3)
    grammar_4 = module_0.Grammar()
    parser_4 = Parser(grammar_4)


# Generated at 2022-06-25 14:56:12.480376
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.addtoken(1, 'abc', (1, 23))

# Generated at 2022-06-25 14:56:21.697143
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar = module_0.Grammar()
    parser = Parser(grammar)
    parser.classify(0, "", ())
    parser.classify(1, "a", ())
    parser.classify(2, "ab", ())
    parser.classify(3, "abc", ())
    parser.classify(4, "abcd", ())
    parser.classify(5, "abcde", ())
    parser.classify(6, "abcdef", ())
    parser.classify(7, "abcdefg", ())
    parser.classify(8, "abcdefgh", ())
    parser.classify(9, "abcdefghi", ())
    parser.classify(10, "abcdefghij", ())
    parser.classify(11, "abcdefghijk", ())

# Generated at 2022-06-25 14:56:23.647504
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    assert parser_0.shift(None, None, None, None) is None


# Generated at 2022-06-25 14:56:25.254354
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.setup()


# Generated at 2022-06-25 14:56:29.368443
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    type_0 = 0
    newdfa_0 = parser_0.grammar.dfas[type_0]
    newstate_0 = 0
    context_0 = Context()
    parser_0.push(type_0, newdfa_0, newstate_0, context_0)
    assert parser_0.stack == [
        (([(1.5, 0)], set([1.5])), 0, (0, None, None, []))
    ]



# Generated at 2022-06-25 14:56:31.944179
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)



# Generated at 2022-06-25 14:57:10.630004
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    try:
        parser_0.pop()
    except ParseError as exc_0:
        assert type(exc_0) == ParseError

if __name__ == '__main__':
    import py.test

    py.test.main()

# Generated at 2022-06-25 14:57:13.385060
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.push(10, (None, None), 0, 10)


# Generated at 2022-06-25 14:57:18.824758
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    dfa_0 = [0, 1, 2, 3]
    newdfa_0 = (dfa_0,)
    newstate_0 = 2
    context_0 = Context(preceding=())
    parser_0.push(13, newdfa_0, newstate_0, context_0)


# Generated at 2022-06-25 14:57:24.349022
# Unit test for method push of class Parser
def test_Parser_push():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    newnode_0 = dict()
    node_0 = (0, None, None, newnode_0)
    node_1 = (0, None, None, [])
    parser_0.stack = [(0, 0, node_0), (0, 0, node_1)]
    parser_0.push(0, 0, 0, None)


# Generated at 2022-06-25 14:57:27.683570
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    try:
        parser_0.pop()
    except Exception as inst_0:
        print(inst_0)


# Generated at 2022-06-25 14:57:29.587927
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.pop()


# Generated at 2022-06-25 14:57:32.376084
# Unit test for method shift of class Parser
def test_Parser_shift():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.shift(0, None, 0, None)


# Generated at 2022-06-25 14:57:35.198519
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)
    parser_0.setup()
    parser_0.pop()


# Generated at 2022-06-25 14:57:39.148676
# Unit test for method classify of class Parser
def test_Parser_classify():
    grammar_0 = module_0.Grammar()
    parser_0 = Parser(grammar_0)

    # Method classify from class Parser (line 131) with arguments type, value and context
    # Testing if call to function classify raises ParseError (line 141)
    try:
        parser_0.classify(1, None, None)
    except ParseError:
        pass
    else:
        assert False, "expected exception"



# Generated at 2022-06-25 14:57:40.664993
# Unit test for method pop of class Parser
def test_Parser_pop():
    grammar_1 = module_0.Grammar()
    parser_1 = Parser(grammar_1)
    parser_1.pop()
