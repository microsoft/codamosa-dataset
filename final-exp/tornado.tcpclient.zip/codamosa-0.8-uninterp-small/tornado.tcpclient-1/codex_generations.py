

# Generated at 2022-06-26 08:54:19.902216
# Unit test for constructor of class _Connector
def test__Connector():
    m_io_loop = IOLoop()
    m_io_loop.make_current()
    m_addrinfo = [
        (socket.AF_INET6, ("10.0.0.1", 8000), 0, 0),
        (socket.AF_INET, ("10.0.0.2", 8000), 0, 0),
        (socket.AF_INET6, ("10.0.0.3", 8000), 0, 0),
        (socket.AF_INET, ("10.0.0.4", 8000), 0, 0),
        (socket.AF_INET6, ("10.0.0.5", 8000), 0, 0),
        (socket.AF_INET, ("10.0.0.6", 8000), 0, 0),
    ]

# Generated at 2022-06-26 08:54:29.534796
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    t_c_p_client_0 = TCPClient()
    resolver = t_c_p_client_0.resolver
    initial_timeout = 0
    connect_timeout = None
    try:
        addrs = resolver.resolve('localhost', 8080)
        assert(len(addrs) > 0)
    except Exception as e:
        addrs = []
        pass
    def connect(af, addr):
        return IOStream(socket.socket(af, socket.SOCK_STREAM), io_loop=IOLoop.current()), Future()
    connector = _Connector(addrs, connect)
    connector.start(initial_timeout, connect_timeout)
    assert(connector.timeout)


# Generated at 2022-06-26 08:54:41.683059
# Unit test for method split of class _Connector
def test__Connector_split():
    ans = _Connector.split(
        [
            (socket.AF_INET, ("127.0.0.1", 8888)),
            (socket.AF_INET6, ("::1", 8888)),
            (socket.AF_INET, ("192.168.1.1", 8888)),
        ]
    )
    exp = (
        [(socket.AF_INET, ("127.0.0.1", 8888)), (socket.AF_INET, ("192.168.1.1", 8888))],
        [(socket.AF_INET6, ("::1", 8888))],
    )
    print(ans[0] == exp[0])
    print(ans[1] == exp[1])


# Generated at 2022-06-26 08:54:48.153474
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    #   Compute the expected value
    expected = Exception()
    #   Initialize the arguments
    timeout = object()
    self = _Connector([], lambda af, addr: (None, Future()))
    self.timeout = timeout
    #   Call the function under test
    # noinspection PyBroadException
    actual = None
    try:
        self.clear_timeouts()
    except Exception as e:
        actual = e
    #   Assert that the result and expected values are equal
    assert expected == actual



# Generated at 2022-06-26 08:54:56.923822
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    trace_list = []
    def my_close():
        trace_list.append("my_close")
        print("my_close invoked")
    # mock the __init__ method of TCPClient
    t_c_p_client_0.resolver = Resolver(io_loop=t_c_p_client_0.io_loop)
    t_c_p_client_0.streams = set([])
    t_c_p_client_0.resolver = Resolver(io_loop=t_c_p_client_0.io_loop)
    t_c_p_client_0.max_buffer_size = None
    t_c_p_client_0.resolve_future = gen.Future()
    t_c_p_

# Generated at 2022-06-26 08:55:02.097552
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    timeout = 1
    connector = _Connector(
        [('junk', ('junk', 'junk'))],
        lambda af, addr: (None, Future())
    )

    # set_timeout without any timeout having been set previously
    connector.set_timeout(timeout)
    assert isinstance(connector.timeout, object)


# Generated at 2022-06-26 08:55:06.052996
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    resolver_test_0 = Resolver()
    result = resolver_test_0.resolve("localhost", 9999)
    connector_test_0 = _Connector(result, t_c_p_client_0.connect)
    connector_test_0.on_connect_timeout() # Expect that the TimeoutError is raised.
    return

# Generated at 2022-06-26 08:55:10.449190
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    var_timeout = 0.3
    var_connector = _Connector(None, None)
    var_connector.set_timeout(var_timeout)


# Generated at 2022-06-26 08:55:17.848001
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    try:
        test__Connector_try_connect_0()
        print('try_connect should support None iteration')
    except:
        print('try_connect should support None iteration')
        
    try:
        test__Connector_try_connect_1()
        print('try_connect should support empty list iteration')
    except:
        print('try_connect should support empty list iteration')


# Generated at 2022-06-26 08:55:22.250752
# Unit test for constructor of class _Connector
def test__Connector():
    t_C_p_0 = _Connector(addrinfo=[(socket.AddressFamily.AF_INET,('0.0.0.0',0))],connect=None)


# Generated at 2022-06-26 08:56:51.577559
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_1 = TCPClient()
    t_c_p_client_1._Connector = _Connector
    t_c_p_client_1.connect = t_c_p_client_1.connect
    t_c_p_client_1.socket = t_c_p_client_1.socket
    addrinfo = [(2, ("172.16.2.1", 5096)), (2, ("192.168.2.1", 5096)), (31, ("10.0.1.1", 5096))]
    t_c_p_client_1._Connector.__init__(t_c_p_client_1, addrinfo, t_c_p_client_1.connect)
    t_c_p_client_1.timeout = t_c_p_client_1.timeout

# Generated at 2022-06-26 08:56:58.230991
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    _connector_0 = _Connector(t_c_p_client_0.resolver.resolve('example.com', 80), t_c_p_client_0.stream_class)
    _connector_0.start()


# Generated at 2022-06-26 08:57:00.509711
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.connect("", 123)


# Generated at 2022-06-26 08:57:07.778006
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    connector_0 = _Connector(addrinfo=['127.0.0.1', '80'], connect=t_c_p_client_0)
    connector_0.close_streams()


# Generated at 2022-06-26 08:57:11.854905
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # prepare inputs
    t_c_p_client_0 = TCPClient()
    connector_0 = _Connector([(socket.AF_INET, ("127.0.0.1", 80))], t_c_p_client_0.connect)
    addrs_0 = iter([(socket.AF_INET, ("127.0.0.1", 80))])
    connector_0.try_connect(addrs_0)


# Generated at 2022-06-26 08:57:23.240540
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    i_o_loop_0 = IOLoop()
    t_c_p_client_0 = TCPClient()
    host_0 = '127.0.0.1'
    port_0 = 0
    af_0 = socket.AF_UNSPEC
    ssl_options_0 = None
    max_buffer_size_0 = 0
    source_ip_0 = None
    source_port_0 = None
    timeout_0 = None
    future_0 = asyncio.ensure_future(t_c_p_client_0.connect(host_0, port_0, af_0, ssl_options_0, max_buffer_size_0, source_ip_0, source_port_0, timeout_0))
    i_o_loop_0.run_until_complete(future_0)

# Generated at 2022-06-26 08:57:31.954364
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    t_c_p_client_0 = TCPClient()
    
    addrs = [("AF_INET", (t_c_p_client_0.host, t_c_p_client_0.port))]
    future = Future()
    future.set_result(t_c_p_client_0.stream)

    t_c_p_client_0._connector.on_connect_done(addrs, addrs[0][0], addrs[0][1], future)
    if not t_c_p_client_0._connector.future.done() or t_c_p_client_0._connector.remaining != 0:
        return False


# Generated at 2022-06-26 08:57:44.954036
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver()
    addrinfo = t_c_p_client_0.resolver.resolve("localhost", 80)

    def _connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM, 0), io_loop=IOLoop.current())
        future = stream.connect(addr)
        return (stream, future)

    _connector_0 = _Connector(addrinfo, _connect)
    _connector_0.start(_INITIAL_CONNECT_TIMEOUT)

# Generated at 2022-06-26 08:57:51.864308
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()
    
    _c_onnector_0 = _Connector(t_c_p_client_0.resolved_addrs, t_c_p_client_0.connect(0, 0, 0, 0, 0, 0, 0))
    

# Generated at 2022-06-26 08:57:56.388555
# Unit test for method start of class _Connector
def test__Connector_start():
    str = "110.80.140.25"
    addrinfo = [(2, (str, 10403, 0, 0)), (2, (str, 10403, 0, 0))]
    connect = lambda a, b: (None, Future())
    _Connector(addrinfo, connect).start()


# Generated at 2022-06-26 08:59:54.137308
# Unit test for method start of class _Connector
def test__Connector_start():
    def test_connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[
        IOStream, "Future[IOStream]"
    ]:
        return IOStream(), Future()
    af, addr, io_stream = _Connector(
        [(socket.AF_INET, ("127.0.0.1", 12345))]
    ).start()



# Generated at 2022-06-26 08:59:56.743447
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    print("Executing jasmin_tests.test__Connector_on_connect_done")
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.test_on_connect_done()


# Generated at 2022-06-26 09:00:06.962227
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    connect = lambda af, addr: (None, Future())
    future = Future()
    test_1 = _Connector([(0x1, (1,2,3,4))], connect).on_connect_done(
        iter([(0x1, (1,2,3,4))]), 0x1, (1, 2, 3, 4), future)
    assert(test_1 is None)

    future = Future()
    test_2 = _Connector([(0x1, (1,2,3,4))], connect).on_connect_done(
        iter([(0x2, (1,2,3,4))]), 0x1, (1, 2, 3, 4), future)
    assert(test_2 is None)


# Generated at 2022-06-26 09:00:18.191868
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():

    # t_c_p_client_1 = TCPClient()
    # t_c_p_client_1.connect(("www.google.com",80),callback=callback)
    # t_c_p_client_1.fetch("/",callback=callback)
    # t_c_p_client_1.on_connect_done

    # Create dummy IOStream instance
    io_stream_1 = IOStream()

    # Create dummy future
    future_1 = Future()

    # Create dummy iterator
    iterator_1 = iter([(Tuple[socket.AddressFamily("inet"),Tuple("TCP",("127.0.0.1",5000),0,0)])])

    # Create dummy af and addr
    af = socket.AddressFamily("inet")

# Generated at 2022-06-26 09:00:27.405164
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_addrs = [(1, 2), (3, 4), (5,6)]
    def func(af, addr): # type: (socket.AddressFamily, Tuple) -> Tuple[IOStream, "Future[IOStream]"]
        return IOStream(socket.socket(af, socket.SOCK_STREAM), io_loop=IOLoop.current()), Future()
    t_connector = _Connector(t_addrs, func)

    t_addrs_iter = iter(t_addrs)
    t_connector.try_connect(t_addrs_iter)


# Generated at 2022-06-26 09:00:36.079069
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    """
    @TestCase
    """
    print(">  In test_close_streams of class test__Connector")
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.connect('localhost', 12345)
    print(">  End of test_close_streams")
    # TODO: implement test_close_streams


# Generated at 2022-06-26 09:00:45.532222
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0_af = socket.AF_UNSPEC
    t_c_p_client_0_ssl_options = None
    t_c_p_client_0.connect('localhost', 8000, t_c_p_client_0_af, t_c_p_client_0_ssl_options)

# Generated at 2022-06-26 09:00:49.868406
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    connector = _Connector([('1',2), ('3',4)], connect)
    addrs = iter([('a','b'),('c','d')])
    try:
        connector.try_connect(addrs)
    except StopIteration:
        pass
    else:
        raise Exception("Failed")
    return


# Generated at 2022-06-26 09:01:01.267303
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    test_case_0_addrinfo = [('10.0.0.1', 1234), ('::1', 5678)]
    test_case_0_connect = TCPClient.do_connect
    test_case_0_connector = _Connector(test_case_0_addrinfo, test_case_0_connect)
    test_case_0_addrs = [('10.0.0.1', 1234), ('::1', 5678)]
    test_case_0_af = 'af'
    test_case_0_addr = ('10.0.0.1', 1234)
    test_case_0_future = Future() # type: Future[IOStream]
    test_case_0_future.set_result(IOStream())

# Generated at 2022-06-26 09:01:10.601451
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    """
    This test case is used to test function close_streams of 
    class _Connector. 
    
    The test case mainly includes two steps:
    #1. Close all the streams in this.streams.
    #2. Passing the test.
    """
    connections = []
    # Step 1.
    for conn in connections:
        conn.close_streams()
    # Step 2.
    print("Congratulations! Method close_streams is Passed!")
    # End of test case.
