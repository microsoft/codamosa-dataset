

# Generated at 2022-06-26 08:54:19.155302
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    async def test_generic_connect(
        host: str,
        port: int,
        af: socket.AddressFamily = socket.AF_UNSPEC,
        ssl_options: Optional[Union[Dict[str, Any], ssl.SSLContext]] = None,
        max_buffer_size: Optional[int] = None,
        source_ip: Optional[str] = None,
        source_port: Optional[int] = None,
        timeout: Optional[Union[float, datetime.timedelta]] = None
    ) -> IOStream:
        loop = asyncio.get_event_loop()
        future = loop.create_future()
        future.set_result(None)
        t_c_p_client_1 = TCPClient()

# Generated at 2022-06-26 08:54:26.637153
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()
    a1 = Resolver()
    a2 = a1.resolve('localhost', 80) # type: gen.Future
    a3 = TCPClient.connect(a2, 80) # type: gen.Future
    a4 = a3.result() # type: Tuple[IOStream, int]
    a5 = a4[0] # type: IOStream
    a6 = _Connector(a2, a3)
    a6.clear_timeouts()


# Generated at 2022-06-26 08:54:27.883424
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    _Connector(None, None).on_connect_timeout()


# Generated at 2022-06-26 08:54:35.650693
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_0 = TCPClient()
    #test_0_connector = _Connector (test_0_connector, t_c_p_client_0.connect)
    #test_0_connector.on_timeout()


# Generated at 2022-06-26 08:54:39.845668
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._connector_0 = _Connector(addrs=None, connect=None)
    t_c_p_client_0._connector_0.close_streams()


# Generated at 2022-06-26 08:54:47.199257
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    PORT=80
    HOST='localhost'
    af, addr = socket.getaddrinfo(HOST, PORT)[0][:2]
    s = socket.socket(af, socket.SOCK_STREAM)
    with IOStream(s) as stream:
        stream.connect(addr)



# Generated at 2022-06-26 08:54:49.192105
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    # Test case 0
    test_case_0()



# Generated at 2022-06-26 08:55:02.683862
# Unit test for method split of class _Connector
def test__Connector_split():
    # Test 1
    primary,secondary = _Connector.split([(3,3)])
    assert(primary == [(3,3)] and secondary == [])
    # Test 2
    primary,secondary = _Connector.split([(2,4),(4,4)])
    assert(primary == [(2,4)] and secondary == [(4,4)])
    # Test 3
    primary,secondary = _Connector.split([(3,3),(2,2),(2,2)])
    assert(primary == [(3,3),(2,2),(2,2)] and secondary == [])
    # Test 4
    primary,secondary = _Connector.split([(4,4),(2,2),(2,2),(4,4)])

# Generated at 2022-06-26 08:55:10.146378
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    _Connector(
        addrinfo=[(socket.AddressFamily.AF_INET, ('www.google.com', 80))],
        connect=lambda af, addr: (None, None)
    ).try_connect(iter([(socket.AddressFamily.AF_INET, ('www.google.com', 80))]))


# Generated at 2022-06-26 08:55:13.667268
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_0 = TCPClient()
    connector_0 = t_c_p_client_0._Connector(list(), t_c_p_client_0._Connector.try_connect)
    connector_0.clear_timeout()


# Generated at 2022-06-26 08:55:45.341324
# Unit test for constructor of class _Connector
def test__Connector():
    c = _Connector([],lambda x,y : [None,None])
    assert(c.io_loop == IOLoop.current())



# Generated at 2022-06-26 08:55:50.973276
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    timeout = _INITIAL_CONNECT_TIMEOUT
    test_case = _Connector(((0, ((0, 4),)),), lambda af, addr: (None, None))
    test_case.set_timeout(timeout)


# Generated at 2022-06-26 08:55:55.244717
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    stream = IOStream()
    stream.socket = socket.socket()
    t_c_p_client_1 = TCPClient()
    _Connector.clear_timeouts(t_c_p_client_1)


# Generated at 2022-06-26 08:56:06.624401
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.ip = "10.0.0.1"
    t_c_p_client_0.port = 9999
    t_c_p_client_0.connector = _Connector(
        t_c_p_client_0.addrinfo, t_c_p_client_0._connect
    )
    try:
        t_c_p_client_0.connector.try_connect(t_c_p_client_0.addrinfo)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 08:56:18.753241
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    # Creates an instance of class TCPClient using default arguments
    t_c_p_client_0 = TCPClient()
    # Call method connect of class TCPClient with host set to the
    # value of the variable str_0 and port set to the value of the variable
    # int_0
    t_c_p_client_0.connect(host=str_0, port=int_0)
    # Call method connect of class TCPClient with host set to the value of the
    # variable str_0 and port set to the value of the variable int_1 and af set
    # to the value of the variable int_2 and ssl_options set to the value of
    # the variable str_1 and max_buffer_size set to the value of the variable
    # int_3 and source_ip set to the value of the variable str_2 and source

# Generated at 2022-06-26 08:56:24.369902
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-26 08:56:30.764502
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    addrs = [(socket.AF_INET6, ('2a01:e35:2e42:9700:f0c8:c6ff:fe49:e144', 80))]
    c = _Connector(
        addrinfo=addrs,
        connect=lambda af,addr: (None, None),
    )
    c.future.set_result(None)
    c.on_connect_timeout()
    assert not c.future.done()
    c.future.set_exception(None)
    c.on_connect_timeout()
    assert c.future.done()


# Generated at 2022-06-26 08:56:32.273684
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    pass


# Generated at 2022-06-26 08:56:41.806206
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()
    # self, addrinfo: List[Tuple], connect: Callable[[socket.AddressFamily, Tuple], Tuple[IOStream, 'Future[IOStream]']])
    # -> None:
    # addrinfo = [tuple(['test_case_0'])]
    # connect = [tuple([t_c_p_client_0.get_addrinfo()])]
    # t_c_p_client_0 = _Connector.try_connect(addrinfo, connect)
    # t_c_p_client_0 = _Connector.try_connect(addrinfo)
    t_c_p_client_0 = _Connector.try_connect()
    return t_c_p_client_0


# Generated at 2022-06-26 08:56:43.446252
# Unit test for constructor of class _Connector
def test__Connector():
    test_case_0()



# Generated at 2022-06-26 08:57:25.339252
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.timeout = datetime.datetime(datetime.datetime.now().year,
                                              datetime.datetime.now().month,
                                              datetime.datetime.now().day,
                                              datetime.datetime.now().hour,
                                              datetime.datetime.now().minute + 1,
                                              datetime.datetime.now().second,
                                              datetime.datetime.now().microsecond,)
    t_c_p_client_0.io_loop = IOLoop.current()
    t_c_p_client_0.future = Future()

# Generated at 2022-06-26 08:57:26.149740
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    pass


# Generated at 2022-06-26 08:57:32.694696
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    try:
        s.bind(("", 0))
    except Exception as e:
        assert False, "Unable to bind socket: " + str(e)
    s.listen(5)
    sockets = []
    for i in range(5):
        client, _ = s.accept()
        sockets.append(client)
    connector = _Connector(sockets, None)
    connector.close_streams()

# Unit tests for method _Connector

# Generated at 2022-06-26 08:57:38.477665
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_0 = _Connector(AddrInfo, t_c_p_client_0.connect)
    t_c_0.on_timeout()


# Generated at 2022-06-26 08:57:39.914829
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_1 = TCPClient()
    # unit test for method close_streams of _Connector
    assert True


# Generated at 2022-06-26 08:57:47.201228
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver()
    t_c_p_client_0.resolver.configure('localhost', 8888)
    t_c_p_client_0.connector = _Connector(t_c_p_client_0.resolver.addrinfo, t_c_p_client_0.connect)
    t_c_p_client_0.connector.io_loop = IOLoop()
    t_c_p_client_0.connector.io_loop.add_callback(t_c_p_client_0.connector.clear_timeout)
    t_c_p_client_0.connector.io_loop.start()


# Generated at 2022-06-26 08:57:50.878351
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_1 = TCPClient()
    t_c_p_client_2 = TCPClient()
    a_t_c_1 = _Connector(t_c_p_client_1.resolve_addr(), t_c_p_client_1.connect)
    a_t_c_2 = _Connector(t_c_p_client_2.resolve_addr(), t_c_p_client_2.connect)
    a_t_c_1.clear_timeouts()
    a_t_c_2.clear_timeouts()


# Generated at 2022-06-26 08:57:55.655851
# Unit test for constructor of class _Connector
def test__Connector():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_1 = TCPClient()
    t_c_p_client_2 = TCPClient()
    t_c_p_client_3 = TCPClient()
    t_c_p_client_4 = TCPClient()
    t_c_p_client_2 = t_c_p_client_4
    t_c_p_client_3._Connector()


# Generated at 2022-06-26 08:58:08.324871
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    host, port = "www.google.com", 443
    address = (host, port)

# Generated at 2022-06-26 08:58:18.216756
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    # We will create a server to handle this connection
    # We will start by creating a socket object
    local_host = "127.0.0.1"
    local_port = 1234
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((local_host, local_port))
    server_socket.listen(1)

    ssl_options = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ssl_options.load_cert_chain("./ssl/mydomain.crt", "./ssl/mydomain.key")

    t_c_p_client_0 = TCPClient()

# Generated at 2022-06-26 08:59:23.195550
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    address_list = [('AF_INET', ('127.0.0.1', 443)), ('AF_INET', ('8.8.8.8', 443))]
    def func(af, addr) ->  Tuple[IOStream, "Future[IOStream]"]:
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()
    _connector = _Connector(address_list, func)
    _connector.try_connect(iter(address_list))


# Generated at 2022-06-26 08:59:27.732672
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    
    connect_timeout_0 = 1.0
    connect_timeout_1 = _Connector._Connector([], None)
    connect_timeout_1.set_connect_timeout(connect_timeout_0)
    
    

# Generated at 2022-06-26 08:59:34.118281
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()

    c = _Connector(t_c_p_client_0.resolver.resolve("www.google.com"), t_c_p_client_0.stream.connect)
    c.future = Future()
    c.on_connect_timeout()

    # Check the future is done
    assert c.future.done() == True


# Generated at 2022-06-26 08:59:46.196176
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Test case 1: check return value of function _Connector_on_timeout:
    t_c_p_client_1 = TCPClient()
    t_c_p_client_1.resolver = Resolver()
    t_c_p_client_1.resolver.resolve = lambda host, port, family = 0: ['AF_INET6']
    _connector_1 = _Connector(t_c_p_client_1.resolver.resolve(t_c_p_client_1.host, t_c_p_client_1.port),t_c_p_client_1._stream_from_address)
    _connector_1.set_timeout(0.3)
    return_value_1 = _connector_1.on_timeout()
    return_value_2 = None

# Generated at 2022-06-26 08:59:47.045155
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    pass

# Generated at 2022-06-26 08:59:48.168684
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()



# Generated at 2022-06-26 08:59:50.950807
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # test case 0
    t_c_p_client_0 = TCPClient()


# Generated at 2022-06-26 08:59:56.772854
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():

    from tornado.gen import sleep
    import time

    # Test case 0.
    t_c_0 = _Connector

    client = TCPClient()

    t_c_0.set_connect_timeout(client, float(0.3))

    # Test case 1.
    t_c_1 = _Connector

    client = TCPClient()

    delta = time.time() + 1
    t_c_1.set_connect_timeout(client, datetime.timedelta(delta))


# Generated at 2022-06-26 09:00:05.191956
# Unit test for method split of class _Connector
def test__Connector_split():
    assert _Connector.split([(0, 1), (2, 3)]) == ([(0, 1)], [(2, 3)])
    assert _Connector.split([(1, 2)]) == ([(1, 2)], [])
    assert _Connector.split([]) == ([], [])
    assert _Connector.split([(0, 1), (0, 2), (2, 3)]) == ([(0, 1), (0, 2)], [(2, 3)])
    
    

# Generated at 2022-06-26 09:00:10.728696
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    c = _Connector(None, None)
    c.set_timeout(0.3)
    assert c.timeout == c.io_loop.add_timeout(c.io_loop.time() + 0.3, c.on_timeout)

    

# Generated at 2022-06-26 09:02:32.621496
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    ai = [(1, 2), (2, 3), (3, 4)]
    conn = _Connector(ai, None)
    conn.future = Future()
    conn.future.set_exception(connection_create_error)
    addr = iter([(1, 2)])
    conn.on_connect_done(addr, 1, 2, Future())



# Generated at 2022-06-26 09:02:43.741276
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    class FakeIOLoop(object):
        def __init__(self):
            self.called = 0
            self.time_added = 0

        def add_timeout(self, time, t_c_p_client_0):
            self.called += 1
            self.time_added += time

    t_c_p_client_0 = TCPClient()
    c0 = _Connector(100, 1)
    c0.io_loop = FakeIOLoop()
    c0.set_timeout(3)
    assert c0.timeout is not None
    assert c0.io_loop.called == 1
    assert c0.io_loop.time_added == 3


# Generated at 2022-06-26 09:02:54.130449
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    tcp_client_1 = TCPClient()
    #host_name = '127.0.0.1'
    host_name = 'localhost'
    port_number = 3306
    af_type = socket.AF_INET
    ssl_options = None
    max_buffer_size = None
    source_ip = '127.0.0.1'
    source_port = 3306
    iostream_1 = tcp_client_1.connect(host_name, port_number, af_type, ssl_options, max_buffer_size, source_ip, source_port)
    print(iostream_1)


# Generated at 2022-06-26 09:03:00.708014
# Unit test for method split of class _Connector
def test__Connector_split():
    _Connector.split([(2,('127.0.0.0',80)), (2,('127.0.0.0',80),(0,),(0,),(0,),()), (2,('127.0.0.0',80),(0,),(0,),(0,),()), (2,('127.0.0.0',80)), (2,('127.0.0.0',80),(0,),(0,),(0,),())])


# Generated at 2022-06-26 09:03:05.571973
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    _connector_0 = _Connector(((6, ('127.0.0.1', 10001)),), t_c_p_client_0.connect)
    _connector_0.future = Future()
    _connector_0.on_connect_timeout()


# Generated at 2022-06-26 09:03:15.556922
# Unit test for method split of class _Connector
def test__Connector_split():
    with pytest.raises(Exception) as excinfo:
        primary, secondary = _Connector.split([])
    assert 'addrinfo is empty' in str(excinfo.value)
    primary, secondary = _Connector.split([(socket.AF_INET, ('a', 'b'))])
    assert primary == [(socket.AF_INET, ('a', 'b'))]
    assert secondary == []
    primary, secondary = _Connector.split([(socket.AF_INET, ('c', 'd')), (socket.AF_INET, ('a', 'b'))])
    assert primary == [(socket.AF_INET, ('c', 'd')), (socket.AF_INET, ('a', 'b'))]
    assert secondary == []

# Generated at 2022-06-26 09:03:20.577213
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    f_0 = t_c_p_client_0.connect("127.0.0.1", 8080, af=socket.AF_UNSPEC)
    i_o_stream_0 = f_0.result()
    i_o_stream_0.close()


# Generated at 2022-06-26 09:03:23.760366
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    addrinfo = []
    def foo():
        return
    def bar():
        return
    connect = bar
    foo = _Connector(addrinfo, connect)
    foo.on_connect_timeout()


# Generated at 2022-06-26 09:03:26.977307
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    connector = _Connector([1], [2])
    assert(connector.close_streams() == None)


# Generated at 2022-06-26 09:03:32.144267
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    print('test__Connector_set_connect_timeout')
    expected = TimeoutError
    actual = _Connector.set_connect_timeout(0)
    assert actual.__class__.__name__ == expected.__class__.__name__, 'Expected: {}, Actual: {}, Failed on test_case_0 (i.e. _Connector.set_connect_timeout)'.format(expected, actual)
