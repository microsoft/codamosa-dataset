

# Generated at 2022-06-26 08:54:18.083315
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    list_0 = []
    connection_0 = _Connector(list_0, _Connector)
    connection_0.set_connect_timeout(_INITIAL_CONNECT_TIMEOUT)
    # Test if a IOloop is called and removes the timeout
    ioloop_0 = IOLoop.current()
    connection_0.io_loop = ioloop_0
    connection_0.connect_timeout = ioloop_0.add_timeout(
        datetime.timedelta, connection_0.on_connect_timeout
    )
    connection_0.set_connect_timeout(datetime.timedelta)


# Generated at 2022-06-26 08:54:22.301386
# Unit test for method start of class _Connector
def test__Connector_start():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    float_0 = 0.0
    future_0 = connector_0.start(float_0)


# Generated at 2022-06-26 08:54:26.893624
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    connector_0.close_streams()


# Generated at 2022-06-26 08:54:27.800840
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    assert True


# Generated at 2022-06-26 08:54:36.157516
# Unit test for method split of class _Connector
def test__Connector_split():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    tuple_0 = connector_0.split(list_0)
    assert not (isinstance(tuple_0, float))


# Generated at 2022-06-26 08:54:40.511768
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    iter_0 = iter(list_0)
    connector_0.try_connect(iter_0)


# Generated at 2022-06-26 08:54:45.211035
# Unit test for method split of class _Connector
def test__Connector_split():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    addrinfo: List[Tuple] = []
    result = connector_0.split(addrinfo) # Should not throw exception


# Generated at 2022-06-26 08:54:55.946648
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    list_0 = []
    list_1 = []
    tuple_0 = (socket.AF_INET6, None)
    list_2 = []
    tuple_1 = (socket.AF_INET6, None)
    list_1.append(tuple_0)
    list_0.append(tuple_1)
    tuple_1 = (socket.AF_INET6, None)
    list_2.append(tuple_1)
    tuple_1 = (socket.AF_INET6, None)
    tuple_2 = (socket.AF_INET6, None)
    tuple_3 = (socket.AF_INET6, None)
    tuple_4 = (socket.AF_INET6, None)

    address_family_0 = module_0.AddressFamily.AF_TIPC


# Generated at 2022-06-26 08:55:06.053067
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    IOStream_0 = IOStream(address_family_0, list_0)
    stream_0 = IOStream_0

    list_1 = []
    address_family_1 = module_0.AddressFamily.AF_TIPC
    IOStream_1 = IOStream(address_family_1, list_1)
    stream_1 = IOStream_1

    list_2 = [stream_0, stream_1]
    address_family_2 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_2, address_family_2)
    connector_0.close_streams()


# Generated at 2022-06-26 08:55:11.422162
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    connector_0.clear_timeout()


# Generated at 2022-06-26 08:55:38.104483
# Unit test for constructor of class _Connector
def test__Connector():
    list_0 = []
    list_1 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    address_family_1 = module_0.AddressFamily.AF_INET
    tuple_0 = (address_family_1, list_1)
    list_2 = [tuple_0]
    connector_0 = _Connector(list_2, address_family_0)
    list_3 = connector_0.primary_addrs
    list_4 = connector_0.secondary_addrs
    if len(list_3) > 0 and len(list_4) > 0:
        list_3.append(address_family_0)
        list_4.append(address_family_0)
        list_5 = connector_0.primary_addrs
        list_6 = connector_

# Generated at 2022-06-26 08:55:42.111295
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    connect_0 = connector_0.try_connect([])
    assert isinstance(connect_0, None.__class__)


# Generated at 2022-06-26 08:55:56.252676
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_INET
    connector_0 = _Connector(list_0, address_family_0)
    # Connect timeout must be a number or timedelta
    try:
        connector_0.set_connect_timeout(bytes([2, 3, 4, 5, 6]))
        assert False
    except ValueError as e:
        assert "connect_timeout must be a number or timedelta" in str(e)
    except:
        assert False

    # Connect timeout must be positive
    try:
        connector_0.set_connect_timeout(-1)
        assert False
    except ValueError as e:
        assert "connect_timeout must be positive" in str(e)
    except:
        assert False

# Generated at 2022-06-26 08:55:59.673288
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    _Connector(list_0, address_family_0)
    _Connector.clear_timeout(connector_0)


# Generated at 2022-06-26 08:56:06.320844
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    try:
        connector_0.on_timeout()
    except Exception as ex:
        if type(ex).__name__ == 'IndexError':
            pass
        else:
            raise

# Generated at 2022-06-26 08:56:16.573088
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    def test_case_0():
        af_0 = socket.AddressFamily.AF_INET6
        addr_0 = ('',)
        expected_0 = 0.3
        stream_0, future_0 = connector_0.connect(af_0, addr_0)
        connector_0.set_timeout(expected_0)
        stream_1, future_1 = connector_0.connect(af_0, addr_0)
        actual_0 = connector_0.set_timeout(expected_0)
        assert_equal(expected_0, actual_0)


# Generated at 2022-06-26 08:56:23.581609
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    list_0 = []
    address_family_0 = socket.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    timeout = 0.3
    connector_0.set_timeout(timeout)



# Generated at 2022-06-26 08:56:25.842464
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    _Connector_set_timeout(0.3)


# Generated at 2022-06-26 08:56:30.227577
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    module__Connector = _Connector
    class_0 = module__Connector
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_INET
    connector_0 = class_0(list_0, address_family_0)
    stream_0 = IOStream()
    stream_0.close()
    # TODO: Test function _Connector.close_streams()
    pass


# Generated at 2022-06-26 08:56:40.458554
# Unit test for method start of class _Connector
def test__Connector_start():
    def _start_aux(timeout: float = 0.3, connect_timeout: Optional[Union[float, datetime.timedelta]] = None):
        list_0 = []
        address_family_0 = module_0.AddressFamily.AF_TIPC
        connector_0 = _Connector(list_0, address_family_0)
        future_0 = connector_0.start(timeout, connect_timeout)
        future_0.result()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-26 08:57:13.219012
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    connect_timeout_0 = 0.1894523902219612
    # Call the method
    connector_0.set_connect_timeout(connect_timeout_0)


# Generated at 2022-06-26 08:57:20.230142
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    connector_0.clear_timeouts()
    connector_0.close_streams()


# Generated at 2022-06-26 08:57:25.063465
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import time
    import concurrent.futures
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    timeout_0 = concurrent.futures.thread.time()
    connector_0.set_timeout(timeout_0)


# Generated at 2022-06-26 08:57:26.538718
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    test_case_0()


# Generated at 2022-06-26 08:57:33.058761
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_INET
    connector_0 = _Connector(list_0, address_family_0)
    stream_0 = connector_0.io_loop.io_stream(stream=None)
    connector_0.streams.add(stream_0)
    connector_0.close_streams()



# Generated at 2022-06-26 08:57:38.776736
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    test_case_0()


# Generated at 2022-06-26 08:57:40.395578
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    test_case_0()


# Generated at 2022-06-26 08:57:42.811014
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    list_0 = []
    connector_0 = _Connector(list_0, 1.0)
    test_case_0()

# Generated at 2022-06-26 08:57:48.773906
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    async def async_func_0():
        client = TCPClient()
        await client.connect(None, None, None, timeout=None)
        client.close()

    IOLoop.current().run_sync(async_func_0)


# Generated at 2022-06-26 08:57:53.144685
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    connector_0.on_connect_timeout()


# Generated at 2022-06-26 08:58:50.682104
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    test_case_0()


# Generated at 2022-06-26 08:58:58.643481
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test data - start
    timeout_0 = 0.3
    module_0 = Resolver()
    address_family_0 = module_0.AddressFamily.AF_TIPC
    list_0 = []
    # Test data - end
    # Test logic - start
    list_0.append((address_family_0, list_0))
    # Test logic - end


# Generated at 2022-06-26 08:59:06.856159
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    list_0 = [1, 2, 3]
    address_family_0 = module_0.AddressFamily.AF_NETLINK
    connector_0 = _Connector(list_0, address_family_0)
    test_case_0()

if __name__ == '__main__':
    test__Connector_clear_timeouts()

# Generated at 2022-06-26 08:59:11.005736
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    list_1 = []
    address_family_1 = module_0.AddressFamily.AF_TIPC
    connector_1 = _Connector(list_1, address_family_1)
    connector_1.on_connect_timeout()


# Generated at 2022-06-26 08:59:17.348336
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    connector_0.on_connect_timeout()


# Generated at 2022-06-26 08:59:22.410960
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_UNIX
    connector_0 = _Connector(list_0, address_family_0)
    connector_0.clear_timeout()


# Generated at 2022-06-26 08:59:28.168341
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    connector_0.clear_timeouts()

import socket as module_1


# Generated at 2022-06-26 08:59:34.014670
# Unit test for method split of class _Connector
def test__Connector_split():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_APPLETALK
    connector_0 = _Connector(list_0, address_family_0)

    # Test for TypeError
    try:
        connector_0.split()
        assert False
    except TypeError:
        pass
    except Exception:
        assert False


# Generated at 2022-06-26 08:59:45.441736
# Unit test for constructor of class _Connector
def test__Connector():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    assert connector_0.connect == module_0.AddressFamily.AF_TIPC
    assert connector_0.future is not None
    assert connector_0.timeout is None
    assert connector_0.connect_timeout is None
    assert connector_0.last_error is None
    assert connector_0.remaining == 0
    assert connector_0.primary_addrs == []
    assert connector_0.secondary_addrs == []
    assert connector_0.streams == set()

import socket as module_1


# Generated at 2022-06-26 08:59:49.693901
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case where connection fails
    # Test case where connection times out
    # Test case where connection is successful
    # Test case where already connected
    pass

# Generated at 2022-06-26 09:02:06.561256
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    timeout_0 = datetime.timedelta(1.5)
    def callable_0(self, connect_timeout: Union[float, datetime.timedelta]) -> None:
        if timeout_0 is not None:
            IOLoop.current().remove_timeout(self.connect_timeout)
            return
    def callable_1(self, connect_timeout: Union[float, datetime.timedelta]) -> None:
        if timeout_0 is not None:
            IOLoop.current().remove_timeout(self.connect_timeout)
            return
    _Connector.set_connect_timeout = callable_0
    _Connector.set_connect_timeout = callable_1
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_UNIX

# Generated at 2022-06-26 09:02:13.166009
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    connector_0.clear_timeouts()


# Generated at 2022-06-26 09:02:17.832449
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    connector_0.clear_timeout()


# Generated at 2022-06-26 09:02:23.196668
# Unit test for method start of class _Connector
def test__Connector_start():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_APPLETALK
    connector_0 = _Connector(list_0, address_family_0)
    future = connector_0.start()
    future.done


# Generated at 2022-06-26 09:02:27.501227
# Unit test for method split of class _Connector
def test__Connector_split():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    assert connector_0.split(list_0) == ([], [])


# Generated at 2022-06-26 09:02:31.776329
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    list_0 = []
    addres_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, addres_family_0)
    connector_0.clear_timeout()


# Generated at 2022-06-26 09:02:33.998744
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    dummy_af = module_0.AddressFamily.AF_INET6
    dummy_addr = tuple()
    result = True

# Generated at 2022-06-26 09:02:38.365101
# Unit test for method start of class _Connector
def test__Connector_start():
    list_0 = []
    address_family_0 = module_0.AddressFamily.AF_TIPC
    connector_0 = _Connector(list_0, address_family_0)
    future_0 = connector_0.start(123.4, 12)
    assert isinstance(future_0, Future)


# Generated at 2022-06-26 09:02:41.723502
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    test_case_0()


# Generated at 2022-06-26 09:02:52.327139
# Unit test for method split of class _Connector
def test__Connector_split():
    list_0 = [('AF_INET', ('127.0.0.1', 8888))]
    address_family_0 = module_0.AddressFamily.AF_INET6
    connector_0 = _Connector(list_0, address_family_0)
    assert connector_0 != None
    result_0, result_1 = connector_0.split(list_0)
    assert result_0 != None
    assert result_1 != None
