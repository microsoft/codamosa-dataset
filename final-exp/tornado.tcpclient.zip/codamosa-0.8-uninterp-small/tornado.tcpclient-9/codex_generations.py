

# Generated at 2022-06-26 08:54:22.788334
# Unit test for method start of class _Connector
def test__Connector_start():
    _Connector.start(self, timeout=0.0)

# Generated at 2022-06-26 08:54:31.076788
# Unit test for method split of class _Connector
def test__Connector_split():
    connector = _Connector
    addrinfo_1 = [(1, (1, 2)), (2, (3, 4)), (1, (5, 6))]
    addrinfo_2 = [(1, (1, 2)), (2, (3, 4)), (2, (5, 6))]

    result_1 = connector.split(addrinfo_1)
    assert result_1 == ([(1, (1, 2)), (1, (5, 6))], [(2, (3, 4))])

    result_2 = connector.split(addrinfo_2)
    assert result_2 == ([(1, (1, 2))], [(2, (3, 4)), (2, (5, 6))])

# Generated at 2022-06-26 08:54:43.128064
# Unit test for method split of class _Connector
def test__Connector_split():
    conn = _Connector(
        [
            (socket.AF_INET, ("", 80)),
            (socket.AF_INET, ("", 80)),
            (socket.AF_INET6, ("", 80)),
        ],
        lambda af, addr: IOStream(socket.socket(af, socket.SOCK_STREAM), True),
    )
    assert conn.split([
            (socket.AF_INET, ("", 80)),
            (socket.AF_INET6, ("", 80)),
            (socket.AF_INET, ("", 80)),
        ]) == ([(socket.AF_INET, ("", 80)), (socket.AF_INET, ("", 80))], [(socket.AF_INET6, ("", 80))])
    print("Test _Connector.split() passed")



# Generated at 2022-06-26 08:54:51.364384
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 6666))]
    connector = _Connector(addrinfo, test_connect)
    future = connector.start()
    addrs = iter(connector.primary_addrs)
    af = next(addrs)
    addr = af[1]
    stream = future.result()[2]
    connector.on_connect_done(addrs, af, addr, stream)



# Generated at 2022-06-26 08:54:53.874796
# Unit test for method start of class _Connector
def test__Connector_start():
    addrinfo = [("socket.AF_INET", "address")]
    def connect(af: socket.AddressFamily,
                addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        pass
    connector = _Connector(addrinfo, connect)
    timeout = 1.0
    future = connector.start(timeout)


# Generated at 2022-06-26 08:54:57.584047
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    _Connector_0 = _Connector()
    _Connector_0.on_connect_timeout()


# Generated at 2022-06-26 08:55:06.852565
# Unit test for method start of class _Connector
def test__Connector_start():
    # test for case when timeout is of type float with default value of _INITIAL_CONNECT_TIMEOUT
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.connect = lambda af, addr: (None, None)
    t_c_p_client_0.io_loop = IOLoop.current()
    t_c_p_client_0.future = Future()
    t_c_p_client_0.timeout = None
    t_c_p_client_0.connect_timeout = None
    t_c_p_client_0.last_error = Exception()
    t_c_p_client_0.remaining = 1

# Generated at 2022-06-26 08:55:14.156109
# Unit test for constructor of class _Connector
def test__Connector():
    t_c_p_client_0 = TCPClient()
    _connector_0 = _Connector(
        addrinfo=t_c_p_client_0.t_c_p_stream.t_c_p_client.t_c_p_client_0._addresses,
        connect=t_c_p_client_0.t_c_p_stream.t_c_p_client.t_c_p_client_0.connect,
    )


# Generated at 2022-06-26 08:55:16.858968
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    c = _Connector([(1,1)],None)
    c.on_connect_timeout()


# Generated at 2022-06-26 08:55:26.865289
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import tornado
    import tornado.testing
    import tornado.gen
    import tornado.iostream
    import tornado.ioloop
    import tornado.options
    import tornado.platform
    import functools
    import socket
    import sys

    class EchoClient(object):
        def __init__(self, stream, io_loop=None):
            self.stream = stream
            self.io_loop = io_loop or tornado.ioloop.IOLoop.current()
            self.stream.set_close_callback(self.on_close)
            self.stream.read_until(b"\n", self.on_read)

        def on_read(self, data):
            sys.stdout.write(data.decode("utf-8"))

# Generated at 2022-06-26 08:55:56.252493
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_1 = TCPClient()
    t_c_p_client_2 = TCPClient()
    t_c_p_client_3 = TCPClient()
    t_c_p_client_4 = TCPClient()
    t_c_p_client_5 = TCPClient()
    t_c_p_client_6 = TCPClient()
    t_c_p_client_7 = TCPClient()

    t_c_p_client_2.connector._Connector__init__(
        t_c_p_client_1.getaddrinfo, t_c_p_client_1.connect
    )

# Generated at 2022-06-26 08:55:58.432629
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()


# Generated at 2022-06-26 08:56:01.141583
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client = TCPClient()
    # Asynchronously returns an `.IOStream` (or `.SSLIOStream` if
    # ``ssl_options`` is not None).
    host = 'localhost'
    port = 8888
    # wait until tcp client finishes work
    t_c_p_client.connect(host, port)


# Generated at 2022-06-26 08:56:12.727735
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.connect("", 0)
    t_c_p_client_0.connect("0", 0)
    t_c_p_client_0.connect("", 0, 0)
    t_c_p_client_0.connect("0", 0, 0)
    t_c_p_client_0.connect("", 0, 0, 0)
    t_c_p_client_0.connect("0", 0, 0, 0)
    t_c_p_client_0.connect("", 0, 0, 0, 0)
    t_c_p_client_0.connect("0", 0, 0, 0, 0)

# Generated at 2022-06-26 08:56:21.266180
# Unit test for constructor of class _Connector
def test__Connector():
    client = TCPClient()
    test_obj_connector_0 = _Connector(
        [], client.connect
    )  # type: Tuple[socket.AddressFamily, Tuple]
    test_obj_connector_1 = _Connector(
        [(socket.AF_INET, ("127.0.0.1", 80, 0, 0))], client.connect
    )  # type: Tuple[socket.AddressFamily, Tuple]
    test_obj_connector_2 = _Connector(
        [(socket.AF_INET, ("127.0.0.1", 80, 0, 0))],
        client.connect,
    )  # type: Tuple[socket.AddressFamily, Tuple]
    # test for __init__
    assert test_obj_connector_0.future.done() is False

# Generated at 2022-06-26 08:56:21.942323
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    pass


# Generated at 2022-06-26 08:56:25.484220
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    #set_timeout and clear_timeouts have been tested by other unit tests of this file
    #-> This test is not necessary
    pass


# Generated at 2022-06-26 08:56:31.536371
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.connect = TCPClient.connect_future
    s_addr = ('127.0.0.1', 8899)
    addrinfo = (socket.AF_INET, s_addr)
    addrinfo_list = [addrinfo]
    _connector_0 = _Connector(addrinfo_list, t_c_p_client_0.connect)
    _connector_0.on_connect_timeout()
    io_loop = IOLoop.current()
    io_loop.add_callback(_connector_0.on_connect_timeout)


# Generated at 2022-06-26 08:56:41.784032
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # Edge case: _Connector does not have an attribute named 'connect'
    t_c__con_0 = _Connector([(None, None)], None)
    # Edge case: The 'self.streams' of _Connector doesn't have an attribute named 'use_ipv6'
    t_c__con_1 = _Connector([(socket.AF_INET, (1, 2))], 1)
    # Edge case: The 'self.streams' of _Connector doesn't have an attribute named 'use_ipv6'
    t_c__con_2 = _Connector([(socket.AF_INET6, (1, 2))], 1)
    # Edge case: The 'self.streams' of _Connector doesn't have an attribute named 'use_ipv6'

# Generated at 2022-06-26 08:56:52.607508
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector.clear_timeouts()


### DEPRECATED class, for backwards compatibility.  Will be removed in a future version.
#
# class TCPClient(object):
#     """A non-blocking TCP connection factory.
#     """
#     def __init__(
#             self,
#             host: str,
#             port: int,
#             resolution_callback: Optional[Callable[[socket.AddressFamily], None]] = None,
#             connect_timeout: Optional[Union[float, datetime.timedelta]] = None,
#             **kwargs: Any) -> None:
#         self.host = host
#         self.port = port
#         self.resolver = Resolver()
#         self.resolution_

# Generated at 2022-06-26 08:57:22.198420
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    test_case_0()
# test_case_0 end



# Generated at 2022-06-26 08:57:31.378829
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_f_0 = Future()
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.client = t_f_0
    t_c_p_client_0.clear_timeout()
    t_c_p_client_1 = TCPClient()
    t_c_p_client_1.client = Future()
    t_c_p_client_1.clear_timeout()
    return t_c_p_client_1.client


# Generated at 2022-06-26 08:57:44.398712
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    t_c_p_client_0 = TCPClient()
    a_c_p_con_obj_0 = _Connector(
        t_c_p_client_0.resolver.resolve("localhost", 80),
        t_c_p_client_0.stream_class.__new__,
    )
    a_c_p_addrs_0 = (
        (
            socket.AddressFamily.AF_INET,
            ("127.0.0.1", 80),
        ),
    )
    a_c_p_af_0 = socket.AddressFamily.AF_INET
    a_c_p_addr_0 = ("127.0.0.1", 80)
    a_c_p_addrs_0_iter_0 = iter(a_c_p_addrs_0)


# Generated at 2022-06-26 08:57:55.726823
# Unit test for method split of class _Connector
def test__Connector_split():
    conn = _Connector([], None)
    assert len(conn.split([(1,1),(2,2),(3,3),(1,1),(2,2)])) == 2
    assert len(conn.split([(1,1),(2,2),(3,3),(1,1),(2,2)])[0]) == 4
    assert len(conn.split([(1,1),(2,2),(3,3),(1,1),(2,2)])[1]) == 1
    assert len(conn.split([(1,1),(2,2),(2,2),(1,1),(2,2)])) == 2

# Generated at 2022-06-26 08:58:01.841143
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Test case: Initialize _Connector object
    addrinfo = [(2, ('127.0.0.1', 8080)), (23, ('202.202.202.202', 8001))]
    connect = lambda addrinfo, addr : (None, None)
    t_c_0 = _Connector(addrinfo,connect) 
    # Initialize the timeout time
    t_c_0.timeout = "0x100"
    # Initialize the future to be set
    t_c_0.future = Future() 
    # Test case: on_timeout
    t_c_0.on_timeout()
    assert t_c_0.future.done()
    # Test case: timeout is not initialized
    t_c_0.timeout = None
    t_c_0.on_timeout()
    assert t_c_0

# Generated at 2022-06-26 08:58:10.685375
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    connector_0 = _Connector(
        [
            (socket.AF_INET, ("blocknews.net", 443)),
            (socket.AF_INET6, ("blocknews.net", 443)),
        ],
        t_c_p_client_0.stream_for_addr,
    )
    # The original code provided by tornado is as follows
    # def close_streams(self):
    #     for stream in self.streams:
    #         stream.close()
    # The first several lines are to imitate the class declaration before the function.
    # the function itself is close to the original one.

# Generated at 2022-06-26 08:58:15.788882
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # TODO: add a test case for method _Connector.set_timeout
    print('test__Connector_set_timeout')
    assert False

if __name__ == "__main__":
    test_case_0()
    print("finish testcase")
    test__Connector_set_timeout()
    print("finish testset_timeout")

# Generated at 2022-06-26 08:58:29.742834
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    host_0 = 'google.com'
    port_0 = 80
    module_0 = __import__('game')
    game_0 = module_0.game
    dns_0 = game_0
    s_r_0 = dns_0.lookup(host_0)
    assert isinstance(s_r_0, list)
    assert len(s_r_0) == 2
    assert isinstance(s_r_0[0], socket.AddressFamily)
    assert isinstance(s_r_0[1], list)
    assert len(s_r_0[1]) >= 1
    assert isinstance(s_r_0[1][0], tuple)

# Generated at 2022-06-26 08:58:33.424034
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    addrinfo = [(2, 1), (2, 4)]
    pconnector = _Connector(addrinfo, None)
    stream = IOStream(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
    stream.connect(("localhost", 8080))
    pconnector.streams.add(stream)
    pconnector.close_streams()

if __name__ == "__main__":
    test__Connector_close_streams()

# Generated at 2022-06-26 08:58:40.248711
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    ipaddr = "1.1.1.1"
    port = 80
    family = socket.AF_INET
    socktype = socket.SOCK_STREAM
    proto = socket.IPPROTO_TCP
    flags = socket.AI_CANONNAME
    _addrinfo = [(family, socktype, proto, "", (ipaddr, port, 0, 0)),]
    _c = _Connector(_addrinfo, None)
    _c.clear_timeout()
    

# Generated at 2022-06-26 08:59:46.912997
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    test_addrinfo_0 = [(socket.AF_INET, ('1.2.3.4', 123)), (socket.AF_INET6, ('5.5.5.5', 567))]
    test_connect_0 = lambda family, addr: (IOStream(socket.socket()), Future())

    test_future_0 = Future()
    tc = _Connector(test_addrinfo_0, test_connect_0)

    # If future is not done, TimeoutError is set as the result
    tc.on_connect_timeout()
    assert test_future_0.result() == TimeoutError

    # If future is done, do nothing
    test_future_0 = Future()
    test_future_0.set_result('result')
    tc.on_connect_timeout()
    assert test_future_0.result

# Generated at 2022-06-26 08:59:55.846992
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    addrinfo = [
        (2, ('10.0.0.1', 10)),
        (10, ('10.0.0.2', 10)),
    ]
    def connect(af: int, addr: Any) -> Tuple[IOStream, "Future[IOStream]"] :
        return IOStream(socket.socket()), Future()
    
    def on_timeout():
        print("on_timeout")
        return
        
    conn = _Connector(addrinfo, connect)
    conn.set_timeout(0.2)

    conn.on_timeout = on_timeout
    
    

# Generated at 2022-06-26 08:59:59.430441
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector.start()


# Generated at 2022-06-26 09:00:08.183390
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_1 = TCPClient()
    t_c_p_client_2 = TCPClient()
    t_c_p_client_3 = TCPClient()
    t_c_p_client_4 = TCPClient()
    t_c_p_client_5 = TCPClient()
    t_c_p_client_6 = TCPClient()
    t_c_p_client_7 = TCPClient()
    t_c_p_client_8 = TCPClient()
    s_0_iostream_0 = IOStream(t_c_p_client_1, t_c_p_client_2)
    s_0_iostream_1 = IOStream(t_c_p_client_3, t_c_p_client_4)
    s_0_iostream_

# Generated at 2022-06-26 09:00:12.719737
# Unit test for method split of class _Connector
def test__Connector_split():
    _Connector.split([(1, ("1.1.1.1", 11111)), (2, ("2.2.2.2", 22222))])


# Generated at 2022-06-26 09:00:21.137484
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 80)), (socket.AF_INET, ('127.0.0.1', 80))]
    connect = lambda af, addr: (IOStream(socket.create_connection(addr)), Future())
    connector = _Connector(addrinfo, connect)

    def connect_done_callback(x):
        return x

    # Testconnector.timeout is not None:
    connector.timeout = 1
    connector.future = Future()
    connector.future.add_done_callback(connect_done_callback)
    connector.on_timeout()
    assert connector.timeout == None

    # Testconnector.timeout is None:
    connector.timeout = None
    connector.future = Future()
    connector.future.add_done_callback(connect_done_callback)


# Generated at 2022-06-26 09:00:26.914704
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_0 = TCPClient()
    ssl_options = {}
    host = 'localhost'
    port = 8080
    af = socket.AddressFamily.AF_INET
    family = 0
    _connector = _Connector(host, port, family, ssl_options)
    _connector.on_timeout()


# Generated at 2022-06-26 09:00:38.815665
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_1 = TCPClient()
    t_c_p_client_2 = TCPClient()
    t_c_p_client_3 = TCPClient()
    t_c_p_client_4 = TCPClient()
    def on_connect_done(data1, data2):
        pass
    _Connector(
        [(AF_INET, ('127.0.0.1', 80))], 
        functools.partial(t_c_p_client_1.connect, functools.partial(on_connect_done, 0))
    ).start()

# Generated at 2022-06-26 09:00:50.653164
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    test_case_0()
    t_c_p_client_0 = TCPClient()
    if (t_c_p_client_0.resolver is None):
        return
    t_c_p_client_0.resolver.getaddrinfo(
        host="testhost",
        port=8080,
        family=socket.AF_INET,
        type=socket.SOCK_STREAM,
        proto=socket.IPPROTO_TCP,
        flags=socket.AI_PASSIVE,
    )

# Generated at 2022-06-26 09:01:01.524513
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    # if you have any arguments to the connect method, put them in this list
    args = []
    # if you have any keyword arguments to the connect method, put them in this dictionary
    kwargs = {}
    # the return type of the connect method
    ret_type = IOStream
    _ret = None
    def replace_connect(self, *args, **kwargs):
        return _ret

    # patch the method
    old_connect = TCPClient.connect
    TCPClient.connect = replace_connect
    # call the method
    try:
        ret = TCPClient.connect(*args, **kwargs)
    except Exception as e:
        raise ValueError(e)
    finally:
        # unpatch
        TCPClient.connect = old_connect

    # check the return type

# Generated at 2022-06-26 09:03:10.308793
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    c = _Connector(None, None)
    if c.timeout != None:
        print("Error: c.timeout != None")
    c.set_timeout(0.1)
    c.on_timeout()


# Generated at 2022-06-26 09:03:16.072295
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    _connector_0 = _Connector(
        addrinfo=[
            (socket.AF_INET, (object(), 88888))
        ],
        connect=t_c_p_client_0.on_connect,
    )
    assert isinstance(_connector_0, _Connector)
    _connector_0.on_connect_timeout()

test_case_0()
test__Connector_on_connect_timeout()

# Generated at 2022-06-26 09:03:28.084040
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.dns_resolver = Resolver()

    addr_list_0 = [('AF_INET', (('13.94.72.82', 80),)), ('AF_INET6', (('2a01:e34:ecdd:8600:2297:9df7:8196:b884', 80),)), ('AF_INET', (('2a01:e34:ecdd:8600:2297:9df7:8196:b884', 80),))]
    af_0 = socket.AF_INET
    addr_0 = (('13.94.72.82', 80),)
    stream_0 = TCPClient()
    future_0 = Future()
    # future_0.set_result(stream

# Generated at 2022-06-26 09:03:29.953107
# Unit test for method start of class _Connector
def test__Connector_start():
    addrinfo = [('', '')]
    connect = "TODO"

    _Connector(addrinfo, connect).start()
    

# Generated at 2022-06-26 09:03:41.577164
# Unit test for method connect of class TCPClient

# Generated at 2022-06-26 09:03:44.532021
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    addrinfo = [("AF_INET", ("127.0.0.1", "8888"))]
    test_connect = functools.partial(test_connect_implement)
    test_connector = _Connector(addrinfo, test_connect)


# Generated at 2022-06-26 09:03:47.275998
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_1 = TCPClient()
    t_c_p_client_2 = TCPClient()

    t_c_p_client_0 = TCPClient()
    _Connector.close_streams()
