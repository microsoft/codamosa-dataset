

# Generated at 2022-06-26 08:54:15.083523
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # setup test
    addrinfo = [('AF_INET', ('localhost', 11))]
    connect = lambda a,b: (a,b)

    test_connector = _Connector(addrinfo=addrinfo,connect=connect)
    # execute test
    test_connector.try_connect(iter(test_connector.primary_addrs))
    # assert result
    assert test_connector.future.done() is True
    assert test_connector.timeout is None
    assert test_connector.connect_timeout is None
    assert test_connector.last_error is None
    assert test_connector.remaining == 0


# Generated at 2022-06-26 08:54:26.541239
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    i_o_stream_0 = t_c_p_client_0.connect("localhost", 80)
    i_o_stream_1 = t_c_p_client_0.connect("localhost", 8080)
    i_o_stream_2 = t_c_p_client_0.connect("localhost", 8081)
    i_o_stream_3 = t_c_p_client_0.connect("localhost", 8082)
    i_o_stream_4 = t_c_p_client_0.connect("localhost", 8083)
    i_o_stream_5 = t_c_p_client_0.connect("localhost", 8084)

# Generated at 2022-06-26 08:54:33.391415
# Unit test for method set_connect_timeout of class _Connector

# Generated at 2022-06-26 08:54:34.857806
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    test_case_0()


# Generated at 2022-06-26 08:54:40.428464
# Unit test for constructor of class _Connector
def test__Connector():
    io_loop_1 = IOLoop.current()
    connect_1 = functools.partial(TCPClient.connect, io_loop_1)
    addrinfo_1 = [(socket.AF_INET, ("10.255.197.190", 80))]
    test_1 = _Connector(addrinfo_1, connect_1)
    test_1.start()



# Generated at 2022-06-26 08:54:44.760416
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    _Connector([(socket.AF_INET, ('127.0.0.1', 9999))], TCPClient._do_connect).on_timeout()


# Generated at 2022-06-26 08:54:54.171741
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # AF_INET, SOCK_STREAM, 6 (TCP)
    tc_0 = TCPClient()
    tc_0.connect(AF_INET, SOCK_STREAM, 6)
    tc_0.bind((host, port_num))
    tc_0.listen(max_num_pending_conns)
    tc_0.accept()
    # accept() returns another int, socket object, which can be used
    # to send data back
    tc_0.close()
    del tc_0

# Function to parse the specified URL and return a tuple of certificate file,
# private key file, and CA certificate file.

# Generated at 2022-06-26 08:55:03.172739
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_1 = TCPClient()
    t_c_p_client_1._connect = lambda af, addr: (None, Future())
    test_conn = _Connector([(socket.AF_INET, ("1", 1)), (socket.AF_INET6, ("2", 2))], t_c_p_client_1._connect)
    test_conn.try_connect([(socket.AF_INET, ("1", 1)), (socket.AF_INET6, ("2", 2))])


# Generated at 2022-06-26 08:55:08.879855
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    test_case_0()
    resolver = Resolver()
    addrinfo = resolver.resolve("www.google.com", 80)
    test_connector = _Connector(addrinfo, test_connect)


# Generated at 2022-06-26 08:55:12.051299
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    _connector_0 = _Connector(addrinfo=[], connect=_Connector.try_connect)
    _connector_0.clear_timeout()


# Generated at 2022-06-26 08:55:39.213161
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    print("\n----------Unit test for method on_timeout of class _Connector----------")
    c_connector_0 = _Connector([(1, ()), (2, ())], None)
    c_connector_0.try_connect([(1, ())])
    if c_connector_0.timeout is not None:
        print("connector0.timeout is not None")
    c_connector_0.remaining = 1
    c_connector_0.future.done = lambda : True
    c_connector_0.on_timeout()
    if c_connector_0.timeout is not None:
        print("connector0.timeout is not None")

    c_connector_1 = _Connector([(1, ()), (2, ())], None)

# Generated at 2022-06-26 08:55:44.814969
# Unit test for method start of class _Connector
def test__Connector_start():
    """
    Functional test case for _Connector.start()
    """
    addrinfo = (
        (socket.AF_INET, ("127.0.0.1", 8888)),
        (socket.AF_INET6, ("127.0.0.1", 8888)),
    )
    connector_0 = _Connector(addrinfo, None)
    connector_0.start()



# Generated at 2022-06-26 08:55:49.157336
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    try:
        pass
    except:
        pass
    # Nothing to be tested here since the method "connect" 
    # depends on network and the test requires more time.


# Generated at 2022-06-26 08:55:58.732462
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Create a _Connector instance
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._connector = _Connector(None, None)

    assert t_c_p_client_0._connector._connect_timeout == None

    # Set a timeout for the connector
    t_c_p_client_0._connector.set_connect_timeout(0.5)
    t_c_p_client_0._connector.on_connect_timeout()

    assert t_c_p_client_0._connector._connect_timeout != None
    assert isinstance(t_c_p_client_0._connector.future.exception(), TimeoutError)


# Generated at 2022-06-26 08:56:00.223604
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    connector_0 = _Connector([], None)
    connector_0.close_streams()
    assert True


# Generated at 2022-06-26 08:56:10.489679
# Unit test for constructor of class _Connector
def test__Connector():
    # Test: IPFamily.AF_INET
    from tornado.netutil import IPFamily

    ipfamily = IPFamily.AF_INET

    # Test case: ipfamily is not AF_INET, not AF_INET6 and not AF_UNSPEC
    try:
        ipfamily = IPFamily.AF_UNSPEC
        t_c_p_client_0 = TCPClient()
        ipfamily = IPFamily.AF_INET6
        t_c_p_client_0 = TCPClient()
    except Exception as e:
        print(e)
    else:
        raise Exception("Failed to raise exception")

    # Test: _Connector.__init__
    # Test case: Get an instance of _Connector
    t_c_client_a = TCPClient()
    t_c_client_b = TCPClient()
    t

# Generated at 2022-06-26 08:56:12.488270
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    connector = _Connector(addrinfo=[], connect=None)
    # Test case 0:
    connector.future.set_done()
    res = connector.on_connect_timeout()
    assert res is None

# Generated at 2022-06-26 08:56:18.564049
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams(): 
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver()
    t_c_p_client_0.__init__(
        max_buffer_size = None,
        max_buffer_size = None,
        max_buffer_size = None,
        max_buffer_size = None,
    )
    t_c_p_client_0.close_streams()


# Generated at 2022-06-26 08:56:24.271918
# Unit test for method split of class _Connector
def test__Connector_split():
    if type(_Connector.split([1, 5, 3])) is not tuple:
        raise Exception("Error: expected tuple")
    if _Connector.split([1, 5, 3])[0] != [1, 5, 3]:
        raise Exception("Error: expected [1, 5, 3]")
    if _Connector.split([1, 5, 3])[1] != []:
        raise Exception("Error: expected []")
    if _Connector.split([5, 1, 3])[0] != [5, 3]:
        raise Exception("Error: expected [5, 3]")
    if _Connector.split([5, 1, 3])[1] != [1]:
        raise Exception("Error: expected [1]")

# Generated at 2022-06-26 08:56:30.090804
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_0 = TCPClient()
    _Connector.__init__(t_c_p_client_0, [], TCPClient.connect)
    t_c_p_client_0.timeout = 0
    _Connector.on_timeout(t_c_p_client_0)
    t_c_p_client_0.timeout = None
    t_c_p_client_0.future = None
    _Connector.on_timeout(t_c_p_client_0)



# Generated at 2022-06-26 08:56:56.114129
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    tracer = Tracer()
    tracer.add_observer(observer0)
    tracer.enable_tracing()

    t_c_p_client_1 = TCPClient()
    _connector_1 = _Connector(((10, ('10', '10')),), ())
    _connector_1.close_streams()
    # we have also to check if ioloop remove_timeout is called:


# Generated at 2022-06-26 08:57:05.700026
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():

    class Resolver(object):
        """Non-blocking DNS resolver.

        .. versionchanged:: 4.1
           Now returns ``Futures`` instead of taking callbacks.

        .. versionchanged:: 5.0
           The ``io_loop`` argument (deprecated since version 4.1) has been
           removed.
        """
        def __init__(self, io_loop: "IOLoop" = None) -> None:
            pass

        def close(self) -> None:
            pass

        def resolve(
            self, host: str, port: int, family: int = socket.AF_UNSPEC
        ) -> "Future[List[Tuple[socket.AddressFamily, Tuple]]]":
            print("I'm resolved")
            print("I'm host: "+host)
            print("I'm port: "+str(port))


# Generated at 2022-06-26 08:57:15.335439
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    _connector1 = _Connector([(1,1)], None)
    _io_stream1 = IOStream(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
    _io_stream2 = IOStream(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
    _io_stream3 = IOStream(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
    _connector1.streams.add(_io_stream1)
    _connector1.streams.add(_io_stream2)
    _connector1.streams.add(_io_stream3)

    assert _io_stream1.closed() == False
    assert _io_stream2.closed() == False
    assert _io_stream3.closed() == False
   

# Generated at 2022-06-26 08:57:25.034928
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import sys
    import tornado
    import socket
    import tornado.iostream
    import tornado.netutil
    import tornado.ioloop
    import logging
    import traceback
    import tornado.iostream
    import tornado.gen
    import tornado.ioloop
    import tornado.netutil

    print('This is a test for method try_connect')
    try:
        _connector_var_0 = _Connector(...)
        _connector_var_1 = _connector_var_0.try_connect(...)
        return None
    except Exception as e:
        raise e


# Generated at 2022-06-26 08:57:32.296504
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    t_c_p_client_0 = TCPClient()
    # Create an instance of _Connector
    t_c_c_object_0 = _Connector([(socket.AF_INET, ('127.0.0.1', 9999))], t_c_p_client_0.create_connection)
    # Initialize set_connect_timeout method
    t_c_c_object_0.set_connect_timeout(30)


# Generated at 2022-06-26 08:57:40.705311
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_0 = TCPClient()
    connect_0 = _Connector([(0,), (0,), (0,)], t_c_p_client_0._stream_connect)
    timeout_0 = 0
    connect_0.set_timeout(timeout_0)
    connect_0.clear_timeout()
    connect_0.start()


# Generated at 2022-06-26 08:57:47.243285
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client = TCPClient()
    t_c_p_client_0 = TCPClient()
    t_c_p_client_1 = TCPClient()
    t_c_p_client_2 = TCPClient()
    t_c_p_client_3 = TCPClient()
    t_c_p_client_4 = TCPClient()
    t_c_p_client_5 = TCPClient()

    t_c_p_client.io_loop.time()
    t_c_p_client_0.io_loop.add_timeout(t_c_p_client.io_loop.time(), t_c_p_client.on_timeout)

# Generated at 2022-06-26 08:57:50.753690
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    future = t_c_p_client_0.connect("localhost", 15000)

# Generated at 2022-06-26 08:57:55.973258
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()
    addrinfo_0 = [[23, [1, 2, 3, 4]]]
    connector_0 = _Connector(addrinfo_0, t_c_p_client_0.connect)
    i_0 = 0
    addrs_0 = []
    for af, addr in addrinfo_0[i_0:]:
        addrs_0.append((af, addr))
        i_0 += 1
    connector_0.try_connect(iter(addrs_0))


# Generated at 2022-06-26 08:58:00.324970
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    # Test case 0:
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.connect("localhost", 80)


# Generated at 2022-06-26 08:58:37.491793
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    print("Start test_case_TCPClient_clear_timeout")
    t_c_p_client_1 = TCPClient()
    t_c_p_client_1.connect("www.facebook.com", 80, None, None)


# Generated at 2022-06-26 08:58:46.551368
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    addrinfo = [(1, (1, 3, 3, 7))]
    connect = _Connector(addrinfo, None)
    connect.timeout = None
    assert connect.timeout == None
    connect.io_loop = IOLoop.current()
    connect.try_connect(iter(addrinfo))
    connect.set_timeout(1.1)
    connect.on_timeout()
    assert connect.timeout == None


# Generated at 2022-06-26 08:58:52.866794
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_1 = TCPClient()
    localhost = '127.0.0.1'
    localport = 54321
    host = localhost
    port = localport
    af = socket.AF_INET
    ssl_options = None
    max_buffer_size = None
    source_ip = None
    source_port = None
    timeout = None
    stream = t_c_p_client_1.connect(host, port, af, ssl_options, max_buffer_size, source_ip, source_port, timeout)

if __name__ == '__main__':
    test_case_0()
    test_TCPClient_connect()

# Generated at 2022-06-26 08:58:59.633312
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    t_c_p_client_0 = TCPClient()
    addrs_0 = []
    __Connector_0 = _Connector(addrs_0, functools.partial(t_c_p_client_0.connect, 0))
    timeout_0 = 0.0
    __Connector_0.set_timeout(timeout_0)

# Class type without method __init__

# Generated at 2022-06-26 08:59:09.778798
# Unit test for constructor of class _Connector
def test__Connector():
    t_c_p_client_0 = TCPClient(max_buffer_size=16384)
    t_c_p_client_1 = TCPClient(max_buffer_size=16384)
    t_c_p_client_2 = TCPClient(max_buffer_size=16384)

    t_c_p_client_0._Connector([],t_c_p_client_0._Connector,)


# Generated at 2022-06-26 08:59:16.463367
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver()
    t_c_p_client_0.resolver.add_localhost_aliases = lambda _: None
    af, addr = None, None
    t_c_p_client_0.stream = IOStream(socket.socket(), af, addr)
    t_c_p_client_0._Connector__timeout = t_c_p_client_0.io_loop.add_timeout(
        t_c_p_client_0.io_loop.time() + _INITIAL_CONNECT_TIMEOUT, t_c_p_client_0._Connector__on_timeout
    )
    test_case_0()


# Generated at 2022-06-26 08:59:23.563434
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # This is the class Unit test

    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.connector = _Connector([],None)
    t_c_p_client_0.connector.clear_timeouts()
    return t_c_p_client_0.connector.timeout == None and t_c_p_client_0.connector.connect_timeout == None


# Generated at 2022-06-26 08:59:29.613535
# Unit test for constructor of class _Connector
def test__Connector():
    t_p_client_0 = TCPClient()
    t_p_connector_0 = _Connector(addrinfo = [("127.0.0.1", "9091")], connect = t_p_client_0.connect)
    print("test_0 done")



# Generated at 2022-06-26 08:59:34.278445
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_1 = TCPClient()
    addrs = [(10, None), (20, None), (30, None)]
    connector = _Connector(addrs, t_c_p_client_1.connect)
    connector.on_timeout()
    assert addrs == list(connector.secondary_addrs)


# Generated at 2022-06-26 08:59:44.828102
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    test_addrinfo = [
        (socket.AddressFamily.AF_INET,
        ("194.45.15.21", 80)
        ),
        (socket.AddressFamily.AF_INET,
        ("194.45.15.21", 80)
        )
    ]
    t_c_p_client_1 = TCPClient()
    def test_connect(af, addr):
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()
    conn = _Connector(test_addrinfo, test_connect)
    conn.on_timeout()


# Generated at 2022-06-26 09:00:57.679008
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    # instantiate _Connector object
    t_c_0 = _Connector(t_c_p_client_0)
    # handle case where future is not done
    t_c_0.future.set_exception(TimeoutError())


# Generated at 2022-06-26 09:01:01.982389
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():

    t_c_p_client_1 = TCPClient()
    t_c_p_client_2 = TCPClient()

    
    
    print("Test clear timeout")

    addrs = [(t_c_p_client_1.af, t_c_p_client_1.address)]
    connect = connect_tcp
    test_connector = _Connector(addrs, connect)

    test_connector.set_timeout(0.3)
    test_connector.clear_timeout()
    print("Time out of _Connector: ", test_connector.timeout)



# Generated at 2022-06-26 09:01:05.627165
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    t_c_p_client = TCPClient()
    t_c_p_client.connect("localhost", 443)



# Generated at 2022-06-26 09:01:14.957818
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    tcp_client = TCPClient()
    host = 'localhost'
    port = 8000
    ssl_options = None
    max_buffer_size = None
    source_ip = None
    source_port = None

    async def _test_connect():
        await tcp_client.connect(host, port, ssl_options, max_buffer_size, source_ip, source_port)

    IOLoop.current().run_sync(_test_connect)

    host = 'localhost'
    port = 8000
    ssl_options = None
    max_buffer_size = None
    source_ip = None
    source_port = None

    async def _test_connect():
        await tcp_client.connect(host, port, ssl_options, max_buffer_size, source_ip, source_port)
    IOLoop.current

# Generated at 2022-06-26 09:01:17.789929
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    tcp_client = TCPClient()
    # Test for exception IOError
    # Note that connect() is an asynchronous method.
    # So we can't use assertRaises() to test for exception
    with pytest.raises(Exception):
        tcp_client.connect(host="invalid.host")


# Generated at 2022-06-26 09:01:27.279561
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    # Create a _Connector object
    addr_info = [(socket.AddressFamily.AF_INET,('172.16.0.1', 80)),(socket.AddressFamily.AF_INET6,('172.16.0.2', 81))]
    t_s_s = test__Connector.TestStreamSetter()
    def connect(af, addr):
        return t_s_s.set_addr(af, addr)
    test_case_0_connector = _Connector(addr_info, connect)
    # Pass a float as the argument 'connect_timeout' of set_connect_timeout()
    test_case_0_connector.set_connect_timeout(0.3)



# Generated at 2022-06-26 09:01:39.821676
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("8.8.8.8", 1202)),
        (socket.AF_INET6, ("2001:4860:4860::8888", 1202)),
        (socket.AF_INET, ("8.8.4.4", 1202)),
    ]
    _Connector_0 = _Connector(addrinfo, None)
    primary_addrs, secondary_addrs = _Connector_0.split(addrinfo)
    assert primary_addrs == [
        (socket.AF_INET, ("8.8.8.8", 1202)),
        (socket.AF_INET, ("8.8.4.4", 1202)),
    ]

# Generated at 2022-06-26 09:01:45.684959
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()
    try:
        t_c_p_client_0._Connector.try_connect()
    except Exception as err:
        print("+++++++++<<<<<<<<<<<<<", err)


# Generated at 2022-06-26 09:01:57.784705
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    def cd_f_tcp_client_connect_0(host_0, port_0, af_0 = socket.AF_UNSPEC, ssl_options_0 = None, max_buffer_size_0 = None, source_ip_0 = None, source_port_0 = None, timeout_0 = None):
        t_c_p_client_0 = TCPClient()
        res_0: IOStream = t_c_p_client_0.connect(host_0, port_0, af_0, ssl_options_0, max_buffer_size_0, source_ip_0, source_port_0, timeout_0)
        return res_0



# Generated at 2022-06-26 09:02:06.282569
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    test_case_0()
    test_addr_info = [
        (socket.AF_INET, ('127.0.0.1', 8080)),
        (socket.AF_INET6, ('::1', 8081)),
    ]
    t_c_p_client_1 = TCPClient()
    test_connector_0 = _Connector(test_addr_info, t_c_p_client_1._try_connect)
    test_connector_0.try_connect(iter(test_connector_0.primary_addrs))
    test_connector_0.try_connect(iter(test_connector_0.secondary_addrs))
