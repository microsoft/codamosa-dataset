

# Generated at 2022-06-26 08:54:20.091819
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    t_c_0 = _Connector([(1, (1, 2))], lambda x, y: (2, 3))
    t_c_0.set_connect_timeout(0)

    t_c_1 = _Connector([(1, (1, 2))], lambda x, y: (2, 3))
    t_c_1.set_connect_timeout(0.0)

    t_c_2 = _Connector([(1, (1, 2))], lambda x, y: (2, 3))
    t_c_2.set_connect_timeout(5)

    t_c_3 = _Connector([(1, (1, 2))], lambda x, y: (2, 3))
    t_c_3.set_connect_timeout(5.0)


# Generated at 2022-06-26 08:54:27.838424
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    connector_0 = _Connector(
        [t_c_p_client_0.default_addrinfo], t_c_p_client_0.default_connect
    )
    t_c_p_client_0.default_stream.close()
    t_c_p_client_0.default_stream.close()
    connector_0.close_streams()
    connector_0.close_streams()


# Generated at 2022-06-26 08:54:33.883779
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.connect("google.com", 443, af=socket.AF_INET)


# Generated at 2022-06-26 08:54:34.889065
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    test__Connector_on_connect_timeout_0()


# Generated at 2022-06-26 08:54:39.282537
# Unit test for constructor of class _Connector
def test__Connector():
    from tornado.netutil import bind_sockets
    import tornado.tcpserver
    import tornado.gen
    import time

    class _TestServer(tornado.tcpserver.TCPServer):
        def __init__(
            self,
            io_loop,
            af,
            addr,
            address_family,
            stream_address,
            stream_family,
            stream_cls,
            ssl_options,
        ) -> None:
            super(_TestServer, self).__init__(
                io_loop=io_loop,
                ssl_options=ssl_options,
                max_buffer_size=None,
                read_chunk_size=None,
            )
            self.address_family = address_family
            self.stream_address = stream_address
            self.stream_family = stream

# Generated at 2022-06-26 08:54:41.572444
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    c = _Connector
    c.clear_timeouts()

# Generated at 2022-06-26 08:54:51.525338
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    t_c_p_stream_0 = t_c_p_client_0.connect(host="127.0.0.1", port=80)
    t_c_p_connector_0 = _Connector([(socket.AF_INET, ("127.0.0.1", 80))], connect)
    t_c_p_connector_0.streams.add(t_c_p_stream_0)
    t_c_p_connector_0.close_streams()


# Generated at 2022-06-26 08:55:04.389228
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_1 = TCPClient()
    # First, set up the test environment
    t_c_p_client_1.poll_max = 100
    t_c_p_client_1.time_to_deadline = 100
    t_c_p_client_1.time_to_open = 100
    t_c_p_client_1.time_to_close = 100
    # Then, set up the test object
    _t_c_p_connector_1_instance = _Connector(
        addrinfo = [
            "af", "addr"
        ],
        connect =  (
            "af", "addr"
        ),
    )
    # Then, set up the test object's attributes
    _t_c_p_connector_1_instance.io_loop = IOL

# Generated at 2022-06-26 08:55:13.559288
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client = TCPClient()
    t_c_p_client.addrinfo = [(1, 2), (3, 4), (5, 6)]
    t_c_p_client.connect = lambda x, y : (a, b)
    t_c_p_client._Connector = _Connector(t_c_p_client.addrinfo, t_c_p_client.connect)
    t_c_p_client._Connector.try_connect(iter(t_c_p_client.addrinfo))


# Generated at 2022-06-26 08:55:20.221557
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    t_c_p_client_0 = TCPClient()
    _connector_0 = _Connector(t_c_p_client_0.resolver.resolve('google.com'),t_c_p_client_0.connect)
    _connector_0.set_connect_timeout(1)


# Generated at 2022-06-26 08:55:36.830888
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    _Connector.set_timeout(_Connector, 0.3)


# Generated at 2022-06-26 08:55:38.361329
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    pass


# Generated at 2022-06-26 08:55:45.051425
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_1 = TCPClient()

    af, addr, stream = t_c_p_client_1.connect(t_c_p_host, t_c_p_port)

    connector = _Connector([(af, addr)], t_c_p_client_1._wrap_socket)

    connector.try_connect(iter(connector.primary_addrs))

    connector.set_timeout(timeout)

    connector.on_timeout()


# Generated at 2022-06-26 08:55:47.942360
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    _Connector_0 = _Connector(list(), lambda x, y: (1, 1))
    return


# Generated at 2022-06-26 08:55:54.371077
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_0 = TCPClient()
    t_connector_0 = _Connector([], None)
    t_connector_0.timeout = None
    t_connector_0.clear_timeout()
    assert t_connector_0.timeout is None


# Generated at 2022-06-26 08:55:55.812105
# Unit test for method start of class _Connector
def test__Connector_start():
    c = _Connector
    assert(c)


# Generated at 2022-06-26 08:55:58.663381
# Unit test for method split of class _Connector
def test__Connector_split():
    # x = _Connector.split(x,y)
    # assert (x == y)
    pass


# Generated at 2022-06-26 08:56:09.843950
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    from typing import List

    t_c_p_client_0 = TCPClient()
    t_conector_0 = _Connector([], t_c_p_client_0.connect)
    t_conector_0.future = Future()
    t_conector_0.io_loop = IOLoop.current()
    t_conector_0.connect = t_c_p_client_0.connect
    t_conector_0.timeout = None
    t_conector_0.connect_timeout = None
    t_conector_0.last_error = None
    t_conector_0.remaining = 0
    t_conector_0.primary_addrs = []
    t_conector_0.secondary_addrs = []
    t_conector_0.streams = set()
    t

# Generated at 2022-06-26 08:56:11.573136
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector.set_timeout(1.5)


# Generated at 2022-06-26 08:56:12.428074
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    pass


# Generated at 2022-06-26 08:56:47.012446
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    conn = Connector(None, None)
    conn.set_timeout(2.0)
    return conn.timeout is None

################################################################################
# End of test cases for Connector
################################################################################



# Generated at 2022-06-26 08:56:54.421705
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # TCPClient()
    # In the following test case, we assume the shortest timeout is 0.3s
    # and the longest timeout is 60s
    # Connecting to a server with a known public address
    t_c_p_client_0 = TCPClient()
    f_0 = Future()
    t_c_p_client_0.connect_future = f_0
    ip_0 = "171.17.193.6"
    port_0 = 21
    timeout_0 = 30
    t_c_p_client_0.connect(ip_0, port_0, timeout_0)
    # Set timeout for our instance
    t_c_p_client_0.connector.set_timeout(0.3)
    t_c_p_client_0.connector.set_connect_timeout(60)


# Generated at 2022-06-26 08:56:58.387741
# Unit test for constructor of class _Connector
def test__Connector():
    _conn = _Connector([(1,2)], test_case_0)
    assert (_conn.__dict__["primary_addrs"] == [(1,2)])


# Generated at 2022-06-26 08:57:09.506422
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()
    t_c_p_resolver_0 = t_c_p_client_0.resolver
    t_c_p_fut_addrs_0 = t_c_p_resolver_0.resolve("google.com")
    t_c_p_resolver_0.resolve("google.com") # maybe triggers call_later
    t_c_p_resolver_0.resolve("google.com") # maybe triggers call_later
    t_c_p_resolver_0.resolve("google.com") # maybe triggers call_later
    t_c_p_resolver_0.resolve("google.com") # maybe triggers call_later
    # The following statement is ok but not good
    # t_c_p_resolver

# Generated at 2022-06-26 08:57:14.403509
# Unit test for constructor of class _Connector
def test__Connector():
    c = _Connector([(1, 2)], None)
    assert c.io_loop is IOLoop.current()
    assert c.future.done()
    assert c.timeout is None
    assert c.connect_timeout is None
    assert c.last_error is None
    assert c.remaining == 1
    assert c.primary_addrs == [(1, 2)]
    assert c.secondary_addrs == []
    assert c.streams == set()



# Generated at 2022-06-26 08:57:26.622179
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo: List[Tuple] = [
        (
            socket.AddressFamily.AF_INET,
            (
                "192.168.243.20",
                8888,
            ),
        ),
        (
            socket.AddressFamily.AF_INET,
            (
                "192.168.243.20",
                9999,
            ),
        ),
        (
            socket.AddressFamily.AF_INET6,
            (
                "[::]",
                8888,
            ),
        ),
    ]
    # print(addrinfo)

# Generated at 2022-06-26 08:57:38.490098
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    t_c_p_client_1 = TCPClient()
    ioloop = IOLoop.current()
    t_c_p_client_2 = TCPClient()
    # t_c_p_client_3 = TCPClient(ioloop=ioloop)
    def t_c_p_connect(af, addr) -> Tuple[IOStream, "Future[IOStream]"]:
        t_c_p_client_4 = TCPClient()
        return t_c_p_client_4.connect(addr, af)
    #t_c_p_client_5 = TCPClient(ioloop=ioloop)
    t_c_connector = _Connector([(socket.AF_INET, ("localhost", 80))], t_c_p_connect)
    t_c_connector.set_timeout(0.5)

# Generated at 2022-06-26 08:57:41.790454
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():

    def test_future_connect_done(
        result: IOStream
    ) -> None:
        print("result", result)

    future = Future()
    future.add_done_callback(test_future_connect_done)

    future.set_result("success to connect")

    f = _Connector(None, None)
    f.try_connect()



# Generated at 2022-06-26 08:57:54.859170
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Unit test for _Connector.on_connect_timeout()
    
    # Set up _Connector with a fake on_connect_timeout function
    future = Future()
    streams = set()
    fake_io_loop = object()
        
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector.on_connect = lambda x, y: (IOStream(x, y), future)
    
    fake_connector = _Connector(t_c_p_client_0._Connector.connect, future)
    fake_connector.io_loop = fake_io_loop
    fake_connector.set_connect_timeout(0.3)
    
    
    # Test if fake_connector.on_connect_timeout() raises exception

# Generated at 2022-06-26 08:58:05.123021
# Unit test for method split of class _Connector
def test__Connector_split():
    _INITIAL_CONNECT_TIMEOUT = 0.3
    _connector = _Connector([], lambda _,__ : ())
    _connector.split([(1,1),(2,2),(4,4),(8,8)])
    _connector.split([(1,1),(2,2),(4,4),(8,8),(32,32),(64,64)])
    _connector.split([(1,1),(2,2)])



# Generated at 2022-06-26 08:59:11.882845
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    addrinfo = [(socket.AF_INET, ("172.17.42.1", 80))]
    def connect(
        self, af: socket.AddressFamily, addr: Tuple
    ) -> Tuple[IOStream, "Future[IOStream]"]:
        future = Future()
        future.set_result(IOStream(socket.socket()))
        return IOStream(socket.socket()), future
    conn = _Connector(addrinfo, connect)
    conn.start(connect_timeout=1)
    conn.on_connect_timeout()


# Generated at 2022-06-26 08:59:16.473127
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # t_c_p_client_0 = TCPClient()
    test_case_0()
    # print(test__Connector_clear_timeouts)


# Generated at 2022-06-26 08:59:24.445485
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    t_c_p_client_0 = TCPClient()
    future_0 = Future()
    addrs_0 = iter(tuple())
    _Connector.on_connect_done(future_0, addrs_0, socket.AddressFamily.AF_UNSPEC, tuple())
    future_0.set_exception(future_0)
    future_0.result()
    _Connector.clear_timeout()
    _Connector.set_timeout(0.3)
    _Connector.on_timeout()
    assert _Connector.last_error is not None


# Generated at 2022-06-26 08:59:35.200454
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    i_o_stream_0 = t_c_p_client_0.connect("127.0.0.1", 80)
    print(i_o_stream_0.closed())
    i_o_stream_0.close()
    print(i_o_stream_0.closed())
    print(i_o_stream_0)
    # Two invocations of method start_tls of class IOStream
    i_o_stream_0 = i_o_stream_0.start_tls(False, ssl_options = {})
    i_o_stream_0 = i_o_stream_0.start_tls(False, ssl_options = {})


# Generated at 2022-06-26 08:59:46.507728
# Unit test for method split of class _Connector
def test__Connector_split():
    connector0 = _Connector(list(), functools.partial())
    connector1 = _Connector([list()], functools.partial())
    connector2 = _Connector([[list()]], functools.partial())
    connector3 = _Connector([(list(), list()), (list(), list()), (list(), list())],
                            functools.partial())
    connector4 = _Connector([(1, list()), (2, list()), (3, list())],
                            functools.partial())
    connector5 = _Connector([(1, (1, list())), (2, (2, list())), (3, (3, list()))],
                         functools.partial())

# Generated at 2022-06-26 08:59:54.063888
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    '''
    def set_timeout(self, timeout: float) -> None:
        self.timeout = self.io_loop.add_timeout(
            self.io_loop.time() + timeout, self.on_timeout
        )
    '''
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector.set_timeout(0.0)


# Generated at 2022-06-26 08:59:59.596898
# Unit test for method split of class _Connector
def test__Connector_split():
    t_c_0 = TCPClient()
    t_c_connector_0 = t_c_0._Connector(
        [], functools.partial(t_c_0._create_connection, None)
    )

    t_c_p_af_addr_0 = t_c_connector_0.split([])

    assert t_c_p_af_addr_0 == ((), ())
    t_c_p_af_addr_1 = t_c_connector_0.split([(t_c_0._resolver.common_af, ())])

    assert t_c_p_af_addr_1 == ((t_c_0._resolver.common_af, ()), ())

# Generated at 2022-06-26 09:00:08.251547
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    str_ret_0 = await t_c_p_client_0.connect(
        'localhost', 80, socket.AF_INET, max_buffer_size=None, source_ip=None, source_port=None, timeout=_INITIAL_CONNECT_TIMEOUT
    )
    assert isinstance(str_ret_0, IOStream) == True
    str_ret_1 = await t_c_p_client_0.connect(
        'localhost', 80, socket.AF_INET, max_buffer_size=None, source_ip=None, source_port=None, timeout=_INITIAL_CONNECT_TIMEOUT
    )
    assert isinstance(str_ret_0, IOStream) == True


# Generated at 2022-06-26 09:00:12.790055
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    """Unit test for method close_streams of class _Connector."""
    c = _Connector(None, None)
    c.close_streams()


# Generated at 2022-06-26 09:00:21.338029
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    test__Connector_set_timeout_client_0 = TCPClient()
    test__Connector_set_timeout_client_0.connect_timeout = 0
    test__Connector_set_timeout_client_0.io_loop = 1
    test__Connector_set_timeout_client_0.timeout = 0
    assert test__Connector_set_timeout_client_0 is not None


# Generated at 2022-06-26 09:02:38.993841
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.connect('localhost', 80, af=socket.AF_INET, ssl_options=None, max_buffer_size=None, source_ip=None, source_port=None)


# Generated at 2022-06-26 09:02:44.478400
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    pass

# Generated at 2022-06-26 09:02:46.936223
# Unit test for method split of class _Connector
def test__Connector_split():
    _Connector([(socket.AF_INET, ("127.0.0.1", 8888))], None)



# Generated at 2022-06-26 09:02:57.848024
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    key_path = "server.key"
    cert_path = "server.crt"

    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 8080)),
        (socket.AF_INET, ("127.0.0.1", 8081)),
    ]

    def connect_fun(af, addr):
        # type: (int, Tuple[str, int]) -> Tuple[IOStream, Future[IOStream]]
        future = Future()  # type: Future[IOStream]

        if af == socket.AF_INET:
            stream = IOStream(socket.socket(af, socket.SOCK_STREAM, 0))
        else:
            assert af == socket.AF_INET6

# Generated at 2022-06-26 09:03:01.730299
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    timeout = 1;
    obj = _Connector(addrinfo=[], connect=lambda af, addr: (None, None))
    obj.set_timeout(timeout)
    assert(obj.timeout is not None)
    assert(obj.timeout._callback is obj.on_timeout)


# Generated at 2022-06-26 09:03:07.082019
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    resolver = Resolver(io_loop=IOLoop.current())
    resolver.resolve('www.example.com', 80)
    # ...
    future = t_c_p_client_0.connect()
    # ...
    future_add_done_callback(future, t_c_p_client_0._Connector.on_timeout())
    # ...



# Generated at 2022-06-26 09:03:12.007788
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    future = Future()
    timeout = IOLoop.current().add_timeout(IOLoop.current().time() + 1, lambda: future.set_result(None))
    connector = _Connector([], lambda af, addr: (4, 1))
    connector.timeout = timeout
    connector.clear_timeout()
    assert(connector.timeout is None)


# Generated at 2022-06-26 09:03:16.200004
# Unit test for constructor of class _Connector
def test__Connector():
    # Assume that localhost is not IPv6
    # This test case is only intended to check if the invocation
    # of the constructor of _Connector is correct.
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector("localhost", 80)


# Generated at 2022-06-26 09:03:20.107103
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    addrs = [(2, 3), (3, 4), (4, 5)]
    def connect(family, address):
        return None
    connector = _Connector(addrs, connect)
    connector.on_timeout()


# Generated at 2022-06-26 09:03:31.386910
# Unit test for method start of class _Connector
def test__Connector_start():
    # Test case 1:
    # This is a normal test case.
    # use an object of class _Connector to call the start method.
    addrinfo = [(socket.AddressFamily.AF_INET, '0.0.0.0')]
    # @param af An address family, either AF_INET or AF_INET6
    # @return: Future[IOStream]
    def connect(af, addr):
        return

    # @typing.overload
    # def __init__(
    #     self,
    #     result: None = None,
    #     exception: BaseException = None,
    # ) -> None: ...
    future = future_add_done_callback(connect, connect)
    
    _connector = _Connector(addrinfo, connect)
    # Set the timeout to 0.3 seconds
   