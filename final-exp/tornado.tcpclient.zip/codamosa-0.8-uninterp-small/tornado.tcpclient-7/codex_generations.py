

# Generated at 2022-06-26 08:54:19.187878
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    t_c_p_client_0 = TCPClient()
    assert(isinstance(t_c_p_client_0, TCPClient))
    conn_holder_0 = t_c_p_client_0._Connector(addrinfo=[],
                                              connect=t_c_p_client_0.connect)
    assert(isinstance(conn_holder_0, t_c_p_client_0._Connector))
    future = Future()

# Generated at 2022-06-26 08:54:20.015173
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    pass


# Generated at 2022-06-26 08:54:30.130532
# Unit test for method split of class _Connector
def test__Connector_split():
    # Case 1, addrinfo is empty
    # Return (empty, empty)
    A = [ ]
    a, b = _Connector.split(A)
    assert (len(a) == 0) and (len(b) == 0)

    # Case 2, addrinfo contains one entry
    # Return (A[0], empty)
    A = [(1,1)]
    a, b = _Connector.split(A)
    assert (a == A) and (len(b) == 0)

    # Case 3, addrinfo contains two entries with the same family
    # Return (A, empty)
    A = [(1,1), (1,2)]
    a, b = _Connector.split(A)
    assert (a == A) and (len(b) == 0)

    # Case 4, addrinfo contains two entries with different

# Generated at 2022-06-26 08:54:33.883689
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    _Connector = _Connector([0,1,2], lambda x: None)
    _Connector.set_timeout(0)



# Generated at 2022-06-26 08:54:38.162943
# Unit test for constructor of class _Connector
def test__Connector():
    # import logging
    # logging.basicConfig(level=logging.DEBUG)
    # logging.info("hello")
    a = _Connector(None, None)
    assert a


# Generated at 2022-06-26 08:54:52.099123
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    # Create _Connector object
    t_c_p_client_0 = TCPClient()
    t_c_connector_0 = _Connector(t_c_p_client_0.get_addrinfo, t_c_p_client_0.connect)

    # Call function on_connect_done and verify test condition

# Generated at 2022-06-26 08:54:58.947615
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_1 = TCPClient()
    t_c_p_client_2 = TCPClient()
    t_c_p_client_3 = TCPClient()
    t_c_p_client_4 = TCPClient()
    t_c_p_client_5 = TCPClient()
    t_c_p_client_6 = TCPClient()
    t_c_p_client_7 = TCPClient()
    t_c_p_client_8 = TCPClient()
    t_c_p_client_9 = TCPClient()
    t_c_p_client_10 = TCPClient()
    t_c_p_client_11 = TCPClient()
    t_c_p_client_12 = TCPClient()
    t_c

# Generated at 2022-06-26 08:55:06.426649
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    x = _Connector(
        [
            (1, (1, 2)),
            (2, (3, 4)),
            (5, (6, 7)),
            (8, (9, 0)),
            (11, (12, 13)),
            (14, (15, 16)),
            (17, (18, 19)),
            (20, (21, 22)),
            (23, (24, 25)),
            (26, (27, 28)),
        ],
        lambda af, addr: (
            None,
            None,
        ),
    )
    x.timeout = 0
    x.future = gen.Future()
    x.on_timeout()


# Generated at 2022-06-26 08:55:10.759243
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # Test case 0
    t_c_p_client_0 = TCPClient()
    _Connector.clear_timeout(t_c_p_client_0)


# Generated at 2022-06-26 08:55:18.902481
# Unit test for constructor of class _Connector
def test__Connector():
    t_c_p_client_0 = TCPClient()
    addrinfo = [
        (
            socket.AddressFamily(1),
            (
                "127.0.0.1",
                "80",
            ),
        ),
        (
            socket.AddressFamily(1),
            (
                "127.0.0.1",
                "80",
            ),
        ),
    ]  # type: List[Tuple]
    t_c_p_client_0.connect = lambda _, __: (None, None)
    tmp_0 = _Connector(
        addrinfo,
        t_c_p_client_0.connect,
    )
    tmp_0.start()
    assert isinstance(tmp_0.start(1.0), Future)


##
# Callbacks are not supported yet


# Generated at 2022-06-26 08:55:43.066933
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ('127.0.0.1', 8000)),
        (socket.AF_INET, ('127.0.0.1', 8001)),
        (socket.AF_INET6, ('127.0.0.1', 8000)),
        (socket.AF_INET, ('127.0.0.1', 8002)),
    ]
    print(Connector._Connector.split(addrinfo))


# Generated at 2022-06-26 08:55:56.798406
# Unit test for method split of class _Connector
def test__Connector_split():

    conn = _Connector()

    test_case_0_addrinfo_1 = [
        socket.AF_INET,
        ((127, 0, 0, 1), 1000),
        socket.AF_INET,
        ((127, 0, 0, 1), 1000),
        socket.AF_INET,
        ((127, 0, 0, 1), 1000),
        socket.AF_INET,
        ((127, 0, 0, 1), 1000),
        socket.AF_INET,
        ((127, 0, 0, 1), 1000),
        socket.AF_INET6,
        ((127, 0, 0, 1), 1000),
    ]


# Generated at 2022-06-26 08:56:09.106180
# Unit test for constructor of class _Connector
def test__Connector():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver()
    t_c_p_client_0.resolver.configure(["127.0.0.1:5555"])
    t_c_p_client_0.resolver.resolve("localhost", 80, t_c_p_client_0._resolve_callback)
    t_c_p_client_0.resolver.close()
    t_c_p_client_0.resolver = None
    t_c_p_client_0.resolver = Resolver()
    t_c_p_client_0.resolver.configure(["127.0.0.1:5555"])
    t_c_p_client_0.resolver.resolve

# Generated at 2022-06-26 08:56:11.345553
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    stream = IOStream(socket.socket())
    test_connector = _Connector([(0, (1, 2))], lambda a, b: (stream, Future()))
    test_connector.close_streams()


# Generated at 2022-06-26 08:56:20.726247
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    def test_body(
        addrs: Iterator[Tuple[socket.AddressFamily, Tuple]],
        af: socket.AddressFamily,
        addr: Tuple,
        future: "Future[IOStream]",
    ) -> None:
        t_conn_0 = _Connector(
            addrinfo=[(socket.AF_INET, ("127.0.0.1", 123)), (socket.AF_INET, ("127.0.0.1", 7890))],
            connect=lambda af, addr: (None, future),
        )
        t_conn_0.on_connect_done(addrs, af, addr, future)

# Generated at 2022-06-26 08:56:22.075501
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    _Connector.close_streams(object)
    print("Unit test for method close_streams of class _Connector", "Test complete")

# Generated at 2022-06-26 08:56:27.582841
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client = TCPClient()
    t_c_p_client.remote_host = 'localhost'
    t_c_p_client.remote_port = 8888
    t_c_p_client.resolve_addr()
    t_c_p_client.connect()


# Generated at 2022-06-26 08:56:37.078686
# Unit test for method start of class _Connector
def test__Connector_start():
    temp_addrinfo = [(socket.AF_INET, ('127.0.0.1', 8888))]
    # temp_timeout = _INITIAL_CONNECT_TIMEOUT
    # temp_connect_timeout = None
    temp_connect = lambda af, addr: (IOStream(), Future())
    temp_connector = _Connector(temp_addrinfo, temp_connect)
    temp_connector.start()



# Generated at 2022-06-26 08:56:43.057386
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # import socket

    # create a socket object
    t1_s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # get local machine name
    t1_host = socket.gethostname()

    t1_port = 9999

    # bind to the port
    t1_s.bind((t1_host, t1_port))

    # queue up to 5 requests
    t1_s.listen(5)

    while True:
        # establish a connection
        t1_c_s, t1_c_addr = t1_s.accept()

        print("Got a connection from %s" % str(t1_c_addr))
        c_msg = 'Thank you for connecting' + "\r\n"

# Generated at 2022-06-26 08:56:46.079058
# Unit test for constructor of class _Connector
def test__Connector():
    _Connector(addrinfo=[()], connect=lambda af, addr: (None, None))


# Generated at 2022-06-26 08:57:25.590755
# Unit test for constructor of class _Connector
def test__Connector():
    """The callables for __init__ will be tested through unit tests for
       functions connectTCP and connectSSL.
    """
    # addr = [(2, ('127.0.0.1', 80)), (10, ('fe80::1', 80))]
    addr = [(2, ('127.0.0.1', 80))]
    conn = _Connector(addr, (lambda x, y: (x, y)))
    conn._Connector__init__(addr, (lambda x, y: (x, y)))
    assert(conn is not None)
    test_case_0()

test__Connector()

_DEFAULT_CONNECT_TIMEOUT = 20.0
_FAMILY_V6 = 10



# Generated at 2022-06-26 08:57:29.286821
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    print("Unit test for method connect of class TCPClient")
    t_c_p_client_0 = TCPClient()
    stream_1 : IOStream = t_c_p_client_0.connect('www.furfuryl.co', 80, af=AF_INET)
    print("Unit test for method connect of class TCPClient passed")


# Generated at 2022-06-26 08:57:30.008249
# Unit test for method start of class _Connector
def test__Connector_start():
    assert 0 


# Generated at 2022-06-26 08:57:31.347458
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()


# Generated at 2022-06-26 08:57:44.369493
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    _connector_inst_0 = _Connector([(2, ((2,), (3,), 4)), (3, ((5,), (6,), 7))], t_c_p_client_0._TCPClient__connect)
    _connector_inst_0.future = Future()
    _connector_inst_0.future.done = MagicMock(side_effect = [False, True])
    _connector_inst_0.future.result = MagicMock(return_value = None)
    _connector_inst_0.future.exception = MagicMock(return_value = None)
    _connector_inst_0.timeout = None
    _connector_inst_0.connect_timeout = None
    _connector_inst_0.last

# Generated at 2022-06-26 08:57:55.725408
# Unit test for constructor of class _Connector
def test__Connector():
    print("Testing constructor of _Connector")
    class FakeFuture(Future):
        def __init__(fake_self) -> None:
            super(FakeFuture, fake_self).__init__()
    fake_addrinfo = [(socket.AF_INET, fake_addr) for fake_addr in ["127.0.0.1", "127.0.0.2", "127.0.0.3"]]
    fake_connect = lambda fake_af, fake_addr: (None, FakeFuture())
    fake_connector = _Connector(fake_addrinfo, fake_connect)
    assert len(fake_connector.primary_addrs) == 3
    assert len(fake_connector.secondary_addrs) == 0
    assert isinstance(fake_connector.future, Future)

# Generated at 2022-06-26 08:57:58.090622
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_1 = TCPClient()


# Generated at 2022-06-26 08:57:59.603086
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    pass


# Generated at 2022-06-26 08:58:08.576009
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    af = socket.AddressFamily.AF_INET
    addr = ("localhost", 8000)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    s.bind((addr))
    s.listen(5)
    c, addr = s.accept()
    s.close()
    c.close()
    tr = _Connector(None, None)
    tr.last_error = None
    tr.future = Future()
    tr.future.done()
    tr.future.result()
    tr.future.set_exception(None)
    tr.future.exception()


# Generated at 2022-06-26 08:58:12.050398
# Unit test for constructor of class _Connector
def test__Connector():
    c = _Connector( [], functools.partial(t_c_p_client_0._create_stream_sync) )


# Generated at 2022-06-26 08:59:10.036742
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    _Connector.set_connect_timeout(1)


# Generated at 2022-06-26 08:59:24.043330
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    connect_timeout = {1.234, datetime.timedelta(microseconds = 50)}
    func = lambda x: isinstance(x, (float, datetime.timedelta))
    assert func(connect_timeout) == True, 'Input test_set_connect_timeout is not of the correct type'
    _Connector_0 = _Connector(
        addrinfo = [
            "l",
            [
                "a",
                [
                    "s",
                    [
                        "t",
                        "a",
                        "t",
                        "i",
                        "c"
                    ]
                ]
            ]
        ],
        connect = lambda x, y: (IOStream(), Future())
    )
    _Connector_0.set_connect_timeout(connect_timeout)


# Generated at 2022-06-26 08:59:35.485105
# Unit test for method split of class _Connector

# Generated at 2022-06-26 08:59:46.612693
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.max_buffer_size = 61830
    t_c_p_client_0.resolver = Resolver()
    t_c_p_client_0.resolver.configure('[::1]:53', 53)
    t_c_p_client_0.start_timeout = 0.8
    t_c_p_client_0.io_loop = IOLoop.current()
    t_c_p_client_0.resolve_future = Future()
    t_c_p_client_0.connect_future = Future()

# Generated at 2022-06-26 08:59:52.449296
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_0 = TCPClient()
    # _Connector(addrinfo, connect)
    _connector_1 = _Connector([], t_c_p_client_0.connect)
    _connector_1.clear_timeout()


# Generated at 2022-06-26 08:59:59.349803
# Unit test for method split of class _Connector
def test__Connector_split():
    # 1. Test case where all address families are the same
    s_p_addrinfo_0 = []
    s_p_addrinfo_0.append((socket.AF_INET, ('192.168.1.244', 11111)))
    s_p_addrinfo_0.append((socket.AF_INET, ('192.168.1.245', 11111)))
    s_p_addrinfo_0.append((socket.AF_INET, ('192.168.1.246', 11111)))
    s_p_addrinfo_0.append((socket.AF_INET, ('192.168.1.247', 11111)))
    s_p_addrinfo_0.append((socket.AF_INET, ('192.168.1.248', 11111)))

# Generated at 2022-06-26 09:00:01.577911
# Unit test for constructor of class _Connector
def test__Connector():
    _Connector([(2, 2)], None)



# Generated at 2022-06-26 09:00:08.730176
# Unit test for constructor of class _Connector
def test__Connector():
    test_addrinfo = [(2,('1.1.1.1',80))]
    t_c_0 = TCPClient()
    # The following two lines are not needed.
    # It is here to show that the __init__ of _Connector is properly called.
    t_c_0.io_loop  # type: IOLoop
    t_c_0.connect  # type: Callable[[socket.AddressFamily, Tuple], Tuple[IOStream, Future]]

    # Unit test for method _Connector.split
    # CAVEAT: This unit test only tests with one type, i.e., IPv4 family.
    #         It does not test for IPv6 family for now.
    test_addrinfo = [(2,('1.1.1.1',80))]

# Generated at 2022-06-26 09:00:13.146042
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.test_clear_timeout_connection._Connector.clear_timeout()


# Generated at 2022-06-26 09:00:26.524901
# Unit test for constructor of class _Connector
def test__Connector():
    addrinfo = [
        (1, 1),
        (1, 12),
        (1, 123),
        (1, 1234),
        (1, 12345),
        (2, 1),
        (2, 12),
        (2, 123),
        (2, 1234),
        (2, 12345),
    ]

    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return IOStream(socket.socket(af, socket.SOCK_STREAM, 0), io_loop=IOLoop.current()), Future()

    resolver = IOLoop.current()
    _Connector(addrinfo, connect).start()



# Generated at 2022-06-26 09:02:46.780372
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    addrs = [('127.0.0.1',80),('127.0.0.1',81)]
    def connect(address_family,addr):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
            s.connect(addr)
        except Exception as e:
            raise e
        return s,Future()

    connector = _Connector(addrs,connect)
    connector.set_timeout(_INITIAL_CONNECT_TIMEOUT)
    assert connector.timeout

    connector.set_timeout(1)
    assert connector.timeout
    time.sleep(1)
    assert not connector.timeout


# Generated at 2022-06-26 09:02:57.848541
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    addrinfo_0 = [
        (AF_INET6, ("::1", 80, 0, 0)),
        (AF_INET6, ("2001:db8::1", 80, 0, 0)),
        (AF_INET, ("127.0.0.1", 80)),
        (AF_INET, ("192.168.28.1", 80)),
    ]
    t_c_p_client_0.resolver = Resolver()
    connector_0 = _Connector(addrinfo_0, t_c_p_client_0.connect)
    stream_0 = IOStream()
    connector_0.streams.add(stream_0)
    assert not (stream_0.closed())
    connector_0.close_streams()

# Generated at 2022-06-26 09:03:02.346532
# Unit test for method split of class _Connector
def test__Connector_split():
    _Connector.split(
        [
            (socket.AF_INET, ("127.0.0.1", 8080)),
            (socket.AF_INET, ("127.0.0.2", 8080)),
            (socket.AF_INET6, ("127.0.0.3", 8080)),
        ]
    )



# Generated at 2022-06-26 09:03:07.161996
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    async def test():
        t_c_p_client = TCPClient()
        i_o_stream = await t_c_p_client.connect("www.google.com", 443)
        print(i_o_stream)

    IOLoop.current().run_sync(test)



# Generated at 2022-06-26 09:03:11.718526
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    f_on_connect_done_0 = Future()
    t_c_p_c_0 = _Connector([], None)
    try:
        t_c_p_c_0._Connector__on_connect_done(iter([]), 0, (), f_on_connect_done_0)
    except:
        pass


# Generated at 2022-06-26 09:03:18.306382
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # Create a TCPClient object for testing
    t_c_p_client_0 = TCPClient()

    # Create a connector object for testing
    connector_0 = _Connector(
        [],  # type: ignore
        t_c_p_client_0._do_connect,
    )
    # Assign wrong type to varible 'streams' of class _Connector
    connector_0.streams = 1

    # Call method 'close_streams' of class _Connector
    connector_0.close_streams()


# Generated at 2022-06-26 09:03:28.217398
# Unit test for method split of class _Connector
def test__Connector_split():
    addr_info = [(socket.AF_INET,('127.0.0.1',80)), (socket.AF_INET6,('127.0.0.1',81)), (socket.AF_INET,('127.0.0.1',82))]
    res = _Connector.split(addr_info)
    assert(list(res) == [(socket.AF_INET,('127.0.0.1',80)), (socket.AF_INET,('127.0.0.1',82)), (socket.AF_INET6,('127.0.0.1',81))])


# Generated at 2022-06-26 09:03:31.818249
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    future_0 = t_c_p_client_0.connect('localhost', 8080, socket.AF_INET)
    result_0 = future_0.result()
    # print(result_0)


# Generated at 2022-06-26 09:03:43.140280
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver(io_loop=IOLoop.current())
    t_c_p_client_0.resolver.resolve = lambda *args: gen.maybe_future(
        [
            (socket.AF_INET, ("127.0.0.1", 0)),
            (socket.AF_INET6, ("127.0.0.2", 1)),
            (socket.AF_INET, ("127.0.0.3", 2)),
            (socket.AF_INET6, ("127.0.0.4", 3)),
        ]
    )