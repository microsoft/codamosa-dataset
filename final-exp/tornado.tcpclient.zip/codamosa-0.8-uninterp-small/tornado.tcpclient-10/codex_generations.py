

# Generated at 2022-06-26 08:54:19.707492
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Create a set of tests of the form _Connector.on_connect_timeout(timeout)
    #   where timeout is one of None, 0, 1, -1, False, True, or an int in teh range (0,1)
    #   and the expected result is true or false
    test_cases = [
        [None, TimeoutError],
        [0, TimeoutError],
        [1, TimeoutError],
        [-1, TimeoutError],
        [False, TimeoutError],
        [True, TimeoutError],
        #[1/2, TimeoutError],
    ]
    # Iterate over the set of test cases
    for test_case in test_cases:
        # Store the inputs to the test case
        test_inputs = test_case[0]
        # Compute the expected result
        expected

# Generated at 2022-06-26 08:54:29.903410
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver()
    args_0: Union[
        Tuple[str, int], Tuple[str, int, bool]
    ] = ("testhost", 1234, False)
    t_c_p_client_0.bind_host = "testhost"
    t_c_p_client_0.bind_port = 1234
    t_c_p_client_0.try_connect_future = Future()
    t_c_p_client_0.io_loop = IOLoop()
    t_c_p_client_0.connect = TCPClient.connect_tcp
    t_c_p_client_0.af = None
    t_c_p_client_0.sock

# Generated at 2022-06-26 08:54:37.541428
# Unit test for method start of class _Connector

# Generated at 2022-06-26 08:54:49.851464
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # initialize _Connector.connect_timeout
    _connector = _Connector([(10, ('0.0.0.0', 80))], None)  # FIXME: connect() should be a mockup
    _connector.connect_timeout = 1
    _connector.future = Future()
    _connector.future.set_result(1)
    # the test condition is that the future is done
    assert (_connector.future.done())
    # trigger on_connect_timeout
    _connector.on_connect_timeout()
    # check that _Connector.connect_timeout is removed
    assert (_connector.connect_timeout is None)


# Generated at 2022-06-26 08:54:54.805945
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    addrinfo = [(1, 2), (1, 3), (2, 3)]
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return IOStream(socket.socket()), Future()
    _connector = _Connector(addrinfo, connect)
    _connector.set_connect_timeout(1.0)


# Generated at 2022-06-26 08:54:55.622271
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    pass



# Generated at 2022-06-26 08:55:06.277142
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    addrs_0 = [(inet_pton(AF_INET6, '2001:0db8:85a3:0000:0000:8a2e:0370:7334'), 8333), (AF_INET6, ('2001:0db8:85a3:0000:0000:8a2e:0370:7334', 8333)), (inet_pton(AF_INET, '10.0.0.2'), 8333), (AF_INET, ('10.0.0.2', 8333))]
    connect_0 = t_c_p_client_0.connect
    _connector_0 = _Connector(addrs_0, connect_0)
    timeout_0 = _INITIAL_CONNECT_TIMEOUT

# Generated at 2022-06-26 08:55:08.268147
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    pass


# Generated at 2022-06-26 08:55:17.298861
# Unit test for method split of class _Connector
def test__Connector_split():
    # Given:
    addrinfo = [
        (socket.AF_INET, ("1.2.3.4", 80)),
        (socket.AF_INET, ("1.2.3.5", 80)),
        (socket.AF_INET6, ("a:b:1::", 80)),
        (socket.AF_INET6, ("c:d:2::", 80)),
    ]
    # When:
    p, s = _Connector.split(addrinfo)
    # Then:
    assert(p == [
        (socket.AF_INET, ("1.2.3.4", 80)),
        (socket.AF_INET, ("1.2.3.5", 80)),
    ])

# Generated at 2022-06-26 08:55:26.536095
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Case 1:
    # Call the method with a timeout that has not been set yet.
    t_c_connector_0 = _Connector([], None)
    t_c_connector_0.clear_timeouts()
    # Test passes if the method did not raise any exceptions.
    # Case 2:
    # Call the method with a timeout that has already been set.
    t_c_connector_1 = _Connector([], None)
    t_c_connector_1.timeout = True
    t_c_connector_1.io_loop = 'io_loop_0'
    t_c_connector_1.clear_timeouts()
    # Test passes if the method did not raise any exceptions.


# Generated at 2022-06-26 08:55:49.389671
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_connector = _Connector([(socket.AF_INET, ("localhost", 8888))],
        functools.partial(t_c_p_client_0.connect, "localhost", 8888))
    t_c_connector.close_streams()


# Generated at 2022-06-26 08:55:59.037212
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    addrinfo = []
    connector_0 = _Connector(addrinfo, None)
    # Test case for exception
    try:
        connector_0.on_connect_timeout()
        assert False
    except TimeoutError:
        assert True
    # Success
    try:
        connector_0.future.set_exception(TimeoutError())
        connector_0.on_connect_timeout()
        assert True
    except TimeoutError:
        assert False
    # Success
    connector_1 = _Connector(addrinfo, None)
    try:
        connector_1.future.set_result((None, None, None))
        connector_1.on_connect_timeout()
        assert True
    except:
        assert False


# Generated at 2022-06-26 08:56:05.951451
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_1 = TCPClient()
    _connector_obj_1 = _Connector(
        [(socket.AF_INET, ('192.0.2.1', 80))],
        t_c_p_client_1._do_connect,
    )
    return _connector_obj_1.on_timeout()


# Generated at 2022-06-26 08:56:07.587030
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    pass


# Generated at 2022-06-26 08:56:19.218459
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Create object t_c_l_0 with type list
    t_c_l_0 = []
    # Create object t_c_p_addrinfo_0 with type list
    t_c_p_addrinfo_0 = []
    # Append addrinfo to t_c_p_addrinfo_0
    t_c_l_0.append(t_c_p_addrinfo_0)

    # Create object t_c_p_io_loop_0 with type IOLoop
    t_c_p_io_loop_0 = IOLoop.current()

    # Create object t_c_p_connect_0 with type function
    def t_c_p_connect_0():
        pass

    # Create object t_c_p_connector_0 with type _Connector
    t_c_p_

# Generated at 2022-06-26 08:56:26.728319
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():

    connector = _Connector([(1, 2)],  lambda x, y: None)
    # test a positive number for connect_timeout
    connector.set_connect_timeout(10)
    # test a negative number for connect_timeout
    try:
        connector.set_connect_timeout(-5) 
        assert False
    except AssertionError:
        pass


# Generated at 2022-06-26 08:56:34.159224
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    t_c_p_client_0 = TCPClient()
    addrs: Iterator[Tuple[socket.AddressFamily, Tuple]] = t_c_p_client_0.client_socket
    t_c_p_client_0.client_socket.send(addrs)


# Generated at 2022-06-26 08:56:42.368915
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()

    # Test that _Connector.close_streams() doesn't raise an exception
    # even when stream is None

    t_c_p_client_0._Connector.streams = [None]
    try:
        t_c_p_client_0._Connector.close_streams()
    except Exception:
        assert False, "Test #0: Exception unexpectedly raised"
    else:
        assert True

    # Tests for streams with and without stream.close() method

    t_c_p_client_0._Connector.streams = [
        "This is a string which doesn't have a .close() method",
        True,
        False,
        None,
        t_c_p_client_0._Connector,
    ]

# Generated at 2022-06-26 08:56:48.286730
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    test_addrinfo = [(socket.AddressFamily.AF_INET, ("localhost", 8080))]
    global conn
    conn = _Connector(test_addrinfo, try_connect)
    conn.try_connect(iter(test_addrinfo))


# Generated at 2022-06-26 08:56:58.624704
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    resolver = Resolver()
    #TCPClient = TCPClient(resolver = resolver)
    #ad = TCPClient.resolve_hostname('google.com', 80)
    t_c_p_client_0 = TCPClient()
    o_connector_0 = _Connector(
        ['google.com',
         80],
        t_c_p_client_0.tcp_connect
    )
    o_connector_0.clear_timeout()


# Generated at 2022-06-26 08:57:38.851479
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    conn = _Connector(None, None)
    t_c_p_client_0 = TCPClient()
    timeout = t_c_p_client_0._initial_connect_timeout
    t_c_p_client_0.resolver.resolve(None, None, None)
    conn.future.set_exception(TimeoutError())
    conn.close_streams()
    conn.set_connect_timeout(timeout)

if __name__ == '__main__':
    test_case_0()
    test__Connector_set_connect_timeout()

# Generated at 2022-06-26 08:57:47.105949
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    addrinfo = [(socket.AF_INET, ('192.168.1.1', 80)), (socket.AF_INET, ('192.168.1.2', 80))]
    
    class mock_connect(object):
        def __init__(self, af, addr):
            self.af = af
            self.addr = addr

        def __call__(self, af, addr):
            self.af = af
            self.addr = addr

        def result(self):
            return self

    class mock_IOLoop(object):
        def __init__(self):
            self.time = 0
            self.time_delta = 1

        def time(self):
            self.time += self.time_delta
            return self.time


# Generated at 2022-06-26 08:57:47.556586
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    assert True


# Generated at 2022-06-26 08:57:51.568986
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._connector_obj._Connector__clear_timeouts()


# Generated at 2022-06-26 08:57:53.020093
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    conn = _Connector([],[])
    conn.close_streams()


# Generated at 2022-06-26 08:57:58.213491
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    io_loop = IOLoop.current()
    io_loop.time_mock = 0
    future = Future()
    stream = IOStream(socket.socket(), io_loop = io_loop)
    connector = _Connector([], lambda af, addr: (stream, future))
    connector.future = future
    connector.on_connect_timeout()
    assert connector.future.result() is None
    assert future.done()
    assert not stream.closed_mock


# Generated at 2022-06-26 08:57:59.682726
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    pass



# Generated at 2022-06-26 08:58:08.853930
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    """
    This unit test is to check the functionality of on_timeout method
    """
    @gen.coroutine
    def test_async_1():
        # Test statement
        test_target_0 = _Connector(
            [],
            lambda s_0, s_1: (
                None,
                future_add_done_callback(s_0, s_0.set_exception(TimeoutError())),
            ),
        )
        test_target_0.start()

    # Test statement
    asyncio.get_event_loop().run_until_complete(test_async_1())

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 08:58:09.527092
# Unit test for method start of class _Connector
def test__Connector_start():
    test_case_0()


# Generated at 2022-06-26 08:58:12.780379
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client = TCPClient()
    _Connector.on_timeout(t_c_p_client.connector)


# Generated at 2022-06-26 08:59:23.161413
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    dummy_addrinfo = [
        (socket.AF_INET, ("1.1.1.1", 80)),
        (socket.AF_INET, ("1.1.1.2", 80)),
        (socket.AF_INET6, ("2.2.2.2", 80)),
    ]
    dummy_connect = lambda af, addr: (None, None)

    sut = _Connector(dummy_addrinfo, dummy_connect)
    sut.streams = set([None, None, None])

    sut.close_streams()
    return True


# Generated at 2022-06-26 08:59:33.067964
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_loc_0 = _Connector(
        [(socket.AF_INET, ("127.0.0.1", 443)), (socket.AF_INET6, ("127.0.0.1", 443))],
        t_c_p_client_0._connect,
    )
    # call set_timeout(t_c_p_loc_0)
    t_c_p_loc_0.set_timeout(0.3)


# Generated at 2022-06-26 08:59:38.013541
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    if (t_c_p_client_0 is not None):
        t_c_p_client_0.close()


# Generated at 2022-06-26 08:59:44.092137
# Unit test for method split of class _Connector
def test__Connector_split():
    # Dummy data
    addrinfo = [(socket.AF_INET, ("1.1.1.1", 80))]

    # Positive case
    p_c_o_0_0 = _Connector(addrinfo, None)
    p_c_o_0_0.split(addrinfo)
    # Negative case



# Generated at 2022-06-26 08:59:48.350124
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # from unit_test_common import test_unit_test_common_class_method
    # test_unit_test_common_class_method(
    #     globals(),                                                                                             # pylint: disable=unused-variable
    #     '_Connector',
    #     'close_streams',
    #     (
    #     )
    # )
    print("Executing test__Connector_close_streams")


# Generated at 2022-06-26 08:59:57.621452
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    af = socket.AF_INET
    addr_0 = ("localhost", 8080)
    addr_1 = ("localhost", 9090)
    address = (af, addr_0)
    address_1 = (af, addr_1)
    addr_info = [address, address_1]
    address_family_0 = socket.AddressFamily(0)
    socket_address_0 = ("localhost", 0)
    socket_address_1 = ("localhost", 0)
    socket_address_2 = ("localhost", 0)
    socket_address_3 = ("localhost", 0)
    io_stream_0 = IOStream(socket_address_0, socket_address_1)
    io_stream_1 = IOStream(socket_address_2, socket_address_3)
    future_0 = Future()
    future_0.set_

# Generated at 2022-06-26 09:00:02.900021
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    resolver = Resolver()

    obj_c_p = _Connector(resolver.resolve('7.7.7.7,8.8.8.8'), None)
    obj_c_p.on_connect_timeout()


# Generated at 2022-06-26 09:00:14.059847
# Unit test for method split of class _Connector
def test__Connector_split():
    # Test case 1
    addrinfo_test_1 = [(1, (1, '1')), (2, (2, '2')), (3, (3, '3'))]
    primary_addrs_test_1, secondary_addrs_test_1 = _Connector.split(addrinfo_test_1)
    if primary_addrs_test_1 == [(1, (1, '1')), (3, (3, '3'))] and secondary_addrs_test_1 == [(2, (2, '2'))]:
        return True
    else:
        return False



# Generated at 2022-06-26 09:00:27.207577
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    i_pv_4_address_0 = t_c_p_client_0.resolve_host("datasift.com")
    af_address_pair_0 = t_c_p_client_0.create_af_address_pair(i_pv_4_address_0)
    t_c_p_client_0.connector = _Connector(af_address_pair_0, t_c_p_client_0.effective_connect)
    t_c_p_client_0.connector.start()
    t_c_p_client_0.connector.close_streams()
    t_c_p_client_0.connector.on_connect_timeout()


# Generated at 2022-06-26 09:00:36.864328
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0_connector_0 = _Connector(t_c_p_client_0.addrinfo, t_c_p_client_0.connect)
    t_c_p_client_0_connector_0.set_connect_timeout(t_c_p_client_0.connect_timeout)
    t_c_p_client_0_connector_0.on_connect_timeout()


# Generated at 2022-06-26 09:02:53.312548
# Unit test for method start of class _Connector
def test__Connector_start():
    tc_start_p_connector_0 = _Connector()

    # Test case _Connector.start with parameter timeout=0.0
    tc_start_p_connector_0.start(timeout=0.0)


# Generated at 2022-06-26 09:02:55.110735
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    args = ()
    _Connector.clear_timeouts(args)
    pass


# Generated at 2022-06-26 09:02:59.666532
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_0 = _Connector(([], []), lambda x, y: (None, Future()))
    t_c_0.streams.add(None)
    t_c_0.close_streams()
    assert not t_c_0.streams
    assert t_c_0.remaining == 0


# Generated at 2022-06-26 09:03:06.152641
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()
    t_c_p_connector_0 = _Connector([(2, 'addr')], t_c_p_client_0.simple_connect)
    t_c_p_connector_0.try_connect(iter([(2, 'addr')]))
    t_c_p_connector_0.try_connect(iter([]))
    t_c_p_client_0.clear()
# End test

# Generated at 2022-06-26 09:03:08.405596
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector.set_timeout(0.0)


# Generated at 2022-06-26 09:03:18.713343
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()
    t_c_p_i_stream_0 = IOStream()

# Generated at 2022-06-26 09:03:30.327728
# Unit test for constructor of class _Connector
def test__Connector():
    t_c_p_c_client_0 = TCPClient()
    t_c_p_c_client_0.resolver = Resolver()
    t_c_p_c_client_0.resolver_options = {}
    _io_loop = t_c_p_c_client_0.io_loop
    af_0 = socket.AF_INET
    af_1 = socket.AF_INET6
    af_2 = socket.AF_INET
    af_3 = socket.AF_INET6
    addr_str_0 = "127.0.0.1"
    addr_str_1 = "127.0.0.2"
    addr_str_2 = "127.0.0.3"
    addr_str_3 = "127.0.0.4"
    addr

# Generated at 2022-06-26 09:03:33.471358
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    addrinfo_0 = [
        (None, None),
        (None, None)
    ]
    _c_0 = _Connector(addrinfo_0, None)
    _c_0.try_connect(1)


# Generated at 2022-06-26 09:03:37.443092
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    i = [1,2,3,4]
    i_iter = iter(i)
    c = _Connector(i, test)

# Generated at 2022-06-26 09:03:44.925007
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_c_client_0 = TCPClient()
    c = _Connector(["", "", "", "", ""], t_c_p_c_client_0.connect)
    c.timeout = IOLoop.current().add_callback(lambda: 42)
    c.connect_timeout = IOLoop.current().add_callback(lambda: 42)
    c.clear_timeouts()
    d = IOLoop.current().add_callback(lambda: 42)
    assert c.timeout != d
    assert c.connect_timeout != d
