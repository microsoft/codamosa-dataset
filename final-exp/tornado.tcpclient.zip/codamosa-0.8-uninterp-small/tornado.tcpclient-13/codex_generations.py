

# Generated at 2022-06-26 08:54:17.033306
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Step 0
    t_c_p_client_0 = TCPClient()
    # Step 1
    # Call _Connector.__init__
    addrinfo = list()
    # Step 2
    # Call _Connector.split
    # Step 3
    # Call _Connector.__init__
    connect = t_c_p_client_0._Connector.start
    t_c_p_client_0._Connector.__init__(addrinfo, connect)
    # Step 4
    # Call _Connector.start
    t_c_p_client_0._Connector.start()

    # Step 5
    # Call _Connector.set_timeout
    t_c_p_client_0._Connector.set_timeout()


# Generated at 2022-06-26 08:54:19.810452
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    _connector_0 = _Connector([""], t_c_p_client_0.connect)
    _connector_0.start()


# Generated at 2022-06-26 08:54:29.079829
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (1, '127.0.0.1'),
        (2, '127.0.0.2'),
        (1, '127.0.0.3'),
        (1, '127.0.0.4'),
        (3, '127.0.0.5')
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(1, '127.0.0.1'), (1, '127.0.0.3'), (1, '127.0.0.4')]
    assert secondary == [(2, '127.0.0.2'), (3, '127.0.0.5')]



# Generated at 2022-06-26 08:54:42.122722
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.connector = _Connector(
        [(10, ("127.0.0.1", 80))], t_c_p_client_0.connect
    )
    t_c_p_client_0.connector.io_loop = IOLoop.current()
    t_c_p_client_0.connector.timeout = t_c_p_client_0.connector.io_loop.add_timeout(
        t_c_p_client_0.connector.io_loop.time() + _INITIAL_CONNECT_TIMEOUT,
        t_c_p_client_0.connector.on_timeout,
    )
    t_c_p_client_0.connector.connect_timeout

# Generated at 2022-06-26 08:54:52.883758
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector = _Connector
    localhost_ip = Settings().get_localhost_ip()

    # Create input variable
    addrinfo = [(socket.AF_INET, (localhost_ip, 443)), (socket.AF_INET6, ("::1", 443))]
    t_c_p_client_0._Connector.__init__(addrinfo, t_c_p_client_0.connect)

    t_c_p_client_0.connect = t_c_p_client_0._Connector.connect
    t_c_p_client_0.stream = socket.socket()

    t_c_p_client_0.stream._set_nodelay()

# Generated at 2022-06-26 08:55:00.661116
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_0 = TCPClient()
    addrs = [(t_c_p_client_0.AF_INET, ("127.0.0.1", 8889))]
    connector = _Connector(addrs, ())
    try:
        connector.on_timeout()
    except Exception as e:
        log.error(e)


# Generated at 2022-06-26 08:55:08.269696
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
    _connector_0 = t_c_p_client_0.make_connector()
    print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
    _connector_0.close_streams()

# Generated at 2022-06-26 08:55:13.010412
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_1 = TCPClient()
    loop = IOLoop.current()
    loop.add_callback(functools.partial(t_c_p_client_1.connect, '127.0.0.1', 8888))
    loop.start()


# Generated at 2022-06-26 08:55:20.738046
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_1 = TCPClient(max_buffer_size=95, resolver=Resolver(), ssl_options={})
    t_c_p_client_2 = TCPClient(resolver=Resolver(), ssl_options={}, max_buffer_size=95)
    t_c_p_client_3 = TCPClient(ssl_options={}, max_buffer_size=95, resolver=Resolver())
    t_c_p_client_4 = TCPClient(ssl_options={}, resolver=Resolver(), max_buffer_size=95)
    t_c_p_client_5 = TCPClient(resolver=Resolver(), max_buffer_size=95, ssl_options={})

# Generated at 2022-06-26 08:55:27.984801
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    for i in [0, 4]:
        t_c_p_client_0 = TCPClient()
        t_c_p_client_0.connect("", 0)
    for i in [1]:
        t_c_p_client_0 = TCPClient()
        t_c_p_client_0.connect("", 0, ssl_options=None)
    for i in [2]:
        t_c_p_client_0 = TCPClient()
        t_c_p_client_0.connect("", 0, max_buffer_size=None)
    for i in [3]:
        t_c_p_client_0 = TCPClient()
        t_c_p_client_0.connect("", 0, ssl_options=None, source_ip=None)

# Generated at 2022-06-26 08:56:06.363145
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()
    _connector_0 = _Connector(t_c_p_client_0.io_loop)
    t_c_p_client_0.io_loop = _connector_0.io_loop
    t_c_p_client_0.start_connecting(t_c_p_client_0.io_loop)
    if not t_c_p_client_0.resolver.has_resolved:
        _connector_0.try_connect(t_c_p_client_0.resolver.resolve())


# Generated at 2022-06-26 08:56:18.716151
# Unit test for method split of class _Connector
def test__Connector_split():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver()
    t_c_p_client_0.resolver.configure(["8.8.8.8"], 2)
    loop_0 = IOLoop.current()
    connect_0 = functools.partial(t_c_p_client_0._tcp_start, loop_0)
    connector_0 = _Connector(t_c_p_client_0.resolver.addresses, connect_0)
    primary, secondary = connector_0.split(t_c_p_client_0.resolver.addresses)
    assert secondary[0][1] == t_c_p_client_0.resolver.addresses[1][1]


# Generated at 2022-06-26 08:56:26.639605
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_1 = TCPClient()
    # Test 1: no exception
    connector = _Connector(t_c_p_client_1.args[0], None)
    assert True
    # Test 2: no exception
    t_c_p_client_1.add()
    connector.on_connect_timeout()
    assert True


# Generated at 2022-06-26 08:56:37.864046
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Assert that on_timeout raises an exception if the future returned by the call to try_connect is already done
    # Assert that on_timeout does not raise an exception if the future returned by the call to try_connect is not done
    t_c_p_client_0 = TCPClient()
    connector_0 = _Connector([addresinfo_1], t_c_p_client_0.bind)
    connector_0.future.set_result(None)
    with pytest.raises(Exception):
        connector_0.on_timeout()


# Generated at 2022-06-26 08:56:51.303706
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    dummy_timeout = 0.8
    dummy_connect_timeout = 0.5
    dummy_addrs = [("AF_INET", ("127.0.0.1", 1234))] * 3
    dummy_connect = lambda af, addr: (IOStream(socket.socket()), Future())
    dummy_resolver = lambda host, port, *args, **kwargs: dummy_addrs
    with mock.patch("tornado.netutil.Resolver.resolve") as mock_resolve:
        mock_resolve.side_effect = dummy_resolver
        connector = _Connector(dummy_addrs, dummy_connect)
        f = connector.start(timeout = dummy_timeout, connect_timeout = dummy_connect_timeout)
        assert f == connector.future
        assert connector.timeout is not None
        assert connector.connect_timeout

# Generated at 2022-06-26 08:57:02.716115
# Unit test for constructor of class _Connector
def test__Connector():
    t_c_p_client_1 = TCPClient()

    # Unit test for constructor of connector with default arguments
    addrinfo = [(1, ("1", 80)), (1, ("2", 443))]
    connector0 = _Connector(addrinfo, t_c_p_client_1.connect)

    # Unit test for constructor of connector with setting arguments
    timeout = _INITIAL_CONNECT_TIMEOUT
    connect_timeout = _INITIAL_CONNECT_TIMEOUT
    connector1 = _Connector(addrinfo, t_c_p_client_1.connect)
    connector1.start(timeout, connect_timeout)

    # Unit test for split function
    res_primary, res_secondary = _Connector.split(addrinfo)
    primary_af = addrinfo[0][0]
    primary = []
    secondary = []


# Generated at 2022-06-26 08:57:10.040597
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    test_case_0() # Execute test_case_0 to setup environment
    # TCPClient().set_connect_timeout(None)   # _Connector.set_connect_timeout is private
    # TypeError: set_connect_timeout() argument 1 must be Union[float, datetime.timedelta], not NoneType


# Generated at 2022-06-26 08:57:16.303177
# Unit test for method split of class _Connector
def test__Connector_split():
    # Case which contains only AF_INET family address
    _Connector([(socket.AF_INET, ('0.0.0.0', 0))], connect=connect)
    # Case which contains only AF_INET6 family address
    _Connector([(socket.AF_INET6, ('0.0.0.0', 0))], connect=connect)
    # Case which contains both AF_INET and AF_INET6 family address
    _Connector([(socket.AF_INET6, ('0.0.0.0', 0)), (socket.AF_INET, ('0.0.0.0', 0))], connect=connect)
    # Case which contains neither AF_INET nor AF_INET6 family address

# Generated at 2022-06-26 08:57:27.820915
# Unit test for method split of class _Connector
def test__Connector_split():
    # Test case 0
    test_case_0 = [[6, ('127.0.0.1', 80)]]
    primary, secondary = _Connector.split(test_case_0)
    assert primary == test_case_0
    assert secondary == []
    # Test case 1
    test_case_1 = [[6, ('127.0.0.1', 80)], [6, ('127.0.0.2', 80)]]
    primary, secondary = _Connector.split(test_case_1)
    assert primary == test_case_1
    assert secondary == []
    # Test case 2
    test_case_2 = [[6, ('127.0.0.1', 80)], [4, ('1.1.1.1', 80)]]
    primary, secondary = _Connector.split(test_case_2)

# Generated at 2022-06-26 08:57:35.068092
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    af = socket.AF_INET
    addr = ('127.0.0.1', 80)
    connect = lambda af, addr: (IOStream(s), Future())
    addrinfo = [(af, addr)]
    c = _Connector(addrinfo, connect)
    c.future.set_result((af, addr, IOStream()))
    c.set_connect_timeout(0.05)
    c.on_connect_timeout()
    pass


# Generated at 2022-06-26 08:58:38.652004
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    host = "www.google.com"
    port = 443
    t_c_p_client_0 = TCPClient()
    loop = IOLoop()
    try:
        loop.run_sync(lambda: t_c_p_client_0.connect(host, port))
    except:
        pass


async def test():
    test_case_0()
    test_TCPClient_connect()

if __name__ == '__main__':
    loop = IOLoop()
    loop.run_sync(test)

# Generated at 2022-06-26 08:58:47.451707
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    test_addrinfo = [("AF_INET", "192.168.0.1")]
    connector = _Connector(
        test_addrinfo,
        connect=tcp_connect,
    )
    connector.future = Future()
    connector.future.done = False
    connector.on_connect_timeout()
    assert(connector.future.done == True)


# Generated at 2022-06-26 08:58:59.594427
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    addrinfo = [(1, (2, 3, 4, 5))]
    con_list = [1]
    af_list = [6]
    addr_list = [(7, 8, 9)]
    future_list = [10, 11]
    conn = _Connector(addrinfo, lambda x, y: (con_list[0], future_list[0]))
    conn.io_loop = 12
    conn.future = future_list[1]
    future_list[0].result = lambda: future_list[0]
    conn.on_connect_done(con_list[0], af_list[0], addr_list[0], future_list[0])


# Generated at 2022-06-26 08:59:04.435897
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    i_o_stream_0 = t_c_p_client_0.connect("0", 1)

# Generated at 2022-06-26 08:59:07.454004
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    if __name__ == "__main__":
        main()



# Generated at 2022-06-26 08:59:10.443712
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector.clear_timeouts()



# Generated at 2022-06-26 08:59:14.697470
# Unit test for method split of class _Connector
def test__Connector_split():
    _Connector._Connector.split([(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("127.0.0.1", 81))])
    _Connector._Connector.split([(socket.AF_INET6, ("127.0.0.1", 80)), (socket.AF_INET6, ("127.0.0.1", 81))])



# Generated at 2022-06-26 08:59:19.850564
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.max_buffer_size = 30
    try:
        t_c_p_client_0.connect(name='localhost', port=998, af=socket.AF_INET,)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 08:59:23.290435
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    # Call method connect of class TCPClient
    i_o_stream_0 = t_c_p_client_0.connect('127.0.01', 1)


# Generated at 2022-06-26 08:59:34.277960
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    addrinfo = [
        (socket.AF_INET, ("192.168.1.2", 3306)),
        (socket.AF_INET6, ("2001:10::1", 8080))
    ]
    c = _Connector(
        addrinfo,
        connect=lambda af, addr: (None, Future()),
    )
    # Test case 1
    c.try_connect(iter(c.primary_addrs))
    assert c.remaining == 1 and c.last_error == None
    # Test case 2
    c.try_connect(iter(c.secondary_addrs))
    assert c.remaining == 0 and c.last_error == None

