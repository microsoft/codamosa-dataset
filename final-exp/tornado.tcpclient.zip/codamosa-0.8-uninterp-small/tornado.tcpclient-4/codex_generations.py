

# Generated at 2022-06-26 08:54:17.669084
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    def test_clear_timeout(test_id, log_stack_trace, timeout, clear_timeout_return):
        try:
            a_connector = _Connector([(1, 2)], None)
            a_connector.timeout = timeout
            a_connector.connect_timeout = 1
            a_connector.clear_timeout()
            if clear_timeout_return != a_connector.timeout:
                raise Exception("Wrong return value!")
        except:
            if log_stack_trace:
                raise
            else:
                print("Exception in test case %d" % test_id)

    # Tuple containing test cases. Each test case is a tuple of parameter values
    test_cases = [
        (1, True, 1, None),

        (2, True, None, None),
    ]


# Generated at 2022-06-26 08:54:21.314517
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Initialization of objects and variables
    t_c_p_client_0 = TCPClient()

    # Use connector object to call set_timeout method
    _Connector.set_timeout(t_c_p_client_0, 3.4)


# Generated at 2022-06-26 08:54:30.922049
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()
    connector_0 = _Connector(t_c_p_client_0.resolve_future.result(), t_c_p_client_0._con, )
    # Unit test for method split of class _Connector
    t_c_p_client_0._con(socket.AF_INET, )
    t_c_p_client_0._con(socket.AF_INET6, )
    t_c_p_client_0._con(socket.AF_INET, )
    t_c_p_client_0._con(socket.AF_INET6, )
    t_c_p_client_0._con(socket.AF_INET6, )

# Generated at 2022-06-26 08:54:37.569376
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    s = socket.socket()
    s.connect(("www.yahoo.com",80))
    c = _Connector([(2,('www.yahoo.com', 80))], None)
    c.streams = [IOStream(s)]
    c.close_streams()


# Generated at 2022-06-26 08:54:39.133934
# Unit test for method start of class _Connector
def test__Connector_start():
    _Connector.start('self', 'timeout', 'connect_timeout')



# Generated at 2022-06-26 08:54:42.042055
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    _Connector.try_connect(0,0)
    print("TEST PASS")


# Generated at 2022-06-26 08:54:54.555163
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    inp_timeout = 0.3
    inp_sockaddr = ('www.google.com', 123)
    inp_af = socket.AF_INET

    t_c_p_client = TCPClient()

    t_c_p_client.start_connecting(inp_sockaddr, inp_timeout)

    t_c_p_client.connection_future.result()

    # Get the _Connector object for unit test
    t_c_p_client_connector_obj = t_c_p_client.connector

    t_c_p_client_connector_obj.on_connect_timeout()

    test_result = t_c_p_client_connector_obj.future.result()
    print("test_result: {}".format(test_result))


test__Connector_on

# Generated at 2022-06-26 08:55:06.087310
# Unit test for method split of class _Connector
def test__Connector_split():
    # Test 1
    addrinfo = [(socket.AF_INET, ("192.168.42.42", 8080))]
    primary, secondary = _Connector.split(addrinfo)
    assert secondary == []
    assert primary == addrinfo
    # Test 2
    addrinfo = [(socket.AF_INET6, ("::1", 8080))]
    primary, secondary = _Connector.split(addrinfo)
    assert secondary == []
    assert primary == addrinfo
    # Test 3
    addrinfo = [
        (socket.AF_INET, ("192.168.42.42", 8080)),
        (
            socket.AF_INET,
            ("192.168.42.42", 8080),
        ),
        (socket.AF_INET6, ("::1", 8080)),
    ]
    primary

# Generated at 2022-06-26 08:55:13.932992
# Unit test for method start of class _Connector
def test__Connector_start():
    def connect(
        af: socket.AddressFamily,
        addr: Tuple,
    ) -> Tuple[IOStream, "Future[IOStream]"]:
        return IOStream(), Future()

    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80))]

    t_c_p_client_1 = _Connector(addrinfo, connect)

    timeout = _INITIAL_CONNECT_TIMEOUT

    t_c_p_client_1.start(timeout)


# Generated at 2022-06-26 08:55:18.748654
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    output = ""
    for i in range(1, 10):
        output += "Hello, world!" + str(i) + "\n"
    assert _Connector(output).clear_timeout() == None



# Generated at 2022-06-26 08:55:50.469538
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    pass



# Generated at 2022-06-26 08:55:52.569197
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    test_case_0()

test__Connector_on_connect_timeout()


# Generated at 2022-06-26 08:55:56.972822
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    print("test__Connector_clear_timeouts")
    a = _Connector(addrinfo=[], connect=lambda foo, bar: (None,None))
    a.timeout = 1
    a.connect_timeout  = 2
    a.clear_timeouts()
    assert a.timeout == None
    assert a.connect_timeout == None


# Generated at 2022-06-26 08:56:02.757042
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    t_c_p_client_0 = TCPClient()
    af_0 = AddressFamily.AF_INET
    addr_0 = ("", 0)
    future_0 = Future()
    setattr(future_0, "_state", "done")
    def connect(af, addr):
        return IOStream(), future_0
    connector_0 = _Connector([(af_0, addr_0)], connect)
    connect_timeout_0 = None
    connector_0.start(connect_timeout=connect_timeout_0)
    timeout_0 = _INITIAL_CONNECT_TIMEOUT
    connector_0.set_timeout(timeout_0)
    assert connector_0.timeout is not None


# Generated at 2022-06-26 08:56:05.868119
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case 1:
    # Empty list
    test_case_1()
    # Test case 2:
    # Non-empty list
    test_case_2()


# Generated at 2022-06-26 08:56:08.092350
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    _Connector(list(), None).clear_timeout()
    pass


# Generated at 2022-06-26 08:56:15.461173
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_0 = TCPClient()
    address = ("127.0.0.1", 10800)
    on_connect = lambda: None
    stream = IOStream(socket.socket())
    # d = _Connector(stream, address, on_connect)
    # d.on_timeout()
    # print (d.timeout)


# Generated at 2022-06-26 08:56:26.939392
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # pass
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.try_connect(
        (
            (
                (1, (2, 3)),
                (4, (5, 6)),
                (7, (8, 9)),
                (10, (11, 12)),
            ),
            (
                (4, (5, 6)),
                (7, (8, 9)),
                (10, (11, 12)),
            ),
        )
    )


# Generated at 2022-06-26 08:56:40.425560
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    af = AddressFamily.AF_INET
    af1 = AddressFamily.AF_INET6
    af2 = AddressFamily.AF_UNSPEC
    af3 = AddressFamily.AF_UNIX
    af4 = AddressFamily.AF_FILE
    af5 = AddressFamily.AF_BLUETOOTH
    af6 = AddressFamily.AF_RDS
    test_addr = (af, ('127.0.0.1', 8820))
    test_addr1 = (af1, ('127.0.0.1', 8821))
    test_addr2 = (af2, ('127.0.0.1', 8822))
    test_addr3 = (af3, ('127.0.0.1', 8823))
    test_addr4 = (af4, ('127.0.0.1', 8824))


# Generated at 2022-06-26 08:56:44.395705
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector_set_timeout(0.3)


# Generated at 2022-06-26 08:57:22.411793
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # 1. Prepare the test data
    af = socket.AddressFamily()
    addr = tuple()
    stream = IOStream()
    future = Future()

    # 2. Call the method
    _Connector.on_connect_done(
        addrs=(af, addr), af=af, addr=addr, future=future
    )

    # 3. Check the result
    assert True


# Generated at 2022-06-26 08:57:26.074113
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_1 = TCPClient().start()
    t_c_p_client_1.clear_timeouts()


# Generated at 2022-06-26 08:57:28.873535
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    _connector = _Connector
    _connector.streams = set([t_c_p_client_0.connect(None, None)])
    _connector.close_streams()


# Generated at 2022-06-26 08:57:34.285147
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    print("Testing method close_streams of class _Connector:")
    t_c_p_client_0 = TCPClient()
    # Testing if method raises any exceptions when invoked
    # (Generic test case)
    t_c_p_client_0._Connector__close_streams()
    print("Passed all assertions!")



# Generated at 2022-06-26 08:57:45.790515
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    """
    'async def connect(self, host, port, af=<AddressFamily.AF_UNSPEC: 0>, ssl_options=None, max_buffer_size=None, source_ip=None, source_port=None, timeout=None) -> IOStream:'
    """
    # Valid values for arguments
    try:
        t_c_p_client_2 = TCPClient()
        t_c_p_client_2.connect(
            host=str(0.0),
            port=int(0.0),
            af=socket.AF_INET,
            ssl_options=None,
            max_buffer_size=int(0.0),
            source_ip=None,
            source_port=int(0.0),
            timeout=None
        )
    except Exception as e:
        print

# Generated at 2022-06-26 08:57:55.972522
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.connector = _Connector(
        [
            (
                10,
                (
                    "localhost",
                    "test__Connector_on_connect_timeout_0",
                ),
            ),
            (
                10,
                (
                    "localhost",
                    "test__Connector_on_connect_timeout_1",
                ),
            ),
        ],
        t_c_p_client_0.connect,
    )
    t_c_p_client_0.connector.future = Future()
    t_c_p_client_0.connector.on_connect_timeout()
    assert t_c_p_client_0.connector.future.result() == str(TimeoutError())


# Generated at 2022-06-26 08:57:58.316813
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()


# Generated at 2022-06-26 08:58:06.093963
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver()
    t_c_p_client_0.resolver.resolve = gen.coroutine(lambda *args: None)  # type: ignore
    connector = t_c_p_client_0._Connector(lambda *args: None, None, None)
    connector.clear_timeouts()


# Generated at 2022-06-26 08:58:17.457775
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    from tornado.gen import Return
    from tornado.netutil import Resolver

    resolver = Resolver()
    ret = resolver.resolve("www.google.com", 80)
    io_loop = IOLoop.current()
    io_loop.run_sync(lambda: ret)
    addrinfo = ret.result()
    c = _Connector(addrinfo, functools.partial(TCPClient._do_connect, t_c_p_client_0))
    future = Future()
    stream = IOStream(socket.socket(addrinfo[0][0], socket.SOCK_STREAM), io_loop)
    stream.connect(addrinfo[0][4])
    future.set_result(stream)
    addrs = iter(addrinfo)
    af, addr = next(addrs)
    c.on_connect

# Generated at 2022-06-26 08:58:30.373254
# Unit test for method split of class _Connector
def test__Connector_split():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver()
    t_c_p_client_0.resolver.force_ipv4 = False
    t_c_p_client_0.resolver.force_ipv6 = False
    t_c_p_client_0.resolver.family = socket.AF_INET
    t_c_p_client_0.resolver.hostnames = ['www.kdg.be']
    t_c_p_client_0.resolver.max_retry_delay = 30.0
    t_c_p_client_0.resolver.min_retry_delay = 1.0
    t_c_p_client_0.resolver.resolver_instance = None
   

# Generated at 2022-06-26 08:59:33.503987
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    _connector = _Connector([(0, ("0", 0))], lambda af, addr: (None, None))
    _connector.clear_timeout()


# Generated at 2022-06-26 08:59:41.337614
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    tcp_client = TCPClient()
    t_c_p_client_0 = _Connector(tcp_client.get_addr_info(None), lambda af, addr: af - addr)
    t_c_p_client_0.try_connect(t_c_p_client_0.primary_addrs)
    assert 1 == 1



# Generated at 2022-06-26 08:59:50.027737
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    try:
        t_c_p_client_0 = TCPClient()
        t_c_p_connector_0 = _Connector(
            list(),
            TCPClient.default_connect,
        )
    except Exception:
        print(Exception)
    t_c_p_connector_0.clear_timeouts()


# Generated at 2022-06-26 08:59:51.259313
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [1, 2, 3, 4]
    assert _Connector.split(addrinfo) == ([], [])



# Generated at 2022-06-26 08:59:56.567175
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    connector = _Connector(
        [(socket.AddressFamily.AF_INET, ("127.0.0.1", 8080))],
        functools.partial(test_connect),
    )

    connector.try_connect(iter(connector.primary_addrs))
    assert connector.last_error is None

    connector.try_connect(iter(connector.primary_addrs))
    assert isinstance(connector.last_error, IOError)



# Generated at 2022-06-26 09:00:07.386861
# Unit test for constructor of class _Connector
def test__Connector():
    t__Connector_p_resolver = Resolver()
    t__Connector_p_resolver.resolve("www.google.com", None, None, None)
    t__Connector_p_addrinfo = [
        (socket.AddressFamily.AF_INET, ("google.com", 80)),
        (socket.AddressFamily.AF_INET6, ("google.com", 80)),
    ]
    t__Connector_p_connect = ConnectionDelegate(None, None, None)
    try:
        t__Connector_p_connect.connect(
            socket.AddressFamily.AF_INET, ("google.com", 80)
        )
        t__Connector_p_connect.result()
        t__Connector_p_connect.exception()
    except Exception as e:
        pass

# Generated at 2022-06-26 09:00:10.089622
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    connector = _Connector([], None)
    connector.clear_timeout()
    assert connector.timeout is None



# Generated at 2022-06-26 09:00:19.841266
# Unit test for method split of class _Connector
def test__Connector_split():
    # Method split has 3 inputs: addrinfo
    # Case0:
    addrinfo_0 = [(0,((0,0),)),(1,((1,1),)),(0,((0,0),))]
    connect_0 = 0
    _Connector_0 = _Connector(addrinfo_0,connect_0)
    res_0 = _Connector_0.split(addrinfo_0)
    assert res_0[0] == [(0,((0,0),)),(0,((0,0),))], "output mismatch"
    assert res_0[1] == [(1,((1,1),))], "output mismatch"
    print("Execution Finished")

if __name__ == "__main__":
    test_case_0()
    test__Connector_split()

# Generated at 2022-06-26 09:00:24.571514
# Unit test for method split of class _Connector
def test__Connector_split():
    with pytest.raises(RuntimeError):
        addrinfo = [("a", 0)]
        c = _Connector(addrinfo, None)
        c.split(addrinfo)



# Generated at 2022-06-26 09:00:31.152479
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import inspect
    import unittest
    from unittest.mock import patch
    test_filename = inspect.getfile(inspect.currentframe())
    test_case_name = unittest.TestCase.id(test__Connector_clear_timeout)
    t_c_p_client_0 = TCPClient()
    connector_0 = _Connector(t_c_p_client_0.resolve_future.result(), t_c_p_client_0.connect_f)
    with patch('{}.IOLoop.remove_timeout'.format(test_filename), return_value=True) as mock_obj:
        connector_0.clear_timeout()
        assert mock_obj.call_count == 1, test_case_name


# Generated at 2022-06-26 09:02:59.164581
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_0 = TCPClient()
    connector_0 = _Connector(
        [
            (
                socket.AddressFamily.AF_INET,
                (
                    "842-650-958-102.area3.spa.estpak.ee",
                    (80, 80),
                    0,
                    0,
                ),
            )
        ],
        functools.partial(
            TCPClient.connect,
            host=None,
            port=None,
            af=None,
            ssl_options=None,
            max_buffer_size=None,
            resolver=None,
            family=None,
            flags=None,
            source_address=None,
            socket_options=None,
        ),
    )
    connector_0.timeout = object()
    # connector

# Generated at 2022-06-26 09:03:09.084649
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver()
    a_d_d_r_i_n_f_o_0 = t_c_p_client_0.resolver.resolve('www.google.com', 80)
    c_o_n_n_e_c_t_o_r_0 = _Connector(a_d_d_r_i_n_f_o_0, t_c_p_client_0._do_connect)
    c_o_n_n_e_c_t_o_r_0.start(1.0)
    c_o_n_n_e_c_t_o_r_0.clear_timeouts()


# Generated at 2022-06-26 09:03:16.633354
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    addrinfo = [(socket.AF_INET, ('1.1.1.1', 80))]
    connect_00_00 = lambda af, addr: (IOStream(socket.socket(af, socket.SOCK_STREAM)), True)
    c_00_00 = _Connector(addrinfo, connect_00_00)
    c_00_00.timeout = True
    c_00_00.connect_timeout = True
    c_00_00.clear_timeouts()
    assert c_00_00.timeout is None
    assert c_00_00.connect_timeout is None


# Generated at 2022-06-26 09:03:21.727492
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.client = _Connector(
        [(2, ('', 0))],
        lambda af, addr: (None, None)
    )
    t_c_p_client_0.client.on_connect_timeout()



# Generated at 2022-06-26 09:03:24.703776
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    host = "www.google.com"
    port = 443
    t_c_p_client = TCPClient()
    t_c_p_client._Connector.clear_timeout()


# Generated at 2022-06-26 09:03:36.425752
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80)), \
        (socket.AF_INET6, ("2001:cdba::3257:9652", 80))]
    def m_connect(af, addr):
        future = Future()
        future.set_exception(IOError())
        return None, future
    connector_0 = _Connector(addrinfo, m_connect)
    connector_0.timeout = True
    connector_0.future.set_result(1)
    connector_0.on_timeout()
    connector_0.timeout = True
    connector_0.future.set_exception(22)
    connector_0.on_timeout()
    connector_0.timeout = True
    connector_0.future.set_exception(IOError())

# Generated at 2022-06-26 09:03:45.900003
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_connector_0 = _Connector([], lambda af, addr, io_loop=IOLoop.current(),\
                                  max_buffer_size=None, resolver=None,\
                                  validate_cert=True, ca_certs=None,\
                                  client_key=None, ssl_options=None: TCPClient.connect(af, addr, io_loop, max_buffer_size,\
                                  resolver, validate_cert, ca_certs,\
                                  client_key, ssl_options))
    t_c_p_p_stream_0 = TCPClient.connect(socket.AF_INET, ("localhost", 80), IOLoop.current())
    t_c_p_connector_0.streams.add(t_c_p_p_stream_0)
   