

# Generated at 2022-06-26 08:54:15.779195
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Create instance of class _Connector
    connector_0 = _Connector()
    connector_0.on_connect_timeout()

    def test_case_1():
        t_c_p_client_0 = TCPClient()
        tuple_0 = ()



# Generated at 2022-06-26 08:54:17.750004
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    _connector = _Connector
    _connector.set_timeout(1)


# Generated at 2022-06-26 08:54:28.329732
# Unit test for method clear_timeout of class _Connector

# Generated at 2022-06-26 08:54:34.037607
# Unit test for constructor of class _Connector
def test__Connector():
    # Case 0: construction
    addrinfo_0 = []
    connect_0 = lambda *args: ()
    _Connector_0 = _Connector(addrinfo_0, connect_0)


# Generated at 2022-06-26 08:54:42.485416
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # construct with the following inputs
    ac = _Connector(
        tuple(
            [
                tuple([int(7), tuple([str("str_1"), int(6)])]),
                tuple([int(8), tuple([str("str_3"), int(3)])]),
                tuple([int(2), tuple([str("str_0"), int(7)])]),
            ]
        ),
        test_case_0,
    )

    # start with the following inputs
    ac.start(float(0.8), int(2))

    # do test
    ac.on_connect_timeout()


# Generated at 2022-06-26 08:54:46.117906
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    t_c_p_client_0 = TCPClient()
    _connector_0 = _Connector(tuple_0, t_c_p_client_0.connect)
    _connector_0.set_timeout(bool_0)


# Generated at 2022-06-26 08:54:56.356561
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():

    def get_on_connect_timeout_cb():
        def on_connect_timeout():
            pass
        return on_connect_timeout

    # Test 1 case
    def test__Connector_on_connect_timeout_1():

        # Initialization
        # Local variable
        connector_0 = _Connector(None, None)
        connector_0.on_connect_timeout = get_on_connect_timeout_cb()
        connector_0.connector_on_connect_timeout_1_0 = False
        connector_0.connector_on_connect_timeout_1_1 = False

        # Start of method
        if not connector_0.future.done():
            connector_0.future.set_exception(TimeoutError())
            connector_0.connector_on_connect_timeout_1_0 = True
        connector_0.close

# Generated at 2022-06-26 08:54:57.901305
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    assert True == True

# Generated at 2022-06-26 08:54:59.738601
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    tuple_0 = ()
    t_c_p_client_0._Connector(tuple_0, t_c_p_client_0._Connector.start)


# Generated at 2022-06-26 08:55:05.336780
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    t_con_0 = _Connector(addrinfo=[], connect=lambda *x: (None, None))
    t_con_0.set_timeout(timeout=0.0)


# Generated at 2022-06-26 08:55:27.453946
# Unit test for method split of class _Connector
def test__Connector_split():
    print('Running unit test for method split of class _Connector...')
    # Inputs that are tuples
    addrinfo_1 = [
        # tuple of 4 elements
        (1, 123, 123, 123),
        # tuple of 4 elements
        (2, 123, 123, 123),
        # tuple of 4 elements
        (1, 123, 123, 123),
        # tuple of 4 elements
        (2, 123, 123, 123),
        # tuple of 4 elements
        (1, 123, 123, 123),
    ]

# Generated at 2022-06-26 08:55:30.416146
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    print("Unit test for method close_streams of class _Connector")


# Generated at 2022-06-26 08:55:43.222955
# Unit test for method split of class _Connector
def test__Connector_split():
    # Test case: argument addrinfo is an empty list
    list_arg_0 = []
    tuple_expected_0 = ([], [])
    _Connector.split(list_arg_0)

    # Test case: argument addrinfo is a list containing the elements
    #            of type tuple(int, tuple(str, int))
    tuple_arg_1 = (1, ("localhost", 80))
    tuple_expected_1 = ((1, ("localhost", 80)), [])
    _Connector.split(list_arg_0 + [tuple_arg_1])

    # Test case: argument addrinfo is a list containing the elements
    #            of type tuple(int, tuple(str, int))
    tuple_arg_2 = (2, ("localhost", 8080))

# Generated at 2022-06-26 08:55:56.548083
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    # Test raising of exception "TimeoutError" for the following call of
    # method connect of class TCPClient
    t_c_p_client_1 = TCPClient()
    async def func():
        await t_c_p_client_1.connect(
            "abcdefghijklmnopqrstuvwxyz", 43, ssl_options=None, source_ip="abcdefghijklmnopqrstuvwxyz", source_port=43, timeout=0.0
            )
    try:
        loop = IOLoop.current()
        future = func()
        loop.run_sync(future)
    except TimeoutError as error:
        pass
    else:
        assert False


# Generated at 2022-06-26 08:56:03.284017
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()
    _connector_0 = t_c_p_client_0.connect(t_c_p_client_0.resolve_host('example.com'), 80)
    _connector_0.clear_timeouts()


# Generated at 2022-06-26 08:56:08.583622
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    resolver = Resolver()
    future = Future()
    future.set_result([("AF_INET6", ("::1", 80, 0, 0), 6, 0, 0)])
    _Connector(future, functools.partial(tcp_client.TCPClient.connect, t_c_p_client_0, None, """x_y_z""", 0, None, None))


# Generated at 2022-06-26 08:56:13.955071
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    connector_0 = _Connector()
    float_0 = float()
    int_0 = int()
    connector_0.set_connect_timeout(float_0)
    connector_0.set_connect_timeout(int_0)


# Generated at 2022-06-26 08:56:15.251707
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    test_case_0()


# Generated at 2022-06-26 08:56:24.144747
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    _Connector_0 = _Connector(
        [],
        lambda _0, _1: (
            IOStream(
                socket.socket(family = _0, type = _0, proto = _0),
                io_loop = IOLoop.current(),
            ),
            Future(),
        ),
    )
    _Connector_0.on_connect_timeout()


# Generated at 2022-06-26 08:56:30.686088
# Unit test for method split of class _Connector
def test__Connector_split():
    # unittest.TestCase.failureException = t_c_c__C_s_0__failureException
    t_c_c__C_s_0 = _Connector(
        [],
        functools.partial(
            TCPClient.connect,
            resolver=Resolver(),
            io_loop=IOLoop.current(),
            max_buffer_size=None,
            source_address=None,
        ),
    )
    t_c_c__C_s_0_out_0 = t_c_c__C_s_0.split(())
    pass



# Generated at 2022-06-26 08:57:05.872145
# Unit test for method start of class _Connector
def test__Connector_start():
    _a = ['sd']
    _a = ('sd', 'sdf')
    _a = ('sd', ('sdf', 'dfdf'))
    _a = ('sd', ('sdf', 'dfdf', 'df'))
    _a = ('sd', ('sdf', 'dfdf', 'df', 'd'))
    _a = ('sd', ('sdf', 'dfdf', 'df', 'd', 'f'))
    _a = ('sd', ('sdf', 'dfdf', 'df', 'd', 'f', 'dd'))
    _a = ('sd', ('sdf', 'dfdf', 'df', 'd', 'f', 'dd', 'ddf'))

# Generated at 2022-06-26 08:57:06.824614
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()
    tuple_0 = ()


# Generated at 2022-06-26 08:57:09.649585
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    # Init argument
    tuple_0 = ()
    _connector_0 = _Connector(tuple_0, None)
    _connector_0.on_connect_timeout()


# Generated at 2022-06-26 08:57:14.760344
# Unit test for constructor of class _Connector
def test__Connector():
    resolver_0 = Resolver()
    tuple_0 = resolver_0.resolve("localhost", 80)
    def connect(af, addr):
        io_stream_0 = IOStream()
        future_0 = Future()
        return io_stream_0, future_0

    _connector_0 = _Connector(tuple_0, connect)
    dict_0 = dict()
    dict_0["timeout"] = 0.3
    dict_1 = dict()
    dict_1["connect_timeout"] = 0.3
    tuple_1 = _connector_0.start(dict_0["timeout"], dict_1["connect_timeout"])
    dict_2 = dict()
    dict_2["timeout"] = 0.3
    _connector_0.set_timeout(dict_2["timeout"])
    _connect

# Generated at 2022-06-26 08:57:26.654731
# Unit test for method split of class _Connector

# Generated at 2022-06-26 08:57:38.478641
# Unit test for method clear_timeout of class _Connector

# Generated at 2022-06-26 08:57:43.481603
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_0 = TCPClient() #todo: mock this to provide the required params
    a_0 = _Connector(tcpclient_0_addrinfo, tcpclient_0_connect)
    test__Connector_set_timeout(a_0)
    a_0.clear_timeout()



# Generated at 2022-06-26 08:57:52.200536
# Unit test for constructor of class _Connector
def test__Connector():
    """
    This is a unit test for the constructor of class _Connector.
    """
    addrinfo_1 = [(2,2), (1,1)]
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return ()
    test_case_1 = _Connector(addrinfo_1, connect)


# Generated at 2022-06-26 08:57:58.785654
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    _c_onn_ctor = _Connector((), ())
    _c_onn_ctor.future = Future()
    _c_onn_ctor.on_connect_timeout()
    

# Generated at 2022-06-26 08:58:01.570727
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    test_case_0()

test__Connector_clear_timeout()


test_case_1()


# Generated at 2022-06-26 08:58:58.266124
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_0 = TCPClient()
    tuple_0 = ()
    _Connector(tuple_0, t_c_p_client_0.connect)


# Generated at 2022-06-26 08:58:59.924563
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()
    tuple_0 = ()


# Generated at 2022-06-26 08:59:06.127053
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    tuple_0 = ()
    tuple_1 = ()
    tuple_2 = ()
    tuple_3 = ()

    t_c_p_client_0 = TCPClient()
    t_c_p_client_1 = TCPClient()
    t_c_p_client_2 = TCPClient()
    t_c_p_client_3 = TCPClient()
    t_c_p_client_4 = TCPClient()
    t_c_p_client_5 = TCPClient()
    t_c_p_client_6 = TCPClient()
    t_c_p_client_7 = TCPClient()
    t_c_p_client_8 = TCPClient()
    t_c_p_client_9 = TCPClient()
    t_c_p_client_10 = TCPClient()
    t_c_p

# Generated at 2022-06-26 08:59:08.357256
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.connector.clear_timeouts()
    assert ((), None) == ((t_c_p_client_0.connector.timeout, t_c_p_client_0.connector.connect_timeout))


# Generated at 2022-06-26 08:59:13.677978
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    # Create an instance of class TCPClient
    t_c_p_client_0 = TCPClient()
    # Create an instance of class Future
    future_0 = Future()
    # Call method connect of t_c_p_client_0
    t_c_p_client_0.connect(None, None, None)
    # Call method result of future_0
    future_0.result()


# Generated at 2022-06-26 08:59:20.993620
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_2 = TCPClient()
    tuple_0 = ()

    # Conversion of attribute 'addrs' to 'Iterator' failed with error: set() is not subscriptable
    # t_c_p_client_2.connector.try_connect(t_c_p_client_2.connector.addrs)


# Generated at 2022-06-26 08:59:34.343577
# Unit test for constructor of class _Connector
def test__Connector():
    def test_case_0():
        # Test case with empty parameters
        tuple_0 = ()
        tuple_1 = ()
        obj_0 = _Connector(tuple_0, tuple_1)
        test_case_0()

    def test_case_1():
        # Test case with valid parameters
        tuple_0 = ()
        def func_0(arg_0, arg_1):
            return IOStream, Future
        obj_0 = _Connector(tuple_0, func_0)
        test_case_1()

    def test_case_2():
        # Test case with parameters containing incorrect data type
        tuple_0 = [] # tuple is expected
        def func_0(arg_0, arg_1):
            return IOStream, Future
        obj_0 = _Connector(tuple_0, func_0)

# Generated at 2022-06-26 08:59:46.269055
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():

    connect_timeout = 0.0

    t_c_p_client_1 = TCPClient()
    tuple_0 = ()
    tuple_1 = ()
    tuple_2 = ()
    tuple_3 = ()
    addrinfo_0: List[Tuple[socket.AddressFamily, Tuple]]  = [tuple_2, tuple_3]
    connect_0: Callable[[socket.AddressFamily, Tuple], Tuple[IOStream, "Future[IOStream]"]] = t_c_p_client_1.connect
    _connector_0 = _Connector(addrinfo_0, connect_0)
    _connector_0.set_connect_timeout(connect_timeout)
    _connector_0.on_connect_timeout()
    _connector_0.close_streams()


# Generated at 2022-06-26 08:59:53.918069
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    tuple_0 = ()
    tuple_1 = ()
    tuple_0 = ()
    tuple_1 = ()
    tuple_0 = ()
    tuple_1 = ()
    tuple_0 = ()
    tuple_1 = ()
    tuple_0 = ()
    tuple_1 = ()
    tuple_0 = ()
    tuple_1 = ()
    tuple_0 = ()
    tuple_1 = ()


# Generated at 2022-06-26 08:59:55.629259
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    _connector_0 = _Connector()
    _connector_0.close_streams()



# Generated at 2022-06-26 09:01:59.357506
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    x = _Connector(None, None)
    x.clear_timeouts()
    assert True, "Pass"


# Generated at 2022-06-26 09:02:07.832449
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    resolver = Resolver()
    addrinfo = resolver.resolve("www.google.com")
    stream = f_r_c_p_connect(addrinfo[0][0], addrinfo[0][4])
    future = Future()
    future.set_result(stream)
    conn = _Connector(addrinfo, functools.partial(f_r_c_p_connect, "www.google.com"))
    conn.timeout = True
    conn.future = Future()
    conn.future.set_result(future)
    conn.on_connect_done([], 0, 4, future)


# Generated at 2022-06-26 09:02:10.080449
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    target = _Connector()
    target.on_timeout()


# Generated at 2022-06-26 09:02:18.357928
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    t_c_p_client_0 = TCPClient()
    _c_0 = _Connector(
        addrinfo=None,
        connect=t_c_p_client_0._wrap_socket_and_connect,
    )
    try:
        _c_0.set_timeout(timeout=0.001)
    except:
        print("Unexpected error:", sys.exc_info()[0])
        assert False


# Generated at 2022-06-26 09:02:19.877875
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    test_case_0()


# Generated at 2022-06-26 09:02:26.988127
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    client = TCPClient()
    if sys.version_info.major <= 2:
        # Python 2 requires a byte string for the first argument
        client.connect('127.0.0.1', 8888)
    else:
        client.connect('127.0.0.1', 8888)
    client.set_nodelay(True)
    client.connect(('127.0.0.1', 8888))
    print("[***] This function is untested, please test it manually [***]")
    return


# Generated at 2022-06-26 09:02:37.303898
# Unit test for method start of class _Connector
def test__Connector_start():
    """Unit test for method start of class _Connector"""
    # test case 0
    t_c_p_conncet_0 = TCPClient()
    tuple_0 = ()
    t_c_p_conncet_0.start(tuple_0)
    # test case 1
    t_c_p_conncet_1 = TCPClient()
    tuple_1 = ()
    t_c_p_conncet_1.start(tuple_1)
    # test case 2
    t_c_p_conncet_2 = TCPClient()
    tuple_2 = ()
    t_c_p_conncet_2.start(tuple_2)


# Generated at 2022-06-26 09:02:43.875425
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    tuple_0 = ()
    _connector_0 = _Connector(tuple_0, t_c_p_client_0._stream_connect)
    _connector_0.on_connect_timeout()
    ##############################################################################
    tuple_0 = ()


# Generated at 2022-06-26 09:02:56.158130
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    tuple_0 = ()
    object_1 = object()
    object_2 = object()
    object_3 = object()
    object_4 = object()
    object_5 = object()
    object_6 = object()
    object_7 = object()
    object_8 = object()
    object_9 = object()
    object_10 = object()
    object_11 = object()
    object_12 = object()
    object_13 = object()
    object_14 = object()
    object_15 = object()
    object_16 = object()
    def function_0(arg0: object) -> None:
        return None
    def function_1(arg0: object, arg1: object) -> None:
        return None
    def function_2(arg0: object) -> None:
        return None

# Generated at 2022-06-26 09:03:01.061484
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Create IOLoop instance for testing
    ioloop_test_0 = IOLoop.current()
    # Create _Connector instance for testing
    connector_test_0 = _Connector([], None)
    # Call method to test
    connector_test_0.set_timeout(0.3)
    assert connector_test_0.timeout is not None
