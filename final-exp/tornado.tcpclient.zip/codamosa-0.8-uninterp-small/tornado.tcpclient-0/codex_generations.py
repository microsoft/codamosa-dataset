

# Generated at 2022-06-26 08:54:19.208544
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    #t_c_p_client_0 = TCPClient()
    connect = lambda af, addr: (IOStream(socket.socket(af, socket.SOCK_STREAM)), Future())
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET6, ("::1", 80))]
    timeout = 0.5
    connect_timeout = 0.5
    con = _Connector(addrinfo, connect)
    con.set_timeout(timeout)
    con.set_connect_timeout(connect_timeout)
    assert con.timeout is not None
    assert con.connect_timeout is not None
    con.on_connect_timeout()
    assert con.future.done()
    assert type(con.future.exception()) == TimeoutError


# Generated at 2022-06-26 08:54:25.598638
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # Create an instance of _Connector class
    # to invoke try_connect(iter) method
    t_c_p_client = TCPClient()
    addrinfo = t_c_p_client.host = "ipv6.google.com"
    connect = t_c_p_client.connect
    t_c_p_client.io_loop = IOLoop()
    t_c_p_client_1 = _Connector(addrinfo, connect)
    assert 1


# Generated at 2022-06-26 08:54:33.123988
# Unit test for method start of class _Connector
def test__Connector_start():
    # Client is connected with this
    t_c_p_client_0 = TCPClient()

    # The result of operation is stored here
    t_c_p_client_0._stream = t_c_p_client_0._create_stream(socket.socket())

    # Test case 0
    test__Connector_start_0 = _Connector(
        [], functools.partial(t_c_p_client_0._create_stream, socket.socket())
    )
    test__Connector_start_0.start()
    assert t_c_p_client_0._stream is test__Connector_start_0.future.result()[2]

    # Test case 1

# Generated at 2022-06-26 08:54:43.054911
# Unit test for constructor of class _Connector
def test__Connector():
    from tornado.tcpclient import _Connector
    from typing import List, Tuple
    import socket
    import unittest
    import random

    class _ConnectorTestCase(unittest.TestCase):
        def setUp(self):
            self.random = random.Random()

        def test_constructor(self):
            addrinfo = []  # type: List[Tuple[socket.AddressFamily, Tuple]]
            connect = None  # type: Callable[[socket.AddressFamily, Tuple], Tuple[Any, Any]]
            
            self.assertRaises(
                TypeError,
                _Connector,
                addrinfo,
                connect,
            )

    _ConnectorTestCase().test_constructor()



# Generated at 2022-06-26 08:54:51.967096
# Unit test for method start of class _Connector
def test__Connector_start():
    test_tcp = TCPClient()
    test_connector = Connector()
    test_addrinfo = [AF_INET, (1,2), AF_INET6, (3,4)]
    test_timeout = 0.3
    test_connect_timeout = None
    test_connect = test_tcp._options.get("connect_timeout", None)
    #test = _Connector(test_addrinfo, test_connect)
    future = future.start(test_timeout, test_connect_timeout)
    return future


# Generated at 2022-06-26 08:54:55.261760
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()
    assert t_c_p_client_0._connector.try_connect(iter(t_c_p_client_0.addrinfo)) is None


# Generated at 2022-06-26 08:54:58.556352
# Unit test for constructor of class _Connector
def test__Connector():
    con = _Connector([0,1],None)
    con.split([0,1])


# Generated at 2022-06-26 08:55:07.158664
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    _connector = _Connector(
        addrinfo=[(1, (1, 0))],
        connect=functools.partial(
            TCPClient()._on_connect,
            af=1,
            addr=(1, 0),
            callback=lambda: None,
            errback=lambda: None,
        ),
    )
    _connector.future = Future()
    _connector.streams.add(1)
    _connector.last_error = 1
    _connector.remaining = 1
    _connector.on_connect_done(
        addrs=[(1, (1, 0))],
        af=1,
        addr=(1, 0),
        future=Future(),
    )
    assert _connector.future.result() == (1, (1, 0), 1)
    assert not _

# Generated at 2022-06-26 08:55:16.997826
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    host_0 = 'host_0'
    port_0 = 50
    af_0 = socket.AF_INET6
    ssl_options_0 = SSLContext.TLSv1
    max_buffer_size_0 = 5
    source_ip_0 = 'source_ip_0'
    source_port_0 = 5
    timeout_0 = datetime.timedelta.total_seconds
    t_c_p_client_0 = TCPClient()
    stream_0 = t_c_p_client_0.connect(host_0, port_0, af_0, ssl_options_0, max_buffer_size_0, source_ip_0, source_port_0, timeout_0)
    assert stream_0 is not None
    assert stream_0._read_buffer_size == max_buffer_

# Generated at 2022-06-26 08:55:19.425021
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    _Connector.try_connect(t_c_c_0.addrs)


# Generated at 2022-06-26 08:55:50.469523
# Unit test for method start of class _Connector
def test__Connector_start():
    connect = lambda family, addr : (None, None)
    addr = [('', 0)]
    test_case_0 = _Connector(addr, connect)
    test_case_0.start()


_resolver = Resolver()



# Generated at 2022-06-26 08:55:57.457864
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # Initialization
    _Connector_0 = _Connector(
        addrinfo=[('AF_INET6', ('::1', 8080, 0, 0)), ('AF_INET', ('127.0.0.1', 8080))],
        connect=lambda af, addr: (IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()),
    )
    _Connector_0.timeout = 'timeout'

    # call the function
    _Connector_0.clear_timeout()

    # check if there is a timeout in the object

    assert _Connector_0.timeout is None


# Generated at 2022-06-26 08:56:09.352874
# Unit test for method split of class _Connector
def test__Connector_split():
    # case0: addrinfo is empty
    case0_addrinfo: List[Tuple] = []
    case0_expected_primary: List[Tuple[socket.AddressFamily, Tuple]] = []
    case0_expected_secondary: List[Tuple[socket.AddressFamily, Tuple]] = []

# Generated at 2022-06-26 08:56:18.458404
# Unit test for method start of class _Connector
def test__Connector_start():
    io_loop = IOLoop.current()
    socket1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    socket1 = IOStream(socket1)
    future1 = Future()
    future1.set_result(socket1)
    resolver = Resolver(io_loop=io_loop, resolver=None)
    tcp_connect = functools.partial(
        resolver.tcp_connect,
        socket.AF_INET,
        ("www.google.com", 80),
        _DEFAULT,
        "",
        True,
    )
    addrinfo = tcp_connect()
    # Connector object under test
    conn_0 = _Connector(addrinfo, tcp_connect)
    timeout = 0.3
    connect_timeout = 0.2
    future

# Generated at 2022-06-26 08:56:29.318875
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    addrinfo: List[Tuple] = [(socket.AF_INET, ('127.0.0.1', 8080))]
    def connect(af, addr):
        return None, None

    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver()
    t_c_p_client_0.resolver._resolve_future = None

    t_c_p_client_0._Connector = _Connector(addrinfo, connect)

    t_c_p_client_0._Connector.try_connect(iter(t_c_p_client_0._Connector.primary_addrs))


# Generated at 2022-06-26 08:56:34.559128
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    resolver = Resolver()
    stream = IOStream(socket.socket(), resolver)
    c = _Connector([(stream, Future())], lambda: (None, None))
    c.close_streams()



# Generated at 2022-06-26 08:56:39.491423
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 4321))]
    def connect(af, addr):
        return None, None
    connector = _Connector(addrinfo, connect)
    connector.set_timeout(1.0)

    # Unit test for method clear_timeout of class _Connector

# Generated at 2022-06-26 08:56:51.726913
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector_0 = _Connector(
        addrinfo = [(socket.AddressFamily.AF_INET, ('127.0.0.1', 8080))],
        connect = t_c_p_client_0.connect,
    )
    stream_0 = TStream(socket.socket(socket.AF_INET, socket.SOCK_STREAM))

# Generated at 2022-06-26 08:57:00.113649
# Unit test for constructor of class _Connector
def test__Connector():
    # Testing for all parameters are non-None
    # Testing for addrinfo is empty list
    # Testing for addrinfo has exactly 1 element
    # Testing for addrinfo has two elements with same address family
    # Testing for addrinfo has two elements with different address family
    # Testing for addrinfo has 3 elements with two elements with different address family
    # Testing for addrinfo has 3 elements with two elements with same address family
    # Testing for connect is None
    pass


# Generated at 2022-06-26 08:57:02.645287
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    connector = _Connector([(1, 2)], None)
    try:
        connector.close_streams()
    except Exception as e:
        assert False, "close_streams of class _Connector throws exception: " + str(e)


# Generated at 2022-06-26 08:57:44.118627
# Unit test for constructor of class _Connector
def test__Connector():
    # Test case with the first entry of addrinfo is the same with the family of the other entries
    addrinfo = [(socket.AF_INET, ("", "1111")), (socket.AF_INET, ("", "2222"))]
    test_connector = _Connector(addrinfo, test_connect)
    assert test_connector.connect == test_connect
    assert test_connector.remaining == 2
    assert test_connector.primary_addrs == addrinfo
    assert test_connector.secondary_addrs == []
    assert test_connector.streams == set()

    # Test case with the first entry of addrinfo is not the same with the family of the other entries
    addrinfo = [(socket.AF_INET, ("", "1111")), (socket.AF_INET, ("", "2222"))]
    test

# Generated at 2022-06-26 08:57:52.551924
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    test_case_0()
    t_c_p_client_0 = TCPClient()
    addrinfo_0 = [(10, ('some string',)), (10, ('some string',))]
    with raises(TypeError):
        t_c_p_client_0._Connector.close_streams(addrinfo_0)
    t_c_p_client_0.close()


# Generated at 2022-06-26 08:57:57.406974
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.connect("178.62.194.194", 80)


# Generated at 2022-06-26 08:58:08.916162
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    def t__Connector_try_connect_0(af, addr):
        return addr
    
    def t__Connector_try_connect_1(af, addr):
        raise Exception("exception in test_1")
    
    def t__Connector_try_connect_2(af, addr):
        raise Exception("exception in test_2")
    
    # test case 0: valid input, no exception
    addr_info = [('127.0.0.0',('127.0.0.1', 8888),0,0),('127.0.0.0',('127.0.0.2', 8888),0,0)]
    c = _Connector(addr_info, t__Connector_try_connect_0)
    c.try_connect(iter(c.primary_addrs))

# Generated at 2022-06-26 08:58:18.383895
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_1 = TCPClient()
    host = 'www.bing.com'
    port = 443
    af = 'socket.AddressFamily.AF_INET'
    ssl_options = 'ssl_options'
    max_buffer_size = 'max_buffer_size'
    source_ip = 'source_ip'
    source_port = 'source_port'
    timeout = 'timeout'
    i_o_stream_0 = t_c_p_client_1.connect(host, port, af, ssl_options, max_buffer_size, source_ip, source_port, timeout)
    # try-catch block for the case where the object is not of type Future
    # try:
    #     i_o_stream_0.result()
    # except Exception as e:
    #    

# Generated at 2022-06-26 08:58:28.381295
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_1 = TCPClient()
    # the following are methods of tornado.testing.AsyncTestCase in tornado.testing module
    # self.stop()
    # self.wait()
    # self.io_loop = tornado.testing.IOLoop()
    # self.io_loop.add_callback()
    # self.io_loop.make_current()
    # self.io_loop.run_sync()
    # self.io_loop.time()


# Generated at 2022-06-26 08:58:32.428355
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector__on_connect_done()


# Generated at 2022-06-26 08:58:42.275458
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver()
    t_c_p_client_0.resolver.resolve = _t_c_p_client_resolve1
    t_c_p_client_0.connect = _t_c_p_client_connect1
    t_c_p_client_0.stream.close = _t_c_p_client_close0
    t_c_p_client_0.stream.set_close_callback = _t_c_p_client_set_close_callback0
    t_c_p_client_0.stream.set_nodelay = _t_c_p_client_set_nodelay0
    t_c_p_client_0.stream

# Generated at 2022-06-26 08:58:51.421789
# Unit test for method start of class _Connector
def test__Connector_start():
    addrinfo = [
        (socket.AF_INET, ('139.199.100.229', 6379))
    ]
    def connect(af, addr):
        return t_c_p_client_0.connect(af, addr)
    t_c__connector_0 = _Connector(addrinfo, connect)
    t_c_p_client_0.start()
    t_c_p_client_0.io_loop.remove_timeout(t_c_p_client_0.connect_timeout)
    t_c_p_client_0.io_loop.remove_timeout(t_c_p_client_0.timeout)


# Generated at 2022-06-26 08:59:02.888158
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    t_c_p_client_0 = TCPClient()

    t_c_1 = _Connector(t_c_p_client_0.resolver.resolve("www.google.com:443"), t_c_p_client_0._wrap_connect)
    t_c_1.future = Future()
    t_c_1.future.set_result(True)

    t_c_1.on_connect_done(iter(t_c_1.primary_addrs), t_c_1.primary_addrs[0][0], t_c_1.primary_addrs[0][1], t_c_1.future)


# Generated at 2022-06-26 09:00:03.580006
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    addrinfo = [("a","b"),("c","d")]
    def connect(af, addr):
        from tornado.iostream import IOStream
        conn = IOStream()
        f = Future()
        f.set_result(conn)
        return conn, f
    conn = _Connector(addrinfo, connect)
    conn.clear_timeouts()



# Generated at 2022-06-26 09:00:13.391843
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_0 = TCPClient()
    # testcase 0
    _connector_0 = _Connector.__init__(t_c_p_client_0, t_c_p_client_0, t_c_p_client_0)
    t_c_p_client_0.timeout = None
    _Connector.clear_timeout(_connector_0)
    assert not t_c_p_client_0.io_loop.timeouts


# Generated at 2022-06-26 09:00:18.116003
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    print('*********Test case_1*********')
    print("Test _Connector.close_streams")
    test_case_0()
    print("Pass test 1")


# Generated at 2022-06-26 09:00:29.073989
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    # Initialize inputs for test_case_0
    addrs = [
        (
            socket.AddressFamily.AF_INET6,
            ("fe80::1",
             9999)
        ),
        (
            socket.AddressFamily.AF_INET6,
            ("fe80::2",
             9999)
        ),
        (
            socket.AddressFamily.AF_INET6,
            ("fe80::3",
             9999)
        ),
        (
            socket.AddressFamily.AF_INET6,
            ("fe80::4",
             9999)
        )
    ]
    af = socket.AddressFamily.AF_INET6
    addr = ("fe80::1",
            9999)
    future = null


# Generated at 2022-06-26 09:00:39.303705
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    from tornado.platform.asyncio import BaseAsyncIOLoop

    t_c_p_client_0 = TCPClient()
    io_loop_0 = IOLoop.current()
    io_loop = io_loop_0

    def connect(
        af: socket.AddressFamily,
        addr: Tuple,
    ) -> Tuple[IOStream, "Future[IOStream]"]:
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
        future = stream.connect(addr)
        return stream, future

    addrinfo_0 = [(socket.AddressFamily.AF_INET, ("127.0.0.1", 8880))]

    _connector_0 = _Connector(addrinfo_0, connect)

    future_0 = _connector_0.start()


# Generated at 2022-06-26 09:00:47.617831
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    """Test if on_timeout is executed after given time"""
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.connect("www.google.com", 80)
    #assert t_c_p_client_0._Connector().set_timeout(5) is not None, "Timeout is not executed"



# Generated at 2022-06-26 09:00:58.636062
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    t_s_c_connector_0 = _Connector([(1, (1,"1"))], t_c_p_client_0.get_connection)
    t_s_c_connector_0.set_connect_timeout(0.3)
    t_s_c_connector_0.set_connect_timeout(datetime.timedelta)
    t_s_c_connector_0.set_connect_timeout(datetime.timedelta)
    return 


# Generated at 2022-06-26 09:01:11.883820
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    t_c_p_client_1 = TCPClient()
    print()
    _connector_1 = _Connector(t_c_p_client_1.resolver.resolve(t_c_p_client_1.host, t_c_p_client_1.port), t_c_p_client_1.connect)
    _connector_1.on_connect_done(iter(_connector_1.primary_addrs), _connector_1.primary_addrs[0][0], _connector_1.primary_addrs[0][1], Future())
    _connector_1.on_connect_done(iter(_connector_1.secondary_addrs), _connector_1.secondary_addrs[0][0], _connector_1.secondary_addrs[0][1], Future())



# Generated at 2022-06-26 09:01:17.589536
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    resolver_0 = Resolver()
    test__Connector_start_0 = _Connector.start(t_c_p_client_0, resolver_0)



# Generated at 2022-06-26 09:01:27.769010
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    stream_type = type(gen.moment)
    stream = mock.Mock(stream_type)
    future = mock.Mock(Future)
    addr = ("af", "addr")
    future_0 = mock.Mock(Future)
    future_0.result.return_value = stream
    future.return_value = (stream, future_0)
    addrinfo: List[Tuple] = [(1, addr), (2, addr)]
    connect = mock.Mock()
    connect.return_value = future
    c_0 = _Connector(addrinfo, connect)
    test_addr = ((1, addr), (2, addr))
    test_addr = iter(test_addr)
    c_0.try_connect(test_addr)
    c_0.try_connect(test_addr)


#

# Generated at 2022-06-26 09:03:41.330224
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.max_buffer_size = None
    t_c_p_client_0.max_buffer_size = None
    t_c_p_client_0.max_buffer_size = None
    t_c_p_client_0.max_buffer_size = None
    # Connector.__init__()
    addrinfo = [(10, ('127.0.0.1', 9999))]
    # Connector.connect()
    future = Future()
    future.set_result(IOStream(socket.socket(10, socket.SOCK_STREAM)))
    result = (future, future)
    connect = lambda af, addr: result
    #Connector.__init__()