

# Generated at 2022-06-26 08:54:29.119924
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # t_c_o_ct_client_0 = TCPClient()
    # t_c_o_ct_client_0.ioloop = IOLoop.current()
    # t_c_o_ct_client_0.timeout = None

    address = ("localhost", 8080)

    resolver = Resolver()
    future = resolver.resolve(address[0], family=socket.AF_INET)
    addrs = future.result() # <class 'list'>: [(2, 1, 6, '', ('127.0.0.1', 8080))]

    t_c_o_ct_connector_0 = _Connector(addrs, t_c_o_ct_client_0._wrap_connect)
    
    t_c_o_ct_connector_0.set_timeout(5)


# Generated at 2022-06-26 08:54:42.123073
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    connect_future = Future()

    class Dummy_IOStream:
        def close(self) -> None:
            pass

    class Dummy_IOLoop:
        def __init__(self) -> None:
            self.clear_timeouts_event = Future()

        def add_timeout(
            self,
            deadline: Union[float, datetime.timedelta],
            callback: Callable[[], None],
            *args: object,
        ) -> object:
            # We add callbacks for timeout and connect_timeout,
            # so we return different objects
            if callback == connect_timeout_callback:
                return 1
            else:
                return 2

        def remove_timeout(self, timeout: object) -> None:
            self.clear_timeouts_event.set_result(1)


# Generated at 2022-06-26 08:54:45.016146
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    try:
        assert _Connector.on_timeout([0, "AF_INET"]) == None
    except Exception:
        return False
    return True


# Generated at 2022-06-26 08:54:55.299219
# Unit test for method split of class _Connector
def test__Connector_split():
    connector = _Connector()
    print(connector)
    c_split = connector.split
    print(c_split)

    print(c_split)
    # Test 1 input: valid list
    test_list_1 = [(2, 3), (3, 2)]
    print(test1)
    print(c_split(test_list_1))
    # Test 2 input: valid list
    test_list_2 = [(2, 3), (2, 3)]
    print(test2)
    print(c_split(test_list_2))
    # Test 3 input: invalid list
    test_list_3 = [2, 3]
    print(test3)
    print(c_split(test_list_3))


# Generated at 2022-06-26 08:55:04.199889
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_0 = TCPClient()
    
    t_c_p_client_0.resolver = lambda x : x
    t_c_p_client_0.size = 3
    t_c_p_client_0.io_loop = IOLoop.current()
    t_c_p_client_0.max_buffer_size = None
    t_c_p_client_0.max_buffer_size = 5
    t_c_p_client_0.socket = None
    t_c_p_client_0.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    t_c_p_client_0.socket.connect(("localhost", 2346))
    t_c_p_client_0.source_ip = None
   

# Generated at 2022-06-26 08:55:11.859522
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test case 0:
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector.set_timeout()
    # Test case 1:
    t_c_p_client_1 = TCPClient()
    t_c_p_client_1._Connector.set_timeout(timeout = 0.3)


# Generated at 2022-06-26 08:55:21.075078
# Unit test for method start of class _Connector
def test__Connector_start():
    test_addrinfo = list([(1, (1, 2, 3, 4)), (2, (4, 3, 2, 1))])
    test_timeout = 1
    test_connect_timeout = 1
    c = _Connector(test_addrinfo, test_case_0)
    result = c.start(test_timeout, test_connect_timeout)
    assert result == None


# Generated at 2022-06-26 08:55:23.906560
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    _connect = _Connector.try_connect
    # Test case
    addrs = [("8.8.8.8", 53),("76.3.4.2", 80)]
    _connect(addrs)



# Generated at 2022-06-26 08:55:36.898256
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import sys
    from tornado.platform.asyncio import AsyncIOMainLoop
    asyncio_loop = asyncio.get_event_loop()
    AsyncIOMainLoop().install()
    t_c_p_client_0 = TCPClient()
    aiohttp_client_0 = AIOHTTPClient()
    current_ioloop = IOLoop.current()
    connector_0 = _Connector(
        t_c_p_client_0._parse_host(
            host='tornadoweb.org',
            port=80,
            ssl=False,
            proxy_host=None,
            proxy_port=None,
            proxy_username=None,
            proxy_password=None,
        ),
        t_c_p_client_0._get_connect_stream,
    )
    connector_0

# Generated at 2022-06-26 08:55:39.612477
# Unit test for method split of class _Connector
def test__Connector_split():
    connector_0 = _Connector(None)
    _Connector.split(connector_0, None)


# Generated at 2022-06-26 08:56:03.206031
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    connector = _Connector([(4, ("127.0.0.1",4000))],tcp_connect)
    connector.close_streams()


# Generated at 2022-06-26 08:56:10.399271
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    addrinfo = [
        (socket.AF_INET6, ('localhost', 80)),
        (socket.AF_INET6, ('localhost', 80)),
        (socket.AF_INET6, ('localhost', 80)),
        (socket.AF_INET6, ('localhost', 80)),
        (socket.AF_INET, ('localhost', 80)),
        (socket.AF_INET, ('localhost', 80)),
    ]
    def f(af, addr):
        return None
    _connector = _Connector(addrinfo, f)
    _connector.set_connect_timeout(_INITIAL_CONNECT_TIMEOUT)



# Generated at 2022-06-26 08:56:19.606299
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    io_loop = IOLoop.current()
    f = Future() # type: Future[IOStream]
    af, addr = 0, 1
    def connect(af, addr):
        return 1, f
    connector = _Connector([(af, addr)], connect)
    connector.future = Future() # type: Future[Tuple[socket.AddressFamily, Any, IOStream]]
    def on_connect_done(addrs, af, addr, future):
        pass
    connector.on_connect_done = on_connect_done
    f.set_result(1)
    connector.try_connect([(af, addr)])
    assert connector.future.result() == (af, addr, 1)


# Generated at 2022-06-26 08:56:22.382944
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0_connector = _Connector([], lambda x,y: [])
    print("Unit test for method on_timeout of class _Connector")
    t_c_p_client_0_connector.on_timeout()


# Generated at 2022-06-26 08:56:24.578580
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    the_connector = _Connector([(socket.AF_INET, ("127.0.0.1", 4444))], \
        lambda x, y: (IOStream('', False), Future()))
    the_connector.try_connect([(socket.AF_INET, ("127.0.0.1", 4444))])


# Generated at 2022-06-26 08:56:31.964692
# Unit test for method split of class _Connector

# Generated at 2022-06-26 08:56:41.896479
# Unit test for constructor of class _Connector
def test__Connector():
    t_c_p_client_1 = TCPClient()
    test_case_1_addrinfo = Resolver().resolve('localhost')
    test_case_1_connect = functools.partial(t_c_p_client_1._connect, False)
    _Connector(test_case_1_addrinfo, test_case_1_connect)
    test_case_2_addrinfo = Resolver().resolve('localhost', socket.AF_INET)
    test_case_2_connect = functools.partial(t_c_p_client_1._connect, False)
    _Connector(test_case_2_addrinfo, test_case_2_connect)
    test_case_3_addrinfo = Resolver().resolve('localhost', socket.AF_INET6)
    test_case_3_connect

# Generated at 2022-06-26 08:56:52.659070
# Unit test for method split of class _Connector
def test__Connector_split():
    # Test case # 0
    addrinfo = [(10, ("127.0.0.1", 65432)), (20, ("127.0.0.2", 65432))]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(10, ("127.0.0.1", 65432))], "Error on test case # 0"
    assert secondary == [(20, ("127.0.0.2", 65432))], "Error on test case # 0"

    # Test case # 1
    addrinfo =  [(20, ("127.0.0.1", 65432)), (10, ("127.0.0.2", 65432))]
    primary, secondary = _Connector.split(addrinfo)

# Generated at 2022-06-26 08:57:01.087098
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():

    class TC0(object):
        """docstring for TC0"""

        def __init__(self, time_: float) -> None:
            self.time = time_
            self.timeouts = set()  # type: Set[object]

        def time(self) -> float:
            return self.time

        def add_timeout(self, timeout: float, callback: Callable[[], None]) -> object:
            self.timeouts.add(callback)
            return callback

        def remove_timeout(self, time_: float) -> None:
            self.timeouts.remove(time_)

    _io_loop = TC0(0.1)

# Generated at 2022-06-26 08:57:12.564659
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    """
    In this test, future.result() is good,
    """
    future = Future()
    future.set_result(0)
    addrs = [] # type: List[Tuple]
    af = socket.AF_INET
    addr = (1, 2) # type: Tuple
    cg = _Connector(addrs, lambda x, y: (None, future))
    cg.streams = []
    cg.remaining = 0
    cg.on_connect_done(addrs, af, addr, future)
    # This test is incomplete


# Generated at 2022-06-26 08:57:44.403437
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_1 = TCPClient()
    # TODO: Replace these assertions with your own tests.
    #assert('t_c_p_client_1' == 't_c_p_client_1')
    #assert('t_c_p_client_1' == 't_c_p_client_1')
    #assert('t_c_p_client_1' == 't_c_p_client_1')
    #assert('t_c_p_client_1' == 't_c_p_client_1')
    #assert('t_c_p_client_1' == 't_c_p_client_1')


# Generated at 2022-06-26 08:57:50.116361
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    f = Future()
    c = _Connector([], lambda af, addr: (None, f))
    c.future = f
    c.on_connect_timeout()
    assert f.exception() is TimeoutError()


# Generated at 2022-06-26 08:57:56.968753
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    #first, we create a _Connector object
    t_c_p_client_0 = TCPClient()
    test_0 = _Connector(
        addrinfo=[],
        connect=t_c_p_client_0._wrap_ssl,
    )
    test_0.io_loop = IOLoop.current()
    test_0.connect = t_c_p_client_0._wrap_ssl
    test_0.future = (Future())
    test_0.timeout = None
    test_0.connect_timeout = None
    test_0.last_error = None
    test_0.remaining = 0
    #test_0.primary_addrs = []
    #test_0.secondary_addrs = []
    test_0.streams = set()
    test_0.clear_timeout()
#

# Generated at 2022-06-26 08:57:57.869404
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    pass



# Generated at 2022-06-26 08:58:03.191607
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    connector = _Connector(["test addrinfo"], "test connect")
    if connector is not None:
        connector.try_connect(["test addrs"])
    else:
        assert False


# Generated at 2022-06-26 08:58:07.402150
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    _io_loop = IOLoop.current()
    _future = Future()
    _future.set_result(None)
    _connect_timeout = _io_loop.add_timeout(_future, _Connector.on_connect_timeout)
    if not _future.done():
        _future.set_exception(TimeoutError())


# Generated at 2022-06-26 08:58:16.217136
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    # Verify this function with two different parameter types:
    # 1) With timedelta type
    t_c_p_client_1 = TCPClient()
    time_delta_0: datetime.timedelta = datetime.timedelta(seconds=5)
    t_c_p_client_1._Connector.set_connect_timeout(time_delta_0)

    # 2) With float type
    t_c_p_client_2 = TCPClient()
    t_c_p_client_2._Connector.set_connect_timeout(5.0)

    # Verify this function with two different parameter types:
    # 1) With timedelta type
    t_c_p_client_3 = TCPClient()
    t_c_p_client_3._Connector.set_connect_timeout(time_delta_0)

# Generated at 2022-06-26 08:58:25.913391
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    addrs = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 8080)),
    ]
    client = TCPClient()
    connect = functools.partial(client._try_connect,ioloop = client.io_loop)    
    connector = _Connector(addrs, connect)
    connector.on_timeout()


# Generated at 2022-06-26 08:58:26.696111
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    test_case_0()


# Generated at 2022-06-26 08:58:29.196573
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    connector_0 = _Connector(None, t_c_p_client_0._connect)
    connector_0.on_connect_timeout()


# Generated at 2022-06-26 08:58:53.755729
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    #tcp_client_test = TCPClient()
    #connector_test = _Connector(tcp_client_test)
    assert 1 == 1

# Generated at 2022-06-26 08:58:54.982594
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    connect = lambda af, addr: (None, Future())
    _Connector([(1, (2, 3))], connect)


# Generated at 2022-06-26 08:59:00.729911
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_1 = TCPClient()
    t_c_p_client_1.test_bool = False
    t_c_p_client_1.future.set_result = set_result
    t_c_p_client_1.on_timeout()
    return t_c_p_client_1.test_bool


# Generated at 2022-06-26 08:59:12.343845
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    t_c_p_set_t_0 = TCPClient()
    t_c_p_con_set_t_0 = _Connector(t_c_p_set_t_0.resolver.resolve('google.com'), t_c_p_set_t_0.connect)
    t_c_p_set_t_0.connector = t_c_p_con_set_t_0
    t_c_p_con_set_t_0.set_timeout(1 * 60 * 60 * 60 * 60 * 60 * 60 * 60 * 60)


# Generated at 2022-06-26 08:59:25.836943
# Unit test for method split of class _Connector

# Generated at 2022-06-26 08:59:30.135347
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    test_case_0()

if __name__ == "__main__":
    test__Connector_set_connect_timeout()
    test_case_0()



# Generated at 2022-06-26 08:59:35.856096
# Unit test for method start of class _Connector
def test__Connector_start():
    def connect(a: socket.AddressFamily, b: Tuple):
        if a == b:
            return None, None
        else:
            return 0, 0
    
    t_c_p_client_0 = TCPClient()
    _Connector.split([(0, 0), (1, 1)], connect)
    t_c_p_client_0._Connector__init__([(0, 0), (1, 1)], connect)
    t_c_p_client_0._Connector_start()


# Generated at 2022-06-26 08:59:46.661733
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.concurrent import Future

    class TestFuture(Future):
        def __init__(self):
            super(TestFuture, self).__init__()

        def set_result(self, result):
            self._result = result

    class TestTcpClient(TCPClient):
        def __init__(self, resolver):
            super(TestTcpClient, self).__init__(resolver=resolver)
            self._create_stream_calls_count = 0
            self._create_stream_results = []

        def _create_stream(self, max_buffer_size, af, addr, source_ip=None, source_port=None):
            self._create_stream_calls_count += 1

# Generated at 2022-06-26 08:59:54.719305
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()

    t_c_p_client_0.resolver = (
        Resolver(io_loop=IOLoop.current())
    )  # type: Resolver
    t_c_p_client_0.io_loop = IOLoop.current()
    t_c_p_client_0.ssl_options = None  # type: Optional[Union[Dict[str, Any], bool]]
    t_c_p_client_0.max_buffer_size = None  # type: Optional[int]
    t_c_p_client_0.read_chunk_size = 65536  # type: int
    t_c_p_client_0.connect_timeout = _INITIAL_CONNECT_TIMEOUT  # type: float
    # Arguments

# Generated at 2022-06-26 09:00:06.432367
# Unit test for constructor of class _Connector
def test__Connector():
    connect = lambda af, addr: (None, None)
    addrs = [("test_0" , "test_1"),("test_2", "test_3")]
    test_case_0 = _Connector(addrs, connect)
    assert test_case_0.future.done() == False
    test_case_0.last_error = 0
    assert test_case_0.last_error == 0
    test_case_0.remaining = 2
    assert test_case_0.remaining == 2
    assert test_case_0.primary_addrs == [("test_0" , "test_1")]
    assert test_case_0.secondary_addrs == [("test_2", "test_3")]

    # Test start of class _Connector
    test_case_0.future = 1
   

# Generated at 2022-06-26 09:01:00.495591
# Unit test for constructor of class _Connector
def test__Connector():
    addrs = [
        (socket.AF_INET, ("127.0.0.1", 1)),
        (socket.AF_INET6, ("::1", 1)),
        (socket.AF_INET, ("localhost", 1)),
        (socket.AF_INET6, ("localhost", 1)),
    ]
    def connect(af, addr):
        return IOStream(socket.socket(af)), Future()
    c = _Connector(addrs, connect)
    c.start()



# Generated at 2022-06-26 09:01:05.326777
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._connector = _Connector(list())
    t_c_p_client_0._connector.start()



# Generated at 2022-06-26 09:01:13.364469
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    """
    _test__Connector_close_streams() -> None

    Unit test for method close_streams of class _Connector
    """
    fake_streams = {FakeStream(state = 'closed')}
    fake_timeout = FakeTimeout()
    fake_timeout.closed = True
    my_connector = _Connector([], '')
    my_connector.streams = fake_streams
    my_connector.close_streams()
    for stream in my_connector.streams:
        assert(stream.state == 'closed')


# Generated at 2022-06-26 09:01:26.645609
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_1 = TCPClient()
    ssl_options_0: Optional[Union[Dict[str, Any], ssl.SSLContext]]
    ssl_options_0 = {
        "ca_certs": "ca_certs.pem",
        "cert_reqs": ssl.CERT_REQUIRED,
        "ciphers": "ciphers.pem",
        "certfile": "certfile.pem",
        "keyfile": "keyfile.pem",
        "protocol": ssl.PROTOCOL_TLSv1,
        "server_hostname": "server_hostname.pem",
        "ssl_version": ssl.PROTOCOL_TLSv1,
    }

# Generated at 2022-06-26 09:01:37.433085
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    # Tests the situation when the input host is not an IP address
    # then it should be converted to its IP address using function
    # gethostbyname

    t_c_p_client_0 = TCPClient()
    @gen.coroutine
    def test_function():
        try:
            tcp_stream = yield t_c_p_client_0.connect("www.google.com", 80)
            print(tcp_stream)
        except:
            print("error")
    test_function()


# Generated at 2022-06-26 09:01:45.470109
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    timeout = 0.3
    connect_timeout = 0.5
    addrinfo = [(2, ('192.168.1.1', 8888)), (23, ('192.168.1.2', 8888))]
    connect = lambda af, addr : (1, 1)
    client = _Connector(addrinfo, connect)
    client.set_timeout(timeout)
    


# Generated at 2022-06-26 09:01:54.054294
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    # t_c_p_client_0 = TCPClient()
    print("Unit test for method connect of class TCPClient")
    host = 'www.google.com'
    port = 80
    res = t_c_p_client_0.connect(host, port)
    print(res)
    print("End unit test for method connect of class TCPClient")


# Generated at 2022-06-26 09:01:57.590520
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # For coverage
    t = _Connector([], lambda x, y: (None, None))
    # Make future done
    t.future.set_result(() )
    t.on_connect_timeout()


# Generated at 2022-06-26 09:02:00.042123
# Unit test for method start of class _Connector
def test__Connector_start():
    print("Running test__Connector_start...")
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.create_connector()


# Generated at 2022-06-26 09:02:08.993756
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    t_c_p_c_connector_0_remaining = t_c_p_client_0.connector.remaining
    t_c_p_c_connector_0_future = t_c_p_client_0.connector.future
    t_c_p_c_connector_0_timeout = t_c_p_client_0.connector.timeout
    t_c_p_c_connector_0_connect_timeout = t_c_p_client_0.connector.connect_timeout
    t_c_p_c_connector_0_last_error = t_c_p_client_0.connector.last_error