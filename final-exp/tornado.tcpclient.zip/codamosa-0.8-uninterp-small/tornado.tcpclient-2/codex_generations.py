

# Generated at 2022-06-26 08:54:16.704355
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # Set-up test
    _Connector_obj = _Connector([(1, 2)], lambda x, y: (None, None))
    _Connector_obj.timeout = 12345

    # Test call
    _Connector_obj.clear_timeout()

    # Check result
    assert _Connector_obj.timeout is None


# Generated at 2022-06-26 08:54:22.339425
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    c = _Connector(
        addrinfo=[],
        connect=lambda af, addr: (None, Future()),
    )
    c.set_connect_timeout(0.25)
    assert True


# Generated at 2022-06-26 08:54:31.517504
# Unit test for constructor of class _Connector
def test__Connector():
    from typing import Any
    from typing import Tuple
    from typing import List

    # Initialize a list of tuples
    t_c_p_client_0 = TCPClient()
    return_value_0 = t_c_p_client_0.resolver.resolve(
        "google.com", 80, family=socket.AF_INET
    )
    _Connector(
        addri=return_value_0, connect=_Connector.__init_on_connect__(af, addr)
    )
    # Initialize a list of tuples
    t_c_p_client_1 = TCPClient()
    return_value_1 = t_c_p_client_1.resolver.resolve(
        "google.com", 80, family=socket.AF_INET6
    )

# Generated at 2022-06-26 08:54:43.330817
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._connector__connector = _Connector(
        [(10, ('127.0.0.1', 8888))], t_c_p_client_0._connector__connect)
    t_c_p_client_0.io_loop = IOLoop()
    t_c_p_client_0._connector__connector.timeout = t_c_p_client_0.io_loop.add_timeout(
        t_c_p_client_0.io_loop.time() + _INITIAL_CONNECT_TIMEOUT, t_c_p_client_0._connector__connector.on_timeout)
    t_c_p_client_0._connector__connector.connect_timeout = t

# Generated at 2022-06-26 08:54:55.227240
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    addr_0 = ()
    addr_1 = ()
    af_0 = socket.AF_UNSPEC
    af_1 = socket.AF_UNSPEC

    t_c_p_client_0 = TCPClient()
    t_c_p_client_1 = TCPClient()

    future_0 = Future()
    future_0._state = future_0._WAITING

    addrs_0 = [
        (af_0, addr_0),
        (af_1, addr_1),
    ]

    addrs_0_iter = (
        (af_0, addr_0),
        (af_1, addr_1),
    )

    _Connector.start(addrs_0, t_c_p_client_1.connect)


# Generated at 2022-06-26 08:55:06.153594
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Test case on_timeout of class _Connector: create instance of 
    # _Connector, so the function have the right parameter to call
    # the function on_timeout
    t_c_p_client_1 = TCPClient()
    connector = _Connector(t_c_p_client_1.addresses, t_c_p_client_1.try_connect)

    # Test case on_timeout of class _Connector: set the self.timeout
    # as None value
    connector.timeout = None

    # Test case on_timeout of class _Connector: Not self.future.done()
    # self.future.done is a flag to indicate whether the future object
    # has been done. The default value is False, which means the future
    # object has not been done. So we need to set the self.future.done
    # to False


# Generated at 2022-06-26 08:55:14.466591
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    def __connect(af, addr):
        # Call IOStream(sock) to create a stream
        return None
    t_c_p_client_0 = TCPClient()
    # Try to create a connection, but connect function throws exception
    # Will return None and future will have exception
    (stream, future) = _Connector._Connector.try_connect(af='ipv4', addr='localhost')
    # Try to create a connection, no exceptions
    (stream, future) = _Connector._Connector.try_connect(af='ipv4', addr='localhost')



# Generated at 2022-06-26 08:55:25.964869
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo: List[Tuple] = list()
    addrinfo.append((socket.AF_INET, ("127.0.0.1", 1234)))
    addrinfo.append((socket.AF_INET, ("127.0.0.1", 5678)))
    addrinfo.append((socket.AF_INET6, ("127.0.0.1", 9012)))
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [
        (socket.AF_INET, ("127.0.0.1", 1234)),
        (socket.AF_INET, ("127.0.0.1", 5678))
    ]
    assert secondary == [
        (socket.AF_INET6, ("127.0.0.1", 9012))
    ]



# Generated at 2022-06-26 08:55:31.996877
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    _connector_0 = _Connector([(10, "123")], t_c_p_client_0.connect)
    _connector_0.start()



# Generated at 2022-06-26 08:55:40.385761
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    connector = _Connector([(1, "Address Family 1"), (2, "Address Family 2")],
                           TCPClient.connect)
    assert connector.timeout is None
    assert connector.connect_timeout is None
    connector.clear_timeouts()
    assert connector.timeout is None
    assert connector.connect_timeout is None
    connector.timeout = 0.1
    assert connector.timeout == 0.1
    connector.clear_timeouts()
    assert connector.timeout is None
    assert connector.connect_timeout is None
    connector.connect_timeout = 0.1
    assert connector.connect_timeout == 0.1
    connector.clear_timeouts()
    assert connector.timeout is None
    assert connector.connect_timeout is None


# Generated at 2022-06-26 08:56:11.997498
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    # Test 1
    try_connector_0 = _Connector(
        addrs=list(), 
        connect=t_c_p_client_0.connect,
    )
    assert try_connector_0.start() is not None


# Generated at 2022-06-26 08:56:17.984718
# Unit test for constructor of class _Connector
def test__Connector():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_1 = TCPClient()

    test_addr_info_0 = t_c_p_client_1.resolver.resolve('www.baidu.com')

    test__Connector_0 = _Connector(test_addr_info_0, t_c_p_client_0.connect)


# test cases for method start of class _Connector

# Generated at 2022-06-26 08:56:21.144627
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    af = socket.AF_INET
    addr = (1, 2, 3)
    ioloop = IOLoop.current()
    connect = lambda family, addr: 0
    c = _Connector([(af, addr)], connect)
    c.start()
    c.clear_timeout()
    assert c.timeout is None


# Generated at 2022-06-26 08:56:28.630422
# Unit test for constructor of class _Connector
def test__Connector():
    addrinfo = [
        (10, (123, 'localhost')),
        (20, (456, '127.0.0.1')),
    ]
    def my_connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        print(af, addr)
        return (None, Future())
    connector = _Connector(addrinfo, my_connect)
    future = connector.start()


# Generated at 2022-06-26 08:56:39.306095
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_1 = TCPClient()
    t_c_p_client_1.resolver = Resolver()
    t_c_p_client_1.resolver.resolve('www.baidu.com')
    addrinfo = t_c_p_client_1.addrinfo
    t_c_p_client_1.stream = IOStream()
    _connect = t_c_p_client_1._connect
    _connector = _Connector(addrinfo,_connect)
    _connector.try_connect(iter(addrinfo)) # True if not dead



# Generated at 2022-06-26 08:56:41.808266
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    connector = _Connector([], set_connect_timeout)
    connector.set_connect_timeout(0.3)


# Generated at 2022-06-26 08:56:48.694140
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    addrs = [(socket.AF_INET, ('127.0.0.1', 8080))]
    af = socket.AF_INET
    addr = ('127.0.0.1', 8080)
    future = Future()
    _Connector.on_connect_done(addrs, af, addr, future)


# Generated at 2022-06-26 08:57:01.908460
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_1 = TCPClient()
    t_c_p_client_2 = TCPClient()
    t_c_p_client_3 = TCPClient()
    t_c_p_client_4 = TCPClient()
    t_c_p_client_5 = TCPClient()
    t_c_p_client_6 = TCPClient()
    t_c_p_client_7 = TCPClient()
    t_c_p_client_8 = TCPClient()
    t_c_p_client_9 = TCPClient()
    t_c_p_client_10 = TCPClient()
    t_c_p_client_11 = TCPClient()
    t_c_p_client_12 = TCPClient()
    t_c_p_client_13 = TCPClient()
    t_c

# Generated at 2022-06-26 08:57:09.746210
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    async def conn(t_c_p_client_0):
        s = await t_c_p_client_0.connect(
            'localhost',
            8080,
        )

    conn(t_c_p_client_0)

# Generated at 2022-06-26 08:57:12.559147
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._connector = _Connector(None, None)
    t_c_p_client_0._connector.start(3.3670361117910486, datetime.timedelta(seconds=2))



# Generated at 2022-06-26 08:58:18.265634
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    # Unit test for method on_connect_timeout of class _Connector
    print('Unit test for method on_connect_timeout of class _Connector')

    addrinfo_0 = list()
    addrinfo_1 = tuple()
    addrinfo_2 = tuple()
    addrinfo_1 = (af_inet, (host, port))
    addrinfo_2 = (af_inet6, (host, port))
    addrinfo_0.append(addrinfo_1)
    addrinfo_0.append(addrinfo_2)


# Generated at 2022-06-26 08:58:19.669782
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    test_case_0()


# Generated at 2022-06-26 08:58:27.452952
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.add_sock_addr_info("www.google.com", 443)
    t_c_p_client_0.init_connection()
    t_c_p_client_0.connector.clear_timeouts()


# Generated at 2022-06-26 08:58:33.800629
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    resolver = Resolver()
    future = resolver.resolve("google.com", 80)
    addrinfo = future.result()
    connect = lambda af, addr: (IOStream(socket.socket()), Future())
    connector = _Connector(addrinfo, connect)
    connector.start()


# Generated at 2022-06-26 08:58:42.685568
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Basic test case
    _Connector_test_instance = _Connector([], None)
    _Connector_test_instance.future = Future()
    _Connector_test_instance.timeout = None
    _Connector_test_instance.connect_timeout = None
    _Connector_test_instance.last_error = None
    _Connector_test_instance.remaining = 0
    _Connector_test_instance.primary_addrs = []
    _Connector_test_instance.secondary_addrs = []
    _Connector_test_instance.streams = set()
    _Connector_test_instance.on_timeout()
    assert _Connector_test_instance.remaining == 0
    assert _Connector_test_instance.future is not None
    assert _Connector_test_instance.last_error is None
    assert _Connector_test_instance.timeout is None

# Generated at 2022-06-26 08:58:46.028862
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    _Connector(addrinfo=[], connect=lambda a, b: (1, 2)).on_timeout()


# Generated at 2022-06-26 08:58:49.702813
# Unit test for method split of class _Connector
def test__Connector_split():
    r = Resolver()
    a = r.resolve('127.0.0.1', 8080)
    c = _Connector(a, "")
    addrinfo = c.split(a)

    # check if a is addrinfo[0]
    assert a == addrinfo[0]


# Generated at 2022-06-26 08:59:01.946620
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():

    @gen.coroutine
    def test():
        t_c_p_client_0 = TCPClient()

        yield t_c_p_client_0.connect(
            'www.google.com',
            80,
            socket.AF_INET,
            ssl_options=None,
            max_buffer_size=None,
            source_ip=None,
            source_port=None,
            timeout=None,
        )

        yield t_c_p_client_0.connect(
            'www.google.com',
            443,
            socket.AF_INET,
            ssl_options=None,
            max_buffer_size=None,
            source_ip=None,
            source_port=None,
            timeout=None,
        )

    IOLoop.current().run_sync

# Generated at 2022-06-26 08:59:11.960761
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    connector = _Connector([("AF_INET", (1, 2, 3, 4))], None)
    connector.streams = set()
    connector.streams.add("stream1")
    # Test before closing stream
    print("Before closing stream: ")
    for stream in connector.streams:
        print("stream: ", stream)
    connector.close_streams()
    # Test after closing stream
    print("After closing stream: ")
    for stream in connector.streams:
        print("stream: ", stream)


# Generated at 2022-06-26 08:59:19.168293
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    f = Future()
    t_c_p_client_0 = TCPClient()
    _Connector._Connector(addrinfo=[], connect=t_c_p_client_0.connect)
    _Connector._Connector.clear_timeouts(connector=t_c_p_client_0)


# Generated at 2022-06-26 09:01:28.901398
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_c_connector_0 = _Connector(t_c_p_client_0.resolver.resolve("127.0.0.1"),t_c_p_client_0._do_connect)
    t_c_c_connector_0.set_timeout(0.3)
    t_c_c_connector_0.clear_timeout()


# Generated at 2022-06-26 09:01:32.238278
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    t_c_p_client_0 = TCPClient()
    _connector_0 = _Connector(None, None,)


# Generated at 2022-06-26 09:01:33.090481
# Unit test for method start of class _Connector
def test__Connector_start():
    pass



# Generated at 2022-06-26 09:01:41.128631
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    # t_c_p_client_0.resolver.add_to_loop()
    t_c_p_client_0.start()


# Generated at 2022-06-26 09:01:51.179259
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    def _connect(
        af: socket.AddressFamily, addr: Tuple, callback: Callable[[IOStream], None]
    ) -> IOStream:
        pass

    connector_0 = _Connector([
        (af, addr)
        for af, addr in [
            (socket.AF_INET, (None, None)),
            (socket.AF_INET6, (None, None)),
            (socket.AF_INET, (None, None)),
        ]
    ], _connect)[0]
    #  raise Exception
    with pytest.raises(Exception):
        connector_0.try_connect(
            iter([(socket.AF_INET, None), (socket.AF_INET6, None)])
        )



# Generated at 2022-06-26 09:02:00.035830
# Unit test for method start of class _Connector
def test__Connector_start():
    arr = []

    # Empty array
    ret = _Connector.start(arr, "")
    assert ret is None

    # One element
    arr = [1]
    ret = _Connector.start(arr, "")
    assert ret is 1

    # Two elements
    arr = [1, 2]
    ret = _Connector.start(arr, "")
    assert ret is 1

    # Multiple elements
    arr = [1, 2, 3, 4]
    ret = _Connector.start(arr, "")
    assert ret is 1

    # Multiple elements, all of which are different
    arr = [1, 1, 2, 3, 4]
    ret = _Connector.start(arr, "")
    assert ret is 1

    # Multiple elements, of which some are the same

# Generated at 2022-06-26 09:02:00.944212
# Unit test for constructor of class _Connector
def test__Connector():
    assert True

# Generated at 2022-06-26 09:02:04.753690
# Unit test for constructor of class _Connector
def test__Connector():
    t_c_p_client_1 = TCPClient()
    test_case_0()
    test_case_0()
    test_case_0()



# Generated at 2022-06-26 09:02:07.187431
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    stream = t_c_p_client_0.connect("0.0.0.0", 8080)


# Generated at 2022-06-26 09:02:08.781444
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    _Connector.set_timeout()
