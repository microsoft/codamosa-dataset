

# Generated at 2022-06-26 08:54:25.962653
# Unit test for constructor of class _Connector
def test__Connector():
    t_c_p_client_0 = TCPClient()
    # First argument is addrinfo
    addrinfo_0: List[Tuple] = [(0, ("127.0.0.1", 80))]
    # Second argument is connect
    def connect(
        af: socket.AddressFamily, addr: Tuple,
    ) -> Tuple[IOStream, "Future[IOStream]"]:
        # TODO: what is this function returning?
        return True, True
    connector_0 = _Connector(addrinfo_0, connect)

    # Test function split in _Connector
    primary_addrs, secondary_addrs = _Connector.split(addrinfo_0)
    assert primary_addrs == [(0, ("127.0.0.1", 80))]
    assert secondary_addrs == []

    # Test function start in _Connector

# Generated at 2022-06-26 08:54:28.768474
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    t_c_p_client_0 = TCPClient()
    test_connector = _Connector(connect=t_c_p_client_0.connect)
    test_connector.on_timeout()


# Generated at 2022-06-26 08:54:34.785045
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():

    f = Future()
    connector = _Connector([], lambda a, b: (None, f))
    connector.set_connect_timeout(.1)

    try:
        f.result()
    except gen.TimeoutError:
        pass


# Generated at 2022-06-26 08:54:37.434332
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    a = _Connector(None, None)
    a.set_connect_timeout(1.0)


# Generated at 2022-06-26 08:54:45.361245
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    byte_count = 1024
    byte_array_0 = bytearray(byte_count)
    for i in range(byte_count):
        byte_array_0[i] = 1
    t_c_p_client_0 = TCPClient()
    local_host_str_0 = "127.0.0.1"
    # send data to a remote server via TCP
    # write a test to cover TCPClient.connect
    client_stream = t_c_p_client_0.connect(local_host_str_0, 53400)
    client_stream.write(byte_array_0)
    client_stream.close()


# Generated at 2022-06-26 08:54:56.011434
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    # Setup
    mock_addrs = iter([(socket.AF_INET6, ("localhost", 0))])
    mock_af = socket.AF_INET6
    mock_addr = ("localhost", 0)
    mock_future = Future()

# Generated at 2022-06-26 08:55:03.475915
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    host = "www.tornadoweb.org"
    t_c_p_client_0 = TCPClient()
    async def async_block_0():
        stream = await t_c_p_client_0.connect(host, 80)
        t_c_p_client_0.close()
        stream.close()
    io_loop_0 = IOLoop.current()
    io_loop_0.run_sync(async_block_0)
    return


# Generated at 2022-06-26 08:55:07.492048
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    non_empty_list = [2]
    connect = lambda x: True
    test = _Connector(non_empty_list, connect)
    addrs = [1, 2, 3]
    future = Future()
    test.on_connect_done(addrs, 1, 1, future)
    assert test.remaining == 0
    assert test.last_error == None
    assert test.streams == set()


# Generated at 2022-06-26 08:55:12.617475
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector.timeout = None
    t_c_p_client_0._Connector.connect_timeout = None
    t_c_p_client_0._Connector.clear_timeouts()


# Generated at 2022-06-26 08:55:24.875886
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    t_c_p_client_0 = TCPClient()

    # Invoke method set_timeout of class _Connector with arguments
    # 0.5

    arg_0 = 0.5

    t_c_p_client_0.resolver = Resolver()
    t_c_p_client_0.set_timeout(arg_0)

    # Verify that the value of attribute timeout of class _Connector
    # is equal to arg_0

    t_c_p_client_0_timeout_0 = t_c_p_client_0.timeout
    if not (t_c_p_client_0_timeout_0 == arg_0):
        raise Exception("value of timeout of class _Connector is not equal to arg_0")


# Generated at 2022-06-26 08:55:56.102521
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():

    @gen.coroutine
    def on_timeout_0(self):

        def on_timeout_0_0(self):
            return self.future.set_exception(TimeoutError())

        _Connector.on_connect_timeout(self)
        return 0



# Generated at 2022-06-26 08:56:03.442967
# Unit test for constructor of class _Connector
def test__Connector():
    addrinfo = [(1, 2), (1, 2)]
    def func(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return 0, 0
    t_c_p_client_0 = TCPClient()
    _Connector(addrinfo, func)



# Generated at 2022-06-26 08:56:06.216356
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():

    # Call function to test

    t_c_p_client_0 = TCPClient()
    t_c_p_client_0._Connector.clear_timeouts()


# Generated at 2022-06-26 08:56:11.738390
# Unit test for method split of class _Connector
def test__Connector_split():
    test_data = [[1, 1], [2, 2]]
    connector = _Connector(test_data, None)
    assert connector.split(test_data) == ([1, 1], [2, 2])



# Generated at 2022-06-26 08:56:19.595703
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    io_loop=IOLoop.current()
    future=Future() # type: Future[Tuple[socket.AddressFamily, Any, IOStream]]
    future.set_exception(TimeoutError())

    primary_addrs=[(2,('127.0.0.1',80))]
    secondary_addrs=[]
    def on_connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, Future[IOStream]]:
        return None, None
    connector=_Connector(primary_addrs,on_connect)
    connector.future=future
    connector.on_connect_timeout()



# Generated at 2022-06-26 08:56:21.493441
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_1 = TCPClient()
    t_c_p_client_1.stream.close()
    t_c_p_client_1.resolver.close()


# Generated at 2022-06-26 08:56:22.330957
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    _Connector.clear_timeouts(None)


# Generated at 2022-06-26 08:56:29.441494
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_connector_0 = _Connector(
        [
            (socket.AF_INET, ("",)),
            (socket.AF_INET6, ("",)),
            (socket.AF_INET, ("",)),
            (socket.AF_INET6, ("",)),
        ],
        TCPClient()._create_stream,
    )

    t_c_connector_0.try_connect(iter(t_c_connector_0.primary_addrs))


# Generated at 2022-06-26 08:56:41.160514
# Unit test for method start of class _Connector
def test__Connector_start():
    # Test initialization
    conn = _Connector(
        [
            (1, (2, 3)),
            (4, (5, 6)),
            (7, (8, 9)),
            (10, (11, 12)),
            (13, (14, 15)),
            (16, (17, 18)),
        ],
        lambda af, addr: addr
    )
    # Test case 0
    conn.future = Future()
    conn.future.result()
    conn.future.set_result((1, 2, 3))
    assert conn.future.done()

    # Test case 1
    conn.future = Future()
    conn.future.result()
    conn.future.set_exception(TimeoutError())
    assert conn.future.done()

    # Test case 2
    conn.future = Future()
    conn.future

# Generated at 2022-06-26 08:56:51.238096
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    async def tcp_client_connect_test(loop):
        await loop.create_server(lambda: None, "127.0.0.1", 8888)
        stream_1 = await t_c_p_client_0.connect(
            "127.0.0.1", 8888, timeout=datetime.timedelta(seconds=1)
        )
        await stream_1.close()
    loop = IOLoop.current()
    t_c_p_client_0 = TCPClient()
    loop.run_sync(tcp_client_connect_test)
    t_c_p_client_0.close()


# Generated at 2022-06-26 08:57:31.045133
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    from tornado.ioloop import IOLoop

    class Stream(object):

        def __init__(self):
            self.closed = False

        def close(self):
            self.closed = True

    class FakeLoop(object):

        def __init__(self):
            self.time_calls = []  # type: List[float]
            self.remove_timeout_ids = set()  # type: Set[object]

        def add_timeout(self, timeout, callback):
            return object()

        def time(self):
            return self.time_calls.pop(0)

        def remove_timeout(self, timeout_id):
            assert timeout_id not in self.remove_timeout_ids
            self.remove_timeout_ids.add(timeout_id)

    loop = FakeLoop()

# Generated at 2022-06-26 08:57:37.068737
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    """
    Unit test for the ``set_timeout`` method of the ``Connector`` class
    """
    # The method set_timeout is part of testing method start of the Connector
    # class and does not need to be tested separately

    pass


# Generated at 2022-06-26 08:57:43.997348
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    addrinfo = [(AF_INET, (a, b)) for a, b in [("127.0.0.1", 80)]]
    connect = t_c_p_client_0._Connector.connect
    t_c_p_client_0_connector_1 = _Connector(addrinfo, connect)
    timeout = 3.5
    t_c_p_client_0_connector_1.set_timeout(timeout)


# Generated at 2022-06-26 08:57:49.646349
# Unit test for constructor of class _Connector
def test__Connector():
    # test case 0
    _Connector([(1, 2), (1, 3), (2, 4)], None)
    # test case 1
    _Connector([(1, 2), (2, 4)], None)



# Generated at 2022-06-26 08:57:53.562488
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_0 = TCPClient()
    connector = _Connector([(1, (1, 1))], t_c_p_client_0.connect)
    connector.clear_timeouts()


# Generated at 2022-06-26 08:58:00.401827
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # Create an instance of _Connector
    t_c_p_client_0 = TCPClient()

    # Create an instance of _Connector
    connector_0 = _Connector(addrinfo=None, connect=None)

    # Call the method
    connector_0.clear_timeout()


# Generated at 2022-06-26 08:58:04.137099
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    _Connector_inst = _Connector([], lambda a, b: None)
    _Connector_inst.close_streams()


# Generated at 2022-06-26 08:58:15.746033
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    a_tcp_client_0 = TCPClient()
    a__connector_0 = t_c_p_client_0._Connector(
        [], lambda x0, x1 : (t_i_o_stream_0, f_t_i_o_stream_0)
    )
    a__connector_0.timeout = object()
    a__connector_0.future.done = False
    a__connector_0.on_timeout()
    assert a__connector_0.timeout is None
    assert a__connector_0.future.done == False


# Generated at 2022-06-26 08:58:29.711718
# Unit test for method start of class _Connector
def test__Connector_start():
    t_c_p_client_0 = TCPClient()
    _c = _Connector(
        [
            (
                socket.AF_INET,
                ("192.0.2.1", 80),
            )  # type: Tuple[socket.AddressFamily, Tuple]
        ],
        (
            functools.partial(
                t_c_p_client_0.connect,
                socket.AF_INET,
                ("192.0.2.1", 80),
                af=socket.AF_INET,
                family=socket.AF_INET,
                server_hostname=None,
            )
        ),
    )

# Generated at 2022-06-26 08:58:41.253938
# Unit test for constructor of class _Connector
def test__Connector():
    ad = [(socket.AF_INET, ('', 8888))]
    def c(a, b):
        return IOStream(socket.socket(family=a, type=socket.SOCK_STREAM))
    t_c_client_0 = TCPClient()
    t_c_p_client_0 = TCPClient(max_clients=20000)
    test_instance = _Connector(ad, c)
    assert test_instance is not None
    assert not test_instance.future.done()
    assert test_instance.timeout == None
    assert test_instance.connect_timeout == None
    assert test_instance.last_error == None
    assert test_instance.remaining == 1
    assert test_instance.primary_addrs == test_instance.secondary_addrs
    assert len(test_instance.streams) == 0

# Generated at 2022-06-26 08:59:46.296705
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    t_c_p_client_1 = TCPClient()
    
    t_c_p_client_2 = TCPClient()
    t_c_p_client_2.host = 'localhost'
    t_c_p_client_2.port = 7000
    
    t_c_p_client_3 = TCPClient()
    t_c_p_client_3.host = 'localhost'
    t_c_p_client_3.port = 8000
    
    _Connector.clear_timeouts(t_c_p_client_2)
    
    
    
    
    



# Generated at 2022-06-26 08:59:47.895376
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [(1, 2), (2, 3), (1, 4)]
    _Connector.split(addrinfo)


# Generated at 2022-06-26 08:59:57.493713
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    my_stream = IOStream(socket.socket.socket(socket.AF_INET, socket.SOCK_STREAM))
    my_stream.socket.connect(("tornadoweb.org", 80))
    my_stream.set_close_callback(callback)
    my_future = Future()
    my_future.result()
    my_future.set_exception()
    my_future.set_result()

    my_stream_1 = IOStream(socket.socket.socket(socket.AF_INET, socket.SOCK_STREAM))
    my_stream_1.socket.connect(("tornadoweb.org", 80))
    my_stream_1.set_close_callback(callback)
    my_future_1 = Future()
    my_future_1.result()
    my_future_1.set_ex

# Generated at 2022-06-26 09:00:04.789990
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    addrinfo: List[Tuple] = [
    ]
    connect: Callable[
        [socket.AddressFamily, Tuple], Tuple[IOStream, "Future[IOStream]"]
    ] = lambda : None
    t_c_p__Connector_0 = _Connector(addrinfo, connect)
    timeout: float = 0.0
    t_c_p__Connector_0.set_timeout(timeout)


# Generated at 2022-06-26 09:00:17.024740
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver(t_c_p_client_0.io_loop)

    dummy_io_stream_0 = IOStream(_sock=socket.socket(socket.AF_INET, socket.SOCK_STREAM))
    dummy_io_stream_1 = IOStream(_sock=socket.socket(socket.AF_INET6, socket.SOCK_STREAM))
    dummy_io_stream_2 = IOStream(_sock=socket.socket(socket.AF_INET6, socket.SOCK_STREAM))

    afinet, afinet6 = socket.AF_INET, socket.AF_INET6
    af, addr = afinet, ("127.0.0.1", 777)
    stream

# Generated at 2022-06-26 09:00:25.456452
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    resolver = Resolver()
    f = Future()
    def create_stream_1(af, addr):
        t_c_p_client_0 = TCPClient()
        return (None, f)
    t_c_p_client_0 = TCPClient()
    _Connector([(0, (1, 2))], create_stream_1).set_connect_timeout(0.0)


# Generated at 2022-06-26 09:00:32.150723
# Unit test for constructor of class _Connector
def test__Connector():
    import socket
    import ssl

    client_tmp_0 = _Connector([(socket.AF_INET, ('127.0.0.1',80))],
        _Connector.connect)

    client_tmp_0.start(timeout=3, connect_timeout=3)


# Generated at 2022-06-26 09:00:36.734852
# Unit test for method start of class _Connector
def test__Connector_start():
    c_00_test_01 = _Connector([(2, ('localhost', 28))], functools.partial(print, 'test connector'))
    c_00_test_01.start(connect_timeout=0.3)



# Generated at 2022-06-26 09:00:50.151536
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver()
    t_c_p_client_0.resolver.configure("tornado.netutil.Resolver.configure", ['127.0.0.1', {}, None])
    t_c_p_client_0.resolve_future = Future()
    t_c_p_client_0.resolve_future.set_result(('127.0.0.1', 80))
    t_c_p_client_0.io_loop = IOLoop()
    t_c_p_client_0.io_loop.start(False)
    t_c_p_client_0.io_loop.current = IOLoop()
    t_c_p_client_0

# Generated at 2022-06-26 09:00:59.780022
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    ip_addresses = [('AF_INET', ('127.0.0.1', 8000)), ('AF_INET6', ('::1', 23333))]
    t_c_c_client_1 = _Connector(
        ip_addresses,
        functools.partial(unittest_TCPClient_connect, unittest=True)
    )
    t_c_c_client_1.try_connect(iter(ip_addresses))
    t_c_c_client_1.start()


# Generated at 2022-06-26 09:03:14.955947
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t_c_p_client_0 = TCPClient()
    t_c_p_client_0.resolver = Resolver(t_c_p_client_0.io_loop)
    t_c_p_client_0.options = {}
    t_c_p_client_0.resolver.resolve('8.8.8.8', 80, callback=t_c_p_client_0._on_resolve)
    t_c_p_client_0.io_loop.add_callback(test_case_0)
    t_c_p_client_0.io_loop.start()


# Generated at 2022-06-26 09:03:25.047175
# Unit test for method split of class _Connector
def test__Connector_split():
    t_c_test_cases = [
        [],
        [(2, ("1.1.1.1", 2))],
        [(2, ("1.1.1.1", 2)), (2, ("1.1.1.1", 3)), (2, ("1.1.1.2", 3))],
        [(2, ("1.1.1.1", 2)), (2, ("1.1.1.1", 3)), (2, ("1.1.1.2", 3)), (45, ("8.8.8.8", 3))],
    ]

    for k in range(len(t_c_test_cases)):
        t_c_test_case = t_c_test_cases[k]

        t_c_result = _Connector.split(t_c_test_case)

       

# Generated at 2022-06-26 09:03:32.741316
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    t_c_p_client_1 = TCPClient()
    t_c_p_client_1.resolver = Resolver()
    t_c_p_client_1.resolver.configure("tornado.netutil.ThreadedResolver")
    t_c_p_client_1.connector = _Connector(
        None, None
    )  # type: _Connector
    t_c_p_client_1.connector.set_connect_timeout(10)
    assert True


# Generated at 2022-06-26 09:03:41.727474
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    t_c_p_client_0 = TCPClient()
    af = socket.AF_ADDRCONFIG
    ssl_options = None
    max_buffer_size = 511
    source_ip = None
    source_port = "source_port_0"
    timeout = "timeout_0"
    try:
        t_c_p_client_0.connect(host, port, af, ssl_options, max_buffer_size, source_ip, source_port, timeout)
    except TimeoutError:
        raise TimeoutError()
    except:
        raise RuntimeError()

# Generated at 2022-06-26 09:03:43.304811
# Unit test for constructor of class _Connector
def test__Connector():
    conn = _Connector(None, None)
    assert type(conn) == _Connector


# Generated at 2022-06-26 09:03:49.369712
# Unit test for method split of class _Connector
def test__Connector_split():
    connector = _Connector([], None)