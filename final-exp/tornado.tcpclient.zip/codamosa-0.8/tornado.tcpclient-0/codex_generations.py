

# Generated at 2022-06-22 15:53:45.615708
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    _Connector(addrinfo = [('af', 'addr')], connect = lambda af, addr: IOStream(socket.create_connection(addr)))


# Generated at 2022-06-22 15:53:50.708742
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    c = _Connector([], lambda af, addr: (IOStream(socket.socket()), Future()))
    c.future._done_callbacks = [lambda: None]
    # test for no error
    c.clear_timeout()
    assert c.timeout is None


# Generated at 2022-06-22 15:53:52.141262
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    io_loop = IOLoop.current()
    io_loop.run_sync(functools.partial(_Connector.on_connect_timeout, _Connector))


# Generated at 2022-06-22 15:53:59.196725
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    class Test(object):
        def __init__(self):
            self.io_loop = IOLoop.current()
            self.connect = self.connect1
            self.future = Future()
            self.timeout = None
            self.connect_timeout = None
            self.last_error = None
            self.remaining = 1
            self.primary_addrs = []
            self.secondary_addrs = []
            self.streams = set()
        async def connect1(self, af, addr):
            raise Exception("success")

    a = Test()
    addrs = iter([("a", "b"), ("c", "d")])
    af = "af"
    addr = "addr"
    future = Future()
    future.set_exception(Exception("success"))

# Generated at 2022-06-22 15:54:05.996919
# Unit test for constructor of class _Connector
def test__Connector():
    from tornado.iostream import IOStream
    import socket
    import tornado.testing as testing

    def test_connect(
        af: socket.AddressFamily,
        addr: Tuple,
    ) -> Tuple[IOStream, "Future[IOStream]"]:
        pass

    addrinfo = [(socket.AF_INET, ('127.0.0.1', 1234))]
    _Connector(addrinfo, test_connect)



# Generated at 2022-06-22 15:54:09.009979
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import doctest
    import sys

    doctest.testmod(sys.modules[__name__])

_iopool = None  # type: Optional[_IOPool]



# Generated at 2022-06-22 15:54:21.629110
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # type: () -> None
    timeouterror = TimeoutError("OnTimeout")
    test_io_loop = IOLoop()
    future = Future()

    def on_timeout():
        future.set_exception(timeouterror)

    test_io_loop.add_timeout = lambda x: x
    test_io_loop.remove_timeout = lambda x: x
    con = _Connector(
        [(AF_INET, ("1.1.1.1", 80)), (AF_INET, ("1.1.1.2", 80))],
        connect=lambda x, y: (0, future),
    )
    con.io_loop = test_io_loop
    con.on_timeout = on_timeout

# Generated at 2022-06-22 15:54:26.289471
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    io_loop = IOLoop()
    io_loop.run_sync(
        lambda: _Connector.on_connect_done(
            None, None, None, None, None, None, True, None
        )
    )



# Generated at 2022-06-22 15:54:31.375235
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Get object
    _connector = _Connector(
        addrinfo=[],
        connect=lambda family, address: (
            IOStream(socket.socket(family, socket.SOCK_STREAM)),
            Future()
        )
    )
    # Set timeout
    timeout = 0.3
    _connector.set_timeout(timeout)
    # Check result
    assert _connector.timeout is not None

# Generated at 2022-06-22 15:54:32.977062
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    my_connector = _Connector([], connect)
    my_connector.try_connect()

# Generated at 2022-06-22 15:56:13.126911
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():

    import unittest
    import time
    from tornado.gen import sleep, IOLoop
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase

    class Test__Connector_on_connect_done(AsyncTestCase):
        def get_async_test_timeout(self):
            return 5

        def test__Connector_on_connect_done(self):
            addrinfo = [(socket.AddressFamily.AF_INET, ('127.0.0.1', 1234))]
            future = Future()
            future.set_exception(TimeoutError())


# Generated at 2022-06-22 15:56:14.479391
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    _Connector.close_streams()



# Generated at 2022-06-22 15:56:16.421991
# Unit test for method start of class _Connector
def test__Connector_start():
    _Connector.start(timeout=0.3)



# Generated at 2022-06-22 15:56:18.639727
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    assert True


IPAddress = Union[Tuple[str, int], str, bytes]



# Generated at 2022-06-22 15:56:27.767475
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import tornado.testing as testing
    import tornado.gen as gen

    class TestStream(object):
        def __init__(self) -> None:
            self.closed = False

        def close(self) -> None:
            self.closed = True

    class TestConnector(testing.AsyncTestCase):
        def test(self):
            stream = TestStream()
            connector = _Connector([], lambda af, addr: ((), Future()))
            connector.streams = set([stream])
            connector.close_streams()
            self.assertTrue(stream.closed)

    t = TestConnector()
    gen.run_test(t.test)

_DEFAULT_RESOLVER = Resolver()



# Generated at 2022-06-22 15:56:36.037467
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    it = iter([(0,('a',1))])
    future_io_stream = Future()
    future_io_stream.set_result('foo')
    conn = _Connector([],lambda x,y: (x,y))
    conn.remaining = 1
    conn.on_connect_done(it,0,('a',1),future_io_stream)
    assert conn.future.result() == (0, ('a', 1), 'foo')
    conn = _Connector([],lambda x,y: (x,y))
    conn.remaining = 1
    conn.on_connect_done(it,0,('a',1),future_io_stream)
    assert conn.last_error == None



# Generated at 2022-06-22 15:56:37.381044
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # TODO
    pass



# Generated at 2022-06-22 15:56:44.760479
# Unit test for method start of class _Connector
def test__Connector_start():
    try:
        addrinfo = [ (1, 2), (3, 4) ]
        connector = _Connector(addrinfo, None)
        timeout = 0.1
        connect_timeout = None  # type: Optional[Union[float, datetime.timedelta]]
        ret = connector.start(timeout, connect_timeout)
        assert ret.done()
    except Exception as e:
        assert False
    else:
        assert True



# Generated at 2022-06-22 15:56:54.891163
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from tornado.iostream import StreamClosedError
    from unittest.mock import Mock, MagicMock, call

    class _UnitTestTCPConnection(unittest.TestCase):
        class _Connector(object):
            def __init__(
                self,
                addrinfo: List[Tuple],
                connect: Callable[
                    [socket.AddressFamily, Tuple], Tuple[IOStream, "Future[IOStream]"]
                ],
            ) -> None:
                self.io_loop = IOLoop.current()
                self.connect = connect
                self.future = Future()  # type: Future[Tuple[socket.AddressFamily, Any, IOStream]]
                self.timeout = None  # type: Optional[object]
                self.connect_timeout = None  # type: Optional[

# Generated at 2022-06-22 15:57:04.977892
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    io_loop = IOLoop.current()
    # Define test_time as the current time
    test_time = io_loop.time()
    # Define timeout as a time 0.5 in the future
    timeout = test_time + 0.5
    # Define connect_timeout as a time 0.1 in the future
    connect_timeout = test_time + 0.1
    # Create a new _Connector object and set the timeouts
    connector = _Connector([[socket.AF_INET, ('localhost', 80)]], None)
    connector.set_timeout(timeout)
    connector.set_connect_timeout(connect_timeout)
    # Check that the current timeouts are the one set above
    assert(timeout == connector.timeout._deadline)
    assert(connect_timeout == connector.connect_timeout._deadline)
    #