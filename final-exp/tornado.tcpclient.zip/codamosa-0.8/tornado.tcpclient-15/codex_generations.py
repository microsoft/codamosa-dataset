

# Generated at 2022-06-22 15:53:38.246430
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    # Connection succeed which means future.result() != None
    af, addr, stream = (0, ('127.0.0.1', 80), object())
    future = Future()
    future.add_done_callback(functools.partial(on_connect_done, future, af, addr))
    future.set_result(stream)
    assert future.result() == stream
    assert future.done()

    def connect(af, addr):
        return (stream, future)

    future = Future()
    future_add_done_callback(future, functools.partial(_Connector.on_connect_done,
                                                       addrs=[], af=af, addr=addr))
    future_add_done_callback(future, functools.partial(on_connect_done, future, af, addr))
    future.set_exception

# Generated at 2022-06-22 15:53:44.332919
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    resolver = Resolver()
    loop = IOLoop.current()
    addrinfo = resolver.resolve('www.google.com', 80)
    def connect(af: socket.AddressFamily,
                addr: Tuple[str, int]) -> Tuple[IOStream, "Future[IOStream]"]:
        s = socket.socket(af, socket.SOCK_STREAM, 0)
        stream = IOStream(s, io_loop=loop)
        future = Future()
        stream.connect(addr, partial(on_connect, future, stream))
        return stream, future

    def on_connect(future: "Future[IOStream]", stream: IOStream, exc: Exception) -> None:
        if exc is None:
            future.set_result(stream)
        else:
            future.set_exception(exc)

# Generated at 2022-06-22 15:53:56.204620
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test setup
    import asyncio
    import sys
    import os

    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()

    import tornado.platform.asyncio

    def raise_timeout_error():
        raise tornado.gen.TimeoutError()

    method = raise_timeout_error
    connector = _Connector(
        [(socket.AddressFamily.AF_INET, ("0.0.0.0", 80))], method
    )

    future = connector.future
    with pytest.raises(TimeoutError):
        connector.on_connect_timeout()


# Generated at 2022-06-22 15:54:03.872254
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    resolver = Resolver()
    def fake_connect(af, addr):
        future = Future()
        future.set_result(addr)
        return future.result(), future
    conn = _Connector(resolver.resolve('example.com', 80), fake_connect)
    conn.start(0.1)
    assert conn.timeout is not None
    conn.on_timeout()
    assert conn.timeout is None


# Generated at 2022-06-22 15:54:07.203804
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    _Connector(addrinfo=[(socket.AddressFamily.AF_UNSPEC, ())], connect=lambda x, y: (None, None)).clear_timeouts()


# Generated at 2022-06-22 15:54:15.142970
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    print("Test start : Method close_streams of class _Connector")
    import socket
    import threading
    from tornado.tcpserver import TCPServer
    from tornado.iostream import IOStream
    from tornado.ioloop import IOLoop

    class MyServer(TCPServer):
        def handle_stream(self, stream: IOStream, address: Tuple) -> None:
            print("Connected from address: ", address)
            self.streams.append(stream)

    def test_connector() -> None:
        io_loop = IOLoop.current()
        server = MyServer()
        server.streams = []
        server.listen(8888)


# Generated at 2022-06-22 15:54:25.372315
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    print("test__Connector_clear_timeouts")

    # Set up the stubs
    #
    def add_timeout_stub(self, timeout: float, callback, io_loop = None):
        if io_loop == None:
            io_loop = IOLoop.current()
        pass

    _Connector.add_timeout_stub = add_timeout_stub
    #
    def remove_timeout_stub(self, timeout):
        pass

    _Connector.remove_timeout_stub = remove_timeout_stub
    #

    # Prevent test from failing when the Resolver is not implemented yet
    #
    def getaddrinfo_stub(host, port, family = 0, socktype = 0, proto = 0, flags = 0):
        pass

    socket.getaddrinfo = getaddrinfo_stub

    #

# Generated at 2022-06-22 15:54:25.778452
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    pass

# Generated at 2022-06-22 15:54:31.983378
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import unittest
    import unittest.mock
    class MockIOStream(unittest.mock.Mock):
        def __init__(self, af: str, addr: str) -> None:
            self.af = af
            self.addr = addr
        def get_extra_info(attr: str) -> str:
            return 'MockIOStream-af:{0}-addr:{1}'.format(self.af, self.addr)
    class MockIOLoop(unittest.mock.Mock):
        def __init__(self) -> None:
            super().__init__()
            self.time = 0
            self.__timeout = {}

# Generated at 2022-06-22 15:54:36.194093
# Unit test for method split of class _Connector
def test__Connector_split():
    class Test():
        @staticmethod
        def assertEqual(a, b):
            assert a == b, f"{a} != {b}"
    test = Test()

    class Connector(_Connector):
        @staticmethod
        def split(
            addrinfo: List[Tuple],
        ) -> Tuple[
            List[Tuple[socket.AddressFamily, Tuple]],
            List[Tuple[socket.AddressFamily, Tuple]],
        ]:
            return super().split(addrinfo)
    connector = Connector()

    # 1.
    addrinfo = [(2, ('0.0.0.0', 80)),]
    expected = ([(2, ('0.0.0.0', 80)),], [])

    retval = connector.split(addrinfo)

# Generated at 2022-06-22 15:54:52.152821
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    assert True

# Generated at 2022-06-22 15:55:00.919577
# Unit test for method split of class _Connector
def test__Connector_split():
    import __main__
    import sys
    import types
    import unittest

    def test_split(
        addrinfo: List[Tuple],
    ) -> Tuple[
        List[Tuple[socket.AddressFamily, Tuple]],
        List[Tuple[socket.AddressFamily, Tuple]],
    ]:
        return _Connector.split(addrinfo)


# Generated at 2022-06-22 15:55:13.605354
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    def my_on_timeout():
        my_on_timeout.called = True
    my_on_timeout.called = False
    def my_on_timeout2():
        my_on_timeout2.called = True
    my_on_timeout2.called = False
    # No timeout object
    c = _Connector([(socket.AF_INET,("",1)), (socket.AF_INET,("",2))],None)
    c.on_timeout()
    assert not my_on_timeout.called
    assert not my_on_timeout2.called
    # With timeout object, no timeout in io_loop
    c.timeout = my_on_timeout
    c.io_loop = {"timeouts":{}}
    c.on_timeout()
    assert not my_on_timeout.called
    assert not my_on

# Generated at 2022-06-22 15:55:19.200523
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # Define unit test function
    def test_try_connect():
        # Create an instance of _Connector
        pc = _Connector([(socket.AF_INET, ("127.0.0.1", 8080))], None)
        # Test to see if method try_connect is called properly
        pc.try_connect(iter([]))



# Generated at 2022-06-22 15:55:23.343145
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    """Unit test for method clear_timeout of class _Connector"""
    _connector_instance = _Connector(addrinfo=[("", "")], connect=lambda *args: None)
    _connector_instance.clear_timeout()



# Generated at 2022-06-22 15:55:24.796431
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    #assert False
    None

# Generated at 2022-06-22 15:55:36.429898
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    addrinfo = [
        (socket.AddressFamily.AF_INET, ('192.168.1.1', 80)),
        (socket.AddressFamily.AF_INET, ('192.168.1.2', 80)),
        (socket.AddressFamily.AF_INET, ('192.168.1.3', 80)),
    ]

    import unittest

    class Stream:
        def __init__(self) -> None:
            self.closed = False

        def close(self) -> None:
            self.closed = True

    class ConnectMock:
        def __init__(self) -> None:
            self.stream = Stream()
            self.future = Future()
            self.future.set_result(self.stream)


# Generated at 2022-06-22 15:55:37.463206
# Unit test for method start of class _Connector
def test__Connector_start():
    pass



# Generated at 2022-06-22 15:55:45.972030
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    async def _test_TCPClient_connect(timeout: str, host: str, port: int, af: str, ssl_options: str, max_buffer_size: int, source_ip: str, source_port: int):
        resolver = Resolver()
        resolver.resolve(host, port, af)
        tcpClient = TCPClient(resolver)
        tcpClient._create_stream(max_buffer_size, af, port, source_ip, source_port)
        tcpClient.close()
        await tcpClient.connect(host, port, af, ssl_options, max_buffer_size, source_ip, source_port, timeout)
    _test_TCPClient_connect("Test timeout", "Test host", 123, "Test af", "Test ssl_options", 5, "Test source_ip", 5)

# Generated at 2022-06-22 15:55:54.195449
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    class Stream(object):
        closed = False
        def close(self):
            self.closed = True
    class Future(object):
        exception_set = False
        def set_exception(self, obj):
            assert type(obj) == TimeoutError
            self.exception_set = True
    c = _Connector(None, None)
    c.future = Future()
    f = Future()
    c.streams.add(Stream())
    # On Timeout
    c.on_connect_timeout()
    assert c.future.exception_set
    assert c.streams.pop().closed
    # Test cleared timeout
    c.streams.add(Stream())
    c.connect_timeout = None
    c.on_connect_timeout()
    assert not c.future.exception_set



# Generated at 2022-06-22 15:56:35.189158
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    class _ConnectorTest:
        def __init__(self, *args, **kwargs):
            self.io_loop = IOLoop.current()
            self.connect = None

            self.future = (
                Future()
            )  # type: Future[Tuple[socket.AddressFamily, Any, IOStream]]
            self.timeout = None  # type: Optional[object]
            self.connect_timeout = None  # type: Optional[object]
            self.last_error = None  # type: Optional[Exception]
            self.remaining = len(addrinfo)
            self.primary_addrs, self.secondary_addrs = self.split(addrinfo)
            self.streams = set()  # type: Set[IOStream]


# Generated at 2022-06-22 15:56:38.462166
# Unit test for constructor of class _Connector
def test__Connector():
    actual = _Connector([(socket.AF_INET,("localhost", 80))], lambda af, addr: (None, None))
    assert actual
    assert actual.io_loop == IOLoop.current()



# Generated at 2022-06-22 15:56:45.935954
# Unit test for method split of class _Connector
def test__Connector_split():
    # type: () -> None
    addrinfo = [(2, 3), (2, 2), (2, 1), (10, 1), (10, 2), (10, 3)]  # type: List[Tuple]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(2, 3), (2, 2), (2, 1)]
    assert secondary == [(10, 1), (10, 2), (10, 3)]



# Generated at 2022-06-22 15:56:55.535589
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    addrinfo = [
        (2, ('10.0.0.0', 1234)),
        (30, ('10.10.10.10', 1234)),
        (10, ('10.10.10.10', 1234)),
        (23, ('20.0.0.10', 1234)),
    ]
    connect = lambda a, b: (b, Future)
    c = _Connector(addrinfo, connect)
    c.try_connect(iter([(2, ('10.0.0.0', 1234))]))
    # We test on_connect_done by checking the Value of two attributes of Connector: future and remaining
    # Let’s first check the case when on_connect_done is called after success of IOStream
    stream = IOStream(socket.socket(), IOLoop.current())
    future = Future

# Generated at 2022-06-22 15:56:56.736974
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    _Connector.set_timeout(self,timeout)


# Generated at 2022-06-22 15:56:58.106201
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    client = _Connector(None, None)
    client._Connector__on_timeout()


# Generated at 2022-06-22 15:57:09.873591
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    try:
        from mock import patch
        from tornado.gen import TimeoutError
    except ImportError:
        raise unittest.SkipTest('mock required for this test')

    future = Future()
    self = _Connector([(socket.AF_INET, ("127.0.0.1", 80))], lambda *args: (None, future))
    self.future = future
    self.future.set_result(None)
    with patch.object(self.io_loop, 'add_timeout') as add_timeout, \
         patch.object(self.future, 'set_exception') as set_exception:
        self.on_connect_timeout()
        assert not set_exception.called

# Generated at 2022-06-22 15:57:20.305797
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    import sys
    from tornado.stack_context import wrap
    from tornado import gen
    from tornado.tcpserver import TCPServer
    from tornado.iostream import IOStream

    @gen.coroutine
    def handle_stream(stream, address):
        yield gen.moment # type: ignore
        stream.write('hello'.encode('utf8'))

    class Server(TCPServer):
        def __init__(self):
            super().__init__() # type: ignore
            self.connections = []

        def handle_stream(self, stream, address):
            self.connections.append(stream)
            self._handlers[0](stream, address)

    resolver = Resolver()
    resolver.install()
    server = Server()

# Generated at 2022-06-22 15:57:27.299113
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    def _Connector_connect(
        self, af: socket.AddressFamily, addr: Tuple
    ) -> Tuple[IOStream, "Future[IOStream]"]:
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
        stream.set_close_callback(
            functools.partial(self.stream_close_callback, addr)
        )
        return stream, stream.connect(addr)

    def _Connector_stream_close_callback(self, addr: Any) -> None:
        self.streams.discard(stream)

    def _Connector_stream_connect_done_callback(self) -> None:
        pass

# Generated at 2022-06-22 15:57:38.907766
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import pytest
    import tornado
    import socket
    import ssl
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import AsyncIOMainLoop

    ioloop = tornado.ioloop.IOLoop()
    asyncio_loop = AsyncIOMainLoop()
    asyncio_loop.make_current()
    resolver = Resolver()
    address = ('google.com', 80)