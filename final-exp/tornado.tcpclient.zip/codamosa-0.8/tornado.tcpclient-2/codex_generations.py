

# Generated at 2022-06-22 15:53:39.041230
# Unit test for method split of class _Connector

# Generated at 2022-06-22 15:53:44.859530
# Unit test for constructor of class _Connector
def test__Connector():
    def connect(
        af: socket.AddressFamily, addr: Tuple
    ) -> Tuple[IOStream, "Future[IOStream]"]:
        # type: (...) -> Tuple[IOStream, Future[IOStream]]
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
        future = stream.connect(addr)
        return (stream, future)

    socket.getaddrinfo = lambda *a, **kw: [(socket.AF_INET, 0, 0, "", ("127.0.0.1", 0))]
    addrinfo = socket.getaddrinfo("localhost", 80)
    c = _Connector(addrinfo, connect)
    c.start()
    assert c.future.result() is not None

CONNECT_SUCCESS = 0
CONNECT_FAILURE = 1


# Generated at 2022-06-22 15:53:56.826618
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    from tornado.iostream import IOStream
    from tornado.testing import AsyncTestCase

    # Patch:
    # class IOStream(object):
    #     def close(self):
    #         pass
    _IOStream = IOStream
    _IOStream.close = lambda self: None
    del IOStream
    IOStream = _IOStream

    class Mock(object):
        def __init__(self):
            self.calls = []  # type: List[Tuple[str, Any]]

        def add_callback(self, callback: Callable, *args: Any, **kwargs: Any) -> None:
            self.calls.append(("add_callback", callback))

        def add_timeout(self, timeout: float) -> object:
            self.calls.append(("add_timeout", timeout))
            return object

# Generated at 2022-06-22 15:54:03.655156
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    _Connector = None
    if _Connector is None:
        raise Exception("The value of variable is None")
    elif isinstance(_Connector, _Connector):
        pass
    else:
        raise Exception("Type of _Connector is not _Connector")
    if hasattr(_Connector, "on_timeout"):
        pass
    else:
        raise Exception("Missing attribute on_timeout")

# Generated at 2022-06-22 15:54:08.954986
# Unit test for method split of class _Connector
def test__Connector_split():
    # Given
    addrinfo = [1, 2, 3, 4, 5, 6, 7]
    primary_af = addrinfo[0]
    primary = []
    secondary = []
    primary_addrs = []
    secondary_addrs = []
    _Connector.split(addrinfo)
    primary, secondary = _Connector.split(addrinfo)


# Generated at 2022-06-22 15:54:14.406243
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    connector = _Connector([], lambda x, y: x)
    connector.set_connect_timeout(1)
    connector.set_timeout(1)
    assert connector.connect_timeout is not None
    assert connector.timeout is not None
    connector.clear_timeouts()
    assert connector.connect_timeout is None
    assert connector.timeout is None



# Generated at 2022-06-22 15:54:22.688207
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    sockets = []
    def mock_close():
        sockets[0].close()
    stream = type(
        "IOStream",
        (),
        {"close": mock_close},
    )

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sockets.append(sock)
    stream = stream(sock)
    _connector = _Connector([], None)
    _connector.streams = [stream]
    _connector.close_streams()
    return True


# Generated at 2022-06-22 15:54:33.142854
# Unit test for method try_connect of class _Connector

# Generated at 2022-06-22 15:54:35.298346
# Unit test for constructor of class _Connector
def test__Connector():
    # type: () -> None
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[object, Future[object]]:
        # type: (socket.AddressFamily, Tuple) -> Tuple[object, Future[object]]
        return None, Future()

    # call _Connector constructor with addrinfo
    _Connector([], connect)



# Generated at 2022-06-22 15:54:42.095623
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Create _Connector object
    connector = _Connector([], None)
    connector.io_loop = IOLoop.current()

    # Setup test case
    connector.future = Future()

    # Method under test
    connector.on_connect_timeout()

    future_1 = Future()
    future_1.set_result(None)
    connector.future = future_1
    connector.on_connect_timeout()



# Generated at 2022-06-22 15:55:01.556812
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    tcp = TCPClient()
    stream = tcp.connect('www.google.com', 80)
    stream.close()
    tcp.close()



# Generated at 2022-06-22 15:55:13.816456
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    """
    For a given object of class _Connector, this function tests the method
    on_connect_timeout
    """
    import socket
    import ssl
    import time
    import datetime

    addrinfo = [(socket.AF_INET, ("127.0.0.1", 8080))]

    def connect(family, addr):
        return IOStream(socket.socket(family, socket.SOCK_STREAM)), Future()

    def on_timeout(self):
        pass

    def clear_timeouts(self):
        pass

    connector = _Connector(addrinfo, connect)
    connector.on_timeout = on_timeout
    connector.clear_timeouts = clear_timeouts
    connector.future.done = True
    connector.on_connect_timeout()


_DEFAULT_RESOLVER = Resolver()



# Generated at 2022-06-22 15:55:18.097152
# Unit test for method start of class _Connector
def test__Connector_start():
    addrinfo = [(socket.AddressFamily.AF_INET, ("127.0.0.1", 8080))]
    connect = lambda family, addr: (None, Future())

    c = _Connector(addrinfo, connect)
    assert c.io_loop == IOLoop.current()
    assert c.connect == connect
    assert c.future.done() == False
    assert c.timeout is None
    assert c.connect_timeout is None
    assert c.last_error is None
    assert c.remaining == 1
    assert c.primary_addrs == [(socket.AddressFamily.AF_INET, ("127.0.0.1", 8080))]
    assert c.secondary_addrs == []
    assert c.streams == set()


# Generated at 2022-06-22 15:55:28.739489
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    timeout = 0.3
    io_loop = IOLoop.current()
    io_loop.time.return_value = 0.0
    c = _Connector([], lambda af, addr: (None, None))
    c.set_timeout(timeout)
    c.io_loop.assert_has_calls([call.add_timeout(timeout + 0, c.on_timeout)])
    c.io_loop.clear_mock()
    c.set_timeout(timeout)
    c.io_loop.assert_has_calls(
        [call.remove_timeout(c.timeout), call.add_timeout(timeout + 0, c.on_timeout)]
    )



# Generated at 2022-06-22 15:55:40.450407
# Unit test for method start of class _Connector
def test__Connector_start():
    self = _Connector(
        addrinfo=[],
        connect=lambda af, addr: (
            self.streams.add(
                IOStream(socket.socket(af, socket.SOCK_STREAM, 0), io_loop=IOLoop.current())
            ),
            future,
        ),
    )
    # self = _Connector(
    #     addrinfo=[],
    #     connect=lambda af, addr: (self.streams.add(IOStream(socket.socket(af, socket.SOCK_STREAM, 0), io_loop=IOLoop.current())), future),
    # )
    timeout = _INITIAL_CONNECT_TIMEOUT
    connect_timeout = None
    self.start(
        timeout=timeout, connect_timeout=connect_timeout,
    )



# Generated at 2022-06-22 15:55:47.129444
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    import time
    from tornado.testing import AsyncTestCase, gen_test

    class _Fake_Resolver(object):
        def resolve(self, host, port, family=0):
            # This must be a pretend IPv6 address or the test will fail on
            # systems without IPv6 support.
            return [("AF_INET", ("127.0.0.1", port))]

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            self.resolver = _Fake_Resolver()
            self.io_loop = self.get_new_ioloop()
            self.connect = self.io_loop.run_sync(
                functools.partial(Connector.connect, self.resolver)
            )


# Generated at 2022-06-22 15:55:54.759066
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    import unittest.mock
    from tornado.ioloop import IOLoop

    class TestCase(unittest.TestCase):
        def test_clear_timeouts(self):
            obj = _Connector(
                [],
                lambda af, addr: (None, None),  # type: ignore
            )
            obj.io_loop = IOLoop()
            with unittest.mock.patch.object(obj.io_loop, "remove_timeout") as mock_io_loop:
                obj.timeout = unittest.mock.Mock()
                obj.connect_timeout = unittest.mock.Mock()
                obj.clear_timeouts()

# Generated at 2022-06-22 15:55:56.302246
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    _Connector.set_timeout(0.3)



# Generated at 2022-06-22 15:55:59.388664
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    connector = _Connector([(1, 2)], 3)
    connector.io_loop = 4
    connector.timeout = 0

    connector.clear_timeout()

    assert connector.io_loop == 4
    assert connector.timeout is None



# Generated at 2022-06-22 15:56:10.242855
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    from unittest.mock import create_autospec, Mock, MagicMock, call

    class HappyEyeballsMock:
        def __init__(self):
            self.primary_addrs = [
                (socket.AF_INET, ("1.1.1.1", 5000)),
                (socket.AF_INET, ("2.2.2.2", 5000)),
            ]
            self.secondary_addrs = [
                (socket.AF_INET6, ("3.3.3.3", 5000)),
                (socket.AF_INET6, ("4.4.4.4", 5000)),
            ]


# Generated at 2022-06-22 15:56:36.887855
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    try:
        from tornado.concurrent import Future
    except:
        from tornado.concurrent import Future
    import socket
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    ioloop = IOLoop.current()
    future1 = Future()
    future2 = Future()
    addrinfo = [
        (socket.AF_INET, ('1', 1)),
        (socket.AF_INET6, ('2', 2))
    ]

    def connect(af, addr):
        if af == socket.AF_INET:
            return None, future1
        else:
            return None, future2

    resolver = Resolver()
    connect_timeout = 1
    timeout = 1

    # SUT
    connector = _Connector(addrinfo, connect)

# Generated at 2022-06-22 15:56:43.746104
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import unittest
    
    class test(unittest.TestCase):
        def test(self):
            self.assertEqual(1,1) 
            #a = _Connector()
            #self.assertEqual(a.clear_timeout, None)
    unittest.main()

if __name__ == "__main__":
    test__Connector_clear_timeout()

# Generated at 2022-06-22 15:56:48.112355
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    timeout = 0
    my_object = _Connector(
        [(1, (1, 2, 3))],
        lambda a1, a2: (None, None),
    )

    my_object.set_timeout(timeout)

    return my_object.timeout is None


# Generated at 2022-06-22 15:56:53.224153
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    addrinfo = [('AF_INET', ('127.0.0.1', 5555)), ('AF_INET6', ('127.0.0.1', 5555))]
    def func() -> None:
        pass

    connect = _Connector.split(addrinfo)
    result = _Connector(addrinfo, connect)
    result.try_connect(iter(result.primary_addrs))


# Generated at 2022-06-22 15:56:59.075882
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    test_stream = IOStream(socket.socket(), io_loop=IOLoop.current())
    test_connector = _Connector(
        [(1, (2, 3))],
        lambda af, addr: (test_stream, Future().set_result(test_stream)),
    )
    test_connector.timeout = 4
    test_connector.connect_timeout = 5
    assert test_connector.timeout is not None
    assert test_connector.connect_timeout is not None
    test_connector.clear_timeouts()
    assert test_connector.timeout is None
    assert test_connector.connect_timeout is None

# Generated at 2022-06-22 15:57:01.046440
# Unit test for method split of class _Connector
def test__Connector_split():
    assert True
    _Connector.split([(2, 3), (4, 5)])

# Generated at 2022-06-22 15:57:12.923047
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    from tornado.testing import AsyncTestCase

    class MyTestCase(AsyncTestCase):
        def test_clear_timeout(self):
            test_io_loop = IOLoop.current()
            timeout = test_io_loop.add_timeout(
                datetime.timedelta(seconds=1), lambda: None
            )
            self.assertIsNotNone(timeout)
            test_connector = _Connector(
                [
                    (socket.AddressFamily.AF_INET, ("192.168.100.100", 80)),
                    (socket.AddressFamily.AF_INET, ("127.0.0.1", 80)),
                ],
                lambda af, addr: (
                    IOStream(socket.socket(af, socket.SOCK_STREAM)),
                    Future(),
                ),
            )
            test_connector.timeout

# Generated at 2022-06-22 15:57:20.818439
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    addrinfo = [('AF_INET', ('ipv4', 80)), ('AF_INET', ('ipv4', 80))]
    io_loop = IOLoop.current()
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return None, None
    connector = _Connector(addrinfo, connect)
    connector.try_connect(iter(connector.primary_addrs))
    assert(connector.try_connect(iter(connector.primary_addrs)) == 'StopIteration')


# Generated at 2022-06-22 15:57:21.800283
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    pass


# Generated at 2022-06-22 15:57:28.936402
# Unit test for method start of class _Connector
def test__Connector_start():
    # from tornado import ioloop
    from tornado import gen
    import socket
    from tornado.iostream import IOStream
    from typing import Any, Union, Dict, Tuple, List, Callable, Iterator, Optional, Set

    future = future_add_done_callback(Future(), lambda future: future)
    future.set_result(None)
    future.result()

    IOLoop.current()

    # create fake socket
    socket_mock = socket.socket()
    socket_mock.connect = lambda addr: None

    def connect(*args, **kwargs):
        return IOStream(socket_mock), future

    addrinfo = [(socket.AF_INET, ('hostname', 80)), (socket.AF_INET6, ('hostname', 80))]

    future = _Connector(addrinfo, connect).start

# Generated at 2022-06-22 15:58:03.882609
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    pass


# Generated at 2022-06-22 15:58:16.400586
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import random, math
    class IOStream:
        def __init__(self, fd, *args, **kwargs):
            pass

        def close(self):
            pass

    class Future:
        def __init__(self, *args, **kwargs):
            pass

        def set_exception(self, e):
            pass

        def done(self):
            return False

        def result(self):
            return self

    class IOLoop:
        def add_timeout(self, time, callback):
            return callback

        def remove_timeout(self, callback):
            pass

        def time(self):
            return 0


# Generated at 2022-06-22 15:58:17.756638
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    _Connector.on_timeout(None)

# Generated at 2022-06-22 15:58:21.267802
# Unit test for constructor of class _Connector
def test__Connector():
    # type: () -> None
    c = _Connector([], lambda x, y: (None, None))
    _Connector.split([(1, ("a", 0)), (2, ("b", 0)), (1, ("c", 0))])



# Generated at 2022-06-22 15:58:30.366902
# Unit test for constructor of class _Connector
def test__Connector():
    # pylint: disable=unused-variable
    test_addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
        (socket.AF_INET6, ("127.0.0.3", 80)),
    ]
    test_connect = lambda af, addr: (None, None)

    connector = _Connector(test_addrinfo, test_connect)
    connector.start()
    connector.close_streams()



# Generated at 2022-06-22 15:58:41.260491
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from unittest.mock import patch
    from tornado import stack_context
    from tornado import testing
    from tornado.iostream import StreamClosedError
    from tornado.netutil import bind_sockets
    from tornado.netutil import add_accept_handler
    from tornado.netutil import ssl_wrap_socket
    import functools
    import ssl
    import socket
    import errno
    import itertools
    from tornado.concurrent import Future
    import collections
    import tornado.testing


# Generated at 2022-06-22 15:58:51.340611
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (
            socket.AddressFamily.AF_INET,
            "72.14.204.99",
        ),
        (
            socket.AddressFamily.AF_INET,
            "64.233.187.99",
        ),
        (
            socket.AddressFamily.AF_INET,
            "216.58.209.99",
        ),
    ]
    x1 = _Connector.split(addrinfo)
    assert x1 == (
        [
            (socket.AddressFamily.AF_INET, ("72.14.204.99",)),
            (socket.AddressFamily.AF_INET, ("64.233.187.99",)),
        ],
        [(socket.AddressFamily.AF_INET, ("216.58.209.99",))],
    )

# Generated at 2022-06-22 15:58:51.820360
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    assert True



# Generated at 2022-06-22 15:59:00.358596
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    timeout = 0.2
    @gen.coroutine
    def test_connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, Future]:
        future = Future()
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
        yield gen.moment
        stream.close()
        future.set_result(stream)
        return stream, future
    
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 8888))]
    connector = _Connector(addrinfo, test_connect)
    connector.start(timeout, timeout)
    assert connector.future.done()
    assert isinstance(connector.future.exception(), TimeoutError)
test__Connector_on_connect_timeout()



# Generated at 2022-06-22 15:59:10.367156
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import datetime
    import socket
    import functools
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('localhost', 0))
    s.listen(1)
    (host, port) = s.getsockname()
    from tornado.gen import TimeoutError
    from tornado.iostream import IOStream, StreamClosedError
    stream = IOStream(s, io_loop=IOLoop.current())
    stream.set_close_callback(lambda _: None)
    def connect(af, addr):
        (host, port) = addr
        sock = socket.socket(af, socket.SOCK_STREAM, 0)
        stream = IOStream(sock, io_loop=IOLoop.current())

# Generated at 2022-06-22 16:00:24.782302
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Create a mock list of _Connector objects
    objs = [_Connector]

    # Make the parameterized call to the method _Connector.clear_timeouts
    # In this case, no parameters will be passed to the function by the test
    # But we can simulate that by passing args=() and kwargs={}
    _Connector.clear_timeouts(objs)

    # Assert that the function call was successful
    assert True



# Generated at 2022-06-22 16:00:32.034579
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    obj = _Connector(
        addrinfo=[
            (socket.AF_INET, ("192.168.1.1", 80)),
            (socket.AF_INET6, ("2001:4860:4860::8888", 443)),
        ],
        connect=lambda af, addr: (test_stream, Future()),
    )
    obj.start()
    obj.close_streams()
    test_stream.close.assert_called_once()
test__Connector_close_streams()



# Generated at 2022-06-22 16:00:41.839841
# Unit test for method start of class _Connector
def test__Connector_start():
    import unittest
    import unittest.mock as mock
    #case1
    with mock.patch("tornado.concurrent.Future") as mock_Future:
        mock_Future_instance = mock.Mock()
        mock_Future.return_value = mock_Future_instance
        with mock.patch("tornado.ioloop.IOLoop.current") as mock_current:
            mock_current_instance = mock.Mock()
            mock_current.return_value = mock_current_instance
            with mock.patch("tornado.iostream.IOStream") as mock_IOStream:
                mock_IOStream_instance = mock.Mock()
                mock_IOStream.return_value = mock_IOStream_instance

# Generated at 2022-06-22 16:00:53.631045
# Unit test for constructor of class _Connector
def test__Connector():
    c = _Connector(
        addrinfo=[(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("127.0.0.1", 8080))],
        connect=lambda family, addr: (None, Future()),
    )
    assert c.io_loop is IOLoop.current()
    assert isinstance(c.future, Future)
    assert c.timeout is None
    assert c.connect_timeout is None
    assert c.last_error is None
    assert c.remaining == 2
    assert c.primary_addrs == [(socket.AF_INET, ("127.0.0.1", 80))]
    assert c.secondary_addrs == [(socket.AF_INET, ("127.0.0.1", 8080))]

# Generated at 2022-06-22 16:00:56.066101
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    class DummyIOStream:
        def close(self):
            pass
    connector = _Connector([], None)
    connector.streams.add(DummyIOStream())
    connector.close_streams()
    if len(connector.streams) != 0:
        raise Exception("connector.streams should be empty!")



# Generated at 2022-06-22 16:01:05.641956
# Unit test for method split of class _Connector
def test__Connector_split():
    # Test for Empty addrinfo
    assert _Connector.split([]) == ([],[])
    # Test for single element in addrinfo
    assert _Connector.split([(socket.AF_INET,['localhost',8000])]) == ([(socket.AF_INET,['localhost',8000])],[])
    # Test for Single element in addrinfo with duplicate family entries
    assert _Connector.split([(socket.AF_INET,['localhost',80]),(socket.AF_INET,['localhost',4444])]) == ([(socket.AF_INET,['localhost',80]),(socket.AF_INET,['localhost',4444])],[])
    # Test for Two element in addrinfo, first two elements are different family

# Generated at 2022-06-22 16:01:14.118753
# Unit test for method split of class _Connector
def test__Connector_split():
    from unittest import TestCase

    class _ConnectorTest(TestCase):

        def test_split(self):
            connector = _Connector.split(
                [
                    (socket.AF_INET, "AF_INET"),
                    (socket.AF_INET, "AF_INET"),
                    (socket.AF_INET6, "AF_INET6"),
                    (socket.AF_INET6, "AF_INET6"),
                ]
            )
            self.assertEqual(
                connector, ([(socket.AF_INET, "AF_INET")], [(socket.AF_INET6, "AF_INET6")])
            )

    _ConnectorTest().test_split()



# Generated at 2022-06-22 16:01:22.979379
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    IOLoop.clear_instance()
    io_loop = IOLoop()

    def connect(*args):
        return IOStream(socket.socket()), Future()

    first_address = (socket.AF_INET, ("ipv4-address", 9999))
    first_address2 = (socket.AF_INET, ("ipv4-address", 9696))
    second_address = (socket.AF_INET, ("ipv4-address", 8787))
    third_address = (socket.AF_INET, ("ipv4-address", 3141))
    c = _Connector([first_address, second_address, third_address], connect)
    c.on_connect_timeout()
    assert c.future.done()
    assert c.future.exception() is not None

# Generated at 2022-06-22 16:01:34.593385
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    from tornado.testing import AsyncTestCase
    from tornado.ioloop import IOLoop
    
    class Test(AsyncTestCase):
        def test_callable_clear_timeouts(self):
            io_loop = IOLoop()
            connector = _Connector(
                [(1, (1, 1))],
                lambda af, addr: None
            )
            self.assertEqual(connector.timeout, None)
            self.assertEqual(connector.connect_timeout, None)
            connector.set_timeout(1)
            connector.set_connect_timeout(1)
            self.assertNotEqual(connector.timeout, None)
            self.assertNotEqual(connector.connect_timeout, None)
            connector.clear_timeouts()
            self.assertEqual(connector.timeout, None)


# Generated at 2022-06-22 16:01:46.171152
# Unit test for method start of class _Connector
def test__Connector_start():
    """
    Test method start of class _Connector
    """

    addrinfo = [(socket.AddressFamily.AF_INET, ("127.0.0.1", 80)), (socket.AddressFamily.AF_INET6, ("127.0.0.1", 80))]