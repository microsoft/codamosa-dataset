

# Generated at 2022-06-22 15:53:50.801650
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    addrinfo = [
        (socket.AddressFamily.AF_INET, ("127.0.0.1", 80)),
        (socket.AddressFamily.AF_INET6, ("::1", 80)),
    ]
    connector = _Connector(addrinfo, connect=lambda *args: (None, None))
    connector.future = Future()
    connector.future.set_result(None)

    connector.on_connect_timeout()

    assert connector.connect_timeout is None


# Generated at 2022-06-22 15:53:57.275578
# Unit test for constructor of class _Connector
def test__Connector():
    from typing import NamedTuple
    from unittest import TestCase

    class AddrInfo(NamedTuple):
        family: socket.AddressFamily
        addr: Tuple

    class DummyAddrInfo(List):
        pass

    class DummyStream(IOStream):
        def __init__(self, io_loop):
            super().__init__(socket.socket(), io_loop)
            self.ready = Future()

    class DummyFuture(Future):
        def set_result(self, result):
            self.result = result

        def done(self):
            return False

    class DummyIOLoop(IOLoop):
        def add_timeout(self, deadline, callback):
            return _ConnectorTimeout(deadline, callback)


# Generated at 2022-06-22 15:54:09.438562
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = list()
    addrinfo.append((2,(1,2,'name', 'addr')))
    addrinfo.append((1,(1,2),'name', 'addr'))
    addrinfo.append((3,(1,3),'name', 'addr'))

    primary, secondary = _Connector.split(addrinfo)

    assert isinstance(primary, list)
    assert isinstance(secondary, list)

    assert len(primary) == 1
    assert primary[0][0] == 2
    assert primary[0][1] == (1,2,'name', 'addr')

    assert len(secondary) == 2
    assert secondary[0][0] == 1
    assert secondary[0][1] == (1,2,'name', 'addr')
    assert secondary[1][0] == 3

# Generated at 2022-06-22 15:54:19.453729
# Unit test for method start of class _Connector
def test__Connector_start():
    print("testing start")
    # 1st test case
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 8888))]
    def connect(address_family, addr):
        return ('127.0.0.1', 8888)
    print("\t1st test case")
    print("\t\tTrying to connect to 127.0.0.1:8888 with TCP")
    _connector = _Connector(addrinfo, connect)
    _connector.start()
    print("\t\tConnection done")


# Generated at 2022-06-22 15:54:31.117254
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    import sys
    import time
    import unittest
    import unittest.mock
    from tornado.testing import AsyncTestCase, bind_unused_port, ExpectLog

    from .. import _Connector
    from .. import TCPClient
    from .. import iostream
    from .. import netutil
    from .. import platform
    from .. import stack_context

    class _ConnectorTest(AsyncTestCase):
        def test_timeout(self):
            server = bind_unused_port()[1]
            connector = _Connector(
                [
                    (socket.AF_INET, ("127.0.0.1", server)),
                    (socket.AF_INET6, ("::1", server)),
                ],
                self.connect,
            )

# Generated at 2022-06-22 15:54:33.372857
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    io_loop = IOLoop.current()
    io_loop.add_callback(io_loop.stop)
    io_loop.start()
    io_loop.close()



# Generated at 2022-06-22 15:54:36.492804
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    io_loop = IOLoop.current()
    future = Future()
    timeout = io_loop.add_timeout(0, {})
    connector = _Connector([], None)
    connector.io_loop = io_loop
    connector.future = future
    connector.timeout = timeout

    connector.set_timeout(1)

    assert connector.timeout is not None



# Generated at 2022-06-22 15:54:46.828977
# Unit test for constructor of class _Connector
def test__Connector():
    from typing import Tuple, List, Set, IOStream, Optional, Union, Dict
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.gen import TimeoutError

    class DummyIOLoop():
        def add_timeout(
            self,
            deadline: Union[datetime.datetime, float],
            callback: Callable[[], None],
        ) -> Any:
            pass

        def remove_timeout(self, timeout: Any) -> None:
            pass

        def time(self) -> float:
            return 0.0

    class DummyFuture(Future):
        pass

    def dummy_connect(
        f: socket.AddressFamily, a: Tuple[str, int]
    ) -> Tuple[IOStream, "Future[IOStream]"]:
        return io_stream,

# Generated at 2022-06-22 15:54:57.694249
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Tests whether the self.timeout and self.connect_timeout are removed
    # from the ioloop by method clear_timeouts.
    def connect(af, addr):
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM), io_loop=IOLoop.instance())
        f = Future()
        if not stream.closed():
            stream.connect(addr, callback=f.set_result)
        return stream, f

    global io_loop
    io_loop = IOLoop.instance()
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET6, ("127.0.0.1", 80))]
    timeout = 0.1
    # Make sure that this test runs quickly
    _INITIAL_CONNECT_TIMEOUT

# Generated at 2022-06-22 15:55:09.853211
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    
    class UnitTest(AsyncTestCase):
        
        def test_clear_timeouts(self):
            ''' init _Connector and call clear_timeouts. 
            '''
            f = Future()
            f.result = lambda :'foo'
            res = []
            now = round(time.time())
            c = _Connector([], lambda af, addr: (f, f))
            c.io_loop = self.io_loop
            c.io_loop.remove_timeout = lambda t: res.append(t)
            c.future = f
            self.io_loop.add_timeout = lambda t, callback: (t, callback)
            c.timeout = now
            c.connect_timeout = now


# Generated at 2022-06-22 15:55:36.888894
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    dns = Resolver()
    dns.install = lambda *args, **kwargs: None

    async def async_dummy(args: Any) -> Any:
        ...

    @dns.callback
    def dummy(args: Any) -> Any:
        ...

    def dummy_connect(af: socket.AddressFamily, addr: Tuple[str]) -> Any:
        ...

    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", "8888"))
    ]  # type: List[Tuple]

    connector = _Connector(addrinfo, dummy_connect)

    connector.io_loop = IOLoop()  # type: ignore
    connector.io_loop.add_callback = lambda *args, **kwargs: None

    connector.clear_timeout = lambda: None

# Generated at 2022-06-22 15:55:44.636407
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import unittest
    from unittest import mock

    from tornado.concurrent import Future

    import six
    from six.moves import range

    from tornado.testing import AsyncTestCase

    from tornado.netutil import TCPServer
    from tornado.iostream import StreamClosedError

    from random import randint

    from test.util import skipIfNonUnix

    from typing import Any, Tuple

    # We need unix sockets for the _Connector test, since it needs to open
    # a lot of sockets quickly.
    skipIfNonUnix()

    class _ConnectorTestCase(AsyncTestCase):
        def setUp(self):
            # type: () -> None
            super(_ConnectorTestCase, self).setUp()

            self.connections = 0
            self.binds = 0
            self.streams = 0

           

# Generated at 2022-06-22 15:55:50.042498
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    connector = _Connector(
        [(socket.AF_INET, ("10.10.10.1", 8000))],
        lambda *args, **kwargs: (None, Future()),
    )
    connector.start()
    connector.clear_timeout()
    assert connector.timeout is None



# Generated at 2022-06-22 15:55:53.508781
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import unittest
    

    class _Connector_clear_timeout(unittest.TestCase):
        def setUp(self):
            pass


    unittest.main()



# Generated at 2022-06-22 15:56:02.713192
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import threading
    from tornado import gen
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop

    # test for close_streams of class_connector
    http_client = AsyncHTTPClient()
    @gen.coroutine
    def run(i):
        response = yield http_client.fetch('http://www.baidu.com')
        print(response.body)

    def main():
        threads = []
        for i in range(10):
            t = threading.Thread(target=run, args=(i,))
            threads.append(t)
        for t in threads:
            t.start()
        for t in threads:
            t.join()


# Generated at 2022-06-22 15:56:10.733160
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():

    def mock_on_connect_done( addrs, af, addr, future):
        future.set_exception(Exception("connection failed"))
        future.result()
        return

    class MockFuture(Future):
        def result(self):
            return self.done
        
    class MockIOStream(IOStream):
        def __init__(self):
            self.closed = False
        
        def close(self):
            self.closed = True
            
    def mock_connect(af, addr):
        stream = MockIOStream()
        future = MockFuture()
        return stream, future

    class MockIOLoop:
        def current(self):
            return self
        
        def add_timeout(self, time, callback):
            return time
            
        def time(self):
            return
        

# Generated at 2022-06-22 15:56:15.726091
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    def mock_close(self):
        return

    setattr(IOStream, 'close', mock_close)
    _Connector(
        [(socket.AF_INET, ('localhost', 5000))],
        lambda a, b: (None, None),
    ).close_streams()



# Generated at 2022-06-22 15:56:25.809959
# Unit test for constructor of class _Connector
def test__Connector():
    import unittest
    from typing import List, Tuple, Optional, Dict
    from unittest.mock import Mock

    class TestConnector(unittest.TestCase):

        def setUp(self) -> None:
            self.io_loop = Mock()
            self.primary_addrs = [
                (
                    socket.AddressFamily.AF_INET,
                    (
                        "192.168.0.254",
                        8888,
                    ),
                )
            ]
            self.secondary_addrs = [
                (
                    socket.AddressFamily.AF_INET6,
                    (
                        "fe80::b50f:aa0a:5c3b:2363",
                        8888,
                    ),
                )
            ]
            self.addrinfo = self.primary_addrs + self.secondary

# Generated at 2022-06-22 15:56:28.733056
# Unit test for constructor of class _Connector
def test__Connector():
    assert 1 == 1, "Implement me!"



# Generated at 2022-06-22 15:56:32.099561
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    connector = _Connector(None, None)
    timeout = 0.3
    # Create the timeout
    connector.set_timeout(timeout)
    self.assertTrue(connector.timeout)


# Generated at 2022-06-22 15:57:13.879268
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # Arrange
    class _Connector_Mock:
        def __init__(self):
            self.vars = {
                'remaining': None,
                'primary_addrs': None,
                'connect': None,
                'secondary_addrs': None,
                'streams': None,
                'future': None,
                'last_error': None,
                'io_loop': None,
                'timeout': None,
                'connect_timeout': None,
            }

    connector = _Connector_Mock()
    af = 'af'
    addr = 'addr'
    addrinfo = [
        (af, addr)
    ]

    def connect(af, addr):
        return af, addr

    f = functools.partial(connect, af=af, addr=addr)
    stream, future = f

# Generated at 2022-06-22 15:57:15.549139
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # print("Testing method try_connect of class _Connector")
    pass



# Generated at 2022-06-22 15:57:25.035341
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # setup
    io_loop = IOLoop.current()
    def mock_io_loop_add_timeout(time: float, callback: Callable) -> object:
        callback()
        return None
    def mock_io_loop_remove_timeout(timeout: object) -> None:
        return None

    addrinfo = [(socket.AddressFamily.AF_INET, ('127.0.0.1', 8888))]
    def mock_connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return (IOStream(socket.socket(af, socket.SOCK_STREAM)), Future())
    connector = _Connector(addrinfo, mock_connect)
    connector._Connector__timeout = None
    connector._Connector__connect_timeout = None

# Generated at 2022-06-22 15:57:37.626415
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import asyncio
    import tornado
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import unittest
    import unittest

    async def test(ioloop, stream):
        fut = ioloop.create_future()
        fut.add_done_callback(lambda x: stream.close())
        fut2 = ioloop.create_future()
        fut2.add_done_callback(lambda x: stream.close())

        # Check that it's still possible to clear timeouts after a
        # socket has been closed. See https://github.com/tornadoweb/tornado/issues/2456
        ioloop.add_timeout(ioloop.time() + 0.5, lambda: None)

# Generated at 2022-06-22 15:57:39.503273
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    connector = _Connector([(socket.AF_INET, ('localhost', 80))], None)
    assert connector.clear_timeouts() == None

# Generated at 2022-06-22 15:57:39.997138
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    assert True



# Generated at 2022-06-22 15:57:52.994426
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [(socket.AF_INET,("1.1.1.1",443)),(socket.AF_INET6,("2.2.2.2",443)),(socket.AF_INET,("3.3.3.3",443)),(socket.AF_INET6,("4.4.4.4",443))]
    primary_addrs, secondary_addrs = _Connector.split(addrinfo)
    assert primary_addrs == [(socket.AF_INET,("1.1.1.1",443)),(socket.AF_INET,("3.3.3.3",443))]
    assert secondary_addrs == [(socket.AF_INET6,("2.2.2.2",443)),(socket.AF_INET6,("4.4.4.4",443))]

# Generated at 2022-06-22 15:57:54.889603
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    assert False, "Unimplemented"



# Generated at 2022-06-22 15:58:05.566236
# Unit test for constructor of class _Connector

# Generated at 2022-06-22 15:58:17.760673
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    from typing import Any, List, Tuple, Set, Iterator

    # fake data
    addrs = []  # type: Iterator[Tuple[socket.AddressFamily, Tuple]]
    af = 1  # type: socket.AddressFamily
    addr = (1, 2)  # type: Tuple
    future = False  # type: Future[IOStream]
    # check empty list
    class fake_io_loop():
        def remove_timeout(self, timeout):
            return None

    class fake_stream():
        def close(self):
            return None

    class fake_future():
        def result(self):
            raise Exception()
        def set_result(self, result):
            return None
        def set_exception(self, exception):
            return None


# Generated at 2022-06-22 15:59:27.640815
# Unit test for constructor of class _Connector
def test__Connector():
    AC = _Connector(
        [
            (socket.AF_INET, ("localhost", 80)),
            (socket.AF_INET6, ("localhost", 80)),
            (socket.AF_INET, ("localhost", 80)),
        ],
        lambda a, b: (None, None),
    )
    assert AC.io_loop is None  # type: ignore
    assert AC.connect is None  # type: ignore
    assert AC.timeout is None  # type: ignore
    assert AC.connect_timeout is None  # type: ignore
    assert AC.last_error is None  # type: ignore
    assert AC.primary_addrs == [(socket.AF_INET, ("localhost", 80))]
    assert AC.secondary_addrs == [(socket.AF_INET6, ("localhost", 80))]
    assert AC.stream

# Generated at 2022-06-22 15:59:28.855116
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    _Connector.try_connect(0,"")


# Generated at 2022-06-22 15:59:32.916653
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    def f():
        # Client client
        client = TCPClient()
        # Connect to our local host
        stream = yield client.connect('localhost', 8888)
        stream.close()
        
    IOLoop.current().run_sync(f)


# Generated at 2022-06-22 15:59:40.922452
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    stream = IOStream(socket.socket())
    stream.connect(("127.0.0.1", 0))
    def callback():
        stream.close()
    t = IOLoop.current().add_timeout(
            IOLoop.current().time(), callback)
    c = _Connector([(socket.AF_INET, ("127.0.0.1", 0))], connect=None)
    c.timeout = t
    c.connect_timeout = t
    c.clear_timeouts()
    assert c.timeout == None
    assert c.connect_timeout == None


# Generated at 2022-06-22 15:59:48.668298
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    """Unit test for method set_connect_timeout of class _Connector."""
    #
    # Test that set_connect_timeout stores set the timeout to a call on a
    # given callback
    #
    io_loop = IOLoop.current()
    connect = lambda af, addr: (None, None)
    connector = _Connector([], connect)
    timeout = 0.7
    timeout_handle = io_loop.add_timeout(timeout, connector.on_connect_timeout)
    connector.set_connect_timeout(timeout)
    assert timeout_handle == connector.connect_timeout
    io_loop.remove_timeout(timeout_handle)
    assert connector.connect_timeout is None

    #
    # Test that set_connect_timeout doesn't overwrite existing timeouts
    #
    io_loop = IOLoop.current()
    connect

# Generated at 2022-06-22 15:59:56.165260
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    
    test_stream = IOStream(socket.socket())
    test_streams = [test_stream]
    test_obj = _Connector(
        addrinfo=[("", ("", 0))],
        connect=lambda a, b: (test_stream, Future()),
    )
    test_obj.streams = set(test_streams)
    test_obj.close_streams()
    try:
        assert test_stream.socket is None
    except AssertionError as e:
        print(e)
        import sys
        sys.exit(1)



# Generated at 2022-06-22 16:00:06.028362
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import bind_unused_port
    from tornado import platform

    port = bind_unused_port()[1]
    on_connect_timeout = False

    class ConnectorTest(AsyncTestCase):
        def test_connect_timeout(self):
            nonlocal on_connect_timeout
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.bind(("127.0.0.1", port))
            s.setblocking(0)
            connector = _Connector(((socket.AF_INET, ("127.0.0.1", port)),),
                                   lambda af, addr: (None, gen.Future()))

# Generated at 2022-06-22 16:00:06.970792
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    pass

# Generated at 2022-06-22 16:00:14.528183
# Unit test for constructor of class _Connector
def test__Connector():
    @gen.coroutine
    def coroutine_test() -> None:
        af, addr, _ = yield _Connector(
            addrinfo=[(socket.AF_INET, ("1.2.3.4",))], connect=connect
        ).start()
        assert af == socket.AF_INET, af
        assert addr == "1.2.3.4", addr

    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return (None, Future())

    IOLoop.current().run_sync(coroutine_test)

# Generated at 2022-06-22 16:00:25.290971
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    def fake_connect(af: int, addr: Tuple[str, int]) -> Tuple[IOStream, Future]:
        class FakeStream:
            def close(self):
                pass

        return FakeStream(), Future().set_result(FakeStream())

    for af, port in [(1, 2), (3, 4)]:
        addrs = [(af, ("localhost", port))]

    # Then we can create a Connector and start it.
    connector = _Connector(addrs, connect)
    future = connector.start()

    # The future should resolve to the first address in the list.
    result = future.result()
    assert result[1] == addrs[0][1]



# Generated at 2022-06-22 16:02:45.952482
# Unit test for method start of class _Connector
def test__Connector_start():
    import unittest
    import socket
    from tornado.util import raise_exc_info

    from tornado.testing import AsyncTestCase, bind_unused_port

    class ConnectorTest(AsyncTestCase):
        def setUp(self):
            addrinfo = [
                (socket.AF_INET, ("1.2.3.4", 111)),
                (socket.AF_INET, ("2.3.4.5", 222)),
                (socket.AF_INET6, ("::1", 333)),
                (socket.AF_INET6, ("fe80::1", 444)),
                (socket.AF_INET6, ("fe80::2", 555)),
            ]
            self.addrs = addrinfo
            self.addr1 = addrinfo[0][1]

# Generated at 2022-06-22 16:02:46.903568
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    _Connector.close_streams()



# Generated at 2022-06-22 16:02:56.462604
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # type: () -> None
    # Test cases for method close_streams of class _Connector
    import unittest
    import io
    import unittest.mock

    class Test__Connector_close_streams(unittest.TestCase):
        def test_close_streams(self) -> None:
            # type: () -> None
            mock_io_loop = unittest.mock.Mock(spec=IOLoop)
            test = _Connector(
                addrinfo=[],
                connect=unittest.mock.Mock(
                    spec=Callable[
                        [socket.AddressFamily, Tuple],
                        Tuple[IOStream, "Future[IOStream]"],
                    ]
                ),
            )
            # Test if method close_streams of class _Connector works when attribute streams is empty
            test

# Generated at 2022-06-22 16:03:07.352023
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # init
    addrinfo = [1, 2, 3]
    connect = lambda a, b: 1
    connector = _Connector(addrinfo, connect)
    connector.future = 1
    connector.timeout = IOLoop().add_timeout(datetime.timedelta(1), 1)
    connector.connect_timeout = 1
    connector.last_error = 1
    connector.remaining = 1
    connector.primary_addrs, connector.secondary_addrs = connector.split(addrinfo)
    connector.streams = set()
    # test
    connector.clear_timeouts()
    assert connector.future == 1
    assert connector.timeout == None
    assert connector.connect_timeout == 1
    assert connector.last_error == 1
    assert connector.remaining == 1
    assert connector.primary_addrs == []

# Generated at 2022-06-22 16:03:17.589620
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import pytest
    from tornado.platform.asyncio import AsyncIOMainLoop

    loop = AsyncIOMainLoop()
    loop.make_current()

    obj = _Connector([(socket.AF_INET, ("localhost", 8080))],
        test_connect)
    obj.io_loop = IOLoop.current()
    obj.io_loop._run_callback(obj.set_timeout, 0.1)
    yield gen.sleep(0.2)
    assert obj.timeout is not None
    assert obj.future.done()
    assert obj.future.exception() is None
    assert obj.future.result()[1] == ("localhost", 8080)
    assert obj.future.result()[2].read_until_close.done

# Generated at 2022-06-22 16:03:21.241091
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    """
    Test calling clear_timeout
    """
    instance = _Connector([], None)
    instance.clear_timeout()
    # check that instance.timeout is now None
    assert instance.timeout is None



# Generated at 2022-06-22 16:03:31.192394
# Unit test for constructor of class _Connector
def test__Connector():
    import sys
    import io
    import unittest
    import tornado.testing
    import tornado.httpserver
    import tornado.platform.asyncio
    import asyncio

    class TestConnector(unittest.TestCase):

        @tornado.testing.gen_test
        def test_connect(self):
            loop = asyncio.get_event_loop()

            def future_connect(af, addr):
                def _connect(addr):
                    sock = socket.socket(af, socket.SOCK_STREAM)
                    sock.setblocking(False)
                    sock.bind(addr)
                    sock.listen(1)
                    fut = loop.create_future()
                    fut.set_result(sock)
                    return fut
