

# Generated at 2022-06-22 15:53:39.038293
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    pass

# Generated at 2022-06-22 15:53:49.829744
# Unit test for constructor of class _Connector
def test__Connector():
    from tornado.testing import AsyncTestCase, gen_test

    class TestConnector(_Connector):
        def __init__(
            self,
            addrinfo: List[Tuple],
            connect: Callable[
                [socket.AddressFamily, Tuple], Tuple[IOStream, "Future[IOStream]"]
            ],
        ) -> None:
            super(TestConnector, self).__init__(addrinfo, connect)

        def split(
            self,
            addrinfo: List[Tuple],
        ) -> Tuple[
            List[Tuple[socket.AddressFamily, Tuple]],
            List[Tuple[socket.AddressFamily, Tuple]],
        ]:
            return super(TestConnector, self).split(addrinfo)


# Generated at 2022-06-22 15:54:01.770128
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    '''
    if not self.future.done():
        self.try_connect(iter(self.secondary_addrs))

    '''
    addrs = [((socket.AF_INET,), ("127.0.0.1", 8080))]
    # A mock connection factory with a mock IOStream
    def mock_connect(af, address): # type: (socket.AddressFamily, Tuple) -> Tuple[IOStream, "Future[IOStream]"]
        future = Future() # type: "Future[IOStream]"
        future.set_exception(Exception)
        return (IOStream(), future)
    connector = _Connector(addrs, mock_connect)
    if not connector.future.done():
        connector.try_connect(iter(connector.secondary_addrs))



# Generated at 2022-06-22 15:54:09.351572
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    test = _Connector(0,0)
    test.io_loop = IOLoop.current()
    connect_timeout = datetime.datetime.now() + datetime.timedelta(seconds=0.2)
    test.future = Future()
    test.timeout = None
    test.connect_timeout = None
    test.set_connect_timeout(connect_timeout)
    assert test.connect_timeout == IOLoop.current().add_timeout(connect_timeout, test.on_connect_timeout)



# Generated at 2022-06-22 15:54:13.627577
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    print('Test _Connector.on_timeout()')
    io_loop = IOLoop.current()
    io_loop.run_sync(functools.partial(_test_Connector_on_timeout, io_loop))


# Generated at 2022-06-22 15:54:21.009898
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    '''Unit test for method try_connect of class _Connector'''
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    import socket
    import functools
    import asyncio
    import tornado.testing
    import tornado.gen
    import tornado.testing
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.web
    import tornado.httpserver
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.httpclient
    import tornado.gen
    import tornado.ioloop
    import tornado.httpclient
    import tornado.platform.asyncio
    import tornado.httputil

    # Create localhost server

# Generated at 2022-06-22 15:54:32.197860
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.iostream import StreamClosedError

    @gen.coroutine
    def _connect(af : socket.AddressFamily, address: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        future = to_asyncio_future(Future())
        def callback():
            future.set_result(gen_test.mock_stream())
            IOLoop.current().add_callback(lambda: gen_test.LoggingCallback("callback")())
        IOLoop.current().call_later(0, callback)
        return (gen_test.mock_stream(), future)

    # Test to check if the on_connect_done method is called when the connection is successfull


# Generated at 2022-06-22 15:54:36.387772
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import pytest

    # Mock
    class IOStreamMock(object):
        def close(self):
            pass

    class FutureMock(object):
        def result(self):
            pass

    class AddrinfoMock(object):
        def next(self):
            pass

    class IOLoopMock(object):
        def time(self):
            pass

        def remove_timeout(self, timeout):
            pass

    io_loop = IOLoopMock()
    stream_mock = IOStreamMock()
    future_mock = FutureMock()
    addrs_mock = AddrinfoMock()
    af = None
    addr = None
    timeout = None
    future = None

    # Creation of the _Connector object with mocked objects
    connector = _Connector(None, None)

# Generated at 2022-06-22 15:54:46.834561
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import socket
    from random import randint
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver

    addrinfo = [
        (1, (1, 2)),
        (2, (2, 3))
    ]

    def connect(af, addr):
        if af == 1: 
            if addr == (1, 2): 
                raise Exception("Error")
            else: 
                stream = IOStream(socket.socket())
                future = Future()
                future.set_result(stream)
                return stream, future
        else:
            stream = IOStream(socket.socket())
            future = Future()
            future.set_result(stream)
            return stream, future


# Generated at 2022-06-22 15:54:57.734193
# Unit test for constructor of class _Connector
def test__Connector():
    result_create_connector = [False]
    result_create_stream = [False]
    def create_connector(
        af: socket.AddressFamily,
        addr: Tuple,
    ) -> Tuple[IOStream, "Future[IOStream]"]:
        result_create_connector[0] = True
        return create_stream(af, addr)

    def create_stream(
        af: socket.AddressFamily,
        addr: Tuple,
    ) -> Tuple["IOStream", "Future[IOStream]"]:
        if result[0] == 0:
            result_create_stream[0] = True
        return IOStream(socket.socket(af=af, type=socket.SOCK_STREAM)), Future()

    result = [0]

# Generated at 2022-06-22 15:55:26.141836
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    result = []  # type: List[Any]
    class _fd:
        fileno = 5
    class _fd2:
        fileno = 6
    class _fd3:
        fileno = 7
    class _socket:
        def __init__(self, fd):
            super().__init__()
            self.fd = fd
            self.timeout = 0
        def fileno(self):
            return self.fd.fileno()
    class _stream:
        closed = False
        def __init__(self, io_loop: IOLoop, socket: _socket):
            self.io_loop = io_loop
            self.socket = socket
        def close(self):
            self.closed = True
    def _connect(af, addr):
        if af == socket.AF_INET:
            stream

# Generated at 2022-06-22 15:55:37.465765
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    def connect(self, af, addr):
        """Connect to the given address.

        Returns a pair (stream, future).  The stream is returned immediately
        as it may be needed before the connection has completed.  The future
        is a ``Future`` that is triggered when the connection is established.
        """
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM), True)
        future = Future()

        def on_connect():
            """Called when the connect() call finishes."""
            if (
                stream.socket is None
                or stream.socket.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR) != 0
            ):
                # Connection has failed.
                future.set_exception(IOError("Connect call failed"))
            else:
                future.set_result(stream)



# Generated at 2022-06-22 15:55:45.943847
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import pytest
    from mock import patch
    from tornado.iostream import _IOStreamClosedException
    _connector=_Connector([], None)
    mock_stream=patch('tornado.netutil.Connector._Connector.streams',
                      _connector.streams).start()
    mock_stream.close=patch('tornado.iostream.IOStream.close',
                            side_effect=_IOStreamClosedException()).start()
    _connector.close_streams()
    assert mock_stream.close.called
    patch.stopall()
    mock_stream=patch('tornado.netutil.Connector._Connector.streams',
                      _connector.streams).start()

# Generated at 2022-06-22 15:55:54.701481
# Unit test for constructor of class _Connector
def test__Connector():
    addrinfo = [(0, ("8.8.8.8", 8888))]
    def connect(af, addr):
        pass
    connector = _Connector(addrinfo, connect)
    assert connector.io_loop == IOLoop.current()
    assert connector.primary_addrs == addrinfo
    assert connector.secondary_addrs == []
    assert connector.connect == connect
    assert isinstance(connector.future, Future)
    assert connector.timeout is None
    assert connector.connect_timeout is None

_MAX_WAIT_SECONDS_AFTER_SHUTDOWN = 5



# Generated at 2022-06-22 15:56:02.243438
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import tornado.testing
    import tornado.gen
    import tornado.httpclient

    class _ConnectorTestCase(tornado.testing.AsyncTestCase):
        def test_set_connect_timeout(self):
            def f():
                raise IOError  # unreachable server

            fut = tornado.gen.Future()
            fut.set_result(Future())
            conn = _Connector(
                None, lambda af, addr: (IOStream(socket.socket()), fut)
            )
            conn.set_connect_timeout(0.1)
            conn.try_connect(iter([(None, None)]))
            with self.assertRaises(IOError):
                conn.future.result()

    tornado.testing.main()



# Generated at 2022-06-22 15:56:06.865526
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import signal
    import time
    import tornado.ioloop
    from tornado.httpclient import HTTPRequest, HTTPClient

    signal.signal(signal.SIGINT, lambda *args, **kwargs: None)

    @gen.coroutine
    def main():
        http_client = HTTPClient()
        request = HTTPRequest("https://www.google.com/")
        response = yield http_client.fetch(request)
        print(response.code)

    tornado.ioloop.IOLoop.current().run_sync(main)



# Generated at 2022-06-22 15:56:10.202023
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # __Connector.close_streams(self) -> None
    # Close all pending connections.
    # This is done automatically when the result is available, but
    # may be called earlier if an error is known.
    _Connector.close_streams()



# Generated at 2022-06-22 15:56:11.360410
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    return TCPClient().connect(host = "127.0.0.1", port = 80)

# Generated at 2022-06-22 15:56:17.681193
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    """ test_connector_clear_timeouts"""
    connector = _Connector([], lambda x, y: (None, None))
    connector.clear_timeouts()
    connector.future.set_result((None, None, None))
    connector.future.set_exception(TimeoutError())
    connector.close_streams()

# Generated at 2022-06-22 15:56:27.887887
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Test how the function works normally
    addrinfo = [(socket.AF_INET, ("192.168.1.1", 8080)),
                (socket.AF_INET, ("192.168.1.2", 8080))]
    def connect(af, addr):
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), None
    def on_connect_done(addrs, af, addr, future):
        if future.done():
            print('connection failed')
        else:
            print('connected to ' + str(addr))
    connector = _Connector(addrinfo, connect)
    connector.try_connect(iter(connector.primary_addrs))
    connector.on_connect_done(None, socket.AF_INET, ("192.168.1.2", 8080), None)

   

# Generated at 2022-06-22 15:56:59.998601
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    _connector = _Connector(addrinfo=[], connect=lambda x,y: (None, None))
    _connector.timeout = 1
    _connector.io_loop = IOLoop.current()
    _connector.clear_timeout()
    return



# Generated at 2022-06-22 15:57:12.037364
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.gen import convert_yielded
    from tornado.testing import bind_unused_port, AsyncTestCase
    from tornado import ioloop
    import os

    class _ConnectorTest(AsyncTestCase):

        def test_start(self):

            def connect(af, addr):
                stream = socket.socket(af)
                stream.setblocking(False)
                self.io_loop.add_callback(stream.connect, addr)
                f = Future()

                def on_connect(fd, events):
                    f.set_result(stream)
                    self.io_loop.remove_handler(stream)

                self.io_loop.add_handler(stream, on_connect, self.io_loop.ERROR)
                return stream, f
            port = bind_unused_port()[1]

# Generated at 2022-06-22 15:57:13.086252
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    _Connector.on_connect_timeout()



# Generated at 2022-06-22 15:57:18.624875
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # Set up the _Connector instance
    io_loop = IOLoop.current()
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", None)),
    ]
    def _connect(af, addr):
        return IOStream(socket.socket(), io_loop=io_loop), Future()
    connector = _Connector(addrinfo, _connect)
    stream, future = connector.connect(socket.AF_INET, ("127.0.0.1", None))
    connector.streams.add(stream)

    # Now call close_streams
    connector.close_streams()

    # Ensure that the stream is closed
    assert stream.closed()



# Generated at 2022-06-22 15:57:27.131588
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    
    # Given
    addrs = iter([(socket.AddressFamily.AF_INET, (1,2)), (socket.AddressFamily.AF_INET, (3,4))])  # type: Iterator[Tuple[socket.AddressFamily, Tuple]]
    af = socket.AddressFamily.AF_INET
    addr = (1,2)
    future = Future()
    future.set_exception(IOError("An error"))
    connect = functools.partial(
        (lambda x,y: (IOStream(socket.socket(x, socket.SOCK_STREAM)), Future())))
    connector = _Connector(addrs,connect)
    
    # When
    connector.on_connect_done(addrs,af,addr,future)
    
    # Then
    assert(connector.future.done())

# Generated at 2022-06-22 15:57:38.906782
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # Test that calls to close_streams set the stream to closed, and optionally call callbacks
    import unittest
    from io import BytesIO
    from io import StringIO
    import os

    # Test that the close_streams function works as expected
    class _DummyStream(object):
        pass
    a = _DummyStream()
    a.closed = False
    b = _DummyStream()
    b.closed = False
    c = _DummyStream()
    c.closed = False
    conn = _Connector(None, None)
    conn.streams.add(a)
    conn.streams.add(b)
    conn.streams.add(c)
    conn.close_streams()
    assert(a.closed == True)
    assert(b.closed == True)

# Generated at 2022-06-22 15:57:52.037179
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import os
    import json
    import sys
    import random
    import base64
    import datetime
    import time
    import types
    
    
    
    from tornado.util import PY3
    from tornado.testing import AsyncTestCase, bind_unused_port, ExpectLog
    from tornado.test.util import unittest, skipIfNonUnix, skipOnTravis
    from tornado.concurrent import Future
    from tornado.tcpserver import TCPServer
    from tornado.netutil import bind_sockets, add_accept_handler
    from tornado.iostream import IOStream
    from tornado.ioloop import IOLoop
    
    
    
    class MyTCPServer(TCPServer):
    
        def handle_stream(self, stream, address):
            stream.close()
    
    
    


# Generated at 2022-06-22 15:58:02.104832
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    from tornado import testing
    from tornado.gen import coroutine
    from tornado.iostream import StreamClosedError
    _Connector_obj = _Connector([], lambda x, y: None)
    _Connector_obj.future = testing.gen_test(coroutine(lambda: None))
    _Connector_obj.streams = set()
    _Connector_obj.streams.add(testing.gen_test(coroutine(lambda: None)))
    _Connector_obj.on_connect_timeout()
    assert isinstance(_Connector_obj.future.exception(), TimeoutError)
    test_flag = False
    try:
        _Connector_obj.streams.pop().close()
    except StreamClosedError:
        test_flag = True
    assert test_flag


# Generated at 2022-06-22 15:58:03.459801
# Unit test for method start of class _Connector
def test__Connector_start():
    conn = _Connector(connect=False)
    conn.start()


# Generated at 2022-06-22 15:58:15.834509
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    """
    In this test, we set up a mock resolver that returns two addresses
    and cancels the resolution.  We then run _Connector.start and cancel
    the resolution.  This exercises the case where _Connector.start
    calls back on the future before any of the addresses begin
    connecting, and the case where it does so after the first address
    has connected.
    """
    ioloop = IOLoop()

    def connect(af: socket.AddressFamily, addr: Tuple[str, int]) -> Tuple[None, None]:
        return None, None

    def on_connect(future: "Future[IOStream]") -> None:
        assert not future.done()
        future.set_exception(gen.TimeoutError())


# Generated at 2022-06-22 15:59:36.767433
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.iostream import IOStream
    from tornado.ioloop import IOLoop
    import socket
    import unittest
    import mock

    class TestConnetor(unittest.TestCase):
        def setUp(self):
            self.connector = _Connector([("AF_INET",("127.0.0.1",8888))],self.connect)
        def connect(self,af,addr):
            return (IOStream(socket.socket(af,socket.SOCK_STREAM,0)), Future())

    conn = TestConnetor()
    conn.setUp()
    conn.connector.start()
    conn.assertEqual(len(conn.connector.primary_addrs), 1)
    conn.assertEqual(len(conn.connector.secondary_addrs), 0)
    conn

# Generated at 2022-06-22 15:59:42.200883
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    from tornado.testing import AsyncTestCase, gen_test
    class MyTestCase(AsyncTestCase):
        @gen_test
        def test_TCPClient_connect(self):
            tc = TCPClient()
            stream = yield tc.connect('www.google.com', 80)
            stream.close()
            tc.close()
    MyTestCase().test_TCPClient_connect()

# Generated at 2022-06-22 15:59:43.097926
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    pass


# Generated at 2022-06-22 15:59:49.829659
# Unit test for method start of class _Connector
def test__Connector_start():
    import pytest
    from tornado.netutil import Resolver
    import socket
    import ssl
    import socket
    import ssl
    import pytest
    from tornado.netutil import Resolver
    import socket
    import ssl
    import socket

    def test__Connector_start():
        import socket
        import ssl
        import socket
        import ssl
        import socket
        import ssl
        import socket
        import ssl
        import socket
        import ssl
        import socket
        import ssl
        import socket
        import ssl
        import socket
        import ssl
        import socket
        import ssl
        import socket
        import ssl
        import socket
        import ssl
        import socket
        import ssl
        import socket
        import ssl
        from tornado.concurrent import Future

# Generated at 2022-06-22 15:59:58.980679
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Test that clear_timeouts removes all timeouts, even if on_timeout
    # was called while we were inside the method.

    # _Connector.clear_timeouts(self) -> None

    # _Connector.close_streams(self) -> None
    stream = IOStream(socket.socket())
    connecter = _Connector(
        [(socket.AF_INET, ("localhost", 80))],
        lambda af, addr: (stream, gen.maybe_future(stream)),
    )

    def on_timeout(cls):
        # _Connector.on_timeout() -> None
        cls.timeout = None
        cls.streams.add(IOStream(socket.socket()))
        cls.streams.add(IOStream(socket.socket()))

# Generated at 2022-06-22 16:00:10.427310
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # Create socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    # Bind the socket to the port
    server_address = ("localhost", 10000)
    s.bind(server_address)
    # Listen for incoming connections
    s.listen(1)
    # Accept connection
    connection, client_address = s.accept()
    # Create an IOStream with the connection
    stream = IOStream(connection)
    # Create the connector
    c = _Connector([(socket.AF_INET, ("localhost", 10000))], lambda a, b: (stream, Future()))
    # Close the stream
    c.close_streams()
    # Test if client has closed the connection

# Generated at 2022-06-22 16:00:21.312848
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 0)), (socket.AF_INET, ("127.0.0.2", 0))]

    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()

    connector = _Connector(addrinfo, connect)
    addrs = iter(connector.primary_addrs)
    future = Future()
    future.set_exception(TimeoutError())
    connector.on_connect_done(addrs, socket.AF_INET, ("127.0.0.1", 0), future)
    connector.future.result()



# Generated at 2022-06-22 16:00:32.913046
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    class dummy_io_loop():
        def __init__(self, test) -> None:
            self.test = test
            self.calls = 0

        def time(self) -> float:
            return 0.0

        def add_timeout(self, time: float, callback: Callable[[], None]) -> object:
            self.calls += 1
            self.test.assertIsInstance(time, numbers.Real)
            self.test.assertGreaterEqual(time, 0.0)
            self.test.assertIs(callback, self.on_timeout)
            return self.calls

        def remove_timeout(self, handle: object) -> None:
            self.test.assertIsNotNone(self.timeout)
            self.test.assertIsInstance(handle, numbers.Real)
            self.test.assertEqual

# Generated at 2022-06-22 16:00:42.209258
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    from tornado import ioloop
    from tornado import testing
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio

    conn = _Connector([], lambda af, addr: (object(), None))

    loop = ioloop.IOLoop.current()
    @gen.coroutine
    def f() -> None:
        def g(future) -> None:
            import tornado
            conn.clear_timeouts()
            conn.close_streams()
            loop.stop()
        future = to_asyncio_future(conn.start(timeout=0.1))
        future.add_done_callback(g)
        yield
        yield tornado.gen.sleep(0.2)
        loop.stop()
    loop.add_callback(f)
    loop.start()



# Generated at 2022-06-22 16:00:52.567838
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():

    class _MockType:
        def __init__(self) -> None:
            self.removed_timeouts = []  # type: List[int]

        def remove_timeout(self, timeout: int) -> None:
            self.removed_timeouts.append(timeout)

    obj = _Connector([(0, ())], lambda af, addr: (None, None))
    obj.timeout = 10
    obj.connect_timeout = 15
    obj.io_loop = _MockType()

    # removal of timeouts called
    obj.clear_timeouts()
    assert obj.io_loop.removed_timeouts == [10, 15]



# Generated at 2022-06-22 16:01:46.910231
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    af = 1
    addr = ()
    addrs = []
    future = Future()
    future.set_result("success")
    object = _Connector(addrs, 'connect')
    object.future = Future()
    object.remaining = 0
    object.streams = set()
    object.on_connect_done(addrs, af, addr, future)
    # object.on_connect_done(addrs, af, addr, future)

# Generated at 2022-06-22 16:01:57.273270
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.platform.auto import set_close_exec
    from tornado.platform.select import SelectIOLoop
    from tornado.tcpclient import _Connector
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado import gen
    from typing import Any, Union, Tuple, Callable, List
    import socket
    import ssl

    ####################################################################
    # @gen.coroutine
    def create_stream_connected(
        af: socket.AddressFamily, addr: Tuple
    ) -> Tuple[IOStream, "Future[IOStream]"]:
        fd = socket.socket(af, socket.SOCK_STREAM)
        set_close_exec(fd.fileno())
        fd.setblocking(False)
        fd.connect_ex(addr)
        stream = IO

# Generated at 2022-06-22 16:02:05.503942
# Unit test for method start of class _Connector
def test__Connector_start():
    pass

_client_factory = None  # type: Optional[TCPClient]
_resolver = None  # type: Optional[Resolver]
_ssl_options = None  # type: Optional[Dict[str, Any]]
_default_bind_host = None  # type: Optional[str]
_default_server_hostname = None  # type: Optional[str]
_global_ssl_options = {
    "ssl_options": dict(cert_reqs=ssl.CERT_REQUIRED, ca_certs="/etc/ssl/certs/ca-certificates.crt")
}



# Generated at 2022-06-22 16:02:13.905110
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    streams_list = [
        IOStream(socket.socket()),
        IOStream(socket.socket(), io_loop=IOLoop.current()),
        IOStream(socket.socket()),
    ]
    _Connector(None, test__Connector_close_streams).streams = set(streams_list)
    _Connector(None, test__Connector_close_streams).close_streams()
    for stream in streams_list:
        assert stream.closed()



# Generated at 2022-06-22 16:02:21.730796
# Unit test for method start of class _Connector
def test__Connector_start():
    import tornado.testing

    import socket


    class ConnectorTest(tornado.testing.AsyncHTTPTestCase):
        @tornado.gen.coroutine
        def get_app(self):
            # type: () -> Any
            return tornado.web.Application()

        def test_connect(self):
            # type: () -> None
            def connect(
                af,
                addr,
            ):
                # type: (socket.AddressFamily, Tuple[str, int]) -> Tuple[IOStream, Future[IOStream]]
                sock = socket.socket(af)
                stream = IOStream(sock, io_loop=self.io_loop)
                stream.connect(addr, callback=self.stop)
                return stream, Future()

            # AF_INET6 first, because it will probably time out first.
            addrinfo

# Generated at 2022-06-22 16:02:26.381271
# Unit test for method start of class _Connector
def test__Connector_start():

    # 1. method start in class _Connector
    #
    #     def start(self,
    #             timeout=_INITIAL_CONNECT_TIMEOUT,
    #             connect_timeout=None):
    #         self.try_connect(iter(self.primary_addrs))
    #         self.set_timeout(timeout)
    #         if connect_timeout is not None:
    #             self.set_connect_timeout(connect_timeout)
    #         return self.future

    # The following code is to set up the environment before calling the method start
    _Connector_instance = _Connector(
        addrinfo,
        connect,
    )
    try:
        _Connector_instance.start(timeout, connect_timeout)
    except TimeoutError as e:
        # Exception happens, could not connect to the address.
        pass

# Generated at 2022-06-22 16:02:33.604115
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.httpclient import HTTPClient
    from tornado.testing import AsyncHTTPTestCase, AsyncHTTPSTestCase, gen_test
    import certifi

    class HelloHandler(RequestHandler):
        def get(self):
            self.write('Hello world')

    class HelloServer(AsyncHTTPTestCase):
        def get_app(self):
            return Application([('/', HelloHandler)])
        
        @gen_test
        def test(self):
            client = HTTPClient()
            response = yield client.fetch(self.get_url('/'))
            self.assertEqual(response.code, 200)
            self.assertEqual(response.body, b'Hello world')
            
            # test ipv4

# Generated at 2022-06-22 16:02:41.850746
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    resolver = Resolver()
    client = TCPClient(resolver=resolver)
    timeout = 0.01
    host = "www.example.com"
    port = 80
    future = client.connect(host, port, timeout=timeout)
    result = IOLoop.current().run_sync(future)
    print(result.socket)
    print(result.socket.family)
    print(result.socket.type)
    print(result.socket.proto)
    print(result.socket.getsockname())
    print(result.socket.getpeername())
    assert(result is not None)

# Generated at 2022-06-22 16:02:50.364293
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    print("TCPClient connect:")
    client = TCPClient()
    async def f():
        try:
            await client.connect("www.google.com", 8888)
        except TimeoutError:
            print("Timeout!")
        except:
            print("Error!")
    f()
test_TCPClient_connect()

if __name__ == "__main__":
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import asyncio
    asyncio.get_event_loop().run_until_complete(test_TCPClient_connect())

# Generated at 2022-06-22 16:02:54.182561
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import asyncio
    async def do_test():
        client = TCPClient()
        stream = await client.connect('127.0.0.1', 80)
        print(stream)

    loop = asyncio.get_event_loop()
    loop.run_until_complete(do_test())