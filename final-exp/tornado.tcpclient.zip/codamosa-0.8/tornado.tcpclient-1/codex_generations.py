

# Generated at 2022-06-22 15:53:39.225683
# Unit test for constructor of class _Connector
def test__Connector():
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        io_loop = IOLoop.current()
        sock = socket.socket(af, socket.SOCK_STREAM, 0)
        sock.setblocking(0)
        stream = IOStream(sock, io_loop=io_loop)
        f = gen.Future()  # type: Future[IOStream]
        stream.connect(
            addr,
            lambda: f.set_result(stream),
        )
        return stream, f


    resolver = Resolver()
    # Success (AF_INET)
    addrinfo = resolver.resolve("www.google.com", 80)  # type: ignore
    assert isinstance(addrinfo[0][0], numbers.Integral)


# Generated at 2022-06-22 15:53:40.176551
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    assert False # TODO: implement your test here



# Generated at 2022-06-22 15:53:50.986609
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import socket
    import ssl
    from tornado.concurrent import Future
    from tornado.gen import TimeoutError
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.test.util import unittest, skipIfNonUnix
    from concurrent.futures.thread import ThreadPoolExecutor
    import tornado.testing
    import asyncio
    import random

    # pylint: disable=not-callable,no-member,undefined-variable
    from tornado.netutil import dns_resolve
    from tornado.testing import AsyncTestCase, get_unused_port
    from tornado.util import Configurable, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop

   

# Generated at 2022-06-22 15:53:51.620617
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    pass

# Generated at 2022-06-22 15:53:54.440260
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # Constructor
    global con
    con = _Connector([(21, (1,2))], [])
    con.clear_timeout()


# Generated at 2022-06-22 15:53:56.998380
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
	connector = _Connector([], None)
	connector.set_timeout(1)
	assert connector.timeout is not None


# Generated at 2022-06-22 15:54:03.874445
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    # Test that method set_connect_timeout of class _Connector raises exception when the given argument is not a number
    # Arrange
    def connect(af:socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, Future[IOStream]]:
        return None

    # Act
    assert_raises(TypeError, _Connector, [], connect.__call__)

# Generated at 2022-06-22 15:54:08.759759
# Unit test for method start of class _Connector
def test__Connector_start():
    # Arrange
    connect = lambda *args: (None, None)
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80))]
    connector = _Connector(addrinfo, connect)
    # Act
    future = connector.start()
    # Assert
    assert future is not None



# Generated at 2022-06-22 15:54:21.372665
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # Test for method close_streams(self)
    class MyClass:
        def __init__(self):
            self.closed = False
        def close(self):
            self.closed = True
    class MockIOStream(object):
        def __init__(self, sock: Any, io_loop: IOLoop, max_buffer_size: int,
                     read_chunk_size: int, timeout: Optional[Union[float, datetime.timedelta]]) -> None:
            pass
        def set_close_callback(self, callback: Optional[Callable]) -> None:
            pass

# Generated at 2022-06-22 15:54:29.242509
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    from tornado import testing
    def f() -> None:
        return
    io_loop: IOLoop = testing.IOLoopTestCase.get_new_ioloop()
    connector = _Connector([], f)
    connector.io_loop = io_loop
    # Method set_timeout of class _Connector
    connector.set_timeout(0.1)
    futures = connector.io_loop.run_sync(lambda: connector.future)
    str(futures)
    io_loop.close()


# Generated at 2022-06-22 15:54:57.042290
# Unit test for constructor of class _Connector

# Generated at 2022-06-22 15:55:00.483364
# Unit test for method start of class _Connector
def test__Connector_start():
    # Given
    _Connector.try_connect = MagicMock()
    _Connector.set_timeout = MagicMock()
    _Connector.set_connect_timeout = MagicMock()
    connector = _Connector(["a", "b", "c"], "connect")
    # When
    connector.start()
    # Then
    pass



# Generated at 2022-06-22 15:55:13.305263
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():

    t1 = datetime.datetime(2016, 11, 18, 15, 10, 10)
    t2 = datetime.datetime(2016, 11, 18, 15, 10, 40)

    ioloop = IOLoop(make_current=False)
    ioloop._time_func = lambda: t1.timestamp()
    result = []  # type: List[datetime.datetime]
    ioloop.add_timeout = result.append  # type: ignore
    addrinfo = [(socket.AF_INET, ("name", 80))]
    connector = _Connector(addrinfo, connect=lambda af, addr: (None, Future()))
    connector.io_loop = ioloop
    connector.set_timeout(30)
    assert result[0] == t2
    # Unit test for method on_timeout of class

# Generated at 2022-06-22 15:55:21.942565
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    connector = _Connector([], lambda af, addr: (None, None))
    assert connector.timeout is None
    assert connector.connect_timeout is None

    # Test timeout
    timeout = object()
    connector.timeout = timeout
    connector.clear_timeout()
    assert connector.timeout is None
    assert connector.connect_timeout is None

    # Test connect_timeout
    connect_timeout = object()
    connector.connect_timeout = connect_timeout
    connector.clear_timeout()
    assert connector.timeout is None
    assert connector.connect_timeout is None

# Generated at 2022-06-22 15:55:29.547833
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    class FakeStream(object):
        def __init__(self):
            self.close_called = False
        def close(self):
            self.close_called = True

    streams = [FakeStream() for _ in range(3)]
    connector = _Connector([], lambda family, address: (None, Future()))
    connector.streams = set(streams)
    connector.close_streams()
    for stream in streams:
        assert stream.close_called



# Generated at 2022-06-22 15:55:41.214608
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # Case-1, we set two timeouts, timeout and connect_timeout
    # we add them in, but remove them in between
    c = _Connector(
        [(socket.AF_INET, ('8.8.8.8', 53))],
        connect=lambda af, addr: (IOStream(), Future()),
    )
    c.set_timeout(1)
    assert c.timeout is not None
    c.timeout = None
    assert c.timeout is None
    c.set_connect_timeout(1)
    assert c.connect_timeout is not None
    c.connect_timeout = None
    assert c.connect_timeout is None

    # Case-2, we remove them one by one
    # when you remove only one of them, it removes the other one
    # When you remove both of them, it doesn't remove anything


# Generated at 2022-06-22 15:55:47.481627
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest.mock as mock
    import tornado.testing as testing
    with mock.patch("tornado.ioloop.IOLoop") as IOLoop:
        ioloop = IOLoop.current.return_value = IOLoop = mock.MagicMock()
        connect = mock.Mock()
        addrs = [(1, object()), (2, object())]
        primary_addrs, secondary_addrs = [(1, object())], [(2, object())]
        connect.side_effect = [
            (mock.Mock(), mock.MagicMock()),
            (mock.Mock(), mock.MagicMock()),
            (mock.Mock(), mock.MagicMock()),
        ]
        future = mock.MagicMock()
        future.done.return_value = False
       

# Generated at 2022-06-22 15:55:56.795055
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Create a mock IOStream
    stream = IOStream()

    # Create a mock Future
    future = Future()

    # Create a mock IOLoop
    ioloop = IOLoop()

    # Create an instance of class Connector
    connector = _Connector([(socket.AF_INET, ("localhost", 8080))], None)

    # Set an attribute of the instance of Connector
    connector.future = future
    connector.streams = set([stream])
    connector.io_loop = ioloop

    # Call the on_connect_timeout method of class Connector
    connector.on_connect_timeout()

    # Assert that
    assert future._done == True



# Generated at 2022-06-22 15:56:09.362551
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    addrinfo = [(socket.AF_INET, ('0.0.0.0', 80)), (socket.AF_INET6, ('::', 80))]
    resolver = Resolver()
    socket_family = socket.AF_INET6

    io_loop = IOLoop.current()
    resolver.configure(io_loop=io_loop)
    resolver.resolve("::", socket_family)

    def on_connect(
        af: socket.AddressFamily,
        addr: Tuple,
    ) -> Tuple[IOStream, Future[IOStream]]:
        future = Future()
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), future

    connector = _Connector(addrinfo, on_connect)
    timeout = 0.3

# Generated at 2022-06-22 15:56:15.672713
# Unit test for method split of class _Connector
def test__Connector_split():
    import pytest
    from tornado.netutil import Resolver
    from tornado.iostream import IOStream
    from tornado.tcpserver import TCPServer
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio

    # Tornado requires us to create the event loop in asyncio
    # loop = asyncio.new_event_loop()
    # asyncio.set_event_loop(loop)
    loop = asyncio.get_event_loop()


# Generated at 2022-06-22 15:56:46.395492
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # clear_timeout() should clear a timeout regardless of whether
    # it was created with timeout = None or timeout = 0.
    connector = _Connector([], lambda af, addr: (None, Future()))
    connector.set_timeout(None)
    connector.try_connect(iter([(socket.AF_INET6, ())]))
    assert connector.timeout is not None
    connector.clear_timeout()
    assert connector.timeout is None
    connector.set_timeout(0)
    connector.try_connect(iter([(socket.AF_INET6, ())]))
    assert connector.timeout is not None
    connector.clear_timeout()
    assert connector.timeout is None



# Generated at 2022-06-22 15:56:51.268146
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    # Test that calling connect with the default is ok.
    # Create the client
    client = TCPClient()
    # Connect to the server
    stream = client.connect("127.0.0.1", 8888)
    # Assert that the returned object is a IOStream
    assert isinstance(stream, IOStream), "Returned object is not a IOStream"

# Generated at 2022-06-22 15:56:59.106421
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import tornado.iostream
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    ioloop = IOLoop()

    class DummyStream(tornado.iostream.IOStream):
        def __init__(self):
            self.closed = False

        def close(self):
            self.closed = True

    stream1 = DummyStream()
    stream2 = DummyStream()
    future = Future()

    _connector = _Connector(
        [],
        lambda af, addr: (stream1, future),
    )
    _connector.io_loop = ioloop
    _connector.future = future
    _connector.streams = set()
    _connector.streams.add(stream1)
    _connector.streams.add(stream2)


# Generated at 2022-06-22 15:57:11.183983
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():

    def mock_try_connect(addrs: Iterator[Tuple[socket.AddressFamily, Tuple]]) -> None:
        assert addrs == iter(list())

    # IOError
    class MockFuture:
        def __init__(self, result: bool = False) -> None:
            self.result_called = False
            self.result = result

        def result(self) -> bool:
            self.result_called = True
            return self.result

    mock_f = MockFuture(True)
    mock_c = _Connector(
        list(),
        connect=lambda x, y: tuple([None, mock_f]),
    )
    mock_c.try_connect = mock_try_connect
    mock_c.future = Future()

# Generated at 2022-06-22 15:57:13.035685
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    # TODO: Implement test for method connect of class TCPClient
    assert False, "Test not implemented"

# Generated at 2022-06-22 15:57:22.750905
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    def start_io_loop(io_loop):
        io_loop.add_callback(functools.partial(start_tcp_client, io_loop))
        io_loop.start()

    def start_tcp_client(io_loop):
        kwargs = {"ssl_options": {'cert_reqs': ssl.CERT_NONE, 'check_hostname': False},
                  "timeout": 2}
        c = TCPClient()
        io_loop.add_callback(functools.partial(connect, c))

    def connect(c):
        print(c.connect("localhost", 9998, **kwargs))

    if __name__ == '__main__':
        io_loop = IOLoop.current()
        start_io_loop(io_loop)

# Generated at 2022-06-22 15:57:24.497968
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    obj = _Connector([], lambda af, addr: (None, None))
    obj.clear_timeout()
    assert obj.timeout is None



# Generated at 2022-06-22 15:57:37.626278
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unit_test_helper; unit_test_helper.fix_module_search_paths()
    from mock import patch, Mock, call
    from tornado.ioloop import IOLoop
    from io import RawIOBase
    from typing import Any
    from typing import Dict
    from typing import Tuple
    from typing import List
    from typing import Union
    from typing import Callable
    from typing import Iterator
    from typing import Optional
    from typing import Set

    def mocked_get_event_loop():
        return event_loop
    mocked_connect = Mock(return_value=(stream, future))
    addrinfo = [(socket.AF_INET, ("query", 8080)), (socket.AF_INET6, ("query", 8080))]
    _Connector(addrinfo, mocked_connect).close_streams()
   

# Generated at 2022-06-22 15:57:38.257084
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    pass



# Generated at 2022-06-22 15:57:42.967011
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    print('test__Connector_on_connect_done begin')
    def connect(af: socket.AddressFamily, addr: Any) -> IOStream:
        sock = socket.socket()
        stream = IOStream(sock)
        stream.connect(addr, callback=lambda *args, **kwargs: None)
        future = stream._connect_future
        return stream, future

    io_loop = IOLoop.current()
    connector = _Connector([(socket.AF_INET, ('localhost', 8888))], connect)
    connector.start()
    io_loop.start()

    print('test__Connector_on_connect_done end')


# Generated at 2022-06-22 15:58:00.068408
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    pass

# Generated at 2022-06-22 15:58:10.050643
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    from unittest import mock

    class Fake_Future(Future):
        def __init__(self):
            super().__init__()

    class Fake_IOStream(IOStream):
        def __init__(self):
            super().__init__(mock.MagicMock(), mock.MagicMock())

    c = _Connector(
        [], lambda _: (Fake_IOStream(), Fake_Future())
    )
    _stream = Fake_IOStream()
    c.streams = [_stream]
    c.close_streams()
    _stream.close.assert_called()



# Generated at 2022-06-22 15:58:11.209333
# Unit test for method start of class _Connector
def test__Connector_start():
    pass


# Generated at 2022-06-22 15:58:17.755873
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    timeout = _INITIAL_CONNECT_TIMEOUT
    resolver = Resolver(IOLoop.current())
    connect = resolver.resolve
    addrinfo = list(resolver.gethostbyname("localhost", 8080))
    connector = _Connector(addrinfo, connect)
    connector.start(timeout=1)
    # print(f"Pick: {list(addrinfo)[0]}")


# Generated at 2022-06-22 15:58:29.845925
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    test_input =  [
        ([], Future()), 
        ([("af1", "addr1"), ("af2", "addr2")], Future()), 
        ([("af1", "addr1")], Future()), 
        ([("af1", "addr1"), ("af2", "addr2"), ("af3", "addr3")], Future())
    ]
    class Dummy_connect: 
        def __init__(self, args): 
            res, self.future = args
            self.next_idx = 0
            self.res = res
        
        def __call__(self, af, addr): 
            stream = Dummy_stream()
            self.future = Future()
            self.future.set_result(stream)
            return stream, self.future


# Generated at 2022-06-22 15:58:31.991942
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    connector = _Connector([(1,2),(3,4)], None)
    try:
        connector.try_connect(None)
        assert False
    except Exception as e:
        assert type(e) == TypeError
    assert True



# Generated at 2022-06-22 15:58:43.088413
# Unit test for method start of class _Connector
def test__Connector_start():

    # test with normal values
    from tornado.iostream import IOStream
    from tornado.netutil import bind_sockets

    def test_connect(af, addr):
        s = socket.socket(af, socket.SOCK_STREAM)
        s.setblocking(False)
        stream = IOStream(s)
        future = stream.connect(addr)
        return stream, future

    res = Resolver()
    fut = res.resolve("www.facebook.com", 80)
    obj = _Connector(fut.result(), test_connect)
    f1 = obj.start()
    print(f1.result())

    # test with empty port
    def test_connect1(af, addr):
        s = socket.socket(af, socket.SOCK_STREAM)
        s.setblocking(False)
        stream

# Generated at 2022-06-22 15:58:47.472521
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import pytest
    from tornado.iostream import StreamClosedError
    from .mock_iostream import MockIOStream
    from .mock_ioloop import MockIOLoop

    class MockFuture(object):
        def __init__(self):
            self.result_ = None
            self.exception_ = None

        def set_result(self, result):
            self.result_ = result

        def set_exception(self, exception):
            self.exception_ = exception

        def result(self):
            return self.result_

        def exception(self):
            return self.exception_

    # 1 CASE: None exception

# Generated at 2022-06-22 15:58:51.523182
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest.mock

    IOStream = unittest.mock.create_autospec(IOStream)
    _Connector(None, None).streams = [IOStream]*3
    _Connector(None, None).close_streams()
    IOStream.close.assert_has_calls([unittest.mock.call()]*3)



# Generated at 2022-06-22 15:59:00.460684
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import asyncio
    import functools
    import ipaddress

    async def try_connect(host, port, ssl_options=None,
                          timeout=1, max_buffer_size=102238):
        client = TCPClient()
        try:
            stream = await client.connect(host, port,
                                          ssl_options=ssl_options,
                                          timeout=timeout,
                                          max_buffer_size=max_buffer_size)
        except TimeoutError:
            return (False, None)
        else:
            return (True, stream)
        finally:
            client.close()

    # Test with a non-existent host
    host = "asdasdasdasdasd.com"
    port = 443
    ssl_options = None
    res = asyncio.get_

# Generated at 2022-06-22 15:59:44.141239
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # connect first and set result 
    connector = _Connector([(socket.AF_INET, ('127.0.0.1', 8000))], None)
    future = Future()
    IOStream = IOStream(None, None)
    future.set_result(IOStream)
    connector.on_connect_done(None, socket.AF_INET, ('127.0.0.1', 8000), future)
    assert connector.remaining == 0
    assert connector.future.done()
    assert not connector.timeout
    assert connector.streams == set()

    # connect second and set exception
    connector = _Connector([(socket.AF_INET, ('127.0.0.1', 8000))], None)
    future = Future()
    IOStream = IOStream(None, None)

# Generated at 2022-06-22 15:59:46.443904
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # Just to check that the method exists
    connector = _Connector([], lambda x, y: (None, None))
    connector.try_connect(None)

# Generated at 2022-06-22 15:59:56.911339
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    class a:
        pass
    obj1 = a()
    obj1.resolver = Resolver()
    obj1.resolver.close = lambda: None
    obj1.resolver.resolve = lambda host, port, af: (
        ((socket.AF_INET, ("192.168.0.2", 1234)),),
    )
    obj1.resolver.resolve = Resolver.resolve
    obj1._create_stream = lambda max_buff, af, addr, source_ip, source_port: (
        (
            IOStream(
                socket.socket(af),
                max_buffer_size=None,
            ),
            Future(),
        )
    )

# Generated at 2022-06-22 16:00:02.962351
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    from unittest import TestCase, mock

    class ClearTimeout(AsyncTestCase, TestCase):
        @mock.patch.object(_Connector, "clear_timeout", mock.Mock())
        @mock.patch.object(_Connector, "set_timeout", mock.Mock())
        @gen_test
        def test_clear_timeout(self):
            connector = _Connector([], mock.Mock())
            connector.set_timeout(0)
            result = yield connector.future
            self.assertIsNotNone(connector.timeout)
            self.assertEqual(connector.set_timeout.call_count, 1)
            self.assertEqual(connector.clear_timeout.call_count, 1)

    return ClearTimeout()


# Generated at 2022-06-22 16:00:14.051393
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    from tornado.ioloop import IOLoop
    with IOLoop.current() as io_loop:
        # Raw TCP
        stream = io_loop.run_sync(
            lambda: TCPClient().connect('github.com', 80, af=socket.AF_INET)
        )
        assert stream is not None
        stream.close()

        # Raw TCP with SSL (not actually SSL)
        stream = io_loop.run_sync(
            lambda: TCPClient().connect('github.com', 80, af=socket.AF_INET, ssl_options={})
        )
        assert stream is not None
        stream.close()

        # Raw TCP with SSL (SSL)

# Generated at 2022-06-22 16:00:20.554316
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    client = TCPClient()
    ioloop = IOLoop.current()
    async def main(host: str, port: int):
        try:
            stream = await client.connect(host, port)
        except Exception as e:
            print(e)

    ioloop.run_sync(functools.partial(main, "www.baidu.com", 80))

# Generated at 2022-06-22 16:00:29.274180
# Unit test for method start of class _Connector
def test__Connector_start():
    import unittest.mock
    _Connector.split = unittest.mock.MagicMock()
    start = unittest.mock.MagicMock()
    _Connector.start = start
    _Connector.clear_timeouts = unittest.mock.MagicMock()
    _Connector.close_streams = unittest.mock.MagicMock()

    with unittest.mock.patch('tornado.ioloop.IOLoop.current') as current:
        _Connector.__init__(addrinfo = [], connect=lambda self: [])


# Generated at 2022-06-22 16:00:35.978239
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # create a mock ioloop
    mock_loop = mock.Mock()

    # create a _Connector instance
    connector = _Connector(mock_loop, '1.1.1.1', 80, None, None, None, 2)
    connector.timeout = 1

    # call clear_timeout
    connector.clear_timeout()

    # check for remove timeout
    mock_loop.remove_timeout.assert_called_once_with(connector.timeout)


# Generated at 2022-06-22 16:00:41.274173
# Unit test for method start of class _Connector
def test__Connector_start():
    future_value = _Connector.start()
    if future_value is None:
        pass
    else:
        response = future_value.result()
        if isinstance(response, tuple):
            if len(response) == 3:
                response
            else:
                raise ValueError("was expecting the value of type tuple with length 3")
        else:
            raise ValueError("was expecting the value of type tuple with length 3")



# Generated at 2022-06-22 16:00:53.190456
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    def _testcase(
        host: str,
        port: Union[int, str],
        family: socket.AddressFamily,
        timeout: Optional[Union[int, float, datetime.timedelta]],
        connect_timeout: Optional[Union[int, float, datetime.timedelta]],
    ) -> "Future[Tuple[socket.AddressFamily, Any, IOStream]]":
        if isinstance(port, numbers.Integral):
            port = str(port)
