

# Generated at 2022-06-24 09:22:33.272499
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test Method set_timeout of class _Connector with parameter timeout = 0.3
    pass


# Generated at 2022-06-24 09:22:42.950295
# Unit test for method split of class _Connector
def test__Connector_split():
    # Test general case
    addrinfo1 = [(socket.AF_INET, socket.AF_INET), (socket.AF_INET6, socket.AF_INET6)]
    assert _Connector.split(addrinfo1) == (addrinfo1[:1], addrinfo1[1:])

    # Test case in which there are both AF_INET and AF_INET6 addresses
    addrinfo2 = [(socket.AF_INET, socket.AF_INET), (socket.AF_INET, socket.AF_INET),
                 (socket.AF_INET6, socket.AF_INET6)]
    assert _Connector.split(addrinfo2) == (addrinfo2[:2], addrinfo2[2:])


# Generated at 2022-06-24 09:22:51.622463
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    host = "google.com"
    port = 80
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.setblocking(False)
    def connect(af, addr):
        IOStream(client, io_loop=IOLoop.current())
        try:
            client.connect(addr)
        except (socket.error, IOError) as e:
            connect_future.set_exception(e)
            return connect_future
        connect_future.set_result(client)
        return connect_future
    resolver = Resolver()
    addrinfo = resolver.resolve(host, port)
    connector = _Connector(addrinfo, connect)
    connector.try_connect(iter(connector.primary_addrs))
    #return connector.start()

# Unit

# Generated at 2022-06-24 09:22:54.856510
# Unit test for constructor of class _Connector
def test__Connector():
    if __name__ == "__main__":
        def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, Future]:
            pass


        _Connector([(2, (1, 2, 3, 4))], connect).start()



# Generated at 2022-06-24 09:22:56.050318
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    pass



# Generated at 2022-06-24 09:23:08.060333
# Unit test for method start of class _Connector
def test__Connector_start():
    resolver = Resolver()
    @gen.coroutine
    def connect(af, addr):
        sock = socket.socket(af, socket.SOCK_STREAM)
        stream = IOStream(sock)
        yield stream.connect(addr)
        return stream
    @gen.coroutine
    def test_sync():
        conn = _Connector(((socket.AF_INET, ("localhost", 0)),), lambda af, addr: (None, None))
        yield conn.start()

    @gen.coroutine
    def test_happy_eyeballs():
        addrinfo = yield resolver.resolve("localhost:8888")
        conn = _Connector(addrinfo, connect)
        _, addr, stream = yield conn.start()
        self.assertEqual(list(addr), [addr[0], 8888])
        self

# Generated at 2022-06-24 09:23:16.454682
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    def test_set_connect_timeout():
        # type: () -> None
        try:
            seconds = 0.01  # type: Union[float, datetime.timedelta]
            c = _Connector([], lambda af, addr: (None, Future()))
            c.set_connect_timeout(seconds)
            assert c.connect_timeout != None
        except Exception as e:
            print(e)

    test_set_connect_timeout()



# Generated at 2022-06-24 09:23:19.470649
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    def test_func(stream: IOStream) -> None:
        stream.close()
    c = _Connector([], test_func)
    c.streams = [1,2,3]
    c.close_streams()

# Generated at 2022-06-24 09:23:31.470125
# Unit test for method start of class _Connector
def test__Connector_start():
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 8888))]
    connector = _Connector(addrinfo, connect)
    future = connector.start()
    # the type of future is Future[Tuple[socket.AddressFamily, Any, IOStream]]
    future.result()
    # the value of future is (socket.AF_INET, '127.0.0.1', <tornado.iostream.IOStream object at 0x10c5c7bd0>)

    # case 2:
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 8888)), (socket.AF_INET, ("127.0.0.1", 8887))]
    connector = _Connector(addrinfo, connect)
    future = connector.start()
    future.result()

# Generated at 2022-06-24 09:23:42.183583
# Unit test for method start of class _Connector
def test__Connector_start():
    import socket
    from tornado.iostream import IOStream
    from tornado.ioloop import IOLoop
    from tornado.log import app_log
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test

    from tornado.test.util import unittest

    class TestConnector(AsyncTestCase):
        def test_connect_failed(self):
            # Tests that the "Happy Eyeballs" algorithm works even if
            # the first connection attempt fails.

            def connect(af, addr):
                raise Exception("connection failed")

            connector = _Connector(Resolver().resolve("localhost:0"), connect)
            future = connector.start()
            with self.assertRaises(Exception):
                future.result()
            self.assertTrue(future.done())


# Generated at 2022-06-24 09:23:51.023076
# Unit test for method start of class _Connector
def test__Connector_start():
    latency = 0.1  # type: float
    time = 0.0  # type: float

    IOLoopTestWithTime.test_time = 0.0  # type: float

    def _add_socket(addrinfo, family, addr, stream=None):
        # type: (List[Tuple[int,Tuple[str,int]]], int, Tuple[str,int], Optional[IOStream]) -> Tuple[IOStream,Future[IOStream]]
        s = socket.socket(family, socket.SOCK_STREAM, 0)
        if stream is None:
            stream = IOStream(s)
        s.setblocking(False)
        future = Future()
        stream.set_close_callback(lambda: future.set_exception(IOError("stream is closed")))


# Generated at 2022-06-24 09:23:53.829346
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    _Connector(None, None).set_connect_timeout(None)



# Generated at 2022-06-24 09:24:04.049352
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    client = TCPClient()
    with pytest.raises(TypeError) as err:
        client.connect('www.google.com', 80, '::1', timeout='bad')
    assert err.value.args[0] == 'Unsupported timeout bad'
    with pytest.raises(TypeError) as err:
        client.connect(
            'www.google.com', 80, '::1', timeout=datetime.datetime.now() + datetime.timedelta(0, -1)
        )
    assert err.value.args[0] == 'Unsupported timeout datetime.datetime(2019, 8, 21, 19, 11, 27, 891710)'

# Generated at 2022-06-24 09:24:07.588436
# Unit test for method split of class _Connector
def test__Connector_split():
    res = _Connector.split([(socket.AF_INET, ('8.8.8.8', 80)), (socket.AF_INET6, ('::1', 80))])
    assert res == ([(socket.AF_INET, ('8.8.8.8', 80))], [(socket.AF_INET6, ('::1', 80))])


# Generated at 2022-06-24 09:24:17.929568
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Testing function for testing function clear_timeouts of class _Connector

    current_dir = os.path.dirname(os.path.realpath(__file__))
    root_dir = os.path.abspath(os.path.join(current_dir, os.pardir, os.pardir))
    src_dir = os.path.join(root_dir, "src")
    script = os.path.join(root_dir, "script")
    dump_file = os.path.join(src_dir, "__temp_dump.json")

    command = [
        os.path.join(script, "test_analyzer.py"),
        "--debug",
        src_dir,
        dump_file,
    ]
    subprocess.run(command, check=True)


# Generated at 2022-06-24 09:24:23.948187
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    resolver = Resolver()
    stream, future = _Connector.set_connect_timeout(
        resolver.resolve("www.baidu.com", 80),
        functools.partial(IOStream, socket.socket()),
        test_timeout=1.0,
    )
    try:
       stream.connect(("www.baidu.com", 80))
    except:
       pass


# Generated at 2022-06-24 09:24:31.661550
# Unit test for constructor of class _Connector
def test__Connector():
    import socket
    
    def _connect(_af, _addr):
        sock = socket.socket(_af)
        sock.setblocking(False)
        stream = IOStream(sock)
        stream.set_close_callback(lambda _: None)
        future = Future()
        stream.connect(_addr, lambda: future.set_result(stream))
        return stream, future

    addrinfo = [(socket.AF_INET, ('127.0.0.1', 80)),
                (socket.AF_INET6, ('::1', 80))]

    connector = _Connector(addrinfo, _connect)
    connector.start(timeout = 0.3)

    assert connector.future.done()


# Generated at 2022-06-24 09:24:37.161283
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    o = _Connector([],lambda af, addr: (lambda:None))
    # unit test for not implemented method "on_connect_timeout" in _Connector
    assert(o.on_connect_timeout() == None)
    # unit test for not implemented method "clear_timeouts" in _Connector
    assert(o.clear_timeouts() == None)
    # unit test for not implemented method "close_streams" in _Connector
    assert(o.close_streams() == None)
    # unit test for "set_connect_timeout" in _Connector
    assert(o.set_connect_timeout(3) == None)



# Generated at 2022-06-24 09:24:38.888574
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    # Test_TCPClient_close()
    pass


# Generated at 2022-06-24 09:24:40.146655
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # FIXME
    pass


# Generated at 2022-06-24 09:24:45.427456
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    io_loop = IOLoop()
    io_loop.make_current()
    connector = _Connector([(socket.AF_INET, ("127.0.0.1", 53))], None)
    connector.io_loop = io_loop
    assert connector.set_connect_timeout(0.1) is None
    io_loop.run_sync(connector.future)


# Generated at 2022-06-24 09:24:47.451261
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Replace with the appropriate test case
    assert False

# Generated at 2022-06-24 09:24:52.592080
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.testing import AsyncTestCase

    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.testing import bind_unused_port
    from tornado.netutil import add_accept_handler

    import logging
    import socket
    from tornado.platform.asyncio import AsyncIOMainLoop as _AsyncIOMainLoop

    #logging.basicConfig(filename='example.log', level=logging.DEBUG)

    class _MockStream(IOStream):
        def __init__(self, sock, io_loop=None):
            if io_loop is None:
                io_loop = IOLoop.current()
            super().__init__(sock, io_loop=io_loop)
            self.closed = False

        def close(self):
            self.closed = True

# Generated at 2022-06-24 09:25:04.536019
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import pytest
    from tornado.httpclient import HTTPClient, HTTPRequest
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import functools
    import traceback
    import pymysql
    import logging

    import sys
    sys.path.extend(["..", '.'])
    from lib.log_util import LogUtil

    import json
    import time
    import concurrent.futures
    from tornado import gen
    from tornado.ioloop import IOLoop
    import tornado.ioloop
    from tornado.platform.asyncio import (
        AnyThreadEventLoopPolicy,
        to_asyncio_future,
        to_tornado_future,
    )
    import pytest

    from lib.database.MySQL.MySQL import MySQL


# Generated at 2022-06-24 09:25:12.716505
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    """
    Test ```_Connector.set_connect_timeout``` for the following conditions:

    #. Test for when ```connect_timeout``` is not passed as an argument;
    #. Test for when ```connect_timeout``` is passed as a `float` class argument;
    #. Test for when ```connect_timeout``` is passed as a `timedelta` class argument;

    Parameters
    ----------
    None

    Returns
    -------
    None

    Raises
    ------
    AssertionError
        If any of the tests fail.
    TypeError
        If any of the tests fail to catch a TypeError.
    """
    # GIVEN

# Generated at 2022-06-24 09:25:21.397674
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import tornado.testing as testing
    from tornado.ioloop import IOLoop
    import socket

    import tornado.platform.asyncio

    tornado.platform.asyncio.AsyncIOMainLoop().install()

    async def async_test_set_timeout(self):

        def connect(af: socket.AddressFamily, addr: Tuple[str, int]) -> Tuple[
            IOStream, "Future[IOStream]"
        ]:
            stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
            stream.set_close_callback(lambda: future.set_result((af, addr, stream)))
            stream.connect(addr, server_hostname="localhost")
            return stream, future

        future = Future()

# Generated at 2022-06-24 09:25:28.563133
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import tornado.testing
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import socket
    import functools
    import time

    def handle_request(request):
        request.connection.stream.write(b"HTTP/1.0 200 OK\r\n\r\nTest\n")
        request.connection.stream.close()

    class TestHandler(tornado.web.RequestHandler):
        @tornado.gen.coroutine
        def get(self):
            http_client = tornado.httpclient.AsyncHTTPClient()
            response = yield http_client.fetch(
                "http://%s:%s/" % (self.request.host, port)
            )
            self.write(response.body)
           

# Generated at 2022-06-24 09:25:36.382636
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    class IOStreamMock(IOStream):
        def __init__(self, *args):
            IOStream.__init__(self, *args)
            self.closed = False
            self.close = lambda: self.closed.__setitem__(0, True)

    stream1 = IOStreamMock(0)
    stream2 = IOStreamMock(0)
    future = Future()
    future.add_done_callback(
        lambda _: stream1.closed and stream2.closed
    )
    _Connector([], lambda _, __: (stream1, future)).close_streams()
    assert future.result() is True



# Generated at 2022-06-24 09:25:47.113254
# Unit test for method split of class _Connector
def test__Connector_split():
    c = _Connector(list(), lambda x, y: tuple())
    expected = ([], [])
    assert c.split(list()) == expected
    assert c.split([(2,3)]) == expected
    assert c.split([(2,3), (1,3)]) == expected
    assert c.split([(2,3), (2,3)]) == expected
    assert c.split([(1,3), (1,3)]) == expected
    assert c.split([(1,3), (2,3)]) == expected
    assert c.split([(1,3), (2,3), (1,3)]) == expected
    assert c.split([(1,3), (1,3), (1,3)]) == expected

# Generated at 2022-06-24 09:25:55.298274
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case 1
    # Test with timeout passed as float
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("ffff::1", 80)),
    ]
    addrinfo.reverse()
    connector = _Connector(
        addrinfo,
        connect=lambda af, addr: (
            IOStream(socket.socket(af, socket.SOCK_STREAM)),
            Future(),
        ),
    )
    connector.start(connect_timeout=0.5)
    assert isinstance(connector.connect_timeout, object)
    assert isinstance(connector.timeout, object)
    assert not connector.future.done()
    IOLoop.current().add_callback(
        lambda: connector.on_connect_timeout()
    )

# Generated at 2022-06-24 09:26:07.369702
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado import testing
    import unittest.mock
    import contextlib
    
    class DummyStream:
        def __init__(self):
            self.closed = False

        def close(self) -> None:
            self.closed = True

    @contextlib.contextmanager
    def mocked_current():
        with unittest.mock.patch("tornado.ioloop.IOLoop.current") as m:
            ioloop = testing.mock_io_loop()
            m.return_value = ioloop

            yield ioloop

    def dummy_connect(
        af: socket.AddressFamily,
        addr: Tuple,
    ) -> Tuple[IOStream, "Future[IOStream]"]:
        stream = DummyStream()
        future = Future()

        future.set_result(stream)

# Generated at 2022-06-24 09:26:15.558993
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    try:
        from tornado.ioloop import IOLoop
    except:
        pass
    try:
        from tornado.concurrent import Future
    except:
        pass
    f = Future()
    def func(self):
        return self.timeout
    socket.socket = func
    ioloop = IOLoop()
    def func1():
        f.set_result(1)
    ioloop.add_timeout = func1
    connector = _Connector([(1,1),(1,1)], lambda x,y: (x,y))
    connector.io_loop = ioloop
    connector.future = f
    connector.set_timeout(0.1)
    connector.clear_timeout()
    assert (connector.timeout is None)
    assert connector.future.result() == 1



# Generated at 2022-06-24 09:26:16.633264
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # TODO
    pass

# Generated at 2022-06-24 09:26:25.542187
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    print("TESTING TESTING TESTING test_TCPClient_connect")
    host = ''
    port = ''
    ssl_options = {}
    max_buffer_size = ''
    source_ip = ''
    source_port = ''
    timeout = 0
    tcp = TCPClient()
    tcp.connect(host, port, ssl_options=ssl_options,
                max_buffer_size=max_buffer_size,
                source_ip=source_ip,
                source_port=source_port,
                timeout=timeout)
    tcp.close()


if __name__ == "__main__":
    test_TCPClient_connect()

# Generated at 2022-06-24 09:26:27.881180
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    obj = _Connector
    # Check for correct return style
    assert isinstance(obj.clear_timeout(), None)


# Generated at 2022-06-24 09:26:37.479921
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    import socket
    import unittest
    from tornado import testing
    from tornado.testing import AsyncTestCase
    from tornado import gen

    class TestConnector(AsyncTestCase):
        def __init__(self, *args, **kwargs):
            AsyncTestCase.__init__(self, *args, **kwargs)

        @testing.gen_test
        def test(self):
            future = Future()  # type: Future
            con = _Connector([(socket.AF_INET, ("localhost", 0))], lambda *args: (None, future))
            con.start()  # type: ignore
            con.on_connect_timeout()
            self.assertRaises(TimeoutError, lambda: future.result())


# Generated at 2022-06-24 09:26:48.971203
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    from tornado.ioloop import IOLoop
    from tornado.testing import get_unused_port
    from tornado.stack_context import ExceptionStackContext
    from tornado.concurrent import Future

    class DummyResolver(object):
        # A dummy resolver that returns an immediate Future.
        def resolve(self, host, port, family):
            fut = Future()
            fut.set_result([(socket.AF_INET, ("localhost", port))])
            return fut
        def close(self):
            pass

    client = TCPClient(resolver=DummyResolver())

    class Error(Exception):
        pass

    fut = Future()
    port = get_unused_port()

# Generated at 2022-06-24 09:26:59.492541
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    
    timeout_mock = mock.Mock()
    connect_timeout_mock = mock.Mock()
    io_loop_mock = mock.Mock()
    io_loop_mock.remove_timeout = mock.Mock()
    io_loop_instance = io_loop_mock()
 
    io_loop_instance.return_value = io_loop_mock
    io_loop_mock.return_value = io_loop_instance
    connector = _Connector(
        addrinfo = [(socket.AF_INET6, ('ABC', 80, 0, 0))],
        connect = lambda family, address: (None, None),
    )
    connector.io_loop = io_loop_instance
    connector.timeout = timeout_mock
    connector.connect_timeout = connect_timeout_mock
   

# Generated at 2022-06-24 09:27:03.386829
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    stream = IOStream()
    future = Future()
    future_add_done_callback(future, lambda *args: stream.close())
    connector = _Connector([], lambda *args: (stream, future))
    connector.future = future
    connector.streams.add(stream)
    connector.on_connect_timeout()
    assert connector.streams == set()



# Generated at 2022-06-24 09:27:04.221698
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():

    client = TCPClient()


# Generated at 2022-06-24 09:27:12.712882
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    class _Connector_MockIOStream:
        def close(self):
            return
    class _Connector_MockFuture:
        def done(self):
            return True
    class _Connector_MockSocket:
        _Connector_MockFuture_instance = _Connector_MockFuture()
        def socket(self):
            return self
        def settimeout(self, timeout: float) -> None:
            return
        def bind(self, address: Tuple) -> None:
            return
        def connect(self, address: Tuple) -> None:
            return
        def fileno(self) -> int:
            return
        def setsockopt(
            self,
            level: socket.AddressFamily,
            option: int,
            value: int,
        ) -> None:
            return

# Generated at 2022-06-24 09:27:16.558450
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test for on_connect_timeout for class _Connector
    # test for on_connect_timeout()
    # but this cannot be unittested
    pass



# Generated at 2022-06-24 09:27:23.977367
# Unit test for method split of class _Connector
def test__Connector_split():
    list_test = [(2, (1, 2, 3)), (2, (2, 3, 4)), (10, (1, 2, 3))]
    primary, secondary = _Connector.split(list_test)
    assert primary == [(2, (1, 2, 3)), (2, (2, 3, 4))]
    assert secondary == [(10, (1, 2, 3))]


_client_factory = None  # type: Optional[Tuple[Callable, Callable]]



# Generated at 2022-06-24 09:27:32.246212
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import unittest
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNoIPv6
    from tornado.testing import bind_unused_port
    from tornado.platform.auto import set_close_exec
    from tornado.netutil import Resolver

    skipIfNoIPv6()

    default_connect_timeout = 0.01

    class ConnectorTestCase(unittest.TestCase):
        def setUp(self):
            # A Connector that doesn't actually try to connect.
            self.sockets = []
            def connect(af, addr):
                sock = socket.socket(af, socket.SOCK_STREAM)
                set_close_exec(sock.fileno())
                self.sockets.append(sock)

# Generated at 2022-06-24 09:27:44.554707
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.iostream import IOStream
    from tornado.testing import AsyncTestCase

    import socket
    import sys
    import threading
    import time

    class TestServer(threading.Thread):
        def run(self):
            global server_ready
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("127.0.0.1", 0))
            server_ready.wait()
            s.listen(1)
            conn, addr = s.accept()
            conn.send(b"hello\n")
            conn.close()
            s.close()

    class TestAddress(object):
        family = socket.AF_INET

# Generated at 2022-06-24 09:27:55.252279
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    import subprocess
    import os
    import sys
    import signal
    import time
    import json
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    os.chdir(os.path.join(os.path.dirname(__file__), '..'))
    # server
    p = subprocess.Popen(["python", "test/test.py", "server", "test_TCPClient_close"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # wait for server start
    time.sleep(2)

# Generated at 2022-06-24 09:28:01.259946
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    print("test__Connector_set_timeout")
    addrinfo = [1, 2, 3]
    connect = lambda x, y: (1, 2)
    connector = _Connector(addrinfo, connect)
    timeout = 3.2
    connector.set_timeout(timeout)
    assert connector.timeout is not None
    assert connector.timeout.deadline <= IOLoop.current().time() + timeout



# Generated at 2022-06-24 09:28:11.665147
# Unit test for constructor of class _Connector
def test__Connector():
    test_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    test_socket.bind(('127.0.0.1', 0))
    test_socket.listen(16)
    addr = test_socket.getsockname()
    addrinfo = socket.getaddrinfo(
        addr[0], addr[1], 0, socket.SOCK_STREAM, socket.SOL_TCP)
    test_connect = lambda af, addr: (None, None)
    test_connector = _Connector(addrinfo, test_connect)
    assert test_connector.io_loop == IOLoop.current()
    assert len(test_connector.primary_addrs) == len(addrinfo)
    assert len(test_connector.secondary_addrs) == 0
    test_socket

# Generated at 2022-06-24 09:28:22.771868
# Unit test for method split of class _Connector
def test__Connector_split():
    from tornado.test.util import unittest
    from tornado.test.util import override_log_errors

    class MyTestCase(unittest.TestCase):
        @override_log_errors
        def test_split(self):
            addrinfo = [
                (socket.AF_INET, ("1.2.3.4", 80)),
                (socket.AF_INET6, ("1:2:3:4:5:6:7:8", 443)),
                (socket.AF_INET, ("5.6.7.8", 8080)),
                (socket.AF_INET6, ("1:2:3:4:5:6:7:9", 8080)),
            ]
            primary, secondary = _Connector.split(addrinfo)

# Generated at 2022-06-24 09:28:33.207767
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    io_loop = IOLoop.current()
    future1 = Future()  # type: Future[IOStream]
    future2 = Future()  # type: Future[IOStream]

    def connect(
        af: socket.AddressFamily, addr: Tuple
    ) -> Tuple[IOStream, "Future[IOStream]"]:
        if af == socket.AF_INET:
            return (None, future1)  # type: ignore
        else:
            return (None, future2)  # type: ignore

    connector1 = _Connector(
        [(socket.AF_INET, (1, 1)), (socket.AF_INET6, (2, 2))], connect
    )
    future = connector1.start()
    connector1.try_connect(iter(connector1.primary_addrs))

# Generated at 2022-06-24 09:28:41.211938
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import json
    import logging
    import os
    import threading
    import time
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.options import define, parse_config_file, options
    from tornado.tcpserver import TCPServer
    from tornado.web import Application, RequestHandler

    define('port', default=8888, type=int)
    define('debug', default=True, type=bool)
    parse_config_file('../config/app_config.py')

    root_logger = logging.getLogger(__name__)
    root_logger.setLevel(logging.DEBUG)

# Generated at 2022-06-24 09:28:42.483969
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    _Connector(addrinfo=[], connect=None).close_streams()



# Generated at 2022-06-24 09:28:43.320856
# Unit test for constructor of class TCPClient
def test_TCPClient():
    tcpclient = TCPClient()
    assert(tcpclient != None)

# Generated at 2022-06-24 09:28:53.876540
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.platform.asyncio
    import asyncio
    ip = "127.0.0.1"
    port = 8000
    timeout = None
    ssl_options = None
    max_buffer_size = None
    source_ip = None
    source_port = None
    addrinfo = [(2, 1), (10, 2)]
    # addrinfo = [(10, 1), (2, 2)]
    # addrinfo = [(30, 1), (20, 2)]
    # addrinfo = [(30, 1), (20, 2), (10, 3), (2, 4)]
    asyncio.set_event_loop_policy(tornado.platform.asyncio.AnyThreadEventLoopPolicy())
    def test(addrinfo):
        async def coro():
            tcp_client = TCPClient()
            res = await tcp

# Generated at 2022-06-24 09:28:56.694173
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Connector = tornado.netutil.Connector
    pass


# Generated at 2022-06-24 09:28:57.724585
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    tcpc = TCPClient()
    tcpc.close()


# Generated at 2022-06-24 09:29:00.213786
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Connector.set_timeout() sets the timeout
    # properly when there is no timeout set
    # before
    assert True == True


# Generated at 2022-06-24 09:29:06.508787
# Unit test for method split of class _Connector
def test__Connector_split():

    connector = _Connector([(1, 2), (1, 4), (3, 5)], None)
    assert connector.split([(1, 2), (1, 4), (3, 5)])\
        == ([(1, 2), (1, 4)], [(3, 5)])
    assert connector.split([(1, 2), (1, 3), (2, 5)])\
        == ([(1, 2)], [(1, 3), (2, 5)])


# Generated at 2022-06-24 09:29:12.272107
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    import tornado

    @gen.coroutine
    def resolve(host, port, family):
        raise gen.Return([(socket.AF_INET, (host, port))])

    resolver = tornado.netutil.Resolver()
    resolver.resolve = resolve
    tcp = tornado.netutil.TCPClient(resolver)
    tcp.close()



# Generated at 2022-06-24 09:29:19.010990
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    @gen.coroutine
    def try_connect(af, addr):
        yield []
        return IOStream(socket.socket())

    connector = _Connector([(socket.AF_INET, "1.2.3.4")], try_connect)
    connector.set_timeout(0.01)
    connector.set_connect_timeout(0.02)

    connector.clear_timeouts()
    assert connector.timeout is None
    assert connector.connect_timeout is None



# Generated at 2022-06-24 09:29:20.993498
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    # This test is not yet working. Will create a PR in future.
    pass


# Generated at 2022-06-24 09:29:21.935467
# Unit test for constructor of class TCPClient
def test_TCPClient():
    obj = TCPClient()


# Generated at 2022-06-24 09:29:26.772303
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    try:
        from . import ioloop
    except ImportError:
        from . import ioloop

    ioloop.IOLoop.configure("tornado.ioloop.PollIOLoop")
    self = _Connector([], lambda af, addr: (None, None))
    self._connect_timeout = TimeoutError()
    self.on_connect_timeout()



# Generated at 2022-06-24 09:29:28.663473
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    resolver = Resolver()
    tcp_client = TCPClient(resolver)
    tcp_client.close()

# Generated at 2022-06-24 09:29:29.376533
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    pass

# Generated at 2022-06-24 09:29:31.189165
# Unit test for method split of class _Connector
def test__Connector_split():
    raise NotImplementedError("Not implemented")



# Generated at 2022-06-24 09:29:40.230653
# Unit test for constructor of class _Connector
def test__Connector():
    @gen.coroutine
    def test(
        af: socket.AddressFamily,
        addr: Tuple,
        af2: socket.AddressFamily,
        addr2: Tuple,
        timeout: float = 0.0,
        address_timeout: float = None,
    ) -> IOStream:
        if address_timeout is not None:
            address_timeout = datetime.timedelta(seconds=address_timeout)
        connector = _Connector(
            [(af, addr), (af2, addr2)],
            functools.partial(
                connect_tcp_nodelay, address_timeout=address_timeout
            ),
        )
        stream = yield connector.start(timeout)  # type: ignore
        return stream


# Generated at 2022-06-24 09:29:44.306563
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    resolver = Resolver()
    addrinfo = resolver.resolve('foo.example.com')
    c = _Connector(addrinfo, connect)
    c.clear_timeout()


# Generated at 2022-06-24 09:29:53.185947
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    class DummyFuture(Future):
        def __init__(self, exception=None):
            self.exception = exception

        def result(self):
            raise self.exception

    class DummyIOStream(IOStream):
        def __init__(self):
            self.closed = False

        def close(self):
            self.closed = True

    class DummyIOLoop(IOLoop):
        def __init__(self):
            self.pending_callbacks = []

        def time(self):
            return 0

        def add_timeout(self, timeout, callback):
            self.pending_callbacks.append((timeout, callback))

    def on_connect_done(
        self, addrs, af, addr, future,
    ):
        self.addrs = addrs
        self.af = af


# Generated at 2022-06-24 09:30:02.976979
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()
    import asyncio
    import sys
    import time

    def setUpModule():
        AsyncIOMainLoop().install()

    def tearDownModule():
        AsyncIOMainLoop().close()

    class _ConnectorUnitTest(unittest.TestCase):
        # Unit test method set_timeout of class _Connector
        @unittest.skipIf(
            not hasattr(IOLoop, "configure"),
            "Current IOLoop instance cannot be configured",
        )
        def test_set_timeout(self):
            io_loop = IOLoop()
            io_loop.make_current()


# Generated at 2022-06-24 09:30:03.698524
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    pass

# Generated at 2022-06-24 09:30:14.087958
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # 1. Create a new _Connector object
    addrinfo: List[Tuple] = list()
    address_family: socket.AddressFamily = socket.AF_INET
    ip: Tuple[str, int] = ('127.0.0.1', 80)
    addrinfo.append((address_family, ip))
    address_family = socket.AF_INET6
    ip = ('127.0.0.1', 80)
    addrinfo.append((address_family, ip))
    connect = lambda address_family, socket_address: ((socket_address, socket_address), Future)
    connect_object = _Connector(addrinfo, connect)
    # 2. Call start with timeout=0.3 and connect_timeout=0.1
    connect_object.start(timeout=0.3, connect_timeout=0.1)


# Generated at 2022-06-24 09:30:14.765943
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    assert True

# Generated at 2022-06-24 09:30:20.843565
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    test_Connector = _Connector(
        addrinfo=[(2, ('test_address', 1))],
        connect=lambda x, y: (IOStream(socket.socket(x, socket.SOCK_STREAM)), 1),
    )
    test_Connector._Connector__future=Future()
    test_Connector._Connector__future.set_result(1)
    assert test_Connector.close_streams()



# Generated at 2022-06-24 09:30:31.221502
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Create a mock object of class IOLoop and assign it to 
    # local variable io_loop
    io_loop = mock.Mock(spec=IOLoop)
    # Create a mock object of class Future and assign it to 
    # local variable future
    future = mock.Mock(spec=Future)
    # Create a mock object of _Connector and initialize its attributes
    _ = _Connector(
        addrinfo = [],
        connect = lambda a, b: (mock.Mock(spec=IOStream), mock.Mock(spec=Future)),
    )
    _.timeout = None
    _.connect_timeout = None
    _.last_error = None
    _.remaining = 0
    _.primary_addrs = []
    _.secondary_addrs = []
    _.streams = set()


# Generated at 2022-06-24 09:30:42.935901
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    if Resolver.configured:
        resolver = Resolver()
    else:
        resolver = None
    addrinfo = resolver.resolve("127.0.0.1", 80)
    # Check that set_connect_timeout with float doesn't raise
    def connect(af, addr):
        future = Future()
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM), io_loop=IOLoop.current())
        future.set_result(stream)
        return stream, future
    connector = _Connector(addrinfo, connect)
    connector.set_connect_timeout(
        float(connector.io_loop.time() + _INITIAL_CONNECT_TIMEOUT) + 1
    )
    # Check that set_connect_timeout with datetime.timedelta doesn't raise
    td

# Generated at 2022-06-24 09:30:45.734741
# Unit test for constructor of class _Connector
def test__Connector():
    c = _Connector([], lambda a, b: (None, None))
    assert c.io_loop == IOLoop.current()

    af, addr = socket.AF_INET, ("136.1.1.1", 1234)
    af2, addr2 = socket.AF_INET6, ("2600:1::1", 1234)



# Generated at 2022-06-24 09:30:50.380663
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    client.bind(("localhost", 0))
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    server.bind(("localhost", 0))
    server.listen(5)
    client.connect(server.getsockname())
    server.accept()
    server.close()
    client.close()
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    client.bind(("localhost", 0))
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    server.bind(("localhost", 0))
    server.listen(5)

# Generated at 2022-06-24 09:30:58.470919
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase

    class TCPClientTestCase(AsyncTestCase):
        def test_TCPClient_close(self):
            if not hasattr(socket, "AF_UNSPEC"):
                # If the system doesn't have IPv6, skip this test.
                return
            tcp_client = TCPClient()
            tcp_client.close()
            tcp_client = TCPClient()
            tcp_client.close()

    AsyncIOMainLoop().install()
    TCPClientTestCase().test_TCPClient_close()



# Generated at 2022-06-24 09:31:10.031678
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    connect_done = False
    def fake_connect(self):
        return (1, 2)
    def fake_try_connect(self, addrs):
        pass
    def fake_on_timeout(self):
        connect_done = True
    def fake_result(self):
        return (1, 2, 2)
    origin__Connector_connect = _Connector.connect
    origin__Connector_try_connect = _Connector.try_connect
    origin__Connector_on_timeout = _Connector.on_timeout
    origin__Connector_result = Future.result
    _Connector.connect = fake_connect
    _Connector.try_connect = fake_try_connect
    _Connector.on_timeout = fake_on_timeout

    a = _Connector([(6, "a")], None)
    a.future.result = fake_result

   

# Generated at 2022-06-24 09:31:14.252133
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    import unittest.mock
    
    class _MockIOStream(unittest.mock.MagicMock):
        def close(self): pass

    mock_io_stream = _MockIOStream()
    mocked_connect = unittest.mock.MagicMock(
        side_effect=lambda af, addr: (mock_io_stream, Future())
    )

    connector = _Connector([(socket.AF_INET, ("localhost", 80))], mocked_connect)
    connector.io_loop = unittest.mock.MagicMock()
    connector.future = Future()
    connector.streams = set([mock_io_stream])
    
    connector.close_streams()
    
    assert mock_io_stream.close.call_count == 1

# Generated at 2022-06-24 09:31:24.144541
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import threading
    from tornado import httpserver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.concurrent import Future
    from unittest import mock
    from random import randint

    from tornado.ioloop import IOLoop

    class _MockIOLoop(IOLoop):
        def is_current(self):
            return True

    io_loop = _MockIOLoop()

    class _MockTimeout(object):
        def __init__(self, timeout: float):
            self.timeout = timeout
            self.tm = 0.01 * randint(1, 10)

        def remove(self):
            pass

        def callback(self):
            pass

    class _Test_Connector(AsyncTestCase):
        """Unit tests for _Connector class"""


# Generated at 2022-06-24 09:31:27.443950
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo=[(socket.AF_INET,("",80)),(socket.AF_INET6,("6",80))]
    primary,secondary=_Connector.split(addrinfo)
    assert primary==[(socket.AF_INET,("",80))]
    assert secondary==[(socket.AF_INET6,("6",80))]


# Generated at 2022-06-24 09:31:36.760769
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    def mock_getaddrinfo(*args, **kwargs):
        return [(socket.AF_INET6, '', '', '', ('::1', 80, 0, 0)),
                (socket.AF_INET, '', '', '', ('10.0.0.1', 80))]

    def mock_connect(*args, **kwargs):
        stream = Mock()
        futures = Future()
        futures.set_result(stream)
        return stream, futures

    def mock_remove_timeout(*args, **kwargs):
        return

    def mock_set_result(*args, **kwargs):
        return

    def mock_set_exception(*args, **kwargs):
        return

    def mock_close(self: object) -> None:
        return

    class Mock(object):
        pass


# Generated at 2022-06-24 09:31:48.341150
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    def address_family_to_name(af: socket.AddressFamily) -> str:
        if af == socket.AF_INET:
            return "AF_INET"
        elif af == socket.AF_INET6:
            return "AF_INET6"
        else:
            return "Unknown"

    def connect_cb(
        af: socket.AddressFamily, addr: Tuple[str, int]
    ) -> Tuple[IOStream, Future[IOStream]]:
        nonlocal num_connects
        nonlocal af_order
        num_connects += 1
        af_order += address_family_to_name(af)
        # We only call the callback once, since our fake _Connector
        # will only try to connect to each address once, so we
        # don't need to worry about closing or returning the stream

# Generated at 2022-06-24 09:31:56.971379
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    def close_streams(streams):
        for stream in streams:
            stream.close()

    class test_io_loop(object):
        def __init__(self):
            self.timeouts = {}

        def time(self):
            return int(time.time())

        def add_timeout(self, timeout=None, callback=None):
            self.timeouts[timeout] = callback

        def remove_timeout(self, timeout):
            del self.timeouts[timeout]

    io_loop = test_io_loop()
    io_loop.add_timeout(1)
    io_loop.add_timeout(2)
    io_loop.add_timeout(3)
    io_loop.add_timeout(4)
    io_loop.add_timeout(5)

    streams = set()
    connector = _

# Generated at 2022-06-24 09:32:04.171668
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    import mock
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from functools import partial
    # make sure close_streams closes all streams
    # make sure close_streams() is called when future is done
    
    def connect(af, addr):
        sock = mock.Mock()
        stream = IOStream(sock)
        return stream, Future()

    class ConnectorTestCase(AsyncTestCase):
        @gen_test
        def test_close_streams(self):
            with mock.patch('tornado.iostream.IOStream.close') as mocked_close:
                # hack IOStream.close to be a coroutine
                mocked_close.side_effect = partial(gen.sleep, 0.1)
               

# Generated at 2022-06-24 09:32:05.011340
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    _Connector.clear_timeout()

# Generated at 2022-06-24 09:32:14.345709
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    '''
    Test that when on_connect_timeout runs that the future on the connector
    returns an exception
    '''
    from tornado.testing import AsyncTestCase
    from tornado.testing import get_unused_port
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    from typing import Dict, Any

    class SimpleClient(asyncio.Protocol):
        def __init__(self, tests, future) -> None:
            tests.assertIsInstance(future, asyncio.Future)
            self._tests = tests
            self._future = future
            future.add_done_callback(self.on_connect)


# Generated at 2022-06-24 09:32:25.659477
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import time
    import string
    
    import tornado.ioloop
    import tornado.testing
    
    import handler
    
    def client_send(tcpclient, port, message, times=1):
        def on_connect(stream):
            stream.write(message)
            time.sleep(0.2)
            
            stream.close()
        for i in range(times):
            future = tcpclient.connect("127.0.0.1", port)
            future.add_done_callback(on_connect)
    
    
    def server_receive(server, message):
        for client in server.clients:
            if client.read_buffer != message:
                return False
        return True
    
    

# Generated at 2022-06-24 09:32:35.106812
# Unit test for constructor of class _Connector
def test__Connector():
    from typing import List

    def test_func(af: socket.AddressFamily, addr: Tuple[str, int]) -> Tuple[IOStream, Future]:
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
        return stream, Future()

    # normal usage
    addrinfo = [(socket.AF_INET, ("1.2.3.4", 80)), (socket.AF_INET6, ("2.3.4.5", 80))]
    _Connector(addrinfo, test_func).start()

    # empty addrinfo usage
    addrinfo = []  # type: List[Tuple]
    _Connector(addrinfo, test_func).start()
