

# Generated at 2022-06-18 10:46:56.772187
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:47:05.208309
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:47:15.597942
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    import unittest.mock
    from tornado.iostream import IOStream
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.testing import bind_unused_port
    from tornado.tcpserver import TCPServer
    from tornado.gen import TimeoutError
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from asyncio import Future as asyncio_Future
    from asyncio import get_event_loop
    from asyncio import ensure_future
    from asyncio import sleep
   

# Generated at 2022-06-18 10:47:26.363481
# Unit test for method split of class _Connector
def test__Connector_split():
    # type: () -> None
    """
    Test for method split of class _Connector
    """
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("127.0.0.1", 80))]

# Generated at 2022-06-18 10:47:31.365423
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    from tornado.testing import AsyncTestCase, gen_test

    class Test_Connector(AsyncTestCase):
        @gen_test
        async def test_set_timeout(self):
            connector = _Connector([], lambda af, addr: (None, None))
            connector.set_timeout(0.1)
            await gen.sleep(0.2)
            self.assertTrue(connector.future.done())

    Test_Connector().test_set_timeout()



# Generated at 2022-06-18 10:47:39.997288
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    import unittest.mock
    import io
    import socket
    import ssl
    import os
    import sys
    import time
    import datetime
    import functools
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.concurrent
    import tornado.gen
    import tornado.testing
    import tornado.tcpserver
    import tornado.platform.asyncio
    import asyncio
    import logging
    import contextlib
    import concurrent.futures
    import typing
    import typing_extensions
    from typing import Any, Union, Dict, Tuple, List, Callable, Iterator, Optional, Set
    from typing_extensions import Protocol, runtime_checkable
    from typing_extensions import Literal

# Generated at 2022-06-18 10:47:50.763092
# Unit test for method split of class _Connector
def test__Connector_split():
    # type: () -> None
    """
    Test for method split of class _Connector
    """
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    connector = _Connector(addrinfo, None)
    primary, secondary = connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("127.0.0.1", 80))]

# Generated at 2022-06-18 10:48:02.059846
# Unit test for constructor of class _Connector
def test__Connector():
    import unittest
    import socket
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio

    class _ConnectorTest(unittest.TestCase):
        def setUp(self):
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(None)

        def tearDown(self):
            self.loop.close()

        @tornado.testing.gen_test
        def test_connector(self):
            def connect(af, addr):
                stream = IOStream(socket.socket(af, socket.SOCK_STREAM), io_loop=self.loop)
                future = stream.connect(addr)
                return stream, future


# Generated at 2022-06-18 10:48:08.410442
# Unit test for method start of class _Connector

# Generated at 2022-06-18 10:48:13.369772
# Unit test for method try_connect of class _Connector

# Generated at 2022-06-18 10:48:46.423061
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.gen
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import time
    import functools
    import logging
    import sys
    import os
    import unittest
    import warnings
    import contextlib
    import threading
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent

# Generated at 2022-06-18 10:48:55.374870
# Unit test for method start of class _Connector
def test__Connector_start():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import functools


# Generated at 2022-06-18 10:49:02.049857
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    io_loop = IOLoop.current()
    timeout = io_loop.add_timeout(io_loop.time() + 0.1, lambda: None)
    connect_timeout = io_loop.add_timeout(io_loop.time() + 0.1, lambda: None)
    _Connector.clear_timeouts(timeout, connect_timeout)
    assert timeout is None
    assert connect_timeout is None



# Generated at 2022-06-18 10:49:11.966216
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import time
    import socket
    import ssl

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            self.io_loop = IOLoop.current()
            self.io_loop.make_current()
            self.resolver = Resolver()
            self.resolver.configure(
                resolver=self.io_loop.asyncio_loop.getaddrinfo
            )

        def tearDown(self):
            self.io_loop.clear_current()

# Generated at 2022-06-18 10:49:18.441778
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import time

    class TestTCPClient(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(TestTCPClient, self).setUp()
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(None)

        def tearDown(self):
            self.loop.close()
            super(TestTCPClient, self).tearDown()

        @tornado.testing.gen_test
        def test_connect(self):
            # type: () -> None
            # Create a server that echos back all data
            server, port = self.create_server()
            client = TCPClient()
           

# Generated at 2022-06-18 10:49:25.928544
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:49:38.172961
# Unit test for method split of class _Connector
def test__Connector_split():
    # type: () -> None
    """
    Test for method split of class _Connector
    """
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
    ]

# Generated at 2022-06-18 10:49:44.626300
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # Test case 1
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 80)), (socket.AF_INET6, ('::1', 80))]
    def connect(af, addr):
        return (IOStream(socket.socket(af, socket.SOCK_STREAM)), Future())
    connector = _Connector(addrinfo, connect)
    connector.try_connect(iter(connector.primary_addrs))
    assert connector.remaining == 1
    assert connector.last_error is None
    assert connector.timeout is None
    assert connector.connect_timeout is None
    assert connector.future.done() is False
    assert connector.streams == set()
    assert connector.primary_addrs == [(socket.AF_INET, ('127.0.0.1', 80))]
    assert connector

# Generated at 2022-06-18 10:49:56.129622
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    import unittest.mock as mock
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.testing import AsyncTestCase, gen_test

    class TestConnector(AsyncTestCase):
        def test_clear_timeouts(self):
            io_loop = IOLoop.current()
            io_loop.add_callback = mock.Mock()
            io_loop.remove_timeout = mock.Mock()
            io_loop.time = mock.Mock(return_value=0)
            io_loop.add_timeout = mock.Mock(return_value=1)
            io_loop.add_callback.side_effect = lambda f: f()
            stream = IOStream(socket.socket())
            stream.close = mock.Mock()


# Generated at 2022-06-18 10:50:03.805228
# Unit test for method set_timeout of class _Connector

# Generated at 2022-06-18 10:50:46.596347
# Unit test for method on_connect_timeout of class _Connector

# Generated at 2022-06-18 10:50:56.739826
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    import unittest.mock
    import socket
    import ssl
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.concurrent
    import tornado.gen
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import asyncio
    import concurrent.futures
    import functools
    import typing
    import logging
    import sys
    import os
    import time
    import datetime
    import contextlib
    import io
    import tempfile
    import shutil
    import random
    import string
    import json
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.parse

# Generated at 2022-06-18 10:51:08.222044
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    from tornado.testing import AsyncTestCase
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_

# Generated at 2022-06-18 10:51:19.683947
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import ssl

    class TestTCPClient(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(TestTCPClient, self).setUp()
            self.client = TCPClient()

        def test_connect(self):
            async def test():
                stream = await self.client.connect("www.google.com", 80)
                stream.close()

            self.io_loop.run_sync(test)

        def test_connect_ssl(self):
            async def test():
                stream = await self.client.connect(
                    "www.google.com", 443, ssl_options=ssl.SSLContext()
                )
                stream.close()

            self.io_loop.run_sync(test)

# Generated at 2022-06-18 10:51:28.671338
# Unit test for method clear_timeouts of class _Connector

# Generated at 2022-06-18 10:51:39.706501
# Unit test for constructor of class _Connector
def test__Connector():
    # type: () -> None
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("::1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
        (socket.AF_INET6, ("::2", 80)),
    ]
    def connect(af, addr):
        # type: (socket.AddressFamily, Tuple) -> Tuple[IOStream, Future[IOStream]]
        return (None, Future())
    connector = _Connector(addrinfo, connect)
    assert connector.io_loop == IOLoop.current()
    assert connector.connect == connect
    assert isinstance(connector.future, Future)
    assert connector.timeout is None
    assert connector.connect_timeout

# Generated at 2022-06-18 10:51:48.111450
# Unit test for constructor of class _Connector
def test__Connector():
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()

    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET6, ("127.0.0.1", 80))]
    connector = _Connector(addrinfo, connect)
    assert connector.io_loop == IOLoop.current()
    assert connector.connect == connect
    assert connector.future.done() == False
    assert connector.timeout == None
    assert connector.connect_timeout == None
    assert connector.last_error == None
    assert connector.remaining == 2

# Generated at 2022-06-18 10:51:58.093033
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import time

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            AsyncIOMainLoop().install()


# Generated at 2022-06-18 10:52:05.118361
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("2001:db8::1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
        (socket.AF_INET6, ("2001:db8::2", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
    ]

# Generated at 2022-06-18 10:52:13.122187
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.testing import bind_unused_port
    import asyncio
    import socket
    import time
    import functools
    import ssl
    import logging
    import sys
    import os
    import signal
    import multiprocessing
    import threading
    import traceback
    import subprocess
    import re
    import random
    import string
    import math
    import tempfile
    import shutil
    import contextlib
    import concurrent.fut

# Generated at 2022-06-18 10:53:26.597013
# Unit test for method split of class _Connector
def test__Connector_split():
    # type: () -> None
    """
    Test case for method split of class _Connector
    """
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80))]

# Generated at 2022-06-18 10:53:36.871950
# Unit test for constructor of class _Connector
def test__Connector():
    # type: () -> None
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("::1", 80)),
    ]
    def connect(af, addr):
        # type: (socket.AddressFamily, Tuple) -> Tuple[IOStream, Future[IOStream]]
        return (IOStream(socket.socket(af, socket.SOCK_STREAM)), Future())
    connector = _Connector(addrinfo, connect)
    assert connector.io_loop == IOLoop.current()
    assert connector.connect == connect
    assert isinstance(connector.future, Future)
    assert connector.timeout is None
    assert connector.connect_timeout is None
    assert connector.last_error is None
    assert connector.remaining == 2
   

# Generated at 2022-06-18 10:53:45.096941
# Unit test for method on_timeout of class _Connector

# Generated at 2022-06-18 10:53:55.867832
# Unit test for method on_connect_timeout of class _Connector

# Generated at 2022-06-18 10:54:05.967871
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.tcpserver
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.concurrent
    import tornado.gen
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.select
    import tornado.platform.asyncioreactor
    import tornado.platform.twistedreactor
    import tornado.platform.asyncioreactor
    import tornado.platform.twistedreactor
    import tornado.platform.asyn

# Generated at 2022-06-18 10:54:08.858290
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    # Test case data
    connect_timeout = 0.3
    # Perform the test
    _Connector.set_connect_timeout(connect_timeout)
    # Post-test assertions
    assert True # TODO: implement your test here



# Generated at 2022-06-18 10:54:18.598794
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock
    import socket
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.testing import AsyncTestCase, gen_test

    class TestConnector(AsyncTestCase):
        def setUp(self):
            super(TestConnector, self).setUp()
            self.io_loop = IOLoop.current()
            self.connect = unittest.mock.Mock()
            self.connector = _Connector(
                [
                    (socket.AF_INET, ("127.0.0.1", 80)),
                    (socket.AF_INET6, ("::1", 80)),
                ],
                self.connect,
            )

        @gen_test
        def test_try_connect(self):
            self.connect

# Generated at 2022-06-18 10:54:21.965178
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # Create a _Connector object
    connector = _Connector([(socket.AF_INET, ("127.0.0.1", 80))], None)
    # Call method clear_timeout of class _Connector
    connector.clear_timeout()


# Generated at 2022-06-18 10:54:27.836771
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.iostream import IOStream
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.concurrent import Future
    import asyncio
    import socket
    import time

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            AsyncIOMainLoop().install()

        @gen_test
        def test_close_streams(self):
            def connect(af, addr):
                stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
                future = Future()
                future.set_result(stream)
                return stream, future


# Generated at 2022-06-18 10:54:35.362205
# Unit test for method start of class _Connector
def test__Connector_start():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    from tornado.iostream import IOStream
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.test.util import unittest

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.io_loop = IOLoop.current()
            self.resolver = Resolver()
            self.resolver.install()
            self.addCleanup(self.resolver.close)
