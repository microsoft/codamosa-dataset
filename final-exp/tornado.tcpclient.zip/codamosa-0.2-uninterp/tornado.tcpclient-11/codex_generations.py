

# Generated at 2022-06-18 10:46:58.861062
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("::1", 80)),
        (socket.AF_INET, ("127.0.0.1", 8080)),
        (socket.AF_INET6, ("::1", 8080)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 8080)),
    ]

# Generated at 2022-06-18 10:47:06.530666
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import socket
    import tornado.ioloop
    import tornado.locks
    import tornado.queues
    import tornado.concurrent
    import tornado.escape
    import tornado.httputil
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi

# Generated at 2022-06-18 10:47:16.645283
# Unit test for constructor of class _Connector
def test__Connector():
    # type: () -> None
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("::1", 80)),
    ]
    connector = _Connector(addrinfo, lambda af, addr: (None, None))
    assert connector.io_loop == IOLoop.current()
    assert connector.connect is not None
    assert connector.future is not None
    assert connector.timeout is None
    assert connector.connect_timeout is None
    assert connector.last_error is None
    assert connector.remaining == 2
    assert connector.primary_addrs == [(socket.AF_INET, ("127.0.0.1", 80))]

# Generated at 2022-06-18 10:47:27.429857
# Unit test for method set_connect_timeout of class _Connector

# Generated at 2022-06-18 10:47:34.153679
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:47:42.312789
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.ioloop
    import tornado.gen
    import tornado.concurrent
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform

# Generated at 2022-06-18 10:47:49.910256
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case data
    timeout = 0.3
    connect_timeout = 0.5
    # Perform the test
    connector = _Connector([], lambda af, addr: (None, None))
    connector.future = Future()
    connector.io_loop = IOLoop.current()
    connector.set_timeout(timeout)
    connector.set_connect_timeout(connect_timeout)
    connector.on_connect_timeout()
    # Check the result
    assert connector.future.exception() is TimeoutError()
    assert connector.timeout is None
    assert connector.connect_timeout is None



# Generated at 2022-06-18 10:48:01.490309
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import unittest
    import unittest.mock
    import tornado.testing
    import tornado.concurrent
    import tornado.iostream
    import tornado.netutil
    import tornado.ioloop
    import socket
    import ssl
    import functools
    import datetime
    import typing
    import numbers
    import itertools
    import collections
    import contextlib
    import io
    import os
    import sys
    import tempfile
    import threading
    import time
    import warnings
    import weakref
    import concurrent.futures
    import concurrent.futures._base
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures._base
    import concurrent

# Generated at 2022-06-18 10:48:09.399114
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import logging
    import sys
    import time
    import tornado.gen
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.tcpserver
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.httputil
    import tornado.httpclient
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.web
    import tornado.websocket
    import tornado

# Generated at 2022-06-18 10:48:19.179995
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Test case data
    timeout = None
    connect_timeout = None
    io_loop = IOLoop.current()
    connect = lambda af, addr: (IOStream(socket.socket(af, socket.SOCK_STREAM)), Future())
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80))]
    # Construct the object
    connector = _Connector(addrinfo, connect)
    # Call the method
    connector.clear_timeouts()
    # Check the result
    assert timeout is None
    assert connect_timeout is None
    assert io_loop is IOLoop.current()
    assert connect is connector.connect
    assert addrinfo == connector.primary_addrs
    assert [] == connector.secondary_addrs
    assert Future() == connector.future
    assert None is connector.timeout
   

# Generated at 2022-06-18 10:48:49.939183
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # Test case data
    timeout = None
    io_loop = IOLoop.current()
    future = Future()
    connect_timeout = None
    last_error = None
    remaining = len(addrinfo)
    primary_addrs, secondary_addrs = split(addrinfo)
    streams = set()

    # Perform the test
    _Connector.clear_timeout(timeout, io_loop, future, connect_timeout, last_error, remaining, primary_addrs, secondary_addrs, streams)

    # Check the result
    assert True # TODO: implement your test here


# Generated at 2022-06-18 10:48:57.293186
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock as mock
    import socket
    import tornado.platform.asyncio
    import asyncio
    import tornado.iostream
    import tornado.gen
    import tornado.ioloop
    import tornado.netutil
    import tornado.testing
    import tornado.concurrent
    import tornado.tcpserver
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:49:08.260216
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from unittest import mock
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestConnector(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.io_loop = IOLoop.current()
            self.connector = _Connector(
                [
                    (socket.AF_INET, ("127.0.0.1", 80)),
                    (socket.AF_INET6, ("127.0.0.1", 80)),
                ],
                self.connect,
            )


# Generated at 2022-06-18 10:49:19.308678
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from asyncio import get_event_loop
    from tornado.netutil import bind_sockets
    from tornado.netutil import add_accept_handler
    from tornado.netutil import ssl_wrap_socket
    from tornado.netutil import Resolver
    from tornado.netutil import _Server
    from tornado.netutil import _Connector
    from tornado.netutil import _Client
    from tornado.netutil import _ClientFactory
    from tornado.netutil import _ServerFactory
    from tornado.netutil import _TCPClient

# Generated at 2022-06-18 10:49:27.876675
# Unit test for constructor of class _Connector
def test__Connector():
    # type: () -> None
    class _ConnectorTest(object):
        def __init__(self, addrinfo, connect):
            # type: (List[Tuple], Callable[..., Tuple[IOStream, "Future[IOStream]"]]) -> None
            self.io_loop = IOLoop.current()
            self.connect = connect

            self.future = (
                Future()
            )  # type: Future[Tuple[socket.AddressFamily, Any, IOStream]]
            self.timeout = None  # type: Optional[object]
            self.connect_timeout = None  # type: Optional[object]
            self.last_error = None  # type: Optional[Exception]
            self.remaining = len(addrinfo)

# Generated at 2022-06-18 10:49:40.159896
# Unit test for method try_connect of class _Connector

# Generated at 2022-06-18 10:49:50.899250
# Unit test for method clear_timeout of class _Connector

# Generated at 2022-06-18 10:49:59.898095
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado
    import socket
    import ssl
    import time
    import sys
    import os
    import logging
    import unittest
    import warnings
    import contextlib
    import functools
    import concurrent.futures
    import concurrent.futures
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing


# Generated at 2022-06-18 10:50:09.257720
# Unit test for method close_streams of class _Connector

# Generated at 2022-06-18 10:50:19.781538
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback

# Generated at 2022-06-18 10:51:04.464651
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.netutil
    import tornado.iostream
    import tornado.gen
    import tornado.concurrent
    import tornado.tcpserver
    import tornado.iostream
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:51:15.314871
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import time
    import os
    import sys
    import logging
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.simple_httpclient
    import tornado.stack_context
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.concurrent
    import tornado.locks
    import tornado.queues
    import tornado.process
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.ioloop
    import tornado.i

# Generated at 2022-06-18 10:51:25.965380
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import unittest
    import unittest.mock as mock
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    from tornado.testing import AsyncTestCase, gen_test

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.io_loop = IOLoop.current()
            self.resolver = Resolver(io_loop=self.io_loop)
            self.connect = mock.Mock()
            self.connect.return_value = (IOStream(socket.socket()), Future())
            self.addrinfo = [(socket.AF_INET, ("127.0.0.1", 80))]

# Generated at 2022-06-18 10:51:31.949235
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Create a mock IOLoop
    mock_io_loop = IOLoop()
    # Create a mock IOStream
    mock_io_stream = IOStream()
    # Create a mock Future
    mock_future = Future()
    # Create a mock TimeoutError
    mock_timeout_error = TimeoutError()
    # Create a mock _Connector
    mock__Connector = _Connector(
        addrinfo=[
            (socket.AF_INET, ("127.0.0.1", 80)),
            (socket.AF_INET6, ("127.0.0.1", 80)),
        ],
        connect=lambda af, addr: (mock_io_stream, mock_future),
    )
    # Assign the mock IOLoop to the mock _Connector
    mock__Connector.io_loop = mock_io_loop
   

# Generated at 2022-06-18 10:51:37.522678
# Unit test for method start of class _Connector
def test__Connector_start():
    # Test case data
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 8080))]
    timeout = 0.3
    connect_timeout = 0.3
    # Construct the object
    connector = _Connector(addrinfo, None)
    # Call the method
    future = connector.start(timeout, connect_timeout)
    # Check the result
    assert future is not None


# Generated at 2022-06-18 10:51:46.802265
# Unit test for constructor of class _Connector
def test__Connector():
    from tornado.testing import AsyncTestCase, gen_test

    class TestConnector(AsyncTestCase):
        @gen_test
        def test_connector(self):
            def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
                stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
                future = Future()
                future_add_done_callback(
                    future, functools.partial(self.on_connect_done, stream)
                )
                stream.connect(addr, callback=lambda: future.set_result(stream))
                return stream, future


# Generated at 2022-06-18 10:51:56.428605
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:52:04.065127
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import socket
    import time
    import unittest

    AsyncIOMainLoop().install()

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            self.io_loop = IOLoop.current()
            self.connect = self.connect_impl
            self.addrinfo = [
                (socket.AF_INET, ("127.0.0.1", 80)),
                (socket.AF_INET6, ("127.0.0.1", 80)),
            ]
            self.connector = _Connector(self.addrinfo, self.connect)


# Generated at 2022-06-18 10:52:08.995435
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.iostream import StreamClosedError

    class TestCase(AsyncTestCase):
        @gen_test
        async def test_close_streams(self):
            stream = IOStream(socket.socket())
            stream.connect(("localhost", 80))
            await to_asyncio_future(stream.connect_future)
            connector = _Connector([], lambda af, addr: (stream, Future()))
            connector.close_streams()
            with self.assertRaises(StreamClosedError):
                await to_asyncio_future(stream.read_bytes(1))

    TestCase().test_close_streams()



# Generated at 2022-06-18 10:52:16.817375
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from asyncio import Future as AsyncioFuture
    from asyncio import get_event_loop
    from tornado import gen
    from typing import Any, Union, Dict, Tuple, List, Callable, Iterator, Optional, Set
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from typing import Coroutine
    class _ConnectorTest(AsyncTestCase):
        def setUp(self) -> None:
            super().setUp()
            self.resolver = Resolver()

# Generated at 2022-06-18 10:54:20.833317
# Unit test for method start of class _Connector
def test__Connector_start():
    # _Connector.start(timeout=_INITIAL_CONNECT_TIMEOUT, connect_timeout=None) -> Future[Tuple[socket.AddressFamily, Any, IOStream]]
    pass


# Generated at 2022-06-18 10:54:27.101418
# Unit test for method start of class _Connector
def test__Connector_start():
    import socket
    import tornado.testing
    import tornado.gen
    import tornado.iostream
    import tornado.tcpserver
    import tornado.platform.asyncio
    import asyncio
    import functools
    import tornado.netutil
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.gen
    import tornado.tcpserver
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.gen
    import tornado.tcpserver
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream

# Generated at 2022-06-18 10:54:34.762433
# Unit test for method try_connect of class _Connector

# Generated at 2022-06-18 10:54:40.868068
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super(_ConnectorTest, self).setUp()
            self.addrinfo = [
                (socket.AF_INET, ("127.0.0.1", 80)),
                (socket.AF_INET6, ("::1", 80)),
            ]
            self.connect_future = to_tornado_future(
                to_asyncio_future(asyncio.Future())
            )
            self.connect_future.set_result(None)


# Generated at 2022-06-18 10:54:49.966344
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado
    import tornado.testing
    import tornado.gen
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.testing
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import time

    class EchoServer(tornado.tcpserver.TCPServer):
        def handle_stream(self, stream, address):
            stream.read_until_close(stream.write)

    class TestTCPClient(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(TestTCPClient, self).setUp()
            self.server = EchoServer()
            self.server.listen(0)
            self.stream = None  # type: Optional[tornado.i

# Generated at 2022-06-18 10:54:58.981031
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock
    import socket
    import tornado.concurrent
    import tornado.iostream
    import tornado.ioloop
    import tornado.netutil
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import functools
    import ssl
    import typing
    import logging
    import sys
    import os
    import time
    import datetime
    import contextlib
    import concurrent.futures
    import threading
    import queue
    import logging
    import logging.handlers
    import traceback
    import io
    import collections
    import random
    import string
    import re
    import math
    import copy
    import inspect
    import json
    import base64
    import hashlib
    import hmac

# Generated at 2022-06-18 10:55:03.217239
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    from typing import Any, Union, Dict, Tuple, List, Callable, Iterator, Optional, Set
    import socket
    import functools
    import datetime
    import ssl
    import numbers
    import gen
    import gen.coroutine
    import gen.return_type
    import gen.engine
    import gen.with_timeout
    import gen.with_timeout.return_type
    import gen.with_timeout.engine
    import gen.with_timeout.with_timeout
    import gen.with_timeout.with_timeout.return_type
    import gen.with_timeout.with_timeout.engine
   

# Generated at 2022-06-18 10:55:07.339469
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.gen
    import tornado.concurrent
    import tornado.locks
    import tornado.queues
    import tornado.iostream
    import tornado.tcpserver
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.web


# Generated at 2022-06-18 10:55:12.354414
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.gen
    import tornado.concurrent
    import tornado.locks
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:55:20.507363
# Unit test for method on_connect_done of class _Connector