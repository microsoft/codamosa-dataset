

# Generated at 2022-06-18 10:47:01.378057
# Unit test for method on_connect_timeout of class _Connector

# Generated at 2022-06-18 10:47:04.996494
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test case data
    timeout = 0.3
    # Construct the object
    connector = _Connector([], None)
    # Execute the tested function
    connector.set_timeout(timeout)
    # Check the result
    assert connector.timeout is not None
    assert connector.timeout.deadline == IOLoop.current().time() + timeout

# Generated at 2022-06-18 10:47:15.480139
# Unit test for method start of class _Connector
def test__Connector_start():
    import pytest
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback

# Generated at 2022-06-18 10:47:18.751866
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test case data
    timeout = 0.3
    # Constructor test
    connector = _Connector([], None)
    # Method test
    connector.set_timeout(timeout)
    # Verify the result
    assert connector.timeout is not None

# Generated at 2022-06-18 10:47:29.141725
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    import unittest
    import time
    import socket
    import ssl
    import tornado.platform.asyncio
    import asyncio
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import AnyThreadEvent

# Generated at 2022-06-18 10:47:40.280411
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio
    import unittest

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.loop)

        def tearDown(self):
            self.loop.close()
            super(Test_Connector, self).tearDown()

        @gen_test
        async def test_clear_timeouts(self):
            def connect(af, addr):
                stream

# Generated at 2022-06-18 10:47:50.881592
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

    class TestConnector(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.io_loop = IOLoop.current()
            self.stream = IOStream(socket.socket(), io_loop=self.io_loop)
            self.stream.set_close_callback(self.stop)
            self.stream.connect(("localhost", 0))
            self.wait()

# Generated at 2022-06-18 10:47:54.601134
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock as mock
    import socket
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.gen import TimeoutError
    from typing import Any, Union, Dict, Tuple, List, Callable, Iterator, Optional, Set
    from typing import cast
    from typing import TYPE_CHECKING
    from typing import TypeVar
    from typing import Generic
    from typing import Type
    from typing import cast
    from typing import Any
    from typing import Callable
    from typing import Dict
    from typing import Iterator
    from typing import List
    from typing import Optional
    from typing import Set
   

# Generated at 2022-06-18 10:48:04.501642
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_asyncio_future

    class TestConnector(AsyncTestCase):
        def setUp(self):
            super(TestConnector, self).setUp()
            self.connector = _Connector(
                [
                    (socket.AF_INET, ("127.0.0.1", 80)),
                    (socket.AF_INET6, ("::1", 80)),
                ],
                self.connect,
            )


# Generated at 2022-06-18 10:48:05.843796
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # test_connector = _Connector(addrinfo, connect)
    # test_connector.set_timeout(timeout)
    pass


# Generated at 2022-06-18 10:48:32.585107
# Unit test for method on_connect_timeout of class _Connector

# Generated at 2022-06-18 10:48:42.038127
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import time
    import random
    import functools
    import socket
    import ssl
    import logging
    import sys
    import os
    import io
    import unittest
    from contextlib import redirect_stdout
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado import gen
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    from typing import Any, Union, Dict, Tuple, List, Callable, Iterator, Optional, Set


# Generated at 2022-06-18 10:48:52.694345
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import time
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.io_loop = IOLoop.current()
            self.resolver = Resolver()
            self.resolver.configure(
                resolver=None,
                io_loop=self.io_loop,
                defaults=dict(family=socket.AF_INET),
            )


# Generated at 2022-06-18 10:49:04.497229
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    from tornado.testing import AsyncTestCase, gen_test
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import asyncio
    import aiohttp
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.iostream
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.util
    import tornado.queues
    import tornado.locks
    import tornado.stack_context
    import tornado.process
    import tornado.ioloop
    import tornado.iostream


# Generated at 2022-06-18 10:49:13.369388
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class _ConnectorTest(AsyncTestCase):
        def test_set_timeout(self):
            def connect(af, addr):
                return (
                    IOStream(socket.socket(af, socket.SOCK_STREAM)),
                    Future(),
                )

            addrinfo = [(socket.AF_INET, ("127.0.0.1", 80))]
            connector = _Connector(addrinfo, connect)
            connector.start(timeout=0.1)
            self.assertEqual(connector.timeout, None)
            time.sleep(0.2)
            self.assertEqual(connector.timeout, None)

    unittest.main()



# Generated at 2022-06-18 10:49:22.554821
# Unit test for method split of class _Connector
def test__Connector_split():
    # Test case 1
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 80)), (socket.AF_INET6, ('::1', 80))]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ('127.0.0.1', 80))]
    assert secondary == [(socket.AF_INET6, ('::1', 80))]

    # Test case 2
    addrinfo = [(socket.AF_INET6, ('::1', 80)), (socket.AF_INET, ('127.0.0.1', 80))]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET6, ('::1', 80))]

# Generated at 2022-06-18 10:49:33.023285
# Unit test for constructor of class _Connector
def test__Connector():
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()

    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("2001:db8::1", 80)),
    ]
    connector = _Connector(addrinfo, connect)
    assert connector.io_loop == IOLoop.current()
    assert connector.connect == connect
    assert isinstance(connector.future, Future)
    assert connector.timeout is None
    assert connector.connect_timeout is None
    assert connector.last_error is None
    assert connector.remaining == 2

# Generated at 2022-06-18 10:49:42.877577
# Unit test for method split of class _Connector
def test__Connector_split():
    # type: () -> None
    """
    Test the method split of class _Connector
    """
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("127.0.0.1", 80))]
    assert secondary == [(socket.AF_INET6, ("127.0.0.1", 80))]



# Generated at 2022-06-18 10:49:50.692048
# Unit test for method start of class _Connector
def test__Connector_start():
    # Test case data
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    timeout = 0.3
    connect_timeout = 0.3
    # Constructor test
    connector = _Connector(addrinfo, None)
    # Method test
    connector.start(timeout, connect_timeout)



# Generated at 2022-06-18 10:49:59.739382
# Unit test for method split of class _Connector
def test__Connector_split():
    # type: () -> None
    """
    Test case for _Connector.split
    """
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)

# Generated at 2022-06-18 10:50:34.184922
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Test case data
    timeout = None
    future = None
    secondary_addrs = None
    io_loop = None
    # Constructor test
    connector = _Connector(addrinfo=None, connect=None)
    # Test __init__()
    assert connector

    # Test on_timeout()
    connector.on_timeout()
    # __repr__() returns a string containing a printable
    # representation of an object.
    # This method is meant to be overridden in subclasses.
    # Note: repr() is a built-in function in Python.
    assert repr(connector)



# Generated at 2022-06-18 10:50:43.653127
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    from tornado.httpclient import AsyncHTTPClient
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    import tornado.ioloop
    import tornado.web
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:50:46.797574
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test for method set_timeout(self, timeout)
    # of class _Connector
    # This test is not complete
    # It is only a placeholder for future tests
    assert True


# Generated at 2022-06-18 10:50:47.320261
# Unit test for method start of class _Connector
def test__Connector_start():
    pass

# Generated at 2022-06-18 10:50:52.131295
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    async def test():
        client = TCPClient()
        stream = await client.connect('www.google.com', 80)
        stream.close()
    asyncio.get_event_loop().run_until_complete(test())

# Generated at 2022-06-18 10:51:02.992339
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test that on_connect_timeout sets the future to a TimeoutError
    # if it is not already done
    connector = _Connector([], lambda af, addr: (None, None))
    connector.future = Future()
    connector.on_connect_timeout()
    assert isinstance(connector.future.exception(), TimeoutError)
    # Test that on_connect_timeout does not set the future to a
    # TimeoutError if it is already done
    connector = _Connector([], lambda af, addr: (None, None))
    connector.future = Future()
    connector.future.set_result(None)
    connector.on_connect_timeout()
    assert connector.future.exception() is None



# Generated at 2022-06-18 10:51:13.624779
# Unit test for method clear_timeout of class _Connector

# Generated at 2022-06-18 10:51:24.601529
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import time
    import sys
    import os
    import subprocess
    import signal
    import socket
    import threading
    import logging
    import tornado.log
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.concurrent
    import tornado.tcpserver
    import tornado.httpserver
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.web
    import tornado.websocket
    import tornado.locks
    import tornado.queues
    import tornado.process
    import tornado.ioloop
    import tornado.iostream
    import tornado

# Generated at 2022-06-18 10:51:31.955974
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case data
    timeout = 0.3
    connect_timeout = 0.3
    # Perform the test
    test = _Connector([], lambda x, y: (None, None))
    test.future = Future()
    test.set_timeout(timeout)
    test.set_connect_timeout(connect_timeout)
    test.on_connect_timeout()
    # Check the result
    assert test.future.done()
    assert test.future.exception() == TimeoutError()
    assert test.timeout is None
    assert test.connect_timeout is None



# Generated at 2022-06-18 10:51:41.897816
# Unit test for method close_streams of class _Connector

# Generated at 2022-06-18 10:52:47.215518
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.testing import bind_unused_port
    from tornado.tcpserver import TCPServer
    from tornado.iostream import IOStream
    from tornado.gen import TimeoutError
    from tornado.testing import bind_unused_port
    from tornado.tcpserver import TCPServer
    from tornado.iostream import IOStream
    from tornado.gen import TimeoutError
    from tornado.testing import bind_unused_port
    from tornado.tcpserver import TCPServer
   

# Generated at 2022-06-18 10:52:57.081831
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import unittest

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            AsyncIOMainLoop().install()
            self.loop = asyncio.get_event_loop()
            self.io_loop = IOLoop.current()

        @gen_test
        def test_clear_timeout(self):
            def connect(af, addr):
                return (
                    IOStream(socket.socket(af, socket.SOCK_STREAM)),
                    Future(),
                )

            addrinfo = [(socket.AF_INET, ("127.0.0.1", 80))]

# Generated at 2022-06-18 10:53:04.487812
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    class MockIOStream:
        def __init__(self):
            self.closed = False
        def close(self):
            self.closed = True
    class MockIOLoop:
        def __init__(self):
            self.timeouts = []
        def add_timeout(self, time, callback):
            self.timeouts.append((time, callback))
            return len(self.timeouts)
        def remove_timeout(self, timeout):
            self.timeouts.remove(timeout)
    class MockFuture:
        def __init__(self):
            self.done = False
        def set_exception(self, exception):
            self.done = True

# Generated at 2022-06-18 10:53:06.210627
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case data
    connector = _Connector(None, None)
    # Perform the test
    connector.on_connect_timeout()
    # Validate the results



# Generated at 2022-06-18 10:53:15.595855
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.netutil import bind_sockets
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOM

# Generated at 2022-06-18 10:53:22.117616
# Unit test for constructor of class _Connector
def test__Connector():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
    ]
    def connect(af, addr):
        return (None, None)
    _Connector(addrinfo, connect)


# Generated at 2022-06-18 10:53:31.920994
# Unit test for method set_connect_timeout of class _Connector

# Generated at 2022-06-18 10:53:39.285879
# Unit test for constructor of class _Connector
def test__Connector():
    # type: () -> None
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80))]
    connector = _Connector(addrinfo, lambda af, addr: (None, None))
    assert connector.io_loop == IOLoop.current()
    assert connector.connect is not None
    assert connector.future is not None
    assert connector.timeout is None
    assert connector.connect_timeout is None
    assert connector.last_error is None
    assert connector.remaining == 1
    assert connector.primary_addrs == addrinfo
    assert connector.secondary_addrs == []
    assert connector.streams == set()



# Generated at 2022-06-18 10:53:47.214328
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    import asyncio
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.iostream
    import tornado.tcpserver
    import tornado.netutil
    import tornado.gen
    import tornado.locks
    import tornado.queues
    import tornado.stack_context
    import tornado.escape
    import tornado.httputil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.netutil
    import tornado.tcpserver
    import tornado.iost

# Generated at 2022-06-18 10:53:58.259356
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:56:07.387722
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import ssl
    import socket
    import os
    import sys
    import logging
    import time
    import datetime
    import tornado.gen
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.tcpserver
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.httputil
    import tornado.httpclient
    import tornado.escape
    import tornado.locks
    import tornado.queues
    import tornado.stack_context
    import tornado.template
    import tornado.util
    import tornado.process
    import tornado.netutil
   

# Generated at 2022-06-18 10:56:13.710719
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future


# Generated at 2022-06-18 10:56:16.683066
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    # Test case data
    connect_timeout = 0.3
    # Perform the test
    connector = _Connector([], lambda af, addr: (None, None))
    connector.set_connect_timeout(connect_timeout)
    # Post-test assertions
    assert connector.connect_timeout is not None



# Generated at 2022-06-18 10:56:24.606081
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Test that the method clear_timeouts of class _Connector
    # removes all timeouts
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import time
    from tornado.testing import AsyncTestCase, gen_test

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super().setUp()
            tornado.platform.asyncio.AsyncIOMainLoop().install()
            self.loop = asyncio.get_event_loop()
            self.io_loop = tornado.ioloop.IOLoop.current()
            self.io_loop.make_current()
            self.io_loop.clear_timeouts()

        def tearDown(self):
            self.io_loop.clear_timeouts()

# Generated at 2022-06-18 10:56:32.548754
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
   