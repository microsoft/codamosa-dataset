

# Generated at 2022-06-18 10:47:00.395260
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock
    import socket
    import ssl
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.concurrent
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import functools
    import typing
    import sys
    import os
    import time
    import threading
    import logging
    import logging.config
    import logging.handlers
    import datetime
    import json
    import random
    import string
    import contextlib
    import io
    import socket
    import ssl
    import tornado.concurrent
    import tornado.gen
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:47:07.023820
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # Test case 1
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
    ]
    connect = lambda af, addr: (None, None)
    connector = _Connector(addrinfo, connect)
    connector.try_connect(iter(connector.primary_addrs))
    assert connector.remaining == 2
    assert connector.last_error is None
    assert connector.timeout is None
    assert connector.connect_timeout is None
    assert connector.future.done() is False
    assert connector.streams == set()

    # Test case 2

# Generated at 2022-06-18 10:47:17.053029
# Unit test for constructor of class _Connector
def test__Connector():
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET6, ("127.0.0.1", 80))]
    def connect(af, addr):
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()
    connector = _Connector(addrinfo, connect)
    assert connector.io_loop == IOLoop.current()
    assert connector.connect == connect
    assert connector.future.done() == False
    assert connector.timeout == None
    assert connector.connect_timeout == None
    assert connector.last_error == None
    assert connector.remaining == 2
    assert connector.primary_addrs == [(socket.AF_INET, ("127.0.0.1", 80))]

# Generated at 2022-06-18 10:47:27.893035
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import unittest
    import unittest.mock
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.gen
    import tornado.concurrent
    import socket
    import ssl
    import functools
    import typing
    import numbers
    import datetime
    import collections
    import itertools
    import contextlib
    import logging
    import sys
    import os
    import io
    import time
    import random
    import string
    import tempfile
    import threading
    import concurrent.futures
    import concurrent.futures._base
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread

# Generated at 2022-06-18 10:47:40.122315
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:47:50.844231
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_asyncio_future

    class TestConnector(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.connector = _Connector(
                [],
                lambda af, addr: (
                    IOStream(socket.socket(af, socket.SOCK_STREAM)),
                    to_asyncio_future(Future()),
                ),
            )
            self.connector.future = Future()
            self.connector.io_loop = self.io_loop

        @gen_test
        async def test_on_connect_timeout(self):
            self.connector.set_connect_timeout(0.1)

# Generated at 2022-06-18 10:47:55.556393
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.netutil
    import tornado.iostream
    import tornado.gen
    import tornado.concurrent
    import tornado.tcpserver
    import tornado.escape
    import tornado.httpclient
    import tornado.httputil
    import tornado.locks
    import tornado.log
    import tornado.options
    import tornado.process
    import tornado.queues
    import tornado.stack_context
    import tornado.template
    import tornado.test
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.iostream

# Generated at 2022-06-18 10:48:05.319015
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import time
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future

    class TestConnector(AsyncTestCase):
        def setUp(self):
            super(TestConnector, self).setUp()
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.connector = _Connector(
                [(socket.AF_INET, ("127.0.0.1", 80))], self.connect
            )


# Generated at 2022-06-18 10:48:11.717530
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import time
    import os
    import sys
    import logging
    import tornado.gen
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.tcpserver
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.httputil
    import tornado.httpclient
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:48:20.563537
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case 1:
    # Test if the future is set to exception when the connection times out
    # and the future is not done yet
    connector = _Connector([], lambda x, y: (None, None))
    connector.future = Future()
    connector.on_connect_timeout()
    assert connector.future.exception() == TimeoutError()

    # Test case 2:
    # Test if the future is not set to exception when the connection times out
    # and the future is done
    connector = _Connector([], lambda x, y: (None, None))
    connector.future = Future()
    connector.future.set_result(None)
    connector.on_connect_timeout()
    assert connector.future.exception() == None



# Generated at 2022-06-18 10:48:51.833316
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import time
    import socket
    import ssl
    import os
    import sys
    import threading
    import logging
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.stack_context
    import tornado.testing
    import tornado.test.util
    import tornado.test.httpclient_test
    import tornado.test.httpserver_test
    import tornado.test.util
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio


# Generated at 2022-06-18 10:48:58.004826
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import functools
    import tornado.iostream
    import tornado.gen
    import tornado.concurrent
    import tornado.ioloop
    import tornado.netutil
    import tornado.tcpserver
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.httputil
    import tornado.httpclient
    import tornado.escape
    import tornado.locks
    import tornado.log
    import tornado.options
    import tornado.process
    import tornado.stack_context
    import tornado.template
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.webs

# Generated at 2022-06-18 10:48:59.901091
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test for method set_timeout(self, timeout)
    # of class _Connector
    pass



# Generated at 2022-06-18 10:49:09.707614
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # Test that close_streams closes all streams in self.streams
    # Create a _Connector object
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80))]
    def connect(af, addr):
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()
    connector = _Connector(addrinfo, connect)
    # Create a stream and add it to self.streams
    stream = IOStream(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
    connector.streams.add(stream)
    # Call close_streams
    connector.close_streams()
    # Check that the stream is closed
    assert stream.closed()



# Generated at 2022-06-18 10:49:15.454881
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    asyncio.set_event_loop(asyncio.new_event_loop())
    loop = asyncio.get_event_loop()
    client = TCPClient()
    stream = loop.run_until_complete(client.connect('www.google.com', 80))
    print(stream)
    loop.close()

if __name__ == '__main__':
    test_TCPClient_connect()

# Generated at 2022-06-18 10:49:22.383004
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.netutil import bind_sockets
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    import asyncio
    import socket
    import time

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super(_ConnectorTest, self).setUp()
            self.sockets = bind_sockets(0, "127.0.0.1")
            self.port = self.sockets[0].getsockname()[1]
            self.server_future = to_asyncio_future(self.io_loop.add_callback)

# Generated at 2022-06-18 10:49:32.878417
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock
    import socket
    import ssl
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import tornado.gen
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.gen
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.gen
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil

# Generated at 2022-06-18 10:49:43.024453
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import unittest

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            self.io_loop = IOLoop.current()
            self.connect = lambda af, addr: (None, None)
            self.addrinfo = [(socket.AF_INET, ("127.0.0.1", 8080))]
            self.connector = _Connector(self.addrinfo, self.connect)

        @gen_test
        def test_set_timeout(self):
            timeout = 0.3
            self.connector.start(timeout)
            yield gen.sleep(timeout + 0.1)

# Generated at 2022-06-18 10:49:53.329013
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("2001:db8::1", 80)),
        (socket.AF_INET, ("127.0.0.1", 8080)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("127.0.0.1", 8080))]
    assert secondary == [(socket.AF_INET6, ("2001:db8::1", 80))]



# Generated at 2022-06-18 10:50:01.700580
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import socket
    import time

    class Test_Connector(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.platform.asyncio.AsyncIOLoop()
            self.io_loop.make_current()
            asyncio.set_event_loop(self.io_loop._asyncio_loop)

        def tearDown(self):
            self.io_loop.close()

        def test_try_connect(self):
            def connect(af, addr):
                stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
                future = Future()

# Generated at 2022-06-18 10:50:37.318269
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Test that clear_timeouts removes both timeouts
    io_loop = IOLoop.current()
    timeout = io_loop.add_timeout(io_loop.time() + 1, lambda: None)
    connect_timeout = io_loop.add_timeout(io_loop.time() + 1, lambda: None)
    connector = _Connector([], lambda af, addr: (None, None))
    connector.timeout = timeout
    connector.connect_timeout = connect_timeout
    connector.clear_timeouts()
    assert timeout not in io_loop._timeouts
    assert connect_timeout not in io_loop._timeouts


# Generated at 2022-06-18 10:50:47.077519
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.testing import AsyncTestCase, gen_test

    class TestConnector(AsyncTestCase):
        def test_connect(self):
            # type: () -> None
            connector = _Connector(
                [(socket.AF_INET, ("127.0.0.1", 80))],
                lambda af, addr: (
                    IOStream(socket.socket(af, socket.SOCK_STREAM)),
                    Future(),
                ),
            )
            future = connector.start()
            self.assertFalse(future.done())
            connector.on_timeout()
            self.assertTrue(future.done())
            self.assertEqual(future.result()[0], socket.AF_INET)
            self.assertEqual(future.result()[1], ("127.0.0.1", 80))


# Generated at 2022-06-18 10:50:57.322845
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Test case data
    timeout = None
    future = None
    io_loop = None
    secondary_addrs = None
    # Constructor test
    connector = _Connector(addrinfo, connect)
    # Test __init__()
    assert connector.io_loop == io_loop
    assert connector.connect == connect
    assert connector.future == future
    assert connector.timeout == timeout
    assert connector.connect_timeout == timeout
    assert connector.last_error == timeout
    assert connector.remaining == len(addrinfo)
    assert connector.primary_addrs == primary
    assert connector.secondary_addrs == secondary
    assert connector.streams == set()
    # Test on_timeout()
    connector.on_timeout()
    assert connector.timeout == timeout
    assert connector.future.done() == False
    assert connector.try_

# Generated at 2022-06-18 10:51:00.770589
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # Test for method clear_timeout(self)
    # of class _Connector
    # This test is not implemented.
    pass



# Generated at 2022-06-18 10:51:03.642193
# Unit test for method start of class _Connector
def test__Connector_start():
    # Test for method start(self, timeout = _INITIAL_CONNECT_TIMEOUT, connect_timeout = None)
    # of class _Connector
    pass



# Generated at 2022-06-18 10:51:14.265824
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("::1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
        (socket.AF_INET6, ("::2", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
    ]
    assert secondary == [
        (socket.AF_INET6, ("::1", 80)),
        (socket.AF_INET6, ("::2", 80)),
    ]



# Generated at 2022-06-18 10:51:25.127446
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import time
    import os
    import sys
    import logging
    import unittest
    import json
    import tornado.ioloop
    import tornado.iostream
    import tornado.gen
    import tornado.concurrent
    import tornado.httpclient
    import tornado.httputil
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.escape
    import tornado.locks
    import tornado.queues
    import tornado.stack_context
    import tornado.template
    import tornado.util
    import tornado.process
    import tornado.tcpserver
    import tornado

# Generated at 2022-06-18 10:51:35.756646
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.connector = _Connector(
                [
                    (socket.AF_INET, ("127.0.0.1", 80)),
                    (socket.AF_INET6, ("::1", 80)),
                ],
                self.connect,
            )
            self.future = self.connector.start(
                timeout=0.1, connect_timeout=0.1
            )


# Generated at 2022-06-18 10:51:38.647091
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    # Test for method set_connect_timeout(self, connect_timeout)
    # of class _Connector
    # This test is not applicable for this class
    pass



# Generated at 2022-06-18 10:51:42.391404
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test case data
    timeout = 0.3
    # Construct the object
    connector = _Connector([], lambda af, addr: (None, None))
    # Call the method
    connector.set_timeout(timeout)
    # Check the result
    assert connector.timeout is not None


# Generated at 2022-06-18 10:52:52.390904
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # _Connector.clear_timeouts
    # This method is tested in test_tcpclient.py
    pass



# Generated at 2022-06-18 10:53:01.865830
# Unit test for constructor of class _Connector
def test__Connector():
    import unittest
    import unittest.mock
    import functools
    import socket
    import ssl
    import tornado.concurrent
    import tornado.gen
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.test.util
    import tornado.test.gen_test

    def test_connect(
        af: socket.AddressFamily, addr: Tuple[str, int]
    ) -> Tuple[tornado.iostream.IOStream, tornado.concurrent.Future[tornado.iostream.IOStream]]:
        stream = tornado.iostream.IOStream(socket.socket(af, socket.SOCK_STREAM))
        future = tornado.concurrent.Future()
        future.set_result(stream)
        return stream, future


# Generated at 2022-06-18 10:53:07.073881
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    import time
    import logging
    import sys
    import unittest
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.testing
    import tornado.gen
    import tornado.httpserver
    import tornado.httputil
    import tornado.httpclient
    import tornado.escape
    import tornado.ioloop
    import tornado.options
    import tornado.web
    import tornado.websocket
    import tornado.template
    import tornado.concurrent
    import tornado.locks
   

# Generated at 2022-06-18 10:53:08.997339
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # Test for method close_streams(self)
    # of class _Connector
    # This method is tested implicitly by test_connect_timeout
    pass



# Generated at 2022-06-18 10:53:14.652460
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 80)), (socket.AF_INET6, ('::1', 80))]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ('127.0.0.1', 80))]
    assert secondary == [(socket.AF_INET6, ('::1', 80))]


# Generated at 2022-06-18 10:53:20.357830
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test case data
    timeout = 0.3
    # Construct the object
    connector = _Connector([(socket.AF_INET, ('127.0.0.1', 80))], None)
    # Call the method
    connector.set_timeout(timeout)
    # Check the result
    assert connector.timeout is not None


# Generated at 2022-06-18 10:53:27.374703
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:53:37.643823
# Unit test for method close_streams of class _Connector

# Generated at 2022-06-18 10:53:45.781670
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import logging
    import sys
    import os
    import time
    import random
    import string
    import tempfile
    import functools
    import unittest
    import unittest.mock
    import concurrent.futures
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
   

# Generated at 2022-06-18 10:53:56.391919
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    import time
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.netutil import Resolver
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

# Generated at 2022-06-18 10:56:14.037113
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test that on_connect_timeout raises a TimeoutError
    # if the future is not done
    #
    # Arrange
    connector = _Connector([], lambda af, addr: (None, None))
    connector.future = Future()
    connector.future.set_result(None)
    # Act
    connector.on_connect_timeout()
    # Assert
    assert connector.future.exception() == None



# Generated at 2022-06-18 10:56:19.056274
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

    class TestConnector(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.io_loop = IOLoop.current()

# Generated at 2022-06-18 10:56:27.063072
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import unittest
    import unittest.mock as mock
    import tornado.testing as testing
    import tornado.platform.asyncio as asyncio
    import asyncio as aio

    class Test__Connector_on_timeout(testing.AsyncTestCase):
        def setUp(self):
            super(Test__Connector_on_timeout, self).setUp()
            self.io_loop = IOLoop.current()
            self.connect = mock.Mock()
            self.future = Future()
            self.timeout = None
            self.connect_timeout = None
            self.last_error = None
            self.remaining = 2
            self.primary_addrs = [(socket.AF_INET, ("127.0.0.1", 80))]