

# Generated at 2022-06-18 10:46:56.852186
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test for method set_timeout(self, timeout)
    # of class _Connector
    # This test is not complete.
    # It is not possible to test the timeout functionality
    # without a running IOLoop.
    # The test is only to check that the method does not crash.
    # The test is not complete.
    # It is not possible to test the timeout functionality
    # without a running IOLoop.
    # The test is only to check that the method does not crash.
    def connect(af, addr):
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()

    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80))]
    connector = _Connector(addrinfo, connect)
    connector.start()



# Generated at 2022-06-18 10:47:05.299909
# Unit test for method split of class _Connector
def test__Connector_split():
    from typing import List, Tuple
    from socket import AddressFamily
    from unittest import TestCase
    from unittest.mock import Mock

    class Test(TestCase):
        def test_split(self):
            addrinfo = [
                (AddressFamily.AF_INET, ("127.0.0.1", 80)),
                (AddressFamily.AF_INET6, ("::1", 80)),
                (AddressFamily.AF_INET, ("127.0.0.2", 80)),
                (AddressFamily.AF_INET6, ("::2", 80)),
            ]
            primary, secondary = _Connector.split(addrinfo)

# Generated at 2022-06-18 10:47:15.640055
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from unittest import mock
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import bind_unused_port
    from tornado.testing import ExpectLog
    from tornado.testing import LogTrapTestCase
    from tornado.testing import main
    from tornado.testing import run_on_executor
    from tornado.testing import gen_test
    from tornado.gen import TimeoutError
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.netutil import Res

# Generated at 2022-06-18 10:47:26.425454
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock as mock
    import socket
    import tornado.testing as testing
    import tornado.concurrent as concurrent
    import tornado.iostream as iostream
    import tornado.netutil as netutil
    import tornado.platform.asyncio as asyncio
    import asyncio as asyncio_std
    import tornado.gen as gen
    import tornado.ioloop as ioloop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import is_future
    from tornado.platform.asyncio import is_cor

# Generated at 2022-06-18 10:47:38.851369
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:47:45.730370
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import unittest
    import unittest.mock as mock
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado

# Generated at 2022-06-18 10:47:53.708514
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado.platform.asyncio
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import socket
    import ssl
    import functools
    import tornado.concurrent
    import tornado.gen
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.testing
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
   

# Generated at 2022-06-18 10:48:03.811625
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import time

    class TestCase(AsyncTestCase):
        def setUp(self):
            super(TestCase, self).setUp()
            self.io_loop = IOLoop.current()
            self.io_loop.make_current()
            self.io_loop.install()
            self.connector = _Connector([], lambda af, addr: (None, None))

        @gen_test
        async def test_set_timeout(self):
            self.connector.set_timeout(0.1)
            await asyncio.sleep(0.2)
            self.assertTrue(self.connector.future.done())

    AsyncIOMainLoop().install()

# Generated at 2022-06-18 10:48:10.090033
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super(_ConnectorTest, self).setUp()
            self.connector = _Connector(
                [],
                lambda af, addr: (
                    IOStream(socket.socket(af, socket.SOCK_STREAM)),
                    Future(),
                ),
            )

        @gen_test
        def test_set_connect_timeout(self):
            self.connector.set_connect_timeout(0.1)
            yield gen.sleep(0.2)
            self.assertTrue(self.connector.future.done())
            self.assertTrue(isinstance(self.connector.future.exception(), TimeoutError))


# Generated at 2022-06-18 10:48:18.510989
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("2001:db8::1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("127.0.0.2", 80))]
    assert secondary == [(socket.AF_INET6, ("2001:db8::1", 80))]



# Generated at 2022-06-18 10:48:49.718751
# Unit test for method start of class _Connector
def test__Connector_start():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.iostream import StreamClosedError
    from tornado.netutil import bind_sockets
    from tornado.testing import bind_unused_port

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.sockets = bind_sockets(0, "127.0.0.1", family=socket.AF_INET)
            self.port = self.sockets[0].getsockname()[1]
            self.server_started = False
            self.server_stopped = False
            self.server_stream = None  # type: Optional[IOStream]

# Generated at 2022-06-18 10:48:57.195162
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock as mock
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            self.io_loop = IOLoop.current()
            self.connect = mock.Mock()
            self.connector = _Connector(
                addrinfo=[(socket.AF_INET, ("127.0.0.1", 80))],
                connect=self.connect,
            )
            self.connector.io_loop = self.io_loop


# Generated at 2022-06-18 10:49:08.176408
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import tornado.platform.asyncio
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.gen
    import tornado.concurrent
    import socket
    import ssl
    import functools
    import numbers
    import datetime
    import ssl
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing

# Generated at 2022-06-18 10:49:19.216091
# Unit test for constructor of class _Connector
def test__Connector():
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()

    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET6, ("127.0.0.1", 80))]
    connector = _Connector(addrinfo, connect)
    assert connector.io_loop == IOLoop.current()
    assert connector.connect == connect
    assert connector.future.done() == False
    assert connector.timeout == None
    assert connector.connect_timeout == None
    assert connector.last_error == None
    assert connector.remaining == 2

# Generated at 2022-06-18 10:49:27.515108
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80))]
    assert secondary == [
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]



# Generated at 2022-06-18 10:49:39.801440
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("2001:db8::1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
        (socket.AF_INET6, ("2001:db8::2", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
    ]

# Generated at 2022-06-18 10:49:42.663536
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case data
    connector = _Connector([(1,2)], lambda x,y: (1,2))
    connector.future = Future()

    # Perform the test
    connector.on_connect_timeout()

    # Check the result
    assert connector.future.result() == TimeoutError()


# Generated at 2022-06-18 10:49:54.318858
# Unit test for method clear_timeout of class _Connector

# Generated at 2022-06-18 10:49:58.111436
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:50:05.045474
# Unit test for method clear_timeout of class _Connector

# Generated at 2022-06-18 10:50:43.968559
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:50:54.133834
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import time
    import unittest

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            AsyncIOMainLoop().install()
            self.loop = asyncio.get_event_loop()

        @gen_test
        async def test_on_connect_timeout(self):
            def connect(af, addr):
                stream = IOStream(socket.socket(af, socket.SOCK_STREAM), io_loop=self.io_loop)
                future = Future()
                future.set_result(stream)
                return stream, future


# Generated at 2022-06-18 10:50:59.612979
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Test that clear_timeouts removes both timeouts
    c = _Connector([], lambda af, addr: (None, None))
    c.timeout = object()
    c.connect_timeout = object()
    c.clear_timeouts()
    assert c.timeout is None
    assert c.connect_timeout is None



# Generated at 2022-06-18 10:51:10.304552
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import socket
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import functools
    import logging
    import sys
    import unittest

    class TestConnector(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.platform.asyncio.AsyncIOLoop()
            self.io_loop.make_current()
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
            self.sock.bind(("127.0.0.1", 0))
            self.sock.listen(1)
            self.port = self.sock.getsockname()[1]

# Generated at 2022-06-18 10:51:21.161713
# Unit test for constructor of class _Connector
def test__Connector():
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET6, ("127.0.0.1", 80))]
    connector = _Connector(addrinfo, connect)
    assert connector.io_loop == IOLoop.current()
    assert connector.connect == connect
    assert connector.future.done() == False
    assert connector.timeout == None
    assert connector.connect_timeout == None
    assert connector.last_error == None
    assert connector.remaining == 2

# Generated at 2022-06-18 10:51:29.645090
# Unit test for method set_timeout of class _Connector

# Generated at 2022-06-18 10:51:40.016947
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    import unittest.mock
    import io
    import socket
    import ssl
    import functools
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import concurrent.futures
    import typing
    import contextlib
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.concurrent
    import tornado.gen
    import tornado.httpclient
    import tornado.httpserver
    import tornado.httputil
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.process
    import tornado.simple_httpclient
   

# Generated at 2022-06-18 10:51:43.751440
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test case data
    timeout = 0.3
    # Construct the object
    connector = _Connector([], lambda af, addr: (None, None))
    # Call the method
    connector.set_timeout(timeout)
    # Check the result
    assert connector.timeout is not None


# Generated at 2022-06-18 10:51:50.328654
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    import asyncio
    import tornado.platform.asyncio
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.tcpserver
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.concurrent
    import tornado.gen
    import tornado.locks
    import tornado.queues
    import tornado.iostream
    import tornado.tcpserver
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.concurrent
    import tornado.gen
    import tornado.locks
   

# Generated at 2022-06-18 10:51:59.785243
# Unit test for constructor of class _Connector
def test__Connector():
    # type: () -> None
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("::1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
        (socket.AF_INET6, ("::2", 80)),
    ]
    connector = _Connector(addrinfo, None)
    assert connector.io_loop == IOLoop.current()
    assert connector.connect is None
    assert connector.future.done() is False
    assert connector.timeout is None
    assert connector.connect_timeout is None
    assert connector.last_error is None
    assert connector.remaining == 4

# Generated at 2022-06-18 10:53:17.149118
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.iostream import IOStream
    import asyncio
    import socket
    import time
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
   

# Generated at 2022-06-18 10:53:26.187880
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import pytest
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.test.util import unittest
    from tornado.util import Configurable
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_stream
    from tornado.platform.asyncio import to_tornado_stream

# Generated at 2022-06-18 10:53:36.517384
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import time
    import logging
    import sys
    import os
    import unittest
    import tornado.netutil
    import tornado.iostream
    import tornado.ioloop
    import tornado.gen
    import tornado.concurrent
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.tcpserver
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.tcpserver
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.test.httpclient_test
    import tornado.test.httpserver_test
    import tornado.test.ioloop_

# Generated at 2022-06-18 10:53:44.799245
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:53:49.095082
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    io_loop = IOLoop.current()
    future = Future()
    future.set_result(None)
    stream = IOStream(socket.socket(), io_loop=io_loop)
    connector = _Connector([], lambda af, addr: (stream, future))
    connector.streams = set([stream])
    connector.close_streams()
    assert stream.closed()



# Generated at 2022-06-18 10:53:53.876976
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    # Test case data
    timeout = 0.3
    connect_timeout = 0.3
    # Perform the test
    test = _Connector([], lambda x, y: (None, None))
    test.set_connect_timeout(connect_timeout)
    # Post-test assertions
    assert test.connect_timeout is not None


# Generated at 2022-06-18 10:53:58.965622
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import unittest
    import unittest.mock as mock
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    import asyncio
    import socket
    import ssl
    import time
    import functools
    import sys
    import os
    import logging
    import logging.handlers
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:54:08.818046
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import pytest
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import socket
    import ssl
    import time
    import os
    import sys
    import logging
    from typing import Any, Union, Dict, Tuple, List, Callable, Iterator, Optional, Set
    from typing import TYPE_CHECKING
    from typing import cast
    from typing import overload
    from typing import TypeVar
    from typing import Generic
    from typing import AnyStr
    from typing import Type
    from typing import List
    from typing import Tuple
    from typing import Dict
    from typing import Optional

# Generated at 2022-06-18 10:54:18.559544
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import IOStream
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import socket

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            self.io_loop = IOLoop.current()
            self.io_loop.make_current()
            self.io_loop.asyncio_loop = asyncio.get_event_loop()
            self.io_loop.asyncio_loop._set_coroutine_origin_tracking_depth(0)
            self.io_loop.asyncio_loop.set_

# Generated at 2022-06-18 10:54:25.823846
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado