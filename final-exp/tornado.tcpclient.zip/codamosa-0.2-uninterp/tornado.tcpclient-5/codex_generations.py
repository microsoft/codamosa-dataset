

# Generated at 2022-06-18 10:47:02.435658
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:47:12.962736
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

# Generated at 2022-06-18 10:47:17.296681
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("fe80::1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
        (socket.AF_INET6, ("fe80::2", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
    ]

# Generated at 2022-06-18 10:47:22.142136
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import sys
    import os
    import time
    import tornado.httpclient
    import tornado.httputil
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.locks
    import tornado.queues
    import tornado.process
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.test.httpclient_test
    import tornado.test.util
    import tornado.test.web_test
    import tornado.test.websocket_test
    import tornado.test.wsgi_test


# Generated at 2022-06-18 10:47:31.366013
# Unit test for method try_connect of class _Connector

# Generated at 2022-06-18 10:47:40.700829
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock as mock

    class MockIOLoop(object):
        def __init__(self):
            self.time = 0
            self.timeouts = []  # type: List[Tuple[float, Callable]]

        def add_timeout(self, timeout: float, callback: Callable) -> object:
            self.timeouts.append((timeout, callback))
            return object()

        def remove_timeout(self, timeout: object) -> None:
            pass

    class MockFuture(object):
        def __init__(self):
            self.done = False
            self.result = None  # type: Optional[Exception]

        def set_result(self, result: IOStream) -> None:
            self.done = True
            self.result = result


# Generated at 2022-06-18 10:47:51.098959
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    import asyncio
    import tornado
    import functools
    import socket
    import ssl
    import time
    import datetime
    import sys
    import os
    import logging
    import threading
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures

# Generated at 2022-06-18 10:48:02.101981
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:48:09.804513
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    import asyncio
    import socket
    import time
    import unittest
    import ssl
    import functools
    import numbers
    import datetime
    import ssl
    import functools
    import numbers
    import datetime
    import ssl
    import functools
    import numbers
    import datetime
    import ssl
    import functools
    import numbers
    import datetime

# Generated at 2022-06-18 10:48:19.596463
# Unit test for method split of class _Connector
def test__Connector_split():
    # Test case 1
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80))]

# Generated at 2022-06-18 10:48:45.108137
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test for on_connect_timeout method of class _Connector
    # Arrange
    # Act
    # Assert
    pass


# Generated at 2022-06-18 10:48:52.626036
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case data
    timeout = 0.3
    connect_timeout = 0.3
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    # Perform the test
    connector = _Connector(addrinfo, connect)
    connector.start(timeout, connect_timeout)
    # Check the result
    assert connector.future.done()
    assert isinstance(connector.future.result(), TimeoutError)



# Generated at 2022-06-18 10:48:53.982669
# Unit test for method start of class _Connector
def test__Connector_start():
    # TODO: implement test
    pass


# Generated at 2022-06-18 10:49:05.849668
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.netutil import Resolver
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import socket
    import ssl
    import time

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.resolver = Resolver()
            self.io_loop = IOLoop.current()

# Generated at 2022-06-18 10:49:16.004569
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import socket

    AsyncIOMainLoop().install()

    class Test_Connector(AsyncTestCase):
        @gen_test
        async def test_close_streams(self):
            s = socket.socket()
            s.bind(("127.0.0.1", 0))
            s.listen(1)
            s.setblocking(False)
            stream = IOStream(s)
            connector = _Connector([], lambda af, addr: (stream, gen.Future()))
            connector.close_streams()

# Generated at 2022-06-18 10:49:24.189061
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:49:29.785931
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.iostream import IOStream
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    class TestCase(AsyncTestCase):
        def test_close_streams(self):
            io_loop = IOLoop.current()
            future = Future()
            stream = IOStream(socket.socket(), io_loop=io_loop)
            future.set_result(stream)
            connector = _Connector([], lambda af, addr: (stream, future))
            connector.future = future
            connector.io_loop = io_loop
            connector.streams = {stream}
            connector.close_streams()
            self.assertTrue(stream.closed())


# Generated at 2022-06-18 10:49:41.244146
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from unittest import mock
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    import asyncio
    import socket
    import ssl
    import time
    import functools
    import sys
    import os
    import logging
    import inspect
    import warnings
    import contextlib
    import types
    from typing import Any, Union, Dict, Tuple, List, Callable, Iterator, Optional, Set

# Generated at 2022-06-18 10:49:44.287168
# Unit test for method start of class _Connector
def test__Connector_start():
    # Test for method start(self: tornado.netutil._Connector, timeout: float = 0.3, connect_timeout: Union[float, datetime.timedelta] = None) -> Future[Tuple[socket.AddressFamily, Any, IOStream]]
    pass



# Generated at 2022-06-18 10:49:55.876251
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import aiohttp
    import time
    import sys
    import os
    import logging
    import json
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.escape
    import tornado.httputil
    import tornado.netutil
    import tornado.iostream
    import tornado.platform.asyncio
    import tornado.locks
    import tornado.queues
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.stack_context

# Generated at 2022-06-18 10:50:36.699858
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop

    class TestConnector(AsyncTestCase):
        def setUp(self):
            super(TestConnector, self).setUp()
            AsyncIOMainLoop().install()

        @gen_test
        def test_clear_timeouts(self):
            # type: () -> None
            def connect(af, addr):
                # type: (socket.AddressFamily, Tuple) -> Tuple[IOStream, Future[IOStream]]
                stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
                future = Future()
                future.set_result(stream)
                return stream, future


# Generated at 2022-06-18 10:50:45.307613
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case data
    timeout = 0.3
    connect_timeout = 0.5
    # Perform the test
    io_loop = IOLoop.current()
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 80))]
    def connect(af, addr):
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()
    connector = _Connector(addrinfo, connect)
    future = connector.start(timeout, connect_timeout)
    io_loop.add_timeout(connect_timeout, lambda: connector.on_connect_timeout())
    # Post-test assertions
    assert future.exception() == TimeoutError()



# Generated at 2022-06-18 10:50:55.243628
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock as mock
    import socket
    import ssl
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.concurrent
    import tornado.platform.asyncio
    import asyncio
    import io
    import functools
    import tornado.gen

    class TestCase(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(TestCase, self).setUp()
            self.io_loop = tornado.platform.asyncio.AsyncIOMainLoop()
            asyncio.set_event_loop(self.io_loop)
            self.io_loop.make_current()
            self.addCleanup(self.io_loop.close)

# Generated at 2022-06-18 10:51:06.824357
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import socket
    import ssl
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
   

# Generated at 2022-06-18 10:51:08.939122
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # type: () -> None
    """Test for method clear_timeouts of class _Connector"""
    # TODO: implement test
    pass



# Generated at 2022-06-18 10:51:20.018044
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class Test_Connector(AsyncTestCase):
        def test_clear_timeouts(self):
            # type: () -> None
            # Test that clear_timeouts() removes both timeouts
            connector = _Connector([], lambda af, addr: (None, None))
            connector.set_timeout(0.1)
            connector.set_connect_timeout(0.1)
            self.assertIsNotNone(connector.timeout)
            self.assertIsNotNone(connector.connect_timeout)
            connector.clear_timeouts()
            self.assertIsNone(connector.timeout)
            self.assertIsNone(connector.connect_timeout)

    unittest.main()



# Generated at 2022-06-18 10:51:28.889874
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.gen
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil

# Generated at 2022-06-18 10:51:39.922192
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import os
    import sys
    import time
    import datetime
    import logging
    import functools
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.concurrent
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.tcpserver
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.httputil
    import tornado.httpclient
    import tornado.escape
    import tornado.ioloop
    import tornado.locks
    import tornado.options
    import tornado.process
    import tornado.stack_context
    import tornado.template

# Generated at 2022-06-18 10:51:48.235199
# Unit test for method try_connect of class _Connector

# Generated at 2022-06-18 10:51:58.092420
# Unit test for method on_connect_timeout of class _Connector

# Generated at 2022-06-18 10:53:19.605235
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    import asyncio
    import socket
    import ssl
    import time
    import unittest
    import warnings
    import sys
    import os
    import logging
    import functools
    import contextlib
    import errno
    import concurrent.futures
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
   

# Generated at 2022-06-18 10:53:27.071384
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case data
    timeout_error = TimeoutError()
    # Constructor test
    connector = _Connector([], lambda af, addr: (None, None))
    # Attribute test
    assert connector.io_loop is IOLoop.current()
    assert connector.connect is not None
    assert connector.future is not None
    assert connector.timeout is None
    assert connector.connect_timeout is None
    assert connector.last_error is None
    assert connector.remaining == 0
    assert connector.primary_addrs == []
    assert connector.secondary_addrs == []
    assert connector.streams == set()
    # Method test
    connector.future.set_exception(None)
    assert connector.future.done()
    connector.future.set_exception(None)
    assert connector.future.done()
    connector

# Generated at 2022-06-18 10:53:37.350058
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import sys
    import os
    import time
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:53:43.711718
# Unit test for method on_connect_timeout of class _Connector

# Generated at 2022-06-18 10:53:50.358583
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import time
    import datetime
    import logging
    import os
    import sys
    import threading
    import concurrent.futures
    import functools
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.stack_context
    import tornado.testing
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util

# Generated at 2022-06-18 10:54:00.957401
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import unittest
    import time
    import os
    import sys
    import threading
    import socket
    import ssl
    import tempfile
    import functools
    import logging
    import warnings
    import errno
    import signal
    import platform
    import subprocess
    import re
    import types
    import datetime
    import collections
    import itertools
    import traceback
    import contextlib
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
   

# Generated at 2022-06-18 10:54:10.713282
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future


# Generated at 2022-06-18 10:54:20.994708
# Unit test for method start of class _Connector
def test__Connector_start():
    import unittest
    import unittest.mock as mock
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.netutil import bind_sockets
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.gen import TimeoutError
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_future

# Generated at 2022-06-18 10:54:27.199729
# Unit test for method try_connect of class _Connector

# Generated at 2022-06-18 10:54:34.918794
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import time
    import os
    import sys
    import logging
    import threading
    import tornado.gen
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.testing
    import tornado.concurrent
    import tornado.platform.asyncio
    import tornado.platform.posix
    import tornado.platform.select
    import tornado.platform.windows_utils
    import tornado.process
    import tornado.queues
    import tornado.stack_context
    import tornado.testing
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado