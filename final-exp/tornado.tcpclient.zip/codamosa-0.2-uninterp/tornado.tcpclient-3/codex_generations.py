

# Generated at 2022-06-18 10:46:55.613564
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio

    class TestConnector(tornado.testing.AsyncTestCase):
        def test_clear_timeouts(self):
            tornado.platform.asyncio.AsyncIOMainLoop().install()
            loop = asyncio.get_event_loop()
            loop.run_until_complete(self.test_clear_timeouts_async())
            loop.close()

        async def test_clear_timeouts_async(self):
            def connect(af, addr):
                return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()

            addrinfo = [(socket.AF_INET, ("127.0.0.1", 80))]
            connector = _Connector(addrinfo, connect)
            connector.start()
            self

# Generated at 2022-06-18 10:47:04.363766
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:47:14.761788
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import unittest
    import unittest.mock
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            self.io_loop = IOLoop.current()
            self.connect = unittest.mock.Mock()
            self.future = Future()
            self.timeout = None
            self.connect_timeout = None
            self.last_error = None
            self.remaining = 1
            self.primary_addrs = [(socket.AF_INET, ("127.0.0.1", 80))]
            self.secondary_addrs = []

# Generated at 2022-06-18 10:47:25.410759
# Unit test for method try_connect of class _Connector

# Generated at 2022-06-18 10:47:36.921931
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import tornado.ioloop
    import tornado.gen
    import tornado.concurrent
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.tcpserver
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.httputil
    import tornado.httpclient
    import tornado.escape
    import tornado.ioloop
    import tornado.locks
    import tornado.options
    import tornado.queues
    import tornado.process
    import tornado.simple_httpclient
    import tornado.stack_context
    import tornado.tcpclient
    import tornado.tcpserver
    import tornado.test.httpclient_test
   

# Generated at 2022-06-18 10:47:49.098743
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:48:00.345374
# Unit test for method split of class _Connector
def test__Connector_split():
    # type: () -> None
    """
    Test the split method of class _Connector
    """
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("127.0.0.1", 80))]

# Generated at 2022-06-18 10:48:08.569055
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

    class TestConnector(AsyncTestCase):
        def setUp(self):
            super(TestConnector, self).setUp()
            self.resolver = Resolver()
            self.resolver.install()
            self.resolver.configure(
                "127.0.0.1",
                [
                    (socket.AF_INET, "127.0.0.1", 80),
                    (socket.AF_INET6, "::1", 80),
                ],
            )

        def tearDown(self):
            super(TestConnector, self).tearDown

# Generated at 2022-06-18 10:48:18.547912
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import time
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    import tornado.platform.asyncio
    from tornado.platform.asyncio import to_asyncio_future
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    import tornado.platform.asyncio
    from tornado.platform.asyncio import to_as

# Generated at 2022-06-18 10:48:24.929100
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import time
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:48:55.041423
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case data
    connect_timeout = datetime.timedelta(seconds=1)
    timeout = datetime.timedelta(seconds=1)
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 80))]
    # Construct the object
    connector = _Connector(addrinfo, None)
    # Call the method
    connector.set_connect_timeout(connect_timeout)
    connector.set_timeout(timeout)
    connector.on_connect_timeout()
    # Check the result
    assert connector.connect_timeout is None
    assert connector.timeout is None
    assert connector.future.done()
    assert isinstance(connector.future.exception(), TimeoutError)
    assert connector.streams == set()


# Generated at 2022-06-18 10:48:59.918011
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Test case data
    timeout = None
    future = None
    io_loop = None
    secondary_addrs = None
    # Construct the object
    obj = _Connector(addrinfo, connect)
    # Call the method
    obj.on_timeout()
    # Return the test result
    return True



# Generated at 2022-06-18 10:49:11.065543
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio
    import socket
    import ssl

    class _ConnectorTestCase(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.io_loop = IOLoop.current()
            self.resolver = Resolver()

# Generated at 2022-06-18 10:49:20.653147
# Unit test for method clear_timeout of class _Connector

# Generated at 2022-06-18 10:49:30.077822
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

# Generated at 2022-06-18 10:49:41.450196
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.iostream import StreamClosedError
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import bind_sockets
    from tornado.testing import bind_unused_port
    from tornado.testing import AsyncHTTPTestCase
    from tornado.testing import AsyncTestCase
    from tornado.testing import ExpectLog
    from tornado.testing import gen_test
    from tornado.testing import LogTrapTestCase
    from tornado.testing import main
    from tornado.testing import bind_unused_port
    from tornado.testing import AsyncHTTPTestCase
    from tornado.testing import AsyncTestCase

# Generated at 2022-06-18 10:49:52.595237
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        @gen_test
        def test_close_streams(self):
            def connect(af, addr):
                stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
                future = Future()
                future.set_result(stream)
                return stream, future

            addrinfo = [
                (socket.AF_INET, ("127.0.0.1", 80)),
                (socket.AF_INET6, ("::1", 80)),
            ]
            connector = _Connector(addrinfo, connect)
            connector.start()
            yield connector.future
            self.assertFalse(connector.streams)

    TestCase().test_close_streams()



# Generated at 2022-06-18 10:50:01.298190
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import unittest
    import unittest.mock as mock
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.test.util import unittest

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.io_loop = IOLoop.current()
            self.connect = mock.Mock()
            self.connect.return_value = (
                IOStream(socket.socket()),
                Future(),
            )

# Generated at 2022-06-18 10:50:11.421336
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super(_ConnectorTest, self).setUp()
            self.connector = _Connector(
                [],
                lambda af, addr: (
                    IOStream(socket.socket(af, socket.SOCK_STREAM)),
                    Future(),
                ),
            )

        @gen_test
        def test_set_timeout(self):
            self.connector.set_timeout(0.1)
            self.assertTrue(self.connector.timeout is not None)
            time.sleep(0.2)
            self.assertTrue(self.connector.timeout is None)

    unittest.main()



# Generated at 2022-06-18 10:50:21.870265
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import socket
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import functools
    import concurrent.futures
    import tornado.concurrent
    from tornado.iostream import IOStream
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_async

# Generated at 2022-06-18 10:51:04.419293
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    import unittest.mock
    from tornado.testing import AsyncTestCase, gen_test

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.io_loop = IOLoop.current()
            self.connect = unittest.mock.Mock()
            self.connect.return_value = (unittest.mock.Mock(), Future())
            self.connector = _Connector(
                [(socket.AF_INET, ("127.0.0.1", 80))], self.connect
            )

        @gen_test
        def test_clear_timeouts(self):
            self.connector.start()
            self.connector.clear_timeouts()

# Generated at 2022-06-18 10:51:15.254925
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import socket
    import ssl
    import functools
    import datetime
    import time
    import os
    import sys
    import logging
    import random
    import string
    import contextlib
    import concurrent.futures
    import threading
    import multiprocessing
    import signal
    import subprocess
    import traceback
    import unittest
    import unittest.mock
    import concurrent.futures

# Generated at 2022-06-18 10:51:25.885088
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:51:28.421414
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    client = TCPClient()
    stream = loop.run_until_complete(client.connect('www.google.com', 80))
    print(stream)
    loop.close()

if __name__ == "__main__":
    test_TCPClient_connect()

# Generated at 2022-06-18 10:51:33.563894
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.stack_context
    import tornado.testing
    import tornado.test.util
    import tornado.web
    import tornado.websocket
    import socket
    import ssl
    import unittest
    import functools
    import os
    import errno
    import logging
    import time
    import sys
    import types
    import weakref
    import threading
    import concurrent.futures
    import concurrent.futures._base
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures._base
    import concurrent.futures.thread
    import concurrent.futures

# Generated at 2022-06-18 10:51:38.828774
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Create a new instance of _Connector
    connector = _Connector(addrinfo=[], connect=lambda af, addr: (None, None))
    # Call method clear_timeouts of class _Connector
    connector.clear_timeouts()
    # Check if the method clear_timeouts of class _Connector is working correctly
    assert connector.timeout is None
    assert connector.connect_timeout is None



# Generated at 2022-06-18 10:51:47.442749
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_future

# Generated at 2022-06-18 10:51:57.339287
# Unit test for method start of class _Connector
def test__Connector_start():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    from tornado.ioloop import IOLoop
    from tornado.testing import bind_unused_port
    from tornado.tcpserver import TCPServer
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNonUnix
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIfNoIPv6
    from tornado.test.util import skipIfNoIPv6

# Generated at 2022-06-18 10:52:04.476590
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("::1", 80)),
        (socket.AF_INET, ("127.0.0.1", 8080)),
        (socket.AF_INET6, ("::1", 8080)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("127.0.0.1", 8080))]
    assert secondary == [(socket.AF_INET6, ("::1", 80)), (socket.AF_INET6, ("::1", 8080))]



# Generated at 2022-06-18 10:52:05.856708
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test for method on_connect_timeout of class _Connector
    # This test is not implemented yet.
    pass


# Generated at 2022-06-18 10:53:22.200740
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import Any
    from tornado.platform.asyncio import Future
    from tornado.platform.asyncio import TimeoutError
    from tornado.platform.asyncio import IOLoop
    from tornado.platform.asyncio import IOStream
    from tornado.platform.asyncio import Resolver
    from tornado.platform.asyncio import ssl


# Generated at 2022-06-18 10:53:32.052795
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import functools
    import time
    import socket
    import ssl
    import tornado.iostream
    import tornado.netutil
    import tornado.concurrent
    import tornado.ioloop
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.tcpserver
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.test.gen_test
    import tornado.test.httpclient_test
    import tornado.test.httpserver_test
    import tornado.test.util
    import tornado.test.web_test
    import tornado.testing
    import tornado.tcpserver
    import tornado.test.util
    import tornado.test.stack_context


# Generated at 2022-06-18 10:53:41.043738
# Unit test for method on_connect_timeout of class _Connector

# Generated at 2022-06-18 10:53:48.560419
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Test case data
    timeout = 0.3
    connect_timeout = None
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 8080))]
    connect = lambda af, addr: (IOStream(socket.socket(af, socket.SOCK_STREAM)), Future())
    # Construct the object
    obj = _Connector(addrinfo, connect)
    # Call the method
    obj.on_timeout()
    # Check the result
    assert obj.timeout == None
    assert obj.connect_timeout == None
    assert obj.last_error == None
    assert obj.remaining == 0
    assert obj.primary_addrs == []
    assert obj.secondary_addrs == [(socket.AF_INET, ('127.0.0.1', 8080))]

# Generated at 2022-06-18 10:53:59.488022
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:54:09.306684
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import unittest
    import time
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import functools
    import socket
    import ssl
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.concurrent
    import tornado.gen
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.stack_context
    import tornado.tcpserver
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.test.util
    import tornado.web
    import tornado.websocket
    import tornado.locks
    import tornado.queues
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process

# Generated at 2022-06-18 10:54:19.035935
# Unit test for method start of class _Connector
def test__Connector_start():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super(_ConnectorTest, self).setUp()
            self.connect_called = False
            self.connect_args = None
            self.connect_future = None
            self.connect_stream = None
            self.connect_timeout = None
            self.connect_timeout_called = False
            self.connect_timeout_args = None
            self.connect_timeout_future = None
            self.connect_timeout_stream = None
            self.connect_timeout_timeout = None
            self.connect_timeout_timeout_called = False
            self.connect_timeout_timeout_args = None
            self.connect_timeout_timeout

# Generated at 2022-06-18 10:54:22.365167
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    # Test case data
    connect_timeout = 0.3
    # Perform the test
    _Connector.set_connect_timeout(connect_timeout)
    # Post-test assertions
    assert True # TODO: implement your test here



# Generated at 2022-06-18 10:54:28.091280
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import unittest
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import time
    import datetime
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    from tornado.testing import AsyncTestCase, gen_test

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            self.io_loop = IOLoop.current()
            self.connect = lambda af, addr: (
                IOStream(socket.socket(af, socket.SOCK_STREAM)),
                Future(),
            )

# Generated at 2022-06-18 10:54:35.577485
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.iostream import StreamClosedError
    from tornado.netutil import bind_sockets
    from tornado.tcpserver import TCPServer
    from tornado.testing import bind_unused_port

    class TestServer(TCPServer):
        def handle_stream(self, stream, address):
            stream.close()

    class TestConnector(AsyncTestCase):
        def setUp(self):
            super(TestConnector, self).setUp()
            self.server = TestServer()
            self.server.listen(0)
            self.port = self.server.socket.getsockname()[1]

        @gen_test
        async def test_connect(self):
            connector