

# Generated at 2022-06-18 10:46:56.212390
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock
    import socket
    import ssl
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.concurrent
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import functools
    import typing
    import contextlib
    import sys
    import os
    import io
    import tempfile
    import time
    import datetime
    import random
    import logging
    import logging.handlers
    import traceback
    import subprocess
    import multiprocessing
    import concurrent.futures
    import concurrent.futures.process

    ################################################################################
    #
    # Unit test for method try_connect of class _Connector
    #


# Generated at 2022-06-18 10:47:02.391838
# Unit test for method start of class _Connector
def test__Connector_start():
    # Test case data
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 80)), (socket.AF_INET6, ('::1', 80))]
    timeout = _INITIAL_CONNECT_TIMEOUT
    connect_timeout = None
    # Construct the object
    connector = _Connector(addrinfo, None)
    # Call the method
    return_value = connector.start(timeout, connect_timeout)
    # Return the test result
    return (return_value)


# Generated at 2022-06-18 10:47:03.092837
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # TODO: implement
    pass


# Generated at 2022-06-18 10:47:13.800163
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import unittest
    import unittest.mock

    class _ConnectorTestCase(unittest.TestCase):
        def test__Connector_on_timeout(self):
            # Arrange
            io_loop = unittest.mock.MagicMock()
            io_loop.time.return_value = 0.0
            io_loop.add_timeout.return_value = 1
            io_loop.remove_timeout.return_value = None
            future = unittest.mock.MagicMock()
            future.done.return_value = False
            future.set_exception.return_value = None

# Generated at 2022-06-18 10:47:24.405813
# Unit test for method start of class _Connector
def test__Connector_start():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import socket
    import time

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            self.io_loop = IOLoop.current()
            self.resolver = Resolver()
            self.resolver.configure(
                "tornado.platform.asyncio.AsyncIOMainLoop",
                io_loop=self.io_loop,
            )

        def tearDown(self):
            super(Test_Connector, self).tearDown()
            self.resolver.close()


# Generated at 2022-06-18 10:47:28.239205
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test case data
    timeout = 0.3
    # Construct the object
    connector = _Connector([], lambda x, y: (None, None))
    # Call the method
    connector.set_timeout(timeout)
    # Check the result
    assert connector.timeout is not None


# Generated at 2022-06-18 10:47:40.159662
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import ssl

    async def test_TCPClient_connect_async(self):
        # Test that TCPClient.connect returns an SSLIOStream if ssl_options
        # is not None.
        client = TCPClient()
        stream = await client.connect("localhost", self.get_http_port(), ssl_options={
            "certfile": test_utils.get_ssl_cert(self.get_http_server().ssl_options),
            "keyfile": test_utils.get_ssl_cert(self.get_http_server().ssl_options),
        })
        self.assertIsInstance(stream, IOStream)
        self.assertIsInstance(stream.socket, ssl.SSLSocket)
        stream.close()
        client

# Generated at 2022-06-18 10:47:50.844932
# Unit test for constructor of class _Connector
def test__Connector():
    from tornado.iostream import IOStream
    from tornado.testing import AsyncTestCase, gen_test

    class TestConnector(AsyncTestCase):
        def setUp(self):
            super(TestConnector, self).setUp()
            self.io_loop = IOLoop.current()
            self.stream = IOStream(socket.socket(), io_loop=self.io_loop)
            self.stream.set_close_callback(self.stop)
            self.future = Future()
            self.future.add_done_callback(self.stop)

        def tearDown(self):
            self.stream.close()
            self.io_loop.add_timeout(self.io_loop.time() + 0.1, self.stop)
            self.wait()
            super(TestConnector, self).tearDown()


# Generated at 2022-06-18 10:47:56.516812
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import socket
    import ssl
    import time
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(None)
            self.io_loop = AsyncIOMainLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.close(all_fds=True)
            self

# Generated at 2022-06-18 10:48:04.421362
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case data
    timeout = 0.3
    connect_timeout = 0.3
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    # Perform the test
    connector = _Connector(addrinfo, None)
    connector.start(timeout, connect_timeout)
    connector.on_connect_timeout()
    # Post-test assertions
    assert connector.future.done()
    assert connector.future.exception() is not None
    assert isinstance(connector.future.exception(), TimeoutError)



# Generated at 2022-06-18 10:48:28.562203
# Unit test for method start of class _Connector
def test__Connector_start():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import time
    import tornado.netutil
    import tornado.iostream
    import tornado.gen
    import tornado.concurrent
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.tcpserver
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.test.gen_test
    import tornado.test.httpclient_test
    import tornado.test.httpserver_test
    import tornado.test.util
    import tornado.test.web_test
    import tornado.test.websocket_test
    import tornado.test.wsgi_test
    import tornado.web
    import tornado.websocket
   

# Generated at 2022-06-18 10:48:34.867247
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Test case data
    timeout = 0.3
    connect_timeout = 0.3
    addrinfo = [
        (socket.AF_INET, ('127.0.0.1', 80)),
        (socket.AF_INET6, ('::1', 80))
    ]

    # Perform the test
    connector = _Connector(addrinfo, None)
    connector.set_timeout(timeout)
    connector.set_connect_timeout(connect_timeout)
    connector.on_timeout()

    # Check the test result
    assert connector.timeout is None
    assert connector.connect_timeout is not None


# Generated at 2022-06-18 10:48:45.417899
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import asyncio
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.concurrent
    import tornado.escape
    import tornado.httputil
    import tornado.httpserver
    import tornado.ioloop
    import tornado.iostream
    import tornado.locks
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.testing
    import tornado.test.httpclient_test
    import tornado.test.util

# Generated at 2022-06-18 10:48:54.795688
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import IOStream
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    import asyncio
    import socket
    import time
    import logging
    import sys
    import os
    import functools
    import traceback
    import inspect
    import types
    import warnings
    import contextlib
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.fut

# Generated at 2022-06-18 10:49:06.821953
# Unit test for method try_connect of class _Connector

# Generated at 2022-06-18 10:49:08.414203
# Unit test for method start of class _Connector
def test__Connector_start():
    # type: () -> None
    """Unit test for method start of class _Connector"""
    # TODO: implement
    pass



# Generated at 2022-06-18 10:49:19.439101
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.iostream import StreamClosedError
    import asyncio
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.ioloop
    import tornado.netutil
    import tornado.iostream
    import tornado.concurrent
    import tornado.gen
    import tornado.locks
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.ioloop
    import tornado.netutil
    import tornado.iostream
    import tornado.concurrent
    import tornado.gen
    import tornado.locks
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.ioloop
    import tornado.netutil

# Generated at 2022-06-18 10:49:25.268395
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    from tornado.testing import AsyncTestCase, gen_test

    class Test_Connector(AsyncTestCase):
        @gen_test
        def test_set_timeout(self):
            connector = _Connector([], lambda af, addr: (None, None))
            connector.set_timeout(0.1)
            self.assertTrue(connector.timeout is not None)
            self.assertTrue(connector.future.done())

    test_connector = Test_Connector()
    test_connector.test_set_timeout()



# Generated at 2022-06-18 10:49:37.347402
# Unit test for method split of class _Connector
def test__Connector_split():
    from tornado.netutil import bind_sockets
    from tornado.platform.auto import set_close_exec
    from tornado.tcpserver import TCPServer
    from tornado.testing import AsyncTestCase, bind_unused_port

    class TestServer(TCPServer):
        def handle_stream(self, stream, address):
            stream.write(b"hello")
            stream.close()

    class TestConnector(AsyncTestCase):
        def test_split(self):
            # This test is a bit of a hack.  It starts a server on
            # localhost, then uses _Connector to connect to it.  If
            # _Connector.split is working correctly, it will try the
            # IPv6 address first and succeed, while if it's not working
            # it will try the IPv4 address first and fail.
            sockets = bind_

# Generated at 2022-06-18 10:49:44.342989
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado
    import tornado.httpclient
    import tornado.httpserver
    import tornado.netutil
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.ioloop
    import tornado.iostream
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.gen
    import tornado.locks
    import tornado.queues
    import tornado.stack_context
    import tornado.concurrent
    import tornado.escape
    import tornado.httputil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.test.httpclient_

# Generated at 2022-06-18 10:50:23.856430
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import unittest
    import unittest.mock
    import tornado.platform.asyncio
    import asyncio
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, bind_unused_port

    class _ConnectorTestCase(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.io_loop = IOLoop.current()
            self.resolver = Resolver()
            self.resolver.configure(
                resolver=tornado.platform.asyncio.AsyncIOMainLoop().getaddrinfo
            )
            self.sock, self.port = bind_unused_port()
            self.stream = IOStream(self.sock)
            self

# Generated at 2022-06-18 10:50:33.823927
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.netutil import bind_sockets
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

    class TestConnector(AsyncTestCase):
        def setUp(self):
            super(TestConnector, self).setUp()
            self.sockets = bind_sockets(0)
            self.port = self.sockets[0].getsockname()[1]
            self.io_loop.add_callback(self.io_loop.stop)
            self.io_loop.start()

        def tearDown(self):
            super(TestConnector, self).tearDown()

# Generated at 2022-06-18 10:50:42.763492
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    import pytest
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.gen import TimeoutError
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import socket
    import time
    import functools
    import ssl
    import os
    import sys
    import logging
    import threading
    import concurrent.futures
    import tornado
    import tornado.platform.asyncio
    import tornado.ioloop
    import tornado.iostream
    import tornado.gen
    import tornado.tcpserver
    import tornado.httpserver
    import tornado.netutil
    import tornado.process
    import tornado.stack_context
    import tornado.testing
    import tornado

# Generated at 2022-06-18 10:50:52.906846
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    import unittest.mock as mock

    class MockIOStream(object):
        def __init__(self, *args, **kwargs):
            pass

        def close(self):
            pass

    class MockIOLoop(object):
        def __init__(self, *args, **kwargs):
            pass

        def add_timeout(self, *args, **kwargs):
            pass

        def remove_timeout(self, *args, **kwargs):
            pass

        def time(self):
            pass

    class MockFuture(object):
        def __init__(self, *args, **kwargs):
            pass

        def set_exception(self, *args, **kwargs):
            pass

        def done(self):
            pass


# Generated at 2022-06-18 10:51:04.975090
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import time
    import unittest
    import sys
    import os
    import socket
    import ssl
    import logging
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.stack_context
    import tornado.testing
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util
    import tornado.test.util

# Generated at 2022-06-18 10:51:15.742577
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock
    import socket
    import ssl
    import tornado.iostream
    import tornado.concurrent
    import tornado.ioloop
    import tornado.netutil
    import tornado.gen
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import functools
    import typing
    import collections
    import datetime
    import time
    import sys
    import os
    import logging
    import logging.config
    import logging.handlers
    import json
    import random
    import string
    import re
    import io
    import contextlib
    import tempfile
    import subprocess
    import multiprocessing
    import multiprocessing.connection
    import multiprocessing.reduction
    import multiprocessing.managers


# Generated at 2022-06-18 10:51:26.285302
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    import unittest
    from unittest.mock import patch, Mock
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.netutil import Resolver
    from tornado.concurrent import Future
    from tornado.gen import TimeoutError

    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super(Test_Connector, self).setUp()
            self.io_loop = IOLoop.current()
            self.connect = Mock()
            self.connect.return_value = (Mock(), Future())
            self.connector = _Connector(
                [(socket.AF_INET, ("127.0.0.1", 80))], self.connect
            )
            self.connector.start()


# Generated at 2022-06-18 10:51:37.523329
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_future

# Generated at 2022-06-18 10:51:46.803382
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:51:56.429492
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        def test_close_streams(self):
            from tornado.iostream import IOStream
            from tornado.concurrent import Future
            from tornado.ioloop import IOLoop

            class FakeStream(IOStream):
                def __init__(self, *args, **kwargs):
                    super(FakeStream, self).__init__(*args, **kwargs)
                    self.closed = False

                def close(self):
                    self.closed = True

            class FakeFuture(Future):
                def __init__(self, *args, **kwargs):
                    super(FakeFuture, self).__init__(*args, **kwargs)
                    self.done_called = False


# Generated at 2022-06-18 10:53:16.503161
# Unit test for method start of class _Connector

# Generated at 2022-06-18 10:53:25.790241
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:53:27.515688
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # test case 1
    # test case 2
    # test case 3
    pass



# Generated at 2022-06-18 10:53:37.766535
# Unit test for method clear_timeouts of class _Connector

# Generated at 2022-06-18 10:53:44.118333
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import unittest
    import unittest.mock as mock
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from asyncio import Future as AsyncioFuture
    from asyncio import get_event_loop
    from typing import Any, Union, Dict, Tuple, List, Callable, Iterator, Optional, Set
    import socket
    import ssl
    import functools
    import datetime
    import time
    import sys
    import os
    import logging
    import logging.config
    import inspect
    import random
    import string
    import json
    import uuid
    import copy
    import io

# Generated at 2022-06-18 10:53:53.412856
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import sys
    import os
    import time
    import logging
    import functools
    import socket
    import ssl
    import tornado.netutil
    import tornado.iostream
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.concurrent
    import tornado.gen
    import tornado.tcpserver
    import tornado.testing
    import tornado.stack_context
    import tornado.locks
    import tornado.queues
    import tornado.escape
    import tornado.httpclient
    import tornado.httputil
    import tornado.httpserver
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado

# Generated at 2022-06-18 10:54:04.611200
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.netutil import bind_sockets
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_tornado_yieldable
    from tornado.platform.asyncio import to_asyncio_yieldable
    from tornado.platform.asyncio import to_asyncio_coroutine
    from tornado.platform.asyncio import to_tornado_coroutine

# Generated at 2022-06-18 10:54:13.147428
# Unit test for method start of class _Connector
def test__Connector_start():
    import unittest
    import unittest.mock
    import tornado.testing
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import functools
    import tornado.concurrent
    import tornado.ioloop
    import tornado.gen
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import functools
    import tornado.concurrent
    import tornado.ioloop
    import tornado.gen
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import functools
    import tornado

# Generated at 2022-06-18 10:54:23.225411
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:54:32.793851
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class Test__Connector_clear_timeout(AsyncTestCase):
        @gen_test
        def test_clear_timeout(self):
            from tornado.iostream import IOStream
            from tornado.netutil import Resolver
            from tornado.testing import bind_unused_port
            from tornado.tcpserver import TCPServer

            class EchoServer(TCPServer):
                def handle_stream(self, stream, address):
                    stream.read_until_close(stream.close)

            server = EchoServer()
            server.listen(0)
            port = server.socket.getsockname()[1]
            resolver = Resolver()
            addrinfo = yield resolver.resolve("127.0.0.1", port)
            connector