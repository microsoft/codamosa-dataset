

# Generated at 2022-06-18 10:46:58.148738
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
    ]

# Generated at 2022-06-18 10:47:06.047025
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.netutil import Resolver
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio
    import socket
    import ssl
    import time
    import unittest
    import warnings
    import sys
    import os
    import logging
    import functools
    import datetime
    import tornado

# Generated at 2022-06-18 10:47:16.281151
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future


# Generated at 2022-06-18 10:47:27.036941
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.iostream import StreamClosedError
    from tornado.netutil import bind_sockets
    from tornado.tcpserver import TCPServer
    from tornado.testing import bind_unused_port
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.gen import TimeoutError
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.gen import Timeout

# Generated at 2022-06-18 10:47:39.657831
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import IOStream
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.testing import bind_unused_port
    from tornado.tcpserver import TCPServer
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.testing import bind_unused_port

# Generated at 2022-06-18 10:47:48.725629
# Unit test for method start of class _Connector
def test__Connector_start():
    # Test case data
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    timeout = 0.3
    connect_timeout = None
    # Construct the object
    connector = _Connector(addrinfo, None)
    # Construct the expected value
    expected = None
    # Invoke the method
    actual = connector.start(timeout, connect_timeout)
    # Compare the actual value to the expected value
    assert actual == expected
    # Return the result
    return



# Generated at 2022-06-18 10:47:57.947432
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("2001:db8::1", 80)),
        (socket.AF_INET, ("192.0.2.1", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("192.0.2.1", 80))]
    assert secondary == [(socket.AF_INET6, ("2001:db8::1", 80))]



# Generated at 2022-06-18 10:48:06.786683
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import sys
    import os
    import time
    import logging
    import unittest
    import tornado.ioloop
    import tornado.gen
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.testing
    import tornado.concurrent
    import tornado.platform.asyncio
    import tornado.httpserver
    import tornado.httputil
    import tornado.httpclient
    import tornado.escape
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.test.httpclient_test
    import tornado.test

# Generated at 2022-06-18 10:48:15.196343
# Unit test for method set_connect_timeout of class _Connector

# Generated at 2022-06-18 10:48:23.109295
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    import pytest
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.gen import TimeoutError
    from tornado.netutil import Resolver
    from tornado.concurrent import Future
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import socket
    import ssl
    import time
    import sys
    import os
    import logging
    import unittest
    import json
    import re
    import inspect
    import functools
    import datetime
    import tornado
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:48:54.575008
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:49:06.663684
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.gen
    import tornado.concurrent
    import tornado.locks
    import socket
    import ssl
    import time
    import logging
    import os
    import sys
    import unittest
    import threading
    import concurrent.futures
    import functools
    import contextlib
    import warnings
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.gen
    import tornado.concurrent
    import tornado.locks
    import socket
    import ssl

# Generated at 2022-06-18 10:49:16.569653
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test that _Connector.set_timeout() sets the timeout correctly
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class _ConnectorTest(AsyncTestCase):
        def test_set_timeout(self):
            connector = _Connector([], lambda af, addr: (None, None))
            connector.io_loop = self.io_loop
            connector.set_timeout(0.1)
            self.assertEqual(connector.timeout, None)
            self.io_loop.add_timeout(time.time() + 0.1, self.stop)
            self.wait()
            self.assertNotEqual(connector.timeout, None)

    unittest.main()



# Generated at 2022-06-18 10:49:20.482796
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    client = TCPClient()
    stream = loop.run_until_complete(client.connect('www.google.com', 80))
    stream.close()
    client.close()


# Generated at 2022-06-18 10:49:27.320729
# Unit test for method on_connect_timeout of class _Connector

# Generated at 2022-06-18 10:49:32.157729
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:49:42.757572
# Unit test for method clear_timeouts of class _Connector

# Generated at 2022-06-18 10:49:53.751969
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case data
    test_future = Future()
    test_future.set_result(None)
    test_stream = IOStream(socket.socket())
    test_streams = {test_stream}
    test_connect_timeout = 0.5
    # Perform the test
    test_obj = _Connector(
        [],
        lambda x, y: (test_stream, test_future),
    )
    test_obj.future = test_future
    test_obj.streams = test_streams
    test_obj.set_connect_timeout(test_connect_timeout)
    test_obj.on_connect_timeout()
    # Check the result
    assert test_future.done()
    assert test_stream.closed()



# Generated at 2022-06-18 10:50:02.077120
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
    ]

# Generated at 2022-06-18 10:50:12.993770
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:50:55.512657
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import unittest

    class Test_Connector(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.platform.asyncio.AsyncIOLoop()
            self.io_loop.make_current()
            self.connector = _Connector(
                [],
                lambda af, addr: (
                    IOStream(socket.socket(af, socket.SOCK_STREAM)),
                    Future(),
                ),
            )

        def tearDown(self):
            self.io_loop.close()

        def test_clear_timeout(self):
            self.connector.set_timeout(0.1)
            self.connector.clear_timeout()

# Generated at 2022-06-18 10:51:07.060452
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from asyncio import Future as AsyncioFuture
    from tornado.testing import bind_unused_port
    from tornado.netutil import Resolver
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.gen import TimeoutError
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

# Generated at 2022-06-18 10:51:17.800851
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from unittest import mock
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import socket
    import ssl
    import time
    import datetime
    import functools
    import typing
    from typing import Any, Union, Dict, Tuple, List, Callable, Iterator, Optional, Set
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from typing import Coroutine
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to

# Generated at 2022-06-18 10:51:27.867372
# Unit test for method on_connect_timeout of class _Connector

# Generated at 2022-06-18 10:51:35.195920
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 80)), (socket.AF_INET6, ('::1', 80))]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ('127.0.0.1', 80))]
    assert secondary == [(socket.AF_INET6, ('::1', 80))]


# Generated at 2022-06-18 10:51:41.219360
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Test case data
    timeout = None
    future = Future()
    secondary_addrs = []

    # Constructor test
    connector = _Connector(None, None)
    connector.timeout = timeout
    connector.future = future
    connector.secondary_addrs = secondary_addrs

    # Perform the test
    connector.on_timeout()

    # Validate the results
    assert connector.timeout is None
    assert future.done()
    assert future.result() is None


# Generated at 2022-06-18 10:51:47.443812
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Test that clear_timeouts() removes both timeouts
    io_loop = IOLoop()
    io_loop.make_current()
    connector = _Connector([], lambda af, addr: (None, None))
    connector.io_loop = io_loop
    connector.set_timeout(0.1)
    connector.set_connect_timeout(0.1)
    assert connector.timeout is not None
    assert connector.connect_timeout is not None
    connector.clear_timeouts()
    assert connector.timeout is None
    assert connector.connect_timeout is None



# Generated at 2022-06-18 10:51:52.416805
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import ssl
    import socket
    import time
    import logging
    import os
    import sys
    import unittest
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.netutil
    import tornado.iostream
    import tornado.gen
    import tornado.concurrent
    import tornado.tcpserver
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
   

# Generated at 2022-06-18 10:52:01.627390
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # Test for method clear_timeout of class _Connector
    import unittest
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.ioloop
    import tornado.gen
    import socket
    import ssl
    import time
    import tornado.concurrent
    import tornado.queues
    import tornado.locks
    import functools
    import tornado.escape
    import tornado.httputil
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.tcpclient

# Generated at 2022-06-18 10:52:07.537344
# Unit test for method on_timeout of class _Connector

# Generated at 2022-06-18 10:56:12.363160
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import socket

    class TestConnector(AsyncTestCase):
        def setUp(self):
            super(TestConnector, self).setUp()
            self.io_loop = IOLoop.current()
            self.io_loop.make_current()
            self.resolver = Resolver()
            self.resolver.configure(
                "tornado.netutil.ThreadedResolver", io_loop=self.io_loop
            )

        def tearDown(self):
            self.resolver.close()
            self.io_loop.clear_current()
            super(TestConnector, self).tearDown()


# Generated at 2022-06-18 10:56:19.497286
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import pytest
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import functools
    import tornado.gen
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil

# Generated at 2022-06-18 10:56:27.574633
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.locks
    import tornado.ioloop
    import tornado.httpserver
    import tornado.web
    import tornado.escape
    import tornado.httputil
    import tornado.process
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.auto
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.asyncio
    import tornado.platform