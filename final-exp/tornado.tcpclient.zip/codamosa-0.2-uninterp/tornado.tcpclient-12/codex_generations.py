

# Generated at 2022-06-18 10:47:12.044907
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        @gen_test
        def test_clear_timeout(self):
            def connect(af, addr):
                return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()

            addrinfo = [(socket.AF_INET, ("127.0.0.1", 80))]
            connector = _Connector(addrinfo, connect)
            connector.start()
            connector.clear_timeout()
            self.assertEqual(connector.timeout, None)

    TestCase().test_clear_timeout()



# Generated at 2022-06-18 10:47:21.927935
# Unit test for method clear_timeouts of class _Connector

# Generated at 2022-06-18 10:47:26.772231
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    class FakeStream:
        def close(self):
            pass

    fake_stream = FakeStream()
    connector = _Connector([], lambda x, y: (None, None))
    connector.streams.add(fake_stream)
    connector.close_streams()
    assert len(connector.streams) == 0



# Generated at 2022-06-18 10:47:33.783751
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test the case when the future is not done
    # Create a mock object for the future
    future = Future()
    future.done = MagicMock(return_value=False)
    # Create a mock object for the ioloop
    ioloop = MagicMock()
    ioloop.time = MagicMock(return_value=0)
    # Create a mock object for the connector
    connector = _Connector([], None)
    connector.future = future
    connector.io_loop = ioloop
    # Call the method
    connector.on_connect_timeout()
    # Check the results
    future.set_exception.assert_called_once_with(TimeoutError())
    # Test the case when the future is done
    # Create a mock object for the future
    future = Future()
    future.done = MagicMock

# Generated at 2022-06-18 10:47:42.107586
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock
    import socket
    import ssl
    import tornado.concurrent
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.gen
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import functools
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
   

# Generated at 2022-06-18 10:47:51.614284
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:48:02.188193
# Unit test for constructor of class _Connector
def test__Connector():
    # type: () -> None
    from tornado.iostream import IOStream
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestConnector(AsyncTestCase):
        def setUp(self):
            # type: () -> None
            super(TestConnector, self).setUp()
            self.io_loop = AsyncIOMainLoop()
            self.io_loop.make_current()

        def tearDown(self):
            # type: () -> None
            self.io_loop.close(all_fds=True)
            super(TestConnector, self).tearDown()


# Generated at 2022-06-18 10:48:08.530801
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.iostream import StreamClosedError
    from tornado.netutil import bind_sockets, add_accept_handler
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.gen import TimeoutError

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.sockets = bind_sockets(0, "127.0.0.1")
            self.port = self.sockets[0].getsockname()[1]
            add_accept_handler(self.sockets[0], self.accept_connection, self.io_loop)


# Generated at 2022-06-18 10:48:18.547572
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    import unittest.mock as mock
    from tornado.testing import AsyncTestCase, gen_test

    class Test_Connector(AsyncTestCase):
        @mock.patch("tornado.ioloop.IOLoop.current")
        def test_clear_timeouts(self, mock_current):
            mock_io_loop = mock.Mock()
            mock_current.return_value = mock_io_loop
            c = _Connector([], None)
            c.timeout = mock.Mock()
            c.connect_timeout = mock.Mock()
            c.clear_timeouts()
            mock_io_loop.remove_timeout.assert_has_calls(
                [mock.call(c.timeout), mock.call(c.connect_timeout)]
            )


# Generated at 2022-06-18 10:48:24.957735
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import unittest
    import unittest.mock
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio
    import socket
    import ssl
    import time
    import functools
    import os
    import sys
    import logging
    import threading
    import concurrent.futures
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:48:50.377494
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Test case data
    timeout = None
    future = None
    io_loop = None
    secondary_addrs = None

    # Perform the test
    test_obj = _Connector(None, None)
    test_obj.timeout = timeout
    test_obj.future = future
    test_obj.io_loop = io_loop
    test_obj.secondary_addrs = secondary_addrs
    test_obj.on_timeout()

    # Return the results
    return



# Generated at 2022-06-18 10:49:01.792666
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado.platform.asyncio

    class TestCase(AsyncTestCase):
        def setUp(self):
            super(TestCase, self).setUp()
            AsyncIOMainLoop().install()
            self.io_loop = tornado.ioloop.IOLoop.current()
            self.resolver = Resolver()
            self.resolver.configure(
                resolver=tornado.platform.asyncio.AsyncIOLoopResolver(self.io_loop)
            )


# Generated at 2022-06-18 10:49:11.793900
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    import asyncio
    import tornado
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.ioloop
    import tornado.netutil
    import tornado.iostream
    import tornado.tcpserver
    import tornado.locks
    import tornado.queues
    import tornado.gen
    import tornado.escape
    import tornado.httpclient
    import tornado.httputil
    import tornado.httpserver
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado

# Generated at 2022-06-18 10:49:21.284795
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    import asyncio
    import socket
    import ssl
    import time
    import functools
    import logging
    from typing import Any, Union, Dict, Tuple, List, Callable, Iterator, Optional, Set
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from typing import Coroutine

# Generated at 2022-06-18 10:49:27.848516
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import Any
    from tornado.platform.asyncio import Future
    from tornado.platform.asyncio import iscoroutinefunction
    from tornado.platform.asyncio import iscoroutine
    from tornado.platform.asyncio import ensure_future
    from tornado.platform.asyncio import to

# Generated at 2022-06-18 10:49:40.121029
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    import unittest.mock
    import tornado.platform.asyncio
    import asyncio

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.platform.asyncio.AsyncIOLoop()
            self.io_loop.make_current()
            self.connect = unittest.mock.Mock()
            self.addrinfo = [(socket.AF_INET, ("127.0.0.1", 80))]
            self.connector = _Connector(self.addrinfo, self.connect)
            self.connector.future = Future()
            self.connector.timeout = unittest.mock.Mock()
            self.connector.connect_timeout = unittest.mock.Mock()


# Generated at 2022-06-18 10:49:48.812693
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    client = TCPClient()
    stream = loop.run_until_complete(client.connect('www.google.com', 80))
    loop.run_until_complete(stream.write(b'GET / HTTP/1.0\r\n\r\n'))
    data = loop.run_until_complete(stream.read_until_close())
    print(data)
    stream.close()
    client.close()


# Generated at 2022-06-18 10:49:58.273396
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    import asyncio
    import socket
    import ssl
    import time
    import logging
    import sys
    import os
    import functools
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:50:05.138813
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:50:16.559517
# Unit test for constructor of class _Connector
def test__Connector():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class TestConnector(AsyncTestCase):
        @gen_test
        def test_connector(self):
            def connect(af, addr):
                stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
                future = Future()
                self.io_loop.add_callback(stream.connect, addr)
                self.io_loop.add_callback(future.set_result, stream)
                return stream, future

            addrinfo = [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET6, ("::1", 80))]
            connector = _Connector(addrinfo, connect)
            result = yield connector.start()

# Generated at 2022-06-18 10:51:00.673561
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.concurrent import Future
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import AsyncIOLoop
    from tornado.platform.asyncio import to_asyncio_future

# Generated at 2022-06-18 10:51:11.539843
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import socket
    import ssl
    import time

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super(_ConnectorTest, self).setUp()
            self.io_loop = IOLoop.current()
            self.resolver = Resolver()
            self.resolver.install()
            self.addCleanup(self.resolver.close)
            self.addCleanup(self.io_loop.close)
            self.connect

# Generated at 2022-06-18 10:51:22.227094
# Unit test for method clear_timeouts of class _Connector

# Generated at 2022-06-18 10:51:30.268794
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test that on_connect_timeout raises a TimeoutError
    # when the future is not done
    import pytest
    from tornado.concurrent import Future
    from tornado.gen import TimeoutError
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.test.util import unittest

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super(_ConnectorTest, self).setUp()
            self.io_loop = IOLoop.current()
            self.connect = lambda af, addr: (
                IOStream(socket.socket(af, socket.SOCK_STREAM)),
                Future(),
            )

# Generated at 2022-06-18 10:51:40.438862
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:51:48.577781
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # Test case data
    timeout = None
    io_loop = IOLoop.current()
    future = Future()
    connect_timeout = None
    last_error = None
    remaining = len(addrinfo)
    primary_addrs, secondary_addrs = split(addrinfo)
    streams = set()
    # Test code
    _Connector.clear_timeout(timeout, io_loop, future, connect_timeout, last_error, remaining, primary_addrs, secondary_addrs, streams)
    # Post-conditions
    assert timeout is None
    assert io_loop is IOLoop.current()
    assert future is Future()
    assert connect_timeout is None
    assert last_error is None
    assert remaining is len(addrinfo)
    assert primary_addrs is split(addrinfo)[0]
    assert secondary_addrs

# Generated at 2022-06-18 10:51:58.137341
# Unit test for constructor of class _Connector
def test__Connector():
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET6, ("127.0.0.1", 80))]
    connector = _Connector(addrinfo, connect)
    assert connector.io_loop == IOLoop.current()
    assert connector.connect == connect
    assert connector.future.done() == False
    assert connector.timeout == None
    assert connector.connect_timeout == None
    assert connector.last_error == None
    assert connector.remaining == 2

# Generated at 2022-06-18 10:52:01.808578
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("2001:db8::1", 80)),
        (socket.AF_INET, ("192.0.2.1", 80)),
        (socket.AF_INET6, ("2001:db8::2", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("192.0.2.1", 80)),
    ]

# Generated at 2022-06-18 10:52:07.649745
# Unit test for method start of class _Connector

# Generated at 2022-06-18 10:52:12.812191
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test that the timeout is set correctly
    io_loop = IOLoop.current()
    io_loop.time = lambda: 0
    connector = _Connector([], lambda af, addr: (None, None))
    connector.io_loop = io_loop
    connector.set_timeout(0.3)
    assert connector.timeout is not None
    assert connector.timeout.deadline == 0.3
    assert connector.timeout.callback == connector.on_timeout
    assert connector.timeout in io_loop._timeouts


# Generated at 2022-06-18 10:53:22.357948
# Unit test for constructor of class _Connector
def test__Connector():
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()

    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET6, ("127.0.0.1", 80))]
    _Connector(addrinfo, connect)


# Generated at 2022-06-18 10:53:32.269685
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("::1", 80)),
        (socket.AF_INET, ("127.0.0.1", 8080)),
        (socket.AF_INET6, ("::1", 8080)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 8080)),
    ]

# Generated at 2022-06-18 10:53:41.260228
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    import mock
    import socket
    import ssl
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_torn

# Generated at 2022-06-18 10:53:49.351091
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    import unittest.mock

    class TestCase(unittest.TestCase):
        def test_close_streams(self):
            io_loop = unittest.mock.Mock()
            io_loop.time.return_value = 0
            io_loop.add_timeout.return_value = 1
            io_loop.remove_timeout.return_value = None
            future = unittest.mock.Mock()
            future.done.return_value = False
            future.result.return_value = None
            future.set_result.return_value = None
            future.set_exception.return_value = None
            stream = unittest.mock.Mock()
            stream.close.return_value = None

# Generated at 2022-06-18 10:53:53.115976
# Unit test for method start of class _Connector
def test__Connector_start():
    # Test for method start(self: _Connector, timeout: float = 0.3, connect_timeout: Optional[Union[float, datetime.timedelta]] = None) -> Future[Tuple[socket.AddressFamily, Any, IOStream]]
    pass



# Generated at 2022-06-18 10:53:58.270510
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNonUnix
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIfNoIPv6
    from tornado.test.util import skipIfNoIPv6
    from tornado.test.util import skipIfNoUnixResolver
    from tornado.test.util import skipIfNoSSL

# Generated at 2022-06-18 10:54:02.919701
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Test case data
    timeout = None
    future = None
    secondary_addrs = None
    io_loop = None
    # Construct the object
    obj = _Connector(None, None)
    # Call the method
    obj.on_timeout()
    # Check the result
    assert True # TODO: implement your test here



# Generated at 2022-06-18 10:54:11.908668
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    import unittest.mock as mock
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_

# Generated at 2022-06-18 10:54:22.181812
# Unit test for method on_connect_timeout of class _Connector

# Generated at 2022-06-18 10:54:27.189727
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 8080)),
        (socket.AF_INET6, ("fe80::1", 8080)),
        (socket.AF_INET, ("127.0.0.2", 8080)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 8080)), (socket.AF_INET, ("127.0.0.2", 8080))]
    assert secondary == [(socket.AF_INET6, ("fe80::1", 8080))]

