

# Generated at 2022-06-18 10:46:57.000815
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.concurrent
    import tornado.gen
    import tornado.tcpserver
    import tornado.stack_context
    import tornado.locks
    import socket
    import ssl
    import functools
    import numbers
    import datetime
    import typing
    import contextlib
    import sys
    import unittest
    import logging
    import concurrent.futures


# Generated at 2022-06-18 10:47:05.381240
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:47:06.804407
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    _Connector.clear_timeout(None)


# Generated at 2022-06-18 10:47:16.890874
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado.platform.asyncio
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    from tornado.concurrent import Future
    from tornado.gen import TimeoutError
    import socket
    import ssl
    import functools
    import numbers
    import datetime
    import ssl
    import functools
    import numbers
    import datetime
    import ssl
    import functools
    import numbers
    import datetime
    import ssl
    import functools
    import numbers
    import datetime
    import ssl
    import functools
    import numbers
    import datetime
   

# Generated at 2022-06-18 10:47:27.689480
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock
    import socket
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.concurrent
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import functools
    import ssl
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado

# Generated at 2022-06-18 10:47:40.085692
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import functools
    import socket
    import ssl
    import time
    import tornado.gen
    import tornado.netutil
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.tcpserver
    import tornado.test.stack_context
    import tornado.test.util
    import tornado.test.httpclient_test
    import tornado.web
    import tornado.websocket
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.process
    import tornado.simple_httpclient
    import tornado.testing
    import tornado.tcpserver
    import tornado.test.httpclient_test
    import tornado.test.util

# Generated at 2022-06-18 10:47:50.804884
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    from tornado.testing import bind_unused_port
    from tornado.tcpserver import TCPServer
    from tornado.test.util import unittest

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.io_loop = IOLoop.current()
            self.connect = self.connect
            self.future = Future()
            self.timeout = None
            self.connect

# Generated at 2022-06-18 10:48:02.057825
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:48:09.770096
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    import unittest
    import unittest.mock
    import time
    import socket
    import ssl
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.concurrent
    import tornado.gen
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import functools
    import tornado.platform.asyncio
    import asyncio
    import functools
    import tornado.platform.asyncio
    import asyncio
    import functools
    import tornado.platform.asyncio
    import asyncio
    import functools
    import tornado.platform.asyncio
    import asyncio
    import functools
    import tornado.platform.asyncio
    import asyncio
    import functools

# Generated at 2022-06-18 10:48:18.756107
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class Test_Connector(AsyncTestCase):
        @gen_test
        def test_clear_timeouts(self):
            def connect(af, addr):
                return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()

            addrinfo = [(socket.AF_INET, ("127.0.0.1", 80))]
            connector = _Connector(addrinfo, connect)
            connector.start()
            connector.clear_timeouts()
            self.assertIsNone(connector.timeout)
            self.assertIsNone(connector.connect_timeout)

    unittest.main()



# Generated at 2022-06-18 10:48:53.858632
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock
    import socket
    import ssl
    import tornado.concurrent
    import tornado.gen
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.tornado
    import tornado.platform.uvloop
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.asyncio
    import tornado.platform.auto
    import tornado.platform.caresresolver
    import tornado.platform.tornado

# Generated at 2022-06-18 10:49:05.657494
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import unittest
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import time
    import functools
    import socket
    import ssl
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import to_

# Generated at 2022-06-18 10:49:15.920327
# Unit test for method clear_timeout of class _Connector

# Generated at 2022-06-18 10:49:20.614795
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # Test that clear_timeout removes the timeout
    io_loop = IOLoop()
    io_loop.make_current()
    connector = _Connector([], lambda af, addr: (None, None))
    connector.io_loop = io_loop
    connector.set_timeout(0.1)
    assert connector.timeout is not None
    connector.clear_timeout()
    assert connector.timeout is None



# Generated at 2022-06-18 10:49:30.121790
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import os
    import sys
    import time
    import logging
    import tornado.log
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.gen
    import tornado.concurrent
    import tornado.locks
    import tornado.queues
    import tornado.escape
    import tornado.httpclient
    import tornado.httputil
    import tornado.httpserver
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpclient
    import tornado.tcpserver
    import tornado.test.httpclient_test

# Generated at 2022-06-18 10:49:41.471198
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:49:52.649663
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio
    import unittest

    class Test_Connector(AsyncTestCase):
        @gen_test
        async def test__Connector_clear_timeouts(self):
            asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())
            loop = asyncio.get_event_loop()
            future = to_asyncio_future(self.io_loop.add_timeout(
                self.io_loop.time() + 0.3, self.on_timeout
            ))

# Generated at 2022-06-18 10:49:55.114598
# Unit test for method start of class _Connector
def test__Connector_start():
    # Test for method start(self, timeout=0.3, connect_timeout=None)
    # of class _Connector
    # self.fail()
    pass



# Generated at 2022-06-18 10:50:03.081446
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import unittest
    import unittest.mock as mock
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    from tornado.testing import AsyncTestCase
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import socket
    import ssl
    import functools
    import numbers
    import datetime
    import time
    import sys
    import os
    import logging
    import inspect
    from typing import Any, Union, Dict, Tuple, List, Callable, Iterator, Optional, Set
    from typing import TYPE_CHECKING
    from typing import cast
    from typing import overload
    from typing import Protocol


# Generated at 2022-06-18 10:50:13.959469
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        pass
    addrs = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    connector = _Connector(addrs, connect)
    connector.try_connect(iter(addrs))
    assert connector.remaining == 1
    assert connector.last_error is None
    assert connector.future.done() is False
    assert connector.timeout is None
    assert connector.connect_timeout is None
    assert connector.primary_addrs == [
        (socket.AF_INET, ("127.0.0.1", 80)),
    ]
    assert connector.secondary

# Generated at 2022-06-18 10:51:36.617029
# Unit test for method clear_timeout of class _Connector

# Generated at 2022-06-18 10:51:41.218968
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case data
    connector = _Connector([], lambda x, y: (None, None))
    connector.future = Future()
    # Perform the test
    connector.on_connect_timeout()
    # Validate the results
    assert connector.future.exception() == TimeoutError()
    assert connector.future.done() == True


# Generated at 2022-06-18 10:51:49.016650
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("2001:db8::1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
        (socket.AF_INET6, ("2001:db8::2", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("127.0.0.2", 80))]
    assert secondary == [(socket.AF_INET6, ("2001:db8::1", 80)), (socket.AF_INET6, ("2001:db8::2", 80))]



# Generated at 2022-06-18 10:51:58.461319
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError

    class _ConnectorTest(AsyncTestCase):
        def test_clear_timeouts(self):
            # type: () -> None
            connector = _Connector(
                [],
                lambda af, addr: (
                    IOStream(socket.socket(af, socket.SOCK_STREAM)),
                    Future(),
                ),
            )
            connector.set_timeout(0.1)
            connector.set_connect_timeout(0.1)
            connector.clear_timeouts()
            self.assertTrue(connector.timeout is None)
            self.assertTrue(connector.connect_timeout is None)


# Generated at 2022-06-18 10:52:05.430781
# Unit test for method clear_timeouts of class _Connector

# Generated at 2022-06-18 10:52:13.461081
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    import unittest.mock
    import socket
    import ssl
    import tornado.concurrent
    import tornado.gen
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.test.util
    import tornado.test.stack_context
    import tornado.test.gen_test
    import tornado.test.iostream_test
    import tornado.test.util
    import tornado.test.httpclient_test
    import tornado.test.httpserver_test
    import tornado.test.routing_test
    import tornado.test.web_test
    import tornado.test.websocket_test
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.iol

# Generated at 2022-06-18 10:52:14.411941
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # _Connector.clear_timeouts()
    pass



# Generated at 2022-06-18 10:52:22.034718
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import logging
    import sys
    import time
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.gen import coroutine
    from tornado.ioloop import IOLoop
    from tornado.iostream import StreamClosedError
    from tornado.tcpserver import TCPServer
    from tornado.netutil import bind_sockets
    from tornado.concurrent import Future
    from tornado.testing import bind_unused_port
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import gen_test
    from tornado.platform.asyncio import to_tornado_future

# Generated at 2022-06-18 10:52:22.853113
# Unit test for method start of class _Connector
def test__Connector_start():
    # TODO: implement
    pass


# Generated at 2022-06-18 10:52:29.971954
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import time
    import os
    import sys
    import logging
    import re
    from tornado.httpclient import AsyncHTTPClient
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.websocket import WebSocketHandler
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.concurrent import Future
    from tornado.gen import TimeoutError
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.iostream import StreamClosed

# Generated at 2022-06-18 10:54:09.300605
# Unit test for method try_connect of class _Connector

# Generated at 2022-06-18 10:54:15.176179
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.iostream import IOStream
    from tornado import gen
    from tornado.gen import TimeoutError
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

# Generated at 2022-06-18 10:54:17.273300
# Unit test for method start of class _Connector
def test__Connector_start():
    # Test for method start(...) of class _Connector
    # This method is tested indirectly by test_TCPClient
    pass



# Generated at 2022-06-18 10:54:22.068954
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.netutil
    import tornado.iostream
    import tornado.gen
    import tornado.tcpserver
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:54:27.886229
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:54:35.422059
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import logging
    import sys
    import os
    import time
    import socket
    import ssl
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.gen
    import tornado.ioloop
    import tornado.iostream
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.netutil
    import tornado.process
    import tornado.tcpserver
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.netutil
    import tornado.process
    import tornado.tcpserver
    import tornado

# Generated at 2022-06-18 10:54:39.539059
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import functools
    import socket
    import ssl
    import time
    import os
    import sys
    import logging
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import functools
    import socket
    import ssl
    import time
    import os
    import sys
    import logging
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
   

# Generated at 2022-06-18 10:54:49.147105
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:54:51.761547
# Unit test for method start of class _Connector
def test__Connector_start():
    # Test for method start(self, timeout = 0.3, connect_timeout = None)
    # of class _Connector
    # self.assertEqual(expected, _Connector.start(timeout, connect_timeout))
    raise NotImplementedError()



# Generated at 2022-06-18 10:55:00.280654
# Unit test for method try_connect of class _Connector

# Generated at 2022-06-18 10:55:35.614587
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import time
    import logging
    import sys
    import os
    import os.path
    import tempfile
    import shutil
    import subprocess
    import unittest
    import unittest.mock
    import warnings
    import functools
    import contextlib
    import io
    import concurrent.futures
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process

# Generated at 2022-06-18 10:55:36.400308
# Unit test for method start of class _Connector
def test__Connector_start():
    # TODO: implement test
    pass


# Generated at 2022-06-18 10:55:43.267157
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    # Test case 1:
    # Test for the case when the host is not reachable
    # Expected output:
    #     IOError
    #     True
    # Actual output:
    #     IOError
    #     True
    client = TCPClient()
    try:
        client.connect("www.google.com", 80)
    except IOError:
        print("IOError")
        print(True)
    # Test case 2:
    # Test for the case when the host is reachable
    # Expected output:
    #     True
    #     True
    # Actual output:
    #     True
    #     True
    try:
        client.connect("www.google.com", 80)
    except IOError:
        print(False)
        print(True)
    else:
        print(True)


# Generated at 2022-06-18 10:55:51.625725
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-18 10:55:59.994142
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import tornado.gen
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.testing
    import tornado.concurrent
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:56:07.903442
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import time
    import os
    import sys
    import logging
    import unittest
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.netutil
    import tornado.iostream
    import tornado.escape
    import tornado.httputil
    import tornado.gen
    import tornado.httpclient
    import tornado.locks
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.test.httpclient_test
    import tornado.test.util
    import tornado.test.web_test
    import tornado.concurrent
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.iostream
    import tornado

# Generated at 2022-06-18 10:56:14.117272
# Unit test for method split of class _Connector
def test__Connector_split():
    # type: () -> None
    """
    Test for method split of class _Connector
    """
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("127.0.0.1", 80))]

# Generated at 2022-06-18 10:56:21.600188
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.gen
    import tornado.concurrent
    import tornado.locks
    import socket
    import ssl
    import time
    import functools
    import logging
    import os
    import sys
    import unittest
    import warnings
    import typing
    import contextlib
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:56:29.474981
# Unit test for method try_connect of class _Connector