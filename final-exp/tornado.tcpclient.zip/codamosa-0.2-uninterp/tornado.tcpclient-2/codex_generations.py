

# Generated at 2022-06-18 10:46:55.781441
# Unit test for constructor of class _Connector
def test__Connector():
    # type: () -> None
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("::1", 80)),
    ]
    def connect(af, addr):
        # type: (socket.AddressFamily, Tuple) -> Tuple[IOStream, Future[IOStream]]
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()
    connector = _Connector(addrinfo, connect)
    assert connector.io_loop == IOLoop.current()
    assert connector.connect == connect
    assert isinstance(connector.future, Future)
    assert connector.timeout is None
    assert connector.connect_timeout is None
    assert connector.last_error is None
    assert connector.remaining == 2

# Generated at 2022-06-18 10:47:04.459659
# Unit test for method split of class _Connector
def test__Connector_split():
    # type: () -> None
    """
    Test for method split of class _Connector
    """
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    ]
    connector = _Connector(addrinfo, None)
    primary, secondary = connector.split(addrinfo)
    assert primary == [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
    ]

# Generated at 2022-06-18 10:47:14.884281
# Unit test for method start of class _Connector
def test__Connector_start():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio
    import socket

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.io_loop = IOLoop.current()
            self.resolver = Resolver()

# Generated at 2022-06-18 10:47:24.055017
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("2001:db8::1", 80)),
        (socket.AF_INET, ("127.0.0.1", 8080)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("127.0.0.1", 8080))]
    assert secondary == [(socket.AF_INET6, ("2001:db8::1", 80))]



# Generated at 2022-06-18 10:47:32.225586
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:47:37.277100
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio
    import socket
    import ssl
    import time
    import unittest

    class Test__Connector_start(AsyncTestCase):
        def setUp(self):
            super(Test__Connector_start, self).setUp()
            self.io_loop = IOLoop.current()
            self.resolver = Resolver

# Generated at 2022-06-18 10:47:49.143061
# Unit test for method start of class _Connector
def test__Connector_start():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.netutil import bind_sockets
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_as

# Generated at 2022-06-18 10:48:00.436160
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.netutil
    import tornado.iostream
    import tornado.gen
    import tornado.concurrent
    import tornado.escape
    import tornado.httputil
    import tornado.httpclient
    import tornado.locks
    import tornado.log
    import tornado.options
    import tornado.process
    import tornado.simple_httpclient
    import tornado.stack_context
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.test.httpclient_test
    import tornado.test.util
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi


# Generated at 2022-06-18 10:48:08.667427
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import asyncio
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.testing
    import tornado.gen
    import tornado.httpclient
    import tornado.httpserver
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.process
    import tornado.simple_httpclient
    import tornado.testing
    import tornado.tcpserver
    import tornado.test.httpclient_test
    import tornado.test.httpserver_test
    import tornado.test.util
    import tornado.testing

# Generated at 2022-06-18 10:48:11.541728
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test case data
    timeout = 0.3

    # Constructor test
    connector = _Connector(addrinfo=[], connect=lambda af, addr: (None, None))

    # Function test
    connector.set_timeout(timeout)



# Generated at 2022-06-18 10:48:36.569124
# Unit test for method start of class _Connector
def test__Connector_start():
    # _Connector.start(timeout=_INITIAL_CONNECT_TIMEOUT, connect_timeout=None) -> Future[Tuple[socket.AddressFamily, Any, IOStream]]
    pass


# Generated at 2022-06-18 10:48:37.348627
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    assert True

# Generated at 2022-06-18 10:48:48.391684
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test case data
    timeout = 0.3
    connect_timeout = 0.3
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 8080))]
    # Construct the object
    connector = _Connector(addrinfo, None)
    # Call the method
    connector.on_connect_timeout()
    # Check the result
    assert connector.future.done()
    assert connector.future.exception() == TimeoutError()
    assert connector.timeout is None
    assert connector.connect_timeout is None
    assert connector.last_error is None
    assert connector.remaining == 0
    assert connector.primary_addrs == []
    assert connector.secondary_addrs == []
    assert connector.streams == set()


# Generated at 2022-06-18 10:48:56.461229
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import time
    import unittest
    import unittest.mock
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_asyncio_future

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.connect = unittest.mock.Mock()
            self.connect.return_value = (
                unittest.mock.Mock(),
                to_asyncio_future(self.io_loop, Future()),
            )

# Generated at 2022-06-18 10:49:07.680071
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_future

# Generated at 2022-06-18 10:49:18.648266
# Unit test for constructor of class _Connector
def test__Connector():
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.testing import AsyncTestCase, gen_test

    class TestConnector(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.resolver = Resolver()
            self.resolver.configure("tornado.netutil.ThreadedResolver")

        @gen_test
        def test_connect(self):
            addrinfo = yield self.resolver.resolve("localhost:8888")
            connector = _Connector(addrinfo, self.connect)
            stream = yield connector.start()
            self.assertTrue(isinstance(stream, IOStream))
            stream.close()


# Generated at 2022-06-18 10:49:26.082189
# Unit test for method clear_timeouts of class _Connector

# Generated at 2022-06-18 10:49:38.221194
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_future

# Generated at 2022-06-18 10:49:43.288189
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class TestConnector(AsyncTestCase):
        def test_try_connect(self):
            def connect(af, addr):
                return (None, Future())

            c = _Connector([(socket.AF_INET, ("127.0.0.1", 80))], connect)
            c.try_connect(iter(c.primary_addrs))
            self.assertEqual(c.remaining, 0)

    unittest.main()



# Generated at 2022-06-18 10:49:54.957639
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest
    import unittest.mock as mock
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    from tornado.testing import bind_unused_port
    from tornado.tcpserver import TCPServer
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver

# Generated at 2022-06-18 10:50:34.607829
# Unit test for method split of class _Connector
def test__Connector_split():
    # Test case 1
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("127.0.0.1", 80))]
    assert secondary == [(socket.AF_INET6, ("127.0.0.1", 80))]

    # Test case 2

# Generated at 2022-06-18 10:50:36.242314
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test for method set_timeout(self, timeout)
    # of class _Connector
    # This test is not implemented.
    pass


# Generated at 2022-06-18 10:50:45.786176
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import is_future
    from tornado.platform.asyncio import is_coroutine_function
    from tornado.platform.asyncio import is_coroutine
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback

# Generated at 2022-06-18 10:50:48.328754
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    # Test for method set_connect_timeout(self, connect_timeout: Union[float, datetime.timedelta])
    # of class _Connector
    # This test is not yet implemented
    pass



# Generated at 2022-06-18 10:51:00.045118
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio
    import socket
    import ssl
    import time
    import functools
    import concurrent.futures
    import logging
    import sys
    import os
    import signal
    import subprocess
    import threading
    import concurrent.futures
    import multiprocessing
    import multiprocessing.connection
    import multiprocessing.managers
    import multiprocessing.pool
    import multiprocessing.process
    import multipro

# Generated at 2022-06-18 10:51:10.869454
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import IOStream
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:51:21.587182
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import functools
    import socket
    import ssl
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNonUnix
    from tornado.testing import AsyncTestCase, bind_unused_port, gen_test
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import Any
    from tornado.platform.asyncio import Future

# Generated at 2022-06-18 10:51:29.907093
# Unit test for method clear_timeouts of class _Connector

# Generated at 2022-06-18 10:51:40.130308
# Unit test for method start of class _Connector
def test__Connector_start():
    import unittest
    import tornado.testing
    import tornado.platform.asyncio
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_callback
    from tornado.platform.asyncio import to_asyncio_yieldable
    from tornado.platform.asyncio import to_tornado_yieldable
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_asyncio_

# Generated at 2022-06-18 10:51:48.381426
# Unit test for method split of class _Connector
def test__Connector_split():
    # Test case 1:
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET, ("127.0.0.1", 80))]
    assert secondary == [(socket.AF_INET6, ("127.0.0.1", 80))]

    # Test case 2:

# Generated at 2022-06-18 10:53:02.794729
# Unit test for constructor of class _Connector
def test__Connector():
    import socket
    import tornado.testing
    import tornado.gen
    import tornado.iostream
    import tornado.netutil

    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()


# Generated at 2022-06-18 10:53:07.457161
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    loop.set_debug(True)
    client = TCPClient()
    stream = loop.run_until_complete(client.connect("www.google.com", 80))
    print(stream)
    loop.run_until_complete(stream.close())
    loop.close()


# Generated at 2022-06-18 10:53:17.554892
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import time
    import unittest
    import unittest.mock as mock

    from tornado.ioloop import IOLoop

    from tornado.netutil import Resolver

    from tornado.testing import AsyncTestCase, gen_test

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super(_ConnectorTest, self).setUp()
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.resolver = Resolver(io_loop=self.io_loop)
            self.connect = mock.Mock()
            self.addrinfo = [
                (socket.AF_INET, ("127.0.0.1", 80)),
                (socket.AF_INET6, ("::1", 80)),
            ]

# Generated at 2022-06-18 10:53:26.445861
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import asyncio
    import socket
    import ssl
    import tornado.testing
    import tornado.gen
    import tornado

# Generated at 2022-06-18 10:53:31.833380
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Test for method clear_timeouts of class _Connector
    # This test is not very good, but it is better than nothing
    connector = _Connector([(socket.AF_INET, ("127.0.0.1", 80))], None)
    connector.clear_timeouts()
    assert connector.timeout is None
    assert connector.connect_timeout is None



# Generated at 2022-06-18 10:53:40.844145
# Unit test for method on_connect_timeout of class _Connector

# Generated at 2022-06-18 10:53:48.407496
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("2001:db8::1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
        (socket.AF_INET6, ("2001:db8::2", 80)),
    ]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
    ]

# Generated at 2022-06-18 10:53:59.360894
# Unit test for method clear_timeout of class _Connector

# Generated at 2022-06-18 10:54:05.798398
# Unit test for constructor of class _Connector
def test__Connector():
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()

    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80)), (socket.AF_INET6, ("127.0.0.1", 80))]
    _Connector(addrinfo, connect)



# Generated at 2022-06-18 10:54:14.234492
# Unit test for method on_connect_done of class _Connector