

# Generated at 2022-06-22 04:30:21.677558
# Unit test for constructor of class TCPClient
def test_TCPClient():
    stream = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    stream.bind(("localhost",0))
    stream.listen(2)
    ioloop = IOLoop.current()
    sock_addr = stream.getsockname()
    print('sock_addr', sock_addr)
    client = TCPClient()
    fu = gen.Task(client.connect, 'localhost', sock_addr[1], socket.AF_INET)
    s = ioloop.run_sync(fu)
    print(s)
    stream.close()
    s.close()
    ioloop.stop()

if __name__ == '__main__':
    test_TCPClient()

# Generated at 2022-06-22 04:30:23.733279
# Unit test for constructor of class TCPClient
def test_TCPClient():
    client = TCPClient()



# Generated at 2022-06-22 04:30:30.778616
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())
    class UnitTestTCPClient(AsyncTestCase):
        def setUp(self):
            super(UnitTestTCPClient, self).setUp()
            self.stream = TCPClient()
        @gen_test()
        async def test_close(self):
            await self.stream.close()
    UnitTestTCPClient().test_close()


# Generated at 2022-06-22 04:30:31.562691
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    pass



# Generated at 2022-06-22 04:30:36.390283
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    @gen.coroutine
    def test(self):
        stream = yield TCPClient().connect("127.0.0.1", 8080)
        stream.close()
        # TODO: Add more tests here
    #self.io_loop.run_sync(test)
# Test class TCPClient

# Generated at 2022-06-22 04:30:39.680575
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    connector = _Connector([(socket.AF_INET, ('127.0.0.1', 80))], None)
    connector.timeout = 1
    connector.connect_timeout = 2
    connector.clear_timeouts()
    assert connector.timeout == None
    assert connector.connect_timeout == None
    

# Generated at 2022-06-22 04:30:42.302720
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test set_timeout of _Connector class
    # Expected: 
    assert True == True


# Generated at 2022-06-22 04:30:54.687388
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import unittest
    import tornado.testing
    from tornado import gen
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import url_concat
    AsyncIOMainLoop().install()
    asyncio.set_event_loop(asyncio.new_event_loop())
    class test__Connector_set_timeout(tornado.testing.AsyncTestCase):

        @tornado.testing.gen_test
        async def test_set_timeout(self):
            request = HTTPRequest("http://localhost")
            _connector = _Connector("addrinfo", "connect")
            timeout = _INITIAL_CONNECT_TIMEOUT
            await _connector.set_timeout(timeout)
            self.stop()

# Generated at 2022-06-22 04:31:03.199891
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import socket
    
    class s:
        def getsockname(self):
            return ('127.0.0.1', 8888)
        def __init__(self):
            pass
    def connect(af, addr):
        if af is None: 
            raise Exception()
        
        if af == socket.AF_INET:
            return s, True
        else:
            return s, False
    
    addrinfo = [
        (socket.AF_INET, 'test'),
        (socket.AF_INET6, 'test'),
        (socket.AF_INET, 'test'),
    ]
    con = _Connector(addrinfo, connect)
    con.try_connect(iter(con.primary_addrs))
    assert con.streams == set([s])

# Generated at 2022-06-22 04:31:07.804753
# Unit test for method split of class _Connector
def test__Connector_split():
    def check(addrinfo, expected):
        actual = _Connector.split(addrinfo)
        assert actual == expected

    check([(1, 2), (1, 3), (2, 4), (2, 5)], ([(1, 2), (1, 3)], [(2, 4), (2, 5)]))



# Generated at 2022-06-22 04:31:33.589364
# Unit test for method start of class _Connector
def test__Connector_start():
    from asyncio import set_event_loop
    from tornado import testing
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy

    set_event_loop(AnyThreadEventLoopPolicy().new_event_loop())

    # Simulate only the case that a tornado.iostream is successfully created
    # for a given (AF, address) tuple.
    class TestConnector(object):
        def start(self, addrinfo):
            self.succeeded = True

    # Simulate that getaddrinfo returns both AF_INET and AF_UNSPEC entries
    # and no AF_INET6 entries.
    addrinfo = [(socket.AF_UNSPEC, None), (socket.AF_INET, None)]

    # Start 3 concurrent _Connector instances.
    # Simulate that the first call to IOStream.__init__() raises an


# Generated at 2022-06-22 04:31:34.357258
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    assert True == True

# Generated at 2022-06-22 04:31:35.441018
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Create an instance of the _Connector class
    connector = _Connector((), None)
    # Clear timeouts
    connector.clear_timeouts()



# Generated at 2022-06-22 04:31:47.608244
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError

    class UnitTest(_Connector, AsyncTestCase):
        def __init__(self, *args, **kwargs):
            AsyncTestCase.__init__(self, *args, **kwargs)
            _Connector.__init__(
                self,
                addrinfo=list(),
                connect=lambda *args: (None, Future()),
            )

        # Unit test for method: set_connect_timeout
        @gen_test
        def test_set_connect_timeout(self):
            future = self.start(connect_timeout=self.io_loop.time() + 0.001)
            yield gen.sleep(0.002)
            self.assertRaises(TimeoutError, future.result)

    Unit

# Generated at 2022-06-22 04:31:59.985774
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.test.util import unittest
    from tornado.test.testutils import skipBefore35
    from tornado.testing import gen_test

    class Test_Connector(unittest.AsyncTestCase):
        def test_set_connect_timeout(self):

            async def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
                return None, to_asyncio_future(None)

            def cancel(future: Future) -> None:
                future.cancel()

            f = _Connector([(socket.AF_INET, (b"a", 0))], connect).start(
                connect_timeout=0
            )

# Generated at 2022-06-22 04:32:06.696762
# Unit test for method split of class _Connector
def test__Connector_split():
    assert _Connector.split([(1, 2)]) == ([(1, 2)], [])
    assert _Connector.split([(1, 2), (3, 4)]) == ([(1, 2)], [(3, 4)])



# Generated at 2022-06-22 04:32:08.153933
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    obj = _Connector(addrinfo = [], connect = lambda: ())
    assert type(obj.clear_timeouts()) == None.__class__


# Generated at 2022-06-22 04:32:11.615170
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    resolver = Resolver(io_loop=IOLoop.current())
    client = TCPClient(resolver=resolver)
    client.close()
    assert isinstance(client, TCPClient)



# Generated at 2022-06-22 04:32:13.256562
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    client=TCPClient()
    client.close()
    assert True==True

test_TCPClient_close()

# Generated at 2022-06-22 04:32:25.746117
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    from tornado.platform.auto import set_close_exec
    import ssl

    ssl_options = None  # type: Optional[Dict[str, Any]]
    ssl_context = None  # type: Optional[Union[ssl.SSLContext, Dict[str, Any]]]
    max_buffer_size = None  # type: int
    try:
        socket.socketpair()
    except socket.error:
        # Python 2.6 or Windows
        return

    io_loop_instance = IOLoop.current()
    io_loop_instance.make_current()

    def connect(af: socket.AddressFamily, addr: Tuple[str, int]) -> Tuple[IOStream, "Future[IOStream]"]:
        # type: (...) -> Tuple[IOStream, Future[IOStream]]
        sock = socket.socket

# Generated at 2022-06-22 04:33:06.691527
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
  # a set of attributes and arguments used to test function try_connect of class _Connector
  new_addrinfo_list_1 = [(socket.AddressFamily.AF_INET, ('127.0.0.1', 80))]
  new_addrinfo_list_2 = [(socket.AddressFamily.AF_INET, ('127.0.0.1', 80)), (socket.AddressFamily.AF_INET6, ('127.0.0.1', 80)), (socket.AddressFamily.AF_INET6, ('127.0.0.1', 80))]

# Generated at 2022-06-22 04:33:17.488300
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import logging
    import unittest
    from unittest import mock
    from unittest.mock import MagicMock
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio

    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())

    def mock_stream(event_loop):
        stream = MagicMock()
        stream.close = MagicMock()
        stream.io_loop = event_loop
        stream.closed = False
        def mk_close():
            stream.closed = True
            return stream
        stream.close.side_effect = mk_close
        stream.closed = False
        return stream

    def mock_stream_factory(event_loop):
        return lambda af, addr: (mock_stream(event_loop), MagicMock())

    # Tri

# Generated at 2022-06-22 04:33:18.452182
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    client = TCPClient()
    client.close()


# Generated at 2022-06-22 04:33:26.832389
# Unit test for method split of class _Connector
def test__Connector_split():
    class connector(_Connector):
        def __init__(self, addrs):
            self.result = super().split(addrs)

    # type: List[Tuple[Any, Any, str]]
    addrs = [
        (socket.AF_INET, ("127.0.0.1", 443), ""),
        (socket.AF_INET, ("127.0.0.1", 80), ""),
        (socket.AF_INET6, ("fe80::1", 443), ""),
        (socket.AF_INET6, ("fe80::1", 80), ""),
    ]
    c = connector(addrs)
    assert len(c.result[0]) == 3
    assert len(c.result[1]) == 1



# Generated at 2022-06-22 04:33:32.200476
# Unit test for method start of class _Connector
def test__Connector_start():
    addrinfo = [(2,('127.0.0.1',8080))]
    resolver = Resolver()
    def connect(af, addr):
        future = Future()
        future.set_result(IOStream(socket.socket(af, socket.SOCK_STREAM)))
        return (future.result(), future)
    c = _Connector(addrinfo, connect)
    c.start()
    assert isinstance(c.future.result(), tuple)



# Generated at 2022-06-22 04:33:37.991087
# Unit test for constructor of class _Connector
def test__Connector():
    resolver = Resolver()
    future = resolver.resolve("www.google.com", 80)
    # wait for resolver result
    addrinfo = future.result()
    def connect(family: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, Future[IOStream]]:
        af = socket.AF_INET
        if family == socket.AF_INET6:
            af = socket.AF_INET6
        sock = socket.socket(af, socket.SOCK_STREAM, 0)
        stream = IOStream(sock, io_loop=IOLoop.current())
        future = Future()
        stream.connect(addr, functools.partial(connect_done_handler, future))
        return stream, future

# Generated at 2022-06-22 04:33:40.224031
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    _Connector(None,None,None).clear_timeouts()
    assert True



# Generated at 2022-06-22 04:33:47.974871
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    from tornado import testing, gen
    server = 'www.python.org'
    import socket
    resolver = socket.gethostbyname_ex(server)
    resolver = (('0.0.0.0', server, [server, 'localhost']), (None, None))
    client = TCPClient(resolver)
    stream = client.connect(server, 80)
    client.close()
    client.close()


# Generated at 2022-06-22 04:33:59.610476
# Unit test for constructor of class _Connector
def test__Connector():
    from . import iostream
    import socket

    def connect(af: int, addr: Tuple[str, int]) -> Tuple[IOStream, Future[IOStream]]:
        s = socket.socket(af, socket.SOCK_STREAM)
        s.connect(addr)
        return iostream.IOStream(s), Future()

    addrs = [
        (socket.AF_INET, ("127.0.0.1", 1234)),
        (socket.AF_INET6, ("2001::1", 1234)),
    ]
    connector = _Connector(addrs, connect)

    assert connector.remaining == 2
    assert connector.primary_addrs == [(socket.AF_INET, ("127.0.0.1", 1234))]

# Generated at 2022-06-22 04:34:11.347156
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # prepare test
    address_family = socket.AF_INET
    address = ("127.0.0.1", 9000)
    io_loop = IOLoop.current()
    socket_ = socket.socket(address_family, socket.SOCK_STREAM, 0)
    def connect(af, addr):
        sock = socket.socket(af, socket.SOCK_STREAM, 0)
        stream = IOStream(sock)
        future = Future()
        stream.set_close_callback(functools.partial(io_loop.add_callback, future.set_result, None))
        stream.connect(addr)
        return stream, future
    stream, future = connect(address_family, address)
    # test
    future.result()
    # cleanup test
    stream.close()
    socket_.close()



# Generated at 2022-06-22 04:35:17.405617
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import socket
    from tornado.testing import AsyncTestCase, gen_test
    import pytest
    from pytest import approx

    # A simple test with the default timeout
    class TestTimeout(AsyncTestCase):
        def test_set_timeout(self):
            # Make a list with socket.AF_INET and socket.AF_INET6
            addrs = [
                (socket.AF_INET, ("8.8.8.8", 53)),
                (socket.AF_INET6, ("2001:4860:4860::8888", 53)),
            ]  # type: List[Tuple[socket.AddressFamily, Any]]
            connector = _Connector(addrs, self.connect)
            self.connect_future = connector.start()
            self.connect_future.add_done_callback(self.on_connect)

# Generated at 2022-06-22 04:35:27.220734
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    with mock.patch('tornado.iostream.IOStream') as MockIOStream:
        from tornado.concurrent import Future
        from tornado.ioloop import IOLoop
        from tornado.stack_context import ExceptionStackContext
        from tornado.util import raise_exc_info
        from tornado.netutil import Resolver
        from tornado.gen import TimeoutError
        from tornado.iostream import IOStream
        from tornado.netutil import ssl_wrap_socket, SSLCertificateError
        from tornado.platform.auto import set_close_exec
        from tornado.log import gen_log
        from tornado import gen
        import socket
        import errno
        
        class _Connector(object):
            def __init__(self, addrinfo, connect):
                self.io_loop = IOLoop.current()

# Generated at 2022-06-22 04:35:35.072111
# Unit test for constructor of class _Connector
def test__Connector():
    # Test for constructor
    ai = [(1, 1, 1, 1, 1, 1, 1)]
    c = _Connector(ai, None)
    # Test for method split
    assert c.split([(1, 1, 1, 1, 1, 1, 1), (2, 2, 2, 2, 2, 2, 2)]) == (
        [(1, 1, 1, 1, 1, 1, 1)],
        [(2, 2, 2, 2, 2, 2, 2)],
    )



# Generated at 2022-06-22 04:35:35.458415
# Unit test for constructor of class TCPClient
def test_TCPClient():
    TCPClient()

# Generated at 2022-06-22 04:35:47.693251
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    _Connector.close_streams.__code__ = compile(
        _Connector.close_streams.__code__.co_consts[0],
        "_Connector.close_streams",
        "exec",
    )
    exec(_Connector.close_streams.__code__)
    # Create an instance of class _Connector
    _Connector_obj = _Connector([([2, 2], ("192.168.1.1", 8080))], lambda: None)
    _Connector_obj.close_streams()
    # Unit test for method clear_timeout of class _Connector

# Generated at 2022-06-22 04:35:59.293170
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # A unit test for _Connector.on_connect_timeout
    import unittest
    import socket
    import ssl
    import time
    import os
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.netutil import _possible_local_ports, _Server
    from tornado.platform.auto import set_close_exec
    # Used by create_connection
    def _try_connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        stream = IOStream
        return stream, Future
    # Used by create_connection

# Generated at 2022-06-22 04:36:09.362979
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    from tornado import ioloop

    def connect(af, addr):
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
        return stream, stream.connect(addr)

    self = _Connector([(socket.AF_INET6, ('::1', 8888))], connect)
    self.io_loop = ioloop.IOLoop()
    self.io_loop.make_current()
    
    def test():
        self.on_timeout()

    self.io_loop.add_callback(test)
    self.io_loop.start()


# Generated at 2022-06-22 04:36:15.087848
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-22 04:36:16.487417
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    _Connector.on_connect_done(None, None, None, None)



# Generated at 2022-06-22 04:36:29.862123
# Unit test for constructor of class _Connector

# Generated at 2022-06-22 04:38:30.253852
# Unit test for method start of class _Connector
def test__Connector_start():
    expected_future = Future()
    expected_future.set_result((socket.AF_INET, ("localhost", 80), None))
    connector = _Connector([(socket.AF_INET, ("localhost", 80))], None)
    assert connector.start() == expected_future



# Generated at 2022-06-22 04:38:42.147190
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    """
    Assert that if future is not done, _Connector.on_connect_done calls future.set_result
    """
    # GIVEN
    future = Future()
    future._state = 'PENDING'
    af = socket.AddressFamily.AF_INET
    addr = ('localhost', 2223)
    addrs = iter([(af, addr)])
    connector = _Connector(
        addrinfo=[(af, addr)],
        connect=lambda af, addr: (
            IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()
        ),
    )
    connector.future = future
    # WHEN
    connector.on_connect_done(addrs, af, addr, Future())
    # THEN
    assert future._state == 'DONE'



# Generated at 2022-06-22 04:38:51.649213
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    v1 = next(addrs)
    v2 = next(addrs)
    v3 = future.result()
    v4 = self.future.done()
    v5 = self.timeout
    v6 = self.io_loop
    v7 = self.io_loop.time()
    v8 = self.io_loop.remove_timeout(self.timeout)
    v9 = self.on_timeout()
    v10 = self.future.done()
    v11 = self.streams
    v12 = self.future.done()
    v13 = self.future.result()

    path1 = [v1, v2, v4, v11]
    path2 = [v1, v2, v4, v5, v6, v12]

# Generated at 2022-06-22 04:38:54.741847
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    def test():
        def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
            pass

        _Connector([], connect).set_timeout(_INITIAL_CONNECT_TIMEOUT)

    test()



# Generated at 2022-06-22 04:39:06.069969
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    class MyFuture(Future):
        def __init__(self):
            super().__init__()
            self.result_ = None

        def result(self):
            return self.result_

    my_future = MyFuture()
    connector = _Connector([], lambda x, y: [None, my_future])

    my_future.result_ = IOStream(None)
    addrs = iter([(None, None)])
    af, addr = (None, None)

    connector.on_connect_done(addrs, af, addr, my_future)
    assert(connector.remaining == 0 and connector.future.result() == (None, None, IOStream(None)))

    # will set exception in future
    my_future.result_ = IOError()

# Generated at 2022-06-22 04:39:17.289001
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    class _Connector_test_IOStream(object):
        def __init__(self):
            self.closed = False

        def close(self):
            self.closed = True

    class _Connector_test_resolver_Future(object):
        def __init__(self, connected, addr=None):
            self.connected = connected
            self.addr = addr
            self.done = False

        def result(self):
            self.done = True
            return _Connector_test_IOStream() if self.connected else self.addr

    def _Connector_test_connect(af, addr):
        if af == socket.AF_INET:
            return (
                _Connector_test_IOStream(),
                _Connector_test_resolver_Future(True),
            )
        else:
            return _Connector_test_IOStream(), _

# Generated at 2022-06-22 04:39:30.056181
# Unit test for method start of class _Connector
def test__Connector_start():
    import pytest
    from contextlib import contextmanager
    from unittest.mock import Mock

    from tornado import gen
    
    from tornado.util import ObjectDict
    
    from tornado.tcpclient import _Connector
    from tornado.ioloop import IOLoop
    
    from tornado import stack_context
    
    from tornado.gen import TimeoutError
    
    from tornado.iostream import IOStream
    
    from tornado import concurrent
    
    from tornado.netutil import Resolver
    
    from typing import Any, Union, Dict, Tuple, List, Callable, Iterator, Optional, Set
    
    @contextmanager
    def mock_resolver(expected_resolutions):
        resolver_instance = Mock(spec=Resolver)

# Generated at 2022-06-22 04:39:41.612127
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import sys
    import time
    import os
    import unittest
    import tempfile
    import shutil
    import errno

    def unlink(path):
        try:
            os.unlink(path)
        except OSError as e:
            if e.errno != errno.ENOENT:
                raise

    # Unit test for method try_connect of class _Connector
    from tornado.testing import AsyncTestCase, gen_test, main, bind_unused_port
    from tornado import gen
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver


# Generated at 2022-06-22 04:39:42.525734
# Unit test for constructor of class TCPClient
def test_TCPClient():
    client = TCPClient()
    assert client is not None

# Generated at 2022-06-22 04:39:43.112474
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    assert True

