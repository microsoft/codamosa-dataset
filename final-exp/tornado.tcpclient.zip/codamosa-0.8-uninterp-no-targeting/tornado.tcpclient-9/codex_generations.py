

# Generated at 2022-06-22 04:30:11.045540
# Unit test for constructor of class TCPClient
def test_TCPClient():
    client = TCPClient()
    assert client

# Generated at 2022-06-22 04:30:21.541520
# Unit test for constructor of class TCPClient
def test_TCPClient():
    client = TCPClient()
    assert client.resolver.nameservers == [
        "8.8.8.8",
        "8.8.4.4",
        "2001:4860:4860::8888",
        "2001:4860:4860::8844",
    ]
    assert client._own_resolver is True

    resolver = Resolver(["1.1.1.1", "8.8.8.8"])
    client = TCPClient(resolver)
    assert client.resolver.nameservers == ["1.1.1.1", "8.8.8.8"]
    assert client._own_resolver is False

    client.close()
    assert client.resolver is None
    assert client._own_resolver is False



# Generated at 2022-06-22 04:30:27.233643
# Unit test for constructor of class _Connector
def test__Connector():
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return None, None
    
    res = _Connector([(socket.AF_INET, (1, 2))], connect)
    if not isinstance(res, _Connector):
        raise Exception("wrong constructor")



# Generated at 2022-06-22 04:30:36.112234
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    ioloop = IOLoop.current()

    def get_addrs():
        return [(socket.AF_INET, ("127.0.0.1", 8000))]

    def connect(af, addr):
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM), ioloop=ioloop)
        future = Future()
        return stream, future

    def start_connect(timeout=_INITIAL_CONNECT_TIMEOUT):
        _Connector(get_addrs(), connect).start(timeout)

    # _Connector.start checks whether future is done
    start_connect()
    ioloop.close()



# Generated at 2022-06-22 04:30:39.148683
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    connector = _Connector(None, None)
    timeout = 3.5
    connector.set_connect_timeout(timeout)
    if connector.connect_timeout.timeout != timeout:
        raise AssertionError()



# Generated at 2022-06-22 04:30:52.202354
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    from unittest import TestCase
    from tornado.testing import AsyncTestCase
    from tornado import gen
    from _Connector import _Connector

    # _Connector is a class in module tornado.netutil
    # where its definition is not shown here
    # _Connector is a normal class, not a new style class
    @gen.coroutine
    def test_Coroutine_future_add_done_callback():
        connector = _Connector([], None)

        @gen.coroutine
        def test_Coroutine_set_timeout():
            connector = _Connector([], None)
            connector.set_timeout(1)

        @gen.coroutine
        def test_Coroutine_on_timeout():
            connector = _Connector([], None)
            # connector.on_timeout()


# Generated at 2022-06-22 04:31:03.431581
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Setup fixtures
    future = future_add_done_callback(
        Future(), functools.partial(on_connect_done, addrs, af, addr)
    )
    future.set_result(future.result())
    # Exercise SUT
    _Connector.set_timeout(timeout=_INITIAL_CONNECT_TIMEOUT)
    # Verify outcome
    assert _Connector.isinstance(object)
    assert type(self) is _Connector
    assert self.timeout is not None
    assert self.future.done()
    assert self.future.result() == future.result()
    assert _Connector.set_timeout == _Connector.on_timeout
    # Cleanup
    self._connector = None
    self.timeout = None
    self.remaining = None
    self.primary_addrs = None
    self.secondary

# Generated at 2022-06-22 04:31:15.698871
# Unit test for method clear_timeout of class _Connector

# Generated at 2022-06-22 04:31:16.585328
# Unit test for constructor of class TCPClient
def test_TCPClient():
    TCPClient(None)


if __name__ == "__main__":
    test_TCPClient()

# Generated at 2022-06-22 04:31:26.382984
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import socket
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    # setup
    host = "1.1.1.1"
    port = 12345
    io_loop = IOLoop.current()
    def connect(af, addr):
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()
    addrs = list()
    addrs.append((socket.AF_INET, (host, port)))
    connector = _Connector(addrs, connect)
    connector._Connector__io_loop = io_loop
    connector.remaining=0
    connector.future = Future()
    future = Future()
    future.set_exception(Exception())
    # test

# Generated at 2022-06-22 04:31:52.271126
# Unit test for method split of class _Connector
def test__Connector_split():
    import socket
    # Create dummy addrinfo
    addrinfo=[(socket.AF_INET,('1.1.1.1',80)),(socket.AF_INET,('2.2.2.2',80)),(socket.AF_INET6,('1:1:1:1:1:1:1:1',80))]
    connector = _Connector(addrinfo, lambda a,b: (1,2))
    expected = ([(socket.AF_INET,('1.1.1.1',80)),(socket.AF_INET,('2.2.2.2',80))],
                [(socket.AF_INET6,('1:1:1:1:1:1:1:1',80))])
    # Call tested method
    obtained = connector.split(addrinfo)

# Generated at 2022-06-22 04:31:54.527877
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    obj=_Connector([],lambda af, addr: (None, None))
    obj.set_timeout(0.3)
    assert obj.timeout != None


# Generated at 2022-06-22 04:32:03.741282
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # Create fake objects
    class IOStream:
        def __init__(self: IOStream) -> None:
            self.closed = False
        def close(self: IOStream) -> None:
            self.closed = True
    class IOLoop:
        def __init__(self: IOLoop) -> None:
            pass
    class socket:
        AF_INET = 1
        AF_INET6 = 2
        __expect = [AF_INET, AF_INET6]
        def __init__(self: socket) -> None:
            assert self.AF_INET in self.__expect
            assert self.AF_INET6 in self.__expect
            self.__expect.remove(self.AF_INET)
            self.__expect.remove(self.AF_INET6)

# Generated at 2022-06-22 04:32:10.119703
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    host = "localhost"
    port = 80
    io_loop = IOLoop()
    resolver = Resolver()
    connector = _Connector(
        resolver.resolve(host),
        functools.partial(
            _ClientIOStream._try_connect,
            io_loop,
            host,
            port,
            max_buffer_size=None,
            ssl_options=None,
            resolver=resolver,
        ),
    )
    future =connector.start()
    connector.on_connect_timeout()
    assert future.exception()

# Generated at 2022-06-22 04:32:11.040854
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    pass



# Generated at 2022-06-22 04:32:11.715344
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
  #TODO
  pass


# Generated at 2022-06-22 04:32:23.911426
# Unit test for constructor of class _Connector
def test__Connector():
    addrinfo = [
        (socket.AddressFamily.AF_INET, ("127.0.0.1", 80)),
        (socket.AddressFamily.AF_INET6, ("127.0.0.1", 80)),
        (socket.AddressFamily.AF_INET, ("127.0.0.1", 80)),
    ]
    connector = _Connector(
        addrinfo,
        connect=lambda af, addr: (
            IOStream(socket.socket(af, socket.SOCK_STREAM)),
            Future(),
        ),
    )
    assert connector is not None
    assert isinstance(connector.io_loop, IOLoop)
    assert callable(connector.connect)
    assert isinstance(connector.future, Future)
    assert connector.timeout is None
    assert connector.connect_timeout is None


# Generated at 2022-06-22 04:32:30.972757
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    def check(
        timeout: float,
        expected_return_value: bool,
        expected_timeout: Optional[object],
        expected_loop_time: float,
    ) -> None:
        def fake_add_timeout(dt: Union[float, datetime.timedelta]) -> Any:
            assert dt == expected_loop_time
            return "timeout"

        io_loop = FakeIOLoop()
        io_loop.add_timeout = fake_add_timeout
        io_loop.time = lambda: 0

        connector = _Connector([], lambda *args: (None, Future()))
        connector.io_loop = io_loop
        assert connector.set_timeout(timeout) == expected_return_value
        assert connector.timeout == expected_timeout


# Generated at 2022-06-22 04:32:43.047701
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import asyncio
    import sys
    import signal
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    host = '127.0.0.1'
    port = 3490
    loop = asyncio.get_event_loop()
    conn_handler = loop.create_connection(lambda: asyncio.StreamReaderProtocol(asyncio.StreamReader(), loop=loop), host=host, port=port)
    client_socket, _ = loop.run_until_complete(conn_handler)
    loop.close()
    # get the IO object from tornado
    io_stream = IOStream(client_socket, max_buffer_size=10)
    # run the connect method
    resolved_addr = asyncio.run(io_stream.connect((host, port)))

# Generated at 2022-06-22 04:32:53.789983
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # replace the io_loop
    class io_loop(object):
        def __init__(self) -> None:
            self.add_timeout = add_timeout

    def add_timeout(
        self, callback: Callable, timeout: float
    ) -> Optional[Any]:  # pylint: disable=no-self-argument
        return None

    # replace the split method of the _Connector class

# Generated at 2022-06-22 04:35:27.521880
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    pass

# Generated at 2022-06-22 04:35:39.190949
# Unit test for constructor of class _Connector
def test__Connector():
    addrinfo = [
        (socket.AF_INET, ("192.168.1.1", 8000)),
        (socket.AF_INET6, ("192.168.1.1", 8000)),
        (socket.AF_INET, ("192.168.1.2", 8000))
    ]
    def connect(af: int, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
        res = Future()
        return (stream, res)
    connector = _Connector(addrinfo, connect)
    assert connector.io_loop == IOLoop.current()
    assert connector.connect == connect
    assert not connector.future.done()
    assert connector.timeout is None
    assert connector.connect_timeout is None


# Generated at 2022-06-22 04:35:52.337031
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    from tornado.tcpserver import TCPServer
    from tornado.iostream import IOStream
    
    class MockTCPServer(TCPServer):
        def handle_stream(self, stream: IOStream, address: Tuple) -> None:
            pass
    resolver = Resolver()
    port = 8888
    print("MockTCPServer will listen on port %d" % (port))
    server = MockTCPServer()
    server.listen(port)
    localhost_addrs = resolver.resolve("localhost:%d" % (port))
    remote_addrs = resolver.resolve("www.baidu.com:%d" % (port))
    connector = _Connector(localhost_addrs, functools.partial(IOStream.connect, max_buffer_size=10))

# Generated at 2022-06-22 04:36:03.058227
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    from tornado.ioloop import IOLoop
    from tornado.gen import TimeoutError
    from tornado.testing import AsyncTestCase, gen_test

    test_case = AsyncTestCase()

    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[
        IOStream, "Future[IOStream]"
    ]:
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM))

        future = Future()  # type: "Future[IOStream]"
        # delayed handler, just simulates the socket connection
        IOLoop.current().call_later(1, future.set_result, stream)

        return stream, future


# Generated at 2022-06-22 04:36:15.344892
# Unit test for method split of class _Connector
def test__Connector_split():
    addr_list = [
        (socket.AF_INET, ("127.0.0.1", 8080)),
        (socket.AF_INET6, ("127.0.0.1", 8080)),
        (socket.AF_INET, ("127.0.0.1", 8080)),
        (socket.AF_INET6, ("127.0.0.1", 8080)),
        (socket.AF_INET, ("127.0.0.1", 8080)),
        (socket.AF_INET6, ("127.0.0.1", 8080)),
        ]
    _connector = _Connector(addr_list, None)
    _connector_split = _connector.split(addr_list)

# Generated at 2022-06-22 04:36:28.799713
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import random
    import time
    import traceback
    from typing import Tuple
    from nose.tools import assert_equal
    from nose.tools import assert_true

    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream

    from .connection import get_ssl_context

    from zmq.eventloop.ioloop import IOLoop as ZeroMQIOLoop

    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, Future]:
        # type: (socket.AddressFamily, Tuple) -> Tuple[IOStream, Future]
        # print('connecting to %s:%d' % addr)
        sock = socket.socket(af)
        sock.setblocking(False)
        stream = IOStream(sock)


# Generated at 2022-06-22 04:36:29.772090
# Unit test for method start of class _Connector
def test__Connector_start():
    future = _Connector.start


# Generated at 2022-06-22 04:36:37.315411
# Unit test for method split of class _Connector
def test__Connector_split():
    inputs = [(socket.AF_INET, ("10.0.0.2", 80)),
                (socket.AF_INET6, ("2601:646:8100:6db3:6c9e:f2b8:f35b:44d5", 80))]
    actual = _Connector.split(inputs)
    expected = ([(socket.AF_INET, ("10.0.0.2", 80))],
                [(socket.AF_INET6, ("2601:646:8100:6db3:6c9e:f2b8:f35b:44d5", 80))])
    assert expected == actual


# Generated at 2022-06-22 04:36:49.540721
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    addrinfo = [('af', ('addr', 1)), ('af2', ('addr2', 2))]
    def dummy_connect(af, addr):
        return (IOStream(), Future())

    connector = _Connector(addrinfo, dummy_connect)
    calls = 0
    def on_connect_done(addrs, af, addr, future):
        nonlocal calls
        if calls == 0:
            assert af == 'af'
            assert addr == ('addr', 1)
        elif calls == 1:
            assert af == 'af2'
            assert addr == ('addr2', 2)
        elif calls == 2:
            assert addrs is None
            assert af == 'af'
            assert addr == ('addr', 1)
        elif calls == 3:
            assert addrs is None
            assert af == 'af2'

# Generated at 2022-06-22 04:37:00.255239
# Unit test for method split of class _Connector
def test__Connector_split():
    from collections import defaultdict

    test_list = [
        (0, "a"),
        (1, "b"),
        (0, "c"),
        (1, "d"),
        (1, "e"),
        (1, "f"),
        (0, "g"),
    ]
    expected_result = [
        [(0, "a"), (0, "c"), (0, "g")],
        [(1, "b"), (1, "d"), (1, "e"), (1, "f")],
    ]
    splited_list = _Connector.split(test_list)
    af0_addrs = {(af, addr) for (af, addr) in splited_list[0]}

# Generated at 2022-06-22 04:39:13.377411
# Unit test for method start of class _Connector
def test__Connector_start():
    def _test_case1(
        _testcase_name: str, _testcase_argv: Any, _testcase_expected: Any
    ) -> None:
        _testcase_actual = _Connector(
            addrinfo=_testcase_argv[0], connect=_testcase_argv[1]
        ).start()
        assert _testcase_actual == _testcase_expected
        return


# Generated at 2022-06-22 04:39:24.896673
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    def func1(arg1, arg2):
        pass
    def func2():
        pass
    def func3():
        pass
    
    # Test case 1: normal
    config = {
        'arg1': [
            (1, 1),
            (2, 2),
            (3, 3)
        ],
        'arg2': [
            (1, 1),
            (2, 2),
            (3, 3)
        ]
    }    
    
    m = _Connector(config['arg1'], func1)
    
    # Test case 2: timeout is None

# Generated at 2022-06-22 04:39:27.704509
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    tcp_client = TCPClient()
    tcp_client.close()

# Generated at 2022-06-22 04:39:28.666259
# Unit test for constructor of class TCPClient
def test_TCPClient():
    client = TCPClient()

# Generated at 2022-06-22 04:39:35.409267
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import pytest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    from tornado.platform.asyncio import to_tornado_future
    from tornado.testing import bind_unused_port
    class Test_clear_timeout(AsyncTestCase):
        def setUp(self) -> None:
            super().setUp()
            AsyncIOMainLoop().install()
            self.ioloop = AsyncIOMainLoop().current()
            self.address, self.port = bind_unused_port()
            self.default_timeout = self.io_loop.time() + 0.3

# Generated at 2022-06-22 04:39:42.328947
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    obj = _Connector(addrinfo=['addrinfo'], connect=['connect'])
    obj.timeout = "timeout"
    obj.connect_timeout = "connect_timeout"
    IOLoop.remove_timeout = mock.Mock()
    obj.clear_timeouts()
    IOLoop.remove_timeout.assert_any_call(obj.timeout)
    IOLoop.remove_timeout.assert_any_call(obj.connect_timeout)

# Generated at 2022-06-22 04:39:51.422296
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import gen_test
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase
    
    class Test_Connector(AsyncTestCase):
        def setUp(self):
            super().setUp()
            AsyncIOMainLoop().install()
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        @gen_test(timeout=30)
        async def test__Connector_clear_timeout(self):
            timeout = 0.3