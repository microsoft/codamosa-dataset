

# Generated at 2022-06-22 04:30:08.145928
# Unit test for method start of class _Connector
def test__Connector_start(): pass



# Generated at 2022-06-22 04:30:16.213472
# Unit test for constructor of class _Connector
def test__Connector():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("[::1]", 80)),
    ]
    assert _Connector.split(addrinfo) == ([(socket.AF_INET, ("127.0.0.1", 80))], [
        (socket.AF_INET6, ("[::1]", 80)),
    ])



# Generated at 2022-06-22 04:30:17.549786
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    client = TCPClient()
    client.close()
    return True


# Generated at 2022-06-22 04:30:21.812981
# Unit test for constructor of class TCPClient
def test_TCPClient():
    # Test: When the TCPClient is created, the resolver should be the same
    a = TCPClient()
    resolver = a.resolver
    print("Test constructing the class:PASS")

    if resolver is not None:
        a.close()
        print("Test closing the reslover:PASS")
    else:
        print("Test closing the reslover:FAIL")


# Generated at 2022-06-22 04:30:23.453190
# Unit test for constructor of class TCPClient
def test_TCPClient():
    TCPClient()

# Generated at 2022-06-22 04:30:34.397614
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    import io
    import socket

    class MockIO(io.BytesIO):
        def __getattr__(self, attr):
            raise AttributeError(
                'MockIO doesn\'t have attribute "%s"' % (attr))

    class MockSocket(socket.socket):
        def __init__(self, *args, **kwargs):
            self.fileno = lambda: -1
            self.getsockopt = lambda _, __: 0
            self.setblocking = lambda _: None

        def __getattr__(self, attr):
            raise AttributeError(
                'MockSocket doesn\'t have attribute "%s"' % (attr))

    class Test_Connector_set_timeout(AsyncTestCase):
        def setUp(self):
            super().set

# Generated at 2022-06-22 04:30:45.923313
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    set_function = ["set_exception"]
    set_function_args = [(TimeoutError(),)]
    set_function_kwargs = [dict()]
    call_function = ["close"]
    call_function_args = [list()]
    call_function_kwargs = [dict()]
    connector = _Connector(
        list(
            [
                (socket.AF_INET, ("127.0.0.1", 80)),
                (socket.AF_INET6, ("127.0.0.1", 80)),
            ]
        ),
        lambda af, addr: (IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()),
    )
    future = connector.start(timeout=0.3, connect_timeout=0.3)
    future.result = lambda: None
    future

# Generated at 2022-06-22 04:30:49.625206
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    t = _Connector(None, None)
    t.on_connect_done((None, None), "", (1, 2, 3))
    pass



# Generated at 2022-06-22 04:30:59.530783
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    timeout = 0.3
    # Start loop
    ioloop = IOLoop()
    ioloop.make_current()
    stream = IOStream(socket.socket())
    future = future_add_done_callback(
            future, functools.partial(self.on_connect_done, addrs, af, addr)
        )
    future.set_result(stream)
    stream.close()
    def connect(af, addr):
        stream = IOStream(socket.socket())
        stream.connect(addr, callback=lambda: future.set_result(stream))
        return (stream, future)
    # Initialize
    connector = _Connector([(socket.AF_INET, ("127.0.0.1", 80))], connect)
    connector.set_timeout(timeout)
    ioloop.start()


# Generated at 2022-06-22 04:31:03.523892
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    a = _Connector(addrinfo=None,connect=None)
    a.timeout = object()
    a.connect_timeout = object()
    a.clear_timeouts()
    assert a.timeout is None
    assert a.connect_timeout is None



# Generated at 2022-06-22 04:32:03.335821
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    io_loop = IOLoop.current()

    def connect(af: Any, addr: Any):
        raise NotImplementedError()

    class NotFoundError(Exception):
        pass

    class TimedOutError(Exception):
        pass

    socket = NotFoundError()  # type: Any

    _, addrinfo = Resolver().resolve(socket).result()
    addrinfo = [a for a in addrinfo if a[0] in (socket.AF_INET, socket.AF_INET6)]
    connector = _Connector(addrinfo, connect)

    def on_connect_done():
        raise NotImplementedError()

    def on_timeout():
        raise NotImplementedError()

    def clear_timeouts():
        raise NotImplementedError()

    def set_timeout(timeout: float):
        raise

# Generated at 2022-06-22 04:32:11.201996
# Unit test for constructor of class _Connector
def test__Connector():
    from tornado import gen
    from tornado.iostream import IOStream

    async def connect(af, addr):
        # type: (socket.AddressFamily, Tuple[str, int]) -> Tuple[IOStream, Future[IOStream]]
        s = socket.socket(af, socket.SOCK_STREAM, 0)
        stream = IOStream(s)
        future = Future()
        stream.connect(addr, lambda: future.set_result(stream))
        await future

        return stream, future


# Generated at 2022-06-22 04:32:18.033616
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
    s.bind(("127.0.0.1", 0))
    c = _Connector([(socket.AF_INET, s.getsockname())], lambda af, addr: (None, None))
    c.future = Future()
    c.on_connect_timeout()
    assert c.future.result() == TimeoutError()


# Generated at 2022-06-22 04:32:22.732557
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    io_loop = IOLoop.current()
    io_loop.time = lambda: 1543106132.711425
    a = _Connector([(2, ("74.125.200.106", 80))], lambda t1, t2: (t2, None))
    a.io_loop = io_loop
    a.set_timeout(0.3)
    b: Optional[datetime.timedelta] = a.timeout
    assert b == datetime.timedelta(seconds=0.3)

# Generated at 2022-06-22 04:32:30.080319
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    # Test: set_timeout, clear_timeouts, on_timeout
    # Assert:
    class Mock_Connector():
        def __init__(self):
            self.timeout = None
            self.io_loop = IOLoop.current()
        def set_timeout(self, timeout: float) -> None:
            self.timeout = self.io_loop.add_timeout(
                self.io_loop.time() + timeout, self.on_timeout
            )
        def clear_timeouts(self) -> None:
            if self.timeout is not None:
                self.io_loop.remove_timeout(self.timeout)
        def on_timeout(self) -> None:
            self.timeout = None
            print('Time out')

    c = Mock_Connector()
    c.set_timeout(0.3)
   

# Generated at 2022-06-22 04:32:32.753126
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    connector = _Connector([], None)
    connector.timeout = "nothing"
    connector.clear_timeout()
    assert connector.timeout is None


# Generated at 2022-06-22 04:32:34.177888
# Unit test for constructor of class TCPClient
def test_TCPClient():
    tcpclient = TCPClient()
    tcpclient.close()


# Generated at 2022-06-22 04:32:47.167157
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import asyncio
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop

    class MyTestCase(AsyncTestCase):
        def setUp(self) -> None:
            super(MyTestCase, self).setUp()
            AsyncIOMainLoop().install()

        def tearDown(self) -> None:
            super(MyTestCase, self).tearDown()
            AsyncIOMainLoop().close(all_fds=True)

        @gen_test
        def test_clear_timeouts(self) -> None:
            class MyConnector(_Connector):
                def split(self, addrInfo):
                    return [], []

                def try_connect(self, addrs):
                    self.clear_timeouts()


# Generated at 2022-06-22 04:32:49.487889
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    client = TCPClient()  # type: TCPClient
    # Test that the right method is being called
    assert client.close() == None


# Generated at 2022-06-22 04:32:51.817151
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    client = TCPClient()
    client.close()
    assert True == True



# Generated at 2022-06-22 04:33:32.636883
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # void _Connector::clear_timeouts()
    pass



# Generated at 2022-06-22 04:33:33.118428
# Unit test for constructor of class _Connector
def test__Connector():
    pass


# Generated at 2022-06-22 04:33:34.867498
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    connector = _Connector(addrinfo=None, connect=None)
    connect_timeout = None
    connector.set_connect_timeout(connect_timeout)



# Generated at 2022-06-22 04:33:47.074537
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio

    asyncio_loop = asyncio.get_event_loop()
    from tornado.ioloop import IOLoop

    class TCPClientTestCase(tornado.testing.AsyncTestCase):
        @tornado.testing.gen_test
        async def test_connect(self):
            stream = await TCPClient().connect("127.0.0.1", 80)
            stream.close()

        @tornado.testing.gen_test
        async def test_timeout(self):
            with self.assertRaises(asyncio.TimeoutError):
                await TCPClient().connect("127.0.0.1", 80, timeout=0.01)

    tornado.testing.AsyncTestCase.configure("coroutine", "asyncio")

# Generated at 2022-06-22 04:33:51.533909
# Unit test for method split of class _Connector
def test__Connector_split():
    test_addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("::1", 80))
    ]
    primary, secondary = _Connector.split(list(test_addrinfo))
    assert primary == test_addrinfo
    assert secondary == []



# Generated at 2022-06-22 04:33:52.315284
# Unit test for method start of class _Connector
def test__Connector_start():
    # TODO: implement this
    pass

# Generated at 2022-06-22 04:33:59.457436
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    connector = _Connector(
        [
            (socket.AF_INET, ("www.google.com", 80)),
            (socket.AF_INET6, ("::1", 80))
        ],
        lambda af, addr: (
            None,
            Future()
        )
    )
    with pytest.raises(IOError):
        connector.close_streams()



# Generated at 2022-06-22 04:34:02.893746
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    # Note: Need _Connector to be used first
    assert True

_Connector_clear_timeouts = test__Connector_clear_timeouts



# Generated at 2022-06-22 04:34:08.657875
# Unit test for constructor of class _Connector
def test__Connector():
    from tornado.iostream import IOStream, _Connector, _ConnectionType
    import socket
    import unittest

    import ssl
    from ssl import SSLError

    class FakeIOStream(IOStream):
        def __init__(
            self,
            raw_socket: socket.socket,
            *args: Any,
            **kwargs: Any
        ) -> None:
            super(FakeIOStream, self).__init__(
                socket.socket(),
                *args,
                **kwargs
            )


# Generated at 2022-06-22 04:34:10.108405
# Unit test for method start of class _Connector
def test__Connector_start():
    # _Connector is tested in the test for client.HTTPClient.
    pass



# Generated at 2022-06-22 04:34:51.747317
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    assert True


# Generated at 2022-06-22 04:34:53.447961
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    timeout = datetime.timedelta(minutes=1)
    connector = _Connector([], None)
    connector.set_connect_timeout(timeout)



# Generated at 2022-06-22 04:35:04.670830
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    from tornado.testing import AsyncTestCase, get_unused_port
    from tornado.netutil import bind_sockets
    from tornado.iostream import StreamClosedError

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super(_ConnectorTest, self).setUp()
            sockets = bind_sockets(get_unused_port())
            self.port = sockets[0].getsockname()[1]


# Generated at 2022-06-22 04:35:06.888865
# Unit test for constructor of class TCPClient
def test_TCPClient():
    tclient = TCPClient()
    tclient.close()

    tclient = TCPClient(resolver=Resolver())
    tclient.close()

# Generated at 2022-06-22 04:35:09.158507
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    args = []
    # No argument
    obj = TCPClient(args[0])
    obj.close()


# Generated at 2022-06-22 04:35:14.980725
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import sys
    import io
    import unittest
    #set sys.stdout to io.StringIO object to suppress print statement
    sys.stdout = io.StringIO()

    #test method clear_timeout of class _Connector
    result = _Connector.clear_timeout()
    #assert equal to check if Ioloop instance is created
    assert result is None

    #reset sys.stdout to the original stdout
    sys.stdout = sys.__stdout__



# Generated at 2022-06-22 04:35:26.666233
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import datetime
    from tornado.gen import TimeoutError
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, LogTrapTestCase
    from tornado.log import gen_log
    class UnitTest(AsyncTestCase, LogTrapTestCase):
        def test_example(self):
            future = Future()  # type: Future[int]
            self.io_loop.add_callback(
                functools.partial(self._example, future)
            )
            self.wait()

        @gen.coroutine
        def _example(self, future: "Future[int]") -> None:
            def _on_connect() -> None:
                pass


# Generated at 2022-06-22 04:35:31.139130
# Unit test for method split of class _Connector
def test__Connector_split():
    res = [
        (socket.AF_INET, ('1.1.1.1', 443)),
        (socket.AF_INET6, ('2.2.2.2', 443)),
        (socket.AF_INET, ('3.3.3.3', 443)),
        (socket.AF_INET6, ('4.4.4.4', 443))
    ]
    primary, secondary = _Connector.split(res)
    if res[0][0] == socket.AF_INET:
        assert(primary == [(socket.AF_INET, ('1.1.1.1', 443)), (socket.AF_INET, ('3.3.3.3', 443))])

# Generated at 2022-06-22 04:35:42.974663
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import _IOStreamSocketAdapter
    from ioloop import test_utils

    class _ConnectorTestCase(AsyncTestCase):
        @gen_test
        def test_on_connect_timeout(self):
            f = Future()

            def connect_mock(af: Any, addr: Any) -> Tuple[Any, Any]:
                return _IOStreamSocketAdapter(), f

            connector = _Connector(
                [(socket.AF_INET, ("example.com", 80))], connect_mock
            )
            future = connector.start(connect_timeout=0.1)
            test_utils.run_sync(future)

            with self.assertRaises(TimeoutError):
                raise future.exception()

    _ConnectorTestCase().test_on

# Generated at 2022-06-22 04:35:51.093741
# Unit test for constructor of class _Connector
def test__Connector():
    import socket

    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        pass

    addr = [
        (socket.AF_INET6, ()),
        (socket.AF_INET, ()),
        (socket.AF_INET, ()),
    ]

    _Connector(addr, connect)


TCPClient = Union[socket.socket, IOStream]

