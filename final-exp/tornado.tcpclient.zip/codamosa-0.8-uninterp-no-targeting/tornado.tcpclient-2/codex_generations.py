

# Generated at 2022-06-22 04:30:15.846278
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    # some code here
    pass

# Generated at 2022-06-22 04:30:27.999630
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    class FakeStream:
        pass
    stream1 = FakeStream()
    stream2 = FakeStream()
    stream3 = FakeStream()
    test_streams = [stream1, stream2, stream3]
    test_connector = _Connector([], lambda *args: None)
    test_connector.streams = set(test_streams)
    stream1.close = lambda: print("stream1 closed")
    stream2.close = lambda: print("stream2 closed")
    stream3.close = lambda: print("stream3 closed")
    test_connector.close_streams()
    assert len(test_connector.streams) == 0
    assert test_streams[0] is stream1
    assert test_streams[1] is stream2
    assert test_streams[2] is stream3


# Generated at 2022-06-22 04:30:28.599503
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    pass



# Generated at 2022-06-22 04:30:39.835912
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    from tornado import testing
    import socket
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = IOLoop.current()
    loop.make_current()
    iostream: IOStream = IOStream(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
    iostream.set_close_callback(lambda: None)
    iostream_future = Future()
    iostream_future.set_result(iostream)

    def connect(af: int, addr: Tuple[str, int]) -> Tuple[IOStream, Future[IOStream]]:
        if af == socket.AF_INET:
            socket.AF_INET
            return iostream, iostream_future
        else:
            assert True

# Generated at 2022-06-22 04:30:42.535277
# Unit test for method start of class _Connector
def test__Connector_start():
    future = Future()
    def callback(stream, future):
        pass

    _Connector([], callback).start()



# Generated at 2022-06-22 04:30:51.995490
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    print("Testing _Connector.on_timeout(...)")
    # Test Setup
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 0))]
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        raise Exception("Shouldn't use connect()")
    c = _Connector(addrinfo, connect)
    assert(c.timeout is None)
    # Test
    c.on_timeout()
    assert(c.timeout is None)
    print("Done")


# Generated at 2022-06-22 04:31:03.432072
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import pytest
    from unittest import mock

        # test with a addrinfo
    addrs = iter([
            (socket.AF_INET, ('youtube.com', 80)),
            (socket.AF_INET, ('facebook.com', 80)),
            (socket.AF_INET, ('google.com', 80)),
        ])
        # test with a function connect
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM),
                          io_loop=IOLoop.current())
        future = stream.connect(addr)
        return (stream, future)

# Generated at 2022-06-22 04:31:15.698513
# Unit test for method split of class _Connector
def test__Connector_split():
    from tornado.platform.asyncio import to_asyncio_future, to_tornado_future

    import asyncio
    import functools

    my_addrinfo = [
        (socket.AF_INET, ("10.0.1.1", 80)),
        (socket.AF_INET, ("10.0.1.2", 80)),
        (socket.AF_INET6, ("10.10.1.1", 80)),
    ]

    def test_connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, Any]:
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
        # Wrap the tornado Future in an asyncio Future so we don't get a
        # warning from the tornado Future implementation.
        return stream, to_asyncio_future

# Generated at 2022-06-22 04:31:16.756533
# Unit test for method start of class _Connector
def test__Connector_start():
    _Connector.start()


# Generated at 2022-06-22 04:31:26.570333
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import tornado
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.concurrent import Future, future_add_done_callback
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.gen import TimeoutError
    from tornado.tcpclient import _Connector
    from tornado.gen import Return, coroutine
    import socket
    import time
    import tornado

    @gen.coroutine
    def faked_connection(addrinfo: List[Tuple]) -> "Future[IOStream]":
        future = Future()
        raise gen.Task(
            tornado.platform.asyncio.to_asyncio_future(future)
        )

    if tornado.version_info[0] >= 5:
        faked_connect = faked_connection

# Generated at 2022-06-22 04:31:52.270872
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Test of method set_timeout of class _Connector
    # def set_timeout(self, timeout):
    #     self.timeout = self.io_loop.add_timeout(self.io_loop.time() + timeout, self.on_timeout)
    # 
    # def on_timeout(self):
    #     self.timeout = None
    #     if not self.future.done():
    #         self.try_connect(iter(self.secondary_addrs))
    io_loop = IOLoop.current()
    io_loop.time = lambda: 0
    future = Future()
    future.done = lambda: False
    _Connector.__init__ = lambda self, addrinfo: None
    _Connector.on_timeout = lambda self: None
    _Connector.close_streams = lambda self: None

# Generated at 2022-06-22 04:31:54.532608
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    connector._Connector.on_connect_timeout(connector._Connector)
    assert connector._Connector.on_connect_timeout(connector._Connector) == None


# Generated at 2022-06-22 04:32:03.074740
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # test calls:
    # d.close_streams()
    # on_connect_timeout()
    # on_timeout()
    # close()
    addrinfo1 = ((1, ('127.0.0.1', 80)), (2, ('127.0.0.2', 80)))
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()
    d = _Connector(addrinfo1, connect)
    d.start()
    d.close_streams()
    assert d.streams.pop().socket.__class__ == socket.socket

# Generated at 2022-06-22 04:32:05.650562
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    connector = _Connector([],lambda _: 0)
    connector.clear_timeouts()

# Generated at 2022-06-22 04:32:07.008188
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    _Connector(None, None).close_streams()



# Generated at 2022-06-22 04:32:14.680147
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # Unit test for method try_connect of class _Connector
    # Try to add this to unit test.py
    def connect(af, addr):
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()

    primary = [(socket.AF_INET, (1, 2, 3, 4)), (socket.AF_INET, (4, 3, 2, 1))]
    secondary = [(socket.AF_INET, (1, 2, 3, 5)), (socket.AF_INET, (4, 3, 2, 2))]
    primary.reverse()
    secondary.reverse()

    # get a future object
    connector = _Connector(primary + secondary, connect)
    future = connector.future
    # assert the attributes of connector
    assert connector.last_error is None

# Generated at 2022-06-22 04:32:26.025621
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Create a mock tornado.ioloop.IOLoop
    ioloop = MagicMock()
    ioloop.time.return_value = 100
    IOLoop.current = MagicMock(return_value=ioloop)

    # Create a mock tornado.concurrent.Future
    future = MagicMock()
    future.done.return_value = False
    future.set_exception = MagicMock()

    # Create an instance of _Connector
    # Use a mock getaddrinfo
    def getaddrinfo(host: str, port: int, family: int, socktype: int, proto: int, flags: int) -> List[Tuple[socket.AddressFamily, Tuple]]:
        return [(socket.AF_INET, ('0.0.0.0', 1234, 0, 0))]

# Generated at 2022-06-22 04:32:37.512029
# Unit test for method start of class _Connector
def test__Connector_start():

    # result_list = [(10, ('192.168.11.165', 9001)), (10, ('fe80::dc22:9fe1:3e3d:dfae', 9001))]
    # result_list = [(10, ('127.0.0.1', 9001))]
    result_list = [(10, ('192.168.11.165', 9001)), (10, ('fe80::dc22:9fe1:3e3d:dfae', 9001))]
    random.shuffle(result_list)
    af, addr = result_list[0]
    def connect(af, addr):
        print(af, addr)

    future = Future()
    _Connector(result_list, connect).start()
    IOLoop.current().start()
# test__Connector_start()
# class _Connector

# Generated at 2022-06-22 04:32:46.084639
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # Set up
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 80))]
    connect = lambda af, addr: (
        IOStream(socket.socket(af, socket.SOCK_STREAM)),
        Future(),
    )
    connector = _Connector(addrinfo, connect)
    connector.try_connect(iter(addrinfo))
    # Test
    connector.close_streams()
    # Finalize
    connector = None



# Generated at 2022-06-22 04:32:53.138537
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    @gen.coroutine
    def test_TCPClient_connect_coroutine():
        # Assign
        t_client = TCPClient()
        # Act
        result1 = yield t_client.connect("google.com", 80)
        result2 = yield t_client.connect("google.com", 80, timeout=1)
        # Assert
        assert isinstance(result1, IOStream)
        assert isinstance(result2, IOStream)
    IOLoop.current().run_sync(test_TCPClient_connect_coroutine)

# Generated at 2022-06-22 04:33:23.287259
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    _Connector.clear_timeouts()



# Generated at 2022-06-22 04:33:28.904284
# Unit test for constructor of class _Connector
def test__Connector():
    X = _Connector(None, None)
    assert isinstance(X.io_loop, IOLoop)
    assert X.future.done()
    assert X.timeout == None
    assert X.connect_timeout == None
    assert X.last_error == None
    assert X.connect == None
    assert X.remaining == 0
    assert len(X.primary_addrs) == 0
    assert len(X.secondary_addrs) == 0
    assert len(X.streams) == 0



# Generated at 2022-06-22 04:33:36.000339
# Unit test for method start of class _Connector
def test__Connector_start():
    from tornado.platform.asyncio import to_asyncio_future, AsyncIOMainLoop
    from tornado.netutil import ssl_wrap_socket
    import functools
    import socket

    class _Stream(_Stream):
        def __init__(self, socket, *args, **kwargs):
            self.socket = socket
            super().__init__(*args, **kwargs)
        def connect(self, address, callback=None):
            try:
                self.socket.connect(address)
            except:
                raise
            return callback()
        def write(self, data, callback=None):
            return to_asyncio_future(self.socket.sendall(data))

# Generated at 2022-06-22 04:33:40.349733
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    connector = _Connector(None, None)
    assert connector.connect_timeout is None
    connector.set_connect_timeout(0.3)
    assert connector.connect_timeout is not None
    assert connector.connect_timeout.deadline() <= 0.3
    connector.set_connect_timeout(0.7)
    assert connector.connect_timeout is not None
    assert connector.connect_timeout.deadline() <= 0.7
    connector.set_connect_timeout(datetime.timedelta(seconds=0.1))
    assert connector.connect_timeout is not None
    assert connector.connect_timeout.deadline() <= 0.1
    connector.set_connect_timeout(datetime.timedelta(seconds=0.3))
    assert connector.connect_timeout is not None

# Generated at 2022-06-22 04:33:48.362892
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import time
    result=None
    addrinfo=[(socket.AF_INET, ("127.0.0.1",80)),(socket.AF_INET, ("192.168.1.1",80))]
    connector=_Connector(addrinfo,None)
    start = time.time()
    connector.on_timeout()
    end = time.time()
    elapsed = end - start
    assert elapsed < _INITIAL_CONNECT_TIMEOUT + 0.2

# Generated at 2022-06-22 04:34:00.043976
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import asyncio, time, sys

    TIMEOUT = 10

    def gen_TCPClient(**kwargs):
        # Create an instance of class TCPClient
        return TCPClient(**kwargs)

    def gen_ssl_options():
        # Create an instance of class SSLContext
        return ssl.create_default_context(ssl.Purpose.SERVER_AUTH)

    def gen_future(loop, corout):
        # Create an instance of class Future
        return loop.create_task(corout)

    def gen_future_return_addr(loop, corout):
        # Create an instance of class Future
        return loop.create_task(corout)

    def gen_loop():
        # Create an instance of class asyncio.get_event_loop
        return asyncio.get_event_loop()


# Generated at 2022-06-22 04:34:01.594104
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # _Connector().close_streams()
    # return
    pass



# Generated at 2022-06-22 04:34:13.562713
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import tornado.ioloop
    import tornado.testing
    import time

    def test_condtion():
        if time.time() > start_time + 10:
            return True
        return False

    ioloop = tornado.ioloop.IOLoop.current()
    start_time = time.time()
    print("start_time:", start_time)
    connector = _Connector([(0, 0)], lambda x, y: (None, None))
    connector.set_timeout(10)
    connector.on_timeout()
    ioloop.add_callback(lambda: "" if test_condtion() else ioloop.stop())
    ioloop.start()
    end_time = time.time()
    print("end_time:", end_time)
    return True



# Generated at 2022-06-22 04:34:14.789949
# Unit test for method start of class _Connector
def test__Connector_start():
    # _INITIAL_CONNECT_TIMEOUT = 0.3
    _connector = _Connector([(socket.AF_INET,(1,2))],connect)
    _connector.start()



# Generated at 2022-06-22 04:34:23.451510
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    host = 'www.google.com'
    port = 80
    s = socket.socket()
    # creating address
    addr = s.getsockname()
    # initializing stream
    stream = IOStream(s)
    # initializing future
    future = Future()
    # initializing io loop current
    ioloop = IOLoop.current()
    # initializing connector
    connector = _Connector(
        addrinfo=[(AF_INET, addr)],
        connect=lambda af, addr: (stream, future),
    )
    # clearing timeout
    connector.clear_timeout()



# Generated at 2022-06-22 04:35:28.221346
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    from tornado.test.util import unittest
    from tornado.platform.asyncio import to_asyncio_future, to_tornado_future
    import asyncio
    import async_generator
    import tornado.testing
    import pytest
    import time
    import socket
    import tornado.gen
    import threading


# Generated at 2022-06-22 04:35:40.021466
# Unit test for constructor of class _Connector
def test__Connector():
    class FakeIOStream(IOStream):
        def __init__(self):
            self.addr = None  # type: Any
            self.af = None  # type: Any

        async def connect(self, af, addr):
            self.af = af
            self.addr = addr

    def fake_connect(af, addr):
        future = gen.Future()  # type: Future[IOStream]
        stream = FakeIOStream()
        future.set_result(stream)
        return stream, future

    addrinfo = [(socket.AF_INET6, ("2001::1", 443)), (socket.AF_INET, ("1.2.3.4", 443))]

    connector = _Connector(addrinfo, fake_connect)

    future = connector.start()

    stream = future.result()[2]


# Generated at 2022-06-22 04:35:53.066690
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import unittest
    import mock
    import pytest
    logentries = []
    def mock_log(msg, *args):
        logentries.append(msg%args)
    mock.patch('tornado.tcpserver.LoggerMixin.log').start()
    mock.patch('tornado.tcpserver.LoggerMixin.log', side_effect=mock_log).start()
    class Test_Connector_set_connect_timeout(unittest.TestCase):
        def test_set_connect_timeout_1(self):
            # mock 'IOLoop.add_timeout'
            from tornado import gen
            from tornado.concurrent import Future
            from tornado.ioloop import IOLoop

# Generated at 2022-06-22 04:36:04.108535
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # data type definition
    class _Connector:
        timeout = None
        future = Future()
        secondary_addrs = [(socket.AF_INET, ("127.0.0.1", 8888))]

        def try_connect(self, addrs: Iterator[Tuple[socket.AddressFamily, Tuple]]) -> None:
            return

    # test case 1
    connector = _Connector()
    connector.on_timeout()
    assert connector.secondary_addrs == []
    connector.future = Future()
    connector.secondary_addrs = [(socket.AF_INET, ("127.0.0.1", 8888))]
    connector.timeout = None
    connector.on_timeout()
    assert connector.secondary_addrs == []


# Generated at 2022-06-22 04:36:05.890852
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    _self = TCPClient()
    _host = 'ipcidr.com'
    _port = 80

    result = _self.connect(_host, _port, ssl_options={}, max_buffer_size=None, source_ip=None, source_port=None, timeout=None)

    print(result.done())

# Generated at 2022-06-22 04:36:11.294816
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    connector = _Connector(
        [], lambda x, y: ([], [])
    )
    connector.timeout = None
    connector.clear_timeout()
    assert connector.timeout is None
    connector.timeout = [
        1, 2, 3
    ]  # type: Optional[List[int]]  # Noqa: F821
    connector.clear_timeout()
    assert connector.timeout is None



# Generated at 2022-06-22 04:36:13.244457
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    # Unit test for method close of class TCPClient
    resolver = None
    instance = TCPClient(resolver)
    assert isinstance(instance, TCPClient)
    instance.close()



# Generated at 2022-06-22 04:36:25.644941
# Unit test for constructor of class _Connector
def test__Connector():
    loop = IOLoop.current()
    addrs = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET, ("127.0.0.2", 80)),
        (socket.AF_INET, ("127.0.0.3", 80)),
        (socket.AF_INET6, ("127.0.0.4", 80)),
    ]
    resolver = Resolver(io_loop=loop)

    def handle_future(future):
        future.result()
        loop.stop()

    def handle_addrinfo_future(future):
        future.result()
        loop.stop()


# Generated at 2022-06-22 04:36:33.781057
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import time
    import tornado
    args1 = [0.3]
    def_args1 = {"timeout": 0.3}
    set_timeout1 = _Connector(None, None)
    current_time1 = time.time()
    set_timeout1.io_loop = tornado.ioloop.IOLoop()
    set_timeout1.set_timeout(*args1, **def_args1)
    future_time1 = set_timeout1.timeout.deadline
    assert future_time1 - current_time1 > 0.29
    assert future_time1 - current_time1 < 0.31


# Generated at 2022-06-22 04:36:34.790127
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    obj1 = TCPClient()
    obj1.connect("host", 0)

# Generated at 2022-06-22 04:38:33.099052
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    c = _Connector([], lambda a, b: (None, None))
    c.timeout = []
    c.connect_timeout = []
    c.clear_timeouts()
    assert c.timeout is None
    assert c.connect_timeout is None



# Generated at 2022-06-22 04:38:40.496605
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    def try_connect_impl(af, addr):
        return IOStream([socket.socket(af, socket.SOCK_STREAM, 0),]), Future()

    HOST = "localhost"
    PORT = 80

    def test_impl():
        addrinfo = Resolver(io_loop=IOLoop.current()).resolve(
            HOST, PORT).result()
        obj = _Connector(addrinfo, try_connect_impl)
        obj.start()
        return obj

    obj = test_impl()

    assert obj.remaining == 2, obj.remaining
    assert obj.last_error is None, obj.last_error
    assert obj.streams == set(), obj.streams
    assert obj.connect_timeout is None, obj.connect_timeout
    assert obj.timeout is not None, obj.timeout
   

# Generated at 2022-06-22 04:38:51.253807
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import unittest
    import random
    import functools
    import socket
    import ipaddress
    import ssl
    from unittest.mock import patch
    import tornado.testing
    import tornado.concurrent
    import tornado.iostream
    import tornado.platform.asyncio
    import tornado.netutil
    import logging

    class TestException(Exception):
        pass

    class _MockFuture(tornado.concurrent.Future):
        def __init__(self, result=None):
            super(_MockFuture, self).__init__()
            if result is None:
                self.result = random.randint(1, 100)
            else:
                self.result = result

        def result(self):
            return self.result


# Generated at 2022-06-22 04:38:52.280692
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    _Connector.clear_timeout(object)
    pass


# Generated at 2022-06-22 04:39:03.733219
# Unit test for method split of class _Connector
def test__Connector_split():
    tuple_of_integers = Union[Tuple[int, int], Tuple[int, str]]
    list_of_tuple_of_integers_and_str = List[Tuple[int, Union[int, str]]]

    @gen.coroutine
    def getaddrinfo(
        hostname: Optional[str] = None,
        port: Optional[int] = None,
        family: Optional[int] = None,
        flags: Optional[int] = None,
    ) -> List[Tuple[int, int, int, str, tuple_of_integers]]:
        return []


# Generated at 2022-06-22 04:39:04.584348
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    pass


# Generated at 2022-06-22 04:39:08.859074
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    import tornado.platform.asyncio
    import asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()

    loop = asyncio.get_event_loop()
    cns = _Connector([(2, ("127.0.0.1", 5432))], connect=lambda af, addr: (None, None))
    cns.set_connect_timeout(0.1)
    loop.run_until_complete(cns.future)
    assert isinstance(cns.future.exception(), TimeoutError)


_RESOLVER = Resolver()



# Generated at 2022-06-22 04:39:15.597227
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    addrs = [('AF_INET', ('127.0.0.1', 80))]
    def connect(af, addr):
        return IOStream(), Future()
    connector = _Connector(addrs, connect)
    connector.try_connect(iter(addrs))
    # Test if the result is right
    assert isinstance(addrs[0][1], tuple)
    assert isinstance(addrs[0][0], type(socket.AF_INET))

# Generated at 2022-06-22 04:39:28.626381
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    class Test:
        def __init__(self):
            self.af = socket.AF_UNSPEC
            self.host = "localhost"
            self.port = 80
            self.addr_info = [(socket.AddressFamily.AF_INET, ("127.0.0.1", 8000))]
            self.ssl_options = None
            self.max_buffer_size = None
            self.source_ip = None
            self.source_port = None
            self.timeout = None
            self.tcp_client = TCPClient()
    test = Test()


    class Mock_gen:
        def __init__(self):
            self.input_tuple = (test.af, test.host, test.port)
            self.output_addrinfo = test.addr_info

# Generated at 2022-06-22 04:39:29.167106
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    _Connector()