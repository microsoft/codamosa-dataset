

# Generated at 2022-06-22 04:30:12.428510
# Unit test for constructor of class TCPClient
def test_TCPClient():
    tcpClient = TCPClient()
    assert tcpClient is not None

# Generated at 2022-06-22 04:30:20.731673
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    my_io_loop = Mock_IOLoop.current()
    my_io_loop.time.return_value = 0
    my_addrs = [(socket.AF_INET, ("1.1.1.1", 8888))]
    my_conn = _Connector(my_addrs, Mock_connect)
    my_conn.set_timeout(10)
    assert my_conn.timeout is not None
    assert my_conn.io_loop.add_timeout.called
    my_conn.io_loop.add_timeout.assert_called_with(10, my_conn.on_timeout)


# Generated at 2022-06-22 04:30:32.390230
# Unit test for method split of class _Connector
def test__Connector_split():
    from tornado.platform.asyncio import to_asyncio_future

    class TestConnect:
        def __init__(self):
            self.fut = None  # type: Optional[Future[Tuple[int, Any]]]

        def __call__(
            self,
            address_family: socket.AddressFamily,
            address: Tuple,
        ) -> Tuple[IOStream, "Future[IOStream]"]:
            assert self.fut is None
            self.fut = Future()  # type: Future[Tuple[int, Any]]
            return IOStream(socket.socket(address_family, socket.SOCK_STREAM)), self.fut


# Generated at 2022-06-22 04:30:35.860631
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    test_Connector = _Connector(
        1, 1
    )
    # Test normal cases
    # TODO: Test cases with exceptional inputs
    test_Connector.set_timeout(0.3)


# Generated at 2022-06-22 04:30:42.317324
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    import unittest

    class Dummy_io_loop(unittest.TestCase):
        def remove_timeout(self, timeout):
            pass
    Dummy_io_loop.current = Dummy_io_loop()

    from tornado.concurrent import Future
    class Dummy_Future(unittest.TestCase):
        def set_result(self, arg):
            pass

    import mock
    import threading
    @mock.patch('tornado.ioloop.IOLoop', Dummy_io_loop)    
    @mock.patch('tornado.concurrent.Future', Dummy_Future)
    def test():
        connector = _Connector([], lambda af, addr: ([], []))
        connector.future = mock.Mock()
        connector.io_loop = mock.Mock()

        connector.timeout

# Generated at 2022-06-22 04:30:43.960668
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    _Connector.on_connect_done(None, None, None, None)



# Generated at 2022-06-22 04:30:56.186084
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    # Test case 1
    connector = _Connector([(socket.AF_INET, ("localhost", 8000))], None)
    stream, future = connector.connect(socket.AF_INET, ("localhost", 8000))
    future.set_exception(Exception())
    connector.on_connect_done(iter([(socket.AF_INET, ("localhost", 8000))]), socket.AF_INET, ("localhost", 8000), future)
    print('Passed 1')


    # Test case 2
    connector = _Connector([(socket.AF_INET, ("localhost", 8000))], None)
    stream, future = connector.connect(socket.AF_INET, ("localhost", 8000))
    future.set_result(stream)

# Generated at 2022-06-22 04:31:04.442578
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    # OBJECTIVE
    # To test that method set_connect_timeout is working as expected.
    # METHOD
    # using a unittest module
    # EXPECTED RESULT
    # The function should raise a TimeoutError exception
    timeout = object()
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 8080))]
    connect = object()
    a = _Connector(addrinfo, connect)
    a.set_connect_timeout(timeout)


# Generated at 2022-06-22 04:31:16.804130
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    from tornado.testing import AsyncTestCase

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super(_ConnectorTest, self).setUp()
            self.connector = _Connector(
                [(socket.AF_INET, ("127.0.0.1", 6897))],
                functools.partial(
                    IOStream.connect,
                    io_loop=self.io_loop,
                    max_buffer_size=None,
                    read_chunk_size=None,
                ),
            )

        def test_set_timeout(self):
            import time
            start = time.time()
            self.connector.start()
            self.wait(timeout=1)

# Generated at 2022-06-22 04:31:22.472311
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import time

    from tornado import gen

    import pytest

    from tornado.httpserver import HTTPServer
    from tornado.netutil import bind_sockets

    from tornado.ioloop import IOLoop

    @gen.coroutine
    def handle_request(request):
        # type: (HTTPServerRequest) -> None
        pass

    def main():
        # type: () -> None
        sock, port = bind_sockets(None, '127.0.0.1', family=socket.AF_INET)
        server = HTTPServer(handle_request)
        server.add_sockets([sock])

        @gen.coroutine
        def f():
            # type: () -> None
            client = TCPClient()

# Generated at 2022-06-22 04:31:48.889037
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    from tornado.testing import gen_test, AsyncTestCase, main
    import re

    class Test__Connector_clear_timeout(AsyncTestCase):
        @gen_test
        def test_clear_timeout(self):
            stream = IOStream(socket.socket())

            def on_timeout():
                pass

            stream.set_close_callback(on_timeout)
            self.assertFalse(stream.closed())
            self.assertEqual(
                re.compile(r'<AddrStream \[closed\]>').search(str(stream)),
                None
            )
            stream._handle_close()
            self.assertTrue(stream.closed())
            self.assertNotEqual(
                re.compile(r'<AddrStream \[closed\]>').search(str(stream)),
                None
            )


# Generated at 2022-06-22 04:31:53.004476
# Unit test for constructor of class TCPClient
def test_TCPClient():
    resolver = Resolver()
    client = TCPClient(resolver)
    client.close()

if __name__ == "__main__":
    test_TCPClient()

# Generated at 2022-06-22 04:31:53.850036
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    _Connector.on_timeout(object)

# Generated at 2022-06-22 04:31:56.908874
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    r = Resolver()
    c = TCPClient(r)
    c.close()


# Generated at 2022-06-22 04:32:03.452169
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    connector = _Connector([(1, 2)], connect=lambda a, b, c: None)

    class fake_ioloop:
        def __init__(self):
            self.calls = 0
            self.timeouts = []

        def remove_timeout(self, timeout):
            self.calls += 1
            self.timeouts.append(timeout)

    ioloop = fake_ioloop()
    connector.io_loop = ioloop
    connector.timeout = 1
    connector.connect_timeout = 2
    connector.clear_timeouts()

    assert ioloop.calls == 2
    assert ioloop.timeouts == [1, 2]



# Generated at 2022-06-22 04:32:10.984963
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [
        (socket.AF_INET, (1, 2)),
        (socket.AF_INET, (1, 2)),
        (socket.AF_INET, (1, 2)),
        (socket.AF_INET6, (1, 2)),
    ]
    expected_primary = [(socket.AF_INET, (1, 2))]
    expected_secondary = [(socket.AF_INET6, (1, 2))]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == expected_primary
    assert secondary == expected_secondary



# Generated at 2022-06-22 04:32:16.747743
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import socket
    import time
    import tornado.ioloop
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    import ssl
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpserver import HTTPServer
    from tornado.netutil import bind_sockets

    import certifi

    NETLOC = 'localhost'
    PORT = 8888
    MAX_BUFFER_SIZE = 10
    SSL = True
    CERTS_DIR = 'certs'
    KEYFILE = 'privkey1.pem' #'key.pem'
    CERTFILE = 'fullchain1.pem' #'cert.pem'
    CA_CERTS = certifi.where()

    # Create socket
    sockets = bind_sockets(PORT)

# Generated at 2022-06-22 04:32:20.238861
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    conn = _Connector(((socket.AF_INET, ("google.com", 80)), ), None)
    conn.io_loop = IOLoop()
    conn.future = Future()
    conn.future.done = lambda : True
    conn.on_connect_timeout()


# Generated at 2022-06-22 04:32:22.695671
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    tcp_client = TCPClient()
    tcp_client.close()


# Generated at 2022-06-22 04:32:30.035220
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    class Test:
        def get_result(self, value) -> Any:
            return value

        def result(self) -> Any:
            return self.get_result()

    def test_failure(get_result_result: Any) -> None:
        class FakeIOLoop:
            def remove_timeout(self, timeout) -> Any:
                return timeout

            def add_timeout(self, time, callback) -> Any:
                return callback

            def time(self) -> Any:
                return None

        class FakeFuture:
            def done(self) -> Any:
                return None

            def result(self) -> Any:
                return None

            def set_exception(self, exception) -> Any:
                return exception

        from functools import partial
        from typing import Iterator, Tuple
        from unittest import mock

# Generated at 2022-06-22 04:33:01.871461
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    def mock_remove_timeout(timeout):
        return None
    ioloop = mock_remove_timeout
    _connector = _Connector(ioloop, mock_remove_timeout, mock_remove_timeout)
    _connector.clear_timeouts()


# Generated at 2022-06-22 04:33:14.306298
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    import json
    import os
    import requests
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado import ioloop, web
    from tornado.httpserver import HTTPServer
    from tornado.tcpclient import TCPClient

    class MyHandler(web.RequestHandler):
        def get(self):
            self.write({"status": "ok"})

    class MyTestHandler(web.RequestHandler):
        def get(self):
            client = TCPClient()
            fu = client.close()
            self.write(fu)

    AsyncIOMainLoop().install()

# Generated at 2022-06-22 04:33:18.056942
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    import unittest
    from unittest.mock import MagicMock
    from unittest import mock
    from unittest.mock import patch
    import sys
    import os
    import traceback

    global current_id
    # global original_stdout
    # global original_stderr
    # global captured_stdout
    # global captured_stderr
    # global filename
    current_id = 0
    # original_stdout = sys.stdout
    # original_stderr = sys.stderr
    # captured_stdout = io.StringIO()
    # captured_stderr = io.StringIO()
    # filename = "out"+str(current_id)+".log"

    # def mock_time_currtime():
    #     return 1.0

    # def mock_

# Generated at 2022-06-22 04:33:28.023047
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    timeout = 0.3
    def on_timeout():
        pass

    class Object:
        def __init__(self, time):
            self.time: float = time
        def add_timeout(self, timeout, callback):
            if timeout == 0.3 or timeout == 0.6:
                if self.time > timeout:
                    print("Correct")
                    return "Correct"
            return "Error"

    # Case 1: If time of object < timeout, the test will pass
    obj = Object(0.2)
    c = _Connector([], None)
    length_pre = len(obj.__dict__)
    c.io_loop = obj
    c.set_timeout(timeout)
    if len(obj.__dict__) - length_pre == 1:
        print("Correct")

# Generated at 2022-06-22 04:33:35.418559
# Unit test for method start of class _Connector
def test__Connector_start():
    # The following is a unit test for method start of class _Connector
    # Please note that the following test is not complete.
    # You are supposed to add your own tests
    # Feel free to define additional functions for better testing
    # of your code

    # A sample implementation of method start of class _Connector
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        io_stream = io_streams[0]
        future = futures[0]
        return io_stream, future
        
    import io
    import os
    import unittest
    
    # The following is a test for method start of class _Connector

# Generated at 2022-06-22 04:33:42.016306
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    "Testing _Connector.set_timeout"
    import pytest # type: ignore
    from tornado.testing import AsyncTestCase, LogTrapTestCase
    import asyncio # type: ignore
    import time
    import socket
    import random

    def execute_connector(server_port: int, timeout: float) -> Future[List[str]]:
        connector: _Connector = _Connector(
            addrinfo=[
                (socket.AF_INET, (socket.gethostname(), server_port)),
                (socket.AF_INET, ("127.0.0.1", server_port)),
            ],
            connect=connect,
        )
        stream_future: Future[Tuple[socket.AddressFamily, Any, IOStream]] = connector.start(timeout=timeout, connect_timeout=None)

# Generated at 2022-06-22 04:33:44.597665
# Unit test for constructor of class TCPClient
def test_TCPClient():
    test_tcp_client=TCPClient()
    assert test_tcp_client is not None
    test_tcp_client.close()

# Generated at 2022-06-22 04:33:45.977010
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    assert True



# Generated at 2022-06-22 04:33:57.480507
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        @gen_test
        async def test_close_streams(self):
            from tornado.tcpclient import TCPClient
            stream = TCPClient().connect("localhost", 1234)
            for name in ("close", "write_to_fd", "read_from_fd"):
                setattr(stream, name, lambda *args, **kwargs: None)
            connector = _Connector([], lambda *_: (stream, to_asyncio_future(None)))

            await connector.close_streams()

    test_close_streams = TestCase("test_close_streams")
    test_close_streams.test_close_streams()


# Generated at 2022-06-22 04:34:04.440685
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # test input of type float is valid 
    _connector = _Connector(
        [
            (
                socket.AF_INET,
                ("45.76.61.12", 443),
            )
        ],
        functools.partial(IOStream.connect, io_loop=IOLoop.current()),
    )
    _connector.set_timeout(timeout=0.0)
    assert True


# Generated at 2022-06-22 04:35:06.892457
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    from unittest.mock import MagicMock
    from unittest.mock import patch
    import io
    import ssl
    io_loop = IOLoop.current()

    io_loop.add_timeout = MagicMock()
    io_loop.time = MagicMock(return_value=1)
    io_loop.remove_timeout = MagicMock()
    future = Future()  # type: Future[Tuple[socket.AddressFamily, Any, IOStream]]
    future.done = MagicMock(return_value=True)

    def connect(af: int, addr: Tuple[str, int]) -> Tuple[IOStream, Future]:
        stream = IOStream(socket.socket())
        stream.connect(addr, af)
        return stream, stream.connect_future


# Generated at 2022-06-22 04:35:15.048440
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    from tornado.httpclient import AsyncHTTPClient
    from .httpclient_test import NullHandler, start_http_server, stop_http_server

    io_loop = IOLoop.current()
    server = start_http_server(io_loop)
    io_loop.run_sync(server.wait_until_port_is_open)
    try:
        http_client = AsyncHTTPClient()
        response = http_client.fetch(
        "http://localhost:%d/" % server.http_port,
        request_timeout=5)
        assert response.code == 200
    finally:
        stop_http_server(server)

test_TCPClient_connect()

# Generated at 2022-06-22 04:35:17.894761
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    assert True==True


# Generated at 2022-06-22 04:35:27.303732
# Unit test for method start of class _Connector
def test__Connector_start():
    # Arrange
    addrinfo = [(AF_INET, ('0.0.0.0', 80)), (AF_INET, ('0.0.0.1', 80)), (AF_INET, ('0.0.0.2', 80))]
    connect = _connect
    connector = _Connector(addrinfo, connect)
    timeout = _INITIAL_CONNECT_TIMEOUT
    connect_timeout = None
    
    # Act
    future = connector.start(timeout, connect_timeout)
    
    # Assert
    assert isinstance(future, Future)
    assert future.done()
    af, addr, stream = future.result()
    assert af == AF_INET
    assert addr == ('0.0.0.2', 80)



# Generated at 2022-06-22 04:35:38.922791
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    def test_inner(af, addr):
        future = Future()
        #future.set_result(True)
        return (None, future)
    a = _Connector([(socket.AF_INET, 1), (socket.AF_INET, 2), (socket.AF_INET, 3)], test_inner)
    addrs = iter([(socket.AF_INET, 1), (socket.AF_INET, 2), (socket.AF_INET, 3)])
    a.try_connect(addrs)

# Generated at 2022-06-22 04:35:52.061132
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import sys, os
    import tornado
    import tornado.tcpclient

    port = os.getenv('PORT0')
    if not port:
        raise Exception('PORT0 not found')

    class TestTCPClientFactory(tornado.tcpclient.TCPClient):
        connector = tornado.tcpclient._Connector({}, {})

    def on_timeout():
        global test1
        test1 = True
        raise tornado.tcpclient.TimeoutError()

    global test1
    test1 = False
    TestTCPClientFactory.connector.on_timeout = on_timeout

# Generated at 2022-06-22 04:36:02.661200
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    """Unit tests for method try_connect of class _Connector."""

    import pytest

    def test_exception():
        """Test for exception."""

        def connect(af, addr):
            """Dummy connect method."""
            return IOStream(), Future()

        addrinfo = [
            (socket.AF_INET, ("192.168.0.1", 80)),
            (socket.AF_INET6, ("2001:db8::1", 80)),
            (socket.AF_INET6, ("2001:db8::2", 80)),
        ]

        def io_loop():
            return IOLoop.current()

        with patch("tornado.ioloop.IOLoop.current", io_loop):
            cn = _Connector(addrinfo, connect)
            cn.last_error = None

# Generated at 2022-06-22 04:36:08.142515
# Unit test for method start of class _Connector
def test__Connector_start():
    """Unit test for method start of class _Connector"""
    # [1]
    # Test for case where _Connector.start returns None
    _Connector(None, None).start()
    
test__Connector_start()



# Generated at 2022-06-22 04:36:17.872631
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # Get a sample password manager
    password_manager = tornado.httpclient.HTTPPasswordMgrWithDefaultRealm()
    # Create a sample password manager
    password_manager.add_password(
        realm='passwd',
        uri='http://httpbin.org/basic-auth/test/test',
        user='test',
        passwd='test'
    )
    # Initialize a HTTPBasicAuthHandler with the password manager
    auth_handler = tornado.httpclient.HTTPBasicAuthHandler(password_manager)
    # Create a tornado HTTPClient instance with the auth handler
    client_with_auth = tornado.httpclient.HTTPClient(auth_handler)
    # Create a tornado HTTPClient instance without the auth handler
    client_without_auth = tornado.httpclient.HTTPClient()
    # http://localhost:8888
    # Set a sample

# Generated at 2022-06-22 04:36:31.205793
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    ioloop = IOLoop.current()
    resolver = Resolver()
    connect_future = Future()
    called = False
    class IOStream(object):
        def __init__(self):
            self.ioloop = ioloop

        def close(self):
            self.ioloop.stop()
    def connect(af, addr):
        stream = IOStream()
        return (stream, connect_future)
    af = socket.AF_INET
    addr = ('localhost', 80)
    addr_iterator = iter([(af, addr)])
    connector = _Connector([(af, addr)], connect)
    connector.future = Future()
    connector.try_connect(addr_iterator)
    def callback():
        assert(connector.future.result() == (af, addr, stream))
        called = True


# Generated at 2022-06-22 04:38:15.333375
# Unit test for constructor of class TCPClient
def test_TCPClient():
    client = TCPClient()
    assert client.resolver != None
    assert client._own_resolver == True

# Generated at 2022-06-22 04:38:17.777850
# Unit test for constructor of class TCPClient
def test_TCPClient():
    t = TCPClient()
    assert type(t) == TCPClient
    print("Success")


if __name__ == "__main__":
    test_TCPClient()

# Generated at 2022-06-22 04:38:29.869432
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    import pytest
    import unittest

    class TestClass(unittest.TestCase):
        @pytest.fixture
        def io_loop(self):
            return IOLoop()

        def test_on_connect_timeout(self):
            io_loop = self.io_loop
            io_loop.make_current()

            def connect(
                address_family,
            ):  # type: (socket.AddressFamily, Tuple[Any, Any]) -> Tuple[IOStream, Future[IOStream]]
                stream = IOStream(socket.socket(address_family, socket.SOCK_STREAM))
                future = Future()
                io_loop.add_callback(
                    functools.partial(
                        future.set_result, stream
                    )
                )  # type: ignore
                return stream, future

           

# Generated at 2022-06-22 04:38:35.752603
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    def _set_timeout(timeout):
        self, timeout = timeout
        self.timeout = self.io_loop.add_timeout(
            self.io_loop.time() + timeout, self.on_timeout
        )
    
    ioloop = IOLoop.current()
    ioloop.time = lambda: 0
    timeout = _Connector.set_timeout(ioloop, _set_timeout, 1)
    print(timeout)


# Generated at 2022-06-22 04:38:48.134803
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # test for method try_connect
    # _Connector.try_connect(self, addrs: Iterator[Tuple[socket.AddressFamily, Tuple]]) -> None:
    addrinfo = [(socket.AF_INET, ('10.0.0.1', 80)), (socket.AF_INET, ('10.0.0.2', 80)),
                (socket.AF_INET6, ('2001:0db8::1', 80)), (socket.AF_INET6, ('2001:0db8::2', 80))]
    # (Family, Address) ==> (Family, Address, IOStream)

# Generated at 2022-06-22 04:38:53.719746
# Unit test for method split of class _Connector
def test__Connector_split():
    # Test _Connector.split with IPv4 and IPv6 addresses
    IPv4_address = ("127.0.0.1", 8080)
    IPv6_address = ("[::1]", 8080)
    address_list = [IPv4_address, IPv6_address]
    primary_addrs, secondary_addrs = _Connector.split(address_list)
    assert primary_addrs[0] == (socket.AF_INET, IPv4_address)
    assert secondary_addrs[0] == (socket.AF_INET6, IPv6_address)



# Generated at 2022-06-22 04:38:57.616109
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    a = _Connector(None, None)
    a.io_loop = mock.Mock()
    a.timeout = 11
    a.connect_timeout = 22
    a.clear_timeouts()
    a.io_loop.remove_timeout.assert_has_calls([mock.call(11), mock.call(22)])
test__Connector_clear_timeouts()



# Generated at 2022-06-22 04:38:58.163541
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    pass

# Generated at 2022-06-22 04:39:08.470412
# Unit test for constructor of class TCPClient
def test_TCPClient():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serverStream = IOStream(sock)
    client = TCPClient()
    addrinfo = [(socket.AF_INET, ("127.0.0.1", 123)), (socket.AF_INET6, ("127.0.0.1", 456))]
    connector = _Connector(addrinfo, client._create_stream)
    connector.start()
    stream, future = connector.connect(socket.AF_INET, ("127.0.0.1", 123))
    assert(isinstance(stream, IOStream))
    assert(isinstance(future, Future))
    

# Generated at 2022-06-22 04:39:11.662361
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
	resolver = Resolver()
	connector = _Connector(resolver.resolve("www.google.com", 80), None)
	connector.clear_timeout()
	