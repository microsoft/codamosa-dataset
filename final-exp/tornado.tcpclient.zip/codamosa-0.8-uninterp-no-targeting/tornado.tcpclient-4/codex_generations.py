

# Generated at 2022-06-22 04:30:17.423458
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    pass



# Generated at 2022-06-22 04:30:21.432584
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    tcp_client = TCPClient()
    tcp_client.connect(
        host="www.baidu.com",
        port=443,
        af=socket.AF_UNSPEC,
        ssl_options=None,
        max_buffer_size=None,
        source_ip=None,
        source_port=None,
        timeout=None,
    )


# Generated at 2022-06-22 04:30:23.210918
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    client = TCPClient()
    client.close()
    try:
        client.close()
    except Exception as e:
        # print(e)
        assert True
    else:
        assert False


# Generated at 2022-06-22 04:30:30.645625
# Unit test for method start of class _Connector
def test__Connector_start():
    mock_sleep = lambda x: None
    connect = lambda x, y: (None, IOLoop.current().spawn_callback(lambda: 1))
    c = _Connector([], connect)
    with mock_sleep:
        c.start(1, 1)

    def assert_error(e):
        assert isinstance(e, TimeoutError)

    future = c.start(1, 0.000001)
    future.add_done_callback(assert_error)
    # Unit test for method close_streams of class _Connector
    for stream in c.streams:
        assert stream.closed()



# Generated at 2022-06-22 04:30:35.001332
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    from tornado import testing
    from tornado import gen
    from tornado.netutil import Resolver
    from tornado.tcpserver import TCPServer
    from tornado.ioloop import IOLoop

    #def _make_ioloop():
    #    # Python 3.3 and later have timeouts with nanosecond precision,
    #    # but Python 2's socket module is only precise to the second.
    #    # To make tests pass consistently between the two, we use an
    #    # IOLoop that runs in seconds rather than milliseconds.
    #    io_loop = IOLoop()
    #    io_loop.make_current()
    #    return io_loop

    #class SleepHandler(StreamRequestHandler):
    #    def handle_stream(self, stream, address):
    #        self.stream = stream
    #        self.stream

# Generated at 2022-06-22 04:30:42.193214
# Unit test for method split of class _Connector
def test__Connector_split():
    addrinfo = [(socket.AF_INET6, ("2001:DB8::ABCD", 80, 0, 0)), (socket.AF_INET, ('127.0.0.1', 80))]
    primary, secondary = _Connector.split(addrinfo)
    assert primary == [(socket.AF_INET6, ("2001:DB8::ABCD", 80, 0, 0))]
    assert secondary == [(socket.AF_INET, ('127.0.0.1', 80))]



# Generated at 2022-06-22 04:30:47.217635
# Unit test for method start of class _Connector
def test__Connector_start():
    import pytest

    with pytest.raises(NotImplementedError):
        _Connector_test = _Connector([], None)
        _Connector_test.start(_INITIAL_CONNECT_TIMEOUT, None)

# Generated at 2022-06-22 04:30:54.372988
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    """This tests the _Connector set_connect_timeout method"""
    c = _Connector([(1, (1, 2))], lambda x, y: (IOStream(), Future()))

    c.set_connect_timeout(datetime.timedelta(seconds=2))
    """This test just checks the object is passed, not the value"""
    assert isinstance(c.connect_timeout, object)

    c.set_connect_timeout(2)
    assert isinstance(c.connect_timeout, object)



# Generated at 2022-06-22 04:30:55.539081
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    assert False, "Test not implemented"



# Generated at 2022-06-22 04:31:07.521344
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    import socket

    loops = [IOLoop.instance(), IOLoop.instance()]

# Generated at 2022-06-22 04:31:24.967322
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    ioloop = IOLoop() #type: IOLoop
    connector = _Connector([(socket.AF_INET, ("1.2.3.4", 80))],
                           lambda af, addr: (None, None)) # type: _Connector
    assert connector.connect_timeout is None
    connector.set_connect_timeout(30)
    assert isinstance(connector.connect_timeout, object)


# Generated at 2022-06-22 04:31:26.123869
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    client = TCPClient()
    future = client.connect("127.0.0.1", 8888)
    print(future)


# Generated at 2022-06-22 04:31:31.645314
# Unit test for constructor of class _Connector
def test__Connector():
    resolver = Resolver()

    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("::1", 8081)),
    ]

    def connect(af: Any, addr: Any) -> Tuple[Any, "Future[Any]"]:
        return None, Future()

    connector = _Connector(addrinfo, connect)
    connector.start()


# Generated at 2022-06-22 04:31:32.738762
# Unit test for constructor of class TCPClient
def test_TCPClient():
    c = TCPClient()
    assert c
    c.connect("www.google.com", 80)
    assert c

# Generated at 2022-06-22 04:31:33.313702
# Unit test for constructor of class TCPClient
def test_TCPClient():
    tcp_client = TCPClient()
    assert tcp_client

# Generated at 2022-06-22 04:31:35.085284
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    _Connector(None,None).set_timeout(0.3)

# Generated at 2022-06-22 04:31:47.161204
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import unittest

    # Define the callback functions to be used in _Connector
    def mock_connect(af, addr):
        # type: (socket.AddressFamily, Tuple) -> Tuple[IOStream, Future]
        return (0, 0)

    def mock_on_connect_done(addrs, af, addr, future):
        # type: (Iterator[Tuple[socket.AddressFamily, Tuple]], socket.AddressFamily, Tuple, Future[IOStream]) -> None
        pass

    def mock_on_timeout():
        # type: () -> None
        pass

    def mock_set_timeout(timeout):
        # type: (float) -> None
        pass


# Generated at 2022-06-22 04:31:53.954340
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    from tornado.iostream import IOStream
    from tornado.iostream import SSLIOStream
    from tornado.concurrent import Future

    Addr = Tuple[socket.AddressFamily, Tuple]
    AddrInfo = List[Addr]
    ConnectedStream = Union[IOStream, SSLIOStream]
    FutureStream = Future[ConnectedStream]

    io_loop = IOLoop.current()

    class FakeStream:
        def __init__(self, f: FutureStream):
            self.stream = f.result()
            self.closed = False
        def close(self):
            self.closed = True


# Generated at 2022-06-22 04:31:58.034702
# Unit test for constructor of class _Connector
def test__Connector():
    res = Resolver()
    addr: List[Tuple] = res.resolve("127.0.0.1", 8888)
    assert isinstance(addr, list)
    assert len(addr) == 1



# Generated at 2022-06-22 04:32:01.856736
# Unit test for method try_connect of class _Connector

# Generated at 2022-06-22 04:32:41.631211
# Unit test for method start of class _Connector
def test__Connector_start():
    my_io_loop = IOLoop.current()
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 8080))]
    connect = lambda af, addr: (1, None)
    connector = _Connector(addrinfo, connect)
    connector.start()
    diff = my_io_loop.time() - connector.timeout
    assert diff >= 0
    assert diff <= 1e-2
    assert connector.remaining == 1
    assert connector.primary_addrs == [(socket.AF_INET, ('127.0.0.1', 8080))]
    assert connector.secondary_addrs == []


# Generated at 2022-06-22 04:32:47.073135
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    pass


async def async_main():
    client = TCPClient()
    stream = await client.connect("www.google.com", 443)
    stream.close()


if __name__ == "__main__":
    tornado.ioloop.IOLoop.current().run_sync(async_main)

# Generated at 2022-06-22 04:32:55.961059
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import pytest
    import time
    from tornado.platform.asyncio import AsyncIOMainLoop, to_asyncio_future
    from asyncio import Future, get_event_loop
    AsyncIOMainLoop().install()
    loop = get_event_loop()
    s = socket.socket()
    host = '127.0.0.1'
    port = 5000
    s.bind((host,port))
    s.listen(5)
    start = time.time()
    client = TCPClient()
    future = client.connect(host=host, port=port, timeout=1)
    future = to_asyncio_future(future)

# Generated at 2022-06-22 04:33:08.079779
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    from tornado.platform.auto import set_close_exec
    from tornado.iostream import SSLIOStream
    from tornado.log import gen_log
    from tornado.testing import AsyncTestCase

    class _ConnectorTest(AsyncTestCase):
        def test__Connector_on_connect_done(self):
            ssl_options = dict(certfile="tests/ca_cert.pem", keyfile=None)

            def mock_ssl_wrap_socket(sock, *args, **kwargs):
                ssloptions = dict(
                    certfile=kwargs.get("certfile"), keyfile=kwargs.get("keyfile")
                )
                self.assertEqual(ssloptions, ssl_options)
                self.stop()
                return ssloptions

            def mock_socket_connect(sock, addr):
                self

# Generated at 2022-06-22 04:33:09.438402
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Implementation here
    raise NotImplementedError()

# Generated at 2022-06-22 04:33:19.338202
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test data
    timeout_error = TimeoutError()
    # Mocks
    io_loop = Mock(IOLoop)
    io_loop.time.return_value = 0.0
    io_loop.add_timeout.return_value = 0
    io_loop.remove_timeout.return_value = 0
    future = Mock(Future)
    future.done.return_value = True
    # Test target
    test_obj = _Connector([], lambda _, __: None)
    # Prepare test object
    test_obj.future = future
    test_obj.io_loop = io_loop
    # Execute method under test.
    test_obj.on_connect_timeout()
    # Check result.
    future.set_exception.assert_called_with(timeout_error)



# Generated at 2022-06-22 04:33:27.914644
# Unit test for method start of class _Connector
def test__Connector_start():
    class Dummy_Connector(_Connector):
        def __init__(self, addrinfo, connect):
            super().__init__(addrinfo, connect)

        @staticmethod
        def split(addrinfo):
            primary = []
            secondary = []
            primary_af = addrinfo[0][0]
            for af, addr in addrinfo:
                if af == primary_af:
                    primary.append((af, addr))
                else:
                    secondary.append((af, addr))
            return primary, secondary

    addrinfo = [(2, ('', 0, 0, ''))]
    connect = lambda x, y: (x, y)
    dummy = Dummy_Connector(addrinfo, connect)
    # Call method start of class _Connector
    dummy.start()
    #

# Generated at 2022-06-22 04:33:28.432256
# Unit test for constructor of class TCPClient
def test_TCPClient():
    pass

# Generated at 2022-06-22 04:33:31.241369
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    connect_timeout = 1.0
    conn = _Connector([], lambda af, addr: (None, None))
    conn.set_connect_timeout(connect_timeout)
    conn.clear_timeouts()
    assert conn.connect_timeout is None



# Generated at 2022-06-22 04:33:32.307319
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    _Connector.close_streams()
    # TODO: implement this test

# Generated at 2022-06-22 04:35:38.693374
# Unit test for method start of class _Connector
def test__Connector_start():
    print(
        "Unit test for method start of class _Connector")
    # TODO
    print(
        "Todo: test_case is Empty\n")



# Generated at 2022-06-22 04:35:39.480666
# Unit test for constructor of class TCPClient
def test_TCPClient():
    tcp_client = TCPClient()



# Generated at 2022-06-22 04:35:47.693375
# Unit test for constructor of class _Connector
def test__Connector():
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("::1", 80)),
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("::1", 80)),
    ]
    connect = lambda *args: (0, Future())
    _Connector(addrinfo, connect)



# Generated at 2022-06-22 04:35:55.222787
# Unit test for method split of class _Connector
def test__Connector_split():
    from collections import namedtuple

    class _AddrInfo(namedtuple('_AddrInfo', 'family')):
        def __new__(cls, family):
            self = super(_AddrInfo, cls).__new__(cls, family)
            return self

    class _GetAddrInfoResolver(object):
        def __init__(self): self.flag = False
        def resolver(self, host, port, family, socktype, proto, flags):
            if self.flag:
                self.flag = False
                return [_AddrInfo(socket.AF_INET), _AddrInfo(socket.AF_INET6)]
            else:
                self.flag = True
                return [_AddrInfo(socket.AF_INET6), _AddrInfo(socket.AF_INET)]

   

# Generated at 2022-06-22 04:36:08.236583
# Unit test for method start of class _Connector
def test__Connector_start():
    import fcntl
    import os
    import sys
    import tempfile
    import unittest
    from tornado.concurrent import return_future
    from tornado.iostream import IOStream
    from tornado.netutil import bind_sockets
    from tornado.testing import AsyncTestCase, bind_unused_port, gen_test
    from tornado.util import errno_from_exception
    from tornado.platform.posix import set_close_exec
    from tornado.platform.posix import set_inheritable

    # try:
    #     from unittest import mock
    # except ImportError:
    #     from mock import mock

    from .util import bind_unused_port_ssl as ssl_bind_unused_port
    from .util import bind_unused_port_with_mode as bind_un

# Generated at 2022-06-22 04:36:17.962182
# Unit test for method on_connect_done of class _Connector

# Generated at 2022-06-22 04:36:31.293021
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    test_addrinfo = [
        (
            "AF_INET", (
                "W", "R", "s", "d", "f", "g", "h", "j", "k", "l", "z", "x", "c", "v",
                "b", "n", "m", "a", "s", "d", "f", "g", "h", "j", "k", "l", "z", "x",
                "c", "v", "b", "n", "m"
            )
        )
    ]  # type: List[Tuple]
    test_connect = lambda family, addr: (True, False)  # type: Callable[[socket.AddressFamily, Tuple], Tuple[IOStream, "Future[IOStream]"]]
    test_timeout = 0.3
    test

# Generated at 2022-06-22 04:36:31.970896
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    t = TCPClient()
    t.close()

# Generated at 2022-06-22 04:36:36.034938
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    async def t1():
        tcp_client = TCPClient()
        await tcp_client.connect('localhost', 6666)
        tcp_client.close()
    IOLoop.current().run_sync(t1)

if __name__ == '__main__':
    test_TCPClient_connect()

# Generated at 2022-06-22 04:36:48.417035
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    def mock_add_timeout(
        self, f :Callable, timeout: Union[float, datetime.timedelta]
    ) -> 'object':
        return timeout
    import tornado.iostream
    io_loop = tornado.ioloop.IOLoop.current()
    tornado.iostream.IOLoop = io_loop
    io_loop.add_timeout = mock_add_timeout
    addrinfo = []
    addrinfo.append((socket.AF_INET, ('12.0.0.1', 80)))
    addrinfo.append((socket.AF_INET, ('12.0.0.2', 80)))