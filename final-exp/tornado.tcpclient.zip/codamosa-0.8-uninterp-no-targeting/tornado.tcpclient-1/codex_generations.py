

# Generated at 2022-06-22 04:30:16.809118
# Unit test for method start of class _Connector
def test__Connector_start():
    io_loop = None
    connect = None
    target = _Connector(None, connect)
    target.io_loop = io_loop
    timeout = None
    connect_timeout = None
    try:
        actual = target.start(timeout, connect_timeout)
    except Exception:
        raise AssertionError
# Test case for method close_streams in class _Connector

# Generated at 2022-06-22 04:30:27.277778
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    # Some arbitrary value which is valid for socket.AF_INET
    addr = ('127.0.0.1', 8080)

    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future"]:
        res = Future()
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
        # simulate that the stream connection is already closed.
        stream.close()
        res.set_result(stream)
        return stream, res

    # timeout must be executed
    conn = _Connector([(socket.AF_INET, addr)], connect)
    # execute the connect method twice
    conn.start()
    conn.start()



# Generated at 2022-06-22 04:30:28.224177
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    _Connector.on_timeout(self)

# Generated at 2022-06-22 04:30:28.822075
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    pass

# Generated at 2022-06-22 04:30:39.893353
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    Addrinfo = Tuple[socket.AddressFamily, Tuple]
    # Addrinfo = Tuple[socket.AddressFamily, Any]
    IOStream = Any
    addrinfo = []
    # for i in range(4):
    #     addrinfo.append((socket.AddressFamily.AF_INET, ('127.0.0.1')))
    # for i in range(4):
    #     addrinfo.append((socket.AddressFamily.AF_INET6, ('127.0.0.1')))
    # for i in range(4):
    #     addrinfo.append((socket.AddressFamily.AF_UNSPEC, ('127.0.0.1')))
    # set()
    # addrinfo.append((socket.AddressFamily.AF_UNSPEC, '127.0.0.1'))
    #

# Generated at 2022-06-22 04:30:53.041649
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    from pytest import raises
    from tornado import gen
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import gen_test
    from unittest.mock import MagicMock
    from unittest.mock import Mock
    import socket
    import ssl
    import tornado.testing
    import typing

    class MyFixture(tornado.testing.AsyncTestCase):
        def my_fake_connect(
            self,
            af: socket.AddressFamily,
            addr: typing.Tuple,
        ) -> typing.Tuple[IOStream, "Future[IOStream]"]:
            return IOStream(socket.socket(af, socket.SOCK_STREAM, 0)), gen.Future()


# Generated at 2022-06-22 04:31:01.703253
# Unit test for method start of class _Connector
def test__Connector_start():
    connect_af_addr_stream = None
    def connect(af, addr):
        nonlocal connect_af_addr_stream
        connect_af_addr_stream = (af, addr, None)
        return connect_af_addr_stream
    c = _Connector([(4, ('4', '4'))], connect)
    c.start()
    assert c.io_loop == IOLoop.current()
    assert c.connect == connect
    assert c.future
    assert c.timeout == None
    assert c.connect_timeout == None
    assert c.last_error == None
    assert c.remaining == 1
    assert c.primary_addrs == [(4, ('4', '4'))]
    assert c.secondary_addrs == []
    assert c.streams == set()

# Generated at 2022-06-22 04:31:04.906612
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    _INITIAL_CONNECT_TIMEOUT = 0.3
    _connector = _Connector([], lambda x, y: None)
    _connector.set_timeout(_INITIAL_CONNECT_TIMEOUT)


# Generated at 2022-06-22 04:31:17.266884
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import IOStream
    import socket
    
    class _MyConnector(AsyncTestCase):
        
        @gen_test
        def test_try_connect(self):
            connector = _Connector([(socket.AF_INET, ('127.0.0.1', 80))], connect)
            future=connector.start()
            res= yield future
            assert set(res)== set((socket.AF_INET, ('127.0.0.1', 80), IOStream(socket.socket(socket.AF_INET, socket.SOCK_STREAM))))
            assert connector.future.done()
            assert connector.future._done== True
            

# Generated at 2022-06-22 04:31:27.099808
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import asyncio
    from tornado.testing import AsyncTestCase, gen_test
    from my_connector import connect
    import socket
    import ssl

    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", 9998)),
        (socket.AF_INET, ("127.0.0.1", 9999)),
        (socket.AF_INET6, ("::1", 9998)),
        (socket.AF_INET6, ("::1", 9999)),
    ]
    c = _Connector(addrinfo, connect)
    future = c.start()

    loop = asyncio.get_event_loop()
    f = loop.create_future()

    @gen.coroutine
    def set_f():
        yield c.future

# Generated at 2022-06-22 04:31:44.246601
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    client = TCPClient()
    client.close()

# Generated at 2022-06-22 04:31:52.011530
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    import unittest
    import unittest.mock

    from pyrsistent import pmap, pvector

    from tornado import gen
    import tornado.platform.asyncio
    from tornado.testing import AsyncTestCase, gen_test


    from pyrsistent import pmap, pvector

    from tornado import gen
    import tornado.platform.asyncio

    from tornado.testing import AsyncTestCase, gen_test

    from tornado.test.util import unittest


    class _ConnectorUnitTest(AsyncTestCase):
        @staticmethod
        def _make_ssl_stream() -> IOStream:
            # type: () ->  IOStream
            stream = IOStream(socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0))
            stream.set_close_callback(lambda: None)
           

# Generated at 2022-06-22 04:31:59.472559
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    global _Connector
    import unittest
    import tornado.testing
    import types

    class MyTestCase(tornado.testing.AsyncTestCase):
        def test_clear_timeouts(self):
            with self.assertRaises(AttributeError):
                self.assertFalse(
                    hasattr(_Connector, "clear_timeouts")
                )

    MyTestCase = types.new_class("MyTestCase", (MyTestCase, unittest.TestCase))
    MyTestCase().test_clear_timeouts()



# Generated at 2022-06-22 04:32:05.281380
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
  # _Connector.on_timeout
  # Called when the initial connection attempt times out, so we should start
  # the secondary connection attempt.
  _Connector._Connector__on_timeout(self)

# Generated at 2022-06-22 04:32:13.718872
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import sys
    import os
    import inspect
    import tornado

    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0,parentdir)

    from .tcpclient import TCPClient

    def add_future(future, timeout):
        future.set_result(timeout)

    def post_callback(x):
        x.add_done_callback(
            tornado.ioloop.IOLoop.current().add_future, tornado.ioloop.IOLoop.current().time() + x.result()
        )


# Generated at 2022-06-22 04:32:21.726114
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    def get_future():
        return Future()

    connector = _Connector([(4, ('127.0.0.1', 80)), (6, ('::1', 80))], get_future)
    assert not connector.future.done()
    connector.set_connect_timeout(1)
    assert connector.connect_timeout is not None
    connector.on_connect_timeout()
    assert connector.future.exception() == TimeoutError()



# Generated at 2022-06-22 04:32:29.724829
# Unit test for method split of class _Connector
def test__Connector_split():
    result = _Connector.split(
        [
            (1, 2),
            (3, 4),
            (5, 6),
            (1, 7),
            (8, 9),
            (1, 10),
        ]
    )
    result1 =(
        [
            (1, 2),
            (1, 7),
            (1, 10),
        ],
        [
            (3, 4),
            (5, 6),
            (8, 9),
        ]
    )

    result2 =(
        [
            (3, 4),
            (5, 6),
            (8, 9),
        ],
        [
            (1, 2),
            (1, 7),
            (1, 10),
        ],
    )
    assert result == result1 or result == result2



# Generated at 2022-06-22 04:32:34.640817
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    Defaults = Connector(getaddrinfo("localhost", 8080))
    Defaults.on_connect_done(iter([]), socket.AF_INET, ("localhost", 8080))
    Defaults = Connector(getaddrinfo("localhost", 8080))
    Defaults.on_connect_done(iter([]), socket.AF_INET, ("localhost", 8080))



# Generated at 2022-06-22 04:32:47.758963
# Unit test for constructor of class _Connector
def test__Connector():
    from tornado.escape import utf8
    from tornado.iostream import IOStream
    from tornado.testing import bind_unused_port

    sock, port = bind_unused_port()
    sock.listen(1)
    addrinfo = [
        (socket.AF_INET, ("127.0.0.1", port)),
        (socket.AF_INET6, ("::1", port)),
        (socket.AF_INET, ("127.0.0.2", port)),
    ]

    def connect(af: socket.AddressFamily, addr: Tuple[str, int]) -> Tuple[IOStream, Future[IOStream]]:
        stream = IOStream(socket.socket(af, socket.SOCK_STREAM))
        stream._connecting = True
        f = Future()

# Generated at 2022-06-22 04:32:48.389989
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
	assert True



# Generated at 2022-06-22 04:33:23.320637
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    print("Test of method set_connect_timeout of class _Connector")
    my_connector = _Connector(
        [("af", ("192.168.1.1", 1010))],
        lambda af, addr: (None, None),
    )
    my_connector.set_connect_timeout(0.0001)
#test__Connector_set_connect_timeout()



# Generated at 2022-06-22 04:33:31.789670
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    addrinfo = [(socket.AF_INET6, ('1::1', 8080, 0, 0))]
    def connect(family, addr):
        return IOStream(socket.socket(family, socket.SOCK_STREAM)), Future()

    _connector = _Connector(addrinfo, connect)
    _connector.future.set_result
    _connector.streams.add(IOStream(socket.socket(socket.AF_INET6, socket.SOCK_STREAM)))

    # the first attempt failed, don't wait for the timeout to try an address from the secondary queue.
    _connector.on_timeout()
    assert _connector.timeout is None
    assert _connector.future.done()

    _connector.io_loop.remove_timeout = MagicMock()
    _connector.on_connect_done

# Generated at 2022-06-22 04:33:37.757383
# Unit test for method on_timeout of class _Connector

# Generated at 2022-06-22 04:33:50.533752
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    # __init__(self, addrinfo: List[Tuple], connect: Callable[[socket.AddressFamily, Tuple], Tuple[IOStream, "Future[IOStream]"]]) -> None
    _connector = _Connector([(AF_INET, ('0.0.0.0', 0)), (AF_INET, ('0.0.0.0', 0))], connect=None)
    # addrs: Iterator[Tuple[socket.AddressFamily, Tuple]],
    addrs = iter([(AF_INET, ('0.0.0.0', 0)), (AF_INET, ('0.0.0.0', 0))])
    # af: socket.AddressFamily,
    af = AF_INET
    # addr: Tuple,
    addr = ('0.0.0.0', 0)
   

# Generated at 2022-06-22 04:34:03.069829
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    """Test for method _Connector.on_connect_done"""
    from unittest.mock import Mock, patch
    mock_addrs : Iterator[Tuple[socket.AddressFamily, Tuple]] = Mock()
    mock_af : socket.AddressFamily = Mock()
    mock_addr : Tuple = Mock()
    mock_future : "Future[IOStream]" = Mock()
    x : _Connector = _Connector(None, None)

    with patch("netharn.connections.connector.IOLoop") as mock_ioloop:
        mock_ioloop.current.return_value.time.return_value = 0

        # Mock case #1
        mock_ioloop.current.return_value.add_timeout.side_effect = [1]

        mock_addrs.__next__.side_effect = StopIteration



# Generated at 2022-06-22 04:34:04.667141
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    tcp = TCPClient()
    tcp.close()
    assert True

# Generated at 2022-06-22 04:34:12.076972
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    connector = _Connector([(socket.AddressFamily.AF_INET, (1, 1)), (socket.AddressFamily.AF_INET, (2,2))], lambda x, y: None)
    #TODO: Create an iterator of tuples and add two tuples
    #TODO: Call self.try_connect(iter(self.primary_addrs))
    #TODO: Test self.try_connect(iter(self.primary_addrs))
    return



# Generated at 2022-06-22 04:34:19.909272
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    io_loop = IOLoop.current()
    future = Future()
    future.set_result(None)
    connector = _Connector([], lambda af, addr: (None, future))
    connector.io_loop = io_loop
    connector.future = Future()
    connector.timeout = io_loop.add_timeout(io_loop.time() + 10, connector.on_timeout)
    secondary_addrs = []
    # secondary_addrs is empty
    connector.on_timeout()
    assert connector.future.done()


# Generated at 2022-06-22 04:34:31.336969
# Unit test for constructor of class _Connector
def test__Connector():
    self = _Connector
    addrinfo = [
        (
            socket.AddressFamily.AF_INET,
            (socket.AddressFamily.AF_INET, 0, "lo", "lo"),
        ),
        (
            socket.AddressFamily.AF_INET6,
            (
                socket.AddressFamily.AF_INET6,
                0,
                "lo",
                "lo",
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                socket.AddressFamily.AF_INET6,
            ),
        ),
    ]
    connector = self(addrinfo, None)
    assert connector.io_loop == IOLoop.current()
    assert connector.connect == None
    assert connector.future != None

# Generated at 2022-06-22 04:34:35.016717
# Unit test for constructor of class _Connector
def test__Connector():
    # _Connector(addrinfo: List[Tuple], connect: Callable[[socket.AddressFamily, Tuple], Tuple[IOStream, 'Future[IOStream]']]) -> None
    pass



# Generated at 2022-06-22 04:35:33.299321
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    resolver = Resolver()
    TCPClient = TCPClient(resolver)
    TCPClient.close()



# Generated at 2022-06-22 04:35:36.315874
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    io_loop = IOLoop.current()
    io_loop.make_current()
    fut = TCPClient().connect('127.0.0.1', 6379, ssl_options=None)
    res = io_loop.run_sync(fut)
    print(res)

if __name__ == '__main__':
    test_TCPClient_connect()
    from multiprocessing import Process
    p = Process(target=test_TCPClient_connect)
    p.start()
    p.join()

# Generated at 2022-06-22 04:35:41.020404
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    future = Future()
    future.set_exception(TimeoutError())
    stream = IOStream(socket.socket())
    connector = _Connector([(socket.AF_INET, ('8.8.8.8', 80))], lambda a, b: (stream, future))
    connector.close_streams()
    assert stream.closed()



# Generated at 2022-06-22 04:35:43.189053
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    tc = TCPClient()
    stream = tc.connect("127.0.0.1", 8080)
    print(stream)
    tc.close()



# Generated at 2022-06-22 04:35:46.499323
# Unit test for constructor of class _Connector
def test__Connector():
    # type: () -> None
    def connect(family, addr):
        # type: (int, Tuple[str, int]) -> Tuple[IOStream, Future[IOStream]]
        return IOStream(socket.socket(family, socket.SOCK_STREAM)), Future()

    test_addrinfo = [(socket.AF_INET, ("127.0.0.1", 8080))]
    _Connector(test_addrinfo, connect)


# Generated at 2022-06-22 04:35:49.082791
# Unit test for constructor of class TCPClient
def test_TCPClient():
    client = TCPClient()
    assert client._own_resolver == True
    assert isinstance(client.resolver, Resolver)
    assert client._own_resolver == True
    resolver = Resolver()
    client = TCPClient(resolver)
    assert client._own_resolver == False
    assert resolver == client.resolver

# Generated at 2022-06-22 04:35:59.961450
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import StreamClosedError
    from tornado.concurrent import Future
    from tornado.netutil import bind_sockets
    from socket import socket, AF_INET, SOCK_STREAM
    from asyncio import Protocol
    import errno
    import sys
    import threading
    
    class EchoProtocol(Protocol):
        def __init__(self):
            self._buffer = b''
            self._message = b'g'
            self._transport = None
        
        def connection_made(self, transport):
            self._transport = transport
        
        def data_received(self, data):
            self._buffer += data

# Generated at 2022-06-22 04:36:11.774876
# Unit test for method split of class _Connector
def test__Connector_split():
    # af, addr
    addrinfo = [
        # primary address
        (socket.AF_INET, ("127.0.0.1", 5000)),
        # secondary addresses
        (socket.AF_INET6, ("127.0.0.1", 5000)),
        (socket.AF_UNIX, ("127.0.0.1", 5000))
    ]
    # primary, secondary
    p, s = _Connector.split(addrinfo)
    print(p)
    print(s)


_LOCALHOST_ADDRINFO = [(socket.AF_INET, ("127.0.0.1", 0)), (socket.AF_INET6, ("::1", 0))]
_LOCALHOST_NAMES = ["localhost"]



# Generated at 2022-06-22 04:36:13.585780
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    ioloop = IOLoop.current()
    client = TCPClient()
    ioloop.run_sync(lambda: client.connect("www.google.com", 80))
    client.close()

# Generated at 2022-06-22 04:36:26.068363
# Unit test for method start of class _Connector
def test__Connector_start():
    # Test cases for _Connector.
    test__Connector_start.__doc__ = _Connector.start.__doc__
    from typing import List, Tuple
    from tornado.iostream import IOStream
    from tornado.concurrent import Future
    from socket import socket
    from tornado.testing import gen_test, AsyncTestCase

    _CONNECTOR_TIMEOUT = _INITIAL_CONNECT_TIMEOUT
    _CONNECTOR_CONNECT_TIMEOUT = 10
    # An IP address that will probably not be in DNS but is valid,
    # guaranteed not to be a private address, and guaranteed not to
    # exist on the public internet.
    _TEST_IP = "198.18.0.254"
    # The next available port on localhost to use in tests.
    _TEST_PORT = 39741
    #

# Generated at 2022-06-22 04:38:32.689530
# Unit test for method start of class _Connector
def test__Connector_start():
    # Test start of _Connector
    import unittest
    import unittest.mock as mock

    class Test_Connector_start(unittest.TestCase):
        @mock.patch("tornado.concurrent.Future")
        @mock.patch("tornado.ioloop.IOLoop")
        @mock.patch("tornado.netutil.Connector._Connector.split")
        def test_start(self, mocked_split, mocked_IOLoop, mocked_Future):
            print("unit test for method Connector._Connector.start")
            connector = Connector._Connector("addrinfo", "connect")
            connector.io_loop = "io_loop"
            mocked_split.return_value = ("primary_addrs", "secondary_addrs")
            mocked_Future.return_value = "future"

# Generated at 2022-06-22 04:38:40.466594
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    # Test 1: connect_timeout is a float
    from tornado.testing import AsyncTestCase, gen_test
    from tornado import testing
    from tornado.concurrent import Future
    from tornado.gen import TimeoutError
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import socket
    import unittest

    class Test_(AsyncTestCase):
        @testing.gen_test
        async def test1(self):
            class test_connect():
                def __init__(self):
                    self.io_loop = IOLoop.current()
                    self.addrinfo = []

                def __call__(self, af, addr):
                    if af is socket.AF_INET:
                        raise TimeoutError

# Generated at 2022-06-22 04:38:50.099322
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    class _ConnectorTest(object):
        def __init__(self):
            self.connect = _connect
            self.addrinfo = [(1, 1), (2, 0)]
            self.af = socket.AF_INET
            self.addr = (1, 1)
            self.future = Future()
            self.future.set_result(45)
            self.streams = []

    connector = _ConnectorTest()
    connector.start()
    assert connector.remaining == 1
    assert connector.timeout is None
    assert connector.connect_timeout is None
    assert connector.last_error is None
    assert connector.future.result()[2] == 45



# Generated at 2022-06-22 04:39:01.167782
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    import time
    import tornado.testing
    import io
    import ssl
    import socket
    import tornado.gen
    import tornado.ioloop
    import tornado.netutil
    import tornado.iostream
    import tornado.platform.select
    import tornado.platform.asyncio
    import unittest


    class BaseTestAsyncio(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            try:
                from asyncio import ensure_future
            except ImportError:
                from asyncio import _ensure_future as ensure_future

            cls.ensure_future = ensure_future


        @classmethod
        def tearDownClass(cls):
            try:
                del cls.ensure_future
            except AttributeError:
                pass



# Generated at 2022-06-22 04:39:07.351086
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # Creates an instance of class _Connector
    conn = _Connector([(socket.AddressFamily.AF_INET, ('127.0.0.1', 6666))], lambda x,y: (fake_iostream(), fake_fut()))

    # Checks the attribute "io_loop"
    assert isinstance(conn.io_loop, IOLoop)
    assert conn.io_loop.instance() == IOLoop.current()

    assert conn.remaining == 1

    # Checks the attribute "primary_addrs" and "secondary_addrs"
    assert len(conn.primary_addrs) == 1
    assert conn.primary_addrs[0] == (socket.AddressFamily.AF_INET, ('127.0.0.1', 6666))

    assert len(conn.secondary_addrs) == 0

# Generated at 2022-06-22 04:39:11.885081
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    a = _Connector(None, None)
    assert not a.future.done()
    
    a.io_loop = IOLoop.current()
    a.timeout = a.io_loop.add_timeout(
        a.io_loop.time() + 0.1, a.on_timeout
    )
    
    a.connect_timeout = a.io_loop.add_timeout(
        a.io_loop.time() + 0.1, a.on_connect_timeout
    )
    assert a.timeout != None
    assert a.connect_timeout != None

    a.clear_timeouts()
    assert a.timeout == None
    assert a.connect_timeout == None



# Generated at 2022-06-22 04:39:23.759397
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import asyncio
    import random

    def is_address_useful(address: Tuple) -> bool:
        return address[1] < 0

    def is_address_valid(address: Tuple) -> bool:
        return address[1] > 0

    def get_address():
        address = (random.randint(0, 1), random.randint(-1, 1))
        return address

    class _Future:

        def __init__(self, address: Tuple):
            self.address = address
            self.done = False
            self.result = None
            self.exception = None

        def set_exception(self, exception: Exception) -> None:
            self.exception = exception
            self.done = True


# Generated at 2022-06-22 04:39:34.840507
# Unit test for constructor of class _Connector
def test__Connector():
    import asyncio
    from tornado.concurrent import Future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.tcpserver import TCPServer
    import tornado
    import logging
    import socket
    import time
    import asyncio
    from asyncio import ensure_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.iostream import IOStream
    import functools
    import ssl

    logging.basicConfig(level=logging.INFO)
    loop = IOLoop.current()


# Generated at 2022-06-22 04:39:46.493302
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import os
    import socket
    import unittest
    from tornado.testing import AsyncTestCase, bind_unused_port

    from .base import _Connector
    from .base import (
        future_add_done_callback,
        functools,
        gen,
        IOLoop,
        IOStream,
        Resolver,
        socket,
        ssl,
        StreamClosedError,
        tcpserver,
    )

    class _ConnectorTest(AsyncTestCase):
        def setUp(self):
            super(_ConnectorTest, self).setUp()
            self.server = None
            self.socket, self.port = bind_unused_port()

        def tearDown(self):
            self.socket.close()
            if self.server is not None:
                self.server.stop()
            super