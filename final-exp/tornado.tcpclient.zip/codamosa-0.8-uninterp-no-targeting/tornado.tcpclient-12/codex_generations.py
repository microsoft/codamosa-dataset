

# Generated at 2022-06-22 04:30:20.779629
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Test definition for _Connector.on_connect_timeout
    from tornado import testing
    from tornado import gen

    from ._connector import _Connector

    # Todo: This is a unit test for _Connector class.
    # Should move it to a file test_cnonector
    class FakeSocket:
        def __init__(self, family=None, type=None, proto=None, fileno=None):
            self.family = family
            self.type = type
            self.proto = proto
            self.fileno = fileno

    class FakeGetAddrInfo:
        def __init__(self, family=None, type=None, proto=None, fileno=None):
            self.family = family
            self.type = type
            self.proto = proto
            self.fileno = fileno


# Generated at 2022-06-22 04:30:25.973421
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    connector = _Connector([(4,("127.0.0.1",80))], "connect")
    connector.on_connect_done([(4,("127.0.0.1",80))], 4, ("127.0.0.1",80), "future")


# Generated at 2022-06-22 04:30:36.626513
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    class MockIOLoop(object):
        def __init__(self) -> None:
            self.time = 0
            self.remove_count = 0
            self.add_count = 0
            self.remove_call_args = None #type: None
            self.add_call_args = None #type: None

        def time(self) -> numbers.Number:
            return self.time

        def remove_timeout(self, handle: numbers.Number) -> None:
            self.remove_count += 1
            self.remove_call_args = handle

        def add_timeout(self, deadline: Union[float, datetime.timedelta], callback: Any) -> numbers.Number:
            self.add_count += 1
            self.add_call_args = callback
            return 1


# Generated at 2022-06-22 04:30:42.075753
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # 1st way
    # Create socket object
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Define the port on which you want to connect
    port = 12345

    # connect to the server on local computer
    res = _Connector.set_timeout(s, port)



# Generated at 2022-06-22 04:30:43.788168
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    client = TCPClient()
    client.close()
    assert True

# Generated at 2022-06-22 04:30:56.048154
# Unit test for constructor of class _Connector
def test__Connector():
    def connect(*args: Any) -> Tuple[Any, "Future[IOStream]"]:
        return None, Future()

    _Connector([(socket.AF_INET, ("1.1.1.1", 80))], connect)
    _Connector(
        [
            (socket.AF_INET, ("1.1.1.1", 80)),
            (socket.AF_INET6, ("::1", 80)),
            (socket.AF_INET, ("1.1.1.2", 80)),
        ],
        connect,
    )

# Generated at 2022-06-22 04:31:02.849436
# Unit test for method start of class _Connector
def test__Connector_start():
    stream = object()
    _connector = _Connector(
        addrinfo=[],
        connect=lambda af, addr: (stream, Future()),
    )

    @gen.coroutine
    def f():
        future = _connector.start()
        _connector.future.set_result(future.result())

    IOLoop.current().run_sync(f)

# Generated at 2022-06-22 04:31:14.723678
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    import socket
    from tornado.iostream import IOStream
    from tornado.testing import AsyncTestCase, bind_unused_port
    
    class Test_Connector(AsyncTestCase):
        def on_connect(self, sock, af):
            if af == socket.AF_INET:
                raise IOError()
            return IOStream(sock), Future()

        def test_connect(self):
            def do_test(sock, port):
                conn = _Connector([(socket.AF_INET, ("0.0.0.0", port))], self.on_connect)
                conn.try_connect(iter([(socket.AF_INET, ("0.0.0.0", port))]))

            sock, port = bind_unused_port()

# Generated at 2022-06-22 04:31:25.086141
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    resolver = Resolver()
    def connect(af, addr):
        return IOStream(socket.socket(af, socket.SOCK_STREAM), io_loop=IOLoop.curent())
    addrinfo = [
        (socket.AF_INET, ('192.168.0.10', 80)),
        (socket.AF_INET, ('192.168.0.11', 80)),
        (socket.AF_INET, ('192.168.0.12', 80)),
        (socket.AF_INET, ('192.168.0.13', 80)),
    ]
    connector = _Connector(addrinfo, connect)
    connector.set_connect_timeout(datetime.timedelta(seconds=1))
    connector.clear_timeouts()

# Generated at 2022-06-22 04:31:25.864158
# Unit test for constructor of class TCPClient
def test_TCPClient():
    client = TCPClient()
    assert isinstance(client, TCPClient)



# Generated at 2022-06-22 04:31:48.564391
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    print("\\\\Unit test for method clear_timeout of class _Connector")

    def test_timeout(self):
        def on_timeout():
            print("\\\\Unit test for method clear_timeout of class _Connector")

    def on_timeout():
        print("\\\\Unit test for method clear_timeout of class _Connector")


if __name__ == "__main__":
    test__Connector_clear_timeout()

# Generated at 2022-06-22 04:32:00.484453
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    resolver = Resolver()
    from tornado.iostream import IOStream
    from tornado.tcpclient import TCPClient
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.iostream import IOStream
    import tornado.httputil
    import tornado.httpserver
    import tornado.httpclient
    import tornado.template
    import tornado.gen
    import tornado.ioloop
    import tornado.locks
    import tornado.process
    import tornado.stack_context
    import tornado.tcpserver
    import tornado.test
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.iostream
    import tornado.tcpclient


# Generated at 2022-06-22 04:32:07.932767
# Unit test for constructor of class TCPClient
def test_TCPClient():
    resolver = Resolver()
    a = TCPClient(resolver)
    assert a.resolver == resolver
    assert a._own_resolver == False
    b = TCPClient()
    assert b.resolver != None
    assert b._own_resolver == True
    a.close()
    b.close()

# Generated at 2022-06-22 04:32:15.210492
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    def on_connect_done(addrs: Iterator[Tuple[socket.AddressFamily, Tuple]], af: socket.AddressFamily, addr: Tuple, future: Future[IOStream]) -> None:
        pass
    addrinfo = [(socket.AddressFamily.AF_UNSPEC, ('host', 80))]
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, Future[IOStream]]:
        return None, Future()
    connector = _Connector(addrinfo, connect)
    connector.future.set_result((socket.AddressFamily.AF_UNSPEC, ('host', 80), IOStream()))
    connector.start()
    connector.on_connect_done(iter(connector.primary_addrs), socket.AddressFamily.AF_UNSPEC, ('host', 80), connector.future)



# Generated at 2022-06-22 04:32:18.252249
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    tc = TCPClient()
    assert tc != None
    tc.close()
    with pytest.raises(Exception):
        tc.connect('localhost', 8080)
    

# Generated at 2022-06-22 04:32:21.367899
# Unit test for method start of class _Connector
def test__Connector_start():
	# test for method start
	# the method is hard to test because it relies on the TCPClient 
	# __init__, which is already tested
	return


# Generated at 2022-06-22 04:32:29.519444
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    import tornado.testing
    import tornado.gen
    import ssl
    import time
    import tornado.httpclient

    @tornado.gen.coroutine
    def _test_TCPClient():
        client = TCPClient()
        res = yield client.connect("localhost", 80, ssl_options=None)
        print("Connected to {}:{}".format(res.socket.getpeername()[0],
                                          res.socket.getpeername()[1]))
        print("Written: {}".format(res.write(b"GET / HTTP/1.1\r\n\r\n")))
        #print("Read: {}".format(res.read_until(b"\r\n\r\n")))
        print("Read: {}".format(res.read_bytes(1024**2)))
        print

# Generated at 2022-06-22 04:32:31.780383
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    _connector = _Connector(addrinfo=[], connect=lambda x,y: ())
    _connector.clear_timeouts()



# Generated at 2022-06-22 04:32:44.415162
# Unit test for constructor of class _Connector
def test__Connector():
    import socket
    import tornado.iostream
    import tornado.platform.asyncio
    import tornado.platform.twisted

    def connect(af, addr):
        stream = tornado.iostream.IOStream(socket.socket(af, socket.SOCK_STREAM))
        return stream, stream.connect(addr)

    # Test with all possible platforms
    platform_list = [
        "tornado.platform.select",
        "tornado.platform.asyncio",
        "tornado.platform.twisted",
    ]
    for platform in platform_list:
        tornado.platform.select.IOLoop = (
            tornado.iostream.BaseIOLoop()
            if platform == "tornado.platform.select"
            else None
        )

# Generated at 2022-06-22 04:32:54.368928
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    from unittest import TestCase

    import mock
    from tornado.util import b

    class FakeSocket(object):
        def __init__(self, returns_error=False):
            self.returns_error = returns_error

        def connect(self, addr):
            if self.returns_error:
                raise IOError("error")

    class FakeFuture(object):
        def __init__(self, result=None, error=None):
            self.result = result
            self.error = error
            self.called = False

        def set_result(self, result):
            self.called = True
            if self.error is not None:
                raise self.error

        def result(self):
            self.called = True
            if self.error is not None:
                raise self.error
            return self.result



# Generated at 2022-06-22 04:33:30.649768
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    class MockIOLoop:

        time = 0
        def add_timeout(self, time, callback):
            assert time == self.time + _INITIAL_CONNECT_TIMEOUT
            return 'timeout'
        def remove_timeout(self, timeout):
            assert timeout == 'timeout'

    io_loop = MockIOLoop()

    connector = _Connector([(socket.AF_INET6, ('::1', 80))], lambda af, addr: (None, None))
    connector.io_loop = io_loop
    connector.start()

    io_loop.time = 100
    assert connector.timeout == 'timeout'
    connector.timeout = None
    connector.set_timeout(_INITIAL_CONNECT_TIMEOUT)
    assert connector.timeout == 'timeout'
    assert io_loop.time == 100

# Unit test

# Generated at 2022-06-22 04:33:37.317903
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    """This function tests the connect method of TCPClient class"""
    resolver = Resolver()
    client = TCPClient(resolver)
    # We have to run the loop to have the client operate
    # In this case, we are just testing if the function
    # is called.
    IOLoop.current().run_sync(lambda: client.connect(host="www.google.com", port=80, af=socket.AF_UNSPEC, ssl_options=None, max_buffer_size=None, source_ip=None, source_port=None, timeout=None))

# Generated at 2022-06-22 04:33:38.462259
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    assert callable(_Connector.close_streams)



# Generated at 2022-06-22 04:33:51.401774
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    class IOStream_dummy():
        def close(self):
            return
    class IOLoop_dummy():
        def add_timeout(self, x, y):
            return 1
        def remove_timeout(self, x):
            return

    
    io_loop = IOLoop_dummy()
    future = Future()
    timeout = 1
    connect_timeout = 2
    last_error = Exception("failed")
    remaining = 1
    primary_addrs = [(socket.AF_INET6, ("127.0.0.1", 5000))]
    secondary_addrs = [(socket.AF_INET, ("127.0.0.1", 5000))]
    streams = [IOStream_dummy()]


# Generated at 2022-06-22 04:34:00.635124
# Unit test for method split of class _Connector
def test__Connector_split():
    address_families = (socket.AF_INET, socket.AF_INET)
    addresses = (('localhost', 8000), ('localhost', 8001))

    constr = _Connector(list(zip(address_families, addresses)),
                        lambda af, addr: (None, Future()))
    primary, secondary = constr.split(list(zip(address_families, addresses)))
    assert primary == [
        (socket.AF_INET, ('localhost', 8000)),
        (socket.AF_INET, ('localhost', 8001)),
    ]
    assert secondary == []


# Generated at 2022-06-22 04:34:06.149964
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    # Setup
    addrinfo = [('af', ('addr', 1))]
    connector = _Connector(addrinfo, lambda a, b: (None, None))
    connector.future = Future()

    # Test
    connector.on_connect_timeout()

    # Assertions
    assert connector.future.exception() == TimeoutError()

# Generated at 2022-06-22 04:34:17.925763
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    import tornado.testing
    import tornado.platform.asyncio
    from tornado.escape import native_str

    @gen.coroutine
    def test_body(self):
        # _Connector.start() should have a timeout
        conn = _Connector(
            [(socket.AF_INET, ("127.0.0.1", 1))], functools.partial(
                self._connect, True
            )
        )
        conn.start(connect_timeout=0.1)
        with self.assertRaises(TimeoutError):
            yield conn.future
        # cleanup
        conn = _Connector(
            [(socket.AF_INET, ("127.0.0.1", 1))], functools.partial(
                self._connect, True
            )
        )
        conn.start(connect_timeout=0.1)

# Generated at 2022-06-22 04:34:29.614855
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    from tornado.testing import gen_test
    from unittest.mock import patch, call
    from unittest import mock

    # (1) Unit test for method clear_timeout of class _Connector when timeout is not None
    
    with patch.object(IOLoop, "remove_timeout") as patches:
        @gen.coroutine
        def test_function(self):
            self.timeout = mock.Mock()
            self.connect_timeout = mock.Mock()
            self._Connector__clear_timeouts(self)

        with mock.patch.object(IOLoop, "current", return_value=mock.MagicMock()):
            connector = _Connector(addrinfo=[mock.Mock(), mock.Mock()],
                                   connect=mock.MagicMock())
            self.io_loop.run_sync

# Generated at 2022-06-22 04:34:40.220568
# Unit test for method split of class _Connector
def test__Connector_split():
    assert (_Connector.split([])) == ([], [])
    assert (_Connector.split(
        [(1, 2)]
    )) == ([(1, 2)], [])
    assert (_Connector.split(
        [(3, 4), (1, 2)]
    )) == ([(3, 4)], [(1, 2)])
    assert (_Connector.split(
        [(3, 4), (5, 6), (1, 2)]
    )) == ([(3, 4), (5, 6)], [(1, 2)])
    assert (_Connector.split(
        [(3, 4), (1, 2), (5, 6)]
    )) == ([(3, 4)], [(1, 2), (5, 6)])



# Generated at 2022-06-22 04:34:44.795017
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    c = _Connector(socket.getaddrinfo("www.python.org", "80"), None)
    c.future = Future()
    c.future.set_result("done")
    c.on_timeout()
    assert c.future.done()



# Generated at 2022-06-22 04:35:50.419823
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # Set parameters for test
    timeout = 0.3
    io_loop = IOLoop.current()
    # Create test instance
    connector = _Connector((), None)
    connector.io_loop = io_loop
    # Run method set_timeout with args
    connector.set_timeout(timeout)
    # Check returned value of method set_timeout
    # assert connector.timeout == True
    # Check exceptions raised by method set_timeout
    # assert connector.timeout == True 
__test__ = {"test__Connector_set_timeout": """Unit test for method set_timeout of class _Connector""",}



# Generated at 2022-06-22 04:36:01.194770
# Unit test for method start of class _Connector
def test__Connector_start():
    class Fake_future():
        def __init__(self):
            self.result = None
            self.exception = None

        def result(self):
            if self.result:
                return self.result
            else:
                raise self.exception

        def set_result(self, result):
            self.result = result

        def done(self):
            return True
    
    class Fake_stream():
        def __init__(self):
            self.closed = False
        
        def __del__(self):
            if not self.closed:
                raise Exception("IOStream is not closed")
        
        def close(self):
            self.closed = True
            del self

    fake_io_loop = Fake_io_loop()
    def fake_connect(af, addr):
        return Fake_stream(), Fake_

# Generated at 2022-06-22 04:36:10.423149
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    # getaddrinfo returns a list of tuples [ (af, sockaddr) ...]
    def getaddrinfo(host, port):
        return [ (0, ("localhost", 8888)), (1, ("127.0.0.1", 8888)) ]
    resolver = Resolver()
    resolver.getaddrinfo = getaddrinfo
    connector = _Connector(resolver.resolve(8888, "localhost"))
    # test the function
    assert connector.try_connect([(0, ("localhost", 8888))]) == None

# Generated at 2022-06-22 04:36:11.173718
# Unit test for constructor of class TCPClient
def test_TCPClient():
    TCPClient()


# Generated at 2022-06-22 04:36:11.648866
# Unit test for constructor of class TCPClient
def test_TCPClient():
    a = TCPClient()

# Generated at 2022-06-22 04:36:14.280383
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    t = _Connector([(socket.AF_INET, ('127.0.0.1', 3306))])
    t.io_loop = IOLoop()
    t.io_loop.make_current()
    t.try_connect(iter(t.primary_addrs))
    t.io_loop.start()


# Generated at 2022-06-22 04:36:20.643604
# Unit test for constructor of class _Connector
def test__Connector():
    from tornado.iostream import IOStream
    connector = _Connector(None, None)
    assert connector.future is not None
    assert connector.timeout is None
    assert connector.connect_timeout is None
    assert connector.last_error is None
    assert connector.remaining == 0
    assert connector.primary_addrs == []
    assert connector.secondary_addrs == []
    assert connector.streams == set()
    assert connector.io_loop is not None



# Generated at 2022-06-22 04:36:24.838555
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    # Ressources
    import unittest
    import time
    import socket
    from tornado.testing import AsyncTestCase, bind_unused_port

    # Test the async client
    class TestTCPClient(AsyncTestCase):
        def test_TCPClient_connect_success(self):
            self.stop()
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
            s.bind(("127.0.0.1", 0))
            s.listen(1)
            port = s.getsockname()[1]

            def client():
                s2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
                s2.connect(("127.0.0.1", port))
                s2.close()
               

# Generated at 2022-06-22 04:36:26.011145
# Unit test for method start of class _Connector
def test__Connector_start():
    assert 1 == 1

# Generated at 2022-06-22 04:36:36.591299
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    # The connect_done handler doesn't have access to the TCPClient
    # instance, so we can't instantiate one here, only mock it.
    class FakeClient(object):
        # Install a fake socket, so we don't have to deal with platform
        # differences.
        socket = socket.socket()

    class FakeAddrinfo(object):
        def __init__(self) -> None:
            self.failures = []  # type: List[Exception]

        def next_af(self) -> Tuple[socket.AddressFamily, Tuple]:
            af = socket.AF_INET
            if self.failures:
                af = socket.AF_INET6
            return af, ("", 80)

        def mark_failure(self, e: Exception) -> None:
            self.failures.append(e)


# Generated at 2022-06-22 04:38:35.246272
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    def on_timeout():
        return
    def on_connect_done():
        return
    def try_connect():
        return
    def on_connect_timeout():
        return
    def close_streams():
        return

    # test case 1
    connector = _Connector([], lambda x, y: (x, y))
    connector.timeout = 1
    helper_1 = connector.future
    helper_1.done = lambda: True
    connector.on_timeout()
    assert connector.timeout is None

    # test case 2
    helper_1.done = lambda: False
    connector.try_connect = lambda x: None
    connector.on_timeout()
    assert connector.timeout is None



# Generated at 2022-06-22 04:38:46.156192
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    def test_connect(af, addr):
        return IOStream(s), Future()
    c = _Connector(
        [(socket.AF_INET, ('', 80))],
        test_connect,
    )
    f = c.start()
    f.set_result((socket.AF_INET, ('', 80), IOStream(s)))
    s.listen()
    s1, addr = s.accept()
    c.on_connect_done(c.primary_addrs, socket.AF_INET, ('', 80), Future())


# Generated at 2022-06-22 04:38:57.459745
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    """Test method on_timeout of class _Connector"""

    import socket
    import unittest

    def _check_on_timeout(self):
        try:
            self.future.result()
        except Exception as e:
            self.last_error = e
            self.try_connect(iter(self.secondary_addrs))
        if self.timeout is not None:
            # If the first attempt failed, don't wait for the
            # timeout to try an address from the secondary queue.
            self.io_loop.remove_timeout(self.timeout)
            self.on_timeout()
    _Connector.on_timeout = _check_on_timeout


# Generated at 2022-06-22 04:39:03.398736
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    # We create two streams. First stream raises exception in method close(),
    # second stream raises exception in method close_fd().
    class Stream1(IOStream):
        def close(self):
            # type: () -> None
            raise Exception('stream1')
    class Stream2(IOStream):
        def close_fd(self):
            # type: () -> None
            raise Exception('stream2')
    # We create instance of class _Connector.
    connector = _Connector([(42, ('0.0.0.0', 0))], lambda x,y: (Stream1(), Future()))
    # We connect two streams to this instance.
    connector.streams.add(Stream2())
    # We run method close_streams.
    connector.close_streams()



# Generated at 2022-06-22 04:39:06.466369
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    """
    Unit test for tornado._connector._Connector.clear_timeout
    """
    stream = IOStream(socket.socket())
    addrs = [(socket.AddressFamily.AF_INET, ("0.0.0.0", 0))]
    connector = _Connector(addrs, lambda _, __: (stream, gen.Future()))
    connector.clear_timeout()



# Generated at 2022-06-22 04:39:11.037701
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    client = TCPClient()
    async def tester():
        stream = await client.connect('www.google.com', 80)
        await stream.write(b'GET / HTTP/1.1\r\nHost: www.google.com\r\n\r\n')
        data = await stream.read_until_close()
        assert len(data) > 0
        print(data.decode().split('\r\n')[0])

    print('Connecting to Google...')
    IOLoop.current().run_sync(tester)
    print('Finished')

if __name__ == '__main__':
    test_TCPClient_connect()

# Generated at 2022-06-22 04:39:19.314278
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    # import tornado.testing
    io_loop = IOLoop.current()
    timeout = io_loop.add_timeout(io_loop.time() + 10, "on_timeout")

    connector = _Connector(
        [(socket.AF_INET, ("127.0.0.1", "8888"))],
        lambda af, addr: (
            IOStream(socket.socket(af, socket.SOCK_STREAM, 0)),
            Future(),
        ),
    )
    connector.set_timeout(10)
    assert (
        connector.timeout is not None
    )  # Connector has no timeout attribute, but it is not None



# Generated at 2022-06-22 04:39:31.959621
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    from asyncio import get_event_loop
    from tornado.ioloop import IOLoop, PollIOLoop
    import socket
    import platform

    def test_clear_timeout():
        # type: () -> None
        io_loop = PollIOLoop()

        connector = _Connector(
            [(socket.AF_INET, ("127.0.0.1", 80))],
            lambda af, addr: (
                IOStream(socket.socket(af, socket.SOCK_STREAM), io_loop=io_loop),
                Future(),
            ),
        )

        connector.set_timeout(60)
        assert connector.timeout is not None
        connector.clear_timeout()
        assert connector.timeout is None
        io_loop.close(all_fds=True)

    test_clear_timeout()



# Generated at 2022-06-22 04:39:43.093752
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    import os
    import tornado

    from tornado.testing import gen_test

    from tornado.httpclient import AsyncHTTPClient

    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import AsyncIOMainLoop

    class FakeResolver(Resolver):
        def initialize(self, io_loop=None, resolver=None, **kwargs):
            if io_loop is not None:
                self.io_loop = io_loop
            else:
                self.io_loop = IOLoop.current()
            if resolver is not None:
                self.resolver = resolver
            else:
                self.resolver = self.io_loop.asyncio_loop.getaddrinfo
                self.resolver_hostname_cache_expiry = 60


# Generated at 2022-06-22 04:39:51.917264
# Unit test for constructor of class _Connector
def test__Connector():  # type: () -> None
    io_loop = IOLoop()
    io_loop.make_current()
    def connect(af, addr):  # type: ignore
        pass
    addrs = [(1, (1, 2, 3))]
    test = _Connector(addrs, connect)
    assert test.io_loop is io_loop
    assert test.connect == connect
    assert test.future is not None  # type: ignore
    assert test.timeout is None
    assert not isinstance(test.timeout, int)
    assert test.connect_timeout is None
    assert not isinstance(test.connect_timeout, int)
    assert test.last_error is None
    assert test.remaining == 1
    assert test.primary_addrs == addrs
    assert test.secondary_addrs == []
    assert test.stream