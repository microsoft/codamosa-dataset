

# Generated at 2022-06-22 04:30:22.842419
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    """
        Asserts that the method sets the exception on the future as TimeoutError
    """
    import unittest
    from tornado.testing import AsyncTestCase, get_unused_port
    from ...client import ConnWrapper
    from ...options import ClientOptions

    class TestConnector(AsyncTestCase):
        @gen.coroutine
        def _test(self, af):
            try:
                yield ConnWrapper.connect(self.io_loop, self.client_options, af)
            except TimeoutError:
                pass
            else:
                raise RuntimeError("Expected TimeoutError exception")

        @gen.coroutine
        def test_on_connect_timeout(self):
            self._test(socket.AddressFamily.AF_INET)
            self._test(socket.AddressFamily.AF_INET6)



# Generated at 2022-06-22 04:30:29.602462
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    def test_function():
        pass

    def mock_stream_close():
        pass

    stream_set = set()
    obj = _Connector(
        [],  # addrinfo
        test_function,
    )

    stream_set.add(mock_stream_close)
    obj.streams = stream_set
    obj.close_streams()
    stream_set.remove(mock_stream_close)
    assert obj.streams == stream_set
    assert obj.streams.__len__() == 0



# Generated at 2022-06-22 04:30:36.313434
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    conn = _Connector(
        [
            (socket.AF_INET, ("127.0.0.1", 3000)),
            (socket.AF_INET6, ("1:2:3:4:5:6:7:8", 3000)),
        ],
        lambda af, addr: (None, Future()),
    )
    future = conn.start(0.5)
    future.set_exception(TimeoutError())



# Generated at 2022-06-22 04:30:39.389976
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    conn = _Connector(
        addrinfo=list(),
        connect=lambda *args: (IOStream(socket.socket()), Future()),
    )
    conn.set_connect_timeout(connect_timeout=1)
    assert conn.connect_timeout is not None



# Generated at 2022-06-22 04:30:40.373981
# Unit test for constructor of class TCPClient
def test_TCPClient():
    TCPClient()

# Generated at 2022-06-22 04:30:53.576941
# Unit test for method clear_timeout of class _Connector
def test__Connector_clear_timeout():
    from tornado.testing import AsyncTestCase, bind_unused_port, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio

    class MyTCPClient(AsyncTestCase):
        def setUp(self):
            super().setUp()
            # 上面的setUp是必须的，否则下面的self.io_loop会报错。
            self.io_loop = self.new_ioloop(make_current=True)

        @gen.coroutine
        def get_sockname(self) -> Tuple[str, int]:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)

# Generated at 2022-06-22 04:31:02.524159
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    io_loop = IOLoop.current()
    connect = lambda af, addr: IOStream(socket.socket(af, socket.SOCK_DREAM), io_loop), Future()
    addrinfo = [
        (socket.AddressFamily.AF_INET, ("0.0.0.0", 1)),
        (socket.AddressFamily.AF_INET, ("0.0.0.0", 2)),
        (socket.AddressFamily.AF_INET, ("0.0.0.0", 3)),
        (socket.AddressFamily.AF_INET, ("0.0.0.0", 4)),
    ]
    class MockFuture1(Future):
        def __init__(self):
            super(MockFuture1, self).__init__()
        def result(self):
            return self

# Generated at 2022-06-22 04:31:03.994380
# Unit test for constructor of class TCPClient
def test_TCPClient():
    client = TCPClient()
    assert client.resolver is not None
    assert client._own_resolver is True


# Generated at 2022-06-22 04:31:15.499091
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    class Stream(IOStream):
        def __init__(self, *args, **kwargs):
            pass

        def close(self):
            pass

    class Future(object):
        def result(self):
            return Stream()

    class IOLoop(object):
        def time(self):
            return 0

        def add_timeout(self, *args, **kwargs):
            return object()

        def remove_timeout(self, *args, **kwargs):
            return object()

    streams = [Future(), Future()]
    connector = _Connector([], lambda *args, **kwargs: (object(), streams.pop()))
    connector.io_loop = IOLoop()

    connector.close_streams()



# Generated at 2022-06-22 04:31:21.159094
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    stream = object()  # type: Future[IOStream]
    connector = _Connector(
        addrinfo=[(socket.AddressFamily.AF_INET, ("0.0.0.0", 0))],
        connect=lambda af, addr: (stream, stream),
    )
    connector.set_connect_timeout(0.1)
    assert connector.connect_timeout is not None, "The value of connect_timeout should not be None."



# Generated at 2022-06-22 04:31:46.925875
# Unit test for constructor of class _Connector
def test__Connector():
    def connect(af, addr):
        f = Future()
        f.set_result(af)
        return f, f
    addrinfo = [
        (socket.AF_INET, (1, 2)),
        (socket.AF_INET6, (1, 2)),
        (socket.AF_INET, (1, 2)),
        (socket.AF_INET6, (1, 2)),
    ]
    a = _Connector(addrinfo, connect)
    a.start()
    assert a.future.result() == socket.AF_INET



# Generated at 2022-06-22 04:31:50.057527
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    c = _Connector(None, None)
    # test that when timeout is None, _Connector.on_timeout() doesn't attempt to
    # access it
    def do_nothing():
        pass
    c.timeout = None
    c.on_timeout()



# Generated at 2022-06-22 04:31:51.765891
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    obj = TCPClient()
    obj.close()

# Generated at 2022-06-22 04:32:01.641123
# Unit test for method split of class _Connector
def test__Connector_split():
    assert _Connector.split([]) == ([], [])
    assert _Connector.split([(socket.AF_INET, ("1.2.3.4", 1234))]) == (
        [(socket.AF_INET, ("1.2.3.4", 1234))],
        [],
    )
    assert _Connector.split(
        [(socket.AF_INET, ("1.2.3.4", 1234)), (socket.AF_INET, ("2.3.4.5", 2345))]
    ) == ([(socket.AF_INET, ("1.2.3.4", 1234)), (socket.AF_INET, ("2.3.4.5", 2345))], [])

# Generated at 2022-06-22 04:32:02.398921
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    tcp = TCPClient()
    tcp.close()

# Generated at 2022-06-22 04:32:10.150927
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    # Set up the test data
    io_loop = IOLoop.current()
    resolver = Resolver(io_loop=io_loop)
    resolver.configure('test', ['127.0.0.1'])
    connector = _Connector([(socket.AF_INET6, ('::1', 8080, 0, 0))], resolver.resolve)
    future = Future()
    future.add_done_callback(connector.on_connect_done)
    stream = IOStream(socket.socket(family=socket.AF_INET6, type=socket.SOCK_STREAM), io_loop)
    future.set_result(stream)

    # Perform the test
    assert future.done()
    assert stream.closed()




# Generated at 2022-06-22 04:32:11.290138
# Unit test for constructor of class _Connector
def test__Connector():
    _Connector([1, 2])
    _Connector([('a', 'b'), ('c', 'd'), 3])



# Generated at 2022-06-22 04:32:23.281008
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    import sys
    import random
    random.seed(0) # Reproducibility
    from tornado.testing import AsyncTestCase

    # Subclass to use a special ioloop so we can control time
    class TimerControlTest(AsyncTestCase):
        def get_new_ioloop(self):
            return TimeControl()

    # Subclass to control time
    class TimeControl(IOLoop):
        def time(self):
            return self._time

        def fake_time(self, time):
            self._time = time

    # Test case
    class MyTestCase(TimerControlTest):
        def test_on_connect_timeout(self):
            ioloop = TimeControl()
            def simple_connect(af, addr):
                future = Future()

# Generated at 2022-06-22 04:32:30.338689
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    
    @gen.coroutine
    def get_socket_info(host: str, port: int) -> Tuple[str, int]:
        """Gets the local address of a remote connection."""
        stream = yield TCPClient().connect(host, port, af=socket.AF_INET)
        socket = stream.socket
        stream.close()
        local_addr = socket.getsockname()
        local_port = socket.getsockname()[1]
        raise gen.Return((local_addr, local_port))

    # Test default source address selection
    loop = IOLoop.current()
    remote_addr = "127.0.0.1"
    remote_port = 8888
    remote_host = "www.google.com"

# Generated at 2022-06-22 04:32:37.423925
# Unit test for method start of class _Connector
def test__Connector_start():

    @gen.coroutine
    def f():
        af, _, stream = yield _Connector(
            [(socket.AF_INET, ("127.0.0.1", 80))], connect
        ).start()
        assert af == socket.AF_INET

    @gen.coroutine
    def connect(af: socket.AddressFamily, addr: Tuple) -> Tuple[IOStream, "Future[IOStream]"]:
        raise gen.Return((None, None))  # type: ignore

    f()



# Generated at 2022-06-22 04:33:06.962253
# Unit test for method start of class _Connector
def test__Connector_start():
    pass



# Generated at 2022-06-22 04:33:17.165986
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    io_loop = IOLoop.current()
    io_loop.add_callback = mock.Mock()
    addrinfo = [('Some_AddressFamily', 'Some_Tuple')]

    def connect(af, addr):
        return (
            IOStream(socket.socket(af, socket.SOCK_STREAM, 0)),
            Future(),
        )

    timeout = 3.0  # type: Union[float, datetime.timedelta]
    conn = _Connector(addrinfo, connect)
    result = conn.set_connect_timeout(timeout)
    assert conn.connect_timeout == conn.io_loop.add_timeout(
        timeout, conn.on_connect_timeout
    )
    assert result is None



# Generated at 2022-06-22 04:33:17.901477
# Unit test for constructor of class TCPClient
def test_TCPClient():
    t = TCPClient()
    return True

# Generated at 2022-06-22 04:33:26.149634
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    # Setup
    io_loop = IOLoop.current()
    future = Future()
    _Connector.future.set(future)
    _Connector.timeout = io_loop.add_timeout(io_loop.time() + _INITIAL_CONNECT_TIMEOUT, _Connector.on_timeout)
    sec = []
    _Connector.secondary_addrs = sec
    addrs = iter(sec)
    _Connector.try_connect = mock_try_connect

    # Exercise
    _Connector.on_timeout()

    # Verify
    assert _Connector.try_connect.called_with(addrs)

test__Connector_on_timeout()  # pragma: no cover



# Generated at 2022-06-22 04:33:31.860969
# Unit test for method split of class _Connector
def test__Connector_split():

    _connector = _Connector([(1, ("[::1]", 80)), (2, ("[::1]", 80))], None)

    result = _connector.split(
        [(1, ("[::1]", 80)), (2, ("[::1]", 80)), (1, ("[::1]", 80))]
    )

    assert result == ([(1, ("[::1]", 80)), (1, ("[::1]", 80))], [(2, ("[::1]", 80))])



# Generated at 2022-06-22 04:33:37.626444
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    # type: ()->None
    import time
    from tornado.testing import AsyncTestCase, gen_test

    from unittest import mock

    from .util import parse_hostport

    class ConnectorTest(AsyncTestCase):
        def setUp(self):
            # type: ()->None
            super(ConnectorTest, self).setUp()
            self.resolver = mock.Mock()
            self.stream = mock.Mock()
            self.client_connected = Future()
            self.stream.connect_future.add_done_callback(
                lambda f: self.client_connected.set_result(f.exception())
            )
            self.connect = mock.Mock()
            self.connect.return_value = self.stream, self.stream.connect_future
            self.io_loop = mock.Mock

# Generated at 2022-06-22 04:33:44.132607
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    # tcp_client = TCPClient()
    # port = 8888
    # host = "127.0.0.1"
    # af = socket.AF_UNSPEC
    # stream_rst = tcp_client.connect(host, port, af)
    # print(type(stream_rst))
    # print(stream_rst)
    pass

# Generated at 2022-06-22 04:33:49.242656
# Unit test for constructor of class TCPClient
def test_TCPClient():
    tcpclient = TCPClient()
    assert tcpclient.resolver is not None
    assert tcpclient._own_resolver is True
    # Test __init__ with a specific Resolver
    resolver = Resolver()
    tcpclient = TCPClient(resolver)
    assert tcpclient.resolver is not None

# Generated at 2022-06-22 04:33:53.920585
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    tester = _Connector
    assert tester.set_connect_timeout(1) is None
    assert tester.on_connect_timeout() is None
    assert tester.clear_timeouts() is None
    assert tester.close_streams() is None
    assert tester.__init__((1,2,3,4), object) is None
    



# Generated at 2022-06-22 04:34:02.143236
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    io_loop = IOLoop.current()
    io_loop_add_timeout = io_loop.add_timeout
    remaining = 2
    future = Future()
    try_connect = lambda addrs : None
    secondary_addrs = [1,2]
    timeout = None
    _Connector.on_timeout = _Connector.__init__(
    _Connector, [], try_connect).on_timeout
    _Connector.on_timeout()



# Generated at 2022-06-22 04:35:07.014428
# Unit test for constructor of class _Connector

# Generated at 2022-06-22 04:35:10.031517
# Unit test for method connect of class TCPClient
def test_TCPClient_connect():
    client = TCPClient()
    stream = client.connect("google.com", 443)
    print("Connecting from client")

if __name__ == "__main__":
    test_TCPClient_connect()

# Generated at 2022-06-22 04:35:17.862891
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    io_loop = IOLoop.current()
    loop_time = io_loop.time()
    addrinfo = [
        (socket.AF_INET, (1, 2)),
        (socket.AF_INET, (3, 4)),
        (socket.AF_INET, (5, 6)),
    ]
    future = Future()
    future.set_result(1)
    connect = lambda af, addr: (1, future)
    connector = _Connector(addrinfo, connect)
    # test with nothing in addrlist
    primary_addrs = [
        (socket.AF_INET, (1, 2)),
        (socket.AF_INET, (3, 4)),
        (socket.AF_INET, (5, 6)),
    ]
    secondary_addrs = []
    connector.primary_add

# Generated at 2022-06-22 04:35:23.147575
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    addrinfo = [(socket.AF_INET, ('127.0.0.1', 80)),
                (socket.AF_INET, ('127.0.0.2', 80))]
    def connect(af, addr):
        return IOStream(socket.socket(af, socket.SOCK_STREAM)), Future()
    _connector = _Connector(addrinfo, connect)
    assert _connector.set_connect_timeout(2) is None

# Generated at 2022-06-22 04:35:34.849026
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    io_loop = IOLoop.current()

    # stubs
    class IOStreamStub:
        def __init__(self, io_loop=io_loop):
            self.io_loop = io_loop
            self.closed = False
        def close(self):
            self.closed = True
        def is_closed(self):
            return self.closed

    class IOLoopStub:
        def __init__(self):
            self.time = 0

        def add_timeout(self, timeout, callback):
            return timeout

        def remove_timeout(self, timeout):
            pass

    ioloop = IOLoopStub()
    io_loop = ioloop

    def connect(af, addr):
        stream = IOStreamStub(io_loop)
        future = Future()
        future.set_

# Generated at 2022-06-22 04:35:40.862027
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    instance = _Connector(
    [],
    lambda af, addr: (
        IOStream(socket.socket(af, socket.SOCK_STREAM)),
        Future()
    )
    )
    instance.future = Future()
    instance.remaining = 1
    instance.try_connect = MagicMock(return_value=None)

    instance.on_timeout()

    assert instance.timeout is None
    assert instance.try_connect.called



# Generated at 2022-06-22 04:35:46.265654
# Unit test for constructor of class _Connector
def test__Connector():
    assert _Connector(
        [
            (socket.AF_INET, ("127.0.0.1", 80)),
            (socket.AF_INET6, ("::1", 80)),
        ],
        lambda af, addr: (None, Future()),
    ) is not None



# Generated at 2022-06-22 04:35:58.551543
# Unit test for method set_connect_timeout of class _Connector
def test__Connector_set_connect_timeout():
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import functools
    import ssl

    asyncio.set_event_loop(None)
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    io_loop = tornado.ioloop.IOLoop.current()

    def f(n):
        f = Future()
        # TODO: Use TimeoutError
        io_loop.add_timeout(n, f.set_exception, Exception())
        return f
    # Testing successful connection
    c = _Connector([(socket.AF_INET, ("localhost", 0))], f)
    c.set_connect_timeout(0.3)
    f = c.start()
    io_loop.add_callback(io_loop.stop)
    io_loop

# Generated at 2022-06-22 04:36:10.999717
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    stream = IOStream(socket.socket())
    class _io_loop_Mock:
        def add_timeout(self, _1, _2):
            return "timeout"
        def remove_timeout(self, _):
            pass
    io_loop = _io_loop_Mock()
    class stream_Mock:
        def close(self):
            pass
    class _Future_Mock:
        def result(self):
            return stream_Mock()
        def done(self):
            return False
    future = _Future_Mock()
    connector = _Connector(
        [],
        lambda _, __: (stream, future),
    )
    connector.io_loop = io_loop
    connector.timeout = "timeout"
    connector.connect_timeout = "timeout"

# Generated at 2022-06-22 04:36:12.038821
# Unit test for constructor of class TCPClient
def test_TCPClient():
    tcpclient = TCPClient()
    assert tcpclient._own_resolver == True

# Generated at 2022-06-22 04:38:05.814303
# Unit test for method on_connect_timeout of class _Connector
def test__Connector_on_connect_timeout():
    c = _Connector([], None)
    assert c.future.done() == False
    c.on_connect_timeout()
    assert c.future.done() == True
    assert c.future.exception() == TimeoutError()

# Generated at 2022-06-22 04:38:17.664849
# Unit test for method on_connect_done of class _Connector
def test__Connector_on_connect_done():
    def mocked_set_result(future: "Future[IOStream]", x: Any) -> None:
        print("mocked set_result function")
        pass

    def mocked_on_connect_done(object, addrs: Iterator[Tuple[int, tuple]], af: int, addr: tuple, future: "Future[IOStream]"):
        return object.on_connect_done(addrs, af, addr, future)

    def mocked_gen_test(object):
        # Simulate return of type Future
        mocked_future = Future()
        mocked_future.set_result("mocked_stream")
        mocked_gen_test.call_count += 1
        return mocked_future

    mocked_gen_test.call_count = 0
    mocked_resolver = Resolver()
    # Simulate call to addrinfo of method _

# Generated at 2022-06-22 04:38:19.368343
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    __connector = _Connector(0, 0)
    assert __connector.timeout is None
    assert __connector.connect_timeout is None



# Generated at 2022-06-22 04:38:20.660603
# Unit test for method close_streams of class _Connector
def test__Connector_close_streams():
    pass



# Generated at 2022-06-22 04:38:25.108872
# Unit test for method set_timeout of class _Connector
def test__Connector_set_timeout():
    '''
    Test method set_timeout of class _Connector
    '''
    # Test method set_timeout with given data
    timeout = 0.3
    connector = _Connector([], None)
    connector.set_timeout(timeout)
    assert connector.timeout is not None


# Generated at 2022-06-22 04:38:36.244610
# Unit test for method clear_timeouts of class _Connector
def test__Connector_clear_timeouts():
    #Test if clear_timeouts() can be called without any timeout
    c = _Connector(None, None)
    c.clear_timeouts()
    #Test if clear_timeouts() can be called after a timeout has been set
    c = _Connector(None, None)
    c.set_connect_timeout(5)
    c.clear_timeouts()
    #Test if clear_timeouts() can be called after a timeout has been set and removed
    c = _Connector(None, None)
    c.set_connect_timeout(5)
    c.clear_timeouts()
    c.clear_timeouts()
    #Test if clear_timeouts() can be called after a timeout has been set and removed and another set
    c = _Connector(None, None)
    c.set_connect_timeout(5)

# Generated at 2022-06-22 04:38:38.315104
# Unit test for method close of class TCPClient
def test_TCPClient_close():
    resolver = Resolver()
    obj = TCPClient(resolver=resolver)
    obj.close()


# Generated at 2022-06-22 04:38:39.724879
# Unit test for method try_connect of class _Connector
def test__Connector_try_connect():
    pass # test for try_connect ... Finished



# Generated at 2022-06-22 04:38:50.204267
# Unit test for method split of class _Connector
def test__Connector_split():
    # negative test

    # positive test
    addrinfo = (
        (socket.AF_INET, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
        (socket.AF_INET6, ("127.0.0.1", 80)),
    )
    result = _Connector.split(addrinfo)
    assert result == ([(socket.AF_INET, ("127.0.0.1", 80))], [(socket.AF_INET6, ("127.0.0.1", 80)), (socket.AF_INET6, ("127.0.0.1", 80))])



# Generated at 2022-06-22 04:38:53.686315
# Unit test for method on_timeout of class _Connector
def test__Connector_on_timeout():
    #
    # def on_timeout(self):
    #     self.timeout = None
    #     if not self.future.done():
    #         self.try_connect(iter(self.secondary_addrs))
    #

    assert False, "Unimplemented"

