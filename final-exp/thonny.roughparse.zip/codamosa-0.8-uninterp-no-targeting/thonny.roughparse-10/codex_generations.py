

# Generated at 2022-06-22 03:17:10.710074
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from idlelib import hyperparser

    text = Text()
    text.insert(END, "a = ''")
    hp = hyperparser.HyperParser(text)
    test_cases = [(0, 0), (2, 0), (3, 1), (4, 1), (5, 1), (6, 2), (7, 2), (8, 3)]
    for test_case, result in test_cases:
        text.mark_set(INSERT, test_case)
        hp.set_index(INSERT)
        if hp.indexbracket != result:
            return False
    return True


# Generated at 2022-06-22 03:17:18.266372
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(tuple(mapping.__iter__())) == len(whitespace_chars)



# Generated at 2022-06-22 03:17:25.190668
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-22 03:17:32.270799
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    test_dict = {ord('s'): ord('c'), ord('x'): ord('y')}
    mapping = StringTranslatePseudoMapping(test_dict, ord('z'))
    assert mapping.get(ord('s')) == ord('c')
    assert mapping.get(ord('k')) == ord('z')
    assert mapping.get(ord('k'), ord('z')) == ord('z')


# Generated at 2022-06-22 03:17:45.107174
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    s = "a=a+b+(c+(d+(e+f)))+g+h\n"
    hp = HyperParser(Tkinter.Text(), 0)
    hp.text = s
    hp.rawtext = s
    hp.stopatindex = "7.0"
    hp.bracketing = [(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0), (7, 1), (8, 1), (9, 1), (10, 2), (11, 3), (12, 3), (13, 2), (14, 1), (15, 1), (16, 1), (17, 1), (18, 1), (19, 0), (20, 0), (21, 0)]

# Generated at 2022-06-22 03:17:53.443395
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    h = HyperParser(
        Text(
            """# Eat a comment
        if True:
            def f(z=[]):
                pass
            f(z=(1,2,3))
        """
        ),
        "insert",
    )
    h.get_expression()
    global test_count, failed_tests
    test_count += 1
    if h.get_surrounding_brackets() == ("10.25", "10.36"):
        print("passed", end=" ")
    else:
        print("FAILED", end=" ")
        failed_tests.append(test_count)
    print("test case for def f(z=[]):")

    h.set_index("11.4")

# Generated at 2022-06-22 03:18:07.902817
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    # pylint: disable=redefined-builtin
    # pylint: disable=invalid-name

    def get_num_lines_in_stmt(text):
        return RoughParser(text).get_num_lines_in_stmt()

    assert get_num_lines_in_stmt("foo\n") == 1
    assert get_num_lines_in_stmt("foo") == 1
    assert get_num_lines_in_stmt("foo\nbar") == 1
    assert get_num_lines_in_stmt("foo\\\nbar") == 2
    assert get_num_lines_in_stmt("foo\\\nbar\\\nbaz") == 3
    assert get_num_lines_in_stmt('foo\nbar\\\nbaz') == 1
    assert get_num

# Generated at 2022-06-22 03:18:19.386857
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    parser = RoughParser('class C:\n    pass')
    assert parser.is_block_opener()
    parser = RoughParser('def f(): pass')
    assert parser.is_block_opener()
    parser = RoughParser('if True: pass')
    assert parser.is_block_opener()
    parser = RoughParser('elif True: pass')
    assert parser.is_block_opener()
    parser = RoughParser('while True: pass')
    assert parser.is_block_opener()
    parser = RoughParser('for i in []: pass')
    assert parser.is_block_opener()
    parser = RoughParser('try: pass')
    assert parser.is_block_opener()
    parser = RoughParser('except: pass')
    assert parser.is_block_opener()
    parser = Rough

# Generated at 2022-06-22 03:18:24.583549
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=expression-not-assigned
    from lib2to3.pgen2 import token
    parser = RoughParser()
    parser.set_str("if foo:\\\n        bar()")
    parser.get_continuation_type() == token.INDENT

# Generated at 2022-06-22 03:18:37.390996
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import unittest
    import unittest.mock

    class EditorMock(object):
        def __init__(self, chars):
            """Create a text type which gives the given chars on
            get("1.0", "end") instead of the whole text.
            """
            self.text = chars

        def get(self, index1, index2):
            if index2 == "end":
                # We don't handle tabs here.
                return self.text[len(index1) :]
            raise ValueError("get got args %s %s and could only" "handle end" % (index1, index2))

    # A HyperParser object can be created only from a Text object.
    # Since we don't create one, we mock the methods of a Text object
    # which are used by HyperParser.

# Generated at 2022-06-22 03:19:11.372317
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    return None


# Generated at 2022-06-22 03:19:23.735198
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    chars_to_preserve = ' \t\n\r'
    chars_to_replace = '-+'
    preserve_dict = {ord(c): ord(c) for c in chars_to_preserve}
    replacement_dict = {ord(c): ord('x') for c in chars_to_replace}
    mapping = {}
    mapping.update(preserve_dict)
    mapping.update(replacement_dict)
    mapping = StringTranslatePseudoMapping(mapping, default_value=ord('x'))

    assert mapping[ord(' ')] == ord(' ')
    assert mapping[ord('\t')] == ord('\t')
    assert mapping[ord('\n')] == ord('\n')
    assert mapping[ord('\r')] == ord('\r')

# Generated at 2022-06-22 03:19:33.377085
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    print('Running test_RoughParser_compute_backslash_indent...')
    rp = RoughParser()
    rp.set_str('def f():\n   a=b\\\n   c=d')
    res = 4
    assert rp.compute_backslash_indent() == res, \
        'compute_backslash_indent must return %s, but returns %s' % (res, rp.compute_backslash_indent())
    print('Done running test_RoughParser_compute_backslash_indent')



# Generated at 2022-06-22 03:19:41.296134
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    test_cases = (
        ("a = 1", False),
        ("a = {", True),
        ("a = 1", False),
        ("a = {", True),
    )
    for stmt, expected_result in test_cases:
        parser = RoughParser(stmt)
        result = parser.is_block_opener()
        assert result == expected_result, (stmt, expected_result, result)
    print("test is_block_opener OK")



# Generated at 2022-06-22 03:19:42.280192
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-22 03:19:52.478626
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'

# Table mapping each char to its syntactic significance.

_syntactic_chars = (
    """()[]{}:.,"""
    + """'`"""
    + """+=|-&*/%<>^~#"""
    + """!@"""
)

_syntactic_map = {ord(c): c for c in _syntactic_chars}
_syntactic_translation = str.m

# Generated at 2022-06-22 03:20:03.744074
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def _test_hyper_parser(text, index, expected_expr, msg=None):
        hp = HyperParser(text, index)
        if hp.get_expression() != expected_expr:
            raise AssertionError(
                "get_expression on %s gives %s and not %s"
                % (msg or repr(text), repr(hp.get_expression()), repr(expected_expr))
            )

    # Empty string
    _test_hyper_parser("", "1.0", "")

    # String with only white space
    _test_hyper_parser(" \t\n", "1.0", "")

    # String with only a comment
    _test_hyper_parser("# comment", "1.0", "")

    # String with only a following comment

# Generated at 2022-06-22 03:20:12.372123
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    RP = RoughParser()
    RP.set_str("foo(a, b)\n")
    assert not RP.is_block_closer()
    RP.set_str("f = foo(a, b)\n")
    assert not RP.is_block_closer()
    RP.set_str("return foo(a, b)\n")
    assert not RP.is_block_closer()
    RP.set_str("break")
    assert not RP.is_block_closer()
    RP.set_str("continue")
    assert not RP.is_block_closer()
    RP.set_str("pass")
    assert not RP.is_block_closer()
    RP.set_str("raise foo(a, b)")
    assert not RP.is_block_closer()
    RP.set

# Generated at 2022-06-22 03:20:21.367521
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # Test case 0
    text = ScrolledText.ScrolledText(None, width=60, height=20, wrap="none")
    # text <class 'ScrolledText.ScrolledText'>
    text.pack(expand=1, fill="both")
    text.insert("insert", """\
# Test case 0
while 1:
    print(1)
    print(2)
    print(3)
""")
    # self.text <hyperparser.ScrolledText.ScrolledText object .!scrolledtext>
    self = HyperParser(text, "4.8")
    if not self.isopener[0] or self.rawtext[self.bracketing[0][0]] in "# \n":
        text.insert("insert", "test_HyperParser_set_index(): test case 0 failed.\n")


# Generated at 2022-06-22 03:20:33.530563
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest
    from idlelib.idle_test.htest import run

    class TestConstructor(unittest.TestCase):
        def test_index_precedes_statement(self):
            with self.assertRaises(ValueError):
                HyperParser(index="1.0")
        text = Text(None, "")
        text.insert("1.0", "def f(x):\n    pass\n")
        text.insert("3.0", "print('hi')")
        text.insert("3.end", "\n")

        def test_init(self):
            hp = HyperParser(self.text, "3.2")
            self.assertEqual(hp.stopatindex, "3.end")
            self.assertEqual(hp.rawtext, "print('hi') \n")


# Generated at 2022-06-22 03:22:20.143180
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-22 03:22:24.354898
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # Test that a RoughParser object is properly initialized from
    #  a rough-parsed string.

    rp = RoughParser("if 1:\n    a=1\n    b=2", 8, 0)
    assert rp.str == "if 1:\n    a=1\n    b=2"
    assert rp.indent_width == 8
    assert rp.tabwidth == 0
    assert rp.goodlines == [0, 4, 10]
    assert rp.study_level == 0

    rp = RoughParser("if 1:\n    a=1\n    b=2", 4, 4)
    assert rp.str == "if 1:\n    a=1\n    b=2"
    assert rp.indent_width == 4
    assert rp.tabwidth == 4
   

# Generated at 2022-06-22 03:22:31.963385
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    assert mapping[ord("a")] == ord("x")
    assert mapping[ord("d")] == ord("x")
    assert mapping[ord("\n")] == ord("\n")
    assert mapping[ord("\t")] == ord("\t")



# Generated at 2022-06-22 03:22:43.985553
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    assert RoughParser("def f(a,\n b): pass\n").compute_bracket_indent() == 0
    assert RoughParser("def f(\n a,\n b): pass\n").compute_bracket_indent() == 0
    assert RoughParser("def f(\n a,\n b):\n pass\n").compute_bracket_indent() == 4
    assert RoughParser("def f(\n a,\n b):\n pass\n").compute_bracket_indent() == 4
    assert RoughParser("def f(\n a,\n b):\n").compute_bracket_indent() == 4
    assert RoughParser("def f(a,\n b,\n").compute_bracket_indent() == 4

# Generated at 2022-06-22 03:22:53.401118
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def try_HyperParser_get_surrounding_brackets(text, index, expected):
        hyper = HyperParser(text, index)
        try:
            result = hyper.get_surrounding_brackets()
        except ValueError:
            result = None
        if result != expected:
            raise RuntimeError(
                "get_surrounding_brackets(..%s.., %s)=%s, but "
                "should be %s" % (repr(text.string), index, result, expected)
            )

    from tkinter.scrolledtext import ScrolledText

    text = ScrolledText(Tk())
    text.pack()
    text.insert(INSERT, "1234567890abcdef")
    text.config(state=DISABLED)


# Generated at 2022-06-22 03:23:05.099490
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    """The index of the last open bracket ({[ in the last stmt"""
    # TODO: This only runs if you run the whole module, not if you
    # TODO: run pycodestyle.
    import doctest
    doctest.testmod()
    # tests = [
    #     ('', None),
    #     ('   ', None),
    #     ('x = 1', None),
    #     ('if 1:\n  pass', None),
    #     ('if 1:\n  def f():\n    pass', None),
    #     ('if 1:\n  def f():\n    pass\n  x', None),
    #     ('def f():\n  pass', None),
    #     ('def f():\n  return \\', 3),
    #     ('if 1:\n  def f():\n   

# Generated at 2022-06-22 03:23:10.093557
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-22 03:23:15.016877
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    """RoughParser_set_str"""
    RoughParser = RoughParser()
    RoughParser.set_str('if 1:\n    def x():\n        pass')
    print(RoughParser.get_base_indent_string())
    return 0


# Generated at 2022-06-22 03:23:19.603338
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    white_space = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in white_space}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    assert mapping.get(ord("a"), ord("q")) == ord("x")
    assert mapping.get(ord("\t"), ord("q")) == ord("\t")


# [XX] These functions should all be instance methods of class HyperParser.


# Generated at 2022-06-22 03:23:21.138722
# Unit test for method is_in_string of class HyperParser