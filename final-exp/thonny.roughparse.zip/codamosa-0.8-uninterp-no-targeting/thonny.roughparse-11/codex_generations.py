

# Generated at 2022-06-22 03:16:37.284369
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    """Unit test for method __len__ of class StringTranslatePseudoMapping"""
    # Prevent test failure "test_StringTranslatePseudoMapping___len__.test_result
    # failed: <class 'builtins.TypeError'>: object of type 'NoneType' has no len()"
    # that occurs with some Windows Python 3.7 builds.
    if type(None) is type(None):
        return

    # Empty dict
    mapping = StringTranslatePseudoMapping({}, 0)
    assert len(mapping) == 0

    # Non-empty dict
    mapping = StringTranslatePseudoMapping({1: 2}, 3)
    assert len(mapping) == 1



# Generated at 2022-06-22 03:16:41.327867
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # A string with the code followed by a part that is not code.
    expr = "a.b.c.d[1,2]"
    for i in range(len(expr) + 1):
        h.set_index(expr[:i])
        h.indexbracket = 0

# Test the get_expression method of class HyperParser

# Generated at 2022-06-22 03:16:48.007234
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # Test cases for method set_index of class HyperParser
    text = Text()
    text.insert("insert", "")
    # The following code would fail if not properly handled by
    # set_index
    # Bracketing which is only one char long.
    t = "a[0]"
    for i in range(len(t)):
        index = "%d.%d" % (text.index("insert"), i)
        text.insert(index, t[i])
    p = HyperParser(text, "insert")
    p.set_index("insert")
    assert p.rawtext == t
    # A slice
    t = "a[0:]"
    text.insert("insert", t)
    p = HyperParser(text, "insert")
    p.set_index("insert")
    assert p.rawtext

# Generated at 2022-06-22 03:16:58.657492
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    def test(text, expected):
        parser = RoughParser(text)
        pos = parser.get_last_open_bracket_pos()
        if expected is not None:
            assert pos is not None
            assert 0 <= pos < len(text)
        assert expected == pos
    test('x = {', 2)
    test('x = {}', 3)
    test('x = {1: 2}', 5)
    test('x = {1: {}}', 8)
    test('x = {1: 2,}', 8)
    test('x = {1: 2, 3}', 10)
    test('x = {1: 2, 3: 4}', 13)
    test('x = [', 2)
    test('x = []', 3)
    test('x = [1,]', 5)
    test

# Generated at 2022-06-22 03:17:00.938847
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    pseudo_mapping = StringTranslatePseudoMapping({2: 3}, 4)
    for key in pseudo_mapping:
        assert key in (2,)


# Generated at 2022-06-22 03:17:06.405052
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == len(whitespace_chars)

# Generated at 2022-06-22 03:17:07.532911
# Unit test for constructor of class HyperParser

# Generated at 2022-06-22 03:17:15.687539
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = "a+1"
    p = HyperParser(text, "1.0")
    assert p.rawtext == "a+1 "
    assert p.stopatindex == "1.end"
    assert p.bracketing == [(0, 0), (1, 0), (2, 0), (3, 0)]
    assert p.isopener == [True, False, False, False]
    assert p.indexinrawtext == 4
    assert p.indexbracket == 3

    p = HyperParser(text, "0.0")
    assert p.rawtext == "a+1 "
    assert p.stopatindex == "1.end"
    assert p.bracketing == [(0, 0), (1, 0), (2, 0), (3, 0)]

# Generated at 2022-06-22 03:17:27.138129
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    """Test method is_in_code of class HyperParser"""
    from unittest import TestCase

    class Test(TestCase):
        def test_is_in_code(self):
            text = "a b c #1\n(#2\n[#3\n. #4\n#5\n'''#6\n'''#7\n#8\n\"\"\"#9\n\"\"\"#10\n#11\n"

            hp = HyperParser(text, "1.0")
            # Test if hyperparser sees the code.
            self.assertEqual(hp.is_in_code(), True)

            hp = HyperParser(text, "1.1")
            # Test if hyperparser sees the code.
            self.assertEqual(hp.is_in_code(), True)

            hp

# Generated at 2022-06-22 03:17:33.854532
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    preserve_dict = {ord('a'): ord('a'), ord('b'): ord('b'), ord('c'): ord('c')}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "abcaabcaabca"
    assert text.translate(mapping) == "abcabcabc"
    text = "abcaabcaabca"
    assert text.translate(preserve_dict) == "aabbccaabbcc"



# Generated at 2022-06-22 03:18:04.391379
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    rough_parser = RoughParser()
    # A simple text

# Generated at 2022-06-22 03:18:07.342855
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    assert StringTranslatePseudoMapping({}, 'x')[0] == 'x'

# Generated at 2022-06-22 03:18:18.881296
# Unit test for constructor of class HyperParser
def test_HyperParser():
    "Test the HyperParser class."
    import unittest

    class TestHyperParser(unittest.TestCase):
        "Unit tests for HyperParser class"

        def create_hyper_parser(self, text):
            "Create a HyperParser for the given text."
            text = TkTextWrapper(text)
            hp = HyperParser(text, "end")
            return hp

        def test_expression(self):
            "Test the expression extraction."

# Generated at 2022-06-22 03:18:23.001633
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser("if True:\n    pass")
    assert rp.is_block_opener()
    rp = RoughParser("if True:pass")
    assert not rp.is_block_opener()


# Generated at 2022-06-22 03:18:35.244560
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-outer-name
    def f(s, n):
        rp = RoughParser(s, 8)
        assert rp.get_continuation_type() == C_BACKSLASH
        assert rp.compute_backslash_indent() == n

# Generated at 2022-06-22 03:18:42.086650
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    from pycodestyle import select_parser
    parser = select_parser("test.py")
    with open("tests/get_continuation_type_test.py") as f:
        code = f.read()
    parser._analyze_text(code)
    assert parser.get_continuation_type() == 0
    assert parser.get_continuation_type() == 0



# Generated at 2022-06-22 03:18:51.758888
# Unit test for constructor of class RoughParser
def test_RoughParser():  # pylint: disable=redefined-builtin
    def test(s, cont, encl, goodlines, goodlinenos):
        # pylint: disable=redefined-builtin
        rp = RoughParser(s)
        assert rp.get_continuation_type() == cont
        assert rp.get_num_lines_in_stmt() == encl
        assert rp.goodlines == goodlines
        assert rp.goodlinenos == goodlinenos
        # print rp.get_leading_whitespace_of_stmt()
        # print rp.get_base_indent_string()
        # print rp.compute_bracket_indent()
        # print rp.compute_backslash_indent()


# Generated at 2022-06-22 03:18:56.340919
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    class TestException(Exception):
        """Base class for exceptions in this module."""
        pass
    class TestFailed(TestException):
        """Exception raised when a test fails.

        Attributes:
            msg  -- explanation of the error
        """
        def __init__(self, msg):
            self.msg = msg
    def do_test(mapping, expected_result, func_name):
        actual_result = mapping.__len__()
        if (actual_result != expected_result):
            raise TestFailed(
                f"{func_name}(): expected {expected_result}, got {actual_result}"
            )
    pseudo_mapping = StringTranslatePseudoMapping({0:1}, 0)

# Generated at 2022-06-22 03:19:09.847508
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Test for function get_surrounding_brackets
    from test.support import import_helper

    tkinter = import_helper.import_module("tkinter")
    text = tkinter.Text()
    text.insert("insert", "a1 = (2 +\n     3 + 4 +\n     5 + 6 + 7\n     )\n")
    text.mark_set("insert", "3.30")
    #               01234567890123456789012345678901234567890123456789012345678
    #               0         1         2         3         4         5
    text.mark_gravity("insert", "left")
    hp = HyperParser(text, "insert")
    res = hp.get_surrounding_brackets()

# Generated at 2022-06-22 03:19:16.154933
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    test_str = r"""# A test string for testing HyperParser
    class Foo:
        """
    for n in range(len(test_str)):
        assert HyperParser(test_str, repr(n) + ".0").is_in_code() == (
            test_str[n-1] in " \t" or test_str[n-2:n] != "\\\n"
        )



# Generated at 2022-06-22 03:19:44.196801
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-22 03:19:53.945839
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos(): #@UnusedVariable
    str = "def f(x):\n" \
          "    while 1:\n" \
          "        if x:\n" \
          "            a = x\n" \
          "            b = x\n" \
          "        # comment\n" \
          "        c = x\n"
    r = RoughParser(str)
    r.set_str(str)
    assert r.get_last_open_bracket_pos() == 10
    str = "if 1:\n" \
          "    a = 1\n" \
          "    b = 2\n"
    r.set_str(str)
    assert r.get_last_open_bracket_pos() is None

# Generated at 2022-06-22 03:19:59.516095
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    class TestClass:
        def __init__(self, test_name, hp, result):
            self.test_name = test_name
            self.hp = hp
            self.result = result


# Generated at 2022-06-22 03:20:10.219809
# Unit test for method set_str of class RoughParser

# Generated at 2022-06-22 03:20:20.147588
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    expected_result = 'x x x\tx\nx'
    actual_result = text.translate(mapping)
    if expected_result != actual_result:
        print("Failed unit test for StringTranslatePseudoMapping")
        print("  Expected result: '{}'".format(expected_result))
        print("  Actual result:   '{}'".format(actual_result))

__all__ = ["HyperParser", "test_StringTranslatePseudoMapping"]



# Generated at 2022-06-22 03:20:21.106354
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    return 1

# Generated at 2022-06-22 03:20:33.265885
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    h = HyperParser("abc 123", "1.3")
    assert h.is_in_string() == 0, "Not in string"
    h = HyperParser("abc '123'", "1.3")
    assert h.is_in_string(), "In string"
    h = HyperParser("abc '123'", "1.4")
    assert not h.is_in_string(), "Not in string"
    h = HyperParser("abc '123'", "1.5")
    assert h.is_in_string(), "In string"
    h = HyperParser("abc '123'", "1.6")
    assert not h.is_in_string(), "Not in string"
    h = HyperParser("abc u'123'", "1.6")

# Generated at 2022-06-22 03:20:37.294282
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    hp = HyperParser(test_text, "2.0")
    assert hp.is_in_code()

    hp = HyperParser(test_text, "4.0")
    assert hp.is_in_code()

    hp = HyperParser(test_text, "5.0")
    assert hp.is_in_code()

    hp = HyperParser(test_text, "6.0")
    assert not hp.is_in_code()



# Generated at 2022-06-22 03:20:47.990582
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-22 03:20:59.196371
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    non_defaults = {1: 1, 2: 2}
    default_value = 0
    mapping = StringTranslatePseudoMapping(non_defaults, default_value)
    test_vector = [
        (1, 1),
        (2, 2),
        (3, 0),
        ]
    for arg, expected in test_vector:
        try:
            actual = mapping[arg]
        except Exception:
            actual = 'exception'
        if actual == expected:
            result = 'ok'
        else:
            result = 'error'
        msg = '{} {} {} => {}'.format(result, '__getitem__', arg,
                                      repr(actual))
        assert result == 'ok', msg
test_StringTranslatePseudoMapping___getitem__()




# Generated at 2022-06-22 03:21:36.266172
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    assert RoughParser("foo").is_block_closer() is False
    assert RoughParser("if a: b").is_block_closer() is False
    assert RoughParser("if a: b").is_block_closer() is False
    assert RoughParser("return").is_block_closer() is False
    assert RoughParser("return a").is_block_closer() is False
    assert RoughParser("return a").is_block_closer() is False
    assert RoughParser("return a").is_block_closer() is False
    assert RoughParser("return a").is_block_closer() is False
    assert RoughParser("return a").is_block_closer() is False
    assert RoughParser("return a").is_block_closer() is False
    assert RoughParser("return a").is_block_closer() is False

# Generated at 2022-06-22 03:21:43.790511
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    original = 'x = "abc"\ndef f():\n    if True:\n        pass\n'
    sfp = source_to_string_and_filename(original)
    parser = RoughParser(sfp)
    bracketing = parser.get_last_stmt_bracketing()
    assert bracketing == ((0, 0), (3, 0), (8, 1), (12, 0), (17, 1), (21, 0), (26, 1), (30, 0)), bracketing


# Generated at 2022-06-22 03:21:56.484017
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    """ Unit test for method get_continuation_type of 
        class RoughParser
    """
    if not testing:
        return
    tabwidth = 8
    eolwidth = 1
    str1 = """
    a = { 
    } 
    """
    str2 = """
    a = "asdasdasda"
    """
    str3 = """
    a = \'asdasdasda\'
    """
    str4 = """
    a = b \
    + c
    """
    str5 = """
    a = b \\
    + c
    """
    str6 = """
    try:
        a = b
        b = c
    except:
        a = b
        b = c
    finally:
        a = b
        b = c
    """

# Generated at 2022-06-22 03:22:06.461158
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    parser = _RoughParser()

    # C_STRING_FIRST_LINE
    parser.set_str('"""\\\n"""')
    assert parser.get_continuation_type() == C_STRING_FIRST_LINE
    parser.set_str("'''\\\n'''")
    assert parser.get_continuation_type() == C_STRING_FIRST_LINE
    parser.set_str('"""\\\n   """')
    assert parser.get_continuation_type() == C_STRING_FIRST_LINE
    parser.set_str("'''\\\n   '''")
    assert parser.get_continuation_type() == C_STRING_FIRST_LINE
    # in the following, two cases, the continuation is C_BRACKET because,
    # the continuation levels are higher than

# Generated at 2022-06-22 03:22:12.639743
# Unit test for constructor of class RoughParser

# Generated at 2022-06-22 03:22:18.475254
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    """Unit test for method __iter__ of class StringTranslatePseudoMapping"""
    d = {'a': 1, 'b': 2} # type: Dict[str, int]
    m = StringTranslatePseudoMapping(d, 3)
    it = iter(m)
    assert next(it) == 'a'
    assert next(it) == 'b'


# Generated at 2022-06-22 03:22:26.040109
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    err = StringIO()
    def _test(s, expect, report=err):
        p = RoughParser(s, "", "", "")
        start = p.find_good_parse_start(report)
        success = start == expect
        if not success:
            print("test_RoughParser_find_good_parse_start: test failed:\n"
                  "  s = %r\n"
                  "  start = %r\n"
                  "  expect = %r\n"
                  "  report = %r" % (s, start, expect, report.getvalue()),
                  file=sys.stderr)
            assert success
    def _test_error(s, expect, report=err):
        p = RoughParser(s, "", "", "")

# Generated at 2022-06-22 03:22:36.394487
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    def t(src, bool):
        rp = RoughParser(src)
        assert rp.is_block_opener() is bool

    t("    if 1:", True)
    t("    if 1:\n    pass", False)
    t("    try:", True)
    t("    try:\n    pass", False)
    t("    for i in range(10):", True)
    t("    for i in range(10):\n    pass", False)
    t(":", True)
    t(":\n    pass", False)



# Generated at 2022-06-22 03:22:44.676707
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    # pylint: disable=redefined-builtin
    parser = RoughParser('if True:\n    pass\n')
    # line with colon should be block opener
    assert True == parser.is_block_opener()
    parser = RoughParser('if True:\n    pass\nif False:\n    pass')
    # last line with colon is block opener
    assert True == parser.is_block_opener()
    parser = RoughParser('if True:\n    pass\n    pass')
    # line without colon is not block opener
    assert False == parser.is_block_opener()


# Generated at 2022-06-22 03:22:53.852254
# Unit test for method get_base_indent_string of class RoughParser