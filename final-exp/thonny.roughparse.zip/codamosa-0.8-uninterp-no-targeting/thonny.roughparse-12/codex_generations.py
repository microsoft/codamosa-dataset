

# Generated at 2022-06-22 03:16:35.311218
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    non_defaults = {ord('a'): ord('z'), ord('b'): ord('x')}
    default_value = ord('y')
    mapping = StringTranslatePseudoMapping(non_defaults, default_value)
    assert mapping.get(ord('a')) == ord('z')
    assert mapping.get(ord('b')) == ord('x')
    assert mapping.get(ord('c')) == ord('y')
    assert mapping.get(ord('d'), ord('w')) == ord('w')
    import pytest
    with pytest.raises(TypeError, match='unorderable types'):
        mapping.get(None)  # type: ignore

# Generated at 2022-06-22 03:16:40.531816
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    # Trivial test, to check that method works for all instances
    for default_value in range(-15, 15):
        for non_defaults_len in range(0, 15):
            non_defaults = {c: c for c in range(0, non_defaults_len)}
            m = StringTranslatePseudoMapping(non_defaults, default_value)
            assert len(m) == non_defaults_len

# Generated at 2022-06-22 03:16:43.129050
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    assert [k for k in StringTranslatePseudoMapping({}, 0)] == []



# Generated at 2022-06-22 03:16:49.328271
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    failures = 0

# Generated at 2022-06-22 03:16:55.076089
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    mapping = StringTranslatePseudoMapping({ord('a'): ord('A')}, ord('x'))
    assert mapping[ord('a')] == ord('A')
    assert mapping[ord('b')] == ord('x')
    assert mapping.get(ord('a')) == ord('A')
    assert mapping.get(ord('b')) == ord('x')



# Generated at 2022-06-22 03:16:58.492292
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rp = RoughParser(dedent("""\
        say_hi(
        )
        say_hi3(
        )
        """))
    assert rp.get_num_lines_in_stmt() == 1
    assert rp.get_num_lines_in_stmt() == 2


# Generated at 2022-06-22 03:17:03.454488
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    # Construct the mapping that replaces all characters except whitespace
    # with 'x' using StringTranslatePseudoMapping.
    # Replace() the original string with the mapping, and assert that the
    # outcome equals what we expect.
    text = "a + b\tc\nd"
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert text.translate(mapping) == 'x x x\tx\nx'



# Generated at 2022-06-22 03:17:10.038076
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def check(text, index_list, expected_results):
        h = HyperParser(text)
        for index, expected in zip(index_list, expected_results):
            h.set_index(index)
            r = h.is_in_code()
            if r != expected:
                raise AssertionError(
                    "Should be %s, not %s\nText:%s\nIndex:%s"
                    % (expected, r, text.dump("1.0", "end"), index)
                )

    t = MruTestText()
    i = iter("123456789")
    check(t, ["1.0", "1.1", "1.2"], [True, True, True])
    t.replace("1.0", "1.0 line\n")

# Generated at 2022-06-22 03:17:18.544688
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    """Test the get_num_lines_in_stmt method of the RoughParser class.

    This test verifies that the get_num_lines_in_stmt method of the
    RoughParser class is able to correctly determine how many lines are
    in an input string that is a statement that spans multiple lines.
    """
    parser = RoughParser("1; 2; 3;\\\n4", 1)
    assert parser.get_num_lines_in_stmt() == 2

# Generated at 2022-06-22 03:17:31.406930
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = """print( abc,
        (1, 'a'), "A",
        1.1, # comment"""
    h = HyperParser(text, 8)
    assert not h.is_in_string(), "print( abc, should not be in a string"
    h.set_index(10)
    assert not h.is_in_string(), "print( abc, should not be in a string"
    h.set_index(13)
    assert not h.is_in_string(), "print( abc, should not be in a string"
    h.set_index(15)
    assert h.is_in_string(), "(1, 'a') should be in a string"
    h.set_index(20)

# Generated at 2022-06-22 03:18:16.871618
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    # pylint: disable=redefined-outer-name
    parser = RoughParser()

    test = lambda: parser.is_block_closer()

    parser.set_str("")
    assert not test()

    parser.set_str("if False:")
    assert not test()

    parser.set_str("if False:    ")
    assert not test()

    parser.set_str("if False:\n")
    assert not test()

    parser.set_str("if False:\n  pass")
    assert not test()

    parser.set_str("if False:\n  pass\n")
    assert not test()

    parser.set_str("if False:\n  pass\n  ")
    assert not test()


# Generated at 2022-06-22 03:18:28.522529
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    def testit(s, goodstart):
        parser = RoughParser(s)
        if parser.find_good_parse_start() != goodstart:
            print(s[goodstart :], "!=", s[parser.find_good_parse_start() :])
            raise TestFailed
    #
    testit("  \t\n  foo = bar\n  boo = hoo\n", 0)
    testit("  \t\n  foo = bar\n  boo = hoo", 0)
    testit("    foo = bar\n  boo = hoo\n", 4)
    testit("  foo = bar\n  boo = hoo\n\nif 1:\n  pass\n", 0)

# Generated at 2022-06-22 03:18:39.563208
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    import unittest

    class TestRoughParserTest(unittest.TestCase):

        def test_get_num_lines_in_stmt(self):
            tests = [
                ("foo", 1),
                ("foo\\\nbar", 2),
                ("foo\nbar", 1),
                ("foo\n\nbar", 2),
                ("foo\nbar\n", 2),
                ("foo\nbar\\\nspam\neggs", 3),
            ]
            for code, num_lines in tests:
                parser = RoughParser(code)
                self.assertEqual(num_lines, parser.get_num_lines_in_stmt())
    unittest.main()

# Generated at 2022-06-22 03:18:45.198448
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    preserve_dict = {ord(c): ord(c) for c in ' \t\n\r'}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = 'a + b\tc\nd'
    assert text.translate(mapping) == 'x x x\tx\nx'



# Generated at 2022-06-22 03:18:53.613838
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-22 03:19:06.981420
# Unit test for constructor of class RoughParser

# Generated at 2022-06-22 03:19:19.299371
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():

    def check(code, index, expected):
        hyper_parser = HyperParser(code, index)
        result = hyper_parser.get_expression()
        msg = "get_expression() returned '%s', expected '%s'" % (result, expected)
        assert result == expected, msg

    code = "in a line\n"
    check(code, "1.0", "")
    check(code, "1.3", "in")
    check(code, "1.4", "in")
    check(code, "1.5", "a")
    check(code, "2.0", "")

    code = "def f(x): # comment\n    pass\n"
    check(code, "1.9", "f")
    check(code, "2.0", "x")

# Generated at 2022-06-22 03:19:26.316898
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    # Arrange
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    obj = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    expected = len(preserve_dict)

    # Act
    actual = obj.__len__()

    # Assert
    assert expected == actual



# Generated at 2022-06-22 03:19:38.808190
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    import unittest
    import inspect  # to grab sample source code for testing
    from idlelib.pyshell import testing_tools as pst

    class Test_get_last_stmt_bracketing(unittest.TestCase):
        test_source = inspect.getsource(pst.ColorDelegator)
        stmt_start = test_source.find('class ColorDelegator:')
        stmt_end = test_source.find('def _close(self):', stmt_start)
        sample = test_source[stmt_start:stmt_end]

        def test_get_last_stmt_bracketing(self):
            rp = RoughParser(self.sample)
            rp._study2()

# Generated at 2022-06-22 03:19:41.555526
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-22 03:20:47.786198
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # Simplest case, a bit of code
    t = HyperParser("x+x", "1.0")
    assert t.is_in_code()

    # A comment
    t = HyperParser("x+x#Comment", "1.5")
    assert not t.is_in_code()

    # An apostrophe
    t = HyperParser("x+x'Odd'", "1.5")
    assert not t.is_in_code()

    # A quote
    t = HyperParser('x+x"Odd"', "1.5")
    assert not t.is_in_code()

    # A backslash
    t = HyperParser('x+x\\', "1.5")
    assert not t.is_in_code()


# Generated at 2022-06-22 03:20:59.196202
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    def test(s, expected_indent_string):
        rp = RoughParser(s)
        indent_width = rp.compute_backslash_indent()
        # compute indent string
        level = indent_width // rp.indent_width
        rest = indent_width % rp.indent_width
        indent_string = rp.indent_chars[0] * level
        if rest:
            indent_string = indent_string + rp.indent_chars[1] * rest
        assert indent_string == expected_indent_string

    test("if 1:\\\n    a = 12\n", "    ")
    test("if 1:\\\n    a = 12\n    # comment\n", "    ")

# Generated at 2022-06-22 03:21:09.246504
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser(0)
    def check(expected, text):
        rp.set_str(text)
        rp._study2()
        actual = rp.get_base_indent_string()
        assert actual == expected, "%s != %s" % (actual, expected)
    check("", "")
    check("", " ")
    check(" ", "    ")
    check("", "\n")
    check("", "\n\n")
    check("\n", "\n\n ")
    check("\n", "\n\n  ")
    check("\n\n", "\n\n  \n\n")
    check("\n  ", "\n\n  \n  ")
    check("\n  ", "\n\n  \n  \n")
   

# Generated at 2022-06-22 03:21:15.417026
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rp = RoughParser("""
1 + 2
    3
    4
    \
    5
    6
    7
""", indent_width=4, tabwidth=8, line_str="1 + 2")
    rp._study2()
    assert rp.compute_backslash_indent() == 9


# Generated at 2022-06-22 03:21:26.976701
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    strs = (
        "\n"
        "def foo():\n"
        "    if 1:\n"
        "        pass\n"
        "    return\n"
        "\n"
    )
    rp = RoughParser("    ")
    rp.set_lo(strs)
    assert rp.get_good_lines() == (1, 2, 3, 4, 5, 6)
    assert rp.get_continuation_type() == C_NONE
    assert rp.compute_bracket_indent() == 4
    assert rp.get_num_lines_in_stmt() == 0
    assert rp.compute_backslash_indent() == 5
    assert rp.get_base_indent_string() == ""
    assert rp.is_block

# Generated at 2022-06-22 03:21:28.157302
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    assert True



# Generated at 2022-06-22 03:21:36.845017
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    import textwrap

    def check(s, expected, *args, **kwargs):
        got = RoughParser(s, *args, **kwargs).compute_bracket_indent()
        assert expected == got, "For:\n%s\nExpected: %s, got: %s" % (
            s,
            expected,
            got,
        )

    # Empty input
    check("", 0)

    # A simple list
    check("spam(eggs)\n", 8)

    # List which contains a comment on a continuation line
    check("one_time_thing(" "  key=value,  # a comment\n" "               key2=value2\n", 16)

    # List which contains an assignment on a continuation line

# Generated at 2022-06-22 03:21:44.798926
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    mapping = StringTranslatePseudoMapping({ord('a'): ord('x')}, ord('_'))
    assert mapping[ord('a')] == ord('x')
    assert mapping[ord('z')] == ord('_')
    assert mapping.get(ord('a')) == ord('x')
    assert mapping.get(ord('z')) == ord('_')
    assert mapping.get(ord('z'), ord('y')) == ord('y')
    assert list(mapping) == [ord('a')]
    assert len(mapping) == 1



# Generated at 2022-06-22 03:21:56.619322
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-22 03:22:02.573195
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
        global l0
        global tabwidth
        RoughParser.tabwidth = tabwidth
        l1 = RoughParser("if True:\n    b=3", l0)
        lx = RoughParser("if True:\n    b=3\n", l0)
        assert l1.get_last_open_bracket_pos() == 9
        assert l1.is_block_opener()
        assert not l1.is_block_closer()
        assert l1.get_continuation_type() == 0
        assert lx.get_continuation_type() == 2
        assert lx.get_num_lines_in_stmt() == 2
        assert l1.compute_bracket_indent() == tabwidth
        assert lx.compute_backslash_indent() == tabwidth

# Generated at 2022-06-22 03:23:17.410727
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest.mock import Mock
    from tkinter import Tk

    class Dummy:
        pass

    root = Tk()
    root.withdraw()
    text = Dummy()
    text.tabwidth = 8
    text.indent_width = 4
    text.get = Mock(return_value="def foo(bar=None):\n    pass")
    text.index = Mock(return_value="1.0")

    hyper_p = HyperParser(text, "1.0-14c")

    assert hyper_p.is_in_code()
    assert not hyper_p.is_in_string()
    assert hyper_p.get_surrounding_brackets() == ("1.0-1c", "1.0-14c")

# Generated at 2022-06-22 03:23:30.406107
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-22 03:23:33.911323
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == 4, mapping



# Generated at 2022-06-22 03:23:41.324855
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def cbi(str, tabwidth, is_py3):
        """Return compute_bracket_indent of given str, if any"""
        parseobj = RoughParser(str, tabwidth, is_py3)
        if parseobj.get_continuation_type() == C_BRACKET:
            return parseobj.compute_bracket_indent()
        else:
            return None

    # Test for bracket cases

# Generated at 2022-06-22 03:23:49.552539
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # We test the HyperParser class which is used (indirectly) by the
    # extension ParenMatch.
    #
    # We build a string, we use the HyperParser to tell us whether we
    # are in a string, we check that the result is correct.
    #
    # We build all possible strings of up to 20 characters, using all
    # possible delimiters and possible prefixes.
    #
    # We consider some positions in them and compare the result of
    # HyperParser to the expected result.
    class StrState:
        pass

    def _str_state_from_str(str):
        ret = StrState()
        if not str:
            ret.prefix = None
        elif str[0] in "rRbB":
            ret.prefix = str[0]
            str = str[1:]
       

# Generated at 2022-06-22 03:24:00.252813
# Unit test for constructor of class HyperParser
def test_HyperParser():
    h=HyperParser("  foo(a,\n  bar=2,\n  )\n", "1.5")
    assert_equal(h.rawtext, "foo(a,\n  bar=2,\n  ")
    assert_equal(h.stopatindex, "3.0")
    assert_equal(h.bracketing, [(0, 0), (1, 0), (2, 1), (10, 1), (12, 2)])
    assert_equal(h.isopener, [False, True, True, False, True])
    assert_equal(h.indexinrawtext, 6)
    assert_equal(h.indexbracket, 3)


# Generated at 2022-06-22 03:24:05.582428
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    # Can return a value that was passed to __init__:
    pseudo_map = StringTranslatePseudoMapping({1: 2}, 3)
    assert pseudo_map[1] == 2
    # Can return the default value that was passed to __init__:
    assert pseudo_map[99] == 3



# Generated at 2022-06-22 03:24:14.611227
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from test.test_support import verbose, run_unittest
    from unittest import TestCase
    from _tkinter import TclError
    from base64 import b64encode
    from tkinter import Tk
    from idlelib import EditorWindow

    class HpTestCase(TestCase):
        """A group of test methods with some common setUp and tearDown."""

        def setUp(self):
            self.root = Tk()
            self.root.withdraw()

        def tearDown(self):
            self.root.update_idletasks()
            try:
                self.root.destroy()
            except TclError:
                pass

    # The following classes use HpTestCase, so they have to be defined
    # here and not at the top level.


# Generated at 2022-06-22 03:24:20.467229
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():

    def test(data, expected_result):
        # pylint: disable=redefined-builtin
        parser = RoughParser(data, 4)
        result = parser.compute_backslash_indent()
        assert result == expected_result, (
            "Line %r, computed %r, expected %r" % (data, result, expected_result)
        )

    test('hello\\\nworld\n', 5)
    test('hello world\\\nfoo\n', 5)
    test('hello = "world"\\\nfoo = "bar"\n', 14)
    test('hello = "world"\\\n   # foo\n', 14)
    test('hello = (\n1,\\\n2,\\\n)\n', 6)

# Generated at 2022-06-22 03:24:31.110778
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = test_support.load_example("test_tkinter")
    h = HyperParser(text, "1.0")
    assert h.is_in_code()
    h.set_index("1.8")
    assert h.is_in_code()
    h.set_index("1.15")
    assert not h.is_in_code()
    h.set_index("2.0")
    assert h.is_in_code()

    h.set_index("1.21")
    assert not h.is_in_code()
    h.set_index("1.35")
    assert h.is_in_code()
    h.set_index("1.42")
    assert not h.is_in_code()
    h.set_index("1.45")