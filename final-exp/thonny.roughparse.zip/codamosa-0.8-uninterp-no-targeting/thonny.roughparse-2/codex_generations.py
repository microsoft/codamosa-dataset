

# Generated at 2022-06-22 03:16:16.830876
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    for start_str,expected_bracket_pos in [
            ["", None],
            ["foo", None],
            ["[", None],
            ["foo[", 0],
            ["foo[[bar]]", 0],
            ["foo[(bar)]", None],
            ["foo[(bar[]]", 3],
            ["foo[", None],
            ["foo[\n]\n", 0],
            ["foo[\n", None],
    ]:
        parser = RoughParser(start_str, None)
        assert parser.get_last_open_bracket_pos() == expected_bracket_pos

# Generated at 2022-06-22 03:16:23.010273
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    print('Test method __getitem__ of class StringTranslatePseudoMapping')
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"



# Generated at 2022-06-22 03:16:34.759120
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    rp = RoughParser("", 0)
    assert rp.get_line_indent("") == 0
    assert rp.get_line_indent("  x") == 2
    assert rp.get_line_indent("\tx") == 1
    assert rp.get_line_indent("  \tx") == 3
    assert rp.get_line_indent("      x") == 6
    assert rp.get_line_indent("      \\") == 6
    assert rp.get_line_indent("     \\\n\tx") == 0
    assert rp.get_line_indent(
        "     \\\n\t  x"
    ) == 2  # no extra indentation because of backslash

# Generated at 2022-06-22 03:16:43.223858
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=redefined-builtin

    #    print 'test_RoughParser()'

    #    print '  constructor only'
    s = ""
    test(RoughParser(s), [0])
    s = "a\nb\nc"
    test(RoughParser(s), [0, 2, 4])
    s = "a\n\\\nb\nc"
    test(RoughParser(s), [0, 2, 4])

    #    print '  continuation type'
    s = "a\n\\\nb\nc"
    p = RoughParser(s)
    test(p.get_continuation_type(), C_BACKSLASH)
    s = "a\n(\nb\nc"
    p = RoughParser(s)

# Generated at 2022-06-22 03:16:54.608212
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    """Tests for method find_good_parse_start of class RoughParser."""

    class Test:
        pass

    # Create RoughParser instance
    text = "a b = 1"
    rp = RoughParser(text, "<test>")

    # test 1
    rp.goodlines = [0, 1]
    rp.find_good_parse_start()
    assert rp.goodlines == [0, 0]

    # test 2
    rp.goodlines = [0, 2]
    rp.find_good_parse_start()
    assert rp.goodlines == [0, 1]

    # test 3
    rp.goodlines = [0, 4]
    rp.find_good_parse_start()
    assert rp.goodlines == [0, 3]

    # test 4


# Generated at 2022-06-22 03:17:01.933737
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    rp = RoughParser(False, "    foo()")
    assert not rp.is_block_closer()
    rp = RoughParser(False, "    if foo():")
    assert not rp.is_block_closer()
    rp = RoughParser(False, "    pass")
    assert not rp.is_block_closer()
    rp = RoughParser(False, "    foo()")
    assert not rp.is_block_closer()
    rp = RoughParser(False, "    if foo():")
    assert not rp.is_block_closer()
    rp = RoughParser(False, "    pass")
    assert not rp.is_block_closer()
    rp = RoughParser(False, "    plop()")
    assert not rp.is_block

# Generated at 2022-06-22 03:17:05.876622
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rough_parser = RoughParser(get_test_data("1.py"))
    assert "def " in rough_parser.str
    assert "print(" in rough_parser.str

# Generated at 2022-06-22 03:17:16.340105
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    global ROUGH_PARSER_ERRORS_FOUND

    def check(s, expected_indent):
        rp = RoughParser(s)
        actual_indent = rp.compute_bracket_indent()
        if actual_indent != expected_indent:
            print(
                "test_RoughParser_compute_bracket_indent failed: s=%r, expected_indent=%r, actual_indent=%r"
                % (s, expected_indent, actual_indent),
                file=sys.stderr,
            )
            ROUGH_PARSER_ERRORS_FOUND = True

    check('[\n', 1)
    check('[x+1\n', 5)
    check('[x+1,\n', 6)

# Generated at 2022-06-22 03:17:20.343964
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    while True:
        txt = input('txt> ')
        if txt == 'q':
            break
        rp = RoughParser(txt, indent_width=4)
        print(rp.get_base_indent_string())

# Generated at 2022-06-22 03:17:28.866596
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    parser = RoughParser("""
        def foo():
            if (
                blah(
                    blah
                )
            ):
                if (
                    blah(
                        "string"
                    )
                ):
                    for i in range(1):
                        pass
        """, indent_width=4, tab_width=8)

    pos = parser.get_last_open_bracket_pos()
    str = parser.str
    assert pos == len(str) - 1
    assert str[pos] == ")"


# Generated at 2022-06-22 03:18:36.427149
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    """
    >>> rp = RoughParser()
    >>> rp.set_lo(3)
    >>> rp, rp.lo, rp.last_word
    (<RoughParser object at ...>, 3, '')
    >>> rp.set_lo(0)
    Traceback (most recent call last):
      ...
    ValueError: bad RoughParser.set_lo argument
    """
    pass


# Generated at 2022-06-22 03:18:46.725414
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    def get_string_contents(text):
        """Return a list of pairs (start, end), with (start, end) being
        the positions of the strings in text.

        The text is assumed to be correct Python code, and index is
        the index of some part of it.

        The result is intended to be used in tests, so it doesn't
        handle complex cases (like string with other strings inside
        them).
        """
        hp = HyperParser(text, "1.0")
        result = []
        while hp.is_in_string():
            try:
                result.append(hp.get_surrounding_brackets('"', True))
            except ValueError:
                # Here we are at a string end, so we don't have a pair
                pass

# Generated at 2022-06-22 03:18:58.465450
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-22 03:19:04.323384
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    # Test for expected behaviour using str.translate()
    preserve_dict = {ord('a'): ord('a'), ord('b'): ord('b')}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('_'))
    text = "abcdef"
    assert text.translate(mapping) == "ab__ef"

# Test for expected behaviour when using the mapping directly
    del text
    assert mapping[ord('x')] == ord('_')
    assert mapping[ord('a')] == ord('a')
    assert mapping[ord('b')] == ord('b')



# Generated at 2022-06-22 03:19:16.821655
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    from pycodestyle import VERSION
    from . import examples
    from . import tokenize
    from . import _tokenize

    def _is_excluded_case(case_name, text):
        return (not text or (
            case_name in examples.EXCLUDED_CASES[int(VERSION[0])]))

    def _is_commented_out_case(text):
        return (
            isinstance(text, tuple) and
            text[0].strip().startswith('#'))

    pyfile_count = 0
    error_count = 0
    parser = RoughParser()

    for path in examples.find_examples('.'):
        ext = path.rsplit('.', 1)[-1]

        if ext not in ('py', 'pyw'):
            continue


# Generated at 2022-06-22 03:19:26.432407
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    import unittest


# Generated at 2022-06-22 03:19:31.513707
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == 4



# Generated at 2022-06-22 03:19:42.922937
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=redefined-builtin

    # A collection of tests for class RoughParser.find_good_parse_start.

    # First, construct the global variables used in the tests.

    # The tabwidth for calculations of physical line length
    tabsize = 4

    # The max physical line length prior to continuation
    contin_len = 30

    # Whether to check continuation via backslash lines as well
    check_backslash = False

    # The start of the block being considered, as an offset into txt.
    # This is the same as the length of any preceding block.
    start = 0

    # The end of the block being considered, as an offset into txt.
    end = len(txt)

    # The offset into txt of the end of the last physical line breaking
    # the block into two (possibly empty) physically

# Generated at 2022-06-22 03:19:52.894612
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def check(expected, str):
        rp = RoughParser(str, indent_width=8, tabwidth=8)
        actual = rp.get_base_indent_string()
        if actual != expected:  # pylint: disable=undefined-loop-variable
            print("expected %r, got %r" % (expected, actual))
            return False
        return True

    def test(str):
        check(" ", str)

    test("")
    test("\n")
    test("  \n")
    test("  \t\n")
    test("\t  \n")
    test("\t \t\n")
    test(" \t \n")
    test("#x\n")
    test("#x\n  ")
    test("if 1:\n  pass\n")

# Generated at 2022-06-22 03:20:04.344482
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rp = RoughParser("    def f():\n        print\n        ")
    got = rp.compute_backslash_indent()
    assert got == 9

    rp = RoughParser("    def f():\n        print\n        \\\n        ")
    got = rp.compute_backslash_indent()
    assert got == 9

    rp = RoughParser("    def f():\n        print\n        \\# hoi\n        ")
    got = rp.compute_backslash_indent()
    assert got == 9

    rp = RoughParser("    def f():\n        print\n        x = \\# hoi\n        ")
    got = rp.compute_backslash_indent()
    assert got == 9

    rp

# Generated at 2022-06-22 03:20:58.392984
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rp = RoughParser("a = 1 + \\\n  1\n", 4, 8)
    rp.study_level = 2
    rp.continuation = C_BACKSLASH
    rp.str = "abc\n"
    assert rp.str == "abc\n"
    assert rp.compute_backslash_indent() == 5


# Generated at 2022-06-22 03:21:06.372424
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():

    # Exception raised when length is accessed
    exc_raised1 = False
    try:
        StringTranslatePseudoMapping({}, ord('x')).__len__()
    except TypeError:
        exc_raised1 = True
    assert exc_raised1 is False

    # Exception not raised when length is accessed
    exc_raised2 = False
    try:
        StringTranslatePseudoMapping({0x61: 0x61}, ord('x')).__len__()
    except TypeError:
        exc_raised2 = True
    assert exc_raised2 is False



# Generated at 2022-06-22 03:21:18.764249
# Unit test for constructor of class RoughParser

# Generated at 2022-06-22 03:21:31.169673
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(method, e1, e2):
        """method is a method of HyperParser, e1 is a string with
        the method call, e2 is the expected result.
        """
        if method(e1) != e2:
            raise RuntimeError("get_expression(%s) returned %s instead of %s" % (e1, method(e1), e2))
        print("get_expression(%s) = %s" % (e1, method(e1)))

    test(HyperParser(tk.Text(), "1.0").get_expression, "a.b.c+", "a.b.c")
    test(HyperParser(tk.Text(), "1.0").get_expression, "foo(a+4,b).bar", "foo(a+4,b)")

# Generated at 2022-06-22 03:21:37.894258
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    def runtest(text, expected):
        parser = RoughParser(text)
        if expected != parser.get_last_open_bracket_pos():
            raise ValueError(
                f"Test failed on text {text!r} expected {expected} got {parser.get_last_open_bracket_pos()}"
            )

    runtest(
        text="", expected=None
    )
    runtest(
        text="\n", expected=None
    )
    runtest(
        text="{", expected=None
    )
    runtest(
        text="\n{", expected=1
    )
    runtest(
        text=" \n{", expected=2
    )
    runtest(
        text="{\n{", expected=1
    )

# Generated at 2022-06-22 03:21:46.588960
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import mock
    import inspect

    def _mock_get(self, startindex, stopindex):
        if not stopindex.endswith(".end") or stopindex[:-4] != str(self.lno):
            raise ValueError("Invalid arguments to get")
        startindex = int(startindex)
        return "\n".join(
            line.rstrip()
            for (index, line) in enumerate(self.lines[startindex - 1 : self.lno])
        ) + "\n "

    class TestCase(unittest.TestCase):
        def test_HyperParser_set_index(self):
            self.maxDiff = None
            _maxsize = sys.maxsize

            def get_HyperParser(lno, col):
                text = mock.Mock()
                # We simulate a

# Generated at 2022-06-22 03:21:57.389510
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def check(text, w):
        assert RoughParser(text, w).compute_bracket_indent() == w

    check("if 1:", 2)
    check("if 1: a = b", 2)
    check("if 1: a", 2)
    check("if 1:\n  pass", 2)
    check("if 1:\n  a", 2)
    check("if 1:\n  a = b", 2)
    check("if 1:\n  a = b\nelse:", 6)
    check("if 1:\n  a = b\nelse: c", 6)
    check("try:", 2)
    check("try:\n  a = b", 2)
    check("try:\n  a = b\nexcept:", 6)

# Generated at 2022-06-22 03:22:01.450034
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    from idlelib.pyshell import MockEditorWindow
    root = tkinter.Tk()
    editor = MockEditorWindow(root)
    text = editor.text

# Generated at 2022-06-22 03:22:09.420015
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from idlelib.idle_test.mock_idle import Func
    from idlelib.idle_test.mock_tk import Mbox
    from idlelib.idle_test.mock_tk import Text
    Tk = None

    # We need a text widget.  Create it here.
    root = None
    if Tk:
        root = Tk()
    text = Text(root)

    # Build a string with lots of bracketing.  Do it in a way that is
    # visually traceable and resistant to changes.  To do this, we use
    # the bracketing indices in the string.  Each bracketing will be
    # on a line by itself.  Each line will be indented with a number
    # of spaces depending on the bracketing level.  (The level is 0
    # for the outermost bracket

# Generated at 2022-06-22 03:22:19.637524
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    no_change_chars = 'abc'
    no_change_dict = {ord(c): ord(c) for c in no_change_chars}
    mapping = StringTranslatePseudoMapping(no_change_dict, ord('x'))
    assert mapping[ord('a')] == ord('a')
    assert mapping[ord('b')] == ord('b')
    assert mapping[ord('c')] == ord('c')
    assert mapping[ord('d')] == ord('x')

max_utf8_chars = b''.join([bytes([i]) for i in range(256)])
