

# Generated at 2022-06-22 03:19:04.050219
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    "Unit test for method HyperParser.get_expression"
    import re

    def check(text, index, expected):
        """Check that text[:index] is a valid python statement and that
        text[:index].get_expression() == expected
        """
        h = HyperParser(text, index)
        assert h.get_expression() == expected

    check(
        "spam()",
        "1.7",
        "spam",
    )  # simple function call

    check(
        "spam(a,b,c)",
        "1.12",
        "spam(a, b, c)",
    )  # function call with arguments

    check(
        "spam(a,b,c)",
        "1.11",
        "a, b, c",
    )  # function call arguments

# Generated at 2022-06-22 03:19:16.496729
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    # pylint: disable=redefined-builtin
    parser = RoughParser(" # comment\nprint(1) if True:")
    assert parser.is_block_opener()
    parser = RoughParser(" # comment\nprint(1) if True :")
    assert parser.is_block_opener()
    parser = RoughParser(" # comment\nprint(1) if True:\n pass")
    assert parser.is_block_opener()
    parser = RoughParser(" # comment\nprint(1) if True :\n pass")
    assert parser.is_block_opener()
    parser = RoughParser(" # comment\nprint(1) if True: # comment")
    assert parser.is_block_opener()
    parser = RoughParser(" # comment\nprint(1) if True : # comment")

# Generated at 2022-06-22 03:19:23.247680
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    assert StringTranslatePseudoMapping({}, 0)[0] == 0
    assert StringTranslatePseudoMapping({0: 1}, 0)[0] == 1
    assert StringTranslatePseudoMapping({2: 3}, 0)[0] == 0
    assert StringTranslatePseudoMapping({2: 1}, 0)[0] == 0

# Generated at 2022-06-22 03:19:32.678523
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # Make sure we are out of the way.
    root = Tk()
    text = Text(root)
    text.pack()
    root.update()


# Generated at 2022-06-22 03:19:35.970964
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    assert not _test_HyperParser_set_index.failed
_test_HyperParser_set_index.failed = 0

# Generated at 2022-06-22 03:19:44.843017
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    # test default
    mapping = StringTranslatePseudoMapping(dict(), 0)
    assert mapping.get(1) == 0
    assert mapping.get(2) == 0
    # test non-default
    mapping = StringTranslatePseudoMapping({1: 2}, 0)
    assert mapping.get(1) == 2
    assert mapping.get(2) == 0
    assert mapping.get(3) == 0
    assert mapping.get(2, 3) == 3
    # test default as argument
    mapping = StringTranslatePseudoMapping(dict(), 0)
    assert mapping.get(1, 2) == 2
    assert mapping.get(2, 3) == 3


# Utility class:  a proxy for a StringIO object which remembers
# whether it was ever written to.


# Generated at 2022-06-22 03:19:53.981036
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    parser = RoughParser()
    parser.set_lo("")
    assert len(parser.goodlines) == 2
    assert parser.goodlines[1] == 1
    assert parser.goodlines[-1] == 2
    assert parser.indentwidth == 0
    assert parser.tabwidth == 8

    parser.set_lo("\t")
    assert len(parser.goodlines) == 2
    assert parser.goodlines[1] == 1
    assert parser.goodlines[-1] == 2
    assert parser.indentwidth == 8
    assert parser.tabwidth == 8

    parser.set_lo(" " * 8)
    assert len(parser.goodlines) == 2
    assert parser.goodlines[1] == 1
    assert parser.goodlines[-1] == 2
    assert parser.indentwidth == 8
   

# Generated at 2022-06-22 03:20:05.763290
# Unit test for constructor of class RoughParser

# Generated at 2022-06-22 03:20:12.378438
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"



# Generated at 2022-06-22 03:20:21.368077
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = tk.Text()
    text.insert(tk.END, 'x = "nested\\n(\\"(parens)\\")\\n"')

    # Test simple identifiers
    hp = HyperParser(text, "1.0")
    hp.set_index("1.0")
    assert hp.indexinrawtext == 0
    assert hp.indexbracket == 0
    assert hp.stopatindex == "1.end"
    hp.set_index("1.1")
    assert hp.indexinrawtext == 1
    assert hp.indexbracket == 2
    hp.set_index("1.2")
    assert hp.indexinrawtext == 2
    assert hp.indexbracket == 2
    hp.set_index("1.end")
    assert hp.indexinrawtext == 3

# Generated at 2022-06-22 03:22:42.710682
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == 4



# Generated at 2022-06-22 03:22:48.293226
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser("")
    with pytest.raises(ValueError):
        rp.set_lo("a")
    with pytest.raises(ValueError):
        rp.set_lo("a")
    rp.set_lo("    ")
    rp.set_lo("")


# Generated at 2022-06-22 03:22:55.866370
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    def check(str_, expected_goodlines, expected_continuation):
        rp = RoughParser()
        rp.set_str(str_)
        goodlines = rp.get_good_lines()
        if goodlines != expected_goodlines:
            assert 0, (
                "bad result for set_str: bad goodlines:\n"
                "set_str argument = %r\n"
                "goodlines result = %r\n"
                "expected goodlines = %r"
                % (str_, goodlines, expected_goodlines)
            )
        continuation = rp.get_continuation_type()

# Generated at 2022-06-22 03:23:00.983145
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    test_val = "abcd"
    test_default = "0"
    class_instance = StringTranslatePseudoMapping(test_val, test_default)
    assert len(class_instance) == 4, "__len__ made a mistake."


# Generated at 2022-06-22 03:23:08.742497
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    import sys
    import pprint

    verbose = "-v" in sys.argv
    if verbose:
        print("Testing RoughParser.set_str")

    r = RoughParser()

    # Test continuation line recognition


# Generated at 2022-06-22 03:23:18.785383
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest
    from tkinter import Tk

    class SetIndexTestCase(unittest.TestCase):
        def setUp(self):
            self.root = Tk()
            self.t = self.t = Text(self.root)
            self.t.pack()
            self.t.insert('1.0', 'a = 10\n')

        def tearDown(self):
            self.t.destroy()
            self.root.destroy()

        def test_beginning(self):
            self.t.insert('1.0', 'b')
            self.assertRaises(ValueError, self.t.hyperparser.set_index, '1.0')

        def test_in_code(self):
            self.t.insert('1.1', 'b')
            self.t.hyperparser

# Generated at 2022-06-22 03:23:27.360565
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    # pylint: disable=redefined-builtin
    text = """\
#if x:
    def f(
        arg1,
        arg2, arg3):
    print arg1, arg2, arg3
    if 1:
        print 'foo'
        print 'bar'
        if 1:
            print 'baz'
            print 'quux'
            return
    return
"""
    parser = RoughParser(text)
    assert parser.get_num_lines_in_stmt() == 8



# Generated at 2022-06-22 03:23:37.345008
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    import pytest
    from pprint import pprint
    from pyfidelity.debug import test_RoughParser

    def test_one(src, expected):
        rp = test_RoughParser(src)
        actual = rp.get_last_open_bracket_pos()
        if actual != expected:
            print("\n")
            print("src: <<<")
            print(src)
            print(">>>")
            print("expected: %r" % (expected,))
            print("actual  : %r" % (actual,))
            pprint(rp.stmt_bracketing)
            print("")

    test_one("a([1,2,3])", 3)
    test_one("a({1:2,3:4})", 3)

# Generated at 2022-06-22 03:23:38.450890
# Unit test for constructor of class RoughParser

# Generated at 2022-06-22 03:23:43.659955
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    mapping = StringTranslatePseudoMapping({1:10}, 0)
    assert mapping.get(1) == 10
    assert mapping.get(2) == 0
    assert mapping[1] == 10
    assert mapping[2] == 0
    assert list(mapping) == list({1})
    assert len(mapping) == 1

