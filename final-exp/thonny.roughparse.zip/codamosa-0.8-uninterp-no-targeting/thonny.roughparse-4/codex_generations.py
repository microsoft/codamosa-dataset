

# Generated at 2022-06-22 03:16:15.959367
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    # Test incomplete translation:
    translate = StringTranslatePseudoMapping({ord('a'): None}, ord('c'))
    text = 'a + b'
    result = text.translate(translate)
    assert result == 'c + c'

    # Tests that work with all Python releases:
    for mapping in ({}, {ord('a'): None}, {ord('a'): ord('c')}):
        translate = StringTranslatePseudoMapping(mapping, ord('x'))
        text = 'a + b'
        result = text.translate(translate)
        assert result == 'x + x'

    # Tests that work with Python 2 only:
    if str is not bytes:
        # TODO: Figure out how to make this work with Python 3 too
        translate = StringTranslatePseudoM

# Generated at 2022-06-22 03:16:26.905103
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    import tokenize
    from io import BytesIO

    # Not sure if this is the best way to test.
    #
    # The reason we have this test is because we have changed the behavior
    # of compute_bracket_indent with respect to indents that are not
    # consistent with the Python standard. These are indents such as:
    #
    # f(a,
    #    b)
    #
    # Because the Python standard defines that 4 spaces must be used, if
    # the user has their idents set to something different than 4 spaces,
    # this code should still use the 4 spaces to indent on new lines.
    # This is the desired behavior, which we define as correct.

    # The following tests will have 2 cases:
    # 1) The tab size is 4, which is the same as the standard Python indent.
    #

# Generated at 2022-06-22 03:16:37.893507
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("a")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("    ")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    a")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    if x:\n"
                     "        return a\n"
                     "        b = 1\n"
                     "\n"
                     "print(b)\n")
    assert rp.get_base_indent_string() == "    "

# Generated at 2022-06-22 03:16:45.576904
# Unit test for constructor of class RoughParser
def test_RoughParser():
    p = RoughParser("a")
    assert p.str == "a"
    assert p.indent_width == 8
    assert p.tabwidth == 8
    assert p.study_level == 0

    p = RoughParser("a\nb")
    assert p.str == "a\nb"
    assert p.indent_width == 8
    assert p.tabwidth == 8
    assert p.study_level == 0

    p = RoughParser("a\nb", indent_width=6)
    assert p.str == "a\nb"
    assert p.indent_width == 6
    assert p.tabwidth == 8
    assert p.study_level == 0

    p = RoughParser("a\nb", tabwidth=9)
    assert p.str == "a\nb"
    assert p.indent_width == 8

# Generated at 2022-06-22 03:16:57.872380
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    # Test: verify that all replacements are made.
    # Condition:
    #   create an object with a given default value,
    #   and with a mapping that defines replacements for some characters only
    # Action:
    #   call __getitem__() for all characters in a string
    # Expectation:
    #   all characters except those in the mapping are mapped to the default
    #   value, and the others are mapped to the values in the mapping

    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    reference = "x x x\tx\nx"


# Generated at 2022-06-22 03:17:04.049633
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():

    def assert_get_expression(text, index, expr):
        hp = HyperParser(text, index)
        assert_equal(hp.get_expression(), expr)

    # Possible whitespace
    yield check, assert_get_expression, "hello\t", "2.0", "hello"
    yield check, assert_get_expression, "hello\t", "2.1", "hello\t"
    yield check, assert_get_expression, "hello\t", "2.end", ""

    # After a dot
    yield check, assert_get_expression, "hello.world", "7.0", "hello"
    yield check, assert_get_expression, "hello.world", "7.1", "hello."
    yield check, assert_get_expression, "hello.world", "7.end", "world"

    # Ident

# Generated at 2022-06-22 03:17:10.768020
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class HyperParserTest(unittest.TestCase):
        def check(self, str, index, expr, openpos=None, closepos=None, realexpr=None):
            hp = HyperParser(str, index)
            test_expr = hp.get_expression()
            self.assertEqual(test_expr, expr)
            if openpos:
                test_openpos = hp.get_surrounding_brackets()[0]
                self.assertEqual(test_openpos, openpos)
            if closepos:
                test_closepos = hp.get_surrounding_brackets()[1]
                self.assertEqual(test_closepos, closepos)
            if realexpr:
                hp.set_index(openpos)

# Generated at 2022-06-22 03:17:18.786656
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-22 03:17:31.880821
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class Test(TestCase):
        def test_basic(self):
            text = Text(None, {}, "", " \t\n")
            parser = HyperParser(text, "1.0")
            self.assertEqual(parser.text, text)
            self.assertEqual(parser.bracketing, [])
            self.assertEqual(parser.indexbracket, 0)
            self.assertEqual(parser.indexinrawtext, 0)
            self.assertEqual(parser.rawtext, "")

        def test_with_text(self):
            text = Text(None, {}, ") abc\n# Test:\n", " \t\n")
            parser = HyperParser(text, "2.0")

# Generated at 2022-06-22 03:17:44.521751
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    import sys
    import pytest
    import io
    # pylint: disable=redefined-builtin

    # s is a string to be parsed as a logical line.  It may or may not end in
    # a backslash.  indent should be the indentation you expect (this is the
    # "expected" argument), and tabsize is the tab width.  width is the max
    # line width, which is only used to decide whether we need to add a
    # backslash for line-wrapping purposes.
    #
    # The test fails if RoughParser.compute_backslash_indent() returned a
    # different answer.
    #
    # The test case is tricky: we have to pretend that the test suite's
    # stdin was actually the stdin of the program being formatted.  In other
    # words, we

# Generated at 2022-06-22 03:18:45.938967
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest
    import StringIO

    class TestHP(unittest.TestCase):

        def runTest(self):
            s = "def f(x, y, z): pass\n"
            t = Text(StringIO.StringIO(s), 4)

            hp = HyperParser(t, "1.0")
            self.assertEqual(hp.rawtext, s)
            self.assertEqual(hp.bracketing, [(0, 0)])
            self.assertEqual(hp.isopener, [False])

            hp = HyperParser(t, "1.4")
            self.assertEqual(hp.rawtext, s)

            self.assertEqual(hp.bracketing, [(0, 0), (4, 1), (7, 1), (10, 1)])

# Generated at 2022-06-22 03:18:49.999784
# Unit test for constructor of class RoughParser
def test_RoughParser():  # pylint: disable=redefined-builtin
    rp = RoughParser("if 1:\n  if 2:\n    pass\n")
    assert rp.str == "if 1:\n  if 2:\n    pass\n"
    assert rp.get_num_lines_in_stmt() == 3
    assert rp.get_continuation_type() == C_NONE


# Generated at 2022-06-22 03:19:02.790313
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    assert RoughParser("").get_num_lines_in_stmt() == 0
    assert RoughParser("\n").get_num_lines_in_stmt() == 0
    assert RoughParser("#\n").get_num_lines_in_stmt() == 0
    assert RoughParser("#\n#\n").get_num_lines_in_stmt() == 0
    assert RoughParser("#\n#\n\n").get_num_lines_in_stmt() == 0
    assert RoughParser("#\n#\n\n\n").get_num_lines_in_stmt() == 0
    assert RoughParser("#\n#\n\n\n\n").get_num_lines_in_stmt() == 0
    assert RoughParser("\n\n").get_num_lines_in_

# Generated at 2022-06-22 03:19:10.350899
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    from idlelib.configHandler import idleConf
    idleConf.CurrentTheme.theme_use_default_on_new_window = False
    idleConf.CurrentTheme.theme_name = 'IDLE Classic'
    parser = RoughParser('from _a.foo.bar import *\n')
    assert parser.get_last_stmt_bracketing() == ((0, 0), (22, 1), (23, 0))


# Generated at 2022-06-22 03:19:15.803053
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    dTest = {"a": 1, "b": 2}
    nTest = len(dTest)
    oTest = StringTranslatePseudoMapping(dTest, 0)
    nLen = len(oTest)
    assert nLen == nTest, "wrong size: got %d, expected %d" % (nLen, nTest)



# Generated at 2022-06-22 03:19:26.105639
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    mapping = StringTranslatePseudoMapping({ord('a'): ord('x')}, ord('z'))
    assert mapping.get(ord('a')) == ord('x')
    assert mapping.get(ord('b')) == ord('z')
    assert mapping.get('b') == ord('z')
    assert mapping[ord('a')] == ord('x')
    assert mapping[ord('b')] == ord('z')
    assert mapping.get('b', ord('x')) == ord('x')
    assert mapping.get(ord('a'), ord('x')) == ord('x')



# Generated at 2022-06-22 03:19:33.426213
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    assert HyperParser("x = 1", "1.0").is_in_code()
    assert HyperParser("'''\nx = 1\n'''", "1.0").is_in_code()
    assert not HyperParser("#comment\nx = 1", "1.0").is_in_code()
    assert not HyperParser("'''\n#comment\nx = 1\n'''", "1.0").is_in_code()


# Generated at 2022-06-22 03:19:44.164411
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    rp = RoughParser("\ntest\n", 0, 0)
    assert rp.get_continuation_type()==0
    rp = RoughParser("\ntest\\\n", 0, 0)
    assert rp.get_continuation_type()==1
    rp = RoughParser("\ntest\n\"test\\\n\"", 0, 0)
    assert rp.get_continuation_type()==2
    rp = RoughParser("\ntest\n\"test\\\n", 0, 0)
    assert rp.get_continuation_type()==0
    rp = RoughParser("\ntest\n(test\\\n", 0, 0)
    assert rp.get_continuation_type()==3

# Generated at 2022-06-22 03:19:53.914103
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # The usefulness of this function is questionable.
    # It is called by sure_test_all, but doesn't have any known
    # callers of its own.
    #
    # Maybe it could be used in an expression completion dialog.
    # That would at least be a proper unit test for it.

    def check(result, string, pos):
        if result != HyperParser(string, "1.0+%dc" % pos).get_expression():
            print("get_expression('%s', %d) = %s" % (string, pos, result))

    check("x", "x", 0)
    check("y", "x.y", 2)
    check("y", "x.   y", 5)
    check("y", "x. \n y", 4)

# Generated at 2022-06-22 03:19:58.707720
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    unittest.assertIs(test_StringTranslatePseudoMapping.__getitem__,
                      unittest.TestObject.__getitem__)

# Unit tests for class StringTranslatePseudoMapping

# Generated at 2022-06-22 03:21:34.838059
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    import unittest
    import sys

    class StringTranslatePseudoMappingTestCase(unittest.TestCase):
        def test___iter__(self):
            my_dict = {1: '1', 2: '2'}
            my_pseudo_mapping = StringTranslatePseudoMapping(my_dict, '0')
            self.assertEqual(
                sorted(list(my_pseudo_mapping)),
                [1, 2]
            )

    doctest_support.run_unittest(StringTranslatePseudoMappingTestCase)


# Generated at 2022-06-22 03:21:45.319051
# Unit test for constructor of class HyperParser

# Generated at 2022-06-22 03:21:56.647403
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    parser = RoughParser("x = f(1,\n2)")
    assert parser.get_continuation_type() == C_BRACKET

    parser = RoughParser("for x in [\n1\n]:\n    print(x)")
    assert parser.get_continuation_type() == C_BRACKET

    parser = RoughParser("1+\\\n1")
    assert parser.get_continuation_type() == C_BACKSLASH

    parser = RoughParser("foo(1,\\\n2)")
    assert parser.get_continuation_type() == C_BACKSLASH

    parser = RoughParser("foo(\"\"\"\\\n1\n\\\n\"\"\")")
    assert parser.get_continuation_type() == C_STRING_NEXT_LINES

    # a mult

# Generated at 2022-06-22 03:21:58.152327
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    r"""Sphinx-generated unit test for method __len__ of class StringTranslatePseudoMapping"""
    assert True



# Generated at 2022-06-22 03:22:08.002553
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    # pylint: disable=redefined-builtin
    rp = RoughParser("if a:\n    b(c)#\n    d\n")
    assert rp.is_block_closer() == False

    rp = RoughParser("if a:\n    b(c)#\n    d\nelse:\n")
    assert rp.is_block_closer() == True

    rp = RoughParser("if a:\n    b(c)#\n    d\nelse:\n    e(f)\n")
    assert rp.is_block_closer() == False

    rp = RoughParser("def f():\n    pass\nclass C:\n    pass\n")
    assert rp.is_block_closer() == False


# Generated at 2022-06-22 03:22:20.142239
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    non_defaults = {
        ord('a'): ord('x'),
        ord('b'): ord('y'),
        ord('c'): ord('z'),
    }
    dummy_default = ord('x')
    mapping = StringTranslatePseudoMapping(non_defaults, dummy_default)

    assert mapping.get(ord('a')) == ord('x')
    assert mapping.get(ord('b')) == ord('y')
    assert mapping.get(ord('c')) == ord('z')
    assert mapping.get(ord('d')) == dummy_default


# CONSTANTS

# for testing purposes

_wordchars_re = re.compile(r"\w")
_idchars_re = re.compile(r"\w|\.|\d")




# Generated at 2022-06-22 03:22:29.451669
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    "Simple unit test"
    assert HyperParser("if (1): print", "1.0").is_in_code()
    assert HyperParser("if (1): print", "1.2").is_in_code()
    assert HyperParser("if (1): print", "1.5").is_in_code()
    assert not HyperParser("if (1): print", "1.8").is_in_code()
    assert not HyperParser("if (1): print", "1.9").is_in_code()
    assert not HyperParser("#if (1): print", "1.0").is_in_code()
    assert not HyperParser("#if (1): print", "1.1").is_in_code()
    assert not HyperParser("#if (1): print", "1.2").is_in_code()


# Generated at 2022-06-22 03:22:40.690729
# Unit test for constructor of class RoughParser
def test_RoughParser():
    RP = RoughParser
    assert RP("").str == "\n" * 10
    assert RP("", "").str == "\n" * 10
    assert RP("", "", "").str == "\n" * 10
    assert RP("\n" * 9).str == "\n" * 10
    assert RP("\n" * 10).str == "\n" * 10
    assert RP("\n" * 11).str == "\n" * 11 + "\n" * 9
    assert RP("\n" * 20).str == "\n" * 10 + "\n" * 10
    assert RP("", "\n" * 20).str == "\n" * 20
    rp = RP("foo", "bar")
    assert rp.str == "foo\nbar\n"
    rp = RP("foo", "bar", "baz")
   

# Generated at 2022-06-22 03:22:51.703914
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # pylint: disable=redefined-builtin
    _test(
        """\
    if 1:
        if 1:
            x = 1+\\
                2
            x = 'foo' + \
                'bar'
            x = (1 +
                 2)
            x = [
                1,
                2
            ]
            """,
        C_STRING_FIRST_LINE,
        # get_continuation_type
        # get_num_lines_in_stmt
    )


# Generated at 2022-06-22 03:23:04.517504
# Unit test for method compute_backslash_indent of class RoughParser