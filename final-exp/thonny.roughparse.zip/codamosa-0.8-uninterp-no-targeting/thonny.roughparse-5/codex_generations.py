

# Generated at 2022-06-22 03:18:01.952330
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    parser = RoughParser()
    try:
        parser.set_str('while True:\n  x = 1\n  y = 2\n')
    except:
        raise
    try:
        parser.set_str('while True:')
    except:
        raise
    try:
        parser.set_str('\nwhile True:')
    except:
        raise
    try:
        parser.set_str('while True)\n')
    except:
        raise
    try:
        parser.set_str('while True:\n  x = 1\n  y = 2')
    except:
        raise


# Generated at 2022-06-22 03:18:13.132527
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text):
        hp = HyperParser(text, text.index("insert"))
        return hp.get_expression()

    assert test(" if 1+2 > 3: a=1+2; print(a) # comment") == "a"
    assert test("a=1+2\nprint(a) # comment") == "a"

    assert test(" b=4; c=5\nprint(a) # comment") == ""

    assert test("if 1+2 > 3: a=1+2; a.x=1+2\nprint(a) # comment") == "a.x"

    assert test("if 1+2 > 3: a=1+2; a.x=1+2\nprint(a) # comment") == "a.x"


# Generated at 2022-06-22 03:18:21.470324
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=redefined-builtin
    for str in _tests:
        parser = RoughParser(str, indent_width, tabwidth)
        print("Trying [%s]" % str)
        if len(str) < _MAX_COLS / 4:
            print(" was: [%s]" % str[parser.find_good_parse_start():])
        else:
            print("(skipped display; too wide)")



# Generated at 2022-06-22 03:18:33.573133
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin

    def check_backslash_indent(expected, source):
        # pylint: disable=redefined-builtin
        parser = RoughParser(source, indent_width=8)
        continuation_type = parser.get_continuation_type()
        assert continuation_type == C_BACKSLASH
        indent = parser.compute_backslash_indent()
        assert indent == expected, "expected %s, got %s" % (expected, indent)

    def chk(*args):
        check_backslash_indent(*args)  # pylint: disable=star-args

    chk(8, "a = \\")
    chk(16, "a = b \\")
    chk(24, "if a:\\")

# Generated at 2022-06-22 03:18:44.936913
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import unittest

    class Test(unittest.TestCase):
        def test_is_in_code(self):
            text = Text(tabs=4, undo=False)
            text.insert("insert", "a")
            par = HyperParser("", "1.0")
            text.delete("1.0", "1.1")
            par.set_index("1.0")
            text.insert("1.0", '"""abc""""')
            par.set_index("2.2")
            self.assertTrue(par.is_in_code())
            text.insert("2.2", "#")
            par.set_index("2.2 lineend")
            self.assertFalse(par.is_in_code())
            text.insert("2.2 lineend", "abcd")
            par

# Generated at 2022-06-22 03:18:53.438498
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = "a((1+2))"
#    assert HyperParser(text, text.index("(")).get_surrounding_brackets() == (1, 5)
#    assert HyperParser(text, text.index("1")).get_surrounding_brackets() == (1, 5)
#    assert HyperParser(text, text.index("2")).get_surrounding_brackets() == (1, 5)
#    assert HyperParser(text, text.index(")")).get_surrounding_brackets() == (1, 5)
#    assert HyperParser(text, text.index("+")).get_surrounding_brackets() == (3, 3)
#    assert HyperParser(text, text.index("a")).get_surrounding_brackets() == (0, 0)
   

# Generated at 2022-06-22 03:19:06.656702
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from idlelib.HyperParser import HyperParser

    def test_is_in_code(index, expected_result):
        # index must be in the same statement.
        # For the following tests, this means in the same line.
        is_in_code = HyperParser(text, index).is_in_code()
        if is_in_code != expected_result:
            print(
                f"Test failed: is_in_code('{index}')"
                f"should return {expected_result!r} but returned {is_in_code!r}"
            )

    text = "import sys # comment"

    for index in ("1.0", "1.15", "1.end", "1.end-1c", "1.end-2c"):
        test_is_in_code(index, True)

   

# Generated at 2022-06-22 03:19:19.068944
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-22 03:19:30.822458
# Unit test for constructor of class RoughParser
def test_RoughParser():

    def test(s, *args):
        # pylint: disable=redefined-builtin
        rp = RoughParser(s)
        assert rp.get_continuation_type() == args[0]
        assert rp.get_num_lines_in_stmt() == args[1]
        assert rp.is_block_opener() == args[2]
        assert rp.is_block_closer() == args[3]
        assert rp.get_base_indent_string() == args[4]
        assert rp.get_last_open_bracket_pos() == args[5]
        assert rp.get_last_stmt_bracketing() == args[6]

    set_debugging(True)

# Generated at 2022-06-22 03:19:42.288612
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    import unittest
    class TestRoughParser(unittest.TestCase):
        def test_is_block_closer(self):
            self.assertTrue(RoughParser("").is_block_closer())
            self.assertTrue(RoughParser("").is_block_closer())
            self.assertTrue(RoughParser("pass").is_block_closer())
            self.assertTrue(RoughParser("return").is_block_closer())
            self.assertTrue(RoughParser("break").is_block_closer())
            self.assertTrue(RoughParser("continue").is_block_closer())
            self.assertTrue(RoughParser("raise").is_block_closer())
            self.assertTrue(RoughParser("raise E, V").is_block_closer())

# Generated at 2022-06-22 03:20:12.432506
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    non_defaults = {ord('o'): ord('O'), ord('e'): ord('E')}
    mapping = StringTranslatePseudoMapping(non_defaults, ord('x'))
    assert mapping.get(ord('o')) == ord('O')
    assert mapping.get(ord('e')) == ord('E')
    assert mapping.get(ord('t')) == ord('x')
    for c in (string.ascii_letters + string.digits + ' '):
        # Must not throw KeyError, but must work for some key
        mapping[ord(c)]



# Generated at 2022-06-22 03:20:15.471606
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    tester = unittest.FunctionTestCase(RoughParser.is_block_opener)
    tester.expect_result(True, RoughParser("  if "))
    tester.expect_result(False, RoughParser("  if :"))

# Generated at 2022-06-22 03:20:21.466976
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            test_string = (
                '   # foo\n'
                'a = a + \\'
                '    b + \\'
                '    c\n'
                'print(a)\n'
            )
            parser = RoughParser(test_string)
            self.assertEqual(parser.get_num_lines_in_stmt(), 3)

    unittest.main(module=__name__, argv=[__file__])



# Generated at 2022-06-22 03:20:28.857755
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    # Test that the return from __iter__ is what is expected
    expected = (1, 2, 3, 4, 5)
    stpm = StringTranslatePseudoMapping({1: 1, 2: 2, 3: 3, 4: 4, 5: 5}, None)
    actual = tuple(iter(stpm))
    assert actual == expected

# Generated at 2022-06-22 03:20:36.628941
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    from unittest import TestCase
    from typing import Sequence

    class TestStringTranslatePseudoMapping(TestCase):
        strings = (
            "Hello",
            "World",
        )

        def _test(self, *, mapping, expected):
            # type: (StringTranslatePseudoMapping, Sequence[str]) -> None
            result = ''.join(chr(c) for c in iter(mapping))
            self.assertEqual(result, expected)

        def test_string(self):
            mapping = StringTranslatePseudoMapping({ord(self.strings[0][0]): ord('A')},
                                                   ord('Z'))
            self._test(mapping=mapping, expected='Aello')

        def test_all_but_one(self):
            mapping = StringTrans

# Generated at 2022-06-22 03:20:47.727797
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    # pylint: disable=redefined-builtin
    if RoughParser.is_block_opener.__doc__:
        doc = RoughParser.is_block_opener.__doc__
    else:
        doc = "No docstring"
    print("test_RoughParser_is_block_opener:", doc)
    lines = [
        "a=b+c",
        "if foo:",
        "    bar(baz, quux)",
        "x=2",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
    ]
    s = "\n".join(lines)
    rp = RoughParser(s)

# Generated at 2022-06-22 03:20:56.539480
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    source = [
        "x = 1",
        "",
        "y = 2",
        "",
        "z = \\",
        "    3",
        "",
        "if x == 1:",
        "    x = x + 1",
        ""
    ]
    for i in range(len(source)):
        parser = RoughParser(source, i)
        print(
            "source[{}] is {}".format(
                i, "continued" if parser.get_continuation_type() else "not continued"
            )
        )


# Generated at 2022-06-22 03:21:03.468042
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    for key, value in StringTranslatePseudoMapping({0:0}, 10).items():
        assert value == key
    v2 = StringTranslatePseudoMapping({0:0}, 10)
    assert v2.get(0) == 0
    assert v2.get(1) == 10

# Match the first element of a bracket structure, which may be
# followed by more brackets if we're inside some kind of bracket
# structure.  If match is successful, m.end() less 1 is the index of
# the last interesting char matched.  If match is unsuccessful, the
# string starts with an interesting char.


# Generated at 2022-06-22 03:21:13.620622
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from idlelib import parenmatch

    text = parenmatch.ParenMatchTestText(
        "abc",
        _test=True,
        #           012345678
    )
    index = "3.0"
    #                           012345678
    assert text.get(1.0, END) == "abc\n\n\n"
    #                           0123456789012
    assert text.get(1.0, "4.0 linestart") == "abc\n\n"
    assert HyperParser(text, index).rawtext == text.get(1.0, "4.0 linestart")
    assert HyperParser(text, "1.0").rawtext == text.get(1.0, "2.0 linestart")
    assert HyperParser(text, "2.0").raw

# Generated at 2022-06-22 03:21:21.076395
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
  hp = HyperParser('hello world "wonderful" goodbye', '1.0')
  assert hp.is_in_code()
  assert not hp.is_in_string()
  hp.set_index('1.13')
  assert hp.is_in_code()
  assert hp.is_in_string()
  hp.set_index('1.18')
  assert hp.is_in_code()
  assert not hp.is_in_string()
