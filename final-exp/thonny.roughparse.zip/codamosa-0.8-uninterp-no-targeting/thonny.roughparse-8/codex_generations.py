

# Generated at 2022-06-22 03:18:27.904682
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():

    def check(source, expected_expression):
        """Given a source string, try all positions in it, and checks
        that get_expression returns the expected_expression string.

        For example:

        check('a.b', 'b')

        checks that get_expression('a.b', i) will return 'b' for all
        i=0,1,2.
        """
        for i in range(len(source)):
            index = "%d.%d" % (i + 1, i)
            if HyperParser(source, index).get_expression() != expected_expression:
                print("Error in get_expression, source=%s, index=%s" % (repr(source), index))
                return False
        return True

    check('a.b', 'b')
    check('a.b.c', 'c')

# Generated at 2022-06-22 03:18:39.604508
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # Test whether HyperParser.is_in_code() correctly detects whether the
    # given index is inside a string or not.
    import unittest

    class ParserTest(unittest.TestCase):
        def setUp(self):
            self.text = text = tkinter.Text()
            text.insert(1.0, "hello world")
            text.insert("2.0", "this is a\nsecond line")
            text.insert("3.0", "# this is a comment")
            text.insert("4.0", "'''another\nmulti-line\ncomment'''")
            text.insert("5.0", '"this is a\nstring"')
            self.parser = HyperParser(text, "1.0")

        def do_test(self, pos, expected):
            self.parser

# Generated at 2022-06-22 03:18:50.055438
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # Test 1. This 'ipython' console interaction is the first test
    # in the IPython cookbook:
    # https://ipython.readthedocs.io/en/stable/interactive/tutorial.html#code-completion
    # The selection from IPython's history contains two examples.
    source = """# IPython History

In [1]: import sys

In [2]: sys.executable
Out[2]: '/opt/anaconda3/envs/c3i/bin/python3.7'

In [3]: import re

In [4]: re.match?
Docstring:
Try to apply the pattern at the start of the string, returning
a match object, or None if no match was found."""

# Generated at 2022-06-22 03:19:02.835428
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def do_test(input, index, expect):
        h = HyperParser(input, index)
        got = h.is_in_code()
        if got != expect:
            print("input:", repr(input))
            print("index:", repr(index))
            print("expect:", repr(expect))
            print("got:", repr(got))
            print()

    def do_tests(input, *args):
        for index, expect in args:
            do_test(input, index, expect)


# Generated at 2022-06-22 03:19:09.068317
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = Tk.Text()
    # Initialize the text widget with some content
    # text = 'String in an expression()\nCode:\n from a module().\n'
    text.insert("1.0", 'String in an expression()\nCode:\n from a module().\n')
    text.mark_set("insert", "1.0")

# Generated at 2022-06-22 03:19:20.910375
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-22 03:19:31.965740
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    rp = RoughParser("")
    assert rp.find_good_parse_start() == 0

    rp = RoughParser("if 1:\n  pass\n  pass")
    assert rp.find_good_parse_start() == 0
    assert rp.find_good_parse_start(1) == 0
    assert rp.find_good_parse_start(2) == 0
    assert rp.find_good_parse_start(3) == 0
    assert rp.find_good_parse_start(4) == 0
    assert rp.find_good_parse_start(5) == 3
    assert rp.find_good_parse_start(6) == 3
    assert rp.find_good_parse_start(7) == 0

# Generated at 2022-06-22 03:19:36.610364
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    from idlelib.idle_test.htest import run
    run(RoughParser_test)

if __name__ == '__main__':
    test_RoughParser_get_continuation_type()

# Generated at 2022-06-22 03:19:45.998916
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    pos = "1.0"
    text = TextWidget(pos)
    text.insert(pos, "if 1:\n    'a string'")
    text.insert("1.end", "\n")
    text.mark_set("insert", pos)
    parser = HyperParser(text, pos)
    assert parser.is_in_string() == False

    txt = """\
True
isinstance(True, keyword.Keyword)
"""
    import keyword

    for line in txt.splitlines():
        if line.startswith("#"):
            continue
        expr = line.split("(", 1)[1].rsplit(")", 1)[0]
        res = eval(expr)
        assert res == parser.get_expression(), (expr, res, parser.get_expression())



# Generated at 2022-06-22 03:19:54.660275
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    from unittest import TestCase, main
    class Test(TestCase):
        def test_empty(self):
            rough_parser_ = RoughParser('')
            self.assertEqual(rough_parser_.get_base_indent_string(),
                '')
        def test_one_space(self):
            rough_parser_ = RoughParser(' ', 4)
            self.assertEqual(rough_parser_.get_base_indent_string(),
                ' ')
        def test_one_tab(self):
            rough_parser_ = RoughParser('\t', 4)
            self.assertEqual(rough_parser_.get_base_indent_string(),
                '\t')
        def test_one_space_one_tab(self):
            rough_parser_ = RoughParser(' \t', 4)
           

# Generated at 2022-06-22 03:20:42.599002
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    assert HyperParser(Tkinter.Text, "1.0").is_in_code()
    assert HyperParser(Tkinter.Text, "1.1").is_in_code()
    assert not HyperParser(Tkinter.Text, "1.2").is_in_code()
    assert not HyperParser(Tkinter.Text, "1.3").is_in_code()
    assert not HyperParser(Tkinter.Text, "1.4").is_in_code()
    assert not HyperParser(Tkinter.Text, "1.5").is_in_code()
    assert HyperParser(Tkinter.Text, "1.6").is_in_code()

    # Test that we don't get fooled by colons

# Generated at 2022-06-22 03:20:47.481069
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import TestCase

    class HyperParserTC(TestCase):
        """Unit test for HyperParser's is_in_code method"""

        def test_is_in_code(self):
            text = Text(None, {"indentwidth": 8, "tabwidth": 8})

# Generated at 2022-06-22 03:20:57.072487
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    #
    # (1) Setting a larger line offset.
    rp = RoughParser("a\n  b\n    c", 2)
    assert rp.get_line_offset() == 2
    assert rp.get_base_indent_string() == "  "
    assert rp.is_block_opener()

    #
    # (2) Setting a smaller line offset.
    rp.set_lo(1)
    assert rp.get_line_offset() == 1
    assert rp.get_base_indent_string() == ""
    assert not rp.is_block_opener()



# Generated at 2022-06-22 03:21:03.885316
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    lines = ["s = '''",
             "some stuff",
             "'''",
             "some other stuff",
             "    l = (",
             "        '''",
             "        some more stuff",
             "        '''",
             "    )",
             "    more stuff"]
    def test(text):
        print('-' * 20)
        print(text)
        r = RoughParser(text, indent_width=1)
        print(r.get_last_open_bracket_pos())
        print(r.get_last_stmt_bracketing())
    test('  '.join(lines))
    test('\n'.join(lines))


# ----------------------------------------------------------------------
# The specific logic of the indentation rules is implemented in
# the following classes.  The main entry point is the class
# Parser.

# Generated at 2022-06-22 03:21:14.853846
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    r = RoughParser(indent_width=4, tabwidth=8)
    r.set_str("""
        def foo(a,
                b, c):



            if a < b:
                a = b
            elif a > c:
                a = c
            else:
                a = d

            while a <> 0:
                # a comment
                a = a - 3
                a = a - 1
            return a
    """)
    assert r.get_continuation_type() == C_NONE
    assert r.compute_bracket_indent() == 12
    assert r.get_num_lines_in_stmt() == 1
    assert r.compute_backslash_indent() == 16
    assert r.get_base_indent_string() == ""
    assert not r

# Generated at 2022-06-22 03:21:25.906452
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    h = HyperParser(None, None)
    h.rawtext = "foo"
    h.indexbracket = 0
    h.bracketing = [(0, 0)]
    h.isopener = [False]
    h.set_index("0.0")
    assert h.is_in_code()
    h.rawtext = "foo"
    h.indexbracket = 0
    h.bracketing = [(0, 0)]
    h.isopener = [True]
    h.set_index("0.0")
    assert not h.is_in_code()
    h.rawtext = "foo"
    h.indexbracket = 0
    h.bracketing = [(0, 0)]
    h.isopener = [True]
    h.set_index("0.1")


# Generated at 2022-06-22 03:21:32.473779
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    """
    >>> m = StringTranslatePseudoMapping({1:2, 3:4}, 5)
    >>> sorted(list(m))
    [1, 3]
    >>> m = StringTranslatePseudoMapping({}, 5)
    >>> sorted(list(m))
    []
    """


# Generated at 2022-06-22 03:21:44.701516
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-22 03:21:46.311163
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-22 03:21:57.139048
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    def t(str, expect):
        assert RoughParser(str).is_block_closer() == expect

    t("try:\n"
      "    foo\n",
      False)
    t("try:\n"
      "    foo\n"
      "except:\n"
      "    bar\n",
      False)
    t("try:\n"
      "    foo\n"
      "finally:\n"
      "    bar\n",
      False)
    t("try:\n"
      "    foo\n"
      "except:\n"
      "    bar\n"
      "finally:\n"
      "    baz\n",
      False)


# Generated at 2022-06-22 03:24:44.572963
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # dash at start of stmt
    prog = """\
         if 1:
             -1
         """
    result = RoughParser(prog, 2).compute_backslash_indent()
    assert result == 5

    # equals sign at start of stmt
    prog = """\
         if 1:
             =1
         """
    result = RoughParser(prog, 2).compute_backslash_indent()
    assert result == 4

    # equals sign in middle of stmt
    prog = """\
         if 1:
             2=1
         """
    result = RoughParser(prog, 2).compute_backslash_indent()
    assert result == 5

    # equals sign in middle of unmatched open bracket
    prog = """\
         if 1:
             a=[2=1
         """