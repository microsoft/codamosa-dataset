

# Generated at 2022-06-22 03:17:33.431678
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest

    class HyperParser_set_index_tc(unittest.TestCase):
        def check_set_index(self, code, index):
            code = code.splitlines()
            h = HyperParser(text, index)
            h.set_index(index)
            return (h.rawtext, h.stopatindex,
                    h.bracketing, h.isopener, h.indexinrawtext, h.indexbracket)

        def test_set_index(self):
            global text
            code = """\
                one = fish
                two = fish
                red = fish
                blue = fish
            """
            #                            012345678901234567890123456789012345678901
            #                            0         1         2         3         4

# Generated at 2022-06-22 03:17:34.319813
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    assert StringTranslatePseudoMapping({}, ord('x'))



# Generated at 2022-06-22 03:17:47.381516
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def test_text_before_statement(self):
            text = " \n\n\n\n    a = 3\n"
            h = HyperParser(text, 4.0)
            self.assertEqual(h.rawtext, "a = 3")
            self.assertEqual(h.bracketing, [(4, 0)])
            self.assertEqual(h.isopener, [False])
            self.assertEqual(h.indexinrawtext, 0)
            self.assertEqual(h.indexbracket, 0)

        def test_text_inside_statement(self):
            text = "a = 3\n"
            h = HyperParser(text, 1.0)

# Generated at 2022-06-22 03:17:59.401829
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    from _tokenize import tokenize
    from io import BytesIO
    from unittest import TestCase, main
    from io import StringIO

    def check(s, expected):
        result = str(RoughParser(s, 0, len(s), 0).get_last_stmt_bracketing())
        assert result == expected, result

    check("", "()")
    check("print 'foo'", "((0, 0), (7, 1), (11, 0))")
    check("print 'foo' # comment", "((0, 0), (7, 1), (11, 0))")
    check("print 'foo' # comment\\",
          "((0, 0), (7, 1), (11, 0), (19, 1), (19, 0))")

# Generated at 2022-06-22 03:18:07.392369
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    # Test case: no continuation.
    p = RoughParser("a = 1 + 2\n")
    assert p.get_continuation_type() == C_NONE
    assert p.get_num_lines_in_stmt() == 1

    # Test case: backslash continuation.
    p = RoughParser("a = 1 + 2 \\\n        + 3\n")
    assert p.get_continuation_type() == C_BACKSLASH
    assert p.get_num_lines_in_stmt() == 2

    # Test case: bracket continuation.
    p = RoughParser("a = (1 + 2\n      + 3)\n")
    assert p.get_continuation_type() == C_BRACKET
    assert p.get_num_lines_in_stmt() == 2

    # Test case: first

# Generated at 2022-06-22 03:18:12.080114
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    """Test for method __len__ of class StringTranslatePseudoMapping
    """
    preserve_dict = {ord(c): ord(c) for c in ' \t\n\r'}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == 4



# Generated at 2022-06-22 03:18:24.309758
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest
    import unittest.mock

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.text = unittest.mock.Mock()
            self.text.indent_width.return_value = 8
            self.text.tabwidth.return_value = 8

        def test_index_in_statement(self):
            h = HyperParser(self.text, "insert")

            self.text.get.return_value = "abc = 'abc'"
            self.assertEqual(h.get_expression(), "abc = 'abc'")

            self.text.get.return_value = "abc"
            self.assertEqual(h.get_expression(), "abc")

            self.text.get.return_value = ""
            self.assertEqual

# Generated at 2022-06-22 03:18:37.199496
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    def do(s, expected_indent):
        p = RoughParser(s, 0)
        b = p.compute_backslash_indent()
        assert b == expected_indent

    # Test one line
    do(
        r'''
        first
        ''',
        6,
    )
    # Test multiline
    do(
        r'''
        first
           second
        ''',
        9,
    )
    # Test multiline with whitespace
    do(
        r'''
        first
            second
        ''',
        11,
    )

    # Test multiline with comment
    do(
        r'''
        first
            # comment
        ''',
        11,
    )

    # Test

# Generated at 2022-06-22 03:18:48.073352
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # pylint: disable=invalid-name, redefined-builtin
    rp = RoughParser()

    line = "class X:\n"
    rp.set_lo(line)
    assert rp.get_base_indent_string() == ""

    line = "    def y():\n"
    rp.set_lo(line)
    assert rp.get_base_indent_string() == "    "

    line = "if x:\n"
    rp.set_lo(line)
    assert rp.get_base_indent_string() == "    "

    line = "    return\n"
    rp.set_lo(line)
    assert rp.get_base_indent_string() == "    "


# Generated at 2022-06-22 03:18:53.127133
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    parser = RoughParser(indent_width=4, tabwidth=4)
    parseable_code = ("if True:\n"
                      "    print('Hello World')\n")
    parser.set_str(parseable_code)
    # second to last line is the header of a block
    print(parser.is_block_opener())


# Generated at 2022-06-22 03:19:32.149540
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    """
    Test case for method _find_good_parse_start of class RoughParser
    """
    rough_parser = RoughParser("    x = 0", 1, 8)
    assert rough_parser.find_good_parse_start() == 8

    rough_parser = RoughParser("    ['spam', 'eggs']", 1, 8)
    assert rough_parser.find_good_parse_start() == 0

    rough_parser = RoughParser("# a string\n['spam', 'eggs']", 1, 8)
    assert rough_parser.find_good_parse_start() == 0

    rough_parser = RoughParser("    # a string\n['spam', 'eggs']", 1, 8)
    assert rough_parser.find_good_parse_start() == 0


# Generated at 2022-06-22 03:19:43.349914
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-outer-name
    import unittest.mock as mock  # pylint: disable=import-error

    parser = RoughParser("", 0, 0)
    compute_bracket_indent = mock.Mock(spec=parser.compute_bracket_indent)
    parser.compute_bracket_indent = compute_bracket_indent
    parser.get_base_indent_string = mock.Mock(spec=parser.get_base_indent_string)
    parser.get_base_indent_string.return_value = ""
    parser.get_last_open_bracket_pos = mock.Mock(spec=parser.get_last_open_bracket_pos)

# Generated at 2022-06-22 03:19:49.071818
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    from test.test_tokenize import generate_tests
    for good in generate_tests(want_skip=False, want_readline=False):
        rp = RoughParser(good)
        # rp._study1()
        # print(rp.continuation, good)
        ctype = rp.get_continuation_type()
        assert ctype in C_ALL


# Generated at 2022-06-22 03:19:56.260412
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # Test case #1:
    assert RoughParser(_dedent(
        """
        if True:  # zeni debe\
        # zeni debe
            pass
        """).expandtabs()).compute_backslash_indent() == 4
    # Test case #2:
    assert RoughParser(_dedent(
        """
        if True:  # zeni debe\
        # zeni debe
        """).expandtabs()).compute_backslash_indent() == 4
    # Test case #3:
    assert RoughParser(_dedent(
        """
        if True:  # zeni debe
        # zeni debe\
        pass
        """).expandtabs()).compute_backslash_indent() == 4
    # Test case #4:

# Generated at 2022-06-22 03:20:06.967198
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    """Unit test for method compute_backslash_indent of class RoughParser
    """
    rp = RoughParser('x = \\')
    assert rp.compute_backslash_indent() == 1
    rp = RoughParser('x = [1, \\')
    assert rp.compute_backslash_indent() == 1 + 4
    rp = RoughParser('    x = [1, \\')
    assert rp.compute_backslash_indent() == 5 + 4
    rp = RoughParser('x = [1, \\')
    rp.str = 'x=1'
    assert rp.compute_backslash_indent() == 1
    rp = RoughParser('if (1): x = [1, \\')
    assert rp.compute_backslash_

# Generated at 2022-06-22 03:20:14.747098
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    import unittest
    from types import FunctionType
    class TestArgs:
        pass
    class RoughParserTests(unittest.TestCase):
        def test_00(self):
            args = TestArgs()
            args.indent_width = 4
            args.tabwidth = 8
            args.text = """\
if fred(alex): # trailing comment
    return 5
        """.split("\n")
            args.expected_as_pos_or_neg_or_zero = [
                0,
                0,
                0,
                0,
                0,
                8,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                -1,
            ]
            args.expected_as_pos_or_neg_

# Generated at 2022-06-22 03:20:22.510206
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    # Replace all chars except 'x' with 'o'
    stpm = StringTranslatePseudoMapping({ord('x'): ord('x')}, ord('o'))

    for c in string.ascii_letters:
        assert stpm[ord(c)] == ord('o')
    assert stpm[ord('x')] == ord('x')

    # Replace all chars except 'x' and 'y' with 'o'
    stpm = StringTranslatePseudoMapping({ord('x'): ord('x'), ord('y'): ord('y')}, ord('o'))

    for c in string.ascii_letters:
        if c in 'xy':
            assert stpm[ord(c)] == ord(c)
        else:
            assert stpm[ord(c)] == ord('o')




# Generated at 2022-06-22 03:20:29.481044
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'


# Generated at 2022-06-22 03:20:37.172312
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # Test 1, the default case.
    text = Text(None, "a = 10")
    a = HyperParser(text, "1.0")
    assert a.get_expression() == ""
    a.set_index("1.2")
    assert a.get_expression() == "a"
    a.set_index("1.3")
    assert a.get_expression() == "a"

    # Test 2, the case where the bracketing changes.
    text.replace("1.5", "1.5", "\n")
    a.set_index("2.0")
    assert a.get_expression() == ""
    a.set_index("2.2")
    assert a.get_expression() == "10"
    a.set_index("2.3")

# Generated at 2022-06-22 03:20:40.778175
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    assert StringTranslatePseudoMapping({1: 1}, 1).__len__() == 1



# Generated at 2022-06-22 03:22:04.114716
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    # Call function using the typical arguments
    assert test_StringTranslatePseudoMapping___len__.__annotations__ == {}
    # Call function using other positional arguments
    # Call function using varargs
    # Call function using kwargs



# Generated at 2022-06-22 03:22:11.196140
# Unit test for constructor of class HyperParser
def test_HyperParser():
    global parser, rawtext
    h = HyperParser("""this text# is intended
#to test the HyperParser""", "7.0")
    assert h.rawtext == "this text# is intended\n", h.rawtext

# Generated at 2022-06-22 03:22:21.828666
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    # !+RENAME(mr, apr-2011) re-enable test
    # f = StringTranslatePseudoMapping({'a': 1, 'b': 2, 'c': 3}, 'x')
    # assert list(f) == ['a', 'b', 'c']
    pass


# Generated at 2022-06-22 03:22:31.605181
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    pseudo_dict = StringTranslatePseudoMapping({ord('a'): None}, ord('x'))
    given = "aBcD"
    expected = "xBcD"
    result = given.translate(pseudo_dict)
    if result != expected:
        print(f"Str.translate() failed "
              f"pseudo_dict={pseudo_dict!r}, given={given!r}: "
              f"expected {expected!r}, got {result!r}")

test_StringTranslatePseudoMapping()

# This dict maps chars to "special" for all special chars
# (including leading '\').  Used for quick checks in
# classify() and various chew_*() functions.

special_dict = {c: "special" for c in r"""#'"\[](){}"""}

# Generated at 2022-06-22 03:22:43.222335
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser(indent_width=4, tabwidth=8)
    rp.set_str("    if a:")
    assert rp.get_base_indent_string() == "    "
    assert rp.get_continuation_type() == C_NONE

    # single line continuation
    rp.set_str("    if a:\\\n  b")
    assert rp.get_continuation_type() == C_BACKSLASH
    assert rp.compute_backslash_indent() == 2

    # multiple line continuation
    rp.set_str("    if a:\\\n        b")
    assert rp.get_continuation_type() == C_BACKSLASH
    assert rp.compute_backslash_indent() == 6

    # bracketing

# Generated at 2022-06-22 03:22:53.100660
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    assert StringTranslatePseudoMapping({'a': '2'}, 'x')['a'] == '2'

    # The following program is adapted from PEP 3116 -- Revising Dictionary
    # Comparisons.
    # https://www.python.org/dev/peps/pep-3106/
    #
    # It is used to test that the internal dictionary lookup works correctly
    # for integer keys:
    #
    # >>> a = []
    # >>> a.append(a)
    # >>> d = {}
    # >>> d[0] = a
    # >>> d[1] = d
    # >>> d[0] is d[1][0]
    # True
    # >>> d[1][0] is d[1][1][0]
    # True
    # >>>
    #
    # To reproduce

# Generated at 2022-06-22 03:23:05.042440
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import test.support
    from idlelib.idle_test.mock_idle import Func
    with test.support.captured_stdout() as stdout:
        root = Tk()
        PmwBlt.initialise(root)
        root.option_add('*dialog*background', 'grey')
        root.option_add('*dialog*Font', 'TkFixedFont')
        text = Text(root)
        text.pack()

        def index2line(index):
            return int(float(index))
        text.insert('insert', 'a = "123abc"\n')
        text.insert('insert', '  def blah(a):\n')
        text.insert('insert', "    print(a)\n")
        text.insert('insert', "blah('ok')\n")

# Generated at 2022-06-22 03:23:17.042156
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    m = StringTranslatePseudoMapping({ord('a'): ord('x')}, ord('y'))
    assert m[ord('a')] == ord('x')
    assert m[ord('b')] == ord('y')
    assert m.get(ord('a'), ord('z')) == ord('x')
    assert m.get(ord('b'), ord('z')) == ord('z')
del test_StringTranslatePseudoMapping_get

# Match an open bracket char.

_openers = r"[[{(]"

_openerre = re.compile(
    r"""
    [ \t]*
    (?:
        %s |
        \Z
    )
"""
    % _openers,
    re.VERBOSE,
).match

# Match a closing

# Generated at 2022-06-22 03:23:24.813701
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == len(preserve_dict)



# Generated at 2022-06-22 03:23:32.351987
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    # pylint: disable=redefined-outer-name
    d = {
        "if 1:": "",
        "  if 2:": "  ",
        "if 1:\n  if 2:": "",
        "\t#comment": "\t",
        "\t#comment\n": "\t",
        "if 1:\n  if 2:\n    pass\n  if 3:": "  ",
    }
    for key in d.keys():
        rough_parser = RoughParser(key, 0)
        assert rough_parser.get_base_indent_string() == d[key]



# Generated at 2022-06-22 03:24:31.464418
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    def assertContinuationType(text, expected_continuation_type):
        parser = RoughParser(text)
        assert parser.get_continuation_type() == expected_continuation_type

    assertContinuationType("", C_NONE)
    assertContinuationType("x = 5", C_NONE)
    assertContinuationType("x = 5\\\n    + 6", C_BACKSLASH)
    assertContinuationType("x = 5 \\", C_BACKSLASH)
    assertContinuationType("x = 5\\\n   ", C_BACKSLASH)
    assertContinuationType("x = 5\\\n   # comment", C_BACKSLASH)
    assertContinuationType("x = 5\\\n   # comment\n", C_BACKSLASH)

# Generated at 2022-06-22 03:24:40.270798
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = Text(None)
    text.set("""\
a = [
    123,
    456,
    789,
]
b = {
    "abc": 123,
    "def": 456,
}
c = (
    "abc",
    "def",
    "ghi",
)
""")
    h = HyperParser(text, "1.0")
    eq = h.get_surrounding_brackets(mustclose=False)
    assert eq == ("1.0", "6.0"), eq


# Generated at 2022-06-22 03:24:44.760441
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"

