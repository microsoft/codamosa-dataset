

# Generated at 2022-06-22 03:15:50.031132
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    example = {1: 2, 3: 4}
    st = StringTranslatePseudoMapping(example, 2)
    r = list(st)
    assert r == [1, 3]
    r = list(st)
    assert r == [1, 3]

test_StringTranslatePseudoMapping___iter__()


# Generated at 2022-06-22 03:15:54.994033
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    mapping = StringTranslatePseudoMapping(dict(), ord('x'))
    assert len(mapping) == 0
    mapping = StringTranslatePseudoMapping({1: 2}, ord('x'))
    assert len(mapping) == 1



# Generated at 2022-06-22 03:15:58.101682
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = tkinter.Text()
    text.insert("insert", "def f(x):\n  return 2*x\ny = f(3)")
    text.mark_set("insert", "2.0")
    hp = HyperParser(text, "insert")



# Generated at 2022-06-22 03:16:04.574240
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    from unittest import TestCase
    from pickle import dumps, loads

    class Test(TestCase):
        def test(self):
            '''Unit test for method __len__ of class StringTranslatePseudoMapping'''
            test_data = [
                {
                    'non_defaults': {},
                    'default_value': 'x',
                    'len': 0,
                },
                {
                    'non_defaults': {'a': 'b'},
                    'default_value': 'x',
                    'len': 1,
                },
                {
                    'non_defaults': {'a': 'b', 'c': 'd'},
                    'default_value': 'x',
                    'len': 2,
                },
            ]
            for input in test_data:
                non_defaults = input

# Generated at 2022-06-22 03:16:14.965918
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    """
    >>> from pprint import pprint as pp
    >>> from idlelib.idle_test.mock_idle import Func
    >>> from test.test_parse import S

    >>> raw = """# comment
    ...

# Generated at 2022-06-22 03:16:26.658751
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    t = Tk()
    t.withdraw()

    def assert_hps(code, index, expected):
        # print("testing '%s' at %s ==> %s" % (code, index, expected))
        index = repr(index) + ".0"
        text = Text(t, width=40, height=4)
        text.insert(index=END, chars=code)
        hp = HyperParser(text, index)
        assert hp.is_in_string() == expected, "for code %s at %s expected %s" % (
            code,
            index,
            expected,
        )

    for index in range(6):
        assert_hps("'''a\nbc'''", index, False)
        assert_hps('"""a\nbc"""', index, False)

# Generated at 2022-06-22 03:16:29.156216
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    mapping = StringTranslatePseudoMapping({"test": "test"}, "test")
    assert len(mapping) == 1



# Generated at 2022-06-22 03:16:39.782982
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-22 03:16:46.865145
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Just for documentation, the test is not automated.
    import unittest
    import textwrap

    class _Test(unittest.TestCase):
        def t(self, text, index, expected):
            hyper = HyperParser(text, index)
            result = hyper.get_surrounding_brackets()
            self.assertEqual(expected, result)

    test = _Test()

# Generated at 2022-06-22 03:16:53.398074
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=redefined-builtin

    # Smoke tests
    parse = RoughParser("")
    parse = RoughParser("\n")
    parse = RoughParser("\n\n\n")

    parse = RoughParser("blah")
    assert parse.get_base_indent_string() == ""
    assert parse.get_continuation_type() == C_NONE

    parse = RoughParser("blah\nblah")
    assert parse.get_base_indent_string() == ""
    assert parse.get_continuation_type() == C_NONE

    parse = RoughParser("blah\n  blah")
    assert parse.get_base_indent_string() == "  "
    assert parse.get_continuation_type() == C_NONE


# Generated at 2022-06-22 03:17:33.040211
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-22 03:17:40.731080
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-22 03:17:51.439812
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # Some tests for find_good_parse_start
    str = """\
if 1:
    if 1: pass
    else: pass
else:
    try:
        1/0
    except Exception:
        pass"""
    rough_parser = RoughParser(str, "test_RoughParser_find_good_parse_start")

    def check(line, expected_index):
        i = rough_parser.find_good_parse_start(line)
        assert i == expected_index, (line, i, expected_index)

    check(0, 0)
    check(1, 0)
    check(2, 5)
    check(3, 5)
    check(4, 5)
    check(5, 5)
    check(6, 5)
    check(7, 5)
    check(8, 5)

# Generated at 2022-06-22 03:18:02.138918
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    from test.test_support import run_unittest
    import unittest

    class Test(unittest.TestCase):

        def _helper(self, text, expected):
            preparser = RoughParser(text, 0)
            self.assertEqual(preparser.compute_backslash_indent(), expected)

        def test_compute_backslash_indent(self):
            self._helper("if a:\\\n    b", 4)
            self._helper("if a:\\\n    pass", 4)
            self._helper("if a:\\\n    b = c", 4)
            self._helper("if x == 4:\\\n    print x, y; x, y = y, x", 4)

# Generated at 2022-06-22 03:18:06.467239
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    test_dict = dict(zip(range(10), range(10)))
    m = StringTranslatePseudoMapping(test_dict, 'x')
    assert set(m) == set(test_dict)



# Generated at 2022-06-22 03:18:18.171124
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    expected_value = 'Hello, World!'
    default_replacement = '?'
    mapping = StringTranslatePseudoMapping({ord(c): ord(c) for c in expected_value}, ord(default_replacement))
    expected_result = expected_value + '?'
    assert (
        ''.join(chr(c) for c in expected_result).translate(mapping) == expected_result
    )
    assert ''.join(chr(c) for c in expected_value).translate(mapping) == expected_value

# list of characters that need to be escaped with a backslash
# when they occur in a string literal
#
# Note that this should be kept in sync with the list of characters
# that are escaped in idlelib.editor.indent.IndentSearcher.adjust_indent
#
_

# Generated at 2022-06-22 03:18:30.532323
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    assert HyperParser(tk.Text(), "1.0").is_in_code()
    assert HyperParser(tk.Text(), "1.0").is_in_code()
    assert HyperParser(tk.Text(), "1.0").is_in_code()
    assert not HyperParser(tk.Text(), "1.0").is_in_code()
    assert not HyperParser(tk.Text(), "1.0").is_in_code()
    assert HyperParser(tk.Text(), "1.0").is_in_code()
    assert HyperParser(tk.Text(), "1.0").is_in_code()
    assert not HyperParser(tk.Text(), "1.0").is_in_code()
    assert not HyperParser(tk.Text(), "1.0").is_in_code()

# Generated at 2022-06-22 03:18:42.811070
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def t(code, width, expected):
        got = RoughParser(code, width).compute_bracket_indent()
        assert got == expected, (code, width, got, expected)

    t("[   ]  ", 2, 4)
    t("[   ]  ", 4, 4)
    t("[   ]  ", 8, 8)
    t("[   ]  \n", 2, 5)
    t("[   ]  \n", 4, 5)
    t("[   ]  \n", 8, 9)

    t("[\n  ]", 2, 5)
    t("[\n  ]", 4, 5)
    t("[\n  ]", 8, 9)

    t("[\n  ]\n", 2, 0)

# Generated at 2022-06-22 03:18:49.783456
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    from pytest import raises
    from pytest import mark

    from .hyperparser import StringTranslatePseudoMapping

    @mark.parametrize('a, b, c', [

    ])
    def test_StringTranslatePseudoMapping___len___01():
        a = {'a': 1, 'b': 2, 'c': 3}
        b = 2
        c = StringTranslatePseudoMapping(a, b)
        d = len(c)
        assert d == 3

    test_StringTranslatePseudoMapping___len___01()

# Generated at 2022-06-22 03:19:02.605983
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-22 03:21:33.097703
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    """Unit test for method __len__ of class StringTranslatePseudoMapping"""

    # Test with empty dict
    #
    class Test(StringTranslatePseudoMapping):
        pass
    obj = Test({}, 'x')
    assert len(obj) == 0

    # Test with non-empty dict
    #
    non_defaults = {ord('a'): None}
    obj = Test(non_defaults, 'x')
    assert len(obj) == len(non_defaults)


# Generated at 2022-06-22 03:21:45.025364
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    rp = RoughParser(text_for_tests.get_text_for_tests_with_comments(), 4)
    rp.get_last_stmt_bracketing()

# Generated at 2022-06-22 03:21:54.063064
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    text.translate(mapping)
    def _get(key, _get=preserve_dict.get, _default=ord('x')):
        return _get(key, _default)
    for item in iter(mapping):
        get = _get(item)
        assert get == mapping[item]



# Generated at 2022-06-22 03:22:00.333929
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    preserve_dict = {ord('a'): ord('a')}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert mapping.get('a') == ord('a')
    assert mapping.get(ord('a')) == ord('a')
    assert mapping.get('b') == ord('x')
    assert mapping.get(ord('b')) == ord('x')


# Generated at 2022-06-22 03:22:08.223845
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    class DocTestMapping(StringTranslatePseudoMapping):
        def __init__(self, non_defaults, default_value):
            pass

    d = DocTestMapping({}, None)
    test_cases = (({}, 0, None), ({3: 3}, 1, None),
                  (#
                   {'a': 'b', 'c': 'd'},
                   2,
                   None
                  ))  #
    for test_case in test_cases:
        d.__init__(test_case[0], test_case[2])
        expected = test_case[1]
        actual = len(d)
        assert actual == expected, 'expected {}, got {}'.format(expected, actual)



# Generated at 2022-06-22 03:22:20.331731
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    from types import ModuleType

    from lib2to3.pgen2.tokenize import generate_tokens

    from lib2to3.tests import test_grammar
    from lib2to3.pygram import python_symbols, python_grammar_no_print_statement
    from lib2to3.pytree import Leaf, Node
    from lib2to3.pgen2 import driver

    _driver = driver.Driver(python_grammar_no_print_statement, convert=convert_node)

    # build grammar (metagrammar)
    g = _driver.grammar
    g.start = "file_input"

    # build symbol map
    symbols = {}
    for t in g.symbol2number.items():
        symbols[t[1]] = t[0]

    # import checker

# Generated at 2022-06-22 03:22:29.610007
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    from lib2to3.pgen2.tokenize import generate_tokens, generate_tokens, StringIO, tokenize
    from lib2to3.pgen2 import driver, token

    #
    # Test if the line_offset attribute and the first_line_num attribute of the
    # RoughParser are set properly.
    #
    # Test if the offset in the brackets is right.
    # The brackets is a list of tuples, each tuple representing a bracket. The tuple
    # structure is (bracket_offset, bracket_type).
    #
    # Test if the bracket_type is right.
    # The bracket_type is an int, representing the type of the bracket.
    # 0: no bracket
    # 1: open bracket
    # 2: closing bracket
    # 3: open and closed bracket (like string)
    #

# Generated at 2022-06-22 03:22:40.805045
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-22 03:22:48.701175
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    """assert that the constructor works as intended"""
    # replace everything except whitespace with 'x':
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"

    assert text.translate(mapping) == 'x x x\tx\nx'



# Generated at 2022-06-22 03:22:56.759593
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    class DictLike(object):
        def __init__(self, items):
            self._items = items

        def get(self, key, default=None):
            return self._items.get(key, default)

    sm = StringTranslatePseudoMapping(DictLike({ord('a'): ord('x')}), ord('-'))
    assert sm.get(ord('a')) == ord('x')
    assert sm.get(ord('b')) == ord('-')
    sm = StringTranslatePseudoMapping(DictLike({}), ord('-'))
    assert sm.get(ord('a')) == ord('-')
    assert sm.get(ord('b')) == ord('-')

