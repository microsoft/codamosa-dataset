

# Generated at 2022-06-22 03:16:18.105728
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'



# Generated at 2022-06-22 03:16:28.685383
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    p = HyperParser
    assert p("-1", "1.0").get_surrounding_brackets() == ("1.0", "1.2")
    assert p("-((1))", "1.1").get_surrounding_brackets() == ("1.0", "1.2")
    assert p("-(-((1))", "1.0").get_surrounding_brackets() == ("1.0", "1.4")
    assert p("-((1))", "1.3").get_surrounding_brackets() == ("1.0", "1.4")
    assert p("-((1))", "1.4").get_surrounding_brackets() == ("1.0", "1.4")

    assert p("-(1)", "1.0").get_surrounding_br

# Generated at 2022-06-22 03:16:39.420619
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    class FakeText:
        def __init__(self, text, indent_width=0, tabwidth=8):
            self.text = text
            self.indent_width = indent_width
            self.tabwidth = tabwidth

        def get(self, start, stop):
            return self.text[int(start.split(".")[0]) : int(stop.split(".")[0])]

        def index(self, index):
            return repr(int(index.split(".")[0]))+".0"

# Generated at 2022-06-22 03:16:46.596874
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class HyperParser_get_expression_TestCase(unittest.TestCase):
        def setUp(self):
            self.ignore_whitespace_chars = " \t\n"

        def tearDown(self):
            self.ignore_whitespace_chars = None

        def normalize_hyperparser_output(self, txt):
            pos = 0
            while True:
                pos = txt.find("\n", pos)
                if pos < 0:
                    break
                txt = txt[0:pos] + " " + txt[pos + 1 :]

            pos = 0
            while True:
                pos = txt.find("  ", pos)
                if pos < 0:
                    break

# Generated at 2022-06-22 03:16:58.656781
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    h = HyperParser("'foo' + 'bar'", "insert")
    if h.is_in_string():
        fail("'foo' + 'bar' should not be in a string")
    h.set_index("1.0")
    if not h.is_in_string():
        fail("'foo' + 'bar' should be in a string")
    h.set_index("3.0")
    if h.is_in_string():
        fail("'foo' + 'bar' should not be in a string")
    h.set_index("5.0")
    if not h.is_in_string():
        fail("'foo' + 'bar' should be in a string")
    h.set_index("7.0")

# Generated at 2022-06-22 03:17:08.864331
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    parser = RoughParser("""
if sentence.startswith("What's"):
    start_index = sentence.find("What's")
    end_index = sentence.find("?")
    sentence = sentence[start_index + 6:end_index]
    sentence = sentence.replace("'s", "")
    sentence = sentence.replace("your", "my")
    sentence = sentence.replace("you", "I")
    sentence = "My " + sentence
        """)
    assert parser.is_block_opener() == True

# Generated at 2022-06-22 03:17:20.549069
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # pylint: disable=redefined-builtin, invalid-name
    # Testing function - return True if the given continuation
    # status is expected

    def expect_continuation(status):
        if status != parser.get_continuation_type():
            print("Expected continuation:", status, "observed:", end=" ")
            print(parser.get_continuation_type())
            return 0
        return 1

    # Testing function - return True if the given statement
    # bracketing was observed

    def expect_bracketing(bracketing):
        if bracketing != parser.get_last_stmt_bracketing():
            print("Expected bracketing:", end=" ")
            print(bracketing, "observed:", end=" ")
            print(parser.get_last_stmt_bracketing())

# Generated at 2022-06-22 03:17:21.898518
# Unit test for method set_index of class HyperParser

# Generated at 2022-06-22 03:17:33.769635
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    t = "a='''b'''"
    parser = HyperParser(t, "1.0")
    assert not parser.is_in_string()

    parser = HyperParser(t, "2.0")
    assert parser.is_in_string()

    parser = HyperParser(t, "3.0")
    assert parser.is_in_string()

    parser = HyperParser(t, "4.0")
    assert not parser.is_in_string()

    parser = HyperParser(t, "4.3")
    assert not parser.is_in_string()

    t = "a='''b''\nc=d'''"
    parser = HyperParser(t, "2.0")
    assert parser.is_in_string()

    parser = HyperParser(t, "3.0")
    assert parser

# Generated at 2022-06-22 03:17:47.037190
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-22 03:18:30.082317
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-22 03:18:33.523849
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    test_dict = {1: "1", 2: "2"}
    mapping = StringTranslatePseudoMapping(test_dict, "default")
    assert len(mapping) == 2


# Generated at 2022-06-22 03:18:44.898930
# Unit test for constructor of class RoughParser
def test_RoughParser():
    def t(parastr, studylevel=3, continuation=C_NONE):
        p = RoughParser(parastr, tabsize)
        assert p.study_level == 0
        p.set_str(newparastr)
        assert p.study_level == 0
        p.set_study_level(studylevel, continuation)
        assert p.study_level == 2
        assert p.stmt_start is not None
        return p

    tabsize = 8
    #                123456789
    #                  0123456
    p = RoughParser(" if 1:\n"
                    "  pass\n"
                    "elif 0:\n", tabsize)
    assert p.basestring == " if 1:\n"
    assert p.continuation in (C_NONE, C_BRACKET)


# Generated at 2022-06-22 03:18:53.437934
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = "if (expr1):\n" "    pass\n" "elif (expr2):\n" "    pass\n"
    hp = HyperParser(text, "2.10")
    print(hp.get_surrounding_brackets(), "1.5", "2.10")
    hp.set_index("3.10")
    print(hp.get_surrounding_brackets(), "3.5", "4.10")
    hp.set_index("1.5")
    print(hp.get_surrounding_brackets(), "1.4", "2.10")
    hp.set_index("1.4")
    print(hp.get_surrounding_brackets(), "1.3", "2.10")
    hp.set_index("1.3")
    print

# Generated at 2022-06-22 03:19:06.659300
# Unit test for method set_str of class RoughParser

# Generated at 2022-06-22 03:19:11.929427
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    rp = RoughParser("print(1+#comment\n2)")
    assert rp.get_last_stmt_bracketing() == [(0, 0), (6, 1), (8, 0)]

# Basic unit test for class RoughParser

# Generated at 2022-06-22 03:19:24.673730
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-22 03:19:33.237963
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-22 03:19:44.027394
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    """Test the get_surrounding_brackets method of the HyperParser class"""


# Generated at 2022-06-22 03:19:51.499353
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    the_dict = {1: 'abc', 2: 'ABC'}
    the_mapping = StringTranslatePseudoMapping(the_dict, 'def')
    it = the_mapping.__iter__()
    value = next(it)
    assert (value == 1 or value == 2)
    value = next(it)
    assert (value == 1 or value == 2)
    try:
        value = next(it)
    except StopIteration:
        pass
    else:
        assert False, f"unexpected value {value!r}"

# Generated at 2022-06-22 03:21:04.873511
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-22 03:21:05.432626
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-22 03:21:09.093156
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    m = StringTranslatePseudoMapping({1: 2}, 3)
    assert m.get(0) == 3
    assert m.get(1) == 2
    assert m.get(2, 4) == 4
    assert m.get(3, 4) == 4



# Generated at 2022-06-22 03:21:21.076678
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    # create a dict containing only mappings for lowercase letters
    translate_dict = {ord(c): ord(c) for c in string.ascii_lowercase}
    mapping = StringTranslatePseudoMapping(translate_dict, ord('x'))

    # check that all mappings exist as expected
    for c in string.ascii_lowercase:
        assert(mapping.get(ord(c)) == ord(c))

    # check the default mapping
    assert(mapping.get(ord('Z'), None) == ord('x'))


# In Python 3.3+, the default str.translate() behaviour was changed to
# only perform translations on characters that were in the given mapping.
# Previously, the function would perform a translation for all characters.
#
# To restore the old behavior, we can use the class defined above

# Generated at 2022-06-22 03:21:33.444720
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    test_str = """
    def test(arg):
        pass
    def test(arg):
        pass
    def test(arg):
        pass
    def test(arg):
        pass
    def test(arg):
        pass
    def test(arg):
        pass
    def test(arg):
        pass
    """
    rp = RoughParser(test_str)
    assert rp.get_num_lines_in_stmt() == 1
    test_str = """
    def test(arg):
        pass
    def test(arg):
        pass
    def test(arg):
        pass\\
    def test(arg):
        pass
    def test(arg):
        pass
    def test(arg):
        pass
    def test(arg):
        pass
    """

# Generated at 2022-06-22 03:21:45.204549
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    """Unit test for method is_block_closer of class RoughParser

    Testing different continuation types.
    """
    class UnitTest(unittest.TestCase):
        def setUp(self):
            self.parser_cls = RoughParser
            self.x = "  def method(self):\n" \
                     "    if True:\n" \
                     "      return True\n"
            self.y = "  def method(self):\n" \
                     "    if True:\n" \
                     "      return True # " \
                     "comment\n"
            self.z = "  def method(self):\n" \
                     "    if True:\n" \
                     "      return True \\\n" \
                     "          or None\n"

# Generated at 2022-06-22 03:21:56.649124
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # Not sure why it is needed to use "text.Text" here, but it doesn't work
    # without it at least on IDLE.
    text = text_text.Text()
    text.insert("insert", "abc # comment\n  abc")
    hp = HyperParser(text, "insert")
    if hp.rawtext != "abc \n  abc":
        print("Error in HyperParser construction.")
    hp.set_index("3.0")
    if hp.rawtext != "abc \n  abc":
        print("Error in HyperParser setting index.")
    hp.set_index("2.0")
    if hp.rawtext != "abc # comment\n  abc":
        print("Error in HyperParser setting index.")
    hp.set_index("2.0")

# Generated at 2022-06-22 03:21:59.906184
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    preserves = " \t\n\r"
    t = StringTranslatePseudoMapping({ord(c): ord(c) for c in preserves},
                                     ord('x'))
    text = "a + b\tc\nd"
    translated = text.translate(t)
    assert translated == "x x x\tx\nx"



# Generated at 2022-06-22 03:22:08.946980
# Unit test for constructor of class HyperParser
def test_HyperParser():

    class TestText:
        def index(self, index):
            return index

        def get(self, from_index, to_index):
            return from_index + ":" + to_index


# Generated at 2022-06-22 03:22:14.498441
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    # Unit test for method __len__ of class StringTranslatePseudoMapping
    assert len(StringTranslatePseudoMapping(Dict(), 0)) == 0
    assert len(StringTranslatePseudoMapping({"k1": 1, "k2": 2}, 0)) == 2

