

# Generated at 2022-06-22 03:16:27.910122
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    assert RoughParser("x = 5").is_block_closer() == False
    assert RoughParser("x = 5\n").is_block_closer() == False
    assert RoughParser("return 5").is_block_closer() == True
    assert RoughParser("return").is_block_closer() == True
    assert RoughParser("if a:\n    pass\n").is_block_closer() == True
    assert RoughParser("if a:\n    pass").is_block_closer() == False
    assert RoughParser("if a:\n    pass\n    \n").is_block_closer() == True
    assert RoughParser("if a:\n    pass\n    x=3").is_block_closer() == False
    assert RoughParser("if a:\n    pass\n    x=3\n").is_block

# Generated at 2022-06-22 03:16:38.873283
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    assert HyperParser("", "1.0").is_in_code()
    assert HyperParser("(", "1.0").is_in_code()
    assert not HyperParser("'''", "2.0").is_in_code()
    assert not HyperParser("'''(", "3.1").is_in_code()
    assert not HyperParser("'''", "1.0").is_in_code()
    assert HyperParser("'''(", "1.0").is_in_code()
    assert HyperParser("'''(", "2.0").is_in_code()
    h = HyperParser("#     \n'''(", "1.5")
    h.set_index("2.0")
    assert not h.is_in_code()
    h.set_index("2.1")


# Generated at 2022-06-22 03:16:46.204736
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-22 03:16:58.566404
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    import rfc822
    def _test(code, text_bracketing):
        code = dedent(code)
        parser = RoughParser(code)
        brackets = parser.get_last_stmt_bracketing()
        text_bracketing = list(text_bracketing)
        assert brackets == tuple(rfc822.Message(text_bracketing))

        # Test that the bracketing is correct just by looking at
        # the bracket nesting.
        exp = []  # expected bracket nesting level
        for bracket in brackets:
            if bracket[1] == 'increase':
                exp.append(bracket[0])
            elif bracket[1] == 'decrease':
                assert bracket[0] == exp.pop()
            else:
                assert bracket[1] == exp[-1]

    yield

# Generated at 2022-06-22 03:17:02.747283
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Text(None)
    text.insert("insert", "if None")
    hp = HyperParser(text, text.index("insert"))
    assert hp.is_in_code()
    assert not hp.is_in_string()
    text.insert("insert", ":\n")
    hp = HyperParser(text, text.index("insert"))
    hp.set_index("insert")
    assert hp.is_in_code()
    assert not hp.is_in_string()



# Generated at 2022-06-22 03:17:13.228326
# Unit test for constructor of class RoughParser
def test_RoughParser():
    p = RoughParser('f(a, b, c, d)')
    assert p.continuation == C_NONE
    p = RoughParser('f(a,\n b, c, d)')
    assert p.continuation == C_BRACKET
    p = RoughParser('f(a, \\\n b, c, d)')
    assert p.continuation == C_BACKSLASH
    p = RoughParser('f("""\n b, c, d)')
    assert p.continuation == C_STRING_FIRST_LINE
    p = RoughParser('f("""\n b, c, d)', tabwidth=1, indentwidth=1)
    assert p.continuation == C_STRING_FIRST_LINE
    p = RoughParser('f("\n b, c, d)')

# Generated at 2022-06-22 03:17:23.637952
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    from pygments_helper import get_tokens


# Generated at 2022-06-22 03:17:35.696433
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():

    def t_base_indent(program, **kw):
        rp = RoughParser(program, **kw)
        rp.tokenize()
        return rp.get_base_indent_string()

    # Success
    assert t_base_indent("   abc") == '   '
    assert t_base_indent(" \t\tabc") == ' \t\t'
    assert t_base_indent(" \t\t\r\nabc") == ' \t\t'
    assert t_base_indent("""def foo():
    \"\"\"foo doc\"\"\"
    abc""") == '    '
    assert t_base_indent("""def foo():
    \"\"\"foo doc\"\"\"
    if a:
        abc""") == '        '

    # Error

# Generated at 2022-06-22 03:17:39.133312
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    for base_text, expected in [
        ('', ''),
        ('a', ''),
        ('\n', ''),
        (' \n', ' '),
        ('\t\n', '\t'),
        ('    \n', '    '),
        ('  # \n', '  # '),
    ]:
        assert RoughParser(base_text, indent_width=4, tabwidth=8).get_base_indent_string() == expected

# Generated at 2022-06-22 03:17:50.196389
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    """
    >>> test_string = '''foo(1, 2 + 3, { "xxx": 1, "test": 2 })'''
    >>> rp = RoughParser(test_string)
    >>> rp.get_last_stmt_bracketing()
    ((0, 0), (4, 1), (5, 0), (7, 1), (8, 0), (9, 1), (10, 0), (13, 1), (14, 0))

    >>> test_string = '''foo(1, 2 + 3, { "xxx": 1, "test": 2 })\\\nfoo()'''
    >>> rp = RoughParser(test_string)
    >>> rp.get_last_stmt_bracketing()
    ((15, 0), (19, 1), (20, 0))
    """
    pass

# Generated at 2022-06-22 03:19:35.291428
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    class TestCase:
        def __init__(self, input, expected):
            self.input = input
            self.expected = expected

# Generated at 2022-06-22 03:19:44.354084
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():  # @UnusedFunction
    """Test StringTranslatePseudoMapping constructor"""
    # Test the return value of get() in case of missing key.
    preserve_dict = {ord('a'): ord('c'), ord('b'): ord('d')}
    mapping = StringTranslatePseudoMapping(preserve_dict, default_value=123)

    assert mapping.get(ord('a')) == ord('c')
    assert mapping.get(ord('b')) == ord('d')
    assert mapping.get(ord('c')) == 123
    assert mapping.get(ord('d')) == 123

    # Test getitem() in case of missing key.
    assert mapping[ord('a')] == ord('c')
    assert mapping[ord('b')] == ord('d')

# Generated at 2022-06-22 03:19:48.098290
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=redefined-builtin
    import tokenize

    def check(s, indents):
        rp = RoughParser(s, "dummy", 0)
        assert rp.goodlines == indents


# Generated at 2022-06-22 03:19:55.804196
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def do_test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.is_in_code()
        print("test_HyperParser_is_in_code(%r, %r)\nexpected: %r\n  actual: %r" % (
            text, index, expected, actual))
        assert expected == actual

    def assert_error(text, index):
        print("test_HyperParser_is_in_code(%r, %r)\nexpected: error" % (text, index))
        try:
            hp = HyperParser(text, index)
        except (IndexError, ValueError):
            pass
        else:
            assert False, "expected error"

    do_test("", "1.0", True)
    do_test("a", "1.0", True)


# Generated at 2022-06-22 03:20:06.923218
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    if __name__ != "__main__":
        # This file is "hyperparser.py", so if it is being run as a
        # script then it is not being imported as a module, so do not
        # run these unit tests.  Instead, the unit tests are run by
        # the "unit_tests.py" script.
        return

    # These unit tests run only if this file is being run as a
    # script.  That should only happen when run by a human for
    # debugging.  In that case, it is a good idea to run the unit
    # tests with the "-v" flag to "test.py" to see exactly what is
    # being tested (and what is being skipped).  The "-v" flag
    # is also a good idea when using the "-t" flag to "test.py"
    # to find a particular

# Generated at 2022-06-22 03:20:18.095359
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    def assertClosed(source):
        # "def foo():" -> "def foo():\n", so that the parser
        # doesn't treat the end of the file as the end of the
        # definition
        source_ = source.rstrip() + "\n"
        rp = RoughParser(source_)
        assert rp.is_block_closer()

    assertClosed("""if 0:
    pass""")
    assertClosed("""while 0:
    pass""")
    assertClosed("""for a in (1, 2, 3):
    pass""")
    assertClosed("""try:
    pass""")
    assertClosed("""try:
    pass
except Exception:
    pass""")

# Generated at 2022-06-22 03:20:24.407371
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    def test(text, expected_pos):
        rough_parser = RoughParser(text)
        observed_pos = rough_parser.get_last_open_bracket_pos()
        assert observed_pos == expected_pos

    test('''#! /usr/bin/env python
# This is a comment
a = {
    'b' : "c",
    'd' : []
    }
''', 36)

    test('''#! /usr/bin/env python
# This is a comment
a = {'b' : "c",
    'd' : []
    }
''', 36)

    test('''#! /usr/bin/env python
# This is a comment
a = {'b' : "c",
    'd' : []}
''', 36)


# Generated at 2022-06-22 03:20:29.733252
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    ws = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in ws}
    default = ord('x')
    mapping = StringTranslatePseudoMapping(preserve_dict, default)
    assert len(mapping) == len(ws)



# Generated at 2022-06-22 03:20:37.321059
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-22 03:20:47.986417
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():

    from idlelib.pyshell import PyParse

    def do_test(std, exp):
        parser = RoughParser(4, 4)
        parser.set_str(std)
        parser.find_good_parse_start(_build_char_in_string_func())
        text = parser.str
        index = len(text.rstrip()) - 1
        hp = HyperParser(text, index)
        got = hp.get_expression()
        if got != exp:
            print("Test with:\n", std)
            print("Expected '%s' but got '%s'\n" % (exp, got))

    do_test("", "")
    do_test("a", "a")
    do_test("a b", "a")
    do_test("a (b)", "a")
    do_

# Generated at 2022-06-22 03:21:59.730146
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    # test with a simple string
    assert RoughParser("foo = (1, 2, 3,)").get_last_stmt_bracketing() == ((0, 0), (4, 1), (5, 2), (6, 1), (7, 0))

    # test with a simple string which is indented
    assert RoughParser("    foo = (1, 2, 3,)").get_last_stmt_bracketing() == ((4, 0), (8, 1), (9, 2), (10, 1), (11, 0))

    # test with a simple function
    assert RoughParser("def foo():\n    return (1, 2, 3,)").get_last_stmt_bracketing() == ((0, 0), (4, 0), (10, 1), (11, 2), (12, 1), (13, 0))

   

# Generated at 2022-06-22 03:22:08.946023
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    a = Tk()
    t = ScrolledText.ScrolledText(a)
    # Quote characters inside a string or a triple-quoted string
    t.insert("1.0", """\'\""\'\"'"\'\"""""")
    parser = HyperParser(t.text, "1.end")
    assert parser.is_in_string()
    parser.set_index("1.0")
    assert parser.is_in_string()
    parser.set_index("1.1")
    assert not parser.is_in_string()
    parser.set_index("1.3")
    assert parser.is_in_string()
    parser.set_index("1.4")
    assert parser.is_in_string()
    parser.set_index("1.5")
    assert parser.is_in_string

# Generated at 2022-06-22 03:22:20.803156
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-22 03:22:30.477029
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    def check(text, index, shouldbe):
        hp = HyperParser(Text(text), index)
        if hp.is_in_string() != shouldbe:
            print("%r\n%s is_in_string() should return %r, not %r" % (text, index, shouldbe, not shouldbe))

    check("xxx = \"''\"", "1.4", True)
    check("xxx = \"''\"", "1.5", False)
    check("xxx = \"''\"", "1.6", False)
    check("xxx = \"''\"", "1.7", False)
    check("xxx = \"''\"", "1.8", False)
    check("xxx = \"''\"", "1.9", True)
    check("xxx = \"''\"", "1.10", True)
    check

# Generated at 2022-06-22 03:22:41.588983
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    assert RoughParser("if 1:").get_continuation_type() == C_NONE
    assert RoughParser("if 1:\n  pass").get_continuation_type() == C_NONE
    assert RoughParser("if 1:\n  pass\n").get_continuation_type() == C_BRACKET
    assert RoughParser("if 1:\n  pass;").get_continuation_type() == C_BACKSLASH
    assert RoughParser("if 1:\n  pass; ").get_continuation_type() == C_BACKSLASH
    assert RoughParser("if 1:\n  pass; #").get_continuation_type() == C_BACKSLASH
    assert RoughParser("if 1:\n  pass; \\").get_continuation_type() == C_BACKSLASH

# Generated at 2022-06-22 03:22:52.276985
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    from logging import error

    def _test(s, expected):
        rp = RoughParser(s)
        status = rp.is_block_closer()
        if status != expected:
            error("Error in test: %s", s)
            error("Result was %s", status)
            error("Should have been %s", expected)
    #
    _test("", False)
    _test("a", False)
    _test("abc", False)
    _test("abc\ndef", False)
    _test("abc\ndef:", False)
    _test("abc\ndef[", False)
    _test("abc\ndef(", False)
    _test("abc\ndef'", False)
    _test("abc\ndef\"", False)

# Generated at 2022-06-22 03:23:04.937760
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def rp(*args):
        return RoughParser(*args).compute_bracket_indent()
    assert rp("", 0) == 0
    assert rp("if foo:", 4) == 4
    assert rp("if foo:", 4) == 4
    assert rp("  if foo:", 4) == 6
    assert rp("    if foo:", 4) == 8
    assert rp("  if foo:", 4) == 6
    assert rp("  \n  if foo:", 4) == 6
    assert rp("if foo: pass", 4) == 4
    assert rp("if foo:\n  pass", 4) == 4
    assert rp("if foo:\n  if bar:", 4) == 4
    assert rp("if foo:\n  if bar: pass", 4) == 4
   

# Generated at 2022-06-22 03:23:15.017020
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    """
    >>> p = RoughParser("if 1:\\n  if 1:\\n    1 + 1\\n")
    >>> p.get_continuation_type()
    1

    >>> p = RoughParser("1 + 1\\n")
    >>> p.get_continuation_type()
    0

    >>> p = RoughParser("1 + 1")
    >>> p.get_continuation_type()
    1

    >>> p = RoughParser("if 1:\\n  if 1:\\n    1 + 1")
    >>> p.get_continuation_type()
    2
    """

# Generated at 2022-06-22 03:23:21.385007
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    def check(code, firstlineno, indent):
        found = RoughParser(code, firstlineno).compute_backslash_indent()
        if found != indent:
            raise TestFailed(
                "compute_backslash_indent returned %s for\n%s" % (found, code)
            )

    check("a = \\\n", 1, 1)
    check("a = \\\n   ", 1, 4)
    check("a = \\", 1, 1)
    check("a =   \\", 1, 4)
    check("if 1: \\\n", 1, 4)
    check("if 1: \\\n   ", 1, 4)
    check("if 1: \\\n    a", 1, 4)
    check("if 1: \\", 1, 4)

# Generated at 2022-06-22 03:23:32.136175
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest
    from test.test_support import run_unittest

    class HyperParser_set_index(unittest.TestCase):

        def _test_set_index(self, s, expected):
            """Test whether HyperParser.set_index behaves correctly for the given string.

            The test cases below are defined using negative indices, but the
            HyperParser uses absolute indices, so we must convert the expected
            values.

            The following variables are defined inside the string s:
            - self.index
            - The index which is used to initialize the HyperParser object, i.e.
              HyperParser(s, self.index).
            - self.expected_indexbracket
            - The value which is expected to be returned in HyperParser.indexbracket
              after HyperParser.set_index(self.index) is invoked.
            """
