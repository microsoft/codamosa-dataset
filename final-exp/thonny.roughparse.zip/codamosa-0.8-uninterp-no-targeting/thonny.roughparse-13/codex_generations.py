

# Generated at 2022-06-22 03:16:47.199277
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest
    import unittest.mock

    class BaseTest(unittest.TestCase):
        "Base class for the tests"

        def test_inside_string(self):
            "test get_expression in a string"
            text = unittest.mock.Mock()
            text.indentwidth = 8
            text.tabwidth = 4
            text.index.return_value = "2.1"
            text.get.side_effect = lambda x, y: {"1.0": "foo(a, b, c+", "2.1": "d)"}[x]

            self.assertEqual(
                HyperParser(text, "2.1").get_expression(), ""
            )  # inside string
            self.assertEqual(text.get.call_count, 2)
            self

# Generated at 2022-06-22 03:16:58.596208
# Unit test for constructor of class StringTranslatePseudoMapping

# Generated at 2022-06-22 03:17:08.442436
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    """
    >>> s = '''\
    ... if True:
    ...   pass
    ...
    ... # comment
    ... '''
    >>> rp = RoughParser(s)
    >>> rp.get_num_lines_in_stmt()
    2

    >>> s = '''\
    ... if True:
    ...   pass
    ...   # comment
    ... '''
    >>> rp = RoughParser(s)
    >>> rp.get_num_lines_in_stmt()
    2

    >>> s = '''\
    ... if True:
    ...   pass  # comment
    ... '''
    >>> rp = RoughParser(s)
    >>> rp.get_num_lines_in_stmt()
    1
    """

# Generated at 2022-06-22 03:17:20.056626
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    # pylint: disable=redefined-outer-name, redefined-builtin
    # (for the sake of this test)

    # Test for bug #386961.  This code makes sure that when the
    # continuation line precedes the line with the closing
    # backslash, the extra line is not taken into account in
    # computing the indentation.

    from test.test_tokenize import generate_cases_for_unparsable_python_file

    RoughParser = RoughParser  # @ReservedAssignment
    data = ["a = {1: (2,", "        2)}\\", "  "]
    #                 ^---backslash preceding this line

    # data is a list of strings. We test each with three different
    # tabsizes, and with data[0] and the last two lines concatenated
    #

# Generated at 2022-06-22 03:17:23.548400
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    from IDLEX.idle_test.htest import run

    run(StringTranslatePseudoMapping.__dict__, '__iter__')

# Generated at 2022-06-22 03:17:27.982292
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser("abc")
    assert rp.get_line_offset() == 0
    rp.set_lo(100)
    assert rp.get_line_offset() == 100


# Generated at 2022-06-22 03:17:39.843723
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=redefined-builtin
    # pylint: disable=redefined-variable-type
    # pylint: disable=redefined-outer-name
    rp = RoughParser('')
    rp.set_str('')
    if rp.str != '':
        raise RuntimeError("rp.set_str('') failed")
    rp.set_str('    ')
    if rp.str != '    ':
        raise RuntimeError("rp.set_str('    ') failed")
    rp.set_str('\n')
    if rp.str != '\n':
        raise RuntimeError("rp.set_str('\n') failed")
    rp.set_str("\n\n")

# Generated at 2022-06-22 03:17:50.742595
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected_result):
        hp = HyperParser(text, index)
        result = hp.get_expression()
        assert result == expected_result, "Expected {!r} but got {!r}: text={!r}, index={!r}" "".format(
            expected_result, result, text, index
        )

    test(
        """x = a.b[c].d.e
        """,
        "1.6",
        "a.b[c].d",
    )

    test(
        """x = a .b[c]. d.e
        """,
        "1.8",
        "a .b[c]. d",
    )


# Generated at 2022-06-22 03:18:10.307410
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-22 03:18:22.409508
# Unit test for constructor of class HyperParser
def test_HyperParser():
    class Test:
        def __init__(self, text):
            self.indent_width = DEFAULT_INDENT_WIDTH
            self.tabwidth = DEFAULT_TAB_WIDTH
            self.text = text
            self.index = [None]

        def index(self, i):
            self.index[0] = i
            return i

        def get(self, s, e):
            return self.text[int(float(s)):int(float(e))]


# Generated at 2022-06-22 03:19:01.077480
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    import test.test_indentation
    indentation = test.test_indentation

# Generated at 2022-06-22 03:19:13.511842
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():

    def test(s, **kwargs):
        if "\n" not in s:
            s += "\n"
        rp = RoughParser(**kwargs)
        rp.set_str(s)
        return rp.get_line_numbers(), rp.get_continuation_type()

    assert test("") == ([0, 1], C_NONE)
    assert test("hello") == ([0, 1], C_NONE)
    assert test("hello\\") == ([0], C_NONE)
    assert test("hello\\\n") == ([0, 1], C_BACKSLASH)
    assert test("\\\n") == ([0], C_BACKSLASH)
    assert test("hello\\\nworld") == ([0, 1, 2], C_BACKSLASH)

# Generated at 2022-06-22 03:19:19.560293
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    assert RoughParser("").is_block_opener() == 0
    assert RoughParser("# Comment").is_block_opener() == 0
    assert RoughParser("if 1:").is_block_opener() == 1
    assert RoughParser("if 1: # Comment").is_block_opener() == 1
    # Backslash at end of line
    assert RoughParser("if 1: \\").is_block_opener() == 1
    assert RoughParser("if 1: # Comment\\").is_block_opener() == 1
    assert RoughParser("if 1:  # Comment\\").is_block_opener() == 1
    assert RoughParser("if 1: \\# Not a comment").is_block_opener() == 1
    assert RoughParser("if 1: # Comment\\\n").is_block_opener() == 0

# Generated at 2022-06-22 03:19:26.983625
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    from idlelib.parser_utils import StringTranslatePseudoMapping
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    expected = list(sorted(mapping))
    actual = mapping.__iter__()
    assert expected == actual


# Generated at 2022-06-22 03:19:35.728652
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    from box import Box as _Box  # @UnresolvedImport
    for arg in _Box(
        {'non_defaults': {'a': 'x', 'b': 'y'}, 'default_value': 'z'},
        {'non_defaults': {}, 'default_value': 'z'},
    ):
        obj = StringTranslatePseudoMapping(**arg)
        print(list(obj))
        print(list(obj))



# Generated at 2022-06-22 03:19:44.748592
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    import unittest

    class Test(unittest.TestCase):

        def test(self):
            a = RoughParser("123\\\n34")
            self.assertEqual(a.get_num_lines_in_stmt(), 2)
            self.assertRaises(
                AttributeError, getattr, a, "continuation",
            )

            a = RoughParser("123")
            self.assertEqual(a.get_num_lines_in_stmt(), 1)
            self.assertRaises(
                AttributeError, getattr, a, "continuation",
            )

            a = RoughParser("123\\")
            self.assertEqual(a.get_num_lines_in_stmt(), 1)
            self.assertEqual(a.continuation, C_BACKSLASH)

            a

# Generated at 2022-06-22 03:19:53.978821
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    import unittest

    class Test(unittest.TestCase):
        # pylint: disable=too-many-public-methods
        # pylint: disable=invalid-name

        def _do_test(self, expected, text):
            parser = RoughParser(text)
            # pylint: disable=protected-access
            got = parser._compute_backslash_indent()
            self.assertEqual(expected, got)

        def test_no_backslash(self):
            self._do_test(0, "foo")

        # As a special case, we consider a single line with an
        # embedded backslash to be an acceptable continuation line
        def test_one_line_with_backslash(self):
            self._do_test(0, "foo\\\n")

       

# Generated at 2022-06-22 03:20:05.762405
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rp = RoughParser("a = 1\n")
    assert rp.get_num_lines_in_stmt() == 1
    rp = RoughParser("a = 1\n\n")
    assert rp.get_num_lines_in_stmt() == 2
    rp = RoughParser("\n")
    assert rp.get_num_lines_in_stmt() == 1
    rp = RoughParser("a\n")
    assert rp.get_num_lines_in_stmt() == 1
    rp = RoughParser("a #\n")
    assert rp.get_num_lines_in_stmt() == 1
    rp = RoughParser("a\n")
    assert rp.get_num_lines_in_stmt() == 1

# Generated at 2022-06-22 03:20:16.562213
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import sys
    import unittest

    class TestCase(unittest.TestCase):
        # The following text gets inserted in the testing Text, at the end of it (after the "s")
        test_text = "\n\nA = 1\n\n\n"

        def setUp(self):
            self.text = Text()
            self.text.insert("end", "123456789\nabcdefghij\nABCDEFGHIJ\n")
            self.text.insert("end", self.test_text)

        def tearDown(self):
            self.text.delete("1.0", "end")

        def test_set_index(self):
            h = HyperParser(self.text, "1.1")
            # The current index is 1.1

# Generated at 2022-06-22 03:20:26.925953
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    # sequence = ' \t\n\r'
    # test = StringTranslatePseudoMapping(sequence)
    # assert_equal(list(test), sequence)
    import string

    from idlelib.pysyntax import _get_regular_expression_from_string_in_triple_quotes

    regexp = _get_regular_expression_from_string_in_triple_quotes(
        """
    [^[\](){}#'"\\]+
"""
    )
    all_chars = string.printable
    text = "".join(ch for ch in all_chars if not regexp.match(ch))
    print(text)



# Generated at 2022-06-22 03:21:45.293601
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest
    import unittest.mock
    from test.support import captured_stdout

    class StrMock:
        def index(self, s):
            return s[:-2]

    class TextMock:
        def __init__(self, str_mock, index, get_str):
            self.str_mock = str_mock
            self.index = index
            self.get = get_str

    class HyperParserMock:
        def __init__(self, text, index):
            self.text = text
            self.indexinrawtext = len(self.text.str_mock.rawtext)
            self.stopatindex = self.text.index(self.text.str_mock.stopatindex)
            self.bracketing = self.text.str_mock

# Generated at 2022-06-22 03:21:56.648167
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    rough_parser = RoughParser("", "", "")
    # make sure get_last_stmt_bracketing is doing its job
    str = "def foo(x): return x\n"
    rough_parser.str = str
    rough_parser.study_level = 1
    rough_parser.stmt_bracketing = [(0, 0), (11, 1), (16, 0)]
    assert rough_parser.get_last_stmt_bracketing() == rough_parser.stmt_bracketing
    assert (
        rough_parser.get_last_stmt_bracketing()
        == [(0, 0), (11, 1), (16, 0)]
    )



# Generated at 2022-06-22 03:22:02.992463
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    expected = "x x x\tx\nx"
    actual = text.translate(mapping)
    assert expected == actual




# Generated at 2022-06-22 03:22:04.580034
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-22 03:22:16.210578
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    import sys
    if sys.version_info[:2] >= (2, 7):
        # In Python 2.7 and newer, textwrap.dedent() dedents strings
        # according to the indentation of the first non-blank line,
        # instead of using the indentation of the first line.
        # The test strings assumed the former behavior.
        # For backward compatibility, we supply a custom class
        # which works like the old textwrap.dedent:
        class _Dedenter(textwrap.TextWrapper):
            def _dedent(self, text, *args, **kwds):
                return text
    else:
        _Dedenter = textwrap.Dedenter
    dedent = _Dedenter().dedent
    # The following examples, from PEP 8, illustrate the 3 possible cases:
    # 1) The colon

# Generated at 2022-06-22 03:22:25.123201
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-22 03:22:31.869320
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert not mapping, "mapping is not empty"
    assert set(mapping) == set(whitespace_chars), "mapping does not contain all expected characters"



# Generated at 2022-06-22 03:22:37.558655
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    p = RoughParser("min(a, b, c)\nx = foo(a,\n  bar=1)\n")
    assert not p.is_block_opener()
    assert p.is_block_opener()
    assert not p.is_block_opener()



# Generated at 2022-06-22 03:22:48.638365
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser(dedent("""
    int x;
    int y;
    int z;
    """))

    # Test standard case, where the paren_or_brace is a paren
    pob = (0, 'paren', '=')
    lo = rp.set_lo(pob)
    assert lo == 1

    # Test case where the paren_or_brace is a brace, and we want to
    # find the assignment op (here, "=")
    pob = (0, 'brace', '=')
    lo = rp.set_lo(pob)
    assert lo == 1

    # Test case where the paren_or_brace is a brace, and we want to
    # find the colon (here, ":")
    pob = (0, 'brace', ':')


# Generated at 2022-06-22 03:22:56.062234
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=redefined-outer-name
    lines = (
        "\\\n"
        "class spam:\n"
        "    a = 1\n"
        "    b = 2\n"
        "    c = 3\n"
        "        \n"
        "print\n"
        "        \n"
        "        \n"
        "        \n"
        "\n"
        "class _speech_manipulation:\n"
        "   def __init__(self):\n"
    )
    r = RoughParser(lines)
    assert r.get_continuation_type() == C_BACKSLASH
    assert r.compute_backslash_indent() == 8
    assert r.get_num_lines_in_stmt() == 2