

# Generated at 2022-06-22 03:16:09.674578
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    p = RoughParser('def x():\n'
                    '  if a:\n'
                    '    def y():\n'
                    '      if b:\n'
                    '        return 1\n')
    assert p.compute_bracket_indent() == 8


# Generated at 2022-06-22 03:16:22.091684
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    print("running test_RoughParser_compute_bracket_indent ...")

# Generated at 2022-06-22 03:16:23.110238
# Unit test for constructor of class HyperParser

# Generated at 2022-06-22 03:16:34.898724
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-22 03:16:37.271540
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({1: 2}, 3)
    assert mapping.get(1) == 2
    assert mapping.get(2) == 3



# Generated at 2022-06-22 03:16:45.149174
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    preserve_dict = {ord(c): ord(c) for c in ' abcdefghijklmnopqrstuvwxyz'}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert mapping[' '] == ord(' ')
    assert mapping['x'] == ord('x')
    assert mapping['z'] == ord('z')
    assert mapping[ord('y')] == ord('y')
    assert mapping.get(ord('x')) == ord('x')
    assert mapping.get(ord('y')) == ord('y')
    assert mapping.get(ord('z')) == ord('z')
    assert mapping.get('z') == ord('z')
    assert mapping.get(' ', '*') == ord(' ')

# Generated at 2022-06-22 03:16:57.392065
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=redefined-builtin
    def doit(s):
        r = RoughParser(s, 4)
        return r.get_num_lines_in_stmt(), r.compute_bracket_indent(), r.compute_backslash_indent(), r.get_base_indent_string(), r.is_block_opener()

    assert doit("") == (1, 0, 1, "", 0)
    assert doit("hi") == (1, 0, 1, "", 0)
    assert doit(" hi") == (1, 0, 1, " ", 0)
    assert doit(" \t\nhi") == (2, 0, 1, " \t", 0)

# Generated at 2022-06-22 03:17:08.409004
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    source = """
    def f(a, b):
        if a:
            return a + b # comment
        elif b:
            return a - b
        return a / b
    """
    parser = RoughParser(source)
    x = parser.get_last_stmt_bracketing()
    assert x == ((0, 0), (16, 1), (22, 2), (26, 3), (31, 2), (33, 1), (44, 0))

    x = parser.get_last_stmt_bracketing()
    assert x == ((0, 0), (16, 1), (22, 2), (26, 3), (31, 2), (33, 1), (44, 0))


# Generated at 2022-06-22 03:17:14.502271
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    "StringTranslatePseudoMapping.__getitem__(...) -- Unit test"
    mapping = StringTranslatePseudoMapping(
        {ord('a'): ord('b'), ord('c'): ord('d')}, ord('x'))
    assert mapping[ord('a')] == ord('b')
    assert mapping[ord('c')] == ord('d')
    assert mapping[ord('f')] == ord('x')



# Generated at 2022-06-22 03:17:26.770910
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    class MockText:
        def __init__(self, s):
            self.s = s
            self.index = str.index
            self.get = str.__getitem__

        def __getitem__(self, index):
            return self.s[index]

    def test(s, index, openers, mustclose, expected):
        parser = HyperParser(MockText(s), index)
        actual = parser.get_surrounding_brackets(openers, mustclose)
        assert actual == expected
        if actual is not None:
            for x in actual:
                assert x == int(x)

    # Test cases are of the form:
    # "string", index, openers, mustclose, expected

# Generated at 2022-06-22 03:18:12.307290
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # This testcase uses the following text:
    #
    # def foo():
    #     a, b, c == 3, 4, 5
    #     print(a, b, c)
    #     if a > 0:
    #         print("a > 0")
    #     else:
    #         print("a <= 0")
    #
    #         # comment
    #     # comment
    #
    text = Tkinter.Text()
    text.insert("1.0", dedent("""\
        def foo():
            a, b, c == 3, 4, 5
            print(a, b, c)
            if a > 0:
                print("a > 0")
            else:
                print("a <= 0")

                # comment
            # comment
        """))

# Generated at 2022-06-22 03:18:24.630152
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    p = RoughParser()

# Generated at 2022-06-22 03:18:37.388894
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():

    table = {ord('a'): u'\u0101', ord('b'): u'\u0103', ord('c'): u'\u0107',
             ord('d'): u'\u010d', ord('e'): u'\u0113'}
    default = u'\u0119'  # "e" with dot above
    mapping = StringTranslatePseudoMapping(table, default)

    sorted_keys = sorted(table.keys())

    # Ensure that __iter__() returns an iterator that yields the same keys
    # as iter(table)
    assert list(mapping) == sorted_keys

    # Use __iter__() to iterate the table, then check that keys and values
    # match the table's

# Generated at 2022-06-22 03:18:40.438370
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import TestCase

    text = TextIndent(width=4, tabwidth=4)

# Generated at 2022-06-22 03:18:49.687315
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-22 03:19:02.462239
# Unit test for constructor of class RoughParser
def test_RoughParser():
    r = RoughParser("""x = [1, 2,
3, 4,
5]""")
    assert str(r) == "RoughParser", repr(r)
    assert r.study_level == 0
    assert r.is_block_opener()
    assert not r.is_block_closer()
    assert r.get_continuation_type() == C_BRACKET
    assert r.get_last_stmt_bracketing() == (
        (0, 0),
        (1, 0),
        (2, 0),
        (3, 1),
        (4, 1),
        (5, 1),
        (6, 0),
        (7, 0),
    )
    assert r.get_last_open_bracket_pos() == 3
    assert r.get_num_lines

# Generated at 2022-06-22 03:19:14.770866
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    str = "else: a = b"
    parser = RoughParser(str)
    parser._study2()
    assert parser.is_block_closer() == True
    str = "else: # a"
    parser = RoughParser(str)
    parser._study2()
    assert parser.is_block_closer() == True
    str = "else:"
    parser = RoughParser(str)
    parser._study2()
    assert parser.is_block_closer() == True
    str = "if 5: "
    parser = RoughParser(str)
    parser._study2()
    assert parser.is_block_closer() == False
    str = "else:"
    parser = RoughParser(str)
    parser._study2()
    assert parser.is_block_closer() == True

# Generated at 2022-06-22 03:19:22.452352
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    non_defaults = {
        0x20: 0x20,  # space
        0x09: 0x09,  # tab
        0x0A: 0x0A,  # linefeed
        0x0D: 0x0D,  # carriage return
    }
    mapping = StringTranslatePseudoMapping(non_defaults, 0x22)  # double quote
    len_mapping = len(mapping)

    assert len_mapping == 4

# Generated at 2022-06-22 03:19:30.190446
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    """Unit test for method __getitem__ of class StringTranslatePseudoMapping"""
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"



# Generated at 2022-06-22 03:19:33.672147
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    default_value = ord('.')
    non_defaults = {ord('a'): ord('x')}
    mapping = StringTranslatePseudoMapping(non_defaults, default_value)
    assert len(mapping) == 1

