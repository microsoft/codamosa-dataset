

# Generated at 2022-06-22 03:16:00.932342
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    do_unit_test(HyperParser._tests, "HyperParser.is_in_code")



# Generated at 2022-06-22 03:16:10.738516
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    # Test if a string is replaced with a single character
    # >>> whitespace_chars = ' \t\n\r'
    # >>> preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    # >>> mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    # >>> text = "a + b\tc\nd"
    # >>> text.translate(mapping)
    # 'x x x\tx\nx'
    #
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))

# Generated at 2022-06-22 03:16:22.205588
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def test(s):
        global call
        call = 0
        def assert_equal(x, y):
            global call
            call += 1
            if x != y:
                raise ValueError(
                    "call #%d: expecting %r, got %r instead" % (call, x, y)
                )

        h = HyperParser(s, INSERT)
        assert_equal(h.get_surrounding_brackets(), None)
        h.set_index("1.0")
        assert_equal(h.get_surrounding_brackets(), None)
        h.set_index("1.0 lineend")
        assert_equal(h.get_surrounding_brackets(), ("1.0", "1.0 lineend"))
        h.set_index("1.0")

# Generated at 2022-06-22 03:16:33.903173
# Unit test for method set_str of class RoughParser

# Generated at 2022-06-22 03:16:42.640877
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rp = RoughParser("   [ 1,\n20,\n    300,\n     4000]")
    assert rp.get_continuation_type() == C_BRACKET
    assert rp.compute_bracket_indent() == 3
    # Test indentation when the bracket is not on the left margin
    rp = RoughParser("  foo = {1: 2,\n  'a': 'b'}")
    assert rp.get_continuation_type() == C_BRACKET
    assert rp.compute_bracket_indent() == 6
    # Test indentation when the bracket is inside a bracket
    rp = RoughParser("  (1,\n   ('a', 'b'))")
    assert rp.get_continuation_type() == C_BRACKET
    assert r

# Generated at 2022-06-22 03:16:48.983729
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase
    from unittest.mock import patch
    import tkinter

    class MockText:
        def __init__(self, index):
            self.index = index

        def get(self, index1, index2):
            return "est"

    class HyperParserTest(TestCase):
        def setUp(self):
            self.text = MockText("1.0")
            self.rawtext = "test"
            self.bracketing = [(0, 1), (1, 1), (2, 1), (3, 0)]
            self.isopener = [True, True, True, False]
            self.stopatindex = "1.0"
            #self.patcher = patch('HyperParser.set_str', autospec=True)
            #self.patcher.start()

# Generated at 2022-06-22 03:16:56.849631
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Tkinter.Text()
    text.insert("insert", "class Foo:\n")
    text.insert("insert", "    def bar(self, x):\n")

    h = HyperParser(text, "insert")

    h.set_index("2.0")
    assert h.get_surrounding_brackets() == "2.0", "insert + 1c"

    h.set_index("2.0 lineend")
    assert h.get_surrounding_brackets() == "2.0", "insert + 1c"



# Generated at 2022-06-22 03:17:03.362730
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    """Test the get() method of this class.

    The method get() is just a wrapper around the underlying dict's
    get() method. We want to be sure that the default value we set in
    the constructor is actually used, so we set the underlying dict to
    {}.
    """
    mapping_dict = {}
    default_value = 'x'

    mapping = StringTranslatePseudoMapping(mapping_dict, default_value)

    # Check that a nonexistent key returns the default value.
    nonexisting_key = 'nonexisting key'
    assert mapping.get(nonexisting_key) == default_value

    # Check that a valid key returns the associated value.
    existing_key = 'existing key'
    expected_value = 'expected value'
    mapping_dict[existing_key] = expected_value

# Generated at 2022-06-22 03:17:06.525519
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    from idlelib.idle_test.htest import run
    run(StringTranslatePseudoMapping, '__getitem__')


# Generated at 2022-06-22 03:17:10.112675
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    assert set(" \t\n\r") == set(mapping)

# Generated at 2022-06-22 03:18:10.442290
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    class MockText:
        def __init__(self, rawtext, index):
            self.rawtext = rawtext
            self.index = index

        def get(self, index1, index2):
            return self.rawtext[self.index(index1):self.index(index2)]

        def index(self, i):
            return int(i[:-2])

    def do_test(rawtext, index, exp):
        text = MockText(rawtext, index)
        hp = HyperParser(text, text.index(index + ".0"))
        ret = hp.get_expression()
        if ret != exp:
            raise RuntimeError("bad result: %r %r expected: %r" % (rawtext, index, exp))

    exp = do_test
    exp("a(b", "2.0", "")

# Generated at 2022-06-22 03:18:22.528378
# Unit test for method set_lo of class RoughParser

# Generated at 2022-06-22 03:18:34.633242
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    def t(s, answer):
        p = RoughParser(s, 0)
        assert p.is_block_opener() == answer

    # This is a bit fragile since it's dependent on the exact
    # regexp used in study2.
    t("if 1: pass", 1)
    t("if 1:", 1)
    t("if 1:\n    pass", 1)
    t("if 1:\n    \n    pass", 1)
    t("if (1:\n    pass)\n    pass", 0)  # closere
    t("if 1: <>\n    pass", 0)  # no colon before '<'
    t("if 1 +\n    2: pass", 1)  # continuation
    t("if 1 <>\n    2: pass", 0)  # no colon before '<'



# Generated at 2022-06-22 03:18:41.141795
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'



# Generated at 2022-06-22 03:18:47.419606
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    from lib2to3.pgen2.tokenize import generate_tokens, TokenError, untokenize
    from lib2to3.pgen2.tokenize import COMMENT, NAME, OP, NUMBER, STRING
    from lib2to3.pgen2.tokenize import generate_tokens, TokenError, untokenize
    from lib2to3.pgen2.tokenize import COMMENT, NAME, OP, NUMBER, STRING

# Generated at 2022-06-22 03:18:59.377814
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    """
    For testing the function RoughParser_get_last_open_bracket_pos().
    """
    # pylint: disable=redefined-outer-name,invalid-name

    def assert_get_last_open_bracket_pos(text, expected):  # @UnusedVariable
        rough_parser = RoughParser(text)
        general_args = {
            'indent_width': 4,
            'tabwidth': 8,
            'backslash_continues_stmt': False,
            'return_indent': 0,
            'is_comment_or_string': lambda s, i: False,
            'is_open_bracket': lambda ch: ch in "[{(",
            'is_close_bracket': lambda ch: ch in "]})",
        }

# Generated at 2022-06-22 03:19:12.076915
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # pylint: disable=invalid-name
    def get_indent(s):
        rp = RoughParser(s)
        return rp.get_lo()
    assert get_indent('(a, b)\n') == 1
    assert get_indent('(a,\n') == 1
    assert get_indent('(a, b\n') == 1
    assert get_indent('(\n') == 1
    assert get_indent('(\n') == 1
    assert get_indent('((a, b),\n') == 1
    assert get_indent('((a, b,\n') == 1
    assert get_indent('((a, b),\n') == 1
    assert get_indent('a((a, b)\n') == 1

# Generated at 2022-06-22 03:19:19.049484
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    # Replace all non-whitespace
    # (non-whitespace characters -> 'x', whitespace characters -> themselves)
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'

    # Replace all non-whitespace, except for '.'
    # (non-whitespace characters -> 'x', except for '.' -> itself
    #  whitespace characters -> themselves)
    whitespace_chars = ' \t\n\r'

# Generated at 2022-06-22 03:19:31.430137
# Unit test for constructor of class HyperParser
def test_HyperParser():
    class Dummy:
        pass

    text = Dummy()
    text.get = ""
    text.indent_width = text.tabwidth = 4
    text.index = lambda s: int(s.split('.')[0])

    text.get = lambda start, stop: " \n def f(a, b=3, c=[4])"
    hp = HyperParser(text, "9.0")
    if hp.rawtext != " \n def f(a, b=3, c=[4])":
        print("get_surrounding_brackets: 1")
        return
    if hp.stopatindex != "9.end":
        print("get_surrounding_brackets: 2")
        return
    bracketing = hp.bracketing

# Generated at 2022-06-22 03:19:42.845294
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    rp = RoughParser("abcd ef", 0, 8)
    assert(rp.get_last_open_bracket_pos() is None)
    rp = RoughParser("( abcd\nef", 0, 8)
    assert(rp.get_last_open_bracket_pos() == 0)
    rp = RoughParser("(\n\tabcd\nef", 0, 8)
    assert(rp.get_last_open_bracket_pos() == 0)
    rp = RoughParser("abcd\nef)", 0, 8)
    assert(rp.get_last_open_bracket_pos() is None)
    rp = RoughParser("abcd\n\nef)", 0, 8)
    assert(rp.get_last_open_bracket_pos() is None)

# Generated at 2022-06-22 03:23:56.607813
# Unit test for method is_block_opener of class RoughParser

# Generated at 2022-06-22 03:24:10.890026
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    from unittest import TestCase
    from idlelib.idle_test.mock_idle import Func
    from idlelib import output

    import idlelib
    idlelib.output = output

    # Test case for is_in_string method of class HyperParser
    class TestHyperParser(TestCase):
        class FakeText:
            def __init__(self, text):
                self.text = text

            def index(self, index):
                return index

            def get(self, start, stop):
                return self.text[start : stop]

        def test_is_in_string_0(self):
            text = self.FakeText('""')
            text.indent_width = 8
            text.tabwidth = 8
            index = "1.0"
            hp = HyperParser(text, index)
            self

# Generated at 2022-06-22 03:24:17.726366
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-22 03:24:29.784391
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-22 03:24:41.267970
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    def check(s, parse_start,
              continuation=C_NONE, lastch=None,
              lastopenbracketpos=None, stmt_bracketing=None):
        rp = RoughParser(s)
        if parse_start is not None:
            assert parse_start >= 0
            assert parse_start <= len(s)
        else:
            assert rp.find_good_parse_start() is None
            return
        start = rp.find_good_parse_start()
        assert start == parse_start
        if continuation is not None:
            assert rp.get_continuation_type() == continuation
            if continuation == C_BRACKET:
                assert rp.compute_bracket_indent() == 6
        if lastch is not None:
            assert rp.get_lastch()