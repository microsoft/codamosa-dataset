

# Generated at 2022-06-22 03:18:01.835202
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    """Test RoughParser method get_num_lines_in_stmt by running doctest"""
    import doctest
    doctest.testmod(RoughParser.get_num_lines_in_stmt, verbose=True)



# Generated at 2022-06-22 03:18:13.002462
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-22 03:18:17.737263
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    starter = 'BEGIN_CODE_SAMPLE\n'
    ender = '\nEND_CODE_SAMPLE\n'
    code_2_3 = starter + '1\n' + ender + 'a = "string with two lines"\n'
    code_4_5 = starter + '1\n2\n' + ender + 'a = "string with two lines"\n'
    code_6_7 = starter + '1\n2\n3\n' + ender + 'a = "string with two lines"\n'
    code_8_9 = starter + '1\n2\n3\n4\n' + ender + 'a = "string with two lines"\n'

# Generated at 2022-06-22 03:18:29.641635
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    import unittest
    import sys
    if sys.version_info >= (3, 0):
        from test.support import captured_stdout
    

    class Test_RoughParser_is_block_opener(unittest.TestCase):
        def test_is_block_opener_falsy_on_if(self):
            testcases = [
                'if True:\n    pass\n',
                'if self.test():\n    pass\n',
                'if not self.test:\n    pass\n',
                'if not self.test:\n    pass\n    pass\n',
                'if not self.test:\n    pass\n    pass\n    pass\n',
            ]

# Generated at 2022-06-22 03:18:38.695329
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    rp = RoughParser(
        'def f(a):\n'
        '    return a\n'
        '\n'
        'print(list(map(f, range(5))))\n',
        indent_width=4,
        tabwidth=8,
        line_offset=0,
    )
    bracketing = rp.get_last_stmt_bracketing()
    expected = ((75, 0), (76, 1), (77, 2), (78, 1), (79, 0))
    assert bracketing == expected, (bracketing, expected)


# Generated at 2022-06-22 03:18:48.450973
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():

    # Dummy text which will be used for testing
    text = "0123456789"

    # Helper function to give arguments for a HyperParser
    def get_parser_and_index(index_str):
        return HyperParser(text, index_str), text.index(index_str)

    def assert_get_surrounding_brackets(index, expected_result):
        parser, index = get_parser_and_index(index)
        assert parser.get_surrounding_brackets() == expected_result

    def assert_get_surrounding_brackets_mustclose(index, expected_result):
        parser, index = get_parser_and_index(index)
        assert parser.get_surrounding_brackets(mustclose=True) == expected_result


# Generated at 2022-06-22 03:18:53.756558
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'




# Generated at 2022-06-22 03:19:07.113211
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import TestCase
    from test.test_support import run_unittest

    class _Test(TestCase):
        def _test_HyperParser_is_in_code(self, text, expected, index=None):
            if index is None:
                index = "%d.end" % (text.count("\n") + 1)
            hp = HyperParser(text, index)
            result = hp.is_in_code()
            self.failUnlessEqual(
                result,
                expected,
                "is_in_code returned %s, expected %s - for text '%s', index %s"
                % (result, expected, text, index),
            )

        def test_simple(self):
            text = "# comment\n# another comment\n3"
            self._test_HyperParser_is

# Generated at 2022-06-22 03:19:13.098674
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    preserve_dict = {ord(c): ord(c) for c in " \t\n\r"}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'



# Generated at 2022-06-22 03:19:16.589096
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    a = RoughParser()
    a.set_lo('a=1')
    assert a.str == 'a=1'  # @ReservedAssignment
    assert a.strstart == 0
    assert a.study_level == 0



# Generated at 2022-06-22 03:19:53.299424
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    tk = tkinter.Tk()
    text = tkinter.Text()
    text.pack()
    text.insert("1.0", "def foo():\n  bar()")
    hp = HyperParser(text, "1.0")
    hp.set_index("1.0")
    hp.set_index("1.1")
    hp.set_index("2.0")
    hp.set_index("2.1")
    hp.set_index("2.2")
    hp.set_index("2.3")
    hp.set_index("2.4")
    assert hp.stopatindex == "2.end"
    assert hp.rawtext == "def foo():\n  bar()"

# Generated at 2022-06-22 03:20:04.819133
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    import unittest

    class TestRoughParser(unittest.TestCase):
        def test_get_last_stmt_bracketing(self):
            p = RoughParser()

            p.set_str("if 1:")
            self.assertEqual(p.get_last_stmt_bracketing(), ((0, 0), (4, 1), (5, 0)))

            p.set_str("""
if 1:
    if 2:
        print()
""")
            self.assertEqual(p.get_last_stmt_bracketing(), ((8, 2), (12, 1), (13, 0)))

            p.set_str("""
if 1:
    if 2:
        print()

""")

# Generated at 2022-06-22 03:20:15.700925
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    teststr = 'print("a")\n#test\nprint("b")\n'
    # the above string will be parsed successully (by the parser)
    # when the parse start position is 0 or 2 (index of '\n' after
    # 'print("a")'), but will fail to parse otherwise
    test_parser = RoughParser(teststr)
    parse_start_pos = 0
    assert test_parser.find_good_parse_start(parse_start_pos) == parse_start_pos
    
    parse_start_pos = 1
    assert test_parser.find_good_parse_start(parse_start_pos) == parse_start_pos + 1
    
    parse_start_pos = 2
    assert test_parser.find_good_parse_start(parse_start_pos) == parse_start_pos

# Generated at 2022-06-22 03:20:21.593234
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    text.translate(mapping)
    answer = "x x x\tx\nx"
    assert text == answer, "test_StringTranslatePseudoMapping___getitem__"
test_StringTranslatePseudoMapping___getitem__()



# Generated at 2022-06-22 03:20:26.654840
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    parser = RoughParser()
    # check if str is initialized
    assert parser.str == ''
    parser.set_lo('this is a test')
    assert parser.str == 'this is a test'


# Generated at 2022-06-22 03:20:35.609855
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()
    rp.set_str("""\
            def foo(x, y):
                x = x + 1
                y = y + 1
                return x + y
            """)
    rp.set_lo(0)
    rp.set_hi(27)
    assert rp.get_continuation_type() == rp.C_NONE
    assert rp.get_base_indent_string() == ""
    assert not rp.is_block_opener()
    assert rp.get_last_open_bracket_pos() is None
    assert not rp.is_block_closer()

# Generated at 2022-06-22 03:20:36.796808
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    r = StringTranslatePseudoMapping({0: 0}, 0)
    assert next(iter(r)) == 0

# Generated at 2022-06-22 03:20:44.412398
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo(0)
    rp.set_lo('15')
    # rp.set_lo('aaaaa')
    # rp.set_lo('')
    rp.set_lo(None)
    # rp.set_lo(1.2)
    # rp.set_lo(0.0)
    # rp.set_lo(-15)

# Generated at 2022-06-22 03:20:47.545193
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    args = [{0: 1, 2: 3}, 4]
    test = StringTranslatePseudoMapping(*args)
    assert isinstance(test, Mapping)
    assert test.__iter__() == args[0].__iter__()


# Generated at 2022-06-22 03:20:59.102351
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-22 03:22:52.276446
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    assert list(StringTranslatePseudoMapping({}, 0)) == list(StringTranslatePseudoMapping({}, 0))



# Generated at 2022-06-22 03:23:04.932400
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    "Unit test for HyperParser.get_surrounding_brackets"
    hp = HyperParser("", "1.0")

    def get_test_case(text, index, expected):
        hp.text = text
        hp.set_index(index)
        return (
            text.get("1.0", "end"),
            hp.get_surrounding_brackets(),
            expected,
        )

    cases = []

    # We are at the beginning of a file.
    cases.append(get_test_case("", "1.0", None))
    # We are not at a bracket.
    cases.append(get_test_case("abc", "1.0", None))
    # We are in a comment
    cases.append(get_test_case("abc #", "1.end", None))
   

# Generated at 2022-06-22 03:23:17.044020
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    def check(input, output):
        """Helper function to call RoughParser.get_last_stmt_bracketing"""
        parser = tokenize.RoughParser(input)
        parser.set_str(input)
        parser._study2()
        if output is None:
            assert parser.get_last_stmt_bracketing() is None
        else:
            assert parser.get_last_stmt_bracketing() == output

    # Empty string
    check("", None)
    # One line
    check("aaa", ((0, 0), (3, 0)))
    # Two lines
    check("aaa\n", ((0, 0), (3, 0)))
    check("aaa\n  ", ((0, 0), (3, 0)))

# Generated at 2022-06-22 03:23:30.364702
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rp = RoughParser("")
    assert rp.get_num_lines_in_stmt() == 0
    rp = RoughParser("\n")
    assert rp.get_num_lines_in_stmt() == 1
    rp = RoughParser("\n\n")
    assert rp.get_num_lines_in_stmt() == 2
    rp = RoughParser("\n\n\n")
    assert rp.get_num_lines_in_stmt() == 3
    rp = RoughParser("foo\n\n")
    assert rp.get_num_lines_in_stmt() == 2
    rp = RoughParser("foo\n\n")
    assert rp.get_num_lines_in_stmt() == 2

# Generated at 2022-06-22 03:23:31.564450
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    r = RoughParser()
    r.set_lo(3)
    assert r.tabwidth == 8 and r.indentwidth == 4



# Generated at 2022-06-22 03:23:42.101023
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from test.support import requires

    requires("gui")
    from unittest import TestCase
    import idlelib.idle_test
    from idlelib.EditorWindow import EditorWindow

    class Test(TestCase):
        @classmethod
        def setUpClass(cls):
            cls.root = idlelib.idle_test.root
            cls.text = idlelib.idle_test.text

        def tearDown(self):
            self.text.delete(1.0, "end")

        def test_set_index_1(self):
            self.text.insert("end", "a + b\n")
            hp = HyperParser(self.text, "1.4")
            hp.set_index("1.5")
            self.assertEqual(hp.indexinrawtext, 7)
            self

# Generated at 2022-06-22 03:23:50.151385
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-22 03:24:01.015356
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-22 03:24:03.787849
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    rp = RoughParser('''\
{
}
''', indent_width=2, tabwidth=2)
    rp._study2()
    rp.get_last_open_bracket_pos()
    rp.get_last_open_bracket_pos()
    return wasSuccessful()


# Generated at 2022-06-22 03:24:13.848242
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    # example 1
    rp = RoughParser('''
    # comment
    # comment
    ''')
    assert rp.get_base_indent_string() == ''
    # example 2
    rp = RoughParser('''
    # comment
    # comment
    def a():
''')
    assert rp.get_base_indent_string() == '    '
    # example 3
    rp = RoughParser('''
    # comment
    # comment
    class A(object):
''')
    assert rp.get_base_indent_string() == '    '
    # example 4
    rp = RoughParser('''
    # comment
    # comment
    def a():
        pass
''')
    assert rp.get_base_indent_string() == '    '