

# Generated at 2022-06-12 12:58:24.611836
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    source = """line 1; line 2
    line 3; line 4
line 5
def
    line 6; line 7
    line 8; line 9
    """
    parser = RoughParser(source)
    expect = """line 1; line 2
    line 3; line 4
line 5
def
    line 6; line 7
    line 8; line 9
    """
    pos = parser.find_good_parse_start(4, 20)
    assert source[pos:] == expect

# Generated at 2022-06-12 12:58:33.479094
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    parser = RoughParser()

    def test(s, indent):
        parser.set_str(s)
        parser.study_continuation()
        assert parser.compute_backslash_indent() == indent

    # Test:
    # 1. Continuation with backslash.
    # 2. Not at the beginning of the line.
    # 3. No interesting continuation in the string.
    # 4. No continuation in the string.
    # 5. Empty string.

    test("""\
for i in x:
    if i == 3:
        print('\\
        foo')
    else:
        print('\\
            foo')
""", 15)

    test("if 1: print(\\", 4)

    test(
        """if 1: print('foo\\
            bar')""", 16,
    )

    test

# Generated at 2022-06-12 12:58:38.617150
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def build_test(text, index, expected, mustclose=False):
        def test():
            nonlocal text, index
            text = Text(text)
            hp = HyperParser(text, index)
            result = hp.get_surrounding_brackets(mustclose=mustclose)
            assert result is expected, "get_surrounding_brackets(%r, %r) -> %r, expected %r" % (
                text.string,
                index,
                result,
                expected,
            )

        return test

    build_test(
        "ab [cd] ef", "3.0", None
    )()
    build_test(
        "ab [cd] ef", "5.0", ("2.0", "8.0")
    )()

# Generated at 2022-06-12 12:58:49.390543
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    class Mock_text(object):
        def __init__(self, string):
            self._string = string

        def index(self, index):
            return str(int(float(index)))

        def get(self, startatindex, stopatindex):
            return self._string[int(float(startatindex)): int(float(stopatindex))]

        def __repr__(self):
            return repr(self._string)

    class Mock_HyperParser(HyperParser):
        def __init__(self, text, index):
            self.text = text
            self.index = index
            self.bracketing = [(0, 0), (2, 2), (3, 3), (9, 9), (10, 10), (11, 11), (13, 13), (15, 15)]

# Generated at 2022-06-12 12:59:00.034116
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser("a\nb")
    rp.set_lo(1)
    assert rp.lo == 1
    assert rp.stmt_start == 1
    assert rp.stmt_end == 1
    rp.set_lo(2)
    assert rp.lo == 2
    assert rp.stmt_start == 0
    assert rp.stmt_end == 1
    rp.set_lo(1)
    assert rp.lo == 1
    assert rp.stmt_start == 1
    assert rp.stmt_end == 1
    rp.set_lo(-1)
    assert rp.str == "a\nb"
    assert rp.lo == 2
    assert rp.stmt_start == 0

# Generated at 2022-06-12 12:59:07.271244
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():

    # When no brackets are present, None is returned.
    test_cases = [[("", "|"), None], [("|", ""), None]]

    # ('[XX]', '|')
    for bracket in "([{":
        test_cases.append([("[XX]", "|"), (1, "3")])

    # ('XX(|)XX', '|')

# Generated at 2022-06-12 12:59:13.347388
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    """Return test suite for HyperParser.get_expression.

    This is done in a function so that the exceptions raised are
    defined in the function's local scope.
    """

    import unittest

    class Test_HyperParser_get_expression(unittest.TestCase):
        def test1(self):
            s = 'abc("abc")'
            text = Text(s)
            h = HyperParser(text, "1.5")
            self.assertEqual(h.get_expression(), "abc")
            h = HyperParser(text, "1.10")
            self.assertEqual(h.get_expression(), "abc(")
            h = HyperParser(text, "1.11")
            self.assertEqual(h.get_expression(), "abc(")

# Generated at 2022-06-12 12:59:19.887302
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_ = """if 1:
        if 1:
            if 1:
                """
    rough_parser = RoughParser(str_, 0)
    import pytest
    assert rough_parser.find_good_parse_start() == 0
    str_ = """print 1
        # comment
        print 1
        """
    rough_parser = RoughParser(str_, 0)
    assert rough_parser.find_good_parse_start() == 0
    # test case where there is a junk line on the border of the parse
    # start
    str_ = """# comment1
# comment2
print 1
"""
    rough_parser = RoughParser(str_, 0)
    assert rough_parser.find_good_parse_start() == 0
    # test case where the line before the parse start has a comment
    # that is not the

# Generated at 2022-06-12 12:59:26.400704
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    import unittest
    class TestMethods(unittest.TestCase):
        def test_get_num_lines_in_stmt(self):
            for str in ["", "\n", "a = 3\n"]:
                rp = RoughParser(str, "")
                self.assertEqual(rp.get_num_lines_in_stmt(), 0)

    unittest.main(argv=[""], exit=False, verbosity=2)


# Generated at 2022-06-12 12:59:33.197415
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    def test(text, expected):
        eq = expected == HyperParser(text, "1.0").is_in_string()
        if not eq:
            print("Expected", text, "to give is_in_string =", expected)
            raise AssertionError

    test('"a"', 1)
    test("'a'", 1)
    test("'''a'''", 1)
    test("'''''", 1)
    test("'''a'''b'''", 0)
    test("'''a'''1", 0)
    test("1", 0)
    test("0x1", 0)
    test("a", 0)
    test("'a", 0)
    test('"a', 0)
    test("x''", 0)
    test("x'''", 0)
    test

# Generated at 2022-06-12 13:02:01.134631
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser('print "Foo"', 0)
    assert rp.get_base_indent_string() == ''
    rp = RoughParser('    print "Foo"', 0)
    assert rp.get_base_indent_string() == '    '
    rp = RoughParser('    print "Foo"', 8)
    assert rp.get_base_indent_string() == '        '
    rp = RoughParser('print "Foo"\nprint "bar"', 0)
    assert rp.get_base_indent_string() == '    '
    rp = RoughParser('print "Foo"\n    print "bar"', 0)
    assert rp.get_base_indent_string() == ''

# Generated at 2022-06-12 13:02:07.635880
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    #
    # Test method is_in_code of class HyperParser.
    #
    # It's a bit delicate to test this function
    # properly, because it uses a RoughParser,
    # which may change its code.
    #
    # So, we just test what we know about it:
    #
    # - it returns True in normal code
    # - it returns False in strings
    # - it returns False in comments
    # - it returns False after line continuations
    #
    # We assume that the RoughParser used by
    # HyperParser is good enough to detect
    # multiline strings and comments, so
    # that these tests cover all cases.
    text = "one\ntwo"
    h = HyperParser(text, "1.0")
    assert h.is_in_code()
    h.set_index

# Generated at 2022-06-12 13:02:15.678934
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    def _index(row, column):
        return "%d.%d" % (row, column)

    class Test(unittest.TestCase):
        index = None
        hp = None
        rawtext = None

        def setUp(self):
            self.hp = HyperParser(self.text, self.index)
            self.rawtext = self.hp.rawtext

        def test_is_in_string(self):
            self.assertTrue(self.hp.is_in_string())

        def test_is_in_code(self):
            self.assertFalse(self.hp.is_in_code())

        def test_get_surrounding_brackets(self):
            before, after = self.hp.get_surrounding_brackets()

# Generated at 2022-06-12 13:02:24.170514
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-12 13:02:31.637631
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-12 13:02:37.919557
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():

    from idlelib.idle_test.mock_idle import Func
    import unittest


    class HyperParserGetExpressionTest(unittest.TestCase):

        def test_get_expression(self):
            text = Text(None, " \t  \t  \n  \n  ")
            text.set("a.b.c()")
            index = text.index("1.1")
            hp = HyperParser(text, index)
            self.assertEqual(hp.get_expression(), "")
            index = text.index("1.3")
            hp.set_index(index)
            self.assertEqual(hp.get_expression(), "a")
            index = text.index("1.6")
            hp.set_index(index)

# Generated at 2022-06-12 13:02:39.778406
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """Check that set_index can be called and that the results are correct"""
    # The following is a piece of Python code with 8 lines

# Generated at 2022-06-12 13:02:45.415275
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-12 13:02:52.154007
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    testcases = [
        ("1+1\n", 3, True),
        ('"""\n"""\n', 4, True),
        ('"""\n\n"""\n', 5, True),
        ('"""\n\n', 4, True),
        ('1+1 # This is a comment\n', 3, True),
        ('"""123\n', 4, False),
        ("'1+1\n", 3, False),
        ('""", \n', 5, False),
        ("'123\n", 4, True),
    ]
    for case, index, expected in testcases:
        Tk = NewTk()
        text = Tk.Text()
        text.insert(END, case)
        hp = HyperParser(text, index)
        found = hp.is_in_code()

# Generated at 2022-06-12 13:02:59.015919
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-12 13:06:10.140347
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    h = HyperParser
    b = "{"
    assert h(b, "1.0").get_surrounding_brackets() == ("1.0", "2.0")
    assert h(b, "2.0").get_surrounding_brackets() == ("1.0", "2.0")
    assert h(b, "3.0").get_surrounding_brackets() == ("1.0", "2.0")

    b = "{)\n"
    assert h(b, "1.0").get_surrounding_brackets(mustclose=True) is None
    assert h(b, "2.0").get_surrounding_brackets(mustclose=True) is None

# Generated at 2022-06-12 13:06:19.482380
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    from libcst.testing.utils import UnitTest

    class TestRoughParser(UnitTest):
        def assert_continuation_type(
            self,
            continuation_type,
            string,
            tabwidth=8,
            indent_width=4,
        ):
            pr = RoughParser(string, tabwidth, indent_width)
            self.assertEqual(pr.get_continuation_type(), continuation_type)

        def assert_bracket_indent(
            self,
            expected,
            string,
            tabwidth=8,
            indent_width=4,
        ):
            pr = RoughParser(string, tabwidth, indent_width)

# Generated at 2022-06-12 13:06:28.404898
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    try:
        from Tkinter import Text
    except ImportError:
        from tkinter import Text

    def hpy(text, index, openers, mustclose):
        hp = HyperParser(text, index)
        return hp.get_surrounding_brackets(openers, mustclose)

    # Test - use a Text widget to provide functions text.index,
    # text.get, text.indentwidth, and text.tabwidth
    text = Text()

    # index() and get() must be defined on strings
    text.index = lambda index: index
    text.get = lambda startat, endat: endat

    # indentwidth and tabwidth are numbers
    text.indentwidth = 8
    text.tabwidth = 8


# Generated at 2022-06-12 13:06:35.803285
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    h = HyperParser("", "1.0")
    # First tests from the start of the string
    h.text = '"""string"""i'
    h.set_index("1.0")
    assert not h.is_in_string()
    h.set_index("1.4")
    assert h.is_in_string()
    h.set_index("1.7")
    assert h.is_in_string()
    h.set_index("1.8")
    assert h.is_in_string()
    h.set_index("1.9")
    assert not h.is_in_string()
    h.text = "'''string'''i"
    h.set_index("1.0")
    assert not h.is_in_string()

# Generated at 2022-06-12 13:06:41.779391
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # This tests the private method _is_identifier

    def index2line(index):
        return int(float(index))

    class MockText(object):

        def __init__(self, text, tabwidth):
            self.text = text
            self.tabwidth = tabwidth

        def index(self, index):
            return index

        def get(self, startatindex, stopatindex):
            # startatindex is a string of the form <lineno>.<colno>,
            # with lineno and colno being numbers. We assume that
            # just one line is given (i.e. no \n in the string).
            lineno, colno = startatindex.split(".")
            # colno is a string of the form \d+[c]?, where [c] is
            # optional.

# Generated at 2022-06-12 13:06:50.759484
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest
    from test.support import cpython_only

    class HyperParserTest(unittest.TestCase):
        def create_parser(self, text):
            return HyperParser(text, "1.0")

        @cpython_only
        def test_get_surrounding_brackets(self):
            #                 01234567890123456789012345678901
            text = " -[ }])"
            parser = self.create_parser(text)
            #                 01234567890123456789012345678901
            text = "foo([x.bar(a,b).goo()])"
            parser.set_index("1.8")
            self.assertEqual(parser.get_surrounding_brackets(), ("1.3", "1.20"))

# Generated at 2022-06-12 13:06:59.700319
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from idlelib.idle_test.mock_idle import Func

    class DummyEditwin:
        def __init__(self, text):
            self.text = text

        def get_selection_indices(self):
            return 0, "end"


# Generated at 2022-06-12 13:07:06.920463
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=too-many-locals
    # pylint: disable=redefined-builtin
    rp = RoughParser()
    # unit tests derived from the examples in PEP 8

# Generated at 2022-06-12 13:07:15.067457
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-12 13:07:22.429929
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase


    class FakeText:
        def __init__(self, content):
            self.content = content
            self.indent_width = 4
            self.tabwidth = 8

        def index(self, index):
            return index

        def get(self, startatindex, stopatindex):
            return self.content[self._index(startatindex) : self._index(stopatindex)]

        def _index(self, index):
            return int(float(index))

    class TestHyperParser(TestCase):
        def test_is_in_string(self):
            t1 = FakeText("py'\n")
            p = HyperParser(t1, "1.0")
            self.assertEqual(p.is_in_string(), True)
