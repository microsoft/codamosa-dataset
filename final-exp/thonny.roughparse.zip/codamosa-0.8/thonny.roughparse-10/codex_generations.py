

# Generated at 2022-06-12 13:02:05.450515
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    t = Tk()
    t.withdraw()
    t.clipboard_clear()

    h = HyperParser
    e = h(t, "1.0")
    try:
        e.get_surrounding_brackets(openers="([{", mustclose=True)
    except ValueError:
        pass
    else:
        assert 0, "Should have raised ValueError."
    t.clipboard_append(", ]")
    e.set_index("1.0")
    r = e.get_surrounding_brackets(openers="([{", mustclose=True)
    assert r is None, "Should have returned None."
    t.clipboard_append(", '", tkinter.END)
    e.set_index("2.1")
    assert e.get_surrounding_br

# Generated at 2022-06-12 13:02:12.637433
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # Note: unit tests for get_expression are in test_parenmatch.py

    from idlelib.idle_test.mock_idle import Func
    from idlelib.pyshell import PyShell
    from textwrap import dedent

    root = Tk()
    root.withdraw()
    text = Text(root)
    text.pack()

    def test(sample, index, string, opos, bracketing):
        text.delete("1.0", "end")
        text.insert("end", dedent(sample))
        hp = HyperParser(text, index)
        # indexbracket and indexinrawtext are tested by get_expression
        actual = hp.get_surrounding_brackets(mustclose=False)
        expected = string
        if expected is None:
            if actual is not None:
                print

# Generated at 2022-06-12 13:02:19.540066
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    im = "in middle"
    t = "before a triple quote"
    s = "before a single quote"
    n = "nowhere"
    cases = (
        ("'''%s'''", t),
        ("'''%s'", n),
        ("'''%s''", n),
        ('"""%s"""', t),
        ('"""%s"', n),
        ('"""%s""', n),
        ('"""%s', n),
        ("'%s'", s),
        ('"%s"', s),
        ("'''%s", n),
        ('"""%s', n),
        ("'%s'''", n),
        ('"%s"""', n),
    )

    class Text:
        def __init__(self, text, index):
            self.text

# Generated at 2022-06-12 13:02:27.783934
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    """Check method get_surrounding_brackets of class HyperParser"""
    import unittest
    import tkinter
    import idlelib.HyperParser

    class TestHyperParser(unittest.TestCase):
        def setUp(self):
            self.root = tkinter.Tk()
            self.text = tkinter.Text(self.root)
            self.h = idlelib.HyperParser.HyperParser(self.text, '1.0')

        def tearDown(self):
            self.root.destroy()

        def test_simple(self):
            self.text.insert('1.0', "abcd(efgh)")
            # Most simple case: a surrounded by b
            self.h.set_index("1.6")

# Generated at 2022-06-12 13:02:34.716461
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    from test_support import run_unittest

    class TestCase(unittest.TestCase):
        """Test the function is_in_string for correctness."""

        def test_is_in_string(self):
            t = "t.get('1.0', 'end')"
            cases = (
                (t, "1.2", False),
                (t, "1.3", True),
                (t, "1.6", False),
                (t, "1.7", True),
            )
            for text, index, expected in cases:
                hp = HyperParser(text, index)
                self.assertEqual(hp.is_in_string(), expected)

    run_unittest(TestCase)


if __name__ == "__main__":
    test_HyperParser_is_in_

# Generated at 2022-06-12 13:02:40.644037
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    import sys
    import unittest
    from test.test_support import unlink

    class TestUnittest(unittest.TestCase):
        def setUp(self):
            self.addCleanup(unlink, TESTFN)

        def test_compute_bracket_indent(self):
            with open(TESTFN, "w") as f:
                f.write(
                    """\
a = [
    "abcd", "efgh", "ijkl", "mnop",
]
"""
                )
            with open(TESTFN, "rU") as f:
                p = RoughParser(f)
                p.setup()

# Generated at 2022-06-12 13:02:47.137073
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    parser = RoughParser('    a = \\', indent_width=4, tabwidth=8)
    assert parser.compute_backslash_indent() == 5
    parser = RoughParser('    a = \\', indent_width=4, tabwidth=8)
    assert parser.compute_backslash_indent() == 5
    parser = RoughParser('    a += \\', indent_width=4, tabwidth=8)
    assert parser.compute_backslash_indent() == 5
    parser = RoughParser('    a -= \\', indent_width=4, tabwidth=8)
    assert parser.compute_backslash_indent() == 5
    parser = RoughParser('    a *= \\', indent_width=4, tabwidth=8)

# Generated at 2022-06-12 13:02:53.353514
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-12 13:03:00.336235
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    "Unit test for method is_in_string of class HyperParser"
    text = Tkinter.Text()
    text.insert("insert", "blah blah\n" "'alpha'\n" 'beta"\n')
    text.insert("3.0", "\nham\n")
    text.insert("3.0", '"42"')
    text.insert("3.0", "test")
    text.insert("3.0", "#")

    for index in ("2.2", "2.7", "2.11", "2.end -1c", "1.end", "5.5", "5.10", "5.17", "5.end"):
        assert HyperParser(text, index).is_in_string()

# Generated at 2022-06-12 13:03:09.337835
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    def check(text, expected):
        actual = RoughParser(text, 0).compute_backslash_indent()
        assert actual == expected, (actual, expected)

    check("a = \\", 1)
    check("a = a + \\", 5)
    check("(a, \\", 3)
    check("def f(\\", 5)
    check("a = a + \\", 5)
    check("a = x + \\\n\t1", 7)
    check("a = x + \\\r\n\t1", 7)
    check("a = x + \\\r1", 5)
    check("a = (\\\n\t1,\n\t2)", 1)
    test.support.requires("unicode_literals")

# Generated at 2022-06-12 13:04:23.580543
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    parser = RoughParser("\tfoo=1\n\tbar=2\n\t\tbaz=3\n")
    assert parser.get_base_indent_string() == "\t"
    parser = RoughParser("foo=1\nbar=2\nbaz=3\n")
    assert parser.get_base_indent_string() == ""



# Generated at 2022-06-12 13:04:29.480652
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    t1 = " ( ) "
    t2 = ' " " '
    for t in [t1, t2]:
        for i in range(len(t)):
            hp = HyperParser(t, i)
            print(
                t1,
                t2,
                "index",
                i,
                "is_in_string",
                hp.is_in_string(),
                "is_in_code",
                hp.is_in_code(),
                "get_surrounding_brackets",
                hp.get_surrounding_brackets(),
            )

# Generated at 2022-06-12 13:04:34.902241
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text, parser = _test_HyperParser_get_text()
    print(text.get("1.0", "2.0"))
    parser.set_index("1.0")
    assert (parser.get_surrounding_brackets() == ("1.0", "1.5"))
    assert (parser.get_surrounding_brackets(mustclose=True) is None)
    parser.set_index("1.1")
    assert (parser.get_surrounding_brackets() is None)
    assert (parser.get_surrounding_brackets(mustclose=True) is None)
    parser.set_index("1.7")
    assert (parser.get_surrounding_brackets() == ("1.6", "1.7"))

# Generated at 2022-06-12 13:04:42.854656
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def test(h, result_list):
        for i, res in enumerate(result_list):
            h.set_index(i)
            if h.is_in_code() != res:
                return False
        return True

    h = HyperParser(tk.Text(), "1.0")
    h.rawtext = "abc()'def'#ghi\n"
    h.bracketing = [(0, 0), (3, 0), (4, 0), (7, 0), (11, 0), (16, 0), (18, 0)]
    h.isopener = [0, 1, 0, 1, 1, 0]
    if not test(h, [1, 1, 1, 1, 0, 0]):
        return False

    h.rawtext = "abc()'def#ghi\n"

# Generated at 2022-06-12 13:04:51.788930
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    assert RoughParser("baba").get_base_indent_string() == ""
    assert RoughParser("baba:").get_base_indent_string() == ""
    assert RoughParser("\nba").get_base_indent_string() == "\n"
    assert RoughParser("\n ba").get_base_indent_string() == "\n "
    assert RoughParser("if 1:\n  ba").get_base_indent_string() == "  "
    assert RoughParser("if 1:\n  ba  ").get_base_indent_string() == "  "
    assert RoughParser("if 1:\n  ba  # comment").get_base_indent_string() == "  "
    assert RoughParser("\n  \n  ba  ").get_base_indent_string() == "  "


# Generated at 2022-06-12 13:04:58.957441
# Unit test for constructor of class HyperParser
def test_HyperParser():
    t = "def f():\n" + ' pass \n\t \n     pass\n' + "'pass'"
    p = RoughParser(3, 4)
    p.set_str(t)
    p.set_lo(0)
    b = p.get_last_stmt_bracketing()
    if b != [(3, 0), (14, 0), (15, 1), (18, 0), (19, 1), (20, 2), (23, 1), (24, 0)]:
        print("1st test failed: bracketing should be [(3, 0), (14, 0),", "(15, 1), (18, 0), (19, 1), (20, 2), (23, 1), (24, 0)]")
        print("but it is", b)

# Generated at 2022-06-12 13:05:06.847959
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def f(code, expected):
        rp = RoughParser(code, "utf8")
        actual = rp.get_base_indent_string()
        if actual != expected:
            print(
                "code=%s\n"
                "expected=%s\n"
                "  actual=%s\n"
                "  length=%s"
                % (
                    repr(code),
                    repr(expected),
                    repr(actual),
                    len(actual),
                )
            )
            raise ValueError
    f("", "")
    f("# comment\n", "")
    f("# comment\nx=1\n", "")
    f("    # comment\nx=1\n", "    ")
    f("x=1\n", "")

# Generated at 2022-06-12 13:05:12.317612
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=undefined-variable
    def _test(text, expected_start):
        rp = RoughParser(text)
        assert rp.find_good_parse_start() == expected_start

    _test("", 0)
    _test("\n", 0)
    _test("    spam", 0)
    _test("    spam\n", 0)
    _test("\n    spam", 0)
    _test("\n    spam\n", 0)
    _test("\n    def foo():\n        pass\n\n    spam\n", 16)
    _test("\n    def foo():\n        pass\n    #\n    spam\n", 16)

# Generated at 2022-06-12 13:05:18.773994
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-outer-name
    import unittest

    class Test(unittest.TestCase):
        def test_0(self):
            # pylint: disable=unbalanced-tuple-unpacking
            source, expected = _test_data_for_b_indent()
            rp = RoughParser(source, indentwidth=8, tabwidth=8)
            actual = rp.compute_backslash_indent()
            self.assertEqual(actual, expected)

    unittest.main()

# Generated at 2022-06-12 13:05:21.804621
# Unit test for constructor of class HyperParser
def test_HyperParser():
    test_HyperParser_helper(
        """
        if True:
            print "asldfkl"
        """,
        """
        if True:
            print "asldfkl"
        """
    )



# Generated at 2022-06-12 13:07:19.161575
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-12 13:07:24.691201
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def test_case(str, indent_width, tabwidth, answer):
        rp = RoughParser(str, indent_width, tabwidth)
        str = rp.str  # @ReservedAssignment
        assert (
            rp.compute_bracket_indent()
            == answer
        ), 'compute_bracket_indent("...{...\\n%s") returned %d, should have returned %d' % (
            str[rp.lastopenbracketpos + 1 :].expandtabs(tabwidth),
            rp.compute_bracket_indent(),
            answer,
        )


# Generated at 2022-06-12 13:07:33.786247
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class TestCase(TestCase):
        def setUp(self):
            self.s = "a = 1\nb=1"
            self.hp = HyperParser(self.s, "1.0")

    cases = (
        # Testcase (index, isopener)
        ("1.0", [False]),
        ("1.1", [False]),
        ("1.5", [True]),
        ("1.6", [True]),
        ("1.7", [False]),
        ("2.0", [False]),
        ("2.1", [False]),
        ("2.2", [False]),
    )

    for index, isopener in cases:
        tc = TestCase("test_HyperParser_set_index")
        tc.hp.set_index(index)
       

# Generated at 2022-06-12 13:07:40.496176
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-12 13:07:46.946170
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = "\"\"\"(( ) )\n()\"\"\""
    from idlelib.idle_test.mock_tk import Text

    text = Text()
    text.insert("1.0", text)
    for i in range(len(text.get("1.0", "end")) + 1):
        text.mark_set("insert", "%d.%d" % (1, i))
        hp = HyperParser(text, "insert")
        test_res = hp.get_surrounding_brackets("()")
        if "()" in text.get("1.0", "insert"):
            assert test_res == ("1.0", "1.3"), test_res

# Generated at 2022-06-12 13:07:54.797757
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    tests = (
        (0, 0, ''),
        (0, 1, ''),
        (0, 2, ''),
        (1, 0, ''),
        (1, 1, ' '),
        (1, 2, ''),
        (1, 3, ''),
        (2, 0, ''),
        (2, 1, '  '),
        (3, 0, ''),
        (3, 1, '   '),
        (4, 0, ''),
        (4, 1, '    '),
        (8, 0, ''),
        (8, 1, '        '),
        (2, 2, ''),
        (2, 3, ''),
    )
    for tabsize, count, indentation in tests:
        s = 'x' * count + '\n'
        parser

# Generated at 2022-06-12 13:08:03.826593
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from tkinter import Tk, Text

    root = Tk()
    text = Text(root)
    text.insert("insert", "for i in [1,2]:\n")
    text.insert("insert", "i.strip()\n")
    text.insert("insert", "i.spam()\n")
    text.insert("insert", "i.strip[1,2]\n")
    text.insert("insert", "i.spam[1,2]\n")
    text.insert("insert", "i.spam[1,2])\n")
    text.insert("insert", "i.spam[1,2]), 'sometext')\n")
    text.insert("insert", 'i.spam(1,2), "sometext")\n')