

# Generated at 2022-06-12 12:59:36.120702
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    r = RoughParser("", 8)

    # odd-looking case: "\\\n" is not an indent
    assert r.compute_backslash_indent("a = \\", 0) == 0

    # prefixed with tabs; indent should be in columns 0:8:
    assert r.compute_backslash_indent("\ta = \\", 0) == 0
    assert r.compute_backslash_indent("\ta = \\", 1) == 0
    assert r.compute_backslash_indent("\ta = \\", 4) == 1

    # prefixed with spaces; indent should be in columns 0:8:
    assert r.compute_backslash_indent("        a = \\", 0) == 0

# Generated at 2022-06-12 12:59:45.933624
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    rp = RoughParser("def foo():\n  pass", tabwidth=2)
    assert not rp.is_block_closer()
    rp = RoughParser("def foo():\\\n  pass", tabwidth=2)
    assert not rp.is_block_closer()
    rp = RoughParser("def foo():\n  pass\n", tabwidth=2)
    assert rp.is_block_closer()
    rp = RoughParser("def foo():\n  pass # comment\n", tabwidth=2)
    assert rp.is_block_closer()
    rp = RoughParser("def foo():\n  pass\npass\n", tabwidth=2)
    assert rp.is_block_closer()

# Generated at 2022-06-12 12:59:50.585049
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-12 12:59:57.373790
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    from unittest import mock
    from unittest import TestCase
    from pyflakes.api import StringTranslatePseudoMapping

    class TestClass(TestCase):
        def test_case(self):
            mockvv = {'a': 'b'}
            mockvvv = 'b'
            self.assertTrue(StringTranslatePseudoMapping(mockvv, mockvvv)
                            .__len__() == len(mockvv))

    test_case = TestClass().test_case



# Generated at 2022-06-12 13:00:05.072596
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    """Test the HyperParser class.

    When passed a string, the method should raise a ValueError.
    Otherwise, it should return True iff the index is in a string.

    The test is shown as a doctest.
    """
    from tkinter import Text
    from idlelib import PyShell

    # We create a Text widget, with a shell for its substring methods.
    text = Text()
    text.insert("insert", "s = '''This is a\n" 'string''')
    shell = PyShell.PyShell(text)

    # The index which is in a string, after an open triple quote.
    true_index = "2.0 + 14c"

    # The index which is not in a string, after the string.
    false_index = "2.0 + 31c"

    # We check the initial condition -

# Generated at 2022-06-12 13:00:09.628522
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    roughParser = RoughParser(
        r"""say(crazy)
# good
say(
    crazy)
# bad""",
        0,
    )
    assert roughParser.find_good_parse_start() == 87, (
        "find_good_parse_start must find the last parsed starting position"
    )


# Generated at 2022-06-12 13:00:20.026846
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import mock
    from tkinter.test.support import destroy_default_root

    BODY = """\
    def f(x):
        return x+1
    f(3)
    """

    def close(text):
        text.destroy()
        destroy_default_root()

    Text = tkinter.Text

    root = tkinter.Tk()
    root.withdraw()

    class TextMock(mock.MagicMock):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.indent_width = 4
            self.tabwidth = 8
            self.bbox = None


# Generated at 2022-06-12 13:00:26.499583
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest


# Generated at 2022-06-12 13:00:33.953125
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    parser = RoughParser(dedent('''\
    '''))
    assert parser.get_num_lines_in_stmt() == 0
    parser = RoughParser(dedent('''\
    ''').splitlines(True))
    assert parser.get_num_lines_in_stmt() == 0
    parser = RoughParser(dedent('''\
    # line comment
    '''))
    assert parser.get_num_lines_in_stmt() == 1
    parser = RoughParser(dedent('''\
    # line comment
    ''').splitlines(True))
    assert parser.get_num_lines_in_stmt() == 1

# Generated at 2022-06-12 13:00:41.708219
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def add_test(data, openers, mustclose, desired):
        if desired is not None:
            desired_before, desired_after = desired
        else:
            desired_before = desired_after = desired
        data['\n'.join([
            '', # input_str[0:0] is an empty line
            data['input_str'],
            '', # End of file is an empty line
        ]), openers, mustclose] = ((
            data['input_str'][0:desired_before] if desired_before is not None else None,
            data['input_str'][0:desired_after] if desired_after is not None else None,
        ), (0, 1)) # The empty line before and after the input

    # Test with a balanced pair (parenthesis)

# Generated at 2022-06-12 13:01:21.871502
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    from io import StringIO

    testfile = StringIO("""def func():
    print()
        """)
    rp = _RoughParser(testfile.readline)
    print("result is:", repr(rp.get_base_indent_string()))
    assert rp.get_base_indent_string() == '    '


# Generated at 2022-06-12 13:01:29.102926
# Unit test for method set_index of class HyperParser

# Generated at 2022-06-12 13:01:38.197732
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    def t(code, width):
        assert RoughParser(code, width).compute_backslash_indent() == width


# Generated at 2022-06-12 13:01:43.831789
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    test_cases = (
        (None, None),
        (3, 3),
        (3, '    '),
        ('    ', 3),
        ('    ', '    '),
        (0, None),
        (None, 0),
    )
    for tabsize, expected_result in test_cases:
        rough_parser = RoughParser()
        rough_parser.set_lo(tabsize)
        assert rough_parser.tabwidth == expected_result

# Generated at 2022-06-12 13:01:50.499297
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=too-many-branches, too-many-statements
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-return-statements
    # pylint: disable=too-many-arguments
    def check(s, expected):
        """Tests that RoughParser.find_good_parse_start returns the
        expected result for the given string.
        """
        assert s == s.strip()
        p = RoughParser(s, "utf-8")
        p.error_leader = " -> "
        result = p.find_good_parse_start()

# Generated at 2022-06-12 13:01:53.203379
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    p = RoughParser("  a = 1")
    assert p.find_good_parse_start() == 2


# Generated at 2022-06-12 13:02:00.275639
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """Test the HyperParser.set_index method

        This test is a bit complex since it tests the HyperParser
    functionality.
    """
    # Create the HyperParser object
    text_obj = ScratchText()
    text_obj.set("sub  (  5   )   +  4")
    hp = HyperParser(text_obj, "2.4")         # 'sub'
    # Get the index bracket
    assert hp.indexbracket == 0
    # Check the is_in_code method
    assert hp.is_in_code()

    hp.set_index("2.8")                       # '('
    assert hp.indexbracket == 1
    assert not hp.is_in_code()

    hp.set_index("2.10")                      # '5'
    assert hp.indexbracket == 2
    assert hp

# Generated at 2022-06-12 13:02:02.165196
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    r = RoughParser("\nf:\n    y = x[0, 0]\n")
    assert r.get_last_open_bracket_pos() == 10

# Generated at 2022-06-12 13:02:10.034163
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # 1. Test simple cases.
    r = h = HyperParser(Text(), "1.0")

    # 1.1. The index is inside a string.
    r.set_index("1.0")
    h.set_index("1.0")
    assert r.is_in_string() and h.is_in_string()

    # 1.2. The index is after a string.
    r.set_index("1.1")
    h.set_index("1.1")
    assert not r.is_in_string() and not h.is_in_string()

    # 1.3. The index is before a string.
    r.set_index("1.0")
    h.set_index("1.0")
    assert not r.is_in_string() and not h.is_in

# Generated at 2022-06-12 13:02:17.503046
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    from unittest import TestCase

    text = """\
a = 'string'
b = "string"
c = """ + '"""' + """string""" + '"""' + """
d = '''string'''
e = """ + '"""' + """string""" + '"""' + """
"""
    class T(TestCase):
        def test(self):
            self.last_test = None
            self.assertEqual(self.last_test, "string" in text)
            self.assertEqual(self.last_test, 'string' in text)
            self.assertEqual(self.last_test, 'str' in text)
            self.assertEqual(self.last_test, "string" in text)
            self.assertEqual(self.last_test, "string" in text)
            self

# Generated at 2022-06-12 13:07:00.856262
# Unit test for method set_index of class HyperParser

# Generated at 2022-06-12 13:07:08.210996
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    global paren
    global text
    global index

    t = Tk()
    t.withdraw()
    text = Text(t)
    text.insert("insert", sample)
    index = "22.0"
    hp = HyperParser(text, index)
    assert (hp.get_expression() == "")
    index = "26.0"
    hp = HyperParser(text, index)
    assert (hp.get_expression() == "")
    index = "28.0"
    hp = HyperParser(text, index)
    assert (hp.get_expression() == "")
    index = "29.0"
    hp = HyperParser(text, index)
    assert (hp.get_expression() == "")
    index = "30.0"
    hp = HyperParser(text, index)

# Generated at 2022-06-12 13:07:16.158309
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # Test cases can't be expressed with a table, because the results
    # depend on the context. So they are expressed as code.
    assert HyperParser("", "1.0").get_expression() == ""
    assert HyperParser("", "2.0").get_expression() == ""
    assert HyperParser("#", "1.0").get_expression() == ""
    assert HyperParser("#", "2.0").get_expression() == ""
    assert HyperParser("a", "1.1").get_expression() == ""
    assert HyperParser("a", "1.2").get_expression() == ""
    assert HyperParser("a \\\n b", "1.3").get_expression() == ""
    assert HyperParser("a \\\n b", "2.0").get_expression() == ""

# Generated at 2022-06-12 13:07:23.213796
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import io
    import tokenize
    from idlelib.parsers.pyparse import PyParse

    fstr = """\
#! /usr/bin/env python
# This is commented
'''And this is
    a multiline
    string'''
"""
    f = io.StringIO(fstr)
    f.seek(0, 0)
    t = tokenize.generate_tokens(f.readline)
    assert next(t)[0] == tokenize.COMMENT
    assert next(t)[0] == tokenize.STRING
    parser = PyParse(indent_width=8, tab_width=8)
    parser.set_str(fstr)
    parser.set_lo(0)
    parser.parse_source()

# Generated at 2022-06-12 13:07:25.717852
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-12 13:07:34.844262
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-12 13:07:41.559790
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    from idlelib.IdleHistory import history_length
    from unittest import mock

    from idlelib.idle_test.mock_idle import Func

    with mock.patch('idlelib.HyperParser.history_length',
                    new=Func()):
        class text(object):
            def __init__(self, doc):
                self.doc = doc
                self.indentwidth = 8
                self.tabwidth = 8
            def index(self, index):
                return int(float(index))
            def get(self, *args):
                return self.doc[args[0]:args[1]]

        def index_const(index):
            return index

        def get_expression(index, expect):
            exp = HyperParser(text(doc), index).get_expression()
            assert exp == expect, f

# Generated at 2022-06-12 13:07:47.646909
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    t = Tk()
    t.withdraw()
    from idlelib.textView import view_text
    txt = view_text.ViewText(t)
    txt.insert("1.0", "if x == 0:\n    pass\n")
    # Before the first statement
    hp = HyperParser(txt, "1.1")
    assert hp.indexinrawtext == 0
    # In the first statement, before the if
    hp.set_index("1.5")
    assert hp.indexinrawtext == 4
    # In the first statement, at the ':'
    hp.set_index("1.8")
    assert hp.indexinrawtext == 7
    # In the second statement, before the pass
    hp.set_index("2.1")
    assert hp.indexinrawtext == 10
   

# Generated at 2022-06-12 13:07:55.398640
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=redefined-builtin
    parser = RoughParser("if 1:\n  if 2:\n    x = 3\n")
    assert parser.find_good_parse_start() == 0
    parser = RoughParser("if 1:\n  if 2:\n    x = 3")
    assert parser.find_good_parse_start() == 0
    parser = RoughParser("if 1:\n  if 2:\n    x = 3\n  if 4:\n    x = 5\n")
    assert parser.find_good_parse_start() == 0
    parser = RoughParser("if 1:\n  if 2:\n    x = 3\n  if 4:\n    x = 5")
    assert parser.find_good_parse_start() == 0

# Generated at 2022-06-12 13:08:03.708227
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    import doctest
    doctest.testmod()

# UNIT TESTING

# The following code runs a small test suite when the module is run
# under Python 2.3; if it fails, it yields a message describing the
# failure.  Only a subset of the tests are run in this mode; the
# --verbose flag to the script turns on all tests.  All the tests are
# run when the --test flag is passed to the script under Python 2.3
# or higher.

# The test suite is designed to run under Python 2.2, too, but it
# can't be automatically run under that version, because the doctest
# module wasn't available then.

if __name__ == "__main__":
    test_parser()