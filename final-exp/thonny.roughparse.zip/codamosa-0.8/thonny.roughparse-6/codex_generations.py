

# Generated at 2022-06-12 12:58:49.322675
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rp = RoughParser("\t\tDUMMY_TEXT")
    assert rp.compute_backslash_indent() == 1 + 8

    rp = RoughParser("\tdummy = 1 + \\\n\t\tDUMMY_TEXT")
    assert rp.compute_backslash_indent() == 1 + 8

    rp = RoughParser("dummy = 1 + \\\n\t\tDUMMY_TEXT")
    assert rp.compute_backslash_indent() == len("dummy = 1 + ")

    rp = RoughParser("dummy = 1 + DUMMY_TEXT")
    assert rp.compute_backslash_indent() == len("dummy = 1 + ")


# Generated at 2022-06-12 12:58:59.954430
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    assert HyperParser.get_surrounding_brackets.__doc__
    # - Test list of openers with all different types of brackets
    openers = "([{"
    # - Test with index at bracket edge
    for opener in openers:
        for closer in openers:
            if opener == closer:
                code = opener + "a" + closer
            else:
                code = opener + "a" + closer + ")"
            h = HyperParser("a" + code, "insert")
            assert h.get_surrounding_brackets(openers) == ("insert", "insert+2c")
            assert h.get_surrounding_brackets(openers, mustclose=True) is None

    # - Test with index at inside of bracket

# Generated at 2022-06-12 12:59:07.270755
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():

    class DummyText:
        def index(self, index):
            return "1.{0}".format(index)

        def get(self, index1, index2):
            return index1 + ":" + index2

    def test(text, index, expected):
        text = DummyText()
        h = HyperParser(text, index)
        start_index, end_index = h.get_surrounding_brackets(mustclose=True)
        if start_index is None:
            raise ValueError("HyperParser.get_surrounding_brackets() returned None")
        found = text.get(start_index, end_index)
        assert found == expected

    text = "foo(#baz\n'bar')"
    test(text, 7, "(#baz\n'bar')")

# Generated at 2022-06-12 12:59:13.325756
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class HyperParserTestCase(unittest.TestCase):
        def __init__(self, name):
            super().__init__(name)
            self.text = Text()

        def check_before_after(self, hp, name, before, after):
            before = self.text.index(before)
            after = self.text.index(after)
            if not hp.is_in_code():
                self.fail("%s is not inside code" % name)
            self.assertEqual(
                hp.get_surrounding_brackets(), (self.text.index(before), self.text.index(after))
            )

        def check_before_after_expression(self, hp, name, before, after, expression):
            before = self.text.index(before)
            after

# Generated at 2022-06-12 12:59:18.062622
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # bug reported by Yves Duhoux:
    # https://bugs.launchpad.net/idlefork/+bug/1799449
    #
    # is_in_code --> False
    s = """\
a="""
    text = idlelib.editor.EditorWindow(None)
    text.set_text(s)
    text.set_line_and_column(1, 1)
    hp = HyperParser(text, "1.0")
    assert not hp.is_in_code()
    text.close()



# Generated at 2022-06-12 12:59:27.949607
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    def assert_find_good_parse_start(input_string, expected_start_pos):
        parser = RoughParser(indent_width=4)
        actual_start_pos = parser.find_good_parse_start(input_string, 0)
        assert expected_start_pos == actual_start_pos, \
            (input_string, expected_start_pos, actual_start_pos)

    # Empty string and whitespace only strings
    assert_find_good_parse_start("", 0)
    assert_find_good_parse_start("  \t\n \t \n", 0)

    # Comment-only string
    assert_find_good_parse_start("# hello", 0)
    assert_find_good_parse_start("# hello\nworld", 1)

    # String which starts with a non-function

# Generated at 2022-06-12 12:59:35.731617
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    import unittest

    class Test(unittest.TestCase):
        def test_empty(self):
            self.assertEqual(RoughParser("").get_base_indent_string(), "")

        def test_normal(self):
            self.assertEqual(RoughParser("  foo").get_base_indent_string(), "  ")
            self.assertEqual(RoughParser("   \t  foo").get_base_indent_string(), "   \t  ")
            self.assertEqual(RoughParser("  foo\n  bar").get_base_indent_string(), "  ")
            self.assertEqual(RoughParser(" foo\n  bar").get_base_indent_string(), " ")

# Generated at 2022-06-12 12:59:45.933011
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    assert HyperParser("foo()\n", "1.4").get_expression() == "foo"
    assert HyperParser("f()\n", "1.2").get_expression() == ""
    assert HyperParser("(1,)\n", "1.3").get_expression() == ""
    assert HyperParser("f(x).g()\n", "1.6").get_expression() == "f(x).g"
    assert HyperParser("f(x).g()\n", "1.5").get_expression() == "f(x)"
    assert HyperParser("f(x+y).g()\n", "1.6").get_expression() == "f(x+y).g"

# Generated at 2022-06-12 12:59:55.103219
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # TODO: Move this test to Lib/test/test_hyperparser.py
    def t(index, prio, isinstr):
        h = HyperParser(text, index)

        if isinstr != h.is_in_string():
            if isinstr:
                print("%s should be in a string" % index)
            else:
                print("%s should not be in a string" % index)
        h = HyperParser(text, "insert")
        if prio != h.get_expression():
            print("%s: wrong expression %r" % (index, h.get_expression()))

    paren = "()"

# Generated at 2022-06-12 13:00:03.224802
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest
    from idlelib.idle_test.mock_tk import Mbox


# Generated at 2022-06-12 13:00:44.641189
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    def check(s, want):
        result = RoughParser(s).is_block_opener()
        assert result == want, (s, result)

# Generated at 2022-06-12 13:00:47.582874
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import Tkinter
    import tkHyperParser
    root = Tkinter.Tk()
    text = tkHyperParser.HyperParser(root)
    text.insert("1.0", "if True: # comment\n   pass\n'this is a string'")
    root.mainloop()

# Generated at 2022-06-12 13:00:48.709053
# Unit test for method is_block_opener of class RoughParser

# Generated at 2022-06-12 13:00:58.150942
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def check(
        string,
        indent_width=4,
        tabwidth=8,
        expected_result=None,
        continuation='C_BRACKET',
    ):
        rp = RoughParser(string, indent_width, tabwidth)
        assert rp.get_continuation_type() == continuation
        actual_result = rp.compute_bracket_indent()
        assert actual_result == expected_result
        return actual_result

    def eq(a, b):
        assert a == b, "%r == %r" % (a, b)

    eq(check("\nif 1:\n    for i in range(2):"), 4)
    eq(check("\nif 1:\n    for i in range(2):", continuation='C_BACKSLASH'), 5)

# Generated at 2022-06-12 13:01:07.482899
# Unit test for method set_index of class HyperParser

# Generated at 2022-06-12 13:01:16.946820
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
   HyperParser._test1("([])", "")

# Generated at 2022-06-12 13:01:25.431436
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    p = RoughParser("[\nhello\n")
    RESULT = p.compute_bracket_indent()
    assert RESULT == 0

    p = RoughParser("[\n  hello\n")
    RESULT = p.compute_bracket_indent()
    assert RESULT == 2

    p = RoughParser("[\n  hello\n\n")
    RESULT = p.compute_bracket_indent()
    assert RESULT == 2

    p = RoughParser("{\nhello\n")
    RESULT = p.compute_bracket_indent()
    assert RESULT == 0

    p = RoughParser("{\n  hello\n")
    RESULT = p.compute_bracket_indent()
    assert RESULT == 2


# Generated at 2022-06-12 13:01:31.408861
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest
    import Tkinter, tkFont

    try:
        import idlelib.EditorWindow
    except ImportError:
        # Run standalone.
        class EditorWindow(Tkinter.Toplevel):
            def __init__(self):
                Tkinter.Toplevel.__init__(self)
                text = Tkinter.Text(self)
                text.pack()
                # Dummy methods for the following attributes
                self.io = self
                self.top = self
                self.text = text
                self.text_frame = self
                self.indentwidth = 8
                self.tabwidth = 8
                self.widget_name = "EditorWindow"
                self.usetabs = False
                self.context_use_ps1 = False

# Generated at 2022-06-12 13:01:33.058377
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    for failed in _test_HyperParser_is_in_code():
        yield failed


# Generated at 2022-06-12 13:01:42.334331
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest

    class HPSetIndexTestCase(unittest.TestCase):

        def test_set_index(self):
            from idlelib import idle_test
            idle_test.use_resources(
                None,
                [],
                idle_test.__file__,
                "idlelib",
                "idle_test.py"
            )
            text = idle_test.editor_text
            lines = text.split("\n")
            h = HyperParser(text, "1.0")
            for lineno, line in enumerate(lines):
                for col, char in enumerate(line):
                    h.set_index("%d.%d" % (lineno + 1, col))
                    bracketing = h.get_surrounding_brackets("({[")

# Generated at 2022-06-12 13:02:32.692237
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rough_parser = RoughParser('''\
               a
             b
           c''')
    assert rough_parser.get_base_indent_string() == '           '

# Generated at 2022-06-12 13:02:38.863944
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = "if (1):\n  if (2):\n    if [3]:\n      pass\n"

    parser = HyperParser(text, text.index("f [3]"))
    assert parser.get_surrounding_brackets() == (text.index("[3"), text.index("]")), "failure 1"

    parser = HyperParser(text, text.index("3]"))
    assert parser.get_surrounding_brackets() == (text.index("[3"), text.index("]")), "failure 2"

    parser = HyperParser(text, text.index("[3"))
    assert parser.get_surrounding_brackets() == (text.index("if ["), text.index("]:")), "failure 3"


# Generated at 2022-06-12 13:02:44.913582
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    rp = RoughParser("""
                class Foo:
                    # comments
                pass""")
    rp.find_good_parse_start()
    assert rp.error_line == 6

    rp = RoughParser("""
                class Foo:
                    # comments
                pass""",
                     error_line=5)
    rp.find_good_parse_start()
    assert rp.error_line == 6

    rp = RoughParser("""
                class Foo:
                    # comments
                pass""",
                     error_line=7)
    rp.find_good_parse_start()
    assert rp.error_line == 7

    rp = RoughParser("""
                class Foo:
                    # comments
                pass""",
                     error_line=8)
    rp.find_good_parse_start

# Generated at 2022-06-12 13:02:46.193751
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-12 13:02:52.775434
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():

    class Tk_Text(object):

        def __init__(self):
            self.insertions = {}
            self.deletions = {}

        def delete(self, start, end):
            self.deletions[start] = self.get(start, end)

        def index(self, index):
            # Remove things we deleted at the given index
            while index in self.deletions:
                index += "+%dc" % len(self.deletions[index])
            return index

        def get(self, start, end):
            res = ""
            while start != end:
                # Take things we inserted in
                if start in self.insertions:
                    res += self.insertions[start]
                    start += "+%dc" % len(self.insertions[start])

# Generated at 2022-06-12 13:02:59.633072
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():

    rough_parser = RoughParser("# some text")
    assert rough_parser.get_last_stmt_bracketing() == ((10, 0), (10, 0))

    rough_parser = RoughParser("# some text \nsome code")
    assert rough_parser.get_last_stmt_bracketing() == ((1, 0), (5, 0), (5, 0))

    rough_parser = RoughParser("# some text \nsome code\n# some other text")
    assert rough_parser.get_last_stmt_bracketing() == ((1, 0), (5, 0), (5, 0))

    rough_parser = RoughParser("some code\n# some text")
    assert rough_parser.get_last_stmt_bracketing() == ((0, 0), (0, 0))

    rough_

# Generated at 2022-06-12 13:03:08.575471
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    c = lambda s: [s, len(s)]

# Generated at 2022-06-12 13:03:14.422467
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-12 13:03:23.874612
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    class FakeConfig:
        def getint(self, x):
            if x == 'Indent':
                return 4
            if x == 'Tab':
                return 8
    #

# Generated at 2022-06-12 13:03:30.489723
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    abc\n    def", 0, 4)
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("abc\n    def", 0, 4)
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("    abc\n    def", 4, 8)
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    abc\n    def", 0, 0)
    assert rp.get_base_indent_string() == ""



# Generated at 2022-06-12 13:05:13.880628
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    tests = [
        ("xyz", False),
        ("xyz'", False),
        ("xyz'abc", True),
        ('xyz"', False),
        ('xyz"abc', True),
        ("xyz'''", False),
        ("xyz'''abc", True),
        ('xyz"""', False),
        ('xyz"""abc', True),
        ('xyz"""a"""', True),
        ('xyz"""""', False),
    ]

    for text, expected in tests:
        h = HyperParser(Text(text, None), "1.end")
        result = h.is_in_string()
        failure = result != expected
        print(">>>", text, expected, result, failure)
        if failure:
            raise AssertionError("test failed")


# Generated at 2022-06-12 13:05:22.642896
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    good = {}  # find_good_parse_start(k) should return v
    good[""] = (0, "")
    good["\n"] = (1, "\n")
    good["\n\n"] = (2, "\n\n")
    good["\n#"] = (1, "\n")
    good["\n##"] = (1, "\n")
    good["\n###"] = (1, "\n")
    good["\n####"] = (1, "\n")
    good["\n\n#"] = (2, "\n\n")
    good["\n\n##"] = (2, "\n\n")
    good["\n\n###"] = (2, "\n\n")
    good["\n\n####"] = (2, "\n\n")


# Generated at 2022-06-12 13:05:33.007451
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = tk.Text()
    text.insert(1.0, """\
    def f():
        pass

    def g():
        pass
    """)
    for i in range(2):
        for what in "#q'\"([{ )}]q'''":
            hp = HyperParser(text, "%d.17" % (i + 1))
            assert hp.is_in_code() == (what not in " '\"#([{)}]")
            assert hp.is_in_string() == (what in ' "#')
            if what in ("([{", " )]}", "q'\""):
                assert hp.get_surrounding_brackets() == ("%d.10" % (i + 1), "%d.18" % (i + 1))

# Generated at 2022-06-12 13:05:39.422341
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():

    class TestParser(HyperParser):
        def __init__(self, text, index):
            HyperParser.__init__(self, text, index)
            self.text = text
            self.index = index

        def test(self):
            return self.get_expression()

    def test_get_expression(text, index, expected):
        return TestParser(text, index).test() == expected

    assert test_get_expression("a", "1.1", "a")
    assert test_get_expression("a+b", "1.2", "b")
    assert test_get_expression("a+b", "1.1", "a")
    assert test_get_expression("a\nb c", "2.3", "c")
    assert test_get_expression("a\nc", "2.1", "c")

# Generated at 2022-06-12 13:05:47.795760
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():

    def test(s, expected=None, tabwidth=8, **kwargs):
        parser = RoughParser(s, tabwidth=tabwidth, **kwargs)
        found = parser.compute_backslash_indent()
        if expected is not None:
            assert found == expected, "expected %d, found %d" % (expected, found)

    test("a = \\", 9)
    test("a == \\", 9)
    test("a != \\", 9)
    test("a <> \\", 9)
    test("a <= \\", 9)
    test("a >= \\", 9)
    test("a << \\", 9)
    test("a >> \\", 9)
    test("a <<= \\", 9)
    test("a >>= \\", 9)
    test("a < \\", 9)
   

# Generated at 2022-06-12 13:05:56.701906
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    root = Tk()
    text = Text(root)
    h = HyperParser(text, "1.0")
    text.insert("insert", r'a="test"')
    h.set_index("1.6")
    assert h.is_in_string() is True
    h.set_index("1.3")
    assert h.is_in_string() is False
    text.insert("insert", r'b=\'test\'')
    h.set_index("1.10")
    assert h.is_in_string() is True
    h.set_index("1.7")
    assert h.is_in_string() is False
    text.insert("insert", 'c="""test1\ntest2"""')
    h.set_index("1.18")
    assert h.is_

# Generated at 2022-06-12 13:06:03.907035
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    text.insert("1.0", "a = 0")
    parser = HyperParser(text, "1.2")
    parser.set_index("1.0")
    if parser.indexbracket != 0:
        raise ValueError("parser.indexbracket should be 0")
    if parser.indexinrawtext != 1:
        raise ValueError("parser.indexinrawtext should be 1")

    parser.set_index("1.2")
    if parser.indexbracket != len(parser.bracketing) - 1:
        raise ValueError("parser.indexbracket should be len()-1")
    if parser.indexinrawtext != len(parser.rawtext) - 1:
        raise ValueError("parser.indexinrawtext should be len()-1")



# Generated at 2022-06-12 13:06:04.939544
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-12 13:06:14.172294
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    """
    Test RoughParser.get_last_stmt_bracketing method
    """
    from pygments.lexers import PythonLexer


# Generated at 2022-06-12 13:06:23.105883
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class HyperParserTest(TestCase):
        def setUp(self):
            self.text = Text()
            self.text.set("abcdefg")
            #       01234567

        def test_set_index(self):
            h = HyperParser(self.text, "4.0")
            #                   01234
            self.assertEqual(h.indexinrawtext, 4)
            self.assertEqual(h.indexbracket, 1)
            self.assertEqual(h.text.get("1.0", "6.0"), "abcde")
            self.assertEqual(h.rawtext, "abcde")
            self.assertEqual(h.stopatindex, "6.0")