

# Generated at 2022-06-12 12:58:24.093182
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    t = RoughParser("\nabcd")
    assert t.get_base_indent_string() == ""
    t = RoughParser("  \nabcd")
    assert t.get_base_indent_string() == "  "
    t = RoughParser("\t\nabcd")
    assert t.get_base_indent_string() == "\t"
    t = RoughParser("   :\nabcd")
    assert t.get_base_indent_string() == "   "
    t = RoughParser("   :\\\nabcd")
    assert t.get_base_indent_string() == "   "
    t = RoughParser("a = \\")
    assert t.get_base_indent_string() == "a = "


# Generated at 2022-06-12 12:58:28.476257
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest


# Generated at 2022-06-12 12:58:29.095968
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-12 12:58:35.867424
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def h(text, idx):
        return HyperParser(text, idx).get_surrounding_brackets()

    e = ("", "")

    idx = "1.0"
    assert h(e, idx) is None
    assert h("(", idx) is None
    assert h(")", idx) is None
    assert h(" ()", idx) is None
    assert h("( )", idx) == ("1.0", "1.2")
    assert h("a ( )", idx) is None
    assert h("[ ]", idx) == ("1.0", "1.2")
    assert h("{ }", idx) == ("1.0", "1.2")
    assert h("a [ ]", idx) is None

# Generated at 2022-06-12 12:58:45.433590
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    def test(expected, source, *args):
        parser = RoughParser(*args)
        parser.set_str(source)
        result = parser.compute_backslash_indent()
        assert result == expected, (result, source, args)

    test(1, "a = 0")
    test(5, "a = \\\n  0")
    test(1, "a = 0; b = 0")
    test(1, "a = 0; b = \\\n0")
    test(1, "a = 0; b = 0 \\\n")
    test(1, "a = 0; b = 0\\\n")
    test(3, "if 1:\\\n  a = 0")

# Generated at 2022-06-12 12:58:53.249189
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    # doc, startindex, expected_result, mustclose
    tests = []

    # Tests for function get_surrounding_brackets of class HyperParser

    # Test positions of (|) and other brackets, in the same line.
    tests.append(
        (
            "x = (123+|456)*web",
            "sel.index",
            ("sel.index+4c", "sel.index+10c"),
            True,
        )
    )
    tests.append(
        ("x = (123+|456)*web", "sel.index", ("sel.index+4c", "2.0 lineend"), False)
    )

# Generated at 2022-06-12 12:59:01.998728
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    assert RoughParser("abc", 0).get_base_indent_string() == ""
    assert RoughParser("abc\n", 0).get_base_indent_string() == ""
    assert RoughParser("   abc\n", 0).get_base_indent_string() == "   "
    assert RoughParser("\tabc\n", 0).get_base_indent_string() == "\t"
    assert RoughParser("\t \t \tabc\n", 0).get_base_indent_string() == "\t \t \t"
    assert RoughParser("abc\n   def\n", 0).get_base_indent_string() == ""
    assert RoughParser("abc\n  \t\ndef\n", 0).get_base_indent_string() == ""


# Generated at 2022-06-12 12:59:08.555141
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    """Test the method set_lo() of class RoughParser"""
    # pylint: disable=too-many-locals
    if hasattr(RoughParser, '_test_set_lo_done'):
        return

    RoughParser._test_set_lo_done = True

    # Test suite for set_lo:
    import random, string
    import operator


# Generated at 2022-06-12 12:59:15.201799
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    parser_tester = RoughParser("foo()\nf()\n")
    assert parser_tester.find_good_parse_start() == 0
    parser_tester = RoughParser(" foo()\nf()\n")
    assert parser_tester.find_good_parse_start() == 1
    parser_tester = RoughParser("  foo()\nf()\n")
    assert parser_tester.find_good_parse_start() == 2
    parser_tester = RoughParser("foo()\n f()\n")
    assert parser_tester.find_good_parse_start() == 5
    parser_tester = RoughParser("foo()\n  f()\n")
    assert parser_tester.find_good_parse_start() == 6

# Generated at 2022-06-12 12:59:25.509832
# Unit test for constructor of class HyperParser
def test_HyperParser():
    eq = unittest.TestCase.assertEqual

    class MockText:
        index_prefix = "1.0"
        getprefix = "get"

        def __init__(self, content, index_prefix="1.0", getprefix="get"):
            self.content = content
            self.index_prefix = index_prefix
            self.getprefix = getprefix

        def index(self, index):
            return self.index_prefix + index

        def get(self, start, end):
            return self.getprefix + self.content[int(start[2:]) : int(end[2:])]

    def test_HyperParser_with_content(content, index, *args):
        text = MockText(content)
        hyper = HyperParser(text, text.index(index))

# Generated at 2022-06-12 13:00:58.531529
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    test_code = (
        "foo = 1\\\n"
        "    +\\\n"
        "    2\n"
        "bar = 3\\\n"
        "       +\\\n"
        "       4\n"
    )
    assert RoughParser(test_code).compute_backslash_indent() == 5


# Generated at 2022-06-12 13:01:07.937541
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Text()

# Generated at 2022-06-12 13:01:17.335271
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():

    # local state machine to check that _chew_ordinaryre
    # and _itemre work as expected
    SOMETHING = 0
    JUNK = 1
    STMT_START = 2
    LIST_ITEM = 3
    COMMENT = 4
    STRING = 5
    def check_state(state, newstate, ch):
        if state == SOMETHING:
            if newstate == JUNK:
                assert ch in ' \t\n'
            elif newstate == STMT_START:
                assert ch not in ' \t\n'
            elif newstate == LIST_ITEM:
                assert ch == '-' or ch.isdigit() and (len(ch) > 1 or ch != '0')
            elif newstate == COMMENT:
                assert ch == '#'

# Generated at 2022-06-12 13:01:24.275277
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    """
    Testing for method is_in_code of class HyperParser
    """
    from idlelib.idle_test.mock_idle import Func
    f = Func()
    f.editwin = mock.Mock()
    f.editwin.text = ''

    p = HyperParser(f.editwin.text, '1.0')
    p.set_index('1.0')
    p.is_in_code()
    f.editwin.text.index.assert_called_with('1.0')
    print('Successfully tested method is_in_code of class HyperParser.')


# Generated at 2022-06-12 13:01:30.763226
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def get_indices(hp, openers="([{", mustclose=False):
        indices = hp.get_surrounding_brackets(openers, mustclose)
        if indices is None:
            return None, None
        return hp.text.index(indices[0]), hp.text.index(indices[1])

    def chk(text, index, openers, mustclose, indices):
        # build the HyperParser object
        hp = HyperParser(Tkinter.Text(None, width=80, height=24), "insert")
        hp.text.delete("1.0", "end")
        hp.text.insert("1.0", text)
        hp.set_index(index)
        returned = get_indices(hp, openers, mustclose)

# Generated at 2022-06-12 13:01:33.058282
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    mapping = StringTranslatePseudoMapping({32:32}, 45)
    mapping[32] == 32
    mapping[0] == 45


# Generated at 2022-06-12 13:01:36.264284
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rp = RoughParser("class Foo:\n    def bar(self):\n        if True:\n            pass\n")
    rp._study2()
    assert rp.compute_bracket_indent() == 0

# Generated at 2022-06-12 13:01:45.221069
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    """Some unit tests for RoughParser_compute_backslash_indent"""
    rp = RoughParser("        \\\n        a = b\\\n        + c")
    assert rp.compute_backslash_indent() == 8
    rp = RoughParser("if a:\\\n    b\n")
    assert rp.get_continuation_type() == C_BACKSLASH
    assert rp.compute_backslash_indent() == 4
    rp = RoughParser("if a:\\\n    b + \\")
    assert rp.get_continuation_type() == C_BACKSLASH
    assert rp.compute_backslash_indent() == 4

# Generated at 2022-06-12 13:01:51.403222
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest
    import sys

    try:
        from tkinter import *
    except:
        from Tkinter import *

    class HyperParserTest(unittest.TestCase):
        def setUp(self):
            self.root = Tk()
            self.text = Text(self.root)
            self.text.pack()
            self.text.insert("1.0", "abc(def() 'string'\n" "123\n" "234)\n" '"string" (1) def')
            self.text.mark_set("insert", "1.0")

        def tearDown(self):
            self.root.destroy()


# Generated at 2022-06-12 13:01:56.647055
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    import unittest
    exec("""def getit(key, _get=non_defaults.get, _default=default_value):
        return _get(key, _default)""")
    unittest.TestCase().assertEqual(
        getit(ord('x')),ord('x'),
        'Failed on example: getit(ord(\'x\'))'
    )

# Generated at 2022-06-12 13:03:33.123702
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin

    def run(s, indent_width, tabwidth, expected):
        rp = RoughParser(s, indent_width, tabwidth)
        result = rp.compute_bracket_indent()
        assert result == expected, (
            "test failed; "
            "result = %r, expected %r, args %r %r %r"
            % (result, expected, s, indent_width, tabwidth)
        )

    run("[\n]", 4, 8, 1)
    run("[\n    ]", 4, 8, 5)
    run("[\n   foo\n]", 4, 8, 3)
    run("[\n   foo\n]", 2, 4, 2)

# Generated at 2022-06-12 13:03:39.703334
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
        rp = RoughParser(newtext = "")
        assert rp.get_base_indent_string() == ""
        rp = RoughParser(newtext = "    ")
        assert rp.get_base_indent_string() == "    "
        rp = RoughParser(newtext = "  for i in range(4):\n")
        assert rp.get_base_indent_string() == "  "
        rp = RoughParser(newtext = "  for i in range(4):\n    print(i)\n")
        assert rp.get_base_indent_string() == "    "


# Generated at 2022-06-12 13:03:46.326391
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    assert StraightParser("").compute_backslash_indent() == 0
    assert StraightParser("x").compute_backslash_indent() == 0
    assert StraightParser("x \\\n").compute_backslash_indent() == 2
    assert StraightParser("if 1:").compute_backslash_indent() == 0
    assert StraightParser("if 1:\n").compute_backslash_indent() == 0
    assert StraightParser("if 1: \\\n").compute_backslash_indent() == 4
    assert StraightParser("if foo:").compute_backslash_indent() == 0
    assert StraightParser("if foo:\n").compute_backslash_indent() == 0
    assert StraightParser("if foo: \\\n").compute_backslash_indent()

# Generated at 2022-06-12 13:03:51.147486
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser(indent_width=4, tabwidth=8)
    rp.set_lo(7)
    assert rp.study_level >= 1
    assert len(rp.goodlines) > 0


# Generated at 2022-06-12 13:03:58.909387
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    def check(s, offset, result):
        assert RoughParser(s).find_good_parse_start(offset) == result
    # blank or comment lines
    s = '\n   #foo\nbar'
    check(s, 0, 0)
    check(s, 1, 0)
    check(s, 2, 0)
    check(s, 3, 3)
    check(s, 4, 3)
    check(s, 5, 3)
    # lines after the first one
    s = "foo\n   #foo\nbar"
    check(s, 0, 0)
    check(s, 1, 0)
    check(s, 2, 0)
    check(s, 3, 3)
    check(s, 4, 3)
    check(s, 5, 3)

# Generated at 2022-06-12 13:04:05.767866
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-12 13:04:07.459675
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    from _testcapi import test_find_good_parse_start

# Generated at 2022-06-12 13:04:16.152358
# Unit test for method set_lo of class RoughParser

# Generated at 2022-06-12 13:04:25.045153
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    verbose = "-v" in sys.argv[1:]

    if False:
        # Test for a specific expression
        rawtext = "a+  b"
        indexinrawtext = len(rawtext) - 1
        print("Testing expression %s:" % repr(rawtext))
        hp = HyperParser(rawtext, indexinrawtext)
        #~ print (hp.rawtext)
        #~ print (hp.bracketing)
        #~ print (hp.isopener)
        expr = hp.get_expression()
        print("  expression is %s" % repr(expr))


# Generated at 2022-06-12 13:04:26.838159
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("for (i in range(10)):\n    print(i)")


# Generated at 2022-06-12 13:06:01.448116
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def t(str_, indent_width=4, tabwidth=8):
        rp = RoughParser(str_, indent_width, tabwidth)
        return rp.compute_bracket_indent()

    assert t("[") == 4
    assert t("[1,2]") == 4
    assert t("[\n  1,\n  2\n]") == 4
    assert t("{\n  a:b,\n  c:d\n}") == 4
    assert t("(\n  a,\n  b\n)") == 4
    assert t("[a,\n  b,\n  c\n]") == 6
    assert t("[a,\n  b,\n") == 4

# Generated at 2022-06-12 13:06:09.921470
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from idlelib.idle_test.mock_tk import Mbox_func
    from idlelib.idle_test.htest import run

    try:
        import idlelib.colorizer as colorizer
    except ImportError:
        raise unittest.SkipTest("idlelib.colorizer not available")

    colorizer.color_config = idleConf.IdleConfParser(
        idleConf.COLOR_SCHEME_DICT, "test", idleConf.GetSectionName
    )
    tk = Mbox_func()
    text = Text(tk)
    text.insert("insert", "def foo(bar):\n" "    pass\n")
    hp = HyperParser(text, "1.10")
    hp.set_index("1.0")
    hp.set_index("1.4")
   

# Generated at 2022-06-12 13:06:19.206233
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def f(s, w, i):
        parser = RoughParser(s, w)
        got = parser.compute_bracket_indent()
        if got != i:
            print("For input", repr(s))
            print(" expected", i)
            print("      got", got)
        assert got == i

    # pylint: disable=bad-whitespace
    f("foo(",           4, 5)
    f("foo(bar=1,",     4, 5)
    f("foo(bar, baz",   4, 5)
    f("foo([",          4, 5)
    f("foo([1,2,",      4, 5)
    f("foo(a,",         4, 9)
    f("foo(a=1,",       4, 9)

# Generated at 2022-06-12 13:06:20.420579
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 13:06:26.603322
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """Unit test of HyperParser.set_index"""
    # Arguments of HyperParser.set_index:
    # self.text
    # index

    text = "a.b\n"
    hyparser = HyperParser(text, "1.1")
    hyparser.set_index("1.2")
    # self.indexinrawtext
    # self.indexbracket
    # self.indexbracket
    assert hyparser.indexinrawtext == 1
    assert hyparser.indexbracket == 1



# Generated at 2022-06-12 13:06:34.189961
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class HyperParserTest(unittest.TestCase):
        def test_empty(self):
            self.assertEqual(
                HyperParser("", "1.0").get_surrounding_brackets(), None
            )
            self.assertEqual(
                HyperParser("text", "1.0").get_surrounding_brackets(), None
            )
            self.assertEqual(
                HyperParser("\n", "2.0").get_surrounding_brackets(), None
            )

        def test_parens(self):
            self.assertEqual(
                HyperParser("(", "1.0").get_surrounding_brackets(), None
            )

# Generated at 2022-06-12 13:06:40.664431
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """Some basic tests for the set_index method"""
    from test.support import findfile

    filename = findfile("data/tokenize_tests.txt", subdir="idlelib")
    with open(filename) as fh:
        lines = fh.readlines()

    hp = HyperParser(lines, "1.0")
    for i in range(len(lines)):
        hp.set_index("%d.0" % (i + 1))
        if i + 1 == len(lines):
            # The statement is empty
            assert hp.bracketing == []
            assert hp.isopener == []
            assert hp.rawtext == ""
            assert hp.indexinrawtext == 0
            assert hp.indexbracket == 0

# Generated at 2022-06-12 13:06:47.343802
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    """Test set_lo in RoughParse"""
    # value saving
    rp = RoughParser("abc")
    rp.set_lo(3)
    expected = 3
    assert rp.lo == expected, '%r == %r' % (rp.lo, expected)
    # value saving
    rp = RoughParser("abc")
    rp.set_lo()
    expected = 0
    assert rp.lo == expected, '%r == %r' % (rp.lo, expected)

# Generated at 2022-06-12 13:06:48.705277
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    parser = RoughParser()

# Generated at 2022-06-12 13:06:58.065723
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Case(TestCase):
        def setUp(self):
            self.text = Text(state="normal", undo=False)

    # Insert a given text in the text widget and position the index
    # at the given position. Return a HyperParser instance.
    def setup_text_and_parser(text_data):
        text, pos = text_data
        c = Case()
        c.text.insert("1.0", text)
        c.text.mark_set("insert", pos)
        return HyperParser(c.text, pos)

    # Assert that the expression given in the second argument equals
    # the result of calling the HyperParser's get_expression method
    # with the arguments given in the first argument.