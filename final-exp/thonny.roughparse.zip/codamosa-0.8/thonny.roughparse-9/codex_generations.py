

# Generated at 2022-06-12 12:58:52.434675
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()
    rp.set_str("if True:\n    a=1\n    print('a')\n    a+=1\n")
    assert rp.str == "if True:\n    a=1\n    print('a')\n    a+=1\n"
    rp.set_str("\nprint('a')    \n")
    assert rp.str == "\nprint('a')    \n"
    rp.set_str(u"#!/usr/bin/env python\n# -*- coding: utf-8 -*-\n")
    assert rp.str == u"#!/usr/bin/env python\n# -*- coding: utf-8 -*-\n"


# Generated at 2022-06-12 12:59:01.471497
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    # Only one value to preserve
    mapping = StringTranslatePseudoMapping({ord('a'): ord('a')}, ord('x'))
    assert list(mapping.__iter__()) == [ord('a')]
    # Two values to preserve
    mapping = StringTranslatePseudoMapping(
        {ord('a'): ord('a'), ord('b'): ord('b')}, ord('x'))
    assert list(mapping.__iter__()) == [ord('a'), ord('b')]
    # No values to preserve
    mapping = StringTranslatePseudoMapping({}, ord('x'))
    assert list(mapping.__iter__()) == []
    # Tests for default functionality
    assert list(mapping.__iter__(0)) == [0]

# Generated at 2022-06-12 12:59:05.471397
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    for k in mapping:
        assert k in whitespace_chars


# Utility functions ----------------------------------------------------------
# The following functions are used to make the code more readable.


# Generated at 2022-06-12 12:59:11.509595
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # This is a string which is used by some of the tests
    s = """
    def foo(x,y,
            z=5,*a,
            **k):

        if x>=0:
            x=abs(x)
        return x+y+z
    """
    # This is a list of tuples. Each tuple holds a pair of strings:
    # The first string is the index of a character in 's', and the
    # second string is the expression which HyperParser should
    # return for that index.

# Generated at 2022-06-12 12:59:14.215053
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    R = RoughParser()
    R.set_str(textwrap.dedent('''\
        a, b, c = x
        d, e = y, z
        '''))
    assert R.get_num_lines_in_stmt() == 2


# Generated at 2022-06-12 12:59:23.277420
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    check_RoughParser_set_lo( (3,0), '''\
#print 2<3
#print 2+4
''', '''print 2<3
print 2+4
''' )
    check_RoughParser_set_lo( (3,0), '''\
1
2
3
''', '''1
2
3
''' )
    check_RoughParser_set_lo( (3,0), '''\
1
2
3
''', '''1
2
3
''' )
    check_RoughParser_set_lo( (3,0), '''\
1
2
3
''', '''1
2
3
''' )

# Generated at 2022-06-12 12:59:28.354507
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = ""
    index = "1.0"

    hp = HyperParser(text, index)

    assert hp.stopatindex == "1.end"
    assert hp.rawtext == ""
    assert hp.bracketing == []
    assert hp.isopener == []
    assert hp.indexinrawtext == 0
    assert hp.indexbracket == 0


# Generated at 2022-06-12 12:59:36.013764
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rp = RoughParser("""\
if boo:
    if bla:
        ala
    elif bla2:
        ala2
    else:
        ala3
    x = 12
""", indent_width=4)
    # assert rp.compute_bracket_indent() == 4
    rp = RoughParser("""\
if foo:
    if (
        bla and
        ala
    ):
        pass
""", indent_width=4)
    # assert rp.compute_bracket_indent() == 4
    rp = RoughParser("""\
if foo:
    if (
        bla and
        ala
        ):
        pass
""", indent_width=4)
    # assert rp.compute_bracket_indent() == 8
   

# Generated at 2022-06-12 12:59:45.973943
# Unit test for method set_str of class RoughParser

# Generated at 2022-06-12 12:59:51.249904
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    for charset in ('', 'abcdefghijklmnopqrstuvwxyz', '0123456789'):
        for default in (0, ord('x')):
            mapping = StringTranslatePseudoMapping({ord(c): ord(c) for c in charset}, default)
            assert sorted(charset) == sorted(mapping)



# Generated at 2022-06-12 13:00:39.304856
# Unit test for method set_index of class HyperParser

# Generated at 2022-06-12 13:00:46.237953
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    """
    test cases:
    - Given a string or a comment, is_in_code returns False
    - Otherwise, is_in_code returns True
    """

    hp = HyperParser(text="'foo' abc # xy", index="@2")
    assert not hp.is_in_code()

    hp = HyperParser(text="'foo' abc # xy", index="@4")
    assert hp.is_in_code()

    hp = HyperParser(text="'foo' abc # xy", index="@8")
    assert hp.is_in_code()

    hp = HyperParser(text="'foo' abc # xy", index="@10")
    assert not hp.is_in_code()


# Generated at 2022-06-12 13:00:51.945618
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    from idlelib.idle_test.mock_idle import Func
    text = get_example_text()
    hp = HyperParser(text, "1.0")
    # The word 'test' should be recognized as an identifier.
    hp.set_index("1.30")
    assert hp.get_expression() == "test"
    # The word 'test' should not be recognized as an identifier if
    # it is inside of a comment.
    hp.set_index("1.31")
    assert hp.get_expression() == ""
    # The string "Hello, World" should be recognized as an identifier.
    hp.set_index("1.45")
    assert hp.get_expression() == 'test("Hello, World")'
    # Move to the closing parenthesis; the string "Hello, World"
    # should

# Generated at 2022-06-12 13:01:01.162606
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    assert HyperParser(Tkinter.Text(None), "1.0").is_in_code() == True
    assert HyperParser(Tkinter.Text(None), "1.0").is_in_string() == False
    assert HyperParser(Tkinter.Text(None, "import Tkinter\n"), "2.0").is_in_code() == True
    assert HyperParser(Tkinter.Text(None, "import Tkinter\n"), "2.0").is_in_string() == False
    assert HyperParser(Tkinter.Text(None, 'import Tkinter\nprint("hello world")'),
                      "2.0").is_in_code() == True

# Generated at 2022-06-12 13:01:11.013798
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def t(source, expected):
        rp = RoughParser(source)
        assert rp.get_base_indent_string() == expected

# Generated at 2022-06-12 13:01:20.208192
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-12 13:01:24.510594
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=redefined-outer-name
    # pylint: disable=eval-used
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    import re
    import random
    import tempfile
    import shutil

    good = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"

# Generated at 2022-06-12 13:01:30.922679
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def testcase(test):
        # pylint: disable=redefined-builtin
        t = RoughParser(test, indent_width=4, tabwidth=8)
        type = t.get_continuation_type()
        if type != C_BRACKET:
            print("type is %r, expected %r" % (type, C_BRACKET))
        else:
            expected = test.index("[") + 1
            while test[expected] in " \t":
                expected = expected + 1
            indent = t.compute_bracket_indent()
            if indent != expected:
                print(
                    "expected indent=%d, but got %d" % (indent, expected)
                )  # pragma: no cover
    for test in TESTCASES1:
        testcase(test)

# Generated at 2022-06-12 13:01:40.078872
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    """Test method is_block_closer of class RoughParser"""

# Generated at 2022-06-12 13:01:48.170972
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import TestCase
    from unittest.mock import Mock
    from idlelib.pyshell import HyperParser

    class HPTestCase(TestCase):
        """Base test case for testing HyperParser.is_in_code."""

        def setUp(self):
            # Create a mock Text widget with an index method and a get method
            # that returns the string passed to the set method.
            self.text = Mock(name="text")
            self.text.get.return_value = self.text.set()
            self.text.index.side_effect = lambda name: name

            # Create a HyperParser using the mock text
            self.hp = HyperParser(self.text, index="1.0")

            # Override the default rawtext and isopener in the HyperParser
            self.hp.rawtext = self

# Generated at 2022-06-12 13:03:46.537767
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def get_brackets(source, pos):
        """Return a tuple of brackets corresponding to the index
        given in string pos. If the index is not in any bracket,
        return None.
        """
        hp = HyperParser(source, pos)
        if hp.is_in_code():
            return hp.get_surrounding_brackets()
        else:
            return None

    def test(source, pos):
        print("get_brackets(%r, %s) -> %s" % (source, pos, get_brackets(source, pos)))

    hp = HyperParser

    test(r"", "1.0")
    test(r"", "1.5")
    test(r"abc", "1.0")
    test(r"abc", "1.2")


# Generated at 2022-06-12 13:03:56.490281
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def test(code, iscode, atend=True):
        h = HyperParser(code, "end" if atend else "1.0")
        if h.is_in_code() != iscode:
            return "is_in_code gives %s for this code\n\"\"\"\n%s\n\"\"\"" % (h.is_in_code(), code)
    yield test, "", True
    yield test, " ", True
    yield test, "a", True
    yield test, "ab", True
    yield test, "#", False
    yield test, "#comment", False
    yield test, " 'string'", True
    yield test, " 'string", True
    yield test, " 'string", False, False
    yield test, ' """docstring"""', True
    yield test, ' """docstring"""',

# Generated at 2022-06-12 13:03:59.395110
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    parser = RoughParser()
    parser.set_str("""
if a:(
    if b:
        if c:
            x
        else: # comment
            y""")
    assert parser.compute_bracket_indent() == 4


# Generated at 2022-06-12 13:04:06.025666
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=too-many-locals
    def test(s, expected):
        p = RoughParser(s)
        assert p.compute_backslash_indent() == expected

    test(r"""
if a and \
b:
    pass
""", 4)

    test(r"""
if a or \
    b:
    pass
""", 8)

    test(r"""
if (a or \
    b):
    pass
""", 8)

    test(r"""
if [a or \
    b]:
    pass
""", 8)

    test(r"""
if {a or \
    b}:
    pass
""", 8)

    test(r"""
if a + \
    b + c:
    pass
""", 8)


# Generated at 2022-06-12 13:04:14.460375
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-12 13:04:23.336588
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    import pytest

    # pylint: disable=invalid-name

    r = RoughParser("x = \\", 0)
    assert r.compute_backslash_indent() == 1
    r = RoughParser("class x:\n    x = \\", 4)
    assert r.compute_backslash_indent() == 5
    r = RoughParser("assert \\", 0)
    assert r.compute_backslash_indent() == 7

# Generated at 2022-06-12 13:04:30.629049
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    text = """\
            ( # something
                if condition:
                    return True
                else:
                    return False
            )"""
    hp = HyperParser(text, "1.11")
    assert hp.get_surrounding_brackets() == ("1.0", "1.102")
    assert hp.get_surrounding_brackets(mustclose=True) is None
    assert hp.get_surrounding_brackets("i") is None
    assert hp.get_surrounding_brackets("ir") is None
    assert hp.get_surrounding_brackets("if") == ("1.8", "1.102")

    # For now, the following test is broken
    ## test still broken
    ##text = """\
    ##    def myfunc(arg1, arg2):


# Generated at 2022-06-12 13:04:39.093842
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():  # @NoSelf
    # a few borderline cases to test the find_good_parse_start method
    from _pytest.doctest import Example
    from pytest_ast_transformer import doctest_convert_examples_to_doctest
    from textwrap import dedent
    from lib2to3.fixer_util import BlankLine, Newline
    lines_with_dbg = [
        ('\n', BlankLine, 1),
        ('\n', BlankLine, 2),
        ('\n', BlankLine, 3),
        ('co = compile(code, file, "exec", dont_inherit=True)\n', Newline, 4)
    ]
    lines = [i[:-1] for i in lines_with_dbg]

# Generated at 2022-06-12 13:04:45.454476
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def t(src, expected):
        result = RoughParser(src).get_base_indent_string()
        assert result == expected, (
            "RoughParser(%r).get_base_indent_string() returned %r, expected %r"
            % (src, result, expected)
        )
    t("", "")
    t(" ", " ")
    t("\t", "\t")
    t("\t\t", "\t\t")
    t("x=4", "")
    t("  x=4", "  ")
    t("\tx=4", "\t")
    t("x=4\t", "")
    t("x=4\t\t", "")
    t("\tx=4\t", "\t")

# Generated at 2022-06-12 13:04:52.951316
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    text.insert("insert", "hello")
    hp = HyperParser(text, "insert")
    assert hp.indexinrawtext == 0
    assert hp.indexbracket == 0
    text.delete("insert")
    text.insert("insert", "hello(world)")
    hp = HyperParser(text, "insert")
    assert not hp.isopener[hp.indexbracket]
    assert hp.indexinrawtext == 7
    assert hp.indexbracket == 2
    assert hp.isopener[1]
    text.delete("insert")
    text.insert("insert", "hello(")
    hp = HyperParser(text, "insert")
    assert not hp.isopener[hp.indexbracket]
    assert hp.indexinrawtext == 7

# Generated at 2022-06-12 13:06:10.614138
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """Unit test for method set_index of class HyperParser"""

    import unittest
    import textwrap

    from idlelib.idle_test.mock_idle import Func

    from idlelib import hyperparser
    from idlelib.hyperparser import HyperParser

    # This string contains several bracketing levels, so that
    # bracketing level detection can be tested. Note that index
    # numbers in rawtext are 1-based.

# Generated at 2022-06-12 13:06:19.916402
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test_get_expression(text, index, expected):
        hp = HyperParser(text, index)
        text = hp.get_expression()
        if expected != text:
            raise ValueError("expected %r, got %r (index %r)" % (expected, text, index))

    def test_get_expression_on_bad_index(text, index):
        hp = HyperParser(text, index)
        try:
            hp.get_expression()
        except ValueError as e:
            return
        raise ValueError("expected ValueError for %r, got none" % (index,))

    def test_get_expression_in_string(text, index, expected):
        hp = HyperParser(text, index)
        if not hp.is_in_string():
            raise ValueError("exprected an expression in a string")

# Generated at 2022-06-12 13:06:28.866126
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rp = RoughParser("", 0, "    ")
    assert rp.compute_bracket_indent() == 0
    # test the simplest bracketed expression
    rp = RoughParser("[", 0, "    ")
    assert rp.compute_bracket_indent() == 4
    # test indentation within list
    rp = RoughParser("[\n   x\n   y +\n   z\n]", 0, "    ")
    assert rp.compute_bracket_indent() == 4
    # test a nested list (this is not legal Python code, because the
    # continuation line doesn't start with the correct number of spaces)
    rp = RoughParser("[\n   [x + y,\n   z\n  ]\n]", 0, "    ")
   

# Generated at 2022-06-12 13:06:36.188154
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-12 13:06:42.034140
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    __pychecker__ = "no-returnvalues no-argsused"

    def _test(text, index, expopen, expclose):
        try:
            hp = HyperParser(text, index)
            res = hp.get_surrounding_brackets(openers="([{", mustclose=False)
        except:
            print(text)
            print(index)
            raise
        if res is None:
            open, close = expopen, expclose
        else:
            open, close = res
        if open != expopen:
            print(text)
            print(index)
            print(open, close)
            raise ValueError("Open should be %s, got %s" % (expopen, open))
        if close != expclose:
            print(text)
            print(index)

# Generated at 2022-06-12 13:06:50.336970
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """Test method set_index of class HyperParser."""
    # TODO should add more tests.
    hp = HyperParser("  (b )", 5)
    hp.set_index(4)
    assert hp.indexbracket == 3
    assert hp.indexinrawtext == 5
    assert hp.bracketing == ((0, 0), (0, 1), (2, 2), (3, 3), (4, 3), (5, 4))
    assert hp.isopener == [False, True, True, True, False, False]
    assert hp.rawtext == "  (b )"
    assert hp.stopatindex == "2.end"
    assert hp.text == "  (b )"



# Generated at 2022-06-12 13:06:51.852583
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Text(None, "1.0", "end")

# Generated at 2022-06-12 13:07:00.586905
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-12 13:07:08.062567
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def check(text, index, expected):
        hyper = HyperParser(text, index)
        result = hyper.get_expression()
        if result != expected:
            raise AssertionError(
                "for index %r expected %r, but got %r" % (index, expected, result)
            )

    # Test a simple case:
    check(
        "xxx = 1\n" "xxx + 1\n",
        "2.0",
        "xxx",
    )
    # Test that we expand within variables:
    check(
        "xxx = 1\n" "xxx + 1\n",
        "2.2",
        "xxx",
    )
    # Test that we can go backwards from a dot:

# Generated at 2022-06-12 13:07:16.007235
# Unit test for constructor of class HyperParser
def test_HyperParser():
    class MockText:
        def __init__(self, str=None, index=None, indent_width=None, tabwidth=None):
            self.str = str
            self.index = index
            self.indent_width = indent_width
            self.tabwidth = tabwidth

        def get(self, a, b):
            return self.str[a:b]

    def index2line(index):
        return int(float(index))

    # Test get_expression
    def test(a, b, c, d, e, f):
        text = MockText(
            str=a + "\n" + b + "\n" + c + "\n" + d,
            index=e,
            indent_width=4,
            tabwidth=4,
        )
        hp = HyperParser(text, e)
