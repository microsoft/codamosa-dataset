

# Generated at 2022-06-12 12:59:11.537324
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    for s in 'hi there', '\tfoo':
        print("")
        print("-"*40)
        print("")
        print("Test input:")
        print("")
        print(s)
        print("")
        p = RoughParser("if 1:", 2)
        print("")
        print("Indent:")
        print("")
        print("\t"*4 + "|"*4 + "|"*p.compute_bracket_indent())
        print("")
        print("Output:")
        print("")
        print("\t"*4 + s)


# Generated at 2022-06-12 12:59:18.377303
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = TextMockup()
    hp = HyperParser(text, "1.0")
    assert hp.indexinrawtext == 0, "Failed to initialize index in raw text (1)"
    assert hp.indexbracket == 1, "Failed to initialize index bracket (1)"
    hp.set_index("1.0")
    assert hp.indexinrawtext == 0, "Failed to initialize index in raw text (2)"
    assert hp.indexbracket == 1, "Failed to initialize index bracket (2)"
    hp.set_index("1.1")
    assert hp.indexinrawtext == 1, "Failed to initialize index in raw text (3)"
    assert hp.indexbracket == 1, "Failed to initialize index bracket (3)"
    hp.set_index("1.7")
    assert hp.index

# Generated at 2022-06-12 12:59:28.309653
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    from test.support import findfile

    fname = findfile('badsyntax_3161.py')
    with open(fname, 'rb') as file:
        str = file.read().decode('ascii')

    parser = RoughParser(str)

    assert parser.find_good_parse_start() == 783

    # Test the start of the file
    parser.offset = 0
    assert parser.find_good_parse_start() == 0

    # Test the end of the file
    str = 'abcde\n'
    parser.offset = len(str) - 1
    parser.str = str
    assert parser.find_good_parse_start() == parser.offset

    # Test the '\n' at the end of the file
    str = 'abcde\n'

# Generated at 2022-06-12 12:59:35.978178
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-12 12:59:45.935520
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    txt = '''[
        1, 2, 3, 4,
        5, 6, 7, 8,
        9, 10, 11, 12
    ]'''
    rp = RoughParser(txt, indent_width=4)
    assert rp.compute_bracket_indent() == 8
    
    txt = '''[
        1, 2, 3, 4, 5, 6, 7, 8,
        9, 10, 11, 12
    ]'''
    rp = RoughParser(txt, indent_width=4)
    assert rp.compute_bracket_indent() == 4
    
    txt = '''[
        1, 2, 3, 4, 5, 6, 7, 8,
        9,
        10, 11, 12
    ]'''
    rp = Rough

# Generated at 2022-06-12 12:59:51.232210
# Unit test for constructor of class HyperParser
def test_HyperParser():
    """Test HyperParser.

    # FIXME: this needs to be improved; currently it's only testing a
    # very simple case.
    """
    import unittest

    class HyperParserTestCase(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            pass

        def test(self):
            # A simple test.
            h = HyperParser(EDITWIN, EDITWIN.index("insert"))
            self.assertEqual(h.get_expression(), "")
            EDITWIN.insert("insert", "abc")
            h = HyperParser(EDITWIN, EDITWIN.index("insert"))
            self.assertEqual(h.get_expression(), "abc")

    unittest.main(verbosity=2)

if __name__ == "__main__":
    test_HyperParser()

# Generated at 2022-06-12 12:59:52.303772
# Unit test for constructor of class HyperParser

# Generated at 2022-06-12 13:00:01.385387
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    class Mock:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    def test(text, index_str, expected):
        textbox = Mock(index=lambda s: s, get=lambda a, b: text[a:b])
        hp = HyperParser(textbox, textbox.index(index_str))
        result = hp.get_surrounding_brackets()
        if result != expected:
            raise ValueError(
                "For text %r and index %r got %r instead of %r"
                % (text, index_str, result, expected)
            )


# Generated at 2022-06-12 13:00:06.297088
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=unused-variable,invalid-name,too-many-locals,unused-argument
    _, width = sys.maxsize, sys.maxsize
    assert _compute_backslash_indent("a = (\n", '', -1, 4, width) == 1
    assert _compute_backslash_indent("a = (\n", '', -1, 4, width) == 1
    assert _compute_backslash_indent("a = ( \n", '', -1, 4, width) == 2
    assert _compute_backslash_indent("a = ( \n", '', -1, 4, width) == 2

# Generated at 2022-06-12 13:00:09.539040
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    rp = RoughParser("def foo(bar = somefunc(parameter = 42)): pass")
    assert rp.get_last_open_bracket_pos() == rp.stmt_start + 3


# Generated at 2022-06-12 13:00:45.763326
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import unittest

    class Test_HyperParser_is_in_code(unittest.TestCase):
        def test_not_in_code_when_string(self):
            parser = HyperParser("' a string '", "1.3")
            self.assertFalse(parser.is_in_code())

        def test_not_in_code_when_comment(self):
            parser = HyperParser("# a comment", "1.4")
            self.assertFalse(parser.is_in_code())

        def test_in_code_when_not_string_and_not_comment(self):
            parser = HyperParser("1 + 2", "1.1")
            self.assertTrue(parser.is_in_code())

    unittest.main()



# Generated at 2022-06-12 13:00:51.716637
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    assert RoughParser("").compute_bracket_indent() == 0
    assert RoughParser("{").compute_bracket_indent() == 4
    assert RoughParser("foo bar").compute_bracket_indent() == 0
    assert RoughParser("foo bar\n").compute_bracket_indent() == 0
    assert RoughParser("foo bar\n  [").compute_bracket_indent() == 6
    assert RoughParser("foo bar\n  baz = [1, 2, 3").compute_bracket_indent() == 6
    assert RoughParser(
        "foo bar\n  baz = [1, 2, 3,\n"
        "             4, 5, 6,\n"
        "             7, 8, 9,\n"
        "             0]"
    ).compute_

# Generated at 2022-06-12 13:01:00.985942
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    h = HyperParser(tkinter.Text(), "1.0")

    def test(source, expected_result):
        h.text.delete("0.0", "end")
        h.text.insert("insert", source)
        for index in ("1.0", "1.4", "1.8", "2.0", "2.1", "2.2"):
            h.set_index(index)
            if h.is_in_code() == expected_result:
                print("%s -> %s OK" % (source, index))
            else:
                print("%s -> %s WRONG" % (source, index))

    test(r"""a = "abc"
# a comment
b = [1, 2, 3]
if True: pass
    """, True)

# Generated at 2022-06-12 13:01:10.765054
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import unittest
    import idlelib.parsers.is_in_code

    class TestClass(unittest.TestCase):
        def setUp(self):
            self.text = idlelib.editor.EditorWindow(root)
            # self.text.insert(1.0, 'input1')
            self.text.insert(1.0, "import test")
            self.text.insert(END, "1234")
            self.hyper = self.text.hyperparser
            self.hyper.set_index(
                # self.text.index('1.end')
                self.text.index("1.end")
            )
            self.hyper.text = self.text

        def test_is_in_code(self):
            self.assertTrue(self.hyper.is_in_code())

    unitt

# Generated at 2022-06-12 13:01:19.942028
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    _test("[\n", 1)
    _test("[1,\n", 1)
    _test("[1]\n", 1)
    _test("[3,\n", 1)

    def _test(s, want, **kwargs):
        got = RoughParser(s, **kwargs).compute_bracket_indent()
        assert got == want, "%s != %s: %s" % (got, want, s)

    _test("[1,\n 4,\n", 1)
    _test("[1,\n   4,\n", 1)
    _test("[1,\n #foo\n", 1)
    _test("[1,\n #foo\n  4,\n", 1)

# Generated at 2022-06-12 13:01:27.792215
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    parser = RoughParser(tabsize=8)
    get_backslash_indent = parser.compute_backslash_indent
    p1 = "x = 1 \\"
    p2 = "y = 2"
    parser.set_str(p1 + "\n" + p2)
    gets = "getattr(x, 'y', None)"
    assert get_backslash_indent() == _expected_indent(gets, tabsize=8)
    p1 = "x = 1  # foo"
    p2 = "\\"
    p3 = "y = 2"
    parser.set_str(p1 + "\n" + p2 + "\n" + p3)
    gets = "getattr(x, 'y', None)"
    assert get_backslash_indent() == _expected

# Generated at 2022-06-12 13:01:36.571123
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # Check that set_index sets the index to the rightmost opening
    # bracket which is enclosed by the given index (or is the given
    # index).

    # Calling with index inside a string. HyperParser does support
    # this (for example, get_expression is called from ParenMatch and
    # it can sometimes be called from inside a string, if the string
    # ends at the end of the line), but nothing should change in this
    # case, and it's not very useful to test.

    text = Text(None, "")
    text.insert("1.0", "12'34'56")
    hp = HyperParser(text, "1.0")
    assert hp.isopener == [0, 0, 1, 0, 0, 1, 0]
    assert hp.indexbracket == 1

# Generated at 2022-06-12 13:01:41.840464
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    parser = RoughParser(
        "if 1:\\n    print(1)\n    x\\\n        .y\\\n        .z()"
    )
    assert parser.compute_backslash_indent() == 4
    assert parser.str == "if 1:\\n    print(1)\n    x\\\n        .y\\\n        .z()"



# Generated at 2022-06-12 13:01:49.294226
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = ""
    text += "def foo(bar,\n"
    text += "          baz):\n"
    text += "    print('foo')\n"
    text += "    print(bar, baz)\n"
    text += "'first char'[0]\n"
    text += '"second char"[1]\n'
    text += "print('''first element inside triple quoted string'''[0])\n"
    text += 'print("""second element inside triple quoted string"""["""\n'

# Generated at 2022-06-12 13:01:58.543553
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    py_src = """\
a = b + c + d(e+f)
"""
    expect = 10
    actual = RoughParser(py_src, 8).compute_backslash_indent()
    assert expect == actual

    actual = RoughParser(py_src, 4).compute_backslash_indent()
    assert expect == actual

    actual = RoughParser(py_src, 4, tabsize=4).compute_backslash_indent()
    assert expect == actual

    py_src = """\
a = b + c +\\
    d
"""
    expect = 4
    actual = RoughParser(py_src, 4).compute_backslash_indent()
    assert expect == actual
    

# Generated at 2022-06-12 13:03:09.978124
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    from sys import version_info

    pyver = version_info[0]

    def test(text, index, exp):
        hp = HyperParser(text, index)
        got = hp.get_expression()
        if exp != got:
            print(
                "wrong expression at %r in %r:\n"
                "got      %r\n"
                "expected %r" % (index, text, got, exp)
            )


# Generated at 2022-06-12 13:03:18.790705
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-12 13:03:27.824722
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = """\
    # at start:
    def f(a, b):
        return a - b # at end
    # at start
    (a*b)
    # in string
    f"{a}*{b}"
    # out of string
    f"{a}*{b}"
    # in wrong string
    f"{a}*{b}"
    # past wrong string
    """


# Generated at 2022-06-12 13:03:35.460285
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # Ignore errors, for testing only
    def hpe(text, index):
        try:
            hp = HyperParser(text, index)
            return hp.get_expression()
        except ValueError:
            return None

    #
    # Tests
    #
    # If an index is in a code, it should find the expression
    text = Text("x = a + b")
    assert hpe(text, "2.0") == ""
    assert hpe(text, "3.0") == "a"
    assert hpe(text, "4.0") == "a"
    assert hpe(text, "5.0") == ""
    assert hpe(text, "6.0") == "b"
    assert hpe(text, "7.0") == "b"

# Generated at 2022-06-12 13:03:42.160773
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-12 13:03:44.680025
# Unit test for constructor of class HyperParser
def test_HyperParser():
    """Tests HyperParser constructor and also set_index,
    is_in_string, is_in_code and get_surrounding_brackets
    methods"""

    from tkinter import Text

    text = Text()

# Generated at 2022-06-12 13:03:47.674213
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import tempfile, os

    # Test HyperParser's constructor
    t = tempfile.mktemp()
    f = open(t, "w")

# Generated at 2022-06-12 13:03:57.015485
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    p = RoughParser("x = 1\nif y:\n    pass\n")
    assert p.get_base_indent_string() == "    "
    p = RoughParser("if y:\n    x = 1\n")
    assert p.get_base_indent_string() == ""
    p = RoughParser("if y:\n    x = 1\n"
                    "    if z:\n        pass\n")
    assert p.get_base_indent_string() == "        "
    p = RoughParser("x = 1\nif y:\n    pass\n")
    p.is_block_closer()  # don't say p.study() in the docs
    assert p.get_base_indent_string() == "    "

# Generated at 2022-06-12 13:04:04.454053
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    """Unit test for method is_in_string of class HyperParser"""
    H = HyperParser

    assert not H("((a, (b, c)))", "4.0").is_in_string()
    assert not H("((a, 'b', c))", "4.0").is_in_string()
    assert H("((a, 'b', c))", "5.0").is_in_string()
    assert not H("((a, 'b', c))", "6.0").is_in_string()
    assert not H('''((a, ''' "'" '''b', c))''', "8.0").is_in_string()
    assert H('''((a, ''' "'" '''b', c))''', "9.0").is_in_string()

# Generated at 2022-06-12 13:04:08.002270
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    _ = """
#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    parser = RoughParser(_)
    print(parser.get_base_indent_string())

if __name__ == "__main__":
    test_RoughParser_get_base_indent_string()

# Generated at 2022-06-12 13:06:15.205567
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    for string in ["#", '"', "'"]:
        for i in range(len(string) + 1):
            assert not HyperParser(tkinter.Text(), 1).is_in_code()


if __name__ == "__main__":
    test_HyperParser_is_in_code()

# Generated at 2022-06-12 13:06:24.088998
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():

    def test_base_indent_string(source_text, expected):
        rough_parser = RoughParser(source_text, 0)
        assert rough_parser.get_base_indent_string() == expected

    test_base_indent_string("", "")
    test_base_indent_string("  ", "  ")
    test_base_indent_string("  # comment", "  ")
    test_base_indent_string("  if a:", "  ")
    test_base_indent_string("  \n if a:", "  ")
    test_base_indent_string("  \n  if a:", "  ")
    test_base_indent_string("  \n # comment\n  if a:", "  ")
    test_base_ind

# Generated at 2022-06-12 13:06:32.339009
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import pytest
    from idlelib import hyperparser


# Generated at 2022-06-12 13:06:33.414721
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-12 13:06:40.041648
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = "'''\\\n" + "'"
    hp = HyperParser(text, "1.end")
    assert hp.is_in_string()
    hp.set_index("2.end")
    assert not hp.is_in_string()
    text = 'r"\n'
    hp = HyperParser(text, "1.end")
    assert hp.is_in_string()
    text = 'ur"\n'
    hp = HyperParser(text, "1.end")
    assert hp.is_in_string()
    text = 'R"\n'
    hp = HyperParser(text, "1.end")
    assert hp.is_in_string()
    text = 'U"\n'
    hp = HyperParser(text, "1.end")
    assert hp.is_in

# Generated at 2022-06-12 13:06:49.555014
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        """Tests of HyperParser constructor."""

        def setUp(self):
            self.tk = Tkinter.Tk()
            self.text = EditorWindow.EditorWindow(self.tk)
            self.text.set_font(("courier", 9, "normal"))
            self.text.pack()

        def _set(self, text, index=None):
            if index is not None:
                self.text.insert("insert", text)
            else:
                index = self.text.index("insert")
                self.text.insert("insert", text.lstrip())
                index = self.text.index("insert - %ds linestart" % len(text) + index)
            return index


# Generated at 2022-06-12 13:06:58.887053
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    "Unit test for HyperParser.is_in_string()"

    assert not HyperParser("", "1.0").is_in_string()
    assert not HyperParser("", "insert").is_in_string()

    assert HyperParser("'''", "1.0").is_in_string()
    assert not HyperParser("'''", "1.1").is_in_string()
    assert not HyperParser("'''", "1.2").is_in_string()

    assert not HyperParser("'''", "2.0").is_in_string()
    assert HyperParser("'''", "2.1").is_in_string()
    assert HyperParser("'''", "2.2").is_in_string()

    assert not HyperParser("'''", "3.0").is_in_string()

# Generated at 2022-06-12 13:07:05.985858
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    failures = 0
    def test(sample, index, expected):
        if expected:
            expected = "True"
        else:
            expected = "False"
        try:
            hp = HyperParser(sample, index)
            ans = hp.is_in_string()
        except Exception as err:
            ans = "Exception:%s:%s" % (err.__class__.__name__, err)
        if ans != expected:
            print("%s: %s != %s" % (sample.replace("\n", "\\n"), ans, expected))
            nonlocal failures
            failures += 1

    test('"""', "1.0", False)
    test('"', "1.0", False)
    test('"\n', "1.1", True)

# Generated at 2022-06-12 13:07:09.326275
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # TODO: Add more tests.
    def test_ok(source, startline, expected_startline):
        parser = RoughParser(source, startline)
        parser.find_good_parse_start()
        assert parser.goodlines[0] == expected_startline

# Generated at 2022-06-12 13:07:17.268464
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Text(None)
    text.insert("insert", '"a string without an end" """another string without an end')
    text.insert("insert", "some code")
    text.insert("insert", '"""')
    text.insert("insert", '"some code"')
    text.insert("insert", '"a string with an end"')
    text.insert("insert", 'b"a bytes literal"')

    hp = HyperParser(text, text.index("current"))
    assert hp.is_in_string()
    text.mark_set("insert", "current + 8 char")
    assert not hp.is_in_string()
    for i in range(4):
        text.mark_set("insert", "current - 2 lineend")
        assert hp.is_in_string()