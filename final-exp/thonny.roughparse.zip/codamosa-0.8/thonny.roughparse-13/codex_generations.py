

# Generated at 2022-06-12 12:58:20.095259
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    assert RoughParser("").get_last_open_bracket_pos() is None
    assert RoughParser("(").get_last_open_bracket_pos() is None
    assert RoughParser("[").get_last_open_bracket_pos() is None
    assert RoughParser("{").get_last_open_bracket_pos() is None
    assert RoughParser("()").get_last_open_bracket_pos() is None
    assert RoughParser("[]").get_last_open_bracket_pos() is None
    assert RoughParser("{}").get_last_open_bracket_pos() is None
    assert RoughParser("a()").get_last_open_bracket_pos() is None
    assert RoughParser("b[]").get_last_open_bracket_pos() is None

# Generated at 2022-06-12 12:58:24.995561
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser("if a:print b")
    rp.set_lo(8)
    assert rp.stmt_start == 0 and rp.stmt_end == 8 == rp.stmt_bracketing[0][0]
    rp.set_lo(7)
    assert rp.stmt_start == 0 and rp.stmt_end == 7 == rp.stmt_bracketing[0][0]
    rp.set_lo(6)
    assert rp.stmt_start == 0 and rp.stmt_end == 6 == rp.stmt_bracketing[0][0]
    rp.set_lo(5)
    assert rp.stmt_start == 0 and rp.stmt_end == 5 == rp.stmt_bracket

# Generated at 2022-06-12 12:58:33.513509
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def tt(s, o="([{", c=False, exp=None):
        text = Text(s, "1.0", {"tabs": Tabs(4), "indentwidth": 4})
        return HyperParser(text, text.index("insert")).get_surrounding_brackets(o, c)

    assert tt('"a(b"') == (2, 8)
    assert tt('"a(b"', mustclose=True) is None
    assert tt('"a(b"', "([", True) == (2, 8)
    assert tt('"a(b"', "()[]", True) is None
    assert tt('"a(b"', "()", True) == (2, 8)


# Generated at 2022-06-12 12:58:36.363174
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rp = RoughParser("    return ([x for x in (1, 2)])", 4, 8)
    assert rp.compute_bracket_indent() == 4


# Generated at 2022-06-12 12:58:46.218893
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-outer-name
    from lib2to3 import pytree, fixer_util
    from lib2to3.pgen2 import token

    def compute_bracket_indent(source, width=4):
        # pylint: disable=undefined-variable
        tree = pytree.Base.parse(source, "exec")
        wrapper = pytree.Node(syms.file_input, [tree])
        t = wrapper.children[0]
        assert t.type == token.INDENT
        assert t.children[0].type == token.NEWLINE
        t = t.children[1]
        assert t.type == syms.simple_stmt
        t = t.children[0]
        assert t.type == syms.small_stmt

# Generated at 2022-06-12 12:58:48.373873
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    rp = RoughParser("\\\n")
    assert rp.get_continuation_type() == rp.C_BACKSLASH

# Generated at 2022-06-12 12:58:54.951700
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = idlelib.textView.TextView(None) #needed to use index
    text.insert('1.0', test_data)
    hp = HyperParser(text, '1.0')
    # It should be that the index of hp.rawtext is the same as
    # text.index(hp.stopatindex).
    assert  hp.rawtext == test_data[: hp.stopatindex - '1.0']
    # This should also be true
    assert hp.stopatindex  == '1.4'
    # Brackets are counted at indices where they occur
    assert hp.bracketing == [(0, 0), (4, 0), (4, 1), (9, 2)]
    # Openers are counted at indices where the openers occur
    assert hp.isopener == [False, True, True, True]

# Generated at 2022-06-12 12:58:57.584277
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    import doctest
    doctest.testmod()
# Calculates precendence of the given token from the high precedence
# operators down to the low precedence operators.

# Generated at 2022-06-12 12:59:05.249159
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """Check the correctness of the set_index method of the HyperParser class

    """
    hyper = HyperParser(Tkinter.Text, "1.0")
    str1 = (
        '"""This is a string\nwith two lines"""\n'
        "if 1:\n"
        "    print('Hello')\n"
        "    print('World')\n"
    )
    hyper.rawtext = str1
    hyper.stopatindex = "4.2"

# Generated at 2022-06-12 12:59:10.764015
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    rp = RoughParser("", 0)
    rp.find_good_parse_start()
    assert rp.good_parse_start == 0
    rp = RoughParser("  \n  ", 0)
    rp.find_good_parse_start()
    assert rp.good_parse_start == 4
    rp = RoughParser("  #", 0)
    rp.find_good_parse_start()
    assert rp.good_parse_start == 0
    rp = RoughParser(" #\n #\n #\n", 0)
    rp.find_good_parse_start()
    assert rp.good_parse_start == 4


# Generated at 2022-06-12 12:59:41.844310
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    assert HyperParser("", "1.0").is_in_code()
    assert HyperParser("a", "1.0").is_in_code()
    assert not HyperParser("a", "1.0").is_in_code()


# Generated at 2022-06-12 12:59:48.010782
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from idlelib import parenmatch

    text = parenmatch.ParenMatch(None, None)
    text.insert("1.0", "a=1")
    hp = HyperParser(text, "1.2")
    eq = "assert "
    eq += repr(hp.rawtext)
    eq += "=='a=1'"
    assert hp.rawtext == "a=1"

    # hp.set_index("i") is to be called for each i in range(3)
    for i in range(3):
        eq = "hp.set_index('1.%d')" % i
        exec(eq, globals(), locals())
        eq = "assert "
        eq += repr(hp.rawtext)
        eq += "=='a=1'"
        assert hp.rawtext == "a=1"

# Generated at 2022-06-12 12:59:58.189658
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-12 13:00:05.609691
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # Create a text widget and start a HyperParser.
    text = Text()
    text.insert("insert", "foo.bar(a,b)['hello']")
    hp = HyperParser(text, "insert")

    def test_inside_code(pos, exp):
        text.mark_set("insert", pos)
        hp.set_index("insert")
        if hp.is_in_code():
            found_exp = hp.get_expression()
            if found_exp != exp:
                raise AssertionError(
                    "get_expression() returned " + repr(found_exp) + " instead of " + repr(exp)
                )
        else:
            raise AssertionError("get_expression() was called inside a string")


# Generated at 2022-06-12 13:00:08.297964
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    h = HyperParser(Tkinter.Text(), "1.0")
    h.set_index("1.0")
    h.set_index("end")
    h.set_index("sel.first")



# Generated at 2022-06-12 13:00:18.699460
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=redefined-builtin,unused-variable
    # pylint: disable=too-many-branches,too-many-statements
    # "0" is the index of the first char in str
    # pylint: disable=line-too-long

    s = "x = 1+1"
    assert RoughParser(s).find_good_parse_start() == 0
    s = "x = \\\n1+1"
    assert RoughParser(s).find_good_parse_start() == 0
    s = "x = 1+\\\n1"
    assert RoughParser(s).find_good_parse_start() == 0
    s = "x = 1+1#\nprint(x)"
    assert RoughParser(s).find_good_parse_start() == 0
   

# Generated at 2022-06-12 13:00:23.776281
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    lines = dedent("""\
        #!/usr/bin/env python
        x = '''
        Testing multiline strings:
        (
        '''

        """).split("\n")
    for i in range(2, len(lines)):
        tmp = lines[0:i]
        bad_lines = rp_bad(tmp)
        good_start = rp.find_good_parse_start(tmp, bad_lines)
        assert good_start == rp_good(tmp)



# Generated at 2022-06-12 13:00:32.647920
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest
    from test.support import run_unittest

    class TestCase(unittest.TestCase):
        def test_simple(self):
            text = "def foo():\n    print(1)\n"
            for i in range(4):
                self.assertIsNone(HyperParser(text, "1.%d" % i).get_surrounding_brackets())
            self.assertEqual(HyperParser(text, "1.4").get_surrounding_brackets(), ("1.0", "1.8"))
            self.assertEqual(HyperParser(text, "1.5").get_surrounding_brackets(), ("1.0", "1.8"))

# Generated at 2022-06-12 13:00:40.709881
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-12 13:00:47.582529
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    def test(text, expected, index):
        index = str(index) + "c"
        p = HyperParser(text, index)
        indexinrawtext = len(p.rawtext) - len(text.get(index, p.stopatindex))
        bracketing = p.bracketing
        rawtext = p.rawtext

        if expected is None or expected[0] is None:
            r = None
        else:
            r = (
                len(rawtext) - len(text.get(expected[0] + "c", p.stopatindex)),
                len(rawtext) - len(text.get(expected[1] + "c", p.stopatindex))
            )


# Generated at 2022-06-12 13:01:47.485962
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser(tabsize=4)
    rp.set_str("""if True:
    print('Foo')
""")
    assert rp.get_base_indent_string() == '    '
    rp.set_str("""if True:
    print('Foo')
""")
    assert rp.get_base_indent_string() == '    '
    rp.set_str("""if True:
        print('Foo')
""")
    assert rp.get_base_indent_string() == '        '
    rp.set_str("""if True:
    print('Foo') # comment
""")
    assert rp.get_base_indent_string() == '    '

# Generated at 2022-06-12 13:01:51.574984
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    print("testing test_RoughParser_get_continuation_type...")
    txt = """\
if a:
    if b:
        pass
"""
    prs = RoughParser(txt)

# Generated at 2022-06-12 13:01:59.518833
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin
    #
    # Test that compute_bracket_indent indents the first item to at
    # least the same level as the open bracket.
    #
    def test(str, expect):
        parser = RoughParser(str, " ", 1)
        indent = parser.compute_bracket_indent()
        assert expect <= indent, (
            "failed with str = %r" % str + "\n"
            "expected %s <= %s, got %s" % (expect, indent, indent - expect)
        )

    test("[\n", 0)
    test("[# foo\n", 0)
    test("[# foo\n# bar\n", 0)
    test("[a\n", 1)

# Generated at 2022-06-12 13:02:06.155096
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin

    rp = RoughParser("xxx\nxxx\n[\nx", 0, 4)
    assert rp.compute_bracket_indent() == 2

    rp = RoughParser("xxx\nxxx\n[\n  x", 0, 4)
    assert rp.compute_bracket_indent() == 4

    rp = RoughParser("xxx\nxxx\n[\n  x", 0, 4)
    assert rp.compute_bracket_indent() == 4

    rp = RoughParser("xxx\nxxx\n[\n    x", 0, 4)
    assert rp.compute_bracket_indent() == 6


# Generated at 2022-06-12 13:02:13.208903
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class Test(unittest.TestCase):
        def test_get_expression(self):
            text = "a=1\na.b=2\na.b+=3\na.b += 4\na.b.c+= 5\na.b.c += 6\n"
            text += "a.b.c(d)+= 7\na.b.c(d) += 8\n"
            text += "a.b.c(d,e)+= 9\na.b.c(d,e) += 10\n"

            text += "a.b.c(d) + g=11\na.b.c(d) + g=12\n"

# Generated at 2022-06-12 13:02:19.917170
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import doctest
    hyperparser_class = HyperParser

    def index2line(index):
        return int(float(index))

    def test_code(text, where, is_in_code=True, is_in_string=False, get_expression=""):
        """Test whether HyperParser works well at the given place.

        If is_in_code is given, it must be True if the index is
        inside code or False if it is not.

        If is_in_string is given, it must be True if the index is
        inside a string or False if it is not.

        If get_expression is given, it defines a string containing
        the expected expression at that place, which includes the
        character at the place.

        If get_expression is not given, it is assumed to be ''.
        """
        text = text.splitlines

# Generated at 2022-06-12 13:02:27.853337
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    r = RoughParser("")
    assert r.is_block_closer() == False
    r = RoughParser("]")
    assert r.is_block_closer() == True
    r = RoughParser("] \n]")
    assert r.is_block_closer() == True
    r = RoughParser("] \n]\n]")
    assert r.is_block_closer() == True
    r = RoughParser("] \n]\n]\n]")
    assert r.is_block_closer() == True
    r = RoughParser("] \n]\n]\n] \n]")
    assert r.is_block_closer() == True
    r = RoughParser("] \n]\n]\n] \n]\n]")
    assert r.is_block_

# Generated at 2022-06-12 13:02:33.562031
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    for s, index, result in (
        ('(a=1)', '2.0', 'a=1'),
        ('((a=1)', '3.0', 'a=1'),
        ('(a=1', '4.0', 'a=1'),
        ('(a=1))', '4.0', 'a=1'),
        ('(a = 1))', '5.0', 'a = 1'),
    ):
        text = EditorWindow(None)
        text.insert('1.0', s)
        h = HyperParser(text, index)
        assert h.get_expression() == result



# Generated at 2022-06-12 13:02:34.334243
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    pass


# Generated at 2022-06-12 13:02:40.323714
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    def test_is_block_closer(text, expected):
        p = RoughParser(text)
        assert p.is_block_closer() == expected

    test_is_block_closer("foo(a,\n" "    bar=b,\n" "    baz=1)\\\n" "   .say()", False)
    test_is_block_closer("foo(a,\n" "    bar=b,\n" "    baz=1)\n", True)
    test_is_block_closer("foo(a,\n" "    bar=b,\n" "    baz=1)?\n", True)