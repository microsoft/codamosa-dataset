

# Generated at 2022-06-12 12:58:24.681133
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def test_index(self):
            t = hyperparser.HyperParser("", "1.0")
            self.assertEqual(t.index, 1)
            t = hyperparser.HyperParser("", "insert")
            self.assertEqual(t.index, 0)
            t = hyperparser.HyperParser("", "end")
            self.assertEqual(t.index, -1)
            t = hyperparser.HyperParser("", "end-1c")
            self.assertEqual(t.index, -2)

        def test_get_surrounding_brackets(self):
            t = hyperparser.HyperParser("", "1.0")

# Generated at 2022-06-12 12:58:30.045413
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rp = RoughParser("\n", "\n")
    rp.str = "foo"
    rp.indent_width = 4
    rp.tabwidth = 8
    assert rp.compute_bracket_indent() == 0
    rp.continuation = C_BRACKET
    rp.lastopenbracketpos = 0
    assert rp.compute_bracket_indent() == 4
    rp.str = "foo [\n    bar\n]"
    assert rp.compute_bracket_indent() == 4
    rp.str = "foo [\nbar\n]"
    assert rp.compute_bracket_indent() == 8
    rp.str = "foo [\n    bar ,\n    baz\n]"
    assert rp.comp

# Generated at 2022-06-12 12:58:33.963603
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    source = """\
    if True:
        if True:
            var = """ + """\\
    [""" + """\\
        1,
        2,
        3]""" + """\\
    """

    rp = RoughParser(source)
    rp._study2()
    bi = rp.compute_bracket_indent()  # @UndefinedVariable
    assert bi == 12



# Generated at 2022-06-12 12:58:43.545120
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-12 12:58:50.309899
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # Currently, we consider that it doesn't raise exceptions.
    # We want to verify that it won't, even after changing the
    # PyParse code.
    t = Tk()
    t.destroy()
    text = Text()
    text.insert("insert", "   x = 4\n   x")
    h = HyperParser(text, "2.2")
    h.get_expression()  # should not fail

    del h, text
    gc.collect()
    gc.collect()
    gc.collect()



# Generated at 2022-06-12 12:58:56.063581
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    "Unit test for method set_index of class HyperParser"

    import unittest
    import idlelib.hyperparser

    class HyperParserSetIndexTest(unittest.TestCase):

        def test_set_index(self):
            text = """
                    # line 2
                    # line 3
                    # line 4"""
            rawtext = text[1:]
            stopatindex = "%d.end" % (text.count("\n") + 1)
            hp = idlelib.hyperparser.HyperParser(text, "2.0")
            self.assertEqual(hp.rawtext, rawtext)
            self.assertEqual(hp.stopatindex, stopatindex)

            hp.set_index("3.0")

# Generated at 2022-06-12 12:59:04.254226
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from tkinter import Text

    root = Tk()
    text = Text(root, width=40, height=4)
    text.pack()
    text.insert(END, "    # Some comment.\n    foo([bar])\n")

    hp = HyperParser(text, "2.14")
    text.mark_set("test", "2.14")
    assert hp.get_surrounding_brackets() == (
        "1.4",
        "insert",
    ), "Bug in get_surrounding_brackets (1)."

    # This must return None, because the '(' is not closed.
    assert hp.get_surrounding_brackets(mustclose=True) == None, "Bug in get_surrounding_brackets (2)."

    # Now close the '('
    text.insert

# Generated at 2022-06-12 12:59:11.166992
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(test_data):
        for i in range(len(test_data)):
            data = test_data[i]
            if len(data) == 3:
                text, index, expected = data
            else:
                text, index, expected, startatindex = data
            hp = HyperParser(text, index)
            if startatindex:
                hp.set_index(startatindex)
            result = hp.get_expression()
            if result != expected:
                sys.stderr.write(
                    "HyperParser.get_expression %s (%s[%s]: %s) has failed\n"
                    % (i, text, index, expected)
                )
                sys.stderr.write("  Got: %s\n" % result)


# Generated at 2022-06-12 12:59:12.926278
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    parser = RoughParser("a = (1 +\n    2 +\n    3)")
    assert parser.get_num_lines_in_stmt() == 3

# Generated at 2022-06-12 12:59:19.572497
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    from xonsh.codecache import _replace_leading_whitespace

    def repl(s):
        raw = '\n'.join(s.splitlines())
        indented = '\n'.join(s.splitlines(True))
        parser = RoughParser(raw, _replace_leading_whitespace)
        s_ = parser.get_base_indent_string()
        m = re.match(r'\s*', indented)
        assert s_ == m.group(0)

    s = '''\
    foo
    # bar
    '''
    repl(s)

    s = '''\
    foo
    bar
    # baz
    '''
    repl(s)


# Generated at 2022-06-12 13:00:51.343226
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    h = HyperParser(None, "2.0")
    if h.isopener[0]:
        raise ValueError("The isopener list should be empty.")
    h.set_index("3.0")
    if h.isopener[0]:
        raise ValueError("The isopener list should be empty.")
    if h.isopener[1]:
        raise ValueError("The isopener list should be empty.")
    h.set_index("4.0")
    if h.isopener[0]:
        raise ValueError("The isopener list should be empty.")
    if h.isopener[1]:
        raise ValueError("The isopener list should be empty.")
    if h.isopener[2]:
        raise ValueError("The isopener list should be empty.")
    h.set_

# Generated at 2022-06-12 13:01:00.361699
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin

    def test(s, w):
        p = RoughParser(s)
        res = p.compute_bracket_indent()
        assert res == w, (
            f"For {s} compute_bracket_indent returned {res}, should be {w}"
        )

    # Test continuation lines
    test("def foo(bar): baz\n    \n    for a in b:\n", 6)
    test("def foo(bar): baz\n    # a comment\n    for a in b:\n", 6)
    test("def foo(bar): baz\n    \t\n    for a in b:\n", 7)
    test("def foo(bar): baz\n    # a comment\n    for a in b:\n", 6)

# Generated at 2022-06-12 13:01:09.805139
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def _testit(s):
        r = RoughParser(s)
        r._study2()
        return r.get_base_indent_string()

    # Empty string
    assert _testit("") == ""
    # Empty string with blank line
    assert _testit("\n\n") == "  "
    # Indented line
    assert _testit("  abc") == "  "
    # Line ending with \
    assert _testit("  abc\\") == "  "
    # Line ending with \ and whitespace
    assert _testit("  abc \\\n") == "    "
    # Line ending with \ and whitespace and extra line
    assert _testit("  abc \\\n\n") == "    "
    # Line ending with \ and whitespace and extra line, with indent


# Generated at 2022-06-12 13:01:19.077155
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    """ Test RoughParser.is_block_closer on some simple cases """
    p = RoughParser("")
    assert not p.is_block_closer()
    p = RoughParser("""
    # This is a comment
    """)
    assert not p.is_block_closer()
    p = RoughParser("""
    "This is a string"
    """)
    assert not p.is_block_closer()
    p = RoughParser("""
    "This is a string"
    x = 1
    """)
    assert not p.is_block_closer()
    p = RoughParser("""
    x = 1
    """)
    assert not p.is_block_closer()

# Generated at 2022-06-12 13:01:20.288856
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-12 13:01:28.032710
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    rp = RoughParser("if True:\n  pass\n")
    assert rp.get_last_open_bracket_pos() == 3
    rp = RoughParser("if True:\n  if False:\n    pass\n")
    assert rp.get_last_open_bracket_pos() == 3
    rp = RoughParser("if True:\n  if False:\n    pass\n  pass\n")
    assert rp.get_last_open_bracket_pos() == 9
    rp = RoughParser("if True:\n  pass\npass\n")
    assert rp.get_last_open_bracket_pos() is None
    rp = RoughParser("if True:\n  pass\nif False:\n  pass\n")
    assert rp.get_last_open_bracket

# Generated at 2022-06-12 13:01:36.790539
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # pylint: disable=unused-argument
    def make_test(source, result, opts=None):
        # pylint: disable=protected-access
        parser = RoughParser(source)
        parser._study_level = 0
        if opts:
            for name, value in opts.items():
                setattr(parser, "indent_width", opts.pop("indent_width", 4))
                setattr(parser, "tabwidth", opts.pop("tabwidth", 8))
                if opts:
                    raise ValueError("Bad option: %s", ", ".join(opts.keys()))
        parser.set_lo();
        assert parser.lo == result
        return True


# Generated at 2022-06-12 13:01:45.655054
# Unit test for method set_index of class HyperParser

# Generated at 2022-06-12 13:01:51.680470
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    """Unit test for method get_base_indent_string of RoughParser class."""
    texts = [
        '',
        ' ',
        '\t',
        '\n',
        'x',
        ' x',
        '\tx',
        '\nx',
        'def foo():',
        ' def foo():',
        '\tdef foo():',
        '\ndef foo():',
        'one line',
        ' one line',
        '\tone line',
        '\none line',
        'one line\ntwo lines\n',
        ' one line\n two lines\n',
        '\tone line\n\ttwo lines\n',
        '\none line\n\ttwo lines\n',
    ]

# Generated at 2022-06-12 13:01:57.619473
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-12 13:05:39.766453
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    class TextStub:
        def __init__(self, returned_indices):
            self.returned_indices = returned_indices

        def __getitem__(self, key):
            return self.returned_indices[key]

        def __setitem__(self, key, val):
            self.returned_indices[key] = val

        def __delitem__(self, key):
            del self.returned_indices[key]

        def __len__(self):
            return len(self.returned_indices)

        def __iter__(self):
            return iter(self.returned_indices)

        def keys(self):
            return self.returned_indices.keys()


# Generated at 2022-06-12 13:05:48.242073
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def test_is_in_code(text, index, expected):
        result = HyperParser(text, index).is_in_code()
        if result != expected:
            print("\nfor text %r, index %r, expected %r, got %r" % (text, index, expected, result))

    def test_is_in_code_indices(text, expected):
        test_is_in_code(text, "1.0", expected)
        for pos in range(1, len(text), 6):
            test_is_in_code(text, "%d.0" % pos, expected)

    def test_is_in_code_indices_0():
        test_is_in_code_indices("", True)

# Generated at 2022-06-12 13:05:57.073165
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def test(index, text, *brackets):
        print(index, repr(text), brackets)
        p = HyperParser(t, '1.0')
        p.set_index(index)
        assert (
            p.get_surrounding_brackets() == brackets
        ), "Failed to find the right brackets around %s." % index

    t = EditorWindow().text
    t.delete('1.0', "end")  # delete all

    t.insert("1.0", """\
# test0
foo()
bar()
        """)
    test("1.0", "# test0\nfoo()\nbar()")
    test("1.4", "# test0\nfoo()\nbar()")
    test("1.6", "# test0\nfoo()\nbar()")

# Generated at 2022-06-12 13:06:04.168684
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    class FakeText:
        def __init__(self, get_result):
            self.get_result = get_result
            self.call_history = []

        def get(self, i1, i2):
            self.call_history.append(("get", i1, i2))
            return self.get_result

        def index(self, i):
            self.call_history.append(("index", i))
            return "%s-result" % i

    class FakeParser:
        def __init__(self, bracketing, str_result):
            self.bracketing = bracketing
            self.str = str_result
            self.call_history = []

        def get_last_stmt_bracketing(self):
            self.call_history.append("get_last_stmt_bracketing")

# Generated at 2022-06-12 13:06:13.449140
# Unit test for constructor of class HyperParser
def test_HyperParser():
    class text_mock:
        def __init__(self, str, startindex):
            self.str = str
            self.startindex = startindex

        def get(self, startindex, endindex):
            return self.str[startindex:endindex]

    startindex = int(hyper_parser.startindex)
    code = "a = [\n" '  b("a.b[c.d(1, #comment\n' '  e#comment\n' '  , f)])\n' "]"
    text = text_mock(code, startindex)
    bracketing = [(18, 0), (18, 1), (19, 1), (20, 1), (21, 1), (14, 2), (14, 1), (16, 1), (17, 1), (17, 2)]
    rawtext

# Generated at 2022-06-12 13:06:22.488064
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    h = HyperParser("if 1:\n    pass\n", "insert")
    h.set_index("1.0")
    assert h.is_in_code()

    h.set_index("1.4")
    assert h.is_in_code()

    h.set_index("1.8")
    assert not h.is_in_code()

    h.set_index("end")
    assert not h.is_in_code()

    h = HyperParser("if 1:\n    pass\n", "insert")
    h.set_index("1.4")
    assert h.is_in_code()

    h.set_index("2.4")
    assert h.is_in_code()

    h.set_index("3.0")
    assert not h.is_in_code()

# Generated at 2022-06-12 13:06:30.926190
# Unit test for constructor of class HyperParser
def test_HyperParser():
    class Mock(object):
        def __init__(self, w):
            self.indent_width = w
            self.tabwidth = 8
        def index(self, s):
            return s
        def get(self, start, stop):
            return self.buf[start:stop]


# Generated at 2022-06-12 13:06:37.988551
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    class Test:
        def __init__(self, str, index, result):
            self.str = repr(str)
            self.index = repr(index)
            self.result = repr(result)


# Generated at 2022-06-12 13:06:48.361133
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text(None)
    parser = HyperParser(text, "1.0")

    text.insert("1.0", "import sys\nif sys.argv == []:")
    parser.set_index("2.0")
    assert parser.get_surrounding_brackets() == ("1.9", "1.16")

    text.insert("2.4", "f()")
    parser.set_index("2.4")
    assert parser.get_surrounding_brackets() == ("1.9", "1.16")

    text.insert("2.9", ":")
    text.insert("2.4", "(")
    parser.set_index("2.4")
    assert parser.get_surrounding_brackets() == ("1.9", "2.10")


# Generated at 2022-06-12 13:06:49.238179
# Unit test for method compute_backslash_indent of class RoughParser