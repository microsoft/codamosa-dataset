

# Generated at 2022-06-12 12:58:53.145903
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=invalid-name
    parser = RoughParser("a = 2\nb = 2\n", 2, 8)
    assert parser.compute_backslash_indent() == 2
    parser = RoughParser("    a = 2\nb = 2\n", 4, 8)
    assert parser.compute_backslash_indent() == 6
    parser = RoughParser("a=2\nb = 2\n", 2, 8)
    assert parser.compute_backslash_indent() == 2
    parser = RoughParser("    a=2\nb = 2\n", 4, 8)
    assert parser.compute_backslash_indent() == 7
    parser = RoughParser("a==2\nb = 2\n", 2, 8)
    assert parser.compute_backslash_

# Generated at 2022-06-12 12:58:59.486570
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    def check(str_, expect):
        res = RoughParser(str_, 8).compute_backslash_indent()
        if res != expect:
            print("%r: %d != %d" % (str_, res, expect))

    check("", 1)
    check("x = 1\\\n", 5)
    check("x = [1,\\\n", 8)
    check("if 1:\\\n", 6)
    check("if 1: # hello\n", 6)



# Generated at 2022-06-12 12:59:02.784048
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    parser = RoughParser()
    parser.set_str(dedent("""
        [
            key1 = value1,
            key2 = value2,
            key3 = value3
        ]
        """))
    assert parser.compute_bracket_indent() == 4

# Generated at 2022-06-12 12:59:09.506710
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-12 12:59:16.231424
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    r = RoughParser( 'if a:', 0, 4 )
    assert r.is_block_opener() == True
    r = RoughParser( 'if a: pass', 0, 4 )
    assert r.is_block_opener() == True
    r = RoughParser( 'while a:\n\tpass', 0, 4 )
    assert r.is_block_opener() == True
    r = RoughParser( 'elif a:\n\tpass', 0, 4 )
    assert r.is_block_opener() == True
    r = RoughParser( 'for a in b:', 0, 4 )
    assert r.is_block_opener() == True
    r = RoughParser( 'try:', 0, 4 )
    assert r.is_block_opener() == True

# Generated at 2022-06-12 12:59:25.816343
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    def check(data, tabwidth, expected):
        p = RoughParser(data, tabwidth)
        n = p.compute_backslash_indent()
        assert n == expected, repr(data)

    check("a=5", 4, 1)
    check("a = 5", 4, 1)
    check("a += \\", 4, 0)
    check("a == \\", 4, 0)
    check("a = b == c", 4, 1)
    check("for i in l:\\", 4, 1)
    check("if a == b:\\", 4, 1)
    check("if a\\", 4, 0)
    check("if a \\\n", 4, 0)
    check("if a == b\\", 4, 0)
    check("if a == (b\\", 4, 0)
   

# Generated at 2022-06-12 12:59:32.827825
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class TestHyperParserSetIndex(TestCase):
        def test_set_index(self):
            def assert_index_set(index, string, expected_result):
                self.hp.set_index(index)
                self.assertEqual(self.hp.get_expression(), expected_result)

            def assert_index_set_raised(index, string):
                self.assertRaises(ValueError, self.hp.set_index, index)

            self.hp = HyperParser(text, "1.0")
            assert_index_set_raised("0.0", "")

            self.hp = HyperParser(text, "1.end")
            assert_index_set_raised("2.0", "")

            self.hp = HyperParser(text, "3.0")

# Generated at 2022-06-12 12:59:40.744500
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    parser = HyperParser(tkinter.Text(), "1.0")
    parser.rawtext = "#foo (bar\nspam # ham\neggs)\n"
    parser.bracketing = [(0, 0), (4, 1), (5, 1), (11, 1), (14, 2), (26, 2), (27, 2), (28, 1)]
    parser.isopener = [True, False, False, False, True, False, False, False]
    parser.stopatindex = "4.0"

    for i in range(len(parser.rawtext)):
        parser.indexinrawtext = i
        parser.indexbracket = 0

# Generated at 2022-06-12 12:59:47.106605
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=too-many-locals
    # pylint: disable=no-member
    def showresults(
        self,
        indent_width,
        tabwidth,
        lines,
        expected,
        stmt_only=True,
        expected_stmt_bracketing=None,
    ):
        if stmt_only:
            if expected_stmt_bracketing is None:
                lines = [
                    "    x = [",
                    "        1,",
                    "        2,",
                    "        3,",
                    "    ]",
                ]

# Generated at 2022-06-12 12:59:49.618474
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    t = RoughParser("a = []", script_args, 0)
    assert t.compute_bracket_indent() == 1 + 4



# Generated at 2022-06-12 13:00:20.097974
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    tk = Tk()
    s = ScrolledText.ScrolledText(tk, height=20, width=20)
    t = s.component("text")
    t.insert("1.0", "a = f(a, b, c)")
    t.update()
    t.see("1.0")

    hp = HyperParser("1.0", "end", t)
    for i in range(1, 9):
        print("char at 1.%d = '%s'" % (i, t.get("1.%d" % i)))
    hp.set_index("1.2")
    assert hp.get_expression() == "a"
    hp.set_index("1.3")
    assert hp.get_expression() == "a"
    hp.set_index("1.4")
   

# Generated at 2022-06-12 13:00:25.304231
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    t = Text()
    t.insert("insert", "a = b = a\n")
    t.insert("insert", "c")
    t.index("insert")
    hp = HyperParser(t, "insert")
    assert hp.is_in_code() == True
    assert hp.get_expression() == ""

    hp.set_index("insert-1c")
    assert hp.is_in_code() == True
    assert hp.get_expression() == ""

    hp.set_index("insert-2c")
    assert hp.is_in_code() == True
    assert hp.get_expression() == "b"


# Generated at 2022-06-12 13:00:33.274302
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin
    # pylint: disable=invalid-name
    def run(text, tabwidth, expected):
        # pylint: disable=missing-docstring
        assert RoughParser(text, tabwidth=tabwidth).compute_bracket_indent() == expected

    run("[\n]", 8, 1)
    run("[\n    ]", 8, 4)
    run("[\n        ]", 8, 8)
    run("[\n]   # foo\n", 8, 1)
    run("[\n    # foo\n]", 8, 4)
    run("[\n\n]", 8, 0)
    run("[\n    \n]", 8, 4)

# Generated at 2022-06-12 13:00:41.228789
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    for l in ["abc", "abc\n", "abc\ndef\n"]:
        for i in range(len(l)):
            for c in range(len(l)):
                h = HyperParser(tk.Text(None, width=80), repr(c) + "." + repr(i))
                h.set_index(repr(c) + "." + repr(i))
                assert h.indexinrawtext == i
                assert h.stopatindex == repr(c + 1) + ".end"
                if i == len(l) - 1:
                    assert h.indexbracket == len(h.bracketing) - 1
                else:
                    assert h.indexbracket
                    assert h.indexbracket < len(h.bracketing) - 1

# Generated at 2022-06-12 13:00:47.902860
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test_ex(text, index, desired):
        hp = HyperParser(text, index)
        found = hp.get_expression()
        if found != desired:
            print(
                "Error in get_expression:"
                "\nDesired: [%s]"
                "\nFound:   [%s]"
                % (desired, found)
            )

    # First, we test the error cases, where we ask for an expression
    # for an index which is in a comment or in a string.
    test_ex(
        "def foo(x):  # test\n" "   return x+1",
        "1.0",
        "def",
    )

# Generated at 2022-06-12 13:00:50.044588
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from idlelib.idle_test.htest import run

    run(HyperParser)


if __name__ == "__main__":
    test_HyperParser()

# Generated at 2022-06-12 13:00:59.121254
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-12 13:01:08.718179
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    # set up a RoughParser with a text that has various indentation styles
    rp = RoughParser("""\
if 1:
    if 2:
      if 3:
        pass
      # comment
     # comment

# comment

if True:
""" )
    # check that RoughParser.get_base_indent_string returns the right values
    # for the various lines
    assert rp.get_base_indent_string() == "if 1:"
    rp.update_line("    if 2:")
    assert rp.get_base_indent_string() == "    if 2:"
    rp.update_line("      if 3:")
    assert rp.get_base_indent_string() == "      if 3:"
    rp.update_line("        pass")
    assert rp.get

# Generated at 2022-06-12 13:01:18.017099
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin

    rp = RoughParser("", 0)

    def cbi(continuation, str, indent_width):
        rp.str = str
        rp.indent_width = indent_width
        rp.continuation = continuation
        return rp.compute_backslash_indent()

    assert cbi(C_BACKSLASH, "if 1:\\\n    print(17)", 4) == 5
    assert cbi(C_BACKSLASH, "if 1:\\\n    print(17)", 2) == 3
    assert cbi(C_BACKSLASH, "if 1:\\\n    print(17)", 8) == 9
    assert cbi(C_BACKSLASH, "if 1:\\\n    print(17)", 0) == 1
   

# Generated at 2022-06-12 13:01:26.498067
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():

    rp = RoughParser(
        "if d == None:  \\ \n    foo = a = 1", indent_width=4, tabsize=8
    )
    assert rp.compute_backslash_indent() == 13, rp
    rp = RoughParser("\nif d == None:  \\ \n    foo = a = 1", indent_width=4, tabsize=8)
    assert rp.compute_backslash_indent() == 17, rp
    rp = RoughParser("\nif d == None:  \\ \nfoo = a = 1", indent_width=4, tabsize=8)
    assert rp.compute_backslash_indent() == 17, rp

# Generated at 2022-06-12 13:02:09.397798
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    for s in [
        "a.b",
        "a.b.c",
        "(a)",
        "a(b)",
        "[a, b]",
        "[a, b].c",
        "a[b]",
        "a, b",
        "a + b",
        "a + [b, c]",
        "a + b + c",
        "a + b[c, d]",
        "a + (b + c, d)",
        "a[b + c, d]",
        "(a + b).c",
        "a + (b + c).d",
        "(a + b[c, d])",
    ]:
        hp = HyperParser(tid_tk(s), "end")

# Generated at 2022-06-12 13:02:13.719177
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    f1 = "x = \\ \n   10"
    f2 = "x = 10 + \\ \n   20 + \\ \n   30 + \\ \n   40"
    rf1 = RoughParser(f1, len(f1))
    rf2 = RoughParser(f2, len(f2))
    assert rf1.compute_backslash_indent() == 4
    assert rf2.compute_backslash_indent() == 4


# Generated at 2022-06-12 13:02:22.330580
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    rp = RoughParser()
    # No continuation:
    s = "spam(x, y,\n" "      z)\n"
    i = rp.find_good_parse_start(s, len(s))
    assert i == len(s)
    # String continuation:
    s = "spam(x, y,\n" "      " '"""multi\nline\nstring"""' "\n" "      z)\n"
    i = rp.find_good_parse_start(s, len(s))
    assert i == len(s)
    # Bracket continuation:
    s = "spam(x, y,\n" "      z)\n" "if True:\n" "    pass\n"
    i = rp.find_good_parse_start(s, len(s))

# Generated at 2022-06-12 13:02:26.258045
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    from test import test_support
    tp = test_support.import_module("test.test_parser")
    f = tp.findfile("input_backslash_indent.txt")
    n = open(f, "rb").read().decode()
    parser = RoughParser(n)
    assert parser.compute_backslash_indent() == 8


# Generated at 2022-06-12 13:02:33.472572
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest
    from test.support import captured_stdout

    class HyperParser_Tests(unittest.TestCase):
        """Testing HyperParser method set_index"""

        def test_simple_string(self):
            # a sample
            # a sample
            text = Text()
            text.insert("insert", "a sample")
            hyperparser = HyperParser(text, "1.0")
            hyperparser.set_index("1.0")
            self.assertTrue(hyperparser.is_in_string())
            hyperparser.set_index("1.1")
            self.assertTrue(hyperparser.is_in_string())
            hyperparser.set_index("1.2")
            self.assertFalse(hyperparser.is_in_string())

# Generated at 2022-06-12 13:02:38.847510
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():

    class MockText:

        def __init__(self, str):
            self.str = str

        def index(self, index):
            return index

        def get(self, first, last=None):
            if last is None:
                return self.str[first]
            return self.str[first:last]

    def test(text, index, expected):
        hyper = HyperParser(MockText(text), index)
        actual = hyper.get_surrounding_brackets()
        if actual != expected:
            print(
                'get_surrounding_brackets("%s", "%s") --> "%s", expected "%s"'
                % (text, index, actual, expected)
            )

    test("", "1.0", None)
    test("(", "1.0", None)

# Generated at 2022-06-12 13:02:44.706645
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("foo(bar(baz),\nquux=quuux)\n")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("  foo(bar(baz),\nquux=quuux)\n")
    assert rp.get_base_indent_string() == "  "
    rp = RoughParser("    foo(bar(baz),\nquux=quuux)\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("foo(bar(baz),\n  quux=quuux)\n")
    assert rp.get_base_indent_string() == "  "


# Generated at 2022-06-12 13:02:49.942822
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    def check(expected, s):
        rp = RoughParser(s)
        rp.find_good_parse_start()
        assert rp.str == s
        assert rp.goodparse_start == expected
    check(0, "")
    check(0, "  \t \n  \n  ")
    check(0, "a")
    check(3, "if True:\n x=True")
    # the following would be better if it found 1 rather than 0
    check(0, "if True:\n x = True\n")


# Generated at 2022-06-12 13:02:57.290100
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    "Unit test for method get_expression of class HyperParser"
    h_p = HyperParser("a = 5 \n", "1.0")
    assert (h_p.get_expression()) == "a"
    h_p = HyperParser("a = 5 \n", "1.1")
    assert (h_p.get_expression()) == ""
    h_p = HyperParser("a = 5 \n", "1.2")
    assert (h_p.get_expression()) == ""
    h_p = HyperParser("a = 5 \n", "1.3")
    assert (h_p.get_expression()) == ""

    h_p = HyperParser("a+5\n", "1.0")
    assert (h_p.get_expression()) == "a"

# Generated at 2022-06-12 13:03:00.682944
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    for (source, expected_indent_width) in UNIT_TEST_DATA:
        parser = RoughParser(source)
        actual_indent_width = parser.compute_bracket_indent()
        assert expected_indent_width == actual_indent_width

if __name__ == "__main__":
    import pytest
    pytest.main([sys.argv[0]])

# Generated at 2022-06-12 13:04:41.462793
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-12 13:04:51.253971
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from tkinter import Tk, Text
    from test import support

    root = Tk()
    f = Text(root)
    support.use_resources = ["styles", "fetch"]
    for res in support.use_resources:
        if not support.get_resource_path(res, True):
            support.use_resources.remove(res)
    # If we raise an exception, the window stays on the screen,
    # and we have to quit manually.  So we try to be tidy by
    # removing the widget.

# Generated at 2022-06-12 13:04:54.961574
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rp = RoughParser("a = [1,\n]")
    assert rp.get_num_lines_in_stmt() == 2

    rp = RoughParser("a = [\\\n1,\\\n]")
    assert rp.get_num_lines_in_stmt() == 3


# Generated at 2022-06-12 13:05:01.729435
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # |             # |             # |             # |             # |

    assert RoughParser("[1,2").compute_bracket_indent() == 0
    assert RoughParser("[\n ").compute_bracket_indent() == 1
    assert RoughParser("[\n  ").compute_bracket_indent() == 2
    assert RoughParser("[\n   ").compute_bracket_indent() == 3
    assert RoughParser("[\n    ").compute_bracket_indent() == 4
    assert RoughParser("foo(\n    ").compute_bracket_indent() == 4
    assert RoughParser("foo(\n     ").compute_bracket_indent() == 6
    assert RoughParser("[\n        x").compute_bracket_indent() == 8
   

# Generated at 2022-06-12 13:05:08.961432
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest.mock import Mock

    text = Mock()
    text.get = Mock(side_effect=lambda start, stop: "abc"[len(text.get.mock_calls) :])
    text.indent_width = 4
    text.tabwidth = 8
    text.index = lambda i: i

    parser = HyperParser(text, "1.0")
    assert parser.rawtext == "abc"
    assert parser.stopatindex == "1.end"
    assert parser.bracketing == [(0, 0), (1, 0), (2, 0)]
    assert parser.isopener == [True, True, True]
    assert parser.indexinrawtext == 0
    assert parser.indexbracket == 0

    parser.set_index("2.end")

# Generated at 2022-06-12 13:05:12.749027
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    s = RoughParser("foo = \\")
    assert s.compute_backslash_indent() == 4
    s = RoughParser("foo = \\\n")
    assert s.compute_backslash_indent() == 4
    s = RoughParser("if (\\\n")
    assert s.compute_backslash_indent() == 5



# Generated at 2022-06-12 13:05:15.237813
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    _test(
        """
if True:
    (
    {([][
        say(
            boo)
    or
   die(bang)

"""
    )

# Generated at 2022-06-12 13:05:24.037608
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    parser = RoughParser("a=1\\\n  +2\\\n  +3")
    assert parser.compute_backslash_indent() == 3
    parser = RoughParser("a=f(1,\\\n  2,\\\n  3)")
    assert parser.compute_backslash_indent() == 3
    parser = RoughParser("a=f(1,\\\n  2,\\\n  3)\\\n  +4")
    assert parser.compute_backslash_indent() == 3
    parser = RoughParser("a = \\")
    assert parser.compute_backslash_indent() == 0
    parser = RoughParser("a = b + \\")
    assert parser.compute_backslash_indent() == 3

# Generated at 2022-06-12 13:05:34.039408
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def test(s, expected):
        parser = RoughParser("", s)
        actual = parser.get_base_indent_string()
        if actual != expected:
            print("get_base_indent_string() failed on '%s': expected '%s' but got '%s'" % (s, expected, actual))
    test("", "")
    test("x = 0", "")
    test("  x = 0", "  ")
    test("\tx = 0", "\t")
    test("\nx = 0", "")
    test("\n  x = 0", "  ")
    test("\n\tx = 0", "\t")
    test("x = 0\n", "")
    test("  x = 0\n", "  ")

# Generated at 2022-06-12 13:05:40.163668
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest.mock import Mock

    class MockTextWidget:
        """Mock for Tkinter_dnd.dnd_support.TextWidget"""

        def __init__(self, content, indent_width, tab_width):
            self.content = content
            self.indent_width = indent_width
            self.tab_width = tab_width

        def get(self, from_, to_):
            return self.content[from_:to_]

        def index(self, pos):
            if not isinstance(pos, int):
                return pos
            return self.content[pos]
