

# Generated at 2022-06-12 12:59:46.684635
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("a = if b:\n  continue\n")
    rp._study2()
    assert rp.get_base_indent_string() == '  '


if __name__ == "__main__":
    rp = RoughParser("a = if b:\n  continue\n")
    rp._study2()
    assert rp.get_base_indent_string() == '  '
    # Unit test for method get_last_open_bracket_pos of class RoughParser
    rp = RoughParser("a =h [\n")
    rp._study2()
    assert rp.get_last_open_bracket_pos() == 4


if __name__ == "__main__":
    rp = RoughParser("a =h [\n")
    rp._study

# Generated at 2022-06-12 12:59:56.738627
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    def test(text, index, should_be_in_string):
        from unittest import TestCase

        class DummyText:
            def __init__(self, txt):
                self.txt = txt

            def get(self, start, end):
                return self.txt[start : end]

            def index(self, i):
                return i

        parser = HyperParser(DummyText(text), index)
        assert parser.is_in_string() == should_be_in_string

    test("", 0, False)
    test("1", 0, False)
    test("'1", 0, True)
    test("'\\'", 0, False)
    test("'a'", 0, False)
    test("'a'", 1, True)
    test("'a'", 2, False)

# Generated at 2022-06-12 12:59:58.607831
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from idlelib import hyperparser

    text = SimpleEditorWindow(None)

# Generated at 2022-06-12 13:00:03.488383
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    rough_parser = RoughParser(source)
    assert rough_parser.get_last_stmt_bracketing() == (
        (0, 0),
        (2, 1),
        (11, 2),
        (12, 1),
        (19, 2),
        (27, 3),
        (45, 2),
        (51, 1),
        (54, 0),
        (57, 0),
        (60, 0)
    )

# Generated at 2022-06-12 13:00:09.323040
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from idlelib.idle_test.mock_idle import Func
    from tkinter.simpledialog import _QueryString
    root = Tk()

# Generated at 2022-06-12 13:00:16.115679
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    h = HyperParser("a(b)c", 1.5)
    assert h.get_surrounding_brackets() == ("1.0", "1.3")
    assert h.get_surrounding_brackets("[", True) is None
    h = HyperParser("a(b)c", 3.5)
    assert h.get_surrounding_brackets("[", True) == ("1.0", "3.3")



# Generated at 2022-06-12 13:00:21.694230
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    preserve_dict = {
        ord('\t'): ord('\t'),
        ord('\n'): ord('\n'),
        ord('\r'): ord('\r'),
        ord(' '): ord(' '),
    }
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'



# Generated at 2022-06-12 13:00:22.421308
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-12 13:00:32.326436
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser("    pass")
    assert rp.get_num_lines_in_stmt() == 1
    assert rp.get_continuation_type() == C_NONE
    assert rp.get_last_stmt_bracketing() is None
    assert rp.get_last_open_bracket_pos() is None
    assert rp.is_block_opener() == 0
    assert rp.is_block_closer() == 0
    assert rp.get_base_indent_string() == "    "

    rp = RoughParser("x = x + 1")
    assert rp.get_num_lines_in_stmt() == 1
    assert rp.get_continuation_type() == C_NONE
    assert rp.get_last_stmt_br

# Generated at 2022-06-12 13:00:40.365944
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-outer-name,invalid-name
    # pylint: disable=no-member
    # pylint: disable=bare-except
    # pylint: disable=star-args
    import pprint
    import random
    import textwrap
    import itertools

    # pylint: disable=redefined-builtin
    random.seed(12)

    # pylint: disable=too-many-locals
    def test_indent_calculation(*, text, width=4, tabwidth=4):
        rp = RoughParser(text, width)
        indent_type = rp.get_continuation_type()
        expected_indent = 0
        if indent_type == C_BRACKET:
            expected_indent = rp.compute_bracket

# Generated at 2022-06-12 13:01:11.012160
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser(indent_width=8, tabwidth=8)
    rp.set_str('''
    x = 1
    if a:
    \tx = 2
    ''')
    assert 4 == len(rp.get_base_indent_string())

# Generated at 2022-06-12 13:01:20.164342
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rp = RoughParser("[\n    a +\n    b\n]", 0, 0)
    assert rp.compute_bracket_indent() == 4

    rp = RoughParser("[a+\n    b    #\n]", 0, 0)
    assert rp.compute_bracket_indent() == 8

    rp = RoughParser("[a+\n    b    ]", 0, 0)
    assert rp.compute_bracket_indent() == 4

    rp = RoughParser("[a+\n    b]", 0, 0)
    assert rp.compute_bracket_indent() == 4

    rp = RoughParser("(\n)\n", 0, 0)
    assert rp.compute_bracket_indent() == 0

    rp

# Generated at 2022-06-12 13:01:27.973577
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    p = RoughParser()
    p.set_str("""foo = "bar"\\
    "baz"\\
    'foo')
    """)
    p.set_valid_syntax_flags(single_quoted=1)
    p.set_line_end_check_enabled(False)
    assert p.get_continuation_type() == C_STRING_NEXT_LINES
    p.set_str("""foo = (
    'foo')
    """)
    p.set_line_end_check_enabled(False)
    assert p.get_continuation_type() == C_BRACKET
    p.set_str("""foo = (
    'foo')\\
    """)
    p.set_line_end_check_enabled(False)
    assert p.get_continuation_

# Generated at 2022-06-12 13:01:36.799001
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    test_txt = "abc def ghi"
    hp = HyperParser(test_txt, "0.0")
    for i in range(len(test_txt) + 1):
        hp.set_index("%d.0" % i)
        assert hp.indexinrawtext == i, "HyperParser.set_index() ? %s" % i
        assert hp.indexbracket == 0, "HyperParser.set_index() ? %s" % i
    for i in range(len(test_txt) + 1):
        hp.set_index("%d.end" % i)
        assert hp.indexinrawtext == i, "HyperParser.set_index() ? %s.end" % i
        assert hp.indexbracket == 0, "HyperParser.set_index() ? %s.end" % i
   

# Generated at 2022-06-12 13:01:45.689179
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-12 13:01:51.700555
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    assert HyperParser("", "1.0").is_in_code()
    assert HyperParser("# comment", "1.0").is_in_code()
    assert HyperParser("a", "1.0").is_in_code()
    assert HyperParser("a# comment", "1.0").is_in_code()
    assert HyperParser("a # comment", "1.0").is_in_code()
    assert HyperParser("a", "1.1").is_in_code()
    assert HyperParser("a =", "1.2").is_in_code()
    assert HyperParser("a = # comment", "1.2").is_in_code()

    assert not HyperParser("# comment", "1.3").is_in_code()
    assert not HyperParser("a# comment", "1.1").is_in

# Generated at 2022-06-12 13:01:59.544186
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    """Method get_continuation_type of class RoughParser"""
    print("test_RoughParser_get_continuation_type")
    rp = RoughParser()
    assert rp.get_continuation_type() == rp.C_NONE
    rp.set_str('" a"')
    assert rp.get_continuation_type() == rp.C_STRING_FIRST_LINE
    rp.set_str('def f(x):\n   "a"')
    assert rp.get_continuation_type() == rp.C_STRING_NEXT_LINES
    rp.set_str('2**x\n')
    assert rp.get_continuation_type() == rp.C_BACKSLASH

# Generated at 2022-06-12 13:02:01.604770
# Unit test for constructor of class HyperParser

# Generated at 2022-06-12 13:02:08.088835
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    """Test method get_expression from class HyperParser."""
    #
    # Test method in class HyperParser that returns a string with
    # the Python expression which ends at the given index, which
    # is empty if there is no real one.
    #

    # Each test case is triple:
    # 1. a string
    # 2. a number of current position in the string
    # 3. a number of last pos of the expression
    # 4. a number of last pos of the expression that ignores comments
    #    (or None if there is no difference)
    # 5. a number of last pos of the expression that ignores trailing
    #    brackets (or None if there is no difference)


# Generated at 2022-06-12 13:02:16.089697
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin
    # pylint: disable=invalid-name
    
    def test(program, answer, indent_width=4, tabwidth=8):
        rp = RoughParser(program, indent_width, tabwidth)
        j = rp.compute_bracket_indent()
        assert j == answer, "%r != %r for program %r" % (j, answer, program)

    test("if 1:\n    x = [1,2,3,\n        ]", 4)
    test("x = [1,2,\n       3,]", 4)
    test("x = [1,\n    [2]]", 8)
    test("x = [\n    [1],2]", 0)

# Generated at 2022-06-12 13:02:48.040011
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-12 13:02:53.934761
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    class MockText:
        def __init__(self, content, tabwidth):
            self.content = content
            self.index = {
                "0.0": 0,
                "1.0": len(content.split("\n")[0]) + 1,
                "1.5": len(content.split("\n")[0]) + 2,
                "2.0": len(content.split("\n")[0]) +
                       len(content.split("\n")[1]) + 2,
                "end": len(content) + 1,
            }
            self.indent_width = tabwidth
            self.tabwidth = tabwidth

        def get(self, start, stop):
            return self.content[self.index[start] : self.index[stop] - 1]


# Generated at 2022-06-12 13:02:54.855185
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-12 13:02:56.957034
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """Unit test for set_index method of class HyperParser

    This is called from IDLE's test suite.
    """

# Generated at 2022-06-12 13:03:02.604633
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    """ Test find_good_parse_start method of RoughParser

        Does not test the finding of the parse start, but check if at
        least the parsing of the rough_parse argument works.
    """
    rp = RoughParser("{\n{\n{\n{\n{\n{\n{\n{\n{\n{\n{\n{\n{\n{\n{\n{\n")
    assert rp.find_good_parse_start(rp.str, 15) == 0
    assert rp.find_good_parse_start(rp.str, 16) == 1
    assert rp.find_good_parse_start(rp.str, 17) == 1
    assert rp.find_good_parse_start(rp.str, 18) == 1

# Generated at 2022-06-12 13:03:11.050396
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from test.support import captured_stdout

    # Set up some rawtext, as if returned by a PyParser.  The last
    # bracketing level is a comment.  We don't need an actual
    # parser.
    rawtext = "class myclass:\n    def mymeth(self):\n        " 'x = "my string"'
    bracketing = [
        (0, 0),
        (6, 1),
        (12, 2),
        (13, 3),
        (24, 4),
        (30, 5),
        (36, 4),
        (37, 3),
        (38, 2),
        (40, 1),
        (44, 0),
    ]

    # Create a HyperParser with its stopatindex, rawtext and
    # bracketing.  The other attributes will be set by a

# Generated at 2022-06-12 13:03:20.301791
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    from lib2to3.pgen2.tokenize import generate_tokens, untokenize, TokenInfo
    # pylint: disable=redefined-builtin
    def sample_inputs(rp):
        yield ("", False, False)
        yield ("# comment", False, False)
        yield ("\n", False, False)
        yield ("a = b",False, False)
        yield ("a = b = c = d = e = f = g = h = i = j = k = l = m = n = o = p = q = r",
               False, False)
        yield ("if a == b:", False, False)
        yield ("class A(object):", False, False)
        yield ("def A(object):", False, False)
        yield ("if a == b:", False, True)
        yield

# Generated at 2022-06-12 13:03:28.885450
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = """print("foo")
# comment
    def(("bar", 'baz'))
    "string"
    'string'
    'closed by #'
        closed by #
'''
closed by #
'''
"""

# Generated at 2022-06-12 13:03:34.097420
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    parser = RoughParser("def f():\n    if 0:\n        return(", 0, 4)
    assert parser.compute_bracket_indent() == 8
    parser = RoughParser("def f():\n    if 0:\n        return (", 0, 4)
    assert parser.compute_bracket_indent() == 8
    parser = RoughParser("def f():\n    if 0:\n        return\n        foo", 0, 4)
    assert parser.compute_bracket_indent() == 4


# Generated at 2022-06-12 13:03:35.066208
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-12 13:04:05.221444
# Unit test for method set_index of class HyperParser

# Generated at 2022-06-12 13:04:13.524307
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    def check(s, expected):
        data = RoughParser(s, "")
        p = data.find_good_parse_start()
        assert p == expected

    #                 0123456789012345678901234567890123456789
    check("if 1:\n    if 1:\n        if 1:\n            return\n            \n", "if 1:\n    if 1:\n        if 1:\n            return\n")
    check("if 1:\n    if 1:\n        if 1:\n\n", "if 1:\n    if 1:\n")
    check("if 1:\n    if 1:\n        if 1:\n\n    \n", "if 1:\n    if 1:\n")

# Generated at 2022-06-12 13:04:22.437112
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():

    from idlelib.idle_test.mock_idle import Func
    from idlelib.idle_test.htest import run

    # The parser always works on a statement, so we have to add a newline
    # at the end.
    text_prefix = "def foo():\n"
    id_prefix = "foo."
    def create_text(text, id):
        text = text_prefix + text
        id = id_prefix + id
        return (text, "%s.%sc" % (len(text_prefix), len(id) - 1))

    # id: The text of the line, with the cursor position indicated by "|".
    # expected: None if there is no matching brackets, else the indices of
    # the matching brackets.

# Generated at 2022-06-12 13:04:30.050840
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # type: () -> bool

    # FIXME: broken tests.

    h = RoughParser("")
    print("assertEqual(h.get_continuation_type(), C_NONE)")

    h = RoughParser("a = 1\nb = 2")
    print("assertEqual(h.get_continuation_type(), C_NONE)")

    h = RoughParser("a = [1,\n2, 3]")
    print("assertEqual(h.get_continuation_type(), C_BRACKET)")

    h = RoughParser("[1,\n2]")
    print("assertEqual(h.get_continuation_type(), C_BRACKET)")

    h = RoughParser("a = [1,\n2, 3,\n]")

# Generated at 2022-06-12 13:04:38.490121
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # Helper method to do a test.
    def test(s, index, expected):
        hyp = HyperParser(s, index)
        actual = hyp.get_expression()
        if actual != expected:
            raise RuntimeError(
                "Error in expression %s: expected %s, got %s"
                % (repr(s), repr(expected), repr(actual))
            )

    test("", "1.0", "")
    test(" ", "1.0", "")
    test("a", "1.0", "a")
    test("a ", "1.end", "a")
    test("ab ", "2.end", "ab")
    test("a b", "2.0", "")
    test("a b ", "2.0", "")

# Generated at 2022-06-12 13:04:44.988848
# Unit test for constructor of class HyperParser

# Generated at 2022-06-12 13:04:50.279116
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=redefined-builtin
    import doctest
    from .rough_parse import RoughParser
    # doctest does not recognize indented multi-line strings
    # for the docstring of RoughParser.find_good_parse_start,
    # but we can pass the string to the constructor
    doctest.testmod(RoughParser(RoughParser.find_good_parse_start.__doc__))

# Generated at 2022-06-12 13:04:52.743222
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    text = [
        "head1 = (foo\n",
        "         for i in (1, 2, 3):\n",
        "             print i\n",
    ]
    assert RoughParser(text).compute_bracket_indent() == 14


# Generated at 2022-06-12 13:04:59.647171
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():

    def test(expected, *args):
        assert expected == RoughParser(*args).compute_bracket_indent()

    test(8, 'l = [1,\n    2\n    ]')
    test(8, 'l = [1,\n    2,\n    ]')
    test(12, 'l = [1,\n        2\n    ]')
    test(12, 'l = [1,\n        2,\n    ]')
    test(8, 'l = [\n    1,\n    2\n    ]')
    test(12, 'l = [\n        1,\n        2\n    ]')
    test(8, 'l = (1,\n    2\n    )')

# Generated at 2022-06-12 13:05:07.542193
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():

    from lib2to3 import pgen2
    from lib2to3.pytree import Nonterminal, Leaf
    from lib2to3.pygram import python_grammar, python_symbols
    from lib2to3.pgen2 import token

    grammar = python_grammar
    nonterminal = python_symbols.file_input
    parser = pgen2.Driver(grammar, pgen2.convert_grammar_file("Grammar.txt", "Grammar.6.txt", grammar))
    parser.grammar.keywords = grammar._keywords

    def parse(code):
        return parser.parse_string(code, debug=0, start=nonterminal)


# Generated at 2022-06-12 13:05:46.852822
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from idlelib.idle_test.htest import run

    run(HyperParser_set_index)



# Generated at 2022-06-12 13:05:55.627065
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    """Test HyperParser.is_in_string."""
    hyperparser = HyperParser("a 'b' c", 6)
    assert hyperparser.is_in_string()
    hyperparser = HyperParser("a 'b' c", 5)
    assert not hyperparser.is_in_string()
    hyperparser = HyperParser("a 'b' c", 4)
    assert hyperparser.is_in_string()
    hyperparser = HyperParser(r'''a 'b\' c''', 6)
    assert hyperparser.is_in_string()
    hyperparser = HyperParser(r'''a "b\" c''', 6)
    assert not hyperparser.is_in_string()
    hyperparser = HyperParser(r'''a "B\" c''', 6)
    assert hyperparser.is_in_string()
    hyperparser

# Generated at 2022-06-12 13:05:59.431811
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    f=open("1.py","r")
    txt=f.read()
    f.close()
    p1=RoughParser(txt)
    p1.set_lo()
    if p1.lo.startswith("\n"):
        print("ok")
    else:
        print("fail")

# Generated at 2022-06-12 13:06:05.762163
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    """Unit test for method get_surrounding_brackets of class
    HyperParser.
    """

# Generated at 2022-06-12 13:06:14.963842
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    import statemnt
    if not statemnt.test():
        print("_pegen_test_pat failed")
        return False
    import parser
    # First compile the example
    formatter = parser.Parser()
    test_string = """
    while True:
        if x:
            break
    else:
        print("no break!")
        return
    """
    formatter.format(test_string)
    # Now check the bracketing
    # The brackets are the following
    bracketing = ((0, 0), (7, 1), (11, 0), (14, 1), (18, 0), (23, 1), (26,
        0), (32, 1), (35, 0), (42, 1), (46, 0), (52, 1), (55, 0))


# Generated at 2022-06-12 13:06:23.912356
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-12 13:06:32.244883
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-12 13:06:39.078957
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from test.test_support import check_impl_detail

    # NOTE: test_HyperParser_set_index does not use the -K argument because
    # it tests the default argument behaviour of HyperParser.set_index.
    class_name = b"HyperParser"
    check_impl_detail(class_name, b"set_index")

    import unittest

    class HyperParserSetIndexTest(unittest.TestCase):
        text_template = """
123456789
123456789
123456789
123456789
123456789
123456789
123456789
123456789
"""

        def setUp(self):
            self.hp = HyperParser(self.text_template, "1.0")

        def test_set_index(self):
            self.hp.set_index

# Generated at 2022-06-12 13:06:48.896961
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    """Check that get_surrounding_brackets returns the right indexes."""

# Generated at 2022-06-12 13:06:58.293809
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    assert RoughParser("a \\\nb \\\nc \\\nd \\\n").compute_backslash_indent() == 4
    assert RoughParser("a = \\\nb = \\\nc = \\\nd = \\\n").compute_backslash_indent() == 4
    assert RoughParser("if a: \\\n    b \\\n    c \\\n    d \\\n").compute_backslash_indent() == 8
    assert RoughParser("_, a = \\\n1, b = \\\n2, c = \\\n3, d = \\\n").compute_backslash_indent() == 6
    assert RoughParser("if (a \\\n    b \\\n    c \\\nd \\\n").compute_backslash_indent() == 4