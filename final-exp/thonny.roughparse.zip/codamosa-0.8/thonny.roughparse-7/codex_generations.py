

# Generated at 2022-06-12 12:59:40.052145
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-12 12:59:45.676251
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser(indent_width=4, tabwidth=8)
    assert rp.get_base_indent_string() == ""
    rp.set_lo("if a < b == c > d: pass")
    rp.set_lo("if a < b == c > d:")
    rp.set_lo("    if a < b == c > d: pass")
    rp.set_lo("    if a < b == c > d:")
    rp.set_lo("    if a < b == c > d:")
    rp.set_lo("        if a < b == c > d: pass")



# Generated at 2022-06-12 12:59:56.129734
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    from . import pytree
    from .pygram import python_symbols as syms

    # Test for cases when no base indentation string should be returned

# Generated at 2022-06-12 13:00:04.143726
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=redefined-builtin
    import doctest
    from lib2to3 import pytree, pygram

    def find_indent(text):
        rp = RoughParser(text, "string")
        return rp.get_base_indent_string()

    def find_goodlines(text):
        rp = RoughParser(text, "string")
        return rp.goodlines

    def find_continuation_type(text):
        rp = RoughParser(text, "string")
        return rp.get_continuation_type()

    def find_num_lines_in_stmt(text):
        rp = RoughParser(text, "string")
        return rp.get_num_lines_in_stmt()


# Generated at 2022-06-12 13:00:15.736887
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = Tk.Text()
    text.insert("insert", "a(b,\n    c,d(e)")
    hp = HyperParser(text, "insert")
    assert hp.get_surrounding_brackets() == ("1.0", "3.2")
    hp.set_index("2.0")
    assert hp.get_surrounding_brackets() == ("1.0", "3.2")
    hp.set_index("2.1")
    assert hp.get_surrounding_brackets() is None
    hp.set_index("1.2")
    assert hp.get_surrounding_brackets() == ("1.0", "3.2")
    hp.set_index("2.4")

# Generated at 2022-06-12 13:00:23.656845
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    t = _build_char_in_string_func("1.0")


# Generated at 2022-06-12 13:00:32.559373
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    s = "a = \\ \n    b + c"
    rp = RoughParser(s, 4)
    assert rp.compute_backslash_indent() == len("    a = \\") + 1

    s = "a = \\\n"
    rp = RoughParser(s, 4)
    assert rp.compute_backslash_indent() == 0

    s = "a = \\\n    "
    rp = RoughParser(s, 4)
    assert rp.compute_backslash_indent() == len("    ") + 1

    s = "a = \\ \\\\\n"
    rp = RoughParser(s, 4)

# Generated at 2022-06-12 13:00:40.613847
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class DummyEditWidget:
        def __init__(self, width, tabwidth):
            self.indent_width = width
            self.tabwidth = tabwidth

        def get(self, *args):
            return args[0]

        def index(self, *args):
            return 0

    class TestCase1(TestCase):
        def setUp(self):
            self.testobj = HyperParser(DummyEditWidget(8, 8), "0.0")

        def test_white(self):
            self.assertTrue(self.testobj.is_in_code())

        def test_parens(self):
            parser = self.testobj
            self.assertTrue(parser.get_surrounding_brackets() is None)

# Generated at 2022-06-12 13:00:47.490273
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-12 13:00:56.493747
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    from unittest import TestCase

    class Test(TestCase):
        def test_HyperParser_get_expression(self):
            def run(a, b):
                h = HyperParser(tk.Text(tk.Frame()), a)
                e = h.get_expression()
                self.assertEqual(e, b)

            run("1.0", "")
            run("1.1", "")
            run("1.2", "1")
            run("1.3", "1.")
            run("1.4", "")
            run("1.5", "")

            run("1.2 lineend", "1")
            run("1.3 lineend", "1.")
            run("1.4 lineend", "1.")
            run("1.5 lineend", "1")


# Generated at 2022-06-12 13:01:43.005258
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def test(text, b, e, i):
        p = RoughParser()
        p.set_str(text)
        assert p.compute_bracket_indent() == i
        debug = False
    test("a = [", 3, 3, 1)
    test("a = [1, 2, 3, 4, 5]", 3, 15, 5)
    test("a = [1, 2,\n   3, 4, 5]", 3, 18, 8)
    test("a = [1,  2,\n   3, 4, 5]", 3, 19, 8)
    test("a = [1,\n   2,\n   3, 4, 5]", 3, 19, 8)

# Generated at 2022-06-12 13:01:50.005095
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # pylint: disable=anomalous-backslash-in-string, bad-whitespace, invalid-name
    import collections
    import io
    import textwrap
    import unittest

    from . import lib2to3_parse

    from . import pytree, pygram

    from .pgen2.tokenize import *  # pylint: disable=wildcard-import
    from .pgen2.parse import ParseError

    def unit_parse(rough_str, *, encoding='utf-8', debug=0, tokens=None):
        """Parse the string 'rough_str', returning the root node."""
        if tokens is None:
            tokens = generate_tokens(io.StringIO(fail_on_unicode(rough_str)).readline)
        parser = lib2to3_parse.Parser

# Generated at 2022-06-12 13:01:58.919149
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    import unittest

    class TestCase(unittest.TestCase):
        def test_simple(self):
            rp = RoughParser("a=1\nb=2")
            assert rp.get_base_indent_string() == ""

            rp = RoughParser(" a=1\nb=2")
            assert rp.get_base_indent_string() == " "

            rp = RoughParser("a=1\n b=2")
            assert rp.get_base_indent_string() == " "

            rp = RoughParser("\n  a=1\nb=2")
            assert rp.get_base_indent_string() == "  "

            rp = RoughParser("\n   a=1\nb=2")
            assert rp.get_base_indent_

# Generated at 2022-06-12 13:02:02.034482
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    hp = HyperParser("text a b not in string")
    assert hp.is_in_string("a") == 0
    assert hp.is_in_string("not") == 1

    hp = HyperParser("te\"\"\"xt a b not in string")
    assert hp.is_in_string("a") == 0
    assert hp.is_in_string("not") == 1



# Generated at 2022-06-12 13:02:08.549736
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    class TkText(object):
        def __init__(self, text, index):
            self._text = text
            self._index = index

        def get(self, start, end="end"):
            return self._text[self.index(start): self.index(end)]

        def index(self, index):
            return int(float(index.split(".")[0]))

        def __getitem__(self, index):
            return self._text[index]


# Generated at 2022-06-12 13:02:15.149281
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    tests = [
        ("x = {", "x = {"),
        ("x = {\\\ny = 2", "x = {\\\n"),
        ("  x = {\\\n  y = 2", "  x = {\\\n"),
        ("x = {}\\\n  y = 2", "x = {}\\\n  "),
        ("  x = {}\\\n  y = 2", "  x = {}\\\n  "),
    ]
    for _test_, expected_output in tests:
        assert RoughParser(_test_).get_base_indent_string() == expected_output

# Generated at 2022-06-12 13:02:23.586849
# Unit test for constructor of class HyperParser
def test_HyperParser():
    "A simple unit test for constructor"

    text = Text()
    text.insert("insert", '  while 1:\n    a = "abcd "[2]\n        b = 3\n')
    text.mark_set("insert", "2.2")

    hp = HyperParser(text, "insert")
    assert hp.rawtext == '  while 1:\n    a = "abcd "[2]\n        b = 3\n'
    assert hp.stopatindex == "2.end"

# Generated at 2022-06-12 13:02:31.088845
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    class TestText(object):
        def __init__(self, chars):
            self.chars = chars
            self.indent_width = 8
            self.tabwidth = 8

        def get(self, start, stop):
            return self.chars[int(start):int(stop)]

        def index(self, pos):
            return str(self.chars.index(pos))+".0"

    text = TestText("""\
12345678
'
'""")

    # A string is not in code
    hp = HyperParser(text, text.index("'"))
    assert not hp.is_in_code()

    # The first char of a string is not in code
    hp = HyperParser(text, text.index("1"))
    assert hp.is_in_code()

    # The last char of

# Generated at 2022-06-12 13:02:37.471750
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-12 13:02:39.325419
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    parser = RoughParser("def f(x):\n    pass\n")
    assert parser.compute_bracket_indent() == 4


# Generated at 2022-06-12 13:07:11.624133
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # TODO: test all edge cases
    from unittest import TestCase

    class HPTest(TestCase):
        def do_test(self, text, index, expected):
            hp = HyperParser(text, index)
            self.assertEqual(hp.get_expression(), expected)

    hp_test = HPTest("do_test")
    hp_test.do_test("# Comment\n" "foo", "1.14", "")
    hp_test.do_test("# Comment\n" "foo", "1.15", "foo")
    hp_test.do_test("# Comment\n" "foo", "1.16", "foo")
    hp_test.do_test("# Comment\n" "foo", "2.0", "")

# Generated at 2022-06-12 13:07:19.748959
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    print("\nUnit test for method is_in_code of class HyperParser")

    def _test(text, index, is_in_code):
        hyperparser = HyperParser(text, index)
        found = hyperparser.is_in_code()
        assert found == is_in_code, "Test failed: " "\n%s" "\nindex: %s -> %s" "\nshould be: %s" % (
            text.dump(index),
            index,
            found,
            is_in_code,
        )

    def _test_expected(text, index, expected):
        hyperparser = HyperParser(text, index)
        found = hyperparser.get_expression()

# Generated at 2022-06-12 13:07:25.019530
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    def check(
        text,
        expected_indent,
        tabwidth=8,
        indent_width=4,
        # pylint: disable=redefined-builtin
    ):
        # Check for base case: the text has no newlines in it.
        # Indent is ignored and always returned as 0.
        if "\n" not in text:
            if text:
                raise ValueError("expected a newline")
            if expected_indent:
                raise ValueError("expected expected_indent to be 0")
            return

        parser = RoughParser(text, tabwidth, indent_width)
        indent = parser.compute_backslash_indent()

# Generated at 2022-06-12 13:07:34.085089
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-12 13:07:40.658286
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-12 13:07:42.822209
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from idlelib.idle_test.htest import run

    run(HyperParser, "HyperParser")

if __name__ == "__main__":
    test_HyperParser()

# Generated at 2022-06-12 13:07:48.333767
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-12 13:07:53.865722
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    h = HyperParser(TEXT, INSERT)
    h.set_index(INSERT)
    assert(h.indexbracket == 1)
    assert(h.indexinrawtext == 7)
    h.set_index(TEXT.index(INSERT + "-1c"))
    assert(h.indexbracket == 0)
    assert(h.indexinrawtext == 6)
    try:
        h.set_index(TEXT.index("1.0"))
        assert 0
    except ValueError:
        pass


# Generated at 2022-06-12 13:07:54.955963
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = EditorWindow(None, -1)

# Generated at 2022-06-12 13:08:04.077877
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    h = HyperParser("", "")

    h = HyperParser("def foo():\n x = 1", "1.0")
    h.set_index("1.4")
    assert h.get_expression() == ""
    assert not h.is_in_code()
    h.set_index("1.5")
    assert h.get_expression() == "def"
    assert h.is_in_code()
    h.set_index("1.8")
    assert h.get_expression() == "foo"
    assert h.is_in_code()
    h.set_index("1.10")
    assert h.get_expression() == ""
    assert h.is_in_code()
    h.set_index("1.11")
    assert h.get_expression() == ""
    assert not h