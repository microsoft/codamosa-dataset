

# Generated at 2022-06-12 12:58:56.351178
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-12 12:58:59.953990
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    parser = RoughParser("""a = b
  c = d
    def f():
        g()
    """)
    parser.indent_width = 4
    parser.tabwidth = 8
    assert parser.get_base_indent_string() == "  "


# Generated at 2022-06-12 12:59:04.299792
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    """Test passing a keyword parameter to set_lo of
    class RoughParser which is not a string."""
    # Create an instance of RoughParser.
    rough_parser = RoughParser()
    # Get the value of the original list of lines.
    original_lines = rough_parser.lines
    try:
        rough_parser.set_lo(99)
    except AssertionError:
        pass
    else:
        raise AssertionError("test failed")
    assert original_lines == rough_parser.lines

# Generated at 2022-06-12 12:59:05.565021
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    assert_raises(ValueError, HyperParser(0, 0).set_index, "1.end")

# Generated at 2022-06-12 12:59:11.666679
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def test(s, index, expected):
        parser = HyperParser(s, index)
        result = parser.get_surrounding_brackets()
        if result != expected:
            print(
                "get_surrounding_brackets('%s', %s) ==> '%s' (should be '%s')"
                % (s.get("1.0", Tkinter.END), index, result, expected)
            )

    tk = Tkinter.Text()
    test(tk, "1.0", None)
    test(tk, "2.0", ("1.0", "1.0"))
    tk.insert("1.0", "   ")
    test(tk, "2.0", ("1.0", "1.0"))

# Generated at 2022-06-12 12:59:18.496447
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():

    from test.test_support import findfile
    import unittest

    from idlelib.idle_test.mock_idle import Func

    # (functions which return callable)
    def find_good_parse_start(func):
        def _find_good_parse_start(self, startfind):
            return func(startfind)

        return _find_good_parse_start

    def None_or_int(_):
        return None

    def int_(_):
        return 2

    class Tests(unittest.TestCase):
        text = "ab\ncd"

        def test_one(self):
            hp = HyperParser(self.text, "1.0")
            hp.set_index("1.2")
            self.assertEqual(hp.indexbracket, 1)

# Generated at 2022-06-12 12:59:28.385566
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=redefined-builtin
    # pylint: disable=no-member
    import unittest

    from keyword import iskeyword

    from idlelib import rpc

    class MockIdlerpc(list):

        def is_scanning_completed(self):
            # pylint: disable=no-self-use
            return True

        def is_bad_start(self, i):
            return i in self

        def is_bad_end(self, i):
            return i in self




# Generated at 2022-06-12 12:59:36.046025
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    p = RoughParser("a = [\n1,\n2,\n3]\n")
    assert p.find_good_parse_start() == 0
    assert RoughParser("a = [\n1,\n2,\n3]\n").find_good_parse_start() == 0
    assert RoughParser("a = [\n1,\n2,\n3").find_good_parse_start() == 0
    assert RoughParser("a = [\n1,\n2,\n3,\n").find_good_parse_start() == 0
    assert RoughParser("a = (\n1,\n2,\n3]\n").find_good_parse_start() == 0
    assert RoughParser("a = [\n1,\n2,\n3)]\n").find_good

# Generated at 2022-06-12 12:59:42.578629
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text, index = "text", "1.0"

    # Test non-code characters.
    for i in "#,\"'":
        if i == "#":
            text = "\n" + i + "\n"
        else:
            text = i
        hp = HyperParser(text, index)
        assert not hp.is_in_code()

    # Test inside of a code.
    for i in "abcde":
        hp = HyperParser(i, index)
        assert hp.is_in_code()


# Generated at 2022-06-12 12:59:53.082947
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # String delimited by single quotes
    text = "'''stuff'''"
    h = HyperParser(text, "1.2")
    assert h.is_in_string()
    h.set_index("1.5")
    assert h.is_in_string()
    h.set_index("1.6")
    assert not h.is_in_string()
    # String delimited by double quotes
    text = '""stuff""'
    h = HyperParser(text, "1.2")
    assert h.is_in_string()
    h.set_index("1.5")
    assert h.is_in_string()
    h.set_index("1.6")
    assert not h.is_in_string()
    # String delimited by triple single quotes

# Generated at 2022-06-12 13:00:29.559932
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    class C:
        pass
    h = C()
    h.text = C()
    h.stopatindex = 100

    h.text.index = lambda x: x
    h.indexinrawtext = 10
    h.indexbracket = 11
    h.bracketing = [(5, 8), (10, 12)]
    h.isopener = [True, True]
    h.set_index(14.0)
    assert h.indexinrawtext == 11
    assert h.indexbracket == 1
    try:
        h.set_index(10.0)
        assert False  # Should raise ValueError
    except Exception:
        pass

    h.set_index(5.0)
    assert h.indexinrawtext == 5
    assert h.indexbracket == 0



# Generated at 2022-06-12 13:00:37.273308
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import idlelib.idle_test.mock_tk as tk
    text = tk.Text()
    text.insert("insert", "a=1\n")
    text.mark_set("insert", "1.0")
    parser = HyperParser(text, "insert")
    parser.set_index("1.0")
    #
    text.insert("insert", "1\n")
    text.mark_set("insert", "1.0")
    parser = HyperParser(text, "insert")
    parser.set_index("1.0")
    #
    text.insert("insert", "a=1")
    text.mark_set("insert", "1.0")
    parser = HyperParser(text, "insert")
    parser.set_index("1.0")
    #

# Generated at 2022-06-12 13:00:44.663944
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-12 13:00:52.046806
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest.mock import Mock
    from idlelib import parser
    import string

    def mock_text_get(start_index, stop_index):
        """Return the string between the two indexes.

        The indexes are not checked for validity, that must be done
        in the tests. The purpose of these tests is only to check the
        HyperParser.
        """
        return t[string.atoi(start_index) : string.atoi(stop_index)]

    # Mock a text editor.
    t = (
        # line 1
        "def f():\n"
        # line 2
        "    class_name = \"a string\"\n"
        # line 3
        "    return class_name\n"
    )
    text = Mock(indent_width=4, tabwidth=8)

# Generated at 2022-06-12 13:00:55.706110
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    if not True:
        parser = RoughParser("", 0, 0)
        parser.set_str("test-string")

    if True:
        parser = RoughParser("", 0, 0)
        parser.set_str("""test-string
        with
        three
        lines""")



# Generated at 2022-06-12 13:01:04.794900
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    assert RoughParser("#").get_last_open_bracket_pos() is None
    assert RoughParser("").get_last_open_bracket_pos() is None
    assert RoughParser("'''").get_last_open_bracket_pos() is None
    assert RoughParser("''' ").get_last_open_bracket_pos() is None
    assert RoughParser("  ''' ").get_last_open_bracket_pos() is None
    assert RoughParser("  ''''''").get_last_open_bracket_pos() is None
    # With open bracket
    assert RoughParser("  '''['''").get_last_open_bracket_pos() == 5
    # With open bracket, with unclosed bracket:
    assert RoughParser("  '''['''x").get_last_open_br

# Generated at 2022-06-12 13:01:14.776779
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # Insert some spaces after all the opening parens in a string,
    # to make sure that RoughParser works.
    def insert_spaces(s, n):
        r = cStringIO()
        for c in s:
            if c == "(":
                for i in range(n):
                    r.write(" ")
            else:
                r.write(c)
        return r.getvalue()

    # Test with various indentation widths
    for ind in range(5):
        text = insert_spaces(
            "d={'a'(1+2):\n  3*4\n{'b'(5+6):\n  7*8} }", ind
        )  # noqa: E501, W503  # this results in a line that's over 80 chars long

# Generated at 2022-06-12 13:01:23.573941
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-12 13:01:30.308069
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin
    from idlelib.config import idleConf
    parser = RoughParser(tabwidth=idleConf.GetOption("main", "TabWidth",
                                                    "IDLE", type="int"))
    parser.set_str('''if 1:
        if 1:
            if 1:
                pass
''')
    assert parser.compute_bracket_indent() == 12

    parser.set_str('''if 1:
    if 1:''')
    assert parser.compute_bracket_indent() == 8

    parser.set_str('''if True:
    callfunc(x,y)
    # comment
''')
    assert parser.compute_bracket_indent() == 8


# Generated at 2022-06-12 13:01:39.445102
# Unit test for constructor of class HyperParser
def test_HyperParser():
    class DummyEditwin:
        def __init__(self):
            self.text = SimpleEditor()
            self.indentwidth = 8
            self.tabwidth = 8

    editwin = DummyEditwin()
    editwin.text.insert("1.0", """\
if x == 2:
    pass
a = 2 + \
3
""")

    # Check index at "if" and "2" in first line and "a" in second line
    for index in ("1.3", "1.5", "2.0"):
        parser = HyperParser(editwin.text, index)
        # Check parser.rawtext
        assert parser.rawtext.endswith("\n")
        assert len(parser.rawtext) == len(editwin.text.get("1.0", "4.0"))
       

# Generated at 2022-06-12 13:02:21.626302
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin,pointless-statement,undefined-variable
    rp = RoughParser("foo\n  \\", tabsize=4)  # tabsize must be positive
    assert rp.compute_backslash_indent() == 2
    rp = RoughParser("bar\n\\")
    assert rp.compute_backslash_indent() == 0
    rp = RoughParser("if a:\n  foo(a,\n      b,\n      c,\n      d\n     )\n")
    assert rp.compute_backslash_indent() == 4



# Generated at 2022-06-12 13:02:23.079516
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import tkinter
    import unittest
    from idlelib import hyperparser


# Generated at 2022-06-12 13:02:24.354802
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-12 13:02:31.800823
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    EQ = EqualTests.EQ
    h = HyperParser("x", "1.0")
    EQ("", h.get_expression())
    h.set_index("1.1")
    EQ("x", h.get_expression())
    h.set_index("1.2")
    EQ("", h.get_expression())
    h.set_index("1.0")
    h.text.insert("1.2", "*2")
    h.set_index("1.5")
    EQ("*2", h.get_expression())
    h.set_index("1.0")
    h.text.insert("1.2", "2*")
    h.set_index("1.5")
    EQ("x", h.get_expression())

# Generated at 2022-06-12 13:02:38.107713
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Test a very simple case
    text = Text("(a)")
    parser = HyperParser(text, "1.1")
    assert parser.get_surrounding_brackets() == ("1.0", "2.0")

    # Test that get_surrounding_brackets doesn't skip lines
    text = Text("(a)\n(b)")
    parser = HyperParser(text, "1.1")
    assert parser.get_surrounding_brackets() == ("1.0", "2.0")

    # Test that get_surrounding_brackets handles nested parentheses
    text = Text("(a(b))")
    parser = HyperParser(text, "1.3")
    assert parser.get_surrounding_brackets() == ("1.0", "4.0")

    # Test that get

# Generated at 2022-06-12 13:02:44.366904
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class HyperParserTest(TestCase):
        def test_identifiers(self):
            self.assertEqual(HyperParser._eat_identifier("", 0, 0), 0)
            self.assertEqual(HyperParser._eat_identifier("a", 0, 1), 1)
            self.assertEqual(HyperParser._eat_identifier("a", 0, 0), 0)
            self.assertEqual(HyperParser._eat_identifier("a2", 0, 2), 2)
            self.assertEqual(HyperParser._eat_identifier("a_", 0, 2), 2)
            self.assertEqual(HyperParser._eat_identifier("a_2", 0, 3), 3)

# Generated at 2022-06-12 13:02:51.304328
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """Unit test for method set_index of class HyperParser.

    This test was originally based on the code of method test_set_index
    of class PyParse_TestCase, in test_all.py. However, since two
    PyParse_TestCase instances were needed to test set_index, it was
    necessary to modify the test to use HyperParser instead of
    PyParser.

    Modified by G. Thomas, 31-Mar-2006.
    """

    import unittest

    class HyperParser_TestCase(unittest.TestCase):
        def setUp(self):
            self.text = EditorWindow(None)
            self.text.set_indentation_params(1, 4, 0)
            self.parser = HyperParser(self.text, "1.0")


# Generated at 2022-06-12 13:02:58.293090
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    def t(s, width):
        p = RoughParser(s, width)
        return p.compute_backslash_indent()
    # Test line with no \ and no assignment
    assert t("\n" * 3 + "foo(x)", 4) == 4
    # Test line with no \ and assignment
    assert t("\n" * 3 + "foo = bar", 4) == 9
    # Test line with \ and assignment
    assert t("\n" * 3 + "foo = bar\\\n" + " " * 8 + "baz", 4) == 12
    # Test line with \ and no assignment
    assert t("\n" * 3 + "foo(x)\\\n" + " " * 8 + "baz", 4) == 12
    # Test line with \, no assignment and no indentation
    assert t

# Generated at 2022-06-12 13:03:03.419401
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    """Unit test for method is_block_opener of class RoughParser."""
    # pylint: disable=redefined-builtin
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=cell-var-from-loop
    # pylint: disable=undefined-loop-variable
    tests = [("abc()", "abc(xx)", 0, 0), ("if a:", "if a:", 1, 0), ("if a:", "if a: pass", 0, 0), ("def xyz(", "def xyz(xyz):", 0, 1)]

# Generated at 2022-06-12 13:03:11.645244
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def setUp(self):
            self.text = "a = 3\n"

        def _test(self, index, is_in_string, is_in_code):
            p = HyperParser(self.text, index)
            self.assertEqual(p.is_in_string(), is_in_string)
            self.assertEqual(p.is_in_code(), is_in_code)
            return p

        def test_parsing(self):
            self._test("1.0", False, True)
            self._test("1.1", False, True)
            self._test("1.2", False, True)
            self._test("1.3", False, False)


# Generated at 2022-06-12 13:05:40.581160
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    p = RoughParser()
    p.set_str("\\\n      x = 1\\\n        + 2")
    assert p.get_num_lines_in_stmt() == 3
    assert p.compute_backslash_indent() == 8  # "      "

    p.set_str("\\\n        x = 1\\\n      + 2")
    assert p.get_num_lines_in_stmt() == 3
    assert p.compute_backslash_indent() == 8  # "        "

    p.set_str("\\\n    x = 1\\\n          + 2")
    assert p.get_num_lines_in_stmt() == 3
    assert p.compute_backslash_indent()

# Generated at 2022-06-12 13:05:49.176474
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rp = RoughParser("if 1:  \n")
    assert rp.compute_bracket_indent() == 3
    rp = RoughParser("if 1:  # comment\n")
    assert rp.compute_bracket_indent() == 3
    rp = RoughParser("if 1:  \n  \n")
    assert rp.compute_bracket_indent() == 3
    rp = RoughParser("if 1:  # comment\n  \n")
    assert rp.compute_bracket_indent() == 3
    rp = RoughParser("if 1:  \n  2\n")
    assert rp.compute_bracket_indent() == 3
    rp = RoughParser("if 1:  # comment\n  2\n")
    assert rp

# Generated at 2022-06-12 13:05:57.982963
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    """Test get_expression of class HyperParser"""

    def create_HyperParser(t, i):
        """Create a HyperParser for text t and index i"""
        text = tk.Text()
        text.insert(tk.END, t)
        return HyperParser(text, i)

    def get_expression(t, i):
        """Get the expression in string t at index i"""
        return create_HyperParser(t, i).get_expression()

    def _get_expression(t, i):
        """Get the expression in string t at index i

        This is the same as get_expression, but without testing
        correct raising of exceptions.
        """
        hp = create_HyperParser(t, i)
        hp.is_in_code()
        return hp.get_expression()


# Generated at 2022-06-12 13:06:04.833759
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # define test strings
    text = """
    # comment
    if foo in aaa:
        print(foo)"""

    text0 = text + "\n"
    text1 = text0[:-6]
    text2 = text1[:-7]
    text3 = text2[:-4]
    text4 = text3[:-4]
    text5 = text4[:-5]
    text6 = text5[:-4]
    text7 = text6[:-5]
    text8 = text7[:-4]
    text9 = text8[:-8]

    template = """\
    test get_surrounding_brackets:
    string: {string}
    index:  {index}
    result: {answer}
    """


# Generated at 2022-06-12 13:06:14.085790
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    from lib2to3.pgen2.parse import ParseError
    from lib2to3.pygram import python_symbols as syms, python_grammar

    def _find_good_parse_start(code):
        p = RoughParser(python_grammar)
        st = p.find_good_parse_start(code)
        if st is not None:
            grammar = p.pgen.grammar
            # Find the start symbol.
            start_symbol = -1
            for idx, (sym, _, _, _) in enumerate(grammar.number2symbol.items()):
                if sym == syms.file_input:
                    start_symbol = idx
                    break
            assert start_symbol > -1, "Couldn't find start symbol"
            # And parse!
           

# Generated at 2022-06-12 13:06:23.028832
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.text = TextMockup()
            self.hp = HyperParser(self.text, "1.0")

        def set_index(self, index):
            self.text.set("")
            self.hp.set_index(index)

        def check(self, raw, expected, index="insert"):
            self.text.set(raw)
            self.set_index(index)
            self.assertEqual(self.hp.get_expression(), expected, raw)

        def test_empty(self):
            self.check("", "")

        def test_at_eol(self):
            self.check("abc", "abc", "3.0")


# Generated at 2022-06-12 13:06:31.457123
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    for i in range(1, 6):
        rp = RoughParser(
            "abc",
            indent_width=i,
        )
        # test method set_lo of class RoughParser
        rp.set_lo(1)
        assert rp.str == "ab\n", "rp.str != ab\n"
        assert rp.goodlines == [1, 2], "rp.goodlines != [1, 2]"
        assert rp.study_level == 0, "rp.study_level != 0"
        rp.set_lo(6)
        assert rp.str == "\n", "rp.str != \n"
        assert rp.goodlines == [1, 2], "rp.goodlines != [1, 2]"

# Generated at 2022-06-12 13:06:38.435011
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from idlelib import hyperparser

    def parenmatch_fwd_helper(
        self, index, openers="([{", ignore_string=False, ignore_comment=False
    ):
        if not openers:
            # Fallback for compatibility with older versions.
            return self.parenmatch(index)
        hp = hyperparser.HyperParser(self.text, index)
        if not (ignore_comment and hp.is_in_code()) and not (ignore_string and hp.is_in_string()):
            return hp.get_surrounding_brackets(openers, mustclose = True)

    return parenmatch_fwd_helper


if __name__ == "__main__":
    import unittest

# Generated at 2022-06-12 13:06:48.397412
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-12 13:06:57.799439
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = """\
lst = [
        [x1, x2, x3],
        [x4, x5, x6]
]
"""
    assert (1, 6) == HyperParser(text, "3.0").get_surrounding_brackets()
    assert (1, 6) == HyperParser(text, "3.5").get_surrounding_brackets()
    assert (1, 8) == HyperParser(text, "2.0").get_surrounding_brackets()
    assert (1, 8) == HyperParser(text, "2.5").get_surrounding_brackets()
    assert (1, 8) == HyperParser(text, "4.0").get_surrounding_brackets()
    assert (1, 8) == HyperParser(text, "4.5").get_