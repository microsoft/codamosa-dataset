

# Generated at 2022-06-12 12:58:11.170995
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-12 12:58:20.097520
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    "Unit test for method get_expression of class HyperParser"

    class DummyEditWin:
        "Dummy editing window"

        def __init__(self, text):
            self.text = text
            self.indentwidth = 8
            self.tabwidth = 8

        def get(self, index1, index2):
            return self.text.get(index1, index2)

        def index(self, index):
            return index

    def hp_get_expression(text, index):
        "Return the expression of a hyperparser at a given place"
        hp = HyperParser(DummyEditWin(text), index)
        return hp.get_expression()

    assert hp_get_expression("", "1.0") == ""
    assert hp_get_expression("''", "1.0") == ""
    assert hp_

# Generated at 2022-06-12 12:58:25.015630
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    if not pytest.config.getvalue("verbose"):
        pytest.skip("py.test -v needed to run some tests")

    text = '''
    if 1 == 1:
        if 2 == 2:
            if 3 == 3:
                return
    # comment
    '''
    parser = RoughParser(text, 0)
    assert parser.get_continuation_type() == C_NONE
    assert parser.compute_backslash_indent() == 8
    assert parser.get_num_lines_in_stmt() == 4
    assert parser.get_base_indent_string() == '        '
    assert parser.is_block_opener()
    assert not parser.is_block_closer()
    assert parser.get_last_open_bracket_pos() is None
    assert parser

# Generated at 2022-06-12 12:58:30.350505
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    from lib2to3.pgen2.tokenize import TokenError
    from test.test_tokenize import generate_tokens, untokenize
    from io import StringIO
    from token import OP, ENCODING, COMMENT
    from tokenize import tokenize, untokenize
    from lib2to3.fixer_util import BlankLine
    from lib2to3 import pgen2
    if sys.version_info[:2] > (3, 5):
        from tokenize import NUMBER, NAME
        from lib2to3.fixer_util import String
    else:
        from lib2to3.pgen2.token import NUMBER, NAME
        from token import NUMBER, NAME
        from lib2to3.pygram import python_symbols as syms
        from lib2to3.pytree import Leaf


# Generated at 2022-06-12 12:58:31.448651
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    res=RoughParser()

# Generated at 2022-06-12 12:58:37.348536
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-12 12:58:42.313297
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = "if 1:\n    x = [\n        1, 2, 3]\n"
    textwidget = tkinter.Text()
    textwidget.insert("1.0", text)
    text = textwidget
    # The following values of i give the expected result in comment:
    for i in range(9, 38):
        text.mark_set("insert", "%d.0" % i)
        hp = HyperParser(text, "insert")
        print("-" * 60)
        print("INDEX %d:" % i)
        print("The string is: %r" % hp.rawtext)
        print("The bracketing is: %r" % hp.bracketing)
        print("The isopener is: %r" % hp.isopener)

# Generated at 2022-06-12 12:58:51.221145
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest

    class Test_set_index(unittest.TestCase):
        def test_basic(self):
            text = TextWidget(None)
            text.set("# A comment\n" "some.expression(and a function call)")
            hp = HyperParser(text, "1.0")
            hp.set_index("1.0")
            self.assertEqual(hp.indexinrawtext, 0)
            hp.set_index("1.7")
            self.assertEqual(hp.indexinrawtext, 7)
            hp.set_index("1.15")
            self.assertEqual(hp.indexinrawtext, 15)
            hp.set_index("1.16")
            self.assertEqual(hp.indexinrawtext, 16)
            hp.set_index

# Generated at 2022-06-12 12:59:00.421796
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    text.insert("1.0", "first\n\tsecond\nthird\n")
    parser = HyperParser(text, "2.0")
    assert parser.bracketing == [
        (0, 0),
        (5, 0),
        (6, 0),
        (7, 0),
        (8, 0),
        (9, 0),
        (10, 0),
        (11, 0),
        (12, 0),
        (13, 0),
        (14, 0),
    ]
    assert parser.rawtext == "second"
    assert parser.stopatindex == "3.end"
    parser.set_index("2.12")
    assert parser.indexbracket == 9
    assert parser.indexinrawtext == 5

# Generated at 2022-06-12 12:59:07.471078
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # An ordinary expression
    assert HyperParser(Tk, "1.0").is_in_code() == True
    # Inside a string
    assert HyperParser(Tk, "1.0").is_in_code() == True
    # Inside a comment
    assert HyperParser(Tk, "1.0").is_in_code() == True
    # At an operator, should be considered as in code
    assert HyperParser(Tk, "1.0").is_in_code() == True
    # ** not allowed as an exponent
    assert HyperParser(Tk, "1.0").is_in_code() == True
    #\ not allowed unescaped in an string
    assert HyperParser(Tk, "1.0").is_in_code() == True
    # + not allowed in front of a dot
    assert HyperParser

# Generated at 2022-06-12 12:59:40.290266
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    import unittest

    class TestSetLo(unittest.TestCase):

        def test_set_lo(self):
            import re


# Generated at 2022-06-12 12:59:46.839610
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    class Mock_Indentation:

        def __init__(self, tab_width=4, indent_width=4):
            self.tab_width = tab_width
            self.indent_width = indent_width

    def test(s, tab_width=4, indent_width=4, expected_result=None):
        result = RoughParser(s, Mock_Indentation(tab_width, indent_width)).compute_bracket_indent()
        assert expected_result is None or result == expected_result

    test("[\n]")
    test("(\n)")
    test("{\n}")
    test("[\nx]")
    test("[\n    x]")
    test("(\nx\n)")
    test("(\nx\n)\n")

# Generated at 2022-06-12 12:59:48.504787
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    text = """if True:\n    class X:\n        assert True\n    """
    rp = RoughParser(text, 0)
    assert rp.is_block_closer() == False


# Generated at 2022-06-12 12:59:58.200766
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-12 13:00:00.058156
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rp = RoughParser("\n\n")
    assert rp.get_num_lines_in_stmt() == 2



# Generated at 2022-06-12 13:00:06.963110
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-12 13:00:17.403988
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():

    def _get_brackets(s, index, mustclose=False):
        return HyperParser(Tkinter.Text(None), s.index(index)).get_surrounding_brackets(
            mustclose=mustclose
        )


# Generated at 2022-06-12 13:00:19.299830
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    r = RoughParser("def foo():\n    if x:\n        for j in range(4):", 4)
    assert r.get_last_open_bracket_pos() == 12
    # TODO: test with tabs
    # TODO: finish adding tests


# Generated at 2022-06-12 13:00:20.988521
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    parser = RoughParser()
    parser.set_lo("print('a')")
    return parser.is_block_opener()



# Generated at 2022-06-12 13:00:27.470471
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    class MockText:

        IDENTIFIER_COLOR = "#000000"

        def __init__(self, txt):
            self.txt = txt
            self.tw = 8

        def index(self, ind):
            return ind

        def get(self, ind1, ind2):
            return self.txt[ind1 : ind2]

        def tag_nextrange(self, tagname, ind1, ind2=None):
            pass

        def tag_remove(self, tagname, ind1, ind2):
            pass

        def get_idents(self, ind1, ind2):
            pos = ind1
            while pos < ind2:
                ret = HyperParser._eat_identifier(self.txt, ind1, pos)
                if ret:
                    yield pos, pos + ret
                pos += 1


# Generated at 2022-06-12 13:01:25.951848
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    parser = RoughParser("f(1+\n2,\n3)")
    result = parser.compute_bracket_indent()
    assert result == 1, result

    parser = RoughParser("f(\n1+\n2,\n3\n)")
    result = parser.compute_bracket_indent()
    assert result == 1, result

    parser = RoughParser("f(1+\n2+\n3,\n4\n)")
    result = parser.compute_bracket_indent()
    assert result == 2, result

    parser = RoughParser("f(1+\n2,\n3)\n")
    result = parser.compute_bracket_indent()
    assert result == 1, result


# Generated at 2022-06-12 13:01:34.161087
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    """

    """
    ROUGH_PARSER = RoughParser
    assert ROUGH_PARSER.find_good_parse_start('bla', 0) == 0
    assert ROUGH_PARSER.find_good_parse_start('bla\nblu\n', 0) == 0
    assert ROUGH_PARSER.find_good_parse_start('bla\nblu\n', 1) == 0
    assert ROUGH_PARSER.find_good_parse_start('bla\nblu\n', 2) == 0
    assert ROUGH_PARSER.find_good_parse_start('bla\nblu\n', 4) == 4
    assert ROUGH_PARSER.find_good_parse_start('bla\nblu\n', 5) == 4
    assert ROUGH_PARSER.find_good_parse_

# Generated at 2022-06-12 13:01:43.337012
# Unit test for constructor of class HyperParser
def test_HyperParser():
    s = "def f():\n'''doc'''\n"
    h = HyperParser(s, "2.6")
    h.set_index("1.6")
    assert h.get_surrounding_brackets(mustclose=True) == ("1.1", "2.end")
    h.set_index("2.0")
    assert h.get_surrounding_brackets(mustclose=True) == ("1.1", "2.end")
    assert h.get_surrounding_brackets() == ("1.1", "2.end")
    h.set_index("2.6")
    assert h.get_surrounding_brackets() == ("2.0", "2.end")
    h.set_index("2.9")
    assert h.get_surrounding

# Generated at 2022-06-12 13:01:46.587040
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    RoughParser.get_base_indent_string(RoughParser("")) == ""
    RoughParser.get_base_indent_string(RoughParser("    ")) == "    "
    RoughParser.get_base_indent_string(RoughParser("\t")) == "\t"

# Generated at 2022-06-12 13:01:57.747706
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    p = RoughParser("", 0)
    p.str = "some_string = '''\\\n"
    p.indent_width = 8
    assert p.compute_backslash_indent() == 8

    p = RoughParser("", 0)
    p.str = "some_string = '''\\\n"
    p.indent_width = 4
    assert p.compute_backslash_indent() == 4

    p = RoughParser("", 0)
    p.str = "some_string = '''\\\n"
    p.indent_width = 2
    assert p.compute_backslash_indent() == 2

    p = RoughParser("", 0)
    p.str = "some_string = '''\\\n"
    p.indent_width = 1


# Generated at 2022-06-12 13:02:05.124541
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest
    from Tkinter import Text
    from test.support import run_unittest

    # This class will be used by unittest to verify the proper
    # operation of get_surrounding_brackets

    class HyperParser_get_surrounding_brackets_TestCase(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            root = tktools.make_tk()
            text = Text(root)

            text.insert(1.0, "a[b] c() d'e' f\"g\" ")
            text.insert(6.0, "h['i']")
            text.insert(9.0, " j(k\"l\")")
            text.insert(12.0, " m'n(\"o\")'")


# Generated at 2022-06-12 13:02:12.400694
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    # pylint: disable=redefined-builtin

    def check(string, expected):
        parser = RoughParser(string)
        r = parser.get_base_indent_string()
        assert r == expected, "for input %r, expected %r, got %r" % (string, expected, r)

    check("", "")
    check("\n", "")
    check(" \n", " ")
    check("\t\n", "\t")
    check("a\n", "")
    check(" a\n", " ")
    check("\t\na", "\t")

    check("\tdef foo():\n", "\t")
    check(" \tdef foo():\n", " \t")
    check("\n\tdef foo():\n", "\t")

# Generated at 2022-06-12 13:02:19.428482
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def check_get_surrounding_brackets(text, index, brackets, *args):
        parser = HyperParser(text, index)
        brackets_found = parser.get_surrounding_brackets(*args)
        brackets_found = (
            brackets_found
            if brackets_found is None
            else (text.index(brackets_found[0]), text.index(brackets_found[1]))
        )
        assert brackets == brackets_found

    def check_get_surrounding_brackets_failure(text, index, *args):
        parser = HyperParser(text, index)
        assert parser.get_surrounding_brackets(*args) is None

    # Various cases where the method should succeed (return a valid
    # pair of indices)
    t = "([])"
    check_get_sur

# Generated at 2022-06-12 13:02:27.712804
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-12 13:02:34.636607
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    import unittest

    class TestCase(unittest.TestCase):
        def test(self):
            text = "<<<" + repr(self.text) + ">>>"
            index = "<<<" + self.index + ">>>"
            expect = self.expect
            result = HyperParser(text, index).is_in_string()
            self.assertEqual(result, expect, "%r != %r for %r" % (result, expect, self))

        def __repr__(self):
            return "HyperParser_is_in_string(%r, %r)" % (self.text, self.index)


# Generated at 2022-06-12 13:05:40.059013
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    parser = RoughParser("")
    def case(text, expected):
        parser.str = text
        parser._study2()  # pylint: disable=protected-access
        assert parser.is_block_closer() == expected
    case("", False)
    case("\n", False)
    case("\n\n", False)
    case("\n\n\n", False)
    case("a", False)
    case("a\n", False)
    case("a\n\n", False)
    case("a\n\n\n", False)
    case("a # comment\n", False)
    case("a # comment\n\n", False)
    case("a # comment\n\n\n", False)
    case("a # comment\n\n\n", False)
   

# Generated at 2022-06-12 13:05:48.615635
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from unittest.mock import Mock

    def HyperParser_get_surrounding_brackets_test(s, *args, **kwargs):
        t = Mock()
        t.get.return_value = s
        t.index = lambda index: str(len(s) - len(t.get(index, "end")))
        hp = HyperParser(t, "end")
        return hp.get_surrounding_brackets(*args, **kwargs)

    # There are no brackets.
    res = HyperParser_get_surrounding_brackets_test("abc")
    assert res is None

    # There is only an opening bracket.
    res = HyperParser_get_surrounding_brackets_test("(abc")
    assert res is None

    # There is an empty expression.
    res = HyperParser

# Generated at 2022-06-12 13:05:57.411933
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():

    def make_parser(text, index):
        "Create HyperParser instance and call set_index with given index."

        parser = HyperParser(text, index)
        parser.set_index(index)
        return parser

    def index_of(text, char):
        "The index in text right before char, if present, else None."

        if char in text:
            return "%d.0" % (text.index(char) + 1)
        return None

    # The following are tests for the parser, in various forms.

    # These examples test strings.
    # Index is before "s".
    parser = make_parser("s'", "1.0")
    assert parser.is_in_string(), "Error 1a"
    # Index is before 's'.
    parser = make_parser("s'", "1.1")


# Generated at 2022-06-12 13:06:04.423273
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import textwrap

    # Tuple is:
    # 0 - the expression
    # 1 - the string after it
    # 2 - the index of the cursor in the string
    # 3 - the expected result of get_expression

# Generated at 2022-06-12 13:06:13.660946
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-12 13:06:21.444084
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text()
    text.insert("insert", "blah")
    text.insert("insert", "\"");
    text.insert("insert", "blah")
    text.insert("insert", "\'");
    text.insert("insert", "blah")
    text.insert("insert", "\"");
    text.insert("insert", "blah")
    text.insert("insert", "\"");
    text.insert("insert", "blah")
    text.insert("insert", "\"");
    text.insert("insert", "blah")
    text.insert("insert", "\"")

    run_unittest(HyperParser_is_in_code)


# Generated at 2022-06-12 13:06:29.933133
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-outer-name

    def doit(text, klass):
        # pylint: disable=redefined-builtin

        rp = RoughParser(text, klass.indent_width, klass.tabwidth)
        if rp.get_continuation_type() != C_BRACKET:
            print("Warning: input doesn't end in bracket continuation")
        return rp.compute_bracket_indent()

    def dofile(fn, klass):
        # pylint: disable=redefined-builtin
        # pylint: disable=redefined-outer-name

        with open(fn) as f:
            src = f.read()
        rp = RoughParser(src, klass.indent_width, klass.tabwidth)

# Generated at 2022-06-12 13:06:37.077256
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import TestCase

    class _TestCase(TestCase):
        def assertInCode(self, s, index):
            hp = HyperParser(s, index)
            self.assertEqual(hp.is_in_code(), True)

        def assertNotInCode(self, s, index):
            hp = HyperParser(s, index)
            self.assertEqual(hp.is_in_code(), False)


# Generated at 2022-06-12 13:06:39.554973
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Tk.Text()
    HyperParser(text, "1.0")


if __name__ == "__main__":
    from unittest import main

    main("idlelib.idle_test.test_hyperparser", verbosity=2, exit=False)

    from idlelib.idle_test.htest import run

    run(HyperParser)

# Generated at 2022-06-12 13:06:49.353188
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    rp = _RoughParser()
    test_closures = [
        ("if True:", False),
        ("if True:\n  pass", True),
        ("if True:\n  pass\n", True),
        ("# if True:\n  pass\n", False),
        ("if True:\n  pass\n#  pass\n", False),
        ("if True:\n  pass\n#  pass\n\n", True),
        ("if True:\n  pass\n#  pass\n\n\n", True),
        ("a = 1", False),
        ("a =\n  1", True),
        ("pass\n# comment\n", True),
        ("pass\n# comment", False),
        ("pass\n\n", True),
    ]