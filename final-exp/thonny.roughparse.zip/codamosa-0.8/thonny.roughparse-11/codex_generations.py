

# Generated at 2022-06-12 12:58:43.638304
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(preserve_dict) == len(mapping)


# Generated at 2022-06-12 12:58:47.482836
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    assert StringTranslatePseudoMapping({}, None).__len__() == 0
    assert StringTranslatePseudoMapping({1: 0}, None).__len__() == 1
    assert StringTranslatePseudoMapping({1: 0, 2: 2}, None).__len__() == 2

# Generated at 2022-06-12 12:58:50.184688
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    mapping = StringTranslatePseudoMapping({ord('a'): ord('A')}, ord('x'))
    assert set(mapping) == {ord('a')}



# Generated at 2022-06-12 12:58:52.701815
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    assert_raises(ValueError, lambda: HyperParser(Tkinter.Text(), "1.0").set_index("2.0"))



# Generated at 2022-06-12 12:59:01.689915
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from idlelib.idle_test.htest import unittest
    from idlelib.idle_test.mock_idle import Fn

    class Test(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            # The fc when ran as a unit test has no root
            if tkinter.TkVersion < 8.6:
                cls.root = tkinter.Tk()
                cls.root.withdraw()
            cls.text = tkinter.Text()
            cls.text.insert("insert", "def f(x):\n    return x + 1\n\nf")
            #                           0123456789012345678901234567890

        @classmethod
        def tearDownClass(cls):
            cls.text

# Generated at 2022-06-12 12:59:06.386505
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():

    # Test invalid input
    # noinspection PyTypeChecker
    assert StringTranslatePseudoMapping(dict(), ' ').__len__() == 0
    assert StringTranslatePseudoMapping(dict(), ' ').__len__() == 0
    # noinspection PyTypeChecker
    assert StringTranslatePseudoMapping({}, ' ').__len__() == 0

    # Test valid input
    assert StringTranslatePseudoMapping({ord('a'): 'a'}, ' ').__len__() == 1


# Generated at 2022-06-12 12:59:12.340248
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    """Unit test for method is_in_string of class HyperParser"""
    import sys, traceback
    import unittest

# Generated at 2022-06-12 12:59:13.708405
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    hp = HyperParser(TestText, "1.16")
    assert hp.is_in_string()



# Generated at 2022-06-12 12:59:22.095283
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-12 12:59:28.353688
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    non_defaults = {ord(c): ord(c) for c in 'a ab'}
    default_value = ord('x')
    whitespace = StringTranslatePseudoMapping(non_defaults, default_value)
    assert whitespace[ord('x')] == ord('x')
    assert whitespace[ord('a')] == ord('a')
    assert whitespace[ord('b')] == ord('b')

# Generated at 2022-06-12 13:00:20.449845
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest

    class HyperParser_set_index_Test(unittest.TestCase):
        # Tests for set_index

        def setUp(self):
            self.parser = HyperParser("", "")

        def test_argument_type(self):
            # The method should raise a ValueError if the given index
            # is not a string.
            self.assertRaises(TypeError, self.parser.set_index, 0)
            self.assertRaises(TypeError, self.parser.set_index, ())

        def test_argument_value(self):
            # The method should raise a ValueError if the given index
            # is not a valid index of the text.
            self.parser.text = "xyz"
            self.assertRaises(ValueError, self.parser.set_index, "2.1")

# Generated at 2022-06-12 13:00:26.941735
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-12 13:00:34.071280
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
  from _ast import Module
  from ast import literal_eval
  from tokenize import tokenize, untokenize
  from io import BytesIO

  from .test import get_test_cases
  from .indent import ModuleIndenter

  for name, test in get_test_cases("test_module_indenter").items():
    try:
      node = Module(
        body=[literal_eval(test["code"])]
      ).body[0]
    except SyntaxError:
      continue
    else:
      break
  else:
    raise KeyError("not found")

  stream = BytesIO(untokenize(tokenize(test["code"])).encode("utf-8"))
  indent_width = test["config"]["indent_width"]
  tab_width = test["config"]["tab_width"]


# Generated at 2022-06-12 13:00:41.811906
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    text.insert("1.0", """\
if 1:
    if 2:
        if 3:
            if 4:
                if 5:
                    pass
        if 6:
            pass
    if 7:
        pass
if 8:
    pass
""")
    p = HyperParser(text, "1.0")
    p.set_index("1.0")
    assert p.indexbracket == 0
    assert p.indexinrawtext == 0
    p.set_index("1.15")
    assert p.indexbracket == 0
    assert p.indexinrawtext == 15
    p.set_index("1.1")
    assert p.indexbracket == 0
    assert p.indexinrawtext == 1

# Generated at 2022-06-12 13:00:48.895263
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str = """\
    if a:
        if b:
            stmt
    """
    # line starts with if
    rp = RoughParser(str, 4)
    assert rp.compute_backslash_indent() == 4
    # line starts with elif
    str = """\
    if a:
        if b:
            stmt
    elif c:
        stmt
    """
    rp = RoughParser(str, 8)
    assert rp.compute_backslash_indent() == 4
    # multi-line if
    str = """\
    if a==4 and \
        b==5 and \
        c==6:
        stmt
    """
    rp = RoughParser(str, 8)
    assert rp.compute_backslash_indent()

# Generated at 2022-06-12 13:00:58.342703
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    import re
    from test.libregrtest.refleak import NO_LEAK

    # compile all of the regular expressions used by find_good_parse_start
    # locally to avoid crashing non-C locale platforms
    _junkre = re.compile(
        r"([ \t]*#.*)|" "([ \t]*\\\n)|" r"([ \t]*\n)|" r"([ \t]*$)")

# Generated at 2022-06-12 13:01:07.714706
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    content = """\
    foo = 3
    bar = [
      1,
      2,
      [3, 4],
      (5, 6),
      (7,
      8),
      {
        9 : 10,
        11 : 12
      }
    ]
    baz = {
      1 : {
        2 : 3
      }
    }
    """
    curr_index = 5.0
    max_index = tk.IntVar()
    max_index.set(len(content))
    text = FakeText(content, max_index=max_index)
    hp = HyperParser(text, curr_index)
    assert hp.is_in_code()
    assert not hp.is_in_string()
    assert hp.get_expression() == "foo"
    assert hp.get_

# Generated at 2022-06-12 13:01:17.138805
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    line_offset = set([2, 3, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 21, 22, 24, 25, 26, 27])
    rp = RoughParser('''\
    def foo(self):
        a = 1 + 2 + 3
        b = 1 + 2 + 3
        c = 1 + 2 + 3
        d = 1 + 2 + 3
    ''', tabsize=4, line_offset=line_offset)
    print ("line_offset=", line_offset)
    print ("line_offset=%s, line_number=%d, p=0" % (str(rp.line_offset), rp.get_line_number(0)))

# Generated at 2022-06-12 13:01:25.650654
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    assert RoughParser(
        "foo = {'bar':"
    ).get_last_open_bracket_pos() == 4
    assert RoughParser(
        "foo = {'bar':"
    ).get_last_open_bracket_pos() == 4
    assert RoughParser(
        "foo = {'bar':"
    ).get_last_open_bracket_pos() == 4
    assert RoughParser(
        "foo = {'bar':"
    ).get_last_open_bracket_pos() == 4
    assert RoughParser(
        "foo = {'bar':"
    ).get_last_open_bracket_pos() == 4
    assert RoughParser(
        "foo = {'bar':"
        "lambda x:"
    ).get_last_open_bracket_pos() == 14
   

# Generated at 2022-06-12 13:01:33.692799
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from idlelib.idle_test.mock_idle import Func
    from unittest import mock
    from unittest.mock import call
    from idlelib.idle_test.mock_tk import Mbox_func
    with mock.patch('idlelib.hyperparser.RoughParser',
                    side_effect=IndexError('next')):
        hp = HyperParser("", index="")
        with mock.patch('idlelib.hyperparser.tkMessageBox.showerror',
                        side_effect=Mbox_func):
            hp.is_in_code()
            assert call("Idle Internal Error:", index="") in Mbox_func.mbox


# Generated at 2022-06-12 13:02:44.237494
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    # Set up.
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.CRITICAL)
    got_it = "textwrap.dedent got it"
    expect = "'" + got_it + "'."
    fail_msg = "textwrap.dedent failed to get"

    # Verify that textwrap.dedent is working.

# Generated at 2022-06-12 13:02:51.191493
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-12 13:02:55.193336
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # test method is_in_string of class HyperParser
    text = u"def apa():\n    if True:\n        pass\n        if False:\n pass"
    for i, ch in enumerate(text, 1):
        hp = HyperParser(text, str(i) + "." + ch)
        assert hp.is_in_string() == (ch in "\"'")



# Generated at 2022-06-12 13:03:02.248043
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    l = "abcdefghijklmnopqrstuvwxyz"
    text = Text(l)
    text.insert("end", " " + l)
    for i in range(len(l)):
        print(i)
        hp = HyperParser(text, "1.%d" % i)
        print(hp.get_surrounding_brackets(mustclose=0))
        hp = HyperParser(text, "2.%d" % i)
        print(hp.get_surrounding_brackets(mustclose=1))
    for i in range(len(l)):
        print(i)
        hp = HyperParser(text, "1.%d" % i)
        print(hp.get_surrounding_brackets("[{"))

# Generated at 2022-06-12 13:03:10.823912
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=redefined-builtin
    # pylint: disable=unused-variable

    rp = RoughParser()

    # Empty string.
    rp.set_str("")
    assert rp.get_good_lines() == [1]
    assert rp.get_continuation_type() == C_NONE
    assert rp.get_num_lines_in_stmt() == 0

    # Simple statement.
    rp.set_str('a=1\n')
    assert rp.get_good_lines() == [1, 2]
    assert rp.get_continuation_type() == C_NONE
    assert rp.get_num_lines_in_stmt() == 1

    # Two statements.

# Generated at 2022-06-12 13:03:19.661470
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    # pylint: disable=redefined-builtin
    str = "a\n  return True"
    rp = RoughParser(str, 0)
    assert rp.is_block_closer()
    str = "a\n  return\n  True"
    rp = RoughParser(str, 0)
    assert not rp.is_block_closer()
    str = "a\n  return True\n  x"
    rp = RoughParser(str, 0)
    assert not rp.is_block_closer()

# ------------------- parser class -------------------

# This class is responsible for the bulk of the work.  It is a parser
# and also has some additional methods that are used by the reformatter.
# Note that unlike the Parser module, the parser here is NOT a subclass
# of the token

# Generated at 2022-06-12 13:03:28.708859
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-12 13:03:36.257583
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest
    import sys

    # Lazy import to avoid circular imports
    from IDLElib.EditorWindow import EditorWindow

    # To run unit test:
    # * comment out this line:
    raise unittest.SkipTest("Disable editor window unit tests")
    # * enable:
    # if __name__ == "__main__":
    #     unittest.main(verbosity=2)
    # * launch idle with the "-n" option (from command line, not gui).
    #   This prevents the EditorWindow from being used as the main idle
    #   window.
    # * from shell window, run "path/to/file/test_HyperParser.py"

    class HyperParserTest(unittest.TestCase):
        def setUp(self):
            self.root = root = Tk()
            self

# Generated at 2022-06-12 13:03:43.033864
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from unittest import TestCase


# Generated at 2022-06-12 13:03:53.624446
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    # pylint: disable=redefined-builtin,protected-access
    assert RoughParser("foo = [\n").get_last_open_bracket_pos() == 0
    assert RoughParser("foo = [\n").get_last_open_bracket_pos() == 0
    assert RoughParser("foo = [\n    bar\n").get_last_open_bracket_pos() == 0
    assert RoughParser("foo = [\n    bar\n    baz\n").get_last_open_bracket_pos() == 0
    assert RoughParser("foo = [\n    bar\n    baz\n]\n").get_last_open_bracket_pos() is None

    assert RoughParser("foo = {\n").get_last_open_bracket_pos() == 0

# Generated at 2022-06-12 13:05:58.919785
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    parser = RoughParser("foo( [3], {},\nbar = 1\n", 8)
    assert parser.compute_bracket_indent() == 12

# Generated at 2022-06-12 13:06:05.459695
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # all examples are contrived, so that the answer is obvious
    # (and the comment in the code shows what that answer is).
    # Note that the answers are tied to the tab width, which is usually
    # 8.
    #
    # compute_backslash_indent works by looking at the first line of
    # the statement, and backslashes don't affect the indentation of
    # that line.  This can be really confusing, especially in cases
    # where the actual statement contains backslashes.

    def test(text, answer):
        rp = RoughParser(text, "utf-8")
        result = rp.compute_backslash_indent()
        if result != answer:
            print(text)
            print("expected", answer, "got", result, file=sys.stderr)

# Generated at 2022-06-12 13:06:14.675174
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    """
    Tests the method get_parse_start_of_program() of class RoughParser
    """
    def _check_RoughParser(str_, expected_parse_start):
        """
        Checks that the parse start position computed by the method
        get_parse_start_of_program, in this file,
        is equal to expected_parse_start
        """
        parser = RoughParser(str_)
        actual_parse_start = parser.get_parse_start_of_program()
        print("Expected: " + repr(expected_parse_start))
        print("Actual:   " + repr(actual_parse_start))
        assert actual_parse_start == expected_parse_start
    def _simple_test(string_to_parse, expected_parse_start):
        """
        For a simple test
        """


# Generated at 2022-06-12 13:06:22.334186
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    text = """
if 1:
    print(123)
    print(456)
    x=7
    print(x)

if 1:
    while 1:
        print(x)"""
    rp = RoughParser(text)
    lo, hi = rp.get_line_range_from_pos(19)
    assert lo == 2
    assert hi == 4
    lo, hi = rp.get_line_range_from_pos(23)
    assert lo == 0
    assert hi == 0
    lo, hi = rp.get_line_range_from_pos(57)
    assert lo == 5
    assert hi == 6


# Generated at 2022-06-12 13:06:30.784985
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    import tokenize
    s = RoughParser("a = 3\nb = 12\n")
    type_gen = tokenize.generate_tokens(s.find_good_parse_start().__next__)
    assert next(type_gen) == (tokenize.STRING, "a", (1, 0), (1, 1), "a = 3\nb = 12\n")
    assert next(type_gen) == (tokenize.NAME, "a", (1, 0), (1, 1), "a = 3\nb = 12\n")
    assert next(type_gen) == (tokenize.OP, "=", (1, 2), (1, 3), "a = 3\nb = 12\n")

# Generated at 2022-06-12 13:06:37.861627
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    class TestData:
        def __init__(self, text, expect):
            self.text = text
            self.expect = expect


# Generated at 2022-06-12 13:06:48.322255
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-12 13:06:57.720731
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    import unittest
    class T(unittest.TestCase):
        def check(self, input, expected_indent):
            rp = RoughParser(input)
            self.assertEqual(expected_indent, rp.compute_backslash_indent())
    T().check("""\
foo = {
        bar = {
            # comment
            baz = 4
    , qux = 5
        }
""", 25)
    T().check("""\
foo = {
        , qux = 5
        }
""", 13)
    T().check("""\
foo = {
        bar, # comment
            baz = 4
        }
""", 13)
# ---- end of unit test code for RoughParser


# Regular expression matching a single item

# Generated at 2022-06-12 13:07:04.594569
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text(
        """\
# foobar
print foo
'''Hello'''
"World"

# ",
#   '''
#   '''
"""
    )

    def get_is_in_code(pos):
        return HyperParser(text, pos).is_in_code()

    # Strings
    assert not get_is_in_code("1.0")
    assert not get_is_in_code("1.1")
    assert not get_is_in_code("1.2")
    assert not get_is_in_code("1.3")
    assert not get_is_in_code("1.4")
    assert not get_is_in_code("1.5")
    assert not get_is_in_code("1.6")
    assert not get_is_

# Generated at 2022-06-12 13:07:12.774514
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    from idlelib.idle_test.htest import assert_equal
    rawtext = '"a" + b(c.d).e'
    assert_equal(HyperParser(None, 0).get_expression(rawtext, len(rawtext) - 2), 'a')
    assert_equal(HyperParser(None, 0).get_expression(rawtext, len(rawtext) - 4),
                 'c.d')
    assert_equal(HyperParser(None, 0).get_expression(rawtext, len(rawtext) - 6),
                 'b(c.d)')
    assert_equal(HyperParser(None, 0).get_expression(rawtext, len(rawtext) - 8),
                 'b(c.d).e')