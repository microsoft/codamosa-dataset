

# Generated at 2022-06-12 12:59:06.534737
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    def check(text, good_index):
        parsed_index = RoughParser(text).find_good_parse_start()
        assert parsed_index == good_index, (parsed_index, good_index, text)

    check("", 0)
    check(" ", 0)  # no good place to start, but best is first place
    check("x", 0)
    check("x\n", 1)
    check("\nx", 0)
    check("\nx\n", 1)
    check("\\\nx\n", 2)  # line continuation
    check("a = 3\nb = a\\\n    + 4\n", 7)  # line continuation
    # string continuation
    check("'''\na\n'''\n", 5)

# Generated at 2022-06-12 12:59:12.468250
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def _do_test(self, text, index, openers, mustclose, expected):
            parser = HyperParser(text, index)
            actual = parser.get_surrounding_brackets(openers, mustclose)
            self.assertEqual(
                actual,
                expected,
                "Expected get_surrounding_brackets(%r, %r, %r, %r)"
                " to give %r, not %r" % (text, index, openers, mustclose, expected, actual),
            )

        def test_simple_case_1(self):
            text = "foo([a, b, c])"
            index = text.index("b")
            openers = "([{"
            mustclose = False
            expected

# Generated at 2022-06-12 12:59:19.197320
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest

    class SetIndexTestCase(unittest.TestCase):
        def test_no_Statement(self):
            """The statement must contain the index"""
            txt = "a = b + c\n"
            h = HyperParser(txt, "1.0")
            self.assertRaises(ValueError, h.set_index, "1.10")
            self.assertRaises(ValueError, h.set_index, "2.0")
            self.assertRaises(ValueError, h.set_index, "0.0")

        def test_set_index_value(self):
            """indexbracket should be right after the index"""
            txt = "a = (b + c)\n"
            h = HyperParser(txt, "1.0")

# Generated at 2022-06-12 12:59:29.035373
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    def f(s):
        rp = RoughParser(s, "", 4)
        return rp.is_block_opener()

    # These should be true.
    assert f('if 1:')
    assert f('if 1:\n    pass')
    assert f('if 1:\n    pass\n    pass')
    assert f('if 1:\n    pass\n\n    pass')
    assert f('if 1:\n    pass\n#\n    pass')
    assert f('if 1:\n    pass\n"""\n    pass')
    assert f('if 1:\n    pass\n    """a\n    pass')
    assert f('if 1:\n    pass\n    """\n    pass')
    assert f('def f():\n    """\n    pass')

# Generated at 2022-06-12 12:59:35.685346
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def str_indent(s, indent=""): return "\n".join([indent + line for line in s.split("\n")])

    from unittest import TestCase

    class TestCase(TestCase):
        # This string includes all chars that may be in a white space
        _whitespace_chars = " \t\n\\"

        def assertIsInCode(self, index, text):
            self.assertTrue(HyperParser(text, index).is_in_code(), text)

        def assertIsInString(self, index, text):
            self.assertFalse(HyperParser(text, index).is_in_code(), text)

        def assertIsInCodeStr(self, text, indent=""):
            text = str_indent(text, indent=indent)

# Generated at 2022-06-12 12:59:40.147254
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    parser = HyperParser(tkinter.Text(), "1.0")
    assert not parser.is_in_string()
    parser = HyperParser(tkinter.Text(height=2), "2.3")
    parser.text.insert("1.0", 'print "Hello\\n"\n')
    parser.set_index("1.8")
    assert parser.is_in_string()



# Generated at 2022-06-12 12:59:43.479169
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    # Verify the len() method call works as expected
    # Setup
    _non_defaults = {ord('a'): ord('x')}
    _default_value = ord('z')
    mapping = StringTranslatePseudoMapping(_non_defaults, _default_value)
    # Exercise
    assert len(mapping) == 1

# Generated at 2022-06-12 12:59:53.773419
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest
    import sys
    import os

    from idlelib.idle_test.htest import run

    class HyperParserTest(unittest.TestCase):
        """Run tests."""

        text = None
        idx = None
        hp = None
        path = None

        @classmethod
        def setUpClass(cls):
            # Load the file 'idle-test-code.py' as the text used for testing
            # HyperParser.  The file should be in the same directory as this
            # module so that the module path can be used to locate the file
            # also when imported in another test module.
            path = os.path.dirname(__spec__.origin)

# Generated at 2022-06-12 13:00:02.699917
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=redefined-builtin
    """ This is the test routine for RoughParser.find_good_parse_start """

    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-arguments
    """
    This is the test routine for RoughParser.find_good_parse_start
    """

# Generated at 2022-06-12 13:00:08.814482
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    def check(s, n):
        r = RoughParser(s, 0)
        assert r.get_num_lines_in_stmt() == n
        assert r.get_continuation_type() == C_BACKSLASH

    for s in ("a +\\\nb +\\\nc", "a +\\\nb + c\\\n",):
        check(s, 2)

    s = "a + b\\\n"
    check(s, 1)

    s = (
        "a +\\\n"
        "b +\\\n"
        "c +\\\n"
        "d"
    )
    check(s, 3)

    s = "a + b\\\nc = d\\\n"
    check(s, 1)

    s = "a +\\\n"
    check

# Generated at 2022-06-12 13:01:43.537518
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
	# Test with 1-char source
	assert RoughParser("X", 1).find_good_parse_start() == 0
	assert RoughParser(" \t\n", 1).find_good_parse_start() == 3
	assert RoughParser("\t#\n", 1).find_good_parse_start() == 2

	# Test with 2-char source
	assert RoughParser("XX", 2).find_good_parse_start() == 0
	assert RoughParser("X#", 2).find_good_parse_start() == 1
	assert RoughParser("#X", 2).find_good_parse_start() == 1
	assert RoughParser(" \t\nX", 2).find_good_parse_start() == 3
	assert RoughParser(" \t\n#", 2).find_good_parse_start() == 2
	assert RoughParser

# Generated at 2022-06-12 13:01:50.320854
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    class Text:
        def __init__(self, s, index):
            self.s = s
            self.index = index
        def get(self, startindex, stopindex):
            return self.s[int(startindex):int(stopindex)]
        def index(self, s):
            return self.s.index(s)
        def __getattr__(self, attr):
            if attr == "indent_width":
                return 4
            if attr == "tabwidth":
                return 8
            raise AttributeError

    def t(s, index, expected):
        hp = HyperParser(Text(s, index), index)
        expr = hp.get_expression()
        if expr != expected:
            print("expr='%s' expected='%s'" % (expr, expected))
        assert expr == expected

# Generated at 2022-06-12 13:01:59.143697
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def setUp(self):
            self.text = Text(None, b"")

        def check_hyperparser(self, text, index, init_bracketing, init_isopener=None):
            self.text.replace("1.0", "end", text)
            parser = HyperParser(self.text, index)

            raw = [str(b) for b in parser.bracketing]
            self.assertEqual(raw, init_bracketing)

            if init_isopener:
                self.assertEqual([str(b) for b in parser.isopener], init_isopener)
            else:
                isopener = [r[-2] == ">" for r in raw]

# Generated at 2022-06-12 13:02:06.467506
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    class HyperParserMock(HyperParser):
        """A mocked up HyperParser, to test get_surrounding_brackets."""

        def __init__(self, s):
            """Parse the given string into a bracketing list."""
            self.text = s
            self.rawtext = s
            self.stopatindex = len(s)
            self.bracketing = list(iter_open_brackets_in_text(s))
            self.isopener = [x[1] >= 0 for x in self.bracketing]

        def set_index(self, i):
            """Set the index to which the functions relate.

            The index must be in the same statement.
            """
            self.indexinrawtext = i
            # find the rightmost bracket to which index belongs
            self.indexbracket = 0

# Generated at 2022-06-12 13:02:13.469600
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    _base_indent_string = _get_base_indent_string

    assert "" == _base_indent_string("abc\n")
    assert "  " == _base_indent_string("  abc\n")
    assert "\t" == _base_indent_string("\tabc\n")
    assert "\t" == _base_indent_string("\tabc\r\n")
    assert " " == _base_indent_string("\tabc\r\n  xyz\r\n")
    assert "  " == _base_indent_string("  \tabc\r\n  xyz\r\n")
    assert " " == _base_indent_string("\nabc\n")
    assert "" == _base_indent_string("\nabc")
   

# Generated at 2022-06-12 13:02:20.055619
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-12 13:02:28.031299
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    # pylint: disable=redefined-outer-name
    def test_get_base_indent_string(self):
        t = self.assertEqual

        rp = RoughParser("", 0, 0)
        t(rp.get_base_indent_string(), "")

        rp = RoughParser("    ", 0, 0)
        t(rp.get_base_indent_string(), "    ")

        rp = RoughParser(" if 1: pass\n", 0, 0)
        t(rp.get_base_indent_string(), " ")

        rp = RoughParser("if 1: pass\n", 0, 0)
        t(rp.get_base_indent_string(), "")


# Generated at 2022-06-12 13:02:34.921769
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-12 13:02:40.779568
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():

    def check(source, expected):
        rp = RoughParser(source, tabwidth=4)
        actual = rp.get_last_stmt_bracketing()
        assert actual == expected, (actual, expected)
    yield check, "", ()
    yield check, "x=1", ((0, 0), (1, 0), (2, 0))
    yield check, "$x=1+\ny=2", ((0, 0), (4, 0), (5, 0))
    yield check, "a='1\nb=2", ((0, 0), (6, 0), (7, 0))
    yield check, "a='1\n   b=2", ((0, 0), (6, 0), (10, 0))

# Generated at 2022-06-12 13:02:44.472264
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    RoughParser("class Roro(object):\n    def __init__(self):\n        print(\"\"\"hello world\")\n        pass\n").set_lo()
    RoughParser("print(\"\"\"\nhello world\n\")\n").set_lo()
    RoughParser("def f(self, a, b=None,\n        c=None):\n    pass\n").set_lo()
    assert 0, "no assert statements"

# Generated at 2022-06-12 13:03:30.197522
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():

    # pylint: disable=redefined-outer-name

    # The workhorse function
    def find_good_parse_start(text):
        return RoughParser(text).find_good_parse_start()

    def check(text, goodtext):
        # pylint: disable=expression-not-assigned
        assert text.startswith(goodtext)
        assert RoughParser(text).find_good_parse_start() == 0

    def check_bad(text, goodtext):
        # pylint: disable=expression-not-assigned
        assert not text.startswith(goodtext)
        assert RoughParser(text).find_good_parse_start() is None

    def check_all(text, goodtext):
        check(text, goodtext)
        check_bad(text + "x", goodtext)



# Generated at 2022-06-12 13:03:31.012481
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    pass



# Generated at 2022-06-12 13:03:37.877899
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-12 13:03:44.163304
# Unit test for constructor of class HyperParser
def test_HyperParser():
    class FakeText:
        def __init__(fake, str):
            fake._str = str
            fake._i2l = []
            fake._line2i = {}

        def index(fake, index):
            if index[0] == 'n':
                return fake._i2l[int(index[1:])]
            return int(index)

        def get(fake, start, stop):
            start = int(start)
            stop = int(stop)
            return fake._str[start:stop]

        def is_index_in_string(fake, index):
            index = int(index)
            if index < 0 or index >= len(fake._str):
                raise ValueError("Bad index in FakeText.is_index_in_string")
            return fake._str[index] in '"\''


# Generated at 2022-06-12 13:03:54.104961
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    for i in range(2):
        indenter = parser.Parser(
            """foo(bar,
             boo\\
             baz,
             biff\\
             bORK,
             boink)"""
        )
        assert (
            indenter.compute_backslash_indent() == indenter.indent_width
            == indenter.compute_bracket_indent() == 2 + 4
        )

        indenter = parser.Parser(
            """foo(bar,
             boo\\
             baz,
             biff\\
             bORK,
             boink\\
             )"""
        )
        assert (
            indenter.compute_backslash_indent() == indenter.indent_width
            == indenter.compute_bracket_indent() == 2 + 4
        )

       

# Generated at 2022-06-12 13:04:02.196471
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = "def foo(x, y):\n" + "    if x == 0:\n" + "        x = 1\n" + "        y = 2\n" + "        #"

    hp = HyperParser(text, "1.9")
    assert hp.rawtext == "def foo(x, y):\n    if x == 0:\n        x = 1\n        y = 2\n        # "
    assert hp.text.index("2.4") == hp.stopatindex
    assert hp.is_in_code()
    assert hp.get_surrounding_brackets("([") == ("2.0", "2.9")
    assert hp.get_surrounding_brackets("({", mustclose=True) is None
    assert hp.get_expression() == "y"

    hp = Hyper

# Generated at 2022-06-12 13:04:09.643050
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-12 13:04:18.920591
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Tkinter.Text()
    # _ToDo: implement the following test suit:
    #
    #     # Test that set_index fail if given index precedes the analyzed statement.
    #     text.insert('1.0',"a=1")
    #     hyperpars=HyperParser(text,'1.0')
    #     self.assertRaises(ValueError,hyperpars.set_index,'0.0')
    #     # Test that set_index succeed if given index is inside the analyzed statement.
    #     self.assertTrue(hyperpars.set_index('1.0'))
    #     self.assertTrue(hyperpars.set_index('1.1'))
    #     self.assertTrue(hyperpars.set_index('1.end'))
    #     # Test that set_index

# Generated at 2022-06-12 13:04:27.599836
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    t = RoughParser("\n    if foo == 'blah':\n        pass\n")
    assert t.compute_bracket_indent() == 8
    t = RoughParser("\n    if foo == 'blah':\n        something()\n")
    assert t.compute_bracket_indent() == 8
    t = RoughParser("\n    if foo == 'foo':\n        something()\n    elif foo == 'blah':\n        pass\n")
    assert t.compute_bracket_indent() == 12
    t = RoughParser("\n    if (\n        foo == 'blah'):\n        pass\n")
    assert t.compute_bracket_indent() == 4

# Generated at 2022-06-12 13:04:33.442135
# Unit test for method set_index of class HyperParser

# Generated at 2022-06-12 13:05:58.477039
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # A simple test with a single call to get_expression.
    # Testing all possible cases is not feasible.
    test_text = "abc(0, 1+3.14j, def=, efg=None, ghi=list(range(10))).xyz"
    test_index = "3.17"
    hp = HyperParser(test_text, test_index)
    assert hp.get_expression() == "test_text.xyz"
    hp.set_index("3.13")
    assert hp.get_expression() == "test_text.xyz"
    hp.set_index("3.11")
    assert hp.get_expression() == "test_text.xyz"
    hp.set_index("3.10")
    assert hp.get_expression() == "test_text"

# Generated at 2022-06-12 13:06:07.996910
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest


# Generated at 2022-06-12 13:06:17.591723
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = "abcd\nefg\nhij"
    hp = HyperParser(text, "1.0")
    if hp.is_in_string():
        print("The test failed: 1.0 is not in a string.")
    hp = HyperParser(text, "1.2")
    if hp.is_in_string():
        print("The test failed: 1.2 is not in a string.")
    hp = HyperParser(text, "1.3")
    if hp.is_in_string():
        print("The test failed: 1.3 is not in a string.")
    text = 'abcd\nefg"\nhij'
    hp = HyperParser(text, "2.0")
    if not hp.is_in_string():
        print("The test failed: 2.0 is in a string.")


# Generated at 2022-06-12 13:06:21.598737
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    h = HyperParser('"""hi""""', "1.0")
    assert h.is_in_string() == True, "should be in string"
    h.set_index("2.0")
    assert h.is_in_string() == False, "should not be in string"


# Generated at 2022-06-12 13:06:30.045744
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def _build_test_input(text, index):
        return tkinter.Text(None), tkinter.Misc.ins(tkinter.END, text), tkinter.Misc.index(index)

    def check_get_surrounding_brackets(text, index, openers, mustclose, expected_result):
        text, real_index, real_expected_result = _build_test_input(text, index)
        hyper_parser = HyperParser(text, real_index)
        result = hyper_parser.get_surrounding_brackets(openers, mustclose)
        assert result == real_expected_result, result

    check_get_surrounding_brackets("([3,4])", "1.1", "([{", False, ("1.0", "1.end"))
    check_get

# Generated at 2022-06-12 13:06:30.926776
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-12 13:06:40.122704
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-12 13:06:49.565929
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    """Test the method HyperParser.is_in_code."""

# Generated at 2022-06-12 13:06:58.922585
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def do_test(string, result):
        from idlelib.textView import view_factory

        text = view_factory("text")
        text.set("1.0", "end", string)
        hp = HyperParser(text, "1.end")
        assert hp.is_in_code() == result, "for string %r" % string

    do_test("a = 12  # comment", True)
    do_test("# comment", False)
    do_test("a = '''comment'''", False)
    do_test("a = '''comment", False)
    do_test("a = '''comment'''#comment", True)


if __name__ == "__main__":
    from unittest import main


# Generated at 2022-06-12 13:07:03.026338
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest

    class HyperParserTest(unittest.TestCase):
        def _classify_index(self, text, index):
            self.hp.set_index(index)
            return (
                self.hp.is_in_string(),
                self.hp.is_in_code(),
                self.hp.get_expression(),
            )
