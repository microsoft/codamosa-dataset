

# Generated at 2022-06-26 07:38:46.468295
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-26 07:38:47.906208
# Unit test for constructor of class HyperParser
def test_HyperParser():
    test_case_0()


# Generated at 2022-06-26 07:38:50.841898
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    str_0 = '2#N%4:m'
    hyper_parser_0 = HyperParser(str_0, '0.0')
    assert not hyper_parser_0.is_in_code()


# Generated at 2022-06-26 07:38:58.060201
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text_4 = Text()
    text_4.insert('1.end', 'a')
    index_4 = '1.end'
    hyper_parser_2 = HyperParser(text_4, index_4)
    print(hyper_parser_2.is_in_string())
    assert hyper_parser_2.is_in_string() == True, "Expected True, but got %s" % hyper_parser_2.is_in_string()


# Generated at 2022-06-26 07:39:07.891189
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = '/ ='
    rough_parser_0 = RoughParser(str_0, str_0)
    int_0 = rough_parser_0.compute_backslash_indent()
    assert int_0 == 2
    str_1 = '"\nB\n\n#\n'
    rough_parser_1 = RoughParser(str_1, str_1)
    int_1 = rough_parser_1.compute_backslash_indent()
    assert int_1 == 1
    str_2 = '{(#\n'
    rough_parser_2 = RoughParser(str_2, str_2)
    int_2 = rough_parser_2.compute_backslash_indent()
    assert int_2 == 3


# Generated at 2022-06-26 07:39:11.684418
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = str_0 = '1[h5\n\t'
    rp_0 = RoughParser(str_0, str_0)
    print(rp_0.compute_backslash_indent())


# Generated at 2022-06-26 07:39:21.009403
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=unused-argument
    # pylint: disable=redefined-variable-type
    class Test0:
        def __init__(self, str_):
            self.str = str_
            self.start = self.str.find('{')
            self.end = self.str.find('}')
            self.contents = self.str[self.start+1:self.end]
            self.chs = [ch for ch in self.contents]
            self.lines = self.contents.split('\n')

    test = Test0('def f(x:int):\n    print(x)\n')
    print(test.start)
    print(test.end)
    print(test.contents)
    print(test.chs)

# Generated at 2022-06-26 07:39:26.320135
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    str_0 = '2#N%4:m'
    rough_parser_0 = RoughParser(str_0, str_0)
    hyper_parser_0 = HyperParser(str_0, '1.0')
    assert hyper_parser_0.is_in_string() == False
    boolean_0 = hyper_parser_0.is_in_string()
    assert isinstance(boolean_0, bool) == True
    boolean_0 = hyper_parser_0.is_in_string()
    assert isinstance(boolean_0, bool) == True


# Generated at 2022-06-26 07:39:35.797683
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    test_array = [
        ["", 0],
        ["#", 1],
        ["#\n", 1],
        ["#\n#", 2],
        ["#\n#\n", 2],
        ["#\n\n#", 3],
        ["#\n\n#\n", 3],
        ["#\\\n#", 2],
        ["#\\\n\n#", 3],
        ["#\\\n\n\n#", 4],
        ["#\\\n\n\n\n#", 5]
    ]
    for x in test_array:
        assert RoughParser(x[0], x[0]).get_num_lines_in_stmt() == x[1]


# Generated at 2022-06-26 07:39:37.904197
# Unit test for constructor of class HyperParser
def test_HyperParser():
    str_0 = '2#N%4:m'
    hyper_parser_0 = HyperParser(str_0, str_0)
    hyper_parser_0.set_index('4:m')


# Generated at 2022-06-26 07:40:44.165157
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    hp = HyperParser(str_0, 8)
    hp.set_index(8)
    hp.set_index(9)


# Generated at 2022-06-26 07:40:46.236987
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    test_case_0()
    test_HyperParser_set_index_0()


# Generated at 2022-06-26 07:40:51.537358
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    # Test 0:
    str_0 = 'def f(x:int):\n    print(x)\n'
    expected = 'def f(x:int):'
    parser = RoughParser(str_0,indentwidth=4,tabwidth=8)
    parser.study_level = 2
    parser.stmt_start = 0
    parser.stmt_end = len(expected)
    parser.str = str_0
    ret = parser.get_base_indent_string()
    print(ret)



# Generated at 2022-06-26 07:40:55.652489
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = 'abc = 10 \\'
    str_0 += '\ndef = 20\n'
    parser = RoughParser(str_0)
    indent = parser.compute_backslash_indent()
    assert 4 == indent


# Generated at 2022-06-26 07:41:06.166361
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    global str_0
    B = len(str_0)
    _str_0 = str_0 + " "

    for k in range(B):
        i = find_good_parse_start(_str_0, k)
        assert 0 <= i < B
        assert i == 0 or i == k or _str_0[i - 1] == "\n"
        end = find_exception_line_ending(_str_0, i)
        assert end == i or _str_0[end - 1] == "\n"
        assert end == k or end == B

# Generated at 2022-06-26 07:41:14.013524
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    str_0 = 'def f(x:int):\n    print(x)\n'

    # Create test case HyperParser
    hyper_parser_0 = HyperParser(str_0, _)

    # Call method is_in_string
    test_case_1(hyper_parser_0)

    # Call method is_in_string
    test_case_2(hyper_parser_0)

    # Call method is_in_string
    test_case_3(hyper_parser_0)

    # Call method is_in_string
    test_case_4(hyper_parser_0)

    # Call method is_in_string
    test_case_5(hyper_parser_0)

    # Call method is_in_string
    test_case_6(hyper_parser_0)


# Testing function test_case

# Generated at 2022-06-26 07:41:29.623782
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    str_0 = 'def f(x:int):\n    print(x)\n'

    #
    #
    #
    #
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    #
    #
    #
    #
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-26 07:41:35.701635
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    """Test case method is_in_code of class HyperParser"""
    text = tk.Text()
    text.insert("insert", "def f(x: int):\n    print(x)")

    parser = HyperParser(text, "insert")
    assert parser.is_in_code()
    parser.set_index("1.1")
    assert parser.is_in_code()
    parser.set_index("1.2")
    assert parser.is_in_code()
    parser.set_index("1.3")
    assert parser.is_in_code()
    parser.set_index("1.4")
    assert parser.is_in_code()
    parser.set_index("1.5")
    assert parser.is_in_code()
    parser.set_index("1.6")


# Generated at 2022-06-26 07:41:47.885865
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    str_0 = 'def f(x:int):\n    print(x)\n'
    str_1 = '    from tkinter import *\n    root = Tk()\n    root.title(\'hello world\')\n    root.geometry(\'100x100\')\n'
    str_2 = 'def f(x:int):\n    print(x)\n'
    str_3 = 'def f(x:int):\n    print(x)\n'
    str_4 = 'def f(x:int):\n    print(x)\n'
    str_5 = 'def f(x:int):\n    print(x)\n'
    str_6 = '''"""A multi-line docstring."""\n# Leading comment.\nimport math\n'''
    str

# Generated at 2022-06-26 07:41:58.137447
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Text(None)
    text.insert(INSERT, str_0)
    index = "%d.0" % (int(float(text.index(END))) - 1)
    hp = HyperParser(text, index)
    print('hyper_parser:', repr(hp))
    print('hyper_parser.text:', repr(hp.text))
    print('hyper_parser.rawtext:', repr(hp.rawtext))
    print('hyper_parser.stopatindex:', repr(hp.stopatindex))
    print('hyper_parser.bracketing:', repr(hp.bracketing))
    print('hyper_parser.isopener:', repr(hp.isopener))
    print('hyper_parser.indexinrawtext:', repr(hp.indexinrawtext))

# Generated at 2022-06-26 07:46:30.712529
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    cc = HyperParser( str_0, 2)
    assert cc.is_in_string() == False


# Generated at 2022-06-26 07:46:37.995618
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-26 07:46:47.826580
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    if True:
        str_0 = 'def f(x:int):\n    print(x)\n'
        text_0 = tk.Text(None)
        text_0.insert(1.0,str_0)
        index_0 = HyperParser(text_0,8.0)
        # Did the method generate a ValueError?
        assert(not hasattr(index_0,"ValueError"))
        # test passes if the method get_surrounding_brackets returns ('8.0', '8.1')
        assert(index_0.get_surrounding_brackets()==('8.0', '8.1'))
        str_1 = '# Don\'t eat this!\n    # Not this!\n    x = (1 + 2)\n'

# Generated at 2022-06-26 07:46:57.925170
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    str_0 = 'def f(x:int):\n    print(x)\n'
    str_1 = 'def f(x: int):\n    print(x)\n'
    str_2 = 'def f(x: int):\n    print(x)\n'
    str_3 = 'def f(x: int):\n    print(x)\n'
    str_4 = 'def f(x: int):\n    print(x)\n'
    str_5 = 'def f(x: int):\n    print(x)\n'
    str_6 = 'def f(x: int):\n    print(x)\n'
    str_7 = 'def f(x: int):\n    print(x)\n'