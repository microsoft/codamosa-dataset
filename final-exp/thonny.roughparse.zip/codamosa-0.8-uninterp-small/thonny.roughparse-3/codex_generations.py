

# Generated at 2022-06-26 07:39:49.779361
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import idlelib.idle_test.mock_tk as mock_tk
    import tkinter as Tk
    
    path_to_script = "test.py"    # just a test script to be loaded
    root = Tk.Tk()
    root.withdraw()
    
    # Create mock editor window with the test script loaded
    editor_window = idlelib.editor.EditorWindow(root)
    editor_window.open(path_to_script)
    text_widget = editor_window.text
    text_widget.pack()
    
    # create a HyperParser object and check if it was created properly
    hyper_parser = HyperParser(text_widget, "1.0")
    assert len(hyper_parser.rawtext) > 0
    assert len(hyper_parser.stopatindex) > 0
    assert len

# Generated at 2022-06-26 07:39:51.960219
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text_1 = "12345"
    # HyperParser.__init__(): test that HyperParser initializes correctly
    # with an index
    hyper_parser_2 = HyperParser(text_1, 1)

# Test: ensure that HyperParser parses a string correctly

# Generated at 2022-06-26 07:39:56.477688
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    with tempfile.NamedTemporaryFile(mode="w+t", encoding="utf-8") as f:
        f.write('"sample string"')
        f.seek(0)
        tk = tkinter.Text(master=None)
        tk.filetypename = "python"
        text = EditorWindow(tk, f.name, "python", text=tk.get("1.0", "end-1c"))
        index = "1.1"
        hyper_parser_0 = HyperParser(text, index)
        hyper_parser_0.set_index(index)


# Generated at 2022-06-26 07:39:58.947034
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    string_0 = '#]|(\xbf"\x13\x1d\x1a\x00\xf7)'
    index_0 = '1.0'
    object_0 = HyperParser(string_0, index_0)
    function_0 = object_0.is_in_string
    assert_equal(function_0(), False)


# Generated at 2022-06-26 07:40:08.923462
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin
    bytes_0 = b'e\xd8\xba\xa6)\xden\xea_)'
    rough_parser_0 = RoughParser(bytes_0, bytes_0)
    rough_parser_0._study2()
    assert rough_parser_0.stmt_bracketing == ((0, 0), (11, 1), (16, 0))
    assert rough_parser_0.compute_bracket_indent() == 1
    rough_parser_0.stmt_bracketing = ((0, 0), (11, 1), (16, 0))
    assert rough_parser_0.compute_bracket_indent() == 1


# Generated at 2022-06-26 07:40:19.454791
# Unit test for method set_index of class HyperParser

# Generated at 2022-06-26 07:40:21.843530
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    assert RoughParser("abc", "def").compute_bracket_indent() == 4


# Generated at 2022-06-26 07:40:29.749954
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = tk.Text()
    text.insert(tk.END, '"""\nfoo\nbar\n"""')
    hyper_parser_0 = HyperParser(text, '1.end')
    assert not hyper_parser_0.is_in_code()
    hyper_parser_0.set_index('1.0')
    assert hyper_parser_0.is_in_code()
    hyper_parser_0.set_index('2.0')
    assert hyper_parser_0.is_in_code()
    hyper_parser_0.set_index('3.0')
    assert hyper_parser_0.is_in_code()
    hyper_parser_0.set_index('4.0')
    assert not hyper_parser_0.is_in_code()

# Generated at 2022-06-26 07:40:39.128724
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    assert RoughParser(b"(a)", b"x\n(a)").find_good_parse_start(b"\n") == 1
    assert RoughParser(b"(a)", b"x\n").find_good_parse_start(b"\n") == 1
    assert RoughParser(b"(a)", b"(a)").find_good_parse_start(b"\n") == 0
    str_0 = b"x\nabc\ndef"
    assert RoughParser(str_0, str_0).find_good_parse_start(b"\n") == 1
    assert RoughParser(b"x  ", b"x  ").find_good_parse_start(b"\n") == 0
    assert RoughParser(b"", b"").find_good_parse_start(b"\n") == 0


# Generated at 2022-06-26 07:40:44.116793
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    bytes_0 = b'%c\x01\n\x01\x01\x01\x01'
    assert RoughParser(bytes_0, bytes_0).get_base_indent_string() == (b'\n\x01\x01\x01\x01')


# Generated at 2022-06-26 07:41:55.254431
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # test case input: [text, index]
    test_tools = TestTools()
    inputs = [
        ["\n# test case\nprint(1 +\n", "2.4"],
        ["\n# test case\nprint(1 +)\n", "2.4"],
        ["\n# test case\n\"\"\"\ndef add(a, b): return(a + b)\n\n# test case for is_in_code\nprint(add(1, 1))\n\"\"\"\ndef add(a, b): return(a + b)\n\n# test case for is_in_code\nprint(add(1, 1))\n", "26.2"],
    ]


# Generated at 2022-06-26 07:41:59.101130
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    bytes_0 = b'\n  (a, b)\n\na, b)\n'
    rough_parser_0 = RoughParser(bytes_0, bytes_0)
    index_0 = rough_parser_0.find_good_parse_start()
    assert (index_0 == 0)


# Generated at 2022-06-26 07:42:02.408467
# Unit test for constructor of class HyperParser
def test_HyperParser():
    hyper_parser_0 = HyperParser("text0", 0)

test_case_0()
test_HyperParser()


# Generated at 2022-06-26 07:42:12.263202
# Unit test for constructor of class HyperParser
def test_HyperParser():
    bytes_0 = b'e\xd8\xba\xa6)\xden\xea_)'
    bytes_1 = b'\xec\xa7\x97\xfb\x01\x90\x88\xb1\xea\xb7\x8d\xd9\x88\x844\xec\xbc\xaa\xf0\xa8\x0c'
    byte_array_0 = bytearray(bytes_0)
    byte_array_1 = bytearray(bytes_1)
    string_0 = String(byte_array_0, byte_array_1)
    HyperParser(string_0, string_0)


# Generated at 2022-06-26 07:42:21.838488
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=redefined-builtin, unused-argument

    if_stmt = b"""if x==1:
    a += 1
elif x==2:
    b += 1
else:
    c += 1"""

    # Test the initial indentation, where the elses match their ifs.
    actual_value =  RoughParser(if_stmt, if_stmt).find_good_parse_start()
    expected_value = 0
    print("test_RoughParser_find_good_parse_start(): passing test #0")
    print("    expected value = {}".format(expected_value))
    print("    actual value = {}".format(actual_value))
    assert actual_value == expected_value

    # Test the case when the last else doesn't match its if.

# Generated at 2022-06-26 07:42:33.816062
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    str_0 = '{ \n    #cursor \n}'
    str_1 = '{ \n    print(a)#cursor \n}'
    str_2 = '{ \n    "print(a)"#cursor \n}'
    str_3 = '{ \n    \'print(a)\'#cursor \n}'
    text_0 = Text(str_0, 1)
    text_1 = Text(str_1, 1)
    text_2 = Text(str_2, 1)
    text_3 = Text(str_3, 1)
    rough_parser_0 = RoughParser(1, 4)
    rough_parser_0.set_str(str_0 + ' \n')

# Generated at 2022-06-26 07:42:43.903731
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    class obj_0(object):
        def __init__(self, arg_0):
            self.arg_0 = arg_0

# Generated at 2022-06-26 07:42:49.953446
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-26 07:42:54.553673
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Create the parent text
    text_0 = Text()
    # Create a HyperParser instance with its current index set to 0
    hyper_parser_0 = HyperParser(text_0, 0)
    # Set the value of current index to 0
    hyper_parser_0.set_index(0)
    # Call the method
    hyper_parser_0.get_surrounding_brackets()


# Generated at 2022-06-26 07:43:08.001666
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-26 07:45:21.158485
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    test_roug_parser = RoughParser(b'field.search([(\'name\', \'=\', \'aaaa\')])', b'\x10\x00\x00\x00\x00\x00\x00\x00')
    assert test_roug_parser.compute_bracket_indent() == 21


# Generated at 2022-06-26 07:45:25.397528
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Text()
    text.insert(END, 'def foo(x,\n         y,\n         z):\n    """doc"""\n    pass\n')
    hyper_parser = HyperParser(text, text.index('2.2'))
    assert hyper_parser.is_in_string() == False


# Generated at 2022-06-26 07:45:28.070822
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    try:
        text = 'abc '
        hp = HyperParser(text, "2.0")
        assert (hp.get_expression() == '')
    except Exception:
        raise AssertionError()


# Generated at 2022-06-26 07:45:40.561885
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-26 07:45:50.257698
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # FIXME
    rough_parser_0 = RoughParser(bytes_0, bytes_0)
    rough_parser_0.str = ""
    rough_parser_0.str = "%s\n" % ("".join(generate_lines(5, 30)))
    hyper_parser_0 = HyperParser(rough_parser_0.str, rough_parser_0.str)
    str_0 = hyper_parser_0.rawtext
    hyper_parser_0.stopatindex = str_0
    hyper_parser_0.set_index(str_0)
    # FIXME
    # verification fails:
    #   expect to get False
    #   but got None
    # FIXME
    # verification fails:
    #   expect to get True
    #   but got None

# Generated at 2022-06-26 07:45:54.518717
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
  rough_parser_0 = RoughParser(b'\t', b'\t')
  if rough_parser_0.get_base_indent_string() != b'\t':
    return 1
  return 0


# Generated at 2022-06-26 07:45:59.265170
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = "if foo() == 'foo':\n" "    do_something()\n"
    for index in range(len(text) - 1):
        hp = HyperParser(Text(text, 0), repr(index) + ".0")
        actual = hp.is_in_string()
        expected = text[index] == "'"
        assert actual == expected


# Generated at 2022-06-26 07:46:03.158434
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    tk = Text("\n".join(["abc"] * 10 + ["def"] * 10))
    h = HyperParser(tk, "1.100")
    h.set_index("5.5")


# Generated at 2022-06-26 07:46:13.552511
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    file_path = '/home/santosh/work/algo_benchmark/python/src/hyperparser/HyperParser.py'
    file = open(file_path, 'r')
    file_lines = file.readlines()
    file.close()
    file_data = ''
    for line in file_lines:
        file_data += line
    print('file_data: ' + file_data)
    hyper_parser = HyperParser(file_data, 100)
    print(hyper_parser.get_expression())



if __name__ == "__main__":
    test_case_0()
    test_HyperParser_get_surrounding_brackets()

# Generated at 2022-06-26 07:46:24.168143
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    bytes_0 = b'\xde\xfc\xbea\xe1\x87\xbe\x95\xbc\xfb\xb9\xa3\xbc\x83\xbc \xb2\xbc'
    hyper_parser_0 = HyperParser(bytes_0, bytes_0)
    bytes_1 = b'\x8e\xc3\xbdOy\xf1\x8d\xbd\x9b\xb7\xbb\x8e1\xc2\x8a\xbe\x9b\xc1\xbc \xb2\xbc'
    hyper_parser_0.set_index(bytes_1)
