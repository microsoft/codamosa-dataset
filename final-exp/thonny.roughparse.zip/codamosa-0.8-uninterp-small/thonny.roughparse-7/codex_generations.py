

# Generated at 2022-06-26 07:38:52.037374
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    preserve_dict = {ord('-'): ord('-')}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert set(mapping.__iter__()) == {ord('-')}


# Generated at 2022-06-26 07:38:55.799721
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    str_0 = "()\n"
    rough_parser_0 = RoughParser(str_0, False)
    int_0 = rough_parser_0.compute_bracket_indent()


# Generated at 2022-06-26 07:39:05.692386
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # Test 1:
    # str_0 = "=qC|*Q0Eb;~:H,p'6"
    # bool_0 = True
    # rough_parser_0 = RoughParser(str_0, bool_0)

    # str_1 = "=qC|*Q0Eb;~:H,p'6"
    # bool_1 = True
    # rough_parser_1 = RoughParser(str_1, bool_1)
    # hyper_parser_0 = HyperParser(rough_parser_1, hyper_parser_1)

    # bool_2 = hyper_parser_0.is_in_string()
    # assert bool_2
    assert 1 == 1


# Generated at 2022-06-26 07:39:12.518832
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    str_0 = "W8RUfjy_"
    bool_0 = True
    rough_parser_0 = RoughParser(str_0, bool_0)
    bool_1 = False
    rough_parser_0.set_lo(bool_1)


#Checking if RoughParser is a class

# Generated at 2022-06-26 07:39:19.407918
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    if not (True):
        print("Failure  test_HyperParser_is_in_string")


# Generated at 2022-06-26 07:39:29.275904
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    str_0 = "vU`9?[&@6)fc-h*8}iKH0y_%r)fY;C(Q?x~*3e5O{_5!K7:8*z-dV}G@&=Rw_E" \
        "N[LP&{C*}Fu,]z2/P@D3q=y-/FwWmB|>xmI9nZ2i"
    bool_0 = True
    rough_parser_0 = RoughParser(str_0, bool_0)
    rough_parser_0.set_lo(1)


# Generated at 2022-06-26 07:39:33.351390
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = "        if is_block_opener(self) or " + "self.lastch != \\\n"
    bool_0 = True
    rough_parser_0 = RoughParser(str_0, bool_0)
    assert rough_parser_0.compute_backslash_indent() == 8


# Generated at 2022-06-26 07:39:37.710297
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # Instantiate a HyperParser object
    index_0 = "1.0"
    text_0 = ""
    hyper_parser_0 = HyperParser(text_0, index_0)
    # Test the HyperParser object's get_expression method
    assert hyper_parser_0.get_expression() == ""


# Generated at 2022-06-26 07:39:44.626734
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text_0 = Text()
    text_0.insert("1.0", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum")
    hyper_parser_0 = HyperParser(text_0, "2.5")

# Generated at 2022-06-26 07:39:49.715776
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    str_0 = "\n    \n    "
    bool_0 = True
    rough_parser_0 = RoughParser(str_0, bool_0)
    rough_parser_0._study2()
    rough_parser_0.compute_bracket_indent()


# Generated at 2022-06-26 07:40:19.741821
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = "for i in (1, 2): pass"
    index = text.index("i")
    hp = HyperParser(text, index)
    assert hp.get_surrounding_brackets() == ("for i in ", ": pass")


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 07:40:25.393679
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    str_0 = "=qC|*Q0Eb;~:H,p'6"
    bool_0 = True
    rough_parser_0 = RoughParser(str_0, bool_0)
    hyper_parser_0 = HyperParser(rough_parser_0, bool_0)
    result = hyper_parser_0.is_in_string()
    assert result == False


# Generated at 2022-06-26 07:40:28.061623
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    str_0 = "H,p'6"
    hyper_parser_0 = HyperParser(str_0)
    assert_equal(hyper_parser_0.is_in_code(), False)


# Generated at 2022-06-26 07:40:31.165108
# Unit test for constructor of class HyperParser
def test_HyperParser():
    str_0 = "=qC|*Q0Eb;~:H,p'6"
    bool_0 = True

    hyper_parser_0 = HyperParser(str_0, bool_0)

# Generated at 2022-06-26 07:40:38.705672
# Unit test for constructor of class HyperParser
def test_HyperParser():
    t = EditorWindow(text=Tkinter.Text())
    data = "foo = 1"
    t.set_input_line(data)
    hp = HyperParser(t.text, "%s.end" % t.io.lineno)
    assert hp.is_in_code()
    assert not hp.is_in_string()

    assert hp.get_expression() == "1"

    assert hp.get_surrounding_brackets(mustclose=1) is None
    assert hp.get_surrounding_brackets() == (
        "1.0",
        "1.end",
    )

# Generated at 2022-06-26 07:40:43.542656
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    str_0 = "kbd()(^T8VFwO$"
    bool_0 = True
    rough_parser_0 = RoughParser(str_0, bool_0)

    assert(None == rough_parser_0.get_base_indent_string())


# Generated at 2022-06-26 07:40:50.592056
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():

    # Generate inputs
    str_1 = "4&\nA\n]"
    bool_1 = True
    rough_parser_1 = RoughParser(str_1, bool_1)
    int_0 = 2
    rough_parser_1.indent_width = int_0
    int_1 = 1
    rough_parser_1.tabwidth = int_1
    rough_parser_1._study2()

    # Call the method
    int_2 = rough_parser_1.compute_bracket_indent()

    # Check the output
    assert int_2 == 3


# Generated at 2022-06-26 07:40:52.984092
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    str_1 = "=qC|*Q0Eb;~:H,p'6"

    str_2 = "{return (x0','x1')}"
    int_0 = 11
    int_1 = 12
    hyper_parser_0 = HyperParser(str_2, int_0)


# Generated at 2022-06-26 07:41:05.363700
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = "x == y\n"
    hyper_parser_0 = HyperParser(text, "1.3")
    assert hyper_parser_0.rawtext == "x == y"
    assert hyper_parser_0.stopatindex == "2.0"
    assert hyper_parser_0.bracketing == [(0, 0)]
    assert hyper_parser_0.isopener == [False]
    assert hyper_parser_0._eat_identifier(hyper_parser_0.rawtext, 0, 3) == 1
    assert hyper_parser_0._eat_identifier(hyper_parser_0.rawtext, 0, 2) == 0
    assert hyper_parser_0.get_expression() == "y"

# Generated at 2022-06-26 07:41:16.844106
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    tk = Tk()

    #Create a text widget
    text = Text(tk)
    text.pack()

# Generated at 2022-06-26 07:42:21.346978
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-26 07:42:27.939566
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    """Unit test for method get_surrounding_brackets of class HyperParser"""

    text_0 = Tkinter.Text()
    int_0 = 0
    hyper_parser_0 = HyperParser(text_0, int_0)
    str_0 = "([{"
    bool_0 = False
    tuple_0 = hyper_parser_0.get_surrounding_brackets(str_0, bool_0)
    return None


# Generated at 2022-06-26 07:42:31.072465
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    test_case_0()

if __name__ == "__main__":
    test_RoughParser_get_last_open_bracket_pos()

# Generated at 2022-06-26 07:42:38.254582
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    if DEBUG_DET_INDENT_MODE:
        print("test_RoughParser_compute_bracket_indent")
    rough_parser_0 = RoughParser("", False)
    assert_equals(rough_parser_0.compute_bracket_indent(), 0)


# Generated at 2022-06-26 07:42:41.762295
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    str_0 = 'def foo():\n    a = 1\nb = 2'
    num_lines = RoughParser(str_0, False).get_num_lines_in_stmt()
    assert num_lines == 2


# Generated at 2022-06-26 07:42:54.364639
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # print("\nUNIT TEST for method set_lo of class RoughParser")

    class RoughParserStub(RoughParser):
        # This is a stub class to facilitate unit testing.
        # It overrides the constructor and the set_lo method
        # to keep track of what is happening.

        def __init__(self, str_1, bool_1):
            RoughParser.__init__(self, str_1, bool_1)
            self.log = []
            self.log.append("init")

        def set_lo(self, int_1):
            self.log.append("set_lo(%d)" % int_1)
            RoughParser.set_lo(self, int_1)

    # TEST 1 - Check the low setting of the first line
    #          when input is 0 lines and 0 characters

    test

# Generated at 2022-06-26 07:42:58.179426
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():

    # test 0
    str_0 = "=qC|*Q0Eb;~:H,p'6"
    bool_0 = True
    rough_parser_0 = RoughParser(str_0, bool_0)
    int_0 = rough_parser_0.find_good_parse_start()

    print(int_0)


# Generated at 2022-06-26 07:43:00.270666
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-26 07:43:12.126339
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    str_0 = "fW{'i}]*P!o)#:>|8WO"
    rough_parser_0 = RoughParser(str_0)
    rough_parser_0.parser_0 = 0
    rough_parser_0.set_lo(rough_parser_0.parser_0)
    str_1 = "2S9n;?-Lq3=5$5B}\"c,#"
    rough_parser_0.set_str(str_1)
    # TODO: fix weird text
    text_0 = Text(str_1)
    # TODO: fix weird text
    text_0.bod = 0
    hyper_parser_0 = HyperParser(text_0, 0)
    hyper_parser_0.set_index(0)

# unit test for class Hyper

# Generated at 2022-06-26 07:43:16.832684
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text_0 = "a = ''''\n"
    index_0 = "1.1"
    hyper_parser_0 = HyperParser(text_0, index_0)
    bool_0 = hyper_parser_0.is_in_string()

    assert not bool_0
