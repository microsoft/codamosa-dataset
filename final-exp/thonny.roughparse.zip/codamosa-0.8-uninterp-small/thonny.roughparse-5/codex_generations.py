

# Generated at 2022-06-26 07:38:10.781875
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # Check HyperParser.get_expression for a simple function call
    # with no arguments
    s = 'a = f()'
    hp = HyperParser(s, '1.4')
    assert hp.get_expression() == 'f'

    # Check HyperParser.get_expression for a method call
    s = 'a = b.f()'
    hp = HyperParser(s, '1.6')
    assert hp.get_expression() == 'b.f'

    # Check HyperParser.get_expression for a method call
    s = 'a = b.f()'
    hp = HyperParser(s, '1.7')
    assert hp.get_expression() == 'f'

    # Check HyperParser.get_expression for a method call
    s = 'a = b.f.g()'
    hp = HyperParser

# Generated at 2022-06-26 07:38:14.507257
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    bool_1 = True
    str_1 = ')*GX'
    rough_parser_1 = RoughParser(bool_1, str_1)
    rough_parser_1.set_lo(5, ")GX")


# Generated at 2022-06-26 07:38:17.402386
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = '\n'
    rough_parser_0 = RoughParser(False, str_0)
    rough_parser_0.compute_backslash_indent()


# Generated at 2022-06-26 07:38:29.062378
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():

    # Define data
    str_0 = ')/(*\n#\n'

    # Invoke method
    rough_parser_0 = RoughParser(True, str_0)
    var_0 = rough_parser_0.get_continuation_type()
    assert_equals(var_0, 1)

    str_0 = '#\n'

    rough_parser_0 = RoughParser(True, str_0)
    var_0 = rough_parser_0.get_continuation_type()
    assert_equals(var_0, 0)

    str_0 = 'import random\n\nprint("Hello World")\n'

    rough_parser_0 = RoughParser(True, str_0)
    var_0 = rough_parser_0.get_continuation_type()

# Generated at 2022-06-26 07:38:41.185209
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    hp = HyperParser(test_text, "7.0")

    exp = hp.get_expression()
    assert exp == "m"

    hp.set_index("8.0")
    exp = hp.get_expression()
    assert exp == "methods[-1][0]"

    hp.set_index("13.0")
    exp = hp.get_expression()
    assert exp == "s"

    hp.set_index("14.0")
    exp = hp.get_expression()
    assert exp == "str"

    hp.set_index("15.0")
    exp = hp.get_expression()
    assert exp == "str()"

    hp.set_index("17.0")
    exp = hp.get_expression()
    assert exp == "x"

    # FIXME: This is a

# Generated at 2022-06-26 07:38:44.959674
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    non_defaults = {45: 45, 46: 46}
    default_value = 47
    mapping = StringTranslatePseudoMapping(non_defaults, default_value)
    assert next(iter(mapping)) == 45
    assert next(iter(mapping)) == 46



# Generated at 2022-06-26 07:38:45.770510
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    pass


# Generated at 2022-06-26 07:38:48.991521
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    str_0 = '  s = {a:b for a,b in enumerate("12345")}'
    idx = '1.35'
    text_0 = Text(idx)
    text_0.insert(idx, str_0)
    hyper_parser_0 = HyperParser(text_0, idx)
    hyper_parser_0.set_index(idx)


# Generated at 2022-06-26 07:38:59.528702
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    import random
    import string
    # This can be any string, as long as it is not empty.
    str_0 = ")"
    # This can be any integer, as long as it is not less than zero or
    # greater than or equal to len(str_0)
    #
    # NOTE: We use len(str_0) - 1 instead of len(str_0) because Tk
    # uses 1-based indexes.
    int_0 = len(str_0) - 1
    # The index given to the HyperParser must be in the same
    # statement, so we set the stopatindex to be the same as the index.
    stopatindex_0 = str_0 + ".end"
    # Despite the name, text_0 is actually a Text widget.
    text_0 = Text(None)

# Generated at 2022-06-26 07:39:02.779758
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-26 07:40:39.893665
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    tcl = Tk()
    t = scrolledtext.ScrolledText(
        tcl,
        undo=True,
        height=30,
        width=80,
        bg="lightgray",
        font=("arial", 12, "normal"),
        wrap=WORD,
        relief=GROOVE,
    )
    t.pack(expand=YES, fill=BOTH)
    tcl.mainloop()


# Generated at 2022-06-26 07:40:50.108113
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    print('test_RoughParser_find_good_parse_start...')
    rp = RoughParser(False, "x = {'\\n': [1,\n2, 3]}\n")
    assert rp.find_good_parse_start() == 0
    rp = RoughParser(False, "x = {'\\n': [1,\n2, 3]}\nx")
    assert rp.find_good_parse_start() == 0
    rp = RoughParser(False, "x = {'\\n': [1,\n2, 3]}\n\n")
    assert rp.find_good_parse_start() == 0
    rp = RoughParser(False, "\n\nx = {'\\n': [1,\n2, 3]}\n")
    assert rp.find

# Generated at 2022-06-26 07:40:56.956170
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    """Verifies that HyperParser.get_expression method works correctly."""

    parser = HyperParser(text, index)
    expression = parser.get_expression()

    # Test that the returned expression is correct.
    assert expression == expected_expression, "Wrong expression (expression = %r, expected_expression = %r)." % (expression, expected_expression)


# Generated at 2022-06-26 07:41:01.277036
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    hyper_parser_0 = HyperParser(True, True)
    result_0 = hyper_parser_0.get_expression()
    assert result_0 == "", "get_expression returned"


# Generated at 2022-06-26 07:41:12.692305
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # This test case causes a bug on the original libanalyze.py
    #file_0 = open('bug.py', 'rU')
    #content_0 = file_0.read()
    #hyper_parser_0 = HyperParser(content_0, '1.7')
    #hyper_parser_0.is_in_code()
    #reverse the content_0 and remove the comment line, then it works
    file_0 = open('bug.py', 'rU')
    content_0 = file_0.read()
    hyper_parser_0 = HyperParser(content_0, '1.7')
    hyper_parser_0.is_in_code()

if __name__ == "__main__":
    test_HyperParser_is_in_code()

# Generated at 2022-06-26 07:41:24.979544
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    str_0 = 'var_0 = rough_parser_0.get_last_stmt_bracketing()'
    len_0 = len(str_0)
    hyper_parser_0 = HyperParser(
        Text(
            tabsize=4,
            endline="\n",
            lines=str_0
        ), str_0 + "."
    )
    hyper_parser_0.get_surrounding_brackets()
    hyper_parser_0.get_surrounding_brackets(openers="([{", mustclose=False)
    hyper_parser_0.get_surrounding_brackets(openers="([{", mustclose=True)
    

# Generated at 2022-06-26 07:41:32.041085
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    with open("test/test.py") as f:
        text = f.read()
    text = text.replace("print", "")

    hyperParser = HyperParser(text, "1.1")
    output = hyperParser.get_surrounding_brackets()

    assert output == (0, len(text))

# Generated at 2022-06-26 07:41:33.775267
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    pass



# Generated at 2022-06-26 07:41:37.864656
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rough_parser_0 = RoughParser(False, "2.6")
    rough_parser_0._study2()
    var_0 = rough_parser_0.compute_backslash_indent()
    print(var_0)


# Generated at 2022-06-26 07:41:50.039256
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # Test case 0
    bool_0 = True
    str_0 = 'O4c%[RMPE"gC'
    str_1 = '0G0l25E*_J='
    str_2 = "B\n0J#*"
    rough_parser_0 = RoughParser(bool_0, str_0)
    rough_parser_1 = RoughParser(str_1, str_2)
    assert not rough_parser_0.is_in_code()
    assert rough_parser_1.is_in_code()
    # Test case 1
    bool_0 = False
    str_0 = 'O4c%[RMPE"gC'
    str_1 = '0G0l25E*_J='
    str_2 = "B\n0J#*"
    rough

# Generated at 2022-06-26 07:43:58.952575
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    pass


# Generated at 2022-06-26 07:44:03.275389
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text_0 = Text()
    index_0 = '1.0'
    hyper_parser_0 = HyperParser(text_0, index_0)
    hyper_parser_1 = HyperParser(text_0, index_0)
    hyper_parser_2 = HyperParser(text_0, index_0)



# Generated at 2022-06-26 07:44:08.544032
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # Unit test for method is_in_string of class HyperParser

    # This is true (the index is inside a string)
    str_0 = 'String with a quote in the middle \'.'
    hyper_parser_0 = HyperParser(str_0, 10)
    assert hyper_parser_0.is_in_string() == True
    # This is true (the index is inside a string)
    str_0 = 'String with a quote in the middle \'.'
    hyper_parser_0 = HyperParser(str_0, len(str_0) - 1)
    assert hyper_parser_0.is_in_string() == True
    # This is true (the index is inside a string)
    str_0 = 'String with a quote in the middle \'.'
    hyper_parser_0 = HyperParser(str_0, 0)
   

# Generated at 2022-06-26 07:44:17.112795
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():

    # Test 0
    # Check if is_in_code throws a ValueError when
    # is_in_code is called for a HyperParser that is not in code
    #
    # We create a HyperParser that is in a string and then call is_in_code
    #
    # This should throw a ValueError
    #
    
    rough_parser_0 = RoughParser(False, file=__file__)
    hyper_parser_0 = HyperParser(rough_parser_0, 0)
    
    try:
        hyper_parser_0.is_in_code()
        assert False
    except ValueError:
        pass

    # Test 1
    # Check if is_in_code returns the correct value for
    # a HyperParser that is in code
    #
    # We create a HyperParser that is in code and then call is

# Generated at 2022-06-26 07:44:26.280840
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    r'''Test is_in_string.'''
    # From test_parenmatch.py
    c = r'''
        class A:
            def __call__(self):
                print(self)
        A()
        ####
        def f(x,y):
            return "a string "+ str(x + y)
        f(1,2)
        ####
        # A comment
        ####
        "a string"
        ####
        """a docstring"""
        ####
        '''


# Generated at 2022-06-26 07:44:34.461348
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    bool_0 = True

# Generated at 2022-06-26 07:44:39.796122
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # Test cases
    # Make sure that the test case runs in any directory.
    root = tk.Tk()
    root.title('Text')
    text = tkst.ScrolledText(root, width=40, height=10)
    text.pack()
    text.insert('1.0', " 1.0")

# Generated at 2022-06-26 07:44:46.360946
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # Create a test Text widget with a sample Python code
    text = Text(None, takefocus=0)
    text.insert("end", "import os\n" "dirname = os.getcwd()\n" "os.chdir(dirname + '.')\n")
    # Set up a HyperParser instance which can parse the code
    hp = HyperParser(text, "3.end")
    # Perform the test
    assert hp.get_expression() == "os.getcwd"


# Generated at 2022-06-26 07:44:50.719118
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-26 07:44:57.040103
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    test_string = """def test():
        obj.str_0 = ')"'
        obj.str_1 = 'a'
        return a.b.c.d
    """
    hyper_parser_0 = HyperParser(test_string, test_string.rfind("c"))
    assert hyper_parser_0.get_expression() == "a.b.c"
    hyper_parser_1 = HyperParser(test_string, test_string.rfind("a"))
    assert hyper_parser_1.get_expression() == ""
