

# Generated at 2022-06-26 07:38:09.875839
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    float_0 = None
    str_0 = ''
    hyper_parser_0 = HyperParser(float_0, str_0)
    try:
        hyper_parser_0.set_index(str_0)
        assert False
    except ValueError as var_0:
        assert True


# Generated at 2022-06-26 07:38:19.462306
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-26 07:38:23.684607
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    float_0 = None
    str_0 = 'HyperParserTest.py'
    hyper_parser_0 = HyperParser(float_0, str_0)
    str_1 = 'class Foo:'
    hyper_parser_0.set_index(str_1)


# Generated at 2022-06-26 07:38:28.248708
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    float_0 = None
    str_0 = 'test'
    rough_parser_0 = RoughParser(float_0, str_0)
    rough_parser_0.get_num_lines_in_stmt()


# Generated at 2022-06-26 07:38:40.634890
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    indent_string = RoughParser.get_base_indent_string()
    assert indent_string == ''
    indent_string = RoughParser.get_base_indent_string()
    assert indent_string == ''
    indent_string = RoughParser.get_base_indent_string()
    assert indent_string == '    '
    indent_string = RoughParser.get_base_indent_string()
    assert indent_string == '  '
    indent_string = RoughParser.get_base_indent_string()
    assert indent_string == '    '
    indent_string = RoughParser.get_base_indent_string()
    assert indent_string == '    '
    indent_string = RoughParser.get_base_indent_string()
    assert indent_string == ' '

# Generated at 2022-06-26 07:38:43.116066
# Unit test for constructor of class HyperParser
def test_HyperParser():
    float_0 = None
    str_0 = ''
    hyper_parser_0 = HyperParser(float_0, str_0)
    return (hyper_parser_0)


# Generated at 2022-06-26 07:38:47.232365
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    float_0 = None
    str_0 = ''
    hyper_parser_0 = HyperParser(float_0, str_0)
    mapping_0 = hyper_parser_0._chew_ordinaryre
    str_1 = "abcd efg hij"
    str_2 = str_1.translate(mapping_0)
    assert (str_1 == str_2)


# Generated at 2022-06-26 07:38:50.949764
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    """Test for method is_in_code of class HyperParser"""
    float_0 = None
    str_0 = ''
    hyper_parser_0 = HyperParser(float_0, str_0)
    assert hyper_parser_0.is_in_code() == None


# Generated at 2022-06-26 07:38:58.789812
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    text = 'def foo():\n    a=1\n    b=2\n    # comment\n    c=3\n'
    parser = RoughParser(text)
    parser.study_level = 3
    parser.study_level = 3
    parser.stmt_start = 12
    parser.str = text
    
    result = parser.compute_backslash_indent()
    assert result == 5, 'Test case failed, result = %d' % result


# Generated at 2022-06-26 07:39:02.023964
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    """
    string = '''a = 1
        b = 2
        if a == b:
            print('yes')
    '''
    #  RoughParser.find_good_parse_start(string)
    """
    pass


# Generated at 2022-06-26 07:42:21.769984
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    str_0 = "\n    string = '''a = 1\n        b = 2\n        if a == b:\n            print('yes')\n    '''\n    #  RoughParser.find_good_parse_start(string)\n    "
    str_1 = "string = '''a = 1\n        b = 2\n        if a == b:\n            print('yes')\n    '''\n    #  RoughParser.find_good_parse_start(string)\n    "
    str_2 = "print('yes')\n    '''\n    #  RoughParser.find_good_parse_start(string)\n    "

# Generated at 2022-06-26 07:42:25.203100
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    string = "    if a == 1:\n"
    rp = RoughParser(string)
    assert rp.get_base_indent_string() == "    "


# Generated at 2022-06-26 07:42:31.856663
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_0 = "\n    string = '''a = 1\n        b = 2\n        if a == b:\n            print('yes')\n    '''\n    #  RoughParser.find_good_parse_start(string)\n    "
    result = RoughParser.find_good_parse_start(str_0)
    assert result == 1

# Generated at 2022-06-26 07:42:37.989207
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    str_0 = "\n    string = '''a = 1\n        b = 2\n        if a == b:\n            print('yes')\n    '''\n    #  RoughParser.find_good_parse_start(string)\n    "


# Generated at 2022-06-26 07:42:45.275522
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    string = "a = 1\n    b = 2\n    if a == b:\n        print('yes')\n"

    parser = RoughParser(string)
    assert parser.get_base_indent_string() == '    '
    assert parser.get_continuation_type() == C_NONE
    assert parser.goodlines == [0, 4]
    assert parser.get_last_stmt_bracketing() == ((0, 0), (1, 0), (2, 1), (3, 0), (12, 0))
    assert parser.is_block_opener() == True
    assert parser.is_block_closer() == False
    assert parser.get_last_open_bracket_pos() == 2
    # print(parser.get_num_lines_in_stmt())
    assert parser.get

# Generated at 2022-06-26 07:42:50.857574
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    string = "\n    string = '''a = 1\n        b = 2\n        if a == b:\n            print('yes')\n    '''\n    #  RoughParser.find_good_parse_start(string)\n    "
    index = string.index('b')
    parser = HyperParser(string,index)
    res = parser.get_surrounding_brackets('([{',True)
    string = "\n    string = '''a = 1\n        b = 2\n        if a == b:\n            print('yes')\n    '''\n    #  RoughParser.find_good_parse_start(string)\n    "
    index = string.index('a')
    parser = HyperParser(string,index)

# Generated at 2022-06-26 07:42:58.976927
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin
    str_0 = "\n    string = '''a = 1\n        b = 2\n        if a == b:\n            print('yes')\n    '''\n    #  RoughParser.find_good_parse_start(string)\n    "
    rough_parser_0 = RoughParser(str_0, indent_width=4)
    assert (rough_parser_0.get_base_indent_string() == '    ')
    assert (rough_parser_0.is_block_closer() == False)
    assert (rough_parser_0.is_block_opener() == True)
    assert (rough_parser_0.get_num_lines_in_stmt() == 1)

# Generated at 2022-06-26 07:43:01.125441
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    assert (
        RoughParser(str_0).compute_backslash_indent() == 5
    )  # test with args. 


# Generated at 2022-06-26 07:43:10.281661
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    h = HyperParser("\n    string = '''a = 1\n        b = 2\n        if a == b:\n            print('yes')\n    '''\n    #  RoughParser.find_good_parse_start(string)\n    ", "8.0")
    expected_1 = ((34, 66),)
    actual_1 = h.get_surrounding_brackets()
    assert actual_1 == expected_1

if __name__ == '__main__':
    test_HyperParser_get_surrounding_brackets()
    unittest.main()

# Generated at 2022-06-26 07:43:16.955121
# Unit test for constructor of class HyperParser
def test_HyperParser():
    str_0 = "\n    string = '''a = 1\n        b = 2\n        if a == b:\n            print('yes')\n    '''\n    #  RoughParser.find_good_parse_start(string)\n    "
    from tkinter.scrolledtext import ScrolledText
    text = ScrolledText()
    text.insert("end", str_0)
    obj = HyperParser(text, 3.2)



# Generated at 2022-06-26 07:44:34.080968
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-26 07:44:37.358323
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rp = RoughParser(str_0)
    assert rp.compute_backslash_indent() == 4



# Generated at 2022-06-26 07:44:45.203304
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    global str_0
    parser = HyperParser(str_0, '1.0')

# Generated at 2022-06-26 07:44:51.685922
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Tkinter.Text()
    text.insert(END,str_0)
    text.pack()
    parser=HyperParser(text,text.index('end'))
    parser.is_in_string()
    text.delete(1.0,END)
    text.destroy()


# Generated at 2022-06-26 07:44:54.285002
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from idlelib.idle_test.htest import run
    run(HyperParser)

if __name__ == "__main__":
    test_HyperParser()

# Generated at 2022-06-26 07:45:01.442713
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    str_0 = "\n    string = '''a = 1\n        b = 2\n        if a == b:\n            print('yes')\n    '''\n    #  RoughParser.find_good_parse_start(string)\n    "

    # Call the method
    actual = RoughParser(str_0).compute_bracket_indent()

    # Check the result
    assert actual == 8, "%s != %s" % (actual, 8)


# Generated at 2022-06-26 07:45:08.346548
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    hyper = HyperParser(None, None)
    hyper.is_in_string()
    hyper.is_in_string()
    hyper.is_in_string()
    hyper.is_in_string()
    hyper.is_in_string()
    hyper.is_in_string()
    hyper.is_in_string()
    hyper.is_in_string()
    hyper.is_in_string()
    hyper.is_in_string()
    hyper.is_in_string()


# Generated at 2022-06-26 07:45:13.234265
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    pass


if __name__ == "__main__":
    test_case_0()

"""
python -m doctest -v /Users/alex/Documents/Python/Python-Test/Python-Test/python3/HyperParser.py
"""

# Generated at 2022-06-26 07:45:20.662722
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = "\n    string = '''a = 1\n        b = 2\n        if a == b:\n            print('yes')\n    '''\n    #  RoughParser.find_good_parse_start(string)\n    "
    string_2 = str_0
    # Test method compute_backslash_indent of class RoughParser
    rp = RoughParser(string_2)
    assert rp.compute_backslash_indent() == 5

# Generated at 2022-06-26 07:45:23.941702
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    string = '''a = 1
        b = 2
        if a == b:
            print('yes')
    '''
    hyper_parser = HyperParser(string, 1)
    assert hyper_parser.is_in_code()


# Generated at 2022-06-26 07:46:43.133601
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    str_0 = ' yA0Z>A'
    list_0 = [str_0]
    rough_parser_0 = RoughParser(str_0, list_0)
    rough_parser_0.set_lo(100)
    rough_parser_0.set_lo(0)


# Generated at 2022-06-26 07:46:46.909790
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    str_0 = []
    list_0 = []
    rough_parser_0 = RoughParser(str_0, list_0)
    rough_parser_0.set_lo(int_0=123, int_1=254, boolean_0=True)



# Generated at 2022-06-26 07:46:52.263869
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    str_0 = "A"
    tk_0 = Text(width=len(str_0))
    tk_0.insert(INSERT, str_0)
    idx_0 = tk_0.index(INSERT)
    hyper_parser_0 = HyperParser(tk_0, idx_0)
    assert hyper_parser_0.is_in_code() is True