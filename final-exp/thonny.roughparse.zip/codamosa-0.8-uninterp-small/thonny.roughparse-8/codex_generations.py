

# Generated at 2022-06-26 07:39:47.241087
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    bytes_0 = b'\xabN\x17\x99cny\xc04g=\xaf>\xb8ny\x96\xdb'
    bool_0 = False
    rough_parser_0 = RoughParser(bytes_0, bool_0)
    string_0 = 'Z\u000f\u001a-\u0017\x7f%\u000e+\u0014@"\x7f%\u000e+\u0014@"\x7f%\u000e+\u0014@"'
    string_1 = '\u001a-\u0017\x7f%\u000e+\u0014@"\x7f%\u000e+\u0014@"\x7f%\u000e+\u0014@"'


# Generated at 2022-06-26 07:39:52.897490
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text_0 = StringVar()
    int_0 = 30
    index_0 = 2
    hyper_parser_0 = HyperParser(text_0, int_0)
    # Test set_index()
    hyper_parser_0.set_index(index_0)
    # Test get_surrounding_brackets()
    str_0 = '\x94\xd7\x0e\x9f\x97\xd2\x0e\xd2\x8c'
    str_1 = None
    bool_0 = False
    tuple_0 = hyper_parser_0.get_surrounding_brackets(str_0, bool_0)
    # Test get_expression()
    str_2 = hyper_parser_0.get_expression()
    # Test is_in_code()
    bool_1

# Generated at 2022-06-26 07:39:53.837027
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    test_HyperParser_get_expression_0()


# Generated at 2022-06-26 07:39:57.866519
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    """Test get_expression of HyperParser"""

    # Create the Tkinter text widget
    toplevel = tkinter.Tk()
    text = tkinter.Text(toplevel)
    text.insert('1.1', "this\n is a\n test")

    # Create the HyperParser object
    hp = HyperParser(text, '3.3')

    # Test the get_expression method
    assert(hp.get_expression() == "test")

    # Cleanup
    text.destroy()


# Generated at 2022-06-26 07:40:06.911352
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    # pylint: disable=redefined-builtin
    bytes_0 = b'\xabN\x17\x99cny\xc04g=\xaf>\xb8ny\x96\xdb'
    bool_0 = False
    rough_parser_0 = RoughParser(bytes_0, bool_0)
    rough_parser_0._study2()
    stmt_bracketing_0 = rough_parser_0.get_last_stmt_bracketing()
    assert isinstance(stmt_bracketing_0, tuple)
    assert stmt_bracketing_0 == ()
    # pylint: enable=redefined-builtin


# Generated at 2022-06-26 07:40:13.539528
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # Test 0
    # pylint: disable=redefined-builtin
    bytes_0 = b'\xabN\x17\x99cny\xc04g=\xaf>\xb8ny\x96\xdb'
    bool_0 = False
    rough_parser_0 = RoughParser(bytes_0, bool_0)
    rough_parser_0.compute_backslash_indent()
    


# Generated at 2022-06-26 07:40:20.410018
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # Given
    bytes_0 = b'\xabN\x17\x99cny\xc04g=\xaf>\xb8ny\x96\xdb'
    bool_0 = False
    rough_parser_0 = RoughParser(bytes_0, bool_0)
    # Test
    hyper_parser_0 = HyperParser(rough_parser_0, bool_0)
    hyper_parser_0.set_index(bytes_0)


# Generated at 2022-06-26 07:40:29.020598
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    bytes_0 = b'*\xcd\xddC\xc1\xeb\xbe\xa3\xef\x88\x98\xdaA\x92\xcc\xe2'

# Generated at 2022-06-26 07:40:35.303008
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    bytes_0 = b'\xabN\x17\x99cny\xc04g=\xaf>\xb8ny\x96\xdb'
    bool_0 = True
    rough_parser_0 = RoughParser(bytes_0, bool_0)
    rough_parser_0.compute_bracket_indent()
    rough_parser_0.compute_bracket_indent()
    rough_parser_0.get_continuation_type()


# Generated at 2022-06-26 07:40:39.497802
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    bytes_0 = b'\xabN\x17\x99cny\xc04g=\xaf>\xb8ny\x96\xdb'
    bool_0 = False
    rough_parser_0 = RoughParser(bytes_0, bool_0)
    rough_parser_0.set_lo(15)


# Generated at 2022-06-26 07:41:14.500781
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    bytes_0 = b'\xde\x1b\x1f\xe9\x81\x8b\x1f\xbf\xe2\x80\x8a\x92PB\xa9\x16\x0e\r\x10\x12\x1a\xaa'
    bytes_1 = b'\xa9}\xa1\x8a\x99\xbb\xd0\xab\x1f\xd1\x9cy\x8a\xfe\xc3\xf6\xad\x1e\x97\xde\xa9'

# Generated at 2022-06-26 07:41:30.128695
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    check_map = {} # Dictionary to hold results of negative tests
    check_map[0] = b'*\xcd\xddC\xc1\xeb\xbe\xa3\xef\x88\x98\xdaA\x92\xcc\xe2'
    # Should raise SyntaxError if the string is not valid Python source
    # code.
    bytes_0 = b'*\xcd\xddC\xc1\xeb\xbe\xa3\xef\x88\x98\xdaA\x92\xcc\xe2'
    try:
        RoughParser(bytes_0).get_num_lines_in_stmt()
        raise AssertionError()
    except SyntaxError:
        pass
    # Should raise SyntaxError if the string is empty.
    bytes

# Generated at 2022-06-26 07:41:43.224403
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    """A test suite for class HyperParser, method is_in_code."""

    def fake_data(lhs):
        return lhs
    def fake_data():
        return '', '', '', ''

    text = Text(fake_data())
    index = '1.0'
    text.index = lambda: index
    text.get = lambda start, end: fake_data()

    hyperparser = HyperParser(text, index)

    # testing that HyperPaser._eat_identifier is implemented correctly
    hyperparser.text = Text(fake_data())
    hyperparser.index = 1
    hyperparser.stopatindex = 5

    # test 1
    hyperparser.text.get = lambda: 'abc'
    ret = hyperparser._eat_identifier(hyperparser.text.get(), 2, 5)

# Generated at 2022-06-26 07:41:49.617515
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    s = "1234\n" "2345\n" "3456\n" "4567"
    for i in range(len(s)):
        j, k = RoughParser(s, i).find_good_parse_start()
        # print(j, k)
        assert j <= i < k
        assert s[j:k].strip() in RoughParser._goodparsere.findall(s)


# Generated at 2022-06-26 07:41:52.593780
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    h = HyperParser('', '1.0')
    # error
    with raises(ValueError, message=''):
        h.set_index('1.0')


# Generated at 2022-06-26 07:41:54.440721
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    RoughParser = RoughParser('\t')
    RoughParser.compute_backslash_indent()


# Generated at 2022-06-26 07:41:57.515729
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    global text, index
    text = tk.Text()
    text.insert(0.0, 'abc\ndef\nghi')
    index = '2.0'
    help_set_index(text, index)


# Generated at 2022-06-26 07:42:09.799251
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    logger = logging.getLogger("test_RoughParser_compute_bracket_indent")
    rough_parser = RoughParser("a = {1: 1, \n2: 2, \n3: 3, \n4: 4, \n5: 5, \n6: {6: 6, 7: 7, 8: 8, 9: 9, 10: 10}")
    assert rough_parser.compute_bracket_indent() == rough_parser.indent_width
    rough_parser = RoughParser("a = {1: 1, \n2: 2, \n3: 3, \n4: 4, \n5: 5, \n(6: 6, 7: 7, 8: 8, 9: 9, 10: 10)}")
    assert rough_parser.compute_bracket_indent() == rough_parser

# Generated at 2022-06-26 07:42:15.729844
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    start_index = 0
    stop_index = 0
    input_string = ""
    openers = ""
    mustclose = False
    hyper_parser = HyperParser(input_string, start_index)
    result = hyper_parser.get_surrounding_brackets(openers, mustclose)
    print(result)



# Generated at 2022-06-26 07:42:22.719493
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    start_str = "    while True:\n"
    end_str = "        r = r + 1\n"
    test_str = start_str + end_str
    rp = RoughParser(test_str)
    indent = rp.compute_bracket_indent()
    assert indent == rp.indent_width
    assert indent == 4 * rp.indent_unit
    test_str = start_str.replace('    ', '') + end_str
    rp = RoughParser(test_str)
    indent = rp.compute_bracket_indent()
    assert indent == rp.indent_width
    assert indent == 4 * rp.indent_unit
    test_str = start_str + '   ' + end_str
    rp = RoughParser(test_str)


# Generated at 2022-06-26 07:43:27.291101
# Unit test for constructor of class HyperParser
def test_HyperParser():
    bytes_0 = b'*\xcd\xddC\xc1\xeb\xbe\xa3\xef\x88\x98\xdaA\x92\xcc\xe2'
    bytes_1 = b'\xbb\x8c\xbe\xfe\x0f\xdca\x8d\x1cU\xcf\x95\xaf\xe5\x89\xa7y\xe0\x8b\x80\x95\x04\x86\xb1\x81i\xbb\xd3\xcd\xf6\x9f\x7f\xc5\xfd\xeb\xfd\xcf\xd6\xef'
    test_text = bytes_0 + bytes_1

# Generated at 2022-06-26 07:43:32.607532
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rp = RoughParser(b"  [\n  123\n]", 0, 0)
    assert rp.compute_bracket_indent() == 2
    rp = RoughParser(b"  [\n  123\n]", 0, 3)
    assert rp.compute_bracket_indent() == 4
    rp = RoughParser(b"  [\n  123\n]", 0, 1)
    assert rp.compute_bracket_indent() == 5


# Generated at 2022-06-26 07:43:37.360823
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # TODO: Add more tests
    text = Text(
        """
    class Foo:
        def __init__(self, arg):
            self.arg = arg
"""
    )
    # assert False  # TODO: Implement test


# Generated at 2022-06-26 07:43:47.301421
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
  # pylint: disable=redefined-builtin
  reader = codecs.getdecoder("rot-13")
  deobf_reader = lambda s: reader(s)[0]
  # Test empty string
  rp = RoughParser("")
  assert rp.get_base_indent_string() == ""
  # Test that indentation on first line is not returned
  hparser = RoughParser("\n")
  assert hparser.get_base_indent_string() == ""
  # Test last line without '\n'
  hparser = RoughParser("a = 1")
  assert hparser.get_base_indent_string() == ""
  # Test indentation of middle lines
  hparser = RoughParser("a = 1\n\tb = 2")
  assert hparser.get_base_indent_

# Generated at 2022-06-26 07:43:56.489514
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    rp = RoughParser("")
    assert rp.find_good_parse_start(0) == 0
    rp = RoughParser("\n")
    assert rp.find_good_parse_start(0) == 0
    assert rp.find_good_parse_start(1) == 1

    rp = RoughParser(" \n")
    assert rp.find_good_parse_start(0) == 0
    assert rp.find_good_parse_start(2) == 2

    rp = RoughParser("#\n")
    assert rp.find_good_parse_start(0) == 0
    assert rp.find_good_parse_start(2) == 2

    rp = RoughParser("'''\n")
    assert rp.find_good_parse_start(0) == 0

# Generated at 2022-06-26 07:44:01.904193
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text_0 = Text()
    text_0.insert('1.0', 'bug!')
    text_0.insert('2.0', 'woof')
    hyperparser_0 = HyperParser(text_0, '1.0')
    hyperparser_0.set_index('1.0')
    assert hyperparser_0.is_in_string() == False


# Generated at 2022-06-26 07:44:07.965425
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-26 07:44:17.051086
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rp = RoughParser("")
    assert rp.compute_bracket_indent()==0
    rp = RoughParser("a")
    assert rp.compute_bracket_indent()==0
    # rp = RoughParser("\n")
    # assert rp.compute_bracket_indent()==0
    rp = RoughParser("(")
    assert rp.compute_bracket_indent()==0
    rp = RoughParser("(\n")
    assert rp.compute_bracket_indent()==0
    rp = RoughParser("(\n    ")
    assert rp.compute_bracket_indent()==0
    rp = RoughParser("(\n\n ")
    assert rp.compute_bracket_indent()==1


# Generated at 2022-06-26 07:44:19.294699
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    # Test default case of get_base_indent_string
    lft = RoughParser(bytes_0, 'utf-8')
    assert lft.get_base_indent_string() == ''


# Generated at 2022-06-26 07:44:22.653646
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text_0 = Tk()
    index_0 = Tk()
    index_1 = Tk()
    grr_0 = HyperParser(text_0, index_0, index_1)
    grr_0.set_index(index_1)


# Generated at 2022-06-26 07:45:29.280116
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text, bytes_0 = prepare_data_for_test_HyperParser()
    index = Tkinter.Tk().call('tk', 'index', 'end - 1c')
    expected_value = 0
    actual_value = 0
    hp = HyperParser(text, index)

    hp.set_index(index)
    assert actual_value == expected_value


# Generated at 2022-06-26 07:45:40.970888
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    with support.captured_stdout() as stdout:
        hyper_parser = HyperParser(Text, 1.0)
        hyper_parser.text = "testing"
        hyper_parser.rawtext = "testing"
        hyper_parser.stopatindex = "testing"
        hyper_parser.bracketing = ((0, 0), (0, 0), (0, 0), (0, 0), (0, 0), (0, 0), (0, 0))
        hyper_parser.isopener = [True, True, True, True, True, True, True]
        hyper_parser.indexinrawtext = 6
        hyper_parser.indexbracket = 6
        # Testing with openers as '('
        actual_value = hyper_parser.get_expression()
        expected_value = "testing"
        assert actual_value == expected

# Generated at 2022-06-26 07:45:43.420952
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # Constructor call
    hp = HyperParser(test_case_0(), test_case_0())

    pass



# Generated at 2022-06-26 07:45:54.141339
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    # Python source: input.py
    # Source code for roughparser module

    """Scanner for rough parsing of Python."""

    _commentre = re.compile(r"#.*")
    _itemre = re.compile(r"[-+*/%,<>=!(){}\[\]]")
    _nonalnumre = re.compile(r"[^A-Za-z0-9_]")
    _closere = re.compile(r"[)}]")

    # Chew matching string, ignoring backslashes and triple quotes.

# Generated at 2022-06-26 07:45:55.605036
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    print("Testing RoughParser.compute_bracket_indent")
    test_case_0()


# Generated at 2022-06-26 07:46:05.787719
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    bytes_0 = b'\x0f\x80\x8c\x92\xf7\x82\xbe\x13\xa9B\xfb\xeb\xdb\xab\x96\x82\xfa\xdb\x18\x8b\x9c\xc2\x82\xbf\xec\xdc\xa1\xfb\xa5\x10\xcf'
    text_0 = Text(tkt.data_encode(text_0))
    index_0 = u_0.index(u_1)
    hyperparser = HyperParser(text_0,index_0)

# Generated at 2022-06-26 07:46:09.552589
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    print('Test RoughParser.set_lo')

    parser = RoughParser()
    parser.set_lo(0)
    assert parser.lo == 0, 'Failed test_RoughParser_set_lo #1'


# Generated at 2022-06-26 07:46:21.915278
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    bytes_0 = (
        b'\xd3\xf1\x81\x8a\x0c\x90\x98H\x05\x9e\x00\xc6\x00\xfd\x00\xfd\x00\xfd\x00\xfd\x00\xfd\x00\xfd\x00'
    )
    # byte_0 is a bytearray because isinstance(byte_0, bytes) returns True.
    byte_0 = bytearray(bytes_0)
    int_0 = int(0)
    int_1 = int(1)
    str_0 = str('')
    str_1 = str('x')
    str_2 = str('67.0')
    str_3 = str('{')
    str_4 = str

# Generated at 2022-06-26 07:46:26.602167
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # Test that is_comment works correctly for multi-line strings
    # See http://bugs.python.org/issue17336
    formatter = IndentationFormatter()
    input_str = b"""if True:
    if True:  # foo
        pass
    elif True:  # foo
        pass
    else:  # foo
        pass
"""
    formatter.format(input_str)


# Generated at 2022-06-26 07:46:37.995301
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    str_0 = "a == b"
    str_1 = "a.b"
    str_2 = "a.b()"
    str_3 = "a.b()"
    str_4 = "a.b()"
    str_5 = "a.b()"
    str_6 = "a.b()"
    str_7 = "a.b()"
    str_8 = "a.b()"
    str_9 = "a.b()"
    str_10 = "a.b()"
    str_11 = "a.b()"
    str_12 = "a.b()"
    str_13 = "a.b()"
    str_14 = "a.b()"
    str_15 = "a.b()"