

# Generated at 2022-06-26 07:40:28.727429
# Unit test for constructor of class HyperParser
def test_HyperParser():
    string = 'the quick brown fox jumped over the lazy fox'
    offset = 40
    start_index = str(offset) + '.0'
    line_text = text.get(start_index, 'end')
    initial_text = text.get('1.0', 'end')

    parser = HyperParser(text, start_index)

    if parser.bracketing[0][0] != '0':
        raise RuntimeError('The bracketing of the first element is incorrect')
    if parser.bracketing[8][1] != '1':
        raise RuntimeError('The bracketing of the ninth element is incorrect')
    if parser.bracketing[6][0] != '4' and parser.bracketing[6][1] != '1':
        raise RuntimeError('The bracketing of the seventh element is incorrect')

# Generated at 2022-06-26 07:40:34.374757
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    code_string = "def max(x, y):\n    x = y\n    y = f(x, '''hello''')\n    if x > y:\n        return x\n    else:\n        return y\n"
    index = "1.0"
    hyp_parser = HyperParser(code_string, index)
    assert hyp_parser.is_in_code() == True, "Failed"


# Generated at 2022-06-26 07:40:44.967551
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-26 07:40:52.576968
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-26 07:40:58.553497
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = 'A{o[zW8_v!oM-2s(s}'
    rough_parser_0 = RoughParser(str_0, str_0)
    rough_parser_0._study2()
    rough_parser_0.compute_backslash_indent()


# Generated at 2022-06-26 07:41:09.555262
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Test input data
    text = Text(None)
    text._insert("1.0", "((x == 10) and (y == 10))")
    index = "1.2"

    # Unit test implementation
    hyper_parser = HyperParser(text, index)
    result = hyper_parser.get_surrounding_brackets("([{", True)
    expected_result = ('1.0', '1.5')

    # Unit test verification
    assert result == expected_result


# Generated at 2022-06-26 07:41:18.133141
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    str_0 = 'Ytg9'
    set_0 = {str_0, str_0, str_0, str_0, str_0}
    rough_parser_0 = RoughParser(set_0, str_0)
    str_1 = rough_parser_0.get_base_indent_string()
    assert len(str_1) == 4

# Generated at 2022-06-26 07:41:31.544572
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    #given
    sample_string = '''
    class Marsupial:
    def __init__(self):
        self.pouch = []
    def put_in_pouch(self, thing):
        self.pouch.append(thing)
    def pouch_contents(self):
        return self.pouch
    def __str__(self):
        t = [ object.__str__(self) + ' with pouch contents:' ]
        for obj in self.pouch:
            s = '    ' + object.__str__(obj)
            t.append(s)
        return '\n'.join(t)
    '''
    sample_lines = sample_string.split('\n')
    sample_set = set(sample_lines)
    rough_parser = RoughParser(sample_set, sample_string)

# Generated at 2022-06-26 07:41:44.523845
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    str_0 = '].A'
    str_1 = '6'
    set_0 = {str_0, str_1}
    int_0 = len(set_0)
    rough_parser_0 = RoughParser(int_0, str_1)
    hyper_parser_0 = HyperParser(rough_parser_0, int_0)
    hyper_parser_0.rawtext = str_0
    hyper_parser_0.stopatindex = str_0
    hyper_parser_0.bracketing = [(0, 0)]
    hyper_parser_0.isopener = [True]
    hyper_parser_0.indexinrawtext = len(str_1)
    hyper_parser_0.indexbracket = 0
    bool_0 = hyper_parser_0.is_in_string()

# Generated at 2022-06-26 07:41:47.054392
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    from tkinter.simpledialog import askstring
    from tkinter.filedialog import askopenfilename

    root = Tk()
    text = Text(root)
    text.pack()
    text.focus_set()

# Generated at 2022-06-26 07:42:41.070920
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = "="
    rough_parser_0 = RoughParser(str_0, str_0)
    rough_parser_0._study2()
    assert rough_parser_0.compute_backslash_indent() == 1


# Generated at 2022-06-26 07:42:53.839803
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():

    line_1 = "a = (b, c)"
    line_2 = "d = b, c"
    line_3 = "e = b(c,d)"
    line_4 = "f = {b,c}"
    line_5 = "g = [b,c]"
    line_6 = "a = (b, c)["
    line_7 = "a = [(b, c)]"
    line_8 = "a = (b, c)["
    line_9 = "a = (b, c)"
    line_10 = "a = (b, c)"
    line_11 = "a = (b, c)"
    line_12 = "a = (b, c)"
    line_13 = "a = b, c"
    line_14 = "a = (b, c)"
   

# Generated at 2022-06-26 07:43:02.441474
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    text_0 = 'A{o[zW8_v!oM-2s(s}'
    index_0 = '2.0'
    hyper_parser_0 = HyperParser(text_0, index_0)
    result_0 = hyper_parser_0.get_expression()
    assert result_0 == str_0, "Wrong result, returned: " + result_0


# Generated at 2022-06-26 07:43:14.907616
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_0 = """
    if True:
        # comment
        pass
    """
    str_1 = '    while True:\n        break\n'
    str_2 = '    while True:\n        break\n    '
    str_3 = 'if True:\n    # comment\n    pass\n'
    rough_parser_0 = RoughParser(str_0, str_0)
    rough_parser_1 = RoughParser(str_1, str_1)
    rough_parser_2 = RoughParser(str_2, str_2)
    rough_parser_3 = RoughParser(str_3, str_3)
    assert 3 == rough_parser_0.find_good_parse_start(3)
    assert 0 == rough_parser_1.find_good_parse_start(0)
    assert 0

# Generated at 2022-06-26 07:43:23.775687
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-26 07:43:26.810726
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    test_str = 'A{o[zW8_v!oM-2s(s}'
    hyper_parser_0 = HyperParser(test_str, 10)
    hyper_parser_0.set_index(10)
    hyper_parser_0.set_index(20)


# Generated at 2022-06-26 07:43:31.143293
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """
    Execution of this method will cause unit tests to be run on the set_index method of the HyperParser class. 
    """
    hyperparser_0 = HyperParser(text_0, INDEX_0)
    hyperparser_0.set_index(INDEX_1)



# Generated at 2022-06-26 07:43:44.288925
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # test case 0
    # print '>>> test case 0'
    str_0 = ';,$=1\n_8aU)|"4o6F/U6D\nX1@O6[0m:1C\nVuB{8gv0i%2b5<\nP#5X5iB7g5u1z5C\nB{8gv0i%2b5<\nP#5X5iB7g5u1z5C'
    hyper_parser_0 = HyperParser(str_0, '4.0')
    for index in ['4.0', '4.0 linestart']:
        hyper_parser_0.set_index(index)
        assert hyper_parser_0.is_in_code() == True


# Generated at 2022-06-26 07:43:54.153084
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=invalid-name
    str_0 = 'class C(object):\n    """docstring"""\n    def __init__(self):\n        """docstring"""\n        super(C, self).__init__()\n    def f(self, a, b, c, d=0, e=5, f=6):\n        """docstring"""\n        pass\n'
    rough_parser_0 = RoughParser(str_0, str_0)
    res_0 = rough_parser_0.compute_backslash_indent()
    assert res_0 == rough_parser_0.compute_backslash_indent()


# Generated at 2022-06-26 07:44:00.790292
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    """
    This is a unit test for the is_in_string method of class HyperParser.
    """
    # Create an instance of HyperParser
    hyper_parser_0 = RoughParser(
        'abc = (1, 2, 3)',
        'abc = (1, 2, 3)',
    )

    # Invoke method is_in_string
    result_0 = hyper_parser_0.is_in_string()

    # Assert result is as expected
    assert result_0 == False


# Generated at 2022-06-26 07:44:41.411208
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    h = HyperParser(Tk(), '1.0')
    # param "openers" not given
    h.get_surrounding_brackets()
    # param "openers" given
    h.get_surrounding_brackets('([{')
    # param "mustclose" not given
    h.get_surrounding_brackets('([{')
    # param "mustclose" given
    h.get_surrounding_brackets('([{',True)



# Generated at 2022-06-26 07:44:49.028913
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-outer-name

    def check(str_, tabsize, expected):
        res = RoughParser(str_, tabsize).compute_backslash_indent()
        assert res == expected, (res, expected)

    check("\\\n        pass", 4, 8)
    check("\\\n    pass", 4, 4)
    check("\\\npass", 4, 0)
    check("\\\n\tpass", 4, 1)
    check("\\\n\tpass", 8, 1)
    check("\\\n        pass#foo", 4, 8)
    check("\\\n    pass#foo", 4, 4)
    check("\\\npass#foo", 4, 0)
    check("\\\n\tpass#foo", 4, 1)
   

# Generated at 2022-06-26 07:44:51.569270
# Unit test for constructor of class HyperParser
def test_HyperParser():
    pass  # TODO


if __name__ == '__main__':
    test_case_0()
    test_HyperParser()

# Generated at 2022-06-26 07:44:53.790934
# Unit test for constructor of class HyperParser
def test_HyperParser():
    """Unit test for constructor of class HyperParser"""
    # TODO: this unit test needs to be implemented.
    raise NotImplementedError()


# Generated at 2022-06-26 07:44:55.843507
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    str_0 = '\n    Execution of this method will cause unit tests to be run on the get_expression method of the HyperParser class. \n    '


# Generated at 2022-06-26 07:45:08.321193
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-26 07:45:18.458649
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=unused-variable
    data_0 = RoughParser().compute_backslash_indent()
    # data_0 = RoughParser.compute_backslash_indent()
    pprint(data_0)
    # pprint(RoughParser(str_0))

if __name__ == '__main__':
    test_RoughParser_compute_backslash_indent()
#     # pprint(RoughParser(str_0))
#     # test_case_0()
#     import cProfile
#
#     cProfile.run("test_case_0()")

# Generated at 2022-06-26 07:45:21.587475
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    try:
        assert get_surrounding_brackets(self) == (None, None)
        assert ValueError('expected')
    except:
        pass


# Generated at 2022-06-26 07:45:22.486728
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # Unit test setup
    pass


# Generated at 2022-06-26 07:45:24.538899
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    hyperparser_0 = HyperParser(str_0, index_0)
    hyperparser_0.set_index(index_0)

# Generated at 2022-06-26 07:46:03.862104
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # Test for the case where str begins with a opening quote
    # and ends with a closing quote
    str_0 = 'O~[#"S+9m&HPl-\'d\t'
    hyper_parser_0 = HyperParser(str_0, 2)
    assert hyper_parser_0.is_in_code() == False
    # Test for the case where str contains a comment
    str_1 = 'O~[#"S+9m&HPl-\'d\t'
    hyper_parser_1 = HyperParser(str_1, 3)
    assert hyper_parser_1.is_in_code() == False


# Generated at 2022-06-26 07:46:09.320657
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from idlelib.idle_test.mock_idle import Func
    from idlelib import hyperparser

    str_0 = "{x}"

    parser_0 = RoughParser(str_0)

    def is_in_code_0():
        return hyperparser.HyperParser(str_0, 1).is_in_code()

    def is_in_code_1():
        return hyperparser.HyperParser(str_0, 0).is_in_code()

    def is_in_code_2():
        return hyperparser.HyperParser(str_0, 2).is_in_code()

    is_in_code_0()
    is_in_code_1()
    is_in_code_2()


# Generated at 2022-06-26 07:46:12.753848
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    str_0 = 'A{o[zW8_v!oM-2s(s}'
    rough_parser_0 = RoughParser(str_0, str_0)
    try:
        rough_parser_0.set_lo(int_0=1)
    except IOError as exc:
        if isinstance(exc, IOError):
            raise


# Generated at 2022-06-26 07:46:23.696657
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class test_HyperParser(unittest.TestCase):
        def test_case_0(self):
            str_0 = """


    a = [1, 2, 3]


    """
            text_0 = Text(str_0, ' ')
            index_0 = '2.0'
            hyper_parser_0 = HyperParser(text_0, index_0)
            text_1 = Text(str_0, ' ')
            index_1 = '2.0'
            hyper_parser_1 = HyperParser(text_1, index_1)

    unittest.main()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 07:46:28.486557
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    str = 'A\n def: B\n   def: C\n     def: D'
    rough_parser = RoughParser(str, str)
    assert rough_parser.get_base_indent_string() == '     '


# Generated at 2022-06-26 07:46:34.421728
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rough_parser_set_lo = RoughParser('9F\'`', "")
    rough_parser_set_lo.set_lo('~')
    assert_equals(rough_parser_set_lo.indent_width, 4)


# Generated at 2022-06-26 07:46:39.346246
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    expected_backslash_indent_0 = 17
    backslash_indent_0 = RoughParser(str_0_raw, str_0_cooked).compute_backslash_indent()
    assert backslash_indent_0 == expected_backslash_indent_0


# Generated at 2022-06-26 07:46:48.978715
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import re
    import random

    # Get source code
    source_code_file = 'C:\\Users\\Ashish\\AppData\\Local\\Programs\\Python\\Python36\\Lib\\idlelib\\hyperparser.py'
    with open(source_code_file, 'r') as myfile:
        source_code = myfile.read().replace('\n', '')

    # Remove content of the three multi-line strings: multi_line_string_0, multi_line_string_1 and multi_line_string_2
    # so that the test case execution does not take a long time...
    multi_line_string_0 = re.search('"""Provide advanced parsing abilities for (.*?)"""', source_code).group(1)