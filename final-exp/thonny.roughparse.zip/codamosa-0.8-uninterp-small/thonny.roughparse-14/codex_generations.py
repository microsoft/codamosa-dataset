

# Generated at 2022-06-26 07:39:30.674021
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    print("test_HyperParser_set_index")
    index = 3
    hyper_parser_0 = HyperParser(index)
    index = 4
    hyper_parser_0.set_index(index)


# Generated at 2022-06-26 07:39:40.720304
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    str_0 = '"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""a"""\n'
    # Params: text, index
    # Result: None
    hyper_parser_0 = HyperParser(str_0, "1.0")
    # Params: index
    hyper_parser_0.set_index("1.0")


# Generated at 2022-06-26 07:39:42.480312
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = "hi there"
    index = 2
    hyper_parser_0 = HyperParser(text, index)
    assert hyper_parser_0.set_index(index) == None


# Generated at 2022-06-26 07:39:54.720906
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    list_0 = []
    float_0 = -17.313667902409808
    rough_parser_0 = RoughParser(list_0, float_0)
    # assert str(rough_parser_0.find_good_parse_start(0)) == '0'
    # assert str(rough_parser_0.find_good_parse_start(1)) == '1'
    # assert str(rough_parser_0.find_good_parse_start(2)) == '2'
    # assert str(rough_parser_0.find_good_parse_start(3)) == '3'
    # assert str(rough_parser_0.find_good_parse_start(4)) == '4'
    # assert str(rough_parser_0.find_good_parse_start(5)) == '5'
    #

# Generated at 2022-06-26 07:40:00.173159
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    str0 = "def func1(arg1):  # comment here"
    int0 = 0
    str1 = "    int0 += 1  # another comment"
    list0 = [str0, str1]
    rough_parser0 = RoughParser(list0, int0)
    assert rough_parser0.compute_bracket_indent() == 4

if __name__ == '__main__':
    test_case_0()
    test_RoughParser_compute_bracket_indent()

# Generated at 2022-06-26 07:40:05.788641
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # Test 0
    list_0 = ['def f(x, y=1, *, z=2):\n    return x + y + z\n']
    float_0 = 4.0
    rough_parser_0 = RoughParser(list_0, float_0)
    int_0 = rough_parser_0.compute_backslash_indent()
    assert int_0 == 5



# Generated at 2022-06-26 07:40:10.030338
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    list_0 = []
    float_0 = -17.313667902409808
    rough_parser_0 = RoughParser(list_0, float_0)
    rough_parser_0.set_lo(list_0)


# Generated at 2022-06-26 07:40:13.894053
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    text_0 = "abc fgh"
    index_0 = "5.5"
    hyper_parser_0 = HyperParser(text_0, index_0)
    for i in range(10000):
        hyper_parser_0.get_expression()


# Generated at 2022-06-26 07:40:16.104833
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    assert RoughParser("   spam").get_base_indent_string() == "   "


# Generated at 2022-06-26 07:40:24.204119
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Test case data
    text_0 = 'while True:\n    while True:\n        while True:\n            while True:\n                while True:\n                    while True:\n                        while True:\n                            while True:\n                                while True:\n                                    while True:\n                                        while True:\n                                            while True:\n                                                pass'
    index_0 = '49.0'
    # Invoke method
    hyper_parser_0 = HyperParser(text_0, index_0)
    tuple_0 = hyper_parser_0.get_surrounding_brackets()


# Generated at 2022-06-26 07:41:08.747043
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-26 07:41:12.375723
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
   
    # 
    print(HyperParser._eat_identifier('    print(n)\n', 0, 10))

    # 
    print(HyperParser._eat_identifier('def f(x):\nprint(x)\n', 0, 18))

    # 
    print(HyperParser._eat_identifier('if True:\npass\n', 0, 12))
    
    
    
    
    

# Generated at 2022-06-26 07:41:17.646662
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    int_0 = -30
    int_1 = 0
    while int_1 < 10:
        test_case_0()
        int_1 += 1

test_HyperParser_is_in_code()

# Generated at 2022-06-26 07:41:31.300925
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # tests for the get_expression method
    import unittest
    from test.support import run_unittest
    from idlelib import hyperparser
    from idlelib import parenmatch

    class GetExpressionTest(unittest.TestCase):
        """get_expression is a method of class HyperParser
        which returns a string representing the Python expression in
        the given text which is at the given index.
        """

        # the string to be parsed.
        text = ""

        # the index at which the expression should be found
        index = -1

        # the expected expression
        expected = ""

        def test_get_expression(self):
            """test get_expression"""
            hp = hyperparser.HyperParser(self.text, self.index)
            result = hp.get_expression()

# Generated at 2022-06-26 07:41:44.290393
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-26 07:41:47.576667
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    str_0 = '"""'
    int_0 = 5
    boolean_0 = False
    hyper_parser_0 = HyperParser(str_0, int_0)
    hyper_parser_0.is_in_code()
    int_0 = 8
    hyper_parser_0 = HyperParser(str_0, int_0)
    hyper_parser_0.is_in_code()


# Generated at 2022-06-26 07:41:48.745492
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    assert RoughParser("\tdef f(x):\n\t\t").get_base_indent_string() == "\t\t"


# Generated at 2022-06-26 07:41:53.991381
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    float_0 = -4.233335030758128
    rough_parser_0 = RoughParser(float_0, float_0)
    str_0 = "lhyra2=9"
    int_0 = rough_parser_0.find_good_parse_start(str_0)
    assert int_0 == 0


# Generated at 2022-06-26 07:41:59.796806
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Test 1.0: Default values for arguments
    print("\nTest 1.0: Default values for arguments")
    hyper_parser_0 = HyperParser(tkinter.Text(), int())
    hyper_parser_0.get_surrounding_brackets()

    # Test 2.0: Specified values for arguments
    print("\nTest 2.0: Specified values for arguments")
    hyper_parser_0 = HyperParser(None, -1)
    hyper_parser_0.get_surrounding_brackets("({[", False)


# Generated at 2022-06-26 07:42:10.143594
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = """\
1 and
    # Some comment.
2"""
    hp = HyperParser(text, "1.0")
    hp.set_index("1.0")
    hp.set_index("1.3")
    hp.set_index("1.10")
    try:
        hp.set_index("2.0")
        assert False, "Call to HyperParser.set_index with index outside of analyzed statement should fail."
    except ValueError:
        pass
    except:
        assert False, "Calling HyperParser.set_index with index \
            outside of analyzed statement should raise ValueError, not \
            %s" % (sys.exc_info()[0],)
    return None


# Generated at 2022-06-26 07:43:07.304714
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin


    # TODO: it's not clear to me that this test is useful.  The
    # code it tests will never be run by the calling code
    # (compute_indent).  I think what this test really tests is
    # whether RoughParser._compute_backslash_indent can correctly
    # parse the string.  If that's the case, wouldn't it be better
    # to have test_RoughParser_study2 test that directly?

    parser = RoughParser("print(10)\n")
    assert parser.compute_backslash_indent() == 0, "compute_backslash_indent 0 failed"
    parser = RoughParser("print(10) \\\n  + 20\n")
    assert parser.compute_backslash_indent

# Generated at 2022-06-26 07:43:08.659130
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rp = RoughParser(str_0, tabwidth=1)
    assert rp.compute_bracket_indent() == 0


# Generated at 2022-06-26 07:43:11.622353
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    str_0 = 'test get_expression'
    index.set_index(str_0)


# Generated at 2022-06-26 07:43:21.762283
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Test initializations
    # Initialize str_0
    str_0 = 'test get_surrounding_brackets'

    # Initialize int_0
    int_0 = 10
    int_1 = 2
    int_2 = 7
    int_3 = 5
    int_4 = 6

    # Initialize float_0
    float_0 = 2.0
    float_1 = 4.0
    float_2 = 3.0
    float_3 = 7.0
    float_4 = 9.0

    # Initialize char_0
    char_0 = ' '

    # Initialize bool_0
    bool_0 = False

    # Initialize obj_0
    obj_0 = object()

    # Initialize func_0

# Generated at 2022-06-26 07:43:30.605701
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    '''test_HyperParser_get_expression'''
    hyper = HyperParser(str_0,0)
    assert hyper.get_expression() == 'test'

# Generated at 2022-06-26 07:43:33.606926
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    new_obj = RoughParser(str_0)
    result = new_obj.get_base_indent_string()
    assert result == 'test'


# Generated at 2022-06-26 07:43:39.394257
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    assert 'str_0' in vars(), 'str_0 not defined'
    assert 'str_1' in vars(), 'str_1 not defined'

    a = RoughParser(str_0)
    b = RoughParser(str_1)

    assert a.get_last_stmt_bracketing() == b.get_last_stmt_bracketing()

# Generated at 2022-06-26 07:43:41.798713
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # Compute the result of the function call
    result = HyperParser.is_in_code()
    # Check the result
    assert result == None, "Test failed"


# Generated at 2022-06-26 07:43:49.058313
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    str_0 = 'test get_continuation_type'
    rp_0 = RoughParser(str_0)
    assert rp_0.get_continuation_type() == 0


# Generated at 2022-06-26 07:43:52.974326
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = '''
while True:
    try:
        self.cursor.execute(sql)
    except Exception as e:
        raise
'''
    rp = RoughParser(str_0)
    indent = rp.compute_backslash_indent()
    assert indent == 4


# Generated at 2022-06-26 07:44:58.616683
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    str_0 = 'foo((bar, buz))'
    rp_0 = RoughParser(str_0, 2)
    assert rp_0.compute_bracket_indent() == 2


# Generated at 2022-06-26 07:45:01.994238
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    assert 'assert True'  ==  (True)


# Generated at 2022-06-26 07:45:06.239623
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    print("Testing RoughParser.get_num_lines_in_stmt...")
    rough_parser = RoughParser()
    assert rough_parser.get_num_lines_in_stmt() == 1


# Generated at 2022-06-26 07:45:10.797327
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    for rp in [RoughParser(), None]:
        rp = RoughParser()
        rp.set_lo(1)
        pass



# Generated at 2022-06-26 07:45:22.601729
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    i = RoughParser()
    i.set_str('def function(a, b):\n    pass')
    assert i._compute_bracket_indent() == 4
    i.set_str('def another_function(a, b):\n    pass')
    assert i._compute_bracket_indent() == 4
    i.set_str('def a_function(a, b):\n    pass\n')
    assert i._compute_bracket_indent() == 4
    # See that non-indenting comment lines work right
    # (comment is to the left of the bracket)
    i.set_str("def function(a, b):\n" "    pass # comment")
    assert i._compute_bracket_indent() == 4

# Generated at 2022-06-26 07:45:29.614009
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-26 07:45:37.874029
# Unit test for constructor of class HyperParser
def test_HyperParser():
	text_0 = str
	text_1 = "test get_expression"
	index_0 = "1.0"
	token_0 = test_case_0()
	py_0 = HyperParser(text_0, index_0)
	py_1 = py_0.is_in_code()
	py_2 = py_1
	py_3 = py_0.get_expression()
	py_4 = py_3


test_HyperParser()

# Generated at 2022-06-26 07:45:40.397907
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    str_0 = 'test get_expression'
    print (str_0)
    hyparser = HyperParser(str_0,10)
    assert("test" == hyparser.get_expression())


# Generated at 2022-06-26 07:45:41.843214
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # str_0 = 'test get_expression'
    # TODO: finish this test
    pass


# Generated at 2022-06-26 07:45:45.068772
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    str_0 = 'test get_expression'
    text = MockText(str_0)
    hp = HyperParser(text,"1.0")
    hp.is_in_string()

# Generated at 2022-06-26 07:46:41.381331
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    '''Method is_in_code of class HyperParser is tested.
    '''
    flag = False
    # testing when the index is in a code
    if hyper_parser_0.is_in_code():
        flag = True
    else:
        print('Failed to test is_in_code of class HyperParser.')


# Generated at 2022-06-26 07:46:45.769472
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    float_0 = -19.129679952663484
    rough_parser_0 = RoughParser(float_0, float_0)
    stmt_start_0 = rough_parser_0.set_lo(float_0)
    assert (stmt_start_0) == (-6.171106398118355)


# Generated at 2022-06-26 07:46:56.557794
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    import sys
    
    from compiler import compile
    
    from compiler.ast import Function, While, Const, Dict, Tuple
    
    from pychecker2 import Warning, Config
    from pychecker2.Checker import MSG_CLASS
    
    from pychecker2.test import test_util
    from pychecker2.test.test_util import makeWarning
    
    from pychecker2 import RoughCode
    
    from pychecker2.test import test_util
    ########################################################################
    
    
    
    ########################################################################
    # test get_base_indent_string
    ########################################################################
    def test_get_base_indent_string(code_str, expected, **kwargs):
        test_class = kwargs.get('test_class', None)
       