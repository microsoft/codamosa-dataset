

# Generated at 2022-06-26 07:38:00.157099
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_2 = '\n01\n03\n05\n07\n09\n'
    start_0 = 0
    rough_parser_1 = RoughParser(str_2, start_0)
    str_3 = '\n01\n03\n05\n07\n09\n'
    parse_start_0 = rough_parser_1.find_good_parse_start()
    assert str_3 == str_2 and parse_start_0 == 0
    str_4 = str_2 + '11\n13\n15\n17\n19\n'
    rough_parser_2 = RoughParser(str_4, start_0)
    parse_start_1 = rough_parser_2.find_good_parse_start()
    assert str_3 == str_2 and parse_start_1

# Generated at 2022-06-26 07:38:12.520082
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    str_0 = '\x1e'
    index_0 = 0
    hyper_parser_0 = HyperParser(str_0, index_0)
    ret_val_0 = hyper_parser_0.is_in_string()
    assert ret_val_0 == False

    str_0 = '"\x14'
    index_0 = 0
    hyper_parser_0 = HyperParser(str_0, index_0)
    ret_val_0 = hyper_parser_0.is_in_string()
    assert ret_val_0 == True

    str_0 = '\x00'
    index_0 = 0
    hyper_parser_0 = HyperParser(str_0, index_0)
    ret_val_0 = hyper_parser_0.is_in_string()
    assert ret_val_

# Generated at 2022-06-26 07:38:18.311839
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from tkinter import Text

    root = Text()
    text = root.edit_modified(Text())
    text.focus_set()
    text.insert("1.0", "I am a text")
    text.mark_set("insert", "1.2")
    HyperParser(text, "insert")
    text.unbind("<<HyperLink>>")
    text.unbind("<<HyperButton>>")
    root.quit()


# Generated at 2022-06-26 07:38:25.591965
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text_0 = Text(None)
    hyper_parser_0 = HyperParser(text_0, '2.0')
    tuple_0 = hyper_parser_0.get_surrounding_brackets('([{', False)
    assert tuple_0 is not None
    if __name__ == '__main__':
        test_case_0()
    if __name__ == '__main__':
        test_HyperParser_get_surrounding_brackets()

print("Execution Completed Successfully..")

# Generated at 2022-06-26 07:38:37.928587
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    global pass_number
    pass_number = 0
    rough_parser_0 = RoughParser("\n", "\t")
    pass_number = 1
    rough_parser_1 = RoughParser("\n", "\t")
    pass_number = 2
    rough_parser_2 = RoughParser("\n", "\t")
    pass_number = 3
    rough_parser_3 = RoughParser("\n", "\t")
    pass_number = 4
    rough_parser_4 = RoughParser("\n", "\t")
    pass_number = 5
    rough_parser_5 = RoughParser("\n", "\t")
    pass_number = 6
    rough_parser_6 = RoughParser("\n", "\t")
    pass_number = 7
    rough_parser_7 = RoughParser("\n", "\t")
   

# Generated at 2022-06-26 07:38:41.726400
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # Test 1
    str_0 = '$-R\n1A\x0bCD'
    str_1 = 'ZNg'
    rough_parser_0 = RoughParser(str_0, str_1)
  

# Generated at 2022-06-26 07:38:49.017726
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    import unittest
    class TestRoughParser(unittest.TestCase):
        def test_get_base_indent_string_0(self):
            str__1 = '\n\n\n\n    def __init__(self, buffer, indent_width=None, tab_width=8, heuristic_indent_width=None):\n        RoughParser.__init__(self, buffer, indent_width, tab_width)\n\n'
            str__2 = '\n\n    def prepare_to_parse(self, tokenize_chars_fn):\n        RoughParser.prepare_to_parse(self, tokenize_chars_fn)\n        self.tokenize_chars_fn = tokenize_chars_fn\n\n'

# Generated at 2022-06-26 07:38:59.604148
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # from tests.lib2to3_data.fixers.fix_imports import MAPPING, PATTERN
    str_0 = '\x0c4V7\x8cAjeVgv\x0e1'
    assert RoughParser(str_0).compute_backslash_indent() == 0
    str_1 = '\x7f\x8cW\x12h\x81\x7f\x8cW\x12h\x81'
    assert RoughParser(str_1).compute_backslash_indent() == 0
    str_2 = '\x04\x80\x8e'
    assert RoughParser(str_2).compute_backslash_indent() == 0

# Generated at 2022-06-26 07:39:04.218378
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rough_parser = RoughParser('', '')
    expected = 0
    actual = rough_parser.compute_bracket_indent()
    assert expected == actual, 'Expected: %s. Actual: %s' % (expected, actual)


# Generated at 2022-06-26 07:39:05.586343
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # TODO: Unit test for method get_expression of class HyperParser
    pass


# Generated at 2022-06-26 07:39:56.615714
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_0 = '1\n'
    str_1 = '\n2\n'
    str_2 = '\n'
    rough_parser_0 = RoughParser(str_0)
    assert rough_parser_0.find_good_parse_start(str_1) == 0
    rough_parser_0 = RoughParser(str_0)
    assert rough_parser_0.find_good_parse_start(str_2) == 0
    str_0 = '0\n'
    str_1 = '\n1\n'
    str_2 = '\n'
    rough_parser_0 = RoughParser(str_0)
    assert rough_parser_0.find_good_parse_start(str_1) == 0
    rough_parser_0 = RoughParser(str_0)

# Generated at 2022-06-26 07:40:06.996981
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    """Test the method get_expression of class HyperParser"""

    # Basic tests on the indentation we find.
    # We will use these tests on several files.

    # First, test a string with a single line.
    s = "\n  abc"
    hp = HyperParser(s, "1.0")
    # This line should not be indented.
    assert hp.get_expression() == ""
    hp = HyperParser(s, "1.2")
    assert hp.get_expression() == ""
    hp = HyperParser(s, "1.3")
    assert hp.get_expression() == "abc"
    # Test some line below the first one.
    hp = HyperParser(s, "2.0")
    assert hp.get_expression() == ""
    hp = HyperParser(s, "2.2")


# Generated at 2022-06-26 07:40:13.193575
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # def __init__(self, text, index):
    text_0 = ScrolledText(root, 50, 80)
    text_0.grid()
    text_0.insert(END, 'abc')
    index_0 = '1.0'
    hyper_parser_0 = HyperParser(text_0, index_0)
    assert hyper_parser_0.is_in_code() == True

# Generated at 2022-06-26 07:40:23.977026
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    str_0 = ''
    str_1 = ''
    rough_parser_0 = RoughParser(str_0, str_1)
    rough_parser_0._study1()
    assert rough_parser_0.continuation == 0

# Generated at 2022-06-26 07:40:30.857057
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    raw_text = "db.query(\"update users set \"\n            \"is_active=\'f\'\n            where username=\'%s\'\" %username)"
    text = Text(None, undo=False)
    text.insert('1.0', raw_text)
    parser = HyperParser(text, "1.74")
    brackets = parser.get_surrounding_brackets()
    if brackets[0] != "1.53" or brackets[1] != "1.80":
        print("Failed test #0")
        return False
    
    parser.set_index("1.0")
    brackets = parser.get_surrounding_brackets()
    if brackets != None:
        print("Failed test #1")
        return False

    parser.set_index("1.24")

# Generated at 2022-06-26 07:40:39.128460
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=redefined-builtin
    str_0 = '\\a"\x0b\\a\n"\\\n'
    str_1 = '"\\\n"'
    rough_parser_0 = RoughParser(str_0, str_1)
    rough_parser_0.set_str('\\a"\x0b\\a\n"\\\n', '"\\\n"')
    rough_parser_0.set_str("\\a'\\\x00\n'\\\n", '"\\\n"')
    rough_parser_0.set_str("\\a'\\\x00\n'\\\n", '"\\\n"')


# Generated at 2022-06-26 07:40:40.300629
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    pass


# Generated at 2022-06-26 07:40:45.767354
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    '''
    This is a test case for HyperParser.get_expression()
    '''
    for idx in range(0, 200):
        str = 'abcdefghijklmnopqrstuvwxyz'
        h = HyperParser(str, idx)
        h.get_expression()


# Generated at 2022-06-26 07:40:52.931212
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Initialize test variables
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5
    int_6 = 6
    int_7 = 7
    int_8 = 8
    int_9 = 9
    int_10 = 10
    int_11 = 11
    int_12 = 12
    int_13 = 13
    int_14 = 14
    int_15 = 15
    int_16 = 16
    int_17 = 17
    int_18 = 18
    int_19 = 19
    int_20 = 20
    int_21 = 21
    int_22 = 22
    int_23 = 23
    int_24 = 24
    int_25 = 25
    int_26 = 26
    int_

# Generated at 2022-06-26 07:41:05.683129
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from Tkinter import Tk, Text
    root = Tk()
    text = Text(root, bg="white")

    # Define a text to analyze
    text.insert("end", "This\nis\na\ntest.")
    h = HyperParser(text, "end")
    # Note that "end" is outside the analyzed text, so an exception
    # should be raised.
    try:
        h.set_index("end")
    except ValueError as e:
        pass
    else:
        raise Exception("ValueError not raised")

    # set_index doesn't need to be at the end of text.
    # This bug was fixed in issue 605817.
    h.set_index("2.0")


# Generated at 2022-06-26 07:41:54.150098
# Unit test for constructor of class HyperParser
def test_HyperParser():
    str_0 = '$-R\n1A\x0bCD'
    str_1 = 'ZNg'
    rough_parser_0 = RoughParser(str_0, str_1)
    str_2 = '%c%c'
    str_3 = '%c%c'
    str_4 = '%c%c'
    str_5 = '%c%c'
    str_6 = '%c%cX'
    str_7 = '%c%c'
    str_8 = '%c%c'
    str_9 = '%c%c'
    str_10 = '%c%c'
    str_11 = '%c%c'
    str_12 = '%c%c'
    str_13 = '%c%c'
    str_14

# Generated at 2022-06-26 07:42:05.603936
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    def test_get_num_lines_in_stmt(str_, str_1, expected):
        rough_parser_0 = RoughParser(str_, str_1)
        actual = rough_parser_0.get_num_lines_in_stmt()
        if expected != actual:
            raise Exception(
                'Assertion failed: %s != %s' % (expected, actual))
    test_get_num_lines_in_stmt('=}J\x0fv', '', 1)
    test_get_num_lines_in_stmt('\x15\x16', 'D\x18\x0f\x1a', 1)
    test_get_num_lines_in_stmt('', '', 1)


# Generated at 2022-06-26 07:42:09.946556
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    str_0 = '  say "hello there" # this is a comment'
    str_1 = 'P3'
    rough_parser_0 = RoughParser(str_0, str_1)
    assert rough_parser_0.compute_bracket_indent() == 2


# Generated at 2022-06-26 07:42:20.807805
# Unit test for constructor of class HyperParser
def test_HyperParser():
    class Test:
        def __init__(self, text, index):
            self.index = index

    text = Test('', '0.0')
    index = '1'
    hyper_parser_0 = HyperParser(text, index)
    assert hyper_parser_0.stopatindex == '2.0'
    assert hyper_parser_0.bracketing == [(0, 0)]
    assert hyper_parser_0.isopener == [False]
    assert hyper_parser_0.indexinrawtext == 0
    assert hyper_parser_0.indexbracket == 0
    assert hyper_parser_0.index == '1'
    assert hyper_parser_0.rawtext == '\n'
    assert hyper_parser_0.text == text
    text = Test('', '1.0')

# Generated at 2022-06-26 07:42:32.906765
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # Case 0
    str_0 = '$-R\n1A\x0bCD'
    str_1 = 'ZNg'
    rough_parser_0 = RoughParser(str_0, str_1)
    str_5 = '\x0b\x0ct'
    result_0 = rough_parser_0.compute_bracket_indent(str_5)
    # Case 1
    str_0 = '$-R\n1A\x0bCD'
    str_1 = 'ZNg'
    rough_parser_0 = RoughParser(str_0, str_1)
    str_5 = '0\x02U'
    result_0 = rough_parser_0.compute_bracket_indent(str_5)
    # Case 2

# Generated at 2022-06-26 07:42:38.579214
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_0 = 'nW&'
    str_1 = (None,) * 12
    rough_parser_0 = RoughParser(str_0, str_1)
    int_0 = rough_parser_0.find_good_parse_start()
    assert int_0 == 1
    assert rough_parser_0.start == 0
    str_2 = 'L\r'
    str_3 =  'Z\x1b\x03\x7f\x10\x1a\x15\x0f\x1b\x1f\x1b\x18'
    rough_parser_0 = RoughParser(str_2, str_3)
    int_1 = rough_parser_0.find_good_parse_start()
    assert int_1 == 1

# Generated at 2022-06-26 07:42:43.499816
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = '\x0c\xff{Z\n'
    str_1 = '\x1b\x1c<'
    rough_parser_0 = RoughParser(str_0, str_1)
    real_result_0 = rough_parser_0.compute_backslash_indent()
    expected_result_0 = None
    assert real_result_0 == expected_result_0


# Generated at 2022-06-26 07:42:47.559951
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    print('test_get_last_open_bracket_pos: Candidate for Jython Unittesting')


# Generated at 2022-06-26 07:42:55.433651
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin
    str_0 = '#Dvmgt!'
    str_1 = "Qx$'l,l"
    str_2 = '$2aKjH\nZ\nkD'
    str_3 = 'j\x16\x1c9\x1dG'
    rough_parser_0 = RoughParser(str_0, str_1)
    rough_parser_0._study2()
    assert rough_parser_0.continuation == C_BRACKET
    assert rough_parser_0.compute_bracket_indent() == 0
    assert rough_parser_0.indent_width == 4
    assert rough_parser_0.tabwidth == 8

# Generated at 2022-06-26 07:43:07.037884
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # 1. Test without touching the identity of the class
    # Instantiate a class
    # HyperParser(text='', index='')
    # Check the class identity
    # This should return 1
    assert HyperParser(text='', index='').get_expression() == 1
    # 2. Test with changing the identity of the class
    # Instantiate a class
    # HyperParser(text='', index='')
    # Change the class identity
    # This should return 1
    assert HyperParser(text='', index='').get_expression() == 1
    # Check the class identity
    # This should return True
    assert True


# Generated at 2022-06-26 07:46:42.699557
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    str_0 = 'kK~1\nT^b\x0c'
    str_1 = '$r;'
    int_0 = len(str_0)
    hyper_parser_0 = HyperParser(str_0, int_0, str_1)
    int_0 = len(str_0)
    str_2 = hyper_parser_0.get_surrounding_brackets(str_1, int_0)
    int_1 = hyper_parser_0.is_in_code()
    assert_equals(int_1, 1)


# Generated at 2022-06-26 07:46:48.104486
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    str_0 = '2\n'
    str_1 = '\x1c'
    int_0 = len(str_1)
    int_1 = len(str_0)
    txt = Tkinter.Text()
    txt.insert(Tkinter.INSERT, str_0)
    h = HyperParser(txt, int_1)
    h.set_index(int_0)


# Generated at 2022-06-26 07:46:58.192522
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # HyperParser._eat_identifier() is protected. We use a proxy class
    # here in order to be able to access it.
    class HyperParserProxy(HyperParser):
        @classmethod
        def get_eat_identifier(cls, *args, **kwargs):
            return cls._eat_identifier(*args, **kwargs)

    import builtins

    class DummyText(dict):
        @classmethod
        def fromkeys(cls, keys):
            return cls(zip(keys, keys))

        def __getitem__(self, key):
            return dict.get(self, key, key)

        def get(self, item, default):
            return dict.get(self, item, default)
