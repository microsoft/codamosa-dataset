

# Generated at 2022-06-26 07:38:33.188101
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    str_0 = '\\2_5-A7P)+~Bf*x7#[*0ZHX}Gt:C8tqg@0h~y,#M-=_R8b)xj1l:'
    str_1 = 'j<Ea^lL5Q$*Vm`rj+%7V'
    hyper_parser_0 = HyperParser(str_0, str_1)
    assert hyper_parser_0.get_surrounding_brackets('()', True) == (None, None)
    str_0 = '\\H_W]2Lgqo~`%?Z+YK&|'
    str_1 = 'sH0jKD]g_^/qA3}O[ZQX'

# Generated at 2022-06-26 07:38:44.089286
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    str_0 = '}r>^I:_i%P'
    str_1 = 'gNU<'
    rough_parser_0 = RoughParser(str_0, str_1)
    str_2 = "m\\Fmf{GMy?_D[I>i&^"
    str_3 = '%aI'
    rough_parser_1 = RoughParser(str_2, str_3)
    # The following testcase is not portable and might only work on Linux.
    rough_parser_2 = RoughParser("./cal_stress.py", "")
    rough_parser_3 = RoughParser("", "")
    rough_parser_4 = RoughParser("qNu]7Qa", "Mjtop")
    # pylint: disable=maybe-no-member

# Generated at 2022-06-26 07:38:49.665020
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    str_0 = 'E@-+X'
    rough_parser_0 = RoughParser(str_0, str_0)
    str_1 = 'xU6;-A3ra'
    hyper_parser_0 = HyperParser(str_0, rough_parser_0, str_1)
    index_0 = 13
    try:
        hyper_parser_0.set_index(index_0)
        raise RuntimeError("Test Fail")
    except ValueError:
        pass



# Generated at 2022-06-26 07:38:52.317477
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text_0 = 'fD|q1$yH)'
    index_0 = 'i0o'
    hyper_parser_0 = HyperParser(text_0, index_0)


# Generated at 2022-06-26 07:39:04.176329
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    unittest.expectedFailure = True
    parser_0 = RoughParser()
    source_0 = 'v1z%bW8Ii'
    parser_0.set_str(source_0)
    index_0 = parser_0.find_good_parse_start(_build_char_in_string_func(0))
    parser_0.set_lo(index_0)
    parser_0.get_whitespace()
    parser_0.get_indent()
    parser_0.get_line_break()
    parser_0.get_dedent()
    parser_0.get_stmt()
    parser_0.get_as_name()
    parser_0.get_test()
    parser_0.get_testlist_star_expr()
    parser_0.get_comparison()

# Generated at 2022-06-26 07:39:08.755099
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    text_0 = 'def fun(x):\n    a = x[0] + x[1] + x[2]\n    print(a)\nfun(1, 2, 3)'
    # The following line is required to call the class method:
    HyperParser._eat_identifier = HyperParser._eat_identifier.__func__
    hyper_parser_0 = HyperParser(text_0, '4.6')
    print(hyper_parser_0.get_expression())


# Generated at 2022-06-26 07:39:10.745240
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text_0 = TkText()
    hyper_parser_0 = HyperParser(text_0, 0)
    hyper_parser_0.set_index(5)
    print(hyper_parser_0.is_in_code())


# Generated at 2022-06-26 07:39:16.969853
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    str_0 = '\\!D<@[tYiS0>5lCu'
    str_1 = 'f9{t7Q'
    rough_parser_0 = RoughParser(str_0, str_1)
    assert isinstance(rough_parser_0.get_num_lines_in_stmt(), int)


# Generated at 2022-06-26 07:39:24.453405
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    str_0 = "abcd efgh"
    str_1 = '\\!D<@[tYiS0>5lCu'
    rough_parser_0 = RoughParser(str_0, str_1)
    hyper_parser_0 = HyperParser(rough_parser_0, "abcd efgh")
    hyper_parser_0.set_index(0)
    hyper_parser_0.set_index(1)
    hyper_parser_0.set_index(2)
    hyper_parser_0.set_index(3)
    hyper_parser_0.set_index(4)
    hyper_parser_0.set_index(5)
    hyper_parser_0.set_index(6)
    hyper_parser_0.set_index(7)
    hyper_parser_0.set

# Generated at 2022-06-26 07:39:36.199690
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-26 07:40:28.380661
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    pseudo_map = StringTranslatePseudoMapping({}, 1)
    assert pseudo_map.get(1) == 1
    assert pseudo_map.get(2) == 1
    pseudo_map = StringTranslatePseudoMapping({1: 2}, 1)
    assert pseudo_map.get(1) == 2
    assert pseudo_map.get(2) == 1



# Generated at 2022-06-26 07:40:32.874823
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-26 07:40:40.491434
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    test_code = inspect.getsource(test_case_0)
    rough_parser = RoughParser(test_code)
    int_0_indent = rough_parser.compute_bracket_indent()
    assert int_0_indent == 0, 'int_0_indent is {}'.format(int_0_indent)
    int_1_indent = rough_parser.compute_bracket_indent()
    assert int_1_indent == 1, 'int_1_indent is {}'.format(int_1_indent)
    return 'Test for compute_bracket_indent passed!'


# Generated at 2022-06-26 07:40:41.762045
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    test_case_0()
test_HyperParser_is_in_code()

# Generated at 2022-06-26 07:40:51.406101
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from idlelib.EditorWindow import EditorWindow
    from idlelib.PyShell import PyShell

    root = tkinter.Tk()
    root.withdraw()
    text = tkinter.Text(root)
    editor = EditorWindow(root, text)
    shell = PyShell(root)

    text.insert("insert", test_case_0)
    text.insert("end", '\n')

    hp = HyperParser(text, "end")
    # Test that both the set_index method and the is_in_string method
    # work
    assert hp.is_in_string() == False

    # Test that both the set_index method and the is_in_code method
    # work
    assert hp.is_in_code() == False

    # Test that both the set_index method and the get_surrounding

# Generated at 2022-06-26 07:41:01.620766
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    obj_0 = RoughParser("def test_case_0():\n    int_0 = 0\n    int_1 = 5\n",
                        indent_width=4, tabwidth=8)
    assert obj_0.get_last_open_bracket_pos() == None
    assert len(obj_0.goodlines) == 3
    assert obj_0.goodlines[0] == 1
    assert obj_0.goodlines[1] == 2
    assert obj_0.goodlines[2] == 3
    assert obj_0.continuation == 0


# Generated at 2022-06-26 07:41:07.266442
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = f'{test_case_0.__name__}()'
    p = RoughParser(str_0)
    indent_width = p.compute_backslash_indent()
    assert indent_width == 4

# Generated at 2022-06-26 07:41:11.556169
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_0 = """
    1
    2
    def a(b=1):
        while True:
            if b == 0:
                break
            elif b == 1:
                pass
            else:
                b -= 1
"""
    obj_0 = RoughParser(str_0)
    int_0 = obj_0.find_good_parse_start()
    assert int_0 == 22


# Generated at 2022-06-26 07:41:19.038731
# Unit test for constructor of class HyperParser
def test_HyperParser():
    global h
    h = HyperParser(text, "1.1")
    assert h.text == text
    assert h.rawtext == "test_case_0():\n"
    assert h.stopatindex == "3.end"
    assert h.bracketing == [(0, 0), (16, 0), (17, 1), (18, 0)]
    assert h.isopener == [True, False, True, False]
    assert h.indexinrawtext == 4
    assert h.indexbracket == 1


# Generated at 2022-06-26 07:41:22.332861
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    test_case_0()
    parser = RoughParser(test_case_0.__code__.co_code)
    assert parser.compute_backslash_indent() == 8


# Generated at 2022-06-26 07:41:56.584157
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    rough_parser = RoughParser()

    continuation = rough_parser.get_continuation_type('1.1')
    assert continuation == 'C_NONE'

    continuation = rough_parser.get_continuation_type('1.1\\')
    assert continuation == 'C_BACKSLASH'

    continuation = rough_parser.get_continuation_type('1.1    \\')
    assert continuation == 'C_BACKSLASH'

    continuation = rough_parser.get_continuation_type('1.1\\\n bla bla bla')
    assert continuation == 'C_BACKSLASH'

    continuation = rough_parser.get_continuation_type('1.1\n'
                                                      '    \\')
    assert continuation == 'C_BACKSLASH'


# Generated at 2022-06-26 07:42:09.174934
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_0 = '1.1'
    # Creates and returns an instance of RoughParser
    # Usage: RoughParser([tabsize])
    obj_0 = RoughParser()
    # obj_0 is a RoughParser

    # Test case with invalid parameter
    # Test case with an invalid parameter
    #    RoughParser.find_good_parse_start(self, str, p)
    # with 1 parameter(s):
    #     - str (str)
    #
    # raises ParseError
    #
    # find_good_parse_start() raises a ParseError
    # if it can't find a line in the str, starting at position p,
    # that can be used as the start of a statement.
    #
    # Normally this happens only if the input string contains a syntax
    # error; in that case the error is recorded

# Generated at 2022-06-26 07:42:22.016066
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_1 = '1.1'
    _str = str_1
    _str = '%s\n' % (_str, )
    str_2 = 'def f():'
    _str = '%s\n%s' % (_str, str_2, )
    str_3 = 'return None'
    _str = '%s\n%s' % (_str, str_3, )
    str_4 = 'print(f())'
    _str = '%s\n%s' % (_str, str_4, )
    str_5 = '1.2'
    _str = '%s\n%s' % (_str, str_5, )
    str_6 = 'def g():'
    _str = '%s\n%s' % (_str, str_6, )

# Generated at 2022-06-26 07:42:26.740467
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    str_0 = '1.1'
    h = HyperParser(str_0, 10)
    if not h.is_in_code():
        print('Failed test_HyperParser_is_in_code')


# Generated at 2022-06-26 07:42:36.076500
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    str_0 = '1.1'
    str_1 = '1.1.1'
    str_2 = '1.1.1.1'
    str_3 = '1.1.1.1.1'
    str_4 = '1.1.1.1.1.1'
    str_5 = '1.1.1.1.1.1.1'
    str_6 = '1.1.1.1.1.1.1.1'
    str_7 = '1.1.1.1.1.1.1.1.1'
    str_8 = '1.1.1.1.1.1.1.1.1.1'
    return str_0 + str_1 + str_2 + str_3 + str_4 + str_5 + str_

# Generated at 2022-06-26 07:42:43.201720
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = '1.1'
    first_line_0 = ''
    total_length_0 = 0
    indent_width_0 = 4
    tabwidth_0 = 8
    rough_parser_0 = RoughParser(str_0, first_line_0, total_length_0, indent_width_0, tabwidth_0)
    backslash_indent_0 = rough_parser_0.compute_backslash_indent()
    assert (backslash_indent_0 == 0)


# Generated at 2022-06-26 07:42:54.393746
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    # pylint: disable=line-too-long

    str_0   = "def f():\n" \
              "    if foo:\n" \
              "        print 'foo'\n" \
              "    else:\n" \
              "        print 'bar'\n"
    str_1   = "def f():\n" \
              "    if foo:\n" \
              "        print 'foo'\n" \
              "    else:  # comment\n" \
              "        print 'bar'\n"

# Generated at 2022-06-26 07:43:02.232504
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    str_0 = 'True'
    str_1 = 'False'
    str_2 = 'None'
    str_3 = 'True'
    str_4 = 'False'
    str_5 = 'None'
    str_6 = 'True'
    str_7 = 'False'
    str_8 = 'None'
    str_9 = 'True'
    str_10 = 'False'
    str_11 = 'None'
    str_12 = 'True'
    str_13 = 'False'
    str_14 = 'None'
    str_15 = 'True'
    str_16 = 'False'
    str_17 = 'None'
    str_18 = 'True'
    str_19 = 'False'
    str_20 = 'None'
    str_21 = 'True'
   

# Generated at 2022-06-26 07:43:03.992913
# Unit test for constructor of class HyperParser

# Generated at 2022-06-26 07:43:06.055552
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    resut_str = RoughParser.set_str(str_0)
    assert resut_str == None


# Generated at 2022-06-26 07:43:35.284409
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    with test_support.captured_stdout() as output:
        hp = HyperParser(str, 0)
        hp.get_expression()
        print(output) # 

if __name__ == "__main__":
    test_case_0()
    test_HyperParser_get_expression()

# Local Variables:
# mode: python
# End:

# Generated at 2022-06-26 07:43:46.049425
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    str_1 = '((()))'
    str_2 = '(((()))'
    str_3 = '(((())))'

    h = HyperParser(str_1, index)
    b = h.get_surrounding_brackets()
    b = h.get_surrounding_brackets()

    h = HyperParser(str_2, index)
    b = h.get_surrounding_brackets()
    b = h.get_surrounding_brackets()

    h = HyperParser(str_3, index)
    b = h.get_surrounding_brackets()
    b = h.get_surrounding_brackets()



# Generated at 2022-06-26 07:43:55.851229
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from unittest import TestCase
    from test.test_hyperparser import get_expression
    from tkinter import Text
    hyperparser = HyperParser(object, object)
    with TestCase() as tc:
        tc.assertEqual(hyperparser.get_surrounding_brackets(object, object).indent, object)
        tc.assertEqual(hyperparser.get_surrounding_brackets(object, object).indent, object)
        tc.assertEqual(hyperparser.get_surrounding_brackets(object, object).indent, object)
        tc.assertEqual(hyperparser.get_surrounding_brackets(object, object).indent, object)
        tc.assertEqual(hyperparser.get_surrounding_brackets(object, object).indent, object)

# Generated at 2022-06-26 07:43:59.395035
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():

    roughParser = RoughParser()

    str_0 = '1.1'

    roughParser.set_lo(0)
    assert roughParser.lo == 0, "f1()"



# Generated at 2022-06-26 07:44:03.619926
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    str_0 = '1.1'
    parser_0 = RoughParser()
    parser_0.set_str(str_0)
    parser_0._study2()
    lastopenbracketpos_0 = parser_0.get_last_open_bracket_pos()
    assert lastopenbracketpos_0 == None


# Generated at 2022-06-26 07:44:05.157838
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()
    #case 0
    test_case_0()
    print("case 0 passed")


# Generated at 2022-06-26 07:44:08.065857
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    
    # test_case_0
    hyperparser = HyperParser(str_0)
    if (hyperparser.is_in_code):
        print("Method is_in_code of class HyperParser doesn't work as expected.")
    

# Generated at 2022-06-26 07:44:13.458139
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # Test with a simple case
    test_case_1()
    # Test with an expression starting with a dot inside a string
    test_case_2()
    # Test with an expression having a bracketing level different than
    # the last one
    test_case_3()
    # Test with an expression having a bracketing level higher than
    # the last one
    test_case_4()
    # Test with a constant
    test_case_5()

# Generated at 2022-06-26 07:44:21.401043
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # Empty String Test
    string = ''
    h = HyperParser(string, 0)
    assert len(h.rawtext) == 2, 'Length of the rawtext should be 2'
    assert h.stopatindex == '1.end', 'Stopatindex should be 1.end'
    assert h.bracketing == [(0, 0)], 'Bracketing should be [(0, 0)]'
    assert h.isopener == [], 'Isopener should be []'
    assert h.indexinrawtext == 0, 'indexinrawtext should be 0'
    assert h.indexbracket == 0, 'indexbracket should be 0'
    assert h.is_in_code() == True, 'cursor should not be in a string'

# Generated at 2022-06-26 07:44:23.743733
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    str_0 = '1.1'
    hp = HyperParser()
    assert hp.is_in_string()


# Generated at 2022-06-26 07:45:05.995399
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    str_0 = '1.1'
    #str_0 = '"abc"'
    #str_0 = '12345'
    str_1 = str_0.replace('.', ' . ')
    str_1 = str_1.replace(' ', '\x00')
    str_1 = str_1.replace('.', ' ')
    str_1 = str_1.replace('\x00', '.')

    #str_1 = '1 . 1'
    # file_name = 'd:/tmp/data.txt'
    file_name = 'd:/tmp/test.txt'
    with open(file_name, 'w') as f:
        f.write(str_1)

    tk = tkinter.Tk()
    tk.withdraw()
    tk.clipboard

# Generated at 2022-06-26 07:45:07.791738
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    print("Testing test_HyperParser_set_index ...")
    parser = HyperParser
    parser.set_index("1.1")
    return parser.str == "1.1"

# Generated at 2022-06-26 07:45:13.233364
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # Setup
    text_0 = Text()
    index_0 = 0
    # Call the method under test
    hyper_parser = HyperParser(text_0, index_0)
    # Verify the result
    assert hyper_parser is not None, 'Result is None'


# Generated at 2022-06-26 07:45:17.990968
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = "  def foo(self):\n    '''\n    @type self: WorkerGenerator\n    '''\n"
    rough_parser_0 = RoughParser(str_0)
    assert rough_parser_0.compute_backslash_indent() == 5


# Generated at 2022-06-26 07:45:27.648283
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
	#assert( False )
	print('Tests implemented')
	#print(HyperParser.HyperParser)
	#assert( False )
	#print('test3')
	#h = HyperParser()
	#assert( False )
	#print('test4')
	#print(h)
	#h.set_index( 0 )
	#assert( False )
	#print('test5')
	#print(h.get_surrounding_brackets())
	#assert( False )
	#print('test6')
	#print(h.get_expression())
	#assert( False )
	#print('test7')
	#print(h.is_in_code())
	#assert( False )
	#print('test8')
	#h.get_surrounding_brackets()
	#assert

# Generated at 2022-06-26 07:45:30.849123
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo('a')
    assert(rp.lo == 'a')


# Generated at 2022-06-26 07:45:41.946840
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # str_0 = VARCHAR
    str_0 = '1.1'
    # text_0 = Text
    # text_0 = '1.1'

    # result_0 = Tuple
    # result_0 = ()
    # text_1 = Text
    # text_1 = ''
    # result_1 = Tuple
    # result_1 = ()
    # text_2 = Text
    # text_2 = '()'
    # result_2 = Tuple
    # result_2 = ()
    # text_3 = Text
    # text_3 = 'a()'
    # result_3 = Tuple
    # result_3 = ()
    # # text_4 = Text
    # # text_4 = '((a+2)*(b-a))'
    # # result_4 = T

# Generated at 2022-06-26 07:45:53.278000
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    print("Testing get_last_stmt_bracketing")

# Generated at 2022-06-26 07:45:54.786735
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    e = HyperParser('', '')
    assert e.get_expression() == ''


# Generated at 2022-06-26 07:45:58.250252
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # If any exception is thrown, fail the test.
    try:
        hp = HyperParser('1.1', '1.1')
        assert hp.get_expression() == '1.1'
    except:
        assert False


# Generated at 2022-06-26 07:46:38.104658
# Unit test for method set_index of class HyperParser

# Generated at 2022-06-26 07:46:47.826260
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    str_0 = '1.1'
    str_1 = '1.0.0'
    str_2 = '1.1.1'
    str_3 = 'a'
    str_4 = '1'
    str_5 = '1'
    str_6 = '1'
    str_7 = '1'
    str_8 = '1'
    str_9 = '1'
    str_10 = '1'
    str_11 = '1'
    str_12 = '1'
    str_13 = '1'
    str_14 = '1'
    str_15 = '1'
    str_16 = '1'
    str_17 = '1'
    str_18 = '1'
    str_19 = '1'
    str_20 = '1'


# Generated at 2022-06-26 07:46:57.959889
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    s = "a.b.c.d\n"
    p = HyperParser(s, len(s) - 1)
    assert p.get_expression() == "d"
    p = HyperParser(s, len(s) - 2)
    assert p.get_expression() == "d"
    p = HyperParser(s, len(s) - 3)
    assert p.get_expression() == "c.d"
    p = HyperParser(s, len(s) - 4)
    assert p.get_expression() == "c.d"
    p = HyperParser(s, len(s) - 5)
    assert p.get_expression() == "b.c.d"
    p = HyperParser(s, len(s) - 6)