

# Generated at 2022-06-26 07:40:16.609079
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    index = Tkinter.Text.index(None)
    hyper_parser_0 = HyperParser(None, index)
    hyper_parser_0.set_index(index)


# Generated at 2022-06-26 07:40:22.119921
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    str_0 = '#,w7`4KSfpz#V8W#c%OvS\x0fj$9H8I58\x00['
    index_0 = '1.0'
    hyper_parser_0 = HyperParser(str_0, index_0)
    assert not hyper_parser_0.is_in_code()


# Generated at 2022-06-26 07:40:27.476759
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    r"""
    Unit test for method compute_backslash_indent of class RoughParser
    """
    str_0 = "if f(x) and g(y) and h(z):\n    x = 2\n    y = 3\n    z = 4\n"
    rough_parser_0 = RoughParser(str_0, str_0)
    rough_parser_0._study2()
    rough_parser_0.compute_backslash_indent()



# Generated at 2022-06-26 07:40:31.858048
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    str_0 = " \t\n"
    rough_parser_0 = RoughParser(str_0, str_0)
    rough_parser_0.set_lo(0)
    rough_parser_0.set_lo(7)
    assert _junkre(rough_parser_0.str, 0)


# Generated at 2022-06-26 07:40:37.322490
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    str_0 = 'L-S\x00\x10\x1d\x0bz:4\x07'
    text_0 = Text()
    text_0.insert(1.0, str_0)
    index_0 = str_0 + 'C'
    hyper_parser_0 = HyperParser(text_0, index_0)
    hyper_parser_0.set_index(index_0)


# Generated at 2022-06-26 07:40:48.022160
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # Initialize a test buffer.
    text = tk.Text(tk.Tk())
    text.insert("end", "'''(''')")
    text.mark_set("insert", "2.0")


# Generated at 2022-06-26 07:41:03.069507
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # test 0
    str_0 = '@\n@\n  @\n    @\n    @\n    @\n    @\n    @\n    @\n    @\n    @\n  @\n  @\n@\n@'
    index_0 = '18.5'
    index_1 = '18.8'
    index_2 = '18.7'
    index_3 = '18.6'
    index_4 = '18.4'
    index_5 = '18.7'
    index_6 = '18.2'
    index_7 = '18.6'
    index_8 = '18.8'
    index_9 = '18.5'
    index_10 = '18.7'
    index_11 = '18.6'


# Generated at 2022-06-26 07:41:09.598074
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin

    # Test comment line, with continuation
    str_1 = """
if True:
try:
    1/0
    a = 1 + 2
    # Comment
    a = 1 + 2
except:
    a = 1 + 2
    # Comment
    a = 1 + 2
finally:
    a = 1 + 2
    # Comment
    a = 1 + 2
"""
    rough_parser_1 = RoughParser(str_1, str_1)
    res_1 = rough_parser_1.compute_bracket_indent()
    if (res_1 != 8):
        raise Exception_0('Expected 8, but got ' + str(res_1))


# Generated at 2022-06-26 07:41:15.336563
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-26 07:41:30.209526
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-26 07:42:09.795760
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    from tokenize import generate_tokens
    from StringIO import StringIO
    
    def dedent(tokens):
        """Remove indent and eof tokens levels"""
        for ttype, tvalue, _, _, _ in tokens:
            if ttype != tokenize.INDENT and ttype != tokenize.DEDENT:
                yield ttype, tvalue
    
    def iter_code_lines(code):
        lines = StringIO(code).readlines()
        return dedent(generate_tokens(iter(lines).next))
        
    # When continuation is C_BRACKET, return the number of spaces the next line
    # should be indented.

# Generated at 2022-06-26 07:42:22.018010
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # Test for the case when no error occurs.
    for code in (
        "class HyperParser:\n",
        "class HyperParser:\n    def __init__(self, text, index):\n",
    ):
        try:
            HyperParser(code, "1.0")
        except Exception:
            print(
                "unexpected error occurred while testing "
                "`HyperParser` constructor is called with "
                "'HyperParser(%r, '1.0'), " % code
            )
            raise

    # Test for the case when an error occurs.

# Generated at 2022-06-26 07:42:25.737947
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    var_0 = HyperParser(None, 0)
    var_1 = None
    var_2 = var_0.is_in_string()
    assert var_2 == var_1


# Generated at 2022-06-26 07:42:29.082989
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    var_0 = HyperParser("", "")
    assert(  var_0.is_in_code() == True)


# Generated at 2022-06-26 07:42:31.073707
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from idlelib.hyperparser import HyperParser
    pass # TODO



# Generated at 2022-06-26 07:42:43.326226
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():

    obj = RoughParser(tabsize=8)
    obj.set_str('while 1:\n    print 12\n    print 34')
    assert obj.compute_bracket_indent() == 4
    obj.set_str('if 1:\n    print 12\n    print 34')
    assert obj.compute_bracket_indent() == 4
    obj.set_str('elif 1:\n    print 12\n    print 34')
    assert obj.compute_bracket_indent() == 4
    obj.set_str('else:\n    print 12\n    print 34')
    assert obj.compute_bracket_indent() == 4
    obj.set_str('for i in range(10):\n    print(i)\n    print(10)')
    assert obj.compute_bracket_

# Generated at 2022-06-26 07:42:47.929836
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    var_0 = HyperParser(text = None, index = None)
    var_0.is_in_code()


# Generated at 2022-06-26 07:42:49.916619
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    parser = RoughParser('var_0 = None\n')
    assert parser.get_base_indent_string() == ''


# Generated at 2022-06-26 07:42:53.997920
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():

    # Setup
    import __main__
    __main__.test_case_0()
    text = __main__.text
    __main__.hp = HyperParser(text, "1.0")

    # Invoke method with argument and check result
    result = __main__.hp.is_in_code()
    assert result is True


# Generated at 2022-06-26 07:43:07.960107
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    print("Testing find_good_parse_start...")
    var_0 = None
    var_0 = RoughParser("")
    var_1 = var_0.find_good_parse_start(0)
    assert(var_1 == 0)
    var_1 = var_0.find_good_parse_start(1)
    assert(var_1 == 1)
    var_0 = RoughParser("\n")
    var_1 = var_0.find_good_parse_start(0)
    assert(var_1 == 0)
    var_1 = var_0.find_good_parse_start(1)
    assert(var_1 == 1)
    var_0 = RoughParser("\n\n")
    var_1 = var_0.find_good_parse_start(0)

# Generated at 2022-06-26 07:43:48.867531
# Unit test for constructor of class HyperParser
def test_HyperParser():
    testargs = ('', 0)
    text = testargs[0]
    index = testargs[1]

    hyper_parser_0 = HyperParser(text, index)


# Generated at 2022-06-26 07:43:53.814548
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import io, inspect
    from io import StringIO

    # Create a string buffer
    buf = StringIO()

    # Save the current stdout
    save_stdout = sys.stdout

    # Redirect stdout to the buffer
    sys.stdout = buf

    # Call tested method
    test_case_0()

    # Restore stdout
    sys.stdout = save_stdout

    # Test passed
    print('*** test passed ***')

# Generated at 2022-06-26 07:44:03.810043
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    """Test get_expression of class HyperParser."""
    str_0 = 'qX`-HD$^8Tq-H\x0b6#ZLb['
    str_1 = 'I,n`3i.eKBP'
    rough_parser_0 = RoughParser(str_0, str_0)
    # AssertionError: ValueError ('get_expression should only be called' 'if index is inside a code.',) != None
    # AssertionError: ValueError ('get_expression should only be called' 'if index is inside a code.',) != None
    # AssertionError: ValueError ('get_expression should only be called' 'if index is inside a code.',) != None
    # AssertionError: ValueError ('get_expression should only be called' 'if index is inside a code.',) != None


# Generated at 2022-06-26 07:44:12.969307
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-26 07:44:15.671982
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    str_0 = 'qX`-HD$^8Tq-H\x0b6#ZLb['
    hyper_parser_0 = HyperParser(str_0, str_0)
    assert hyper_parser_0.is_in_string() == False


# Generated at 2022-06-26 07:44:24.263966
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import random
    import string

    str_0 = '&#9yQEmT$M!Hd|wC&6#R>d#kA'
    hyper_parser_0 = HyperParser(str_0, str_0)
    str_1 = '12r?cb[r;|oqfOc}b\\9'
    hyper_parser_0.set_index(str_1)
    exp_str_0 = hyper_parser_0.get_expression()

    charset = set(string.ascii_letters)
    charset.update(string.digits)
    charset.update("_")
    charset = list(charset)

    for i in range(100):
        length = random.randint(0, 100)

# Generated at 2022-06-26 07:44:33.393133
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    str_0 = '\t  \t  \t  \t  \t    '
    rough_parser_0 = RoughParser(str_0, str_0)
    rough_parser_0.continuation = 'C_BRACKET'
    rough_parser_0.lastopenbracketpos = 12
    num_0 = rough_parser_0.compute_bracket_indent()
    str_1 = '\t'
    rough_parser_1 = RoughParser(str_0, str_1)
    rough_parser_1.continuation = 'C_BRACKET'
    rough_parser_1.lastopenbracketpos = 12
    num_1 = rough_parser_1.compute_bracket_indent()
    assert num_0 == num_1
    str_2 = '\t    '

# Generated at 2022-06-26 07:44:41.839094
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def check(seq, openers, mustclose, expected_result):
        hp = HyperParser(seq)
        result = hp.get_surrounding_brackets(openers, mustclose)
        if result != expected_result:
            print("Sequence %r" % seq)
            print("Expected result %r" % expected_result)
            print("Obtained result %r" % result)
        assert result == expected_result

    # Test that a sequence of 3 openers, 1 closer and 3 openers has
    # the expected result.
    check("[{([", "([{", False, (0, 5))

    # Test that a closer with no openers does not give a result
    check("({)}", "([{", False, None)

    # Test that a closer with no openers does give a result when
    # must

# Generated at 2022-06-26 07:44:46.333908
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # setup
    py_code = "a + b + c"
    text = Text()
    text.insert("1.0", py_code)
    parser = HyperParser(text, "1.1")

    # exercise
    exp = parser.get_expression()

    # verify
    assert exp == "b", "Unexpected expression: {!r}".format(exp)



# Generated at 2022-06-26 07:44:52.710045
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    str_0 = "B\x14\x0c\x1e\x1c\x1e\x08\x00\x03\x00\x1a\x15\t\x02\x07"
    hyper_parser_0 = HyperParser(str_0, "1.0")
    hyper_parser_0.is_in_string()


# Generated at 2022-06-26 07:46:19.233505
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    str = '    hello = world'
    rough_parser = RoughParser(str, "")
    result = rough_parser.get_base_indent_string()
    assert result == '    '


# Generated at 2022-06-26 07:46:25.747827
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    str_0 = "do_something (a, b=None, *args, **kwargs):\n"
    str_1 = 'qX`-HD$^8Tq-\x0b6#ZLb['
    text_0 = Text_s(str_0, str_1)
    str_2 = '*'
    index_0 = text_0.index(str_2)
    hyper_parser_0 = HyperParser(text_0, index_0)
    str_3 = "([{"
    int_0 = hyper_parser_0.get_surrounding_brackets(str_3)
    assert int_0 == (
        '1.37',
        '1.37',
    )  # str_4 = 'do_something' # str_5 = 'do_someth' #

# Generated at 2022-06-26 07:46:37.510043
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():

    import re
    import random
    import string

    # Test cases taken from test_pgen.py:PgenParserTest.testParseMethod
    #
    # See LICENSE.txt for details about distribution and modification.

    def test_case(parse_method, test_source):
        # build an artificial grammar based on the test source
        nonterminals = {}
        for token in test_source:
            nonterminals[token] = token
        start = nonterminals["start"] = "start"
        rules = [
            ("start", [start, "stop"]),
            ("stop", [])
        ]
        for lhs, rhs in rules:
            rhs[:] = [[nt if nt in nonterminals else "lit", nt]
                      for nt in rhs]

        # construct the parser
        tp

# Generated at 2022-06-26 07:46:39.830256
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rough_parser_0 = RoughParser('test')
    rough_parser_0.compute_backslash_indent()


# Generated at 2022-06-26 07:46:42.825772
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-outer-name
    comp = RoughParser("  XXX\n  \\", "")
    assert comp.compute_backslash_indent() == 3


# Generated at 2022-06-26 07:46:52.523149
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    assert RoughParser(str_1, str_1).get_base_indent_string() == ''
    assert RoughParser(str_2, str_2).get_base_indent_string() == ''
    assert RoughParser(str_3, str_3).get_base_indent_string() == ''
    assert RoughParser(str_4, str_4).get_base_indent_string() == ''
    assert RoughParser(str_5, str_5).get_base_indent_string() == ''
    assert RoughParser(str_6, str_6).get_base_indent_string() == '    '
    assert RoughParser(str_7, str_7).get_base_indent_string() == '        '
    assert RoughParser(str_8, str_8).get_base_indent_