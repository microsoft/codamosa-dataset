

# Generated at 2022-06-26 07:37:46.211328
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text_0 = Text()
    text_0.insert('1.0', '\x0b95x\x0bp2yf@O@Rba2')
    hyper_parser_0 = HyperParser(text_0, text_0.index('2.0'))
    bool_0 = hyper_parser_0.is_in_code()
    print(bool_0)


# Generated at 2022-06-26 07:37:59.372349
# Unit test for method set_index of class HyperParser

# Generated at 2022-06-26 07:38:03.928602
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    assert RoughParser("", "").get_num_lines_in_stmt() == 0
    assert RoughParser("\n", "").get_num_lines_in_stmt() == 1
    assert RoughParser("a\n", "").get_num_lines_in_stmt() == 1
    assert RoughParser("\n\n", "").get_num_lines_in_stmt() == 2
    assert RoughParser("a\n\n", "").get_num_lines_in_stmt() == 2
    assert RoughParser("\n\nb\n", "").get_num_lines_in_stmt() == 2


# Generated at 2022-06-26 07:38:10.036309
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    # pylint: disable=redefined-builtin
    # str = ''
    # rough_parser = RoughParser(str, str)
    # assert rough_parser.get_last_stmt_bracketing() == None
    # assert rough_parser.is_block_opener() == False
    # assert rough_parser.is_block_closer() == False

    # str = '# blabla'
    # rough_parser = RoughParser(str, str)
    # assert rough_parser.get_last_stmt_bracketing() == None
    # assert rough_parser.is_block_opener() == False
    # assert rough_parser.is_block_closer() == False

    str_1 = 'def blah(blah):'

# Generated at 2022-06-26 07:38:19.495431
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    with raises(AssertionError, match='str argument starts with newline'):
        RoughParser('\nx', '', {})
    # Expecting None
    rough_parser_0 = RoughParser('', '', {})
    str_0 = rough_parser_0.get_last_stmt_bracketing()
    assert str_0 == None
    # Expecting None
    with raises(TypeError, match='an integer is required'):
        RoughParser('', '', {})
    # Expecting None

# Generated at 2022-06-26 07:38:24.176984
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    str_0 = 'Ewxu&nZ9\x1d8\x0c^q3\nb\x1f%c'
    rough_parser_0 = RoughParser(str_0, str_0)
    rough_parser_0._study2()
    assert roug

# Generated at 2022-06-26 07:38:36.997292
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import random
    import string

    for i in range(1000):
        if i % 100 == 0:
            print("HyperParser test", i)

        text = ""
        for j in range(random.randint(3, 600)):
            if random.randint(1, 3) == 1 or text == "":
                c = random.randint(0, 255)
                if c == 10:
                    cn = random.randint(1, 20)
                    text += cn * " " + "\n"
            else:
                c = ord(text[-1])
            if c < 256 and chr(c) in string.printable:
                if c in (39, 34) and text[-1] in string.printable:
                    text += random.choice("'\"")
                else:
                    text += chr

# Generated at 2022-06-26 07:38:46.499058
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    tk = Tk()

# Generated at 2022-06-26 07:38:53.419164
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = (
        '# test\n# test\n'
        '# test\n'
        'x = 11\n'
        '# comment\n'
        'y = 22\n'
        '# comment\n'
        'x = x + \\\n'
        'y \\\n'
        '\n'
    )
    rough_parser_0 = RoughParser(str_0, str_0)
    assert rough_parser_0.compute_backslash_indent() == 8


# Generated at 2022-06-26 07:38:59.138362
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    str_0 = "a\nb\nc"
    rough_parser_0 = RoughParser(str_0, str_0)
    rough_parser_0.set_lo(1)
    r2 = rough_parser_0.get_str()
    assert_equal(r2, "b\nc")


# Generated at 2022-06-26 07:40:00.160115
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from tkinter.scrolledtext import ScrolledText
    from idlelib.EditorWindow import EditorWindow
    from idlelib import idle_test

    str_1 = 'def blah(blah):'
    str_2 = '# blah blah'
    str_3 = '"""'
    str_4 = "'''"

    egw = EditorWindow(root)
    egw.text.insert('1.0', str_1 + '\n' + str_2 + '\n' + str_3 + '\n' + str_4)
    egw.text.mark_set('insert', '1.0')
    egw.text.mark_set('test_case_1', '1.20')
    egw.text.mark_set('test_case_2', '2.0')

# Generated at 2022-06-26 07:40:01.258539
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    pass


# Generated at 2022-06-26 07:40:12.575352
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-26 07:40:15.717427
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    """Test if set_index function is working as expected."""
    hp = HyperParser(text=test_case_0, index=0)
    assert hp.is_in_code() == True



# Generated at 2022-06-26 07:40:18.200598
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # Code Strings
    single_line_str = "print('Hello, World!')"

# Generated at 2022-06-26 07:40:27.702799
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    p = HyperParser(test_case_0, index = 0)
    assert p.get_surrounding_brackets(openers='([{', mustclose=False) == (0, 12)
    p = HyperParser(test_case_0, index = 3)
    assert p.get_surrounding_brackets(openers='([{', mustclose=False) == (0, 12)
    p = HyperParser(test_case_0, index = 9)
    assert p.get_surrounding_brackets(openers='([{', mustclose=False) == (9, 12)
    p = HyperParser(test_case_0, index = 12)
    assert p.get_surrounding_brackets(openers='([{', mustclose=False) == None
    

# Generated at 2022-06-26 07:40:36.359944
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    str_0 = 'def test(blah):'
    str_1 = 'print("{}")'
    str_2 = 'print(set(blah))'

    def _test_helper_method(self, str_0):
        text_0 = Text(str_0)
        hyper_0 = HyperParser(text_0, '1.0')
        hyper_0.get_surrounding_brackets()

    _test_helper_method(test_case_0, str_0)
    _test_helper_method(test_case_0, str_1)
    _test_helper_method(test_case_0, str_2)


# Generated at 2022-06-26 07:40:46.943414
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    print('\nRunning test_HyperParser_is_in_string')

    # Case 0
    print('\tCase 0: ')
    str_0 = 'def blah(blah):'
    try:
        index_0 = 0
        hp_0 = HyperParser(str_0, index_0)
        out_0 = hp_0.is_in_string()
        print(out_0)
    except:
        print('ERROR')
    # Case 1
    print('\tCase 1: ')
    str_1 = '""""def blah(blah):'

# Generated at 2022-06-26 07:40:50.338582
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-26 07:40:51.757753
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    str_0 = 'def blah(blah):'
    p = RoughParser(str_0, "")
    assert p.is_block_opener()


# Generated at 2022-06-26 07:41:57.951161
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    str_0 = 'gvD(o\\\nn'
    expected_0 = 1
    rough_parser_0 = RoughParser(str_0, str_0)
    actual_0 = rough_parser_0.compute_backslash_indent()
    # print(actual_0)
    assert actual_0 == expected_0


# Generated at 2022-06-26 07:42:10.143766
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    str_0 = '\ufea1\t"\x06\\\x7f\x04\n\t\x07\x04G\x1b\x03\x1c\x0f\x02\x18\x07\x0b\x1d\x06'
    rough_parser_0 = RoughParser(str_0, str_0)

# Generated at 2022-06-26 07:42:16.570116
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = '\x08U6hz\x0bp2yf@O@Rba2\x0c'
    rough_parser_0 = RoughParser(str_0, str_0)
    rough_parser_0.compute_backslash_indent()


# Generated at 2022-06-26 07:42:25.456246
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text_0 = SimpleText()

# Generated at 2022-06-26 07:42:35.686716
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import random
    import sys

    # This simple function will be used to generate test cases
    # by choosing between two different randomly generated nested
    # structures: one containing only parentheses, and the other
    # containing only braces, of random length and with various
    # possible positions for the index.
    def nested_struct(depth=0):
        left = random.choice("()[]{}")
        if depth == 0:
            return left, ""
        s, index = nested_struct(depth-1)
        return left + s + {
            "(": ")",
            "[": "]",
            "{": "}",
            ")": "",
            "]": "",
            "}": "",
        }[left], index


# Generated at 2022-06-26 07:42:44.776899
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Check basic case - not in brackets
    t = Text(None, "blah")
    h = HyperParser(t, "1.0")
    assert h.get_surrounding_brackets(mustclose=True) == None
    # Check basic case - in brackets
    t = Text(None, "a(b)(c)(())")
    h = HyperParser(t, "1.5")
    assert h.get_surrounding_brackets(mustclose=True) == ("1.3", "1.6")
    # Check other brackets
    t = Text(None, "a{b}[c]")
    h = HyperParser(t, "1.6")
    assert h.get_surrounding_brackets(mustclose=True) == ("1.4", "1.7")
    # Check surrou

# Generated at 2022-06-26 07:42:50.251129
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    py_source= """\
        foo = "bar"
        spam = 'eggs'
        """
    startat= 1
    stopat= 2
    for i in range(startat, stopat + 1):
        tk = Tk()
        text = Text(tk)
        text.insert('insert', py_source)
        text.mark_set('insert', '%d.0' % i)
        hyperparser = HyperParser(text, 'insert')
        assert hyperparser.is_in_string() == (i == 2)


# Generated at 2022-06-26 07:42:58.366979
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    tabwidth = 8
    str_1_1 = 'a=9\n[(a+b;b+c;c+d;d+e;e+f)]'
    indent_width = 4
    rough_parser_1 = RoughParser(str_1_1, indent_width, tabwidth)
    assert rough_parser_1.compute_bracket_indent() == 0

    str_1_2 = 'a=9\n[(a+b;b+c;c+d;d+e;e+f)]\n'
    indent_width = 4
    rough_parser_2 = RoughParser(str_1_2, indent_width, tabwidth)
    assert rough_parser_2.compute_bracket_indent() == 0
    assert rough_parser_2.indent_width == 4



# Generated at 2022-06-26 07:43:04.656623
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    text_1 = '\x0b95x\x0bp2yf@O@Rba2'
    index_1 = text_1.find('a2')
    hp_1 = HyperParser(text_1, index_1)
    assert hp_1.get_expression() == 'ba2'
    assert hp_1.get_expression() == 'ba2'
    index_2 = text_1.find('p2')
    hp_1.set_index(index_2)
    assert hp_1.get_expression() == 'ba2'
    hp_1.set_index(index_1 + 1)
    assert hp_1.get_expression() == 'ba2'
    index_3 = text_1.find('G')
    hp_1.set_index(index_3)
    assert hp

# Generated at 2022-06-26 07:43:16.289502
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # It should work for a simple case
    expr = "foo[bar]."
    h = HyperParser(expr, index="end")
    h.get_expression()
    assert h.get_expression() == "foo[bar]"
    # In a simple case it should return an empty string
    expr = " "
    h = HyperParser(expr, index="end")
    assert h.get_expression() == ""
    # It should work for a complicated case
    expr = "foo.bar[2].ba(r)"
    h = HyperParser(expr, index="end")
    assert h.get_expression() == "foo.bar[2].ba(r)"
    # In a complicated case it should return an empty string
    expr = ""
    h = HyperParser(expr, index="end")
    assert h.get_expression() == ""


# Generated at 2022-06-26 07:44:15.552899
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-26 07:44:20.928466
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    str_0 = '\x0b95x\x0bp2yf@O@Rba2'
    rough_parser_0 = RoughParser(str_0, str_0)
    result_RoughParser__study2 = rough_parser_0._study2()
    result_RoughParser_is_block_closer = rough_parser_0.is_block_closer()
    return (result_RoughParser_is_block_closer, result_RoughParser__study2)


# Generated at 2022-06-26 07:44:30.456127
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    str_0 = '\x0b95x\x0bp2yf@O@Rba2'
    rough_parser_0 = RoughParser(str_0, str_0)
    str_1 = '{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}'
    assert str_1.format('\x0b95x\x0bp2y', 'f@O@Rb', 'a2') == str_0
    assert rough_parser_0.get_last_stmt_bracketing() == None
    str_1 = '{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}'
    assert str_1.format('}', '}', '}') == str_0
    assert rough_parser_0.get_last_stmt

# Generated at 2022-06-26 07:44:40.097936
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = "def f(x):\n    print(x)\n"
    index = text.index("(")
    h = HyperParser(text, index)
    # We are after the bracket
    assert h.indexinrawtext == 7
    # we are in a bracketing
    assert h.bracketing
    # We are after the first bracketing
    assert h.indexbracket == 0
    # The first bracketing is an opener
    assert h.isopener[0]
    # The bracket is a round one
    assert h.rawtext[h.bracketing[0][0]] == "("
    assert h.is_in_code()
    assert not h.is_in_string()
    assert h.get_surrounding_brackets() == ("1.12", "1.13")

# Generated at 2022-06-26 07:44:44.867460
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # The following line should not crash
    HyperParser("  (  )", "1.end").get_surrounding_brackets(" ")

if __name__ == "__main__":
    test_case_0()
    test_HyperParser_get_surrounding_brackets()

# Generated at 2022-06-26 07:44:56.781796
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():

    test_str_1 = "(([],),)" # Testing brackets () and []
    test_str_2 = "(([],),()" # Testing brackets {}
    test_str_3 = "(a, b, , c" # missing ""
    test_str_4 = "(a, b, , c)" # missing ""

    test_str_5 = "(([],),)" # Testing brackets () and []
    test_str_6 = "(([],),()" # Testing brackets {}
    test_str_7 = "(a, b, , c" # missing ""
    test_str_8 = "(a, b, , c)" # missing ""

    test_str_9 = "(([],),)" # Testing brackets () and []
    test_str_10 = "(([],),()" # Testing brackets {}
    test_str_11

# Generated at 2022-06-26 07:45:00.809096
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rough_parser_0 = RoughParser(str_0, str_0)
    rough_parser_0.set_lo(0, 0)


# Generated at 2022-06-26 07:45:06.750363
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    str_0 = '\x0b95x\x0bp2yf@O@Rba2'
    rough_parser_0 = RoughParser(str_0, str_0)
    assert (rough_parser_0.is_block_opener() == False)


# Generated at 2022-06-26 07:45:09.477069
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    for str_1 in ['\x0b95x\x0bp2yf@O@Rba2', '\x0b95x\x0bp2yf@O@Rba2']:
        rough_parser_1 = RoughParser(str_1, str_1)
        rough_parser_1.compute_bracket_indent()


# Generated at 2022-06-26 07:45:21.586611
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from tkinter.simpledialog import askstring

    from idlelib.idle_test.htest import testwrap, run

    text = testwrap("""\
    def f():
        pass
    def g():
        pass
    def h():
        pass
    """)
    text.settext('    def f():\n        pass\n    def g():\n        pass\n    def h():\n        pass\n')

    text.mark_set("insert", "1.0")
    hp = HyperParser(text, "insert")

    text.mark_set("insert", "1.0+5c")
    hp.set_index("insert")
    if hp.is_in_string():
        print("in string")
    if hp.is_in_code():
        print("in code")
   

# Generated at 2022-06-26 07:46:47.158415
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from idlelib import parenmatch
    from Tkinter import Text
    text = Text()
    hyper_parser_0 = HyperParser(text, 0)
