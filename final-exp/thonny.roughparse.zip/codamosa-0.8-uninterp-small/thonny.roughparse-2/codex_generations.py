

# Generated at 2022-06-26 07:38:01.662218
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-26 07:38:07.463958
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    # tested on the following cases:
    # 1. (string_translate_pseudo_mapping_0 == StringTranslatePseudoMapping(False, False)) and
    #    (string_translate_pseudo_mapping_1 == StringTranslatePseudoMapping(False, False))
    test_0(string_translate_pseudo_mapping_0, string_translate_pseudo_mapping_1)
    # 2. (string_translate_pseudo_mapping_2 == StringTranslatePseudoMapping(True, False)) and
    #    (string_translate_pseudo_mapping_3 == StringTranslatePseudoMapping(True, False))

# Generated at 2022-06-26 07:38:18.821159
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    parser = RoughParser()
    parser.set_str("if True:\n    pass\n    \n    \n    \n    \n")
    assert parser.compute_backslash_indent() == 9
    parser.set_str("if True and \\\n    False:\n    pass\n")
    assert parser.compute_backslash_indent() == 20
    parser.set_str("if True and False:\n    pass\n")
    assert parser.compute_backslash_indent() == 20
    parser.set_str("if True:\n    pass\n    # a comment\n")
    assert parser.compute_backslash_indent() == 9
    parser.set_str("if True:\n    pass\n    a = 1\n")
    assert parser.compute_

# Generated at 2022-06-26 07:38:26.645599
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    bool_0 = False
    string_translate_pseudo_mapping_0 = StringTranslatePseudoMapping(bool_0, bool_0)
    string_0 = "([{"
    rough_parser_0 = RoughParser(string_0, string_translate_pseudo_mapping_0)
    rough_parser_0._study2()
    # Check that the last open bracket position is what expected
    assert(0 == rough_parser_0.lastopenbracketpos)


# Generated at 2022-06-26 07:38:28.029763
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-26 07:38:31.431679
# Unit test for constructor of class HyperParser
def test_HyperParser():
    w = Text()
    w.insert("insert", "abc")
    hyper = HyperParser(w, "insert")


# Generated at 2022-06-26 07:38:33.237417
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # Create a RoughParser
    rough_parser_0 = RoughParser(set_lo=True)


# Generated at 2022-06-26 07:38:39.309512
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # 3 cases: all white, all junk, real code
    for s, expect_i in [
        ("   \n # comment\n", 3),
        (" # comment\n", 0),
        ("def foo():\n pass", 0),
    ]:
        start_i, _, _ = RoughParser(s, 0).find_good_parse_start()
        assert start_i == expect_i


# Generated at 2022-06-26 07:38:42.845568
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # It tests the case where there exists a valid string
    string_0 = unichr(0)
    HyperParser_0 = HyperParser(string_0, len(string_0))
    HyperParser_0.is_in_code()


# Generated at 2022-06-26 07:38:45.758874
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rough_parser_0 = RoughParser("abc = 123;\n    def = 456", 4)
    string_0 = rough_parser_0.get_base_indent_string()
    assert string_0 == "    "


# Generated at 2022-06-26 07:39:46.962381
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    class_0 = RoughParser()
    func_0 = test_case_0
    func_0_name = getattr(func_0, '__name__', None)
    if func_0_name is None:
        func_0_name = 'test_case_0'
    parser_ref = get_function_source_code_object(func_0, func_0_name)
    class_0.set_str(parser_ref)
    class_0._study2()

    str_to_check = class_0.get_base_indent_string()
    assert str_to_check == '    '


# Generated at 2022-06-26 07:39:52.692516
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Tests of various expressions
    str_0 = "([{foo1}])"
    str_1 = "(foo2{})"
    str_2 = "({foo3})"
    str_3 = "([foo4])"
    str_4 = "({foo5})"
    str_5 = "([foo6]{})"
    str_6 = "({foo7}{})"
    str_7 = "([foo8{}])"
    str_8 = "({foo9[}])"
    str_9 = "([foo10])"
    str_10 = "foo11(bar12)"
    str_11 = "foo13[bar14]"
    str_12 = "foo15.bar16"
    str_13 = "foo17[0]"

# Generated at 2022-06-26 07:39:56.379166
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    '''
    Test get_expression
    '''
    test_case = 'def test_case_0():\n    int_0 = 0'
    root = tk.Tk()
    text_0 = Text(root)
    text_0.insert('end', test_case)

    hp = HyperParser(text_0, 'end')
    expression = hp.get_expression()
    assert expression == 'test_case_0', 'Didn\'t get correct expression'



# Generated at 2022-06-26 07:39:57.638418
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    assert RoughParser().set_lo == test_case_0


# Generated at 2022-06-26 07:40:00.098708
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import mock

    int_0 = HyperParser.is_in_code(test_case_0)
    assert int_0 is None

# Generated at 2022-06-26 07:40:05.313290
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    int_0 = 0
    RoughParser_0 = RoughParser()
    RoughParser_0.set_str("  def foo():  ")
    assert RoughParser_0.str == "  def foo():  "
    RoughParser_0.set_str("  def foo():  ")
    assert RoughParser_0.str == "  def foo():  "


# Generated at 2022-06-26 07:40:16.564023
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # Test cases with if/else/elif, maybe this is useless?
    assert RoughParser("a = 12").get_continuation_type() == C_NONE
    # Test cases with while/for
    assert RoughParser("a = 12").get_continuation_type() == C_NONE
    # Test cases with =, +, -, *, /, %, &, ^, |, <<, >>, **
    assert RoughParser("a = 12").get_continuation_type() == C_NONE
    assert RoughParser("a + 12").get_continuation_type() == C_NONE
    assert RoughParser("a - 12").get_continuation_type() == C_NONE
    assert RoughParser("a * 12").get_continuation_type() == C_NONE
    assert RoughParser("a / 12").get_

# Generated at 2022-06-26 07:40:23.560396
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # Test cases for is_in_string
    from tkinter import Text
    t = Text()
    t.insert(1.0, 'a = "abc"')
    p = HyperParser(t, "1.6")
    if p.is_in_string():
        raise RuntimeError("is_in_string should return False")
    p = HyperParser(t, "1.0")
    if not p.is_in_string():
        raise RuntimeError("is_in_string should return True")


# Generated at 2022-06-26 07:40:25.653584
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    print("Test set_index")
    testHyperParser = HyperParser("", "")
    testHyperParser.set_index("")


# Generated at 2022-06-26 07:40:28.240807
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    test_text = 'int a = "int_0"'
    idx = test_text.index('int')
    hp = HyperParser(test_text, idx)
    assert hp.is_in_code()


# Generated at 2022-06-26 07:41:48.941216
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    test_case_0()

if __name__ == "__main__":
    import sys
    import logging

    logging.basicConfig(filename="log.txt", level=logging.DEBUG)
    logging.debug("{}".format(sys.argv))

    test_RoughParser_get_last_stmt_bracketing()

# Generated at 2022-06-26 07:41:59.100554
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from math import *

    if not os.path.exists(log_file_name):
        with open(log_file_name, "w") as f:
            f.write("")
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(message)s")
    handler = logging.FileHandler(log_file_name, 'a')
    handler.setFormatter(formatter)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    logger.debug("patch_line = {}".format(patch_line))
    # HyperParser.get_surrounding_brackets
    with open(test_file, "r") as f:
        lines = f.readlines()


# Generated at 2022-06-26 07:42:11.133668
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    test_0 = "asdf = asdf()\nprint(asdf)"
    rp_0 = RoughParser(test_0)
    assert rp_0.compute_backslash_indent() == 5
    assert rp_0.get_num_lines_in_stmt() == 2
    assert rp_0.get_continuation_type() == C_BACKSLASH
    assert rp_0.get_last_open_bracket_pos() == None
    assert rp_0.get_last_stmt_bracketing() == ((0, 0), (5, 1), (6, 0),
                                               (7, 1), (8, 0), (13, 0))

    test_1 = "asdf = asdf() \\ \nprint(asdf)"
    rp_1 = Rough

# Generated at 2022-06-26 07:42:16.009002
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    p = RoughParser("\\", indent_width = 4, tabwidth = 8)
    if p.compute_backslash_indent() != 1:
        test_error("Wrong indent")
    del p


# Generated at 2022-06-26 07:42:21.463574
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    text_0 = test_case_0.__code__
    parser = HyperParser(text_0, 0)
    str_0 = parser.get_expression()


# Generated at 2022-06-26 07:42:33.486000
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    from numba import njit

    int_0 = 0

    # Create a RoughParser
    @njit
    def test_get_num_lines_in_stmt():
        parser = RoughParser(
            "def foo():\n"
            "    int_0 = 0\n"
            "    int_1 = 1\n"
            "    int_2 = 2\n"
            "    int_3 = 3\n"
            "    int_4 = 4\n"
            "    return int_0\n"
        )
        num_lines_in_stmt = parser.get_num_lines_in_stmt()
        return num_lines_in_stmt
    
    # Test and return the results
    res = test_get_num_lines_in_stmt()
    return res


# Generated at 2022-06-26 07:42:43.668746
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    global instance
    global text
    global index
    global int_0
    global int_1
    global int_2

    instance = HyperParser(text, index)
    int_1 = instance.is_in_string()
    assert(int_1 == int_0)

    index = 1.0
    instance.set_index(index)
    int_1 = instance.is_in_string()
    assert(int_1 == int_0)

    index = 1.5
    instance.set_index(index)
    int_1 = instance.is_in_string()
    assert(int_1 == int_0)

    index = 2.0
    instance.set_index(index)
    int_1 = instance.is_in_string()
    assert(int_1 == int_0)


# Generated at 2022-06-26 07:42:48.171004
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    global int_0
    test = HyperParser('    int_0 = 1', 'insert')
    result = test.get_expression()
    assert result == '1'



# Generated at 2022-06-26 07:42:50.096721
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    parse_string = RoughParser()
    parse_string.compute_backslash_indent()
    print('OK')


# Generated at 2022-06-26 07:42:58.189450
# Unit test for constructor of class HyperParser
def test_HyperParser():
    """Unit test for constructor of class HyperParser"""

    # Create a dummy text with a string.
    text = DummyText()
    text.set("test_case_0()\n")
    # The index just before the "0" (class int)
    index = text.index("%d.0" % 2)
    hyper = HyperParser(text, index)

    # test for is_in_code()
    if not hyper.is_in_code():
        print("hyper.is_in_code() failed")

    # test for indexbracket
    # Should be 1
    if hyper.indexbracket != 1:
        print("hyper.indexbracket failed, expected %d got %d" % (1, hyper.indexbracket))

    # test for get_surrounding_brackets()
    # index given to HyperParser

# Generated at 2022-06-26 07:46:46.050910
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    import unittest
    import re
    import sys
    import tkinter
    import idlelib
    from idlelib.idle_test.mock_tk import Text
    from idlelib.idle_test.mock_tk import CallWrapper

    # m is a module object that contains a function called "function_0"
    # which takes no arguments.
    class HyperParser_Stub:
        def __init__(self,m,function_0):
            self.m = m
            self.function_0 = function_0
            self.label = 'Label'
            self.counter = 0
        def __call__(self):
            self.counter += 1