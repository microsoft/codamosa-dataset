

# Generated at 2022-06-26 07:39:16.213235
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rough_parser_0 = RoughParser('a = \\', 0, ' ', '\t')
    assert rough_parser_0.compute_backslash_indent() == 0


# Generated at 2022-06-26 07:39:19.807468
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    Test.it("test_RoughParser_compute_bracket_indent")
    str_0 = "               "
    int_0 = -1911
    rough_parser_0 = RoughParser(int_0, str_0)
    Test.assert_equals(rough_parser_0.compute_bracket_indent(), 0)
    return


# Generated at 2022-06-26 07:39:26.150832
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Setup test
    int_0 = -1760
    str_0 = 'v\tGwh6_1B"B'
    hyper_parser_0 = HyperParser(int_0, str_0)
    # Assertion for instance attribute access get_expression
    hyper_parser_0.get_expression()
    # Teardown test
    # Unit test for method get_expression of class HyperParser
    # Assertion for method get_surrounding_brackets
    hyper_parser_0.get_surrounding_brackets()


# Generated at 2022-06-26 07:39:32.464187
# Unit test for constructor of class HyperParser
def test_HyperParser():
    pass


if __name__ == "__main__":
    # import profile, pstats
    # profile.run("test_case_0()", "profile.stats")
    # p = pstats.Stats("profile.stats")
    # p.strip_dirs().sort_stats("cumulative").print_stats()
    test_case_0()

# Generated at 2022-06-26 07:39:37.096521
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    """
    .. todo::
        method not in use yet
    """
    # pylint: disable=unused-argument
    hyper_parser_0 = RoughParser()
    hyper_parser_0.set_lo(1)


# Generated at 2022-06-26 07:39:41.909433
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    str_0 = 'K\x00t=\x00?_\x00;r'
    hyper_parser_0 = HyperParser(str_0, str_0)
    str_1 = "o\x00;m\x00?\x00?\x00\x7fr\x00;\x00?\x00\x7f\x00\x7f\x00?\x00?\x00\x7f"
    hyper_parser_0.set_index(str_1)
    bool_0 = hyper_parser_0.is_in_code()


# Generated at 2022-06-26 07:39:49.353144
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Test cases
    # A. Test missing brackets
    text = "import math"
    hyper_parser = HyperParser(text, "7.0")
    # No missing brackets, return None
    assert hyper_parser.get_surrounding_brackets() == None
    # Missing brackets, return None
    hyper_parser.set_index("6.0")
    assert hyper_parser.get_surrounding_brackets() == None
    # Missing brackets, return None
    hyper_parser.set_index("6.5")
    assert hyper_parser.get_surrounding_brackets() == None
    # B. Test index at the left of brackets
    text = "((())"
    hyper_parser = HyperParser(text, "4.0")
    # Return bracket indexes
    assert hyper_parser.get_surrounding_br

# Generated at 2022-06-26 07:39:55.188038
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    int_0 = -2289
    str_0 = 'BH'
    hyper_parser_0 = HyperParser(int_0, str_0)
    var_0 = hyper_parser_0.get_expression()
    str_1 = 't\tA<'
    hyper_parser_0 = HyperParser(int_0, str_1)
    var_1 = hyper_parser_0.get_expression()
    str_2 = '`2g'
    hyper_parser_0 = HyperParser(int_0, str_2)
    var_2 = hyper_parser_0.get_expression()
    str_3 = 'C\t'
    hyper_parser_0 = HyperParser(int_0, str_3)
    var_3 = hyper_parser_0.get_expression()


# Generated at 2022-06-26 07:40:02.611192
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # pylint: disable=too-many-statements
    int_0 = 1782
    str_0 = 'z\t"\n[1'
    rough_parser_0 = RoughParser(int_0, str_0)
    int_1 = -1672
    rough_parser_0.set_lo(int_1)
    # Verify exception raised by method set_lo of class RoughParser
    if_0 = isinstance(rough_parser_0, RoughParser)
    # Check the type of the raised exception
    assert_0 = AssertionError()
    # Verify exception raised by method set_lo of class RoughParser
    if_1 = isinstance(rough_parser_0, RoughParser)
    # Check the type of the raised exception
    assert_1 = AssertionError()
    # Verify exception raised by method set

# Generated at 2022-06-26 07:40:08.518284
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Test data
    # Test data
    negative_arg = -1
    negative_arg = -1
    negative_arg = -1
    negative_arg = -1
    hyper_parser_0 = HyperParser(negative_arg, negative_arg)
    var_0 = hyper_parser_0.get_expression()

# Test method set_index of class HyperParser

# Generated at 2022-06-26 07:40:47.066679
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    int_0 = -1
    str_0 = 'abc\ndef\nghi'
    rough_parser_0 = RoughParser(int_0, str_0)
    var_0 = rough_parser_0.compute_backslash_indent()


# Generated at 2022-06-26 07:40:48.379695
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 07:41:03.494684
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    int_0 = 1488
    str_0 = '<>0Wf)&y|%c'
    rough_parser_0 = RoughParser(int_0, str_0)
    var_0 = rough_parser_0.compute_bracket_indent()
    assert var_0 == 1881
    int_0 = 1256
    str_0 = '^k5}5\\'
    rough_parser_0 = RoughParser(int_0, str_0)
    var_0 = rough_parser_0.compute_bracket_indent()
    assert var_0 == 1449
    int_0 = 659
    str_0 = '=W#'
    rough_parser_0 = RoughParser(int_0, str_0)
    var_0 = rough_parser_0.compute_

# Generated at 2022-06-26 07:41:12.604357
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    int_0 = 1860

# Generated at 2022-06-26 07:41:13.345073
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    test_case_0()


# Generated at 2022-06-26 07:41:29.070206
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rough_parser_1 = RoughParser(0, '')
    global line_no
    line_no += 1
    rough_parser_1 = RoughParser(0, ' def compute_backslash_indent(self):\n')
    global line_no
    line_no += 1
    rough_parser_1 = RoughParser(0, '       self._study2()\n')
    global line_no
    line_no += 1
    rough_parser_1 = RoughParser(0, '       assert self.continuation == C_BACKSLASH\n')
    global line_no
    line_no += 1
    rough_parser_1 = RoughParser(0, '       str = self.str\n')
    global line_no
    line_no += 1

# Generated at 2022-06-26 07:41:35.539133
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    int_0 = 1860
    str_0 = '^=|~8amjucN-6\\w$p'
    rough_parser_0 = RoughParser(int_0, str_0)
    rough_parser_0.str = "def 2: "
    int_1 = 0
    int_2 = 2
    int_3 = 2
    tuple_0 = (int_1, int_2)
    tuple_1 = (int_2, int_3)
    tuple_2 = (int_3, int_3)
    list_0 = [tuple_0, tuple_1, tuple_2]
    rough_parser_0.level = list_0
    hyper_parser_0 = HyperParser(rough_parser_0, int_2)
    assert hyper_parser_0.is_in_code()


# Generated at 2022-06-26 07:41:36.886028
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    assert True


# Generated at 2022-06-26 07:41:48.852543
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    test_string_0 = 'eT"T=p}*"|-smau}s+s*s{s+s}s*s(s+s)s*s[s+s]s*s`s+s\'s+s\"s+s#s+s\\s+s'
    test_string_0 = test_string_0.replace("s", " ")
    test_string_0 = test_string_0.replace("T", "True")
    test_string_0 = test_string_0.replace("F", "False")
    test_string_0 = test_string_0.replace("N", "None")
    test_string_0 = test_string_0.replace("e", "=")
    test_string_0 = test_string_0.replace("p", "+")
   

# Generated at 2022-06-26 07:41:54.394207
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    py_mod = '''def foo(x):
    return x +

bar(foo(1))'''
    h = HyperParser(text=py_mod, index="3.0")
    assert not h.is_in_string()
    h.set_index(index="5.0")
    assert h.is_in_string()


# Generated at 2022-06-26 07:43:01.435400
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    print("Test case: set_index in HyperParser")
    rough_parser_0 = RoughParser(0, '')
    hyper_parser_0 = HyperParser(rough_parser_0, 0)
    var_0 = hyper_parser_0.set_index(1)
    print("Test case: Pass")


# Generated at 2022-06-26 07:43:13.341330
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text_0 = 'import functools\n\ndef compose(*funcs):\n    return functools.reduce(lambda f, g: lambda x: f(g(x)), funcs)\n'
    text_box_var_0 = text_0
    hyper_parser_var_0 = HyperParser(text_box_var_0, '5.0')
    hyper_parser_var_1 = HyperParser(text_box_var_0, '5.0')
    hyper_parser_var_2 = HyperParser(text_box_var_0, '4.0')
    hyper_parser_var_2 = HyperParser(text_box_var_0, '7.0')
    hyper_parser_var_3 = HyperParser(text_box_var_0, '34.0')
    hyper_parser_

# Generated at 2022-06-26 07:43:17.395556
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text_0 = Text(state='normal')
    int_0 = 600
    hyper_parser_0 = HyperParser(text_0, int_0)
    int_0 = 100
    hyper_parser_0.set_index(int_0)


# Generated at 2022-06-26 07:43:25.614379
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    int_0 = 1678
    str_0 = "jv88[a,iR]!hL-j^8N}p"
    index_0 = '3.0'
    hyper_parser_0 = HyperParser(int_0, str_0, index_0)
    index_1 = '3.0'
    hyper_parser_0.set_index(index_1)
    str_1 = hyper_parser_0.rawtext

# Generated at 2022-06-26 07:43:27.567193
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    hyper_parser_0 = HyperParser("zRk-13\n5X5\nc", "0.0")
    hyper_parser_0.set_index("3.0")


# Generated at 2022-06-26 07:43:32.228848
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    int_0 = 1860
    str_0 = '^=|~8amjucN-6\\w$p'
    rough_parser_0 = RoughParser(int_0, str_0)
    var_0 = rough_parser_0.get_last_stmt_bracketing()
    hyper_parser_0 = HyperParser(rough_parser_0, var_0)
    var_1 = hyper_parser_0.get_expression()


# Generated at 2022-06-26 07:43:40.181902
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    str_0 = '\n    """\n    Returns an iterable over the items in mapping\n    sorted by their values.\n\n    When two items have the same value, the iterator returns\n    the item which appears first in mapping.\n\n    """\n    return sorted(mapping.items(), key=lambda item: item[1])\n'
    hyper_parser_0 = HyperParser(str_0, int_0)
    var_1 = hyper_parser_0.get_expression()
    int_1 = 1863


test_case_0()

# Generated at 2022-06-26 07:43:46.284301
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    try:
        hyper_parser_0 = HyperParser('This is a test string.', 5)
        hyper_parser_0.set_index(5)
    except ValueError as e:
        print("Failed to set index: {}".format(e))
        return False
    return True


# Generated at 2022-06-26 07:43:55.921925
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():

    # Test 1
    text_1 = tk.Text(tk.Frame(), bg="white", fg="black", height=8, width=10)
    text_1.insert(tk.INSERT, "if True:\n    if True:\n        pass\n")
    hyper_parser_1 = HyperParser(text_1, "end")
    hyper_parser_1.set_index("end")
    var_1 = hyper_parser_1.is_in_string()
    assert var_1 is False

    # Test 2
    text_2 = tk.Text(tk.Frame(), bg="white", fg="black", height=8, width=10)
    text_2.insert(tk.INSERT, "if True:\n    if True:\n        pass\n")
    hyper_parser_2 = HyperParser

# Generated at 2022-06-26 07:44:05.243380
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    test_cases = []

    new_test_case = { 
        'expected': 0,
        'inputs': [
            'x = "\\n"',
        ],
    }
    test_cases.append(new_test_case)

    new_test_case = { 
        'expected': 0,
        'inputs': [
            'x = "\\n\\n"',
        ],
    }
    test_cases.append(new_test_case)

    new_test_case = { 
        'expected': 0,
        'inputs': [
            'x = "\\n\\n\\n"',
        ],
    }
    test_cases.append(new_test_case)
