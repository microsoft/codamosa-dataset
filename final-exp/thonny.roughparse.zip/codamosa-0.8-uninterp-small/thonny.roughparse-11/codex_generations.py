

# Generated at 2022-06-26 07:38:31.605124
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    set_0 = set()
    float_0 = -1475.402929
    string_translate_pseudo_mapping_0 = StringTranslatePseudoMapping(set_0, float_0)
    string_translate_pseudo_mapping_0.__len__()


# Generated at 2022-06-26 07:38:36.449333
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    set_0 = set()
    float_0 = -1475.402929
    string_translate_pseudo_mapping_0 = StringTranslatePseudoMapping(set_0, float_0)
    string_translate_pseudo_mapping_0.get(-14.005439353)


# Generated at 2022-06-26 07:38:46.341334
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    source = """\
    # This is a test for method set_str of class RoughParser
    x = 1
    if True:
        x = 2
        x = 3
    x = 4
    """
    rough_parser = RoughParser(source)
    assert(rough_parser.str == source)

    # Case 0: Try to set the string attribute to an empty string
    #         and see if it works
    # Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0: Case 0:

# Generated at 2022-06-26 07:38:47.580760
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    global hyperparser_inst
    assert hyperparser_inst.is_in_string()


# Generated at 2022-06-26 07:38:55.603932
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # The next line will be replaced by the contents of a test file.
    text_0 = ""
    # The next line will be replaced by the contents of a test file.
    index_0 = ""
    hyper_parser_0 = HyperParser(text_0, index_0)
    # The next line will be replaced by the contents of a test file.
    openers_0 = ""
    # The next line will be replaced by the contents of a test file.
    mustclose_0 = ""
    hyper_parser_0.get_surrounding_brackets(openers_0, mustclose_0)


# Generated at 2022-06-26 07:39:06.363630
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text()
    text.config(state="normal")

    text.insert("1.0", "def test_method():\n")
    text.insert("2.0", "# this is a comment\n")
    text.insert("3.0", "    pass\n")
    text.insert("4.0", "'This is a string'\n")

    parser = HyperParser(text, "1.0")
    assert parser.is_in_code() == True
    parser.set_index("1.1")
    assert parser.is_in_code() == True

    parser.set_index("2.0")
    assert parser.is_in_code() == False
    parser.set_index("2.1")
    assert parser.is_in_code() == False


# Generated at 2022-06-26 07:39:19.122019
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    tabwidth = 8
    s = """\
if a:
    while b:
        if c:
            pass
        else:
            print('\\
              more indenting here')
        print('\\
          more indenting here')
    print('no more indenting here')
"""
    p = RoughParser(s, tabwidth)
    assert p.compute_backslash_indent() == 31
    assert p.get_num_lines_in_stmt() == 1

    s = """\
if a:
    while b:
        if c:
            pass
        else:
            print('\\
              more indenting here')
        print('\\
          more indenting here')
\tprint('no more indenting here')
"""
    p = RoughParser

# Generated at 2022-06-26 07:39:31.017918
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rough_parser_0 = RoughParser(None, 4, 1.0)
    rough_parser_0.continuation = "C_BRACKET"

# Generated at 2022-06-26 07:39:41.154276
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from idlelib.idle_test.mock_idle import Func
    root = tkinter.Tk()
    text = Text(root)
    text.insert('1.0', 'def f(a, arg):\n')
    text.insert('2.0', '    var = 5\n')
    text.insert('3.0', '    var = var * ')
    text.mark_set('sot', '3.0')
    calltip = CallTips()
    calltip.text = text
    calltip.watchers = [Func()]
    calltip.calltip_window = Toplevel(text)
    calltip.calltip_window.wm_overrideredirect(True)
    parser = HyperParser(text, '3.19')

# Generated at 2022-06-26 07:39:43.812149
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    test_text = "foo\n"
    test_index = "1.0"

    hyper_parser = HyperParser(test_text, test_index)
    hyper_parser.set_index(test_index)


# Generated at 2022-06-26 07:40:26.015379
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # Unit test for function get_expression of class HyperParser
    def check(hyper_parser, index, expected_result):
        hyper_parser.set_index(index)
        actual = hyper_parser.get_expression()
        if actual == expected_result:
            print("ok")
        else:
            print("test failed")
            print("  actual: " + actual)
            print("expected: " + expected_result)
    # Unit test for function get_expression of class HyperParser

    # First test case
    str_0 = '    # This is a test for method set_str of class RoughParser\n    x = 1\n    if True:\n        x = 2\n        x = 3\n    x = 4\n    '
    rough_parser_0 = RoughParser(4)
    rough_parser_0.set_

# Generated at 2022-06-26 07:40:30.994582
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    str_0 = '    # This is a test for method set_str of class RoughParser\n    x = 1\n    if True:\n        x = 2\n        x = 3\n    x = 4\n    '
    hyper_parser_0 = HyperParser(str_0, '9.0')
    hyper_parser_0.set_index('16.0')


# Generated at 2022-06-26 07:40:40.381757
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    str_0 = '    # This is a test for method get of class StringTranslatePseudoMapping\n    x = 1\n    if True:\n        x = 2\n        x = 3\n    x = 4\n    '
    str_1 = str_0.replace("\t", '\t' * 4)
    # Remove comments and blank lines
    str_2 = "".join(
        [
            line if not (re.match(r"\s*\n", line) or re.match(r"\s*#+.*\n", line)) else "\n"
            for line in str_1.split("\n")
        ]
    )
    str_3 = re.sub(r"\s+\n", "\n", str_2)
    str_4 = str_3.l

# Generated at 2022-06-26 07:40:50.499389
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    str_0 = '    # This is a test for method get_surrounding_brackets of class HyperParser\n    x = 1\n    if True:\n        x = 2\n        x = 3\n    x = 4\n    '
    hyper_parser_0 = HyperParser(str_0, "4.12")
    assert hyper_parser_0.get_surrounding_brackets(mustclose=True) == ("4.12", "4.13")
    # test case get_surrounding_brackets #1
    str_0 = '    # This is a test for method get_surrounding_brackets of class HyperParser\n    x = 1\n    if True:\n        x = 2\n        x = 3\n    x = 4\n    '

# Generated at 2022-06-26 07:41:04.083598
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    str_1 = '    # This is a test for method set_str of class RoughParser\n    x = 1\n    if True:\n        x = 2\n        x = 3\n    x = 4\n    '
    rough_parser_1 = RoughParser(str_1)
    assert rough_parser_1.get_raw_indent() == 4

    # case_1
    rough_parser_1.set_lo(1)
    assert rough_parser_1.get_raw_indent() == 4

    # case_2
    rough_parser_1.set_lo(4)
    assert rough_parser_1.get_raw_indent() == 4

    # case_3
    rough_parser_1.set_lo(5)
    assert rough_parser_1.get_raw_indent()

# Generated at 2022-06-26 07:41:14.054954
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    str_0 = '    # This is a test for method is_in_code of class HyperParser\n    x = 1\n    if True:\n        x = 2\n        x = 3\n    x = 4\n    '
    rough_parser_0 = RoughParser(str_0)
    tk = Tk()
    text_0 = Text(tk)

    # Send str_0 to the text window
    text_0.insert(END, str_0)
    hyper_parser_0 = HyperParser(text_0, 'str_0.0')

    # 'x = 1'
    ret = hyper_parser_0.is_in_code()
    assert ret

    # 'if True:'
    hyper_parser_0.set_index('str_0.14c')
    ret = hyper_parser_0

# Generated at 2022-06-26 07:41:21.701030
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    lines = [
        '    x = 1\\',
        '    y = 2',
    ]
    str_0 = '\n'.join(lines)
    rough_parser_0 = RoughParser(str_0)
    i = rough_parser_0.compute_backslash_indent()
    assert i == 5


# Generated at 2022-06-26 07:41:29.623264
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    str_0 = '    # This is a test for method set_str of class RoughParser\n    x = 1\n    if True:\n        x = 2\n        x = 3\n    x = 4\n    '
    rough_parser_0 = RoughParser(str_0)
    assert '    ' == rough_parser_0.get_base_indent_string()


# Generated at 2022-06-26 07:41:42.649612
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():

    def assert_hyper_parse_expression(text, exp_index, exp_str, msg=None):
        """Assert that the expression at `index` in `text` is `exp_str`."""
        hyper_parser = HyperParser(text, exp_index)
        act_str = hyper_parser.get_expression()
        if act_str != exp_str:
            raise ValueError(
                "%s: expected %r, got %r" % (msg, exp_str, act_str)
            )

    # (This test is based on the example code in
    # tkinter.tix.Tk.callit/CallWrapper.__call__)

# Generated at 2022-06-26 07:41:46.856643
# Unit test for constructor of class HyperParser
def test_HyperParser():
    str_0 = '    # This is a test for method set_str of class RoughParser\n    x = 1\n    if True:\n        x = 2\n        x = 3\n    x = 4\n    '
    hyper_parser_0 = HyperParser(str_0)



# Generated at 2022-06-26 07:42:35.849322
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-26 07:42:42.391685
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    char_to_keep = 'a'
    preserve_dict = {ord(char_to_keep): ord(char_to_keep)}
    replace_value = ord('x')
    mapping = StringTranslatePseudoMapping(preserve_dict, replace_value)
    assert mapping.get(ord('a')) == ord('a')
    assert mapping.get(ord('b')) == ord('x')


# Generated at 2022-06-26 07:42:54.364738
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # Create a canvas
    t = Tk()
    canvas = Canvas(t)
    # Create a Text widget
    Text = Text()
    # Set the string
    str_0='#this is a comment for is_in_code testing\na = 10 #second comment\n'
    Text.insert(INSERT, str_0)
    Text.pack()
    # Create a HyperParser with index at the end of first line
    index_1=6
    hyperparser_1 = HyperParser(Text, index_1)
    # Test that it is inside code on the first line
    if(hyperparser_1.is_in_code()==False):
        raise ValueError("HyperParser.is_in_code must return True if point is inside code")
    # Create a HyperParser with index at the end of the first comment
    index_

# Generated at 2022-06-26 07:43:07.959810
# Unit test for constructor of class HyperParser
def test_HyperParser():
    print("=== Test 1 ===")

# Generated at 2022-06-26 07:43:14.672398
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    set_0 = set(_PATTERN_0)
    rough_parser_0 = RoughParser(str_0, set_0)
    # Should raise ValueError
    try:
        rough_parser_0.set_index([1,0])
    except ValueError:
        pass
    else:
        raise Exception("Test case Failed! Should raise ValueError")


# Generated at 2022-06-26 07:43:18.837325
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_0 = '*0H(fGdk'
    set_0 = set()
    rough_parser_0 = RoughParser(str_0, set_0)
    result = rough_parser_0.find_good_parse_start()
    print(result)
    assert(result == 3)


# Generated at 2022-06-26 07:43:22.245532
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # Exercise code
    str_0 = 'tHNHh_n>i'
    set_0 = set()
    rough_parser_0 = RoughParser(str_0, set_0)
    rough_parser_0.compute_backslash_indent()


# Generated at 2022-06-26 07:43:29.054801
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    assert HyperParser.get_surrounding_brackets('()', '(') == True


# Generated at 2022-06-26 07:43:37.676515
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    # Test coverage of the get method with a no-default case
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert mapping.get(ord('a')) == ord('x')
    assert mapping.get(ord(' ')) == ord(' ')
    assert mapping.get(ord('\t')) == ord('\t')
    assert mapping.get(ord('\n')) == ord('\n')

#Unit test for method __getitem__ of class StringTranslatePseudoMapping

# Generated at 2022-06-26 07:43:41.002065
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    str_0 = '*0H(fGdk'
    set_0 = set()
    rough_parser_0 = RoughParser(str_0, set_0)
    hyper_parser_0 = HyperParser(str_0, set_0)
    hyper_parser_0.set_index(rough_parser_0)


# Generated at 2022-06-26 07:44:24.012921
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    str_0 = "    if a < b:"
    set_0 = {"\n", "(", ")", ";"}
    parser_0 = RoughParser(str_0, set_0)
    result = parser_0.compute_bracket_indent()
    assert result == 21


# Generated at 2022-06-26 07:44:33.275826
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():

        def test_is_in_string(self, result, string, index):
                for i in range(len(string)):
                        self.set_index("%s.%d" % (index, i))
                        if self.is_in_string():
                                result.append("%s.%d" % (index, i))

        result = []

# Generated at 2022-06-26 07:44:39.878490
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # A simple statement
    s = 'print("hello world")'
    hp = HyperParser(s, len(s) - 3)

    # A complex statement
    s = (
        '''if True:
    print("hello")
        elif True:
            pass
        else:
            print("wazup")
    '''
    )
    hp = HyperParser(s, len(s) - 12)
    hp = HyperParser(s, len(s) - 1)



# Generated at 2022-06-26 07:44:46.767032
# Unit test for constructor of class HyperParser
def test_HyperParser():
    """Unit test for constructor of class HyperParser
    """
    #content = ['|def baz():', '    return foo(a = 3)']
    #content = ['|a = 3']
    content = ['|1', '2', '3']
    text = TkText(None, content)
    #position = '0.11'
    position = '1.1'
    hyper_parser_0 = HyperParser(text, position)
    set_0 = set(hyper_parser_0.rawtext)
    assert True


_MISSING = object()



# Generated at 2022-06-26 07:44:52.402698
# Unit test for constructor of class HyperParser
def test_HyperParser():
    index = "1.0"
    text = """print("hello world")
    def print_hello():
        print("hello")
        print("world")
    """
    hyper_parser_0 = HyperParser(text, index)

if __name__ == '__main__':
    test_case_0()
    test_HyperParser()

# Generated at 2022-06-26 07:44:54.704477
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    set_0 = RoughParser()
    set_0.set_lo(set_0)
    set_0.set_lo(set_0)


# Generated at 2022-06-26 07:44:58.548115
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    set_0 = set()
    str_0 = '*0H(fGdk'
    rough_parser_0 = RoughParser(str_0, set_0)
    str_1 = '*0H(fGdk'
    hyper_parser_0 = HyperParser(str_1, rough_parser_0)


# Generated at 2022-06-26 07:45:05.134215
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    str_0 = \
        'def foo(a, b,\n' + \
        '#blah\n' + \
        'c, d):'
    set_0 = set()
    rough_parser_0 = RoughParser(str_0, set_0)
    int_0 = rough_parser_0.compute_bracket_indent()

    assert int_0 == rough_parser_0.indent_width


# Generated at 2022-06-26 07:45:13.088160
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    str_0 = '*0H(fGdk'
    set_0 = set()
    rough_parser_0 = RoughParser(str_0, set_0)
    int_0 = rough_parser_0.get_base_indent_string()
    assert int_0 == 0


# Generated at 2022-06-26 07:45:15.081158
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    class_RoughParser = RoughParser("", {})
    assert class_RoughParser.get_base_indent_string() == ""
