

# Generated at 2022-06-26 07:38:10.387019
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    l = []
    l.append({})
    l.append({})
    text_0 = Tkinter.Text(l[0], l[1])
    hyper_parser_0 = HyperParser(text_0, "'")
    hyper_parser_0.get_expression()


# Generated at 2022-06-26 07:38:18.042393
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # Create a fake Text widget
    text_0 = Tk.Text()
    text_0.insert("1.0", "class Test:")
    text_0.insert("2.0", "def test(self):")
    text_0.insert("3.0", "Test.test(" )

    # Create a HyperParser at the end of the line
    hyper_parser_0 = HyperParser(text_0, "3.end")
    # Check that the method get_expression returns the expected value
    assert hyper_parser_0.get_expression() == "Test.test", "Error in get_expression"


# Generated at 2022-06-26 07:38:23.785731
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # Test with a index inside a string.
    text_0 = Text(None)
    text_0.insert("end", "\n\n    'test'\n    'test")
    hyper_parser_0 = HyperParser(text_0, "3.0")
    assert hyper_parser_0.is_in_string() == True

    # Test with a index outside a string.
    text_1 = Text(None)
    text_1.insert("end", "teest\n    test\n    'test'\n")
    hyper_parser_1 = HyperParser(text_1, "1.0")
    assert hyper_parser_1.is_in_string() == False


# Generated at 2022-06-26 07:38:28.629451
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    rough_parser_0 = RoughParser()
    str_0 = "test"
    int_0 = rough_parser_0.find_good_parse_start(str_0)
    if (int_0 != 0):
        raise RuntimeError


# Generated at 2022-06-26 07:38:34.803996
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_0 = 'int_0 = 1298\nparentheses\nnext_line'
    bool_0 = True
    int_0 = 1298
    rough_parser_0 = RoughParser(bool_0, int_0)
    rough_parser_0.str = str_0
    rough_parser_0.find_good_parse_start()


# Generated at 2022-06-26 07:38:40.411499
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    print('Test RoughParser.find_good_parse_start')
    # Get a list of indentation levels (in spaces)
    # int_array_0 = RoughParser.find_good_parse_start(int_0, int_1)
    print(' End of test RoughParser.find_good_parse_start')


# Generated at 2022-06-26 07:38:44.047035
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    bool_0 = True
    int_0 = 1
    rough_parser_0 = RoughParser(bool_0, int_0)
    str_0 = "while True: print(\"1\")"
    rough_parser_0.set_lo(str_0)


# Generated at 2022-06-26 07:38:47.413501
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rough_parser_0 = RoughParser(False, 4)
    str_0 = '<!-- Template: {{{1|}}} -->'
    rough_parser_0.str = str_0
    int_0 = rough_parser_0.compute_bracket_indent()
    assert int_0 == 4


# Generated at 2022-06-26 07:38:51.230136
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    test_case_0()

    test_case_1()

    test_case_2()

    test_case_3()

    test_case_4()

    test_case_5()

    test_case_6()

    test_case_7()
# Dummy function for RoughCodeParser

# Generated at 2022-06-26 07:38:55.760324
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    bool_0 = True
    int_0 = 1298
    rough_parser_0 = RoughParser(bool_0, int_0)
    hyper_parser_0 = HyperParser(rough_parser_0, "")
    hyper_parser_0.set_index("")


# Generated at 2022-06-26 07:40:23.604629
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    # test case 0
    bool_0 = True
    int_0 = 1298
    rough_parser_0 = RoughParser(bool_0, int_0)
    rough_parser_0.str = "hui\nhuihui\n"
    int_1 = rough_parser_0.get_num_lines_in_stmt()
    # assert int_1 == 2
    assert int_1 == 3

test_case_0()
test_RoughParser_get_num_lines_in_stmt()

# End class RoughParser.


# Generated at 2022-06-26 07:40:25.002807
# Unit test for constructor of class HyperParser
def test_HyperParser():
    hyper_parser_0 = HyperParser("foo", "bar")


# Generated at 2022-06-26 07:40:30.085890
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    print('Test #1, is_in_code')

    # Create a Tk window
    tkinter.Tk()
    # Create a text widget
    text_0 = tkinter.Text()
    text_0.insert(tkinter.END, 'spam eggs\n')
    # Create a HyperParser instance
    hyper_parser_0 = HyperParser(text_0, '1.14')
    # Get a boolean indicating whether the index is inside code
    bool_0 = hyper_parser_0.is_in_code()
    print(bool_0)


# Generated at 2022-06-26 07:40:32.195188
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    tested_object = StringTranslatePseudoMapping({}, 0)
    tested_object.__iter__()


# Generated at 2022-06-26 07:40:38.273393
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    global file_name
    file = open(file_name, "r")
    file_contents = file.read()
    file.close()
    rough_parser_0 = RoughParser(True, 4)
    rough_parser_0.set_str(file_contents)
    rough_parser_0._study1()
    rough_parser_0._study2()
    int_0 = rough_parser_0.get_last_open_bracket_pos()
    return int_0


# Generated at 2022-06-26 07:40:45.332806
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text_0 = Text()
    text_0.insert(0.0, "def foo(self, a=2, b=3):")
    text_0.insert(1.1, "    if a > 5:")
    text_0.insert(2.2, "        return")
    hyper_parser_0 = HyperParser(text_0, 1.1)
    bool_0 = hyper_parser_0.is_in_code()
    assert bool_0


# Generated at 2022-06-26 07:40:50.338096
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    test_string = 'if (not y):\n    x = 2'
    tkinter_text = tk.Text()
    tkinter_text.insert(1.0,test_string)
    hyper_parser = HyperParser(tkinter_text, 12.0)
    output_tuple = hyper_parser.get_surrounding_brackets()
    assert output_tuple == (10.0, 15.0)


# Generated at 2022-06-26 07:40:59.122276
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    test_string = "if True: '''multiline comment\n" \
                  "    this is second line\n" \
                  "    this is third line'''\n" \
                  "    pass\n" \
                  "'\\'\n" \
                  "    a = 7\n"
    rough_parser_0 = RoughParser(test_string)
    assert rough_parser_0.compute_backslash_indent() == 9


# Generated at 2022-06-26 07:41:07.462014
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    """Method test_RoughParser_compute_backslash_indent of class RoughParser"""
    my_parser = RoughParser(True, 4)
    slines = []
    # pylint: disable=bad-continuation

# Generated at 2022-06-26 07:41:11.431580
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    bool_0 = False
    int_0 = -12
    rough_parser_0 = RoughParser(bool_0, int_0)
    str_0 = ""
    assert rough_parser_0.get_str() == ""
    rough_parser_0.set_str(str_0)
    assert rough_parser_0.get_str() == ""


# Generated at 2022-06-26 07:41:58.233293
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    text = """if condition_0:
        print "something"
        if condition_1:
            print "something else"
    elif condition_2:
        print "something elif"
    else:
        print "something else 2"
    """
    indent_width = 4
    tabwidth = 8
    # int(False) == 0
    rough_parser_0 = RoughParser(False, indent_width, tabwidth)
    rough_parser_0.set_str(text)
    rough_parser_0.get_continuation_type()
    assert rough_parser_0.lastopenbracketpos == text.rfind("if condition_1:")
    rough_parser_0.compute_bracket_indent()


# Generated at 2022-06-26 07:42:04.223940
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_0 = ""
    get_load_average = RoughParser(str_0)
    my_str = "        \n  \n""  ""  '\n'\t!"
    result_0 = get_load_average.find_good_parse_start(my_str)
    assert result_0 == 8


# Generated at 2022-06-26 07:42:16.298207
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_0 = "jjj\njjj\n    jjj\n    jjj"
    str_1 = "    jjj\njjj\njjj\n"
    str_2 = "   if a:\n      pass\n"
    str_3 = "if a:\n      pass\n"
    i_0 = RoughParser.find_good_parse_start(str_0, 4)
    i_1 = RoughParser.find_good_parse_start(str_1, 4)
    i_2 = RoughParser.find_good_parse_start(str_2, 4)
    i_3 = RoughParser.find_good_parse_start(str_3, 4)
    print(i_0)
    print(i_1)
    print(i_2)

# Generated at 2022-06-26 07:42:25.434739
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # The tests don't make much sense, but they show the way to use
    # HyperParser.get_expression().
    string_0 = 120
    string_1 = "<!-- ParenMatch.py\n"
    string_1 = string_1 + "Python extension to idle: match parentheses '()', brackets '[]', braces '{}'\n"
    string_1 = string_1 + "Brackets: '<>' '()' '[]' '{}'\n"
    string_1 = string_1 + "Python class which provides additional information on the structure of code.\n"
    string_1 = string_1 + "Is the index in a string?\n"
    string_1 = string_1 + "Is the index in normal code?\n"

# Generated at 2022-06-26 07:42:33.049645
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    bool_0 = False
    int_0 = 1337
    rough_parser_0 = RoughParser(bool_0, int_0)
    str_0 = "\n\n"
    rough_parser_0.str = str_0
    str_0 = "while"
    rough_parser_0.lastch = str_0
    str_0 = ":"
    str_1 = "while"
    assert str_0 == str_1


# Generated at 2022-06-26 07:42:34.940398
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    hyperparser_0 = HyperParser(text_0, index_0)
    bool_0 = hyperparser_0.is_in_string()
    return bool_0


# Generated at 2022-06-26 07:42:41.911001
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_0 = "fig, ax = plt.subplots()"

    rough_parser_0 = RoughParser(True, 1298)
    rough_parser_0.set_str(str_0)
    pos_0 = 0
    assert rough_parser_0.find_good_parse_start(0, 0) == 3
    assert rough_parser_0.find_good_parse_start(0, 1) == 3


# Generated at 2022-06-26 07:42:48.891292
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    str_0 = "if True:\n    pass\n"
    rough_parser_0 = RoughParser(str_0)
    if not rough_parser_0.is_block_opener():
        raise RuntimeError("Test failed")
    
    str_0 = "    elif True:\n    pass\n"
    rough_parser_0 = RoughParser(str_0)
    if rough_parser_0.is_block_opener():
        raise RuntimeError("Test failed")
    
    str_0 = "for i in range(n):"
    rough_parser_0 = RoughParser(str_0)
    if rough_parser_0.is_block_opener():
        raise RuntimeError("Test failed")
    
    str_0 = "a = lambda x:"

# Generated at 2022-06-26 07:42:53.483498
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    text_0 = "class Foo: pass"
    index_0 = "4.4"
    # The following line will send a traceback to stderr. Need to
    # find a better way to deal with this.
    # hyper_parser_0 = HyperParser(text_0, index_0)
    # assert hyper_parser_0.__class__ == HyperParser


# Generated at 2022-06-26 07:43:05.436799
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rough1 = RoughParser(False, 0)
    rough2 = RoughParser(True, 0)

    assert rough1.get_num_lines_in_stmt() == 1
    assert rough2.get_num_lines_in_stmt() == 1

    rough1.str = "some string with \\ \n a continuation on another line"
    rough2.str = "some string with \\ \n a continuation on another line"
    assert rough1.get_num_lines_in_stmt() == 2
    assert rough2.get_num_lines_in_stmt() == 2


# Generated at 2022-06-26 07:44:02.471983
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-locals
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    # pylint: disable=unused-argument
    # pylint: disable=no-self-use
    test_cases = []
    # test_cases.append(None)

    print("Unit test for method find_good_parse_start of class RoughParser")
    for arg_case_0 in test_cases:
        if arg_case_0 is None:
            test_case_0()
            continue
        try:
            pass
        except Exception:
            pass
    print("End of unit test")
#

# Generated at 2022-06-26 07:44:04.258151
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rough_parser = RoughParser()
    str_0 = '4.4'
    rough_parser.set_lo(str_0)


# Generated at 2022-06-26 07:44:13.344592
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    print('test_RoughParser_compute_backslash_indent 1')
    str_0 = 'class Foo: pass'
    str_1 = '4.4'
    rp = RoughParser(str_0, str_1)
    assert 0 == rp.compute_backslash_indent()
    print('test_RoughParser_compute_backslash_indent 2')
    str_0 = 'class Foo: pass'
    str_1 = '4.4'
    rp = RoughParser(str_0, str_1)
    assert 0 == rp.compute_backslash_indent()
    print('test_RoughParser_compute_backslash_indent 3')
    str_0 = 'class Foo: pass'
    str_1 = '4.4'

# Generated at 2022-06-26 07:44:18.087786
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    tk = Tk()
    t = ScrolledText.ScrolledText(tk)
    t.insert(END,str_0)
    t.insert(END,str_1)
    t.pack()
    hp = HyperParser(t,t.index(END))
    hp.set_index(t.index('1.1'))
    t.mainloop()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 07:44:27.426823
# Unit test for constructor of class HyperParser
def test_HyperParser():
    str_0 = "class Foo: pass"
    str_1 = "foo.bar"

    # TODO: use temp file, not 'editing'
    hp_0 = HyperParser(str_0, len(str_0) - 1)
    assert hp_0.is_in_code()
    assert not hp_0.is_in_string()

    hp_0 = HyperParser(str_0, str_0.find('Foo') + 1)
    assert hp_0.is_in_code()
    assert not hp_0.is_in_string()

    hp_1 = HyperParser(str_1, len(str_1) - 1)
    assert hp_1.is_in_code()
    assert not hp_1.is_in_string()


# Generated at 2022-06-26 07:44:35.500525
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    #test_case_0()
    #inspect.currentframe().f_back.f_lineno
    tk = Tk()
    text = Text(tk)
    text.pack()
    text.insert('1.0', str_0)
    text.mark_set('insert', '1.0')
    hp = HyperParser(text, '1.0')
    actual = hp.get_surrounding_brackets()
    assert actual[0] == '1.0', 'actual = %s' % repr(actual)
    assert actual[1] == '1.14', 'actual = %s' % repr(actual)
    text.insert('1.0', str_1)
    hp = HyperParser(text, '1.0')
    actual = hp.get_surrounding_brackets()

# Generated at 2022-06-26 07:44:43.118814
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str_0 = "'''\n"
    str_1 = '    a = 1\n'
    str_2 = '    class Foo:\n'
    str_3 = '        pass\n'
    str_4 = '\n'
    str_5 = "'''\n"
    str_6 = '    # some comment\n'
    str_7 = '    # ...\n'
    str_8 = '    a = 1\n'
    str_9 = '    class Bar:\n'
    str_10 = '        pass\n'
    str_11 = '\n'
    str_12 = "'''\n"
    str_13 = '    # some comment\n'
    str_14 = '    # ...\n'

# Generated at 2022-06-26 07:44:49.279277
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    h = HyperParser(str_0)
    assert(is_in_code(h)==True)
    
    
    

# Generated at 2022-06-26 07:44:58.651617
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # Create a text box to test HyperParser
    text = tkinter.Text()

    # Insert string to test for
    text.insert('1.0', 'class Foo:\n    pass\n4.4')

    # Create HyperParser instance with index at end of string
    hp = HyperParser(text, '2.0')

    # Check if HyperParser completed successfully

    # Check bracketing
    assert hp.bracketing == ((0, 0), (3, 1), (21, 2))
    assert hp.isopener == (False, True, False)

    # Check index
    assert hp.rawtext[hp.indexinrawtext] == '4'
    assert hp.rawtext[hp.bracketing[hp.indexbracket][0]] == ' '
    assert hp.stopatindex == '2.0'

    #

# Generated at 2022-06-26 07:45:06.834377
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    str_0 = 'if foo == 4:\n    if bar == 5:\n        pass\n    else:\n        pass'
    rp_0 = RoughParser(str_0)
    assert rp_0.compute_backslash_indent() == 5
    str_1 = '4.4'
    rp_1 = RoughParser(str_1)
    assert rp_1.compute_backslash_indent() == 0
    str_2 = 'class Foo: pass'
    rp_2 = RoughParser(str_2)
    assert rp_2.compute_backslash_indent() == 7

# Generated at 2022-06-26 07:45:53.514037
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    test_case_0()

# Unit testing code

# Generated at 2022-06-26 07:46:03.714399
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    str_2 = "'#\n"
    str_3 = "{'#\n"
    str_4 = "(#\n"
    str_5 = "[#\n"
    str_6 = "def f(#\n"
    str_7 = "def f(#)\n"
    str_8 = "def f(#):\n"
    str_9 = "def f(#) ->\n"
    str_10 = "def f(#) -> 1:\n"

    assert RoughParser(str_2).is_block_closer() == False
    assert RoughParser(str_3).is_block_closer() == False
    assert RoughParser(str_4).is_block_closer() == False
    assert RoughParser(str_5).is_block_closer() == False

# Generated at 2022-06-26 07:46:09.255814
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    h = HyperParser(str_0, 1.1)
    h.set_index(5)


# Generated at 2022-06-26 07:46:14.005029
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():

    # TEST CASE: is_block_closer returns False when the last interesting
    # statement is a block opener
    print("TEST CASE: is_block_closer returns False when the last interesting statement is a block opener")

    rp = RoughParser()
    actual_bool = rp.is_block_closer()
    assert actual_bool == False

    print("test_RoughParser_is_block_closer PASSED\n")


# Generated at 2022-06-26 07:46:20.231221
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():

    text = Text(None)

# Generated at 2022-06-26 07:46:21.981529
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    hp = HyperParser(str_0, '1.1')
    print(hp.is_in_string())

# Generated at 2022-06-26 07:46:22.974852
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    test_case_0()


# Generated at 2022-06-26 07:46:26.654995
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rp = RoughParser(str_0)
    print(rp.get_base_indent_string())
    print(rp.compute_backslash_indent())
if __name__ == '__main__':
    test_case_0()
    test_RoughParser_compute_backslash_indent()

# Generated at 2022-06-26 07:46:30.787598
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    str_0 = '1.1'
    hp = HyperParser(str_0, 1)
    assert hp.is_in_code() == True , "True was expected, but got False"


# Generated at 2022-06-26 07:46:36.551729
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    print("Testing method is_in_code...", end="")
    obj = HyperParser(str_0, str_1)
    result = obj.is_in_code()
    assert result == expected_0, "Expected different result: " + str(result)

    print("Done.")
