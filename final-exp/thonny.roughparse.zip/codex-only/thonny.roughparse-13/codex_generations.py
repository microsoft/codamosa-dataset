

# Generated at 2022-06-24 08:05:15.599512
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    assert len(StringTranslatePseudoMapping({'a': 1}, 2)) == 1
    assert len(StringTranslatePseudoMapping({}, 2)) == 0



# Generated at 2022-06-24 08:05:26.974937
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # This is a simple test of the most important functionality of
    # HyperParser. It's purpose is to make sure that even if that
    # functionality is changed, the unit test will fail and thus the
    # authors will be aware of the need to update the code above.

    class DummyText:
        """A simple Text-like object.

        It is used by the HyperParser to call methods of Text.
        """

        def __init__(self, data, indent_width, tabwidth):
            """Initialize the DummyText object.

            data is a list of lines. The new line will be added to the end
            of data.
            """
            self.data = data
            self.indent_width = indent_width
            self.tabwidth = tabwidth


# Generated at 2022-06-24 08:05:29.842808
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    """
    >>> test_RoughParser_get_base_indent_string()
    '    '
    """
    parser = RoughParser("    x = 'foo'")
    indent = parser.get_base_indent_string()
    print(indent)


# Generated at 2022-06-24 08:05:36.961585
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser("if True:\n    x = 1")
    assert rp.is_block_opener()
    #
    rp = RoughParser("if (\n    x)")
    assert not rp.is_block_opener()
    rp = RoughParser("if (\n    x)\n    a = 1")
    assert rp.is_block_opener()
test_RoughParser_is_block_opener()

# Unit tests for method is_block_closer of class RoughParser

# Generated at 2022-06-24 08:05:44.351288
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    """Test __getitem__ method of class StringTranslatePseudoMapping
    """
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    assert mapping[ord(" ")] == ord(" ")
    assert mapping[ord("\t")] == ord("\t")
    assert mapping[ord("\n")] == ord("\n")
    assert mapping[ord("\r")] == ord("\r")
    assert mapping[ord("a")] == ord("x")
    assert mapping[ord("b")] == ord("x")



# Generated at 2022-06-24 08:05:48.642706
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    assert len(StringTranslatePseudoMapping({}, 2)) == 0
    assert len(StringTranslatePseudoMapping({1: 2}, 1)) == 1
    try:
        len(StringTranslatePseudoMapping([2, 3], 5))
        assert False, ("len() should have raised TypeError, but didn't")
    except TypeError:
        pass

# Generated at 2022-06-24 08:06:00.018362
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    tests = (
        ("",
         # ->
         ""),
        ("   x = 3",
         # ->
         "   "),
        ("   x = 3\n   y = 4",
         # ->
         "   "),
        ("x = [\n   1,\n   2,\n   3]",
         # ->
         ""),
        ("   x = [\n      1,\n      2,\n      3]",
         # ->
         "   "),
        ("\n   x = [\n      1,\n      2,\n      3]",
         # ->
         "   "),
    )
    for src, expected in tests:
        parser = RoughParser(src)
        res = src != "" and parser.get_base_indent_string() or ""


# Generated at 2022-06-24 08:06:06.550334
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-24 08:06:07.913628
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    pass  # TODO: implement this test!



# Generated at 2022-06-24 08:06:15.273919
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    class TestCase(unittest.TestCase):
        def _run(self, rp, expected):
            self.assertEqual(rp.get_last_open_bracket_pos(), expected)
    
    test = TestCase()
    content = """
    aaaaa = aaaaa
    bbb = {
        ccc = (
            ddd = ddd
        )
    }
    """
    rp = RoughParser(content)
    test._run(rp, 38)
    test._run(RoughParser(content.replace("\n", "")),  38)
    


# Generated at 2022-06-24 08:06:26.980956
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    def do_test_HyperParser_is_in_string(text, expected, index):
        hp = HyperParser(text, index)
        got = hp.is_in_string()
        if got != expected:
            assert False, "Failure of test_HyperParser_is_in_string:\nexpected:\n%s\ngot:\n%s\nfor:\n%s\nat index %s, bracketing: %s" % (
                expected,
                got,
                text.get(1.0, "end-1c"),
                index,
                hp.bracketing,
            )

    do_test_HyperParser_is_in_string(Text('''\
In [1]:

  x=0
  y=0
  z=0

In [2]:

'''), False, "1.0")

# Generated at 2022-06-24 08:06:35.770158
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from idlelib import parenmatch


# Generated at 2022-06-24 08:06:47.228153
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = scite_extensions.ExtensionHelper("").text
    text.remove(1.0, "end")
    text.insert("end", r'"a"b\'c')
    for i in range(len(text.get("1.0", "end"))):
        text.mark_set("test_insert", "1.0 + %dc" % i)
        assert not HyperParser(text, "test_insert").is_in_string(), "%d shouldn't be in a string" % i
    text.insert("1.1", "d")
    for i in range(len(text.get("1.0", "end"))):
        text.mark_set("test_insert", "1.0 + %dc" % i)

# Generated at 2022-06-24 08:06:50.720090
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rp = RoughParser(b"for i in stuff:\n    pass\n")
    if rp.get_num_lines_in_stmt() != 2:
        raise BadPyCF_FeatureTest


# Generated at 2022-06-24 08:06:56.474688
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    non_defaults = {ord('a'): ord('b'),
                    ord('c'): ord('d')}
    default_value = ord('e')
    mapping = StringTranslatePseudoMapping(non_defaults, default_value)
    actual = set(iter(mapping))
    expected = set(non_defaults)
    assert actual == expected


# Generated at 2022-06-24 08:07:06.926643
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    import itertools
    import textwrap

# Generated at 2022-06-24 08:07:17.937510
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser("")
    assert not rp.is_block_opener()
    rp = RoughParser("x")
    assert not rp.is_block_opener()
    rp = RoughParser("x()")
    assert not rp.is_block_opener()
    rp = RoughParser("def x")
    assert rp.is_block_opener()
    rp = RoughParser("def x():")
    assert not rp.is_block_opener()
    rp = RoughParser("#\n")
    assert not rp.is_block_opener()
    rp = RoughParser("a = f(")
    assert not rp.is_block_opener()
    rp = RoughParser("class C:")
    assert rp.is_block_opener()

# Generated at 2022-06-24 08:07:25.145972
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin

    # Returns the indentation computed for a single line of text,
    # given a particular continuation state.

    def indent(text, continuation=C_NONE):
        class Dummy:
            pass

        # pylint: disable=redefined-builtin
        d = Dummy()
        d.str = text
        d.indent_width = 8
        d.tabwidth = 8
        d.continuation = continuation
        p = RoughParser(d)
        return p.compute_backslash_indent()

    assert indent("a", C_BACKSLASH) == 1
    assert indent("\ta", C_BACKSLASH) == 2
    assert indent("\ta", C_STRING_FIRST_LINE) == 9
    # Check continuation from the first line of

# Generated at 2022-06-24 08:07:27.488068
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    m = StringTranslatePseudoMapping({"a": "b"}, "c")
    assert m.get("a") == "b"
    assert m.get("b") == "c"



# Generated at 2022-06-24 08:07:37.134627
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import unittest


# Generated at 2022-06-24 08:07:42.575947
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    """Unit test for method compute_bracket_indent of class RoughParser."""

    def assert_equal(a, b):
        if a != b:
            print("assertion failed: %r != %r" % (a, b))

    def check(source, expected):
        expected = expected.replace("\t", " " * tabwidth)
        got = RoughParser(source, tabwidth).compute_bracket_indent()
        assert_equal(got, len(expected))

    # Basic
    check(
        "foo = [",
        "                              "
        "                              "
        "                              "
        "                              "
        "                    "
        "        ",
    )
    check("foo = [\n", "    ")
    check("foo = [\\\n", "        ")
   

# Generated at 2022-06-24 08:07:50.458304
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    test_cases = [
        ("", ""),
        ("    ", "    "),
        ("if (1):\n        pass\n", "    "),
        ("if (1):\n        pass", ""),
        ("if (1):\n    pass\n", ""),
        ("if (1):\n    pass", ""),
    ]
    for code, expected in test_cases:
        parser = RoughParser(code)
        actual = parser.get_base_indent_string()
        assert actual == expected

# Generated at 2022-06-24 08:07:56.548065
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # Test basic algorithm
    rp = RoughParser()
    rp.set_lo(0)
    # Test raising an exception
    rp.truncate(1)
    expected = 'set_lo called with invalid line number'
    with raises(ValueError) as got:
        rp.set_lo(2)
    assert expected in str(got.value)


# Generated at 2022-06-24 08:08:01.231098
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({ord('a'): ord('b')}, ord('x'))
    result = mapping.get(ord('a'))
    assert result == ord('b')

    result = mapping.get(ord('b'))
    assert result == ord('x')


# Generated at 2022-06-24 08:08:11.354456
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    def t(s, c, tabwidth=8):
        p = RoughParser(s, tabwidth=tabwidth)
        assert p.get_continuation_type() == c

    t("if 1: pass", C_NONE)
    t("if 1:\\\npass", C_BACKSLASH)
    t("if 1:\\\n    pass", C_BACKSLASH)
    t("if 1:\n    pass", C_NONE)
    t("if 1:\npass", C_NONE)
    t("if 1:\n    if 2:\npass", C_NONE)
    t("if (1\n    and 2):\n    pass", C_BRACKET)
    t("if (1\\\n    and 2):\n    pass", C_BACKSLASH)

# Generated at 2022-06-24 08:08:19.194858
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == len(preserve_dict)

# Generated at 2022-06-24 08:08:21.455283
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    import doctest

    doctest.testmod(RoughParser, verbose=False)
#@+node:ekr.20031218072017.3050: ** class TokenScannerClass
# This class is needed to handle nested tokens.


# Generated at 2022-06-24 08:08:27.228913
# Unit test for constructor of class HyperParser
def test_HyperParser():
    l = ["abcdefg", "", "abc", "abcdefg"]
    # This list should be big enough, since the search is linear.

    i = "2.6"
    hp = HyperParser(l, i)

    assert hp.text is l
    assert hp.stopatindex == "2.end"
    assert hp.indexinrawtext == 0
    assert hp.rawtext == "abcdefg abc abcdefg"
    assert hp.indexbracket == 0
    assert hp.bracketing == [(0, 0), (7, 0), (8, 1), (11, 1), (12, 0), (19, 0)]
    assert hp.isopener == [True, False, True, False, True, False]

    i = "3.0"
    hp.set_index(i)

# Generated at 2022-06-24 08:08:33.380493
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'


# Generated at 2022-06-24 08:08:41.589491
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    import warnings

    warnings.filterwarnings(
        "ignore",
        "The anchor character in regexp pattern '$' is stricter than the one",
        SyntaxWarning,
        ".*",
    )
    TABWIDTH = 8

    def assert_backslash_indent(input_, expected_indent):
        rp = RoughParser(input_, TABWIDTH)
        assert rp.get_continuation_type() == C_BACKSLASH
        indent = rp.compute_backslash_indent()
        assert indent == expected_indent, "%r != %r" % (indent, expected_indent)


# Generated at 2022-06-24 08:08:51.202948
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    # Issue3617: Test for infinite loop in __iter__
    # (issue uncovered by PyPy's translation toolchain).
    from idlelib import hyperparser

    mapping = hyperparser.StringTranslatePseudoMapping({}, 42)
    n = 0
    for _ in mapping:
        n += 1
        if n > 100:
            raise AssertionError("Mapping __iter__ does not terminate")


# Search forward for a stmt boundary
#
# - `indent` is the indentation level at which to start looking,
#   measured in spaces; the function assumes that it is called at the
#   start of a logical line
# - `line` is the logical line on which to start looking; the first
#   stmt boundary found at a higher level will be used; this means
#   that when parsing backwards, the first boundary found will be

# Generated at 2022-06-24 08:09:01.673828
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    def _test(s):
        rp = RoughParser(dedent(s), indent_width=4)
        return rp.get_num_lines_in_stmt()

    assert _test('''
    if 1:
    ''') == 2

    assert _test('''
    if 1:
    2
    ''') == 2

    assert _test('''
    if 1:
    2
    3
    ''') == 3

    assert _test('''
    if 1:


    2
    3
    ''') == 3

    assert _test('''
    if 1: # comment
    ''') == 2

    assert _test('''
    if 1: # comment
    2 # comment
    ''') == 2


# Generated at 2022-06-24 08:09:08.542265
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = string.whitespace
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    result = text.translate(mapping)
    assert result == "x x x\tx\nx", result



# Generated at 2022-06-24 08:09:20.621545
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    text = "print(a+b).c.a1.b2(a.a)(self.foo())"
    B = "1.0"
    E = "end - 1c"
    for pos in range(0, len(text) + 1):
        h = HyperParser(text, "%d.%d" % (len(text) + 1, pos))
        print(text, pos, text[:pos], h.get_expression())
        assert text[:pos] == h.get_expression() + text[pos : pos + 1]
    text = "print(a+b).c.a1.b2(a.a)(self.foo())"
    h = HyperParser(text, "2.0")
    assert h.get_expression() == ""
    h = HyperParser(text, "3.0")


# Generated at 2022-06-24 08:09:28.648911
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    # pylint: disable=star-args, unused-argument
    # pylint: disable=missing-docstring
    # The following test is not a unit test, it's just a convenient way to
    # call RoughParser.get_num_lines_in_stmt.
    def f(s, n):
        if RoughParser(s).get_num_lines_in_stmt() != n:
            raise AssertionError('input: "%s"\nresult: %s\nexpected: %s' % (s, RoughParser(s).get_num_lines_in_stmt(), n))

    assert f("    foo(x,\\\n        y,\\\n        z)\n", 3) == None  # 3 lines
    assert f("    foo(x,\\\n        y,\\", 2) == None  #

# Generated at 2022-06-24 08:09:36.511235
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    pseudomapping = StringTranslatePseudoMapping(
        {ord('a'): ord('A'), ord('b'): ord('B')},
        ord('?')
    )
    assert pseudomapping.get(ord('a')) == ord('A')
    assert pseudomapping.get(ord('b')) == ord('B')
    assert pseudomapping.get(ord('c')) == ord('?')
    assert pseudomapping.get(ord('d')) == ord('?')


# For making copies


# Generated at 2022-06-24 08:09:40.858334
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({32: 1}, 10)
    assert mapping.get(32) == 1
    assert mapping.get(33) == 10



# Generated at 2022-06-24 08:09:48.224446
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    parser = RoughParser("a = 3")
    assert parser.find_good_parse_start() == 0

    parser = RoughParser("a = 3\nb = 4")
    assert parser.find_good_parse_start() == 0

    parser = RoughParser("print(a)")
    assert parser.find_good_parse_start() == 0

    parser = RoughParser("print(a)\nif True:")
    assert parser.find_good_parse_start() == 0

    parser = RoughParser("if True:\n    a = 4\n")
    assert parser.find_good_parse_start() == 4

    parser = RoughParser("if True:\n    a = 4\n    b = 5\n")
    assert parser.find_good_parse_start() == 4


# Generated at 2022-06-24 08:09:54.980299
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    translation_dict = {ord('a'): ord('x'), ord('d'): ord('z')}
    mapping = StringTranslatePseudoMapping(translation_dict, ord('x'))
    assert mapping.get(ord('a')) == ord('x')
    assert mapping.get(ord('b')) == ord('x')
    assert mapping.get(ord('z')) == ord('x')


# An instance of this class is used to do the work.


# Generated at 2022-06-24 08:10:00.749819
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    # Replacement dict that replaces only 'b' with 'B'. All other chars
    # will be replaced with 'x'.
    non_defaults = {ord('b'): ord('B')}
    mapping = StringTranslatePseudoMapping(non_defaults, ord('x'))
    text = 'a + b\tc\nd'
    assert text.translate(mapping) == 'x x x\tx\nx'


# Utility routines

# Generated at 2022-06-24 08:10:06.168863
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin

    def compare(bracket, indent_width, tabwidth, expected):
        parser = RoughParser(bracket, indent_width, tabwidth)
        actual = parser.compute_bracket_indent()
        assert actual == expected, (
            f"{bracket!r} with [indent_width={indent_width}, "
            f"tabwidth={tabwidth}], expected {expected}, "
            f"got {actual}"
        )

    # The most important test case is one in which the bracket line
    # is at the outer indentation level, and the next line is the
    # first non-blank in the stmt; in this case, the indentation of
    # the next line should reproduce the indentation of the bracket
    # line plus another level.

# Generated at 2022-06-24 08:10:16.929787
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin, no-member
    # pylint: disable=undefined-variable, invalid-name
    # pylint: disable=too-many-arguments

    def test(str_, tabwidth, expected):
        rp = RoughParser(str_, tabwidth)
        actual = rp.compute_backslash_indent()
        if actual != expected:
            print("expected", expected, "got", actual, "for", repr(str_))
            return 1
        return 0

    failcount = 0
    failcount = failcount + test("", 8, 0)
    failcount = failcount + test("\n", 8, 0)
    failcount = failcount + test("a", 8, 0)

# Generated at 2022-06-24 08:10:24.465528
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    class TestParser:
        "A fake editwin class to provide a text attribute."

        def __init__(self, text):
            self.text = text


# Generated at 2022-06-24 08:10:35.925817
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    rp = RoughParser()
    rp.set_str('x=1\n')
    assert rp.get_continuation_type()==C_NONE
    rp.set_str('x="a\n')
    assert rp.get_continuation_type()==C_STRING_FIRST_LINE
    rp.set_str('x="a\\\n')
    assert rp.get_continuation_type()==C_BACKSLASH
    rp.set_str('[\n')
    assert rp.get_continuation_type()==C_BRACKET
    rp.set_str('#comment\n')
    assert rp.get_continuation_type()==C_NONE
    rp.set_str('a \\\n')
    assert rp.get_

# Generated at 2022-06-24 08:10:45.233629
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    """Test 'StringTranslatePseudoMapping.__iter__'"""

    # A single argument raises TypeError
    m = StringTranslatePseudoMapping({'k': 3}, 2)
    assert iter(m) is not None
    try:
        iter('x')
    except TypeError:
        pass
    else:  # pragma: no cover - impossible
        raise AssertionError

    # Check that iteration stops after all keys have been yielded
    m = StringTranslatePseudoMapping({'k': 3}, 2)
    d = {'k': 3}
    for v in d:
        assert v in d
    for v in m:
        assert v in d  # pragma: no cover - impossible



# Generated at 2022-06-24 08:10:56.583020
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = Text(None, "1.0", "2.0")


# Generated at 2022-06-24 08:11:10.629102
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def join(fmt, *args):
        return "".join(fmt % (arg,) for arg in args)


# Generated at 2022-06-24 08:11:22.812398
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    class Case:
        def __init__(self, text, expect):
            self.text = text
            self.expect = expect


# Generated at 2022-06-24 08:11:33.379728
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rough_parser = RoughParser(test_lines[0], indent_width=4, tabwidth=8)
    assert rough_parser.is_block_opener() == True
    rough_parser = RoughParser(test_lines[1], indent_width=4, tabwidth=8)
    assert rough_parser.is_block_opener() == False
    rough_parser = RoughParser(test_lines[2], indent_width=4, tabwidth=8)
    assert rough_parser.is_block_opener() == False
    rough_parser = RoughParser(test_lines[3], indent_width=4, tabwidth=8)
    assert rough_parser.is_block_opener() == False
    rough_parser = RoughParser(test_lines[4], indent_width=4, tabwidth=8)
    assert rough_parser

# Generated at 2022-06-24 08:11:44.585706
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    rp = RoughParser('''
x = 1
''')
    assert rp.get_continuation_type() == C_NONE
    rp = RoughParser('''
x = (1
     + 2
     + 3)
''')
    assert rp.get_continuation_type() == C_BRACKET
    rp = RoughParser('''
x = "one two three
    four five six"
''')
    assert rp.get_continuation_type() == C_STRING_NEXT_LINES
    rp = RoughParser('''
x = ("one two three
     four five six")
''')
    assert rp.get_continuation_type() == C_STRING_NEXT_LINES

# Generated at 2022-06-24 08:11:55.834442
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def do_test(text, index, expected):
        s = HyperParser(text, index)
        got = s.get_expression()
        if got != expected:
            raise RuntimeError("HyperParser.get_expression failed for text=%r, index=%r" % (text, index))

    def do_multi_test(text, index_expected_pairs):
        for index, expected in index_expected_pairs:
            do_test(text, index, expected)


# Generated at 2022-06-24 08:12:05.222870
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-24 08:12:15.854667
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    assert not HyperParser("", "1.0").is_in_code()
    assert HyperParser("{}", "1.0").is_in_code()
    assert HyperParser(" #", "1.0").is_in_code()
    assert HyperParser("#\n", "1.1").is_in_code()
    assert not HyperParser("'", "1.0").is_in_code()
    assert not HyperParser("'''", "1.0").is_in_code()
    assert not HyperParser("'abc'", "1.0").is_in_code()
    assert not HyperParser("'''abc'''", "1.0").is_in_code()
    assert not HyperParser("'abc\n", "1.0").is_in_code()

# Generated at 2022-06-24 08:12:23.594931
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-24 08:12:27.904899
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    str_ = """\
# a comment
a = 1\\
+ 2\\
+\\
3
print (a)
b = 4
\
"""
    parser = RoughParser(str_)
    assert parser.get_num_lines_in_stmt() == 3
    assert parser.get_last_open_bracket_pos() == None


# Generated at 2022-06-24 08:12:38.480592
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=redefined-builtin
    # pylint: disable=too-many-locals
    import unittest
    from test.support import run_unittest
    from test.test_tokenize import make_tests

    class TestRoughParser(unittest.TestCase):
        def test(self):
            tests = make_tests(self)
            for test in tests:
                rp = RoughParser(test)
                self.assertEqual(rp.get_num_lines(), len(test.splitlines()))
                self.assertEqual(rp.get_continuation_type(), test.continuation)
                if rp.get_continuation_type() == C_NONE:
                    continue

# Generated at 2022-06-24 08:12:39.433142
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    assert True

# Generated at 2022-06-24 08:12:51.592362
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    index_and_block = [
        (1, 'def'),
        (2, 'for'),
        (3, 'while'),
        (4, 'if'),
        (5, 'elif'),
        (6, 'else'),
        (7, 'with'),
        (8, 'try'),
        (9, 'except'),
        (10, 'finally'),
        (11, 'class'),
        (12, '@'),
        (13, ':')
    ]
    for tup in index_and_block:
        keyword_indx = tup[0]
        keyword_str = tup[1]
        obj = RoughParser(keyword_str)
        if keyword_indx in {1, 11}:
            assert obj.is_block_opener() == True
        else:
            assert obj

# Generated at 2022-06-24 08:12:58.103629
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    _RoughParser = RoughParser
    obj = _RoughParser(['if 1:', '   pass', 'elif cond:', '   pass', 'else:'])
    assert not obj.is_block_closer(), "if 1:\\n   pass\\n\\nelif cond:\\n   pass\\n\\nelse: # is_block_closer()"

# Generated at 2022-06-24 08:13:03.137425
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    mapping = StringTranslatePseudoMapping({ord("a"): 1, ord("b"): 2}, 0)
    assert mapping[ord("a")] == 1
    assert mapping[ord("b")] == 2
    assert mapping[ord("c")] == 0


# Generated at 2022-06-24 08:13:14.687319
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    from astroid.modutils import modpath_from_file
    from astroid.manager import AstroidManager
    from pylint.utils.persistent import load_from_cache

    manager = AstroidManager()
    path = modpath_from_file(
        load_from_cache(manager, "/Users/mac/Documents/workspace/context_complete_git/Django-2.2.4/django/db/models/sql/datastructures.py")
    )
    print(path)
    if path:
        manager.ast_from_module_name(path.module)

if __name__ == "__main__":
    test_RoughParser_get_num_lines_in_stmt()

# Generated at 2022-06-24 08:13:21.358940
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-24 08:13:25.050690
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    # pylint: disable=unused-variable
    import doctest
    from pyflakes.checker import RoughParser
    globs = globals().copy()
    globs.update(locals())
    doctest.testmod(RoughParser, globs)



# Generated at 2022-06-24 08:13:33.574711
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin

    size = RoughParser.compute_backslash_indent
    assert size("") == 1
    assert size("\\") == 1
    assert size("a = 1 \\") == 4
    assert size("a = 1 \\     \n        \\") == 4
    assert size("a = 1 + \\") == 5
    assert size("a = 1 + \\     \n        \\") == 5
    assert size("a = 1 + 2 + \\") == 8
    assert size("a = 1 + 2 + \\     \n        \\") == 8
    assert size("a = (1 + 2 + \\") == 10
    assert size("a = (1 + 2 + \\     \n        \\") == 10



# Generated at 2022-06-24 08:13:46.386380
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    import re

# Generated at 2022-06-24 08:13:51.322623
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    from string import whitespace
    mapping = StringTranslatePseudoMapping(
        {
            ord(c): ord(c)
            for c in whitespace
        },
        ord("x"),
    )
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'


# Generated at 2022-06-24 08:13:58.609994
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    hp = HyperParser('''
    a = 1
    # b = 2
    ''')
    assert hp.is_in_code() == True
    hp.set_index('1.1')
    assert hp.is_in_code() == True
    hp.set_index('1.6')
    assert hp.is_in_code() == False
    hp.set_index('2.0')
    assert hp.is_in_code() == False


# Generated at 2022-06-24 08:14:07.629247
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-24 08:14:13.878685
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    from logging import DEBUG
    from codetransformer import get_logger
    logger = get_logger("test_RoughParser", level=DEBUG)
    rp = RoughParser(logger)
    rp.set_str("abc")
    assert rp.str == "abc", "rp.str == %r" % (rp.str,)


# Generated at 2022-06-24 08:14:14.892759
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    pass



# Generated at 2022-06-24 08:14:26.073058
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rp = RoughParser('def f():\n    a = 1\n    print(a)\n    ', 0)
    assert rp.get_num_lines_in_stmt() == 2
    rp = RoughParser('def f():\n    a = 1\n    print(a\\\n    )', 0)
    assert rp.get_num_lines_in_stmt() == 2
    rp = RoughParser('def f():\n    a = 1\n    print(a\\\n    )\n    ', 0)
    assert rp.get_num_lines_in_stmt() == 3
    rp = RoughParser('def f():\n    a = 1\n    print(a\\\n    )\n    \n    ', 0)
    assert rp.get_num_lines_

# Generated at 2022-06-24 08:14:38.339321
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    parser = RoughParser()
    # Test 1
    parser.set_lo("if (x==0\\\n)\n")
    assert parser.continuation == C_BACKSLASH
    assert parser.goodlines == [1, 2]
    assert parser.get_num_lines_in_stmt() == 2
    assert parser.compute_backslash_indent() == 1

    # Test 2
    parser.set_lo("if (x==0)\n")
    assert parser.continuation == C_NONE
    assert parser.goodlines == [1, 2]
    assert parser.get_num_lines_in_stmt() == 1

    # Test 3
    parser.set_lo("a = {0: \\\\\n1}")
    assert parser.continuation == C_BRACKET
    assert parser.goodlines

# Generated at 2022-06-24 08:14:48.628065
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    x = RoughParser("a = [1,2,3]\nif x > 2:\n    print(a[x])\n")
    assert x.get_last_stmt_bracketing() == (
        (0, 0),
        (2, 1),
        (3, 0),
        (7, 1),
        (10, 0),
        (11, 1),
        (12, 0),
        (13, 1),
        (15, 0),
        (16, 1),
        (18, 0),
        (20, 0),
    )

    x = RoughParser("x = [1,\n2,\n3]\nif x > 2:\n    print(a[x])\n")

# Generated at 2022-06-24 08:14:51.709530
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    '''Test for method __iter__ of class StringTranslatePseudoMapping
    '''
    #
    mapping = StringTranslatePseudoMapping({1:11, 2:22}, 0)
    it = iter(mapping)
    assert next(it) == 1
    assert next(it) == 2



# Generated at 2022-06-24 08:14:53.724531
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    """Test the is_in_code method of the HyperParser class."""

# Generated at 2022-06-24 08:14:59.551810
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'



# Generated at 2022-06-24 08:15:04.885745
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-24 08:15:13.368302
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """
    >>> h = HyperParser(Text(width=8), index="1.0")
    >>> h.set_index("1.3")
    >>> h.is_in_code()
    True
    >>> h.is_in_string()
    False
    >>> h.get_surrounding_brackets()
    ('1.1', '1.4')
    >>> h.get_expression()
    'x'
    >>> h.set_index("1.3 lineend")
    >>> h.is_in_code()
    False
    >>> h.is_in_string()
    False
    >>> h.get_expression()
    ''
    """

