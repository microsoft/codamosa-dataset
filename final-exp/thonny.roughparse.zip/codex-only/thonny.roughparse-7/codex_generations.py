

# Generated at 2022-06-24 08:05:24.758056
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    text.translate(mapping)

##_chew_name = string.ascii_letters + '_'
##_chew_namere = re.compile(
##    '[' + _chew_name + ']*'
##).match
_chew_name = string.ascii_letters + '_'
_chew_namere = re.compile(
    '[' + _chew_name + ']*'
).match

# Generated at 2022-06-24 08:05:26.930550
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    rp = RoughParser("if True:\n    pass")
    print(rp.is_block_closer())


# Generated at 2022-06-24 08:05:30.570185
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    assert set(mapping) == set(map(ord, whitespace_chars))



# Generated at 2022-06-24 08:05:40.133549
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    assert RoughParser("").is_block_opener() is False
    assert RoughParser("x = ").is_block_opener() is False
    assert RoughParser("if").is_block_opener() is False
    assert RoughParser("if ").is_block_opener() is False
    assert RoughParser("if 1:").is_block_opener() is True
    assert RoughParser("if 1: ").is_block_opener() is True
    assert RoughParser("if (1):").is_block_opener() is True
    assert RoughParser("if (1): ").is_block_opener() is True
    assert RoughParser("x = 1\n").is_block_opener() is True
    assert RoughParser("x = 1\n\n").is_block_opener() is True

# Generated at 2022-06-24 08:05:43.775400
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    #class StringTranslatePseudoMapping(Mapping):
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert all(c in whitespace_chars for c in mapping)

# Generated at 2022-06-24 08:05:51.818183
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    tests = [
        ("", ""),
        ("\n", ""),
        (" \n", " "),
        ("  \n", "  "),
        (" \n \n", " "),
        ("\t\n", "\t"),
        (" if 1: pass\n", " "),
        ("  if 1: pass\n", "  "),
        ("if 1:\n    pass\n", ""),
        ("  if 1:\n    pass\n", "    "),
        ("if 1:\n if 1:\n  pass\n", ""),
        ("if 1:\n  if 1:\n   pass\n", "  "),
        ("if 1:\n  if 1:\n    pass\n", "  "),
        ("if 1:\n   pass\n", " "),
    ]
   

# Generated at 2022-06-24 08:05:58.917015
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    from idlelib.hyperparser import StringTranslatePseudoMapping
    try:
        StringTranslatePseudoMapping({}, 0).__iter__()
    except Exception:
        import sys
        import traceback
        _, _, tb = sys.exc_info()
        new_tb = tb.tb_next.tb_next
        raise new_tb.tb_last_value.with_traceback(new_tb)



# Generated at 2022-06-24 08:06:09.967019
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=redefined-builtin,unused-variable

    # Test constructor.  Fails if constructor raises an exception.
    rp = RoughParser('''\
if True:
    if False:
        pass
    elif True:
        pass
    else:
        pass

elif True:
    pass

elif True:
    pass

elif True:
    if True:
        pass
    else:
        pass

else:
    pass
''')
    rp.is_block_opener()
    rp.is_block_closer()
    rp.get_num_lines_in_stmt()
    rp.compute_bracket_indent()
    rp.compute_backslash_indent()
    rp.get_last_

# Generated at 2022-06-24 08:06:22.003792
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    # pylint: disable=redefined-builtin
    str_ = """\
if 1:
    if 1:
        print 1
    elif 1:
        print 1
    else:
        print 1
# """[1:]

# Generated at 2022-06-24 08:06:31.285513
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    preserve_dict = {ord("a"): ord("x")}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("y"))
    assert mapping.get(ord("a")) == ord("x")
    assert mapping.get(ord("b")) == ord("y")
    assert mapping.get(ord("b"), None) is None


# Match valid Python identifier characters and underscore.
_identchars = string.ascii_letters + string.digits + "_"
# Match a valid Python identifier.
_identifier = "[" + _identchars + "]"
# Match a valid Python identifier, possibly followed by parentheses.
_call_expression = _identifier + r"(?:\(" + "|\s)*"
# Match a valid Python import statement.

# Generated at 2022-06-24 08:06:41.795315
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    for s in """\
    #
    #
    #
    a,b,c=[0,1,2]

    a,b,c=[0,1,2]

    a,b,c=[0,1,2]

    a,b,c=[0,1,2]

    a,b,c=[0,1,2]

    a,b,c=[0,1,2]
    """.split("\n"):
        p = RoughParser()
        p.set_str(s)
        assert p.get_base_indent_string() == ""
        c = p.get_continuation_type()
        if c:
            print("unexpected continuation", c, "in", s)
        assert c == C_NONE
        assert not p.is_block_opener()
       

# Generated at 2022-06-24 08:06:44.864943
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    rp = RoughParser(0, 0)
    rp.str = "while True:\n\tpass"
    rp._study2()
    assert rp.get_last_open_bracket_pos() == 6


# Generated at 2022-06-24 08:06:57.191575
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Text(None, undo=False)

# Generated at 2022-06-24 08:07:02.440439
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == len(whitespace_chars)



# Generated at 2022-06-24 08:07:08.640516
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    """Test HyperParser.is_in_string.

    This test method assumes that the test file is this file. This
    cannot be a method of class HyperParser because there is no
    Text object.
    """
    from idlelib.editor import EditorWindow

    # Create a trivial text box in which to test HyperParser.
    text = EditorWindow(None, None)
    text.set_search_results(None)
    text.set_text("")
    text.text["wrap"] = "none"
    text.text.focus_set()
    # Do the test.
    hp = HyperParser(text, "1.0")
    text.insert("1.0", "abc")
    assert not hp.is_in_string()
    text.insert("1.0", "'")
    assert hp.is_in_string()
   

# Generated at 2022-06-24 08:07:19.672345
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser("\nabc:\n  if blah:\n    blah\n")
    assert rp.is_block_opener() is True
    rp = RoughParser("\nabc(blah):\n  blah\n")
    assert rp.is_block_opener() is True
    rp = RoughParser("\nabc[blah]:\n  blah\n")
    assert rp.is_block_opener() is True
    rp = RoughParser("\nabc = (a,\n       b)\n")
    assert rp.is_block_opener() is True
    rp = RoughParser("\nabc += (a,\n        b)\n")
    assert rp.is_block_opener() is True

# Generated at 2022-06-24 08:07:22.146141
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    mapping = StringTranslatePseudoMapping({}, 0)
    assert mapping[0] == 0



# Generated at 2022-06-24 08:07:33.757664
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    """Unit test for method get_expression of class HyperParser.
    """

    def run_test(s, index, expresult):
        """Test the expression of s at the given index.

        If expresult is 0, expect an exception. Otherwise, run the
        test assuming the expression is expresult.
        """
        try:
            result = HyperParser(s, index).get_expression()
        except ValueError:
            if expresult:
                raise
        else:
            if not expresult:
                raise ValueError("ValueError expected")
            elif result != expresult:
                raise ValueError(
                    "Bad result, %r, for %r at %s should be %r" % (result, s, index, expresult)
                )

    run_test("a", "1.0", "a")

# Generated at 2022-06-24 08:07:39.764835
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    """Unit test for method get_last_stmt_bracketing of class RoughParser"""
    p = RoughParser("a = [b(0).c(1).d(2)] # comment\n")
    assert p.get_last_stmt_bracketing() == p.stmt_bracketing
    assert p.stmt_bracketing == ((0, 0), (1, 0), (2, 1), (6, 2), (9, 1), (12, 0))
    p = RoughParser("should_not_be_executed\na = [b(0).c(1).d(2)] # comment\n")
    assert p.get_last_stmt_bracketing() == p.stmt_bracketing

# Generated at 2022-06-24 08:07:50.026818
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    """
    testmethod method
    """
    teststring = """if True:
    if True:
        open_list = [
"""
    parser = RoughParser(teststring)
    parser.parse_if_expression()

    #print(parser.str)
    #print(parser.continuation)
    #print(parser.goodlines)
    #print(parser.study_level)
    #print(parser.stmt_start)
    #print(parser.stmt_end)
    #print(parser.lastch)
    #print(parser.stmt_bracketing)
    #print(parser.lastopenbracketpos)

    # check lastopenbracketpos
    assert parser.get_last_open_bracket_pos() == 31



# Generated at 2022-06-24 08:07:59.429959
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=redefined-builtin
    def test(s, continuation, n_lines, n_unjunk, n_string_cont):
        x = RoughParser(s, tabwidth=8, indentwidth=4)
        c, gl, uj = x.get_continuation_type(), x.get_good_lines(), x.get_num_unjunk_lines()
        sc = x.get_num_string_continuations()
        x = RoughParser(s, tabwidth=8, indentwidth=4, ignore_comment_and_docstring=False)
        c2, gl2, uj2 = x.get_continuation_type(), x.get_good_lines(), x.get_num_unjunk_lines()
        sc2 = x.get_num_string_continuations()
       

# Generated at 2022-06-24 08:08:09.840904
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    """Unit test for method find_good_parse_start of class RoughParser """
    import unittest
    from test.support import captured_stdout

    class TestRoughParserFindGoodParseStart(unittest.TestCase):
        """Test for find_good_parse_start"""

        def do_test(self, s, expected):
            """Convenience function for running one test case."""
            p = _RoughParser(s, 0)
            result = p._find_good_parse_start(0)
            if result != expected:
                raise self.failureException(
                    "bad result: got %d, expected %d" % (result, expected)
                )

        def test_single_statement(self):
            # no continuation
            s = "good()\n"

# Generated at 2022-06-24 08:08:17.348586
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    """
    Test the method HyperParser.is_in_code.
    """
    from test.support import captured_stdout

    def check_is_in_code(text, expected):
        t = type('', (str,), {})()
        t.indent_width = 8
        t.tabwidth = 4
        for i in range(len(text)):
            t.__setitem__(i, text[i])
        with captured_stdout() as stdout:
            h = HyperParser(t, "1.%d" % i)
            print(h.is_in_code())
        assert stdout.getvalue() == "%s\n"%expected


# Generated at 2022-06-24 08:08:23.755247
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():

    def check(s):
        roughparser = RoughParser(s, None)
        return roughparser.is_block_closer()


# Generated at 2022-06-24 08:08:34.535704
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-24 08:08:43.311351
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    class TestCase(object):
        """Test case for RoughParser.get_base_indent_string."""

        def __init__(self, p):
            self.p = p
            self.result = p.get_base_indent_string()

        def __repr__(self):
            return "%s(%r)" % (self.__class__.__name__, self.p)

    suite = unittest.TestSuite()
    # Test cases are named test_* to ensure their order
    test_case_classes = [
        TestCase,
    ]

    # Test Case:
    # 'if True:\n    print_smth()'
    p = RoughParser("if True:\n    print_smth()")
    test_case_class = test_case_classes[0]
    test_case

# Generated at 2022-06-24 08:08:48.200290
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    # This is a rather stupid test, because the only interesting thing
    # for the get() method of this class is to call __getitem__(). But
    # it can't hurt to have it.
    x = StringTranslatePseudoMapping({1: 2}, 3)

    assert x.get(1) == 2
    assert x.get(3) == 3
    assert x.get(1, 3) == 2
    assert x.get(3, 2) == 3


# Generated at 2022-06-24 08:08:59.951764
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # pylint: disable=redefined-outer-name, invalid-name
    def do_test(RoughParser, s, lo):
        # pylint: disable=redefined-outer-name
        # pylint: disable=redefined-outer-name
        rp = RoughParser(s)
        rp.set_lo(lo)
        assert rp.goodlines[0] == lo
    #
    s = "    say(boo)\n"
    do_test(RoughParser, s, 2)
    s = ""
    do_test(RoughParser, s, 2)
    s = (
        "say(3)\n"
        "\n"
        "\n"
        "\n"
        "say(4)\n"
    )

# Generated at 2022-06-24 08:09:08.045494
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import Tkinter
    import tkHyperParser

    root = Tkinter.Tk()
    text = Tkinter.Text(root, height=25, width=30)
    root.update()  # Needed for the text widget to update its size

    text.pack()
    text.focus_set()
    hp = tkHyperParser.HyperParser(text, "1.0")

    def set_index(index):
        return "in_string = %s" % hp.set_index(index)

    # The first test is very important, because it is the one that
    # tkHyperParser uses.
    for i in range(60):
        text.insert("end", " ")
    text.insert("end", "def foo(a, b):\n")
    text.insert("end", "    ")

# Generated at 2022-06-24 08:09:14.140274
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    """Test that RoughParser.get_base_indent_string works correctly"""
    # pylint: disable=undefined-variable
    # Tests for a function which doesn't belong to a class
    # should not be added to pylint tests
    def check(text, base_indent):
        """Check that RoughParser.get_base_indent_string return
        expected result when the text is provided as argument
        """
        parser = RoughParser(text, tabwidth=4)
        assert base_indent == parser.get_base_indent_string()
    check("""\
    def foo():
        if True:
            pass
        else:
            pass
    """, "    ")
    check("""\

    def foo():
        pass
    """, "")

# Generated at 2022-06-24 08:09:18.611776
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    m = StringTranslatePseudoMapping({ord(c): ord(c) for c in ' \t\n\r'},
        ord('x'))
    t = "a + b\tc\nd"
    assert t.translate(m) == 'x x x\tx\nx'



# Generated at 2022-06-24 08:09:27.688365
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-24 08:09:39.102042
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    str_ = """
    def foo(arg):
        try:
            pass
        except Exception as e:
            print(e)
            raise Exception("Failed to handle exception")
       """
    res = RoughParser(str_).get_last_stmt_bracketing()
    assert res == [(1, 0), (6, 1), (11, 0), (14, 1), (19, 0), (22, 1), (27, 0), (29, 0), (45, 1), (46, 0), (48, 0), (51, 1), (57, 0)]

# index of the first character of the last interesting statement
stmt_start = None

# index of the first character after the last interesting statement
stmt_end = None

# offset of the start of the last non-comment, non-blank line
line_start

# Generated at 2022-06-24 08:09:45.305738
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("\n  foo = 1\n")
    assert rp.get_base_indent_string() == "  "
    rp = RoughParser('\n  foo = """\n"""\n')
    assert rp.get_base_indent_string() == "  "


# Generated at 2022-06-24 08:09:56.779352
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    '''Unit test for method __len__ of class StringTranslatePseudoMapping.'''
    from StringTranslatePseudoMapping import StringTranslatePseudoMapping
    from collections import abc
    from subprocess import getoutput
    from sys import platform
    from sys import version_info
    from traceback import format_exc
    from types import ModuleType

    starting_dir = os.getcwd()
    os.chdir(os.path.abspath(os.path.dirname(__file__)))
    if not os.path.exists('__test'):
        os.mkdir('__test')

# Generated at 2022-06-24 08:10:02.949417
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = """a = 1 + [2, 3] + (4, 5) + 6"""
    for index in ["2.0", "3.0", "4.0", "6.0", "8.0", "10.0"]:
        print("\nTesting %s" % index)
        index = int(float(index))
        hp = HyperParser(text, index)
        print("is_in_string = %s" % hp.is_in_string())
        print("is_in_code = %s" % hp.is_in_code())
        print("get_expression = %s" % repr(hp.get_expression()))

# Generated at 2022-06-24 08:10:15.086604
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-24 08:10:21.270399
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    from lib2to3.pgen2.tokenize import tokenize, NL
    parser = RoughParser(tokenize("""
    def foo():

        def bar():
            pass

        def baz():
            pass

    """.lstrip()))
    for tup in parser.tokenize():
        token_type, token, start_pos, end_pos, line = tup
        if token_type != NL:
            continue
        if parser.is_block_opener():
            print(parser.get_base_indent_string())


# Generated at 2022-06-24 08:10:31.431134
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    assert StringTranslatePseudoMapping({}, 42).get(1) == 42
    assert StringTranslatePseudoMapping({1:2}, 42).get(1) == 2
    assert StringTranslatePseudoMapping({1:2}, 42).get(3) == 42

# Like _chew_ordinaryre, but for chars that aren't special in a regexp.
# We only want to match chars that aren't special in both contexts.

_chew_ordinary_norere = re.compile(
    r"""
    [^.[\]{}^$*+?()#'"\\]+
""",
    re.VERBOSE,
).match

# Match a raw string:  r'blah'


# Generated at 2022-06-24 08:10:35.573386
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    p = RoughParser()
    p.set_str("a=1")
    p.set_str("b=2")
    p.set_str("c=3")
    assert p.str == "\na=1\nb=2\nc=3"

# Generated at 2022-06-24 08:10:46.816299
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    parser = RoughParser(indent_width=4)
    parser.str = """\
c = a \
    + {b + 10} * 1000
"""
    assert parser.compute_backslash_indent() == 12
# source: http://sphinx.pocoo.org/ext/autodoc.html
# TODO: improve this

# Autodoc also supports parsing docstrings written in restructured text.
# You can set the :rst-class: option to the directive, to switch its markup
# mode.  It defaults to the markup mode of the current document.  You can
# also use the :no-link: and :no-underline: options to switch off automatic
# linking and underlining of reference names.
#
# The source for the content at the end of this section is the following.
#
# .. python

# Generated at 2022-06-24 08:10:52.946700
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    plain_dict = {1: -1, 2: -2}
    default_value = -100
    mapping = StringTranslatePseudoMapping(plain_dict, default_value)

    for key in plain_dict.keys():
        assert mapping[key] == plain_dict[key]

    for key in range(3, 10):
        assert mapping[key] == default_value

    assert mapping[None] == default_value


# Generated at 2022-06-24 08:10:59.630101
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'


# Generated at 2022-06-24 08:11:11.225967
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
#     s = """
# def foo(x,y):
#     if x:
#         while y:
#             if b:
#                 c = d
# """
    s = """foo(1);bar(2)
baz(3)

foo(4);bar(5)"""
    p = RoughParser()
    p.set_str(s)
#     print(p.goodlines)
    assert p.goodlines == [0,3,3,5]
    p.set_str('')
    assert p.goodlines == [0]
    p.set_str(s+s)
    assert p.goodlines == [0,3,3,5,5+3,5+3,5+5]


# Generated at 2022-06-24 08:11:23.009137
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    def verify(input, expected):
        parser = RoughParser(input)
        assert parser.get_num_lines_in_stmt() == expected, "expected " + str(expected) + " for " + input

    verify("""\
        if True:
            return 1
        """, 1)

    verify("""\
        if True:
            return
        """, 2)

    verify("""\
        if True: doit()
        """, 2)

    verify("""\
        if True: doit()
        else:
            pass
        """, 3)

    verify("""\
        return \\
               1
        """, 2)

    verify("""\
        return 1
        """, 1)

    verify("""\
        return \
               1
        """, 2)


# Generated at 2022-06-24 08:11:33.416436
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    from unittest import TestCase

    class TestHyperParser_is_in_string(TestCase):
        def Entry(self, string, index, exp_is_in_string):
            hp = HyperParser(string, index)
            self.assertEqual(exp_is_in_string, hp.is_in_string(), msg=repr(string))

        def test_is_in_string(self):
            self.Entry("a = 'blah'", "1.0", False)
            self.Entry("a = 'blah'", "1.1", False)
            self.Entry("a = 'blah'", "1.2", False)
            self.Entry("a = 'blah'", "1.3", False)
            self.Entry("a = 'blah'", "1.4", True)


# Generated at 2022-06-24 08:11:36.031639
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from idlelib.idle_test.mock_idle import Func
    root = Tk()
    root.withdraw()
    text = Text(root)
    text.pack()

# Generated at 2022-06-24 08:11:46.093831
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-24 08:11:53.249268
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    #
    parser = RoughParser(3, 70)
    while 1:
        try:
            line = raw_input()
        except EOFError:
            break
        if not line:
            break
        parser.set_lo(line)
    parser.set_lo("")  # end of input


if __name__ == "__main__":
    test_RoughParser_set_lo()
    print("test_RoughParser_set_lo() done.")

# Generated at 2022-06-24 08:12:04.808231
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-24 08:12:15.519102
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def test_HyperParser_get_surrounding_brackets_0():
        # Test with an empty string
        hp = HyperParser("", "1.0")
        assert hp.get_surrounding_brackets() is None

    def test_HyperParser_get_surrounding_brackets_1():
        # Test with an opening bracket
        hp = HyperParser("[", "1.0")
        assert hp.get_surrounding_brackets() is None

    def test_HyperParser_get_surrounding_brackets_2():
        # Test with a closing bracket
        hp = HyperParser("]", "1.0")
        assert hp.get_surrounding_brackets() is None


# Generated at 2022-06-24 08:12:22.749759
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    rough_parser = RoughParser("""    class Foo:
        def foo():
            "Hello" """, indent_width=4)
    assert rough_parser.continuation == C_NONE

    import lib2to3.pgen2.tokenize as tokenize
    from lib2to3.pgen2.parse import ParseError

    try:
        tokenize.tokenize(rough_parser.find_good_parse_start)
    except Exception as ex:
        # In case of a parse error, unindent the text of the class, try
        # again and return the resulting text
        if ex.__class__ == ParseError:
            i = 0
            while True:
                if rough_parser.str[i] == "#":
                    i = rough_parser.str.find("\n", i)

# Generated at 2022-06-24 08:12:26.553261
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    """Test that the lo property of RoughParser is correct"""
    rp = RoughParser()
    for t in ("", "x", "  x", "x\nx", "x\n\nx\n", "x\n\n\nx\n", "x\n\n\n\nx\n"):
        rp.set_lo(t)
        lo = rp.get_lo()
        print(t, lo)
        assert t[:lo].count("\n") == 0


# Generated at 2022-06-24 08:12:31.794221
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    rp = RoughParser("   x(1)  \n   x(2)\n x(3)\nx(4)", indent_width=4)
    assert rp.get_last_stmt_bracketing() == (
        (0, 0),
        (4, 1),
        (5, 0),
        (15, 0),
        (16, 1),
        (20, 0),
        (24, 0),
    )
# Test the functionality of the RoughParser class by running its unit
# test.
test_RoughParser_get_last_stmt_bracketing()

# Generated at 2022-06-24 08:12:40.900177
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    """Test method HyperParser.is_in_code."""

# Generated at 2022-06-24 08:12:52.944582
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    RoughParser("    class A:\n    pass\n    ").find_good_parse_start() == 4
    RoughParser("\"\"\"\nclass A:\n    pass\n    ").find_good_parse_start() == 0
    RoughParser("foo\n\"\"\"\nclass A:\n    pass\n    ").find_good_parse_start() == 0
    RoughParser("    # test\nclass A:\n    pass\n    ").find_good_parse_start() == 4
    RoughParser("    # test\nclass A:\n    pass\n    ").find_good_parse_start() == 4
    RoughParser("    '''\nclass A:\n    pass\n    ").find_good_parse_start() == 0

# Generated at 2022-06-24 08:13:05.970528
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Tk.Text()
    text.insert("1.0", "if 1:")
    text.insert("2.0", "  (")
    text.insert("3.0", "    if 1:")
    text.insert("4.0", "      (" + " " * 15 + ")")
    text.insert("5.0", "    elif 1:")
    text.insert("6.0", "      (" + " " * 7 + ")")
    text.insert("7.0", "    else:")
    text.insert("8.0", "      [")
    text.insert("9.0", "      ]")
    text.insert("10.0", "  )")

    hp = HyperParser(text, "4.8")
    hp.set_index("4.7")

   

# Generated at 2022-06-24 08:13:16.125511
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    it = mapping.__iter__()
    for c in whitespace_chars:
        assert c == chr(it.__next__())
    try:
        it.__next__()
    except StopIteration:
        pass
    else:
        assert False


# Generated at 2022-06-24 08:13:21.663227
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    text.translate(mapping)
    assert len(mapping) == len(whitespace_chars)


# Generated at 2022-06-24 08:13:34.916962
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    def check(text, expected_result):
        rp = RoughParser(text)
        result = rp.is_block_opener()
        assert result == expected_result, ("result is %s, expected %s" %
                                             (result, expected_result))
    check("", False)
    check("\n", False)
    check("if 1:\n    pass", True)
    check("if 1: pass", True)
    check("if 1:\n", False)
    check("if 1:", False)
    check("\n    pass", False)
    check("\nif 1:\n    pass", False)
    check("if 1:\n    pass\nelse:\n    pass", False)
    check("else:\n    pass", False)

# Generated at 2022-06-24 08:13:47.999617
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    test_cases = (
        ("1 + a", "a"),
        ("foo.bar", "foo.bar"),
        ("foo().bar", "bar"),
        ("foo.bar()", "foo.bar"),
        ("foo.bar[3]", "foo.bar[3]"),
        ("foo.bar[3].yadda", "foo.bar[3]"),
        ("(1 + foo).bar", "foo"),
        ("(1 + foo).bar(", "foo"),
        ("(1 + foo).bar()", "foo"),
        ("(1 + foo).bar()[3].yadda", "foo"),
    )

    for code, expected_result in test_cases:
        p = HyperParser(code, len(code))
        result = p.get_expression()

# Generated at 2022-06-24 08:13:54.437470
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    # RoughParser_is_block_closer_test.txt
    # Unit test for method is_block_closer of class RoughParser
    # This is a demonstration test run.  It doesn't check anything.
    rp = RoughParser('''\
if (1):
    if (2):
        xxx
        if (3):
            yyy
            if (4):
                zzz

try:
    if (5):
        alpha
        if (6):
            beta
            if (7):
                gamma

''')

    print("Initial state")
    print("-------------")
    print("str:", repr(rp.str))
    print("goodlines:", rp.goodlines)
    print("continuation:", rp.continuation)
    print()


# Generated at 2022-06-24 08:14:04.545709
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    assert HyperParser("(a+b)", "1.0").is_in_string() == False
    assert HyperParser('(a+"b")', "1.0").is_in_string() == False
    assert HyperParser('(a+"b")', "1.2").is_in_string() == True
    assert HyperParser('(a+"b")', "1.3").is_in_string() == True
    assert HyperParser('(a+"b")', "1.4").is_in_string() == False
    assert HyperParser('(a++"b")', "1.4").is_in_string() == True

# Generated at 2022-06-24 08:14:16.402704
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    find_good_parse_start, RoughParser = RoughParser.find_good_parse_start, RoughParser
    tests = [
        (
            ("\n" * 10) + "if foo:\n" + ("\n" * 20) + "    bar()\n",
            ("if foo:\n", "\n" * 18),
        ),
        (
            ("\n" * 10) + "if foo:\n" + (" " * 4) + "bar()\n",
            ("if foo:\n", (" " * 4)),
        ),
        (
            ("\n" * 10) + "if foo:\n" + "\t\tbar()\n",
            ("if foo:\n", "\t\t"),
        ),
    ]

# Generated at 2022-06-24 08:14:26.713466
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    h = HyperParser(text, "1.0")

    # Test basic cases
    h.set_index("1.0")
    for i, c in enumerate("abcdefghij"):
        text.insert("end", c)
        h.set_index("1.%d" % (i + 1))
        assert h.indexbracket == 1, (i, h.indexbracket)

    # Add three brackets
    text.insert("end", "(")
    text.insert("end", ")")
    text.insert("end", "{")
    text.insert("end", "}")
    text.insert("end", "[")
    text.insert("end", "]")

    # Check that lines containing brackets are parsed correctly
    h.set_index("1.0")
    assert h

# Generated at 2022-06-24 08:14:32.067914
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-24 08:14:41.787826
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    import io

    def check(code, expected_base_indent_string):
        f = io.StringIO(code)
        parser = RoughParser(f.readline, filename="Test", tabwidth=8)
        actual_base_indent_string = parser.get_base_indent_string()
        assert actual_base_indent_string == expected_base_indent_string, f"{code!r} -> expected {expected_base_indent_string!r} but got {actual_base_indent_string!r}"

    check(code="", expected_base_indent_string="")
    check(code="\n", expected_base_indent_string="")
    check(code="\n\n", expected_base_indent_string="")

# Generated at 2022-06-24 08:14:48.407199
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    keep_chars = "ab12"
    keep_dict = {ord(c): ord(c) for c in keep_chars}
    mapping = StringTranslatePseudoMapping(keep_dict, ord('x'))

    assert mapping[ord('a')] == ord('a')
    assert mapping[ord('b')] == ord('b')
    assert mapping[ord('1')] == ord('1')
    assert mapping[ord('2')] == ord('2')
    assert mapping[ord('3')] == ord('x')
    line = "ab1234"
    assert line.translate(mapping) == "ab12xx"

# Find the start of a triple-quoted string, where the line preceding
# the start need not begin with a quote.


# Generated at 2022-06-24 08:14:54.604804
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def test(s, expected_indent):
        parser = RoughParser(s)
        indent = parser.compute_bracket_indent()
        if indent != expected_indent:
            print(s)
            print("  indent:", indent)
            print("expected:", expected_indent)
            print()

    test("[", 1)
    test("[\n", 1)
    test("[\n ", 1)
    test("[\n  ", 3)
    test("[\n   ", 5)
    test("[\n    ", 7)
    test("[\n     ", 9)
    test("[1,\n", 1)
    test("(\n", 1)
    test("(\n ", 1)
    test("(\n  ", 3)
    test("{\n", 1)


# Generated at 2022-06-24 08:15:03.336439
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    call = StringTranslatePseudoMapping.__getitem__

    # Test successful key lookups
    mapping = StringTranslatePseudoMapping({ord('a'): 0, ord('b'): 1}, None)
    assert call(mapping, ord('a')) == 0
    assert call(mapping, ord('b')) == 1

    # Test unsuccessful key lookup and default value
    assert call(mapping, ord('c')) == None
    mapping = StringTranslatePseudoMapping({ord('a'): 0, ord('b'): 1}, 'default')
    assert call(mapping, ord('c')) == 'default'

    # Test unchanged string representation
    mapping = StringTranslatePseudoMapping({ord('a'): 'A', ord('b'): 'B'}, None)

# Generated at 2022-06-24 08:15:05.521819
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    code = "    print('test')\n"
    rp = RoughParser(code, 0)
    assert rp.get_base_indent_string() == "    "



# Generated at 2022-06-24 08:15:09.982776
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rp = RoughParser('a = 1 + \\', 4)
    assert rp.compute_backslash_indent() == 5
    rp = RoughParser('  a = 1 + \\', 4)
    assert rp.compute_backslash_indent() == 7
    rp = RoughParser('a = 1 + \\', 4, tab_width=2)
    assert rp.compute_backslash_indent() == 6
    rp = RoughParser('a = 1\n + \\', 4)
    assert rp.compute_backslash_indent() == 5
    rp = RoughParser('a = 1 + \\', 4)
    assert rp.compute_backslash_indent() == 5
    rp = RoughParser('a = (1 + \\', 4)
    assert r

# Generated at 2022-06-24 08:15:17.206455
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # CPython 3.6, not including the newline
    assert RoughParser("a = 1 + 2 + ").get_continuation_type() == \
        RoughParser.C_BACKSLASH
    assert RoughParser("a = 1 + 2 + \\").get_continuation_type() == \
        RoughParser.C_BACKSLASH
    assert RoughParser("a = 1 + 2 + \\").get_continuation_type() == \
        RoughParser.C_BRACKET
    assert RoughParser("a = [1 + 2 + ").get_continuation_type() == \
        RoughParser.C_BRACKET
    assert RoughParser("a = [1 + 2 + \\").get_continuation_type() == \
        RoughParser.C_BRACKET
    assert RoughParser("a = [1 + 2 + \\").get_