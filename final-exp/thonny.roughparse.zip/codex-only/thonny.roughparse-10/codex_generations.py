

# Generated at 2022-06-24 08:05:19.161173
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    p = RoughParser()
    p.set_str("a = 3")
    assert p.str == "\n    a = 3"
    p.set_str("")
    assert p.str == "\n"


# Generated at 2022-06-24 08:05:30.948307
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import sys
    import unittest

    class Test(unittest.TestCase):
        # test_* methods must start with 'test'
        def test_get_surrounding_brackets(self):
            class TextMockup:
                def __init__(self, string):
                    self._string = string
                    self._nextindex = "1.0"

                def get(self, index1, index2):
                    assert index2 == "end"
                    assert index1 == self._nextindex
                    res = self._string[
                        int(float(index1)) - 1 : int(float(self._nextindex))
                    ]
                    self._nextindex = repr(1 + len(res) + int(float(index1))) + ".0"
                    return res


# Generated at 2022-06-24 08:05:40.287506
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    """Unit test for method is_block_opener of class RoughParser"""

# Generated at 2022-06-24 08:05:45.796192
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Text()
    text.insert("insert", "x = 'a' + '")
    print(HyperParser(text, 'insert').is_in_string())
    text.insert("insert", "'''")
    print(HyperParser(text, 'insert').is_in_string())
    text.insert("insert", "'")
    print(HyperParser(text, 'insert').is_in_string())
    text.insert("insert", "#'")
    print(HyperParser(text, 'insert').is_in_string())
    text.insert("insert", "'")
    print(HyperParser(text, 'insert').is_in_string())

# Generated at 2022-06-24 08:05:47.392789
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    assert len(StringTranslatePseudoMapping({}, "")) == 0


# Exceptions that can occur.


# Generated at 2022-06-24 08:05:54.958072
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    # Test valid keys
    mapping = StringTranslatePseudoMapping({1: 'a', 2: 'b'}, 'x')
    assert mapping.get(1) == 'a'
    assert mapping.get(2) == 'b'
    # Test invalid keys
    assert mapping.get(42) == 'x'
    assert mapping.get(42, 'y') == 'y'



# Generated at 2022-06-24 08:06:03.978174
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    tests = (
        # if those fail, please add a reason
        ("def func(self):", True),
        ("class A:", True),
        ("def func(self): pass", False),
        ("class A: pass", False),
        ("def func(self):  # comment\n pass", False),
        ("class A:  # comment\n pass", False),
        ("def func(self):\n pass", False),
        ("class A:\n pass", False),
        ("pass", False),
        ("pass  # comment", False),
    )
    for text, expected_result in tests:
        result = RoughParser(text).is_block_opener()
        assert expected_result == result, (text, expected_result, result)


# Generated at 2022-06-24 08:06:05.945448
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-24 08:06:16.616691
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    # Test cases are strings which are Python source code.
    # They are intended to be broken into two or more lines,
    # to be passed to the parser.

    # Test that single-line statements without newline are
    # treated as 1 line statements
    test_case = "if x: pass"
    rp = RoughParser(test_case)
    assert rp.get_num_lines_in_stmt() == 1

    # Test that single-line statements with newline are
    # treated as 1 line statements
    test_case = "if x:\n    pass"
    rp = RoughParser(test_case)
    assert rp.get_num_lines_in_stmt() == 1

    # Test that multi-line statements are detected with
    # newline and without newline, and that they are
    # correctly detected as

# Generated at 2022-06-24 08:06:27.897549
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    _translate_pseudo_mapping_default_value = 0
    mapping = StringTranslatePseudoMapping({},
                                           _translate_pseudo_mapping_default_value)
    _string = 'abc'
    _translate_pseudo_mapping_default_value = mapping[_string]
    return _translate_pseudo_mapping_default_value

# Generated at 2022-06-24 08:06:39.056663
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text(None, "")
    hp = HyperParser(text, "1.0")

    hp.set_index("1.0")
    tkMessageBox.showinfo("", repr(hp.rawtext))

    text.insert("1.0", "if 1:\n")
    text.insert("2.0", "  if 2:\n")
    text.insert("3.0", "    pass")

    # index is at indent of line 1
    hp.set_index("1.0")
    tkMessageBox.showinfo("", repr(hp.rawtext))

    # index is at indent of line 2
    hp.set_index("2.0")
    tkMessageBox.showinfo("", repr(hp.rawtext))

    # index is at indent of line 3

# Generated at 2022-06-24 08:06:47.860504
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=protected-access
    if sys.version_info[:2] < (2, 5):
        import doctest
        doctest.testmod(None, None, None, True, False, False)
        return

    # did the word "parsestartfinder" show up in tracebacks?
    # if so, we need to update the test.
    import re

    def check(traceback):
        assert re.search(r"\bparsestartfinder\b", traceback) is None

    import test.test_syntax


# Generated at 2022-06-24 08:06:50.542054
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    mapping = StringTranslatePseudoMapping({'a': 1, 'b': 2}, 3)
    assert len(mapping) == 2

# Generated at 2022-06-24 08:07:00.773277
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    # @unittest.skip("temporarily disabled")
    print("test_StringTranslatePseudoPseudoMapping")

    non_defaults = {ord(c): ord(c) for c in " \t\n\r"}
    mapping = StringTranslatePseudoMapping(non_defaults, ord('x'))
    text = "a + b\tc\nd"
    result = text.translate(mapping)
    # print(result)
    assert result == "x x x\tx\nx"


# Chew up paired punctuation chars as quickly as possible.  If match is
# successful, m.end() less 1 is the index of the last boring char
# matched.  If match is unsuccessful, the string starts with an
# interesting char.  This regexp is used to detect delimiter matching.


# Generated at 2022-06-24 08:07:06.230748
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser("foo", 8)
    rp.set_lo(0)
    assert rp.lno == 1
    assert rp.bol == 0
    assert rp.sol == 0
    rp.set_lo(1)
    assert rp.lno == 1
    assert rp.bol == 0
    assert rp.sol == 0
    rp = RoughParser("\nfoo", 8)
    rp.set_lo(2)
    assert rp.lno == 2
    assert rp.bol == 1
    assert rp.sol == 1
    rp.set_lo(1)
    assert rp.lno == 1
    assert rp.bol == 0
    assert rp.sol == 0


# Generated at 2022-06-24 08:07:12.093425
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def se(input, index, expected_output, indent_width=8, tabwidth=8):
        hp = HyperParser(
            MockTkText(input, indent_width=indent_width, tabwidth=tabwidth), "%d.%d" % index
        )
        output = hp.get_expression()
        assert output == expected_output, f"{output} != {expected_output}"

    # Tests are in this form:
    # se(input, (line, column), expected_output)
    #  where line and column are 1-based, and column is the position to the right of
    #  the character.
    #
    se("", (1, 1), "")
    se("x", (1, 1), "")
    se("x", (1, 2), "x")

# Generated at 2022-06-24 08:07:13.439540
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rough_parser = _TestRoughParser()

# Generated at 2022-06-24 08:07:21.038174
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    """Unit test for method find_good_parse_start of class RoughParser."""
    class TestCase:
        def __init__(self, source, result):
            self.source = source
            self.result = result

# Generated at 2022-06-24 08:07:27.299493
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-24 08:07:31.862353
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    """Unit test for method __getitem__ of class StringTranslatePseudoMapping"""
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'



# Generated at 2022-06-24 08:07:38.480755
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def test(inp, out, opts=None):
        if opts is None:
            opts = default_options
        rp = RoughParser(inp, **opts)
        actual = rp.compute_bracket_indent()
        if actual != out:
            print("Wrong result:")
            print("input:", inp)
            print("expected:", out)
            print("actual:", actual)

    test("x = [1,\n" "      2,\n" "      3]",
         14, opts={"tabwidth": 8})
    test("x = [1,\n" "     2,\n" "      3]",
         16, opts={"tabwidth": 8})
    test("x = [1\n",
         2)

# Generated at 2022-06-24 08:07:39.691202
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-24 08:07:50.283669
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-24 08:08:01.937181
# Unit test for constructor of class RoughParser
def test_RoughParser():
    RoughParser("""\
# line 1
# line 2
a = 1
bb = 2
# line 5
# line 6
c = 3
# line 8
""")
    RoughParser("""\
# line 1
# line 2
a = 1
bb = 2
# line 5
# line 6
c = 3
## line 9
""")
    RoughParser("""\
if a > 2:
    b[3] = 6
    b[4] = 7
""")
    RoughParser("""\
if a > 2:
    b[3] = 6
    b[4] = 7



""")
    RoughParser("""\
if a > 2:
    b[3] = 6
    b[4] = 7
# comment
""")

# Generated at 2022-06-24 08:08:10.695730
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # "print 'some text', 'some more text'"
    text = "print 'some text', 'some more text'"
    idx = 4
    assert HyperParser(text, idx).is_in_code()
    idx = 9
    assert not HyperParser(text, idx).is_in_code()
    idx = 19
    assert HyperParser(text, idx).is_in_code()
    idx = 23
    assert not HyperParser(text, idx).is_in_code()
    idx = 30
    assert HyperParser(text, idx).is_in_code()
    idx = 39
    assert HyperParser(text, idx).is_in_code()


# Generated at 2022-06-24 08:08:17.963994
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == len(preserve_dict)


# Generated at 2022-06-24 08:08:27.501259
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-24 08:08:30.244817
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    x = StringTranslatePseudoMapping({},0)
    assert iter(x) == iter({})

# Generated at 2022-06-24 08:08:31.692322
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    from pyflakes.api import check
    import io
    

# Generated at 2022-06-24 08:08:39.735691
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    h = HyperParser("if True:\n    print 'hello'\n    print 'world'", "1.18")
    assert h.is_in_string() == False
    h.set_index("1.23")
    assert h.is_in_string() == True
    h.set_index("2.0")
    assert h.is_in_string() == False
    h.set_index("2.11")
    assert h.is_in_string() == True
    h.set_index("2.16")
    assert h.is_in_string() == False
    h = HyperParser("'''String with\nmore than one line\n'''", "1.4")
    assert h.is_in_string() == True
    h.set_index("2.3")

# Generated at 2022-06-24 08:08:46.120541
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    '''
    >>> whitespace_chars = ' \t\n\r'
    >>> preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    >>> mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    >>> len(mapping)
    4
    '''



# Generated at 2022-06-24 08:08:59.827521
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    class TestHyperParser(HyperParser):
        def __init__(self, text):
            super().__init__(text, text.index("1.0"))

    # Test inline comments
    text = Text()
    test = TestHyperParser(text)
    text.insert("1.0", "5 # inline comment")
    test.set_index("1.6")
    assert test.rawtext == "5 # inline comment", test.rawtext
    text.insert("1.6", '+ "string"')
    test.set_index("1.end")
    assert test.rawtext == "5 # inline comment + 'string'", test.rawtext
    text.delete("1.6", "1.end")
    text.insert("1.6", "# second comment")
    test.set_index("1.end")
   

# Generated at 2022-06-24 08:09:11.265566
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=redefined-outer-name
    class Mock(object):
        pass


# Generated at 2022-06-24 08:09:20.285833
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    """Test the HyperParser class"""

    # These are the positions that should identify as in code,
    # according the the comment before them
    in_code_positions = "def f(): # def [5]\n" "    return 0 # return [11]\n" "x = f() # x = [19]\n"

    for pos in range(len(in_code_positions)):
        hp = HyperParser(in_code_positions, "%d.0" % pos)
        assert hp.is_in_code()

# Generated at 2022-06-24 08:09:28.501967
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # The only way to test this is to ensure that the tab expanders
    # work properly.  If _tab_width is 8, _tab_expander should turn
    # 'x\tx' into 'x       x', and _line_offset should turn ' \tx'
    # into '        x'.

    global _tab_width, _tab_expander, _line_offset

    # pylint: disable=redefined-builtin

    for tw in (4, 8, 12, 16):
        _tab_width = tw
        _tab_expander = _tab_expander_cache.setdefault(tw, re.compile(r"(\t*)").expand)
        line_offset_re = _tab_expander(" " * tw + r"\1").lstrip()

# Generated at 2022-06-24 08:09:39.591036
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    print("test_RoughParser_get_base_indent_string")

    # The line is not empty => return nothing
    rp = RoughParser("a = 2\n", 0, 0)
    assert rp.get_base_indent_string() == ""

    # There is a space => return the space
    rp = RoughParser(" \n", 0, 0)
    assert rp.get_base_indent_string() == " "

    # There is a tab => return the tab
    rp = RoughParser("\t\n", 0, 0)
    assert rp.get_base_indent_string() == "\t"

    # Nothing but whitespace => return nothing
    rp = RoughParser("  \t\n", 0, 0)

# Generated at 2022-06-24 08:09:47.692335
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    def testit(text, expected_result):
        if RoughParser(text).get_continuation_type() != expected_result:
            raise ValueError("test failed for text: %s" % repr(text))

    testit("", C_NONE)
    testit("# a comment", C_NONE)
    testit("# a comment\\", C_NONE)
    testit("# a comment \\\\\n", C_NONE)
    testit("# a comment \\\\\n ", C_BACKSLASH)
    testit("# a comment \\\\\n def func(): pass", C_BACKSLASH)
    testit("# a comment \\\n", C_BACKSLASH)
    testit("# a comment \\\n ", C_BACKSLASH)

# Generated at 2022-06-24 08:09:59.000869
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = load_sample_file("is_in_code.py")
    hp = HyperParser(text, "9.0")
    assert hp.is_in_code()
    hp.set_index("11.0")
    assert hp.is_in_code()
    hp.set_index("13.0")
    assert hp.is_in_code()
    hp.set_index("15.0")
    assert hp.is_in_code()
    hp.set_index("19.0")
    assert hp.is_in_code()
    hp.set_index("21.0")
    assert not hp.is_in_code()
    hp.set_index("23.0")
    assert not hp.is_in_code()
    hp.set_index("25.0")
    assert not hp

# Generated at 2022-06-24 08:10:03.692015
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    mapping = StringTranslatePseudoMapping({'a': 'b', 'c': 'd'}, 'x')
    assert len(mapping) == 2
    assert len(mapping) == 2

# Generated at 2022-06-24 08:10:15.608434
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def t(s):
        rp = RoughParser(s)
        if rp.is_block_opener() or rp.is_block_closer():
            return ''
        return rp.get_base_indent_string()
    assert t("\n") == ''
    assert t("a = 3\n") == ''
    assert t("a = 3;b = 4\n") == ''
    assert t("if a:\n") == ''
    assert t("if a:\n    b = 4\n") == ''
    assert t("if a:\n    b = 4\n") == ''
    assert t("if a:\n    b = 4\n    c = 6\n") == ''
    assert t("if a:\n    b = 4\n# foo\n") == ''

# Generated at 2022-06-24 08:10:19.996510
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    import doctest
    from lib2to3.pgen2.parse import ParseError
    failure_count, test_count = doctest.testmod(RoughParser)
    assert test_count > 0
    if failure_count:
        # print("{} of {} tests failed".format(failure_count, test_count))
        raise ParseError("{} of {} tests failed".format(failure_count, test_count))

#----------------------------------------------------------------


# Generated at 2022-06-24 08:10:31.400952
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    from test.test_suite import TestSuite
    suite = TestSuite()
    def test(s, expected):
        rough_parser = RoughParser(s, 4)
        suite.run_test(rough_parser.get_last_stmt_bracketing(), expected)

    test("\n", None)
    test("abc\n", ((0, 0), (4, 0)))
    test("abc\\\ndef\n", ((0, 0), (7, 0)))
    test("'''\n\n'''\n", ((0, 0), (6, 0)))
    test("'''\n\n'''\nabc\n", ((0, 0), (6, 0), (9, 0), (13, 0)))

# Generated at 2022-06-24 08:10:40.352395
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # the parsing is simple and not very interesting, so it is sufficient
    # to test the parsing of various statements and statements continuations
    # and make sure they are recognized as such

    def test(code, ctype, *args):
        # check that code is recognized as having ctype continuation
        r = RoughParser(code)
        assert r.get_continuation_type() == ctype, "code %r, continuation type %d" % (code, ctype)

    # a function definition
    test("def f(x):\n    return x\n", C_NONE)

    # a statement with a backslash continuation
    test("x = 1 + \\ \n       2\n", C_BACKSLASH)

    # a statement with bracket continuation

# Generated at 2022-06-24 08:10:47.876873
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():  # @UnusedFunction
    test = StringTranslatePseudoMapping({1: 2}, 0)
    assert test[1] == 2
    assert test[2] == 0
    test = StringTranslatePseudoMapping({}, 0)
    assert test[1] == 0

# Utility function used by 'parse_lines'
# Return a list of the strings contained in 'text',
# each string being a line that is not a continuation line
# (that is, a line without a backslash at the end)

# Generated at 2022-06-24 08:10:59.081547
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():

    def test(s, bracketpos):
        parser = RoughParser(s, 0)
        parser._study2()
        assert parser.get_last_open_bracket_pos() == bracketpos

    # pylint: disable=line-too-long

    yield test, "", None
    yield test, "abc", None
    yield test, "[abc]", None
    yield test, "[abc () [] {} ]", None
    yield test, "(abc () [] {} )", None
    yield test, "([abc () [] {} ])", None
    yield test, "{[abc () [] {} ]}", None
    yield test, "a[b]c", None
    yield test, "a ( b ) c", None
    yield test, "a { b } c", None
    yield test, "[]", None
    yield test, "()", None

# Generated at 2022-06-24 08:11:04.726976
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():

    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))

    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"

# Singleton object to signify use of default from translate()
_default = object()



# Generated at 2022-06-24 08:11:14.244774
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    def test(text, expected):
        rp = RoughParser(text)
        result = rp.get_last_stmt_bracketing()
        assert result == expected, '%r != %r for %r' % (result, expected, text)

    test('#comment\nxyz', None)
    test('if foo:\n    pass\nxyz', None)
    test('xyz', ((0, 0), (3, 0),))
    test('x[y]', ((0, 0), (1, 1), (3, 0),))
    test('x(y)', ((0, 0), (1, 1), (3, 0),))
    test('x[y:z]', ((0, 0), (1, 1), (1, 2), (3, 1), (3, 0),))
    test

# Generated at 2022-06-24 08:11:24.241229
# Unit test for method __iter__ of class StringTranslatePseudoMapping

# Generated at 2022-06-24 08:11:33.948740
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # tabify, for _startatindex to make sense.
    text = '"  first line\n" second (line\n) end'
    lines = text.split('\n')
    lines = [tabs_to_spaces(line, num_spaces=4) for line in lines]
    text = '\n'.join(lines)
    hp = HyperParser(text, "1.0")
    assert str(hp.rawtext) == str(text)
    assert str(hp.stopatindex) == "3.0"
    assert str(hp.bracketing) == str([(len(lines[0]), 0), (0, 1), (10, 2), (13, 1), (14, 0)])
    assert str(hp.isopener) == str([0, 1, 1, 0, 0])


# Generated at 2022-06-24 08:11:44.937916
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from idlelib.parsers import ObjectDelegate

    def htest(text, index, should_be_in_code):
        hp = HyperParser(text, index)
        if hp.is_in_code() != should_be_in_code:
            raise Exception(
                "HyperParser.is_in_code() failed for index %s in text %r"
                % (index, text.get("1.0", "end-1c"))
            )

    text = EditorWindow(root)
    text.insert("1.0", "q = Hello World!\n")
    htest(text, "1.0", True)
    htest(text, "1.1", False)
    htest(text, "1.2", False)
    htest(text, "1.3", True)
    htest

# Generated at 2022-06-24 08:11:55.979464
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    parser = RoughParser("def f():\n")
    parser.study_stmt()
    assert parser.is_block_opener()
    parser = RoughParser("def f(): pass\n")
    parser.study_stmt()
    assert parser.is_block_opener()
    parser = RoughParser("if f():\n")
    parser.study_stmt()
    assert parser.is_block_opener()
    parser = RoughParser("if f(): pass\n")
    parser.study_stmt()
    assert parser.is_block_opener()
    parser = RoughParser("elif f() :\n")
    parser.study_stmt()
    assert parser.is_block_opener()
    parser = RoughParser("elif f() : pass\n")
    parser.study_stmt()


# Generated at 2022-06-24 08:12:04.674940
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-24 08:12:15.403138
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    """
    >>> rp = RoughParser("if x==0:")
    >>> rp.is_block_opener()
    True
    >>> rp = RoughParser("if x==0:\\n    pass")
    >>> rp.is_block_opener()
    True
    >>> rp = RoughParser("if x==0: pass")
    >>> rp.is_block_opener()
    False
    >>> rp = RoughParser("if x==0:\\n    pass")
    >>> rp.is_block_opener()
    True
    >>> rp = RoughParser("if x==0:\\n    a=5")
    >>> rp.is_block_opener()
    True
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest

# Generated at 2022-06-24 08:12:19.536061
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == len(whitespace_chars)


# Generated at 2022-06-24 08:12:28.709933
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    # pylint: disable=redefined-builtin
    # This test is not yet used, because it was not present in the original
    # code and we do not want to introduce new bugs.
    def t(txt, pos):
        parser = RoughParser(txt)
        rp_pos = parser.get_last_open_bracket_pos()
        assert rp_pos == pos
    t("{}", None)
    t("{}", None)
    t("{}", None)
    t("{a}", None)
    t("{a:}", None)
    t("{a:", 0)
    t("{a: b}", None)
    t("{a: b\n c}", None)
    t("{a: b\n c\n", 6)

# Generated at 2022-06-24 08:12:35.788791
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    c1 = """
if 1:
    if 2:
        if 3:
            pass
    else:
"""
    c2 = """
while 1:
    if 2:
        pass
    else:
"""
    c3 = """
try:
    if 1:
        pass
    else:
        pass
except:
    if 1:
        pass
"""
    c4 = """
for i in [1, 2, 3]:
    pass
"""

# Generated at 2022-06-24 08:12:38.533530
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()
    assert rp.str == ""
    rp.set_str("test\n")
    assert rp.str == "test\n"



# Generated at 2022-06-24 08:12:42.752861
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    # Setup:
    mapping = StringTranslatePseudoMapping({}, 1)
    mapping._non_defaults = {1: 2, 3: 4, 5: 6}
    # Exercise:
    result = list(iter(mapping))
    # Verify
    assert set(result) == {1, 3, 5}


# Generated at 2022-06-24 08:12:50.411542
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    # the following is true if the method __iter__ is implemented.
    assert list(iter(mapping)) == list(preserve_dict.keys())

# Generated at 2022-06-24 08:12:57.607877
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def test(s, index, expected):
        parser = HyperParser(s, index)
        actual = parser.is_in_code()
        if actual != expected:
            print(
                "Failed while testing is_in_code with s=%r, index=%r, expected=%r, actual=%r"
                % (s, index, expected, actual)
            )
            assert 0

    # Simple cases
    test("", "1.0", True)
    test(" ", "1.0", False)
    test("#", "1.0", False)
    test("x", "1.0", True)
    test(" ", "1.1", True)
    test("x #", "1.0", True)
    test("x #", "1.2", False)

# Generated at 2022-06-24 08:13:10.298590
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    string = "foo()\nbar('x', 'y'\n     'z')"
    parser = RoughParser(string, indent_width=4, tabwidth=8)
    assert parser.get_continuation_type() == C_STRING_FIRST_LINE

    string = "'foo'\n'spam'\n'spam'\n"
    parser = RoughParser(string, indent_width=4, tabwidth=8)
    assert parser.get_continuation_type() == C_STRING_NEXT_LINES

    string = "foo()\nbar(\n)"
    parser = RoughParser(string, indent_width=4, tabwidth=8)
    assert parser.get_continuation_type() == C_BRACKET

    string = "foo()\nbar()\\\n"

# Generated at 2022-06-24 08:13:16.929401
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=redefined-builtin
    p = RoughParser()
    p.set_str("""
if a:
    if b:
        aaa
        bbb
""")
    assert "    " * 3 == p.get_base_indent_string()

    # pylint: disable=redefined-builtin
    p = RoughParser()
    p.set_str("""
if a:
    if b:
        aaa
        bbb
    else:
        bbb
""")
    assert "    " * 3 == p.get_base_indent_string()

    # pylint: disable=redefined-builtin
    p = RoughParser()

# Generated at 2022-06-24 08:13:27.212441
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    tp = TestCase("__init__")
    # Some reasonable collection of indentation rules
    text = Text("", "", "", "", "")  # a reasonable empty Text
    text.indent_width = 4
    text.tabwidth = 8

    # A parser just capable of handling the full test string
    hp = HyperParser(text, "1.0")

    # Now a small collection of test cases
    # (indexstring, is_in_string?, is_in_code?,
    #   get_expression)

# Generated at 2022-06-24 08:13:34.925337
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()
    rp.set_str("if a:\n    pass\n")
    assert rp.get_base_indent_string() == "    "
    assert rp.get_num_lines_in_stmt() == 2

    rp.set_str("print(a)\n")
    assert rp.get_base_indent_string() == ""
    assert rp.get_num_lines_in_stmt() == 1

    rp.set_str("if a:\n    print(b)\n")
    assert rp.get_base_indent_string() == "    "
    assert rp.get_num_lines_in_stmt() == 2

    rp.set_str("if a:\n    print(b)\n\nprint(c)\n")

# Generated at 2022-06-24 08:13:41.309217
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from tkinter import Tk, Text

    root = Tk()
    text = Text(root)


# Generated at 2022-06-24 08:13:46.097607
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    t = StringTranslatePseudoMapping({}, ord('_'))
    assert t[1] == ord('_')
    t = StringTranslatePseudoMapping({1: 123}, ord('_'))
    assert t[1] == 123
    assert t[2] == ord('_')



# Generated at 2022-06-24 08:13:56.320661
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-24 08:14:05.373670
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    h = HyperParser("if True:\n\tpass\n", "insert")
    h.set_index("1.0")
    assert h.is_in_code()
    h.set_index("1.3")
    assert h.is_in_code()
    h.set_index("1.4")
    assert h.is_in_code()
    h.set_index("1.5")
    assert not h.is_in_code()
    h.set_index("1.6")
    assert not h.is_in_code()
    h.set_index("2.0")
    assert not h.is_in_code()
    h.set_index("2.1")
    assert h.is_in_code()
    h.set_index("2.2")
    assert h

# Generated at 2022-06-24 08:14:17.110733
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    # import used classes and functions
    from lib2to3.pgen2 import token
    from lib2to3.pytree import Leaf
    from lib2to3.pygram import python_symbols as syms
    from lib2to3 import fixer_base
    from lib2to3.fixer_util import Name
    from unittest import TestCase
    import __main__

    # mock a node
    class node_mock(object):
        # mock a node
        def __init__(self, children):
            # constructor
            self.children = children
            self.type = syms.if_stmt
        def prefix(self):
            # mock the prefix method
            return ""
    # Initialize test cases

# Generated at 2022-06-24 08:14:24.104404
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    rp = RoughParser("a,b\nc,d")
    rp.find_good_parse_start()
    assert rp.goodparse_start == 0
    rp = RoughParser("a,b\n\nc,d\n")
    rp.find_good_parse_start()
    assert rp.goodparse_start == 0
    rp = RoughParser("a,b\n\n\nc,d\n")
    rp.find_good_parse_start()
    assert rp.goodparse_start == 0
    rp = RoughParser("\na,b\n\nc,d\n")
    rp.find_good_parse_start()
    assert rp.goodparse_start == 1
    rp = RoughParser("a,b\n \nc,d\n")


# Generated at 2022-06-24 08:14:37.343427
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    """
    >>> rp = RoughParser('a = (1 + (2 + 3)) + 4')
    >>> rp.get_last_stmt_bracketing()
    ((0, 0), (1, 1), (2, 2), (3, 2), (4, 1), (5, 0), (6, 0), (7, 1), (8, 0), (9, 0))
    """


# Return the string from the last interesting stmt up to but not
# including the first interesting char following it.
# This may contain multiple physical lines.

    def get_leading_lines(self):
        self._study2()
        p1, p2 = self.stmt_start, self.stmt_end
        return self.str[p1:p2]


# Same as get_leading_lines, but only the last physical

# Generated at 2022-06-24 08:14:42.691426
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    t = StringTranslatePseudoMapping({}, 0)
    assert t.__getitem__(1) == 0

    t = StringTranslatePseudoMapping({"a": 1}, 0)
    assert t.__getitem__("a") == 1
    assert t.__getitem__(1) == 0
    assert t.__getitem__("x") == 0



# Generated at 2022-06-24 08:14:50.475854
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    import re
    
    # structure:
    # position of first interesting character
    # position of last interesting character
    # position of last non-whitespace character
    # indentation string (or None if there is no indentation)

# Generated at 2022-06-24 08:15:00.655977
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    # pylint: disable=redefined-builtin
    # pylint: disable=too-many-statements

    # fiddle with this code to get different test cases
    s = """\
a=1
while 1:
  try:
    if 1:
      pass
  finally:
    pass
"""
    parsed = RoughParser(s, 0)
    parsed.set_str(s)
    parsed.set_indent_width(4)
    parsed.set_tabwidth(8)

    assert parsed.get_continuation_type() == "C_NONE"
    assert not parsed.is_block_closer()
    s = s + "  "
    parsed.set_str(s)
    assert parsed.get_continuation_type() == "C_NONE"
    assert parsed.is_block

# Generated at 2022-06-24 08:15:04.713267
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    class Subclass(StringTranslatePseudoMapping):
        def __init__(self):
            super().__init__({ord(c): 0 for c in string.ascii_letters}, 1)
    assert Subclass().get(0) == 1
    assert Subclass().get(1) == 1
    for c in string.ascii_letters:
        assert Subclass().get(ord(c)) == 0
    assert Subclass().get(ord(' ')) == 1

# Generated at 2022-06-24 08:15:10.930343
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    """Test __iter__ of StringTranslatePseudoMapping"""
    global _chew_ordinaryre
    _expected = '^[\](){}#\'"\\]+'
    _received = _chew_ordinaryre.pattern
    assert _received == _expected, '\n    Received: %s\n    Expected: %s' % (_received, _expected) # noqa: W505
    return



# Generated at 2022-06-24 08:15:20.503081
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    r = RoughParser("a = \\\n  b")
    assert r.compute_backslash_indent() == 2
    r = RoughParser("a = \\\n  b\\\n  c")
    assert r.compute_backslash_indent() == 2
    r = RoughParser("a = \\\n  b \\\n  c")
    assert r.compute_backslash_indent() == 2
    r = RoughParser("a = b\\\n  + c")
    assert r.compute_backslash_indent() == 6
    r = RoughParser("a = b \\\n  + c")
    assert r.compute_backslash_indent() == 6
    r = RoughParser("a = b +\\\n  c")
    assert r.compute_back