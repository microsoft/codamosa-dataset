

# Generated at 2022-06-24 08:05:23.247002
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # pylint: disable=redefined-builtin
    rp = RoughParser('', 0, 0)
    rp.set_lo('abc', 4)
    assert (rp.goodlines == [4, 5])
    assert (rp.continuation == C_NONE)
    rp.set_lo('.\n', 2)
    assert (rp.goodlines == [2, 3])
    assert (rp.continuation == C_BACKSLASH)
    rp.set_lo('ab\n.\n', 2)
    assert (rp.goodlines == [2, 4])
    assert (rp.continuation == C_BACKSLASH)
    rp.set_lo('a:\n  b\n.\n', 2)

# Generated at 2022-06-24 08:05:31.863118
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    rp = RoughParser(single_mode=True)
    def chk(s, expected):
        rp.set_str(s)
        actual = rp.get_continuation_type()
        assert actual == expected, "{!r}.get_continuation_type() == {!r}, should be {}".format(
            s, actual, expected
        )

    for s in ("", " ", "\n", "a", "  # comment"):
        chk(s, C_NONE)

    chk("a = \\", C_BACKSLASH)
    chk("a = \\\n", C_BACKSLASH)
    chk("a = \\\n b", C_BACKSLASH)
    chk("b = \\\n", C_BACKSLASH)

# Generated at 2022-06-24 08:05:44.235893
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import unittest

    TESTS = [
        # The following two test cases were fixed in
        # http://bugs.python.org/issue17039
        (
            ''''#' #''',
            ("", "", "", "", "#", " "),
        ),
        (
            ''''#' #''',
            ("", "", "", "", "#", " "),
        ),
    ]

    class TestHyperParser(unittest.TestCase):
        def setUp(self):
            self.text = Text()
            self.text.insert("insert", "")

        def test_is_in_code(self):
            """Test HyperParser.is_in_code"""

            for text, ci in TESTS:
                self.text.delete("1.0", "end")
               

# Generated at 2022-06-24 08:05:49.187601
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    def test(code, expected_indent, expected_extra_indent):
        base_indent = " " * expected_indent
        p = RoughParser(code, tabwidth=4, indentwidth=4)
        assert p.compute_backslash_indent() == expected_indent
        if expected_extra_indent:
            extra_indent = " " * expected_extra_indent
        else:
            extra_indent = ""
        assert p.get_base_indent_string() == base_indent

        # Rough Parser always indent new lines with 8 spaces,
        # the question here is how many spaces the next line
        # will be indented.
        next_line_indent = expected_indent + expected_extra_indent
        assert p.indent_next_line() == extra_ind

# Generated at 2022-06-24 08:05:53.414535
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """Check HyperParser.set_index(self, index)"""

    import doctest

    doctest.testmod()


if __name__ == "__main__":
    test_HyperParser_set_index()

# Generated at 2022-06-24 08:06:04.284063
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test_expression(text, result):
        h = HyperParser(text, "%d.0" % len(text))
        if h.get_expression() != result:
            raise AssertionError(
                'Expression "%s" expected, but got "%s"' % (result, h.get_expression())
            )

    test_expression("hi there", "there")
    test_expression("hi.there", "there")
    test_expression("hi.there(", "there")
    test_expression("hi.there[", "there")
    test_expression("hi.there ", "there")
    test_expression("hi.there.", "there")
    test_expression("hi.there#", "there")
    test_expression("hi.there#bla", "there")


# Generated at 2022-06-24 08:06:09.832112
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    m = StringTranslatePseudoMapping({},0)
    assert iter(m) == iter({})
    m = StringTranslatePseudoMapping({1:1, 2:2},0)
    assert iter(m) == iter({1:1, 2:2})


# Generated at 2022-06-24 08:06:12.951740
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    p = re.compile(r"""
\s+
""",
                   re.VERBOSE)
    match = p.match('a@# * b')
    assert match.end() == 3



# Generated at 2022-06-24 08:06:25.135302
# Unit test for constructor of class RoughParser
def test_RoughParser():
    def test(s, continuation, base_indent_string, start, end):
        p = RoughParser(s)
        assert p.continuation == continuation
        assert p.get_base_indent_string() == base_indent_string
        assert p.stmt_start == start
        assert p.stmt_end == end

    test("""\
if 1:
    if 2:
        pass
""", C_NONE, "    ", 10, 21)
    test("""\
if 1:
    if 2:
        if 3:
            pass
""", C_NONE, "        ", 21, 32)
    test("""\
if 1:
    if 2:
        if 3:
            pass""", C_BRACKET, "        ", 21, 32)

# Generated at 2022-06-24 08:06:29.661047
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    # "len(StringTranslatePseudoMapping(dict(a=1, b=2), 3))"
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    assert len(mapping) == 4, mapping

# Generated at 2022-06-24 08:06:40.563140
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    # pylint: disable=redefined-builtin
    #
    # Testcase 1:
    #
    #     a = [a,
    #             ] = b
    #
    # (This is an unusual Python construction, but it's legal.)
    #
    # First line has two open brackets, the first one is the "last"
    # one, because it's latest to the right.  Second line has one close
    # bracket but no open bracket, so the "last" open bracket
    # position is the one on line 1.

    text = 'a = [a,\n] = b'
    p = RoughParser(text)
    p._study2()
    assert p.get_last_open_bracket_pos() == 2

    # Testcase 2:
    #
    #     a = (b,
   

# Generated at 2022-06-24 08:06:52.945998
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    S = """
    hi
    there
    bob
    """
    obj = RoughParser(S, '')
    assert obj.find_good_parse_start() == 0

    S = """
        hi
        there
        bob
    """
    obj = RoughParser(S, '')
    assert obj.find_good_parse_start() == 0

    S = """    hi
    there
    bob
    """
    obj = RoughParser(S, '')
    assert obj.find_good_parse_start() == 0

    S = """# hi
    there
    bob
    """
    obj = RoughParser(S, '')
    assert obj.find_good_parse_start() == 0

    S1 = """# hi
    """
    S2 = """there
    bob
    """
    S = S1

# Generated at 2022-06-24 08:06:58.771933
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'
#unit test for method removeescapes of class PythonSrc

# Generated at 2022-06-24 08:07:10.970329
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():

    class Mock_Text:
        "Mock a text widget."

        def __init__(self, str, indent_width, tabwidth):
            self._str = str
            self.indent_width = indent_width
            self.tabwidth = tabwidth

        def get(self, a, b):
            "Mock for text.get."
            return self._str[int(a) : int(b)]

        def index(self, str):
            "Mock for text.index."
            return str

    class Test:
        "Perform a test."

        def __init__(self, str, index, result):
            self.str = str
            self.index = index
            self.result = result

        def perform(self):
            "Perform the test and check whether the result is as expected."

# Generated at 2022-06-24 08:07:15.694115
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    """ >>> class Foo(RoughParser): pass
    ...
    >>> f = Foo()
    >>> f.set_lo("abc")
    >>> f.set_lo("def")
    >>> f.set_lo("def")
    >>> f.set_lo("ghi")
    >>> f.get_line_offset()
    abcdefghi
    """
    pass


# Generated at 2022-06-24 08:07:23.582700
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # Tests all the cases from __init__, including
    # a string with no newline, and several same line errors.
    h = HyperParser("def f(abc):\n  abc + 2\n", "1.0")
    assert h.indexinrawtext == 0
    h = HyperParser("def f(abc):\n  abc + 2\n", "1.1")
    assert h.indexinrawtext == 1
    h = HyperParser("def f(abc):\n  abc + 2\n", "1.2")
    assert h.indexinrawtext == 2
    h = HyperParser("def f(abc):\n  abc + 2\n", "1.3")
    assert h.indexinrawtext == 3

# Generated at 2022-06-24 08:07:34.163577
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    hp = HyperParser("", "")
    hp.isopener = []
    hp.rawtext = ""
    hp.indexinrawtext = 0
    hp.indexbracket = 0
    assert not hp.is_in_string()
    hp.isopener = [1]
    hp.rawtext = "''"
    hp.indexinrawtext = 1
    hp.indexbracket = 0
    assert not hp.is_in_string()
    hp.rawtext = "  ''' "
    hp.indexinrawtext = 2
    hp.indexbracket = 0
    assert hp.is_in_string()
    hp.isopener = [0, 1]
    hp.rawtext = "  ''' '"
    hp.indexinrawtext = 4
    hp.indexbracket = 1

# Generated at 2022-06-24 08:07:46.854292
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import textwrap
    test_str = textwrap.dedent(
        """\
        a=[
            ['a', 'b'],
            # comment
            ('c', 'd'),
            'e',
            # comment
            'f',
            'g'
            ]
        """
    )
    parser = RoughParser()
    parser.set_str(test_str)
    bod = parser.find_good_parse_start(_build_char_in_string_func("1.0"))
    parser.set_lo(bod)


# Generated at 2022-06-24 08:07:57.909804
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # pylint: disable=redefined-builtin,too-many-branches
    # pylint: disable=too-many-locals,too-many-statements
    # pylint: disable=invalid-name
    """Simply call unittest.main, which will execute the below tests."""

    import unittest


# Generated at 2022-06-24 08:08:01.765700
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    from tests import test_roughparser
    test_roughparser.test_get_last_stmt_bracketing(RoughParser)


# Return true if token starts a triple-quoted string.  If so, set
# token_start_line to the line number where the string starts.

# Generated at 2022-06-24 08:08:11.447128
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(s, expr):
        # Build an index in the middle of s.
        i = len(s) // 2
        while not s[i].isalnum():
            i += 1
        h = HyperParser(SimpleEditWindow(None), "1.0+%dc" % i)
        assert h.get_expression() == expr

    test("", "")
    test("x", "x")
    test("abc xyz", "abc")
    test("abc.xyz", "xyz")
    test("abc .xyz", "abc")
    test("abc . xyz", "xyz")
    test("abc .xyz xyz", "xyz")
    test("abc .  xyz", "xyz")
    test(". ", "")
    test("x.", "")

# Generated at 2022-06-24 08:08:24.882557
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-24 08:08:30.244877
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    import random
    keys = [random.randint(1, 100) for i in range(10)]
    values = [random.randint(1, 100) for i in range(10)]
    default = random.randint(1, 100)

    mapping = StringTranslatePseudoMapping(dict(zip(keys, values)), default)
    for key in keys:
        assert mapping.get(key) == values[keys.index(key)]
    for key in [x for x in range(1, 100) if x not in keys]:
        assert mapping.get(key) == default



# Generated at 2022-06-24 08:08:32.046575
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser("foo")
    assert not rp.is_block_opener()


# Generated at 2022-06-24 08:08:40.115914
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-24 08:08:47.633320
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    parser = RoughParser("""\
if True:
    a = 1
    if True:
        a = 1
        if True:
            a = 1
            if True:
                a = 1
    b = 2
    if True:
        a = 1
        if True:
            a = 1
            if True:
                a = 1
                if True:
                    a = 1
    c = 2""")
    assert parser.compute_bracket_indent() == 8

# Generated at 2022-06-24 08:08:48.963484
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # Tests are in Demo/idle/demo-RoughParser.py
    pass


# Generated at 2022-06-24 08:08:55.848894
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    # The last bracket is the opening of a list so the method
    # should return its position
    str = "list(x,y,\nzip(a"
    rough_parser = RoughParser(str, 0)
    assert rough_parser.get_last_open_bracket_pos() == 8
    # No bracket after the last bracket
    # at the end of the line
    str = "list(x,y,\nzip(a))"
    rough_parser = RoughParser(str, 0)
    assert rough_parser.get_last_open_bracket_pos() == 8
    assert rough_parser.is_block_closer()



# Generated at 2022-06-24 08:09:08.905762
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-24 08:09:18.766309
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    def cb(str_, stmt_start, stmt_end, lastch, lastopenbracketpos,
               continuation, study_level, tabwidth, firstlno):
        rough_parser = RoughParser(str_, tabwidth, firstlno)
        return rough_parser.is_block_closer()

    # any number of spaces, then \n, then any number of spaces, then
    # one of )}]
    string = "   \n   {}"
    parse_compare(cb, "is_block_closer", string, 1)


# Generated at 2022-06-24 08:09:26.784889
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def helper(s, tabwidth=8, expectwidth=None):
        r = RoughParser(s, tabwidth)
        w = r.compute_bracket_indent()
        if expectwidth is not None:
            assert w == expectwidth
            return
        print("(%s) => %d" % (s, w))

    helper(
        s=(
            "['a',\n"
            '    (1, 2),\n'
            '    {"a"\n'
            "      : 1,\n"
            '      "b": 2\n'
            "    }\n"
            "]\n"
        )
    )



# Generated at 2022-06-24 08:09:38.468956
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from unittest import TestCase

    class Test_HyperParser_get_surrounding_brackets(TestCase):
        def setUp(self):
            self.hp = HyperParser(None, None)

        def check(self, text, openers, mustclose, result):
            self.hp.rawtext = str(text)
            self.hp.bracketing = _build_bracketing(text)
            self.hp.isopener = [
                i > 0
                and self.hp.bracketing[i][1] > self.hp.bracketing[i - 1][1]
                for i in range(len(self.hp.bracketing))
            ]
            self.hp.indexbracket = len(text)
            self.hp.indexinrawtext = len(text)
            self.assertE

# Generated at 2022-06-24 08:09:46.647305
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rp = RoughParser("", 0)
    rp.str = 'x[i, :] = foo("""}\\n\\n""", x[0, :])\n'
    rp.continuation = rp.C_BRACKET
    rp.lastopenbracketpos = rp.str.find("[")
    rp.indent_width = 8
    rp.tabwidth = 8
    assert rp.compute_bracket_indent() == 16
 

# Generated at 2022-06-24 08:09:54.485430
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # This text is actually unimportant (only len is relevant)
    text = Text("ABCDE")
    hyper = HyperParser(text, "1.0")
    # We are certainly in a code, since we are at the beginning
    assert hyper.is_in_code()
    # A comment is not code
    text.insert("1.0", "# Here we add a comment\n")
    hyper = HyperParser(text, "1.7")
    assert not hyper.is_in_code()
    # A string is not code
    text.insert("2.0", "''' Here we add a string\n")
    hyper = HyperParser(text, "2.7")
    assert not hyper.is_in_code()
    # Neither is a doc string

# Generated at 2022-06-24 08:10:03.320069
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    p = RoughParser("o, [k, i, j] = l", indent_width=4)
    assert p.get_last_open_bracket_pos() == 7
    p = RoughParser("o, k, j] = l", indent_width=4)
    assert p.get_last_open_bracket_pos() is None
    p = RoughParser("o, [k, i] = l", indent_width=4)
    assert p.get_last_open_bracket_pos() is None
    p = RoughParser("x.y[a] = f", indent_width=4)
    assert p.get_last_open_bracket_pos() == 7
    p = RoughParser("x.y[a", indent_width=4)

# Generated at 2022-06-24 08:10:15.345701
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():

    def check(text, index, expected):
        hp = HyperParser(text, index)
        result = hp.get_expression()
        if result != expected:
            print("Error: for index", index, "in text", text)
            print("Expected", expected, "got", result)

    check("foo.bar", "1.5", "foo")
    check('foo[1].bar', "1.8", "foo[1]")
    check('foo(1).bar', "1.8", "foo(1)")
    check('foo.bar().baz', "1.12", "foo.bar()")
    check('foo.bar().baz', "1.11", "bar()")
    check('foo.bar().baz', "1.10", "bar")

# Generated at 2022-06-24 08:10:21.832363
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import unittest

    class HyperParserTest(unittest.TestCase):
        def make_hyper(self, text, index):
            text = Text(text, "ascii")
            text.tag_configure("TODO", background="red", foreground="white")
            text.tag_add("TODO", "1.0", "end")
            return HyperParser(text, index)

        def test_is_in_code(self):
            h = self.make_hyper("if a:\n    pass\n", "1.0")
            self.assertEqual(h.is_in_code(), True)

            h = self.make_hyper("print 'hi'\n", "1.0")
            self.assertEqual(h.is_in_code(), True)

            h = self.make_

# Generated at 2022-06-24 08:10:34.872313
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    hp = HyperParser("(1+2)", "(1+2)".index("+"))
    assert hp.is_in_code()
    assert hp.get_surrounding_brackets() == ("(1+2)", "(1+2)")
    assert hp.get_surrounding_brackets("{") is None
    assert hp.get_surrounding_brackets("{", True) == ("(1+2)", "(1+2)")

    hp = HyperParser("{1+2}", "{1+2}".index("+"))
    assert hp.is_in_code()
    assert hp.get_surrounding_brackets() == ("{1+2}", "{1+2}")

# Generated at 2022-06-24 08:10:45.307956
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():

    def f(text):
        rp = RoughParser(text, indent_width=4, tabwidth=4)
        return rp.get_last_stmt_bracketing()

    assert f("") == None, "get_last_stmt_bracketing failed for '<empty string>'"

    assert f(" ") == ((1, 0),), "get_last_stmt_bracketing failed for '<space>'"

    assert f("hello") == ((0, 0), (5, 0)), "get_last_stmt_bracketing failed for 'hello'"

    assert f("def f(): # comment") == ((0, 0), (7, 1), (12, 0), (20, 1), (24, 0)), \
        "get_last_stmt_bracketing failed for 'def f(): # comment'"



# Generated at 2022-06-24 08:10:54.441871
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import TestCase

    class IsInCodeTestCase(TestCase):
        def _t(self, s, index, expected):
            h = HyperParser(s, index)
            got = h.is_in_code()
            self.assertEqual(
                expected, got,
                "%r expected at %r in %r, got %r" % (expected, index, s.get("1.0", END), got),
            )

        def test_comment_at_beginning(self):
            s = Text()
            s.insert("1.0", "# a comment\n2 + 3")
            self._t(s, "1.0", False)
            self._t(s, "1.4", False)
            self._t(s, "2.0", True)

# Generated at 2022-06-24 08:11:01.337850
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Text(None, {}, "    '     '")
    htext = HyperParser(text, "2.0")
    if htext.is_in_string():
        print("HyperParser_is_in_string: Test 1 of 8 Failed")
    text = Text(None, {}, '    "     "')
    htext = HyperParser(text, "2.0")
    if htext.is_in_string():
        print("HyperParser_is_in_string: Test 2 of 8 Failed")
    text = Text(None, {}, "    '   '   '")
    htext = HyperParser(text, "2.0")
    if not htext.is_in_string():
        print("HyperParser_is_in_string: Test 3 of 8 Failed")

# Generated at 2022-06-24 08:11:04.826772
# Unit test for constructor of class RoughParser
def test_RoughParser():
    r"""Test for RoughParser constructor.

    >>> p = RoughParser("foo = 'bar'")
    >>> p.get_base_indent_string()
    ''
    >>> p.is_block_opener(), p.is_block_closer()
    (False, False)
    >>> p.get_last_open_bracket_pos() is None
    True
    """



# Generated at 2022-06-24 08:11:07.132106
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    assert StringTranslatePseudoMapping(
            {1:2, 2:3},
            0
        ) == {1:2, 2:3}



# Generated at 2022-06-24 08:11:11.592609
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    t = StringTranslatePseudoMapping({"b": "B", "a": "A"}, "x")
    assert t["a"] == "A"
    assert t["b"] == "B"
    assert t["c"] == "x"

# Generated at 2022-06-24 08:11:21.926903
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    # Show that the mapping works like a dict when only the default value
    # is replaced.
    m = StringTranslatePseudoMapping({ord('a'): ord('b')}, ord('x'))
    assert m[ord('c')] == ord('x')

    # Show that the dict's values are used.
    assert m[ord('a')] == ord('b')

    # Check that the mapping behaves as a mapping, at least when just
    # looking at its keys.
    assert list(m.keys())[0] == ord('a')


# Replace strings, comments and blanks in the first N lines of text.
# Return list of the N stripped lines.


# Generated at 2022-06-24 08:11:25.777258
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    p = RoughParser("  [[], []]")
    assert p.compute_bracket_indent() == 2, repr(p.compute_bracket_indent())


# Generated at 2022-06-24 08:11:31.174928
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    """Tests RoughParser.set_lo"""
    r1 = RoughParser("spam(eggs, 1,", tabsize = 8, indentwidth = 4)
    r1.set_lo(-1)
    assert r1.get_continuation_type() == C_NONE, "1st failure"
    r2 = RoughParser("spam(eggs, 1,", tabsize = 8, indentwidth = 4)
    r2.set_lo(0)
    assert r2.get_continuation_type() == C_STRING_FIRST_LINE, "2nd failure"
    r3 = RoughParser("spam(eggs, 1,", tabsize = 8, indentwidth = 4)
    r3.set_lo(1)
    assert r3.get_continuation_type() == C_STRING_NEXT

# Generated at 2022-06-24 08:11:43.628444
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-24 08:11:55.234183
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=redefined-builtin

    # A Simple test
    s = "love = True\nif love:\n    print 'I love Python'\n"
    rp = RoughParser()
    rp.set_str(s)
    assert rp.get_num_lines_in_stmt() == 1
    assert rp.stmt_bracketing == ((0, 0), (7, 1), (30, 0))

    # Check for bug #117612: study should not crash
    s = "\\\n\\\n"
    rp.set_str(s)
    rp._study1()
    if VERBOSE:
        print("test_RoughParser_set_str: OK")



# Generated at 2022-06-24 08:12:02.886506
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    parser = RoughParser("# comment\n")
    assert parser.is_block_closer()
    parser = RoughParser("if a: # comment\n")
    assert not parser.is_block_closer()
    parser = RoughParser("if a:\n")
    assert not parser.is_block_closer()
    parser = RoughParser("if a:\n    if b: # comment\n")
    assert parser.is_block_closer()
    parser = RoughParser("if a:\n    if b:\n")
    assert parser.is_block_closer()
    parser = RoughParser("if a:\n    if b:\n    else:\n")
    assert parser.is_block_closer()
    parser = RoughParser("if a:\n    if b:\n    else:\n        return # comment\n")
   

# Generated at 2022-06-24 08:12:13.865230
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    p = RoughParser("    if True:\n    \n    \n    print(Welcome!)\n")
    assert p.get_base_indent_string() == "    "
    p = RoughParser("    if True:\n    \n    print(Welcome!)\n")
    assert p.get_base_indent_string() == "    "
    p = RoughParser("if True:\n    \n    print(Welcome!)\n")
    assert p.get_base_indent_string() == ""
    p = RoughParser("    if True:\n    \n\nprint(Welcome!)\n")
    assert p.get_base_indent_string() == ""
    p = RoughParser("    if True:\n    \n    print(Welcome!)")

# Generated at 2022-06-24 08:12:21.947276
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    parser = RoughParser()


# Generated at 2022-06-24 08:12:27.304806
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # test continuation types
    rp = RoughParser("x = 3")
    eq_(rp.get_continuation_type(), C_NONE)

    rp = RoughParser("x = [1\n2\n3]")
    eq_(rp.get_continuation_type(), C_BRACKET)

    rp = RoughParser("x = [1\n2\\\n3]")
    eq_(rp.get_continuation_type(), C_BRACKET)

    rp = RoughParser("x = '''\n1\n2\n3\n'''")
    eq_(rp.get_continuation_type(), C_STRING_FIRST_LINE)

    rp = RoughParser("x = '''\n1\n2\n3\n4'''")

# Generated at 2022-06-24 08:12:38.107520
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest
    import test.test_support

    def test_get_expression(self, source, index, expected_result):
        self.index = index
        self.assertEqual(self.hp.get_expression(), expected_result)

    class TestCase(unittest.TestCase):
        def runTest(self):
            text = self.text
            index = self.index
            expected = self.expected
            hp = HyperParser(text, index)
            result = hp.get_expression()
            if isinstance(expected, str):
                self.assertEqual(result, expected)
            else:
                self.assertTrue(expected(result))


# Generated at 2022-06-24 08:12:50.176671
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    assert HyperParser("# code", "1.0").is_in_code() == False
    assert HyperParser("# code", "1.1").is_in_code() == False
    assert HyperParser("# code\n", "2.0").is_in_code() == False
    assert HyperParser("\"string\"", "1.0").is_in_code() == False
    assert HyperParser("\"string\"", "1.1").is_in_code() == False
    assert HyperParser("\"string\"", "1.2").is_in_code() == False
    assert HyperParser("\"string\"", "1.3").is_in_code() == False
    assert HyperParser("\"string\"", "1.4").is_in_code() == False
    assert HyperParser("\"string\"", "1.5").is_

# Generated at 2022-06-24 08:13:03.369329
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    r = RoughParser("""\
x = "asdfasd\\\\
asdfasdf" + 'asdfasdf\\
asdfasdf' + \\\
'''asdfasdf\\
asdfasdf''' + \\\
r"asdfasdf\\
asdfasfd"
y = "asdfasd" + 'asdfasdf' + '''asdfasdf''' + r"asdfasdf"
""")

# Generated at 2022-06-24 08:13:16.125765
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    assert RoughParser("{0}").is_block_closer()
    assert RoughParser("f()").is_block_closer()
    assert RoughParser("for x in y:").is_block_closer()
    assert RoughParser("end").is_block_closer()
    assert RoughParser("end.").is_block_closer()
    assert RoughParser("end?.").is_block_closer()
    assert RoughParser("}").is_block_closer()
    assert RoughParser("  }").is_block_closer()
    assert RoughParser("x = ").is_block_closer()
    assert RoughParser("x ||=").is_block_closer()
    assert RoughParser("x ?=").is_block_closer()
    assert RoughParser("x +=").is_block_closer()


# Generated at 2022-06-24 08:13:26.357844
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-locals

    def test_goodline(p, expected):
        """Compare '1' with 'expected'"""
        goodline = p.get_num_lines_in_stmt()
        if goodline == expected:
            print("ok %d" % i)
        else:
            print("failed %d: expected %d, got %d" % (i, expected, goodline))

    # See also the test_get_num_lines_in_stmt function at the end
    # of this module, which is a kind of system test.

    # NOTES:
    # - '#' introduced in the middle of the continuation line may
    #   upset the

# Generated at 2022-06-24 08:13:34.932530
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    code = """def f():
    '''abc\nabc'''
    "abc\\nabc"
    """
    hp = HyperParser(code, "3.0")
    assert hp.is_in_string() == False
    hp = HyperParser(code, "3.1")
    assert hp.is_in_string() == False
    hp = HyperParser(code, "3.2")
    assert hp.is_in_string() == False
    hp = HyperParser(code, "3.3")
    assert hp.is_in_string() == False
    hp = HyperParser(code, "3.4")
    assert hp.is_in_string() == False
    hp = HyperParser(code, "3.5")
    assert hp.is_in_string() == True

# Generated at 2022-06-24 08:13:44.308307
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    _pseudomapping = StringTranslatePseudoMapping({'a': 1, 'b': 2}, 'default')
    _expected_iterable = {'a', 'b'}
    _iterable = set(_pseudomapping)
    assert _iterable == _expected_iterable, _iterable

test_StringTranslatePseudoMapping___iter__()


# Generated at 2022-06-24 08:13:52.894987
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    h = HyperParser("(a):1\n", "1.end")
    assert h.get_surrounding_brackets("(") == ("1.0", "1.2")
    assert h.get_surrounding_brackets("{[") == ("1.0", "1.2")
    assert h.get_surrounding_brackets("<") == None
    assert h.get_surrounding_brackets("(", mustclose=True) == None
    h = HyperParser("(a):1\n", "1.1")
    assert h.get_surrounding_brackets("(") == ("1.0", "1.2")
    assert h.get_surrounding_brackets("{[") == ("1.0", "1.2")
    assert h.get_surrounding_

# Generated at 2022-06-24 08:14:04.969903
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    if not running_idle:
        return

    root = Tk()

    text = Text(root)
    text.pack()
    text.insert("1.0", "0123456789\n0123456789\n0123456789\n")
    text.update()

    hp = HyperParser(text, "0.0")

    def ci(index):
        try:
            hp.set_index(index)
        except:
            text.mark_set("my_insert", "insert")
            text.see("my_insert")
            text.focus_set()
            raise

    ci("1.5")
    ci("1.end")
    ci("insert")
    ci("3.end lineend")
    ci("3.0")

# Generated at 2022-06-24 08:14:13.688610
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    assert StringTranslatePseudoMapping({}, 0) == {}
    mapping = StringTranslatePseudoMapping({1: 2}, 3)
    assert len(mapping) == 1
    assert 0 not in mapping
    assert 1 in mapping
    assert mapping[0] == 3
    assert mapping[1] == 2
    assert mapping.get(0) == 3
    assert mapping.get(1) == 2
    assert mapping.get(2, 4) == 4
    assert mapping.get(2) == 3



# Generated at 2022-06-24 08:14:21.893833
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-24 08:14:31.305296
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def check(text, index, expected_result):
        hp = HyperParser(text, index)
        res = hp.get_expression()
        if res != expected_result:
            raise ValueError(
                f"For text '{text[0:index+1]}','{text[index+1:]}' and "
                f"index {index}, get_expression() returned {res!r}"
                f" instead of {expected_result!r}"
            )

    # Empty code
    check("", 0, "")
    check("#\n", 1, "")
    check("\n\n", 0, "")
    # Syntax error
    check("[", 0, "")
    check("[, 1", 0, "")
    # Whitespace and comments

# Generated at 2022-06-24 08:14:44.755518
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expression):
        try:
            exp = HyperParser(text, index).get_expression()
            assert exp == expression, "Wrong expression %s (should be %s)" % (exp, expression)
        except AssertionError as e:
            print("Test failed: %s" % text)
            raise e

    test("""\
print
xxx
""", "1.0", "print")
    test("""\
print
foo
""", "1.0 lineend", "print")
    test("""\
print
foo
""", "1.1", "")
    test("""\
print
foo
""", "1.4", "")
    test("""\
print
foo
""", "2.0", "")

# Generated at 2022-06-24 08:14:51.284592
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    # cases where string contains no continuation
    cases = [
        ('x=2\ny=3', 1),
        ('\nx=2\ny=3', 1),
        ('\nx=2\n\n\ny=3', 2),
        ('x=2\n\n\ny=3', 3),
        ('x=2\n\n\ny=3\n\nz=5', 4),
    ]
    for src, expected in cases:
        parser = RoughParser(src, indent_width=4)
        n = parser.get_num_lines_in_stmt()
        assert n == expected, 'src=%r, n=%r, expected=%r' % (src, n, expected)

    # cases where string contains continuation

# Generated at 2022-06-24 08:14:59.520194
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    string = """asdf
    asdf
    asdffgh
    asdf
    """
    parser = RoughParser(string, 0)
    assert parser.get_num_lines_in_stmt() == 3

    string = """asdf
    asdf
    asdf
    """
    parser = RoughParser(string, 0)
    assert parser.get_num_lines_in_stmt() == 2

    string = """asdf
    asdf
    asdf
    """
    parser = RoughParser(string, 0)
    assert parser.get_num_lines_in_stmt() == 2



# Generated at 2022-06-24 08:15:08.078727
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # This is a class for use by get_surrounding_brackets in the following tests.
    class HyperParserTest:
        def __init__(self, text, index):
            # This is as in HyperParser.
            self.indexbracket = 0
            self.indexinrawtext = len(text) - len(text.get(index, len(text)))
            self.stopatindex = len(text)
            self.text = text
            self.rawtext = text
            # This is a trick - treat the tuple as a list
            bracketing = [0] * len(text)
            for i in range(len(text)):
                bracketing[i] = (i, 0)
            self.bracketing = bracketing
            self.isopener = [False] * len(text)


# Generated at 2022-06-24 08:15:14.406943
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    def t(test, expect):
        assert RoughParser(test).get_num_lines_in_stmt() == expect
    yield t, "", 0
    yield t, "\n", 0
    yield t, "foo\n", 1
    yield t, "foo\n#bar\n", 1
    yield t, "foo\\\n    bar\n", 1
    yield t, "foo\nbar\n", 2
    yield t, "foo\n    bar\n", 2


# end of class RoughParser

# ______________________________________________________________________
# Determine the indentation of a continuation line.

