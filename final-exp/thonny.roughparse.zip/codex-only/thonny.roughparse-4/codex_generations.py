

# Generated at 2022-06-24 08:05:23.559716
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    # pylint: disable=redefined-builtin
    line = """
if True:
    print('hello')
elif False:
    print('world')
else:
    print('!')
    if True:
        print('!')
    else:
        print('!')
    print('!')
"""
    r = RoughParser(line)
    # get_last_stmt_bracketing
    last_stmt_bracketing = r.get_last_stmt_bracketing()
    print("last_stmt_bracketing=", last_stmt_bracketing, "\n")

# Generated at 2022-06-24 08:05:31.791939
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-24 08:05:35.044433
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    r = RoughParser("    if True:\n        pass\n")
    assert r.get_last_open_bracket_pos() == 4

# Generated at 2022-06-24 08:05:45.973054
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest
    import doctest
    from test.support import captured_stdout

    class TestHyperParser(unittest.TestCase):

        def setUp(self):
            self.root = Tk()
            self.root.withdraw()
            self.root.tk.call("set", "::tk::unsupported::MacWindowStyle", "plain")
            self.text = Text(self.root)
            self.text.pack()
            self.text.bind("<<set-line-and-column>>", self._set_line_and_column)
            self.text.event_add("<<set-line-and-column>>", "<KeyRelease>")
            self.line = StringVar()
            self.column = StringVar()
            lbl1 = Label(self.root, textvariable=self.line)
           

# Generated at 2022-06-24 08:05:53.780283
# Unit test for method set_str of class RoughParser

# Generated at 2022-06-24 08:06:04.164385
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-24 08:06:15.145879
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    assert RoughParser("").get_num_lines_in_stmt() == 0
    assert RoughParser("\n").get_num_lines_in_stmt() == 1
    assert RoughParser("\n\n").get_num_lines_in_stmt() == 2
    assert RoughParser("a\n").get_num_lines_in_stmt() == 1
    assert RoughParser("a\n\n").get_num_lines_in_stmt() == 2
    assert RoughParser("a\n\n\n").get_num_lines_in_stmt() == 3
    assert RoughParser("a\n\nb\n").get_num_lines_in_stmt() == 2
    assert RoughParser("#\n").get_num_lines_in_stmt() == 1

# Generated at 2022-06-24 08:06:20.620774
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    parser = RoughParser("if a < b \\\n    and c < d\n")
    assert parser.compute_backslash_indent() == 10
    parser = RoughParser("if 1 \\ \n    and 2\n")
    assert parser.compute_backslash_indent() == 6


# Generated at 2022-06-24 08:06:30.067626
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    import unittest
    from . import test_pyflakes_inputs as testinputs

    parens_inputs = testinputs.parens_inputs
    brackets_inputs = testinputs.brackets_inputs
    comments_inputs = testinputs.comments_inputs
    continuation_inputs = testinputs.continuation_inputs
    strings_inputs = testinputs.strings_inputs
    whitespace_inputs = testinputs.whitespace_inputs

    class TestRoughParser(unittest.TestCase):
        def test_parens(self):
            for orig_input, orig_goodlines in parens_inputs:
                rp = RoughParser(orig_input)
                self.assertEqual(tuple(rp.goodlines), orig_goodlines)


# Generated at 2022-06-24 08:06:34.337623
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    assert(StringTranslatePseudoMapping({}, 0) == {})
    assert(StringTranslatePseudoMapping({'foo': 'bar'}, 0) == {'foo': 'bar'})



# Generated at 2022-06-24 08:06:39.777057
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-24 08:06:46.515128
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-24 08:06:58.087250
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-24 08:07:04.052222
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    m = StringTranslatePseudoMapping({ord('x'): ord('y')}, ord('z'))
    assert m.get(ord('x')) == ord('y')
    assert m.get(ord('y')) == ord('z')
    assert m.get(ord('y'), ord('x')) == ord('x')
test_StringTranslatePseudoMapping_get()
del test_StringTranslatePseudoMapping_get



# Generated at 2022-06-24 08:07:13.281794
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest.mock import Mock
    from io import StringIO

    # _build_char_in_string_func() needs the text widget.
    text = Mock(spec=["index", "get"], name="text")

    def side_effect_index(index):
        """The index() method of text returns a float.
        """
        try:
            return int(float(index))
        except:
            raise ValueError("Bad index")

    text.index.side_effect = side_effect_index

    # HyperParser needs lines of text.
    def side_effect_get(index1, index2):
        """The get() method of text returns a text.

        It also checks that the argument are as expected.
        """
        l1 = int(float(index1))
        l2 = int(float(index2))

# Generated at 2022-06-24 08:07:20.962615
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    import sys
    if sys.flags.optimize >= 2:
        pytest.skip("test cannot run in optimized mode!")

    def f(input, result):
        text = input.strip()
        p = RoughParser(text, "utf-8")
        assert p.get_num_lines_in_stmt() == result

    f("x = \\", 1)
    f("x = \\\n \\", 2)
    f("x = 1 \\", 1)
    f("x = 1 \\\n \\", 2)
    f("x = '''\n \\", 2)
    f("x = ''' \\\n \\", 2)
    f("x = '''\\\n\\\n''' \\", 2)
    f("x = '''\\\n\\\n''' \n \\", 3)


# Generated at 2022-06-24 08:07:28.628158
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-24 08:07:31.863368
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    pass

# Generated at 2022-06-24 08:07:38.989653
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def check_is_in_code(text, index, result):
        hp = HyperParser(text, index)
        if result != hp.is_in_code():
            print(
                "HyperParser_is_in_code test failed: %r =/=> %r for text %r"
                % (index, result, text)
            )

    # The following example has only ASCII characters, to make the
    # error messages easier to read.
    check_is_in_code('x = "abc"', "insert", 1)
    check_is_in_code('x = "abc"', "insert-1c", 1)
    check_is_in_code('x = "abc"', "insert-4c", 0)
    check_is_in_code('x = "abc"', "insert-6c", 1)

# Generated at 2022-06-24 08:07:44.813899
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))

    # Test that iteration yields all the non-default values
    indices = set(mapping)
    assert indices == {9, 10, 13, 32}
    assert len(indices) == 4



# Generated at 2022-06-24 08:07:49.735017
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    mapping = StringTranslatePseudoMapping({}, 0)
    assert len(mapping) is 0
    assert list(mapping) == []
    mapping = StringTranslatePseudoMapping({"foo": 1}, 0)
    assert len(mapping) is 1
    assert list(mapping) == ["foo"]
    mapping = StringTranslatePseudoMapping({"foo": 1, "bar": 2}, 0)
    assert len(mapping) is 2
    assert sorted(list(mapping)) == ["bar", "foo"]

# Generated at 2022-06-24 08:07:59.275282
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    # Global scope
    parser = RoughParser('''
        #empty
    ''', 0)
    assert parser.get_last_open_bracket_pos() is None

    parser = RoughParser('''
        def f():
            pass
    ''', 0)
    assert parser.get_last_open_bracket_pos() is None

    parser = RoughParser('''
        class c:
            pass
    ''', 0)
    assert parser.get_last_open_bracket_pos() is None

    # Function scope
    parser = RoughParser('''
        def f():
            #empty
    ''', 0)
    assert parser.get_last_open_bracket_pos() > 0


# Generated at 2022-06-24 08:08:03.204973
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    for instance in [StringTranslatePseudoMapping({}, 0),
     StringTranslatePseudoMapping({0: 1}, 0),
     StringTranslatePseudoMapping({1: 2}, 3)]:
        for obj in instance.__iter__():
            assert isinstance(obj, int)



# Generated at 2022-06-24 08:08:11.880015
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    p = RoughParser()
    p.set_str("if baaa: pass\n")
    assert p.goodlines == [0, 14]
    assert p.continuation == C_NONE
    assert p.study_level == 1
    p.set_str("if baaa:\n    pass\n")
    assert p.goodlines == [0, 14]
    assert p.continuation == C_BRACKET
    assert p.study_level == 1
    p.set_str("if baaa:\n    pass\n")
    assert p.goodlines == [0, 14]
    assert p.continuation == C_BRACKET
    assert p.study_level == 1
    p.set_str("if baaa:\n    pass\n")
    assert p.goodlines == [0, 14]

# Generated at 2022-06-24 08:08:24.966617
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    def check(text, expected):
        actual = RoughParser(text).find_good_parse_start()
        assert defined(expected) == defined(actual), (
            "Expected %r, got %r" % (expected, actual)
        )
        # Don't make this check because the actual result may have a
        # different number of leading 0's
        #   assert expected == actual, (
        #       "Expected: %r Actual: %r" % (expected, actual))
    check("", None)
    check("\n", 0)
    check("\n # hi \n", 4)
    check(" # hi \n", 4)
    check(" # hi \n '''\n\n'''", 7)
    check("    # hi \n\n", 8)
    check("#", 1)

# Generated at 2022-06-24 08:08:32.155217
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    def check(s, continuation_type, s_lines=None):
        if s_lines is None:
            s_lines = s.splitlines(keepends=True)
        parser = RoughParser(s, len(s_lines), len(s_lines[0]))
        if parser.get_continuation_type() != continuation_type:
            print(s.strip())
            print("Continuation type should be %r, found %r" % (
                continuation_type, parser.get_continuation_type()))
        else:
            print("Correct: %r has continuation type %r" % (
                s.strip(), continuation_type))
    check("a = 1\nb = 2", C_NONE)
    check("a = 1\\\nb = 2", C_BACKSLASH)

# Generated at 2022-06-24 08:08:40.176342
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    assert RoughParser("").is_block_closer() is False  # no statements
    assert RoughParser(":").is_block_closer() is False  # just a colon
    assert RoughParser("hello").is_block_closer() is False  # no colon
    assert RoughParser("hello:").is_block_closer() is False  # colon not special
    assert RoughParser("return 42").is_block_closer() is False  # no colon
    assert RoughParser("else:").is_block_closer() is True
    assert RoughParser("hello else:").is_block_closer() is True
    assert RoughParser("hello\nelse:").is_block_closer() is True
    assert RoughParser("hello\r\nelse:").is_block_closer() is True

# Generated at 2022-06-24 08:08:48.665109
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    """

    :return:
    """
    source_string = """
    # comment code
    def f(a):
        if a > 1:
            return a * f(a - 1)
        """
    indent_string = "    "  # 4 spaces
    result = RoughParser(source_string, indent_string)
    print("-"*40)
    print("source code:")
    print(result.text)
    print("continuation type:", result.get_continuation_type())
    result.get_last_stmt_bracketing()
    print("last statement bracketing:", result.get_last_stmt_bracketing())
    last_bracket = result.get_last_open_bracket_pos()
    print("last open bracket position:", last_bracket)

# Generated at 2022-06-24 08:08:55.826993
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("a = b + [1, 2, 3]\n")
    rp.set_lo("""a = b+(1, 2, 3, # comment
        4, 5, 6, \\
        7)\n""")
    rp.set_lo("""a = b+(1, 2, 3, # comment
        4, 5, 6, \\
        7) - c\n""")

# Generated at 2022-06-24 08:09:08.859134
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    def test(s, expected):
        parser = RoughParser(s, len(s), 0)
        actual = parser.get_last_stmt_bracketing()
        assert actual == expected, "expected %s, got %s" % (expected, actual)

    test("", None)
    test("# hello", [(0, 0), (7, 0)])
    test("1", [(0, 0)])
    test("'hello'", [(0, 0), (7, 0)])
    test('"hello"', [(0, 0), (8, 0)])
    test("[1, 2, 3]", [(0, 0), (1, 1), (2, 2), (3, 3), (5, 2), (6, 1), (7, 0)])

# Generated at 2022-06-24 08:09:16.853278
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    whitespace_chars = " \t\n\r"  # type: str
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"



# Generated at 2022-06-24 08:09:27.234273
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = """\
    "hello" + "world"
    """
    hp = HyperParser(text, 6)
    assert hp.is_in_string()
    hp.set_index(7)
    assert not hp.is_in_string()
    hp.set_index(8)
    assert hp.is_in_string()
    hp.set_index(12)
    assert not hp.is_in_string()
    hp.set_index(13)
    assert not hp.is_in_string()



# Generated at 2022-06-24 08:09:30.829454
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    """Unit test for method is_in_string of class HyperParser

    """

# Generated at 2022-06-24 08:09:41.306886
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    assert RoughParser("    a = 1").get_base_indent_string() == "    "
    assert RoughParser("\ta = 1").get_base_indent_string() == "\t"
    assert RoughParser("a = 1").get_base_indent_string() == ""
    assert RoughParser("    a = 1\n    ").get_base_indent_string() == "    "
    assert RoughParser('    a = 1\n    # Foo\n    ').get_base_indent_string() == "    "
    assert RoughParser('    a = 1\n    """\n    ').get_base_indent_string() == "    "
    assert RoughParser('    a = 1\n    """\n    ').get_base_indent_string() == "    "

# Generated at 2022-06-24 08:09:51.715948
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    # pylint: disable=redefined-builtin, protected-access
    # pylint: disable=too-many-locals, too-many-branches, too-many-statements
    # pylint: disable=too-many-public-methods
    txt = """\
if a:
    b
    if c:
        d
    elif e:
        f
    else:
        g
h
""".strip()
    printer = StringIO()
    parser = RoughParser(txt, printer, tabwidth=8)
    parser.set_str(txt)
    parser._study2()

# Generated at 2022-06-24 08:10:01.794068
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-24 08:10:14.146040
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    h = HyperParser(
        """
      [r"string",
        (1,2, 3
            )    ,
      {'dict': 'value'},
      ]""",
        "sel.first",
    )
    h.set_index("sel.first")
    assert h.get_surrounding_brackets() == ("1.14", "1.28")
    assert h.get_surrounding_brackets(mustclose=True) == ("1.14", "1.28")
    h.set_index("1.16")
    assert h.get_surrounding_brackets() == ("1.14", "1.28")
    assert h.get_surrounding_brackets(mustclose=True) == ("1.14", "1.28")

# Generated at 2022-06-24 08:10:20.237721
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo(0, 10, 1)
    print(rp.lo, rp.hi, rp.lno)
    rp.set_lo(20, 30, 3)
    print(rp.lo, rp.hi, rp.lno)
    rp.set_lo(0, 20, 2)
    print(rp.lo, rp.hi, rp.lno)
    rp.set_lo(15, 25, 3)
    print(rp.lo, rp.hi, rp.lno)


# Generated at 2022-06-24 08:10:31.401467
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # id is not a keyword but is a builtin which is a keyword =>
    # iskeyword() returns True for it
    text = Text()

# Generated at 2022-06-24 08:10:44.732024
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-24 08:10:56.581866
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def check(str, w):
        parser = RoughParser(str, 1)
        got = parser.compute_bracket_indent()
        assert got == w

    # Test on a few statements, where we know the indentation should be 4.
    check("{", 4)
    check("{a, b = [\n", 5)
    check("{a: {b: 3}}", 6)
    check("{a,\n{b,\n{c,\n", 6)
    check("{a,\n{b,\n{c,\n}", 6)
    check("{a,\n{b,\n{c,\n}}", 6)
    check("{a,\n{b,\n{c,\n}}\n", 6)

# Generated at 2022-06-24 08:11:07.149101
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    @parametrize('non_defaults, default_value, expected_iter', [
        ({}, 'x', []),
        ({'a': 1}, 'x', ['a']),
        ({'a': 1, 'b': 2}, 'x', ['a', 'b']),
    ])
    def do(non_defaults, default_value, expected_iter):
        actual_iter = list(StringTranslatePseudoMapping(non_defaults,
                                                        default_value))
        assert_equal(actual_iter, expected_iter)

    do()


# Generated at 2022-06-24 08:11:12.086105
# Unit test for method set_index of class HyperParser

# Generated at 2022-06-24 08:11:23.223818
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-24 08:11:25.743831
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    """Test method __len__ of class StringTranslatePseudoMapping"""

    # Example 1: length of an empty mapping should be 0
    mapping = StringTranslatePseudoMapping({}, None)
    assert len(mapping) == 0



# Generated at 2022-06-24 08:11:30.386715
# Unit test for constructor of class RoughParser
def test_RoughParser():
    rp = RoughParser("\n\n\n     \n")
    assert rp.goodlines == [0, 4, 5]
    assert rp.continuation == C_NONE

    rp = RoughParser("\\\n  \\\n   \\\n")
    assert rp.goodlines == [0, 1, 2, 3]
    assert rp.continuation == C_BACKSLASH

    rp = RoughParser("[\n  1,\n  2,\n]\n")
    assert rp.goodlines == [0, 1, 2, 3]
    assert rp.continuation == C_BRACKET

    rp = RoughParser("x = [\n  1,\n  2,\n]\n")

# Generated at 2022-06-24 08:11:43.583900
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    # pylint: disable=redefined-builtin

    def test_close_bracket(s):
        rp = RoughParser(s)
        return rp.is_block_closer()

    # The following Python program is used to generate combinations of
    # lines and comments; the problem is that triple-quoted strings
    # may contain triple-quoted strings and comments, so we need to
    # have the program itself produce the test cases.
    #
    # The format of each line of the input is
    #     line comment
    # where:
    #   line can be:
    #      one of the following literals
    #          "", "f", "n", "k", "i", "t", "s", "x", "e", "t", "y", "p", "q"
    #      or a string

# Generated at 2022-06-24 08:11:48.520422
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    rp = RoughParser("# comment\n(1)\n")
    assert rp.get_last_stmt_bracketing() == ((0,0), (2,1), (3,0))

# Generated at 2022-06-24 08:11:56.051736
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    p = RoughParser()
    p.set_lo("\ntoday\n  \n  \n  \n  \n  \n  \n  \n  \n  \n  \n  ")
    assert p.get_good_lines() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    assert p.get_num_lines() == 13
    assert p.get_continuation_type() == C_NONE
    assert p.get_last_open_bracket_pos() is None


# Generated at 2022-06-24 08:12:00.604932
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser("", 0)
    rp.set_lo("foo")
    assert rp.study_level == 0
    assert rp.lo == "foo"

# Generated at 2022-06-24 08:12:12.109047
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Text()
    text.insert("1.0", "a(b) 'c'.find('d') e[f]")
    hp = HyperParser(text, text.index("1.10"))
    assert hp.is_in_string()
    hp = HyperParser(text, text.index("1.11"))
    assert not hp.is_in_string()
    hp = HyperParser(text, text.index("1.16"))
    assert not hp.is_in_string()
    hp = HyperParser(text, text.index("1.17"))
    assert hp.is_in_string()
    hp = HyperParser(text, text.index("1.22"))
    assert not hp.is_in_string()
    hp = HyperParser(text, text.index("1.23"))

# Generated at 2022-06-24 08:12:20.661948
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    parser = RoughParser()

# Generated at 2022-06-24 08:12:26.984830
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    #
    def check(str_, expected, expected_continuation=0, expected_lines=None, expected_lastopenbracketpos=None, expected_bracketing=None, study_level=1):  # @ReservedAssignment
        rp = RoughParser()
        rp.set_str(str_)
        if expected_lines is None:
            expected_lines = [0, len(expected)]
        assert rp.str == expected
        assert rp.study_level == study_level
        assert rp.continuation == expected_continuation
        assert rp.goodlines == expected_lines
        assert rp.lastopenbracketpos == expected_lastopenbracketpos
        assert rp.stmt_bracketing == expected_bracketing

    #

# Generated at 2022-06-24 08:12:32.666109
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def check(code, expect):
        if isinstance(code, str):
            code = code.split("\n")
        text = tkinter.Text()
        text.insert("insert", "\n".join(code))
        hp = HyperParser(text, "insert")
        got = hp.get_expression()
        ok = (got[: -len(expect)] == expect) if expect else not got
        if not ok:
            # Print some context information.
            print("-" * 40)
            for i, line in enumerate(code):
                print("%3d: %s" % (i + 1, line))
            print("-" * 40)
            print("got  = ", got)
            print("want = ", expect)
            print("-" * 40)
        assert ok


# Generated at 2022-06-24 08:12:34.690731
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # see http://bugs.python.org/issue7206
    RoughParser("x = '''\\\nfoo").compute_backslash_indent()


# Generated at 2022-06-24 08:12:45.104469
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-24 08:12:55.369326
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest
    import test.test_support

    class TestCase(unittest.TestCase):
        def check_expression(self, source, result, line, col):
            tr = Text(source)
            tr.mark_set("insert", "%d.%d" % (line, col))
            obj = HyperParser(tr, "insert")
            self.assertEqual(obj.get_expression(), result)

        def test_get_expression(self):
            # Some simple examples
            self.check_expression("a", "", 1, 1)
            self.check_expression("a", "a", 1, 2)
            self.check_expression("a+b", "", 1, 1)
            self.check_expression("a+b", "a", 1, 2)

# Generated at 2022-06-24 08:13:01.158620
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rp = RoughParser("if a\nif b:", 0)
    assert rp.get_num_lines_in_stmt() == 2
    rp = RoughParser("if a\n  if b:", 0)
    assert rp.get_num_lines_in_stmt() == 1
    rp = RoughParser("if a:\n  if b:", 0)
    assert rp.get_num_lines_in_stmt() == 1
    rp = RoughParser("if a\n  if b:", 4)
    assert rp.get_num_lines_in_stmt() == 1
    rp = RoughParser("if a:\n  if b:", 4)
    assert rp.get_num_lines_in_stmt() == 1

# Generated at 2022-06-24 08:13:05.211400
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    hp = HyperParser('spam = "eggs"', '1.7')
    assert hp.is_in_string()
    hp.set_index('1.4')
    assert not hp.is_in_string()



# Generated at 2022-06-24 08:13:18.083601
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest.mock import Mock

    text = Mock()
    text.index.side_effect = lambda index: str(index)

    def side_effect(index):
        if index == "1.0":
            return "a[b, (c, d)][e]\n"

    text.get.side_effect = side_effect

    hyper_parser = HyperParser(text, "9.0")

    hyper_parser.set_index("16.0")
    assert (hyper_parser.indexbracket, hyper_parser.indexinrawtext) == (8, 8)
    hyper_parser.set_index("15.0")
    assert (hyper_parser.indexbracket, hyper_parser.indexinrawtext) == (7, 7)
    hyper_parser.set_index("14.0")

# Generated at 2022-06-24 08:13:30.313780
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest.mock import Mock

    def mock_get(s, e):
        if s == "1.0" and e == "end":
            return text
        elif e == "1.0" and s == "end":
            return ""
        return text.get(s, e)

    def mock_index(i):
        return str(i)

    text = Mock(spec=("get", "index"))
    text.get = mock_get

    text.index = mock_index

    hyper = HyperParser(text, "1.0")

    text = "abcd efgh.abc" + """ ijkl
    mnop
    qrst
    """
    assert hyper.is_in_code()


# Generated at 2022-06-24 08:13:42.768629
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-24 08:13:44.085617
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():  # TODO: unit test
    pass



# Generated at 2022-06-24 08:13:52.770252
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-24 08:14:04.900922
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    from test.support import import_fresh_module

    # Each test case is a string with a single character which
    # represents that character as it should appear in the Text widget.
    # The number before the character is the column number of the
    # character. The number after the character is the expected return
    # value of is_in_string.
    #
    # The column numbers don't matter unless the test string contains
    # a tab (which is represented as '>'). The tab expands to four
    # spaces.

# Generated at 2022-06-24 08:14:16.894869
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("a = (\n", 2)
    assert rp.continuation == C_BRACKET
    rp.set_lo("a = (\n\nb", 2)
    assert rp.continuation == C_BRACKET
    rp.set_lo("a = (\n\nb\nc", 2)
    assert rp.continuation == C_NONE
    rp.indent_width = 2
    rp.set_lo("a = (\n\nb", 2)
    assert rp.continuation == C_BRACKET
    rp.set_lo("a = (\n\nb  ", 2)
    assert rp.continuation == C_BRACKET
    # 62791: mutating string passed to set_lo


# Generated at 2022-06-24 08:14:23.967254
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-24 08:14:37.118475
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():

    def test(s, w):
        assert w == RoughParser(s).compute_backslash_indent()

    # test basic cases
    test("hello", 6)
    test("  hello", 8)
    test("hello\\", 6)
    test("  hello\\", 8)

    # test tabs and mixed tabs and spaces
    test("\thello", 7)
    test("\t  hello", 9)
    test("\thello\\", 7)
    test("\t  hello\\", 9)
    test("\t  hello\t\\", 9)
    test("  \thello", 9)
    test("  \t  hello", 11)
    test("  \thello\\", 9)
    test("  \t  hello\\", 11)

# Generated at 2022-06-24 08:14:45.061502
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    text = """\
if test:
    try:
        if self.path:
            if self.path.endswith(os.extsep + "py"):
                self.is_py_src = 1
"""
    rp = RoughParser(text)
    assert rp.is_block_opener() == False
    rp.set_str(text + "    pass\n")
    assert rp.is_block_opener() == True
    rp.set_str(text + "    pass")
    assert rp.is_block_opener() == False

# Generated at 2022-06-24 08:14:53.141285
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """Test the method HyperParser.set_index()."""

    def test_set_index(parser, index, expected_result):
        """Test the method set_index()."""
        parser.set_index(index)
        r = parser.get_expression()
        if r != expected_result:
            return "For %s got %s, expected %s." % (index, r, expected_result)

    h = HyperParser("def g():\n    if True:\n        a=5", "4.4")
    assert test_set_index(h, "4.4", "5") == None
    assert test_set_index(h, "4.3", "a") == None
    assert test_set_index(h, "4.2", "if True") == None

# Generated at 2022-06-24 08:14:58.615420
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"


# Generated at 2022-06-24 08:15:03.945498
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    parser = RoughParser("print(123)")
    continuation_type = parser.get_continuation_type()
    assert continuation_type == C_NONE # nothing interesting

    parser = RoughParser("print(123\\\n456)")
    continuation_type = parser.get_continuation_type()
    assert continuation_type == C_BACKSLASH # nothing interesting

    parser = RoughParser("print(123[456]\\\n789)")
    continuation_type = parser.get_continuation_type()
    assert continuation_type == C_BRACKET # nothing interesting

    # examples from the documentation
    parser = RoughParser("""if (1 ==
    2): pass""")
    continuation_type = parser.get_continuation_type()
    assert continuation_type == C_NONE # nothing interesting


# Generated at 2022-06-24 08:15:13.520191
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()
    #
    # Test 1
    #
    rp.set_str("")
    assert rp.get_continuation_type() == 0
    assert rp.get_num_lines_in_stmt() == 1
    #
    # Test 2
    #
    rp.set_str("foo")
    assert rp.get_continuation_type() == 0
    assert rp.get_num_lines_in_stmt() == 1
    #
    # Test 3
    #
    rp.set_str("foo\\")
    assert rp.get_continuation_type() == 1
    assert rp.get_num_lines_in_stmt() == 1
    #
    # Test 4
    #

# Generated at 2022-06-24 08:15:15.685138
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    """
    >>> test_string = "        hello world"
    >>> parser = RoughParser(test_string)
    >>> parser.get_base_indent_string()
    '        '
    """



# Generated at 2022-06-24 08:15:23.653493
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    test_cases = {
        "a := (2, 3, 4)\n": False,
        "a := (2, 3, 4)": False,
        "a := (2, 3, 4)\nelse:\n": True,
        "a := (2, 3, 4)\n" * 2 + "else:\n": True,
        "a := (2, 3, 4)\n" * 2 + "else:": True
    }
    for program, expected_result in test_cases.items():
        with tempfile.TemporaryDirectory() as temp_dir:
            path_to_file = os.path.join(temp_dir, "file.txt")
            with open(path_to_file, "w") as program_file:
                program_file.write(program)