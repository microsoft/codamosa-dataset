

# Generated at 2022-06-24 08:05:18.333288
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def test_valid(s, indent):
        got = RoughParser(s).compute_bracket_indent()

# Generated at 2022-06-24 08:05:25.603378
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # Provides a number of test cases for the method
    # RoughParser.compute_backslash_indent.
    #
    # The test cases below could be written as doctest strings, but
    # currently, they're not.  This function is not intended to be
    # called, so it shouldn't matter.

    # pylint: disable=bad-whitespace, missing-docstring


    class Dummy:
        # Dummy class for simulating RoughParser objects

        def __init__(self, str):
            self.tabwidth = 8
            self.indent_width = 4
            self.str = str


# Generated at 2022-06-24 08:05:30.712445
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    tmap = StringTranslatePseudoMapping({}, 'x')
    assert tmap.get(ord('(')) == 'x'
    assert tmap.get(ord('x'), 'y') == 'y'
    tmap = StringTranslatePseudoMapping({ord('('): ord('x')}, 'x')
    assert tmap.get(ord('(')) == 'x'
    assert tmap.get(ord('x'), 'y') == 'y'


# Generated at 2022-06-24 08:05:38.216822
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    preserve_dict = {ord('x'): ord('x'), ord('y'): ord('y')}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('z'))
    assert mapping['x'] == ord('x')
    assert mapping['y'] == ord('y')
    assert mapping['z'] == ord('z')
    assert len(mapping) == 2
    assert set(mapping) == set(['x', 'y'])
    assert mapping.get('x') == ord('x')
    assert mapping.get('y') == ord('y')
    assert mapping.get('z') == ord('z')



# Generated at 2022-06-24 08:05:39.130356
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-24 08:05:45.789162
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    """Test the method HyperParser.get_surrounding_brackets.
    """
    import unittest
    import test.test_support

    # Some helper functions
    def check(text, index, openers, mustclose, mustopen, start, end):
        """Test the method get_surrounding_brackets of the HyperParser.

        It is expected to return ((start, end), mustopen).
        """
        text = Text(text)
        parser = HyperParser(text, index)
        # print text.get("1.0", "end"), repr(index)
        res = parser.get_surrounding_brackets(openers, mustclose)
        if (res, mustopen) != ((start, end), mustopen):
            print

# Generated at 2022-06-24 08:05:48.784479
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    d = {"12":2, 3:"5"}
    mapping=StringTranslatePseudoMapping(d, 10)
    assert mapping.get("123")==10
    assert mapping.get("12")==2
    assert mapping.get(3)=="5"


# Generated at 2022-06-24 08:05:50.234150
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    assert RoughParser.find_good_parse_start("\n \n \n \n") == 3


# Generated at 2022-06-24 08:06:00.651364
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import unittest as ut
    import textwrap as tw
    class TestHyperParser(ut.TestCase):
        def do_test(self, code, expected):
            testfunc = lambda: self.assertEqual(
                [HyperParser(code, '%dc' % i).is_in_code() for i in range(len(code) + 1)],
                expected
            )
            self.assertTrue(testfunc is not None)
            testfunc()


# Generated at 2022-06-24 08:06:08.112046
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    while 1:
        if not len(sys.argv) > 1:
            print("Give a filename as argument")
            return
        try:
            f = open(sys.argv[1], "r")
        except IOError:
            print("%s does not exist" % sys.argv[1])
            return
        break
    text = f.read()
    f.close()
    hp = HyperParser(text, "1.0")

    while 1:
        line = input("line number: ")
        try:
            line = int(line)
        except ValueError:
            return
        index = repr(line) + ".0"
        try:
            hp.set_index(index)
        except ValueError:
            print("Invalid index.")
            continue

# Generated at 2022-06-24 08:06:17.655458
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    from .pprint import pformat
    from lib2to3.pgen2.parse import ParseError

    def find_good_parse_start(code):
        #p(code)
        parser = RoughParser(code)
        n = parser.find_good_parse_start()
        #p(code.split('\n')[parser.lno0:parser.lno0 + parser.lno1])
        #print('Good parse start at line %d, offset %d/%d' % (parser.lno1,
        #                                                     n, len(code)))
        try:
            # FIXME: This won't be needed with --no-future-unicode
            parser.compile('<string>')
        except ParseError:
            pass # pparse() will show error
        #pprint(parser.rs

# Generated at 2022-06-24 08:06:28.672495
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class Test(unittest.TestCase):
        def doTest(self, text, index, expected):
            self.assertEqual(HyperParser(text, index).get_expression(), expected)

    test = Test("get_expression")

    test.doTest("a = 1", "end", "")
    test.doTest("a = 1", "1.0", "a")
    test.doTest("a = 1", "1.0 lineend", "a")
    test.doTest("a = 1 + 2", "end", "")
    test.doTest("a = 1 + 2", "2.0", "1")
    test.doTest("a = 1 + 2", "1.0", "a")
    test.doTest("a = 1+2", "end", "")
    test

# Generated at 2022-06-24 08:06:39.669863
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import sys, time
    if sys.version[:3] != "2.2":
        return
    f = open("unittest_HyperParser_set_index.py", "w")
    f.write("x = (1\n" " +2)")
    f.close()
    text = Text()
    text.file_open(f.name)

# Generated at 2022-06-24 08:06:46.436240
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    # pylint: disable=redefined-builtin

    for t in [
        "if True: return True",
        "if True: try: return True",
        "if True: finally: return True",
        "try: return True",
        "try: return True\nexcept: pass",
        "try: return True\nfinally: return True",
        "try: return True\nexcept: pass\nfinally: return True",
        "return True\n" * 20 + "return False",
    ]:
        assert RoughParser(t).is_block_closer()


# Generated at 2022-06-24 08:06:51.556156
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    parser = RoughParser("if True:\n    a\nb", tabwidth=0)
    assert parser.is_block_opener()

    parser = RoughParser("a\nb", tabwidth=0)
    assert not parser.is_block_opener()



# Generated at 2022-06-24 08:07:01.050671
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-24 08:07:06.818905
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    """
    >>> test_RoughParser_get_last_open_bracket_pos()
    """
    def check(s, openpos):
        parser = RoughParser(s, indent_width=4, tabwidth=8)
        assert parser.get_last_open_bracket_pos() == openpos

    check("foo(\n\n)", 3)
    check("foo([\n\n", 3)
    check("foo{\n\n", 3)
    check("foo\n([\n\n", 5)
    check("foo\n[\n\n", 5)
    check("foo\n{\n\n", 5)
    check("foo(a,\n\n)", 1)
    check("foo[a,\n\n", 1)

# Generated at 2022-06-24 08:07:07.874378
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    pass


# Generated at 2022-06-24 08:07:11.785532
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    """Unit test for method __len__ of class StringTranslatePseudoMapping"""
    # see https://docs.python.org/3/library/unittest.mock.html
    # <<<
    # or, see https://docs.python.org/3/library/unittest.mock.html#basic-patching
    # >>>


# Generated at 2022-06-24 08:07:19.966897
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-24 08:07:28.109007
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    r = RoughParser("foo = \\", 0)
    assert r.compute_backslash_indent() == 4
    r = RoughParser("foo = \\", 4)
    assert r.compute_backslash_indent() == 8
    r = RoughParser("foo = \\\n    x", 4)
    assert r.compute_backslash_indent() == 8
    r = RoughParser("foo = x + \\\n    \\", 4)
    assert r.compute_backslash_indent() == 8
    r = RoughParser("foo = x + \\\n    \\", 9)
    assert r.compute_backslash_indent() == 13
    r = RoughParser("foo = \\\n    x\nbar = \\\n    y", 4)
    assert r.compute_

# Generated at 2022-06-24 08:07:37.976255
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    eq = unittest.TestCase().assertEqual

    eq(HyperParser("bla (bla", 5).get_surrounding_brackets(mustclose=True), None)
    eq(HyperParser("bla (bla)", 5).get_surrounding_brackets(), ("1.0", "8.0"))
    eq(HyperParser("(bla).bla", 5).get_surrounding_brackets(), ("0.0", "7.0"))
    eq(HyperParser("(bla).bla", 6).get_surrounding_brackets(), None)
    eq(HyperParser("(bla).bla", 7).get_surrounding_brackets(), None)

# Generated at 2022-06-24 08:07:48.596868
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser(None, 0)

    rp.set_str("# this is a comment\n")
    assert rp.get_base_indent_string() == ""
    assert rp.get_continuation_type() == C_NONE
    assert not rp.is_block_opener()
    assert not rp.is_block_closer()
    assert rp.get_last_open_bracket_pos() is None

    rp.set_str('"""\n')
    assert rp.get_continuation_type() == C_STRING_FIRST_LINE

    rp.set_str('"\\\n')
    assert rp.get_continuation_type() == C_STRING_FIRST_LINE

    rp.set_str('#\\\n')
   

# Generated at 2022-06-24 08:07:54.615533
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    """Unit test for method __len__ of class StringTranslatePseudoMapping
    """
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    default_value = ord("x")
    mapping = StringTranslatePseudoMapping(preserve_dict, default_value)
    assert len(mapping) == len(whitespace_chars)

# Generated at 2022-06-24 08:08:04.165694
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    parser = RoughParser("a = b")
    assert parser.is_block_closer() == False
    parser = RoughParser("a = b\n")
    assert parser.is_block_closer() == False
    parser = RoughParser("a = b:\n")
    assert parser.is_block_closer() == False
    parser = RoughParser("a = b\nwhile a < 2:\n    print(a)\na = a + 1")
    assert parser.is_block_closer() == True
    parser = RoughParser("a = b\nwhile a < 2:\n    print(a)\na = a + 1\n")
    assert parser.is_block_closer() == True

# Generated at 2022-06-24 08:08:12.613114
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()
    rp.set_str("line1\n\tline2\n\tline3")
    assert rp.str == "line1\n\tline2\n\tline3"
    assert rp.study_level == 0
    assert rp.goodlines == [0, 5, 10]
    assert rp.continuation == C_NONE
    assert rp.lastch == ""
    assert rp.lastopenbracketpos is None
    #assert rp.stmt_bracketing == None
    assert rp.stmt_start == 5
    assert rp.stmt_end == 10

# Generated at 2022-06-24 08:08:25.292101
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    # 0. Test on empty input
    rp = RoughParser('')
    assert rp.get_last_stmt_bracketing() is None

    # 1. Test on non-empty input
    rp = RoughParser('''
    # a comment
    ''')
    assert rp.get_last_stmt_bracketing() == ((0, 0), (24, 0))
    # 2. Test on non-empty input
    rp = RoughParser('''
    [1,
    # a comment
    ''')
    assert rp.get_last_stmt_bracketing() == ((0, 0), (2, 1), (20, 0))
    # 3. Test on non-empty input

# Generated at 2022-06-24 08:08:32.409077
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    def check_get_continuation_type(src, expected_continuation):
        """
        :param src: source of python text
        :param expected_continuation: expected value of
            RoughParser.get_continuation_type
        """
        assert RoughParser(src).get_continuation_type() == expected_continuation

    check_get_continuation_type("", C_NONE)

    check_get_continuation_type(
        "abc\nabc",
        C_NONE,
    )

    check_get_continuation_type(
        "abc\n\\\nabc",
        C_BACKSLASH,
    )


# Generated at 2022-06-24 08:08:40.418271
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    # test1_src="# comment line\nif True:\n    for i in range(4):\n        print('a', end='')"
    test1_src = "if True:\n    for i in range(4):\n        print('a', end='')"
    test1_expected = 5

    test2_src = "if True:  # comment line\n    for i in range(4):\n        print('a', end='')"
    test2_expected = 5

    test3_src = "if True:\n    for i in range(4):\n        print('a', end='')  # comment line"
    test3_expected = None

    rp = RoughParser(test1_src)
    assert rp.get_last_open_bracket_pos() == test1_expected

   

# Generated at 2022-06-24 08:08:48.836247
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    r = RoughParser("\n    if True:\n        pass\n")
    assert r.is_block_opener()
    r1 = RoughParser("\n    if True:\n        pass")
    assert not r1.is_block_opener()
    r2 = RoughParser("\n    if True:\n        pass# this is a comment\n")
    assert r2.is_block_opener()
    r3 = RoughParser("\n    if True:\n        pass # this is a comment\n")
    assert r3.is_block_opener()



# Generated at 2022-06-24 08:09:00.150453
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-24 08:09:11.297002
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = idlelib.idle_test.mock_tk_text.MockText()
    # The data is made such that if a char is inside a string, it is
    # followed by an odd number of backslashes.
    # We initialize the text with a newline, so that indexes won't
    # be at the beginning of the line, so that its status will be
    # the same as the char before it, if should.
    text.insert("insert", "\\\n")
    text.insert("insert", "'''")
    text.insert("insert", "\\\n")
    text.insert("insert", "'\\\n")
    text.insert("insert", "'")
    text.insert("insert", "\\\n")
    text.insert("insert", "'")
    text.insert("insert", "\\\n")

# Generated at 2022-06-24 08:09:23.612914
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():

    # Test cases:
    #  - i is the index of an opening bracket;
    #  - i is the index of the closing bracket with the same number;
    #  - i is the index of the closing bracket with a different number.
    #  - i is beyond the last closing bracket.

    # 0. Test on an empty string
    p = _RoughParser("")
    assert p.get_last_open_bracket_pos() is None

    # 1. Test on a string without brackets
    p = _RoughParser("abc")
    assert p.get_last_open_bracket_pos() is None

    # 2. Test on a string with one opening bracket: a b ([ c ] d)
    p = _RoughParser("a b ([ c ] d)")
    assert p.get_last_open_bracket_pos

# Generated at 2022-06-24 08:09:25.413111
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rp = RoughParser()
    rp.set_str("foo\\\nbar\\\nbaz")
    assert 3 == rp.get_num_lines_in_stmt()
    return rp


# Generated at 2022-06-24 08:09:37.386944
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest
    from test.support import requires

    class TestHyperParser(unittest.TestCase):
        # test for issue14294

        def test_set_index(self):
            text = "  str.lstrip(' ')"
            parser = HyperParser(text, 4)
            self.assertEqual(parser.get_expression(), "str")
            self.assertTrue(parser.is_in_code())

            parser.set_index(5)
            self.assertEqual(parser.get_expression(), "str")
            self.assertTrue(parser.is_in_code())

            parser.set_index(6)
            self.assertEqual(parser.get_expression(), "")
            self.assertTrue(parser.is_in_code())

            parser.set_index(7)

# Generated at 2022-06-24 08:09:42.773066
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rp = RoughParser('''
x = 1
y = 2 # comment
z = 3\
''')
    assert rp.get_continuation_type() == 0
    assert rp.get_num_lines_in_stmt() == 3


# Generated at 2022-06-24 08:09:50.483608
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    p = RoughParser()
    p.set_str("def foo(): pass")
    p.get_continuation_type()
    p.set_str("def foo(): pass # foo")
    p.get_continuation_type()
    p.set_str("def foo(): pass\nproc(x,\\")
    p.get_continuation_type()



# Generated at 2022-06-24 08:10:00.949938
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = "foo('bar' + 'baz')"
    h = HyperParser(text, index="3.0")
    assert h.is_in_string() is False, "is_in_string should be False before opening quote"
    h = HyperParser(text, index="3.1")
    assert h.is_in_string() is True, "is_in_string should be True inside string"
    h = HyperParser(text, index="3.6")
    assert h.is_in_string() is True, "is_in_string should be True inside string"
    h = HyperParser(text, index="3.7")
    assert h.is_in_string() is False, "is_in_string should be False after closing quote"
    h = HyperParser(text, index="4.1")
    assert h

# Generated at 2022-06-24 08:10:13.392093
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    """Test for the get_last_stmt_bracketing method of the RoughParser class"""

    rough_parser = RoughParser(text)
    bracketing = rough_parser.get_last_stmt_bracketing()
    print(bracketing)

    # The displayed tuple doesn't look like a bracketing, partly because
    # it includes offsets within the string instead of line numbers;
    # it also includes positions at the beginning and end of strings
    # and comments.  The sample text has no strings or comments, so
    # if you look at the tuple positions that are tuples of the form
    # (offset, bracket level), you'll see that they correspond to
    # the bracketing structure you get from the sample text when you
    # strip off all the comments, strings and backslashes.

    # The bracketing tuple is in the format used by the

# Generated at 2022-06-24 08:10:19.893402
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rough_parser = RoughParser("  for i in [1,2,3]:\n")
    assert rough_parser.compute_bracket_indent() == 2
    rough_parser = RoughParser("  try:\n")
    assert rough_parser.compute_bracket_indent() == 2
    rough_parser = RoughParser("  try:\n    print(hello)\n")
    assert rough_parser.compute_bracket_indent() == 4



# Generated at 2022-06-24 08:10:29.219733
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    """Test that StringTranslatePseudoMapping.get() behaves as expected"""
    mapping = StringTranslatePseudoMapping({ord('c'): ord('x'),
                                            ord('d'): ord('y')},
                                           ord('z'))
    assert mapping.get(ord('a')) == ord('z')
    assert mapping.get(ord('c')) == ord('x')
    assert mapping.get(ord('d')) == ord('y')
    assert mapping.get(ord('e')) == ord('z')



# Generated at 2022-06-24 08:10:38.728613
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-24 08:10:44.853241
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    """
    >>> # Test case 1
    >>> h = HyperParser(tk.Text(None, '1.0', 'end'))
    >>> h.set_index('1.0')
    >>> h.get_expression()
    ''
    >>> # Test case 2
    >>> h = HyperParser(tk.Text(None, '1.0', 'end'))
    >>> h.set_index('1.0')
    >>> h.get_expression()
    ''
    """

# Generated at 2022-06-24 08:10:46.970107
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({42: 43}, 44)
    assert mapping.get(42) == 43
    assert mapping.get(41, 42) == 42
    assert mapping.get(41) == 44



# Generated at 2022-06-24 08:10:58.266186
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    class TestParse:
        def __init__(self, test, result):
            self.test = test
            self.result = result


# Generated at 2022-06-24 08:11:07.568147
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = Text(None)
    text.insert('1.0', "([{)]}")
    text['1.0'] = '1.0'
    text['1.end'] = '1.end'
    parser = HyperParser(text, '1.0')
    assert parser.get_surrounding_brackets() == ('1.3', '1.4'), parser.get_surrounding_brackets()
    text = Text(None)
    text.insert('1.0', "([{)}")
    text['1.0'] = '1.0'
    text['1.end'] = '1.end'
    parser = HyperParser(text, '1.0')
    assert parser.get_surrounding_brackets() == ('1.3', '1.3'), parser.get_surrounding_

# Generated at 2022-06-24 08:11:17.149994
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest
    import unittest.mock
    from tkinter import Text

    class Test(unittest.TestCase):
        text = Text()
        text.insert("1.0", "x = a + b\n")
        text.mark_set("insert", "2.2")

        def test1(self):
            "Test that setting the index to a valid place works."
            HyperParser(self.text, "1.0").set_index(1.0)
            HyperParser(self.text, "insert").set_index("insert")
            with self.assertRaises(ValueError):
                HyperParser(self.text, "1.0").set_index("insert")

    unittest.main(module=__name__, exit=False)

# Generated at 2022-06-24 08:11:18.658953
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    pass  # implemented by test_StringTranslatePseudoMapping

# Generated at 2022-06-24 08:11:26.990003
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-24 08:11:32.196500
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    # Create a pseudo mapping for translations.
    # The defaults are the same as for str.maketrans().
    # This pseudo mapping will translate each non-default character to
    # the value None.
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, default_value=None)
    # For the length of a character set for which we have no special
    # mappings, the length of the pseudo mapping should be 0.
    char_set = string.digits
    assert len(mapping) == 0
    # The pseudo mapping has a non-empty mapping for each character
    # that is neither in the default set nor in the character set
    # for which we

# Generated at 2022-06-24 08:11:43.978646
# Unit test for constructor of class RoughParser
def test_RoughParser():
    rp = RoughParser("#foo\nx = 1\n")
    rp = RoughParser("#foo\nx = 1\nx = 2\n")
    rp = RoughParser("#foo\nx = 1\n\nx = 2\n")
    rp = RoughParser("#foo\n#bar\nx = 1\n")
    rp = RoughParser("#foo\n#bar\n\nx = 1\n")
    # class RoughParser:
    #     def __init__(self, str, indent_width, tabwidth):
    #         self.str = str
    #         self.indent_width = indent_width
    #         self.tabwidth = tabwidth
    #         self.study_level = 0
    #         #
    #         # self.continuation = continuation

# Generated at 2022-06-24 08:11:55.720977
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # Test with an open bracket after a colon.
    rp = RoughParser("if foo: [")
    rp.set_lo(5)
    _assert(rp.level_stack == [0, 1])
    _assert(rp.lastopenbracketpos == 6)
    _assert(rp.lastopentokentype == tokenize.OP)

    # Test with an open bracket after a comment.
    rp = RoughParser("if True:  # comment\n  [")
    rp.set_lo(22)
    _assert(rp.level_stack == [0, 0])
    _assert(rp.lastopenbracketpos == 23)
    _assert(rp.lastopentokentype == tokenize.OP)

    # Test with an open bracket after a comment.
    rp

# Generated at 2022-06-24 08:12:01.807140
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    assert len(mapping) == len(whitespace_chars)



# Generated at 2022-06-24 08:12:13.102617
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = "def f():\n    if a:\n        return a.b\n"
    h = HyperParser(text, "1.0")
    assert h.get_expression() == ""
    h = HyperParser(text, "1.4")
    assert h.get_expression() == ""
    h = HyperParser(text, "2.0")
    assert h.get_expression() == "a"
    h = HyperParser(text, "2.4")
    assert h.get_expression() == "a"
    h = HyperParser(text, "3.0")
    assert h.get_expression() == ""
    h = HyperParser(text, "3.4")
    assert h.get_expression() == "a.b"
    h = HyperParser(text, "3.9")

# Generated at 2022-06-24 08:12:21.579933
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    class MockText:
        def __init__(self):
            self.tabwidth = 8
            self.indent_width = 4

        def index(self, index):
            return index

        def get(self, start, end):
            return self.input[int(start[:-2]) : int(end[:-2])]

    # Note: the following strings have 4 spaces at the beginning
    # and 2 at the end of each line.

# Generated at 2022-06-24 08:12:26.938908
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    # pylint: disable=redefined-outer-name, invalid-name, unused-variable
    def double_check(s, n):
        # pylint: disable=redefined-outer-name
        parser = RoughParser(s)
        n1 = parser.get_num_lines_in_stmt()
        n2 = (s + " ").split("\n")[-2].count("\n") + 1
        assert n1 == n2 == n
    #
    double_check("a = '''\\\nprint\n'''\n", 2)
    double_check("a = '''print\n'''\n", 1)
    double_check("a = '''\nprint'''\n", 2)

# Generated at 2022-06-24 08:12:37.824955
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from tkinter import Tk, Frame, Text

    # Create a frame to hold the Text widget.
    root = Tk()
    frame = Frame(root)
    text = Text(frame)
    text.pack()
    frame.pack()

    # Insert a test string including various operators and strings.
    text.insert("1.0", "a = b.c + (d and e) + 'f' and g \\\\ h")

    # Define test cases.

# Generated at 2022-06-24 08:12:50.084559
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    cases = [
        ((dict(), 0), 0),
        ((dict([(1, 100)]), 0), 1),
        ((dict([(1, 100)]), 0), 1),
        ((dict([(1, 100), (2, 200)]), 0), 2),
        ((dict([(1, 100), (2, 200)]), 0), 2),
    ]
    for ((non_defaults, default_value), expected) in cases:
        # We do the following on purpose so that the variables are
        # defined locally to the lambda.
        non_defaults = non_defaults
        default_value = default_value
        result = StringTranslatePseudoMapping(non_defaults, default_value).__len__()

# Generated at 2022-06-24 08:12:57.066081
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-24 08:13:09.973766
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-24 08:13:19.488175
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.hp = HyperParser(text, index)

        def check(self, expression):
            self.assertEqual(self.hp.get_expression(), expression)

    # Mock the Text widget for the tests
    class Text:
        def __init__(self, index, string):
            self._string = string
            self._index = index

        def get(self, start, stop):
            return self._string[self.index(start) : self.index(stop)]

        def index(self, string):
            if string == "insert":
                return self._index
            elif string[-2:] == ".0":
                return int(string[:-2]) - 1

# Generated at 2022-06-24 08:13:29.865886
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-24 08:13:34.417198
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    s = "foo"
    expected = ""
    actual = RoughParser(s).get_base_indent_string()
    print(actual)
    assert expected == actual

    s = "    foo"
    expected = "    "
    actual = RoughParser(s).get_base_indent_string()
    print(actual)
    assert expected == actual

    s = """if True:
        foo"""
    expected = "        "
    actual = RoughParser(s).get_base_indent_string()
    print(actual)
    assert expected == actual


# Generated at 2022-06-24 08:13:46.662552
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():  # pylint: disable=invalid-name
    """Test function for method get_last_open_bracket_pos of class RoughParser."""
    def test(s, expected):
        """Test function for method get_last_open_bracket_pos of class RoughParser.

        Parameters
        ----------
        s : str
            String to test.
        expected : int
            The expected index of the last open bracket ({[.
        """
        rp = RoughParser(s)
        last_open_bracket_pos = rp.get_last_open_bracket_pos()
        if expected == last_open_bracket_pos:
            status = "OK"
        else:
            status = "FAIL"
        print("%s: %d %s" % (status, last_open_bracket_pos, s))

# Generated at 2022-06-24 08:13:57.020120
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Text()
    text.insert("1.0", "a = [11, 12,\n13]")
    hp = HyperParser(text, "1.0")
    assert hp.text == text
    assert hp.rawtext == "a = [11, 12,\n13"
    assert hp.isopener == [True, True, False]
    assert hp.bracketing == [[0, 0], [3, 1], [1, 1], [0, 1]]
    assert hp.stopatindex == "2.end"
    assert hp.indexinrawtext == 0
    assert hp.indexbracket == 0
    hp.set_index("1.end")
    assert hp.indexinrawtext == 1
    assert hp.indexbracket == 0
    hp.set_index("1.6")
    assert hp

# Generated at 2022-06-24 08:14:00.513497
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    x = RoughParser()
    x.set_str("class X:\n    pass")



# Generated at 2022-06-24 08:14:08.193523
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    def test(expected, s, index):
        hp = HyperParser(s, index)
        res = hp.is_in_string()
        if res != expected:
            print("Error:", repr(s), index, res)

    test(False, 'abc"def"', "1.0")
    test(True, 'abc "def"', "4.0")
    test(False, 'abc "def"', "5.0")

    test(False, 'abc"def"', "1.1")
    test(True, 'abc "def"', "4.1")
    test(False, 'abc "def"', "5.1")

    test(False, 'abc"def"', "1.2")
    test(True, 'abc "def"', "4.2")

# Generated at 2022-06-24 08:14:12.246367
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    p = RoughParser("""\
if 1:
    x = 1
    y = 2
z = 3
""")
    assert p.get_num_lines_in_stmt() == 3

# Generated at 2022-06-24 08:14:21.092631
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    assert RoughParser("").get_base_indent_string() == ""
    assert RoughParser(" ").get_base_indent_string() == " "
    assert RoughParser(" # comment").get_base_indent_string() == ""
    assert RoughParser("a = 12").get_base_indent_string() == ""
    assert RoughParser("a = 12 ").get_base_indent_string() == " "
    assert RoughParser("a = 12 # comment").get_base_indent_string() == ""
    assert RoughParser("a = 12 # comment ").get_base_indent_string() == " "
    assert RoughParser("if True:\n    a = 12").get_base_indent_string() == "    "
    assert RoughParser("if True:\n    a = 12# comment").get_base_ind

# Generated at 2022-06-24 08:14:26.784327
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=redefined-builtin
    r = RoughParser()
    r.set_str("")
    assert r.get_continuation_type() == C_NONE
    assert r.get_num_lines_in_stmt() == 1
    assert r.get_base_indent_string() == ""
    assert r.is_block_closer() is False
    assert r.is_block_opener() is False
    assert r.get_last_stmt_bracketing() is None
    assert r.get_last_open_bracket_pos() is None
    assert r.compute_bracket_indent() == 0
    assert r.compute_backslash_indent() == 0

    r.set_str("\n")
    assert r.get_continuation_type

# Generated at 2022-06-24 08:14:38.457631
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    """Unit test for RoughParser.find_good_parse_start()

    """
    # pylint: disable=redefined-builtin

    # The following example code has two parse errors in it.
    # The correct indentation for the third line is 6 spaces, but
    # the first parse error is on line 3, so the correct answer is
    # line 2.  When tabwidth is 8 and that line starts with a tab,
    # the correct answer is actually a negative number.  The second
    # parse error is on line 6, which is the same as the answer, so
    # that doesn't affect the result.

# Generated at 2022-06-24 08:14:48.696546
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    rp = RoughParser("def afunc():\n    if True:\n        pass\n    return True")
    assert rp.is_block_opener()
    assert rp.is_block_closer()
    rp = RoughParser("def afunc():\n    if True:\n        pass\n    else:\n        return True")
    assert rp.is_block_opener()
    assert not rp.is_block_closer()
    rp = RoughParser("def afunc():\n    if True:\n        pass\nreturn True")
    assert not rp.is_block_opener()
    assert rp.is_block_closer()
    rp = RoughParser("def afunc():\n    if True:\n        pass\nelse:\n    return True")
    assert not rp

# Generated at 2022-06-24 08:14:57.811062
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import random
    import string

    def sanity_check(text, pos, expected):
        hp = HyperParser(text, pos)
        expr = hp.get_expression()
        if expr != expected:
            print(
                "For text %r and index %r, we got:"
                % (repr(text)[1:-1], pos),
                repr(expr)[1:-1],
                "instead of",
                repr(expected)[1:-1],
            )

    def random_alphanum(num):
        return "".join([random.choice(string.ascii_letters + string.digits) for _ in range(num)])

    def random_identifier(num):
        s = random_alphanum(num)
        while keyword.iskeyword(s):
            s = random_alphanum(num)

# Generated at 2022-06-24 08:15:02.294630
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=invalid-name
    def check(s, want):
        # pylint: disable=redefined-builtin
        r = RoughParser(s)
        try:
            got = r.compute_backslash_indent()
        except (SyntaxError, ValueError):
            assert 0, 'compute_backslash_indent(%r)' % (s,)
        if got != want:
            print("compute_backslash_indent(%r) -> %r, expected %r" % (s, got, want))

    check("foo(", 2)  # an assignment stmt
    check("foo (", 3)  # an assignment stmt
    check("foo\\", 2)  # an assignment stmt
    check("foo =", 2)  # an assignment stmt


# Generated at 2022-06-24 08:15:08.623107
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    assert RoughParser("  foo()[0]").get_last_open_bracket_pos() == 8
    assert RoughParser("  foo()").get_last_open_bracket_pos() == 4
    assert RoughParser("  foo[0]").get_last_open_bracket_pos() == 4
    assert RoughParser("  foo()[").get_last_open_bracket_pos() == 8
    assert RoughParser("  foo(a=[").get_last_open_bracket_pos() == 10

# Generated at 2022-06-24 08:15:16.266530
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class HyperParserTestCase(TestCase):
        def __init__(self, a, b):
            TestCase.__init__(self, a)
            self.b = b

        def runTest(self):
            hp = HyperParser(self.b, "insert")
            assert hp.bracketing == [(0, 0), (5, 1), (6, 2), (7, 1)]
            hp.set_index("1.6")
            assert hp.indexinrawtext == 6
            assert hp.indexbracket == 2
            assert hp.is_in_string()
            assert not hp.is_in_code()
            assert hp.get_surrounding_brackets(openers="([") is None
            assert hp.get_expression() == ""