

# Generated at 2022-06-24 08:05:22.643664
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    # Case that empty string is given
    assert RoughParser("").get_base_indent_string() == ""

    # Case that only one space is given
    assert RoughParser(" ").get_base_indent_string() == " "

    # Case that only one tab is given
    assert RoughParser("\t").get_base_indent_string() == "\t"

    # Case that only one newline is given
    assert RoughParser("\n").get_base_indent_string() == ""

    # Case that only one bkslash_newline is given
    assert RoughParser("\\\n").get_base_indent_string() == ""

    # Case that only one space_bkslash_newline is given
    assert RoughParser(" \\n").get_base_indent_string() == " "

    # Case that two

# Generated at 2022-06-24 08:05:31.293177
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    rp = RoughParser("")
    assert not rp.is_block_closer()
    rp = RoughParser("if True:\n")
    assert not rp.is_block_closer()
    rp = RoughParser("if True:\n    pass\n")
    assert rp.is_block_closer()
    rp = RoughParser("if True:\n    pass\n    pass\n")
    assert rp.is_block_closer()
    rp = RoughParser("if True:\n    pass\n    try:\n        pass\n")
    assert rp.is_block_closer()
    rp = RoughParser("if True:\n    pass\n    dem = 10")
    assert not rp.is_block_closer()

# Generated at 2022-06-24 08:05:40.705660
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    from pytest import raises

    # (function to test, input, expected output)

# Generated at 2022-06-24 08:05:46.877069
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=too-many-statements,too-many-branches
    s = RoughParser("""\
    def foo():
        if 0:
            x = 1
            y = 2
        else:
            x = 4
            y = 3
        # comment
    """)
    assert s.get_base_indent_string() == "        "
    assert s.get_last_open_bracket_pos() == 16

# Generated at 2022-06-24 08:05:59.885933
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # normal
    parser = RoughParser("""\
for i in xrange(10):
    for j in xrange(10):
        if i < j:
            x = 2
        else:
            x = 3
""")
    assert parser.compute_backslash_indent() == 8

    # normal, with extra initial whitespace
    parser = RoughParser("""\
for i in xrange(10):
    for j in xrange(10):
        if i < j:
            x = 2
        else:
            x = 3
""")
    assert parser.compute_backslash_indent() == 8

    # weird
    parser = RoughParser("""\
while True:
    foo()
\\
    bar()
""")
    assert parser.compute_backslash_indent() == 4



# Generated at 2022-06-24 08:06:04.206380
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-24 08:06:09.945077
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-24 08:06:22.004360
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    class MockTextWidget:
        "Mock tkinter.Text widget."

        def __init__(self, content, **kwd):
            self._content = content
            self._index = {"insert": 0, "end": len(content)}
            self._options = kwd

        def index(self, strid):
            "Return index of strid."
            return self._index[strid]

        def get(self, start, stop):
            "Return container[start:stop]."
            return self._content[self.index(start) : self.index(stop)]

        def cget(self, key):
            "Return value of key in widget options."
            return self._options[key]

    # Basic test

# Generated at 2022-06-24 08:06:31.882722
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    class DummyText:
        def __init__(self):
            self.indent_width = 8
            self.tabwidth = 8

        def index(self, index):
            return int(float(index))

        def get(self, index1, index2):
            return index1 + "-" + index2

    dummytext = DummyText()

    def test(text, index, expected):
        print("Testing:", repr(text), index)
        hp = HyperParser(dummytext, index)
        dummytext.get = lambda i1, i2: text[int(float(i1)) : int(float(i2))]
        dummytext.index = lambda i: int(float(i))
        expr = hp.get_expression()

# Generated at 2022-06-24 08:06:45.655636
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-24 08:06:48.335372
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    import doctest, roughparser
    doctest.testmod(roughparser, verbose=False)


# Generated at 2022-06-24 08:06:59.548432
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    str = (
        "from math import sin\nfrom pygame import *\nfrom\n#from random import *\nimport sys\n"
        "def f(x):\n    return sin(x) * x\n"
    )
    import sys
    sys.path.append("../..")
    from py_compile import PyCompileError
    import py_compile
    class FakeCompileError(PyCompileError):
        def __init__(self, lineno):
            super(FakeCompileError, self).__init__("...", "...", lineno)
    assert (
        py_compile.find_good_parse_start(str, FakeCompileError(1)) == 0
    )

# Generated at 2022-06-24 08:07:08.668442
# Unit test for constructor of class RoughParser

# Generated at 2022-06-24 08:07:19.424894
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-24 08:07:26.161156
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=redefined-builtin

    def check(s, continuation, stmt_bracketing):
        # Check that RoughParser(s)._study2() produces the given continuation
        # and stmt_bracketing.
        p = RoughParser(s)
        p._study2()
        assert p.continuation == continuation
        assert p.stmt_bracketing == stmt_bracketing

    check("", C_NONE, None)
    check("\n", C_NONE, None)
    check("# a\n", C_NONE, None)
    check("# a\nx", C_NONE, ((1, 0), (3, 0)))
    check("# a\n# b\nx", C_NONE, ((2, 0), (4, 0)))
   

# Generated at 2022-06-24 08:07:35.074621
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def check_get_expression(text, index, expected):
        hyper = HyperParser(text, index)
        got = hyper.get_expression()
        if got != expected:
            raise ValueError(
                "In '%s'\n    hyper.get_expression() at '%s' did not"
                " return '%s', but '%s'" % (text, index, expected, got)
            )

    # Empty string
    check_get_expression("", "1.0", "")

    # Keywords
    check_get_expression("def", "1.0", "")
    check_get_expression("def f(a):\n  return a", "2.7", "a")
    check_get_expression("lambda", "1.0", "")

# Generated at 2022-06-24 08:07:46.936262
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=redefined-builtin,invalid-name
    # to reproduce bug #369305, import parser
    try:
        import parser
    except:
        return

    # input text

# Generated at 2022-06-24 08:07:50.414079
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    rp = RoughParser("if foo: [1,\n2,\n3]")
    assert rp.get_last_open_bracket_pos() == 14

# Generated at 2022-06-24 08:08:02.019049
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    """Test HyperParser.is_in_code"""

    h = HyperParser("# hello\n# there\n(1 or 2) and 3\n", "2.10")
    assert h.is_in_code()

    h = HyperParser("# hello\n# there\n(1 or 2) and 3\ntest = \"hi\\n\"\n", "2.20")
    assert h.is_in_code()

    h = HyperParser(
        "# hello\n# there\n(1 or 2) and 3\ntest = \"hi\\n\"\n", "3.0 linestart"
    )
    assert not h.is_in_code()


# Generated at 2022-06-24 08:08:11.571023
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser("a = {1: 'one'}", 1)
    assert rp.is_block_opener()

    rp = RoughParser("a = (1, 'one')", 1)
    assert not rp.is_block_opener()

    rp = RoughParser("a = [1, 'one']", 1)
    assert not rp.is_block_opener()

    rp = RoughParser("a = 'one'", 1)
    assert not rp.is_block_opener()

    rp = RoughParser("a = {}", 1)
    assert not rp.is_block_opener()

    rp = RoughParser('a = {1, "one"}', 1)
    assert not rp.is_block_opener()


# Generated at 2022-06-24 08:08:21.219896
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    p = RoughParser("")
    assert p.get_num_lines_in_stmt() == 0
    p = RoughParser("\\\n")
    assert p.get_num_lines_in_stmt() == 2
    p = RoughParser("abc\\\n  xyz\n")
    assert p.get_num_lines_in_stmt() == 2
    p = RoughParser("abc\\\n  xyz\n\n")



# Generated at 2022-06-24 08:08:26.995095
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-outer-name

    parser = RoughParser(tabsize=8, indent_width=4)

    def test(s, expected_indent):
        parser.set_str(s)
        assert parser.compute_backslash_indent() == expected_indent

    test("\n", 0)
    test("x\n", 1)
    test("x\\\n", 1)
    test("x =\n", 1)
    test("x = \\\n", 5)
    test("x = 5\\\n", 5)
    test("x = 5 +\\\n", 8)
    test("if 1:\\\n", 4)
    test("if 1:\n    x\\\n", 8)

# Generated at 2022-06-24 08:08:38.665326
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest
    import unittest.mock
    from tkinter import Text

    class MockText(Text):
        "A mock text object with a few methods implemented."
        def __init__(self, *args, **kwargs):
            Text.__init__(self, *args, **kwargs)
            self.index = unittest.mock.Mock()
            self.index.side_effect = lambda x: str(int(float(x))) + ".0"
            self.get = unittest.mock.Mock()
        def tag_add(self, tagName, *args):
            self.tag_added = (tagName, args)
        def tag_remove(self, tagName, *args):
            self.tag_removed = (tagName, args)

    # The following are some

# Generated at 2022-06-24 08:08:47.316391
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    knowntext1 = "def f():\n    print(\"Hello, world\")\n"
    knowntext2 = "def f():\n    print(\"Hello, world\")\n    print(\"Goodbye, world\")\n"
    knowntext3 = "def f():\n    print(\"Hello, world\")\nprint(\"Goodbye, world\")\n"
    exptext1 = "def f():\n    print(\"Hello, world\")\n    pass\n"
    exptext2 = "def f():\n    print(\"Hello, world\")\n    print(\"Goodbye, world\")\n    pass\n"

# Generated at 2022-06-24 08:08:59.913155
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    import unittest
    from test.support import TESTFN
    from difflib import SequenceMatcher
    from .tokenize import untokenize

    class Test(unittest.TestCase):
        maxDiff = None

        def _show_diff(self, str_, indent):
            # Return a string showing how the dedented docstring differs
            # from the original docstring.
            matcher = SequenceMatcher(None, str_, indent)
            out = []
            for tag, alo, ahi, blo, bhi in matcher.get_opcodes():
                if tag == "equal":
                    continue
                prefix = ["-", "+"][tag == "insert"]
                out.append("%s %s\n" % (prefix, str_[alo:ahi]))
            return "".join(out)


# Generated at 2022-06-24 08:09:04.962697
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    a = 'class X:\n    "docstring"\n    def f(self):\n        print("Hello")\nprint("world")'
    r = RoughParser(a)
    print(r.get_last_open_bracket_pos())


# Generated at 2022-06-24 08:09:10.668458
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    p = RoughParser()
    p.set_lo("a = [\n1, #comment\n2,\n]\n")
    assert p.stmt_bracketing == ((0, 0), (1, 0), (2, 1), (3, 1), (4, 1), (5, 1), (6, 1), (7, 0), (8, 0))


# Generated at 2022-06-24 08:09:18.436456
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = ' \t\n\r\f\v'

    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))

    text = "a + b\tc\nd\fe"
    assert text.translate(mapping) == 'x x x\tx\nx\fx'



# Generated at 2022-06-24 08:09:27.598734
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=redefined-builtin, unused-variable
    # pylint: disable=undefined-variable
    test_str = """
if 1:
    if 2:
        pass
    else:
        a = (
            1
        )
        b = {
            2
        }
        c = [
            3
        ]
else:
    class D:
        pass

    def e():
        pass
print(a)
print(b)
print(c)
print(d)
print(e)
"""
    for test_class in (RoughParser,):
        parser = test_class(test_str)

# Generated at 2022-06-24 08:09:39.060984
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    s = """def f(x):
    return [x for x in range(y)]

    """
    rp = RoughParser(s)
    g = rp.get_last_stmt_bracketing()
    assert g == ((0, 0), (3, 1), (12, 0))
    rp = RoughParser("def f(x): return [x for x in range(y)]")
    g = rp.get_last_stmt_bracketing()
    assert g == ((0, 0), (3, 1), (12, 0))
    rp = RoughParser("def f(x): return [x for x in range(y)]\n")
    g = rp.get_last_stmt_bracketing()
    assert g == ((0, 0), (3, 1), (12, 0))


# Generated at 2022-06-24 08:09:44.911998
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    rp = RoughParser()
    rp.set_str("foo(")
    rp.bracketing_depth("def")
    assert rp.get_last_open_bracket_pos() == 3

test_RoughParser_get_last_open_bracket_pos()


# Generated at 2022-06-24 08:09:52.895456
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-24 08:10:02.563424
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-24 08:10:14.712989
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    """Unit test for method find_good_parse_start of class RoughParser"""
    r = RoughParser(indent_width=4)

# Generated at 2022-06-24 08:10:23.083408
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    # pylint: disable=redefined-builtin

    def check(s, pos):
        rp = RoughParser(s)
        rp._study1()
        assert rp.lastopenbracketpos == pos

    check("foo(", 3)
    check("foo((", 3)
    check("foo(()", 3)
    check("foo(()*", 3)
    check("foo(()* ()", 3)
    check("foo(()* ()[", 3)
    check("foo(()* ()[)", 3)

    check("foo(", -1)
    check("foo((", -1)
    check("foo(()", -1)
    check("foo(()*", -1)
    check("foo(()* ()", -1)

# Generated at 2022-06-24 08:10:24.837918
# Unit test for constructor of class HyperParser
def test_HyperParser():
    assert HyperParser("#hi\n", "1.0")



# Generated at 2022-06-24 08:10:36.049163
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Text()
    h = HyperParser("", "")
    assert not h.is_in_string()  # is_in_string before set_index
    h.text = text
    h.set_index("1.0")
    assert not h.is_in_string()  # empty text
    text.insert("1.0", " ")
    assert not h.is_in_string()  # space
    text.insert("1.0", '"')
    assert h.is_in_string()  # is_in_string after set_index, inside a string
    h.set_index("1.0 lineend")
    assert h.is_in_string()  # end of string
    h.set_index("1.0")
    text.insert("1.0", "\\")
    assert h

# Generated at 2022-06-24 08:10:44.027896
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    rp = RoughParser("from foo import \\", "", 0)
    assert rp.get_continuation_type() == C_BACKSLASH
    rp = RoughParser("x = {1: 2,\\\n", "", 0)
    assert rp.get_continuation_type() == C_BRACKET
    rp = RoughParser("'''  \\", "", 0)
    assert rp.get_continuation_type() == C_STRING_FIRST_LINE
RoughParser.test_get_continuation_type = test_RoughParser_get_continuation_type

# Generated at 2022-06-24 08:10:56.491087
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest.mock import Mock

    text = Mock(
        index=lambda I: int(I.replace(".", "")),
        get=lambda start, stop: str(len(str(start) + " " + str(stop))) + "\n",
        end="end\n",
        index=lambda I: int(I.replace(".", "")),
    )
    hp = HyperParser(text=text, index="100.0")

    assert hp.rawtext == "100  end\n"
    assert hp.stopatindex == "100\n"
    assert hp.bracketing == [[0, 0], [2, 0], [5, 0]]
    assert hp.isopener == [True, False, False]

    hp.set_index("100.3")
    assert hp.indexinrawtext == 3

# Generated at 2022-06-24 08:11:01.016750
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    parser = RoughParser()
    str1 = """haha"""
    parser.set_lo(str1)
    assert parser.continuation == 0


# Generated at 2022-06-24 08:11:13.025591
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest

    class TestHyperParser(HyperParser):
        def __init__(self, text):
            HyperParser.__init__(self, text, text.index("insert"))

        def get_surrounding_brackets(self, openers="([{", mustclose=False):
            return HyperParser.get_surrounding_brackets(self, openers, mustclose)

        def get_expression(self):
            return HyperParser.get_expression(self)

    def _test_method(self, text_index_result):
        text = self.text
        index = text.index(text_index_result[0])
        result = text_index_result[1]
        text.mark_set("insert", index)
        self.set_index(index)
        if not result:
            self.assertRa

# Generated at 2022-06-24 08:11:23.435476
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-24 08:11:29.918639
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-24 08:11:43.216165
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-24 08:11:52.821890
# Unit test for constructor of class RoughParser
def test_RoughParser():
    string = """
    if a:
        b = 3
        if c:
            d = 4
    """
    r = RoughParser(string)
    assert r.get_num_lines_in_stmt() == 1
    more = """
    e = 5
    """
    r.add_str(more)
    assert r.get_num_lines_in_stmt() == 3
    assert r.get_continuation_type() == C_BACKSLASH
    assert r.get_base_indent_string() == "            "


# Generated at 2022-06-24 08:12:01.681014
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    def check(s, want):
        b = RoughParser(s, None).compute_backslash_indent()
        if b != want:
            print("test_RoughParser_compute_backslash_indent: got", b, "want", want)
            print("s =", repr(s))


# Generated at 2022-06-24 08:12:13.005235
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=eval-used, too-many-branches, too-many-statements, redefined-builtin, unexpected-keyword-arg
    from lib2to3 import pygram

    # The purpose of the following is to find out if compute_backslash_indent
    # does the right thing for all the operators in pygram.python_symbols
    # (and also for all keywords that may follow a ":").

    # We use pytree.Node as a hack: since pytree.Node has a
    # compute_backslash_indent method, we can pass it to compute_backslash_indent
    # and see if the result agrees with compute_backslash_indent's result.

    # define a class whose instances have a compute_backslash_indent method,
    # and whose __init

# Generated at 2022-06-24 08:12:21.349365
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class HPTest(TestCase):
        def setUp(self):
            self.h = HyperParser(self.textwidget, index="2.5")

        def tp(self):
            """Print the text widget for comparison with expected parser results."""
            for i in range(self.textwidget.index("end-1c").split(".")[0]):
                print(self.textwidget.get("%d.0" % i, "%d.end" % i))


# Generated at 2022-06-24 08:12:29.496473
# Unit test for constructor of class RoughParser

# Generated at 2022-06-24 08:12:38.154201
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    parser = RoughParser()
    test_text = "\n".join(['print("Hello World!")', 'print("Goodbye World!")'])
    parser.set_str(test_text)
    assert parser.continuation == 1
    assert parser.goodlines == [1, 2]
    assert parser.lastch == ')'
    assert parser.lastopenbracketpos == None
    assert parser.stmt_bracketing == None
    assert parser.study_level == 0
    assert parser.stmt_end == None
    assert parser.stmt_start == None
    assert parser.str == test_text
    assert parser.tabwidth == 8

# Generated at 2022-06-24 08:12:50.176420
# Unit test for method set_lo of class RoughParser

# Generated at 2022-06-24 08:12:52.868570
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    from idlelib.hyperparser import StringTranslatePseudoMapping
    assert set(StringTranslatePseudoMapping({"a": "A"}, "1")) == {'a'}


# Generated at 2022-06-24 08:13:05.932925
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    parser = RoughParser()
    # Check that no indent for a single line
    parser.set_str("a = 12")
    assert parser.get_number_of_lines_in_statement() == 1
    assert parser.get_base_indent_string() == ""
    assert parser.get_continuation_type() == C_NONE
    assert parser.get_last_open_bracket_pos() == None
    # Check that no indent for a single line not starting with whitespace
    parser.set_str("a = 12")
    assert parser.get_number_of_lines_in_statement() == 1
    assert parser.get_base_indent_string() == ""
    assert parser.get_continuation_type() == C_NONE
    assert parser.get_last_open_bracket_pos() == None
   

# Generated at 2022-06-24 08:13:18.496653
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    """Test the set_str method of the RoughParser class."""
    rp = RoughParser()
    rp.set_str(
        """
    if a:
        if b:
            pass
    elif e:
        pass
    elif f:
        pass
    else:
        pass
    """
    )
    # 1
    assert rp.get_num_lines_in_stmt() == 1
    # 0
    assert rp.compute_bracket_indent() == 0
    # 0
    assert rp.compute_backslash_indent() == 0
    # "    "
    assert rp.get_base_indent_string() == "    "
    # False
    assert rp.is_block_opener() == False
    # False

# Generated at 2022-06-24 08:13:29.420766
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    mapping = StringTranslatePseudoMapping({ord('1'): ord('2')}, ord('x'))
    assert mapping[ord('1')] == ord('2')
    assert mapping[ord('x')] == ord('x')
    assert mapping[ord('a')] == ord('x')
    assert len(mapping) == 1
    assert list(iter(mapping)) == [ord('1')]
    assert mapping.get(ord('1')) == ord('2')
    assert mapping.get(ord('x')) == ord('x')
    assert mapping.get(ord('a')) == ord('x')
    assert len(mapping) == 1
    assert list(iter(mapping)) == [ord('1')]



# Generated at 2022-06-24 08:13:37.359510
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-24 08:13:48.407159
# Unit test for method set_lo of class RoughParser

# Generated at 2022-06-24 08:13:49.966203
# Unit test for constructor of class RoughParser
def test_RoughParser():
    rp = RoughParser("import sys\nsys.exit(0)\n")
    assert rp.continuation == C_NONE


# Generated at 2022-06-24 08:14:02.974004
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    import unittest
    import sys

    if sys.version_info[:2] >= (3, 0):
        # pylint: disable=no-name-in-module
        from test.support import run_unittest

    class RoughParserTest(unittest.TestCase):
        def test_get_base_indent_string(self):
            # pylint: disable=redefined-outer-name, too-many-locals
            cases = [
                (
                    "foo() or \\\n"
                    "  bar()",
                    "foo() or ",
                ),
                (
                    "foo() or \\\n"
                    "  bar() \\ \\\n"
                    "  baz()",
                    "foo() or ",
                ),
            ]
            # pylint: enable=redefined-

# Generated at 2022-06-24 08:14:09.368143
# Unit test for constructor of class RoughParser
def test_RoughParser():
    rp = RoughParser("if a: b\n  c\n")
    assert rp.get_num_lines() == 3
    rp = RoughParser("if a: b\n  c\nd")
    assert rp.get_num_lines() == 4
    rp = RoughParser("if a: b\n  c\n\n")
    assert rp.get_num_lines() == 4
    rp = RoughParser("if a: b\n  c\n\n")
    assert rp.get_num_lines() == 4
    rp = RoughParser("")
    assert rp.get_num_lines() == 1
    rp = RoughParser("\n")
    assert rp.get_num_lines() == 2
    rp = RoughParser("\n  ")

# Generated at 2022-06-24 08:14:21.631075
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    from tokenize import tokenize, untokenize, NAME, OP, COMMENT, NEWLINE

    def check(s):
        r = RoughParser(s)
        indent = r.get_base_indent_string()
        good = False
        i = 0
        # look for the first non-blank line and verify that this
        # line starts with the same string indent
        rp = RoughParser(s)
        while True:
            type = rp.get_last_stmt_type()
            good = newline_with_indent(type, indent)
            if good or type == ENDMARKER:
                break
            rp.update("\n")
        return good

    def newline_with_indent(type, indent):
        return type == NEWLINE and tokeneater.token == indent

    tokene

# Generated at 2022-06-24 08:14:32.351664
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    from difflib import unified_diff
    from io import StringIO
    from itertools import product

    def s(x):
        return '"{}"'.format(x)

    r = RoughParser()

    # Testing empty string
    r.set_str("")
    assert r.get_continuation_type() == C_NONE

    # Testing uncontinued statements

# Generated at 2022-06-24 08:14:41.936668
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    """
    Test case for method compute_bracket_indent of class RoughParser
    """
    # pylint: disable=redefined-builtin
    str = """\
foo(
    bar,
    this
    )"""
    rp = RoughParser(str, 4)
    assert rp.compute_bracket_indent() == 4
    rp = RoughParser("with (whatever):\n" + str, 4)
    assert rp.compute_bracket_indent() == 8

    str = """\
foo(
    bar,
    boo)"""
    rp = RoughParser(str, 4)
    assert rp.compute_bracket_indent() == 4
    assert rp.get_last_open_bracket_pos() == 6

# Generated at 2022-06-24 08:14:51.144501
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-24 08:15:00.014191
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    for i, (text, expected_indent) in enumerate(
        [
            ('[1,\n2]', 0), ('[1,\n   2]', 3),
            ('[1,\\\n2]', 0),
            ('[1,\\\n   2]', 3),
            ('[1,\\\n]', 0),
            ('[1,\\\n   ]', 3),
        ]
    ):
        parser = RoughParser(text)
        indent = parser.compute_bracket_indent()
        if indent != expected_indent:
            raise TestFailed('%d: expected %d, got %d' % (i, indent, expected_indent))

# Generated at 2022-06-24 08:15:05.277562
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-24 08:15:14.646170
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    parse = RoughParser()
    parse.set_str('''
if p:
    q = True
else:
    q = False''')
    assert parse.is_block_closer() == True
    assert parse.is_block_opener() == True
    parse.set_str(
        '''
if p:
    q = True
    if d:
        e = True
    else:
        e = False
    print(False)
else:
    q = False
''')
    assert parse.is_block_closer() == True
    assert parse.is_block_opener() == True
    assert parse.get_last_open_bracket_pos() == 43
    assert parse.get_base_indent_string() == '    '
    assert parse.get_last_stmt_bracketing