

# Generated at 2022-06-24 08:05:19.756124
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'
#print(test_StringTranslatePseudoMapping())


# Generated at 2022-06-24 08:05:31.002020
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest

    # A test value of the class used for testing:
    # A string to be parsed, and a list of (index, bracket index)
    # pairs to be tested.

    test_value = """\
    def f(a, (b, c)):
    """


# Generated at 2022-06-24 08:05:35.238265
# Unit test for constructor of class HyperParser
def test_HyperParser():
    for x in ["", ")", "[]", ""]:
        h = HyperParser(Text(x, tabsize=8), "1.0")
        assert h.rawtext == x, (x, h.rawtext)



# Generated at 2022-06-24 08:05:44.889414
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-24 08:05:51.693817
# Unit test for constructor of class HyperParser
def test_HyperParser():
    a = HyperParser(Text(None, "\nif x:\n    print y\n    "), "2.0")
    assert a.rawtext == "\nif x:\n    print y\n    "
    assert a.is_in_code()
    assert not a.is_in_string()
    assert a.get_expression() == "y"

    a = HyperParser(Text(None, "\nif x:\n    print y\n    "), "2.5")
    assert a.get_expression() == "y"

    a = HyperParser(Text(None, "\nif x:\n    print y\n    "), "3.0")
    assert a.get_expression() == ""


# Generated at 2022-06-24 08:06:01.349914
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    """Test setting the low-level text to be parsed.
    """
    # pylint: disable=redefined-builtin
    parser = RoughParser()
    # test empty string
    parser.set_lo('')
    assert not parser.str

    # test trailing newline
    parser.set_lo('\n')
    assert parser.str == '\n'

    # test no trailing newline
    parser.set_lo('a')
    assert parser.str == 'a\n'

    # test two newlines
    parser.set_lo('\n\n')
    assert parser.str == '\n\n\n'

    # test two characters (and two newlines)
    parser.set_lo('a\nb')
    assert parser.str == 'a\nb\n'


# Generated at 2022-06-24 08:06:07.609536
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("a")
    rp.set_lo("pass#test\n")
    rp.set_lo("def a():pass\n")
    rp.set_lo("def a():pass\n    pass\n")
    rp.set_lo("a = []\n")
    rp.set_lo("a = [1,\n      2,\n    3]\n")
    rp.set_lo("a = [1,\n      2,\n    3]\n# comment\n")
    rp.set_lo("a = [1,\n")
    rp.set_lo("a = (1,\n      2,\n    3)\n")

# Generated at 2022-06-24 08:06:17.353537
# Unit test for constructor of class RoughParser

# Generated at 2022-06-24 08:06:28.453289
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(code, index):
        hp = HyperParser(code, index)
        return hp.get_expression()


# Generated at 2022-06-24 08:06:36.489850
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    input_data = [
        {'non_defaults': {}, 'default_value': 0},
        {'non_defaults': {1: 1, 2: 2}, 'default_value': 0},
    ]

    for values in input_data:
        mapping = StringTranslatePseudoMapping(**values)
        for key in range(-100, 100):
            assert mapping.get(key) == (values['non_defaults'].get(key) or values['default_value'])

# Generated at 2022-06-24 08:06:47.765872
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    import io
    import unittest
    import tempfile
    import os
    from tokenize import detect_encoding
    from tokenize import TokenInfo
    import tokenize
    from unittest.mock import sentinel
    from unittest.mock import object
    from unittest.mock import MagicMock
    if os.name == "java":
        import platform

        jython = True
        jdk_version_string = platform.java_ver()[1]
        jdk_major_version, rest = jdk_version_string.split(".", 1)
        jdk_minor_version, rest = rest.split("_", 1)
    else:
        jython = False


# Generated at 2022-06-24 08:06:49.986776
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    assert 0 == len(StringTranslatePseudoMapping({}, ord('x')))



# Generated at 2022-06-24 08:06:56.342985
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    """Unit tests for method get of class StringTranslatePseudoMapping.
    """
    translation = {ord('a'): 1}
    mapping = StringTranslatePseudoMapping(translation, 2)
    assert mapping.get(ord('a')) == 1
    assert mapping.get(ord('b')) == 2
    assert mapping.get(ord('b'), 3) == 3



# Generated at 2022-06-24 08:07:06.886145
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():

    def t(str_, continuation, is_block_opener, is_block_closer):
        parser = RoughParser()
        parser.set_str(str_)
        assert parser.get_continuation_type() == continuation
        assert parser.is_block_opener() == is_block_opener
        assert parser.is_block_closer() == is_block_closer
        return parser

    t("x = 1", C_NONE, 0, 0)
    t("x = (\n1", C_BRACKET, 0, 0)
    t("x = {\n1", C_BRACKET, 0, 0)
    t("x = [\n1", C_BRACKET, 0, 0)
    t("x = foo(\n1", C_BRACKET, 0, 0)
   

# Generated at 2022-06-24 08:07:17.900307
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    _i, _j, _n = inspect.currentframe().f_back.f_locals.items()

    def check(source_lines, expected_indent):
        line_iterator = iter(source_lines)
        line = ''.join(line_iterator).rstrip()
        rough_parser = RoughParser(line, len(expected_indent))
        actual_indent = rough_parser.get_base_indent_string()
        if actual_indent == expected_indent:
            return
        error = "Wrong indent for {!r}: found {} instead of {}".format(
            line,
            repr(actual_indent),
            repr(expected_indent),
        )
        raise AssertionError(error)

    # Test 1:

# Generated at 2022-06-24 08:07:20.028653
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    pass
    # rp = RoughParser()
    # AssertionError: set_lo() not yet ready!
    # rp.set_lo(1)
    


# Generated at 2022-06-24 08:07:24.396234
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    mapping = StringTranslatePseudoMapping({ord('1'): ord('A'),
                                            ord('2'): ord('B')},
                                           ord('Z'))
    assert mapping[ord('1')] == ord('A')
    assert mapping[ord('2')] == ord('B')
    assert mapping[ord('3')] == ord('Z')



# Generated at 2022-06-24 08:07:29.760318
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # pylint: disable=redefined-builtin
    fail_msg = \
        "RoughParser.get_continuation_type() returned wrong value '$found'\n" \
        "for input '$input'\n"
    for case in _testcases:
        rp = RoughParser(case.input, case.tabwidth)
        found = rp.get_continuation_type()
        if found != case.continuation:
            raise TestFailure(
                fail_msg.replace("$found", repr(found))
                .replace("$input", repr(case.input))
            )


# Generated at 2022-06-24 08:07:38.686135
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser(indent_width=4, tabwidth=8)
    assert rp.goodlines == [1]
    assert rp.study_level == 0
    assert rp.get_base_indent_string() == ""
    rp.set_lo("a = 1\nb = 2")
    rp.study1()
    #assert rp.continuation == C_NONE
    assert rp.get_base_indent_string() == ""
    assert rp.get_num_lines_in_stmt() == 1
    assert rp.goodlines == [1, 2]
    assert rp.study_level == 2
    assert rp.stmt_start == 0
    assert rp.stmt_end == 7

# Generated at 2022-06-24 08:07:46.847208
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    from unittest import TestCase

    class _StringTranslatePseudoMapping_TestCase(TestCase):
        class _Mapping:
            def __init__(self, *args):
                self._data = dict(args)
            def get(self, key, default=None):
                return self._data.get(key, default)
        def test_return_non_default_value(self):
            _non_defaults = self._Mapping((('x', 1),))
            _default = 0
            _mapping = StringTranslatePseudoMapping(_non_defaults, _default)

            _key = 'x'
            _expected = 1
            _result = _mapping[_key]

            _expected_output = "Error: _mapping[_key] should be _expected"

# Generated at 2022-06-24 08:07:53.394261
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = tk.Text()
    h = HyperParser(text, "1.0")

    text.insert("1.0", "if True: pass")
    h.set_index("1.0")
    assert not h.is_in_string()
    h.set_index("1.4")
    assert not h.is_in_string()

    text.delete("1.0", "end")
    text.insert("1.0", "if ('True'): pass")
    h.set_index("1.0")
    assert h.is_in_string()
    h.set_index("1.2")
    assert h.is_in_string()
    h.set_index("1.7")
    assert h.is_in_string()
    h.set_index("1.8")


# Generated at 2022-06-24 08:08:01.089234
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    """The HyperParser class's is_in_string method should return whether
    the given index is inside a string."""

    text = Tkinter.Text()
    text.insert("insert", "foo = 'string'")
    text.mark_set("insert", "1.0")

    hyper = HyperParser(text, "1.0")
    if hyper.is_in_string():
        raise TestFailed("is_in_string failed for 1.0")

    hyper = HyperParser(text, "1.3")
    if hyper.is_in_string():
        raise TestFailed("is_in_string failed for 1.3")

    hyper = HyperParser(text, "1.8")
    if not hyper.is_in_string():
        raise TestFailed("is_in_string failed for 1.8")

   

# Generated at 2022-06-24 08:08:05.742824
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    parser = RoughParser()
    parser.set_str("""
    a = b
    if c:
        d = e
""")
    assert parser.str == "a = b\nif c:\n    d = e\n"

# Generated at 2022-06-24 08:08:13.528250
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():  # pylint: disable=redefined-outer-name
    # pylint: disable=invalid-name
    """
    Unit test for method `RoughParser.set_lo`
    """

# Generated at 2022-06-24 08:08:20.602521
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Text()
    text.set("'a' \"b\"")

    hp = HyperParser(text, "1.0")
    assert hp.is_in_string()
    hp.set_index("1.2")
    assert hp.is_in_string()
    hp.set_index("1.3")
    assert not hp.is_in_string()
    hp.set_index("1.4")
    assert hp.is_in_string()
    hp.set_index("1.5")
    assert hp.is_in_string()
    hp.set_index("2.0")
    assert not hp.is_in_string()
    hp.set_index("2.1")
    assert hp.is_in_string()
    hp.set_index("2.2")
    assert hp

# Generated at 2022-06-24 08:08:26.346120
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=redefined-builtin
    # pylint: disable=too-many-locals
    # pylint: disable=unused-variable

    rough_parser = RoughParser()

    class TestCase:
        # pylint: disable=too-few-public-methods
        def __init__(self, string, continuation, indent_width, tabwidth):
            self.string = string
            self.continuation = continuation
            self.indent_width = indent_width
            self.tabwidth = tabwidth

        def __repr__(self):
            return "<TestCase indent_width=%d tabwidth=%d continuation=%s string=%s>" % (
                self.indent_width,
                self.tabwidth,
                self.continuation,
                self.string,
            )

# Generated at 2022-06-24 08:08:38.441591
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase
    from idlelib import PyParse

    class Test(TestCase):
        def check(self, cases):
            for rawtext, index, res in cases:
                index = len(rawtext) - index
                parser = HyperParser(PyParse.Parser(rawtext, None), index)
                got = parser.get_expression()
                self.assertEqual(got, res)


# Generated at 2022-06-24 08:08:40.314422
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-24 08:08:50.705303
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-24 08:09:01.366815
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    def test_one(s, bracket, tabwidth=8, indent_width=4):
        rp = RoughParser(s, tabwidth, indent_width)
        assert rp.get_last_open_bracket_pos() == bracket

    test_one("{'foo':[a,\n  b,\n  c],\n  'bar':(1, 2,]}", 16)
    test_one("{'foo':[a,\n  b,\n  c],\n  'bar':(1, 2,]})", 19)
    test_one("{'foo':[a,\n  b,\n  c],\n  'bar':(1, 2,]})", 20)  # too far

# Generated at 2022-06-24 08:09:05.714343
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    from wx import GetApp
    app = GetApp()
    obj = RoughParser(0)
    obj.set_str("xxx")
    assert obj.str == "xxx"

    obj.str = None
    try:
        obj.set_str("xxx")
    except NotImplementedError:
        pass
    else:
        assert False, "expected exception"


# Generated at 2022-06-24 08:09:12.301496
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    from idlelib.pyshell import HyperParser

    def is_in_string(s, i):
        return HyperParser(s, i).is_in_string()

    assert is_in_string("'''", "1.0")
    assert is_in_string("'''", "1.1")
    assert is_in_string("'''", "1.2")
    assert not is_in_string("'''", "1.3")
    assert not is_in_string("'''", "insert")

    assert is_in_string("'''xxx", "1.0")
    assert is_in_string("'''xxx", "1.1")
    assert is_in_string("'''xxx", "1.2")
    assert is_in_string("'''xxx", "1.3")
   

# Generated at 2022-06-24 08:09:21.167327
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    r = RoughParser("class A:")
    print(repr(r.get_base_indent_string()))
    # -> '    '
    r = RoughParser("class A:\n    def X(self):\n        pass")
    print(repr(r.get_base_indent_string()))
    # -> '    '
    r = RoughParser("if 1:\n    pass")
    print(repr(r.get_base_indent_string()))
    # -> '    '
    r = RoughParser("    if 1:")
    print(repr(r.get_base_indent_string()))
    # -> '    '
    r = RoughParser("\n    if 1:")
    print(repr(r.get_base_indent_string()))
    # ->

# Generated at 2022-06-24 08:09:28.855511
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    parser = RoughParser("if True:\n foo = [\n1\n]\n")
    assert parser.compute_bracket_indent() == 3
    parser = RoughParser("if True:\n    # Some comment\n    foo = [\n        1,\n        2\n    ]\n")
    assert parser.compute_bracket_indent() == 3
    parser = RoughParser("if True:\n\n    foo = [\n        1,\n        2\n    ]\n")
    assert parser.compute_bracket_indent() == 3
    parser = RoughParser("if True:\n    foo = [\n        1,\n        2,\n    ]\n")
    # With the line with 2, we guessed that it was a list item, and
    # added the extra indentation

# Generated at 2022-06-24 08:09:39.854317
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text(None)
    text.insert("end", """\
# this is a comment
"This is a string"
"""
    )
    hp = HyperParser(text, "2.0")
    assert hp.is_in_code()
    text.insert("2.0", "#")
    assert not hp.is_in_code()
    hp = HyperParser(text, "1.0")
    assert not hp.is_in_code()
    hp = HyperParser(text, "2.4")
    assert not hp.is_in_code()

    # Test with triple-quoted strings.
    text.delete("1.0", "end")
    text.insert("end", """\
# this is a comment
'''This is a string'''
"""
    )

# Generated at 2022-06-24 08:09:47.837863
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():

    # Test edge cases.

    rp = RoughParser("", 0)
    assert rp.compute_backslash_indent() == 0

    rp = RoughParser(" \n", 1)
    assert rp.compute_backslash_indent() == 1

    rp = RoughParser("\n", 0)
    assert rp.compute_backslash_indent() == 0

    rp = RoughParser("\n ", 1)
    assert rp.compute_backslash_indent() == 1

    rp = RoughParser("\n \n", 1)
    assert rp.compute_backslash_indent() == 2

    rp = RoughParser("\\\n", 0)
    assert rp.compute_backslash_indent() == 0

    rp = Rough

# Generated at 2022-06-24 08:09:59.134600
# Unit test for method is_block_opener of class RoughParser

# Generated at 2022-06-24 08:10:04.262930
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    data_dict = {'foo': 'bar'}
    pseudo_mapping = StringTranslatePseudoMapping(data_dict, 'x')
    assert len(pseudo_mapping) == len(data_dict)


# Generated at 2022-06-24 08:10:09.436870
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("   a = 1 + 2\n")
    assert rp.get_base_indent_string() == "   "
    rp = RoughParser("a = 1 + 2\n")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("a = 1 + 2")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("\ta = 1 + 2\n")
    assert rp.get_base_indent_string() == "\t"
    rp = RoughParser("\ta = 1 + 2\n")
    assert rp.get_base_indent_string() == "\t"
    rp = RoughParser("\ta = 1 + 2")
    assert rp.get_base_indent_

# Generated at 2022-06-24 08:10:13.391676
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    m = StringTranslatePseudoMapping({}, '')
    assert m.get(0) == ''
    assert m.get(0, 'x') == ''
    assert m.get(1, 'x') == 'x'


# Generated at 2022-06-24 08:10:22.812665
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    mapping = StringTranslatePseudoMapping(
        {0x41:0x61, 0x45:0x65, 0x49:0x69}, 0x100
    )
    assert len(mapping) == 3

    assert mapping[0x41] == 0x61
    assert mapping[0x42] == 0x100
    assert mapping[0x45] == 0x65

    assert mapping.get(0x49) == 0x69
    assert mapping.get(0x4A) == 0x100
    assert mapping.get(0x4A, 0x200) == 0x200

    for char in mapping:
        assert char in [0x41, 0x45, 0x49]

    is_iterable = False
    for char in mapping:
        is_iterable = True

# Generated at 2022-06-24 08:10:26.935506
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    # This shouldn't be necessary, but there's something wrong with
    # doctest, so we have to do it manually
    from . import parser
    parser.testmod()



# Generated at 2022-06-24 08:10:37.484052
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    from unittest.mock import Mock
    from tkinter import Text

    def lines(text):
        return text.split("\n")

    class T(Text):
        # This method is always called by tkinter.Text to get the
        # configuration of the widget, and we don't have to define any
        # other method for this to work.
        def __getitem__(self, item):
            if item == "tabs":
                return "4c"
            elif item == "tabstyle":
                return "wordprocessor"
            elif item == "wrap":
                return "none"
            elif item == "width":
                return "4000"
            elif item == "height":
                return "4000"
            raise KeyError("T.__getitem__", item)

    # 1. Test a simple case

# Generated at 2022-06-24 08:10:40.904582
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()
    rp.set_str("    a = 1\n")
    rp.set_str("    b = 2\n")
    print(rp)


# Generated at 2022-06-24 08:10:46.790128
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser("a = [i for i in range(1)]")
    assert rp.is_block_opener() == True
    rp = RoughParser(" a = [i for i in range(1)]")
    assert rp.is_block_opener() == False
    rp = RoughParser("a = 1")
    assert rp.is_block_opener() == False
 

# Generated at 2022-06-24 08:10:57.989941
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    _expected = r"""    >>> whitespace_chars = ' \t\n\r'
    >>> preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    >>> mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    >>> text = "a + b\tc\nd"
    >>> text.translate(mapping)
    'x x x\tx\nx'
    """
    d = {"a": "x", "b": "x", "c": "x", "d": "x", "e": "x"}
    # "c" and "d" are not in the dictionary
    m = StringTranslatePseudoMapping(d, ord("c"))
    test1 = "bdabedabdabcdabedabdabcd"

# Generated at 2022-06-24 08:11:11.121151
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    import pprint
    def check(input, output):
        rp = RoughParser(input)
        actual = rp.find_good_parse_start(0)
        if actual != output:
            print("Input: %r" % (input,))
            print("Expected: %r" % (output,))
            print("Actual: %r" % (actual,))
            pprint.pprint(rp.good_parse_start_pairs)
            print("Continuation: %d" % rp.continuation)
            assert 0

    # Simple.

# Generated at 2022-06-24 08:11:16.844774
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    mapping = StringTranslatePseudoMapping({ord('a'): ord('b')}, ord('c'))
    assert mapping[ord('a')] == ord('b')
    assert mapping[ord('b')] == ord('c')



# Generated at 2022-06-24 08:11:26.743538
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    import unittest
    import unittest.mock
    from pygments.lexers.python import Python3Lexer

    # Inject the fake into the relevant global
    class FakeStringTranslatePseudoMapping:
        def __init__(self):
            self._non_defaults = None
            self._default_value = None

        def __len__(self):
            return NotImplemented

    fake_StringTranslatePseudoMapping = FakeStringTranslatePseudoMapping()
    fake_get_builtin_module = unittest.mock.Mock(return_value=fake_StringTranslatePseudoMapping)

# Generated at 2022-06-24 08:11:32.106464
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    r = RoughParser("[1,\n")
    r.indent_width = 2
    r.tabwidth = 2
    r.compute_bracket_indent()
    assert r.lastch == ","
    r = RoughParser("[].\n")
    r.indent_width = 2
    r.tabwidth = 4
    assert r.compute_bracket_indent() == 0
    r = RoughParser("[\n  1,\n  2]\n")
    r.indent_width = 2
    r.tabwidth = 4
    assert r.compute_bracket_indent() == 4
    r = RoughParser("[\n  [\n    [\n      1,\n      2\n    ]\n  ]\n]\n")
    r.indent

# Generated at 2022-06-24 08:11:39.242177
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    def t(s, open_bracket_pos=None):
        rp = RoughParser(s, indent_width=4, tabwidth=8)
        assert rp.get_last_open_bracket_pos() == open_bracket_pos
    t('hello # there')
    t('a, b', 0)
    t('(a\n, b)', 0)
    t('a, b, (c)')



# Generated at 2022-06-24 08:11:47.408851
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest
    import StringIO
    import textwrap
    import tokenize
    import os

    class Test_set_index(unittest.TestCase):
        def test_set_index(self):
            def test(text, index, expected_result, expected_exc=None):
                hp = HyperParser(text)
                hp.set_index(index)
                self.assertEquals(hp.indexbracket, expected_result)

            def test_exception(text, index):
                hp = HyperParser(text)
                self.assertRaises(ValueError, hp.set_index, index)

            # Test a variety of situations, including the cases when
            # the index precedes the analyzed string, which should
            # raise an exception.
            text = Text("01234")
            text.set_insert(5)

# Generated at 2022-06-24 08:11:57.073786
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    assert is_block_opener(RoughParser('if x:\n'))
    assert is_block_opener(RoughParser('if x:\n\n'))
    assert is_block_opener(RoughParser('if x:\n    pass'))
    assert is_block_opener(RoughParser('if (x\n') is False)
    assert is_block_opener(RoughParser('if (x):\n') is False)
    assert is_block_opener(RoughParser('if (\n') is False)
    assert is_block_opener(RoughParser('if (\n    pass')) is False
    assert is_block_opener(RoughParser('if x:\n    if y\n'))

# Generated at 2022-06-24 08:12:01.865722
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    '''Test for Class StringTranslatePseudoMapping, method __len__
    '''
    mapping = StringTranslatePseudoMapping({}, 0)
    assert len(mapping) == 0
    mapping = StringTranslatePseudoMapping({1: 1}, 0)
    assert len(mapping) == 1



# Generated at 2022-06-24 08:12:13.193106
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    def check(s, expected):
        r = RoughParser(s)
        actual = r.get_continuation_type()
        assert actual == expected, (s, actual, expected)
    # Test a list of samples
    s = "foo"
    check(s, C_NONE)
    check(s + "\\", C_BACKSLASH)
    check(s + "\\\n", C_BACKSLASH)
    check(s + "\\\nbar", C_BACKSLASH)
    check(s + "\\\n\nbar", C_BACKSLASH)
    check(s + "\\\n  \nbar", C_BACKSLASH)
    check(s + "\\\n\n  bar", C_BACKSLASH)

# Generated at 2022-06-24 08:12:23.266876
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():  # @DontTrace
    r"""Test method __iter__ of class StringTranslatePseudoMapping"""
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    assert list(mapping) == list(preserve_dict)



# Generated at 2022-06-24 08:12:31.012766
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    if True:\n        pass")
    assert rp.get_base_indent_string() == "    "

    rp = RoughParser(" #\n    if True:\n        pass")
    assert rp.get_base_indent_string() == "    "

    rp = RoughParser("if True:\n #\n        pass")
    assert rp.get_base_indent_string() == "    "

    rp = RoughParser("\n    if True:\n        pass")
    assert rp.get_base_indent_string() == "    "

    rp = RoughParser("if True:\n    pass")
    assert rp.get_base_indent_string() == "    "

    rp = RoughParser("if True:\n     pass")
    assert r

# Generated at 2022-06-24 08:12:40.486953
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    rp = RoughParser("x = {(1): [1]\n }", 0, 0)
    assert rp.get_last_stmt_bracketing() == ((0, 0), (5, 1), (7, 0), (11, 1), (15, 0))
    rp = RoughParser("x = {(1): [1]\n }", 0, 2)
    assert rp.get_last_stmt_bracketing() == ((0, 2), (5, 1), (8, 0), (11, 1), (15, 0))
    rp = RoughParser("x = {(1): [1]\n }", 0, 4)

# Generated at 2022-06-24 08:12:52.571537
# Unit test for method set_lo of class RoughParser

# Generated at 2022-06-24 08:13:02.264196
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rough_parser = RoughParser()

    with open("tests/data/rough_parser_py", "r") as f:
        text = f.read()

    rough_parser.set_str(text)

    # Verify line numbers of "good" lines
    assert rough_parser.goodlines == [0, 6, 12, 18, 24, 30, 36, 42,
                                      48, 53, 58, 65, 70, 78, 84, 91,
                                      97, 102, 109, 116, 123, 129, 135]

# Generated at 2022-06-24 08:13:06.540693
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    assert RoughParser('}').is_block_closer() == True
    assert RoughParser(')\n').is_block_closer() == True
    assert RoughParser(']\n').is_block_closer() == True
    assert RoughParser('d\n').is_block_closer() == False
    assert RoughParser(']\n\n').is_block_closer() == True

# Generated at 2022-06-24 08:13:10.671005
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import sys

# Generated at 2022-06-24 08:13:19.789499
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    class DummyText(object):
        def __init__(self, text):
            self.text = text

        def index(self, index):
            if index == "1.0":
                return "0"
            elif index == "1.end":
                return str(len(self.text))
            elif index.endswith("c"):
                return str(int(index[: -1]) - 1)
            else:
                return index

        def get(self, start, end):
            return self.text[int(start) : int(end)]


# Generated at 2022-06-24 08:13:30.099695
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    p = RoughParser('blah blah blah', 0)
    assert not p.is_block_opener(), 'Empty string is not a block opener'
    p.str = 'if True:\n    pass'
    print(p.str)
    assert p.is_block_opener(), 'if statement is a block opener'
    p.str = 'if True:\n    pass\n'
    assert p.is_block_opener(), 'if statement with trailing newline is a block opener'
    p.str = 'if True:\n    blah blah blah'
    assert p.is_block_opener(), 'if statement followed by a non-empty line is a block opener'
    p.str = 'if True:\n    pass\nelse:\n    pass'

# Generated at 2022-06-24 08:13:35.774672
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    p = RoughParser(
        """\
    def f():
        if True:
            if True:
                pass

    if True:
        pass
    elif True:
        pass
    elif True:
        if True:
            pass

    if True:
        pass
    else:
        pass

    while True:
        pass


    if True:
        pass
    if True:
        pass

    if True:
        pass
    if True:
        pass
    if True:
        pass
    print()

    if True:
        pass
    if True:
        pass
    if True:
        pass

    if True:
        pass
    if True:
        pass"""
    )

# Generated at 2022-06-24 08:13:38.092766
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-24 08:13:49.000718
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # test code that does triple-quoted strings:
    str = """if 1:
    say('''
        There is a cow
        in this line.
    ''', 'and also')  # triple-quoted strings are also brackets
   '''
   #'''
    and (
      open two brackets,
    )
    '''
    say('''
    ''')
"""
    s = RoughParser(str, 0)
    assert s.compute_bracket_indent() == 8
    # test code with an open bracket before any other code
    str = """  '''
    ''')
    """
    s = RoughParser(str, 0)
    assert s.compute_bracket_indent() == 4
    # test code with a bracket not directly after the first
    # indent in the first line

# Generated at 2022-06-24 08:13:58.967595
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    """

    >>> import tokenize
    >>> from io import StringIO
    >>> stream = StringIO('''
    ... if True:
    ...     "fdfdg"
    ...     sdfdfg
    ...     def f(x,y):
    ...         g=x+y
    ...       x=g+y
    ... ''')
    >>> RoughParser(tokenize.generate_tokens(stream.readline)).find_good_parse_start()
    0
    >>> stream = StringIO('''
    ... a=1
    ... b=2
    ... c=3
    ... ''')
    >>> RoughParser(tokenize.generate_tokens(stream.readline)).find_good_parse_start()
    6

    """


# Generated at 2022-06-24 08:14:05.947058
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    # Test for Python < 3.9
    preserve_dict = {ord(c): ord(c) for c in ' \t\n\r'}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'



# Generated at 2022-06-24 08:14:13.294333
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    # Test get()
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'
# Test string constants

# Generated at 2022-06-24 08:14:21.642334
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    for s, expected in (
        ("[\n]", 1),
        ("say(1,\n    2)", 4),
        ("say(1,\n    (2,\n     3),\n    4)", 4),
        ("if 1:\n print(spam)\n else:\n print(eggs)", 6),
        (
            "def f():\n if 1:\n  return 2\n def g(a=1,\n        b=2):\n  return a + b",
            8
        ),
    ):
        actual = RoughParser(s).compute_bracket_indent()
        assert actual == expected, (s, actual, expected)
#@+node:ekr.20120211175051.10373: ** Error Classes
#@+node:ekr.20120211175051

# Generated at 2022-06-24 08:14:31.902065
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    """Test constructor exception, method __getitem__(), and method __len()__
    """
    # Use case: replace all characters with 'X' or 'Y'.
    # (Only whitespace will be replaced with 'Y'.)
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'
    assert len(mapping) == len(whitespace_chars)
    for key in mapping:
        assert key in preserve_dict



# Generated at 2022-06-24 08:14:41.698133
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():

    parser = RoughParser()
    parser.set_str("a,\n    b = c")
    assert parser.get_num_lines() == 2
    assert parser.is_block_opener() == False
    assert parser.is_block_closer() == False
    assert parser.get_continuation_type() == C_NONE
    assert parser.get_last_open_bracket_pos() == None
    assert parser.get_last_stmt_bracketing() == ((0, 0), (6, 1), (11, 0))
    parser.set_str("a, b = (c +\n d -\n e)\n")
    assert parser.get_num_lines() == 3
    assert parser.is_block_opener() == False
    assert parser.is_block_closer() == False
   

# Generated at 2022-06-24 08:14:48.330539
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = tkinter.Text()

# Generated at 2022-06-24 08:14:49.958717
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-24 08:15:00.311414
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    """Test get_surrounding_brackets on a variety of inputs"""

    # Create a Text widget and insert some text in it
    from unittest import mock

    from idlelib.idle_test.mock_tk import Mbox_func
    from idlelib.idle_test.htest import run

    with mock.patch.object(HyperParser, "text", spec_set=True):
        with mock.patch.object(HyperParser, "stopatindex", spec_set=True):
            h = HyperParser(None, 0)
            h.text = mock.Mock()
            h.text.index = mock.Mock(side_effect=["1.0", "1.0", "12.0", "1.0"])
            h.stopatindex = "12.0"


# Generated at 2022-06-24 08:15:03.303943
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert set(mapping) == {32, 9, 10, 13}

# Generated at 2022-06-24 08:15:08.513749
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    non_defaults = {ord('a'): ord('x')}
    s_map = StringTranslatePseudoMapping(non_defaults, ord('y'))
    assert s_map.get(ord('a'), ord('z')) == ord('x')
    assert s_map.get(ord('b'), ord('z')) == ord('z')



# Generated at 2022-06-24 08:15:16.180666
# Unit test for constructor of class HyperParser
def test_HyperParser():
    def _get_lines(class_):
        return text_overlap_repr(textw, class_.rawtext)

    import unittest, inspect

    from test.support import requires, run_unittest

    requires("gui")
    from idlelib import editor
    from idlelib.EditorWindow import EditorWindow

    class TestInit(unittest.TestCase):
        @classmethod
        def setUpClass(class_):
            class_.root = root = Tk()
            root.withdraw()
            root.update()
            class_.editor = editor.EditorWindow(root)
            class_.textw = textw = class_.editor.text
            textw.insert("end", test_text)
            textw.update()
            textw.see("end")