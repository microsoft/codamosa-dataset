

# Generated at 2022-06-24 08:05:17.266716
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """Test HyperParser.set_index.

    There was a bug where self.indexbracket was not set properly if
    self.indexinrawtext was a "(" and there was an ")" to the left.
    """
    b = tk.Text()
    b.insert("insert", "x = (")
    b.mark_set("insert", "end - 1c")  # set insert to before the ')'
    hp = HyperParser(b, index="insert")
    hp.set_index("insert")
    assert hp.indexbracket == 1
    assert hp.indexinrawtext == 3



# Generated at 2022-06-24 08:05:28.675262
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    r = RoughParser("")
    assert r.get_continuation_type() == C_NONE

    r = RoughParser("a = 1")
    assert r.get_continuation_type() == C_NONE

    r = RoughParser("if a:")
    assert r.get_continuation_type() == C_NONE

    r = RoughParser("if a:\\")
    assert r.get_continuation_type() == C_BACKSLASH

    r = RoughParser("if a:\\\n    pass")
    assert r.get_continuation_type() == C_BACKSLASH

    r = RoughParser("if a:\n    pass\n")
    assert r.get_continuation_type() == C_NONE

    r = RoughParser("if a:\n    \\\n    pass")
    assert r

# Generated at 2022-06-24 08:05:34.420361
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    tabwidth = 4
    import doctest
    doctest.testmod(verbose=0)

### end RoughParser

# These are used only by the unit tests
_openers_to_indent = "({["
_closers_to_dedent = ")}]"
_valid_unindent_chars = _closers_to_dedent + "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ:."


# Generated at 2022-06-24 08:05:42.446868
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-24 08:05:48.819545
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    preserve_dict = {ord(c): ord(c) for c in string.whitespace}
    instance = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    expected = "x x x\tx\nx"
    actual = text.translate(instance)
    assert actual == expected, "failed on text = '%s'" % (text,)

# Generated at 2022-06-24 08:05:56.220945
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    non_defaults = {ord('a'): ord('A'), ord(' '): ord('-')}
    mapping = StringTranslatePseudoMapping(non_defaults, ord('x'))
    assert mapping[ord('a')] == ord('A')
    assert mapping[ord(' ')] == ord('-')
    assert mapping[ord('b')] == ord('x')


# Generated at 2022-06-24 08:06:07.393611
# Unit test for constructor of class RoughParser
def test_RoughParser():
    parser = RoughParser("  if True:\n    pass\n")
    assert parser.get_continuation_type() == parser.C_NONE

    parser = RoughParser("  if True:\\\n    pass\n")
    assert parser.get_continuation_type() == parser.C_BACKSLASH

    parser = RoughParser("  if True:\\\n    pass\\\n")
    assert parser.get_continuation_type() == parser.C_BACKSLASH

    parser = RoughParser("  if True:\\\n    pass")
    assert parser.get_continuation_type() == parser.C_BACKSLASH

    parser = RoughParser("  if True:\n    pass\\")
    assert parser.get_continuation_type() == parser.C_BACKSLASH


# Generated at 2022-06-24 08:06:17.293602
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    s = r"""
        [1,
        2,
        ]
        """
    p = RoughParser()
    p.set_str(s)
    p.set_tabsize(8)
    assert p.get_continuation_type() == C_NONE
    p.set_str("a + \\")
    assert p.get_continuation_type() == C_BACKSLASH
    p.set_str("a * \\")
    assert p.get_continuation_type() == C_BACKSLASH
    p.set_str("a + \\")
    assert p.get_continuation_type() == C_BACKSLASH
    p.set_str("a = \\")
    assert p.get_continuation_type() == C_BACKSLASH
    p.set_str("a = \\")
   

# Generated at 2022-06-24 08:06:28.460425
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    from _pytest.logging import CapturedLogging

    class MockLogging():

        def __init__(self):
            self.calls = []

        def debug(self, msg, *, stacklevel=1):
            self.calls.append(msg)

    cwd = os.getcwd()  # paranoia
    for test in (RoughParser_Tests):
        for i, ch in enumerate(test.code):
            # PARANOIA: make sure all test cases are relative to this directory
            this_file = os.path.abspath(test.__file__)
            if os.path.dirname(this_file) != cwd:
                raise RuntimeError(
                    "cwd is not the directory that contains test file " + this_file
                )
            # The logging is going to be mocked in

# Generated at 2022-06-24 08:06:39.418743
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"


# Chew up blanks and comments as quickly as possible.  If match is
# successful, m.end() less 1 is the index of the last boring char
# matched.  If match is unsuccessful, the string starts with an
# interesting char.


# Generated at 2022-06-24 08:06:40.781862
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    assert StringTranslatePseudoMapping.__getitem__


# Generated at 2022-06-24 08:06:46.571535
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # this function tests get_expression by creating a large Python
    # file and running over it, looking for syntax errors.
    import tokenize
    import io

    # Some of the words which we will use in the test file

# Generated at 2022-06-24 08:06:55.907181
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():

    def check(s, expected):
        return s.count("\n") == expected

    def do_test(s, expected):
        parser = RoughParser(s, "foo.py")
        assert check(s, expected)
        assert parser.get_num_lines_in_stmt() == expected

    do_test('abc\nabc\nabc\nabc', 4)
    do_test('abc\nabc\nabc', 3)
    do_test('abc\nabc\n', 2)
    do_test('abc\n', 1)
    do_test('abc', 1)


# Generated at 2022-06-24 08:07:03.507002
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-24 08:07:09.645141
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    from pprint import pprint
    from lib2to3.pgen2 import token
    from lib2to3.pgen2 import driver
    from lib2to3.pytree import Leaf
    from lib2to3.pygram import python_symbols as syms

    def pretty_number(nodes):
        return [[node.type, node.value, node.prefix] for node in nodes]

    # we need to create a parser, but we only need the parsing function
    driver.parse_tokens = lambda parse_input, debug: parse_input()

    class MockGrammar:
        def number(self, parser):
            return parser.token(token.NUMBER)
        parser_config = {'single_input': 0,
                         'file_input': 0,
                         'eval_input': 0}
    grammar = Mock

# Generated at 2022-06-24 08:07:14.815003
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    rp = RoughParser("a = foo(\\\n", indent_width=4, tabwidth=4)
    assert rp.compute_backslash_indent() == 4
    rp = RoughParser("a =  foo(\\\n", indent_width=4, tabwidth=4)
    assert rp.compute_backslash_indent() == 5
    rp = RoughParser("a = foo(\\\n", indent_width=4, tabwidth=4)
    assert rp.compute_backslash_indent() == 4
    rp = RoughParser("a = foo(\n", indent_width=4, tabwidth=4)
    assert rp.compute_backslash_indent() == 0

# Generated at 2022-06-24 08:07:22.877432
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    INDENT_WIDTH = 4
    TAB_WIDTH = 4

    e = RoughParser('\n', INDENT_WIDTH, TAB_WIDTH)
    assert '\n' == e.get_base_indent_string()
    assert '' == e.get_leading_whitespace(1)

    e = RoughParser('    \n', INDENT_WIDTH, TAB_WIDTH)
    assert ' '*4 == e.get_base_indent_string()
    assert ' '*4 == e.get_leading_whitespace(1)

    e = RoughParser('    x = 1\n', INDENT_WIDTH, TAB_WIDTH)
    assert ' '*4 == e.get_base_indent_string()
    assert ' '*4 == e

# Generated at 2022-06-24 08:07:34.108223
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def do(code, index, result, descr=None):
        hp = HyperParser(code, index)
        actual = hp.is_in_code()
        if actual is not result:
            msg = "\n" + descr + "\n" "input:\n" + code + "\n"
            msg += "index: " + index + "\n"
            msg += "result expected: " + str(result) + "\n"
            msg += "result got: " + str(actual) + "\n"
            raise test.test_support.TestFailed(msg)

    # code, index, result
    do('1 # comment', '1.0', True, 'cursor in code')
    do('1 # comment', '1.1', True, 'cursor in a digit')

# Generated at 2022-06-24 08:07:42.253815
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-outer-name

    def do(src, width, expected):
        parser = RoughParser(src, width)
        val = parser.compute_bracket_indent()
        print(src, "->", val)
        assert val == expected

    do('if 1:', 8, 4)
    do('if 1:  # this is a comment', 8, 4)
    do('if 1:    pass', 8, 8)
    do('if 1:    # this is a comment', 8, 8)
    do('if 1:  pass', 8, 4)
    do('if 1:\n    pass', 8, 8)
    do('if 1:  # comment\n    pass', 8, 8)

# Generated at 2022-06-24 08:07:53.060770
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():

    class AttrAccessClass(object):
        pass

    def assert_expected_bracketing(s, expected_output):
        parser = RoughParser(s, None)
        parser._study2()
        assert parser.stmt_bracketing == expected_output

    # Test that strings, comments and parens are treated as "brackets"

# Generated at 2022-06-24 08:08:00.869615
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))

    assert mapping.get(ord("c")) == ord("x")
    assert mapping.get(ord("\n"), None) == ord("\n")
    assert mapping.get(ord("x"), "y") == "y"


# Generated at 2022-06-24 08:08:11.153481
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    rp = RoughParser("while b:\n    c\n")
    assert rp.get_continuation_type() == C_NONE
    rp = RoughParser("while b:\n    c \\\n   \n")
    assert rp.get_continuation_type() == C_BACKSLASH
    rp = RoughParser("while b:\n    c = d\n")
    assert rp.get_continuation_type() == C_BRACKET
    rp = RoughParser("while b:\n    c = \\\n   d\n")
    assert rp.get_continuation_type() == C_BRACKET
    rp = RoughParser("while b:\n    c = [1, \\ \n   2, 3]\n")
    assert rp.get_continuation_type() == C_

# Generated at 2022-06-24 08:08:24.668103
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    "Make sure HyperParser.is_in_code returns the correct results."

    # Test cases:
    #   - the text to analyze
    #   - the index (where to place the cursor)
    #   - the expected result

# Generated at 2022-06-24 08:08:34.597478
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    is_in_code = HyperParser(text, center).is_in_code
    equal(is_in_code(), True)
    equal(is_in_code(1.0), True)
    equal(is_in_code("1.0"), True)
    equal(is_in_code("'q' + 'w'" + 1.0), True)
    equal(is_in_code(1.0 + 1), True)
    equal(is_in_code(1), True)
    equal(is_in_code("1 + 1 + 1"), True)
    equal(is_in_code("1 + 1 + 1"), True)
    equal(is_in_code('"q\\"w" + 1'), True)

# Generated at 2022-06-24 08:08:35.421733
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    assert 'invalid test'

# Generated at 2022-06-24 08:08:50.265378
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = "abc()"
    textwidget = Text()
    textwidget.insert("insert", text)

    # Test cases
    cases = [
        ("end", "", ""),
        ("insert", "()", ""),
        ("4.0", "", ""),
        ("2.0", "()", ""),
        ("1.0", "", "),("),
        ("1.0", "([{", "]})"),
        ("end-1c", "", ")"),
        ("4.0-1c", "", ")"),
        ("2.0-1c", "()", ""),
        ("1.0-1c", "", "),("),
        ("1.0-1c", "([{", "]})"),
    ]

# Generated at 2022-06-24 08:09:01.221037
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-24 08:09:11.749627
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    import pprint

# Generated at 2022-06-24 08:09:23.903287
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    from io import StringIO
    from tokenize import tokenize
    from unittest import TestCase
    from token import STRING, NAME, OP, NL, ENDMARKER

    class Tokenizer(object):
        def __init__(self, f):
            self.src = f
            self.tokenize()
        def tokenize(self):
            src = self.src
            tokenize(src.readline, self)
        def __iter__(self):
            return self
        def __next__(self):
            return next(self.tokens)

# Generated at 2022-06-24 08:09:36.240866
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"

# Pseudo-mappings for removing comments and docstring separators
TRANSL_COMMENTS = StringTranslatePseudoMapping({ord("\n"): None}, None)
TRANSL_DOCSTRING_SEPARATORS = StringTranslatePseudoMapping({ord("\n"): None}, None)

# Substitution patterns for unescaping string and bytes literals

_bslash = chr(92)


# Generated at 2022-06-24 08:09:46.523403
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    from itertools import permutations
    from random import sample
    from unittest import TestCase
    from unittest.mock import Mock


# Generated at 2022-06-24 08:09:50.000195
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rp = RoughParser("text\n\ntext\n", 0, 8)
    assert rp.get_num_lines_in_stmt() == 3
    rp = RoughParser("text\n\ntext\n", 0, 11)
    assert rp.get_num_lines_in_stmt() == 2


# Generated at 2022-06-24 08:10:00.674953
# Unit test for method set_lo of class RoughParser

# Generated at 2022-06-24 08:10:03.024261
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    rp = RoughParser("""\
a = [...
    ...
    lambda x: x * x,
    ]
""", 0)
    assert rp.get_continuation_type() == C_BRACKET



# Generated at 2022-06-24 08:10:07.126507
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Tkinter.Text()
    text.insert("insert", TEST_STRING)
    text.mark_set("insert", "4.0")
    hp = HyperParser(text, "insert")
    assert hp.is_in_string() == "1"
    hp.set_index("6.0")
    assert hp.is_in_string() == ""
    hp.set_index("8.0")
    assert hp.is_in_string() == "1"
    hp.set_index("10.0")
    assert hp.is_in_string() == ""


# Generated at 2022-06-24 08:10:17.476164
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from test import test_support

    def test(s, index, openers, mustclose, expect):

        if isinstance(s, bytes):
            s = s.decode("utf-8")
        t = Tk()
        t.withdraw()
        txt = Text(t)
        txt.insert("insert", s)
        txt.pack()

        p = HyperParser(txt, index)
        result = p.get_surrounding_brackets(openers, mustclose)
        if result is not None:
            result = (txt.index(result[0]), txt.index(result[1]))
        txt.destroy()
        t.destroy()
        if result != expect:
            print("test failed")
            print("expected ", expect)
            print("got      ", result)

# Generated at 2022-06-24 08:10:23.156390
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    # basic usage
    # - replace all chars with 'x'
    mapping = StringTranslatePseudoMapping({}, ord('x'))
    assert 'foo'.translate(mapping) == 'xxx'

    # - replace all chars except 'a' and 'b' with 'x'
    mapping = StringTranslatePseudoMapping({ord('a'): ord('a'),
                                            ord('b'): ord('b')},
                                           ord('x'))
    assert 'foobar'.translate(mapping) == 'xxxbxx'

    # no replacement
    mapping = StringTranslatePseudoMapping({}, None)
    assert 'foo'.translate(mapping) == 'foo'


# Special characters (subset of python identifier chars)

# Generated at 2022-06-24 08:10:26.537053
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({1: 10, 2: 20}, 3)
    assert mapping.get(0) == 3
    assert mapping.get(0, 0) == 0
    assert mapping.get(1) == 10



# Generated at 2022-06-24 08:10:37.226369
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    import pytest


# Generated at 2022-06-24 08:10:48.658020
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()
    istr = """if True:
    pass
"""
    rp.set_str(istr)
    assert rp.stmt_bracketing == ((0, 0), (4, 1), (4, 0), (8, 0), (12, 0))
    assert rp.get_base_indent_string() == "    "
    assert rp.get_last_open_bracket_pos() is None
    assert rp.is_block_opener() and not rp.is_block_closer()
    assert rp.continuation == 0
    assert rp.get_num_lines_in_stmt() == 0
    assert rp.compute_bracket_indent() == 4
    assert rp.compute_backslash_indent() == 4



# Generated at 2022-06-24 08:10:55.699421
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    # pylint: disable=redefined-builtin,undefined-variable
    import difflib, sys

    def validate(result, expected_base_indent, error_prefix=''):
        if not result and result == '':
            assert expected_base_indent is None, \
                   error_prefix + "base indent is '%s', not None" % result
        else:
            assert result == expected_base_indent, \
                   error_prefix + "base indent is '%s', not '%s'" \
                   % (result, expected_base_indent)

    # pylint: disable=unused-variable,too-many-branches,too-many-statements

# Generated at 2022-06-24 08:11:02.672489
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == len(preserve_dict)


# Generated at 2022-06-24 08:11:14.339611
# Unit test for constructor of class RoughParser

# Generated at 2022-06-24 08:11:24.338029
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    def check(text, continuation):  # pylint: disable=missing-docstring
        test_parser = RoughParser(text, "utf-8")
        assert test_parser.get_continuation_type() == continuation
        test_parser.reset(text, "utf-8")
        assert test_parser.get_continuation_type() == continuation

    s = "x" "=" "\"" "\\\n" "\""
    check(s, C_STRING_FIRST_LINE)
    check(" " + s, C_STRING_FIRST_LINE)
    check("\\\n" + s, C_STRING_FIRST_LINE)
    check("(" + s, C_BRACKET)
    check("(" "\\\n" + s, C_BRACKET)

# Generated at 2022-06-24 08:11:25.330121
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-24 08:11:31.012728
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    test_dict = {'test\n': 1,
                 'def test():\n    a = 3\n    b = 4\n    print(a + b)\n': 4,
                 'def test():\n    print(3 + 4)\nprint(': 2}
    for key, value in test_dict.items():
        assert RoughParser(key).get_num_lines_in_stmt() == value



# Generated at 2022-06-24 08:11:35.017511
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from idlelib.idle_test.htest import run

    run(HyperParser)


if __name__ == "__main__":
    test_HyperParser()

# Generated at 2022-06-24 08:11:43.168427
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    for (index, expected) in test_HyperParser.is_in_string:
        text = test_HyperParser.text
        index = text.index(index)
        hp = HyperParser(text, index)
        actual = hp.is_in_string()
        if actual != expected:
            print(
                "Failed: HyperParser(%r, %s).is_in_string()=%s, expected %s"
                % (text.get("1.0", "end"), index, actual, expected)
            )



# Generated at 2022-06-24 08:11:55.276851
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def t(cmd, openers, mustclose, res):
        if not isinstance(cmd, bytes):
            cmd = cmd.encode("utf-8")
        testcmd = cmd.replace(
            b"x", b" " if not isinstance(cmd, bytes) else b"x"
        )  # make sure there are no "real" x's
        hp = HyperParser(Text(testcmd), "insert")
        hp.set_index("insert")
        ret = hp.get_surrounding_brackets(openers=openers, mustclose=mustclose)
        eq = self.assertEqual
        if ret is None:
            eq(ret, res, "CMD: %s" % repr(cmd))

# Generated at 2022-06-24 08:12:07.604749
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():

    rp = RoughParser("")
    assert not rp.is_block_closer()

    rp = RoughParser(" \n")
    assert not rp.is_block_closer()

    rp = RoughParser("if bla\n")
    assert not rp.is_block_closer()

    rp = RoughParser("if bla: pass\n")
    assert rp.is_block_closer()

    rp = RoughParser("if bla: a = 2\n")
    assert not rp.is_block_closer()

    rp = RoughParser("if bla: a = 2\n   pass\n")
    assert rp.is_block_closer()

    rp = RoughParser("if bla: a = 2\n   pass # comment\n")
    assert r

# Generated at 2022-06-24 08:12:17.938203
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    def test(text, expected_result):
        parser = RoughParser(text)
        print(parser.get_num_lines_in_stmt())
        assert parser.get_num_lines_in_stmt() == expected_result

    test("a", 1)
    test("a\nb", 1)
    test("a\nb\nc", 1)

    test("a\\", 2)
    test("a\n\\", 2)
    test("a\n\\\n", 2)
    test("a\nb\n\\", 2)

    # Method get_num_lines_in_stmt returns the number of physical
    # lines in the last statement, even if that statement is not
    # interesting.
    test("# comment\n", 1)
    test("# comment\n\\\n", 2)
    test

# Generated at 2022-06-24 08:12:19.393347
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-24 08:12:28.572160
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Tkinter.Text()
    text.insert(END, 'print   ("hello there")')
    p = HyperParser(text, "1.4")
    assert p.is_in_code()
    p.set_index("1.9")
    assert p.is_in_code()
    p.set_index("1.1")
    assert p.is_in_code()
    p.set_index("1.14")
    assert not p.is_in_code()
    p.set_index("1.15")
    assert not p.is_in_code()
    text.insert(END, '#comment in the middle')
    p.set_index("2.1")
    assert not p.is_in_code()
    p.set_index("3.0")
    assert p

# Generated at 2022-06-24 08:12:35.148467
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    def t(text, first_line, last_line):
        assert text.count('\n') == (last_line - first_line)
        rp = RoughParser(text, indent_width=8)
        assert rp.get_num_lines_in_stmt() == (last_line - first_line + 1)
    def tE(text, exc):
        try:
            RoughParser(text, indent_width=8)
        except exc:
            pass
        else:
            raise AssertionError('%r' % (text,))
    stmt1 = 'x  =  5  +  \\'
    stmt2 = '\t\t\ty'
    stmt3 = 'x = "zzz\\'
    stmt4 = '\tzzz"'

# Generated at 2022-06-24 08:12:36.700205
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    #TODO
    pass

# Generated at 2022-06-24 08:12:45.103173
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    prog = """\
if True:
    if False:
        print("spam")
    else:
        print("ham")
else:
    if False:
        print("eggs")
"""
    parser = RoughParser(prog)
    parser._study2()
    assert parser.compute_bracket_indent() == 4
    pos = len(prog) - 1
    assert parser.compute_bracket_indent(pos) == 4
    pos = prog.find("if False:") + len("if False:")
    assert parser.compute_bracket_indent(pos) == 8

# Generated at 2022-06-24 08:12:55.365665
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():  # pylint: disable=invalid-name

    def _check(s, n):
        parser = RoughParser(s)
        assert parser.get_continuation_type() == C_BACKSLASH
        assert parser.get_num_lines_in_stmt() == n

    _check("a = 3\nb = 5\\\n   +4\n", 2)
    _check("a = 3\nb = 5\\\n   +4\\\n  + 5\n", 3)
    _check("a = 3\\\n   +4\n", 2)
    _check("a = 3\\\n   +4\\\n  + 5\n", 3)
    _check("a = 3\n\\\n   +4\n", 2)

# Generated at 2022-06-24 08:13:08.458623
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():

    def check(expected, str):
        parser = RoughParser(str)
        actual = parser.compute_backslash_indent()
        assert expected == actual, "{!r} !expected {!r}".format(str, expected)

    check(2, "a\\\n b")

    # Continuation is C_BACKSLASH if possible, else C_STRING_FIRST_LINE.
    # The first two of these are expected to be C_BACKSLASH, the third
    # C_STRING_FIRST_LINE.
    check(2, "a = b + \\\n      c\\\n   d")
    check(2, 'a = b + \\\n      c\\\n   d')
    check(2, "a = b + \\\n      '''\\\n   d'''")

   

# Generated at 2022-06-24 08:13:14.455901
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    assert list(mapping) == [10, 13, 9, 32]



# Generated at 2022-06-24 08:13:17.423914
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # This test also tests is_in_string() and is_in_code().
    text = Tkinter.Text()

# Generated at 2022-06-24 08:13:24.914631
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    lines = [
        'return 2;',
        'else:',
        '    a = 3;',
        '    b = 4;',
        'return 5;',
        '',
        '# comment line',
        'def f():',
        '    if a:',
        '        return 0;',
        '    if b:',
        '        return 1;',
        '',
        'def g():',
        '    return 2;',
    ]
    parser = RoughParser('\n'.join(lines))
    _test_block_closer(parser, lines)

# Generated at 2022-06-24 08:13:33.734371
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    def test_case(source_text, expected):
        rp = RoughParser(source_text, None)
        assert rp.get_last_stmt_bracketing() == expected, \
            (rp.get_last_stmt_bracketing(), expected)
    test_case('', None)
    test_case('#', None)
    test_case('#\n', None)
    test_case('#\n\n', None)
    test_case('#\n\n\n', None)
    test_case('a', ((0, 0), (1, 0)))
    test_case('#\na', ((1, 0), (2, 0)))
    test_case('#\n\na', ((2, 0), (3, 0)))

# Generated at 2022-06-24 08:13:43.885981
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    """
    See comments in the definition of class StringTranslatePseudoMapping
    for example usage.  The code below is an equivalent of that example
    which should raise an error if the constructor can't be invoked
    as shown in the example.
    """
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))

# Unit tests for _parse_lines()

# Generated at 2022-06-24 08:13:50.511139
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=redefined-builtin

    # pylint: disable=unbalanced-tuple-unpacking

    def noop(parser):
        pass

    def check_eq(parser, expected):
        if parser.get_continuation_type() != expected:
            raise RuntimeError(
                "test failed:\n"
                '  source = "%s"\n'
                "  parser = %r\n"
                "  parser.get_continuation_type() = %r\n"
                "  expected = %r"
                % (source, parser, parser.get_continuation_type(), expected)
            )

    def check_eq2(parser, expected):
        got = parser.get_last_stmt_bracketing()

# Generated at 2022-06-24 08:14:03.020307
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Test case 1:
    hp = HyperParser(tk.Text(), index="end")
    hp.rawtext = "()[{}]"
    hp.bracketing = ((0, 0), (1, 0), (2, 1), (3, 0), (4, 1), (5, 0))
    hp.isopener = (1, 0, 1, 1, 0, 0)
    hp.indexinrawtext = 5
    hp.indexbracket = 5
    assert hp.get_surrounding_brackets(openers="[]{(") == ("1.0", "3.0")
    assert hp.get_surrounding_brackets() == ("2.0", "5.0")

    # Test case 2:
    hp = HyperParser(tk.Text(), index="end")

# Generated at 2022-06-24 08:14:09.388915
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    class Ok(Exception): pass

# Generated at 2022-06-24 08:14:19.137890
# Unit test for method is_block_opener of class RoughParser

# Generated at 2022-06-24 08:14:28.381858
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    rp = RoughParser('''
if a:
    if b:
        pass
''')
    rp.get_last_open_bracket_pos() == (
        rp.str.index('if b'))

import re

# Helpers for regexp-based scanner
#

# this regexp matches the start of a comment or string
_startprogre = re.compile(
    r"""
    (?P<char>
        [\'\"]         # either kind of quote
    )
    |
    (?P<comment>
        # anything beginning with # (unless # is preceded by \)
        (?<!\\)
        \#
    )
""",
    re.VERBOSE,
)

# this regexp matches the end of a string, or the start of a comment
#

# Generated at 2022-06-24 08:14:39.202782
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    """
    >>> test_RoughParser_get_last_stmt_bracketing()
    test_get_last_stmt_bracketing passed.
    """
    test_str = (
        'class FooBar(object):\n'
        '    """\n'
        '    Foo Bar class\n'
        '    """\n'
        '    def __init__(self, name):\n'
        '        """\n'
        '        constructor\n'
        '        """\n'
        '        self._name = name\n'
    )
    rp = RoughParser(test_str)
    rp.parse()
    # print(rp.get_last_stmt_bracketing())

# Generated at 2022-06-24 08:14:49.224916
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    rp = RoughParser("")
    assert rp.get_last_stmt_bracketing() == None
    rp = RoughParser(" ", tabsize=None)
    assert rp.get_last_stmt_bracketing() == None
    rp = RoughParser(" ", tabsize=None)
    assert rp.get_last_stmt_bracketing() == None
    rp = RoughParser(" \n  def foo(a):\n    pass", tabsize=None)
    assert rp.get_last_stmt_bracketing() == ((10, 0), (12, 1), (17, 0))
    rp = RoughParser("\n  def foo(a):\n    pass", tabsize=None)

# Generated at 2022-06-24 08:14:55.760773
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # Simple test
    rough_parser = RoughParser('x = "hello\\\nyou"')
    assert (rough_parser.get_continuation_type() == C_STRING_NEXT_LINES)

    # More complicated test
    rough_parser = RoughParser(dedent('''\
        def foo():
        \tx = "hello\\
        \tyou"
        '''))
    assert (rough_parser.get_continuation_type() == C_STRING_NEXT_LINES)


# Unit tests for the class RoughParser

# Generated at 2022-06-24 08:14:59.861288
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    mapping = StringTranslatePseudoMapping({}, None)
    assert len(mapping) == 0
    mapping = StringTranslatePseudoMapping({ord('a'): ord('x')}, ord(' '))
    assert len(mapping) == 1

# Generated at 2022-06-24 08:15:08.471778
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from idlelib.WidgetRedirector import WidgetRedirector

    class Dummy_editor:
        def __init__(self, text):
            self.text = WidgetRedirector(text)

        def index(self, index):
            return self.text.index(index)

    class Dummy_text:
        def __init__(self, string):
            self.string = string

        def get(self, index1, index2):
            return self.string[int(float(index1)):int(float(index2))]

        def index(self, index):
            return index

    t = Dummy_text("""print('Hello, world!')
"abc " 'abc'
""")
    e = Dummy_editor(t)
    hp = HyperParser(t, "1.0")
    assert hp

# Generated at 2022-06-24 08:15:17.393882
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    """Callable unit test for method get of class StringTranslatePseudoMapping"""
    test_dict = {ord("a"): "A", ord("b"): "B", ord("c"): "C",
                 ord("d"): "D"}
    mapping = StringTranslatePseudoMapping(test_dict, "X")
    assert mapping.get('foo', 'bar') == "bar"
    assert mapping.get('foo', 'bar') is not 'bar'
    assert mapping.get('foo', 'bar') != 'bar'
    assert mapping.get(ord("a"), 'X') == "A"
    assert mapping.get(ord("a"), 'X') != "A"
    assert mapping.get(ord("a"), 'X') is not "A"
    assert mapping.get(ord("z"), 'X')