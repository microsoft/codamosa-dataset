

# Generated at 2022-06-24 08:05:22.543583
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    # pylint: disable=missing-docstring, invalid-name
    from pytest import raises  # pylint: disable=redefined-outer-name

# Generated at 2022-06-24 08:05:27.983872
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from test.support import import_helper

    tk = import_helper.import_module("tkinter")
    text = tk.Text()
    text.insert("insert", "if True: pass # comment\n")
    text.insert("insert", "if True: pass # comment\n")
    text.mark_set("insert", "2.0")
    assert HyperParser(text, "insert").is_in_code()

# Generated at 2022-06-24 08:05:29.988572
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    import pytest


# Generated at 2022-06-24 08:05:35.172581
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    non_defaults = {1:11, 2:22, 3:33}
    default_value = -1
    mapping = StringTranslatePseudoMapping(non_defaults, default_value)
    expected = [1, 2, 3]
    assert sorted(mapping.__iter__()) == expected



# Generated at 2022-06-24 08:05:43.474681
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser("\nif True:\n    try:\n        pass\n    except:\n        pass\n")
    assert rp.is_block_opener() == True
    rp = RoughParser("\nif True:\n    try:\n        pass\n    except:\n        pass\n")
    assert rp.is_block_opener() == True
    rp = RoughParser("\nif True:\n    try:\n        pass\n    except:\n        pass\n")
    assert rp.is_block_opener() == True


# Generated at 2022-06-24 08:05:51.790491
# Unit test for constructor of class RoughParser

# Generated at 2022-06-24 08:06:02.404440
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    from pygments.lexers.python import Python3Lexer

    class DummySkeletons:
        config = DummyConfig()

    s = """\
# some comment not inside the string
if True:
    if True:
      some_variable_that_keeps_the_indent = 42
"""
    rp = RoughParser(DummySkeletons, s, Python3Lexer())
    assert rp.compute_bracket_indent() == 0

    s = """\
# some comment not inside the string
if True:
    if True:
       some_variable_that_keeps_the_indent = 42
"""
    rp = RoughParser(DummySkeletons, s, Python3Lexer())
    assert rp.compute_bracket_indent() == 0


# Generated at 2022-06-24 08:06:13.422969
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    test_string = "some[text]"
    mapping_dict = {ord('['): ord('('), ord(']'): ord(')')}
    non_default_mapping = StringTranslatePseudoMapping(mapping_dict, ord('x'))
    assert test_string.translate(non_default_mapping) == "some(text)"
    test_string = "some[text]{(with_other_text)}"
    assert test_string.translate(non_default_mapping) == "some(text)x(with_other_text)x"
    mapping_dict = {}
    non_default_mapping = StringTranslatePseudoMapping(mapping_dict, ord('x'))
    assert test_string.translate(non_default_mapping) == "xxxxxxx"
test_String

# Generated at 2022-06-24 08:06:17.006998
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rp = RoughParser("foo \\\n bar \\", 0, 0)
    assert rp.compute_backslash_indent() == 2  # It's a hack
    rp.str = "foo = \\ \nbar"
    assert rp.compute_backslash_indent() == 6
    rp.str = "foo = bar \\ \n   bar = foo"
    assert rp.compute_backslash_indent() == 6



# Generated at 2022-06-24 08:06:28.218872
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    parser = RoughParser(
        r"""
a = x + y
if z > 0:
    z = z * 2
"""
    )
    assert parser.find_good_parse_start() == 6
    assert parser.find_good_parse_start(0) == 6
    assert parser.find_good_parse_start(10) == 6
    assert parser.find_good_parse_start(23) == 6
    assert parser.find_good_parse_start(5, 23) == 23
    assert parser.find_good_parse_start(3, 23) == 3
    parser = RoughParser(
        r"""
a = x + y\
"""
    )
    assert parser.find_good_parse_start() == 6
    assert parser.find_good_parse_start(0) == 6
    assert parser.find

# Generated at 2022-06-24 08:06:39.157077
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    _test_objs = [
        StringTranslatePseudoMapping({}, 0),
        StringTranslatePseudoMapping({1: 2, 3: 4}, 0),
    ]
    _test_keys = [-1, 0, 1, 2, 3]

    for obj in _test_objs:
        for key in _test_keys:
            value = obj.__getitem__(key)

    # Example from the docstring
    mapping = StringTranslatePseudoMapping({32: 32, 9: 9, 10: 10, 13: 13}, 120)
    assert mapping[32] == 32
    assert mapping[9] == 9
    assert mapping[10] == 10
    assert mapping[13] == 13
    assert mapping[1] == 120
    assert mapping[2] == 120

# Generated at 2022-06-24 08:06:46.055151
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    assert RoughParser("\nif 1:\n  f(a)\n").compute_bracket_indent() == 2
    assert RoughParser("\nif 1:\n f(a)\n").compute_bracket_indent() == 2
    assert RoughParser("\nif 1:\n  \n f(a)\n").compute_bracket_indent() == 2
    assert RoughParser("\nif 1:\n  pass\n f(a)\n").compute_bracket_indent() == 2
    assert RoughParser("\nif 1:\n  pass\n  f(a)\n").compute_bracket_indent() == 4
    assert RoughParser("\nif 1:\n  pass\n\n  f(a)\n").compute_bracket_indent() == 4

# Generated at 2022-06-24 08:06:58.003142
# Unit test for method is_block_opener of class RoughParser

# Generated at 2022-06-24 08:07:05.962802
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    expected = 'x x x\tx\nx'
    result = text.translate(mapping)
    assert result == expected, result

test_StringTranslatePseudoMapping()
del test_StringTranslatePseudoMapping

# Utility stuff used by all parsers.


# Generated at 2022-06-24 08:07:11.446770
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert mapping[ord(' ')] == ord(' ')
    assert mapping[ord('x')] == ord('x')

# Generated at 2022-06-24 08:07:20.402970
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase


# Generated at 2022-06-24 08:07:28.402479
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    from idlelib import hyperparser
    from idlelib.idle_test.htest import mock_idle
    from types import MappingProxyType
    root = mock_idle.create_root(None)
    with mock_idle.mock_idle_test(root):
        # Example 1: MappingProxyType of StringTranslatePseudoMapping
        translate_non_defaults = {ord('a'): ord('z'), ord('b'): ord('y')}
        translate_default = ord('x')
        mapping = hyperparser.StringTranslatePseudoMapping(
            translate_non_defaults,
            translate_default)
        mapping_proxy = MappingProxyType(mapping)
        assert {ord('a'), ord('b')} == set(mapping_proxy)
        # Example 2: Mapping

# Generated at 2022-06-24 08:07:35.335244
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    assert RoughParser("").get_continuation_type() == C_NONE
    assert RoughParser("   \n   \n   \n").get_continuation_type() == C_NONE
    assert RoughParser("   \n#blah\n   \n").get_continuation_type() == C_NONE
    assert RoughParser("1 + 1").get_continuation_type() == C_NONE
    assert RoughParser("1 + \\").get_continuation_type() == C_BACKSLASH
    assert RoughParser("[").get_continuation_type() == C_BRACKET
    assert RoughParser("()").get_continuation_type() == C_NONE
    assert RoughParser("(\\").get_continuation_type() == C_BACKSLASH
    assert RoughParser("[\\").get_continuation_type

# Generated at 2022-06-24 08:07:42.381083
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def test(code, indent_width, tabwidth, result, reason):
        rp = RoughParser(code, indent_width, tabwidth)
        rp._study2()
        if rp.compute_bracket_indent() != result:
            print("failed test %r" % reason)
            print("  code: %r" % code)
            print("  indent_width: %r" % indent_width)
            print("  tabwidth: %r" % tabwidth)
            print("  result: %r" % result)

    test("", 4, 8, 0, "empty")
    test("[", 4, 8, 4, "just open bracket")
    test("[\n", 4, 8, 4, "just open bracket w/newline")

# Generated at 2022-06-24 08:07:53.144906
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=redefined-builtin

    # Empty string.
    s = RoughParser("")
    eq = test.support.check_impl_detail
    eq(s.get_base_indent_string(), "")
    eq(s.get_continuation_type(), C_NONE)
    eq(s.get_last_open_bracket_pos(), None)
    eq(s.get_num_lines_in_stmt(), 0)
    eq(s.get_last_stmt_bracketing(), None)
    eq(s.is_block_closer(), False)
    eq(s.is_block_opener(), False)

    # Whitespace only.
    s = RoughParser("    \t\n   # comment\n\n   \t")

# Generated at 2022-06-24 08:08:03.837078
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rp = RoughParser("    foo = bar\\\n    baz", 4, 0)
    assert rp.compute_backslash_indent() == 4

    rp = RoughParser("    foo = bar\\\n    baz", 4, 4)
    assert rp.compute_backslash_indent() == 8

    rp = RoughParser("    foo = bar\\\n    baz", 4, 8)
    assert rp.compute_backslash_indent() == 12

    rp = RoughParser("    foo = bar\\\n    baz", 0, 0)
    assert rp.compute_backslash_indent() == 0

    rp = RoughParser("    foo = bar\\\n    baz", 0, 4)
    assert rp.compute_backslash_

# Generated at 2022-06-24 08:08:13.494105
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    #redefining assert_equal to shut pylint warnings
    my_assert_equals = assert_equal
    def assert_equal(val1, val2):
        my_assert_equals(tuple(val1), tuple(val2))
    
    def assert_not_equal(val1, val2):
        if tuple(val1) == tuple(val2):
            raise AssertionError
    
    class TestCase(object):
        def assert_equal(self, val1, val2):
            my_assert_equals(tuple(val1), tuple(val2))
        def assert_not_equal(self, val1, val2):
            if tuple(val1) == tuple(val2):
                raise AssertionError
    

# Generated at 2022-06-24 08:08:25.657745
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=redefined-builtin
    # Test for bug 1153661: find_good_parse_start() should ignore
    # blank and comment lines.
    r = RoughParser("def f():\n  if a:\n    pass\n")
    pos = r.find_good_parse_start()
    # This depends on the implementation detail that find_good_parse_start
    # returns the first good line number rather than its position
    assert pos == 1
    # Check that find_good_parse_start() can handle trigger strings
    # that don't start at the beginning of the buffer.
    pos = RoughParser("foo\n\n  def f():\n  if a:\n    pass\n", pos=4).find_good_parse_start()
    assert pos == 3


# Generated at 2022-06-24 08:08:34.607708
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    ## Test that the hyperparser finds strings and comments.
    text = """\
# This is a comment, but this is not "This is a string."
    # Neither is this.
    not_a_string_either = 'But this is "a string".'
    # Neither is this.
    nor_this = """
    # Neither is this.
    # Neither is this.
    """
    also_not_a_string = 'Nor this: # Not a comment either.'
    'This is another string.'
    """
    for i in range(len(text) + 1):
        hp = HyperParser(tkinter.Text(), text, "%d.0" % i)

# Generated at 2022-06-24 08:08:39.967047
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    a = tests.get_example_string()
    bp = RoughParser(a)
    x = bp.compute_backslash_indent()
    assert x == 1

    a = """\
c = a + \
    b
"""
    bp = RoughParser(a)
    x = bp.compute_backslash_indent()
    assert x == 5

    a = """\
c = a + \
    \
    b
"""
    bp = RoughParser(a)
    x = bp.compute_backslash_indent()
    assert x == 5

    a = """\
c = a + \\
    b
"""
    bp = RoughParser(a)
    x = bp.compute_backslash_indent()
    assert x == 5

   

# Generated at 2022-06-24 08:08:47.392580
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # Make sure that the method returns correct value
    text = tk.Text()
    text.insert('1.0', 'testing HyperParser.set_index\n')
    text.insert('2.0', 'def idd(i): pass\n')
    text.mark_set('insert', '3.0')
    hl = HyperParser(text, '3.0')
    hl.set_index('3.0')
    s = "s"
    if hl.get_expression() == s:
        print("set_index passed")
    else:
        print("set_index failed")
test_HyperParser_set_index()


# Generated at 2022-06-24 08:08:56.641332
# Unit test for constructor of class HyperParser
def test_HyperParser():
    data = 'foo(0, 1, "bar", \'baz\', "", "\\"")'
    t = Text()
    t.insert(END, data)
    hp = HyperParser(t, "1.10")
    assert hp.text == t
    assert hp.indexinrawtext == 10
    assert hp.indexbracket == 6
    assert hp.stopatindex == "1.end"
    assert hp.rawtext == data
    assert hp.bracketing == [(0, 0), (0, 0), (3, 0), (3, 1), (10, 0), (10, 1), (17, 0), (17, 1), (24, 0), (24, 1), (26, 0), (26, 1), (31, 0), (31, 1), (34, 0), (34, 1)]

# Generated at 2022-06-24 08:09:09.620881
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    text.insert("1.0", "class A:\n def b():\n  pass")
    text.mark_set("insert", "1.0")
    hp = HyperParser(text, "insert")
    hp.set_index("1.0")
    assert hp.indexbracket == 0
    assert hp.indexinrawtext == 0
    hp.set_index("1.4")
    assert hp.indexbracket == 0
    assert hp.indexinrawtext == 4
    hp.set_index("1.6 linestart")
    assert hp.indexbracket == 0
    assert hp.indexinrawtext == 6
    hp.set_index("2.0")
    assert hp.indexbracket == 0
    assert hp.indexinrawtext == 7

# Generated at 2022-06-24 08:09:22.468261
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    def check_bracketing(s, expected):
        parser = RoughParser(s, 0)
        assert parser.get_last_stmt_bracketing() == expected, (
            "for %r, expected %r, got %r" % (s, expected, parser.get_last_stmt_bracketing())
        )
    check_bracketing("if foo(): bar()\nelse: baz()", ((0, 0), (5, 1), (10, 0)))
    check_bracketing("a = 2", ())
    check_bracketing("a = 2  # blah blah blah", ())
    check_bracketing("a = 2  # blah blah blah\\\n  not_a_comment()", ((0, 0), (16, 0)))

# Generated at 2022-06-24 08:09:30.467863
# Unit test for method __getitem__ of class StringTranslatePseudoMapping

# Generated at 2022-06-24 08:09:41.002847
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():  # No semicolon before docstring
    def assert___getitem__(args, non_defaults, default_value, expected):
        mapping = StringTranslatePseudoMapping(non_defaults, default_value)
        actual = mapping.__getitem__(args)
        assert actual == expected, "__getitem__({!r}) == {} != {}".format(args, actual, expected)
    assert___getitem__(0, {0: 1, 1: 2}, 3, 1)
    assert___getitem__(1, {0: 1, 1: 2}, 3, 2)
    assert___getitem__(2, {0: 1, 1: 2}, 3, 3)
    assert___getitem__(0, {}, 3, 3)
    assert___getitem__(1, {}, 3, 3)
    assert___

# Generated at 2022-06-24 08:09:48.272942
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rough_parser = RoughParser("if x:", 0)
    if rough_parser.is_block_opener():
        print("PASSED")
    else:
        print("FAILED")

    rough_parser2 = RoughParser("#if x:", 0)
    if not rough_parser2.is_block_opener():
        print("PASSED")
    else:
        print("FAILED")

    rough_parser3 = RoughParser("if x: y = 3", 0)
    if not rough_parser3.is_block_opener():
        print("PASSED")
    else:
        print("FAILED")

    rough_parser4 = RoughParser('if x: y = "xxx"', 0)
    if not rough_parser4.is_block_opener():
        print("PASSED")
   

# Generated at 2022-06-24 08:09:56.369020
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    assert HyperParser("'''" + '"', "1.4").is_in_string()
    assert HyperParser("'''" + "'", "1.4").is_in_string()
    assert not HyperParser("'''" + "'", "1.3").is_in_string()
    assert not HyperParser("'''" + "'", "1.5").is_in_string()
    assert not HyperParser("'''" + '"', "1.3").is_in_string()
    assert not HyperParser("'''", "1.3").is_in_string()



# Generated at 2022-06-24 08:10:02.651257
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rp = RoughParser(tabwidth=4)
    assert rp.get_num_lines_in_stmt() == 0

    rp.set_str('''\
if a:
    pass
''')
    assert rp.get_num_lines_in_stmt() == 1

    rp.set_str('''\
if a:
    pass
else:
    pass
''')
    assert rp.get_num_lines_in_stmt() == 2

    rp.set_str('''\
if a:
    pass
elif b:
    pass
''')
    assert rp.get_num_lines_in_stmt() == 2


# Generated at 2022-06-24 08:10:14.425899
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    parser = RoughParser()
    parser.set_str('a = 2 + 3\nfoo()')
    assert parser.get_last_stmt_bracketing() == ((0, 0), (1, 0), (2, 0),
                                                 (3, 0), (4, 0), (5, 0),
                                                 (6, 0))
    parser.set_str('a = 2 + 3\nfoo()')
    assert parser.get_bracket_indent() == 0
    parser.set_str('a = 2 + [3]\nfoo()')
    assert parser.get_bracket_indent() == 10
    parser.set_str('a = 2 + [3]\n    foo()')
    assert parser.get_bracket_indent() == 10

# Generated at 2022-06-24 08:10:22.966878
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = get_main_text_widget()
    text.delete("1.0", "end")
    text.insert("1.0", "def foo():\n    bar\n")
    s = HyperParser(text, "1.6")
    assert s.get_surrounding_brackets() == ("1.0", "1.7")
    s = HyperParser(text, "2.0")
    assert s.get_surrounding_brackets() == ("1.9", "2.0")
    s = HyperParser(text, "1.10")
    assert s.get_surrounding_brackets() == ("1.9", "2.5")
    s = HyperParser(text, "1.5")
    assert s.get_expression() == "foo"



# Generated at 2022-06-24 08:10:35.347503
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    doc = '"""just testing"""\n'
    doc += 'code = "no-code-here"\n'
    doc += '#notcode = 3\n'
    doc += 'def func():\n'
    doc += '    pass\n'
    doc += 'class Klass:\n'
    doc += '    pass\n'
    doc += 'outer = "no-code-here-either"'

    hp = HyperParser(tkinter.Text(None), "1.0")
    hp.text.insert("1.0", doc)

    # Go over the whole document and make sure the HyperParser
    # reports that this is code in what we expect to be code and not
    # in what we expect to be not code.

# Generated at 2022-06-24 08:10:40.343521
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"

_is_closed_re = re.compile(r"^\s*(#|$)").match



# Generated at 2022-06-24 08:10:47.024324
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # return a HyperParser of a code in form of a string, at the given character index
    def gethp(code, index):
        text = CodeWidget(None)
        text.replace("1.0", "end", code)
        text.compile()
        return HyperParser(text, "%d.0" % index)

    gethp("if 1:", 0)
    gethp("a = {0: []}", 5)
    gethp("[0, (1,), 2, 3][1]", 14)
    gethp("len(a)", 6)
    gethp("a[::]", 4)
    gethp("a.b", 3)
    gethp("15", 2)

    try:
        gethp("if 1:", 3)
    except ValueError:
        pass
    else:
        raise Ass

# Generated at 2022-06-24 08:10:54.873696
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def _get_base_indent_string(s):
        return RoughParser(s, 0).get_base_indent_string()
    assert _get_base_indent_string("foo") == ""
    assert _get_base_indent_string("  foo") == "  "
    assert _get_base_indent_string("\tfoo") == "\t"
    assert _get_base_indent_string("\t  foo") == "\t  "
    assert _get_base_indent_string("\t  foo\n\t  bar") == "\t  "
    assert _get_base_indent_string("\t  foo\n\t  bar\n\t  baz") == "\t  "


# Generated at 2022-06-24 08:11:08.332947
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    h = HyperParser("", "1.0")

    # In a string
    h.rawtext = ''
    h.isopener = [True]
    h.indexbracket = 0
    h.indexinrawtext = 0
    h.stopatindex = '1.0'
    assert h.get_expression() == ''

    # In a comment
    h.rawtext = '#ab\n'
    h.isopener = [True]
    h.indexbracket = 0
    h.indexinrawtext = 3
    h.stopatindex = '1.0'
    assert h.get_expression() == ''

    # Simple
    h.rawtext = 'ab\n'
    h.isopener = [False]
    h.indexbracket = 0
    h.indexinrawtext = 2

# Generated at 2022-06-24 08:11:17.822132
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    # pylint: disable=redefined-builtin
    def _check(text, expect):
        p = RoughParser(text)
        got = p.is_block_opener()
        assert got == expect, "expected %r, got %r for |%s|" % (
            expect,
            got,
            text,
        )

    _check("if True:", True)
    _check("if True:  # abc", True)
    _check("if True:\n  pass  # abc", True)
    _check("def foo():", True)
    _check("def foo():  # abc", True)
    _check("def foo():\n  pass  # abc", True)
    _check("class Foo:", True)
    _check("class Foo:  # abc", True)


# Generated at 2022-06-24 08:11:31.436148
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    """Unit test for method get_expression of class HyperParser."""

    class DummyEditwin:
        text = None

    def do_tests(tests):
        for expr, index, expected in tests:
            index = "%d.%d" % index
            hyper = HyperParser(DummyEditwin, expr, index)
            got = hyper.get_expression()
            assert got == expected, "got %s, expected %s" % (got, expected)

    # Test cases where we got an empty expression

# Generated at 2022-06-24 08:11:36.733241
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def _test_expression(self, text, index, expected):
            hyper = HyperParser(text, index)
            expression = hyper.get_expression()
            self.assertEqual(
                expression,
                expected,
                "HyperParser.get_expression() should return expected "
                "expression:\n%r\nActual expression:\n%r\n"
                "Text:\n%r\n" % (expected, expression, (text.get("1.0", "end"))),
            )

        def test_basic(self):
            self._test_expression("foo(bar)bar","1.8", "bar")
            self._test_expression("foo(bar)bar","1.9", "bar")

# Generated at 2022-06-24 08:11:45.281467
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    # pylint: disable=redefined-builtin

    # ------------------------------ TESTS ------------------------------
    cases = [
        (C_NONE, False),
        (C_BACKSLASH, False),
        (C_STRING_FIRST_LINE, False),
        (C_STRING_NEXT_LINES, False),
        (C_BRACKET, False),
        (None, False),
    ]
    str = ": \n"
    for continuation, expected in cases:
        parser = RoughParser(str, continuation, TABSIZE)
        actual = parser.is_block_opener()
        assert expected == actual

# Generated at 2022-06-24 08:11:49.463525
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    doctest.run_docstring_examples(
            HyperParser.is_in_code,
            {"HyperParser": HyperParser},
            verbose=False,
    )


# Generated at 2022-06-24 08:11:58.935195
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin
    # test the start of a function def
    s = "def foo(a, b, c):"
    rp = RoughParser("def foo(a, b, c):", 0)
    assert rp.compute_bracket_indent() == 0

    # test the start of a class def
    s = "class foo(a, b, c):"
    rp = RoughParser("class foo(a, b, c):", 0)
    assert rp.compute_bracket_indent() == 0

    # test an if statement
    s = "if 1:\n  pass"
    rp = RoughParser(s, 0)
    assert rp.compute_bracket_indent() == 2

    # test an if-else statement

# Generated at 2022-06-24 08:12:09.910833
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    assert RoughParser("").is_block_closer() == False
    assert RoughParser("abc").is_block_closer() == False
    assert RoughParser(" return").is_block_closer() == False
    assert RoughParser("return").is_block_closer() == True
    assert RoughParser("return a").is_block_closer() == True
    assert RoughParser("return a\n").is_block_closer() == True
    assert RoughParser("return a #\n").is_block_closer() == True
#@+node:ekr.20120626085232.12485: *4* class PythonIndenter

# Generated at 2022-06-24 08:12:19.789788
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    p = RoughParser("    if 1:pass")
    assert p.get_base_indent_string() == "    "
    p = RoughParser("    if 1:pass\n      pass")
    assert p.get_base_indent_string() == "      "
    p = RoughParser("    if 1:pass   \n    pass")
    assert p.get_base_indent_string() == "    "
    p = RoughParser(
        """
        if 1:
            pass
""",
        indent_width=4,
        tabwidth=4,
    )
    assert p.get_base_indent_string() == "        "
    p = RoughParser(
        """
if 1:
    pass
""",
        indent_width=4,
        tabwidth=4,
    )

# Generated at 2022-06-24 08:12:28.946837
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = "text.text\n"
    index = "3.3"
    hp = HyperParser(text, index)
    assert hp.get_surrounding_brackets() == ("1.0", "4.0"), "Wrong brackets found 1"
    index = "1.7"
    hp.set_index(index)
    assert hp.get_surrounding_brackets() == ("1.0", "4.0"), "Wrong brackets found 2"
    index = "1.2"
    hp.set_index(index)
    assert hp.get_surrounding_brackets() == None, "Wrong brackets found 3"
    text = "(a+b)\n"
    index = "1.2"
    hp = HyperParser(text, index)
    assert hp.get_surrounding_br

# Generated at 2022-06-24 08:12:39.400397
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text(None)
    text.insert("1.0", "( A B 'string) #")
    hp = HyperParser(text, "1.16")
    assert not hp.is_in_code(), "Failed: is_in_code 1"
    hp = HyperParser(text, "1.15")
    assert hp.is_in_code(), "Failed: is_in_code 2"
    assert not hp.is_in_string(), "Failed: is_in_string 3"
    hp = HyperParser(text, "1.14")
    assert hp.is_in_code(), "Failed: is_in_code 4"
    assert hp.is_in_string(), "Failed: is_in_string 5"
    hp = HyperParser(text, "1.11")

# Generated at 2022-06-24 08:12:51.553621
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    class testclass:
        def __init__(self, s):
            self.s = s
            self.index = self.s.index

    text = testclass("(gasp) # goo")
    hp = HyperParser(text, "1.0")
    hp.set_index("1.4")
    assert hp.bracketing[hp.indexbracket][0] == 2
    assert hp.indexinrawtext == 4
    assert hp.rawtext == "(gasp) "
    assert hp.is_in_code()
    assert not hp.is_in_string()
    assert not hp.get_expression()
    hp.set_index("1.5")
    assert hp.is_in_code()
    assert not hp.is_in_string()

# Generated at 2022-06-24 08:13:04.994499
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def test(text, index, expectedResult):
        hp = HyperParser(text, index)
        if hp.get_surrounding_brackets() != expectedResult:
            print(
                "Error: for text '%s' and index '%s' expected '%s', "
                "but got '%s'"
                % (text.string, index, expectedResult, hp.get_surrounding_brackets())
            )

    # Test various ways to get the return value None.
    test(
        editor,
        "9.10",
        None,
    )
    test(
        editor,
        "16.0",
        None,
    )

    # Test that we can get it right.

# Generated at 2022-06-24 08:13:17.870127
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    tester = _RoughParser()
    tester.set_str("")
    # (1) test bracket continuation
    tester.set_str("a={\nb=1\n")
    assert tester.get_continuation_type() == C_BRACKET
    assert tester.compute_bracket_indent() == 2
    tester.set_str("a={\n    b=1\n")
    assert tester.get_continuation_type() == C_BRACKET
    assert tester.compute_bracket_indent() == 6
    tester.set_str("{\n{\n{\n{\n{\n{\n{\n{\n{\n{\n{\n{\n")
    assert tester.get_continuation_type() == C_BRACKET
    assert tester.compute

# Generated at 2022-06-24 08:13:26.466662
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    test_cases = [
        ('{}', 0),
        ('{1: 2}', 1),
        ('{1: 2, 3: 4}', 2),
        ('{1: 2, 2: 3}', 2),
        ('set()', 0),
        ('{1}', 1),
        ('{1, 2}', 2),
        ('{1, 2, 3, 1}', 3),
        ('{1, 1, 1, 1}', 1),
    ]

    for test_case in test_cases:
        assert len(StringTranslatePseudoMapping(eval(test_case[0]), -1)) == test_case[1]



# Generated at 2022-06-24 08:13:30.999617
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    preserve_dict = {ord('a'): ord('a'), ord('b'): ord('b')}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    text = text.translate(mapping)
    assert text == "a b\tx\nd"



# Generated at 2022-06-24 08:13:43.822369
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-24 08:13:50.418520
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    import sys
    import io
    import sys
    import unittest

    from idlelib.pyshell import hlist

    class PseudoMappingTest(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            test_text = '"a" + "b"\t"c"\n"d"'
            cls.default_value = ord('x')
            cls.whitespace_chars = ' \t\n\r'
            cls.preserve_dict = {ord(c): ord(c) for c in cls.whitespace_chars}
            cls.mapping = hlist.StringTranslatePseudoMapping(
                cls.preserve_dict, cls.default_value
            )

        def setUp(self):
            self

# Generated at 2022-06-24 08:14:00.314299
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """
    Unit test for method set_index of class HyperParser

    """
    import unittest
    from unittest.mock import Mock

    class TestCase(unittest.TestCase):
        def setUp(self):
            text = Mock(spec=["index", "get", "indent_width", "tabwidth"])
            text.get.return_value = "    if x:\n        while y:\n            z = z + 1\n        "
            text.index.side_effect = lambda s: int(float(s))
            self.hyper = HyperParser(text, "16.15")

    # Found a bug in the HyperParser implementation.
    # If an index is given for which indentation is not valid Python code,
    # HyperParser will raise a ValueError. It is not clear what is expected
    # in

# Generated at 2022-06-24 08:14:02.978519
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rough_parser
test_RoughParser_is_block_opener()

# Generated at 2022-06-24 08:14:09.369728
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class GetSurroundingBracketsTest(unittest.TestCase):
        # Tests for get_surrounding_brackets

        def setUp(self):
            self.text = text = Text(None)
            text.insert("1.0", "a\nb")
            text.mark_set("insert", "1.0")

        def tearDown(self):
            self.text.delete("1.0", "end")
            self.text.destroy()
            self.text = None

        def check_surrounding_brackets(self, index, openers="([{", mustclose=False):
            return HyperParser(self.text, index).get_surrounding_brackets(openers, mustclose)


# Generated at 2022-06-24 08:14:21.629558
# Unit test for method is_block_opener of class RoughParser

# Generated at 2022-06-24 08:14:29.031442
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    parser = RoughParser()
    assert parser.get_str() == ""
    parser.set_str("""for (i = 0; i < 10; i++)
{
    print "boo", i
}
""")
    assert parser.get_str() == """for (i = 0; i < 10; i++)
{
    print "boo", i
}
"""

    assert parser.get_str() != """for (i = 0; i < 10; i++)
{
    print "boo", i
}
"""
# Unit tests for getters

# Generated at 2022-06-24 08:14:39.552491
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-24 08:14:48.623634
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    """Test method __iter__ of class StringTranslatePseudoMapping"""
    pseudo_mapping = StringTranslatePseudoMapping({}, None)
    assert not list(pseudo_mapping.__iter__())
    pseudo_mapping = StringTranslatePseudoMapping({'one': 1}, None)
    assert list(pseudo_mapping.__iter__()) == ['one']
    pseudo_mapping = StringTranslatePseudoMapping({'two': 2, 'one': 1}, None)
    assert set(pseudo_mapping.__iter__()) == {'one', 'two'}



# Generated at 2022-06-24 08:14:57.667430
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=redefined-builtin

    method = RoughParser.set_str

    def check(str, firstlineno,
              expected_str, expected_study_level, expected_goodlines,
              expected_continuation):
        # pylint: disable=redefined-builtin
        # Construct an object
        obj = RoughParser("")
        # Call the method
        method(obj, str, firstlineno)
        # Check the results
        assert obj.str == expected_str
        assert obj.study_level == expected_study_level
        assert obj.goodlines == expected_goodlines
        assert obj.continuation == expected_continuation

    # Test with an empty string
    check("", 1, "", 0, [1], C_NONE)

    # Test with a simple string deactivated by a whitespace

# Generated at 2022-06-24 08:15:05.846121
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Tkinter.Text()
    text.insert("insert", "'''\n# comment\nx = (y +\n z)\n'''\n")

    for ins in  ("1.0", "1.1", "1.2", "1.3", "1.4",
            "2.0", "2.1", "2.2", "2.3", "2.4",
            "3.0", "3.1", "3.2", "3.3", "3.4",
            "4.0", "4.1", "4.2"):
        parser = HyperParser(text, ins)
        assert parser.is_in_string() == (ins in ("1.1","1.2","1.3")), ins


# Generated at 2022-06-24 08:15:09.875980
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    from unittest import mock
    from unittest.mock import Mock
    mock_get = Mock()
    t = StringTranslatePseudoMapping({"non_defaults": mock_get},
                                     "default_value")
    assert len(t) == 1

# Generated at 2022-06-24 08:15:17.155130
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():

    def _test(input, res_code, res_reason, res_indent):
        if res_reason is None:
            res_reason = u""
        p = RoughParser(input, "utf-8")
        if res_indent is not None:
            p.set_lo(res_indent)
        if p.error_code != res_code or p.error_message != res_reason:
            raise AssertionError("Expected", (res_code, res_reason), "but got", (p.error_code, p.error_message))

    _test(b"1 2",     0, None, None)
    _test(b"1\n2",    1, None, None)
    _test(b"1\n2",    1, None, None)