

# Generated at 2022-06-24 08:05:24.821068
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-24 08:05:29.534446
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    non_defaults = {0x41: 0x42}
    default = 0x43
    mapping = StringTranslatePseudoMapping(non_defaults, default)
    assert mapping[0x41] == 0x42
    assert mapping[0x42] == 0x43
    assert list(mapping) == [0x41]
    assert list(iter(mapping)) == [0x41]



# Generated at 2022-06-24 08:05:38.616410
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    import unittest

    class Test(unittest.TestCase):
        weight = 1

        def setUp(self):
            self.text = tk.Text()
            self.h = HyperParser(self.text, "1.0")
            self.text.insert("1.0", "\n    '''a\n    b\n    c''' #incomment\n")

        def test_HyperParser_is_in_string(self):
            self.h.set_index("1.0")
            self.assertEqual(self.h.is_in_string(), 1)
            self.h.set_index("1.4")
            self.assertEqual(self.h.is_in_string(), 1)
            self.h.set_index("1.5")

# Generated at 2022-06-24 08:05:45.926308
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    """test the output of get_base_indent_string"""
    # The following class is used to check that the stubs are correct
    class Stub:
        def __init__(self, str_):
            self.str = str_
    # simple
    assert RoughParser(Stub('a\nfoo')).get_base_indent_string() == '\n'
    # leading spaces
    assert RoughParser(Stub('  foo')).get_base_indent_string() == '  '
    assert RoughParser(Stub('  foo\n  bar')).get_base_indent_string() == '  '
    assert RoughParser(Stub('    a\n  b')).get_base_indent_string() == '    '
    # leading tabs

# Generated at 2022-06-24 08:05:47.784533
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    """This method is tested via test_get_struct()"""
    pass

# Generated at 2022-06-24 08:05:59.347406
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()
    rp.set_str("line0;\nline1;\nline2")
    assert rp.str == "line0;\nline1;\nline2"
    assert rp.study_level == 0
    assert rp.num_lines() == 3
    assert rp.get_line(0) == "line0;"
    assert rp.get_line(1) == "line1;"
    assert rp.get_line(2) == "line2"
    with pytest.raises(IndexError):
        rp.get_line(3)
    with pytest.raises(IndexError):
        rp.get_line(-1)

# Generated at 2022-06-24 08:06:05.052909
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    """Unit test for method __getitem__ of class StringTranslatePseudoMapping"""
    preserve_dict = {ord(c): ord(c) for c in ' \t\n\r'}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'


# Some people like to issue a warning when a string is split across lines.

_warn_on_string_splits = False



# Generated at 2022-06-24 08:06:12.666390
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # The internal representation of the text. The text has newlines,
    # followed by index markers.
    rawtext = "a = (5 + 6)\n01234567890123456789012"
    # The bracketing info. Each entry is a tuple of (index in
    # rawtext, nesting level)
    bracketing = [
        (0, 0),
        (1, 0),
        (2, 0),
        (3, 0),
        (4, 1),
        (5, 1),
        (6, 1),
        (7, 0),
        (9, 0),
        (10, 0),
        (13, 0),
    ]
    # The set of openers.
    isopener = [False, False, False, False, True, False, False, False, True, False, False]

# Generated at 2022-06-24 08:06:24.749983
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-outer-name
    from lib2to3.pgen2 import token

    # pylint: disable=too-many-arguments
    def test(str_, tabwidth, expected, with_semicolon=False):
        code = _dedent(str_)
        if with_semicolon:
            code = code[:-1] + ";\n" + code[-1]
        rp = RoughParser(code, tabwidth)
        assert rp.compute_bracket_indent() == expected
        assert rp.compute_backslash_indent() == expected


# Generated at 2022-06-24 08:06:32.312703
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    import unittest

# Generated at 2022-06-24 08:06:45.655191
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    parser = RoughParser()
    test_data = [
        ("", None),
        ("foo", None),
        ("foo(", None),
        ("foo()", None),
        ("[", 0),
        ("[]", 1),
        ("[1,]", 1),
        ("[1,2,]", 1),
        ("[1,2,3,]", 1),
        ("[1,2,3,4,]", 1),
        ("[1,2,3,4,5,]", 1),
        ]
    for test in test_data:
        parser.set_str(test[0])
        parser.study_level = 0
        assert parser.get_last_open_bracket_pos() == test[1]
test_RoughParser_get_last_open_bracket_pos()


# Generated at 2022-06-24 08:06:49.933794
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    mapping = StringTranslatePseudoMapping({"a": "b", "c": "d"}, "x")
    expected = 2
    actual = len(mapping)
    assert actual == expected


# Generated at 2022-06-24 08:07:00.418505
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    import collections

    Bracket = collections.namedtuple("Bracket", ["str", "expected"])

# Generated at 2022-06-24 08:07:09.186047
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    t = " \nif 1:\n    x = 1\n\nx = 1\n"
    h = HyperParser(t, "2.10")
    assert h.rawtext == "if 1:\n    x = 1"
    assert h.stopatindex == "3.0"
    assert h.bracketing == [(3, 1), (3, 2), (3, 3), (3, 4), (8, 1), (8, 2)]
    assert h.isopener == [True, False, False, False, True, False]
    assert h.indexbracket == 1
    assert h.indexinrawtext == 6

    h.set_index("2.8")
    assert h.rawtext == "if 1:\n    x = 1"
    assert h.stopatindex == "3.0"

# Generated at 2022-06-24 08:07:17.431190
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin

    def get_indent(s):
        return RoughParser(s, 0).compute_backslash_indent()

    # test_compute_backslash_indent
    eq(get_indent("if 1:\\\n    x = 2\\\n"), 4)
    eq(get_indent("if 1:\\\n    x = 2\\\n   "), 4)
    eq(get_indent("if 1:\\\n   x = 2\\\n"), 5)
    eq(get_indent("if 1:\\\n   x = 2\\\n   "), 5)
    eq(get_indent("if 1:\\\n    x = 2\\\n"), 4)

# Generated at 2022-06-24 08:07:20.360701
# Unit test for constructor of class RoughParser
def test_RoughParser():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest


# Generated at 2022-06-24 08:07:28.473705
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():  # pylint: disable=C0103
    import unittest
    from unittest import mock
    from unittest.mock import Mock


    class Test(unittest.TestCase):
        """Test the RoughParser.get_last_open_bracket_pos()."""

        def test_get_last_open_bracket_pos(self):
            """Test the RoughParser.get_last_open_bracket_pos()."""
            # pylint: disable=protected-access

            pars = RoughParser("{a:b}")
            pars._study2 = Mock()
            pars.get_last_open_bracket_pos()
            self.assertEqual(pars.lastopenbracketpos, 0)

            pars = RoughParser("a = {a:b}")
            pars._study2 = Mock

# Generated at 2022-06-24 08:07:38.420403
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=redefined-builtin

    rp = RoughParser("file.py", "   a = [x for x in range(10)]\n")
    assert rp.str == "   a = [x for x in range(10)]\n"
    assert rp.goodlines == [0]
    assert rp.continuation == C_NONE
    assert rp.indent_width == 4
    assert rp.tabwidth == 8
    assert rp.prefix == "   "
    rp = RoughParser("file.py", "   a = [x for x in range(10)]\n", 4)
    assert rp.str == "   a = [x for x in range(10)]\n"
    assert rp.goodlines == [0]
    assert rp.continuation == C

# Generated at 2022-06-24 08:07:46.787602
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    """This verifies that HyperParser.get_expression() returns correct results.

    The results of HyperParser are hard to verify automatically, because
    they depend on many details in the Python grammar, which might change
    with time. Therefore, this function allows manual verification, by
    reporting the results for various strings.
    """
    def test_exp(s):
        print(s)
        # Add a callable body to s and use exec to prepare the
        # PyParse constants
        exec(s[:-1] + ": pass\n")
        # Find the indentation and number of lines in s
        lineno = s.count("\n")
        indent = len(s) - len(s.lstrip()) + 1
        # Create a Tk Text object to use with HyperParser
        text = tk.Text(None)
        text.insert

# Generated at 2022-06-24 08:07:57.825608
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    rp = RoughParser("try:\n    while True:\n        pass\nfinally:\n    pass\n")
    assert rp.is_block_closer() == False
    rp = RoughParser("try:\n    while True:\n        pass\nelse:\n    pass\n")
    assert rp.is_block_closer() == False
    rp = RoughParser("while True:\n    pass\nelse:\n    pass\n")
    assert rp.is_block_closer() == True
    rp = RoughParser("for x in y:\n    pass\nelse:\n    pass\n")
    assert rp.is_block_closer() == True
    rp = RoughParser("if a:\n    pass\nelse:\n    pass")
    assert rp.is_block_cl

# Generated at 2022-06-24 08:08:06.586515
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    r = RoughParser("  foo =\\\n  3 + 4\n")
    assert r.get_continuation_type() == C_BACKSLASH
    r = RoughParser("  foo = 3 + 4 + \\ \n  5\n")
    assert r.get_continuation_type() == C_BACKSLASH
    r = RoughParser("  foo = 3 + 4 + 5 + 6\\\n  + 7\n")
    assert r.get_continuation_type() == C_BACKSLASH
    r = RoughParser("  foo(bar,\n    baz)\n")
    assert r.get_continuation_type() == C_BRACKET
    r = RoughParser("  foo(bar,\n    baz,\n  )\n")
    assert r.get_continuation_type() == C_

# Generated at 2022-06-24 08:08:14.753900
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    def f(s):
        parser = RoughParser(s)
        return parser.get_num_lines_in_stmt()

    assert f("") == 1  # even if it's not a legal single-line stmt
    assert f("\n") == 1
    assert f("\n\n") == 1  # a bare blank line is not a stmt
    assert f("\n\n\n") == 1
    assert f("\n\n\n\n") == 2  # stmt end at end of last \n
    assert f("#\n") == 1  # a comment line is not a stmt
    assert f("#\n\n\n") == 1
    assert f("a\nb\nc\n") == 3
    assert f("a\n#\n\n") == 1

# Generated at 2022-06-24 08:08:26.062988
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import unittest

    class HyperParser_TestCase(unittest.TestCase):
        def setUp(self):
            from idlelib.textView import TextViewer

            self.tv = TextViewer(None)
            self.tv.set_font(('courier', 10, 'normal'))
            self.tv.frame.deiconify()
            self.tv.frame.update()

        def test_is_in_code(self):

            def test_is_in_code_with_text(text, pos, expected):
                self.tv.set_text(text)
                hp = HyperParser(self.tv, pos)
                result = hp.is_in_code()
                self.assertEqual(result, expected)

            text = " # comment\nspam = 'eggs'"
            test_

# Generated at 2022-06-24 08:08:31.839194
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    m = StringTranslatePseudoMapping({ord('a'):ord('x')}, ord('z'))
    assert m.get('a') == ord('x')
    assert m.get('b') == ord('z')  # default value
    assert m.get('b', 'y') == 'y'  # default value passed to get



# Generated at 2022-06-24 08:08:39.922920
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # This is a test for HyperParser.__init__
    #
    # We use the text as a buffer, creating a new text for each test.
    indent_width = 8
    tabwidth = 8
    text = EditWin.EditWindow(None)
    text.indent_width = indent_width
    text.tabwidth = tabwidth
    # We use "xxx" as a delimiter between tests in text.

    def createsetup(args):
        # Create a setup in text and index.
        global text
        text.delete(1.0, "end")
        text.insert(1.0, "xxx\n")
        text.insert(1.0, "setUp(self)\n")
        for arg in args:
            text.insert(1.0, "    %s\n" % arg)

# Generated at 2022-06-24 08:08:50.524435
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    rp = RoughParser('x = 111\ny = 222')
    assert rp.get_continuation_type() == C_NONE
    rp = RoughParser('x = 111\ny = 222\n')
    assert rp.get_continuation_type() == C_NONE
    rp = RoughParser('x = 111\ny = ')
    assert rp.get_continuation_type() == C_BACKSLASH
    rp = RoughParser('x = 111\n(')
    assert rp.get_continuation_type() == C_BRACKET
    rp = RoughParser('x = 111\n(xxx')
    assert rp.get_continuation_type() == C_BRACKET
    rp = RoughParser('x = 111\n(\n   xxx')
    assert rp.get

# Generated at 2022-06-24 08:08:56.121647
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class Test(unittest.TestCase):
        def check(self, text, index, exp_expr, exp_indexinrawtext):
            """Check that HyperParser returns the expected expr and
            indexinrawtext.
            """
            import tkinter

            text = tkinter.Text(width=len(text) + 10)
            text.insert("insert", text)
            if index == "insert":
                index = text.index("insert")
            else:
                # Find the index
                indexi = int(index[:-2])
                index = text.index("%d.%d" % (indexi / 10, indexi % 10))
            parser = HyperParser(text, index)
            expr = parser.get_expression()
            self.assertEqual(expr, exp_expr)
           

# Generated at 2022-06-24 08:09:09.122616
# Unit test for constructor of class RoughParser

# Generated at 2022-06-24 08:09:16.508928
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rp = RoughParser("""\
if True:
    # a comment
    x = 1+2+3+\\
        4+5+6+7+8+9
""")
    # 8 lines in the continued statement "x = 1+2+3+\\n        4+5+6+7+8+9"
    assert rp.get_num_lines_in_stmt() == 8

# Generated at 2022-06-24 08:09:29.566895
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    r"""test method __len__ of class StringTranslatePseudoMapping"""

    def _init(non_defaults, default_value):
        return StringTranslatePseudoMapping(non_defaults, default_value)

    r"""Test function _init"""

    testcase_0 = {
        "expected": 0,
        "non_defaults": {},
        "default_value": "dummy_string_0",
    }

    _tu.validate_testcase(testcase_0, _init, lambda inst: len(inst))

    testcase_1 = {
        "expected": 1,
        "non_defaults": {
            "key": "dummy_string_0",
        },
        "default_value": "dummy_string_1",
    }

    _tu.validate_

# Generated at 2022-06-24 08:09:40.381475
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest
    import sys

    class HyperParserGetSurroundingBracketsTestCase(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = Text()
            text.set('if 1:\n a = 1 + 2')
            hp = HyperParser(text, 3)
            self.assertEqual( hp.get_surrounding_brackets(), (1, 4))
            try:
                hp.get_surrounding_brackets(mustclose=True)
            except ValueError:
                pass
            else:
                self.fail('get_surrounding_brackets() did not raise ValueError')

    unittest.main(
        HyperParserGetSurroundingBracketsTestCase,
        verbosity=2,
        exit=False,
    )
# Unit

# Generated at 2022-06-24 08:09:47.665621
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    preserve_dict = {ord('f'): ord('f'), ord('o'): ord('o')}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert list(mapping.keys()) == [ord('f'), ord('o')]
    assert mapping[ord('f')] == ord('f')
    assert mapping[ord('o')] == ord('o')
    assert mapping[ord('z')] == ord('x')
    assert mapping.get(ord('z')) == ord('x')
    assert mapping.get(ord('z'), ord('y')) == ord('x')
    assert mapping.get(ord('y'), ord('z')) == ord('z')



# Generated at 2022-06-24 08:09:54.645767
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-24 08:10:01.151719
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    parser = RoughParser("x = \\", indent_width=4, tabwidth=8)
    assert parser.compute_backslash_indent() == 4

    parser = RoughParser("x = \\", indent_width=4, tabwidth=8)
    assert parser.compute_backslash_indent() == 4

    parser = RoughParser("x.y.z()  \\", indent_width=4, tabwidth=8)
    assert parser.compute_backslash_indent() == 4

    parser = RoughParser("x.y.z()\\", indent_width=4, tabwidth=8)
    assert parser.compute_backslash_indent() == 4

    parser = RoughParser("x.y.z()\\", indent_width=4, tabwidth=8)
    assert parser.compute_back

# Generated at 2022-06-24 08:10:09.868038
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    result = text.translate(mapping)
    if result != "x x x\tx\nx":
        raise Exception("Expected 'x x x\\tx\\nx', got %r" % result)



# Generated at 2022-06-24 08:10:19.102280
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = EditorWindow(None)
    text.insert("1.0", "def f(x): ")
    text.insert("insert", '""" comment')
    assert HyperParser(text, "insert").is_in_code()
    text.insert("insert", '""" ')
    assert not HyperParser(text, "insert").is_in_code()
    text.insert("insert", '"""')
    assert not HyperParser(text, "insert").is_in_code()
    text.insert("insert", 'a = "string """ ')
    assert not HyperParser(text, "insert").is_in_code()
    text.insert("insert", "# comment")
    assert not HyperParser(text, "insert").is_in_code()
    text.insert("insert", "  ")

# Generated at 2022-06-24 08:10:19.729621
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-24 08:10:31.275505
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    from test.support import captured_stdout
    import io
    import unittest

    class StringTranslatePseudoMapping___len__Test(unittest.TestCase):
        def test_1(self):
            whitespace_chars = ' \t\n\r'
            preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
            mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
            text = "a + b\tc\nd"
            # print(whitespace_chars)
            # print(type(whitespace_chars))
            # print(len(whitespace_chars))
            # print(preserve_dict)
            # print(type(preserve_dict))
            # print(len(preserve

# Generated at 2022-06-24 08:10:34.653306
# Unit test for constructor of class HyperParser

# Generated at 2022-06-24 08:10:45.197788
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    def test(src, expected):
        parsed_bracketing = RoughParser(src).get_last_stmt_bracketing()
        assert parsed_bracketing == tuple(expected), (
            "Source string: %r\n"
            "Parsed bracketing: %r\n"
            "Expected: %r" % (src, parsed_bracketing, expected)
        )

    test("", [])
    test("  \n  \n", [])
    test("print(", [(0, 0), (5, 1), (6, 0)])
    test("print()", [(0, 0), (6, 0)])
    test("print(1", [(0, 0), (6, 1), (7, 0)])

# Generated at 2022-06-24 08:10:52.856901
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    # Note: the method is tested indirectly via test_StringTranslatePseudoMapping__init__().
    expected = 'Dummy result'
    def dummy_get(_key):
        return expected
    mapping = StringTranslatePseudoMapping({}, '')
    mapping._get = dummy_get
    result = mapping.__getitem__('')
    assert result == expected, 'Expected "{}", but got "{}" instead.'.format(expected, result)

# Generated at 2022-06-24 08:11:00.563107
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    translated = text.translate(mapping)
    expected = "x x x\tx\nx"
    assert translated == expected



# Generated at 2022-06-24 08:11:12.698567
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    def assert_bracket_pos(
        text,
        base_indent="",
        is_block_opener=False,
        is_block_closer=False,
        expected_bracket_pos=None,
    ):
        """Test get_last_open_bracket_pos of RoughParser for text."""
        parser = RoughParser(text, 0)
        assert parser.get_base_indent_string() == base_indent
        assert parser.is_block_opener() == is_block_opener
        assert parser.is_block_closer() == is_block_closer
        assert parser.get_last_open_bracket_pos() == expected_bracket_pos
        assert parser.get_last_stmt_bracketing() != None
    assert_bracket_pos("\n")

# Generated at 2022-06-24 08:11:23.401124
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # In the following test cases the pipe character represents the
    # index given to set_index.

    # Simple test case
    h = HyperParser(util.str2tk("foo()|"), "insert")
    h.set_index("insert")
    assert h.indexbracket == 1
    assert h.indexinrawtext == 4

    # Test with string on left
    h = HyperParser(util.str2tk('"foo"()|'), "insert")
    h.set_index("insert")
    assert h.indexbracket == 1
    assert h.indexinrawtext == 6

    # Test with comment on left
    h = HyperParser(util.str2tk("#foo\n()|"), "insert")
    h.set_index("insert")
    assert h.indexbracket == 1
    assert h.indexinraw

# Generated at 2022-06-24 08:11:29.919044
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    import unittest
    import unittest.mock as mock

    class TestHyperParser(unittest.TestCase):
        """Unit test for hyperparse.py"""

        # Test for method is_in_string of class HyperParser

        def is_in_string_tester(self, rawtext, index, result):
            """Helper function to test method is_in_string of
            class HyperParser.

            Parameters:
            rawtext -- the text to parse
            index   -- the position to test
            result  -- Boolean, the expected result
            """
            # Use mock to simulate the text box
            tktext = mock.Mock()
            tktext.get.return_value = rawtext
            tktext.index.side_effect = lambda x: str(x)
            tktext.indent_width = 8


# Generated at 2022-06-24 08:11:43.168767
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    from unittest import TestCase

    class TestStringTranslatePseudoMapping(TestCase):
        def test_STPM_constructor(self):
            # test the constructor of StringTranslatePseudoMapping

            # empty dict
            mapping = StringTranslatePseudoMapping({}, ord('x'))
            self.assertEqual(len(mapping), 0)
            self.assertEqual(mapping.get(ord('a')), ord('x'))

            # non-empty dict
            mapping = StringTranslatePseudoMapping({ord('a'): ord('b')}, ord('x'))
            self.assertEqual(len(mapping), 1)
            self.assertEqual(mapping.get(ord('a')), ord('b'))

# Generated at 2022-06-24 08:11:55.276944
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-24 08:11:57.691758
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    assert sorted(StringTranslatePseudoMapping({}, None)) == []
    assert sorted(StringTranslatePseudoMapping({1: 2}, 3)) == [1]



# Generated at 2022-06-24 08:12:04.813452
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    rp = RoughParser("""\
if 1:
    if 1:
        if 1:
            if 1:
                if 1:
                    if 1:
                        if x == 1 and y == 2 and z == 3 and \\
                           a == 4 and b == 5 and c == 6:
                            pass
            pass
    pass
   """, 0)
    assert rp.compute_backslash_indent() == 23
    rp = RoughParser("""\
if 1:
    if 1:
        if 1:
            if 1:
                if 1:
                    if 1:
                        if x == 1 and y == 2 and \\
                           z == 3 and a == 4:
                            pass
            pass
    pass
   """, 0)
    assert r

# Generated at 2022-06-24 08:12:15.518066
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=too-many-locals, too-many-branches, too-many-statements

    #
    # Basic test
    #
    src = "class foo:\n    bar = 23"
    rp = RoughParser(src)
    assert_equal(rp.get_line_indent(1), 0)
    assert_equal(rp.get_line_indent(2), 4)
    assert_equal(rp.compute_backslash_indent(), 5)

    #
    # Tests with strings
    #
    # These tests check how strings influence the indentation.
    # The format of the test is:
    # - Line 1: Source code
    # - Line 2: Expected computation for next line with backslash continuation
    # - Line 3: Expected computation for next line

# Generated at 2022-06-24 08:12:23.329592
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    class TempEditor:pass
    editor = TempEditor()
    text = Text("""
x = "foo" + "bar" + "baz
""")
    text.indent_width = 4
    text._text = text.get("1.0", "end-1c")
    text.set("1.0", text._text)
    editor.text = text
    editor.root = tkinter.Tk()
    assert editor.text.get("sel.first", "sel.last") == "foo"
    assert not HyperParser(text, "sel.last").is_in_code()
    assert editor.text.get("sel.first", "sel.last") == "baz"
    assert HyperParser(text, "sel.last").is_in_code()
    editor.root.destroy()


# Generated at 2022-06-24 08:12:30.395301
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    str = """\
a
"""
    p = RoughParser(str)
    assert p.get_num_lines_in_stmt() == 1

    str = """\
a

"""
    p = RoughParser(str)
    assert p.get_num_lines_in_stmt() == 1



# Generated at 2022-06-24 08:12:40.119305
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    mapping = StringTranslatePseudoMapping({ord('a'): ord('x')}, ord('y'))
    assert mapping.get(ord('a')) == ord('x')
    assert mapping[ord('b')] == ord('y')
    assert len(mapping) == 1
    assert list(mapping) == [ord('a')]
    assert mapping.get(ord('c'), ord('z')) == ord('y')

# Map the last char before an end of stmt to a C_* code.
# Map other chars to C_NONE.


# Generated at 2022-06-24 08:12:49.985595
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    # Tests for method __iter__( ... ).  (copied from idlelib.parser)
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    iter_method = mapping.__iter__
    # Call without args
    iterator = iter_method()
    assert isinstance(iterator, type(iter(preserve_dict)))
    assert set(iterator) == set(preserve_dict)


# Generated at 2022-06-24 08:12:57.372802
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def make_HyperParser(text, index):
        return HyperParser(MockText(text), index)

    def hpe(text, index):
        return make_HyperParser(text, index).get_expression()

    assert hpe("", "1.0") == ""
    assert hpe("a + c", "1.4") == "a + c"
    assert hpe("a + c", "1.6") == "c"
    assert hpe("a + c", "1.7") == ""

    assert hpe("ab [12 + 3", "1.10") == "12 + 3"
    assert hpe("ab [12 + 3]", "1.12") == "3"
    assert hpe("ab [12 + 3", "1.11") == ""


# Generated at 2022-06-24 08:13:10.203378
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def test(s, expected):
        # pylint: disable=redefined-builtin
        r = RoughParser(s, "utf-8")
        assert r.compute_bracket_indent() == expected

    # pylint: disable=bad-whitespace
    test("if True: pass\n    ", 4)
    test("if True:\n    pass\n    ", 4)
    test("if True:\n    pass\n", 0)
    test("if True:\n    pass", 0)
    test("if True:\n    []", 4)
    test("if True:\n    [1,\n", 8)
    test("if True:\n    [1,\n     2,\n", 8)
    test("if True:\n    [\n", 4)

# Generated at 2022-06-24 08:13:19.373255
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest
    from test.test_support import run_unittest

    class TestHyperParser(unittest.TestCase):
        def check_get_expression(self, x):
            self.assertEqual(HyperParser(x, "1.0").get_expression(), "")
            self.assertEqual(HyperParser(x, "1.0 lineend").get_expression(), "lineend")
            self.assertEqual(HyperParser(x, "1.0 linestart").get_expression(), "")

        def test_get_expression(self):
            self.check_get_expression("lineend")
            self.check_get_expression("x = linestart * lineend")

    run_unittest(TestHyperParser)



# Generated at 2022-06-24 08:13:29.741856
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    import sys
    import unittest
    from test.support import captured_stdout
    from idlelib.colorizer import ColorDelegator
    from idlelib.editor import EditorWindow, fixwordbreaks
    from idlelib.io import encoding

    globals()["root"] = tkinter.Tk()
    globals()["root"].withdraw()

    class TestCase(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            global text, hp

            text = ColorDelegator()
            text.set_font(EditorWindow.font)
            text.color_config(foreground="black", background="white")

# Generated at 2022-06-24 08:13:36.407400
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    class TextForTesting:
        "A class with methods similar to a text widget."

        def __init__(self):
            # Put some newlines in it.
            self.s = "def f(a,\nb):\n"
            # A simple way to ensure that the index is in the window.
            self.indent_width = 8

        def get(self, index1, index2):
            return self.s[int(index1) : int(index2) + 1]

        def index(self, index):
            try:
                return int(float(index))
            except ValueError:
                if index.startswith("end"):
                    return len(self.s)
                raise
            raise ValueError("Bad index: %r" % index)


# Generated at 2022-06-24 08:13:44.092145
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    rp = RoughParser('')
    assert rp.is_block_closer() is False
    rp.str = 'x = "try:\n\ty += 1\n\tfinally:\n\t\tprint(x, end=\' \')\n"'
    rp._study2()
    assert rp.is_block_closer()


# Generated at 2022-06-24 08:13:50.724681
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    from . import parser
    rp = RoughParser("print(1, [2])", None, parser)
    rp.study_level = 2
    assert rp.get_last_stmt_bracketing() == [(0, 0), (6, 1), (7, 2), (8, 1), (12, 0)]

    rp = RoughParser("print(1,\n   [2])", None, parser)
    rp.study_level = 2
    assert rp.get_last_stmt_bracketing() == [(0, 0), (6, 1), (7, 2), (9, 1), (12, 0)]

# For backwards compatibility, this class's functions are first made
#  instance methods of a class.  It is then instantiated and its
#  functions reassigned over the instance methods.  The old

# Generated at 2022-06-24 08:13:52.187396
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    import unittest
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 08:14:04.336148
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def create(s):
        import tkinter
        t = tkinter.Text(None)
        t.insert("insert", s)
        return HyperParser(t, t.index("insert"))

    assert create("").get_expression() == ""

    assert create("# comment").get_expression() == ""

    assert create(".string").get_expression() == ""
    assert create("1.2e1.string").get_expression() == ""
    assert create("'abc'.string").get_expression() == ""
    assert create("\"abc\".string").get_expression() == ""
    assert create("(1 + 2).string").get_expression() == ""
    assert create("[1, 2].string").get_expression() == ""
    assert create("{1: 2}.string").get_expression() == ""

# Generated at 2022-06-24 08:14:16.140524
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=redefined-builtin
    global _itemre  # pylint: disable=global-statement

    RoughParser._init()

    if sys.maxunicode == 65535:
        # UCS2 build: u'' prefix means a UCS2 string.
        # This string has 3 characters, each one a 4-byte surrogate pair
        # in UCS4.
        # An alternative would be to use a raw UTF-16 string; since we
        # don't have code that runs on UCS2 and UCS4, it doesn't matter
        # which we use.
        x = u"\U0001FFFE\U0001FFFF\U00020000"
        assert len(x) == 3
    else:
        # UCS4 build
        x = u"\U0001FFFE\U0001FFFF\U00020000"
        assert len

# Generated at 2022-06-24 08:14:23.850895
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    tpm = StringTranslatePseudoMapping(
        {ord('a'): ord('b')}, ord('x')
    )
    assert tpm.get(ord('a')) == ord('b')
    assert tpm.get(ord('b')) == ord('x')
    assert tpm.get(ord('x')) == ord('x')
    assert tpm.get(ord('!')) == ord('x')


# Utility function to simplify the definition of a mapping containing
# character substitution mappings

# Generated at 2022-06-24 08:14:36.980202
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    r = RoughParser("""
a\
b
""".splitlines(True))
    assert r.get_num_lines_in_stmt() == 2
    r = RoughParser("""
a\
b\
c
""".splitlines(True))
    assert r.get_num_lines_in_stmt() == 3
    r = RoughParser("""
a\
b\
c \
d
""".splitlines(True))
    assert r.get_num_lines_in_stmt() == 4
    r = RoughParser("""
a#
b\
""".splitlines(True))
    assert r.get_num_lines_in_stmt() == 3
    r = RoughParser("""
a #
b\
""".splitlines(True))
    assert r.get_num_lines_in

# Generated at 2022-06-24 08:14:42.827273
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({ord('a'): ord('b')}, ord('x'))
    assert mapping.get(ord('a')) == ord('b')
    assert mapping.get(ord('x')) == ord('x')
    assert mapping.get(ord('z')) == ord('x')
    assert mapping.get(ord('z'), ord('y')) == ord('y')



# Generated at 2022-06-24 08:14:50.529218
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-24 08:15:00.657132
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()
    rp.set_str("string\n[1,\n#comment\n'a']")
    assert rp.continuation == 'C_NONE'
    assert rp.goodlines == [0, 1, 2, 3, 4]

    rp.set_str("string\n[1,\n#comment\n'a")
    assert rp.continuation == 'C_STRING_FIRST_LINE'
    assert rp.goodlines == [0, 1, 2, 3, 3]

    rp.set_str('string\n[1,\n#comment\n"a"\\\nline2')
    assert rp.continuation == 'C_STRING_NEXT_LINES'

# Generated at 2022-06-24 08:15:06.836314
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    """Test the constructor of class StringTranslatePseudoMapping

    This function is used as a unit test for the constructor of the
    class StringTranslatePseudoMapping.

    If the unit test fails, an AssertionError is raised.
    """

    # Test the function with a trivial mapping
    trivial_dict = {
        ord('a'): ord('a'),
    }
    trivial_mapping = StringTranslatePseudoMapping(trivial_dict, ord('b'))
    assert trivial_mapping[ord('a')] == ord('a')
    assert trivial_mapping[ord('b')] == ord('b')
    assert trivial_mapping[ord('c')] == ord('b')

    # Create a pseudo mapping for non-whitespace characters.

# Generated at 2022-06-24 08:15:07.857421
# Unit test for method is_block_opener of class RoughParser

# Generated at 2022-06-24 08:15:15.796116
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    for s in ["a = {", "a = { ", "a = {\n\n"]:
        assert RoughParser(s).get_base_indent_string() == "a = {"
    for s in ["a = {\n", "a = {\n\n\n"]:
        assert RoughParser(s).get_base_indent_string() == "a = {"

    for s in ["a = {\n  x = 1\n  x = 2",
              "a = {\n  x = 1\n  x = 2\n"]:
        assert RoughParser(s).get_base_indent_string() == "a = {"


# Generated at 2022-06-24 08:15:19.552798
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    preserve_dict = {ord('a'): ord('A'), ord('b'): ord('B')}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('X'))
    assert {ord('A'), ord('B')} == set(mapping.keys())
    assert ord('X') == mapping[ord('x')]
    assert [ord('A'), ord('B')] == sorted(mapping.values())
    assert ord('X') == mapping.get(ord('x'))

