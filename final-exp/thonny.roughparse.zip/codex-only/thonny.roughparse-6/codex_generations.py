

# Generated at 2022-06-24 08:05:22.925998
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    for src in [
        "",
        "\n",
        "  \n",
        "\n ",
        "\n  \n",
        "a",
        "a\n",
        "a\n ",
        "a\n  \n",
        "a\nb",
        "a\n\nb",
        "a\n\nb\n",
    ]:
        assert RoughParser(src)._study1() == (0, len(src) - 1)

# Generated at 2022-06-24 08:05:31.326570
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    # Tests various character transformations.
    preserve_dict = {ord('a'): ord('A')}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "This is a test."
    assert text.translate(mapping) == "xhis is A xesx."


# Find opening brace of a {}-delimited structure.

_open_braces = "({["
_close_braces = ")}]"

_match_bracepairre = re.compile(
    r"""
    .*?
    ( [%(_open_braces)s]
    | [%(_close_braces)s]
    )
"""
    % globals(),
    re.VERBOSE,
).match


# Set up table to translate what's been str

# Generated at 2022-06-24 08:05:39.044348
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    def t(block, expect):
        actual = RoughParser(block, "").get_num_lines_in_stmt()
        assert actual == expect, "%r actual != expect %r" % (actual, expect)
    t("a\nb", 1)
    t("a\n\\\nb", 2)
    t("a\\\n", 1)
    t("a\\\n\\\n", 2)
    t("a\\\n\\\nb", 2)
    t("a\\\n\\\nb\\\n\\\nc", 2)
    t("a\n\\\n\\\nb", 2)

# Generated at 2022-06-24 08:05:45.710983
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    global _JUNKRE  # pylint: disable=global-statement

# Generated at 2022-06-24 08:05:53.670599
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    def toktest(test):
        exp = [(0, 0), (3, 1), (8, 0), (9, 1), (12, 0)]
        bruce = RoughParser(test)
        bruce.indent_width = 4
        bruce.tabwidth = 8
        bruce._study2()
        assert bruce.get_last_stmt_bracketing() == exp
    toktest("say(boo) or die")
    toktest("""\
say( \"hello world\" ) or die""")
    toktest("""\
say( "say(\\"hello world\\") or die" ) or die""")
    toktest("""\
say( "say(\\"hello world\\") or die" # but don't die
) or die""")

    # Test a generator expression:


# Generated at 2022-06-24 08:06:04.133617
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    rp = RoughParser('''\
if True:
    if False:
        pass
    elif True:
        print(3)
    else:
        print(4)
    print(5)
''', 0)
    rp.set_str('''\
else:
    print(4)
''')
    assert rp.is_block_closer()
    rp.set_str('''\
if False:
    pass
''')
    assert not rp.is_block_closer()
    rp.set_str('''\
elif True:
    print(3)
''')
    assert not rp.is_block_closer()
    rp.set_str('''\
if True:
    print(5)
''')
    assert not rp

# Generated at 2022-06-24 08:06:15.059254
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    default_char = ord('x')

    # make a dict mapping numeric values to numeric values that
    # can be used with str.translate()
    #
    # dict comprehension expression:
    #   for value in range(10):
    #       yield value, ord('0') + value
    #
    # verbose functional equivalent:
    #   _make_preserve_dict = lambda: dict((value, ord('0') + value)
    #                                      for value in range(10))
    _make_preserve_dict = lambda: dict((value, ord('0') + value)
                                       for value in range(10))
    preserve_dict = _make_preserve_dict()
    mapping = StringTranslatePseudoMapping(preserve_dict, default_char)

    # check that the default char is returned for unknown chars


# Generated at 2022-06-24 08:06:26.843897
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.h = HyperParser(
                tkinter.Text(None, bd=0, highlightthickness=0), "insert"
            )

        def test_loops(self):
            self.h.rawtext = "for i in range(0): pass"
            self.h.set_index("10c")  # i
            bs = self.h.get_surrounding_brackets(openers="([")
            self.assertEqual(bs, ("7.0", "8.0"))
            self.h.set_index("12c")  # :
            bs = self.h.get_surrounding_brackets(openers="([")

# Generated at 2022-06-24 08:06:33.506746
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    def _test(text, expected_result):
        result = RoughParser(text).get_last_open_bracket_pos()
        assert (
            result == expected_result
        ), f"result={result} expected_result={expected_result}"

    _test("", None)
    _test("# comment", None)
    _test("a = # comment", None)
    _test("def f():\n    pass", None)
    _test("def f():\n    if x:\n        pass", 8)
    _test("if x:\n    pass\nelse:", 3)
    _test("if x:\n    pass\nelif y:\n    pass", 6)
    _test("if x:\n    pass\nelif y:\n    pass\nelse:\n    pass", 6)

# Generated at 2022-06-24 08:06:41.816799
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    parser = RoughParser("\n  foo(a,\n    b,\n    c,\n    d)\n")
    assert parser.stmt_start == 2
    assert parser.stmt_end == 22
    assert parser.compute_bracket_indent() == 2
    assert parser.line_offset == (2, 2, 2, 2, 6)
    parser = RoughParser("\n  foo(a,\n    b,\n    c,\n    d,\n  )\n")
    assert parser.stmt_start == 2
    assert parser.stmt_end == 24
    assert parser.compute_bracket_indent() == 2


if __name__ == "__main__":
    test_RoughParser_compute_bracket_indent()

# Generated at 2022-06-24 08:06:47.829254
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-24 08:06:53.164306
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()
    rp.set_str("a = 1")
    assert rp.str == "a = 1"

    rp.set_str("a = 1\n")
    assert rp.str == "a = 1\n"


# Generated at 2022-06-24 08:06:59.635875
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    from idlelib.parsers import StringTranslatePseudoMapping
    c = {1: 1, 2: 2, 3: 3}
    mapping = StringTranslatePseudoMapping(c, 0)
    l = [x for x in mapping]
    assert l == [1, 2, 3], l


# Generated at 2022-06-24 08:07:08.780068
# Unit test for constructor of class HyperParser
def test_HyperParser():
    if sys.version_info < (3, 6):
        # The _HyperParser is tested by the test_idle unit test
        # (test_parenmatch.py).
        return
    from unittest import TestCase

    from idlelib.pyshell import PyShell
    from idlelib.configHandler import idleConf

    root = Tk()
    root.withdraw()
    text = Text(root)
    text.pack()

    orig_config_parser = idleConf.GetCoreParseFunc()
    idleConf.SetCoreParseFunc(
        lambda filename, encoding: orig_config_parser(filename, encoding)
    )

    iom = io.StringIO()
    pyshell = PyShell(root, None, text, iom)


# Generated at 2022-06-24 08:07:13.930240
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    p = RoughParser()
    p.set_lo("the quick brown fox jumped over\nthe lazy dog\n")
    assert p.goodlines == [0, 2]
    assert p.continuation == C_NONE


# Generated at 2022-06-24 08:07:22.140504
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from idlelib import parenmatch
    from idlelib.idle_test.mock_idle import all_warns


    class HPTest:
        def __init__(self, text, index, indent_width, tabwidth):
            self.text = text
            self.indent_width = indent_width
            self.tabwidth = tabwidth
            self.index = index

        def get(self, startindex, stopindex):
            return self.text[int(startindex) : int(stopindex)]

        def index(self, i):
            return int(i)


# Generated at 2022-06-24 08:07:33.757307
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-24 08:07:46.894388
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # pylint: disable=expression-not-assigned
    from pycodestyle import _tokenize

    def g(s, result):
        f = _tokenize.StringIO(s)
        f.readline()  # throw away the first line
        r = RoughParser(f.readline, False)
        assert r.get_continuation_type() == result

    g("", C_NONE)
    g("x = 1", C_NONE)
    g("x = (1", C_BRACKET)
    g("x = [1", C_BRACKET)
    g("x = {1", C_BRACKET)
    g("x = 1 +\\\n2", C_BACKSLASH)
    g("\"\"", C_NONE)
    g("''", C_NONE)


# Generated at 2022-06-24 08:07:57.913333
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin
    parser = RoughParser(_indentwidth=4, _tabwidth=8)
    # Test with a single-line list literal
    parser.set_str("x = [7, 8, 9]")
    parser.set_goodlines(1, 1)
    assert parser.compute_bracket_indent() == 4
    # Test with a multi-line list literal
    parser.set_str("x = [\n    7,\n    8,\n    9,\n]")
    parser.set_goodlines(1, 4)
    assert parser.compute_bracket_indent() == 4
    # Test with a list literal that's continued after the second line

# Generated at 2022-06-24 08:08:07.449319
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    from unittest import mock
    hp = HyperParser(mock.Mock(), "index")
    hp.rawtext = "some text \"Hey\""  # noqa: E252
    hp.stopatindex = "index"
    hp.bracketing = [(0, 0), (2, 0), (8, 0), (11, 0)]
    hp.indexbracket = 1
    hp.isopener = [0, 0, 1, 1]
    hp.indexinrawtext = 5

    assert hp.is_in_string()



# Generated at 2022-06-24 08:08:14.984798
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    text = "a + b\tc\nd"
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    # This tests that the characters that are whitespace are being
    # replaced with themselves.
    assert (text.translate(mapping) in ('x x x\tx\nx', 'x x x\tx\rx'))


# Python's parser doesn't like 2 or 3 quotes, or a mixture.
# The string module will replace 3 or more quotes with 2, and 2 or more
# single quotes with 1.  We want to remove all quotes and backslashes.

_following_whitespace_re = re.comp

# Generated at 2022-06-24 08:08:16.840748
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()

# Generated at 2022-06-24 08:08:19.197357
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    """
    >>> from test import test_support
    >>> test_support.run_doctest(test_RoughParser)
    """
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 08:08:25.219799
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # pylint: disable=redefined-builtin
    str = "def foo():\n    if 1:\n        pass\n"
    p = RoughParser(str, indent_width=8)  # continuation is C_BRACKET
    assert p.get_continuation_type() == C_BRACKET
    #
    str = "def foo():\n# comment\n    if 1:\n        pass\n"
    p = RoughParser(str, indent_width=8)  # continuation is C_BRACKET
    assert p.get_continuation_type() == C_BRACKET
    #
    str = "def foo():\n    while 1:\n        if 1:\n            pass\n    def bar(): pass\n"
    p = RoughParser(str, indent_width=8)  # continuation is C

# Generated at 2022-06-24 08:08:34.598808
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    from .test.support import requires

    requires("dynamic")

    hp = HyperParser("abc(def.ghi)jkl", "2.3")
    assert hp.get_expression() == "ghi"

    hp = HyperParser("abc(def.ghi).mno", "2.10")
    assert hp.get_expression() == "mno"

    hp = HyperParser("abc(def.ghi).mno", "2.9")
    assert hp.get_expression() == "ghi.mno"

    hp = HyperParser("abc(def.ghi).mno", "1.1")
    assert hp.get_expression() == ""

    hp = HyperParser("abc(def.ghi).mno", "2.0")
    assert hp.get_expression() == ""


# Generated at 2022-06-24 08:08:42.932781
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import unittest

    class IsInCodeTest(unittest.TestCase):
        def test_empty_string(self):
            hp = HyperParser("", "1.0")
            self.assertTrue(hp.is_in_code())

        def test_simple_code(self):
            hp = HyperParser("print('hello')", "1.0")
            self.assertTrue(hp.is_in_code())

        def test_simple_code_at_start(self):
            hp = HyperParser("print('hello')", "0.0")
            self.assertTrue(hp.is_in_code())

        def test_simple_code_at_end(self):
            hp = HyperParser("print('hello')", "1.11")
            self.assertTrue(hp.is_in_code())


# Generated at 2022-06-24 08:08:50.326348
# Unit test for method is_block_opener of class RoughParser

# Generated at 2022-06-24 08:08:53.086796
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    import unittest

    origin = dict(a=1, b=2)

    mapping = StringTranslatePseudoMapping(origin, 0)

    it = iter(mapping)

    assert next(it) == 'a'
    assert next(it) == 'b'

    with unittest.assertRaises(StopIteration):
        next(it)



# Generated at 2022-06-24 08:09:03.605275
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    """This unittest may be run from IDLE.

    It should print 'Done' if the test passed and nothing if it fails.
    """
    import unittest


# Generated at 2022-06-24 08:09:08.992605
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser("")
    rp.set_lo(None)
    rp.set_lo(42)
    with pytest.raises(Exception):
        rp.set_lo(-1)
    with pytest.raises(Exception):
        rp.set_lo(1234567)


# Generated at 2022-06-24 08:09:22.033592
# Unit test for constructor of class RoughParser
def test_RoughParser():
    for i in range(1):
        for input_ in [
            """
            if 1:
                if 2:
                    pass


            pass
            """,
            """
            if 1:
                if 2:
                    pass
                pass
            """,
            """
            if 1:
                if 2:
                    if 3:
                        pass
                if 4:
                    pass
            """,
        ]:
            if False:  # set this to True to install debugging hooks
                RoughParser.__init__ = RoughParser_debug
                global debug_info
                debug_info = []

            input_ = textwrap.dedent(input_).strip() + "\n"
            p = RoughParser(input_)

            if False:  # set this to True to check __init__ debugging info
                print(debug_info)


# Generated at 2022-06-24 08:09:30.255701
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    def test_case(s, pos):
        r = RoughParser(s)
        l = r.get_last_open_bracket_pos()
        assert l == pos, (s, l, pos)

    test_case("if 1:\n    a()", 4)
    test_case("if 1:\n    a(\n)", 4)
    test_case("if 1:\n    a(\n      )", 4)
    test_case("if 1:\n    a()\n  b()", 4)
    test_case("1", None)
    test_case("1\nfoo(\nbar)", None)
    test_case("{}", None)
    test_case("{}\nfoo(\nbar)", None)
    test_case("{a:1}", None)

# Generated at 2022-06-24 08:09:34.916697
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():  # 98

    class Dummy:
        pass

    text = Dummy()
    text.indent_width = 4
    text.tabwidth = 8
    text.get = lambda a, b: b[len(a) + 2 :]  # add two to take care of + " \n"

    def index(s):
        "Simulate enough of the text index method"
        return s

    text.index = index
    h = HyperParser(text, index("1.0"))

    def check(h, rawtext, index, expected):
        h.rawtext = rawtext
        h.bracketing = RoughParser(4, 8).get_all_stmt_bracketings(rawtext + " \n")[0]

# Generated at 2022-06-24 08:09:38.969908
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    f = RoughParser(0)
    f.set_str("hi")  # calls study.  No syntax errors.
    f.set_str("x = hi")  # a syntax error
    assert f.get_error_line() == 1



# Generated at 2022-06-24 08:09:49.651289
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements

    def verify(str_, expected):
        parser = RoughParser(str_)
        assert expected == parser.compute_bracket_indent()

    for width in (4, 8):
        verify(""">
      [
        1,
        2,
        3,
    """, width)
        verify("""
[

""", width)

# Generated at 2022-06-24 08:10:00.383372
# Unit test for constructor of class HyperParser
def test_HyperParser():
    """Propose a number of test cases for HyperParser.

    Do it in a non-interactive way, which is simpler, but doesn't
    show the text boxes as they are modified.
    """

    import sys
    import inspect

    def check(text, index, result, message):
        """Check a result for HyperParser for given text and index.

        If the result does not match, print an error message and the
        values of the variables text and result.
        """

        parser = HyperParser(text, index)
        if result != parser.get_surrounding_brackets():
            print("ERROR:", message)
            print("text: %s" % repr(text.get("1.0", "end")))
            print("result:", result)

# Generated at 2022-06-24 08:10:13.188064
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    class TestCase:
        def __init__(self, string, indent_width, tabwidth, expected):
            self.string = string
            self.indent_width = indent_width
            self.tabwidth = tabwidth
            self.expected = expected

# Generated at 2022-06-24 08:10:16.363034
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    r = StringTranslatePseudoMapping({65: 65, 97: 97}, 65)
    assert len(r) == 2


# Useful for debugging.


# Generated at 2022-06-24 08:10:24.207052
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=redefined-builtin, no-member
    a = RoughParser()
    a.set_str("")
    assert a.get_num_lines_in_stmt() == 1
    assert a.get_base_indent_string() == ""
    assert a.get_continuation_type() == C_NONE
    assert a.get_last_open_bracket_pos() is None
    assert a.get_last_stmt_bracketing() is None
    assert not a.is_block_closer()
    assert not a.is_block_opener()
    assert a.compute_bracket_indent() == 0
    assert a.compute_backslash_indent() == 0
    a.set_str("x = 3")
    assert a.get_num

# Generated at 2022-06-24 08:10:32.272326
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    substitutions = {ord(c): ord(c) for c in '1'}
    mapping = StringTranslatePseudoMapping(substitutions, ord('x'))
    assert mapping.get(ord('0')) == ord('x')
    assert mapping[ord('1')] == ord('1')

_chew_namechars = StringTranslatePseudoMapping(
    {ord(c): None for c in ' \t\n\r([{},:`=;#\\\'"@'}, None
).get



# Generated at 2022-06-24 08:10:41.004470
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin

    def test_one(s, expected):
        parser = RoughParser(s, 0)
        got = parser.compute_bracket_indent()
        assert got == expected, "for input %r expected %s but got %s" % (
            s,
            expected,
            got,
        )

    def test_many(table, expected):
        for s in table:
            test_one(s, expected)

    def test_2(table):
        test_many(
            table,
            4,
        )

    def test_3(table):
        test_many(
            table,
            8,
        )

    test_2(("[ ", "[a, ", "[1, 2, ", "foo(["))

# Generated at 2022-06-24 08:10:44.741458
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == 4

# Generated at 2022-06-24 08:10:56.582578
# Unit test for constructor of class HyperParser
def test_HyperParser():

    class MockText:
        "Dummy class with enough Text attributes for hyperparser"
        indent_width = 8
        tabwidth = 8

        def get(self, start, end):
            return self.rawtext[int(start) : int(end)]

        def index(self, index):
            return int(index)

    # Some simple cases

    text = MockText()
    text.rawtext = "a,(bc)"
    hp = HyperParser(text, "2.0")
    assert hp.get_expression() == "a"
    assert not hp.is_in_string()
    assert hp.is_in_code()
    assert hp.get_surrounding_brackets() == ("1.0", "4.0")

    text.rawtext = "a,(bc)"

# Generated at 2022-06-24 08:11:10.631313
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    from test.support import temp_dir


# Generated at 2022-06-24 08:11:21.234165
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def test(s):
        p = RoughParser(s)
        return p.get_base_indent_string()
    assert test("x = 5") == ""
    assert test("    x = 5") == "    "
    assert test("\t\tx = 5") == "\t\t"
    assert test("\tx = 5") == "\t"
    assert test("#x = 5") == ""
    assert test("\t#x = 5") == "\t"
    assert test("    a = 8\n    b = 9\n    c = 10\n    d = 11\n") == "    "

# Generated at 2022-06-24 08:11:23.911694
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    test_str = """\
    x = {
    """
    p = RoughParser(test_str)
    assert p.get_continuation_type() == C_BRACKET



# Generated at 2022-06-24 08:11:33.749047
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-24 08:11:42.782385
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    # pylint: disable=redefined-builtin
    from idlelib import snippy

    tests = [
        ("\n", False),
        ("return\n", True),
        ("return #comment\n", True),
        ("assert \\\nTrue\n", False),
        ("\nfoo( #comment\n 1,\n 2\n)", False),
    ]
    for s, result in tests:
        parser = snippy.RoughParser(s)
        if parser.is_block_closer() != result:
            print("For", repr(s), "expected", result)


# Generated at 2022-06-24 08:11:54.891629
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import pytest


# Generated at 2022-06-24 08:11:58.484831
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-24 08:12:00.628915
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    r"""StringTranslatePseudoMapping.__len__() -> int"""



# Generated at 2022-06-24 08:12:06.723560
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """Check that set_index works properly.

    We also check that indexbracket and indexinrawtext are updated
    correctly.
    """

    import unittest

    text = "a,b"
    hp = HyperParser(text)

    class MyTest(unittest.TestCase):
        def test_initial(self):
            hp.set_index("1.0")
            self.assertEqual(hp.text.get("1.0", "insert"), "a,b")
            self.assertEqual(hp.text.get("1.0", "end"), "")
            self.assertEqual(hp.indexinrawtext, 3)
            self.assertEqual(hp.indexbracket, 0)
            self.assertEqual(hp.rawtext, "a,b")


# Generated at 2022-06-24 08:12:12.160739
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    parser = RoughParser("[  # comment\n   1,\n   2,\n]", 0, 4)
    assert parser.compute_bracket_indent() == 2
    parser = RoughParser("[\n]", 0, 4)
    assert parser.compute_bracket_indent() == 4



# Generated at 2022-06-24 08:12:16.733929
# Unit test for constructor of class HyperParser
def test_HyperParser():
    if 0:
        # Fast tests for the module

        class DummyText:
            def __init__(self):
                self.indent_width = 4
                self.tabwidth = 8

        def get_result(dummytext, st, index):
            hp = HyperParser(dummytext, index)
            res = [hp.is_in_string(), hp.is_in_code(), hp.get_expression()]
            assert len(st) - len(hp.rawtext) == len(
                dummytext.get("1.0", index)
            ) - len(hp.rawtext)
            return res

        text = DummyText()
        text.get = lambda x, y: st[x:y]


# Generated at 2022-06-24 08:12:24.251856
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    rough_parser = RoughParser("try:\n    pass\n", 0)
    assert rough_parser.get_continuation_type() == "C_NONE"
    rough_parser = RoughParser("try:\n    pass\\\n", 0)
    assert rough_parser.get_continuation_type() == "C_BACKSLASH"
    rough_parser = RoughParser("try:\n    pass[\\\n", 0)
    assert rough_parser.get_continuation_type() == "C_BRACKET"
    rough_parser = RoughParser('try:\n    pass("""\\\n', 0)
    assert rough_parser.get_continuation_type() == "C_STRING_FIRST_LINE"
    rough_parser = RoughParser('try:\n    pass("""string \\\n', 0)
    assert rough

# Generated at 2022-06-24 08:12:31.688108
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def cbi(source, column, width=4):
        parser = RoughParser(source, width)
        return parser.compute_bracket_indent() == column
    assert cbi("{", 0)
    assert cbi("{}", 0)
    assert cbi("{\n", 0)
    assert cbi("{a\n", 0)
    assert cbi("{\na\n", 4)
    assert cbi("{a\nb\n", 4)
    assert cbi("{a\n    b\n", 0)
    assert cbi("{\na\n    b\n", 4)
    assert cbi("{\na\n    b\n    c\n", 4)
    assert cbi("{\na\n    b\n    c\n}\n", 4)

# Generated at 2022-06-24 08:12:37.680088
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    non_defaults = {ord('\t'): ord('\x00')}
    default = ord(' ')
    mapping = StringTranslatePseudoMapping(non_defaults, default)
    assert mapping.get(ord('\t')) == ord('\x00')
    assert mapping.get(ord(' ')) == ord(' ')
# End of unit test for method get of class StringTranslatePseudoMapping



# Generated at 2022-06-24 08:12:50.085097
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-24 08:12:55.822235
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # The actual test
    t = Text()
    t.insert(END, test_HyperParser_is_in_string_text)
    p = HyperParser(t, "1.0")
    ok = True
    for index, expect in test_HyperParser_is_in_string_results:
        ok = ok and p.is_in_string() == expect
        p.set_index(index)
    if ok:
        t.mark_set("my_mark", END)
    else:
        t.mark_set("my_mark", "1.0")


# Generated at 2022-06-24 08:13:08.916146
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    """Tests for method set_str() of class RoughParser."""

# Generated at 2022-06-24 08:13:18.346132
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    k = StringTranslatePseudoMapping(
        {ord('a'): ord('*'), ord('m'): ord('m'), ord('z'): ord('z')},
        default_value=ord('x')
    )
    assert sorted(list(k)) == [ord('a'), ord('m'), ord('z')]
    assert sorted(k.keys()) == [ord('a'), ord('m'), ord('z')]
    assert sorted(k.values()) == [ord('*'), ord('m'), ord('z')]
    assert sorted(k.items()) == [(ord('a'), ord('*')), (ord('m'), ord('m')),
                                 (ord('z'), ord('z'))]

test_StringTranslatePseudoMapping___iter__()


# Generated at 2022-06-24 08:13:30.357109
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    ROUGH_PARSER_TEST_PASSED = True
    rp = RoughParser()

# Generated at 2022-06-24 08:13:31.900751
# Unit test for constructor of class RoughParser
def test_RoughParser():
    x = RoughParser("whatever")
    assert x.str == "whatever"
    assert x.study_level == 0


# Generated at 2022-06-24 08:13:38.026960
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-24 08:13:48.808278
# Unit test for constructor of class HyperParser
def test_HyperParser():
    t = Text()
    t.insert("insert", "if a:\n  pass")
    t.index("insert")
    hp = HyperParser(t, "insert")
    assert hp.rawtext == "if a:\n  pass\n"
    assert hp.bracketing == [(0, 0), (2, 0), (3, 0), (6, 1), (8, 0)]
    assert hp.isopener == [False, False, True, False, False]
    assert not hp.is_in_string()
    assert hp.get_surrounding_brackets() is None
    t.insert("insert", "  ")
    hp = HyperParser(t, "insert")
    assert hp.get_surrounding_brackets() == ("2.0", "8.0")
    assert hp.get_expression()

# Generated at 2022-06-24 08:13:52.477223
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rp = RoughParser("    a[1] = (foo(\\\n"
                     "        3, 4), 5)\n")
    assert rp.get_num_lines_in_stmt() == 2
    assert rp.compute_backslash_indent() == 5


# Generated at 2022-06-24 08:14:04.631135
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def test(code, base_indent_string):
        p = Parser.RoughParser(code)
        assert p.get_base_indent_string() == base_indent_string

    test("\n", "")
    test("a = 1\n", "")
    test("\t\n", "\t")
    test("a = 1\n\t\n", "\t")
    test("a = 1\nb = 2\n", "")
    test("a = 1\n\tb = 2\n", "\t")
    test("a = 1\n  # comment\n", "  ")
    test("a = 1\n  # comment\nb = 2\n", "")

#------------------------------------------------------------------------
#              The tokenize(iter) function
#------------------------------------------------------------------------

# The iter parameter must

# Generated at 2022-06-24 08:14:13.640747
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    h = HyperParser(Text(), "1.0")
    h.text = "a = (1,\n # comment\n 2)"
    h.set_index("1.0")
    assert h.is_in_code()
    h.set_index("1.3")
    assert not h.is_in_code()
    h.set_index("2.0")
    assert h.is_in_code()
    h.set_index("3.0")
    assert not h.is_in_code()



# Generated at 2022-06-24 08:14:25.999739
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    rp = RoughParser("""
    if 1:
    try:
    if 2:
    def f(): pass
    except 1:
    if 3:
    def g(): pass
    finally:
    if 4:
    def h(): pass
    """)
    assert rp.find_good_parse_start() == 30
    rp = RoughParser("""
    if 1:
    try:
    if 2:
    def f(): pass
    finally:
    if 4:
    def h(): pass
    """)
    assert rp.find_good_parse_start() == 30
    rp = RoughParser("""
    if 1:
    try:
    if 2:
    def f(): pass
    else:
    if 3:
    def g(): pass
    """)
    assert rp.find_

# Generated at 2022-06-24 08:14:28.928676
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    test_base_indent_string(RoughParser, _check_equal)



# Generated at 2022-06-24 08:14:37.787972
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser(u"\n    a = b\n", tabwidth=4)
    rp._study2()
    assert rp.get_base_indent_string() == u"    "

    rp = RoughParser(u" c = d", tabwidth=4)
    rp._study1()
    assert rp.get_base_indent_string() == u" "

    rp = RoughParser(u"\n", tabwidth=4)
    rp._study2()
    assert rp.get_base_indent_string() == u""

# Generated at 2022-06-24 08:14:40.390187
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    parser = RoughParser(test_str, 0)
    parser.get_last_open_bracket_pos() == 5

# Generated at 2022-06-24 08:14:50.024212
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-24 08:15:00.310662
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # Test that RoughParser doesn't crash on various inputs.
    RoughParser("")
    RoughParser("# hi\n")
    RoughParser("# hi\n\n")
    RoughParser("pass\n")
    RoughParser("pass # hi\n")
    RoughParser("pass \\\n")
    RoughParser("pass \\\nhi\n")
    RoughParser("pass # hi\\\n")
    RoughParser("pass # hi\\\n\n")
    RoughParser("pass # hi\\\nhi\n")
    RoughParser("pass # hi\\\n\nhi\n")
    RoughParser("pass # hi\\\n\nhi # there\n")
    RoughParser("pass # hi\\\n\nhi # there\\\n")

# Generated at 2022-06-24 08:15:05.458320
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    from random import randint, random
    from string import whitespace
    from time import time
    from idlelib.tree import _async_call
    if _async_call:
        _async_call(test_StringTranslatePseudoMapping___len__)
        return
    def init_size():
        return max(0, int(random() * 20 - 10))
    def init_dict_length():
        return max(0, int(random() * 20 - 10))
    def init_dict():
        return {randint(0, 20): randint(0, 20) for _ in range(init_dict_length())}
    def init_default_value():
        return randint(0, 20)
    def check_length(n, obj):
        return len(obj) == n

# Generated at 2022-06-24 08:15:14.710362
# Unit test for method set_lo of class RoughParser