

# Generated at 2022-06-24 08:05:22.618060
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():

    rp = RoughParser('''
        result = [
            (1, 2),
            (3, 4),
            #(5, 6),
        ]
    ''')
    expected = [(0, 0), (9, 1), (18, 1), (25, 1), (26, 2), (27, 1), (28, 0)]
    got = rp.get_last_stmt_bracketing()
    assert expected == got

    rp = RoughParser('''
        ''')
    expected = None
    got = rp.get_last_stmt_bracketing()
    assert expected == got

    rp = RoughParser('''
        # comment
        ''')
    expected = [(0, 1), (11, 0)]
    got = rp.get_last_stmt_br

# Generated at 2022-06-24 08:05:31.293105
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    # http://bugs.archlinux.org/task/17621
    used_keywords = ['for', 'while', 'with', 'if', 'elif', 'else', 'def', 'class',
                     'try', 'except', 'finally', 'except', 'as', 'lambda',
                     'from', 'and', 'or', 'not', 'is']
    for kw in used_keywords:
        rp = RoughParser("%s foo:" % kw, "", "", "")
        assert rp.is_block_opener() == True, "%s should be a block opener" % kw
        rp = RoughParser("%s foo:" % kw, "", "", "")
        assert rp.is_block_opener("%s foo:" % kw) == True, "%s should be a block opener"

# Generated at 2022-06-24 08:05:40.519277
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from test.test_support import requires

    requires("gui")

    from idlelib.idle_test.mock_idle import Func
    root = Tk()
    root.withdraw()
    text = Text(root)
    text.insert(END, "class foo:\n    def bar(self):\n        pass")
    text.mark_set(INSERT, "1.0")
    text.pack()
    text.focus_set()

    hp = HyperParser(text)
    assert hp.is_in_code()
    text.mark_set(INSERT, "2.0")
    assert hp.is_in_code()
    text.mark_set(INSERT, "2.4")
    assert not hp.is_in_code()

# Generated at 2022-06-24 08:05:46.801515
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Test(TestCase):
        def test1(self):
            text = Text(
                """\
    def f():
        pass
# comment
"""
            )
            hp = HyperParser(text, "1.0")
            self.assertEqual(hp.is_in_code(), True)
            hp.set_index("1.12")
            self.assertEqual(hp.is_in_code(), False)
            hp.set_index("1.0")
            self.assertEqual(hp.is_in_code(), True)
            hp.set_index("1.4")
            self.assertEqual(hp.is_in_code(), True)
            hp.set_index("2.0")

# Generated at 2022-06-24 08:05:59.886306
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    """Verify method HyperParser.is_in_string."""

    text = EditWin.EditWindow(None)
    text.insert("1.0", 'a = "string"\n')
    text.insert("2.0", "'another string'\n")
    text.insert("3.0", "str = \"yet another \\\"string\\\"\"\n")
    text.insert("4.0", 'print r"raw string"\n')
    text.insert("5.0", "print R'raw string'\n")
    text.insert("6.0", "print u'unicode string'\n")
    text.insert("7.0", "print b'bytes string'\n")


# Generated at 2022-06-24 08:06:03.941217
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    rp = RoughParser("foo", 4, 0)
    rp.str = "foo (\n    bar\n    baz\n    )"
    rp.goodlines = [0, 5, 9, 12]
    rp._study1()
    assert rp.continuation == C_BRACKET

# Generated at 2022-06-24 08:06:12.298637
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    # Test that __iter__ gives a Python 2 and Python 3 compatible iterator
    # (Python 2 iterators are not iterators, but sequences)
    mapping = StringTranslatePseudoMapping({42:43}, 44)
    iterator = mapping.__iter__()
    values = []
    for value in iterator:
        values.append(value)
    assert values == [42]
    iterator_as_sequence = iterator.__iter__()
    values = []
    for value in iterator_as_sequence:
        values.append(value)
    assert values == [42]



# Generated at 2022-06-24 08:06:22.365323
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    """
    >>> rp = RoughParser("\nprint(1)")
    >>> assert rp.find_good_parse_start() == 1
    >>> rp = RoughParser("\n\nprint(1)")
    >>> assert rp.find_good_parse_start() == 2
    >>> rp = RoughParser("\n\nprint(1)\n")
    >>> assert rp.find_good_parse_start() == 2
    >>> rp = RoughParser("\n\nprint(1)\n\n")
    >>> assert rp.find_good_parse_start() == 2
    """



# Generated at 2022-06-24 08:06:28.155227
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == len(whitespace_chars)



# Generated at 2022-06-24 08:06:39.156433
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    from pytest import raises
    from simpleparse.parser import ParserError
    parser = RoughParser()
    # Test invalid arguments
    with raises(TypeError):
        parser.compute_backslash_indent(3)
    # Test simple case
    parser.set_str("""\
    stmt
    stmt
    stmt
    stmt
    stmt
    stmt
    stmt
    stmt
    stmt
    stmt
    stmt
    stmt
    stmt
    """)
    parser._study1()
    assert parser.get_continuation_type() == C_NONE
    parser._study2()
    assert parser.get_continuation_type() == C_NONE
    assert parser.get_base_indent

# Generated at 2022-06-24 08:06:40.134887
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-24 08:06:46.719937
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():

    def test1(str, expected):
        actual = RoughParser(str).is_block_closer()
        if actual == expected:
            print("ok -- %r" % (str,))
        else:
            print("expected %r but got %r for %r" % (expected, actual, str))

    test1("  x = a  # hi there\\\n  # yo mama\n", False)
    test1("  x = a  # hi there\\\n  # yo mama", False)
    test1("  x = a  # hi there\\\n  y = b\n", False)
    test1("  x = a  # hi there\\\n  y = b\n", False)
    test1("  x = a  # hi there\\\n  x = b\n", False)


# Generated at 2022-06-24 08:06:58.168458
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    rp = RoughParser()
    assert rp.compute_bracket_indent() == 0
    rp.setup("if foo:", indent_width=4, tabwidth=8)
    assert rp.compute_bracket_indent() == 4
    rp.setup("if foo:", indent_width=4, tabwidth=8)
    assert rp.compute_bracket_indent() == 4
    rp.setup("if foo:", indent_width=4, tabwidth=8)
    assert rp.compute_bracket_indent() == 4
    rp.setup("if foo:", indent_width=4, tabwidth=8)
    assert rp.compute_bracket_indent() == 4

# Generated at 2022-06-24 08:07:08.005624
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest
    import test.test_support

    class HyperParserTestCase(unittest.TestCase):

        def setUp(self):
            self.hp = HyperParser("   abc", "1.0")

        def test_getting_expressions(self):

            def test(expr, correctexpr):
                self.hp.text.set("   " + expr)
                self.hp.set_index("1.3")
                self.assertEqual(self.hp.get_expression(), correctexpr)

            test("abc", "abc")
            test("abc.def", "def")
            test("abc.def.ghi.jkl", "jkl")
            test("abc().def", "def")
            test("abc.def(ghi.jkl)", "jkl")

# Generated at 2022-06-24 08:07:15.650907
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    from lib2to3.pgen2.parse import ParseError

    def f(s, row, col, allow_parse_error=False):
        try:
            i = RoughParser(s, row, col).find_good_parse_start()
        except ParseError as e:
            if allow_parse_error:
                return e
            raise TestFailed("%s" % e)
        assert s[i:] == s[i : i + len(s[i:])].lstrip()
        return i

    assert f("1 + [2, 4]", 0, 0) == 0
    assert f("1 + [2, 4]", 2, 1) == 2
    assert f("1 + [2, 4]", 0, 5) == 4

# Generated at 2022-06-24 08:07:21.305498
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    parser = RoughParser(
        """
        (    # first open bracket
        [
        )  # first close bracket
        ]  # second close bracket
        (    # second open bracket
        (    # third open bracket
        )    # second close bracket
        [
        ]    # fourth close bracket
        (    # fifth open bracket
        )    # third close bracket
        """,
        0
    )
    assert parser.get_last_open_bracket_pos() == 34, \
           "last open bracket should be at position 34"



# Generated at 2022-06-24 08:07:27.421892
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    print("Testing HyperParser.get_surrounding_brackets...")
    hp = HyperParser(None, None)

    def test_at_index(src, index, result):
        hp.text = tk.Text()
        hp.rawtext = src
        hp.stopatindex = repr(len(src)) + ".0"
        hp.bracketing = RoughParser(0, 0).get_all_stmt_bracketings(src)[0]
        hp.isopener = [
            i > 0 and hp.bracketing[i][1] > hp.bracketing[i - 1][1]
            for i in range(len(hp.bracketing))
        ]
        hp.indexinrawtext = len(src) - len(src[len(src) - index :])
        # find the rightmost

# Generated at 2022-06-24 08:07:34.472845
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    # test at tabsize 1
    if test.test_support.verbose:
        print("\nstarting test_compute_backslash_indent at TAB_SIZE = 1")
    f = RoughParser("", 1).compute_backslash_indent
    e = lambda s, expected: _test_one(f, s, expected, 1)
    e("", 0)
    e("\n", 0)
    e("\\\n", 0)
    e("  \\\n", 2)
    e("x\\\n", 1)
    e("    x\\\n", 4)
    e("if 1:\\\n", 4)
    e("if 1:  \\\n", 6)

# Generated at 2022-06-24 08:07:46.937893
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-24 08:07:53.469717
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def hptest(text, pos, expected_value):
        ep = HyperParser(text, pos)
        test.assert_equal(ep.is_in_code(), expected_value)

    def simpletest(text, pos):
        hptest(text, pos, False)
        hptest(text, pos + "|", True)

    text = Text(
        tabsize=4,
        indentwidth=4,
        indentsize=4,
        context_use_ps1=False,
    )
    hptest(text, "1.0", True)
    hptest(text, "1.0 linestart", True)
    hptest(text, "1.0 lineend", True)
    hptest(text, "1.1", True)

# Generated at 2022-06-24 08:08:02.548242
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    for line in (
        "a = 1",
        "a = '('",
        "a = foo(1, 2)",
        "a = 'foo'",
        "a = 3 + 4",
        'a = "foo"',
        "a = (3 + 4)",
    ):
        hp = HyperParser(tkinter.Text(), "1.0")
        hp.stopatindex = "1.end"
        hp.rawtext = line
        hp.bracketing = RoughParser(8, 8).get_last_stmt_bracketing(line)
        hp.isopener = [
            i > 0 and hp.bracketing[i][1] > hp.bracketing[i - 1][1]
            for i in range(len(hp.bracketing))
        ]

# Generated at 2022-06-24 08:08:11.661103
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    rp = RoughParser(r"""if 1:
    print(0)
if 2:
    print(1) # I am a comment
else:
    print(2)
if 3:
    print(3)
    else:
        print(4)
if 4:
    print(5)
else:
    print(6)
""")

# Generated at 2022-06-24 08:08:16.294130
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    '''Unit test for method __getitem__ of class StringTranslatePseudoMapping
    '''
    functional_test_dict = {ord('a'): ord('x')}
    obj = StringTranslatePseudoMapping(functional_test_dict, ord('y'))
    assert obj[ord('a')] == ord('x'), 'incorrect dict value'
    assert obj[ord('b')] == ord('y'), 'incorrect dict value'

# Generated at 2022-06-24 08:08:26.603499
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    text = "a = (\n1\n)\n" # only final line is interesting
    parser = RoughParser(text)
    assert parser.get_num_lines_in_stmt() == 1

    text += "b = (\n1)\n" # final 2 lines are interesting
    parser = RoughParser(text)
    assert parser.get_num_lines_in_stmt() == 2

    text = "a = (1\n)\n" # no trailing newline
    parser = RoughParser(text)
    assert parser.get_num_lines_in_stmt() == 1

    text = "a = 1\n" # no continuation
    parser = RoughParser(text)
    assert parser.get_num_lines_in_stmt() == 1



# Generated at 2022-06-24 08:08:32.090147
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-outer-name
    import doctest
    doctest.run_docstring_examples(
        RoughParser.compute_backslash_indent,
        globals(),
        name="RoughParser.compute_backslash_indent"
    )



# Generated at 2022-06-24 08:08:40.142470
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    """
    >>> p = RoughParser("foo\\nbar", 0, [0, 0])
    >>> p.get_num_lines_in_stmt()
    2

    >>> p = RoughParser("foo", 0, [0, 0])
    >>> p.get_num_lines_in_stmt()
    1
    """


# Helper instances
# pylint: disable=invalid-name
_junkre = re.compile(r"^\s*(#.*)?$").match
_ordinaryre = re.compile(r"[^#\"'\\\n]*").match
_itemre = re.compile(r"\s*[^#\"'\\\n]*").match
_closere = re.compile(r"^\s*[])}]\s*$").match


# Generated at 2022-06-24 08:08:50.634192
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin
    def test(input, expected_indent):
        # pylint: disable=redefined-builtin
        parser = _RoughParser(input, indent_width=4)
        assert parser.compute_bracket_indent() == expected_indent
    test('''[1,
2,
3]''', 4)
    test('''{1:
2,
3}''', 4)
    test('''{1: 2,
3:
4}''', 8)
    test('''{1: 2,
3: 4}''', 8)
    test('''if (1:
2)''', 8)
    test('''if 1:
2''', 4)

# Generated at 2022-06-24 08:08:55.428252
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()
    rp.set_str("hello world")
    assert rp.str == "hello world"
    assert rp.study_level == 0
    assert rp.continuation == C_NONE
    assert rp.goodlines == [1]


# Generated at 2022-06-24 08:09:02.064504
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    # This actually tests whether or not str.translate() is smart
    # enough to use __getitem__() instead of __getattr__()
    # <<<<<<< HEAD
    non_defaults = {ord(c): ord(c)+1 for c in 'abc'}
    mapping = StringTranslatePseudoMapping(non_defaults, ord('x'))
    assert 'aBc'.translate(mapping) == 'bCd'
    # Special case: empty dict
    mapping = StringTranslatePseudoMapping({}, ord('x'))
    assert 'aBc'.translate(mapping) == 'xxx'

# Perform string translation on a given string _s, replacing all
# characters that are neither letters, numbers, nor underscores with
# the given replacement character _r.

# Generated at 2022-06-24 08:09:07.795341
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))

    for c in string.printable:
        if c in whitespace_chars:
            actual = mapping[ord(c)]
            assert actual == ord(c)
        else:
            actual = mapping[ord(c)]
            assert actual == ord("x")



# Generated at 2022-06-24 08:09:13.899107
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    text = """
    1
    2
    3
    """.lstrip()
    assert RoughParser(text).get_num_lines_in_stmt() == 3



# Generated at 2022-06-24 08:09:21.720668
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    source1 = """\
if True:
    print("1")"""
    source2 = """\
if True:
    print("1")
else:
    print("2")"""
    source3 = """\
if True:
    print("1")
    if True:
        print("2")
"""
    source4 = """\
if True:
    if True:
        print("2")
    print("1")
"""

    def analysis_source(source):
        p = RoughParser(source)
        p._study2()
        print("lastopenbracketpos:", p.lastopenbracketpos)
        print("stmt_bracketing:", p.stmt_bracketing)
        print("lastch:", repr(p.lastch))

    print("source1")

# Generated at 2022-06-24 08:09:30.231084
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import fix_getnames
    import keyword
    import tokenize
    import token

    i = 3
    kw = keyword.kwlist[i]
    if kw[0].isupper():
        return

    # In the following text:
    # a) the string 'kw' should be parsed as a normal identifier;
    # b) the string 'Kw' should be parsed as a keyword, even if it is not
    #    a keyword;
    # c) the string 'Kw' should be parsed as an identifier if fix_getnames
    #    is being used and Kw is not a keyword.
    text = """\
    kw = 1
    Kw = 1
    """

    f = StringIO(text)

# Generated at 2022-06-24 08:09:40.872424
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    "Unit test for method get_expression of class HyperParser."

    def check_hyper_parser(text, index, expected):
        actual = HyperParser(text, index).get_expression()
        if actual != expected:
            assert actual == expected, (
                "Wrong result for %r at %s: expected %s, got %s"
                % (text.get("1.0", "end"), index, repr(expected), repr(actual))
            )

    def check_hyper_parser_exception(text, index):
        try:
            HyperParser(text, index).get_expression()
        except ValueError:
            pass  # Correct exception
        else:
            assert False, "Expected exception not raised for %r at %s" % (text.get("1.0", "end"), index)

    from tkinter import Text

# Generated at 2022-06-24 08:09:45.761454
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    x=StringTranslatePseudoMapping({"a":10,"b":20},30)
    assert x.__getitem__('a')==10
    assert x.__getitem__('b')==20
    assert x.__getitem__('c')==30
    assert x.get('a')==10
    assert x.get('b')==20
    assert x.get('c')==30


# Generated at 2022-06-24 08:09:53.694102
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from idlelib.idle_test.idle_test_support import run_unittest

    class Test_HyperParser(unittest.TestCase):
        def _hp_get_expression(self, s, index):
            hp = HyperParser(s, index)
            return hp.get_expression()


# Generated at 2022-06-24 08:10:00.214301
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():

    non_defaults = {ord('a') : ord('b'), ord('c') : ord('d')}
    default_value = ord('x')
    mapping = StringTranslatePseudoMapping(non_defaults, default_value)

    assert mapping.get(ord('a')) == ord('b')
    assert mapping.get(ord('x')) == default_value
    assert mapping.get(ord('z')) == default_value


# Generated at 2022-06-24 08:10:07.885925
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from tkinter import Tk

    root = Tk()
    root.withdraw()
    text = root.clipboard_get()

    # create an instance of HyperParser
    hyper_parser = HyperParser(text, "1.0")

    # test the method is_in_code(self)
    print(hyper_parser.is_in_code())
    print(hyper_parser.is_in_string())



# Generated at 2022-06-24 08:10:13.647045
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    assert RoughParser("if foo:").is_block_opener()
    assert not RoughParser("if foo: return").is_block_opener()
    assert RoughParser("if foo:\n  print('foo')").is_block_opener()
    assert not RoughParser("if foo:\n  print('foo')\n  return").is_block_opener()

# Generated at 2022-06-24 08:10:22.874281
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    import os, unittest
    import chameleon.core.py3compat
    from chameleon.core.testing import LanguageAdapter
    from chameleon.core.testing import LanguageAdapterTestCase
    from chameleon.core.testing import get_target_language

    class TestRoughParser(LanguageAdapterTestCase):
        def afterSetUp(self):
            self.parser = RoughParser(self.string,
                                      get_target_language('python'))

        def test_get_num_lines_in_stmt(self):
            self.assertEqual(self.parser.get_num_lines_in_stmt(), 2)

    # Instantiate and run the unit test
    suite = unittest.TestSuite((
        unittest.makeSuite(TestRoughParser),
    ))
    unittest

# Generated at 2022-06-24 08:10:26.504682
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    assert StringTranslatePseudoMapping(
        {},
        0,
    ).__len__() == 0



# Generated at 2022-06-24 08:10:37.187296
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    lines = [
        "if 1:",
        "    pass",
        "",
        "def double(x):",
        "    return x * 2",
        "",
        "def main():",
        "    print('Test:', ",
        "          double(12))",
        "",
        "if __name__ == '__main__':",
        "    main()",
        "",
    ]
    parser = RoughParser('\n'.join(lines), len(lines) - 1)
    is_block_opener = parser.is_block_opener()
    assert is_block_opener

    lines = [
        "if __name__ == '__main__'",
        "    main()",  # Missing colon
    ]

# Generated at 2022-06-24 08:10:39.960515
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    mapping = StringTranslatePseudoMapping({1: 1, 2: 2, 3: 3}, 4)
    result = list(iter(mapping))
    assert result == [1, 2, 3]



# Generated at 2022-06-24 08:10:50.743188
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    text = "s_s s.s s/s s\\s s[s s]s s(s s)s" #pylint: disable=anomalous-backslash-in-string
    preserved_chars = "._/"
    replacement_char = 'x'
    preserve_dict = {ord(c): ord(c) for c in preserved_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord(replacement_char))
    assert text.translate(mapping) == 'x_x x.x x/x x\\x x[x x]x x(x x)x'


# Chew up matching brackets as quickly as possible.
# The rules are:
# - square brackets can contain anything, but must start with '[' and
# end with ']'.
# - curly braces

# Generated at 2022-06-24 08:10:53.602618
# Unit test for constructor of class HyperParser
def test_HyperParser():
    for index in ["1.0", "1.4", "end"]:
        text = Text()
        text.insert("insert", "def f(x):\n" " return x+1\n")
        text.insert("insert", "print f(3)")
        HyperParser(text, index)


# Generated at 2022-06-24 08:10:54.311445
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-24 08:10:56.077541
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = tk.Text(None)

# Generated at 2022-06-24 08:10:57.723275
# Unit test for constructor of class HyperParser

# Generated at 2022-06-24 08:11:07.540616
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-24 08:11:10.656438
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == 4
    assert len(str(mapping)) == 6  # at least {' ': 32, '\t': 9, '\n': 10, '\r': 13}

# Generated at 2022-06-24 08:11:17.783821
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))

    assert set(mapping) == set(preserve_dict)


# Generated at 2022-06-24 08:11:26.009746
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    assert mapping.get(ord("a"), 0) == ord("x")
    assert mapping.get(ord(" "), 0) == ord(" ")
    assert mapping.get(ord("\t"), 0) == ord("\t")
    assert mapping.get(ord("\n"), 0) == ord("\n")
    assert mapping.get(ord("\r"), 0) == ord("\r")


# Generated at 2022-06-24 08:11:30.801609
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():# unit test
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}

    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    text.translate(mapping)



# Generated at 2022-06-24 08:11:43.582928
# Unit test for constructor of class RoughParser

# Generated at 2022-06-24 08:11:50.274721
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    """Unit tests for method get of class StringTranslatePseudoMapping"""
    t1 = StringTranslatePseudoMapping({None: 'a'}, 'b')
    assert t1.get('a') == 'b'
    assert t1.get(None) == 'a'
    assert t1.get(object()) == 'b'


# Generated at 2022-06-24 08:12:01.343034
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    rp = RoughParser("")
    assert rp.get_last_open_bracket_pos() is None
    rp = RoughParser("for a in b:")
    assert rp.get_last_open_bracket_pos() is None
    rp = RoughParser("for a in b:\n    pass")
    assert rp.get_last_open_bracket_pos() is None
    rp = RoughParser("for a in [1]:")
    assert rp.get_last_open_bracket_pos() == 8
    rp = RoughParser("for a in [1]:\n    pass")
    assert rp.get_last_open_bracket_pos() == 8
    rp = RoughParser("for a in [1]:\n    pass\n    [2]")

# Generated at 2022-06-24 08:12:12.669151
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    empty_dict = {}
    mapping = StringTranslatePseudoMapping(empty_dict, ord(' '))

    # Try to get an item that is in the underlying dict.
    assert mapping.get(ord('A')) == ord(' ')

    # Try to get an item that is not in the underlying dict.
    assert mapping.get(ord('B')) == ord(' ')

    # Try to get an item that is in the underlying dict and specify
    # a default.
    assert mapping.get(ord('A'), ord('x')) == ord(' ')

    # Try to get an item that is not in the underlying dict and specify
    # a default.
    assert mapping.get(ord('B'), ord('x')) == ord('x')

    # Try to get an item that is not in the underlying dict, specify a
   

# Generated at 2022-06-24 08:12:21.097293
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    '''test get_last_stmt_bracketing'''
    text = '''        # Dummy comment.
        if boo:
            for _ in range(2):
                r = 2 ** 8
'''
    rp = RoughParser(text)
    assert not rp.get_last_stmt_bracketing()
    rp = RoughParser(text.replace('#', 'if'))
    assert rp.get_last_stmt_bracketing() == ((17, 0), (18, 1), (25, 0))
    rp = RoughParser(text.replace('#', '('))
    assert rp.get_last_stmt_bracketing() == ((16, 0), (17, 1), (24, 0))
    rp = RoughParser(text.replace('#', ')'))


# Generated at 2022-06-24 08:12:29.311350
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-24 08:12:39.637273
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    print("testing RoughParser.get_last_stmt_bracketing")
    def test(code, expected_result):
        print('\ncode: """\n%s\n"""' % code)
        result = RoughParser(code).get_last_stmt_bracketing()
        print("result:", result)
        print("expected_result:", expected_result)
        assert result == expected_result
    test("", None)
    test("# comment", None)
    test("# comment\n\n# comment", None)
    test("# comment\n\n# comment\n\n", None)

    # TODO: check that these pass
    test("x", ((0, 0), (1, 0)))

# Generated at 2022-06-24 08:12:45.200713
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    r"""StringTranslatePseudoMapping.__len__() -> int"""
    obj = StringTranslatePseudoMapping(None, None)
    assert not len(obj)
    assert not len(StringTranslatePseudoMapping({}, None))
    assert len(StringTranslatePseudoMapping({1: 1}, None)) == 1

# Generated at 2022-06-24 08:12:55.431417
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def test_1(self):
            hp = HyperParser("a.b.c", "1.2")
            self.assertEqual(hp.get_expression(), "c")
            hp.set_index("1.5")
            self.assertEqual(hp.get_expression(), "b.c")
            hp.set_index("1.6")
            self.assertEqual(hp.get_expression(), "b.c")
            hp.set_index("1.1")
            self.assertEqual(hp.get_expression(), "a.b.c")
            hp.set_index("1.0")
            self.assertEqual(hp.get_expression(), "")


# Generated at 2022-06-24 08:13:08.512479
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def check(s, expected):
        r = RoughParser(s)
        assert r.get_base_indent_string() == expected

    check("", "")
    check("# comment", "")
    check("#\n#\n#\nx = 5\n", "")
    check("x = 5\n", "")
    check("\nx = 5\n", "\n")
    check("  \tx = 5\n", "  \t")
    check("\n  \tx = 5\n", "\n  \t")
    check("\n\n  \tx = 5\n", "\n\n  \t")
    check("\n\n  \tx = 5\n  \n", "\n\n  \t")

# Generated at 2022-06-24 08:13:18.038478
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str(): # pylint: disable=invalid-name
    rp = RoughParser()
    rp.set_str("1\n2\n3\n")
    assert rp.get_line_count() == 3, "line count incorrect"
    assert rp.get_line_start(0) == 0, "line starts incorrect"
    assert rp.get_line_start(1) == 2, "line starts incorrect"
    assert rp.get_line_start(2) == 4, "line starts incorrect"
    assert rp.get_line_start(3) == 6, "line starts incorrect"
    #
    # now test that continuation detection works
    rp.set_str("1\n2\\\n3\n")
    assert rp.get_line_count() == 3, "line count incorrect"
   

# Generated at 2022-06-24 08:13:27.211490
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    global _counter  # pylint: disable=global-statement
    _counter = 0
    lines = []  # pylint: disable=unused-variable
    for line in _parser.text.splitlines():
        if line.startswith("#"): # pragma: no cover
            continue
        _counter += 1
        try:
            # pylint: disable=eval-used
            lines.append(eval(line))
        except:  # pylint: disable=bare-except
            print(_parser.text)
            raise
    assert _counter == len(lines)

    for line, flag in lines:
        assert RoughParser(line).get_continuation_type() == flag

# Generated at 2022-06-24 08:13:32.046705
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from idlelib.idle_test.mock_tk import Text

    text = Text()
    hp = HyperParser(text, "1.0")
    hp.set_index("1.0")
    text.insert("1.0", "abc 11 22")
    hp.set_index("1.end")
    return hp, text

if __name__ == "__main__":
    test_HyperParser_set_index()



# Generated at 2022-06-24 08:13:39.053793
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import unittest

    class Test_HyperParser_is_in_code(unittest.TestCase):
        """Test method is_in_code of class HyperParser"""

        def runTest(self):

            class MockText:
                def __init__(self, text, index):
                    self.text = text
                    self.index = index

                def get(self, start, stop):
                    return self.text[start : stop]

                def index(self, index):
                    if index == "end":
                        return str(len(self.text))
                    return index

            def generate_cases():
                for i in range(4):
                    if i == 0:
                        text = 'print("Hello, World!")'
                        expect = True
                    if i == 1:
                        text = 'print("Hello, World!")  # comment'

# Generated at 2022-06-24 08:13:49.061417
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    from os.path import dirname
    from test_tokenize import tokenize_test_file
    sio = StringIO()
    opt = tokenize_test_file(
        os.path.join(dirname(__file__), "tokenize_tests", "test2.py"),
        printfunc=sio.write)
    lines = sio.getvalue().splitlines()
    for line in lines[:]:
        if line is None:
            lines.remove(None)
    lines.remove(
        "========================================================================")
    rp = RoughParser(lines)
    indent = rp.compute_backslash_indent()
    assert indent == 5, "backslash indent: %d != 5" % indent


# Generated at 2022-06-24 08:13:59.060704
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    # pylint: disable=redefined-builtin

    class Case:
        def __init__(self, source, expected):
            self.source = source
            self.expected = expected


# Generated at 2022-06-24 08:14:05.874915
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    """Ensure StringTranslatePseudoMapping.__iter__() works as expected"""
    mapping = StringTranslatePseudoMapping({"s": ord("s")}, ord("x"))
    assert "s" in mapping
    assert "r" not in mapping
    # dict() is used to ensure we get a predictable ordering for the test
    assert dict(mapping) == {'s': ord("s")}
    assert frozenset(mapping) == frozenset({'s'})



# Generated at 2022-06-24 08:14:17.239820
# Unit test for constructor of class RoughParser

# Generated at 2022-06-24 08:14:27.195877
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    mapping = StringTranslatePseudoMapping({'a': 'b'}, 'c')
    translation_table = mapping.get_translation_table()
    expected_translation_table = {
        ord('a'): 'b',
        ord('b'): 'c',
        }
    assert translation_table == expected_translation_table


# class HyperParser:
#
#     def __init__(self, indentwidth, tabwidth,
#                  context_use_ps1=True):
#         self.indentwidth = indentwidth
#         self.tabwidth = tabwidth
#         self.context_use_ps1 = context_use_ps1
#
#
#     def parse_block(self, text, startindex):
#         """Analyze Python block enclosing startindex.
#
#         Return info:
#


# Generated at 2022-06-24 08:14:32.350719
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    # Tests for method __len__ of class StringTranslatePseudoMapping
    mapping = StringTranslatePseudoMapping({1: 1, 2: 2}, 3)
    assert len(mapping) == 2, "len(StringTranslatePseudoMapping) == 2"



# Generated at 2022-06-24 08:14:38.513871
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({ord('a'): ord('b')}, ord('x'))
    assert mapping.get(ord('a')) == ord('b')
    assert mapping.get(ord('c')) == ord('x')
    assert mapping.get(ord('c'), ord('d')) == ord('d')
    assert mapping.get(ord('c'), default=ord('d')) == ord('d')



# Generated at 2022-06-24 08:14:43.652156
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    r"""Testcase that tests method __getitem__ of class StringTranslatePseudoMapping"""
    # Create test object
    mapping = None
    mapping = StringTranslatePseudoMapping({"ab":1}, 2)
    result = mapping["ab"]
    assert result == 1, result
    result = mapping["xy"]
    assert result == 2, result

# Generated at 2022-06-24 08:14:45.184148
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    iter(StringTranslatePseudoMapping({}, None))

# Generated at 2022-06-24 08:14:53.224110
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    from lib2to3.pgen2.tokenize import group


# Generated at 2022-06-24 08:15:02.392119
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    def check(src, indent):
        parser = RoughParser(src, indent_width=4, tabwidth=8)
        assert parser.compute_backslash_indent() == indent

    check(
        "if 1: \\",
        4,
    )
    check(
        "if 1: \\\n    2",
        4,
    )
    check(
        "if 1: \\\n    a = 1 + \\",
        8,
    )
    check(
        "if 1: \\\n    a = 1 + \\\n        2",
        8,
    )
    check(
        "if 1: \\\n    a = \\",
        8,
    )
    check(
        "if 1: \\\n    a = 2",
        8,
    )

# Generated at 2022-06-24 08:15:11.721536
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    print("unit testing StringTranslatePseudoMapping.get()")
    replaced_value = ord('x')
    preserve_dict = {}
    mapping = StringTranslatePseudoMapping(preserve_dict, replaced_value)
    assert len(mapping) == 0
    assert mapping.get(ord('a')) == replaced_value
    assert mapping.get(ord('b'), ord('y')) == replaced_value
    preserve_dict = {ord('c'): ord('c')}
    mapping = StringTranslatePseudoMapping(preserve_dict, replaced_value)
    assert len(mapping) == 1
    assert mapping.get(ord('c')) == ord('c')
    assert mapping.get(ord('d')) == replaced_value

# Generated at 2022-06-24 08:15:20.540763
# Unit test for constructor of class RoughParser
def test_RoughParser():
    from test.test_tokenize import tokenize_cases

    for input_, (encoding, tokens) in tokenize_cases:
        rp = RoughParser(input_, encoding)
        lno = 0
        for i in range(0, len(tokens)):
            tok = tokens[i]
            lno = tok.start[0]
            if tok.type == token.NEWLINE and i + 1 != len(tokens):
                end = tokens[i+1].start[0]
                if end > lno + 1:
                    assert rp.get_num_lines_in_stmt() == end - lno
                    assert rp.get_base_indent_string() == ""
                else:
                    assert rp.get_num_lines_in_stmt() == 1