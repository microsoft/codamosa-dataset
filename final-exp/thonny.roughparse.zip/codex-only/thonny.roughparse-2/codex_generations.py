

# Generated at 2022-06-24 08:05:15.720096
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    text = """
a = foo(
        bar,
        baz)
"""
    assert RoughParser(text).get_continuation_type() == C_PAREN


# Generated at 2022-06-24 08:05:22.400861
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    data = r'''
    """a string"""
    '''

    tk = tkinter.Text()
    tk.insert("insert", data)
    hp = HyperParser(tk, "insert")
    res = hp.is_in_string()
    print(res)


if __name__ == "__main__":
    test_HyperParser_is_in_string()


# Generated at 2022-06-24 08:05:28.515669
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    result = text.translate(mapping)
    assert result == "x x x\tx\nx"
    return
test_StringTranslatePseudoMapping___iter__()



# Generated at 2022-06-24 08:05:35.483425
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({}, 5)
    assert mapping.get(3) == 5, "StringTranslatePseudoMapping.get() error"


# Map chars outside the printable range to themselves.
_nonprintable_translation_table = StringTranslatePseudoMapping({i: i for i in range(256)}, None)
nonprintable_replace_char = "?"


# Generated at 2022-06-24 08:05:42.166182
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"



# Generated at 2022-06-24 08:05:51.558762
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # The first case is just a normal one
    text = Text()
    text.insert("1.0", """\
if 1:
    a = 12
    b = 34
    c = 56
    d = 78
    if 1:
        e = 90
        x = 123
""")
    hp = HyperParser(text, "1.0")
    assert hp.bracketing == [(-1, -1), (0, 0), (4, 1), (35, 0), (60, 1), (72, 0)]
    assert hp.isopener == [False, True, False, True, False]

# Generated at 2022-06-24 08:06:01.298424
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    import unittest

    class HPTestCase(unittest.TestCase):
        def _test_is_in_string(self, code, pos, expected):
            """Verify HyperParser.is_in_string() result on a code.

               'code' should be a multiline string and 'pos' should be
               a text index in it.
            """
            hp = HyperParser(code, pos)
            self.assertEqual(hp.is_in_string(), expected)

        def test_is_in_string(self):
            self._test_is_in_string("a = 'a'", "1.3", True)
            self._test_is_in_string("a = 'a'", "1.2", False)

# Generated at 2022-06-24 08:06:08.375546
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest.mock import Mock

    class FakeText:
        def __init__(self, str):
            self.str = str

        def get(self, start, stop):
            return self.str[start : stop]

        def index(self, index):
            if isinstance(index, int):
                return index
            else:
                return int(index.split(".")[0])

    def test(str, index, res):
        hp = HyperParser(FakeText(str), index)
        if hp.is_in_code() == res:
            return True
        else:
            print(hp.rawtext)
            print(hp.text.str)
            print(hp.indexinrawtext)
            print(hp.indexbracket)
            print(hp.isopener)

# Generated at 2022-06-24 08:06:19.380638
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        got = HyperParser(text, index).get_expression()
        if got != expected:
            raise ValueError(
                "Assertion failed: get_expression(%r, %r) = %r, expected %r"
                % (text, index, got, expected)
            )

    # The test strings are arranged so that the index points just
    # after the expression.
    test("a", "1.0", "")
    test("a ", "1.1", "a")
    test("a.b", "1.2", "a.b")
    test("a.b.c", "1.3", "a.b.c")
    test("a .b .c", "1.6", "a .b .c")

# Generated at 2022-06-24 08:06:25.231223
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    non_defaults = {"A": "X", "B": "Y"}
    default_value = "Z"
    mapping = StringTranslatePseudoMapping(non_defaults, default_value)
    for key, expected_value in non_defaults.items():
        assert mapping[key] == expected_value
    assert mapping["C"] == default_value



# Generated at 2022-06-24 08:06:32.591536
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    from test.test_support import run_unittest
    import unittest

    class RoughParserTestCase(unittest.TestCase):
        def test_is_block_closer(self):
            # Test that is_block_closer works as expected
            rp = RoughParser('if 1: return\nif 1:\n return','test_is_block_closer',debug_level=1)
            self.assertTrue(rp.is_block_closer())
            rp = RoughParser('if 1: return\n\nif 1:\n  return','test_is_block_closer',debug_level=1)
            self.assertTrue(rp.is_block_closer())

# Generated at 2022-06-24 08:06:40.374834
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    class TestClass(StringTranslatePseudoMapping):
        def __init__(self):
            StringTranslatePseudoMapping.__init__(self, {}, 0)
    #
    tc = TestClass()
    assert tc.get(1) == 0
    assert tc.get(2, 8) == 8



# Generated at 2022-06-24 08:06:43.553421
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo(): #@UnusedVariable
    parser = RoughParser()
    parser.set_lo(1)
    assert parser.lo == 1
    parser.set_lo(2)
    assert parser.lo == 2


# Generated at 2022-06-24 08:06:55.908790
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-24 08:07:06.602950
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    def f(s, want):
        p = RoughParser(s)
        if p.get_continuation_type() != C_BACKSLASH:
            # print("didn't find C_BACKSLASH")
            return
        got = p.compute_backslash_indent()
        if got != want:
            print("Error in %r" % s)
            print("Want %d, got %d" % (want, got))

    f("""if 1:
    x = 12
y = 6""", 10)
    f("""if 1:
    x = \\
12""", 10)
    f("""if 1:
    x = 12\\
""", 10)
    f("""if 1:
    x = \\
        12""", 12)

# Generated at 2022-06-24 08:07:10.501489
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    """Unit test for method set_index of class HyperParser"""
    # first, create a text widget, and fill it with some Python code
    t = Tk()
    text = Text(t)

# Generated at 2022-06-24 08:07:18.907403
# Unit test for constructor of class RoughParser
def test_RoughParser():
    from re import compile
    from test.test_deprecations import check_py3k_warnings
    if not hasattr(RoughParser, 'TYPE_CHECKING'):
        with check_py3k_warnings():
            CompileError = compile('dummy', 'dummy').error


    # j = RoughParser(text, indentwidth, tabwidth)
    #
    # Create and return a RoughParser object.  The arguments
    # are passed to the constructor.
    #
    # If the text doesn't consist entirely of whitespace and
    # comments, the RoughParser object can compute various bits
    # of information about the first statement in the block; but
    # it doesn't understand much of the syntax of Python, so it's
    # easily confused, and should be used only for heuristic
    # purposes.  It's especially confused by

# Generated at 2022-06-24 08:07:25.951232
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = ' \t\n\r'
    to_preserve = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(to_preserve, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'
    text = "a + b\tc\nd"
    to_preserve.update({ord('a'): ord('A')})
    mapping = StringTranslatePseudoMapping(to_preserve, ord('x'))
    assert text.translate(mapping) == 'A x b\tc\nx'



# Generated at 2022-06-24 08:07:33.308540
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    class Test:
        def _test(self, rawtext, index):
            index = "%d.%d" % (rawtext.count("\n", 0, index) + 1, index - rawtext.rfind("\n", 0, index))
            hp = HyperParser(self.text, index)
            return hp.get_expression()

        def __init__(self):
            self.text = text = Tkinter.Text(None)

# Generated at 2022-06-24 08:07:38.037650
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser(''' 
        a = ''')
    assert rp.get_first_line_indent_string() == '        '
    assert rp.get_last_line_indent_string() is None
    rp.set_lo('   ')
    assert rp.get_first_line_indent_string() == '   '
    assert rp.get_last_line_indent_string() == '        '


# ---
# Tests for the dedent method of class RoughParser.
# ---


# Generated at 2022-06-24 08:07:48.660087
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rp = RoughParser()

# Generated at 2022-06-24 08:07:58.713981
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=undefined-variable
    # pylint: disable=invalid-name
    # pylint: disable=no-member
    # pylint: disable=expression-not-assigned
    from tokenize import generate_tokens, generate_lines

    def _get_line(lineno, lines):
        i = 0
        while i < len(lines):
            if lines[i][0][0] >= lineno:
                break
            i += 1
        return lines[i][1]

    _C = RoughParser  # class RoughParser

# Generated at 2022-06-24 08:08:03.650335
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    assert set(iter(mapping)) == set(preserve_dict.values())
test_StringTranslatePseudoMapping___iter__()
    

# Generated at 2022-06-24 08:08:13.385335
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # Test all cases which should return True
    h = HyperParser("print('zzz')", "1.10")
    assert h.is_in_string()
    h = HyperParser("print('z\\'z')", "1.11")
    assert h.is_in_string()
    h = HyperParser('print("z\\"z")', "1.11")
    assert h.is_in_string()
    h = HyperParser('print("""zzz""")', "1.12")
    assert h.is_in_string()
    h = HyperParser('print("""z\\"z""")', "1.13")
    assert h.is_in_string()
    h = HyperParser('print("""z\'z""")', "1.13")
    assert h.is_in_string()
    h

# Generated at 2022-06-24 08:08:19.732623
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({'a': 'x'}, 'y')
    assert 'x' == mapping.get('a')
    assert 'y' == mapping.get('b')
    assert 'z' == mapping.get('c', 'z')



# Generated at 2022-06-24 08:08:23.046099
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    """Unit test for method __iter__ of class StringTranslatePseudoMapping"""

    mapping_1 = StringTranslatePseudoMapping({ord('\n'): ord('x'), ord(','): ord(' ')}, ord('x'))
    print(list(mapping_1))


# Compute the difference between two strings, outputting a list of
# (opcode, start, end) tuples

# Generated at 2022-06-24 08:08:27.389678
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    assert StringTranslatePseudoMapping({}, 0) == StringTranslatePseudoMapping({}, -1), \
        "StringTranslatePseudoMapping({}, 0) should be equal to StringTranslatePseudoMapping({}, -1)"


# Generated at 2022-06-24 08:08:38.903215
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    """Unit tests for RoughParser.set_str().

    This is needed to properly test RoughParser.get_continuation_type().
    """
    rp = RoughParser()
    rp.set_str(
        """
        # A comment
        x = 1
        """
    )
    assert rp.get_continuation_type() == C_NONE
    rp.set_str(
        """
        # A comment
        x = \\
            1
        """
    )
    assert rp.get_continuation_type() == C_BACKSLASH
    rp.set_str(
        """
        # A comment
        x = {
            1
        """
    )
    assert rp.get_continuation_type() == C_BRACKET

# Generated at 2022-06-24 08:08:47.538236
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = Text()
    text.insert("insert", "def f(x):\n" "    pass\n")
    text.mark_set("insert", "1.5")
    hp = HyperParser(text, "insert")
    if hp.get_surrounding_brackets("f") != (
        "1.1",
        "1.10",
    ):
        raise ValueError("get_surrounding_brackets error")
    text.mark_set("insert", "2.0")
    hp.set_index("insert")
    if hp.get_surrounding_brackets("f") != (
        "1.1",
        "1.10",
    ):
        raise ValueError("get_surrounding_brackets error")
    text.mark_set("insert", "2.2")
   

# Generated at 2022-06-24 08:08:49.756072
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    lst = [1, 2, 5]
    obj = StringTranslatePseudoMapping(dict(enumerate(lst)), 0)
    assert len(obj) == len(lst)
    assert len(obj) == 3

# Generated at 2022-06-24 08:09:00.783623
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-24 08:09:11.661975
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=redefined-builtin
    parser = RoughParser()
    parser.set_str("x = 6")
    assert parser.get_base_indent_string() == ""
    assert parser.get_last_open_bracket_pos() is None
    assert (
        parser.get_last_stmt_bracketing()
        == ((0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0))
    )

    parser.set_str("if 1:\n    x = 6")
    assert parser.get_base_indent_string() == "    "
    assert parser.get_last_open_bracket_pos() is None
    assert parser.compute_bracket_indent() == 4

# Generated at 2022-06-24 08:09:23.863136
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    """Tests for method compute_bracket_indent of class RoughParser"""
    parser = RoughParser(tabsize=4)
    # Some tests copied from test_indenter.py, but with extra
    # indentation required to make them work.
    str0 = """\
if a:
    if b:
        if c:
            print 'b'
            print 'c'
        if d:
            print 'd'
        print 'yes'
    print 'ok'
"""
    parser.set_str(str0)
    assert parser.compute_bracket_indent() == 4

# Generated at 2022-06-24 08:09:36.307466
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    test_suite = [
        (C_NONE, "a = [\n1, 2, 3]\n"),
        (C_BRACKET, "a = [\n1, 2, 3"),
        (C_BACKSLASH, "a = \\\n1\n"),
        (C_STRING_FIRST_LINE, "s = '''\nbla"),
        (C_STRING_FIRST_LINE, 's = """\nbla'),
        (C_STRING_NEXT_LINES, "s = '''\nbla\nbla'''\n"),
        (C_STRING_NEXT_LINES, 's = """\nbla\nbla"""\n'),
    ]


# Generated at 2022-06-24 08:09:47.713014
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    def check(s, expected):
        try:
            code = compile(s, "", "exec")
        except Exception:
            print(s)
        rp = RoughParser(s, " ", 0)
        actual = rp.find_good_parse_start()
        if actual == expected:
            print("OK")
        else:
            print("FAIL - expected {}, got {}".format(expected, actual))

    check("\ndef x():\n    print(1)\n", 4)
    check("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", 0)

# Generated at 2022-06-24 08:09:59.001030
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import TestCase
    from test.test_support import run_unittest
    from idlelib.idle_test.mock_idle import Func
    from idlelib.idle_test.mock_tk import Mbox_func

    class HPTest(TestCase):
        # Replace the two standard dialogs with functions
        tkerror = Func()
        askyesno = Mbox_func(None)

        def test_is_in_code(self):
            self.text = Text()
            self.hp = HyperParser(self.text, "1.0")
            self.text.insert("1.0", '# Comment 1\n')
            self.assertFalse(self.hp.is_in_code())
            self.assertFalse(self.hp.is_in_string())

# Generated at 2022-06-24 08:10:12.764080
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    test_data = [
        ("""
if 1:
    if 1:
        a = b + \\
            c
    """, C_NONE),
        ("""
if 1:
    if 1:
        a = '''
            b
            '''
    """, C_STRING_FIRST_LINE),
        ("""
if 1:
    if 1:
        a = '''
            b
            ''' + \\
            c
    """, C_BACKSLASH),
        ("""
if 1:
    if 1:
        a = '''
            b
            ''' + [
            c
        ]
    """, C_BRACKET),
    ]

    for code, result in test_data:
        p = RoughParser(code)
        continuation = p.get_continuation_type()

# Generated at 2022-06-24 08:10:20.567830
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Text()
    # Write a dummy text.
    text.insert("1.0", """\
if True:
    def f(x):
        print x
    f(2)
    """)
    # Test the HyperParser.
    assert HyperParser(text, "1.0").get_expression() == ""
    assert HyperParser(text, "1.7").get_expression() == ""
    assert HyperParser(text, "1.8").get_expression() == "True"
    assert HyperParser(text, "2.0").get_expression() == "True"
    assert HyperParser(text, "3.0").get_expression() == "f(2)"
    assert HyperParser(text, "3.1").get_expression() == "2"
    assert HyperParser(text, "3.2").get_expression()

# Generated at 2022-06-24 08:10:34.897837
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=too-many-branches,unused-variable
    import inspect
    import random

    # studylevel is the argument to the RoughParser constructor.
    # testlevel is the argument to the study method.
    # We want to test all combinations of studylevel and testlevel.
    #
    # testlevel 0 means examine only the continuation field.
    # testlevel 1 means examine stmt_start, stmt_end, and continuation.
    # testlevel 2 means test all fields.
    #
    # studylevel 0 means use only study0.
    # studylevel 1 means use only study1.
    # studylevel 2 means use study2.
    #
    # The testlevel value actually given to study() is determined by the
    # studylevel given to the RoughParser constructor.  If the studylevel
    # is 0, study

# Generated at 2022-06-24 08:10:40.172454
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    cases = [
        ("", False),
        ("a", False),
        ("(", False),
        ("(a", False),
        ("(a b)", False),
        ("if", True),
        ("try:", True),
        ("def f():", True),
    ]
    for code, expected in cases:
        rp = RoughParser(code)
        actual = rp.is_block_opener()
        if actual != expected:
            print(code, actual, expected)

# Generated at 2022-06-24 08:10:46.882318
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def t(input, output):
        if HyperParser(input, "insert").get_expression() != output:
            raise RuntimeError(
                "Error in get_expression with input: %r"
                % input.replace("\n", "\\n")
            )

    t("", "")
    t("# comment", "")
    t("# comment\n", "")
    t("# comment\n# comment\n", "")
    t('# comment\n# comment\nx = "string"', "x")
    t('x = "string"\n# comment\n# comment', "")
    t('x = "string"\n# comment\n# comment\nx = "string"', "x")
    t("(a.b)", "a.b")

# Generated at 2022-06-24 08:10:53.410949
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    class test_RoughParser(RoughParser):
        def __init__(self):
            self.lo = None
            self.set_lo("if \n")
    t = test_RoughParser()
    assert t.lo == 3
    t.set_lo("if \t")
    assert t.lo == 4
    t.set_lo("if ")
    assert t.lo == 3
    t.set_lo("")
    assert t.lo == 0

# Generated at 2022-06-24 08:11:06.598833
# Unit test for method is_block_opener of class RoughParser

# Generated at 2022-06-24 08:11:17.192812
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    assert RoughParser("pass").is_block_closer()
    assert RoughParser("pass\n").is_block_closer()
    assert not RoughParser("pass#comment").is_block_closer()
    assert RoughParser("return a+b").is_block_closer()
    assert RoughParser("return\na+b").is_block_closer()
    assert RoughParser("return #comment\na+b").is_block_closer()
    assert not RoughParser("return#comment\na+b").is_block_closer()
    assert not RoughParser("return a+b#comment").is_block_closer()
    assert not RoughParser("return lambda:0").is_block_closer()
    assert RoughParser("return\nlambda:0").is_block_closer()

# Generated at 2022-06-24 08:11:25.484610
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():

    def do_test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.is_in_code()
        if actual != expected:
            return False, "text=%r, index=%r: should be %s" % (text, index, expected)
        else:
            return True, ""


# Generated at 2022-06-24 08:11:34.514415
# Unit test for constructor of class HyperParser
def test_HyperParser():
    "Unit test for class HyperParser"
    import unittest

    class HyperParserTest(unittest.TestCase):
        def setUp(self):
            self.hp = HyperParser(self.text, "1.0")

        def test_is_in_string(self):
            self.assertFalse(self.hp.is_in_string())
            self.hp.set_index("1.5")
            self.assertTrue(self.hp.is_in_string())

        def test_is_in_code(self):
            self.assertTrue(self.hp.is_in_code())
            self.hp.set_index("1.5")
            self.assertFalse(self.hp.is_in_code())


# Generated at 2022-06-24 08:11:43.803747
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    # pylint: disable=redefined-builtin, invalid-name
    """
    >>> rp = RoughParser()

    >>> rp.set_str("while True:\n    i = 1\n    print(i)")
    >>> rp.get_base_indent_string()
    '    '

    >>> rp.set_str("i = 1\nprint(i)")
    >>> rp.get_base_indent_string()
    ''

    >>> rp.set_str("while True:\n    pass")
    >>> rp.get_base_indent_string()
    '    '
    """



# Generated at 2022-06-24 08:11:55.603512
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()
    # pylint: disable=consider-using-ternary
    rp.set_str("if 1:")
    assert rp.get_continuation_type() == C_NONE
    rp.set_str("if 1:\n  pass")
    assert rp.get_continuation_type() == C_NONE
    rp.set_str("if 1:\n  pass\n")
    assert rp.get_continuation_type() == C_NONE
    rp.set_str("if 1:\n  pass\n  ")
    assert rp.get_continuation_type() == C_BACKSLASH
    rp.set_str("for x in range(10,\n    20):")
    assert rp.get_continuation_type() == C

# Generated at 2022-06-24 08:12:01.334839
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    # Setup
    preserve_dict = {ord('a'): ord('a')}
    mapping = StringTranslatePseudoMapping(preserve_dict)
    expected = 1
    # Exercise
    actual = len(mapping)
    # Verify
    assert actual == expected

# Generated at 2022-06-24 08:12:05.858013
# Unit test for constructor of class RoughParser
def test_RoughParser():
    p = RoughParser("", 0)
    assert p.goodlines == [0, 0]
    assert p.continuation == C_NONE
    assert p.get_last_stmt_bracketing() is None
    p = RoughParser("\n", 0)
    assert p.goodlines == [0, 1]
    assert p.continuation == C_NONE
    assert p.get_last_stmt_bracketing() is None
    p = RoughParser("\n\n", 0)
    assert p.goodlines == [0, 2]
    assert p.continuation == C_NONE
    assert p.get_last_stmt_bracketing() is None


# Generated at 2022-06-24 08:12:17.790931
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    class DummyEditWin:
        def __init__(self):
            self.text = DummyText()

    class DummyText:
        def __init__(self):
            self.indentwidth = 8
            self.tabwidth = 8
            self.editwin = DummyEditWin()

        def index(self, index):
            return int(float(index))

        def get(self, startindex, stopindex):
            return "stringstring"


# Generated at 2022-06-24 08:12:27.707338
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from test.test_support import requires

    requires("gui")
    from test.test_support import requires

    requires("gui")
    import idlelib.EditorWindow
    import idlelib.textView

    try:
        tk = idlelib.TestSupport.tk
    except Exception:
        raise unittest.SkipTest("test requires Tkinter")
    root = tk.Tk()

# Generated at 2022-06-24 08:12:38.336135
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    assert RoughParser("a").get_continuation_type() == C_NONE
    assert RoughParser("a ").get_continuation_type() == C_NONE
    assert RoughParser("a\n").get_continuation_type() == C_NONE
    assert RoughParser("a\\\n").get_continuation_type() == C_BACKSLASH
    assert (
        RoughParser("a\\\n    b = \\").get_continuation_type() == C_BACKSLASH
    )
    assert RoughParser("a # \\").get_continuation_type() == C_NONE
    assert (
        RoughParser("a # \\").get_continuation_type() == C_NONE
    )
    assert RoughParser("a (b)").get_continuation_type() == C_NONE

# Generated at 2022-06-24 08:12:42.933139
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({ord('a'): ord('b')}, ord('c'))
    assert mapping.get(ord('a')) == ord('b')
    assert mapping.get(ord('b')) == ord('c')
    assert mapping.get(ord('b'), ord('d')) == ord('d')


# Generated at 2022-06-24 08:12:55.070607
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test_one(text, index, expected):
        hp = HyperParser(text, index)
        result = hp.get_expression()
        if result != expected:
            raise AssertionError(
                "get_expression failed for text=%r, index=%r. Expected %r, got %r"
                % (text, index, expected, result)
            )

    def test_all(text, *args):
        for index, expected in zip(args[::2], args[1::2]):
            test_one(text, index, expected)

    if 1:
        test_all("foo", "1.0", "", "1.1", "foo")
        test_all("foo(", "1.3", "", "1.2", "foo")

# Generated at 2022-06-24 08:13:08.204556
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    global test_num, failures
    test_num = test_num + 1
    failures = []

    def check(src, num_lines):
        print(f"\ntest #{test_num}")
        parser = RoughParser(src)
        got = parser.get_num_lines_in_stmt()
        print(f"src: {repr(src)}")
        print(f"got: {repr(got)}")
        print(f"num_lines: {repr(num_lines)}")
        if got == num_lines:
            print('ok')
        else:
            print('*** FAIL ***')
            failures.append(test_num)

    check('foo\\\nbar', 2)
    check('foo \\\nbar', 2)

# Generated at 2022-06-24 08:13:17.711287
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    rawtext = "abc#def\nghi\njkl\n"
    parser = RoughParser()
    parser.set_str(rawtext)
    bracketing = parser.get_last_stmt_bracketing()
    isopener = [
        i > 0 and bracketing[i][1] > bracketing[i - 1][1]
        for i in range(len(bracketing))
    ]

    hp = HyperParser('')

    # No bracket
    hp.rawtext = rawtext
    hp.indexbracket = -1
    hp.isopener = isopener
    hp.indexinrawtext = 0
    assert hp.is_in_string() == 0

    # In a middle of a comment
    hp.indexinrawtext = 3

# Generated at 2022-06-24 08:13:28.103333
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-24 08:13:32.582257
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    """Method __iter__ of class StringTranslatePseudoMapping"""
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    text.translate(mapping)
    return True



# Generated at 2022-06-24 08:13:39.428761
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest.mock as mock

    class MockText:
        def __init__(self):
            self.indent_width = 4
            self.tabwidth = 8
            self.index = mock.Mock(
                side_effect=lambda x: int(float(x))
            )  # support only integers as index
            self.get_side_effect = []

        def get(self, start, end):
            self.get_side_effect.append((start, end))
            return " \n"[::-1]  # We return this string backwards

        def __getitem__(self, key):
            return self.__dict__[key]

        def __setitem__(self, key, value):
            self.__dict__[key] = value

    text = MockText()

# Generated at 2022-06-24 08:13:45.607449
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    d = {ord('x'): ord('y')}
    mapping = StringTranslatePseudoMapping(d, ord('z'))
    assert mapping.get(ord('x')) == ord('y')
    assert mapping.get(ord('y')) == ord('z')



# Generated at 2022-06-24 08:13:52.093713
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from . import test_support
    from .edit import UndoDelegator

    class Text:
        def __init__(self):
            self.tk = None
            self.tag_add = self.tag_remove = self.tag_configure = self.tag_names = self.tag_ranges = self.tag_nextrange = self.tag_prevrange = self.rindex = self.index = self.bbox = self.yview = self.search = self.compare = self.focus = None
            self.get = self.get_selection_indices = lambda f, t: "contents between %r and %r" % (f, t)
            self.set_insert = self.get_insert = lambda : None
            self.indent_width = self.tabwidth = None
            self.bell = None
            self._

# Generated at 2022-06-24 08:14:00.025227
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'
test_StringTranslatePseudoMapping_get()



# Generated at 2022-06-24 08:14:08.661335
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-24 08:14:12.935503
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    d = {ord('a'): ord('b'), ord('c'): ord('d')}
    p = StringTranslatePseudoMapping(d, ord('x'))
    assert p.get(ord('a')) == ord('b')
    assert p.get(ord('c')) == ord('d')
    assert p.get(ord('e')) == ord('x')
    assert len(p) == 2
    assert list(iter(p)) == list(d)



# Generated at 2022-06-24 08:14:17.540802
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = ' \t\n\r'

    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}

    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))

    it = iter(mapping)
    assert type(it) == type(iter(preserve_dict))


# Generated at 2022-06-24 08:14:24.516932
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    test_cases = {
        "def test(a):": 3,
        "if a:": 2,
        "def test():": 3,
        "for foo in bar([]):": 18,
        "with open('foo'):": 19,
    }
    for s in test_cases:
        r = RoughParser(s, len(s))
        assert r.get_last_open_bracket_pos() == test_cases[s]



# Generated at 2022-06-24 08:14:37.788233
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    # pylint: disable=redefined-outer-name
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements

    def do(ss, ws=8, tw=8):
        # RoughParser.__init__(self, indent_width, tabwidth)
        parser = RoughParser(ws, tw)  # @ReservedAssignment
        parser.set_str(ss)
        return parser

    def show(parser):
        # pylint: disable=redefined-builtin
        print("line   0:", repr(parser.str))
        # goodlines is one-based, so goodlines[i] is the first line
        # of the corresponding stmt

# Generated at 2022-06-24 08:14:49.999582
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=undefined-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    # pylint: disable=too-many-locals

    str = """lala

a
b
c

if 0:
    a
    b
    c

if 0:
    a
    b
    c

if 0:
    a
    b
    c


if 0:
    a
    b
    c
    d
    e

if 0:
    a
    b
    c
    d
    e

if 0:
    if 0:
        if 0:
            a
            b
            c
            d
            e
"""
    s = RoughParser(str, 0)


# Generated at 2022-06-24 08:14:55.468082
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    """Unit test for method __getitem__ of class StringTranslatePseudoMapping"""
    def _test(test_case):
        """
        Local helper function to run a specific test case.

        Args:
            test_case (dict): The test case parameters as a dict

        Returns:
            void: None. Unit test failure will raise an exception
        """
        name = test_case["name"]
        text = test_case["input"]["text"]
        preserve_dict = test_case["input"]["preserve_dict"]
        default_value = test_case["input"]["default_value"]
        expected = test_case["expected"]
        description = test_case.get("description", None)
        if description:
            print("Description:  ", description)


# Generated at 2022-06-24 08:15:03.962488
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # pylint: disable=redefined-builtin
    # pylint: disable=invalid-name
    def t(s, i):
        return (s, RoughParser(s).get_continuation_type(), i)

    def t1(s, i1):
        return [t(x, y) for x, y in zip(s.split("|"), i1)]

    # This test tests all the code that used to be in study1.
    # It doesn't test study2.
    goodlines = RoughParser("").goodlines

    assert t(
        "x = 1", None
    ) == ("x = 1", None, [])
    # multiline strings

# Generated at 2022-06-24 08:15:13.483527
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    print("Running test: test_StringTranslatePseudoMapping___len__")

    mapping = StringTranslatePseudoMapping(
        {ord("b"): ord("b")},
        ord("x")
    )
    assert len(mapping) == 1
    assert mapping.get("a", ord("x")) == ord("x")
    assert mapping.get("b", ord("x")) == ord("b")

    mapping = StringTranslatePseudoMapping(
        {ord("a"): ord("a"), ord("b"): ord("b")},
        ord("x")
    )
    assert len(mapping) == 2
    assert mapping.get("a", ord("x")) == ord("a")
    assert mapping.get("b", ord("x")) == ord("b")
