

# Generated at 2022-06-24 08:05:22.591156
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    raw = """

x = {
y = 1 + 1
}
"""
    rp = RoughParser(raw)
    assert rp.stmt_start == 6
    assert rp.stmt_end == 51

    # This code is tested implicitly from _scan_block()
    assert _closere(raw, 6) is not None
    assert rp.is_block_closer() is True
    assert rp.is_block_closer() is True
    rp = RoughParser("x = y")
    assert rp.is_block_closer() is False
    assert rp.is_block_closer() is False
    rp = RoughParser("class x: pass")
    assert rp.is_block_closer() is True
    assert rp.is_block_closer() is True
    r

# Generated at 2022-06-24 08:05:31.232405
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():

    def assert_invalid(text):
        assert RoughParser(text).get_base_indent_string() == ""

    def assert_text_indent(text, expected):
        assert RoughParser(text).get_base_indent_string() == expected

    assert_text_indent("", "")
    assert_text_indent(" ", " ")
    assert_text_indent("  ", "  ")
    assert_text_indent("   ", "   ")
    assert_text_indent("\t", "\t")
    assert_text_indent("\t\t", "\t\t")
    assert_text_indent("\t \t", "\t \t")
    assert_invalid("\t  \t")
    assert_invalid(" \t ")
    assert_text_

# Generated at 2022-06-24 08:05:40.483304
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from unittest.mock import Mock, sentinel

    class MockText(Mock):
        @staticmethod
        def index(arg):
            if arg == sentinel.stopatindex:
                return "xxx"
            if arg.startswith(sentinel.stopatindex):
                return arg[len(sentinel.stopatindex) :]

    MockText.get = Mock(return_value=sentinel.str)

    def check(str_, index, raw_result):
        # str_ is the contents of the text widget; index is a Tkinter index;
        # raw_result is the result (or None) of get_surrounding_brackets
        # without the stopatindex argument.
        text = MockText(sentinel.indent_width, sentinel.tabwidth)

# Generated at 2022-06-24 08:05:46.777540
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def is_in_code_test(text, index):
        return HyperParser(text, index).is_in_code()

    def test_case(text, index, expected):
        if is_in_code_test(text, index) != expected:
            raise AssertionError("FAILED at %s.eval(%s): %s expected but %s found" % (
                repr(text), repr(index), repr(expected), repr(is_in_code_test(text, index))))

    test_case("print(hello)", "insert", True)
    test_case("print('hello')", "insert", False)
    test_case("print(2 + 3)", "insert", True)
    test_case("print('hello')", "1.0", False)

# Generated at 2022-06-24 08:05:59.885284
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser("class x:\n    pass\n")
    assert rp.is_block_opener()
    rp = RoughParser("class x:     pass\n")
    assert rp.is_block_opener()
    rp = RoughParser("class x  (  Yo):     pass\n")
    assert rp.is_block_opener()
    rp = RoughParser("class x(Yo)  : pass\n")
    assert rp.is_block_opener()
    rp = RoughParser("x = 3\n")
    assert not rp.is_block_opener()
    rp = RoughParser("x = 3  \n")
    assert not rp.is_block_opener()
    rp = RoughParser("x 3  \n")
    assert not r

# Generated at 2022-06-24 08:06:07.760384
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    h = HyperParser("I'm not in str1 or str2", "1.end")
    log = ""
    for index in ["1.0", "1.4", "1.5", "1.8", "1.9", "1.11", "1.12", "3.0", "3.7"]:
        h.set_index(index)
        log += "index %s, rawtext=%s, bracketing=%s, isopener=%s, text=%s\n" % (
            index,
            h.rawtext,
            h.bracketing,
            h.isopener,
            h.text,
        )

# Generated at 2022-06-24 08:06:17.832770
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-24 08:06:25.624162
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping_dict = {ord('a'): ord('b'), ord('b'): ord('c')}
    mapping = StringTranslatePseudoMapping(mapping_dict, ord('d'))
    assert mapping.get(ord('a')) == ord('b')
    assert mapping.get(ord('b')) == ord('c')
    assert mapping.get(ord('c')) == ord('d')
    assert mapping.get(ord('d')) == ord('d')



# Generated at 2022-06-24 08:06:34.977105
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase, main

    class TestHP(TestCase):
        def test_set_index(self):
            p = HyperParser(Tkinter.Text, "1.0")
            p.set_index("1.0")
            assert repr(p.indexinrawtext) == "0"
            assert p.indexbracket == 0
            p.set_index("1.1")
            assert repr(p.indexinrawtext) == "1"
            assert p.indexbracket == 1
            p.set_index("1.2")
            assert repr(p.indexinrawtext) == "2"
            assert p.indexbracket == 2
            p.set_index("1.3")
            assert repr(p.indexinrawtext) == "3"

# Generated at 2022-06-24 08:06:42.144894
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    # pylint: disable=redefined-builtin
    from io import StringIO

    rp = RoughParser("", 0, 0)

    def t(x, expected):
        rp.set_str(x, "<test string>")
        actual = rp.get_num_lines_in_stmt()
        assert actual == expected, "in <%s>, expected %r, got %r" % (x, expected, actual)

    t("", 0)
    t("\n", 0)
    t("x=3\n\ny=3", 2)
    t("x=3\n\ny=3 #comment\n", 1)
    t("x=3\n\ny=3 #comment\n\n", 2)
    t("x=3\n\ny=3\\", 1)
    t

# Generated at 2022-06-24 08:06:46.879017
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    p = compiling.RoughParser()
    p.set_lo(0)
    assert p.lo == 0
    p.set_lo(2)
    assert p.lo == 2
    p = compiling.RoughParser()
    p.set_lo(7)
    assert p.lo == 7


# Generated at 2022-06-24 08:06:58.285822
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    """Unit test for method get_last_stmt_bracketing of class RoughParser.

    It is assumed that the code associated to this file is
    analyzed by pylint, so it complains if no docstring is
    provided for this function or if the docstring does not
    start with a short description followed by blank line(s).
    """
    # following definition is for pylint's benefit only
    # pylint: disable=unused-argument
    def f(s):
        """Just for testing RoughParser.get_last_stmt_bracketing."""
        return s

    def test(s):
        """Test RoughParser class with string s."""
        parser = RoughParser(s, indent_width=4, tabwidth=8)
        return parser.get_last_stmt_bracketing()

    assert test("")

# Generated at 2022-06-24 08:07:04.934604
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # pylint: disable=redefined-outer-name,protected-access
    """Demonstrate set_lo"""
    parser = RoughParser(indent_width=4, tabwidth=8, num_spaces_for_tab=1)
    parser.set_lo("""\
hello
whitespace = [
    ' ' * num_spaces_for_tab,
    ]
    """)
    p = parser._parser_stack[-1]
    assert p.goodlines == [0, 3]
    assert p.continuation == C_BRACKET
    assert p.str == (
        "whitespace = [\n"
        "    ' ' * num_spaces_for_tab,\n"
        "    ]"
    )

# Generated at 2022-06-24 08:07:09.118030
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-24 08:07:19.643663
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    assert RoughParser("    ").get_last_open_bracket_pos() is None
    assert RoughParser("foo").get_last_open_bracket_pos() is None
    assert RoughParser("foo()").get_last_open_bracket_pos() == 3
    assert RoughParser("foo(").get_last_open_bracket_pos() == 3
    assert RoughParser("foo()").get_last_open_bracket_pos() == 3
    assert RoughParser("foo(bar").get_last_open_bracket_pos() == 3
    assert RoughParser("foo(bar)").get_last_open_bracket_pos() == 3
    assert RoughParser("foo(bar)[blaz]").get_last_open_bracket_pos() == 9
    assert RoughParser("foo(bar)[blaz](").get_

# Generated at 2022-06-24 08:07:21.992217
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser('  \n')
    rp.set_lo(3)
    assert rp.str == '\n'
    assert rp.goodlines == [1, 2]


# Generated at 2022-06-24 08:07:33.665120
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-24 08:07:42.228936
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    print('Testing function get_last_open_bracket_pos  of class RoughParser')

# Generated at 2022-06-24 08:07:53.019833
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    from .tokenize import generate_tokens
    from .tokenize import Untokenizer

    def check(source, expected):
        # pylint: disable=no-member
        tokens, _ = generate_tokens(source.readline)
        untokenize = Untokenizer()
        untokenize.tokens = tokens
        actual = RoughParser(untokenize.untokenize()).get_continuation_type()
        source.seek(0)
        assert actual == expected

    import io
    buf = io.BytesIO

    c = C_NONE
    cb = C_BRACKET
    cbfls = C_BRACKET_FIRST_LINE | C_STRING_FIRST_LINE
    cbs = C_BRACKET | C_STRING_FIRST_LINE
    cbsnl

# Generated at 2022-06-24 08:08:03.792005
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    def test_equal(s, expected):
        p = RoughParser(s, indentsize=4)
        assert p.get_num_lines_in_stmt() == expected
    test_equal("x=1+4\n", 2)
    test_equal("x=1+4", 1)
    test_equal("x=1+4\\\n", 1)
    test_equal("x=1+4\\\n+\\\n", 1)
    test_equal("x=1+4\\\n+1\\\n+1\\\n+1\\\n+1\\\n", 5)
    test_equal("x=1+4\\\n+1\\\n+1\\\n+1\\\n+1\\\n+1", 1)

# Generated at 2022-06-24 08:08:12.194790
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-24 08:08:21.484827
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def test_RoughParser_get_base_indent_string(self):
        rough_parser = RoughParser(text, 1, self.tabwidth)
        self.assertEqual(rough_parser.get_base_indent_string(),
                         ' ' * self.indent_width)

    test_RoughParser_get_base_indent_string(self)
    test_RoughParser_get_base_indent_string(self)



# Generated at 2022-06-24 08:08:27.252365
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-24 08:08:38.837960
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    res = RoughParser("").get_last_stmt_bracketing()
    assert res is None, res

    res = RoughParser("#").get_last_stmt_bracketing()
    assert res is None, res

    res = RoughParser("\n").get_last_stmt_bracketing()
    assert res is None, res

    res = RoughParser("\n\n").get_last_stmt_bracketing()
    assert res is None, res

    res = RoughParser("\n\n\n").get_last_stmt_bracketing()
    assert res is None, res

    res = RoughParser("a=").get_last_stmt_bracketing()
    assert res == ((0, 0), (2, 0)), res

    res = RoughParser("a=1+1").get_

# Generated at 2022-06-24 08:08:47.499829
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    c1 = RoughParser("for x in range(100): print x + 1\\\n"
                     "    + 2\\\n"
                     "    + 3")
    indent_1 = c1.compute_backslash_indent()
    assert indent_1 == 2, "bug in compute_backslash_indent()"

    c2 = RoughParser("class SomeClass(object):\n"
                     "    if test:\n"
                     "        return 1\n"
                     "    else:\n"
                     "        return 2\\\n"
                     "        + 2\\\n"
                     "        + 3")
    indent_2 = c2.compute_backslash_indent()
    assert indent_2 == 8, "failed to increase indent for a backslash continuation"


# Generated at 2022-06-24 08:08:59.914773
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # Creates a text which is a single line, with all the possible
    # combinations of the built-in delimiters and comments.
    # index = column = 5
    # delimiters and comments are always in pairs, at the same column.
    # the following is a list of the possible pairs, where the content
    # of column 5 is either the first or the second element of the pair.
    # The text is created by adding pairs to the previous pairs, and
    # with the pairs in the following order.
    pairs = [("", ""), ("#", "#")]
    for c in "([{'\"":
        newpairs = []
        for l, r in pairs:
            newpairs.append((l + c, c + r))
        pairs = newpairs
    rawtext = ""

# Generated at 2022-06-24 08:09:05.334594
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    assert len(mapping) == 4



# Generated at 2022-06-24 08:09:09.307307
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    # replace everything except whitespace with 'x'
    non_defaults = {}
    non_defaults[ord(" ")] = ord(" ")
    non_defaults[ord("\t")] = ord("\t")
    non_defaults[ord("\n")] = ord("\n")
    non_defaults[ord("\r")] = ord("\r")
    default = ord("x")
    mapping = StringTranslatePseudoMapping(non_defaults, default)
    # text with whitespace
    text = "a + b\tc\nd"
    expected = "x x x\tx\nx"
    actual = text.translate(mapping)
    assert actual == expected, text



# Generated at 2022-06-24 08:09:18.017928
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    """Test __getitem__ method of class StringTranslatePseudoMapping"""
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"



# Generated at 2022-06-24 08:09:27.414478
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    # pylint: disable=anomalous-backslash-in-string,eval-used
    # pylint: disable=star-args,unused-variable
    # pylint: disable=redefined-outer-name,singleton-comparison
    # pylint: disable=bad-classmethod-argument,unused-import
    # pylint: disable=bare-except,no-else-return
    # pylint: disable=bad-whitespace,line-too-long
    tracer = []

# Generated at 2022-06-24 08:09:30.031882
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    mapping = StringTranslatePseudoMapping({ord('A'): ord('B')}, ord('x'))
    assert mapping[ord('A')] == ord('B')
    assert mapping[ord('C')] == ord('x')
    assert mapping.get(ord('C'), ord('y')) == ord('x')



# Generated at 2022-06-24 08:09:39.657144
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({}, 0)
    assert mapping.get(True, default=0) is 0
    mapping = StringTranslatePseudoMapping({True: True, False: False}, None)
    assert mapping.get(True, default=None) is True
    assert mapping.get(False, default=None) is False
    assert mapping.get(None, default=None) is None
    mapping = StringTranslatePseudoMapping({True: True, False: False}, -1)
    assert mapping.get(True, default=-1) is True
    assert mapping.get(False, default=-1) is False
    assert mapping.get(None, default=-1) is -1


# Generated at 2022-06-24 08:09:45.482011
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    for s in [
        "if x: pass\nif y: pass",
        "if x: pass # comment",
        "if x: pass\n# comment\nif y: pass",
    ]:
        assert RoughParser(s).get_num_lines_in_stmt() == 2

# Generated at 2022-06-24 08:09:52.597338
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import re

    tests = ["#comment", '"string"', "1", "[1]", "(1)", "{1}", "'string'", "20#comment"]

    results = [0, 0, 1, 1, 1, 1, 0, 1]

    for i in range(len(tests)):
        parser = HyperParser(Text(tests[i]), "2.0")
        if parser.is_in_code() != results[i]:
            print(parser.rawtext)
            print(parser.bracketing)
            print(parser.isopener)
            print(parser.indexbracket)
            print(parser.indexinrawtext)
            raise AssertionError



# Generated at 2022-06-24 08:10:02.356789
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # The backslash continuation form is a little cumbersome, so
    # we don't test it with a string literal; it needs to be in
    # a real file.
    fn = "dummy.py"

    # Case 1:  x = 1 + \
    #              2
    # We expect 1 not 2.
    src = "x = 1 + \\ \n" " 2"
    rp = RoughParser(fn, src, 0)
    assert rp.compute_backslash_indent() == 1

    # Case 2:
    # x = [
    #     1 + \
    #     2
    #     ]
    # We expect 4 not 5.
    src = "x = [\n" "    1 + \\ \n" "    2\n" "    ]"

# Generated at 2022-06-24 08:10:05.329856
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    lines = """\
    #comment
    a = f(
    #comment
    1,
    #comment
    2
    )
    """.splitlines(True)
    rp = RoughParser("".join(lines), 0)
    assert rp.get_num_lines_in_stmt() == 5
    assert rp.get_num_lines_in_stmt() == 5 # should be idempotent


# Generated at 2022-06-24 08:10:15.345636
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():  # noqa
    """StringTranslatePseudoMapping.__getitem__(*args, **kwargs)"""
    non_defaults = {ord("a"): ord("A"), ord("b"): ord("B")}
    default_value = ord("?")
    mapping = StringTranslatePseudoMapping(non_defaults, default_value)
    assert mapping[ord("a")] == ord("A")
    assert mapping[ord("b")] == ord("B")
    assert mapping[ord("c")] == ord("?")
    assert mapping.get(ord("c")) == ord("?")
    with pytest.raises(KeyError):
        mapping[ord("c")]



# Generated at 2022-06-24 08:10:23.565773
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    parse = RoughParser().get_num_lines_in_stmt
    assert parse("") == 1
    assert parse("\n") == 2
    assert parse("\\\n") == 2
    assert parse("a\n") == 2
    assert parse("a\\\n") == 2
    assert parse("a\\\nb\\\n") == 4
    assert parse("a\\\n\n") == 3
    assert parse("a\\\n\n\n") == 4
    assert parse("a\\\nb\\\n\n") == 4
    assert parse("a\\\n\nb\\\n") == 4
    assert parse("a\\\n\nb\\\n\n") == 5
    assert parse("a\\\n\n\nb\\\n") == 5

# Generated at 2022-06-24 08:10:30.734674
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    test_dict = {"a": "b", "c": "d"}
    mapping = StringTranslatePseudoMapping(test_dict, "e")
    assert mapping.get("a") == "b"
    assert mapping.get("c") == "d"
    assert mapping.get("e") == "e"  # default value
    assert mapping.get("f", "g") == "g"  # given default value



# Generated at 2022-06-24 08:10:44.241121
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from idlelib.EditorWindow import EditorWindow
    root = Tk()
    text = Text(root)
    text.pack()
    text.insert('1.0', 'a')
    text.mark_set('insert', 'end')

    # Test is_in_code by replacing the original HyperParser.is_in_code
    # with a method which raises an exception if 'a' is not in code
    # after each insert.
    #
    # After each insert, _test_is_in_code is called to test the
    # position of the new character.
    def _test_is_in_code(event):
        text.edit_separator()
        hp = HyperParser(text, text.index('insert'))
        assert hp.is_in_code()
        assert not hp.is_in_string()
       

# Generated at 2022-06-24 08:10:51.522595
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    for s, result in ["if 1:", "if 1: pass", "if 1:", "if 1:  \n  pass", "if 1:\n  pass"]:
        rp = RoughParser(s)
        if result:
            assert rp.is_block_opener()
        else:
            assert not rp.is_block_opener()


# Generated at 2022-06-24 08:11:01.154108
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    parser = RoughParser(
        "def foo():\n    if True:\n    \n        if True:\n            return False\n    return True"
    )
    assert parser.get_base_indent_string() == "    "

    parser = RoughParser(
        "def foo():\n    if True:\n        pass\n        if True:\n            return False\n    return True"
    )
    assert parser.get_base_indent_string() == "    "

    parser = RoughParser(
        "def foo():\n    if True:\n        pass\n        if True:\n            return False\n        return True"
    )
    assert parser.get_base_indent_string() == "            "

    parser = RoughParser("")
    assert parser.get_base_indent_string() == ""

# Generated at 2022-06-24 08:11:08.205668
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    from pygments.token import Token
    from pygments.lexers import PythonLexer

    test_text = """if True:
    pass
"""
    lexer = PythonLexer()
    assert RoughParser(test_text, lexer).is_block_opener()
    assert not RoughParser("", lexer).is_block_opener()
    assert not RoughParser("pass\n", lexer).is_block_opener()
    assert not RoughParser("pass", lexer).is_block_opener()

    lexer.add_filter("trim")
    assert RoughParser("", lexer).is_block_opener()
    assert not RoughParser("pass\n", lexer).is_block_opener()
    assert RoughParser("pass", lexer).is_block_opener()

    toy_lexer = PythonLex

# Generated at 2022-06-24 08:11:15.148701
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    assert RoughParser("def a:").is_block_opener()
    assert RoughParser("if a:").is_block_opener()
    assert RoughParser("try:").is_block_opener()
    assert RoughParser("while a:").is_block_opener()
    assert not RoughParser("pass").is_block_opener()
    assert not RoughParser("def a():").is_block_opener()
    assert not RoughParser("a = b").is_block_opener()



# Generated at 2022-06-24 08:11:19.036264
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    test_cases = [
        ('if True:\n' + 4*' ' + '[\n' + 8*' ' + '1\n' + 4*' ' + ']', 12),
        ('[\n1\n]', 0),
        ('[\n', 0),
        ('\n]', -1),
        ('', -1),
    ]
    for test_case in test_cases:
        text, expected = test_case
        parser = RoughParser(text)
        assert parser.get_last_open_bracket_pos() == expected



# Generated at 2022-06-24 08:11:31.519174
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    rough_parser = RoughParser("   abc")
    assert rough_parser.find_good_parse_start(0) == 0
    assert rough_parser.find_good_parse_start(1) == 0
    assert rough_parser.find_good_parse_start(2) == 0
    assert rough_parser.find_good_parse_start(3) == 0
    assert rough_parser.find_good_parse_start(4) == 0
    assert rough_parser.find_good_parse_start(5) == 0
    assert rough_parser.find_good_parse_start(6) == 0
    assert rough_parser.find_good_parse_start(7) == 0
    assert rough_parser.find_good_parse_start(8) == 0


# Generated at 2022-06-24 08:11:36.794422
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    tp = HyperParser(
        text=tk.Text(None, autoseparators=False, width=80, undo=True),
        index="insert",
    )
    tp.text.insert("end", "def foo()\n")
    for i in range(1, 11):
        tp.set_index("%d.%d" % (i, i))
        assert tp.is_in_code(), "tp.is_in_code() -> False, expected True"
    tp.set_index("1.0")
    assert not tp.is_in_code(), "tp.is_in_code() -> True, expected False"
    tp.text.insert("end", "   ")

# Generated at 2022-06-24 08:11:46.436109
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def get_expression(s, index):
        h = HyperParser(Tk.Text(None, "2i"), index)
        h.rawtext = s
        h.indexinrawtext = len(s) - Tk.Text(None, "2i").index(index)
        return h.get_expression()

    assert get_expression("", "1.0") == ""
    assert get_expression("", "1.end") == ""
    assert get_expression("x", "1.0") == "x"
    assert get_expression("\n", "2.0") == ""
    assert get_expression("x;", "1.1") == ""
    assert get_expression("x; ", "1.2") == ""
    assert get_expression("x; ", "1.end") == ""

# Generated at 2022-06-24 08:11:47.856382
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    pass



# Generated at 2022-06-24 08:11:51.064571
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({}, "default")
    # Test if the pseudo mapping returns the correct value if a key is
    # found in the mapping
    assert mapping.get(0) == "default",\
        "Key found: Pseudo mapping did not return correct value"
    # Test if the pseudo mapping returns the correct default value if a key
    # is not found in the mapping
    assert mapping.get(42, "not default") == "not default",\
        "Key not found: Pseudo mapping did not return correct default value"

# Generated at 2022-06-24 08:11:54.017214
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    d = {3:4}
    m = StringTranslatePseudoMapping(d, 0)
    assert m[3] == 4
    assert m[7] == 0


# Generated at 2022-06-24 08:11:56.352080
# Unit test for method set_str of class RoughParser

# Generated at 2022-06-24 08:11:58.350641
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    sut = StringTranslatePseudoMapping({1: 2}, 3)
    assert sut[0] == 3
    assert sut[1] == 2



# Generated at 2022-06-24 08:12:11.952651
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    from unittest import TestCase, main

    class Test(TestCase):
        def test_get_expression(self):
            import tkinter

            text = tkinter.Text()
            text.insert("insert", "x.y.z.w")

            def check(index, res):
                hp = HyperParser(text, index)
                self.assertEqual(hp.get_expression(), res)

            for i in range(0, 9):
                check(str(i), "x.y.z.w"[:i])

            text.insert("insert", " + 1")
            check("8.end", "x.y.z.w")

        def test_get_expression_at_end(self):
            import tkinter

            text = tkinter.Text()

# Generated at 2022-06-24 08:12:20.505915
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=missing-function-docstring
    # pylint: disable=redefined-outer-name

    class TestCase:
        def __init__(self, text, continuation, tabsize, expected_results):
            self.text = text
            self.continuation = continuation
            self.tabsize = tabsize
            self.expected_results = expected_results


# Generated at 2022-06-24 08:12:29.124031
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-24 08:12:37.387279
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    assert RoughParser('').get_base_indent_string() == ''
    assert RoughParser('def foo():\npass').get_base_indent_string() == '    '
    assert RoughParser('def foo():\n  pass\n').get_base_indent_string() == '    '
    assert RoughParser('if True:\n    pass\nelse:\n    pass').get_base_indent_string() == '        '
    assert RoughParser('if True:\n    if False:\n        pass\nelse:\n    pass').get_base_indent_string() == '            '


# Generated at 2022-06-24 08:12:43.956931
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    if not __debug__:
        return
    # Test string with a statement containing both brackets and strings
    # This test case was found by the fuzzer and previously caused a bug
    # in RoughParser.get_last_stmt_bracketing()
    str = "foo('[')"
    p = RoughParser(str, None)
    assert p.get_last_stmt_bracketing() == ((0, 0), (4, 1), (6, 0))



# Generated at 2022-06-24 08:12:46.968513
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-24 08:12:55.890078
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def test(code, mustclose, expected):
        text = tk.Text()
        text.insert("insert", code)
        text.mark_set("insert", "1.0")
        parser = HyperParser(text, "insert")
        res = parser.get_surrounding_brackets(mustclose=mustclose)
        if res is None:
            res = ()
        assert res == expected, (
            "Wrong result for code %r, mustclose %r: %r != %r"
            % (code, mustclose, res, expected)
        )

    test("ab[c]", False, ("1.2", "1.4"))
    test("ab[c", True, None)
    test("ab]c", True, None)

# Generated at 2022-06-24 08:13:05.430738
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    m = StringTranslatePseudoMapping({}, 42)
    assert len(list(m)) == 0
    assert list(m) == []

    m = StringTranslatePseudoMapping({0: 1}, 42)
    assert len(list(m)) == 1
    assert list(m) == [0]

    m = StringTranslatePseudoMapping({0: 1, 2: 3}, 42)
    assert len(list(m)) == 2
    # The order in which the key/value pairs are returned is unspecified
    assert list(m) in [[0, 2], [2, 0]]


# Generated at 2022-06-24 08:13:18.279894
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    r = RoughParser()

# Generated at 2022-06-24 08:13:28.707510
# Unit test for constructor of class HyperParser
def test_HyperParser():
    global test_text
    test_text = root.text
    test_text.insert("1.0", test_text_str)
    test_text.tag_add("sel", "sel.first", "sel.last")
    test_text.tag_configure("sel", background="red")
    mark = test_text.index("insert")
    t = HyperParser(test_text, mark)
    for i in range(len(t.rawtext)):
        if t.rawtext[i] != test_text_str[i]:
            print("i=%d t.rawtext[i]=%s test_text_str[i]=%s" % (i, t.rawtext[i], test_text_str[i]))
    print(t.is_in_code())

# Generated at 2022-06-24 08:13:31.554946
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    obj = StringTranslatePseudoMapping({1:2, 2:3}, 4)
    assert obj[1] == 2
    raises(KeyError, obj.__getitem__, 3)


# Generated at 2022-06-24 08:13:44.153946
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import main

    class TestConfig(Config):
        indentwidth = 8
        tabwidth = 8
        endsep = "\n"
        usetabs = 0

    class TestText(Text):
        def __init__(self, *args):
            Text.__init__(self, TestConfig(*args))

    class Test(unittest.TestCase):
        def __init__(self, text, index, expected):
            unittest.TestCase.__init__(self)
            self.text = text
            self.index = index
            self.expected = expected

        def runTest(self):
            hp = HyperParser(self.text, self.index)
            self.assertEqual(hp.get_expression(), self.expected)

    # Test get_expression

# Generated at 2022-06-24 08:13:52.802841
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    parser = RoughParser("")
    assert not parser.is_block_opener()
    parser = RoughParser("\n")
    assert not parser.is_block_opener()
    parser = RoughParser("\n")
    assert not parser.is_block_opener()
    parser = RoughParser("\n:")
    assert parser.is_block_opener()
    parser = RoughParser("\n")
    assert not parser.is_block_opener()
    parser = RoughParser("\n")
    assert not parser.is_block_opener()
    parser = RoughParser("\n")
    assert not parser.is_block_opener()
    parser = RoughParser("\n")
    assert not parser.is_block_opener()
    parser = RoughParser("\n")
    assert not parser.is_

# Generated at 2022-06-24 08:14:03.929051
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    parser = RoughParser()
    parser.set_str("a = 12")
    assert parser.str == "a = 12"
    parser.set_str("a =\n  12")
    assert parser.str == "a = 12"
    parser.set_str('a = "12"')
    assert parser.str == "a = 12"
    parser.set_str("a = \\\n   12")
    assert parser.str == "a = 12"
    parser.set_str("if 1:\n    pass\nelif 2:\n    pass\nelse:\n    pass")
    assert parser.str == "if 1: pass elif 2: pass else: pass"


# Generated at 2022-06-24 08:14:15.475756
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    from lib2to3.fixes.fix_print import _3to2_operators

    _3to2_operators = _3to2_operators
    # TODO: should be moved to py3k.

# Generated at 2022-06-24 08:14:26.183084
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class HyperParserTest(unittest.TestCase):
        def test_basic(self):
            h = HyperParser("(<first-line>\n<second-line>\n<third-line>)", "2.0")
            self.assertEqual(h.get_surrounding_brackets(), (0, "4.1"))
            self.assertEqual(h.get_surrounding_brackets(mustclose=True), None)

            h = HyperParser("(<first-line>\n<second-line>\n<third-line>)", "3.0")
            self.assertEqual(h.get_surrounding_brackets(), (0, "4.1"))

# Generated at 2022-06-24 08:14:38.336504
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser('  True:')
    assert rp.is_block_opener() == True

    rp = RoughParser('  if True:')
    assert rp.is_block_opener() == True

    rp = RoughParser('  False:')
    assert rp.is_block_opener() == True

    rp = RoughParser('  False:')
    assert rp.is_block_opener() == True

    rp = RoughParser('  False:')
    assert rp.is_block_opener() == True

    rp = RoughParser('  a = ')
    assert rp.is_block_opener() == False

    rp = RoughParser('  a = ')
    assert rp.is_block_opener() == False


# Generated at 2022-06-24 08:14:46.422179
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    class DictLike(Mapping):
        def __init__(self, d):
            self.d = d
        def __getitem__(self, key):
            return self.d[key]
        def __len__(self):
            return len(self.d)
        def __iter__(self):
            return iter(self.d)

    t = StringTranslatePseudoMapping(DictLike({'a': 12}), 99)
    assert t.get('a') == 12
    assert t.get('b') == 99
    assert t.get('b', 98) == 98



# Generated at 2022-06-24 08:14:53.439181
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # test that the functions returns an expression or nothing

    def do_test(text, index, expected_expr):
        hp = HyperParser(text, index)
        expr = hp.get_expression()
        if expr != expected_expr:
            raise Exception("get_expression(%r, %s) returned %s, not %s" % (text, index, expr, expected_expr))

    # test a simple case
    text = "    xyz   "
    index = "insert"
    do_test(text, index, "xyz")

    # test a case after a dot
    text = "    xyz.abc"
    index = "insert"
    do_test(text, index, "abc")

    # test a case with an extra dot
    text = "    xyz.abc."
    index = "insert"
   

# Generated at 2022-06-24 08:14:55.205697
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({}, 0)
    assert mapping.get(1) == 0



# Generated at 2022-06-24 08:14:58.517240
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    rp = RoughParser("{'a': [1, (2, 3), {'bar': 'baz'}])}")
    assert rp.get_last_open_bracket_pos() == 28



# Generated at 2022-06-24 08:15:00.382445
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    for x in range(4):
        parser = RoughParser()

# Generated at 2022-06-24 08:15:05.438387
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    text = """
if foo:
    a = 1
elif bar:
    a = 2
    if bar2:
        a = 3
    else:
        a = 4
else:
    a = 5

while True:
    pass

for i in list:
    pass

"""
    for line in text.split("\n"):
        if not line:
            continue
        p = RoughParser(line)
        if line.lstrip().startswith("else"):
            assert not p.is_block_opener()
        else:
            assert p.is_block_opener()


# Generated at 2022-06-24 08:15:14.711149
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start(): # pylint: disable=missing-docstring
    for cls in _parseable_function_classes():
        if cls.is_parseable:
            # Class is ready to test
            break
    else:
        unittest.skipTest('No parseable class found')
    function_name = cls.function_name
    function_names = cls.function_names
    with cls.open() as function_file:
        lines = function_file.readlines()
    parser = RoughParser(lines)
    # First line
    print("* First line")
    print("-   find_good_parse_start(%u)" % 0)
    actual = parser.find_good_parse_start(0)
    expected = 0