

# Generated at 2022-06-24 08:05:24.808487
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rp = RoughParser(
        "def f():\n"
        "  return (\n"
        "somecode\n"
        "somecode2\n"
        "  )",
        4)
    assert rp.compute_backslash_indent() == 5
    rp = RoughParser(
        "def f():\n"
        "  return (\\\n"
        "somecode\n"
        "somecode2\n"
        "  )",
        4)
    assert rp.compute_backslash_indent() == 5


# Generated at 2022-06-24 08:05:32.593265
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    from lib2to3 import pytree as PT
    from lib2to3.pgen2.token import INDENT
    from lib2to3.pgen2.parse import ParseError
    from lib2to3.pgen2 import driver
    from lib2to3.pgen2.convert import pytree_convert
    from lib2to3.pytree import Leaf, Node
    from lib2to3.pygram import python_symbols as syms

    def parse(code):
        try:
            d = driver.Driver(lexer=driver.parse_tokens)
            tree = d.parse_string(code)
        except ParseError:
            tree = None
            print("Failed to parse:")
            print(code)
        return tree


# Generated at 2022-06-24 08:05:41.402270
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    from pyflakes.test.harness import TestCase
    from pyflakes.test.test_pyflakes import skipIf
    from pyflakes.test.test_pyflakes import skipUnless

    class RoughParserTestCase(TestCase):

        def test_get_continuation_type(self):
            from pyflakes.checker import C_BACKSLASH, C_STRING_FIRST_LINE, C_STRING_NEXT_LINES


# Generated at 2022-06-24 08:05:52.997813
# Unit test for constructor of class HyperParser
def test_HyperParser():
    s = """
    def f(x):
        print(x)
    class C:
        def m(self):
            print(self)
    x = 2
    """
    parser = HyperParser(s, "1.0")
    def check(index, expected):
        parser.set_index(index)
        actual = parser.get_expression()
        if actual != expected:
            raise RuntimeError(
                "HyperParser didn't recognize %s at %s; expected %s got %s"
                % (s[index], index, expected, actual)
            )
    check("1.4", "f")
    check("2.4", "x")
    check("1.6", "")
    check("4.4", "C")
    check("5.4", "self")

# Generated at 2022-06-24 08:06:03.913736
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    x = RoughParser("[\n   1,\n   foo(),\n   bar=[\n      1,\n      2,\n   ]\n]", indent_width=3, tabwidth=8)
    assert x.compute_bracket_indent() == 3
    x = RoughParser("[1,\n]", indent_width=3, tabwidth=8)
    assert x.compute_bracket_indent() == 3
    x = RoughParser("[", indent_width=3, tabwidth=8)
    assert x.compute_bracket_indent() == 3
    x = RoughParser("[", indent_width=3, tabwidth=8)
    assert x.compute_bracket_indent() == 3


# Generated at 2022-06-24 08:06:09.683105
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test_get_expression(text, index, expected):
        hp = HyperParser(text, index)
        if __debug__:
            if hp.get_expression() != expected:
                import sys
                print("Expression at index %s in string '%s' is '%s', not '%s'" %
                      (index, text, hp.get_expression(), expected), file=sys.stderr)
                raise ValueError("hyperparser failed!")
            else:
                print("Expression at index %s in '%s' is '%s'" %
                      (index, text, expected))

    test_get_expression('foo(5)', '2.2', '')
    test_get_expression('foo(5)', '2.3', '')

# Generated at 2022-06-24 08:06:15.181351
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    import unittest
    from test.test_support import run_unittest
    s = """\
# is_in_string tests

# This is a test.
"This is a string."
'This is "another" string.'
'''This is
another
string.'''
"""

    class is_in_string_TestCase(unittest.TestCase):
        def setUp(self):
            self.text = text_widget_class()
            self.text.set_text(s)

        def test_is_in_string(self):
            hp = HyperParser(self.text, "1.0")
            for i in range(1, 31):
                self.assertFalse(hp.is_in_string(), "failure in line %d" % i)

# Generated at 2022-06-24 08:06:26.933746
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # pylint: disable=redefined-outer-name,protected-access
    # Open a file for unit testing
    file = open("./tests/data/rough_parser.py")
    # Read the file data
    data = file.read()
    # Close the file
    file.close()
    # Create a RoughParser object
    rp = RoughParser()
    # Set a string in the RoughParser
    rp.set_str(data)
    # Set the indent width in the RoughParser
    rp.set_indentwidth(4)
    # Set the tab width in the RoughParser
    rp.set_tabwidth(4)
    # Set the continuation list in the RoughParser
    rp.set_lo(['\\', '('])
    # Assert that the continuation list is correct

# Generated at 2022-06-24 08:06:37.965600
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    import unittest

    class Test(unittest.TestCase):

        def setUp(self):
            self.text = Text()
            self.h = HyperParser(self.text, "1.0")
            self.h.set_index("1.0")

        def test_empty(self):
            self.h.set_index("1.0")
            self.assertEqual(self.h.is_in_string(), False)

        def test_contents(self):
            self.text.insert("1.0", 'x = "abc"')
            self.h.set_index("2.0")
            self.assertEqual(self.h.is_in_string(), True)
            self.assertEqual(self.h.is_in_code(), False)
            self.h.set_

# Generated at 2022-06-24 08:06:48.752068
# Unit test for constructor of class HyperParser
def test_HyperParser():
    h = HyperParser("\n\nfoo(bar) 123\nabc(123,\n   456)", "2.10")
    assert h.get_surrounding_brackets() == ("2.5", "2.13")
    assert h.get_expression() == "foo(bar)"
    h.set_index("2.6")
    assert h.get_expression() == "bar"
    h.set_index("2.13")
    assert h.get_surrounding_brackets(mustclose=True) is None
    assert h.get_expression() == ""
    h = HyperParser("abcdefghijklmnopqrstuvwxyz", "3.3")
    assert h.get_expression() == "def"
    assert h.is_in_code()

# Generated at 2022-06-24 08:06:59.820960
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    class TextClass:
        def __init__(self, s):
            self.s = s

        def get(self, a, b):
            return self.s[int(float(a)):int(float(b))]

        def index(self, s):
            return repr(int(float(s)))

        def __len__(self):
            return len(self.s)

        indent_width = tabwidth = None

    def HyperParser(text, index):
        parser = HyperParser(text, index)
        parser.set_index(index)
        return parser

    text = TextClass("""\
a = (1,
        2)""")
    hp = HyperParser(text, "2.2")
    assert hp.get_expression() == "a"

# Generated at 2022-06-24 08:07:08.899241
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    p = RoughParser("", None, None)

    p.str = r"foo = [ x for x in range(1)\
                           if x == 1 ]" # line continuation \
    p.goodlines = [1, 2, 3, 3]
    p.set_str(p.str)
    p.study_level = 2
    p.continuation = C_NONE
    p.stmt_bracketing = ((0, 0), (3, 1), (8, 2), (20, 1), (27, 0))
    p.lastch = "]"
    p.lastopenbracketpos = 27
    p.stmt_start = 3
    p.stmt_end = 27
    p.goodlines = [1, 2]
    p.continuation = C_NONE
    assert p.is_block_

# Generated at 2022-06-24 08:07:19.572393
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import pprint


# Generated at 2022-06-24 08:07:26.264135
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    from unittest import main
    from test.test_support import run_unittest

    class Test_is_in_string(unittest.TestCase):
        def test(self):
            index = "1.0"
            h = HyperParser("#Comment\n'''docstring'''\n#Comment\n'''docstring'''", index)
            self.assertFalse(h.is_in_string())
            h = HyperParser("#Comment\n'''docstring'''\n#Comment\n'''docstring'''\n", index)
            self.assertFalse(h.is_in_string())
            h = HyperParser("#Comment\n'''docstring'''\n#Comment\n'''docstring'''", "2.0")

# Generated at 2022-06-24 08:07:35.596614
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def test(text, mustclose, index, openers, ret):
        p = HyperParser(text, index)
        if ret is not None:
            ret = text.index(ret[0]), text.index(ret[1])
        ret2 = p.get_surrounding_brackets(openers, mustclose)
        if ret2 != ret:
            print("%s result %s, not %s" % (index, ret2, ret))

    root = Tk()
    root.withdraw()
    text = Text(root)
    text.insert("1.0", "def f(x : str) -> str:")
    text.insert("insert", "\n  ")
    text.insert("insert", "# On comment\n")
    text.insert("insert", "  return x.upper()")


# Generated at 2022-06-24 08:07:42.452108
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import sys
    import idlelib.pyshell

    root = idlelib.pyshell.make_test_shell()
    root.withdraw()

    # The following text is a part of a complex Python code.
    # The expression '+(a[0].foo().bar).fubar' is at the end.
    # The index is given as the position of the last char 'r'.
    text = (
        "    # a comment\n"
        "    x = {\n"
        "        'a': [1,\n"
        "              2],\n"
        "        'b': {'c': 3}\n"
        "        }\n"
        "    +(a[0].foo().bar).fubar\n"
    )
    index = len(text) - 1
    h = Hyper

# Generated at 2022-06-24 08:07:53.226853
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    rp = RoughParser("from foo import \\")
    bracketing = rp.get_last_stmt_bracketing()
    assert bracketing == ()
    rp = RoughParser("from foo import (")
    bracketing = rp.get_last_stmt_bracketing()
    assert bracketing == ((0, 0), (12, 1))
    rp = RoughParser("from foo import (qq)")
    bracketing = rp.get_last_stmt_bracketing()
    assert bracketing == ((0, 0), (12, 1), (14, 0))
    rp = RoughParser("from foo import (qq)\\")
    bracketing = rp.get_last_stmt_bracketing()
    assert bracketing == ((0, 0), (12, 1), (14, 0))
   

# Generated at 2022-06-24 08:08:03.824449
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    # pylint: disable=global-statement,eval-used
    global NUM_FAILS
    global NUM_TESTS
    NUM_TESTS += 1
    parser = RoughParser("", "", "", 0, 0)

# Generated at 2022-06-24 08:08:12.219718
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-24 08:08:20.186705
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    assert StringTranslatePseudoMapping({}, 'default')['nothing'] == 'default'
    assert StringTranslatePseudoMapping({'something': 'non_default'}, 'default')['something'] == 'non_default'
    assert StringTranslatePseudoMapping({'something': 'non_default'}, 'default')['nothing'] == 'default'


# Generated at 2022-06-24 08:08:28.189867
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-24 08:08:40.338440
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser(indent_width=4, tabwidth=8)
    rp.set_str("if True:\n    pass")
    assert rp.is_block_opener()
    rp.set_str("if True:pass")
    assert rp.is_block_opener()
    rp.set_str("if True: pass")
    assert rp.is_block_opener()
    rp.set_str("if True:")
    assert rp.is_block_opener()
    rp.set_str('if True;')
    assert not rp.is_block_opener()
    rp.set_str('if True:\n\npass\n')
    assert rp.is_block_opener()



# Generated at 2022-06-24 08:08:50.736260
# Unit test for constructor of class HyperParser
def test_HyperParser():
    def check(index, rawtext, bracketing, isopener, is_in_string, is_in_code, indexbracket):
        hp = HyperParser(
            TextIOWrapper(BytesIO(text.encode("utf-8"))), index
        )  # Text() doesn't have __str__...
        assert hp.text.get("1.0", END) == text
        assert hp.text.index("1.0") == "1.0"
        assert hp.rawtext == rawtext
        assert hp.bracketing == bracketing
        assert hp.isopener == isopener
        assert hp.is_in_string() == is_in_string
        assert hp.is_in_code() == is_in_code
        assert hp.indexbracket == indexbracket

    # 1. Test the main functionality

# Generated at 2022-06-24 08:08:57.395718
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({}, 42)
    assert mapping.get("key") == 42
    assert mapping.get("key", 43) == 42



# Generated at 2022-06-24 08:09:09.743764
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import string


# Generated at 2022-06-24 08:09:22.517065
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    """This function tests for method is_in_string of class HyperParser."""

    import unittest


# Generated at 2022-06-24 08:09:35.163119
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-24 08:09:46.907068
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-24 08:09:58.157711
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-24 08:10:12.132773
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    global p1_bracketing, p2_bracketing, p3_bracketing, p4_bracketing, p5_bracketing
    p1 = RoughParser(dedent("""\
        def f(a, b): pass
        def g(a, b):
            pass"""))
    p1_bracketing = p1.get_last_stmt_bracketing()
    p2 = RoughParser(dedent("""\
        {}
        (1,)
        foo(1, 2)
        foo(1,
            2)"""))
    p2_bracketing = p2.get_last_stmt_bracketing()

# Generated at 2022-06-24 08:10:20.266221
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    def do_test(s, index, expected):
        hp = HyperParser(s, index)
        if hp.is_in_string() != expected:
            print("test_HyperParser_is_in_string('%s', %s) failed" % (s, index))
            print("Expected result", expected)
            print("Actual result  ", hp.is_in_string())

    # is_in_string
    do_test("(a)   'foo'", "1.1", False)
    do_test("(a)   'foo'", "1.2", False)
    do_test("(a)   'foo'", "1.3", False)
    do_test("(a)   'foo'", "1.4", False)

# Generated at 2022-06-24 08:10:34.770605
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    import unittest
    from pytest import raises

    class TestComputer(unittest.TestCase):
        def __test(self, code, expected):
            r = RoughParser(code, None)
            self.assertEqual(r.compute_bracket_indent(), expected)

        def test_no_brackets(self):
            self.__test("foo\n", 0)

        def test_increase(self):
            self.__test("if foo:\n  bar\n", 2)

        def test_increase_nested(self):
            self.__test("if foo:\n  if bar:\n    boo\n", 3)

        def test_decrease(self):
            self.__test("if foo:\n  if bar:\n  boo\n", 2)


# Generated at 2022-06-24 08:10:40.724524
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    for test_string, expected_result in (
        ("while True:", True),
        ("if True:", True),
        ("continue", False),
        ("return", False),
        ("return\n", False),
        ("return\nx", False),
    ):
        assert is_block_opener(test_string) is expected_result



# Generated at 2022-06-24 08:10:50.955585
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class MockText:
        def __init__(self, *lines):
            self.lines = lines
            self.indent_width = 4
            self.tabwidth = 4

        def get(self, start, end):
            startlineno, startcolumn = [int(x) for x in str(start).split(".")]
            endlineno, endcolumn = [int(x) for x in str(end).split(".")]
            if startlineno == endlineno:
                return self.lines[startlineno - 1][startcolumn : endcolumn]
            buf = self.lines[startlineno - 1][startcolumn:] + "\n"
            for i in range(startlineno, endlineno - 1):
                buf += self.lines[i] + "\n"
            buf += self

# Generated at 2022-06-24 08:11:03.512651
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    parser = RoughParser('')
    assert parser.get_continuation_type() == C_NONE
    parser = RoughParser('x = "')
    assert parser.get_continuation_type() == C_STRING_FIRST_LINE
    parser = RoughParser('x = "y\n')
    assert parser.get_continuation_type() == C_STRING_NEXT_LINES
    parser = RoughParser('a = [1, 2')
    assert parser.get_continuation_type() == C_BRACKET
    parser = RoughParser('a = (1, 2')
    assert parser.get_continuation_type() == C_BRACKET
    parser = RoughParser('a = (1, 2\n')
    assert parser.get_continuation_type() == C_BRACKET
    parser = RoughParser

# Generated at 2022-06-24 08:11:14.862806
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    # pylint: disable=redefined-builtin

    def test(c_type, txt, expected):
        rp = RoughParser(txt, 0)
        rp.set_lo(6)
        # print(rp.continuation, c_type)
        assert rp.continuation == c_type
        # print(rp.get_base_indent_string(), expected)
        assert rp.get_base_indent_string() == expected


# Generated at 2022-06-24 08:11:24.754347
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    from unittest import TestCase

    class TC(TestCase):
        def runTest(self):
            self.assertEqual(HyperParser(self.before, self.index).get_expression(), self.after)


# Generated at 2022-06-24 08:11:34.109809
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    import random
    import unittest

    # Create 6 strings (a - f) by concatenating 300 lines
    # of randomized garbage, including newlines.
    lines = []
    for j in range(300):
        line = ""
        for _ in range(random.randrange(0, 51)):
            line = line + chr(random.randrange(0, 256))
        line = line + "\n"
        lines.append(line)

    i = 0
    a = lines[i : i + 100]
    i = i + 100
    b = lines[i : i + 100]
    i = i + 100
    c = lines[i : i + 100]
    i = i + 100
    d = lines[i : i + 100]
    i = i + 100

# Generated at 2022-06-24 08:11:45.041866
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    # Check that is_block_opener() works
    # on most Python constructions opening a block.
    # Note that it doesn't need to work on all Python
    # constructs, just those that can be followed by
    # an indented block.
    f = RoughParser("").is_block_opener
    fail_unless(f("if 1:"))
    fail_unless(f("if 1: #comment"))
    fail_unless(f("elif 1:"))
    fail_unless(f("else:"))
    fail_unless(f("try:"))
    fail_unless(f("except:"))
    fail_unless(f("except E, X:"))
    fail_unless(f("except (A, B), e:"))
    fail_unless(f("finally:"))
    fail_unless(f("while 1:"))

# Generated at 2022-06-24 08:11:53.702320
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    """
    Testing python_source.RoughParser.find_good_parse_start()
    """

    source = (
        "def test():\n"
        '    if True:  # more lines\n'
        '        pass  #\n'
        '    # more comments #\n'
    )
    assert RoughParser(source).find_good_parse_start() == (1, 31)

    source = 'print("""\\\n"""\n'
    assert RoughParser(source).find_good_parse_start() == (1, 14)



# Generated at 2022-06-24 08:11:57.265097
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    preserve_dict = {ord('A'): ord('A')}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert mapping[ord('A')] == ord('A')
    assert mapping[ord('B')] == ord('x')



# Generated at 2022-06-24 08:12:04.606147
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    assert RoughParser("").is_block_closer() == False
    assert RoughParser("pass").is_block_closer() == False
    assert RoughParser("a = 1").is_block_closer() == False
    assert RoughParser("a = 1; b = 2").is_block_closer() == False
    assert RoughParser("a = 1 # Comment").is_block_closer() == False
    assert RoughParser("return a").is_block_closer() == False
    assert RoughParser("return").is_block_closer() == False
    assert RoughParser("return # Comment").is_block_closer() == False
    assert RoughParser("raise").is_block_closer() == False
    assert RoughParser("raise Exception").is_block_closer() == False
    assert RoughParser("raise Exception()").is_block_cl

# Generated at 2022-06-24 08:12:15.320944
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    # check that we get a dict back when the default value is the same
    # as the value for the keys.
    mapping = StringTranslatePseudoMapping({"a": "b", "c": "c"}, "d")
    assert dict(mapping) == {"a": "b", "c": "c"}
    assert list(mapping) == ["a", "c"]  # list because order is undefined
    # check that we get a dict back when the default value is different
    # from the values for the keys.
    mapping = StringTranslatePseudoMapping({"a": "b", "c": "c"}, "d")
    assert dict(mapping) == {"a": "b", "c": "c"}
    assert list(mapping) == ["a", "c"]
    # check that we get a dict back when the

# Generated at 2022-06-24 08:12:27.061068
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Create the test data.
    str = "   foo([a,b])  \n"
    data = []
    # Create a test case for every index in the line.
    for i in range(len(str)):
        data.append([str, i, (str, 3, 10)])

    # Create the HyperParser object.
    hp = HyperParser(str, 0)

    # Check all test cases with the expected result.
    for item in data:
        idx = str.index(item[2][0], item[2][1], item[2][2])
        hp.set_index(idx)
        res = hp.get_surrounding_brackets("([")

# Generated at 2022-06-24 08:12:33.991924
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-24 08:12:43.116754
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    p = RoughParser("a=3; #comment\nprint(a)")
    p._study2()
    assert p.get_last_stmt_bracketing() == [(0, 0), (1, 1), (5, 0), (6, 1), (11, 0)]



# Parser class, encapsulating the pseudo-grammar used to determine
# where to insert newlines.  A word of explanation is in order.
#
# This pseudo-grammar is not intended to cover *all* Python syntax,
# but rather just those aspects that are useful to determine where
# to add newline characters.  In key ways, it's a very "liberal"
# grammar, designed to be *simple*, not to be a full spec of Python.
# Unfortunately, there are many ways to "trick" the parser by
# writing non-Pythonic constructs

# Generated at 2022-06-24 08:12:54.596280
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    RP = RoughParser("")
    assert RP.get_continuation_type() == C_NONE
    RP = RoughParser("\\\n")
    assert RP.get_continuation_type() == C_BACKSLASH
    RP = RoughParser("#\\\n")
    assert RP.get_continuation_type() == C_NONE
    RP = RoughParser("[\\\n")
    assert RP.get_continuation_type() == C_BRACKET
    RP = RoughParser("(\\\n")
    assert RP.get_continuation_type() == C_BRACKET
    RP = RoughParser("{\\\n")
    assert RP.get_continuation_type() == C_BRACKET
    RP = RoughParser("'\\\n")
    assert RP.get_continuation_type() == C_

# Generated at 2022-06-24 08:13:06.949734
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin

    RoughParser("").compute_backslash_indent()  # should not crash

    # with no continuation, return the base indentation
    rp = RoughParser("  foo()\n")
    assert rp.compute_backslash_indent() == 2

    # backslash at end of line
    rp = RoughParser("  foo()\\\n")
    assert rp.compute_backslash_indent() == 2

    # backslash+newline in middle of line
    rp = RoughParser("  foo(a=\\\n  17)\n")
    assert rp.compute_backslash_indent() == 2

    # backslash+newline at start of line is treated as continuation

# Generated at 2022-06-24 08:13:17.271581
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():

    class DummyEditor:
        def __init__(self, **kw):
            self.__dict__.update(kw)
            # Since this is a unit test, we can assume the tab width is 4.
            self.tabwidth = 4

    v = DummyEditor(text="some text\n")
    p = HyperParser(v.text, "1.0")
    assert p.get_expression() == ""

    v = DummyEditor(text="some text\n")
    p = HyperParser(v.text, "1.7")
    assert p.get_expression() == ""

    v = DummyEditor(text="some text\n")
    p = HyperParser(v.text, "1.8")
    assert p.get_expression() == "text"

    # Test inside strings and comments
    v = Dummy

# Generated at 2022-06-24 08:13:18.300650
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-24 08:13:28.707307
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class GetSurroundingBracketsTestCase(unittest.TestCase):
        def _run_test(self, text, want, index=None):
            text = textwrap.dedent(text)
            if index is None:
                index = "insert"
            hyp = HyperParser(tk.Text(None, wrap="none"), index)
            hyp.text.insert("insert", text)
            hyp.set_index("insert")
            got = hyp.get_surrounding_brackets()
            self.assertEqual(want, got)

        def test_empty_line(self):
            self._run_test("", (None, None))

        def test_single_bracket(self):
            self._run_test("(", (None, None))


# Generated at 2022-06-24 08:13:36.860035
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class TestCase(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            unittest.TestCase.__init__(self, *args, **kwargs)

            self.hp = HyperParser("", 0)
            self.set_text(0, "")

        def set_text(self, index, text):
            self.hp.text.set("1.0", "end", text)
            self.hp.set_index("%d.%d" % (index + 1, len(text)))

        def test_get_expression(self):
            hp = self.hp

            def check(text, index, exp):
                self.set_text(index, text)
                self.assertEqual(hp.get_expression(), exp)


# Generated at 2022-06-24 08:13:48.149702
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-24 08:13:54.580991
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    import py.test
    tester = RoughParser()
    s = "foo = {1: \\a, 2: \"b\"}"
    tester.set_str(s)
    tester.study1()
    assert tester.get_last_open_bracket_pos() == 7
    s = "foo = {1: [\\a, 2: \"b\"]"
    tester.set_str(s)
    tester.study1()
    assert tester.get_last_open_bracket_pos() == 7
    s = "foo = {1: [a, 2: \"b\"]"
    tester.set_str(s)
    tester.study1()
    assert tester.get_last_open_bracket_pos() == 7

# Generated at 2022-06-24 08:14:05.970754
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def test_basic(self):
            text = TestTextWrapper.TestText(
                """
if 1:
    # comment
    if 1:
        pass
"""
            )
            # Since HyperParser eats all text before the statement and
            # the parser needs an end newline, we add  and
            # an extra newline so that the statement doesn't end at
            # the end of the file.
            p = HyperParser(text, "3.0")
            self.assertEqual(str(p.bracketing), "[(0, 0), (8, 0), (11, 0), (15, 0), (16, 0)]")


# Generated at 2022-06-24 08:14:10.280112
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    assert StringTranslatePseudoMapping({1:1}, 2).get(1) == 1
    assert StringTranslatePseudoMapping({1:1}, 2).get(3) == 2



# Generated at 2022-06-24 08:14:19.766935
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    assert ("".translate(StringTranslatePseudoMapping({}, ord("x")))
            == "")
    assert ("".translate(StringTranslatePseudoMapping({ord("x"): ord("X")}, ord("x")))
            == "")
    assert ("abc".translate(StringTranslatePseudoMapping({}, ord("x")))
            == "xxx")
    assert ("abc".translate(StringTranslatePseudoMapping({ord("x"): ord("X")}, ord("x")))
            == "xxx")

# Generated at 2022-06-24 08:14:26.421259
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin

    # compute_backslash_indent is tricky.  if it's wrong, that's a
    # real mess, so let's make sure we get it right.

    import io

    def check(str, expected):
        rp = RoughParser("  " * 20 + str, 20)
        rp._study2()
        if rp.compute_backslash_indent() != expected:
            raise ValueError("%r: expected %d, got %d" % (str, expected, rp.compute_backslash_indent()))

    check("if a:\\\nb=c", 2)
    check("if a:\\\n    b=c", 4)
    check("if a:\n    b=c", 4)

# Generated at 2022-06-24 08:14:38.375080
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-24 08:14:44.174871
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    table = StringTranslatePseudoMapping({
        ord('a'): ord('b'),
        ord('c'): ord('d'),
    }, ord('x'))
    text = "abcdef"
    # surrogate to make sure the mapping is handled correctly by
    # Python's str.translate()
    text += '\U0001f606'
    assert text.translate(table) == "bcdefxx", text.translate(table)



# Generated at 2022-06-24 08:14:51.077571
# Unit test for constructor of class RoughParser
def test_RoughParser():
    # pylint: disable=too-many-branches

    def test(code, cont):
        r = RoughParser(code, "tab", 0, 0)
        got = r.get_continuation_type()
        assert got == cont, "%s expected %s got %s" % (code, cont, got)
    test("a", C_NONE)
    test("a\\", C_BACKSLASH)
    test("a\\\nb", C_BACKSLASH)
    test("a(\n)", C_BRACKET)
    test("a[\n]", C_BRACKET)
    test("a{\n}", C_BRACKET)
    test("a'''\n'''", C_STRING_FIRST_LINE)

# Generated at 2022-06-24 08:15:00.272743
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # This should have a lot of tests, but it actually doesn't
    # have any.
    text = r"""
    foo.bar.baz.\
    quux
    """
    hp = HyperParser(text, "4.0")
    print("repr(hp.get_expression()) ->", repr(hp.get_expression()))
    print("repr(hp.get_expression()) ->", repr(hp.get_expression()))
    hp.set_index("4.23")
    print("repr(hp.get_expression()) ->", repr(hp.get_expression()))
    hp.set_index("4.15")
    print("repr(hp.get_expression()) ->", repr(hp.get_expression()))



# Generated at 2022-06-24 08:15:05.816048
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    p = RoughParser(verbose=0, tabwidth=32)
    for (s, lo) in [
        ('', 0),
        (' ', 1),
        (' \t ', 2),
        ('\t', 0),
        ('\t ', 1),
        ('\t \t', 2),
        ('\t \t ', 3),
        ('  \t ', 3),
        ('  \t  ', 4),
    ]:
        p.set_lo(s)
        if p.lo != lo:
            raise ValueError(
                'Wrong result for s="%s": expected lo=%d, got %d'
                % (s, lo, p.lo))


# Generated at 2022-06-24 08:15:09.370126
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    left = "from random import randint\n"
    test_cases = [
        ("", 1),
        ("\n", 2),
        ("\n\n", 3),
        ("\n\n\n", 4),
    ]
    for right, expected in test_cases:
        rp = RoughParser(left + right)
        actual = rp.get_num_lines_in_stmt()
        assert actual == expected, (left + right,
                "actual:", actual, "expected:", expected)


# Generated at 2022-06-24 08:15:16.796713
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    import unittest
