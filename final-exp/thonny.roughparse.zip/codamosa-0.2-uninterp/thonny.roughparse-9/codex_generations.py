

# Generated at 2022-06-18 09:33:56.757185
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from idlelib.idle_test.mock_idle import Func
    from idlelib.idle_test.mock_tk import Mbox_func

    def test(text, index, openers, mustclose, expected):
        hp = HyperParser(text, index)
        res = hp.get_surrounding_brackets(openers, mustclose)
        if res is None:
            res = "None"
        else:
            res = "%s, %s" % res
        if res != expected:
            Mbox_func("%s\n%s\n%s\n%s\n%s" % (text, index, openers, mustclose, res))

    # Test with a string

# Generated at 2022-06-18 09:34:06.761516
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:34:15.865267
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # Test 1:
    # Check that HyperParser.is_in_string() returns True when the
    # index is inside a string.
    text = Text(None, "")
    text.insert("1.0", '"""a"""')
    hp = HyperParser(text, "1.1")
    assert hp.is_in_string()

    # Test 2:
    # Check that HyperParser.is_in_string() returns False when the
    # index is not inside a string.
    text = Text(None, "")
    text.insert("1.0", '"""a"""')
    hp = HyperParser(text, "1.0")
    assert not hp.is_in_string()

    # Test 3:
    # Check that HyperParser.is_in_string() returns False when the
    # index is inside a comment

# Generated at 2022-06-18 09:34:26.090345
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    # pylint: disable=redefined-builtin
    # pylint: disable=invalid-name
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-arguments

    # This test is a bit more complex than the others, because it
    # tests the RoughParser class, which is used by the parser
    # module.  The parser module is not imported by default, so
    # we have to do it here.
    import parser

    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=

# Generated at 2022-06-18 09:34:37.377225
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text()
    text.insert("1.0", "a = 1\n")
    text.insert("2.0", 'b = "a"\n')
    text.insert("3.0", "c = 'a'\n")
    text.insert("4.0", "# comment\n")
    text.insert("5.0", "d = 1 # comment\n")
    text.insert("6.0", "e = 1 # comment\n")
    text.insert("7.0", "f = 1 # comment\n")
    text.insert("8.0", "g = 1 # comment\n")
    text.insert("9.0", "h = 1 # comment\n")
    text.insert("10.0", "i = 1 # comment\n")

# Generated at 2022-06-18 09:34:42.145641
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo(0)
    assert rp.lo == 0
    rp.set_lo(1)
    assert rp.lo == 1
    rp.set_lo(2)
    assert rp.lo == 2


# Generated at 2022-06-18 09:34:47.313481
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert set(mapping) == set(whitespace_chars)

# Generated at 2022-06-18 09:34:58.916062
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:35:06.652567
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            raise AssertionError(
                "HyperParser.get_expression(%r, %r) -> %r, expected %r"
                % (text, index, actual, expected)
            )

    test("a.b", "1.0", "")
    test("a.b", "1.1", "a")
    test("a.b", "1.2", "a.")
    test("a.b", "1.3", "a.b")
    test("a.b", "1.4", "a.b")
    test("a.b", "2.0", "a.b")

# Generated at 2022-06-18 09:35:19.116573
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:36:07.256024
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Text()
    text.insert("insert", '"""a"""')
    text.insert("insert", '"b"')
    text.insert("insert", "'c'")
    text.insert("insert", "'''d'''")
    text.insert("insert", '"e')
    text.insert("insert", "'f")
    text.insert("insert", "g")
    text.insert("insert", "h")
    text.insert("insert", "i")
    text.insert("insert", "j")
    text.insert("insert", "k")
    text.insert("insert", "l")
    text.insert("insert", "m")
    text.insert("insert", "n")
    text.insert("insert", "o")
    text.insert("insert", "p")

# Generated at 2022-06-18 09:36:17.376487
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.is_in_code()
        if actual != expected:
            print("test failed:")
            print("text:", repr(text))
            print("index:", repr(index))
            print("expected:", repr(expected))
            print("actual:", repr(actual))
            print()

    test("", "1.0", True)
    test("#", "1.0", False)
    test("#", "1.1", True)
    test("#\n", "1.1", True)
    test("#\n", "2.0", True)
    test("#\n", "2.1", True)
    test("#\n#", "2.1", False)

# Generated at 2022-06-18 09:36:27.020878
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Test(TestCase):
        def test_set_index(self):
            from idlelib.idle_test.mock_idle import Func
            from idlelib.idle_test.mock_tk import Text

            text = Text()
            text.insert("1.0", "a\nb\nc\n")
            text.mark_set("insert", "1.0")
            text.mark_set("current", "1.0")
            text.mark_set("current_char", "1.0")
            text.mark_set("anchor", "1.0")
            text.mark_set("sel", "1.0")
            text.mark_set("sel_char", "1.0")

# Generated at 2022-06-18 09:36:37.604391
# Unit test for constructor of class HyperParser
def test_HyperParser():
    # Test the HyperParser constructor
    text = Text()
    text.insert("insert", "def f(x):\n    return x + 1\n")
    hp = HyperParser(text, "insert")
    assert hp.rawtext == "def f(x):\n    return x + 1"
    assert hp.stopatindex == "3.end"

# Generated at 2022-06-18 09:36:47.289848
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("a = 1")
    assert rp.str == "a = 1"
    assert rp.goodlines == [0, 1]
    assert rp.continuation == C_NONE
    assert rp.study_level == 0
    assert rp.stmt_start == 0
    assert rp.stmt_end == 0
    assert rp.lastch == ""
    assert rp.lastopenbracketpos is None
    assert rp.stmt_bracketing is None

    rp.set_lo("a = 1\nb = 2")
    assert rp.str == "a = 1\nb = 2"
    assert rp.goodlines == [0, 2]
    assert rp.continuation == C_NONE

# Generated at 2022-06-18 09:36:57.431976
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def setUp(self):
            self.text = Text()
            self.text.insert("1.0", "a = 1\n")
            self.text.insert("2.0", "b = 2\n")
            self.text.insert("3.0", "c = 3\n")
            self.text.insert("4.0", "d = 4\n")
            self.text.insert("5.0", "e = 5\n")
            self.text.insert("6.0", "f = 6\n")
            self.text.insert("7.0", "g = 7\n")
            self.text.insert("8.0", "h = 8\n")

# Generated at 2022-06-18 09:37:08.078332
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:37:19.538846
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    from unittest import TestCase


# Generated at 2022-06-18 09:37:31.500419
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:37:39.387734
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    def foo():\n        pass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("def foo():\n    pass\n")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("    def foo():\n        pass")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("def foo():\n    pass")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("    def foo():\n        pass\n    ")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("def foo():\n    pass\n")

# Generated at 2022-06-18 09:38:49.635547
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:39:00.045183
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            print("Error:")
            print("text =", repr(text))
            print("index =", repr(index))
            print("expected =", repr(expected))
            print("actual =", repr(actual))
            print()

    test("", "1.0", "")
    test("a", "1.0", "a")
    test("a", "1.1", "")
    test("a ", "1.1", "a")
    test("a ", "1.2", "")
    test("a b", "1.2", "b")
    test("a b", "1.3", "")

# Generated at 2022-06-18 09:39:09.437908
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:39:18.361427
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-18 09:39:26.151258
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    assert HyperParser("", "1.0").is_in_string() == False
    assert HyperParser("a", "1.0").is_in_string() == False
    assert HyperParser("'", "1.0").is_in_string() == True
    assert HyperParser("''", "1.0").is_in_string() == True
    assert HyperParser("'''", "1.0").is_in_string() == True
    assert HyperParser("'''a", "1.0").is_in_string() == True
    assert HyperParser("'''a'", "1.0").is_in_string() == True
    assert HyperParser("'''a''", "1.0").is_in_string() == True

# Generated at 2022-06-18 09:39:31.405010
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:39:36.917509
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:39:42.232166
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:39:47.473182
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Test(TestCase):
        def test_set_index(self):
            from tkinter import Text

            text = Text()
            text.insert("insert", "if True:\n    pass\n")
            hp = HyperParser(text, "1.0")
            hp.set_index("1.0")
            self.assertEqual(hp.indexinrawtext, 0)
            self.assertEqual(hp.indexbracket, 0)
            hp.set_index("1.1")
            self.assertEqual(hp.indexinrawtext, 1)
            self.assertEqual(hp.indexbracket, 0)
            hp.set_index("1.2")
            self.assertEqual(hp.indexinrawtext, 2)
            self.assertEqual

# Generated at 2022-06-18 09:39:53.095737
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # pylint: disable=redefined-builtin

    def check(s, expected):
        rp = RoughParser(s, "utf-8")
        actual = rp.get_continuation_type()
        assert actual == expected, (
            "expected %s, got %s for %r" % (expected, actual, s)
        )

    check("", C_NONE)
    check("\n", C_NONE)
    check("\n\n", C_NONE)
    check("\n\n\n", C_NONE)
    check("\n\n\n\n", C_NONE)
    check("\n\n\n\n\n", C_NONE)
    check("\n\n\n\n\n\n", C_NONE)
    check

# Generated at 2022-06-18 09:42:03.929011
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:42:11.157818
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:42:20.264575
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:42:31.152938
# Unit test for method compute_bracket_indent of class RoughParser