

# Generated at 2022-06-18 09:33:50.650770
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    def t(s, expected):
        rp = RoughParser(s, indent_width=4, tabwidth=8)
        actual = rp.get_last_stmt_bracketing()
        assert actual == expected, (actual, expected)

    t("", None)
    t("#\n", None)
    t("#\n#\n", None)
    t("#\n#\n#\n", None)
    t("#\n#\n#\n#\n", None)
    t("#\n#\n#\n#\n#\n", None)
    t("#\n#\n#\n#\n#\n#\n", None)
    t("#\n#\n#\n#\n#\n#\n#\n", None)

# Generated at 2022-06-18 09:34:01.120903
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def setUp(self):
            self.text = Text()
            self.text.insert("1.0", "a = 1\nb = 2\n")
            self.text.mark_set("insert", "1.0")
            self.text.see("insert")

        def test_get_expression(self):
            self.assertEqual(HyperParser(self.text, "1.0").get_expression(), "")
            self.assertEqual(HyperParser(self.text, "1.1").get_expression(), "a")
            self.assertEqual(HyperParser(self.text, "1.2").get_expression(), "a")

# Generated at 2022-06-18 09:34:03.566605
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase


# Generated at 2022-06-18 09:34:13.179822
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-18 09:34:22.784535
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:34:34.457710
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:34:45.707733
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-18 09:34:57.220387
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest
    import textwrap

    class TestHyperParser(unittest.TestCase):
        def test_get_expression(self):
            text = textwrap.dedent(
                """\
                def foo(a, b, c):
                    if a:
                        if b:
                            if c:
                                pass
                            else:
                                pass
                        else:
                            pass
                    else:
                        pass
                """
            )
            text = text.replace("\n", "\r\n")
            text = text.replace("    ", "\t")
            text = text.replace("\t", " " * 4)
            text = text.replace("\r\n", "\n")
            text = text.replace("\n", "\r\n")

# Generated at 2022-06-18 09:35:06.148642
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:35:07.868833
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert set(mapping) == set(whitespace_chars)

# Generated at 2022-06-18 09:35:42.059517
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    def foo():\n        pass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("\tdef foo():\n\t\tpass\n")
    assert rp.get_base_indent_string() == "\t"
    rp = RoughParser("\tdef foo():\n    pass\n")
    assert rp.get_base_indent_string() == "\t"
    rp = RoughParser("    def foo():\n\tpass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("\tdef foo():\n    pass\n")
    assert rp.get_base_indent_string() == "\t"
    r

# Generated at 2022-06-18 09:35:44.649254
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from idlelib.idle_test.htest import run

    run(HyperParser)


if __name__ == "__main__":
    test_HyperParser()

# Generated at 2022-06-18 09:35:55.417721
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:36:06.230096
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:36:16.268478
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def test_get_expression(self):
            text = """\
            def f(x):
                if x:
                    return x.foo(
                        a,
                        b,
                        c,
                    )
                else:
                    return x.bar(
                        d,
                        e,
                        f,
                    )
            """
            # Test the HyperParser constructor
            hp = HyperParser(text, "1.0")
            self.assertEqual(hp.rawtext, text)
            self.assertEqual(hp.stopatindex, "1.end")

# Generated at 2022-06-18 09:36:26.408125
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    def foo():\n        pass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("\tdef foo():\n\t\tpass\n")
    assert rp.get_base_indent_string() == "\t"
    rp = RoughParser("\tdef foo():\n    pass\n")
    assert rp.get_base_indent_string() == "\t"
    rp = RoughParser("    def foo():\n\tpass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n    pass\n")
    assert rp.get_base_indent_string() == "    "
    rp

# Generated at 2022-06-18 09:36:37.210380
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("if 1:\n    print(1)\n    print(2)")
    assert rp.get_continuation_type() == C_NONE
    assert rp.get_num_lines_in_stmt() == 1
    assert rp.get_base_indent_string() == "    "
    assert rp.is_block_opener()
    assert not rp.is_block_closer()
    assert rp.get_last_open_bracket_pos() == None
    assert rp.get_last_stmt_bracketing() == ((0, 0), (4, 1), (9, 0))
    rp.set_lo("if 1:\n    print(1)\n    print(2)\n")

# Generated at 2022-06-18 09:36:46.424945
# Unit test for method set_lo of class RoughParser

# Generated at 2022-06-18 09:36:57.221190
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        result = hp.get_expression()
        assert result == expected, (
            "HyperParser.get_expression(%r, %r) returned %r, "
            "expected %r" % (text, index, result, expected)
        )

    test("", "1.0", "")
    test("a", "1.0", "")
    test("a", "1.1", "a")
    test("a b", "1.2", "a")
    test("a b", "1.3", "b")
    test("a b", "1.4", "")
    test("a b", "1.5", "")
    test("a b", "2.0", "")

# Generated at 2022-06-18 09:36:59.959519
# Unit test for method is_in_code of class HyperParser