

# Generated at 2022-06-18 09:34:47.462644
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:34:59.017474
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    text.insert("insert", "a = 1 + 2\n")
    text.insert("insert", "a = 1 + 2\n")
    text.insert("insert", "a = 1 + 2\n")
    text.insert("insert", "a = 1 + 2\n")
    text.insert("insert", "a = 1 + 2\n")
    text.insert("insert", "a = 1 + 2\n")
    text.insert("insert", "a = 1 + 2\n")
    text.insert("insert", "a = 1 + 2\n")
    text.insert("insert", "a = 1 + 2\n")
    text.insert("insert", "a = 1 + 2\n")
    text.insert("insert", "a = 1 + 2\n")

# Generated at 2022-06-18 09:35:07.397153
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_expression(self):
            def check(text, index, expected):
                hp = HyperParser(text, index)
                actual = hp.get_expression()
                self.assertEqual(actual, expected)

            check("", "1.0", "")
            check("a", "1.0", "a")
            check("a", "1.1", "")
            check("a b", "1.1", "a")
            check("a b", "1.2", "")
            check("a b", "1.3", "b")
            check("a b", "1.4", "")
            check("a b c", "1.4", "b")

# Generated at 2022-06-18 09:35:19.117798
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    text.insert("insert", "a = 1\n")
    text.insert("insert", "b = 2\n")
    text.insert("insert", "c = 3\n")
    text.insert("insert", "d = 4\n")
    text.insert("insert", "e = 5\n")
    text.insert("insert", "f = 6\n")
    text.insert("insert", "g = 7\n")
    text.insert("insert", "h = 8\n")
    text.insert("insert", "i = 9\n")
    text.insert("insert", "j = 10\n")
    text.insert("insert", "k = 11\n")
    text.insert("insert", "l = 12\n")

# Generated at 2022-06-18 09:35:29.330161
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    text.insert("1.0", "a = 1\n")
    text.insert("2.0", "b = 2\n")
    text.insert("3.0", "c = 3\n")
    text.insert("4.0", "d = 4\n")
    text.insert("5.0", "e = 5\n")
    text.insert("6.0", "f = 6\n")
    text.insert("7.0", "g = 7\n")
    text.insert("8.0", "h = 8\n")
    text.insert("9.0", "i = 9\n")
    text.insert("10.0", "j = 10\n")
    text.insert("11.0", "k = 11\n")

# Generated at 2022-06-18 09:35:34.222332
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({ord('a'): ord('b')}, ord('c'))
    assert mapping.get(ord('a')) == ord('b')
    assert mapping.get(ord('b')) == ord('c')
    assert mapping.get(ord('c')) == ord('c')



# Generated at 2022-06-18 09:35:45.090246
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:35:56.431525
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    p = RoughParser()
    p.set_str("a = 1\n")
    assert p.get_num_lines_in_stmt() == 1
    assert p.get_continuation_type() == C_NONE
    assert p.get_base_indent_string() == ""
    assert not p.is_block_opener()
    assert not p.is_block_closer()
    assert p.get_last_open_bracket_pos() is None
    assert p.get_last_stmt_bracketing() == ((0, 0), (5, 0))

    p.set_str("a = 1 + \\")
    assert p.get_num_lines_in_stmt() == 1
    assert p.get_continuation_type() == C_BACKSLASH
    assert p.get_

# Generated at 2022-06-18 09:36:07.013482
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:36:17.067669
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser("if True:\n    pass\n")
    assert rp.is_block_opener()
    rp = RoughParser("if True:\n    pass")
    assert rp.is_block_opener()
    rp = RoughParser("if True: pass\n")
    assert rp.is_block_opener()
    rp = RoughParser("if True: pass")
    assert rp.is_block_opener()
    rp = RoughParser("if True:\n    pass\n    pass\n")
    assert rp.is_block_opener()
    rp = RoughParser("if True:\n    pass\n    pass")
    assert rp.is_block_opener()

# Generated at 2022-06-18 09:37:07.603101
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Test(TestCase):
        def test_set_index(self):
            from tkinter import Text

            text = Text()
            text.insert("insert", "a = (1, 2, 3)")
            text.mark_set("insert", "1.0")
            hp = HyperParser(text, "insert")
            hp.set_index("1.1")
            self.assertEqual(hp.indexinrawtext, 1)
            self.assertEqual(hp.indexbracket, 0)
            hp.set_index("1.2")
            self.assertEqual(hp.indexinrawtext, 2)
            self.assertEqual(hp.indexbracket, 0)
            hp.set_index("1.3")

# Generated at 2022-06-18 09:37:19.168890
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-18 09:37:25.803115
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("""\
    def foo():
        pass
    """, indent_width=4, tabwidth=8)
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("""\
    def foo():
        pass
    """, indent_width=2, tabwidth=8)
    assert rp.get_base_indent_string() == "  "
    rp = RoughParser("""\
    def foo():
        pass
    """, indent_width=4, tabwidth=4)
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("""\
    def foo():
        pass
    """, indent_width=4, tabwidth=2)
    assert rp.get_base_ind

# Generated at 2022-06-18 09:37:36.231850
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:37:47.138054
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from unittest import TestCase

    class Test(TestCase):
        def test_get_surrounding_brackets(self):
            from tkinter import Text

            text = Text()
            text.insert("insert", "a = (1, 2, 3)")
            text.mark_set("insert", "1.4")
            hp = HyperParser(text, "insert")
            self.assertEqual(hp.get_surrounding_brackets(), ("1.2", "1.10"))
            text.mark_set("insert", "1.5")
            hp.set_index("insert")
            self.assertEqual(hp.get_surrounding_brackets(), ("1.2", "1.10"))
            text.mark_set("insert", "1.6")

# Generated at 2022-06-18 09:37:57.994721
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    def foo():\n        pass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("\tdef foo():\n\t\tpass\n")
    assert rp.get_base_indent_string() == "\t"
    rp = RoughParser("\tdef foo():\n    pass\n")
    assert rp.get_base_indent_string() == "\t"
    rp = RoughParser("    def foo():\n\tpass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n    pass\n")
    assert rp.get_base_indent_string() == "    "
    rp

# Generated at 2022-06-18 09:38:08.254294
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:38:20.007637
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest
    import sys


# Generated at 2022-06-18 09:38:27.776535
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def test(text, index, openers, mustclose, expected):
        hp = HyperParser(text, index)
        actual = hp.get_surrounding_brackets(openers, mustclose)
        if actual != expected:
            print("Error in test:")
            print("text: %r" % text)
            print("index: %r" % index)
            print("openers: %r" % openers)
            print("mustclose: %r" % mustclose)
            print("expected: %r" % expected)
            print("actual: %r" % actual)
            print()
            raise ValueError

    # Test with a string
    test("a[b]", "1.2", "([{", False, ("1.0", "1.3"))

# Generated at 2022-06-18 09:38:33.164887
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest


# Generated at 2022-06-18 09:39:16.229612
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-18 09:39:24.656660
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from idlelib.idle_test.mock_idle import Func
    from idlelib.idle_test.mock_tk import Mbox_func

    class DummyEditwin:
        text = None

        def __init__(self):
            self.text = DummyText()

    class DummyText:
        index = None

        def __init__(self):
            self.index = Func()

        def get(self, start, stop):
            return start + stop

        def index(self, index):
            return index

    class DummyEditwin2:
        text = None

        def __init__(self):
            self.text = DummyText2()

    class DummyText2:
        index = None

        def __init__(self):
            self.index = Func()


# Generated at 2022-06-18 09:39:29.391884
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text()
    text.insert("1.0", "a = 1\n")
    hp = HyperParser(text, "1.0")
    assert hp.is_in_code()
    hp.set_index("1.1")
    assert hp.is_in_code()
    hp.set_index("1.2")
    assert hp.is_in_code()
    hp.set_index("1.3")
    assert not hp.is_in_code()
    hp.set_index("1.4")
    assert not hp.is_in_code()
    hp.set_index("1.5")
    assert not hp.is_in_code()
    hp.set_index("1.6")
    assert not hp.is_in_code()

# Generated at 2022-06-18 09:39:35.002987
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-18 09:39:40.427414
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-18 09:39:45.649578
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("if a:")
    assert rp.get_last_open_bracket_pos() == 3
    assert rp.get_last_stmt_bracketing() == ((0, 0), (3, 1), (4, 0))
    assert rp.is_block_opener()
    assert not rp.is_block_closer()
    assert rp.get_base_indent_string() == ""
    assert rp.get_continuation_type() == C_NONE
    assert rp.get_num_lines_in_stmt() == 1

    rp.set_lo("if a:\n    pass")
    assert rp.get_last_open_bracket_pos() == 3
    assert rp.get_last_st

# Generated at 2022-06-18 09:39:50.950989
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:39:57.405371
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-18 09:40:06.142115
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-return-statements
    # pylint: disable=too-many-boolean-expressions
    # pylint: disable=too-many-instance-attributes
    # pylint: disable=too-many-public-methods
    # pylint: disable=too-many-lines

    def check(expected, s, indent_width=4, tabwidth=8):
        parser = RoughParser

# Generated at 2022-06-18 09:40:15.293164
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Test(TestCase):
        def test_set_index(self):
            text = Text()
            text.insert("1.0", "a = 1 + 2\n")
            hp = HyperParser(text, "1.0")
            hp.set_index("1.0")
            self.assertEqual(hp.indexinrawtext, 0)
            self.assertEqual(hp.indexbracket, 0)
            hp.set_index("1.1")
            self.assertEqual(hp.indexinrawtext, 1)
            self.assertEqual(hp.indexbracket, 0)
            hp.set_index("1.2")
            self.assertEqual(hp.indexinrawtext, 2)

# Generated at 2022-06-18 09:41:41.326144
# Unit test for constructor of class HyperParser

# Generated at 2022-06-18 09:41:45.344615
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    """Unit test for method get_surrounding_brackets of class HyperParser"""
    import unittest


# Generated at 2022-06-18 09:41:51.340770
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def test_get_expression(self):
            text = "a.b.c.d.e.f.g.h.i.j.k.l.m.n.o.p.q.r.s.t.u.v.w.x.y.z"
            for i in range(len(text)):
                hp = HyperParser(text, "%d.0" % (i + 1))
                self.assertEqual(hp.get_expression(), text[i:])


# Generated at 2022-06-18 09:42:00.387665
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    def foo():\n        pass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("def foo():\n    pass\n")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("\n    def foo():\n        pass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("\n\n    def foo():\n        pass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("\n\n    def foo():\n        pass\n\n")
    assert rp.get_base_indent_string() == "    "


# Generated at 2022-06-18 09:42:07.837456
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-18 09:42:17.211868
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    if True:\n        pass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("if True:\n    pass\n")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("if True:\n    pass\n    ")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("if True:\n    pass\n    \n")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("if True:\n    pass\n    # comment\n")
    assert rp.get_base_indent_string() == ""

# Generated at 2022-06-18 09:42:27.151587
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:42:28.331436
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:42:33.512524
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Test for method get_surrounding_brackets(self, openers='([{', mustclose=False)
    # of class HyperParser
    from idlelib.idle_test.htest import run
    run(HyperParser)

if __name__ == "__main__":
    test_HyperParser_get_surrounding_brackets()

# Generated at 2022-06-18 09:42:42.869289
# Unit test for method compute_backslash_indent of class RoughParser