

# Generated at 2022-06-18 09:34:22.521040
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-18 09:34:34.159363
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            print("Error in HyperParser.get_expression:")
            print("  text:", repr(text))
            print("  index:", repr(index))
            print("  expected:", repr(expected))
            print("  actual:", repr(actual))
            print()

    test("", "1.0", "")
    test("a", "1.0", "a")
    test("a", "1.1", "")
    test("a b", "1.2", "b")
    test("a b", "1.3", "")
    test("a b", "1.4", "")

# Generated at 2022-06-18 09:34:45.390467
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-18 09:34:56.958763
# Unit test for method set_lo of class RoughParser

# Generated at 2022-06-18 09:35:06.588120
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.text = Text()
            self.text.insert("1.0", "a = (1 + 2)\n")
            self.parser = HyperParser(self.text, "1.0")

        def test_set_index(self):
            self.parser.set_index("1.0")
            self.assertEqual(self.parser.indexinrawtext, 0)
            self.assertEqual(self.parser.indexbracket, 0)
            self.parser.set_index("1.1")
            self.assertEqual(self.parser.indexinrawtext, 1)
            self.assertEqual(self.parser.indexbracket, 0)

# Generated at 2022-06-18 09:35:19.028683
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Text()
    text.insert("1.0", "def f(x):\n    return x + 1\n")
    text.mark_set("insert", "1.0")
    text.see("insert")
    hp = HyperParser(text, "insert")
    assert hp.get_expression() == "x"
    text.insert("insert", " ")
    hp.set_index("insert")
    assert hp.get_expression() == "x"
    text.insert("insert", " ")
    hp.set_index("insert")
    assert hp.get_expression() == "x"
    text.insert("insert", " ")
    hp.set_index("insert")
    assert hp.get_expression() == "x"
    text.insert("insert", " ")
    hp.set_index

# Generated at 2022-06-18 09:35:29.282724
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest

    class Test(unittest.TestCase):
        def test_set_index(self):
            text = Text()
            text.insert("insert", "a = 1 + 2 + 3")
            parser = HyperParser(text, "insert")
            parser.set_index("insert")
            self.assertEqual(parser.get_expression(), "")
            parser.set_index("insert + 1c")
            self.assertEqual(parser.get_expression(), "")
            parser.set_index("insert + 2c")
            self.assertEqual(parser.get_expression(), "")
            parser.set_index("insert + 3c")
            self.assertEqual(parser.get_expression(), "")
            parser.set_index("insert + 4c")

# Generated at 2022-06-18 09:35:35.195478
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({}, 0)
    assert mapping.get(1) == 0
    assert mapping.get(1, 2) == 2
    mapping = StringTranslatePseudoMapping({1: 2}, 0)
    assert mapping.get(1) == 2
    assert mapping.get(1, 3) == 2
    assert mapping.get(2) == 0
    assert mapping.get(2, 3) == 3



# Generated at 2022-06-18 09:35:46.567677
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    text = """\
    (1,
     2,
     3)"""
    hp = HyperParser(text, "1.0")
    assert hp.get_surrounding_brackets() == ("1.0", "1.12")
    hp.set_index("1.4")
    assert hp.get_surrounding_brackets() == ("1.0", "1.12")
    hp.set_index("1.8")
    assert hp.get_surrounding_brackets() == ("1.0", "1.12")
    hp.set_index("1.12")
    assert hp.get_surrounding_brackets() == ("1.0", "1.12")
    hp.set_index("1.13")
    assert hp.get_surrounding_brackets() is None

   

# Generated at 2022-06-18 09:35:57.463208
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:36:21.113142
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:36:28.098288
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-18 09:36:38.401353
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-18 09:36:45.345571
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Text(None, "")
    text.insert("insert", '"""a"""')
    text.insert("insert", '"b"')
    text.insert("insert", "'''c'''")
    text.insert("insert", "'d'")
    text.insert("insert", '"""e"""')
    text.insert("insert", '"f"')
    text.insert("insert", "'''g'''")
    text.insert("insert", "'h'")
    text.insert("insert", "i")
    text.insert("insert", "j")
    text.insert("insert", "k")
    text.insert("insert", "l")
    text.insert("insert", "m")
    text.insert("insert", "n")
    text.insert("insert", "o")

# Generated at 2022-06-18 09:36:55.585753
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = "'''\n'''\n'''\n'''\n"
    hp = HyperParser(text, "1.0")
    assert hp.is_in_string()
    hp = HyperParser(text, "2.0")
    assert not hp.is_in_string()
    hp = HyperParser(text, "3.0")
    assert hp.is_in_string()
    hp = HyperParser(text, "4.0")
    assert not hp.is_in_string()
    text = "'''\n'''\n'''\n'''\n'''\n"
    hp = HyperParser(text, "1.0")
    assert hp.is_in_string()
    hp = HyperParser(text, "2.0")
    assert not hp.is_in_string

# Generated at 2022-06-18 09:37:06.185975
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def setUp(self):
            self.text = Text()
            self.text.insert("1.0", "a = 1\n")
            self.text.insert("2.0", "b = 2\n")
            self.text.insert("3.0", "c = 3\n")
            self.text.insert("4.0", "d = 4\n")
            self.text.insert("5.0", "e = 5\n")
            self.text.insert("6.0", "f = 6\n")
            self.text.insert("7.0", "g = 7\n")
            self.text.insert("8.0", "h = 8\n")

# Generated at 2022-06-18 09:37:18.454352
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Text()
    text.insert("insert", "'''\n'''\n'''\n'''\n")
    text.insert("insert", "'''\n'''\n'''\n'''\n")
    text.insert("insert", "'''\n'''\n'''\n'''\n")
    text.insert("insert", "'''\n'''\n'''\n'''\n")
    text.insert("insert", "'''\n'''\n'''\n'''\n")
    text.insert("insert", "'''\n'''\n'''\n'''\n")
    text.insert("insert", "'''\n'''\n'''\n'''\n")

# Generated at 2022-06-18 09:37:29.235350
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements

    def check(s, expected):
        rp = RoughParser(s, indent_width=4, tabwidth=8)
        rp._study1()
        assert rp.continuation == C_BACKSLASH
        assert rp.compute_backslash_indent() == expected

    check("", 0)
    check("a", 1)
    check("a =", 1)
    check("a = b", 1)
    check("a = b\\", 5)
    check("a = b\\\n", 5)
    check("a = b\\\n ", 5)

# Generated at 2022-06-18 09:37:37.914312
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:37:48.270912
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text()
    text.insert("1.0", '"""a"""\n"""b"""\n"""c"""')
    text.insert("2.0", '"""d"""\n"""e"""\n"""f"""')
    text.insert("3.0", '"""g"""\n"""h"""\n"""i"""')
    text.insert("4.0", '"""j"""\n"""k"""\n"""l"""')
    text.insert("5.0", '"""m"""\n"""n"""\n"""o"""')
    text.insert("6.0", '"""p"""\n"""q"""\n"""r"""')
    text.insert("7.0", '"""s"""\n"""t"""\n"""u"""')

# Generated at 2022-06-18 09:38:36.339375
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # Test that set_index works correctly when the index is at the
    # beginning of the statement.
    text = Text(
        "def f():\n"
        "    if True:\n"
        "        pass\n"
        "    else:\n"
        "        pass\n"
        "\n"
        "def g():\n"
        "    pass\n"
    )
    hp = HyperParser(text, "1.0")
    hp.set_index("1.0")
    assert hp.indexbracket == 0
    assert hp.indexinrawtext == 0
    assert hp.rawtext == "def f():\n"
    assert hp.stopatindex == "1.end"

    # Test that set_index works correctly when the index is in the
    # middle of the statement.
    text

# Generated at 2022-06-18 09:38:41.542491
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:38:51.184260
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Text()
    text.insert("1.0", "abc 'def'")
    hp = HyperParser(text, "1.0")
    assert hp.is_in_string() == False
    hp.set_index("1.3")
    assert hp.is_in_string() == False
    hp.set_index("1.4")
    assert hp.is_in_string() == True
    hp.set_index("1.5")
    assert hp.is_in_string() == True
    hp.set_index("1.6")
    assert hp.is_in_string() == False
    text.insert("1.7", "'''")
    hp.set_index("1.8")
    assert hp.is_in_string() == True
    hp.set_index("1.9")

# Generated at 2022-06-18 09:39:01.803238
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def test_get_expression(self):
            text = """\
            a = 1
            b = 2
            c = 3
            d = 4
            e = 5
            f = 6
            g = 7
            h = 8
            i = 9
            j = 10
            k = 11
            l = 12
            m = 13
            n = 14
            o = 15
            p = 16
            q = 17
            r = 18
            s = 19
            t = 20
            u = 21
            v = 22
            w = 23
            x = 24
            y = 25
            z = 26
            """
            text = text.replace("\n", "\r\n")

# Generated at 2022-06-18 09:39:11.040585
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def test(text, index, openers, mustclose, expected):
        hp = HyperParser(text, index)
        result = hp.get_surrounding_brackets(openers, mustclose)
        if result != expected:
            print(
                "test_HyperParser_get_surrounding_brackets:",
                "text=%r, index=%r, openers=%r, mustclose=%r, expected=%r, result=%r"
                % (text, index, openers, mustclose, expected, result),
                file=sys.stderr,
            )

    test("(a+b", "1.4", "([", False, ("1.0", "1.5"))
    test("(a+b", "1.4", "([", True, None)

# Generated at 2022-06-18 09:39:19.847256
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text()
    text.insert("insert", "def f(x):\n    return x + 1\n")
    text.mark_set("insert", "1.0")
    hp = HyperParser(text, "insert")
    assert hp.is_in_code()
    text.mark_set("insert", "1.4")
    hp.set_index("insert")
    assert hp.is_in_code()
    text.mark_set("insert", "1.5")
    hp.set_index("insert")
    assert not hp.is_in_code()
    text.mark_set("insert", "1.6")
    hp.set_index("insert")
    assert hp.is_in_code()
    text.mark_set("insert", "2.0")

# Generated at 2022-06-18 09:39:27.328051
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            print(
                "test failed: text=%r, index=%r, expected=%r, actual=%r"
                % (text, index, expected, actual)
            )

    # Test 1
    text = "a = b.c"
    index = "1.end"
    expected = "b.c"
    test(text, index, expected)

    # Test 2
    text = "a = b.c.d"
    index = "1.end"
    expected = "b.c.d"
    test(text, index, expected)

    # Test 3
    text = "a = b.c.d"

# Generated at 2022-06-18 09:39:28.718690
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("""
    def foo():
        pass
    """)
    assert rp.get_base_indent_string() == "    "


# Generated at 2022-06-18 09:39:34.357908
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            raise AssertionError(
                "get_expression returned %r instead of %r" % (actual, expected)
            )

    test("a.b.c", "1.0", "")
    test("a.b.c", "1.1", "a")
    test("a.b.c", "1.2", "a.")
    test("a.b.c", "1.3", "a.b")
    test("a.b.c", "1.4", "a.b.")
    test("a.b.c", "1.5", "a.b.c")

# Generated at 2022-06-18 09:39:39.812301
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import TestCase

    class Test(TestCase):
        def test_is_in_code(self):
            text = Text()
            text.insert("1.0", "a = 1\n")
            text.insert("2.0", 'b = "a"\n')
            text.insert("3.0", "c = 'a'\n")
            text.insert("4.0", "d = #a\n")
            text.insert("5.0", "e = 1 #a\n")
            text.insert("6.0", "f = 1 #a\n")
            text.insert("7.0", "g = 1 #a\n")
            text.insert("8.0", "h = 1 #a\n")

# Generated at 2022-06-18 09:41:52.940960
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:42:01.464141
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest

    class Test(unittest.TestCase):
        def test_set_index(self):
            text = Text()
            text.insert("1.0", "a = 1 + 2\n")
            text.insert("2.0", "b = 3 + 4\n")
            text.insert("3.0", "c = 5 + 6\n")
            text.insert("4.0", "d = 7 + 8\n")
            text.insert("5.0", "e = 9 + 10\n")
            text.insert("6.0", "f = 11 + 12\n")
            text.insert("7.0", "g = 13 + 14\n")
            text.insert("8.0", "h = 15 + 16\n")

# Generated at 2022-06-18 09:42:08.834759
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:42:18.656482
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:42:24.554166
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Test(TestCase):
        def test_set_index(self):
            from tkinter import Text

            text = Text()
            text.insert("insert", "def f(x):\n    return x + 1\n")
            text.mark_set("insert", "1.0")
            text.mark_gravity("insert", "left")

            hp = HyperParser(text, "insert")
            self.assertTrue(hp.is_in_code())
            self.assertFalse(hp.is_in_string())
            self.assertEqual(hp.get_expression(), "")

            hp.set_index("1.4")
            self.assertTrue(hp.is_in_code())
            self.assertFalse(hp.is_in_string())
            self.assertE