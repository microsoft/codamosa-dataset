

# Generated at 2022-06-18 09:35:54.173642
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # Test that set_index works as expected.
    # This test is not very good, because it doesn't test the
    # functionality of the class, but only that set_index works.
    # It is better than nothing, though.
    text = Text()
    text.insert("1.0", "a = 1 + 2\n")
    text.insert("2.0", "b = 3 + 4\n")
    text.insert("3.0", "c = 5 + 6\n")
    hp = HyperParser(text, "2.0")
    hp.set_index("2.0")
    assert hp.get_expression() == ""
    hp.set_index("2.1")
    assert hp.get_expression() == ""
    hp.set_index("2.2")

# Generated at 2022-06-18 09:36:04.667193
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo(0)
    assert rp.lo == 0
    rp.set_lo(1)
    assert rp.lo == 1
    rp.set_lo(2)
    assert rp.lo == 2
    rp.set_lo(3)
    assert rp.lo == 3
    rp.set_lo(4)
    assert rp.lo == 4
    rp.set_lo(5)
    assert rp.lo == 5
    rp.set_lo(6)
    assert rp.lo == 6
    rp.set_lo(7)
    assert rp.lo == 7
    rp.set_lo(8)
    assert rp.lo == 8
    rp.set_lo(9)


# Generated at 2022-06-18 09:36:14.791483
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser("if True:\n    pass\n")
    assert rp.is_block_opener()
    rp = RoughParser("if True:\n    pass")
    assert rp.is_block_opener()
    rp = RoughParser("if True:\n    pass\n# comment")
    assert rp.is_block_opener()
    rp = RoughParser("if True:\n    pass\n# comment\n")
    assert rp.is_block_opener()
    rp = RoughParser("if True:\n    pass\n# comment\n\n")
    assert rp.is_block_opener()
    rp = RoughParser("if True:\n    pass\n# comment\n\n\n")
    assert rp.is_block_opener()
   

# Generated at 2022-06-18 09:36:25.764898
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:36:37.119043
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-18 09:36:46.300527
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:36:57.050728
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Text()
    text.insert("1.0", "def f(x):\n" "    return x + 1\n")
    text.mark_set("insert", "1.0")
    text.see("insert")
    h = HyperParser(text, "insert")
    assert h.get_expression() == "x"
    assert h.get_surrounding_brackets() == ("1.9", "1.10")
    assert h.get_surrounding_brackets(mustclose=True) is None
    assert h.get_surrounding_brackets("x") is None
    assert h.get_surrounding_brackets("+") == ("1.7", "1.8")
    assert h.get_surrounding_brackets("+", mustclose=True) is None
    assert h

# Generated at 2022-06-18 09:37:07.602738
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:37:08.691960
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-18 09:37:20.015089
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-18 09:38:07.125461
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class Test(TestCase):
        def test_HyperParser(self):
            text = Text(None, "", "1.0")
            text.insert("1.0", "def f(x):\n    return x + 1\n")
            text.mark_set("insert", "1.0")
            text.see("insert")
            h = HyperParser(text, "insert")
            self.assertEqual(h.get_expression(), "x")
            text.mark_set("insert", "1.9")
            h = HyperParser(text, "insert")
            self.assertEqual(h.get_expression(), "")
            text.mark_set("insert", "1.10")
            h = HyperParser(text, "insert")

# Generated at 2022-06-18 09:38:17.799939
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:38:26.793109
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest


# Generated at 2022-06-18 09:38:31.896485
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def test_is_in_code(self):
            text = Text(
                """\
            # This is a comment
            if True:
                print("Hello world!")
            """
            )

# Generated at 2022-06-18 09:38:37.630149
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:38:42.468071
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-18 09:38:51.499192
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            # Test a simple case
            self.assertEqual(
                HyperParser(self.text, "1.0").get_surrounding_brackets(),
                ("1.0", "1.6"),
            )
            # Test a case where the index is at the end of the line
            self.assertEqual(
                HyperParser(self.text, "1.6").get_surrounding_brackets(),
                ("1.0", "1.6"),
            )
            # Test a case where the index is at the end of the line,
            # and mustclose is True

# Generated at 2022-06-18 09:39:02.087210
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-18 09:39:11.307925
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:39:20.208398
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class Test(unittest.TestCase):
        def test_get_expression(self):
            def check(text, index, expected):
                hp = HyperParser(text, index)
                self.assertEqual(hp.get_expression(), expected)

            check("a", "1.0", "")
            check("a", "1.1", "a")
            check("a.b", "1.2", "a.b")
            check("a.b", "1.3", "b")
            check("a.b.c", "1.4", "b.c")
            check("a.b.c", "1.5", "c")
            check("a.b.c", "1.6", "")

# Generated at 2022-06-18 09:40:15.141648
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-18 09:40:26.361166
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Test(TestCase):
        def test_set_index(self):
            from idlelib.idle_test.mock_idle import Func
            from idlelib.idle_test.mock_tk import Text

            text = Text()
            text.insert("1.0", "def f(x):\n    return x + 1\n")
            text.mark_set("insert", "1.0")
            text.see("insert")
            hp = HyperParser(text, "insert")
            hp.set_index("1.0")
            self.assertEqual(hp.indexinrawtext, 0)
            self.assertEqual(hp.indexbracket, 0)
            hp.set_index("1.4")

# Generated at 2022-06-18 09:40:36.393944
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-18 09:40:43.575980
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-18 09:40:53.594086
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            raise AssertionError(
                "HyperParser.get_expression(%r, %r) -> %r, expected %r"
                % (text, index, actual, expected)
            )

    test("", "1.0", "")
    test("a", "1.0", "a")
    test("a b", "1.1", "a")
    test("a b", "1.2", "b")
    test("a b", "1.3", "")
    test("a b", "2.0", "")
    test("a.b", "1.0", "")

# Generated at 2022-06-18 09:41:04.138142
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    rp = RoughParser("")
    assert rp.is_block_closer() == False
    rp = RoughParser("if True:")
    assert rp.is_block_closer() == False
    rp = RoughParser("if True:\n    pass")
    assert rp.is_block_closer() == False
    rp = RoughParser("if True:\n    pass\n")
    assert rp.is_block_closer() == False
    rp = RoughParser("if True:\n    pass\n\n")
    assert rp.is_block_closer() == False
    rp = RoughParser("if True:\n    pass\n\n\n")
    assert rp.is_block_closer() == False

# Generated at 2022-06-18 09:41:12.087741
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:41:17.906108
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:41:27.036017
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    rp = RoughParser("a = [1,\n2,\n3]")
    assert rp.get_last_stmt_bracketing() == ((0, 0), (3, 1), (5, 2), (7, 1), (9, 0))
    rp = RoughParser("a = [1,\n2,\n3]\n")
    assert rp.get_last_stmt_bracketing() == ((0, 0), (3, 1), (5, 2), (7, 1), (9, 0))
    rp = RoughParser("a = [1,\n2,\n3]\n\n")

# Generated at 2022-06-18 09:41:37.698755
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class Test(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = Text(
                """\
    def f(x):
        if x:
            if x:
                pass
            else:
                pass
        else:
            pass
    """
            )
            # Test the case where the index is inside a string
            hp = HyperParser(text, "1.0")
            self.assertEqual(hp.get_surrounding_brackets(), None)
            # Test the case where the index is inside a comment
            hp = HyperParser(text, "1.9")
            self.assertEqual(hp.get_surrounding_brackets(), None)
            # Test the case where the index is inside a code

# Generated at 2022-06-18 09:43:03.695341
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-18 09:43:12.133815
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    rp = RoughParser("if True:\n    pass\n")
    assert rp.get_last_open_bracket_pos() == 4
    rp = RoughParser("if True:\n    pass")
    assert rp.get_last_open_bracket_pos() == 4
    rp = RoughParser("if True:\n    pass\n# comment")
    assert rp.get_last_open_bracket_pos() == 4
    rp = RoughParser("if True:\n    pass\n# comment\n")
    assert rp.get_last_open_bracket_pos() == 4
    rp = RoughParser("if True:\n    pass\n# comment\n\n")
    assert rp.get_last_open_bracket_pos() == 4

# Generated at 2022-06-18 09:43:20.740742
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class Test(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = Text()
            text.insert("insert", "a = [1, 2, 3]")
            hp = HyperParser(text, "insert")
            self.assertEqual(hp.get_surrounding_brackets(), ("1.0", "1.end"))
            hp.set_index("1.3")
            self.assertEqual(hp.get_surrounding_brackets(), ("1.0", "1.end"))
            hp.set_index("1.4")
            self.assertEqual(hp.get_surrounding_brackets(), ("1.4", "1.end"))
            hp.set_index("1.5")
            self.assertE