

# Generated at 2022-06-18 09:34:32.387330
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def setUp(self):
            self.text = tkinter.Text()
            self.text.insert("insert", "a = 1\n")
            self.text.insert("insert", "def f(x):\n")
            self.text.insert("insert", "    return x + 1\n")
            self.text.insert("insert", "def g(x):\n")
            self.text.insert("insert", "    return x + 1\n")
            self.text.insert("insert", "def h(x):\n")
            self.text.insert("insert", "    return x + 1\n")
            self.text.insert("insert", "def i(x):\n")

# Generated at 2022-06-18 09:34:44.396635
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Test(TestCase):
        def test_set_index(self):
            from idlelib.idle_test.mock_idle import Func
            from idlelib.idle_test.mock_tk import Text

            text = Text()
            text.insert("1.0", "abc\n")
            text.insert("2.0", "def\n")
            text.insert("3.0", "ghi\n")
            text.insert("4.0", "jkl\n")
            text.insert("5.0", "mno\n")
            text.insert("6.0", "pqr\n")
            text.insert("7.0", "stu\n")
            text.insert("8.0", "vwx\n")
            text

# Generated at 2022-06-18 09:34:56.190552
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # Test is_in_code
    text = Text(None, "")
    text.insert("insert", "def f(x):\n    if x:\n        print(x)")
    hp = HyperParser(text, "insert")
    assert hp.is_in_code()
    hp.set_index("insert - 2 chars")
    assert hp.is_in_code()
    hp.set_index("insert - 1 chars")
    assert not hp.is_in_code()
    hp.set_index("insert + 1 chars")
    assert hp.is_in_code()
    hp.set_index("insert + 2 chars")
    assert hp.is_in_code()
    hp.set_index("insert + 3 chars")
    assert not hp.is_in_code()

# Generated at 2022-06-18 09:35:05.342442
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:35:09.961146
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.text = Text()
            self.text.insert("1.0", self.text_content)

        def test_get_surrounding_brackets(self):
            for index, expected in self.test_cases:
                hp = HyperParser(self.text, index)
                self.assertEqual(hp.get_surrounding_brackets(), expected)


# Generated at 2022-06-18 09:35:20.816276
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest


# Generated at 2022-06-18 09:35:31.745070
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            raise AssertionError(
                "For text %r and index %r, expected %r, got %r"
                % (text.get("1.0", "end"), index, expected, actual)
            )

    # Test 1
    text = Text()
    text.insert("1.0", "a.b.c")
    test(text, "1.2", "b")
    test(text, "1.3", "c")
    test(text, "1.4", "")

    # Test 2
    text = Text()
    text.insert("1.0", "a.b.c(d.e)")

# Generated at 2022-06-18 09:35:42.446997
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Test(TestCase):
        def test(self):
            text = Text()
            text.insert("1.0", "a b c")
            hp = HyperParser(text, "1.0")
            hp.set_index("1.0")
            self.assertEqual(hp.indexinrawtext, 0)
            self.assertEqual(hp.indexbracket, 0)
            hp.set_index("1.1")
            self.assertEqual(hp.indexinrawtext, 1)
            self.assertEqual(hp.indexbracket, 0)
            hp.set_index("1.2")
            self.assertEqual(hp.indexinrawtext, 2)
            self.assertEqual(hp.indexbracket, 0)
            hp.set_

# Generated at 2022-06-18 09:35:45.384384
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from idlelib.idle_test.htest import run

    run(HyperParser, "HyperParser")

if __name__ == "__main__":
    test_HyperParser_get_surrounding_brackets()

# Generated at 2022-06-18 09:35:49.462526
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:37:18.030740
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from unittest import TestCase

    class Test(TestCase):
        def test_get_surrounding_brackets(self):
            from idlelib.hyperparser import HyperParser

            def check(text, index, openers, mustclose, expected):
                hp = HyperParser(text, index)
                result = hp.get_surrounding_brackets(openers, mustclose)
                self.assertEqual(result, expected)

            text = Text(None, "")
            text.insert("1.0", "a(b)c")
            check(text, "1.0", "()", False, ("1.0", "1.3"))
            check(text, "1.1", "()", False, ("1.0", "1.3"))

# Generated at 2022-06-18 09:37:25.181222
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.is_in_string()
        if actual != expected:
            raise AssertionError(
                "HyperParser(%r, %r).is_in_string() -> %r, expected %r"
                % (text, index, actual, expected)
            )

    test("", "1.0", False)
    test("'", "1.0", True)
    test("'", "1.1", False)
    test("''", "1.1", True)
    test("''", "1.2", False)
    test("'a'", "1.2", True)
    test("'a'", "1.3", False)

# Generated at 2022-06-18 09:37:35.786203
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:37:38.921688
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from idlelib.idle_test.htest import run

    run(HyperParser, "HyperParser")


if __name__ == "__main__":
    test_HyperParser_get_surrounding_brackets()

# Generated at 2022-06-18 09:37:49.635296
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:38:00.668613
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def test_HyperParser(self):
            text = Text()
            text.insert("1.0", "a = (1 +\n" "      2 +\n" "      3)\n")
            text.mark_set("insert", "1.0")
            text.see("insert")
            hp = HyperParser(text, "insert")
            self.assertEqual(hp.get_expression(), "a")
            text.mark_set("insert", "1.10")
            hp = HyperParser(text, "insert")
            self.assertEqual(hp.get_expression(), "")
            text.mark_set("insert", "2.10")
            hp = HyperParser(text, "insert")

# Generated at 2022-06-18 09:38:11.105196
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:38:22.078198
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            print("Test failed for text %r, index %r" % (text, index))
            print("Expected %r, got %r" % (expected, actual))
            raise ValueError("Test failed")

    test("", "1.0", "")
    test(" ", "1.0", "")
    test("\n", "1.0", "")
    test("\t", "1.0", "")
    test("\t\n", "1.0", "")
    test("# comment", "1.0", "")
    test("# comment\n", "1.0", "")

# Generated at 2022-06-18 09:38:29.279226
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text()
    text.insert("1.0", "def f():\n    pass\n")
    text.insert("2.4", "'''")
    text.insert("2.7", '"""')
    text.insert("2.10", "#")
    text.insert("2.11", '"""')
    text.insert("2.14", "'''")
    text.insert("2.17", "    ")
    text.insert("2.21", "'''")
    text.insert("2.24", '"""')
    text.insert("2.27", "#")
    text.insert("2.28", '"""')
    text.insert("2.31", "'''")
    text.insert("2.34", "    ")
    text.insert("2.38", "#")


# Generated at 2022-06-18 09:38:34.830549
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text()
    text.insert("1.0", "def f(x):\n  pass\n")
    hp = HyperParser(text, "1.0")
    assert hp.is_in_code()
    hp = HyperParser(text, "1.4")
    assert hp.is_in_code()
    hp = HyperParser(text, "1.5")
    assert not hp.is_in_code()
    hp = HyperParser(text, "2.0")
    assert hp.is_in_code()
    hp = HyperParser(text, "2.3")
    assert hp.is_in_code()
    hp = HyperParser(text, "2.4")
    assert not hp.is_in_code()
    hp = HyperParser(text, "2.5")
    assert not hp

# Generated at 2022-06-18 09:41:01.162921
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def check(s, expected):
        parser = RoughParser(s, 0)
        assert parser.get_base_indent_string() == expected

    check("", "")
    check("\n", "")
    check("\n\n", "")
    check("\n\n\n", "")
    check("\n\n\n\n", "")
    check("\n\n\n\n\n", "")
    check("\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n\n\n", "")

# Generated at 2022-06-18 09:41:09.744106
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text(None, "")
    text.insert("insert", "if True:\n    pass\n")
    hp = HyperParser(text, "insert")
    assert hp.is_in_code()
    text.insert("insert", "#")
    hp = HyperParser(text, "insert")
    assert not hp.is_in_code()
    text.insert("insert", "if True:\n    pass\n")
    hp = HyperParser(text, "insert")
    assert not hp.is_in_code()
    text.insert("insert", "if True:\n    pass\n")
    hp = HyperParser(text, "insert")
    assert hp.is_in_code()
    text.insert("insert", '"')
    hp = HyperParser(text, "insert")
    assert not hp.is_in

# Generated at 2022-06-18 09:41:14.984949
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:41:22.357581
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest


# Generated at 2022-06-18 09:41:31.666833
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:41:42.963687
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    text.insert("insert", "a = 1 + 2\n")
    text.insert("insert", "b = 3 + 4\n")
    text.insert("insert", "c = 5 + 6\n")
    text.insert("insert", "d = 7 + 8\n")
    text.insert("insert", "e = 9 + 10\n")
    text.insert("insert", "f = 11 + 12\n")
    text.insert("insert", "g = 13 + 14\n")
    text.insert("insert", "h = 15 + 16\n")
    text.insert("insert", "i = 17 + 18\n")
    text.insert("insert", "j = 19 + 20\n")
    text.insert("insert", "k = 21 + 22\n")

# Generated at 2022-06-18 09:41:50.120526
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = "a = 1\n"
    hp = HyperParser(text, "1.0")
    assert hp.is_in_code()
    hp.set_index("1.1")
    assert hp.is_in_code()
    hp.set_index("1.2")
    assert hp.is_in_code()
    hp.set_index("1.3")
    assert not hp.is_in_code()
    text = "a = 1 # comment\n"
    hp = HyperParser(text, "1.0")
    assert hp.is_in_code()
    hp.set_index("1.1")
    assert hp.is_in_code()
    hp.set_index("1.2")
    assert hp.is_in_code()

# Generated at 2022-06-18 09:42:00.276996
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:42:07.733522
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:42:08.527816
# Unit test for method is_in_string of class HyperParser