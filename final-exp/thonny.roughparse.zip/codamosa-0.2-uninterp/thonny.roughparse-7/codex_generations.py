

# Generated at 2022-06-18 09:36:02.431832
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:36:12.454928
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:36:24.072614
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:36:35.132918
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-18 09:36:41.653106
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest


# Generated at 2022-06-18 09:36:52.497905
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Text()
    text.insert("1.0", "def f(x):\n" "    return x + 1\n")
    text.mark_set("insert", "1.0")
    hp = HyperParser(text, "insert")
    assert hp.rawtext == "def f(x):\n    return x + 1"
    assert hp.stopatindex == "2.0"

# Generated at 2022-06-18 09:37:02.225034
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import TestCase

    class Test(TestCase):
        def test_is_in_code(self):
            text = Text()
            text.insert("1.0", "a = 1\n")
            text.insert("2.0", "b = 2\n")
            text.insert("3.0", "c = 3\n")
            text.insert("4.0", "d = 4\n")
            text.insert("5.0", "e = 5\n")
            text.insert("6.0", "f = 6\n")
            text.insert("7.0", "g = 7\n")
            text.insert("8.0", "h = 8\n")
            text.insert("9.0", "i = 9\n")

# Generated at 2022-06-18 09:37:14.250880
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-18 09:37:23.361878
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_expression(self):
            def check(text, index, expected):
                hp = HyperParser(text, index)
                self.assertEqual(hp.get_expression(), expected)

            check("", "1.0", "")
            check("a", "1.0", "a")
            check("a b", "1.1", "a")
            check("a b", "1.2", "b")
            check("a.b", "1.2", "a.b")
            check("a.b", "1.3", "b")
            check("a.b()", "1.4", "b()")
            check("a.b()", "1.5", "")

# Generated at 2022-06-18 09:37:34.492833
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:39:31.378955
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-18 09:39:36.890797
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:39:42.208818
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:39:47.426066
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-18 09:39:53.020408
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    text.insert("1.0", "a = 3\n")
    text.insert("2.0", "b = 4\n")
    text.insert("3.0", "c = 5\n")
    text.insert("4.0", "d = 6\n")
    text.insert("5.0", "e = 7\n")
    text.insert("6.0", "f = 8\n")
    text.insert("7.0", "g = 9\n")
    text.insert("8.0", "h = 10\n")
    text.insert("9.0", "i = 11\n")
    text.insert("10.0", "j = 12\n")
    text.insert("11.0", "k = 13\n")

# Generated at 2022-06-18 09:39:59.444950
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Test(TestCase):
        def test_set_index(self):
            from idlelib.idle_test.mock_idle import Func
            from idlelib.idle_test.mock_tk import Text

            text = Text()
            text.insert("1.0", "def f(x):\n    return x+1\n")
            text.mark_set("insert", "1.0")
            hp = HyperParser(text, "insert")
            self.assertEqual(hp.rawtext, "def f(x):\n    return x+1")
            self.assertEqual(hp.stopatindex, "2.end")

# Generated at 2022-06-18 09:40:09.542953
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    assert RoughParser("").get_base_indent_string() == ""
    assert RoughParser(" ").get_base_indent_string() == " "
    assert RoughParser("  ").get_base_indent_string() == "  "
    assert RoughParser("\t").get_base_indent_string() == "\t"
    assert RoughParser("\t\t").get_base_indent_string() == "\t\t"
    assert RoughParser("\n").get_base_indent_string() == ""
    assert RoughParser("\n\n").get_base_indent_string() == ""
    assert RoughParser(" \n").get_base_indent_string() == ""
    assert RoughParser("  \n").get_base_indent_string() == ""

# Generated at 2022-06-18 09:40:19.872071
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:40:29.690089
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:40:39.717609
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest
