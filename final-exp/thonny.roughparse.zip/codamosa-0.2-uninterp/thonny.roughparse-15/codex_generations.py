

# Generated at 2022-06-18 09:35:04.215887
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-18 09:35:10.978203
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:35:21.861708
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-18 09:35:32.788254
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text(None, "")
    text.insert("1.0", "a\n")
    text.insert("2.0", "b\n")
    text.insert("3.0", "c\n")
    text.insert("4.0", "d\n")
    text.insert("5.0", "e\n")
    text.insert("6.0", "f\n")
    text.insert("7.0", "g\n")
    text.insert("8.0", "h\n")
    text.insert("9.0", "i\n")
    text.insert("10.0", "j\n")
    text.insert("11.0", "k\n")
    text.insert("12.0", "l\n")

# Generated at 2022-06-18 09:35:43.574435
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    # pylint: disable=redefined-builtin
    def test(s, expected):
        rp = RoughParser(s, indent_width=4, tabwidth=8)
        assert rp.compute_bracket_indent() == expected

    test("[\n", 4)
    test("[\n    ", 8)
    test("[\n        ", 12)
    test("[\n    x", 8)
    test("[\n    x,\n", 8)
    test("[\n    x,\n    ", 12)
    test("[\n    x,\n    y", 12)
    test("[\n    x,\n    y,\n", 12)
    test("[\n    x,\n    y,\n    ", 16)

# Generated at 2022-06-18 09:35:47.738840
# Unit test for constructor of class HyperParser
def test_HyperParser():
    class Text:
        def __init__(self, text):
            self.text = text

        def get(self, start, end):
            return self.text[int(start) : int(end)]

        def index(self, index):
            return index


# Generated at 2022-06-18 09:35:58.831295
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:36:09.365629
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:36:20.676385
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(code, index, expected):
        hp = HyperParser(code, index)
        actual = hp.get_expression()
        if actual != expected:
            print(
                "Error: get_expression returned %r for code %r, index %r"
                % (actual, code, index)
            )

    test("a", "1.0", "a")
    test("a", "1.1", "")
    test("a.b", "1.2", "a.b")
    test("a.b", "1.3", "b")
    test("a.b", "1.4", "")
    test("a.b()", "1.5", "b")
    test("a.b()", "1.6", "")

# Generated at 2022-06-18 09:36:27.994180
# Unit test for method get_last_open_bracket_pos of class RoughParser

# Generated at 2022-06-18 09:37:19.701193
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    def check(s, expected):
        rp = RoughParser(s, indent_width=4, tabwidth=8)
        actual = rp.get_last_stmt_bracketing()
        assert actual == expected, (actual, expected)

    check("", None)
    check("\n", None)
    check("\n\n", None)
    check("\n\n\n", None)
    check("\n\n\n\n", None)
    check("a", ((0, 0), (1, 0)))
    check("a\n", ((0, 0), (1, 0)))
    check("a\n\n", ((0, 0), (1, 0)))
    check("a\n\n\n", ((0, 0), (1, 0)))

# Generated at 2022-06-18 09:37:31.772273
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:37:39.076925
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_expression(self):
            def test(text, index, expected):
                hp = HyperParser(text, index)
                self.assertEqual(hp.get_expression(), expected)

            test("a.b", "1.0", "")
            test("a.b", "1.1", "a")
            test("a.b", "1.2", "a.")
            test("a.b", "1.3", "a.b")
            test("a.b", "1.4", "a.b")
            test("a.b", "2.0", "a.b")
            test("a.b", "2.1", "a.b")

# Generated at 2022-06-18 09:37:49.857033
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import TestCase

    class Test(TestCase):
        def test_is_in_code(self):
            text = Text()
            text.insert("1.0", "a = 1\n")
            text.insert("2.0", 'b = "abc"\n')
            text.insert("3.0", "c = 'def'\n")
            text.insert("4.0", "d = '''ghi'''\n")
            text.insert("5.0", 'e = """jkl"""\n')
            text.insert("6.0", "f = 1 # comment\n")
            text.insert("7.0", "g = 1 + 2\n")
            text.insert("8.0", "h = (1, 2)\n")

# Generated at 2022-06-18 09:38:00.933455
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def test_set_index(self):
            text = Text()
            text.insert("1.0", "a = [1, 2, 3]")
            hp = HyperParser(text, "1.0")
            hp.set_index("1.0")
            self.assertEqual(hp.indexinrawtext, 0)
            self.assertEqual(hp.indexbracket, 0)
            hp.set_index("1.1")
            self.assertEqual(hp.indexinrawtext, 1)
            self.assertEqual(hp.indexbracket, 0)
            hp.set_index("1.2")
            self.assertEqual(hp.indexinrawtext, 2)

# Generated at 2022-06-18 09:38:11.398017
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:38:22.339582
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class Test(TestCase):
        def test_HyperParser(self):
            text = Text()
            text.insert("1.0", "def f(x):\n" "    return x + 1\n")
            text.insert("2.0", "# comment\n")
            text.insert("3.0", "a = f(3)\n")
            text.insert("4.0", "b = f(4)\n")
            text.insert("5.0", "c = f(5)\n")
            text.insert("6.0", "d = f(6)\n")
            text.insert("7.0", "e = f(7)\n")
            text.insert("8.0", "f = f(8)\n")

# Generated at 2022-06-18 09:38:29.501840
# Unit test for method is_block_opener of class RoughParser

# Generated at 2022-06-18 09:38:35.061664
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = "abc"
    index = "1.0"
    hp = HyperParser(text, index)
    assert hp.is_in_code()
    text = "abc"
    index = "1.0"
    hp = HyperParser(text, index)
    assert hp.is_in_code()
    text = "abc"
    index = "1.0"
    hp = HyperParser(text, index)
    assert hp.is_in_code()
    text = "abc"
    index = "1.0"
    hp = HyperParser(text, index)
    assert hp.is_in_code()
    text = "abc"
    index = "1.0"
    hp = HyperParser(text, index)
    assert hp.is_in_code()
    text = "abc"
    index

# Generated at 2022-06-18 09:38:40.603112
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:40:10.612766
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:40:20.988359
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-18 09:40:30.880919
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    # Test is_in_code
    text = Text()
    text.insert("insert", "if True:\n    pass\n")
    text.mark_set("insert", "1.0")
    hp = HyperParser(text, "insert")
    assert hp.is_in_code()
    text.mark_set("insert", "1.4")
    hp.set_index("insert")
    assert not hp.is_in_code()
    text.mark_set("insert", "1.5")
    hp.set_index("insert")
    assert hp.is_in_code()
    text.mark_set("insert", "2.4")
    hp.set_index("insert")
    assert hp.is_in_code()
    text.mark_set("insert", "2.5")
    hp.set

# Generated at 2022-06-18 09:40:40.596472
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    rp = RoughParser("""
    if True:
        pass
    else:
        pass
    """)
    assert rp.is_block_closer() == True
    rp = RoughParser("""
    if True:
        pass
    elif True:
        pass
    else:
        pass
    """)
    assert rp.is_block_closer() == True
    rp = RoughParser("""
    if True:
        pass
    elif True:
        pass
    else:
        pass
    """)
    assert rp.is_block_closer() == True
    rp = RoughParser("""
    if True:
        pass
    elif True:
        pass
    else:
        pass
    """)
    assert rp.is_block_closer() == True


# Generated at 2022-06-18 09:40:51.669935
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def test_is_in_code(self):
            text = Text()
            text.insert("1.0", "a = 1")
            parser = HyperParser(text, "1.0")
            self.assertTrue(parser.is_in_code())
            parser = HyperParser(text, "1.1")
            self.assertTrue(parser.is_in_code())
            parser = HyperParser(text, "1.2")
            self.assertTrue(parser.is_in_code())
            parser = HyperParser(text, "1.3")
            self.assertTrue(parser.is_in_code())
            parser = HyperParser(text, "1.4")
            self.assertTrue(parser.is_in_code())
           

# Generated at 2022-06-18 09:41:02.107302
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Text()
    text.insert("1.0", "def f(x):\n    return x + 1\n")
    text.mark_set("insert", "1.0")
    text.see("insert")
    text.update()
    hp = HyperParser(text, "insert")
    assert hp.rawtext == "def f(x):\n    return x + 1\n"
    assert hp.stopatindex == "2.end"

# Generated at 2022-06-18 09:41:10.477921
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def test_set_index(self):
            text = Text()
            text.insert("1.0", "a = 1\n")
            text.insert("2.0", "b = 2\n")
            text.insert("3.0", "c = 3\n")
            text.insert("4.0", "d = 4\n")
            text.insert("5.0", "e = 5\n")
            text.insert("6.0", "f = 6\n")
            text.insert("7.0", "g = 7\n")
            text.insert("8.0", "h = 8\n")
            text.insert("9.0", "i = 9\n")

# Generated at 2022-06-18 09:41:15.898805
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:41:22.208495
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("a = 1\nb = 2\n")
    assert rp.str == "a = 1\nb = 2\n"
    assert rp.goodlines == [0, 5, 10]
    assert rp.continuation == C_NONE
    assert rp.study_level == 1
    assert rp.stmt_start == 0
    assert rp.stmt_end == 0
    assert rp.lastch == ""
    assert rp.lastopenbracketpos is None
    assert rp.stmt_bracketing is None


# Generated at 2022-06-18 09:41:31.454806
# Unit test for method compute_bracket_indent of class RoughParser