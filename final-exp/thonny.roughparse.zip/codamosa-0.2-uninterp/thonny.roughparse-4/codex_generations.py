

# Generated at 2022-06-18 09:34:39.640676
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:34:51.486481
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = tk.Text()
    text.insert("insert", "abc 'def' ghi")
    hp = HyperParser(text, "insert")
    assert hp.is_in_string()
    text.insert("insert", "jkl")
    hp.set_index("insert")
    assert not hp.is_in_string()
    text.insert("insert", "mno")
    hp.set_index("insert")
    assert not hp.is_in_string()
    text.insert("insert", "pqr")
    hp.set_index("insert")
    assert not hp.is_in_string()
    text.insert("insert", "stu")
    hp.set_index("insert")
    assert not hp.is_in_string()
    text.insert("insert", "vwx")
    hp

# Generated at 2022-06-18 09:35:01.658239
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:35:09.402997
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    def check(s, expected):
        rp = RoughParser(s, "", 0)
        actual = rp.find_good_parse_start()
        if actual != expected:
            print("%r -> %r, expected %r" % (s, actual, expected))

    check("", 0)
    check("\n", 1)
    check("\n\n", 2)
    check("\n\n\n", 3)
    check("\n\n\n\n", 4)
    check("\n\n\n\n\n", 5)
    check("\n\n\n\n\n\n", 6)
    check("\n\n\n\n\n\n\n", 7)

# Generated at 2022-06-18 09:35:20.472937
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:35:30.978118
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            print("test failed:")
            print("text:", repr(text))
            print("index:", index)
            print("expected:", repr(expected))
            print("actual:", repr(actual))

    test("", "1.0", "")
    test("#", "1.0", "")
    test("#", "1.1", "")
    test("a", "1.0", "")
    test("a", "1.1", "a")
    test("a b", "1.2", "b")
    test("a b", "1.3", "")
    test("a b", "1.4", "")
    test

# Generated at 2022-06-18 09:35:34.528514
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    def check(s, expected):
        rp = RoughParser(s)
        actual = rp.get_num_lines_in_stmt()
        assert actual == expected, (actual, expected)


# Generated at 2022-06-18 09:35:45.385093
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class Test(TestCase):
        def test_HyperParser(self):
            text = Text(None, "", "1.0")
            text.insert("1.0", "def f(x, y):\n" "    return x + y\n")
            text.mark_set("insert", "1.0")
            hp = HyperParser(text, "insert")
            self.assertEqual(hp.get_expression(), "y")
            text.insert("insert", " ")
            hp.set_index("insert")
            self.assertEqual(hp.get_expression(), "")
            text.insert("insert", " ")
            hp.set_index("insert")
            self.assertEqual(hp.get_expression(), "")

# Generated at 2022-06-18 09:35:56.672485
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:36:07.185821
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:37:02.851013
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-18 09:37:14.688227
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            print("%r\n%s\n%r != %r" % (text, index, actual, expected))

    test("a", "1.0", "")
    test("a", "1.1", "a")
    test("a ", "1.2", "a")
    test("a b", "1.3", "b")
    test("a b", "1.2", "a")
    test("a b", "1.1", "")
    test("a b", "1.0", "")
    test("a b", "2.0", "")
    test("a b", "2.1", "b")

# Generated at 2022-06-18 09:37:23.669959
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            raise AssertionError(
                "HyperParser.get_expression(%r, %r) -> %r, expected %r"
                % (text, index, actual, expected)
            )

    test("", "1.0", "")
    test("a", "1.0", "a")
    test("a b", "1.1", "a")
    test("a b", "1.2", "b")
    test("a b", "1.3", "")
    test("a b", "2.0", "")
    test("a b", "2.1", "")
    test("a b", "2.2", "")
   

# Generated at 2022-06-18 09:37:34.691390
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def setUp(self):
            self.text = Text()
            self.text.insert("1.0", "a = 1\n")
            self.text.insert("2.0", "b = 2\n")
            self.text.insert("3.0", "c = 3\n")
            self.text.insert("4.0", "d = 4\n")

        def test_get_expression(self):
            self.assertEqual(HyperParser(self.text, "1.0").get_expression(), "")
            self.assertEqual(HyperParser(self.text, "1.1").get_expression(), "a")

# Generated at 2022-06-18 09:37:44.711187
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_expression(self):
            def test(text, index, expected):
                hp = HyperParser(text, index)
                self.assertEqual(hp.get_expression(), expected)

            test("a", "1.0", "")
            test("a", "1.1", "a")
            test("a.b", "1.1", "a")
            test("a.b", "1.2", "a.b")
            test("a.b", "1.3", "a.b")
            test("a.b()", "1.3", "a.b")
            test("a.b()", "1.4", "a.b()")

# Generated at 2022-06-18 09:37:55.331130
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def check(s, expected):
        parser = RoughParser(s, 0)
        actual = parser.get_base_indent_string()
        assert actual == expected, "expected %r, got %r" % (expected, actual)

    check("", "")
    check("\n", "")
    check("\n\n", "")
    check("\n\n\n", "")
    check("\n\n\n\n", "")
    check("\n\n\n\n\n", "")
    check("\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n\n", "")

# Generated at 2022-06-18 09:38:06.525109
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    def test(s, expected):
        rp = RoughParser(s)
        actual = rp.compute_backslash_indent()
        if actual != expected:
            print("FAIL:", repr(s))
            print("  expected:", expected)
            print("       got:", actual)
        else:
            print("OK:", repr(s))

    test("a = 1 + \\\n       2", 9)
    test("a = 1 + \\\n       2 + \\\n       3", 9)
    test("a = 1 + \\\n       2 + \\\n       3 + \\\n       4", 9)

# Generated at 2022-06-18 09:38:16.937464
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def test_get_expression(self):
            def check(text, index, expected):
                self.assertEqual(HyperParser(text, index).get_expression(), expected)

            check("a", "1.0", "a")
            check("a", "1.1", "")
            check("a b", "1.1", "a")
            check("a b", "1.2", "")
            check("a.b", "1.2", "a.b")
            check("a.b", "1.3", "")
            check("a.b", "1.1", "a")
            check("a.b", "1.0", "a")
            check("a.b", "2.0", "")
           

# Generated at 2022-06-18 09:38:26.305051
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:38:31.861508
# Unit test for method compute_bracket_indent of class RoughParser
def test_RoughParser_compute_bracket_indent():
    def check(text, expected):
        rp = RoughParser(text)
        actual = rp.compute_bracket_indent()
        if actual != expected:
            print("FAIL: expected %d, got %d" % (expected, actual))
            print("   text: %r" % text)
            print("   lastopenbracketpos: %r" % rp.lastopenbracketpos)
            print("   stmt_bracketing: %r" % rp.stmt_bracketing)
            print("   lastch: %r" % rp.lastch)
            print("   continuation: %r" % rp.continuation)
            print("   goodlines: %r" % rp.goodlines)

# Generated at 2022-06-18 09:39:49.497304
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    from unittest import TestCase


# Generated at 2022-06-18 09:39:55.227062
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-18 09:40:03.977156
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-18 09:40:13.223624
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from unittest import TestCase


# Generated at 2022-06-18 09:40:24.400544
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:40:34.461642
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class TestCase(unittest.TestCase):
        def __init__(self, text, index, expected):
            unittest.TestCase.__init__(self)
            self.text = text
            self.index = index
            self.expected = expected

        def runTest(self):
            hp = HyperParser(self.text, self.index)
            self.assertEqual(hp.get_expression(), self.expected)

    def make_test(text, index, expected):
        return TestCase(text, index, expected)

    suite = unittest.TestSuite()
    suite.addTest(make_test("a.b.c", "1.0", "c"))
    suite.addTest(make_test("a.b.c", "1.2", "c"))
   

# Generated at 2022-06-18 09:40:42.334368
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    def foo():\n        pass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n        pass")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n        pass\n    ")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n        pass\n    \n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n        pass\n    \n    ")
    assert rp.get_base_indent_string() == "    "
   

# Generated at 2022-06-18 09:40:53.126437
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:41:03.594394
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def setUp(self):
            self.text = Text()
            self.text.insert("1.0", "a = (1 + 2) * 3\n")
            self.text.insert("2.0", "b = [1 + 2] * 3\n")
            self.text.insert("3.0", "c = {1 + 2} * 3\n")
            self.text.insert("4.0", "d = '1 + 2' * 3\n")
            self.text.insert("5.0", "e = \"1 + 2\" * 3\n")
            self.text.insert("6.0", "f = r'1 + 2' * 3\n")

# Generated at 2022-06-18 09:41:11.674552
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:42:43.662206
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = Text()
            text.insert("1.0", "a = (1, 2, 3)")
            hp = HyperParser(text, "1.0")
            self.assertEqual(hp.get_surrounding_brackets(), ("1.0", "1.13"))
            hp = HyperParser(text, "1.4")
            self.assertEqual(hp.get_surrounding_brackets(), ("1.0", "1.13"))
            hp = HyperParser(text, "1.5")
            self.assertEqual(hp.get_surrounding_brackets(), ("1.4", "1.13"))

# Generated at 2022-06-18 09:42:51.759033
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        if hp.is_in_code():
            expr = hp.get_expression()
            if expr != expected:
                print(
                    "Error: text=%r, index=%r, expected=%r, got=%r"
                    % (text, index, expected, expr)
                )
                return False
        else:
            print("Error: text=%r, index=%r, expected=%r, got=not in code" % (text, index, expected))
            return False
        return True

    assert test("", "1.0", "")
    assert test("a", "1.0", "a")
    assert test("a", "1.1", "")

# Generated at 2022-06-18 09:43:01.106468
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:43:08.580520
# Unit test for method find_good_parse_start of class RoughParser