

# Generated at 2022-06-18 09:33:56.590735
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:34:06.328127
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("if 1:")
    assert rp.get_continuation_type() == C_NONE
    assert rp.get_num_lines_in_stmt() == 1
    assert rp.get_base_indent_string() == ""
    assert rp.is_block_opener()
    assert not rp.is_block_closer()
    assert rp.get_last_open_bracket_pos() is None
    assert rp.get_last_stmt_bracketing() == ((0, 0), (4, 0))

    rp.set_lo("if 1:\\")
    assert rp.get_continuation_type() == C_BACKSLASH

# Generated at 2022-06-18 09:34:15.593641
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Text()
    text.insert("1.0", "def f(x):\n    return x+1\n")
    text.mark_set("insert", "1.0")
    hp = HyperParser(text, "insert")
    assert hp.get_expression() == "x"
    text.insert("insert", " ")
    assert hp.get_expression() == "x"
    text.insert("insert", " ")
    assert hp.get_expression() == "x"
    text.insert("insert", " ")
    assert hp.get_expression() == "x"
    text.insert("insert", " ")
    assert hp.get_expression() == "x"
    text.insert("insert", " ")
    assert hp.get_expression() == "x"

# Generated at 2022-06-18 09:34:25.746556
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text()
    text.insert("1.0", "a = '''\nabc\n'''\n")
    text.insert("2.0", "b = '''\nabc\n'''\n")
    text.insert("3.0", "c = '''\nabc\n'''\n")
    text.insert("4.0", "d = '''\nabc\n'''\n")
    text.insert("5.0", "e = '''\nabc\n'''\n")
    text.insert("6.0", "f = '''\nabc\n'''\n")
    text.insert("7.0", "g = '''\nabc\n'''\n")

# Generated at 2022-06-18 09:34:37.054788
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def setUp(self):
            self.text = Text()
            self.text.insert("1.0", "if 1:\n    pass\n")
            self.text.mark_set("insert", "1.0")
            self.text.see("insert")

        def test_get_expression(self):
            self.assertEqual(HyperParser(self.text, "1.0").get_expression(), "")
            self.assertEqual(HyperParser(self.text, "1.4").get_expression(), "1")
            self.assertEqual(HyperParser(self.text, "1.5").get_expression(), "")
            self.assertEqual(HyperParser(self.text, "1.6").get_expression(), "")

# Generated at 2022-06-18 09:34:49.064056
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:34:59.861578
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:35:07.991189
# Unit test for method set_lo of class RoughParser

# Generated at 2022-06-18 09:35:09.316727
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()

# Generated at 2022-06-18 09:35:20.470764
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            raise AssertionError(
                "HyperParser.get_expression(%r, %r) -> %r, expected %r"
                % (text, index, actual, expected)
            )

    test("", "1.0", "")
    test("a", "1.0", "a")
    test("a ", "1.1", "a")
    test("a ", "1.0", "")
    test("a b", "1.2", "b")
    test("a b", "1.1", "a")
    test("a b", "1.0", "")
    test("a.b", "1.2", "b")


# Generated at 2022-06-18 09:36:10.249272
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    assert RoughParser("").is_block_closer() == False
    assert RoughParser("return").is_block_closer() == False
    assert RoughParser("return 1").is_block_closer() == False
    assert RoughParser("return 1\n").is_block_closer() == False
    assert RoughParser("return 1\n\n").is_block_closer() == False
    assert RoughParser("return 1\n\n\n").is_block_closer() == False
    assert RoughParser("return 1\n\n\n\n").is_block_closer() == False
    assert RoughParser("return 1\n\n\n\n\n").is_block_closer() == False

# Generated at 2022-06-18 09:36:15.393289
# Unit test for constructor of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"



# Generated at 2022-06-18 09:36:26.111001
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-18 09:36:37.166592
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:36:46.342550
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def test_get_expression(self):
            text = "a.b.c.d.e.f"
            hp = HyperParser(text, "1.0")
            self.assertEqual(hp.get_expression(), "a.b.c.d.e.f")
            hp.set_index("1.1")
            self.assertEqual(hp.get_expression(), "a.b.c.d.e.f")
            hp.set_index("1.2")
            self.assertEqual(hp.get_expression(), "a.b.c.d.e")
            hp.set_index("1.3")
            self.assertEqual(hp.get_expression(), "a.b.c.d")

# Generated at 2022-06-18 09:36:52.204808
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'


# Generated at 2022-06-18 09:37:01.849423
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest
    import unittest.mock

    class TestCase(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = unittest.mock.Mock(spec_set=tkinter.Text)
            text.index.side_effect = lambda index: index
            text.get.side_effect = lambda start, stop: start + " " + stop
            text.indent_width = 4
            text.tabwidth = 8

            def test(text, index, expected):
                hp = HyperParser(text, index)
                self.assertEqual(hp.get_surrounding_brackets(), expected)

            test(text, "1.0", None)
            test(text, "1.1", None)

# Generated at 2022-06-18 09:37:08.221498
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"



# Generated at 2022-06-18 09:37:19.661309
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:37:31.725894
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = "'''\n" + "'''\n" + "'''\n"
    hp = HyperParser(text, "2.0")
    assert hp.is_in_string()
    hp = HyperParser(text, "2.1")
    assert hp.is_in_string()
    hp = HyperParser(text, "2.2")
    assert hp.is_in_string()
    hp = HyperParser(text, "2.3")
    assert not hp.is_in_string()
    hp = HyperParser(text, "2.4")
    assert not hp.is_in_string()
    hp = HyperParser(text, "2.5")
    assert not hp.is_in_string()
    hp = HyperParser(text, "2.6")
    assert not hp.is_in