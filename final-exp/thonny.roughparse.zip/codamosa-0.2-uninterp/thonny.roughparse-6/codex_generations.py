

# Generated at 2022-06-18 09:34:53.598889
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_expression(self):
            def check(text, index, expected):
                hp = HyperParser(text, index)
                self.assertEqual(hp.get_expression(), expected)

            check("a", "1.0", "")
            check("a", "1.1", "a")
            check("a.b", "1.1", "a")
            check("a.b", "1.2", "a.b")
            check("a.b", "1.3", "a.b")
            check("a.b()", "1.3", "a.b")
            check("a.b()", "1.4", "a.b()")

# Generated at 2022-06-18 09:35:03.464286
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Text()
    text.insert("1.0", "a = (1 + 2 +\n" "      3 + 4 +\n" "      5 + 6 +\n" "      7 + 8)\n")
    text.mark_set("insert", "1.0")
    text.see("insert")
    hp = HyperParser(text, "insert")
    assert hp.get_expression() == "8"
    assert hp.get_surrounding_brackets() == ("1.23", "1.25")
    assert hp.get_surrounding_brackets(mustclose=True) == ("1.23", "1.25")
    assert hp.get_surrounding_brackets("+-") == ("1.23", "1.25")

# Generated at 2022-06-18 09:35:10.498403
# Unit test for method is_block_closer of class RoughParser
def test_RoughParser_is_block_closer():
    rp = RoughParser("if True: pass\n")
    assert rp.is_block_closer()
    rp = RoughParser("if True: pass")
    assert not rp.is_block_closer()
    rp = RoughParser("if True:\n    pass\n")
    assert rp.is_block_closer()
    rp = RoughParser("if True:\n    pass")
    assert not rp.is_block_closer()
    rp = RoughParser("if True:\n    pass\n# comment\n")
    assert rp.is_block_closer()
    rp = RoughParser("if True:\n    pass\n# comment")
    assert not rp.is_block_closer()

# Generated at 2022-06-18 09:35:21.396104
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Tkinter.Text()
    text.insert("insert", "def foo(x):\n    if x:\n        pass\n")
    text.mark_set("insert", "1.0")
    hp = HyperParser(text, "insert")
    assert hp.is_in_code()
    text.mark_set("insert", "1.4")
    hp.set_index("insert")
    assert hp.is_in_code()
    text.mark_set("insert", "1.5")
    hp.set_index("insert")
    assert not hp.is_in_code()
    text.mark_set("insert", "1.6")
    hp.set_index("insert")
    assert hp.is_in_code()
    text.mark_set("insert", "2.0")
   

# Generated at 2022-06-18 09:35:32.401909
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Text()
    text.insert("1.0", "foo = 'bar'")
    hp = HyperParser(text, "1.0")
    assert hp.is_in_string()
    hp.set_index("1.4")
    assert not hp.is_in_string()
    hp.set_index("1.5")
    assert hp.is_in_string()
    hp.set_index("1.6")
    assert hp.is_in_string()
    hp.set_index("1.7")
    assert not hp.is_in_string()
    hp.set_index("1.8")
    assert not hp.is_in_string()
    text.insert("1.8", "'")
    hp.set_index("1.9")
    assert hp.is_in_string

# Generated at 2022-06-18 09:35:43.018163
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def test_set_index(self):
            text = Text()
            text.insert("1.0", "a = (1, 2, 3)")
            hp = HyperParser(text, "1.0")
            self.assertEqual(hp.get_expression(), "")
            hp.set_index("1.4")
            self.assertEqual(hp.get_expression(), "a")
            hp.set_index("1.5")
            self.assertEqual(hp.get_expression(), "")
            hp.set_index("1.6")
            self.assertEqual(hp.get_expression(), "")
            hp.set_index("1.7")

# Generated at 2022-06-18 09:35:54.045462
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_expression(self):
            def check(text, index, expected):
                hp = HyperParser(text, index)
                self.assertEqual(hp.get_expression(), expected)

            # Test that get_expression works for all possible
            # combinations of whitespace, comments and dots.
            check("a.b.c", "1.0", "a.b.c")
            check("a.b.c", "1.1", "b.c")
            check("a.b.c", "1.2", "c")
            check("a.b.c", "1.3", "")
            check("a.b.c", "1.4", "")

# Generated at 2022-06-18 09:36:04.544175
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-18 09:36:14.706692
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:36:25.674936
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class Test(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = Text()
            text.insert("1.0", "a = [1, 2, 3]")
            parser = HyperParser(text, "1.0")
            self.assertEqual(parser.get_surrounding_brackets(), ("1.2", "1.10"))
            parser.set_index("1.4")
            self.assertEqual(parser.get_surrounding_brackets(), ("1.2", "1.10"))
            parser.set_index("1.6")
            self.assertEqual(parser.get_surrounding_brackets(), ("1.2", "1.10"))
            parser.set_index("1.8")
           

# Generated at 2022-06-18 09:37:17.433610
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-18 09:37:24.862415
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:37:35.574682
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:37:45.851448
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Text(None, "")
    text.insert("1.0", "'''\n'''")
    text.mark_set("insert", "1.0")
    hp = HyperParser(text, "insert")
    assert hp.is_in_string()
    text.mark_set("insert", "1.1")
    hp = HyperParser(text, "insert")
    assert not hp.is_in_string()
    text.mark_set("insert", "1.2")
    hp = HyperParser(text, "insert")
    assert hp.is_in_string()
    text.mark_set("insert", "1.3")
    hp = HyperParser(text, "insert")
    assert not hp.is_in_string()
    text.mark_set("insert", "1.4")
    hp

# Generated at 2022-06-18 09:37:57.028669
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    rp = RoughParser("{[(", indent_width=4, tabwidth=8)
    assert rp.get_last_open_bracket_pos() == 0
    rp = RoughParser("{[(", indent_width=4, tabwidth=8)
    assert rp.get_last_open_bracket_pos() == 0
    rp = RoughParser("{[(", indent_width=4, tabwidth=8)
    assert rp.get_last_open_bracket_pos() == 0
    rp = RoughParser("{[(", indent_width=4, tabwidth=8)
    assert rp.get_last_open_bracket_pos() == 0
    rp = RoughParser("{[(", indent_width=4, tabwidth=8)
    assert rp.get_last

# Generated at 2022-06-18 09:38:07.550248
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:38:18.417534
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:38:27.213715
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-18 09:38:32.477773
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = Text()
            text.insert("1.0", self.text)
            parser = HyperParser(text, "1.0")
            self.assertEqual(parser.get_surrounding_brackets(), self.result)

    class TestCase1(TestCase):
        text = "foo(bar)"
        result = ("1.4", "1.8")

    class TestCase2(TestCase):
        text = "foo(bar, baz)"
        result = ("1.4", "1.12")

    class TestCase3(TestCase):
        text = "foo(bar, baz, quux)"
        result = ("1.4", "1.16")

# Generated at 2022-06-18 09:38:38.231933
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:40:26.822651
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    rp = RoughParser("")
    assert rp.get_last_stmt_bracketing() is None
    rp = RoughParser("#")
    assert rp.get_last_stmt_bracketing() is None
    rp = RoughParser("#\n")
    assert rp.get_last_stmt_bracketing() is None
    rp = RoughParser("#\n#")
    assert rp.get_last_stmt_bracketing() is None
    rp = RoughParser("#\n#\n")
    assert rp.get_last_stmt_bracketing() is None
    rp = RoughParser("#\n#\n#")
    assert rp.get_last_stmt_bracketing() is None

# Generated at 2022-06-18 09:40:36.825129
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("")
    assert rp.str == ""
    assert rp.goodlines == [0, 0]
    assert rp.continuation == C_NONE
    assert rp.study_level == 0
    assert rp.stmt_start is None
    assert rp.stmt_end is None
    assert rp.lastch is None
    assert rp.lastopenbracketpos is None
    assert rp.stmt_bracketing is None

    rp.set_lo("\n")
    assert rp.str == "\n"
    assert rp.goodlines == [0, 1, 1]
    assert rp.continuation == C_NONE
    assert rp.study_level == 0

# Generated at 2022-06-18 09:40:43.816541
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:40:53.825023
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    rp = RoughParser("if True:\n    print('hello')\n    print('world')\n")
    assert rp.get_last_open_bracket_pos() == 4
    rp = RoughParser("if True:\n    print('hello')\n    print('world')")
    assert rp.get_last_open_bracket_pos() == 4
    rp = RoughParser("if True:\n    print('hello')\n    print('world')\n\n")
    assert rp.get_last_open_bracket_pos() == 4
    rp = RoughParser("if True:\n    print('hello')\n    print('world')\n\n\n")
    assert rp.get_last_open_bracket_pos() == 4

# Generated at 2022-06-18 09:41:04.426981
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # Test the method is_in_string of class HyperParser.
    #
    # This test is not complete. It only tests that the method
    # works for a few cases.

    # The test is done by creating a text widget, inserting the
    # given text, and calling the method.

    # The text widget is created in a toplevel window, so that it
    # can be displayed if the test fails.

    from tkinter import Tk, Text

    root = Tk()
    text = Text(root)
    text.pack()

    def test(text, index, expected):
        text.delete("1.0", "end")
        text.insert("1.0", text)
        hp = HyperParser(text, index)
        actual = hp.is_in_string()

# Generated at 2022-06-18 09:41:12.325171
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:41:18.182451
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Test(TestCase):
        def test_set_index(self):
            from tkinter import Text

            text = Text()
            text.insert("insert", "a\n")
            text.insert("insert", "b\n")
            text.insert("insert", "c\n")
            text.insert("insert", "d\n")
            text.insert("insert", "e\n")
            text.insert("insert", "f\n")
            text.insert("insert", "g\n")
            text.insert("insert", "h\n")
            text.insert("insert", "i\n")
            text.insert("insert", "j\n")
            text.insert("insert", "k\n")
            text.insert("insert", "l\n")
           

# Generated at 2022-06-18 09:41:27.374038
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def check(s, expected):
        parser = RoughParser(s, 0)
        actual = parser.get_base_indent_string()
        assert actual == expected, (actual, expected)

    check("", "")
    check("\n", "")
    check("\n\n", "")
    check("\n\n\n", "")
    check("\n\n\n\n", "")
    check("\n\n\n\n\n", "")
    check("\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n\n", "")

# Generated at 2022-06-18 09:41:38.043410
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import TestCase

    class Test(TestCase):
        def test_is_in_code(self):
            def test(text, index, expected):
                self.assertEqual(HyperParser(text, index).is_in_code(), expected)

            test("", "1.0", False)
            test("#", "1.0", False)
            test("#", "1.1", False)
            test("#\n", "2.0", False)
            test("#\n", "2.1", False)
            test("#\n", "1.1", False)
            test("#\n", "1.end", False)
            test("#\n", "1.end-1c", False)
            test("#\n", "1.end-2c", False)
           

# Generated at 2022-06-18 09:41:47.515401
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def test_constructor(self):
            # Test that the constructor doesn't crash
            text = Text()
            text.insert("1.0", "def f(x):\n    return x + 1\n")
            HyperParser(text, "1.0")
            HyperParser(text, "1.4")
            HyperParser(text, "1.6")
            HyperParser(text, "2.0")
            HyperParser(text, "2.4")
            HyperParser(text, "2.6")
            HyperParser(text, "2.8")
            HyperParser(text, "2.10")
            HyperParser(text, "2.12")
            HyperParser(text, "2.14")