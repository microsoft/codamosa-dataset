

# Generated at 2022-06-18 09:34:20.286491
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import unittest

    class Test(unittest.TestCase):
        def test_is_in_code(self):
            # Test that HyperParser.is_in_code() returns True for
            # all positions in the string except for the ones
            # marked with a comment.
            s = """\
            # comment
            # comment
            a = 1 # comment
            b = 2
            c = 3 # comment
            # comment
            """
            for i in range(len(s)):
                if s[i : i + 8] == "# comment":
                    self.assertFalse(HyperParser(s, i).is_in_code())
                else:
                    self.assertTrue(HyperParser(s, i).is_in_code())

    unittest.main(Test)



# Generated at 2022-06-18 09:34:30.999415
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-18 09:34:34.407974
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from idlelib.idle_test.htest import run

    run(HyperParser)

if __name__ == "__main__":
    test_HyperParser()

# Generated at 2022-06-18 09:34:45.705906
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class Test(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = Text()
            text.insert("insert", "a(b(c(d(e(f(g(h(i(j(k(l(m(n(o(p(q(r(s(t(u(v(w(x(y(z))))))))))))))))))))))))")
            text.insert("insert", "a[b[c[d[e[f[g[h[i[j[k[l[m[n[o[p[q[r[s[t[u[v[w[x[y[z]]]]]]]]]]]]]]]]]]]]]")

# Generated at 2022-06-18 09:34:57.220450
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser("if True:\n    pass\n")
    assert rp.is_block_opener()
    rp = RoughParser("if True:\n    pass")
    assert rp.is_block_opener()
    rp = RoughParser("if True:\n    pass\n    pass\n")
    assert rp.is_block_opener()
    rp = RoughParser("if True:\n    pass\n    pass")
    assert rp.is_block_opener()
    rp = RoughParser("if True:\n    pass\n    pass\n    pass\n")
    assert rp.is_block_opener()
    rp = RoughParser("if True:\n    pass\n    pass\n    pass")
    assert rp.is_block_opener()
   

# Generated at 2022-06-18 09:34:58.704393
# Unit test for method set_str of class RoughParser
def test_RoughParser_set_str():
    rp = RoughParser()

# Generated at 2022-06-18 09:35:07.185754
# Unit test for method set_str of class RoughParser

# Generated at 2022-06-18 09:35:19.116975
# Unit test for method is_in_string of class HyperParser

# Generated at 2022-06-18 09:35:29.331190
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    def foo():\n        pass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n        pass")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n        pass\n    ")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n        pass\n    \n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n        pass\n    # comment\n")
    assert rp.get_base_indent_string() == "    "
   

# Generated at 2022-06-18 09:35:40.259208
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    # pylint: disable=redefined-builtin
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-nested-blocks

    def test(str, expected):
        rp = RoughParser(str, indent_width=4, tabwidth=8)
        rp.study_continuation()
        assert rp.get_continuation_type() == C_BACKSLASH
        assert rp.compute_backslash_indent() == expected

    test("a = \\", 4)
    test("a = \\\n", 4)
    test("a = \\\n ", 4)
    test("a = \\\n  ", 4)

# Generated at 2022-06-18 09:36:42.858171
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class Test(unittest.TestCase):
        def test_HyperParser(self):
            text = Text()
            text.insert("1.0", "a = 1 + 2\n")
            text.insert("2.0", "b = 3 + 4\n")
            text.insert("3.0", "c = 5 + 6\n")
            text.insert("4.0", "d = 7 + 8\n")
            text.insert("5.0", "e = 9 + 10\n")
            text.insert("6.0", "f = 11 + 12\n")
            text.insert("7.0", "g = 13 + 14\n")
            text.insert("8.0", "h = 15 + 16\n")

# Generated at 2022-06-18 09:36:52.987594
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = """\
            foo(bar,
                baz)
            """
            h = HyperParser(text, "1.0")
            self.assertEqual(h.get_surrounding_brackets(), ("1.0", "1.12"))
            h.set_index("1.4")
            self.assertEqual(h.get_surrounding_brackets(), ("1.0", "1.12"))
            h.set_index("1.5")
            self.assertEqual(h.get_surrounding_brackets(), ("1.0", "1.12"))
            h.set_index("1.6")
            self.assertEqual

# Generated at 2022-06-18 09:37:03.002948
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class Test(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            from idlelib.idle_test.mock_idle import Func
            from idlelib.idle_test.mock_tk import Mbox

            def test(text, index, expected, openers="([{", mustclose=False):
                hp = HyperParser(text, index)
                result = hp.get_surrounding_brackets(openers, mustclose)
                self.assertEqual(result, expected)

            def test_fail(text, index, openers="([{", mustclose=False):
                hp = HyperParser(text, index)

# Generated at 2022-06-18 09:37:14.828421
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            print("Error: %r %r -> %r, expected %r" % (text, index, actual, expected))

    # Test cases for get_expression
    test("foo(bar)", "1.0", "")
    test("foo(bar)", "1.3", "")
    test("foo(bar)", "1.4", "foo")
    test("foo(bar)", "1.5", "foo")
    test("foo(bar)", "1.6", "foo")
    test("foo(bar)", "1.7", "foo")
    test("foo(bar)", "1.8", "foo")

# Generated at 2022-06-18 09:37:23.761345
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:37:34.770087
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class Test(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = Text()
            text.insert("1.0", "a(b(c[d.e]f)g)h")
            parser = HyperParser(text, "1.0")
            self.assertEqual(parser.get_surrounding_brackets(), ("1.0", "1.9"))
            parser = HyperParser(text, "1.1")
            self.assertEqual(parser.get_surrounding_brackets(), ("1.0", "1.9"))
            parser = HyperParser(text, "1.2")
            self.assertEqual(parser.get_surrounding_brackets(), ("1.2", "1.7"))

# Generated at 2022-06-18 09:37:44.740775
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from unittest import TestCase

    class Test(TestCase):
        def test_is_in_code(self):
            def check(text, index, expected):
                hp = HyperParser(text, index)
                self.assertEqual(hp.is_in_code(), expected)

            check("", "1.0", True)
            check("#", "1.0", False)
            check("#", "1.1", True)
            check("#\n", "1.1", False)
            check("#\n", "2.0", True)
            check("#\n", "2.1", True)
            check("#\n", "2.2", True)
            check("#\n", "2.end", True)
            check("#\n", "2.endline", True)


# Generated at 2022-06-18 09:37:55.331067
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = "a = 1\n"
    hp = HyperParser(text, "1.0")
    assert hp.is_in_code()
    hp = HyperParser(text, "1.1")
    assert hp.is_in_code()
    hp = HyperParser(text, "1.2")
    assert hp.is_in_code()
    hp = HyperParser(text, "1.3")
    assert hp.is_in_code()
    hp = HyperParser(text, "1.4")
    assert hp.is_in_code()
    hp = HyperParser(text, "1.5")
    assert not hp.is_in_code()
    text = 'a = 1\n#comment\n'
    hp = HyperParser(text, "2.0")
    assert not hp.is_in

# Generated at 2022-06-18 09:38:06.520268
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_expression(self):
            def test(text, index, expected):
                hp = HyperParser(text, index)
                self.assertEqual(hp.get_expression(), expected)

            test("a", "1.0", "a")
            test("a.", "1.2", "a")
            test("a.b", "1.3", "a.b")
            test("a.b.c", "1.5", "a.b.c")
            test("a.b.c.d", "1.7", "a.b.c.d")
            test("a.b.c.d.", "1.8", "a.b.c.d")

# Generated at 2022-06-18 09:38:16.937404
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:39:04.452496
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-18 09:39:13.225136
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def test_get_expression(self):
            text = Text()
            text.insert("insert", "a.b.c.d.e")
            hp = HyperParser(text, "insert")
            self.assertEqual(hp.get_expression(), "e")
            hp.set_index("insert-1c")
            self.assertEqual(hp.get_expression(), "d.e")
            hp.set_index("insert-2c")
            self.assertEqual(hp.get_expression(), "c.d.e")
            hp.set_index("insert-3c")
            self.assertEqual(hp.get_expression(), "b.c.d.e")
            hp.set_index("insert-4c")


# Generated at 2022-06-18 09:39:22.111759
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def test_is_in_string(self):
            text = "'''\n'''\n"
            self.assertEqual(HyperParser(text, "1.0").is_in_string(), False)
            self.assertEqual(HyperParser(text, "1.1").is_in_string(), True)
            self.assertEqual(HyperParser(text, "1.2").is_in_string(), True)
            self.assertEqual(HyperParser(text, "1.3").is_in_string(), True)
            self.assertEqual(HyperParser(text, "2.0").is_in_string(), False)

# Generated at 2022-06-18 09:39:28.953401
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    # pylint: disable=redefined-builtin

    def check(s, expected):
        rp = RoughParser(s, "utf-8")
        got = rp.get_last_open_bracket_pos()
        if got != expected:
            print("%s: expected %s, got %s" % (s, expected, got))

    check("", None)
    check("x", None)
    check("(", 0)
    check("()", 0)
    check("(x", 0)
    check("(x)", 0)
    check("(x)y", 0)
    check("[", 0)
    check("[]", 0)
    check("[x", 0)
    check("[x]", 0)
    check("[x]y", 0)
    check("{", 0)

# Generated at 2022-06-18 09:39:34.536193
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def test_constructor(self):
            text = Text()
            text.insert("1.0", "if 1:\n  pass\n")
            hp = HyperParser(text, "1.0")
            self.assertEqual(hp.rawtext, "if 1:\n  pass")
            self.assertEqual(hp.stopatindex, "2.0")
            self.assertEqual(hp.bracketing, [(0, 0), (2, 0), (3, 1), (4, 1), (5, 0)])
            self.assertEqual(hp.isopener, [False, True, True, False, False])
            self.assertEqual(hp.indexinrawtext, 0)

# Generated at 2022-06-18 09:39:39.988044
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("a = 1")
    assert rp.str == "a = 1"
    assert rp.study_level == 0
    assert rp.continuation == C_NONE
    assert rp.goodlines == [0, 1]
    assert rp.stmt_start == 0
    assert rp.stmt_end == 0
    assert rp.lastch == ""
    assert rp.lastopenbracketpos is None
    assert rp.stmt_bracketing is None
    rp.set_lo("a = 1\nb = 2")
    assert rp.str == "a = 1\nb = 2"
    assert rp.study_level == 0
    assert rp.continuation == C_NONE

# Generated at 2022-06-18 09:39:45.233473
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:39:50.566012
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def setUp(self):
            self.text = Text()
            self.text.insert("1.0", "a = 1 + 2\n")
            self.text.insert("2.0", "b = (1 + 2)\n")
            self.text.insert("3.0", "c = [1 + 2]\n")
            self.text.insert("4.0", "d = {1 + 2}\n")
            self.text.insert("5.0", "e = '1 + 2'\n")
            self.text.insert("6.0", "f = \"1 + 2\"\n")
            self.text.insert("7.0", "g = r'1 + 2'\n")
            self.text.insert

# Generated at 2022-06-18 09:39:57.002237
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Test(TestCase):
        def test_set_index(self):
            from tkinter import Text

            text = Text()
            text.insert("insert", "a = 1 + 2")
            hp = HyperParser(text, "insert")
            self.assertEqual(hp.get_expression(), "")
            hp.set_index("insert - 2c")
            self.assertEqual(hp.get_expression(), "1")
            hp.set_index("insert - 3c")
            self.assertEqual(hp.get_expression(), "")
            hp.set_index("insert - 4c")
            self.assertEqual(hp.get_expression(), "")
            hp.set_index("insert - 5c")

# Generated at 2022-06-18 09:40:05.647620
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("a = 1")
    assert rp.str == "a = 1"
    assert rp.goodlines == [0, 1]
    assert rp.continuation == C_NONE
    assert rp.study_level == 0
    assert rp.stmt_start == 0
    assert rp.stmt_end == 0
    assert rp.lastch == ""
    assert rp.lastopenbracketpos is None
    assert rp.stmt_bracketing is None

    rp.set_lo("a = 1\nb = 2")
    assert rp.str == "a = 1\nb = 2"
    assert rp.goodlines == [0, 2]
    assert rp.continuation == C_NONE

# Generated at 2022-06-18 09:40:42.443939
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # Test the method get_surrounding_brackets of class HyperParser
    # This test is not run automatically.
    # To run it, execute this file from IDLE.
    import unittest

    class Test(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = "a = (1, 2, 3)\n"
            hp = HyperParser(text, "1.0")
            self.assertEqual(hp.get_surrounding_brackets(), ("1.0", "1.13"))
            hp.set_index("1.1")
            self.assertEqual(hp.get_surrounding_brackets(), ("1.0", "1.13"))
            hp.set_index("1.2")

# Generated at 2022-06-18 09:40:53.126732
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-18 09:40:57.723230
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest


# Generated at 2022-06-18 09:41:07.441019
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            raise ValueError(
                "HyperParser.get_expression(%r, %r) -> %r, expected %r"
                % (text, index, actual, expected)
            )

    test("foo", "1.0", "")
    test("foo", "1.1", "")
    test("foo", "1.2", "")
    test("foo", "1.3", "foo")
    test("foo", "1.4", "foo")
    test("foo", "1.5", "foo")
    test("foo", "1.6", "foo")
    test("foo", "1.7", "foo")

# Generated at 2022-06-18 09:41:11.815523
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # pylint: disable=redefined-builtin
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements

    def test(str, continuation):
        rp = RoughParser(str, indent_width=4, tabwidth=8)
        assert rp.get_continuation_type() == continuation

    test("", C_NONE)
    test("\n", C_NONE)
    test("\n\n", C_NONE)
    test("\n\n\n", C_NONE)
    test("\n\n\n\n", C_NONE)
    test("\n\n\n\n\n", C_NONE)

# Generated at 2022-06-18 09:41:17.445259
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:41:26.576347
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:41:37.255816
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:41:46.991875
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-18 09:41:52.913331
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    # This function tests the method get_surrounding_brackets of
    # class HyperParser. It is called when the module is run as a
    # script.
    import unittest

    class Test(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            # Test the method get_surrounding_brackets of class
            # HyperParser.
            text = Text()
            text.insert("1.0", "a(b)c")
            hp = HyperParser(text, "1.0")
            self.assertEqual(hp.get_surrounding_brackets(), ("1.0", "1.3"))
            hp.set_index("1.1")

# Generated at 2022-06-18 09:43:01.027216
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-18 09:43:08.491989
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text()
    text.insert("1.0", "def f():\n    pass\n")
    text.mark_set("insert", "1.4")
    hp = HyperParser(text, "insert")
    assert hp.is_in_code()
    text.mark_set("insert", "1.6")
    hp = HyperParser(text, "insert")
    assert not hp.is_in_code()
    text.mark_set("insert", "1.8")
    hp = HyperParser(text, "insert")
    assert hp.is_in_code()
    text.mark_set("insert", "2.0")
    hp = HyperParser(text, "insert")
    assert not hp.is_in_code()
    text.mark_set("insert", "2.4")