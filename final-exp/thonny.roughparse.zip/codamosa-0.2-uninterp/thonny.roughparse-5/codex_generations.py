

# Generated at 2022-06-18 09:34:05.755005
# Unit test for constructor of class HyperParser

# Generated at 2022-06-18 09:34:07.744690
# Unit test for method __getitem__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___getitem__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'


# Generated at 2022-06-18 09:34:16.989813
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:34:27.436628
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:34:39.332634
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:34:50.879205
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    rp = RoughParser("""\
    a = 1
    b = 2
    """)
    assert rp.get_num_lines_in_stmt() == 2
    rp = RoughParser("""\
    a = 1
    b = 2
    """)
    assert rp.get_num_lines_in_stmt() == 2
    rp = RoughParser("""\
    a = 1
    b = 2
    """)
    assert rp.get_num_lines_in_stmt() == 2
    rp = RoughParser("""\
    a = 1
    b = 2
    """)
    assert rp.get_num_lines_in_stmt() == 2
    rp = RoughParser("""\
    a = 1
    b = 2
    """)
    assert r

# Generated at 2022-06-18 09:35:01.272667
# Unit test for constructor of class HyperParser
def test_HyperParser():
    text = Text()
    text.insert("1.0", "a = 1\n")
    text.insert("2.0", "b = 2\n")
    text.insert("3.0", "c = 3\n")
    text.insert("4.0", "d = 4\n")
    text.insert("5.0", "e = 5\n")
    text.insert("6.0", "f = 6\n")
    text.insert("7.0", "g = 7\n")
    text.insert("8.0", "h = 8\n")
    text.insert("9.0", "i = 9\n")
    text.insert("10.0", "j = 10\n")
    text.insert("11.0", "k = 11\n")

# Generated at 2022-06-18 09:35:09.068314
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("""\
if 1:
    if 2:
        pass
    elif 3:
        pass
    else:
        pass
elif 4:
    pass
else:
    pass
""")
    assert rp.get_base_indent_string() == "    "
    assert rp.get_last_open_bracket_pos() == 10
    assert rp.get_last_stmt_bracketing() == ((0, 0), (4, 1), (8, 0))
    assert rp.get_continuation_type() == C_NONE
    assert rp.get_num_lines_in_stmt() == 1
    assert rp.is_block_opener()
    assert not rp.is_block_closer()


# Generated at 2022-06-18 09:35:20.248932
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    text.insert("1.0", "a = 1\n")
    text.insert("2.0", "b = 2\n")
    text.insert("3.0", "c = 3\n")
    text.insert("4.0", "d = 4\n")
    text.insert("5.0", "e = 5\n")
    text.insert("6.0", "f = 6\n")
    text.insert("7.0", "g = 7\n")
    text.insert("8.0", "h = 8\n")
    text.insert("9.0", "i = 9\n")
    text.insert("10.0", "j = 10\n")
    text.insert("11.0", "k = 11\n")

# Generated at 2022-06-18 09:35:30.684606
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            print("test failed:")
            print("text:", repr(text))
            print("index:", index)
            print("expected:", repr(expected))
            print("actual:", repr(actual))
            print()

    test("", "1.0", "")
    test("", "insert", "")
    test("a", "1.0", "")
    test("a", "1.1", "a")
    test("a", "insert", "")
    test("a ", "1.2", "a")
    test("a ", "insert", "")
    test("a b", "1.3", "b")

# Generated at 2022-06-18 09:38:56.030376
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("if 1:\n    if 1:\n        pass\n")
    assert rp.get_base_indent_string() == "    "
    assert rp.get_continuation_type() == C_NONE
    assert rp.get_num_lines_in_stmt() == 1
    assert rp.get_last_open_bracket_pos() == 8
    assert rp.get_last_stmt_bracketing() == ((0, 0), (4, 1), (8, 0), (12, 1), (17, 0))
    assert rp.is_block_opener()
    assert not rp.is_block_closer()
    assert rp.compute_bracket_indent() == 4
    assert rp.comp

# Generated at 2022-06-18 09:39:06.803161
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = Text()
            text.insert("1.0", self.text)
            hp = HyperParser(text, "1.0")
            self.assertEqual(hp.get_surrounding_brackets(), self.result)

    class TestCase1(TestCase):
        text = "foo(bar(baz))"
        result = ("1.4", "1.12")

    class TestCase2(TestCase):
        text = "foo(bar(baz))"
        result = ("1.4", "1.12")

    class TestCase3(TestCase):
        text = "foo(bar(baz))"

# Generated at 2022-06-18 09:39:15.115988
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class TestHyperParser(unittest.TestCase):
        def setUp(self):
            self.text = Text()
            self.text.insert("insert", "def f(x):\n    return x + 1\n")

        def test_get_expression(self):
            self.assertEqual(HyperParser(self.text, "insert").get_expression(), "")
            self.assertEqual(HyperParser(self.text, "insert linestart").get_expression(), "")
            self.assertEqual(HyperParser(self.text, "insert + 1c").get_expression(), "")
            self.assertEqual(HyperParser(self.text, "insert + 2c").get_expression(), "")

# Generated at 2022-06-18 09:39:23.832003
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:39:29.995092
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-18 09:39:31.960497
# Unit test for method is_in_code of class HyperParser

# Generated at 2022-06-18 09:39:37.452476
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:39:42.763974
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:39:47.981888
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def setUp(self):
            self.hp = HyperParser("", "1.0")

        def test_set_index(self):
            self.hp.set_index("1.0")
            self.assertEqual(self.hp.indexinrawtext, 0)
            self.assertEqual(self.hp.indexbracket, 0)
            self.hp.set_index("1.1")
            self.assertEqual(self.hp.indexinrawtext, 1)
            self.assertEqual(self.hp.indexbracket, 0)
            self.hp.set_index("1.2")
            self.assertEqual(self.hp.indexinrawtext, 2)

# Generated at 2022-06-18 09:39:53.626027
# Unit test for method compute_bracket_indent of class RoughParser