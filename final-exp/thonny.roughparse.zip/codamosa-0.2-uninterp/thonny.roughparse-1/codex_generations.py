

# Generated at 2022-06-18 09:33:31.817557
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    whitespace_chars = " \t\n\r"
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord("x"))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == "x x x\tx\nx"


# Utility functions


# Generated at 2022-06-18 09:33:39.176244
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({ord('a'): ord('b')}, ord('x'))
    assert mapping.get(ord('a')) == ord('b')
    assert mapping.get(ord('b')) == ord('x')
    assert mapping.get(ord('c')) == ord('x')
    assert mapping.get(ord('a'), ord('y')) == ord('b')
    assert mapping.get(ord('b'), ord('y')) == ord('y')
    assert mapping.get(ord('c'), ord('y')) == ord('y')



# Generated at 2022-06-18 09:33:50.718442
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # Test a simple case
    text = "abc 'def'"
    hp = HyperParser(text, "1.3")
    assert hp.is_in_string()
    # Test a case where the index is at the end of the string
    text = "abc 'def'"
    hp = HyperParser(text, "1.7")
    assert hp.is_in_string()
    # Test a case where the index is at the end of the string, but
    # there is a continuation character
    text = "abc 'def\\\nghi'"
    hp = HyperParser(text, "1.8")
    assert hp.is_in_string()
    # Test a case where the index is at the end of the string, but
    # there is a continuation character
    text = "abc 'def\\\nghi'"

# Generated at 2022-06-18 09:34:01.121039
# Unit test for method is_block_opener of class RoughParser
def test_RoughParser_is_block_opener():
    rp = RoughParser("if True:\n    pass\n")
    assert rp.is_block_opener()
    rp = RoughParser("if True:\n    pass")
    assert rp.is_block_opener()
    rp = RoughParser("if True:")
    assert rp.is_block_opener()
    rp = RoughParser("if True")
    assert not rp.is_block_opener()
    rp = RoughParser("if True\n    pass")
    assert not rp.is_block_opener()
    rp = RoughParser("if True\n    pass\n")
    assert not rp.is_block_opener()
    rp = RoughParser("if True\n    pass\n    pass")
    assert not rp.is_block_opener

# Generated at 2022-06-18 09:34:10.656529
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-18 09:34:15.748712
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    text = "a + b\tc\nd"
    assert text.translate(mapping) == 'x x x\tx\nx'


# Generated at 2022-06-18 09:34:25.992773
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def check(s, expected):
        rp = RoughParser(s)
        assert rp.get_base_indent_string() == expected

    check("", "")
    check("\n", "")
    check("\n\n", "")
    check("\n\n\n", "")
    check("\n\n\n\n", "")
    check("\n\n\n\n\n", "")
    check("\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n\n\n", "")

# Generated at 2022-06-18 09:34:37.248980
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = """\
            (1,
             2,
             3)
            """
            hp = HyperParser(text, "1.0")
            self.assertEqual(hp.get_surrounding_brackets(), ("1.0", "1.16"))
            hp = HyperParser(text, "1.1")
            self.assertEqual(hp.get_surrounding_brackets(), ("1.0", "1.16"))
            hp = HyperParser(text, "1.2")
            self.assertEqual(hp.get_surrounding_brackets(), ("1.0", "1.16"))
            hp = HyperParser(text, "1.3")

# Generated at 2022-06-18 09:34:49.283213
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    def foo():\n        pass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("def foo():\n    pass\n")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("\n")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("    \n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    \n    ")
    assert rp.get_base_indent_string() == "    "

# Generated at 2022-06-18 09:35:00.059288
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            from idlelib.idle_test.mock_idle import Func
            from idlelib.idle_test.mock_tk import Mbox

            def test(text, index, expected):
                hp = HyperParser(text, index)
                result = hp.get_surrounding_brackets()
                if result is None:
                    result = "None"
                else:
                    result = (result[0], result[1])
                self.assertEqual(result, expected)

            test(
                "a = [1, 2, 3]",
                "1.0",
                ("1.0", "1.13"),
            )

# Generated at 2022-06-18 09:35:41.973571
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def check(text, expected):
        parser = RoughParser(text)
        actual = parser.get_base_indent_string()
        assert actual == expected, "expected %r, got %r" % (expected, actual)

    check("", "")
    check("\n", "")
    check("\n\n", "")
    check("\n\n\n", "")
    check("\n\n\n\n", "")
    check("\n\n\n\n\n", "")
    check("\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n\n", "")

# Generated at 2022-06-18 09:35:52.833981
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:36:03.386935
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    a = 1\n    b = 2\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    a = 1\n  b = 2\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    a = 1\n    b = 2\n  c = 3\n")
    assert rp.get_base_indent_string() == "  "
    rp = RoughParser("    a = 1\n  b = 2\n    c = 3\n")
    assert rp.get_base_indent_string() == "    "

# Generated at 2022-06-18 09:36:13.440337
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:36:24.773540
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest


# Generated at 2022-06-18 09:36:29.835793
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def check(s, expected):
        rp = RoughParser(s, 0)
        assert rp.get_base_indent_string() == expected

    check("", "")
    check("\n", "")
    check("\n\n", "")
    check("\n\n\n", "")
    check("\n\n\n\n", "")
    check("\n\n\n\n\n", "")
    check("\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n\n\n", "")
   

# Generated at 2022-06-18 09:36:39.813050
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    text.insert("1.0", "a = 1\n")
    text.insert("2.0", "b = 2\n")
    text.insert("3.0", "c = 3\n")
    text.insert("4.0", "d = 4\n")
    text.insert("5.0", "e = 5\n")
    text.insert("6.0", "f = 6\n")
    text.insert("7.0", "g = 7\n")
    text.insert("8.0", "h = 8\n")
    text.insert("9.0", "i = 9\n")
    text.insert("10.0", "j = 10\n")
    text.insert("11.0", "k = 11\n")

# Generated at 2022-06-18 09:36:46.190336
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-18 09:36:56.926698
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            def check(text, index, expected):
                hp = HyperParser(text, index)
                actual = hp.get_surrounding_brackets()
                self.assertEqual(actual, expected)

            check("a[b]", "1.0", ("1.0", "1.3"))
            check("a[b]", "1.1", ("1.0", "1.3"))
            check("a[b]", "1.2", ("1.0", "1.3"))
            check("a[b]", "1.3", ("1.0", "1.3"))
            check("a[b]", "1.4", None)

# Generated at 2022-06-18 09:37:06.923479
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest
    from test.support import run_unittest

    class Test(unittest.TestCase):
        def test_set_index(self):
            text = Text(None, "")
            text.insert("1.0", "a = 1 + 2\n")
            text.insert("2.0", "b = 3 + 4\n")
            text.insert("3.0", "c = 5 + 6\n")
            text.insert("4.0", "d = 7 + 8\n")
            text.insert("5.0", "e = 9 + 10\n")
            text.insert("6.0", "f = 11 + 12\n")
            text.insert("7.0", "g = 13 + 14\n")

# Generated at 2022-06-18 09:37:49.419706
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def test_set_index(self):
            # Test that set_index works correctly when the index is
            # inside a string.
            text = "a = 'a' + 'b'"
            hp = HyperParser(text, "1.0")
            hp.set_index("1.2")
            self.assertTrue(hp.is_in_string())
            self.assertFalse(hp.is_in_code())
            self.assertEqual(hp.get_expression(), "")
            hp.set_index("1.3")
            self.assertTrue(hp.is_in_string())
            self.assertFalse(hp.is_in_code())
            self.assertEqual(hp.get_expression(), "")
            hp.set

# Generated at 2022-06-18 09:38:00.504486
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:38:11.021889
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest


# Generated at 2022-06-18 09:38:22.002163
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    def f(x):\n        return x\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def f(x):\n        return x\n    ")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def f(x):\n        return x")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def f(x):\n        return x\n    ")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def f(x):\n        return x\n    ")
    assert rp.get_base_

# Generated at 2022-06-18 09:38:29.247565
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:38:34.805462
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = Text()
    text.insert("1.0", "a = 'a' + \"b\"")
    text.mark_set("insert", "1.0")
    hp = HyperParser(text, "insert")
    assert hp.is_in_string()
    text.mark_set("insert", "1.2")
    hp.set_index("insert")
    assert not hp.is_in_string()
    text.mark_set("insert", "1.4")
    hp.set_index("insert")
    assert hp.is_in_string()
    text.mark_set("insert", "1.6")
    hp.set_index("insert")
    assert not hp.is_in_string()
    text.mark_set("insert", "1.8")
    hp.set_index("insert")

# Generated at 2022-06-18 09:38:40.378568
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    # Test that set_index works correctly when the index is at the
    # beginning of a line.
    text = Text()
    text.insert("1.0", "a = 1\n")
    hp = HyperParser(text, "1.0")
    hp.set_index("1.0")
    assert hp.indexinrawtext == 0
    assert hp.indexbracket == 0
    assert hp.isopener[0] is False
    assert hp.rawtext == "a = 1"
    assert hp.stopatindex == "2.0"
    assert hp.bracketing == [(0, 0), (3, 0), (4, 0), (5, 0)]
    assert hp.isopener == [False, False, False, False]

    # Test that set_index works correctly when the index is at the
    #

# Generated at 2022-06-18 09:38:50.370469
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("if 1:")
    assert rp.get_continuation_type() == C_NONE
    assert rp.get_num_lines_in_stmt() == 1
    assert rp.get_last_open_bracket_pos() is None
    assert rp.get_last_stmt_bracketing() is None
    assert rp.get_base_indent_string() == ""
    assert not rp.is_block_opener()
    assert not rp.is_block_closer()
    assert rp.compute_bracket_indent() == 0
    assert rp.compute_backslash_indent() == 0

    rp.set_lo("if 1:\\")
    assert rp.get_continuation

# Generated at 2022-06-18 09:39:00.990552
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        if hp.is_in_code() != expected:
            raise ValueError(
                "HyperParser.is_in_code() failed for %s, %s" % (repr(text), index)
            )

    test("", "1.0", True)
    test("#", "1.0", False)
    test("#", "1.1", True)
    test("a = 1", "1.0", True)
    test("a = 1", "1.1", True)
    test("a = 1", "1.2", True)
    test("a = 1", "1.3", True)
    test("a = 1", "1.4", True)

# Generated at 2022-06-18 09:39:10.263947
# Unit test for constructor of class HyperParser
def test_HyperParser():
    from unittest import TestCase

    class TestHyperParser(TestCase):
        def test_get_expression(self):
            def test(text, index, expected):
                hp = HyperParser(text, index)
                self.assertEqual(hp.get_expression(), expected)

            test("a", "1.0", "")
            test("a", "1.1", "a")
            test("a.b", "1.2", "a.b")
            test("a.b", "1.3", "b")
            test("a.b.c", "1.4", "b.c")
            test("a.b.c", "1.5", "c")
            test("a.b.c", "1.6", "")

# Generated at 2022-06-18 09:40:26.149018
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            raise AssertionError(
                "HyperParser.get_expression(%r, %r) -> %r, expected %r"
                % (text, index, actual, expected)
            )

    test("", "1.0", "")
    test("x", "1.0", "x")
    test("x", "1.1", "")
    test("x+y", "1.1", "x")
    test("x+y", "1.2", "")
    test("x+y", "1.3", "y")
    test("x+y", "1.4", "")

# Generated at 2022-06-18 09:40:36.155579
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    def foo():\n        pass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("def foo():\n    pass\n")
    assert rp.get_base_indent_string() == ""
    rp = RoughParser("    def foo():\n        pass")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n        pass\n    ")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n        pass\n    \n")
    assert rp.get_base_indent_string() == "    "

# Generated at 2022-06-18 09:40:37.142765
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:40:43.986846
# Unit test for method compute_backslash_indent of class RoughParser
def test_RoughParser_compute_backslash_indent():
    rp = RoughParser("a = 1 + 2 +\\\n    3 + 4 + 5 + 6 + 7 + 8 + 9 + 10")
    assert rp.compute_backslash_indent() == 5
    rp = RoughParser("a = 1 + 2 +\\\n    3 + 4 + 5 + 6 + 7 + 8 + 9 + 10 +\\\n    11")
    assert rp.compute_backslash_indent() == 5
    rp = RoughParser("a = 1 + 2 +\\\n    3 + 4 + 5 + 6 + 7 + 8 + 9 + 10 +\\\n    11 + 12")
    assert rp.compute_backslash_indent() == 5

# Generated at 2022-06-18 09:40:53.987146
# Unit test for method get_expression of class HyperParser

# Generated at 2022-06-18 09:41:04.509963
# Unit test for constructor of class HyperParser
def test_HyperParser():
    import unittest

    class Test(unittest.TestCase):
        def test_basic(self):
            text = "a = 1\n"
            hp = HyperParser(text, "1.0")
            self.assertEqual(hp.get_expression(), "")
            self.assertTrue(hp.is_in_code())
            self.assertFalse(hp.is_in_string())
            hp.set_index("1.1")
            self.assertEqual(hp.get_expression(), "a")
            self.assertTrue(hp.is_in_code())
            self.assertFalse(hp.is_in_string())
            hp.set_index("1.2")
            self.assertEqual(hp.get_expression(), "a")

# Generated at 2022-06-18 09:41:12.356841
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    import unittest

    class TestCase(unittest.TestCase):
        def test_set_index(self):
            text = Text()
            text.insert("insert", "a = (1 + 2) * 3")
            hp = HyperParser(text, "insert")
            self.assertEqual(hp.get_expression(), "3")
            hp.set_index("insert-1c")
            self.assertEqual(hp.get_expression(), "2")
            hp.set_index("insert-2c")
            self.assertEqual(hp.get_expression(), "1")
            hp.set_index("insert-3c")
            self.assertEqual(hp.get_expression(), "")
            hp.set_index("insert-4c")

# Generated at 2022-06-18 09:41:18.320139
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("if 1:")
    assert rp.get_continuation_type() == C_NONE
    assert rp.get_num_lines_in_stmt() == 1
    assert rp.get_base_indent_string() == ""
    assert rp.is_block_opener()
    assert not rp.is_block_closer()
    assert rp.get_last_open_bracket_pos() is None
    assert rp.get_last_stmt_bracketing() == ((0, 0), (4, 0))
    assert rp.compute_bracket_indent() == 0
    assert rp.compute_backslash_indent() == 0

    rp.set_lo("if 1:\n  pass")

# Generated at 2022-06-18 09:41:27.482319
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-18 09:41:38.256158
# Unit test for method get_num_lines_in_stmt of class RoughParser
def test_RoughParser_get_num_lines_in_stmt():
    def check(s, expected):
        rp = RoughParser(s, indent_width=4, tabwidth=8)
        actual = rp.get_num_lines_in_stmt()
        assert actual == expected, (
            "expected %r, got %r for input %r" % (expected, actual, s)
        )

    check("", 0)
    check("\n", 1)
    check("\n\n", 2)
    check("\n\n\n", 3)
    check("\n\n\n\n", 4)
    check("\n\n\n\n\n", 5)
    check("\n\n\n\n\n\n", 6)
    check("\n\n\n\n\n\n\n", 7)