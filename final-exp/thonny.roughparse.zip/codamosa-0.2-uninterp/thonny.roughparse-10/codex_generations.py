

# Generated at 2022-06-18 09:34:52.287113
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    # pylint: disable=redefined-builtin
    def check(s, expected):
        parser = RoughParser(s, 0)
        assert parser.get_base_indent_string() == expected

    check("", "")
    check("\n", "")
    check("\n\n", "")
    check("\n\n\n", "")
    check("\n\n\n\n", "")
    check("\n\n\n\n\n", "")
    check("\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n", "")
    check("\n\n\n\n\n\n\n\n", "")

# Generated at 2022-06-18 09:35:02.242842
# Unit test for method set_str of class RoughParser

# Generated at 2022-06-18 09:35:09.209529
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import mock

    class MockText:
        def __init__(self, index_return_value):
            self.index_return_value = index_return_value

        def index(self, index):
            return self.index_return_value

    class MockParser:
        def __init__(self, bracketing):
            self.bracketing = bracketing

        def get_last_stmt_bracketing(self):
            return self.bracketing

    # Test 1: index is in the analyzed statement
    text = MockText("1.0")
    parser = MockParser([(0, 0), (1, 0)])
    hyper_parser = HyperParser(text, "1.0")
    hyper_parser.rawtext = "a"
    hyper_parser.stopatindex = "1.0"


# Generated at 2022-06-18 09:35:20.381146
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({}, ord('x'))
    assert mapping.get(ord('a')) == ord('x')
    assert mapping.get(ord('a'), ord('y')) == ord('x')
    assert mapping.get(ord('a'), default=ord('y')) == ord('x')
    assert mapping.get(ord('a'), ord('y'), ord('z')) == ord('x')

# Generated at 2022-06-18 09:35:30.877526
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-18 09:35:38.393850
# Unit test for method get of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping_get():
    mapping = StringTranslatePseudoMapping({}, 'x')
    assert mapping.get('a') == 'x'
    assert mapping.get('a', 'y') == 'y'
    mapping = StringTranslatePseudoMapping({ord('a'): ord('b')}, 'x')
    assert mapping.get('a') == 'b'
    assert mapping.get('b') == 'x'
    assert mapping.get('a', 'y') == 'b'
    assert mapping.get('b', 'y') == 'y'


# Generated at 2022-06-18 09:35:48.788271
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:35:54.218357
# Unit test for method __len__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___len__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert len(mapping) == len(preserve_dict)


# Generated at 2022-06-18 09:35:59.008858
# Unit test for method __iter__ of class StringTranslatePseudoMapping
def test_StringTranslatePseudoMapping___iter__():
    whitespace_chars = ' \t\n\r'
    preserve_dict = {ord(c): ord(c) for c in whitespace_chars}
    mapping = StringTranslatePseudoMapping(preserve_dict, ord('x'))
    assert set(mapping) == set(whitespace_chars)


# Generated at 2022-06-18 09:36:09.537186
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    text.insert("1.0", "a = 1\n")
    text.insert("2.0", "b = 2\n")
    text.insert("3.0", "c = 3\n")
    text.insert("4.0", "d = 4\n")
    text.insert("5.0", "e = 5\n")
    text.insert("6.0", "f = 6\n")
    text.insert("7.0", "g = 7\n")
    text.insert("8.0", "h = 8\n")
    text.insert("9.0", "i = 9\n")
    text.insert("10.0", "j = 10\n")
    text.insert("11.0", "k = 11\n")

# Generated at 2022-06-18 09:36:48.834432
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:36:59.006444
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:37:10.162217
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-18 09:37:13.118351
# Unit test for method set_index of class HyperParser

# Generated at 2022-06-18 09:37:22.557350
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:37:33.915910
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:37:40.615929
# Unit test for method get_last_open_bracket_pos of class RoughParser
def test_RoughParser_get_last_open_bracket_pos():
    rp = RoughParser("if True:\n    pass")
    assert rp.get_last_open_bracket_pos() == 4
    rp = RoughParser("if True:\n    pass\n")
    assert rp.get_last_open_bracket_pos() == 4
    rp = RoughParser("if True:\n    pass\n\n")
    assert rp.get_last_open_bracket_pos() == 4
    rp = RoughParser("if True:\n    pass\n\n\n")
    assert rp.get_last_open_bracket_pos() == 4
    rp = RoughParser("if True:\n    pass\n\n\n\n")
    assert rp.get_last_open_bracket_pos() == 4

# Generated at 2022-06-18 09:37:51.896963
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_expression(self):
            def check(text, index, expected):
                hp = HyperParser(text, index)
                self.assertEqual(hp.get_expression(), expected)

            check("a", "1.0", "a")
            check("a.b", "1.0", "a.b")
            check("a.b", "1.1", "b")
            check("a.b", "1.2", "")
            check("a.b()", "1.0", "a.b()")
            check("a.b()", "1.1", "b()")
            check("a.b()", "1.2", "b")

# Generated at 2022-06-18 09:38:02.429421
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-18 09:38:12.835110
# Unit test for method get_last_stmt_bracketing of class RoughParser

# Generated at 2022-06-18 09:41:44.855686
# Unit test for method get_last_stmt_bracketing of class RoughParser
def test_RoughParser_get_last_stmt_bracketing():
    def test(s, expected):
        rp = RoughParser(s)
        actual = rp.get_last_stmt_bracketing()
        if actual != expected:
            print("test failed:")
            print("    input:", s)
            print("    expected:", expected)
            print("    actual:", actual)
    test("", None)
    test("# comment", None)
    test("\n", None)
    test("\n\n", None)
    test("# comment\n", None)
    test("# comment\n\n", None)
    test("# comment\n\n\n", None)
    test("# comment\n\n\n\n", None)
    test("# comment\n\n\n\n\n", None)

# Generated at 2022-06-18 09:41:50.997598
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = Text()
            text.insert("1.0", self.text)
            hp = HyperParser(text, "1.0")
            self.assertEqual(hp.get_surrounding_brackets(), self.expected)

    class TestCase1(TestCase):
        text = "a = (1, 2, 3)"
        expected = ("1.2", "1.8")

    class TestCase2(TestCase):
        text = "a = (1, 2, 3"
        expected = None

    class TestCase3(TestCase):
        text = "a = (1, 2, 3)"
        expected = ("1.2", "1.8")


# Generated at 2022-06-18 09:42:00.349004
# Unit test for method compute_backslash_indent of class RoughParser

# Generated at 2022-06-18 09:42:07.803623
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:42:14.390214
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-18 09:42:22.364864
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:42:34.114246
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = "'''abc'''"
    hp = HyperParser(text, "1.0")
    assert hp.is_in_string()
    hp = HyperParser(text, "1.1")
    assert hp.is_in_string()
    hp = HyperParser(text, "1.2")
    assert hp.is_in_string()
    hp = HyperParser(text, "1.3")
    assert not hp.is_in_string()
    hp = HyperParser(text, "1.4")
    assert not hp.is_in_string()
    hp = HyperParser(text, "1.5")
    assert not hp.is_in_string()
    hp = HyperParser(text, "1.6")
    assert not hp.is_in_string()

# Generated at 2022-06-18 09:42:43.300574
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    from idlelib.idle_test.mock_idle import Func
    from idlelib.idle_test.mock_tk import Mbox_func
    from idlelib.idle_test.htest import run

    text = Text()
    text.insert('1.0', 'def f(x):\n    return x**2\n')
    text.mark_set('insert', '1.0')
    text.see('insert')

    def is_in_code():
        hp = HyperParser(text, 'insert')
        return hp.is_in_code()

    def is_not_in_code():
        hp = HyperParser(text, 'insert')
        return not hp.is_in_code()


# Generated at 2022-06-18 09:42:51.396462
# Unit test for method compute_bracket_indent of class RoughParser

# Generated at 2022-06-18 09:43:00.762043
# Unit test for method find_good_parse_start of class RoughParser