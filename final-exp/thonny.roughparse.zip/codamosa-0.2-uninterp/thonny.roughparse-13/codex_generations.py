

# Generated at 2022-06-18 09:34:05.347039
# Unit test for method find_good_parse_start of class RoughParser
def test_RoughParser_find_good_parse_start():
    from lib2to3.pgen2 import token
    from lib2to3.pgen2 import driver
    from lib2to3.pygram import python_symbols as syms
    from lib2to3.pytree import Leaf
    from lib2to3.pytree import Node
    from lib2to3.pytree import type_repr
    from lib2to3.pytree import pretty_print
    from lib2to3.pygram import python_grammar

    # Create a parser
    pgen = driver.load_grammar("Grammar.txt")
    driver.initialize_grammar(pgen)
    parser = pgen.parser
    # Create a rough parser
    rough_parser = RoughParser(pgen)

    # Create a test suite

# Generated at 2022-06-18 09:34:14.658784
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_expression(self):
            from idlelib.idle_test.mock_idle import Func
            from idlelib.idle_test.mock_tk import Text

            text = Text()
            text.insert("1.0", "a.b.c.d")
            hp = HyperParser(text, "1.6")
            self.assertEqual(hp.get_expression(), "c")
            hp.set_index("1.8")
            self.assertEqual(hp.get_expression(), "")
            text.insert("1.0", "a.b(c.d)")
            hp = HyperParser(text, "1.10")

# Generated at 2022-06-18 09:34:18.755414
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    text = "'''abc''' 'def' '''ghi'''"
    for i in range(len(text)):
        hp = HyperParser(text, "%d.0" % i)
        assert hp.is_in_string() == (i in (0, 4, 8, 12, 16, 20))



# Generated at 2022-06-18 09:34:29.420155
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:34:40.831622
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest


# Generated at 2022-06-18 09:34:52.798688
# Unit test for method get_surrounding_brackets of class HyperParser

# Generated at 2022-06-18 09:35:02.677874
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        result = hp.get_surrounding_brackets()
        if result != expected:
            print("HyperParser.get_surrounding_brackets(%s, %s) -> %s, expected %s" % (
                repr(text), repr(index), repr(result), repr(expected)))
    test("a[1]", "1.0", None)
    test("a[1]", "1.1", ("1.0", "1.3"))
    test("a[1]", "1.2", ("1.0", "1.3"))
    test("a[1]", "1.3", None)
    test("a[1]", "insert", None)

# Generated at 2022-06-18 09:35:03.884108
# Unit test for method get_num_lines_in_stmt of class RoughParser

# Generated at 2022-06-18 09:35:10.771369
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    rp = RoughParser("    def foo():\n        pass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n    pass\n")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n        pass")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n        pass\n    ")
    assert rp.get_base_indent_string() == "    "
    rp = RoughParser("    def foo():\n        pass\n        ")
    assert rp.get_base_indent_string() == "        "

# Generated at 2022-06-18 09:35:21.691879
# Unit test for method get_base_indent_string of class RoughParser
def test_RoughParser_get_base_indent_string():
    def check(s, expected):
        rp = RoughParser(s, indent_width=4, tabwidth=8)
        assert rp.get_base_indent_string() == expected

    check("", "")
    check("\n", "")
    check("\n\n", "")
    check("\n\n\n", "")
    check("  \n", "  ")
    check("  \n  \n", "  ")
    check("  \n  \n  \n", "  ")
    check("  \n  \n  \n  \n", "  ")
    check("  \n  \n  \n  \n  \n", "  ")

# Generated at 2022-06-18 09:37:15.060564
# Unit test for method get_base_indent_string of class RoughParser

# Generated at 2022-06-18 09:37:23.938436
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:37:34.920703
# Unit test for method is_block_closer of class RoughParser

# Generated at 2022-06-18 09:37:38.246837
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    from idlelib.idle_test.mock_idle import Func
    from idlelib.idle_test.htest import run

    text = Text(None)

# Generated at 2022-06-18 09:37:48.619794
# Unit test for method get_surrounding_brackets of class HyperParser
def test_HyperParser_get_surrounding_brackets():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_surrounding_brackets(self):
            text = Text()
            text.insert("1.0", self.text)
            hp = HyperParser(text, "1.0")
            self.assertEqual(hp.get_surrounding_brackets(), self.result)

    class TestCase1(TestCase):
        text = "abc(def)"
        result = ("1.3", "1.7")

    class TestCase2(TestCase):
        text = "abc(def"
        result = None

    class TestCase3(TestCase):
        text = "abc(def"
        result = ("1.3", "1.end")


# Generated at 2022-06-18 09:37:59.517167
# Unit test for method is_in_string of class HyperParser
def test_HyperParser_is_in_string():
    # Test is_in_string
    text = Text(None, "")
    text.insert("insert", '"""a"""')
    text.mark_set("insert", "1.0")
    hp = HyperParser(text, "insert")
    assert hp.is_in_string()
    text.mark_set("insert", "1.1")
    hp.set_index("insert")
    assert hp.is_in_string()
    text.mark_set("insert", "1.2")
    hp.set_index("insert")
    assert hp.is_in_string()
    text.mark_set("insert", "1.3")
    hp.set_index("insert")
    assert not hp.is_in_string()
    text.mark_set("insert", "1.4")
    hp.set_

# Generated at 2022-06-18 09:38:10.310173
# Unit test for method get_continuation_type of class RoughParser

# Generated at 2022-06-18 09:38:21.378015
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    import unittest


# Generated at 2022-06-18 09:38:25.484739
# Unit test for method get_continuation_type of class RoughParser
def test_RoughParser_get_continuation_type():
    # pylint: disable=redefined-builtin

    def test(s, expected):
        parser = RoughParser(s, 0)
        actual = parser.get_continuation_type()
        assert actual == expected, (
            "expected %r, got %r for %r" % (expected, actual, s)
        )

    test("", C_NONE)
    test("\n", C_NONE)
    test("\n\n", C_NONE)
    test("\n\n\n", C_NONE)
    test("\n\n\n\n", C_NONE)
    test("\n\n\n\n\n", C_NONE)
    test("\n\n\n\n\n\n", C_NONE)

# Generated at 2022-06-18 09:38:30.066070
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        actual = hp.get_expression()
        if actual != expected:
            print("Error:")
            print("text:", repr(text))
            print("index:", index)
            print("expected:", repr(expected))
            print("actual:", repr(actual))
            print()
            raise AssertionError("test failed")

    test("", "1.0", "")
    test(" ", "1.0", "")
    test("\t", "1.0", "")
    test("\n", "1.0", "")
    test("#", "1.0", "")
    test("#\n", "1.0", "")
    test("#\n", "2.0", "")
   

# Generated at 2022-06-18 09:40:52.396310
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Test(TestCase):
        def test_set_index(self):
            from tkinter import Text

            text = Text()
            text.insert("insert", "a b c")
            hp = HyperParser(text, "1.0")
            hp.set_index("1.0")
            self.assertEqual(hp.indexinrawtext, 0)
            self.assertEqual(hp.indexbracket, 0)
            hp.set_index("1.1")
            self.assertEqual(hp.indexinrawtext, 1)
            self.assertEqual(hp.indexbracket, 0)
            hp.set_index("1.2")
            self.assertEqual(hp.indexinrawtext, 2)

# Generated at 2022-06-18 09:41:02.838550
# Unit test for method find_good_parse_start of class RoughParser

# Generated at 2022-06-18 09:41:11.041574
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    def test(text, index, expected):
        hp = HyperParser(text, index)
        result = hp.is_in_code()
        if result != expected:
            print(
                "HyperParser.is_in_code(%r, %r) -> %r, expected %r"
                % (text.get("1.0", "end"), index, result, expected)
            )

    # Test with a simple string
    test(
        "def f(x):\n" "    return x + 1\n",
        "1.0",
        True,
    )
    test(
        "def f(x):\n" "    return x + 1\n",
        "1.4",
        True,
    )

# Generated at 2022-06-18 09:41:15.464385
# Unit test for method set_lo of class RoughParser
def test_RoughParser_set_lo():
    rp = RoughParser()
    rp.set_lo("a = 1\nb = 2\n")
    assert rp.str == "a = 1\nb = 2\n"
    assert rp.goodlines == [0, 5, 10]
    assert rp.continuation == C_NONE
    assert rp.study_level == 1
    assert rp.stmt_start is None
    assert rp.stmt_end is None
    assert rp.lastch is None
    assert rp.lastopenbracketpos is None
    assert rp.stmt_bracketing is None


# Generated at 2022-06-18 09:41:23.078741
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_expression(self):
            def test(text, index, expected):
                hp = HyperParser(text, index)
                self.assertEqual(hp.get_expression(), expected)

            test("a", "1.0", "")
            test("a", "1.1", "a")
            test("a b", "1.2", "b")
            test("a b", "1.3", "")
            test("a b", "1.4", "")
            test("a b", "1.5", "")
            test("a b", "1.6", "")
            test("a b", "1.7", "")
            test("a b", "1.8", "")

# Generated at 2022-06-18 09:41:32.632159
# Unit test for method get_expression of class HyperParser
def test_HyperParser_get_expression():
    # This function tests the method get_expression of class HyperParser.
    # It is called by the unit test module.

    def test(text, index, expected):
        # Test the method get_expression of class HyperParser.
        # text is the text to be used.
        # index is the index to be used.
        # expected is the expected result.
        # If expected is None, an exception is expected.
        try:
            hp = HyperParser(text, index)
            result = hp.get_expression()
        except Exception:
            if expected is None:
                return
            else:
                raise
        if result != expected:
            raise AssertionError(
                "get_expression failed: %r != %r" % (result, expected)
            )

    # Test a simple identifier

# Generated at 2022-06-18 09:41:44.471635
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from idlelib.idle_test.mock_idle import Func
    from idlelib.idle_test.mock_tk import Mbox_func
    from idlelib.idle_test.htest import run

    def test_set_index(text, index, expected):
        hp = HyperParser(text, index)
        hp.set_index(index)
        actual = hp.indexbracket
        if actual != expected:
            Mbox_func("test_set_index", "expected %s, got %s" % (expected, actual))

    def test_set_index_1():
        text = Text(None, "")
        text.insert("1.0", "def f(x):\n    return x + 1\n")
        test_set_index(text, "1.0", 0)
       

# Generated at 2022-06-18 09:41:50.744368
# Unit test for method is_in_code of class HyperParser
def test_HyperParser_is_in_code():
    text = Text(None)
    text.insert("insert", "a = 1")
    hp = HyperParser(text, "insert")
    assert hp.is_in_code()
    text.insert("insert", " # comment")
    hp = HyperParser(text, "insert")
    assert not hp.is_in_code()
    text.insert("insert", ' "string"')
    hp = HyperParser(text, "insert")
    assert not hp.is_in_code()
    text.insert("insert", " 'string'")
    hp = HyperParser(text, "insert")
    assert not hp.is_in_code()
    text.insert("insert", " # comment")
    hp = HyperParser(text, "insert")
    assert not hp.is_in_code()

# Generated at 2022-06-18 09:42:00.348980
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    from unittest import TestCase

    class Test(TestCase):
        def test_set_index(self):
            from idlelib.idle_test.mock_idle import Func
            from idlelib.idle_test.mock_tk import Text

            text = Text()
            text.insert("insert", "a = 1\n")
            text.insert("insert", "b = 2\n")
            text.insert("insert", "c = 3\n")
            text.insert("insert", "d = 4\n")
            text.insert("insert", "e = 5\n")
            text.insert("insert", "f = 6\n")
            text.insert("insert", "g = 7\n")
            text.insert("insert", "h = 8\n")

# Generated at 2022-06-18 09:42:07.157499
# Unit test for method set_index of class HyperParser
def test_HyperParser_set_index():
    text = Text()
    text.insert("1.0", "a = 1\n")
    text.insert("2.0", "b = 2\n")
    text.insert("3.0", "c = 3\n")
    text.insert("4.0", "d = 4\n")
    text.insert("5.0", "e = 5\n")
    text.insert("6.0", "f = 6\n")
    text.insert("7.0", "g = 7\n")
    text.insert("8.0", "h = 8\n")
    text.insert("9.0", "i = 9\n")
    text.insert("10.0", "j = 10\n")
    text.insert("11.0", "k = 11\n")