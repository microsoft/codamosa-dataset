

# Generated at 2022-06-23 09:23:49.350468
# Unit test for constructor of class CacheModule
def test_CacheModule():

    test_object = CacheModule()
    
    test_object._load('C:\\Users\\user\\Documents\\Ansible\\ansible-2.9.7.0.zip')
    test_object._dump('', 'C:\\Users\\user\\Documents\\Ansible\\ansible-2.9.7.0.zip')

# Generated at 2022-06-23 09:23:50.903243
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c


# Generated at 2022-06-23 09:23:52.256702
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachemodule = CacheModule()
    assert isinstance(cachemodule, CacheModule)

# Generated at 2022-06-23 09:24:01.002227
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test if obj1, obj2 are both of the same type
    obj1 = CacheModule()
    obj2 = CacheModule()
    assert isinstance(obj1, CacheModule)
    assert isinstance(obj2, CacheModule)

    # Test if obj1, obj2 are the same object
    assert obj1 == obj2

    # Test if obj1, obj2 are different objects
    obj3 = CacheModule()
    assert obj1 is not obj3

    # Test if obj1, obj2 have the same hash value
    assert hash(obj1) == hash(obj2)

# Generated at 2022-06-23 09:24:04.054157
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # instantiate a CacheModule object
    cm = CacheModule()
    # test that the object was created correctly
    assert(cm._get_cache_basedir().endswith("/caches"))
    assert(cm._get_cache_basedir().startswith("/tmp"))
    cm._clean_cache()

# Generated at 2022-06-23 09:24:08.948042
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        global _cache_module
        _cache_module = CacheModule()
    except Exception as e:
        print(e)
        assert False

if __name__ == '__main__':
    # Run test for class CacheModule
    test_CacheModule()

# Generated at 2022-06-23 09:24:11.928990
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert not cm is None

# Generated at 2022-06-23 09:24:16.728154
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    plugin = CacheModule()
    assert plugin
    assert plugin._connection.base_path == os.path.join(plugin._connection.conf_basedir, 'ansible_fact_caching')

    plugin = CacheModule(connection={'base_path': '/tmp/file'})
    assert plugin._connection.base_path == '/tmp/file'

# Generated at 2022-06-23 09:24:28.668566
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    # public attributes
    assert '_timeout' in cm.__dict__
    assert '_connection' in cm.__dict__
    assert '_prefix' in cm.__dict__
    assert '_load' in cm.__dict__
    assert '_dump' in cm.__dict__
    assert '_flush' in cm.__dict__
    assert 'get' in cm.__dict__
    assert 'set' in cm.__dict__
    # private attributes
    assert '__dict__' in cm.__dict__
    assert '__weakref__' in cm.__dict__
    assert '__doc__' in cm.__dict__
    assert '__module__' in cm.__dict__
    assert '__annotations__' in cm.__dict__

# Generated at 2022-06-23 09:24:30.476756
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test an empty constructor.
    cache_module = CacheModule()
    assert cache_module is not None


# Generated at 2022-06-23 09:24:35.520925
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(None, {
        '_uri': '/tmp/ansible_test',
        '_prefix': 'ansible_test_',
        '_fact_caching_timeout': 3600
    })
    assert cache is not None, 'Created a cache object'
    assert cache._connection_info == {
        '_uri': '/tmp/ansible_test',
        '_prefix': 'ansible_test_',
        '_fact_caching_timeout': 3600
    }, 'Connection info is correct'

# Generated at 2022-06-23 09:24:38.838110
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        cacheModule = CacheModule()
    except Exception as error:
        print('test_CacheModule() raised exception error: %s' % str(error))
        assert False
        return False
    else:
        assert True
        return True


# Generated at 2022-06-23 09:24:40.582027
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import CacheModule
    CacheModule()

# Generated at 2022-06-23 09:24:41.343490
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()

# Generated at 2022-06-23 09:24:44.789168
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert type(obj._load) == type(CacheModule._load), "Type error in _load() method"
    assert type(obj._dump) == type(CacheModule._dump), "Type error in _dump() method"

# Generated at 2022-06-23 09:24:45.310827
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:24:47.092495
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Testing the constructor of CacheModule
    c = CacheModule()
    assert c.type == 'jsonfile'
    assert c.timeout == 86400

# Generated at 2022-06-23 09:24:48.226067
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({})
    assert cache._timeout == 86400

# Generated at 2022-06-23 09:24:49.060324
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mod = CacheModule()
    assert mod

# Generated at 2022-06-23 09:24:59.488868
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os

    cache_dir = os.path.join(os.path.dirname(__file__), 'cache_dir')
    cache_plugin = CacheModule(plugin='jsonfile', terms='', **{'_uri': cache_dir})

    assert cache_plugin._plugin == 'jsonfile'
    assert cache_plugin._connection == cache_dir
    assert cache_plugin._cache_dir == cache_dir

    cache_plugin_with_prefix = CacheModule(plugin='jsonfile', terms='', **
                                           {'_uri': cache_dir, '_prefix': 'ansible_facts'})
    assert cache_plugin_with_prefix._plugin == 'jsonfile'
    assert cache_plugin_with_prefix._connection == cache_dir

# Generated at 2022-06-23 09:25:02.217703
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache = CacheModule(
        _uri='$HOME/.ansible/tmp',
        _prefix='ansible-cache',
        _timeout=1000,
    )

    assert cache._timeout == 1000
    assert cache._prefix == 'ansible-cache'

# Generated at 2022-06-23 09:25:06.838456
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.plugin_name == 'jsonfile'
    assert cache_plugin._plugin_args == {'_uri': None, '_prefix': None, '_timeout': 86400}
    assert cache_plugin._connection is None
    assert cache_plugin._timeout == 86400
    assert cache_plugin._prefix == None

# Generated at 2022-06-23 09:25:07.921821
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-23 09:25:15.276742
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_connection = "path/to/json_file"
    cache_plugin_prefix = "ansible_facts"
    cache_plugin_timeout = 86400

    # Instantiate CacheModule class
    item = CacheModule()

    # Set values of class attributes
    item.set_options(direct={ "_uri" : cache_plugin_connection,
                              "_prefix" : cache_plugin_prefix,
                              "_timeout" : cache_plugin_timeout,
                              })

    # Get values of class attributes
    uri = item.get_option("_uri")
    prefix = item.get_option("_prefix")
    timeout = item.get_option("_timeout")

    # Asserts
    assert uri == cache_plugin_connection
    assert prefix == cache_plugin_prefix
    assert timeout == cache_plugin_timeout

# Generated at 2022-06-23 09:25:20.850700
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''Unit test for constructor of class CacheModule'''
    unit_under_test = CacheModule()
    assert isinstance(unit_under_test, BaseFileCacheModule), \
        "Unit under test should be an instance of class BaseFileCacheModule"
    assert hasattr(unit_under_test, '_dump')

# Generated at 2022-06-23 09:25:25.941601
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._cachefile_suffix == '.cache'
    cache = CacheModule()
    path = cache._connection._uri
    assert path == '$HOME/.ansible/tmp/ansible-caching'

# Generated at 2022-06-23 09:25:26.961086
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__doc__

# Generated at 2022-06-23 09:25:28.608640
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule(task=None)
    assert plugin._timeout == 86400

# Generated at 2022-06-23 09:25:32.142580
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('/tmp')
    assert cache._connection == '/tmp'
    assert cache._prefix == 'ansible-facts'
    assert cache._timeout == 86400
    assert cache.lock_path == '/tmp/.ansible-facts/cache.lock'
    assert cache.timeout == 86400

# Generated at 2022-06-23 09:25:39.278481
# Unit test for constructor of class CacheModule
def test_CacheModule():
    #
    # Create a cachedir named 'cachedir'
    # The default name is '.ansible_cachedir'
    #
    import os
    import tempfile
    cachedir = tempfile.mkdtemp()
    os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = cachedir
    cache_module = CacheModule()
    assert cache_module, "_uri is None"
    assert cache_module.cache_size() == 0, "Unexpected cache contents"
    assert cache_module.get('k1') == None, "Unexpected cache contents"
    assert cache_module.get('k2') == None, "Unexpected cache contents"
    assert cache_module.set('k1', 'v1'), "Unable to set or get key k1"

# Generated at 2022-06-23 09:25:40.597875
# Unit test for constructor of class CacheModule
def test_CacheModule():
  cache_module = CacheModule()
  assert cache_module

# Generated at 2022-06-23 09:25:43.340763
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._prefix == 'ansible-facts'
    assert plugin._timeout == 86400
    assert plugin._connection == ''

# Generated at 2022-06-23 09:25:54.614858
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-23 09:25:56.651214
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    cache._load('file')
    cache._dump('value', 'file')

# Generated at 2022-06-23 09:25:59.299253
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cmodule = CacheModule()
    cmodule.get('127.0.0.1')

# Generated at 2022-06-23 09:26:01.142807
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Check whether class CacheModule is defined
    assert 'CacheModule' in globals()

# Generated at 2022-06-23 09:26:13.616853
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Constructor of class CacheModule
    input_values = [
        {
            'ANSIBLE_CACHE_PLUGIN_CONNECTION': '/home/user/Documents/ansible-cache',
            'ANSIBLE_CACHE_PLUGIN_TIMEOUT': 10000,
            'ANSIBLE_CACHE_PLUGIN_PREFIX': 'ansible-hostname'
        }
    ]
    expected_values = [
        {
            '_timeout': 10000,
            '_prefix': 'ansible-hostname',
            '_uri': '/home/user/Documents/ansible-cache'
        }
    ]
    for input_value, expected_value in zip(input_values, expected_values):
        cache_module = CacheModule(input_value)

# Generated at 2022-06-23 09:26:15.346956
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert isinstance(m, CacheModule)

# Generated at 2022-06-23 09:26:18.120270
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filename = "/tmp/test.json"
    timeout = 604800
    cache_module = CacheModule(filename, timeout)
    assert timeout == cache_module._timeout

# Generated at 2022-06-23 09:26:22.223810
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj._prefix == 'ansible'
    assert obj._timeout == 86400
    assert obj._encoding == 'utf-8'

# Generated at 2022-06-23 09:26:25.834132
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachemodule = CacheModule(None)
    assert cachemodule is not None
    assert cachemodule._cachefile_extension == "json"

# Generated at 2022-06-23 09:26:28.270728
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    # TODO: add more assertions about the initial state
    assert isinstance(m, BaseFileCacheModule)

# Generated at 2022-06-23 09:26:31.701086
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cacheModule = CacheModule()
    assert cacheModule._load("/etc/ansible/facts.d/test01.fact") == {"someitem": "somevalue", "someitem2": [1,2,3]}

# Generated at 2022-06-23 09:26:32.372501
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert True

# Generated at 2022-06-23 09:26:36.179905
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(module_name='jsonfile',
                            module_args=dict({
                                '_uri': './',
                                '_prefix': 'ansible',
                                '_timeout': 120
                            }))) is not None


# Generated at 2022-06-23 09:26:36.788956
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:26:38.081411
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert isinstance(obj, BaseFileCacheModule)

# Generated at 2022-06-23 09:26:40.225785
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(None)
    assert cache_module._load('/') == {}
    assert cache_module._dump('', '/') == None

# Generated at 2022-06-23 09:26:40.795738
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-23 09:26:42.309753
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-23 09:26:51.345870
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Test default values of constructor
    cache_module = CacheModule({})
    assert cache_module.conn == ''
    assert cache_module.timeout == 86400

    # Test other values for constructor
    test_connection = "/tmp/test-connection"
    test_timeout = 100
    cache_module = CacheModule({"_uri": test_connection, "_timeout": test_timeout})
    assert cache_module.conn == test_connection
    assert cache_module.timeout == 100


# Generated at 2022-06-23 09:26:52.264208
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-23 09:26:57.335394
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    # Test all the methods in CacheModule
    c.get("test_key")
    c.set("test_key", "test_value")
    c.keys()
    c.contains("test_key")
    c.delete("test_key")
    c.flush()
    c.close()

# Generated at 2022-06-23 09:27:01.487489
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = '/home/ansible/jsonfile.json'
    timeout = 100
    prefix = 'ansible'
    json_cache = CacheModule(uri, timeout, prefix)

    assert(json_cache._timeout == timeout)
    assert(json_cache._prefix == prefix)
    assert(json_cache._basedir == uri)


# Generated at 2022-06-23 09:27:05.457488
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert not bool(CacheModule({}).__dict__)

# Generated at 2022-06-23 09:27:08.369704
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonfile_cache = CacheModule()

    # Test private variables
    assert jsonfile_cache._load
    assert jsonfile_cache._dump


# Generated at 2022-06-23 09:27:10.433405
# Unit test for constructor of class CacheModule
def test_CacheModule():
    example_plugin_name = CacheModule()
    assert isinstance(example_plugin_name,BaseFileCacheModule)

# Generated at 2022-06-23 09:27:13.741995
# Unit test for constructor of class CacheModule
def test_CacheModule():
    file = CacheModule()
    assert file.__class__.__name__ == 'CacheModule'

# Generated at 2022-06-23 09:27:16.438254
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ca = CacheModule()
    # Can be ignored, this is just to test if the class have been invoked properly
    print(ca.terminated)
    assert(ca.terminated == False)

# Generated at 2022-06-23 09:27:21.046843
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ansible_config_file_path = '/etc/ansible/ansible.cfg'
    config_file_path = None
    data = {}
    timeout = None
    cache_plugin = CacheModule(ansible_config_file_path, config_file_path, data, timeout)
    assert cache_plugin._directory == '/etc/ansible/cachedir' or cache_plugin._directory == '/etc/ansible/cached'
    assert cache_plugin._timeout == 86400
    assert cache_plugin._plugin_name == 'jsonfile'

# Generated at 2022-06-23 09:27:22.595342
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj

# Generated at 2022-06-23 09:27:25.012205
# Unit test for constructor of class CacheModule
def test_CacheModule():
    queue = None
    CacheModule(queue)

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:27:26.213157
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()

# Generated at 2022-06-23 09:27:28.941149
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m._connection.replace('\\','/').endswith('/plugins/cache/jsonfile.py')

# Generated at 2022-06-23 09:27:38.812262
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    cache_path = '/tmp/facts/'
    cache_prefix = 'test'
    timeout = 60

    # Check the file doesn't exist
    file_path = os.path.join(cache_path, cache_prefix)
    if os.path.exists(file_path):
        os.remove(file_path)

    # Check the cache path doesn't exist
    if os.path.exists(cache_path):
        os.rmdir(cache_path)

    # Check the cache constructor creates the cache file
    cache = CacheModule({'_uri': cache_path, '_prefix': cache_prefix, '_timeout': timeout})
    assert os.path.exists(cache._file)

    # Check the cache constructor creates the cache path
    assert os.path.exists(cache_path)

   

# Generated at 2022-06-23 09:27:44.706023
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin_class = 'jsonfile'
    path = '/path/to/jsonfile'
    prefix = 'jsonfile'
    timeout = 86400
    source_dict = {'plugin_class': plugin_class, 'path': path, 'prefix': prefix, 'timeout': timeout}
    cm = CacheModule(source_dict)
    assert cm.uri == path
    assert cm.prefix == prefix
    assert cm.timeout == timeout

# Generated at 2022-06-23 09:27:47.846127
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_obj = CacheModule()
    assert cache_obj is not None

# Generated at 2022-06-23 09:27:51.345644
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Construct and assert initial state of object
    my_cm = CacheModule()
    assert my_cm._prefix == 'ansible-fact-cache'
    assert my_cm._timeout == 86400

# Generated at 2022-06-23 09:27:54.728059
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.get_timeout() == 86400
    assert c._prefix == 'ansible-cache'
    assert c.get_connection() == u''
    assert c._load_name == '_load'
    assert c._dump_name == '_dump'

# Generated at 2022-06-23 09:27:58.018260
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache._load, object)
    assert isinstance(cache._dump, object)

# Generated at 2022-06-23 09:27:58.848543
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:27:59.443794
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-23 09:28:00.709332
# Unit test for constructor of class CacheModule
def test_CacheModule():
    caching = CacheModule()

# Generated at 2022-06-23 09:28:02.230882
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(foo='bar'))

# Generated at 2022-06-23 09:28:12.332212
# Unit test for constructor of class CacheModule
def test_CacheModule():
    config = dict(
        _prefix='some_prefix',
        _timeout=123,
        _listnames=['list1', 'list2', 'list3'],
        _fact_lists=['list2', 'list3'],
        _fact_path='.',
    )
    cache = CacheModule(config)
    assert cache._prefix == config['_prefix']
    assert cache._timeout == config['_timeout']
    assert cache._listnames == config['_listnames']
    assert cache._fact_lists == config['_fact_lists']
    assert cache._fact_path == config['_fact_path']

# Generated at 2022-06-23 09:28:14.396883
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache_plugin = CacheModule()
    assert cache_plugin is not None


# Generated at 2022-06-23 09:28:15.616181
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module is not None

# Generated at 2022-06-23 09:28:25.938184
# Unit test for constructor of class CacheModule
def test_CacheModule():
    results = {}
    test_CacheModule = CacheModule()

# Generated at 2022-06-23 09:28:29.171890
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test that we use BaseFileCacheModule as superclass
    BaseFileCacheModule.__call__(CacheModule())

# Generated at 2022-06-23 09:28:30.644211
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'test_uri'})

# Generated at 2022-06-23 09:28:32.486300
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule(connection='./cache')
    assert isinstance(module, CacheModule)

# Generated at 2022-06-23 09:28:38.583337
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule(connection={'name': '', 'port': '', 'host': '', 'password': '', 'user': ''}, module_implementation_preferences=('',), become_method= ('',), become_user='', become_password='', check=False, diff=False)
    if type(module) == CacheModule:
        pass
    else:
        raise Exception("test_CacheModule")

# Generated at 2022-06-23 09:28:45.942635
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = '~/temp'
    prefix = 'test_cache'
    timeout = '86400'
    cache = CacheModule()
    # use an invalid path to check the uri
    assert cache._load is not None
    assert cache._dump is not None
    assert cache._uri is not None
    assert cache._prefix is not None
    assert cache._timeout is not None
    assert uri == cache._uri
    assert prefix == cache._prefix
    assert timeout == cache._timeout

# Generated at 2022-06-23 09:28:49.329643
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None
    assert cache._load('/tmp/test') is None
    cache._dump('foo', '/tmp/test')
    assert cache._load('/tmp/test') == 'foo'

# Generated at 2022-06-23 09:28:57.914536
# Unit test for constructor of class CacheModule
def test_CacheModule():
    config = dict(
        _uri='/home/.ansible/tmp/ansible-tmp-1541156991.25-257476636013560/',
        _prefix='ansible-factcache',
        _timeout=86400
    )
    cache = CacheModule(config)
    assert cache._timeout == config['_timeout']
    assert cache._connection == config['_uri']
    assert cache._prefix == config['_prefix']


# Generated at 2022-06-23 09:29:05.104977
# Unit test for constructor of class CacheModule
def test_CacheModule():

    assert issubclass(CacheModule, BaseFileCacheModule)

    instance = CacheModule('/example/path')

    assert isinstance(instance, CacheModule)

    assert isinstance(instance.cache, BaseFileCacheModule)

    assert instance._load('/example/path') == {}

    assert instance._dump({}, '/example/path') is None

    assert instance._timeout == 86400

# Generated at 2022-06-23 09:29:08.932378
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('/path/to/file', 'prefix_', 300)
    assert cache._timeout == 300
    assert cache._uri == '/path/to/file'
    assert cache._prefix == 'prefix_'



# Generated at 2022-06-23 09:29:16.532308
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_options = {'_uri': '/tmp', '_timeout': 10}

    # Create CacheModule instance with test default options
    test_cache_module = CacheModule(mock_connection_load(test_options))

    # Initialize CacheModule  instance
    test_cache_module.init_plugin()

    # Try to get cache data for an empty cache
    assert test_cache_module.get('test_cache_item') is None

    # Set cache item data
    test_cache_data = {'test_key': 'test_value'}
    test_cache_module.set('test_cache_item', test_cache_data)

    # Try to get cached data item
    assert test_cache_module.get('test_cache_item') == test_cache_data

    # Make sure the cache data is only available for timeout seconds

# Generated at 2022-06-23 09:29:21.191073
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)
    assert cm._uri == u'~/.ansible/tmp/ansible-fact-cache'
    assert cm._timeout == 86400
    assert cm._prefix is None

# Generated at 2022-06-23 09:29:23.538919
# Unit test for constructor of class CacheModule
def test_CacheModule():
  bfm = CacheModule()
  assert bfm.get_timeout() == 86400

# Generated at 2022-06-23 09:29:33.342931
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    # Check '_load' method
    cache._cachefile = dict()
    cache._cachefile['data'] = dict({'test_data': 'test_value'})
    assert cache._load(cache._cachefile) == dict({'test_data': 'test_value'})
    cache._cachefile = dict()

    # Check '_dump' method
    cache._cachefile = dict()
    val = dict({'test_data': 'test_value'})
    cache._dump(val, cache._cachefile)
    assert cache._cachefile['data'] == dict({'test_data': 'test_value'})
    cache._cachefile = dict()


# Generated at 2022-06-23 09:29:36.602550
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert(cache.plugin_name == 'jsonfile')
    assert(cache.plugin_path ==  '/Users/lcl/git_prj/ansible/lib/ansible/plugins/cache/jsonfile.py')


# Generated at 2022-06-23 09:29:44.378866
# Unit test for constructor of class CacheModule
def test_CacheModule():
    extra_args = dict()
    extra_args['_uri'] = './'
    extra_args['_timeout'] = 86400
    test_instance = CacheModule(extra_args)
    assert test_instance.plugin_name == 'jsonfile'
    assert test_instance.plugin_path == './'
    assert test_instance.plugin_timeout == 86400

# Generated at 2022-06-23 09:29:45.460398
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__init__


# Generated at 2022-06-23 09:29:47.008322
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert ansible.plugins.cache.jsonfile.CacheModule() is not None

# Generated at 2022-06-23 09:29:48.050049
# Unit test for constructor of class CacheModule
def test_CacheModule():
  x = CacheModule()

# Generated at 2022-06-23 09:29:49.584853
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-23 09:29:51.085377
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_timeout': '1'})
    assert cache.timeout == 1

# Generated at 2022-06-23 09:29:52.781052
# Unit test for constructor of class CacheModule
def test_CacheModule():
    myCacheModule = CacheModule(task=None, vars=dict())
    assert myCacheModule is not None

# Generated at 2022-06-23 09:29:59.639163
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # It is necessary to execute this function to test the constructor.
    # This function is called by the pytest when this file is executed.
    cache_dir = 'cache_dir'
    cache_connection = 'cache_connection'
    cache_timeout = 42
    cache_prefix = 'cache_prefix'

    assert CacheModule(cache_dir, cache_connection, cache_timeout, cache_prefix)._directory == cache_dir
    assert CacheModule(cache_dir, cache_connection, cache_timeout, cache_prefix)._timeout == cache_timeout
    assert CacheModule(cache_dir, cache_connection, cache_timeout, cache_prefix)._connection == cache_connection
    assert CacheModule(cache_dir, cache_connection, cache_timeout, cache_prefix)._prefix == cache_prefix

# Generated at 2022-06-23 09:30:01.102312
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule({'_uri': '/tmp'})

# Generated at 2022-06-23 09:30:06.553051
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = '/path/to/fact_cache'
    prefix = 'ansible_facts'
    timeout = 10
    cache = CacheModule(connection, prefix, timeout)
    assert cache._uri == connection
    assert cache._prefix == prefix
    assert cache._timeout == timeout

# Generated at 2022-06-23 09:30:07.565746
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()


# Generated at 2022-06-23 09:30:12.125055
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        import ansible.plugins.cache.jsonfile
        print("Successfully imported ansible.plugins.cache.jsonfile")
    except ImportError:
        print("Failed to import ansible.plugins.cache.jsonfile, Exception: %s" % ImportError)

# Generated at 2022-06-23 09:30:13.254768
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin

# Generated at 2022-06-23 09:30:14.065137
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-23 09:30:19.064577
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test if the constructor can be called
    obj = CacheModule('/some/path')
    assert obj._connection is not None
    assert obj._prefix is None

    obj = CacheModule('/some/path', prefix='test')
    assert obj._connection is not None
    assert obj._prefix == 'test'

    obj = CacheModule('/some/path', timeout=3600)
    assert obj._connection is not None
    assert obj._timeout == 3600

    obj = CacheModule('/some/path', 'test', 3600)
    assert obj._connection is not None
    assert obj._prefix == 'test'
    assert obj._timeout == 3600

# Generated at 2022-06-23 09:30:21.009811
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m._load == m._load
    assert m._dump == m._dump

# Generated at 2022-06-23 09:30:22.729213
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule() is not None

# Generated at 2022-06-23 09:30:26.230138
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Test that the constructor of CacheModule work as expected.
    """
    # Construct the object.
    obj = CacheModule()

    # Test the object.
    assert obj.get_cache_timeout() == 86400

# Generated at 2022-06-23 09:30:29.410784
# Unit test for constructor of class CacheModule
def test_CacheModule():
    #import pdb; pdb.set_trace()
    plugin = CacheModule({'_uri': '/test/test1'})
    assert plugin._connection._uri == '/test/test1'

# Generated at 2022-06-23 09:30:31.048135
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_timeout == 86400
    assert cache.cache_prefix == 'ansible_'
    assert cache.cache_connection == None

# Generated at 2022-06-23 09:30:39.583367
# Unit test for constructor of class CacheModule
def test_CacheModule():
    class Mock(object):
        def __init__(self, facts):
            self.ansible_facts = facts

    args = {
        '_uri': '/path/to/somewhere',
        '_prefix': 'some_prefix',
        '_timeout': '3600',
    }
    plugin = CacheModule(Mock(args))
    assert plugin._uri == '/path/to/somewhere'
    assert plugin._prefix == 'some_prefix'
    assert plugin._timeout == 3600

# Generated at 2022-06-23 09:30:41.478638
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert 'cache' in globals()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-23 09:30:42.240650
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:30:43.368423
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule() is not None

# Generated at 2022-06-23 09:30:48.935906
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule({})
    assert plugin.get_option('plugin_name', default=None) == 'jsonfile'
    assert plugin.get_option('_prefix', default=None) == 'ansible_facts'
    assert plugin.get_option('_timeout', default=None) == 86400

# Generated at 2022-06-23 09:30:56.474894
# Unit test for constructor of class CacheModule
def test_CacheModule():
    tmpdir = "/tmp"
    name = "jsonfile"
    task_uuid = "5f539e3c-4a4e-4f32-9620-8a15ecdf7743"
    play_uuid = "8f539e3c-4a4e-4f32-9620-8a15ecdf7743"
    result = {}
    cache = CacheModule(tmpdir, name, task_uuid, play_uuid, result)
    assert cache._basedir == tmpdir
    assert cache._name == name
    assert cache._task_uuid == task_uuid
    assert cache._play_uuid == play_uuid
    assert cache._result == result


# Generated at 2022-06-23 09:31:01.121179
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    Unit test for constructor of class CacheModule
    '''
    m = CacheModule()
    assert m._connection == '/tmp'
    assert m._timeout == 86400
    assert m._prefix == ''

# Generated at 2022-06-23 09:31:02.489660
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

# Generated at 2022-06-23 09:31:09.217121
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Load the class
    cache = CacheModule()
    # See if the class is of the right type
    assert(isinstance(cache, CacheModule))


# Generated at 2022-06-23 09:31:10.431832
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({}) is not None

# Generated at 2022-06-23 09:31:13.118393
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Get a new instance of CacheModule class
    cacheModule = CacheModule()

    # Check correct type of object
    assert type(cacheModule) is CacheModule


# Generated at 2022-06-23 09:31:15.528316
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_instance = CacheModule(dict(
        _timeout=86400,
        _prefix='',
        _uri='/tmp/ansible_cache'
    ))
    assert cache_instance

# Generated at 2022-06-23 09:31:22.738854
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachedir = '/tmp'
    timeout = 1
    cm = CacheModule()
    cm._timeout = timeout
    cm.configure(cachedir, {})

    if cm.has_expired():
        print("Expired - CacheModule()")
    else:
        print("Not expired - CacheModule()")

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:31:24.125029
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:31:27.715255
# Unit test for constructor of class CacheModule
def test_CacheModule():
    global cache
    cache = dict(
        _connection='cache',
        _prefix=None,
        _timeout=3600
    )
    cache_module = CacheModule(cache)
    assert cache_module

# Generated at 2022-06-23 09:31:29.023745
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-23 09:31:30.233189
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache



# Generated at 2022-06-23 09:31:33.748821
# Unit test for constructor of class CacheModule
def test_CacheModule():
    host = 'host'
    data = {host: ['foo', 'bar']}
    cache = CacheModule(data)
    assert cache.plugin_name == 'jsonfile'
    assert cache.plugin_timeout == 86400
    assert cache.data[host] == ['foo', 'bar']

# Generated at 2022-06-23 09:31:41.280975
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # test for Windows OS
    #  noinspection PyTypeChecker
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2

    if PY2:
        cache_mod = CacheModule({
            u'_uri': to_bytes(u'C:\\Users\\Administrator\\AppData\\Local\\Temp\\ansible-facts'),
            u'_prefix': to_bytes(u'prefix'),
            u'_timeout': 360
        })
    else:
        cache_mod = CacheModule({
            u'_uri': to_bytes('C:\\Users\\Administrator\\AppData\\Local\\Temp\\ansible-facts'),
            u'_prefix': to_bytes('prefix'),
            u'_timeout': 360
        })

    assert cache_mod._timeout == 360


# Generated at 2022-06-23 09:31:53.233268
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # We are going to create file under /tmp/ansible_test_cm, so create this dir first
    import os, shutil
    # Create tmp dir
    dir = '/tmp/ansible_test_cm'
    if not os.path.exists(dir):
        os.makedirs(dir)
    # Create CacheModule object
    cm = CacheModule({'_uri': dir})

    # Test get function
    for key in ['key1', 'key2', 'key3']:
        value = 'value %s' % key
        cm.set(key, value)
        assert cm.get(key) == value

    # Test set function
    for key in ['key1', 'key2', 'key3']:
        value = 'value %s' % key
        cm.set(key, value)
        assert cm

# Generated at 2022-06-23 09:31:54.042516
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load is not None and cache._dump is not None

# Generated at 2022-06-23 09:32:02.514425
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create an instance of CacheModule derived class
    a = CacheModule()

    # Check the instance was created correctly
    if(a is not None):
        print('test_CacheModule(): Constructor works.')
    else:
        print('test_CacheModule(): Constructor failed.')

test_CacheModule()

# Generated at 2022-06-23 09:32:06.243178
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    Test call to constructor of class CacheModule.
    '''
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-23 09:32:07.218827
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert True

# Generated at 2022-06-23 09:32:09.935436
# Unit test for constructor of class CacheModule
def test_CacheModule():
    args = {
        '_uri': '/tmp',
        '_prefix': 'test',
        '_timeout': 86400,
    }

    cache = CacheModule(args)
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-23 09:32:12.062891
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert isinstance(cache_plugin, CacheModule)

# Generated at 2022-06-23 09:32:13.800669
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()

    assert cache_plugin.get_file_extension() == 'json'

# Generated at 2022-06-23 09:32:15.429513
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({})
    assert cache.get_basedir() == "/tmp"


# Generated at 2022-06-23 09:32:16.947274
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-23 09:32:19.146258
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert(cm != None)

# Generated at 2022-06-23 09:32:21.391427
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(uri='/tmp/', timeout=10)
    assert cache._plugin_options['destination'] == '/tmp/'
    assert cache._plugin_options['timeout'] == 10

# Generated at 2022-06-23 09:32:22.314717
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-23 09:32:30.118579
# Unit test for constructor of class CacheModule

# Generated at 2022-06-23 09:32:31.086324
# Unit test for constructor of class CacheModule
def test_CacheModule():
    return CacheModule({'_timeout':1})

# Generated at 2022-06-23 09:32:37.299144
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.get_timeout() == 86400
    assert cm.get_connection() != ''

    cm = CacheModule(timeout=3000)
    assert cm.get_timeout() == 3000
    assert cm.get_connection() != ''

    cm = CacheModule(connection='/foo')
    assert cm.get_timeout() == 86400
    assert cm.get_connection() == '/foo'

    cm = CacheModule(timeout=4000, connection='/bar')
    assert cm.get_timeout() == 4000
    assert cm.get_connection() == '/bar'

# Generated at 2022-06-23 09:32:38.528607
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test constructor
    cache = CacheModule()
    assert isinstance(cache, CacheModule)
    assert isinstance(cache, BaseFileCacheModule)
    assert cache._cachefile is None
    assert cache._timeout == 86400

# Generated at 2022-06-23 09:32:40.316457
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(isinstance(CacheModule(), dict))
    assert(isinstance(CacheModule()['_timeout'], int))

# Generated at 2022-06-23 09:32:47.081717
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(conn_path='/tmp/ansible-fact-cache')).get_filename('localhost') == '/tmp/ansible-fact-cache/ansible-facts-localhost.json'
    assert CacheModule(dict(conn_path='/tmp/ansible-fact-cache', timeout=86400)).get_filename('localhost') == '/tmp/ansible-fact-cache/ansible-facts-localhost.json'
    assert CacheModule(dict(conn_path='/tmp/ansible-fact-cache', timeout=86400, prefix='facts_')).get_filename('localhost') == '/tmp/ansible-fact-cache/facts_localhost.json'

# Generated at 2022-06-23 09:32:49.768961
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert isinstance(obj, CacheModule)


# Generated at 2022-06-23 09:32:51.085537
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})


# Generated at 2022-06-23 09:32:59.810055
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'plugin': 'cache.jsonfile', '_uri': '/tmp'}) is not None
    assert CacheModule({'plugin': 'cache.jsonfile', '_uri': '/tmp', '_prefix': 'myprefix'}) is not None
    assert CacheModule({'plugin': 'cache.jsonfile', '_uri': '/tmp', '_timeout': 3600}) is not None
    assert CacheModule({'plugin': 'cache.jsonfile', '_uri': '/tmp', '_prefix': 'myprefix', '_timeout': 3600}) is not None

# Generated at 2022-06-23 09:33:03.662085
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = 'ansible.plugins.cache.jsonfile'
    module = __import__(module, fromlist=['CacheModule'])
    class_ = getattr(module, 'CacheModule')
    cache = class_()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-23 09:33:05.667712
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert isinstance(cache_module, CacheModule)

# Generated at 2022-06-23 09:33:08.614460
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._timeout == 86400
    assert cm._prefix == ''
    assert cm._connection == ''

# Generated at 2022-06-23 09:33:09.785071
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(None)

# Generated at 2022-06-23 09:33:11.773262
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    Test for constructor of class CacheModule
    '''
    cache = CacheModule()
    assert cache

# Generated at 2022-06-23 09:33:23.184811
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_file = '/tmp/ansible/cache_file'
    cache_timeout = 1800

    frozenset_expected = frozenset(('_uri', '_prefix', '_timeout'))

    cache_module = CacheModule(cache_file, cache_timeout)

    # Test attributes and their values
    assert cache_module._file_path == cache_file
    assert cache_module._max_age == cache_timeout
    assert cache_module._cached_value == {}
    assert cache_module._listeners == []
    assert cache_module._timeout == cache_timeout
    assert cache_module.has_expired() == False
    assert cache_module.cache_args == frozenset_expected
    assert cache_module.lock_path == cache_file + '.lock'

    # Test if the encoded value is None
    data = cache

# Generated at 2022-06-23 09:33:25.090272
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    cache_plugin = module.get_cache_plugin( 10, '', '','')
    assert cache_plugin

# Generated at 2022-06-23 09:33:28.097453
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.cache.jsonfile import CacheModule as jsonfile
    c = cache_loader.get('jsonfile', None)
    assert c.__class__ is jsonfile

# Generated at 2022-06-23 09:33:29.424147
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule(3)
    assert(c._timeout == 3)

# Generated at 2022-06-23 09:33:31.957236
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._timeout == 86400
    assert c._plugin_name == 'jsonfile'

# Generated at 2022-06-23 09:33:34.919395
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert hasattr(obj, '_load')
    assert hasattr(obj, '_dump')

# Generated at 2022-06-23 09:33:39.527423
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule('/tmp/test-cache')

    assert plugin is not None
    assert plugin.timeout == 86400
    assert plugin._connection.os.path.isdir('/tmp/test-cache')
    assert plugin._get_cachefile_path() == '/tmp/test-cache/ansible-facts'

# Generated at 2022-06-23 09:33:42.730269
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule(play_context=None, new_play=None)
    obj._load("/tmp/test.json")
    obj._dump("test", "/tmp/test.json")