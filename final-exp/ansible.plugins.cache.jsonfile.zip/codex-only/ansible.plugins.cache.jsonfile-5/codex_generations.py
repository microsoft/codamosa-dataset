

# Generated at 2022-06-23 09:23:52.546032
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._connection is None
    assert cache_plugin._timeout == 86400
    assert cache_plugin._prefix == 'ansible-facts'

    # Test overriding the prefix via user-supplied ANSIBLE_CACHE_PLUGIN_PREFIX
    _prefix_value = 'my-prefix'
    cache_plugin = CacheModule(connection='connection', _prefix=_prefix_value)
    assert cache_plugin._prefix == _prefix_value

    # Test overriding the prefix via user-supplied fact_caching_prefix
    _prefix_value = 'my-prefix'
    cache_plugin = CacheModule(connection='connection', _fact_caching_prefix=_prefix_value)
    assert cache_plugin._prefix == _prefix_value

    # Test overriding the connection

# Generated at 2022-06-23 09:23:56.431097
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache_plugin_connection = 'test_path'
    cache_plugin_prefix = 'test_prefix'
    cache_plugin_timeout = 100

    test_cache_plugin = CacheModule(
        None,
        False,
        'test_plugin',
        {
            '_uri': cache_plugin_connection,
            '_prefix': cache_plugin_prefix,
            '_timeout': cache_plugin_timeout,
        }
    )

    assert test_cache_plugin._connection == cache_plugin_connection
    assert test_cache_plugin._prefix == cache_plugin_prefix
    assert test_cache_plugin._timeout == cache_plugin_timeout

# Generated at 2022-06-23 09:23:57.602742
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': '/tmp'})
    assert cache

# Generated at 2022-06-23 09:23:59.428227
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module


# Unit tests for methods CacheModule._load and CacheModule._dump

# Generated at 2022-06-23 09:24:01.789031
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Constructor of class CacheModule sets appropriate values"""
    cache = CacheModule()
    assert cache.config == {'_timeout': 86400}
    assert cache._cachefile is None
    assert cache._cache is None

# Generated at 2022-06-23 09:24:07.958783
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule(plugin=dict(_uri='/tmp/', _connection=None, _prefix=None))
    assert c.plugin['_uri'] == '/tmp/'
    assert c.plugin['_connection'] is None
    assert c.plugin['_prefix'] is None

# Generated at 2022-06-23 09:24:09.140006
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print(CacheModule)
    cache = CacheModule()
    print(cache)

# Generated at 2022-06-23 09:24:14.415786
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_option('_prefix') == 'ansible_facts'
    assert cache_plugin.get_option('_timeout') == 86400

# Generated at 2022-06-23 09:24:15.424733
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()

# Generated at 2022-06-23 09:24:17.137945
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        cm = CacheModule()
    except:
        raise


# Generated at 2022-06-23 09:24:29.456934
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test that CacheModule throws exception when using unsupported URI
    supported_uri = 'memory:///'
    mock_uri = 'http://mock.uri'
    try:
        CacheModule(mock_uri)
        assert False, 'An exception was expected'
    except Exception as e:
        assert e.message == 'Plugin memory does not support connection uri scheme: ' + mock_uri

    # Test that CacheModule throws exception when using unsupported prefix
    supported_prefix = 'ansible_cache_'
    mock_prefix = 'mock_prefix'
    try:
        CacheModule(supported_uri, mock_prefix)
        assert False, 'An exception was expected'
    except Exception as e:
        assert e.message == 'Plugin memory does not support prefix: ' + mock_prefix

    # Test that CacheModule throws exception when using unsupported timeout


# Generated at 2022-06-23 09:24:31.772777
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule(dict(plugin_name="jsonfile", plugin_args=None))
    assert plugin.name == "jsonfile"
    assert plugin.timeout == 86400

# Generated at 2022-06-23 09:24:35.713250
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with default constructor
    cacheModule = CacheModule()
    assert cacheModule.timeout == 86400

    # Test with constructor with parameters
    timeout = 1800
    cacheModule = CacheModule(timeout=timeout)
    assert cacheModule.timeout == timeout

    # Test with constructor with parameters
    timeout = None
    cacheModule = CacheModule(timeout=timeout)
    assert cacheModule.timeout == 86400

# Generated at 2022-06-23 09:24:40.687321
# Unit test for constructor of class CacheModule
def test_CacheModule():
    expected_base_class = BaseFileCacheModule

    class_name = 'CacheModule'
    try:
        class_obj = globals()[class_name]
        class_test_obj = class_obj()
    except KeyError:
        assert False, 'Missing class {}'.format(class_name)

    assert isinstance(class_test_obj, expected_base_class), '{} is not an instance of {}'.format(class_name, expected_base_class)


# Generated at 2022-06-23 09:24:50.508288
# Unit test for constructor of class CacheModule
def test_CacheModule():

    import os
    dir_name = 'test_dir'
    file_name = 'test_file'
    dir_path = os.path.join(os.getcwd(), dir_name)
    file_path = os.path.join(dir_path, file_name)


# Generated at 2022-06-23 09:24:53.575872
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = '~/.ansible/tmp'
    timeout = 10
    obj = CacheModule(uri, timeout)
    assert obj.uri == '~/.ansible/tmp'
    assert obj.timeout == 10

# Generated at 2022-06-23 09:24:57.467972
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # This is a temporary hack until we have a proper core-supported plugin interface for
    # unit testing
    from ansible.plugins import cache_loader

    loader = cache_loader.get('jsonfile')
    instance = loader.get('jsonfile', {})

    assert isinstance(instance, CacheModule)

# Generated at 2022-06-23 09:24:59.500212
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module is not None, "CacheModule object could not be created"

# Generated at 2022-06-23 09:25:11.385927
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with open('ansible/plugins/cache/jsonfile.py') as f:
        module_data = f.read()

    # Create the module instance
    cm = CacheModule()

    # Check the metadata
    assert cm.get_metadata() == dict(
        status=True,
        supported_by="core",
    )

    # Check the documentation
    assert cm.get_doc() == DOCUMENTATION

    # Check the options

# Generated at 2022-06-23 09:25:17.204801
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert not hasattr(CacheModule, '_load')
    assert not hasattr(CacheModule, '_dump')

    module = CacheModule()
    assert hasattr(module, '_load')
    assert hasattr(module, '_dump')


# Generated at 2022-06-23 09:25:19.012791
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-23 09:25:21.176583
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test on known values
    cache = CacheModule('/tmp', 'prefix')
    assert cache._connection == '/tmp'
    assert cache._prefix == 'prefix'

# Test save

# Generated at 2022-06-23 09:25:30.954702
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import os.path

    # setup
    test_cache_path = os.path.join(os.path.dirname(__file__), "cache_test_dir")
    args_to_pass = {}
    args_to_pass['_uri'] = test_cache_path
    args_to_pass['_prefix'] = "prefix_"

    # test constructor
    cache = CacheModule(**args_to_pass)
    assert cache._connection == test_cache_path
    assert cache._prefix == "prefix_"

    # teardown
    os.removedirs(test_cache_path)

# Generated at 2022-06-23 09:25:32.365478
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule('./tmp')


# Generated at 2022-06-23 09:25:33.635787
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert(cm != None)

# Generated at 2022-06-23 09:25:36.552650
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_basedir() is not None


# Generated at 2022-06-23 09:25:41.858651
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._encrypt is False
    assert cache._plugin_name == 'jsonfile'
    assert cache._prefix == 'ansible_'
    assert cache._uri is None

# Generated at 2022-06-23 09:25:45.715052
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Instantiate a CacheModule object.
    cacheModule = CacheModule()

    # Assert values of properties.
    assert cacheModule.file_extension == "json"
    assert cacheModule.supports_preloading is True

# Unit tests for method _load of class CacheModule.
from ansible.plugins.cache.jsonfile import test_data


# Generated at 2022-06-23 09:25:46.187876
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:25:47.995456
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # ?????
    pass

# Generated at 2022-06-23 09:25:50.812624
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None
    assert cache.plugin_name == 'jsonfile'
    assert cache.expiration_time is not None
    assert cache.plugin_timeout is not None

# Generated at 2022-06-23 09:25:57.181620
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # uri can't be None
    res = None

    try:
        res = CacheModule()
    except Exception as e:
        # print(('Exception: %s', str(e)))
        pass

    assert res is None

    # uri can be folder
    os_path = os.path.normpath(os.path.join(os.getcwd(), 'test_folder'))

    try:
        res = CacheModule(uri=os_path)
    except Exception as e:
        # print(('Exception: %s', str(e)))
        assert False

    assert res is not None
    assert res.uri == os_path

# Generated at 2022-06-23 09:25:58.968749
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-23 09:26:08.158439
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._uri.default == '~/.ansible/cache'
    assert CacheModule._uri.type is str
    assert CacheModule._uri.required is True
    assert CacheModule._uri.description == 'Path in which the cache plugin will save the JSON files'
    assert CacheModule._uri.ini_key == 'fact_caching_connection'
    assert CacheModule._uri.ini_section == 'defaults'

    assert CacheModule._prefix.type is str
    assert CacheModule._prefix.description == 'User defined prefix to use when creating the JSON files'
    assert CacheModule._prefix.ini_key == 'fact_caching_prefix'
    assert CacheModule._prefix.ini_section == 'defaults'

    assert CacheModule._timeout.default == 86400
    assert CacheModule._timeout.type is int

# Generated at 2022-06-23 09:26:10.068333
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._timeout == 86400
    assert module._cache._basedir == "."

# Generated at 2022-06-23 09:26:14.524557
# Unit test for constructor of class CacheModule
def test_CacheModule():
    class cache_module:
        def __init__(self, path, timeout):
            self.path = path
            self.timeout = timeout
            self.cache = {}

    _path = "/path/for/cache"
    _timeout = 10
    cache = cache_module(_path, _timeout)
    assert cache.path == _path
    assert cache.timeout == _timeout

# Generated at 2022-06-23 09:26:15.888976
# Unit test for constructor of class CacheModule
def test_CacheModule():
  plugin = CacheModule()
  assert plugin.get_cache_dir() == 'cache'

# Generated at 2022-06-23 09:26:17.725517
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test if this constructor can work
    cache = CacheModule()
    return cache


# Generated at 2022-06-23 09:26:18.568200
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()


# Generated at 2022-06-23 09:26:22.756965
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create an instance
    filepath = b"/tmp/cachemodule.json"
    instance = CacheModule(filepath)
    
    # assert that the filepath is set
    assert instance.filepath == filepath

# Generated at 2022-06-23 09:26:23.691218
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()

# Generated at 2022-06-23 09:26:26.285362
# Unit test for constructor of class CacheModule
def test_CacheModule():
    tt = CacheModule()
    assert tt


# test for _load() of class CacheModule

# Generated at 2022-06-23 09:26:27.278573
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-23 09:26:28.317666
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(None)

# Generated at 2022-06-23 09:26:38.856838
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_connection = "test_ansible_connection"
    cache_plugin_prefix = "test_ansible_prefix"
    cache_plugin_timeout = 100

    cache = CacheModule()
    assert cache.connection == '$HOME/.ansible/tmp/ansible-cache'
    assert cache.plugin_name == 'jsonfile'
    assert cache.plugin_prefix == ''
    assert cache.timeout == 86400
    assert cache.cache_lock is not None

    cache = CacheModule(connection=cache_plugin_connection,
                        prefix=cache_plugin_prefix,
                        timeout=cache_plugin_timeout)
    assert cache.connection == cache_plugin_connection
    assert cache.plugin_name == 'jsonfile'
    assert cache.plugin_prefix == cache_plugin_prefix
    assert cache.timeout == cache_plugin_timeout


# Generated at 2022-06-23 09:26:40.537686
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.timeout == 86400
    assert cache.plugin_name is None

# Generated at 2022-06-23 09:26:49.558633
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c_module = CacheModule()
    assert c_module._load(None) == None , '_load error'
    assert c_module._dump(None,None) == None , '_dump error'
    assert c_module.get_database() == dict() , 'get_database error'
    assert c_module.get_value(None,None) == None , 'get_value error'
    assert c_module.set_value(None,None,None) == None , 'set_value error'

# Generated at 2022-06-23 09:26:51.753632
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m is not None

# Generated at 2022-06-23 09:26:53.274639
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

# Generated at 2022-06-23 09:26:54.266986
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-23 09:26:56.727549
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_class = CacheModule()
    assert test_class._plugin_name == "jsonfile"
    assert test_class._file_extension == ".json"

# Generated at 2022-06-23 09:26:57.651360
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), BaseFileCacheModule)

# Generated at 2022-06-23 09:26:58.935814
# Unit test for constructor of class CacheModule
def test_CacheModule():
    json_file_obj = CacheModule()

# Generated at 2022-06-23 09:27:00.844258
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert x._connection == '$HOME/.ansible/tmp/ansible-local'
    assert x._timeout == 86400

# Unit tests for function _load

# Generated at 2022-06-23 09:27:07.081570
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._load_file == module._load
    assert module._dump_file == module._dump

# Generated at 2022-06-23 09:27:08.622285
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    prefix = plugin._get_prefix("localhost")
    assert prefix == "localhost"

# Generated at 2022-06-23 09:27:14.109453
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile

    module = CacheModule()
    module.set_options(direct=dict(_uri=tempfile.mkdtemp()))
    module._flush()

# Generated at 2022-06-23 09:27:18.317127
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.options['_prefix'] == 'ansible_fact_cache'
    assert cache_plugin.options['_timeout'] == 86400
    assert cache_plugin.options['_uri'] == '~/.ansible/tmp/ansible-fact-cache'

# Generated at 2022-06-23 09:27:22.048825
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_class = CacheModule(dict(plugin_connection='/path/to/cache/module',
                                          plugin_prefix='prefix'))
    assert cache_plugin_class._connection == '/path/to/cache/module'
    assert cache_plugin_class._prefix == 'prefix'

# Generated at 2022-06-23 09:27:24.407217
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._timeout == 86400
    assert cache_module.get_timeout() == 86400

# Generated at 2022-06-23 09:27:35.271273
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import CacheModule
    from pathlib import Path
    import tempfile
    import shutil
    import time

    test_dir = Path(tempfile.mkdtemp())
    # assert that the directory is empty
    assert not list(test_dir.iterdir())

    plugin = CacheModule({'_prefix': str(test_dir), '_uri': str(test_dir), '_timeout': 1000})
    test_fixture = 'this is a test'
    plugin.set('test', test_fixture)

    # test that the cache module wrote a file
    files = list(test_dir.iterdir())
    assert files
    assert len(files) == 1
    assert files[0].is_file()


# Generated at 2022-06-23 09:27:36.352921
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache

# Generated at 2022-06-23 09:27:38.301916
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert isinstance(m, BaseFileCacheModule)

# Generated at 2022-06-23 09:27:40.232463
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._prefix == 'ansible-factcache'
    assert cache._timeout == 86400

# Generated at 2022-06-23 09:27:40.821719
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test = CacheModule()

# Generated at 2022-06-23 09:27:48.219623
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.file_extension == 'json'
    assert cache_plugin.file_extension_re == 'json$'
    assert cache_plugin._load('./test/unit/plugins/cache/test_jsonfile.json') == {'John': 'Doe'}
    assert cache_plugin._dump({'Jane': 'Doe'}, './test/unit/plugins/cache/test_jsonfile_dump.json') == None
    assert cache_plugin._load('./test/unit/plugins/cache/test_jsonfile_dump.json') == {'Jane': 'Doe'}

# Generated at 2022-06-23 09:27:49.999852
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """ Test constructor and its parameters """
    assert CacheModule({})

# Generated at 2022-06-23 09:27:52.138714
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(None)._load == CacheModule._load
    assert CacheModule(None)._dump == CacheModule._dump
    # test_CacheModule()

# Generated at 2022-06-23 09:27:53.396818
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule(None)
    assert cacheModule is not None

# Generated at 2022-06-23 09:27:56.327394
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._load(CacheModule) == value
    assert module._dump(CacheModule, value) == f.write(json.dumps(value, cls=AnsibleJSONEncoder, sort_keys=True, indent=4))

# Generated at 2022-06-23 09:28:02.568110
# Unit test for constructor of class CacheModule
def test_CacheModule():
    json_file = './test_cache.jso'
    cm = CacheModule(json_file)
    if cm.get('test'):
        cm.set('test', {})
    else:
        cm.set('test', {'test':True})

# Generated at 2022-06-23 09:28:03.480585
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:28:05.242333
# Unit test for constructor of class CacheModule
def test_CacheModule():
    json_cache_module = CacheModule()
    assert json_cache_module is not None

# Generated at 2022-06-23 09:28:15.583947
# Unit test for constructor of class CacheModule

# Generated at 2022-06-23 09:28:17.501302
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-23 09:28:22.132874
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        assert(os.path.exists(uri))
    except:
        assert(False)
    try:
        assert(os.path.exists(uri+"/ansible_facts@"+host+".json"))
    except:
        assert(False)

# Generated at 2022-06-23 09:28:23.231168
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

    assert cm is not None

# Generated at 2022-06-23 09:28:29.099076
# Unit test for constructor of class CacheModule
def test_CacheModule():
    temp_file = '/tmp/test_fact_cache.json'
    cache = CacheModule(temp_file)
    assert cache._timeout == 86400
    assert cache._prefix == ''
    assert cache._uri == temp_file
    assert cache._cache == None
    assert cache._cache_lock == None
    assert cache._expiration_times == None

# Generated at 2022-06-23 09:28:30.593665
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test = CacheModule()
    assert isinstance(test, BaseFileCacheModule)

# Generated at 2022-06-23 09:28:31.222756
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule(dict())

# Generated at 2022-06-23 09:28:34.588101
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_CacheModule = CacheModule()
    assert(test_CacheModule.get_option('_timeout') == 86400)
    assert(test_CacheModule.get_option('_uri') == None)
    assert(test_CacheModule.get_option('_prefix') == None)

# Generated at 2022-06-23 09:28:36.292828
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_class = CacheModule()
    assert isinstance(test_class, CacheModule)


# Generated at 2022-06-23 09:28:37.956920
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

# Generated at 2022-06-23 09:28:39.968754
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)
    assert CacheModule._load
    assert CacheModule._dump

# Generated at 2022-06-23 09:28:50.769116
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create cache plugin instance
    cm = CacheModule()

    # Set cache file location, prefix and timeout
    cm.set_options(Directive('_uri', '/tmp/', '', []))
    cm.set_options(Directive('_prefix', 'prefix', '', []))
    cm.set_options(Directive('_timeout', '43200', '', []))

    # Try getting an object that is not in the cache
    assert cm.get('localhost') is None

    # Put an object into the cache
    cm.set('localhost', {"foo": "bar"})

    # Get object from the cache
    cached = cm.get('locahost')
    assert cached is not None
    assert cached['foo'] == 'bar'

    # Delete object from the cache
    cm.flush()

# Generated at 2022-06-23 09:28:51.469233
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module is not None

# Generated at 2022-06-23 09:28:53.853433
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert "jsonfile" in cache.cache_key

# Generated at 2022-06-23 09:28:56.234120
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Testing if the constructor works
    assert(isinstance(CacheModule(), CacheModule))
    assert(isinstance(BaseFileCacheModule(), BaseFileCacheModule))

# Generated at 2022-06-23 09:28:56.823344
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

# Generated at 2022-06-23 09:28:57.862812
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:28:59.662325
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule(None)
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-23 09:29:04.239353
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule({ "_uri": "test_CacheModule"})
    assert module._connection == "test_CacheModule"
    assert module._prefix == "ansible_fact_cache"
    assert module._timeout == 86400

# Generated at 2022-06-23 09:29:12.849480
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create object with only required parameters
    uri = '/path/to/uri'
    obj = CacheModule(uri)
    assert obj
    assert isinstance(obj, CacheModule)
    assert obj._uri == uri
    assert obj._timeout == 86400
    assert obj._prefix is None
    # Create object with all parameters
    prefix = 'ansible_fact'
    timeout = 60
    obj = CacheModule(uri,prefix=prefix,timeout=timeout)
    assert obj
    assert isinstance(obj, CacheModule)
    assert obj._uri == uri
    assert obj._timeout == 60
    assert obj._prefix == 'ansible_fact'

# Generated at 2022-06-23 09:29:15.661256
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert 'CacheModule' not in str(BaseFileCacheModule.__init__)
    assert 'CacheModule' in str(CacheModule.__init__)

# Generated at 2022-06-23 09:29:17.557903
# Unit test for constructor of class CacheModule
def test_CacheModule():
    the_object = CacheModule()
    assert the_object is not None


# Generated at 2022-06-23 09:29:18.856705
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, '_dump')

# Generated at 2022-06-23 09:29:21.931965
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module
    assert module._load
    assert module._dump
    assert module.get
    assert module.set

# Generated at 2022-06-23 09:29:23.630824
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj._prefix == 'ansible-facts'
    assert obj._timeout == 86400

# Generated at 2022-06-23 09:29:27.290108
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._options.get('_uri') == '/tmp/ansible_fact_cache'
    assert c._options.get('_timeout') == 86400

# Generated at 2022-06-23 09:29:37.649910
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import shutil
    import tempfile
    cache_uri = tempfile.mkdtemp()
    cache = CacheModule({'_uri': cache_uri})
    cache.set('value', 'key')
    assert os.path.exists(os.path.join(cache_uri, cache._digest('key')))

    assert cache.get('key') == 'value'
    assert cache.has_expired('key') == True

    cache.set('value', 'key', ttl=0)
    assert cache.has_expired('key') == True

    cache.set('value', 'key', ttl=1)
    assert cache.has_expired('key') == False

    # cleanup
    shutil.rmtree(cache_uri)

# Generated at 2022-06-23 09:29:40.860844
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Test class CacheModule"""
    # Initialize Module
    cm = CacheModule()
    # Check if the Module was initialized
    assert cm is not None

# Generated at 2022-06-23 09:29:42.678037
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._load is not None
    assert module._dump is not None

# Generated at 2022-06-23 09:29:49.586619
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.cache_lock_timeout == 30
    assert c.cache_lock_path == os.path.expanduser("~/.ansible/cache")
    assert c.plugin_name == 'jsonfile'
    assert c.cache_prefix == 'ansible-fact'
    assert c.cache_timeout == 86400
    assert c.cache_connection == os.path.expanduser("~/.ansible/cache/facts")


# Generated at 2022-06-23 09:29:52.217346
# Unit test for constructor of class CacheModule
def test_CacheModule():
    config = dict()
    cm = CacheModule(config)
    assert cm
    assert isinstance(cm, BaseFileCacheModule)
    assert cm.file_extension == '.json'

# Generated at 2022-06-23 09:29:53.548127
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mod = CacheModule()
    assert mod is not None


# Generated at 2022-06-23 09:29:55.064148
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.file_extension is '.json'

# Generated at 2022-06-23 09:29:58.842222
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({
        '_uri': '~',
        '_prefix': "",
        '_timeout': 360
    })
    assert cache._prefix == ""
    assert cache._timeout == 360

# Generated at 2022-06-23 09:29:59.845143
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert 'CacheModule' == CacheModule.__name__

# Generated at 2022-06-23 09:30:01.102734
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-23 09:30:10.431613
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.plugins import cache_loader

    plugin = cache_loader.get("jsonfile")("uri=/tmp/cache", timeout=10)
    json.loads(plugin.get("test"))
    plugin.set("test", "1")
    assert plugin.get("test") == to_bytes("1")
    plugin.set("test", "2")
    assert plugin.get("test") == to_bytes("2")
    plugin.delete("test")
    assert plugin.get("test") == to_bytes("")

# Generated at 2022-06-23 09:30:15.292072
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test = CacheModule({
        '_uri': 'test',
        '_prefix': 'test',
        '_timeout': 'test',
        }, {})
    assert test._uri == 'test'
    assert test._prefix == 'test'
    assert test._timeout == 'test'

# Generated at 2022-06-23 09:30:16.481121
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

# Generated at 2022-06-23 09:30:19.080302
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create an instance of CacheModule
    c = CacheModule()
    assert c

# Generated at 2022-06-23 09:30:21.452311
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert ('jsonfile' == cache.cache_plugin_name)
    assert ('file' == cache.cache_plugin_type)

# Generated at 2022-06-23 09:30:22.756710
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_option('_uri') is not None
    assert cache_module.get_option('_prefix') is not None
    assert cache_module.get_option('_timeout') is not None

# Generated at 2022-06-23 09:30:25.865610
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert(cacheModule._load('jsonfile.py') is not None)
    assert(cacheModule._dump('jsonfile.py', 'test') is not None)

# Generated at 2022-06-23 09:30:28.381816
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    f = CacheModule()
    assert f.__class__.__name__ == 'CacheModule'

# Generated at 2022-06-23 09:30:30.152017
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule()
    assert isinstance(instance, CacheModule)

# Generated at 2022-06-23 09:30:34.620505
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin_name = 'jsonfile'
    plugin_class = getattr(__import__('ansible.plugins.cache', fromlist=[plugin_name]), plugin_name)
    mod = plugin_class(None)

# Generated at 2022-06-23 09:30:36.162214
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-23 09:30:38.035639
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._load is not None

# Generated at 2022-06-23 09:30:39.633882
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ch = CacheModule()
    print(ch)

# Generated at 2022-06-23 09:30:45.290026
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache_module = CacheModule()
    assert cache_module is not None
    assert cache_module._timeout == 86400
    #assert cache_module._connection == '~/.ansible/tmp/ansible-fact-cache'
    assert cache_module._connection == '"~/.ansible/tmp/ansible-fact-cache"'

# Generated at 2022-06-23 09:30:49.392627
# Unit test for constructor of class CacheModule
def test_CacheModule(): 
    obj = CacheModule()
    assert obj.get_timeout() == 86400
    assert obj.get_option("_timeout") == 86400
    assert obj.get_option("_prefix") == ''

# Generated at 2022-06-23 09:30:54.371702
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_class = CacheModule
    cache_plugin_instance = cache_plugin_class({'_uri': 'my/cache/path'})
    assert cache_plugin_instance
    assert cache_plugin_instance.cachefile == 'my/cache/path'

# Generated at 2022-06-23 09:30:55.520796
# Unit test for constructor of class CacheModule
def test_CacheModule():
    foo = CacheModule()
    assert(isinstance(foo, CacheModule))

# Generated at 2022-06-23 09:30:55.954819
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()

# Generated at 2022-06-23 09:30:57.497711
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test = CacheModule()
    assert test._timeout == 86400
    assert test._prefix == ''
    assert test._load is not None
    assert test._dump is not None

# Generated at 2022-06-23 09:30:59.856931
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()._timeout == 86400
    assert CacheModule()._prefix == ''

# Generated at 2022-06-23 09:31:08.634336
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test constructor and both getter and setter for class variables.
    cache_module = CacheModule()
    cache_module._uri = 1
    assert cache_module._uri == 1
    cache_module._prefix = 2
    assert cache_module._prefix == 2
    cache_module._timeout = 3
    assert cache_module._timeout == 3

# Generated at 2022-06-23 09:31:13.039235
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = "/tmp"
    timeout = 3600
    prefix = ""
    cache = CacheModule(connection, timeout, prefix)
    assert cache.get_timeout() == timeout
    assert cache.get_connection() == connection
    assert cache.get_prefix() == prefix


# Generated at 2022-06-23 09:31:19.948058
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # This is used as a test. It is a private method in the BaseFileCacheModule class
    test_cache_dir = '~/.ansible/tmp/ansible-test-cache'

    test_cache = CacheModule(tmppath=test_cache_dir)
    # Make sure instance is of the correct class
    assert(isinstance(test_cache, CacheModule))
    # Make sure tmppath is set correctly
    assert(test_cache.tmppath == test_cache_dir)

    test_cache.tmppath = test_cache_dir
    # Make sure tmppath is set correctly
    assert(test_cache.tmppath == test_cache_dir)

# Generated at 2022-06-23 09:31:30.407932
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Unsupported hostname
    uri = 'strange://'
    path = '/var/cache/somewhere'
    hostname = 'strange.example.org'
    plugin_timeout = 600
    prefix = 'prefix'
    p = CacheModule(uri, path, plugin_timeout, hostname, prefix)
    assert p._prefix == prefix
    assert p._plugin_timeout == plugin_timeout
    assert p._cache_path == path + '/ansible/facts/'
    assert p._cache_key == 'prefix_' + hostname

    # Hostname with non-alpha characters
    uri = 'local://'
    path = '/var/cache/somewhere'
    hostname = 'strange:example;org'
    plugin_timeout = 600
    prefix = 'prefix'

# Generated at 2022-06-23 09:31:32.491350
# Unit test for constructor of class CacheModule
def test_CacheModule():
  expr = 'ansible.plugins.cache.jsonfile.CacheModule'
  obj = eval(expr)
  print(obj)

# Generated at 2022-06-23 09:31:33.707220
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': '/tmp'}, {}) is not None

# Generated at 2022-06-23 09:31:38.544092
# Unit test for constructor of class CacheModule
def test_CacheModule():
    d = {
        '_uri': '/tmp/test.json',
        '_prefix': 'test_prefix_',
        '_timeout': 10
    }

    cm = CacheModule()
    cm.set_options(d)

    assert cm._connection == '/tmp/test.json', 'test for _connection failed'
    assert cm._prefix == 'test_prefix_', 'test for _prefix failed'
    assert cm._timeout == 10, 'test for _timeout failed'

# Generated at 2022-06-23 09:31:40.157822
# Unit test for constructor of class CacheModule
def test_CacheModule():
    #Create an instance of CacheModule
    cache_module = CacheModule()
    assert cache_module is not None


# Generated at 2022-06-23 09:31:40.873997
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()



# Generated at 2022-06-23 09:31:41.701911
# Unit test for constructor of class CacheModule
def test_CacheModule():
   obj = CacheModule()

# Generated at 2022-06-23 09:31:44.483123
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.uri == '~/.ansible/tmp'


# Generated at 2022-06-23 09:31:45.534954
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-23 09:31:48.026736
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = "/tmp/ansible_fact_caching_plugin"
    module_1 = CacheModule(data)
    assert module_1._connection, data

# Generated at 2022-06-23 09:31:50.494863
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._connection

# Generated at 2022-06-23 09:31:54.015603
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert isinstance(module._load('%s/%s' % (module.cache_dir(),"my.cache")), dict)

# Generated at 2022-06-23 09:31:56.308204
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule()
    assert instance.get_prefix()
    assert instance.get_timeout()
    assert instance.get_connection()

# Generated at 2022-06-23 09:32:03.920943
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # By default, the plugin_prefix is set to 'ansible_facts'
    filename = 'ansible_facts.json'
    cacheModule = CacheModule()
    # Encode the object to JSON string
    data = {'apple': 'cherry', 'banana': 'blueberry'}
    jsonData = json.dumps(data, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)
    cacheModule._dump(data, filename)
    # Decode the JSON string back to object
    result = cacheModule._load(filename)
    assert result['apple'] == 'cherry'
    assert result['banana'] == 'blueberry'

# Generated at 2022-06-23 09:32:04.389070
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()

# Generated at 2022-06-23 09:32:05.306609
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert (CacheModule(dict(url='/tmp/ansible-cache')))

# Generated at 2022-06-23 09:32:07.509241
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert "ansible.plugins.cache.jsonfile.CacheModule" == CacheModule.__module__ + '.' + CacheModule.__name__

# Generated at 2022-06-23 09:32:09.505208
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    cm.get_option("_uri")
    assert cm.get_option("_uri") == None

# Generated at 2022-06-23 09:32:11.288753
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    obj._load('/tmp/stats.json')
    obj._dump('value', '/tmp/stats.json')
    assert obj != None


# Generated at 2022-06-23 09:32:11.876861
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-23 09:32:12.506700
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

# Generated at 2022-06-23 09:32:13.468291
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(None) is not None

# Generated at 2022-06-23 09:32:14.581830
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.file_extension == 'cache'

# Generated at 2022-06-23 09:32:21.540577
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule(None)

    assert module._connection is None
    assert module.get_timeout('localhost') == 86400
    assert module.ext == '.json'

    module2 = CacheModule(['tmp'])
    assert module2._connection == ['tmp']
    assert module2.get_timeout('localhost') == 86400
    assert module2.ext == '.json'

    module3 = CacheModule(['tmp', '_timeout=10'])
    assert module3._connection == ['tmp']
    assert module3.get_timeout('localhost') == 10
    assert module3.ext == '.json'

# Generated at 2022-06-23 09:32:23.996531
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._connection == '.'



# Generated at 2022-06-23 09:32:26.025388
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Constructor CacheModule with empty args
    obj = CacheModule()
    assert not obj.filepath

# Generated at 2022-06-23 09:32:37.333746
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os

    cache = CacheModule()
    assert cache._connection is None
    assert cache._timeout == 86400

    prefix = os.environ.get('ANSIBLE_CACHE_PLUGIN_PREFIX', cache._prefix)

    connection = os.environ.get('ANSIBLE_CACHE_PLUGIN_CONNECTION', cache._connection)
    assert connection.endswith(prefix)

    timeout = os.environ.get('ANSIBLE_CACHE_PLUGIN_TIMEOUT', cache._timeout)
    assert timeout == 86400

    cache._setup_cache_dir()
    cache.set('/test/test.yml', 'test', timeout=30)

    # test get
    cached = cache.get('/test/test.yml')
    assert cached == 'test'

    #

# Generated at 2022-06-23 09:32:43.276433
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = {'a':1, 'b':2, 'c':3}
    cache = CacheModule(task_vars={})
    cache.set(data)
    assert cache.get() == data
    cache.set({'x':1})
    assert cache.get() == {'x':1}

# Generated at 2022-06-23 09:32:45.906507
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)
    file_path = CacheModule._get_cachefile_path('foo')
    assert file_path is not None

# Generated at 2022-06-23 09:32:49.097812
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert callable(CacheModule)

# Generated at 2022-06-23 09:33:00.935901
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('/tmp/test.json', 2)
    cache._prefix = "xyz"
    cache.set('a', '1')
    assert cache.get('a') == '1'
    cache.set('a', '2')
    assert cache.get('a') == '2'
    cache.set('b', '3')
    assert cache.get('b') == '3'
    cache.set('c', '4')
    assert cache.get('c') == '4'
    cache.delobj('b')
    cache.delobj('c')
    cache.delobj('a')
    cache.delobj('a')
    assert cache.get('a') is None
    assert cache.get('b') is None
    assert cache.get('c') is None

# Generated at 2022-06-23 09:33:03.661686
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Unit test for constructor of class CacheModule."""
    cacheplugin = CacheModule()
    data = cacheplugin.get('localhost', 'some_fact')
    assert data == {}

# Generated at 2022-06-23 09:33:07.406745
# Unit test for constructor of class CacheModule
def test_CacheModule():
    res = CacheModule()
    assert res._prefix == "ansible_facts"
    assert res._timeout == 86400
    assert res._connection == "~/.ansible/facts"

# Generated at 2022-06-23 09:33:09.612733
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_path() == '/tmp'

# Generated at 2022-06-23 09:33:15.886556
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(task_vars={'ansible_cache_plugin': 'jsonfile', 'ansible_cache_plugin_timeout': '3600', 'ansible_cache_plugin_connection': '/tmp', 'ansible_cache_plugin_prefix': ''})
    # Testing properties of instance 'cache'
    assert cache.timeout == 3600
    assert cache.plugin_name == 'jsonfile'
    assert cache.connection == '/tmp'
    assert cache.get_cache_prefix() == ''

# Generated at 2022-06-23 09:33:27.098737
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Constructor of class CacheModule
    :return:
    """

    json_file = 'test_cache_plugin_jsonfile.json'
    cache = CacheModule(tmp_path=json_file)

    # Test '_uri'
    assert cache._uri == json_file

    # Test '_prefix'
    assert cache._prefix == None

    # Test '_timeout'
    assert cache._timeout == 86400


# Generated at 2022-06-23 09:33:30.585033
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert(module._prefix == 'ansible_facts_', "incorrect prefix")
    assert(module._timeout == 86400, "incorrect timeout")
    assert(module._connection == '', "incorrect connection")
    assert(module.get_extension() == '.json', "incorrect extension")

# Generated at 2022-06-23 09:33:31.715913
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(), 'jsonfile')

# Generated at 2022-06-23 09:33:35.047954
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module_name = 'jsonfile'
    c = CacheModule.CacheModule(module_name)
    assert c.plugin_name() == module_name
    assert c.plugin_timeout() == 86400

# Generated at 2022-06-23 09:33:41.826762
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert hasattr(cache, '_load')
    assert hasattr(cache, '_dump')
    assert hasattr(cache, '_load_cache')
    assert hasattr(cache, '_dump_cache')
    assert hasattr(cache, '_flush_cache')
    assert hasattr(cache, 'get')
    assert hasattr(cache, 'set')
    assert hasattr(cache, 'keys')
    assert hasattr(cache, 'contains')
    assert hasattr(cache, 'delete')
    assert hasattr(cache, 'flush')