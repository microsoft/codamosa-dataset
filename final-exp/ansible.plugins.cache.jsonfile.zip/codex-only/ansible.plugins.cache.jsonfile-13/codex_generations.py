

# Generated at 2022-06-23 09:23:41.240190
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('/path/to/file')

# Generated at 2022-06-23 09:23:42.872701
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None


# Generated at 2022-06-23 09:23:46.890530
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.parsing.ajson import AnsibleJSONDecoder
    from ansible.plugins.cache.jsonfile import CacheModule
    CacheModule()

# Generated at 2022-06-23 09:23:47.941503
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-23 09:23:49.912202
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_plugin = CacheModule()
    assert isinstance(test_plugin, CacheModule)


# Generated at 2022-06-23 09:23:57.445322
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._cache_plugin_class_name == 'jsonfile'
    assert CacheModule._cache_plugin_shard_directory == 'ansible_facts'
    assert CacheModule._cache_plugin_timeout == 86400
    assert CacheModule._cache_plugin_prefix == 'ansible_fact_'
    assert CacheModule._cache_plugin_files_per_directory == 256

# Generated at 2022-06-23 09:23:59.951492
# Unit test for constructor of class CacheModule
def test_CacheModule():
    conf = dict()
    test_cache_module = CacheModule(conf)
    # check if the object is a non-zero object
    assert test_cache_module

# Generated at 2022-06-23 09:24:02.035314
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_key == 'ansible-plugin-jsonfile'
    assert cache.cache_prefix == 'ansible_facts.'
    assert cache.cache_timeout == 86400

# Generated at 2022-06-23 09:24:07.511300
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': '/tmp'})
    assert(cache.basedir == '/tmp')
    assert(cache.get_basedir() == '/tmp')
    assert(cache.valid() == False)

# Generated at 2022-06-23 09:24:10.224470
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test constructor of class CacheModule
    cm = CacheModule()
    assert hasattr(cm, '_load')
    assert hasattr(cm, '_dump')

    # Test return type of _load()
    assert isinstance(cm._load(''), dict)

    # Test return type of _dump()
    assert isinstance(cm._dump({}, ''), None)

# Generated at 2022-06-23 09:24:12.656830
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test to see if the constructor correctly sets the default variables
    CacheModule()

# Generated at 2022-06-23 09:24:16.611012
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.cache_plugin_version == '1.3'
    assert CacheModule.cache_protocol_version == '2.0'
    assert CacheModule.cache_schema_version == '1.0'
    assert CacheModule._timeout == 86400

# Generated at 2022-06-23 09:24:18.346394
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        CacheModule()
    except:
        pass

# Generated at 2022-06-23 09:24:19.419760
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

# Generated at 2022-06-23 09:24:21.102872
# Unit test for constructor of class CacheModule
def test_CacheModule():

    c = CacheModule()
    assert c.cache_timeout == 86400

# Generated at 2022-06-23 09:24:24.042673
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._load('/tmp/foo') is None
    assert plugin._dump('bar', '/tmp/foo') is None

# Generated at 2022-06-23 09:24:25.419847
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # instantiating class CacheModule
    inst_val = CacheModule()

# Generated at 2022-06-23 09:24:30.798480
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = {
        '_timeout': 86400,
        '_prefix': 'ansible-factcache',
        '_uri': '/tmp'
    }
    cache = CacheModule(data)
    assert cache.timeout == 86400
    assert cache.prefix == 'ansible-factcache'
    assert cache.directory == '/tmp'

# Generated at 2022-06-23 09:24:32.328188
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule('jsonfile', {})._prefix == 'ansible_fact_caching'


# Generated at 2022-06-23 09:24:35.835177
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._timeout == 86400
    assert cm._load is not None
    assert cm._dump is not None
    assert cm._prefix is None

# Generated at 2022-06-23 09:24:44.803049
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    # Create instance of class CacheModule
    test = CacheModule()

    # Set various attributes of the instance of class CacheModule
    test.set_options(direct={'_uri': tempfile.mkdtemp(), '_timeout': 10})

    # Check if the attributes in the instance of class CacheModule is set correctly
    assert test._timeout == 10
    assert test._connection == tempfile.mkdtemp()
    assert test._prefix == ""

# Generated at 2022-06-23 09:24:50.955249
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Test for CacheModule.
    This is expected to be run from the root of the source directory with
    ``PYTHONPATH=lib/python ansible-test units -v test/units/plugins/cache/test_jsonfile.py``
    """
    from ansible_collections.ansible.community.tests.unit.plugins.cache.test_jsonfile import test_CacheModule
    from ansible_collections.ansible.community.plugins.cache.jsonfile import CacheModule

    cache = CacheModule('/tmp/jsonfile')
    assert cache.cache_dir == '/tmp/jsonfile'

# Generated at 2022-06-23 09:24:54.339925
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # CacheModule() seems to require a config which I don't know how to make
    assert(False)

# Generated at 2022-06-23 09:24:59.493817
# Unit test for constructor of class CacheModule
def test_CacheModule():
    empty_dict = {}
    fixture_path = '/usr/local/ansible'

    # Arrange
    # Create mock object for class CacheModule()
    cache = CacheModule({
        "_uri": fixture_path,
        "_prefix": "",
        "_timeout": 86400})

    # Act
    result = cache._load(fixture_path)

    # Assert
    assert result == empty_dict



# Generated at 2022-06-23 09:25:05.066164
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cmod = CacheModule()
    cmod.set_options({'_uri': '/tmp/test_caching'})
    assert cmod.get_options() == {'_uri': '/tmp/test_caching', '_prefix': u'ansible-', '_timeout': 86400}
    cmod.set_options({'_uri': '/tmp/test_caching', '_prefix': 'new-prefix-', '_timeout': 60})
    assert cmod.get_options() == {'_uri': '/tmp/test_caching', '_prefix': u'new-prefix-', '_timeout': 60}

# Generated at 2022-06-23 09:25:06.535789
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.prefix == 'ansible-facts'

# Generated at 2022-06-23 09:25:08.130426
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Verify that we can construct a CacheModule
    CacheModule()

# Generated at 2022-06-23 09:25:12.838651
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from tempfile import mkdtemp
    from shutil import rmtree

    try:
        d = mkdtemp(prefix='ansible-tests-cache_')
        c = CacheModule(task_vars={'_ansible_tmpdir': d})
    finally:
        rmtree(d)

# Generated at 2022-06-23 09:25:15.200229
# Unit test for constructor of class CacheModule
def test_CacheModule():
    t = CacheModule()
    assert t.get_timeout() == 86400


# Generated at 2022-06-23 09:25:20.438950
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._connection is None
    assert CacheModule._prefix == u'ansible_fact_cache'
    assert CacheModule._timeout == 86400
    c = CacheModule()
    assert c._connection is None
    assert c._timeout == 86400


# Generated at 2022-06-23 09:25:22.353837
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Constructor for the CacheModule class.
    """
    cache_module = CacheModule()
    print(cache_module.get_options())

# Generated at 2022-06-23 09:25:24.189842
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:25:25.248677
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-23 09:25:26.185420
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({},{})

# Generated at 2022-06-23 09:25:27.716018
# Unit test for constructor of class CacheModule
def test_CacheModule():
    global cache_module
    cache_module = CacheModule()
    assert cache_module != None

# Generated at 2022-06-23 09:25:29.161304
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cacheModule = CacheModule()
    assert cacheModule is not None

# Generated at 2022-06-23 09:25:33.557916
# Unit test for constructor of class CacheModule
def test_CacheModule():
    arg_data = {
        '_timeout': 86400,
        '_prefix': 'f',
        '_uri': '/home/.ansible/facts'
    }
    cache_module = CacheModule(arg_data)
    assert cache_module._timeout == 86400
    assert cache_module._prefix == 'f'
    assert cache_module._uri == '/home/.ansible/facts'

# Generated at 2022-06-23 09:25:34.682157
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.plugin_name == 'jsonfile'

# Generated at 2022-06-23 09:25:39.406363
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule(connection=['json'], timeout=300)
    assert cm.get_timeout() == 300
    assert cm.get_connection() == ['json']
    assert str(cm) == '<jsonfile>'

# Generated at 2022-06-23 09:25:41.096607
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)



# Generated at 2022-06-23 09:25:45.808769
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    c = plugin._construct_path('c')
    assert c == "c.json", "cache path {} must end in .json".format(c)

# Generated at 2022-06-23 09:25:48.980658
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_client is None
    assert cache._timeout == 86400
    assert cache._plugin_name == 'jsonfile'

# Generated at 2022-06-23 09:25:51.395539
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.timeout == 86400
    assert cache.get_cache_size() == 0
    assert cache.get_cache_timeout() == 86400

# Generated at 2022-06-23 09:25:53.389198
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()

    if module is None:
        sys.exit(1)

# Generated at 2022-06-23 09:25:54.730679
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    cache_plugin.set_options()

# Generated at 2022-06-23 09:25:59.134352
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = {
        "_timeout": 86400,
        "_uri": "/home/test/src/test-ansible/",
        "_prefix": "test"
    }
    cache_module = CacheModule(data)
    assert cache_module._timeout == 86400
    assert cache_module._prefix == data["_prefix"]
    assert cache_module._uri == data["_uri"]


# Generated at 2022-06-23 09:26:08.232439
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    # create a temp directory
    directory = tempfile.TemporaryDirectory()
    # create a temp cache file
    filepath = directory.name + "/tmp.json"

    cache_module = CacheModule()
    cache_module.set_options({u'_uri': directory.name})

    # test method load()
    with codecs.open(filepath, 'w', encoding='utf-8') as f:
        f.write(json.dumps({u'foo': u'bar'}))

    cache_content = cache_module.load(filepath)
    assert cache_content == {u'foo': u'bar'}

    # test method dump()
    cache_module.dump({u'foo': u'bar'}, filepath)
    cache_content = cache_module.load(filepath)
   

# Generated at 2022-06-23 09:26:11.071965
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test that subclasses of BaseFileCacheModule have working constructors
    assert CacheModule({'_uri': "/tmp/", '_timeout': 60, '_prefix': ""})

# Generated at 2022-06-23 09:26:12.123354
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({}, {})

# Generated at 2022-06-23 09:26:15.889887
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._load("test/test_connection_jsonfile.json")
    cm._dump("2017-12-27", "test/test_connection_jsonfile.json")


# TODO: Add unit test for other functions

# Generated at 2022-06-23 09:26:17.797369
# Unit test for constructor of class CacheModule
def test_CacheModule():
    aCacheModule = CacheModule('/tmp/test')
    assert aCacheModule.cache_size(123) == 123



# Generated at 2022-06-23 09:26:21.395401
# Unit test for constructor of class CacheModule
def test_CacheModule():
    chmod = CacheModule(None, '', None, None)
    assert chmod is not None

# Generated at 2022-06-23 09:26:25.054614
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import pytest

    with pytest.raises(AssertionError):
        CacheModule()

# Generated at 2022-06-23 09:26:29.331681
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = dict(a=1, b=2)
    cache = CacheModule()
    path = cache._cache_path("test_host")
    cache._dump(data, path)
    saved_data = cache._load(path)
    assert saved_data == data

# Generated at 2022-06-23 09:26:31.161438
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm != None


# Generated at 2022-06-23 09:26:34.251192
# Unit test for constructor of class CacheModule
def test_CacheModule():
    conn = CacheModule()
    conn.set_options()
    assert isinstance(conn._encoder, AnsibleJSONEncoder)
    assert isinstance(conn._decoder, AnsibleJSONDecoder)

# Generated at 2022-06-23 09:26:35.243988
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)

# Generated at 2022-06-23 09:26:37.024510
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._timeout == 86400
    assert plugin._prefix == ''

# Generated at 2022-06-23 09:26:44.831922
# Unit test for constructor of class CacheModule
def test_CacheModule():

    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.cache import BaseFileCacheModule
    from ansible.module_utils.facts.cache.base import BaseFactCacheModule

    class MyCacheModule(BaseFileCacheModule, BaseFactCacheModule):
        pass

    # Test PY2 and PY3 compatibility
    if PY3:
        data1 = {'a': 'bö'}
        data2 = {'a': 'bö'}
        data3 = {'a': 'bö ä'}
        data4 = {'a': 'bö ä'}
        data5 = {'a': 'bö ä'}
        data6 = {'a': 'böc'}
       

# Generated at 2022-06-23 09:26:49.558079
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = ''
    prefix = ''
    timeout = 1800

    cacheModule = CacheModule(connection, prefix, timeout)

    assert cacheModule.connection == ''
    assert cacheModule.prefix == ''
    assert cacheModule.timeout == 1800
    assert cacheModule.plugin_name == 'jsonfile'


# Generated at 2022-06-23 09:26:52.026230
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({}, {}, {}, {})

# Generated at 2022-06-23 09:26:57.164668
# Unit test for constructor of class CacheModule
def test_CacheModule():
     module = CacheModule()
     assert module.get_file_extension() == ".cache"
     assert isinstance(module.get_timeout(), int)
     assert module.get_timeout() >= 0
     module._save_cache_data("test", "test")
     module._load_cache_data("test")
     module._delete_cache_data("test")

# Generated at 2022-06-23 09:27:00.551274
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None
    assert cache_plugin.plugin_name is not None
    assert cache_plugin.path is not None
    assert cache_plugin.timeout is not None
    assert cache_plugin.prefix is not None

# Generated at 2022-06-23 09:27:06.766704
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._cache_plugin_class == 'jsonfile'

# Generated at 2022-06-23 09:27:10.223249
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm.json_decoder, AnsibleJSONDecoder)
    assert isinstance(cm.json_encoder, AnsibleJSONEncoder)

# Generated at 2022-06-23 09:27:15.327302
# Unit test for constructor of class CacheModule
def test_CacheModule():
    tcm = CacheModule()
    if hasattr(tcm, '_load') and hasattr(tcm, '_dump'):
        print('SUCCESS!')

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:27:16.874207
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.__doc__.strip()  == DOCUMENTATION.strip()
    assert cm._prefix == 'ansible_facts'
    assert cm._timeout == 86400

# Generated at 2022-06-23 09:27:18.833401
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_path = '../../data/ansible_facts.cache'
    cm = CacheModule(test_path)
    assert cm

# Generated at 2022-06-23 09:27:30.506467
# Unit test for constructor of class CacheModule
def test_CacheModule():
    if __name__ == "__main__":
        print('Ansible: CacheModule class instantiation test.')
        print(CacheModule)

        s = CacheModule()
        print(s)

        print('CacheModule: set_plugin_options test()')
        s.set_plugin_options(dict(connection='test'))
        print('CacheModule: serialize_value test()')
        value = s.serialize_value({'key1': 'value1'})
        print('CacheModule: deserialize_value test()')
        result = s.deserialize_value(value)
        print('CacheModule: get test()')
        s.get('test')
        print('CacheModule: set test()')
        s.set('test', 'test_value')
        print('CacheModule: keys test()')
        s

# Generated at 2022-06-23 09:27:36.841428
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    filename = "test/filename"
    cache_module.set_basedir(filename)
    cache_module.clean_cache()
    cache_module.flush()
    cache_module.get_basedir()
    cache_module.get_cachefile_path(filename)
    cache_module.get_cache(filename)
    cache_module.set_cache(filename, {})
    cache_module.has_expired()

# Generated at 2022-06-23 09:27:40.674963
# Unit test for constructor of class CacheModule
def test_CacheModule():
  cmodule = CacheModule()
  cmodule.set_options(path='')
  assert cmodule._load('/tmp/deleteme') == {}
  cmodule._dump({}, '/tmp/deleteme')

# Generated at 2022-06-23 09:27:42.201756
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    obj._load('this/is/a/fake/path')

# Generated at 2022-06-23 09:27:50.642023
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__doc__ == '''A caching module backed by json files.'''
    assert CacheModule._load.__doc__ == '''
        A caching module backed by json files.
        '''
    assert CacheModule._dump.__doc__ == '''
        A caching module backed by json files.
        '''
    assert CacheModule.do_clear.__doc__ == '''Delete any cached facts for a host'''
    assert CacheModule.do_clean.__doc__ == '''
        Clean up the cache and remove any expired data based on the
        'timeout' value specified for this plugin.'''
    assert CacheModule.do_flush.__doc__ == '''Delete all cached facts from all hosts.'''

# Generated at 2022-06-23 09:27:51.307262
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:27:55.379245
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Initialize CacheModule object
    cache_dir = '/tmp/test_cache'
    cache_module_obj = CacheModule(cache_dir)

    # Assert CacheModule attributes
    assert cache_module_obj.cache_dir == cache_dir
    assert cache_module_obj.cache_lock == '%s/cache.lock' % cache_dir

# Generated at 2022-06-23 09:28:03.837759
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_basedir() == 'ansible_fact_cache'
    assert cache.get_timeout() == 3600
    cache._prefix = 'foobar'
    assert cache.get_prefix() == 'foobar'
    assert cache.get_plugin_name() == 'jsonfile'
    cache.set_plugin_name('foobar')
    assert cache.get_plugin_name() == 'foobar'

# Generated at 2022-06-23 09:28:05.499582
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-23 09:28:07.783060
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None



# Generated at 2022-06-23 09:28:14.261431
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = {
        'hostname': 'localhost',
        'data': {
            'test_data': {
                'test_data': True
            }
        }
    }
    plugin_options = {
        '_uri': '/tmp/test',
        '_timeout': 3600
    }
    p = CacheModule(plugin_options)
    p._dump(data, p.get_file_path('test'))
    assert data == p._load(p.get_file_path('test'))

# Generated at 2022-06-23 09:28:23.565705
# Unit test for constructor of class CacheModule
def test_CacheModule():
  cache_module = CacheModule("/tmp/ansible_caching")
  assert cache_module._prefix == 'ansible-cache'
  assert cache_module._timeout == 86400
  assert cache_module._uri == "/tmp/ansible_caching"

  # Test setting the prefix to a specific value
  cache_module = CacheModule("/tmp/ansible_caching", "my_ansible_cache", 43200)
  assert cache_module._prefix == 'my_ansible_cache'
  assert cache_module._timeout == 43200
  assert cache_module._uri == "/tmp/ansible_caching"

# Generated at 2022-06-23 09:28:34.026151
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # initialise certain variables to test
    _uri = '/etc/ansible/'
    _timeout = '86400'
    _prefix = 'test_prefix'
    _plugin_name = 'cache_plugin_test'

    # create instance of class CacheModule
    cache_plugin_test = CacheModule(_plugin_name)

    # supply _uri, _prefix and _timeout with values
    cache_plugin_test._uri = _uri
    cache_plugin_test._prefix = _prefix
    cache_plugin_test._timeout = _timeout
    # assert the values
    assert cache_plugin_test._uri == _uri
    assert cache_plugin_test._prefix == _prefix
    assert cache_plugin_test._timeout == _timeout

# Generated at 2022-06-23 09:28:36.885774
# Unit test for constructor of class CacheModule
def test_CacheModule():
    url = "~/playbook/cache"
    timeout = 600
    from ansible.plugins.cache import CacheModule
    cm = CacheModule(url, timeout)
    assert cm._connection == url
    assert cm._timeout == 600

# Generated at 2022-06-23 09:28:40.329874
# Unit test for constructor of class CacheModule
def test_CacheModule():

    test_module = CacheModule()
    assert test_module._timeout == 86400
    assert test_module._prefix == 'ansible-facts'
    assert test_module._uri is None

# Generated at 2022-06-23 09:28:50.992437
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create a CacheModule object.
    cache_module = CacheModule()

    # Print the CacheModule object.
    print('type(cache_module)={0}'.format(type(cache_module)))
    print('cache_module={0}'.format(cache_module))

    # Load the CACHE_PLUGIN_CONNECTION environment variable.
    try:
        from os import environ
        print('CACHE_PLUGIN_CONNECTION={0}'.format(environ['CACHE_PLUGIN_CONNECTION']))
    except:
        pass

    # Load the CACHE_PLUGIN_PREFIX environment variable.

# Generated at 2022-06-23 09:28:53.353558
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_module = CacheModule()
    assert test_module.type == 'jsonfile'

# Generated at 2022-06-23 09:28:54.177489
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-23 09:29:03.559175
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test minimal constructor
    cache_plugin = CacheModule()
    assert cache_plugin.plugin != None

    # Test constructor with uri
    cache_plugin = CacheModule(connection='/var/tmp/ansible')
    assert cache_plugin.plugin != None

    # Test constructor with uri and timeout
    cache_plugin = CacheModule(connection='/var/tmp/ansible', timeout=3600)
    assert cache_plugin.plugin != None

    # Test constructor with uri, timeout and plugin_prefix
    cache_plugin = CacheModule(connection='/var/tmp/ansible', timeout=3600, plugin_prefix='123')
    assert cache_plugin.plugin != None

    # Test constructor with uri, plugin_prefix, timeout and valid_extensions

# Generated at 2022-06-23 09:29:05.268137
# Unit test for constructor of class CacheModule
def test_CacheModule():
    file_cache = CacheModule()
    assert file_cache.get_basedir()

# Generated at 2022-06-23 09:29:12.809751
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = '/tmp/'
    cache_prefix = 'ansible-cache'
    timeout = 3600
    cache_plugin = CacheModule(cache_dir,cache_prefix,timeout)
    assert cache_plugin._connection == cache_dir
    cache_plugin._check_mode = True
    cache_plugin._timeout = timeout
    cache_plugin._prefix_compute = cache_prefix
    assert cache_plugin._check_mode == True
    assert cache_plugin._prefix_compute == cache_prefix
    #TODO: check if the file is writeable, etc.

# Generated at 2022-06-23 09:29:18.056070
# Unit test for constructor of class CacheModule
def test_CacheModule():
    new_instance = CacheModule()
    assert new_instance.get_cache_size() == 0
    assert new_instance.get_cache_file({'localhost': {'foo': 'bar'}}) == '/home/ansible/.ansible/tmp/ansible-local/localhost'

# Generated at 2022-06-23 09:29:20.530503
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_cache_prefix() == 'ansible_facts'

# Generated at 2022-06-23 09:29:21.247596
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:29:33.547184
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj._load(None) is None
    assert obj._dump(None, None) is None
    assert obj.hash_content(None) is None
    assert obj.dump_content(None, None) is None
    assert obj.load_content(None) is None
    assert obj.dump_to_file(None, None, None) is None
    assert obj.load_from_file(None) is None
    assert obj.get_content(None) is None
    assert obj.set_content(None) is None
    assert obj.delete_file(None) is None
    assert obj.delete_dir(None) is None
    assert obj._get_content_path(None) is None


if __name__ == '__main__':
    module = CacheModule()

# Generated at 2022-06-23 09:29:34.992594
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert type(cm).__name__ == 'CacheModule'

# Generated at 2022-06-23 09:29:41.127665
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    import os
    import shutil

    test_dir = tempfile.mkdtemp()

    cache_plugin = CacheModule({
        '_timeout': 30,
        '_prefix': 'test',
        '_uri': test_dir,
    })

    assert cache_plugin._expiration == 30
    assert cache_plugin._prefix == 'test'
    assert cache_plugin._cache == test_dir
    assert cache_plugin._cache_dir == os.path.join(test_dir, 'ansible_test')

    shutil.rmtree(test_dir)


# Generated at 2022-06-23 09:29:47.573257
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None
    assert cache.conn is None
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible_facts_'
    assert cache._uri is None
    assert ('_uri' in cache._config_options) is True
    assert ('_prefix' in cache._config_options) is True
    assert ('_timeout' in cache._config_options) is True

# Generated at 2022-06-23 09:29:50.044953
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.get_options() == {'_uri': '', '_prefix': '', '_timeout': 86400}

# Generated at 2022-06-23 09:29:52.246307
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule({'_uri': 'my_directory'})
    assert cache_module
    assert cache_module._basedir == 'my_directory/ansible_facts'

# Generated at 2022-06-23 09:29:53.906518
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.get_option('_prefix') is None
    assert c.get_option('_timeout') == 86400

# Generated at 2022-06-23 09:29:57.470269
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._timeout == 86400
    assert CacheModule._connection_options == {'uri': 'ANSIBLE_CACHE_PLUGIN_CONNECTION',
                                               'prefix': 'ANSIBLE_CACHE_PLUGIN_PREFIX',
                                               'timeout': 'ANSIBLE_CACHE_PLUGIN_TIMEOUT'}

# Generated at 2022-06-23 09:29:58.965336
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    A function for unit testing the constructor of class CacheModule
    """

    pass

# Generated at 2022-06-23 09:30:00.997651
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(), str(), dict())

# Generated at 2022-06-23 09:30:04.318562
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_obj = CacheModule()
    assert test_obj._timeout == 86400
    assert test_obj._wrapped == False

# Generated at 2022-06-23 09:30:06.658640
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.__class__.__name__ == 'CacheModule'

# Generated at 2022-06-23 09:30:15.617811
# Unit test for constructor of class CacheModule
def test_CacheModule():
    class TestClass(CacheModule):
        """
        A testing class backed by json files.
        """
    _uri = 'test'
    _timeout = 1000
    test = TestClass(_uri, _timeout)

    assert test._timeout == _timeout
    assert test._directory == _uri

    test._dump({}, '/test/test')
    assert test._load('/test/test') == {}

    test._dump(['a', 'b', 'c'], '/test/test')
    assert test._load('/test/test') == ['a', 'b', 'c']

    test._dump({'a': 'b'}, '/test/test')
    assert test._load('/test/test') == {'a': 'b'}

    test._dump({'a': ['b', 'c']}, '/test/test')
   

# Generated at 2022-06-23 09:30:19.530365
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mod = CacheModule()
    assert mod.write_path == 'cache'
    assert mod.lockfile_timeout == 10


# Generated at 2022-06-23 09:30:21.008660
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # create a cache module object
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-23 09:30:24.266693
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load_name == '_load'
    assert cache_module._dump_name == '_dump'

# Generated at 2022-06-23 09:30:29.129535
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filepath = '/path/to/file'
    prefix = 'test'
    timeout = 123
    cache = CacheModule(filepath, prefix, timeout)
    assert cache._plugin_options['_uri'] == '/path/to/file'
    assert cache._plugin_options['_prefix'] == 'test'
    assert cache._plugin_options['_timeout'] == 123

# Generated at 2022-06-23 09:30:38.077214
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': '/tmp'})
    assert CacheModule({'_uri': '/tmp'}, {})
    assert CacheModule({'_uri': '/tmp'}, {}, '/tmp')
    assert CacheModule({'_uri': '/tmp', '_prefix': 'test'}, {})
    assert CacheModule({'_uri': '/tmp', '_prefix': 'test'}, {}, '/tmp')
    assert CacheModule({'_uri': '/tmp', 'timeout': 'test'}, {}, '/tmp')

# Generated at 2022-06-23 09:30:42.454345
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Fetch a cache module to test
    test_module = CacheModule()

    assert hasattr(test_module, "_connection")
    assert hasattr(test_module, "_load")
    assert hasattr(test_module, "_dump")
    assert hasattr(test_module, "_get_path")
    assert hasattr(test_module, "_get_timeout")
    assert hasattr(test_module, "_get_data")
    assert hasattr(test_module, "_get_file")
    assert hasattr(test_module, "_set_data")
    assert hasattr(test_module, "_dict_to_file")
    assert hasattr(test_module, "_refresh_cache")

# Generated at 2022-06-23 09:30:44.631507
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._connection is not None
    assert cm._timeout == 86400

# Generated at 2022-06-23 09:30:45.654885
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)

# Generated at 2022-06-23 09:30:48.514336
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_cache = CacheModule()

    assert isinstance(test_cache, BaseFileCacheModule)

# Generated at 2022-06-23 09:30:58.541464
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.utils.path import unfrackpath
    import tempfile

    # create a temporary directory for the test
    tmpdir = tempfile.mkdtemp()
    # make a tempfile using the cache plugin path
    name = 'test-cache-plugin'
    fd, file_path = tempfile.mkstemp(prefix=name, dir=tmpdir)
    # Create an instance of the plugin
    cache_plugin = CacheModule()
    # validate that the path we created is the same of the cache plugin
    assert(file_path == cache_plugin.get_file_path(name))
    # validate that the module gets the same filename
    # (fqcn.host.username.name)
    assert(file_path == cache_plugin.get_file_path(name, unfrackpath('/unknown/path')))

# Generated at 2022-06-23 09:31:01.880302
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module_name = "jsonfile"
    module_path = "ansible.plugins.cache"
    cache_module = CacheModule()
    assert cache_module.__name__ == module_name
    assert cache_module.__module__ == module_path

# Generated at 2022-06-23 09:31:04.543192
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-23 09:31:08.356417
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict()) == None

# Generated at 2022-06-23 09:31:09.914143
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule(task=None)
    assert plugin

# Generated at 2022-06-23 09:31:10.536566
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:31:13.879434
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.cache_plugin_name == 'jsonfile'
    assert cache_module._connection is None
    assert cache_module._prefix is None
    assert cache_module._timeout == 86400

# Generated at 2022-06-23 09:31:16.209452
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    cache._init_cache_dir('/tmp')
    assert cache._cache_dir == '/tmp'
    assert cache._timeout == 86400

# Generated at 2022-06-23 09:31:18.374749
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Instantiate an object
    cache_obj = CacheModule()
    assert isinstance(cache_obj._load, object)
    assert isinstance(cache_obj._dump, object)

# Generated at 2022-06-23 09:31:20.928801
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    print(cache)

# Generated at 2022-06-23 09:31:21.870809
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(None), CacheModule)

# Generated at 2022-06-23 09:31:28.388529
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.get_options() == {
        '_uri': dict(required=True, type='path', description='Path in which the cache plugin will save the JSON files'),
        '_prefix': dict(default='ansible_fact_cache_', description='User defined prefix to use when creating the JSON files'),
        '_timeout': dict(default=86400, type='integer',
                         description='Expiration timeout for the cache plugin data'),
    }

# Generated at 2022-06-23 09:31:28.939206
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule

# Generated at 2022-06-23 09:31:34.736398
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_uri = "tests/ansible_test_cache"
    test_prefix = "prefix"
    test_timeout = 10

    plugin = CacheModule(test_uri, test_prefix, test_timeout)
    plugin._load = lambda x: x
    plugin._dump = lambda x, y: y

    assert plugin._uri == test_uri
    assert plugin._prefix == test_prefix
    assert plugin._timeout == test_timeout

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:31:39.296445
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = '/home/dummy'
    timeout = 10
    prefix = 'abc'
    cache = CacheModule(path, timeout, prefix)

    assert cache.path == path
    assert cache.timeout == timeout
    assert cache.prefix == prefix

# Generated at 2022-06-23 09:31:40.228056
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(CacheModule() is not None)

# Generated at 2022-06-23 09:31:51.522424
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    Unit test for class CacheModule
    '''

    # Constructor with no parameter
    obj = CacheModule()
    assert 'CacheModule' == obj.__class__.__name__
    assert obj.plugin_name == 'jsonfile'

    # Constructor with an empty dict parameter
    obj = CacheModule({})
    assert 'CacheModule' == obj.__class__.__name__
    assert obj.plugin_name == 'jsonfile'

    # Constructor with a non-empty dict parameter
    obj = CacheModule({'timeout': 86400})
    assert 'CacheModule' == obj.__class__.__name__
    assert obj.plugin_name == 'jsonfile'
    assert obj.timeout == 86400

# Generated at 2022-06-23 09:31:54.687397
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(None)
    assert cache is not None


if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:32:00.657691
# Unit test for constructor of class CacheModule
def test_CacheModule():
    _uri = "/Users/jgensl2/workspace/ansible-venv/lib/python2.7/site-packages/ansible/plugins/cache/jsonfile.py"
    _prefix = "test_CacheModule"
    _timeout = 1000
    
    cache = CacheModule()
    cache._uri = _uri
    cache._prefix = _prefix
    cache._timeout = 1000
        
    return cache


# Generated at 2022-06-23 09:32:02.071331
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.filename_extension == 'json'

# Generated at 2022-06-23 09:32:06.241685
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    assert cache._file_extension == 'json'


# Generated at 2022-06-23 09:32:13.420454
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # When no argument is passed to constructor, _options property is expected to be empty
    cache = CacheModule()
    assert cache._options == {}

    # When the argument is not dictionary object, TypeError is expected to be thrown
    try:
        cache = CacheModule(['key1', 'value1'])
    except TypeError:
        pass

    # When the argument is not dictionary object, TypeError is expected to be thrown
    try:
        cache = CacheModule({'key1': 'value1', 'key2': 123})
    except TypeError:
        pass

    # When the argument is not dictionary object, TypeError is expected to be thrown
    try:
        cache = CacheModule({'key1': 'value1', 123: 'key2'})
    except TypeError:
        pass

    # When the argument is not dictionary object, TypeError is

# Generated at 2022-06-23 09:32:16.452385
# Unit test for constructor of class CacheModule
def test_CacheModule():

    instance = CacheModule()
    print(instance)

    # output:
    # <ansible_collections.ansible.community.plugins.cache.jsonfile.CacheModule object at 0x7fbf06584f98>

# Generated at 2022-06-23 09:32:19.638186
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    result = module._load("C:/Users/Admin/Desktop/Repos/ansible-2.7.5/lib/ansible/plugins/cache/jsonfile.py")
    assert result


# Generated at 2022-06-23 09:32:22.021619
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._options is not None

# Generated at 2022-06-23 09:32:31.548915
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile
    from ansible.plugins.cache import BaseFileCacheModule
    path = tempfile.mkdtemp()
    cache = CacheModule({'_uri': path, '_prefix': ''})

    # test the inheritance of BaseFileCacheModule
    assert issubclass(CacheModule, BaseFileCacheModule) is True

    # test the constructor of CacheModule
    assert isinstance(cache, CacheModule) is True

    # test the _load method of CacheModule
    assert isinstance(cache._load, type(CacheModule._load)) is True

    # test the _dump method of CacheModule
    assert isinstance(cache._dump, type(CacheModule._dump)) is True

    # clean up
    os.rmdir(path)

# Generated at 2022-06-23 09:32:33.217453
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule({'_uri': 'test'})
    assert cache_plugin is not None

# Generated at 2022-06-23 09:32:40.473326
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_cache_obj = CacheModule()
    assert test_cache_obj.get_path() == "~/.ansible/tmp/ansible-fact-cache"
    assert test_cache_obj.get_timeout() == 86400
    assert test_cache_obj.get_plugin_prefix() == "facts"
    assert test_cache_obj.get_plugin_path() == "/var/tmp/ansible/facts"

# Generated at 2022-06-23 09:32:47.698095
# Unit test for constructor of class CacheModule
def test_CacheModule():
    p = {}
    p.update(CacheModule.__dict__)
    p.update(BaseFileCacheModule.__dict__)
    p.update({'connect': lambda: False})

    path = "/etc/ansible/facts"
    prefix = "ansible_local"
    timeout = 600
    plugin = CacheModule(path=path, prefix=prefix, timeout=timeout)
    try:
        plugin.set("test", "1234")
        plugin.get("test")
    except Exception as e:
        print("Test case failed, exception={}".format(e))
        assert(0)

# Generated at 2022-06-23 09:32:50.226860
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache
    assert len(cache.plugin_name) > 0

# Generated at 2022-06-23 09:32:53.594351
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create a instance of class CacheModule
    cache = CacheModule()

# Get the path to use as the cache plug-in base directory

# Generated at 2022-06-23 09:32:58.637995
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = '/home/centos'
    timeout = '86400'

    c = CacheModule()
    assert c.timeout == 3600
    c = CacheModule(timeout=timeout)
    assert c.timeout == 86400

    c = CacheModule(uri=uri)
    assert c.connection == uri

# Generated at 2022-06-23 09:33:00.422861
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._load is not None
    assert cm._dump is not None

# Generated at 2022-06-23 09:33:04.704988
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.fact_cache import CacheModule as cache_module
    time = 86400
    uri = 'testing_uri'
    prefix = 'testing_prefix'
    # Test for constructor
    assert isinstance(cache_module(time,uri,prefix),cache_module), 'wrong type'


# Generated at 2022-06-23 09:33:07.038804
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.FMT == 'json'

# Generated at 2022-06-23 09:33:10.165522
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.file_extension == 'json'
    assert module._prefix == 'ansible_fact_cache'
    assert module.timeout == 86400

# Generated at 2022-06-23 09:33:12.948551
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(connection={})
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_prefix() is None

# Generated at 2022-06-23 09:33:13.936366
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__doc__ is not None

# Generated at 2022-06-23 09:33:15.062480
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-23 09:33:19.590286
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-23 09:33:20.956230
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert isinstance(cache_module, CacheModule)


# Generated at 2022-06-23 09:33:23.344816
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Create an instance of the CacheModule class
    """
    cache_plugin = CacheModule({
        '_uri': '.',
    })
    assert isinstance(cache_plugin, CacheModule)


# Generated at 2022-06-23 09:33:30.856065
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._get_cachefile_path("localhost") == cache._get_cachefile_path("127.0.0.1")

    cache = CacheModule(timeout=0)
    assert cache._timeout == 0
    assert cache.is_expired(cache._get_cachefile_path("localhost"))
    assert cache.is_expired(cache._get_cachefile_path("127.0.0.1"))

# Generated at 2022-06-23 09:33:35.526013
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = '/path/to/cachedir'
    timeout = 86400
    prefix = 'ansible-facts'

    cache = CacheModule(cache_dir, prefix, timeout)

    assert cache._cache_dir == cache_dir
    assert cache._prefix == prefix
    assert cache._timeout == timeout

# Generated at 2022-06-23 09:33:37.593196
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    assert(cache._load != None)
    assert(cache._dump != None)

# Generated at 2022-06-23 09:33:41.176290
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

    assert cm.get_timeout() == 86400
    assert cm.get_connection() == ''
    assert cm.get_prefix() == 'ansible-fact'