

# Generated at 2022-06-23 09:23:42.824141
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._timeout == 86400


# Generated at 2022-06-23 09:23:55.651317
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = './test_dir/'
    cache_module = CacheModule(cache_dir)

    cache_module.get('node1', 'value1')
    assert(len(open('./test_dir/node1.json').read()) == 17)
    cache_module.set('node1', 'value1')
    assert(len(open('./test_dir/node1.json').read()) == 17)
    cache_module.delete('node1')
    assert(len(open('./test_dir/node1.json').read()) == 0)

    cache_module.get('node1', 'value1')
    cache_module.get('node2', 'value2')
    assert(len(open('./test_dir/node1.json').read()) == 17)
    cache_module.flush

# Generated at 2022-06-23 09:23:58.402236
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._timeout == 86400
    assert cm._connection == None
    assert cm._prefix == None

# Generated at 2022-06-23 09:24:00.087875
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule()
    assert isinstance(instance, CacheModule)

# Generated at 2022-06-23 09:24:07.300412
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Setup
    plugin = CacheModule()
    plugin._timeout = 1
    plugin._prefix = 'prefix'
    plugin._load = lambda x : x
    plugin._dump = lambda x, y : None
    plugin._uri = './test_caches'

    plugin.set('key1', 'value1')
    plugin.set('key2', 'value2')

    # Test
    assert plugin.get('key1') == 'value1', 'Erreur get with CacheModule'
    assert plugin.get('key2') == 'value2', 'Erreur get with CacheModule'
    assert plugin.has_expired('key1') == False, 'Erreur has_expired with CacheModule'

    # Teardown
    plugin.remove('key1')
    plugin.remove('key2')

# Generated at 2022-06-23 09:24:08.330139
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(isinstance(CacheModule([]), CacheModule))

# Generated at 2022-06-23 09:24:17.561136
# Unit test for constructor of class CacheModule
def test_CacheModule():
    datadir = "/tmp/ansible_tests/ansible_module_cache_jsonfile"
    timeout = 1111111
    cache_plugin = CacheModule(datadir, timeout)

    assert cache_plugin.serializer == 'json'
    assert cache_plugin.datadir == datadir
    assert cache_plugin.timeout == timeout
    # It should not fail
    cache_plugin.get("/localhost", "__foo")
    cache_plugin.set("/localhost", "__foo", [10,20,30])


# Generated at 2022-06-23 09:24:20.539243
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        cache_module = CacheModule()
    except Exception as e:
        assert False, "Creation of CacheModule() fails with exception: " + repr(e)


# Generated at 2022-06-23 09:24:21.461359
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(None), CacheModule)

# Generated at 2022-06-23 09:24:28.822001
# Unit test for constructor of class CacheModule
def test_CacheModule():

    _uri = 'default_uri'
    _prefix = 'default_prefix'
    module = CacheModule(_uri, _prefix)

    # test default config
    assert module._timeout == 86400
    assert module._connection == _uri
    assert module._prefix == _prefix

    # test module
    assert module.__doc__ != ''
    assert module.__dict__
    assert module._load != ''
    assert module._dump != ''

# Generated at 2022-06-23 09:24:36.751880
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import random
    import doctest
    import tempfile
    import shutil
    import os
    import sys

    class MockModule(object):
        """MockModule class"""

        def __init__(self, **kwargs):
            self.params = {}
            self.params.update(kwargs)

        def get_option(self, key):
            """get_option method"""
            return self.params.get(key)

        def fail_json(self, *args, **kwargs):
            """fail_json method"""
            raise Exception(kwargs['msg'])

    # Create temporary directory for using in filesystem tests
    temp_dir = tempfile.mkdtemp()

    # Create temporary file for using in filesystem tests
    _, temp_file = tempfile.mkstemp()

    # Create temporary modules for using in filesystem tests

# Generated at 2022-06-23 09:24:39.328475
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("Testing Constructor")
    cache = CacheModule()

# Generated at 2022-06-23 09:24:41.385864
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._timeout == 86400

# Test for method _load

# Generated at 2022-06-23 09:24:46.109692
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_path = '/path/to/cache/location'
    cache_prefix = 'prefix'
    timeout = 10
    cache_object = CacheModule(cache_path, cache_prefix, timeout)
    # check if proper parameters are set by construtor
    assert cache_object._connection == cache_path
    assert cache_object._prefix == cache_prefix
    assert cache_object._timeout == timeout

# Generated at 2022-06-23 09:24:48.915951
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-23 09:24:49.685521
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c

# Generated at 2022-06-23 09:24:51.459609
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert(cache_plugin) is not None

# Generated at 2022-06-23 09:24:53.495570
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        cache_module = CacheModule('/dev/null', 100)
        assert cache_module is not None
    except:
        assert False

# Generated at 2022-06-23 09:24:54.841122
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None


# Generated at 2022-06-23 09:24:59.452600
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    cache_module.set_options(connection='/tmp', prefix='foo')
    cache_module.flush()
    cache_module.set_options(connection='/tmp', prefix='foo', timeout=3600)
    cache_module.flush()


# Generated at 2022-06-23 09:25:06.272786
# Unit test for constructor of class CacheModule

# Generated at 2022-06-23 09:25:06.739549
# Unit test for constructor of class CacheModule
def test_CacheModule():
    t = CacheModule()

# Generated at 2022-06-23 09:25:08.443128
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert isinstance(module, CacheModule)

# Generated at 2022-06-23 09:25:13.076889
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # JSON formatted files.
    json_cache = CacheModule()

    assert json_cache._options["fact_caching_timeout"] == 0
    assert json_cache._options["fact_caching_connection"] is None
    assert json_cache._options["fact_caching_prefix"] is None


# Generated at 2022-06-23 09:25:14.000280
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:25:14.612812
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:25:17.305624
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:25:19.634954
# Unit test for constructor of class CacheModule
def test_CacheModule():
    timestamp = 1554876612
    assert CacheModule(timestamp).expiration_time == timestamp

# Generated at 2022-06-23 09:25:21.321291
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cls = CacheModule()
    assert cls is not None, ('CacheModule instantiation is valid')

# Generated at 2022-06-23 09:25:33.050209
# Unit test for constructor of class CacheModule
def test_CacheModule():

    module = CacheModule()
    assert module.cache_plugin_timeout == 86400
    assert module.cache_plugin_name == 'jsonfile'
    assert module.cache_plugin_prefix is None
    assert module.cache_plugin_connection is None
    assert module._timeout == 86400
    assert module._connection == None
    assert module._prefix == None

    module = CacheModule('redis', 'ansible', 'http://localhost:16379')
    assert module.cache_plugin_timeout == 86400
    assert module.cache_plugin_name == 'jsonfile'
    assert module.cache_plugin_prefix is None
    assert module.cache_plugin_connection is None
    assert module._timeout == 86400
    assert module._connection == None
    assert module._prefix == None


# Generated at 2022-06-23 09:25:34.826617
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonfile_cache = CacheModule()
    assert jsonfile_cache._load('test') == None

# Generated at 2022-06-23 09:25:37.147610
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import CacheModule
    obj = CacheModule()

# Generated at 2022-06-23 09:25:38.141699
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

# Generated at 2022-06-23 09:25:39.936564
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, BaseFileCacheModule)

# Generated at 2022-06-23 09:25:44.098864
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == None
    assert cache.get_connection() == "~/.ansible/facts"
    assert cache.get_valid() == False

# Generated at 2022-06-23 09:25:48.522160
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = "/tmp/cache_dir"
    timeout = 3600
    prefix = "hostname"
    obj = CacheModule(uri, timeout, prefix)
    assert obj is not None


# Generated at 2022-06-23 09:25:49.949965
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-23 09:25:50.866704
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-23 09:25:57.831672
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('/path/to/json/dir')
    assert cache._connection == '/path/to/json/dir'
    assert cache._prefix == 'ansible-factcache'
    assert cache._timeout == 86400
    cache2 = CacheModule('/path/to/json/dir', 'myprefix')
    assert cache2._connection == '/path/to/json/dir'
    assert cache2._prefix == 'myprefix'
    assert cache2._timeout == 86400
    cache3 = CacheModule('/path/to/json/dir', 'myprefix', 120)
    assert cache3._connection == '/path/to/json/dir'
    assert cache3._prefix == 'myprefix'
    assert cache3._timeout == 120

# Generated at 2022-06-23 09:26:04.799285
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)
    assert CacheModule.__doc__.strip().startswith("A caching module backed by json files.")
    assert CacheModule._load.__doc__.strip() == "_load(self, filepath) method of CacheModule caches the data from filepath in a dictionary"
    assert CacheModule._dump.__doc__.strip() == "_dump(self, value, filepath) method of CacheModule dumps the data in the filepath"

# Generated at 2022-06-23 09:26:15.935121
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import BaseFileCacheModule
    from ansible.plugins.cache.jsonfile import CacheModule

    # TODO: this test is broken in a number of ways:
    # 1) the filename it wants to load is not present in source tree
    # 2) the json data it wants to create/load is not present in source tree
    # 3) the constructor is not being tested
    # 4) if this test is run in the local source tree, it will clobber the
    #    contents of the source file

    cache = CacheModule()
    assert isinstance(cache, BaseFileCacheModule)

    cache = CacheModule(timeout=5)
    assert isinstance(cache, BaseFileCacheModule)

    cache = CacheModule()

    # create sample json data

# Generated at 2022-06-23 09:26:19.740591
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.file_extension == '.json'
    assert cache_module._timeout == 86400


# Generated at 2022-06-23 09:26:21.063574
# Unit test for constructor of class CacheModule
def test_CacheModule():
    f = CacheModule()
    assert f._load is not None

# Generated at 2022-06-23 09:26:24.517185
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    # The below test is just to ensure the constructor of the class doesn't throw any exception
    assert True

# Generated at 2022-06-23 09:26:27.891438
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.file_extension == '.cache'
    assert isinstance(cache._decoder, AnsibleJSONDecoder)
    assert 'CacheModule' in repr(cache)

# Generated at 2022-06-23 09:26:28.943461
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(isinstance(CacheModule(''), CacheModule))

# Generated at 2022-06-23 09:26:34.399041
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Unit test for CacheModule constructor.
    """

    assert issubclass(CacheModule, BaseFileCacheModule)
    cache = CacheModule({}, {'_timeout': 2}, task_vars=None, shared_loader_obj=None)

    assert isinstance(cache, CacheModule)
    assert cache.timeout == 2

    cache.timeout = 5

    assert cache.timeout == 5

# Generated at 2022-06-23 09:26:35.782660
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._connection._load() == 'test'

# Generated at 2022-06-23 09:26:39.509835
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(task_vars={'cache_prefix': 'foo', 'cache_connection': '/tmp/ansible_cache'})
    assert cache_module.get_options() == dict(_prefix='foo', _timeout=86400, _uri='/tmp/ansible_cache')

# Generated at 2022-06-23 09:26:40.793785
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule('/foo')
    assert m.plugin_name == 'jsonfile'

# Generated at 2022-06-23 09:26:44.612371
# Unit test for constructor of class CacheModule
def test_CacheModule():
    db = CacheModule()
    assert db.uri == ''
    assert db._prefix == 'ansible-cache'
    assert db._timeout == 86400

# Generated at 2022-06-23 09:26:48.069227
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._prefix is None
    assert cache._timeout == 86400
    assert cache._uri == "/tmp/ansible_fact_cache"


# Generated at 2022-06-23 09:26:51.134409
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._load is not None
    assert cm._dump is not None

# Generated at 2022-06-23 09:26:53.037402
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Filepath is optional argument. If not provided, it will use default value - /tmp/ansible_fact_cache
    cache = CacheModule()
    assert cache.filepath == '/tmp/ansible_fact_cache'
    cache = CacheModule(filepath='/tmp/test.json')
    assert cache.filepath == '/tmp/test.json'

# Generated at 2022-06-23 09:26:54.027400
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._load

# Generated at 2022-06-23 09:26:58.904297
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Unit Test for constructor of class CacheModule"""
    plugin_name = 'jsonfile'
    timeout = 86400
    config = {'_timeout': timeout,'_prefix':'','_uri': ''}
    cache_module = CacheModule(plugin_name, **config)
    assert cache_module.plugin_name == plugin_name
    assert cache_module.timeout == timeout

# Generated at 2022-06-23 09:27:00.430529
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule("/tmp", 3600, "test")
    assert m.filepath("localhost") == "/tmp/test_localhost.json"

# Generated at 2022-06-23 09:27:09.485773
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    # The module only works on unix-like systems
    try:
        assert cache.plugin
        assert cache.plugin == 'jsonfile'
    except AssertionError:
        raise "CacheModule does not have a module variable called plugin"

# Generated at 2022-06-23 09:27:15.342535
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    #Check 'set_options' method works properly
    cache.set_options(timeout=100)
    assert cache.timeout == 100
    #Check 'get' method works properly
    cache_value = cache.get('key')
    assert cache_value == {}
    #Check 'get' method works properly
    cache_value = cache.get('key', 'def')
    assert cache_value == 'def'
    #Check 'set' method works properly
    cache.set('key', 'value')
    assert cache.get('key') == 'value'
    #Check 'set' method works properly
    assert cache.has_expired('key') == False
    #Check 'purge' method works properly
    cache.purge('key')
    assert cache.get('key') == {}
    #Check 'keys'

# Generated at 2022-06-23 09:27:17.444790
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._uri == '~/.ansible/tmp/ansible-local'

# Generated at 2022-06-23 09:27:21.653942
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create an instance of CacheModule
    cache_module = CacheModule()

    # Make sure that _load was called
    assert cache_module._load('filepath')

    # Make sure that _dump was called
    assert cache_module._dump('value', 'filepath')

# Generated at 2022-06-23 09:27:25.012756
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert isinstance(cache_module, CacheModule)
    assert cache_module._timeout == 86400
    assert cache_module._prefix == ''
    assert cache_module._uri == None

# Generated at 2022-06-23 09:27:26.962615
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-23 09:27:27.570228
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:27:30.833851
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.ext == 'cache'
    assert cache_plugin._connection is None
    assert cache_plugin._prefix is None
    assert cache_plugin._timeout == 86400

# Generated at 2022-06-23 09:27:40.317989
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = {'foo': 'bar'}
    cache_plugin_name = 'jsonfile'
    timeout = 86400
    connection = '/tmp'
    prefix = 'foobar'

    # Basic constructor
    cache_plugin = CacheModule()
    assert cache_plugin
    assert cache_plugin.connection == None
    assert cache_plugin.prefix == None
    assert cache_plugin.cache == {}

    # Constructor with args
    cache_plugin = CacheModule(connection, prefix)
    assert cache_plugin
    assert cache_plugin.connection == connection
    assert cache_plugin.prefix == prefix
    assert cache_plugin.cache == {}

    # Constructor with default values
    cache_plugin = CacheModule(connection='', prefix='', timeout=timeout, cache=data)
    assert cache_plugin
    assert cache_plugin.connection == ''


# Generated at 2022-06-23 09:27:45.799068
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule()
    expected = 'jsonfile'
    assert instance.plugin_name == expected, 'plugin_name not set correctly'
    assert instance._options['_uri'] is None, '_uri not set to default'
    assert instance._options['_timeout'] == 86400, '_timeout not set to default'
    assert instance._options['_prefix'] is None, '_prefix not set to default'

# Generated at 2022-06-23 09:27:48.520504
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-23 09:27:49.625627
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_CacheModule = CacheModule()
    return test_CacheModule


# Generated at 2022-06-23 09:27:52.721302
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(task_vars={}).dump({'a': {'b': {'c': 'd'}}}) == \
        '{\n    "a": {\n        "b": {\n            "c": "d"\n        }\n    }\n}\n'

# Generated at 2022-06-23 09:27:54.345842
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400

# Generated at 2022-06-23 09:27:56.245492
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({})
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-fact'

# Generated at 2022-06-23 09:27:59.201253
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins import cache_loader
    assert cache_loader._create_cache_instance("jsonfile", {})

# Generated at 2022-06-23 09:28:04.442066
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(None,{"_timeout": 3600, "_prefix": "default/", "_uri": "/var/tmp"})
    assert cache._timeout == 3600
    assert cache._prefix == "default/"
    assert cache._connection == "/var/tmp"
    assert cache._plugin_name == "jsonfile"

# Generated at 2022-06-23 09:28:10.093644
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = 'path/to/cache'
    timeout = 86400
    prefix = 'dummy_prefix'
    cache_module = CacheModule(path=path, timeout=timeout, prefix=prefix)
    assert cache_module._timeout == timeout
    assert cache_module._prefix == prefix
    assert cache_module._uri == path

# Generated at 2022-06-23 09:28:11.066298
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm != None

# Generated at 2022-06-23 09:28:15.846254
# Unit test for constructor of class CacheModule
def test_CacheModule():
    fact_caching_connection = "/tmp/ansible/facts/"
    fact_caching_timeout = 3600
    fact_caching_prefix = "fact_"
    cache = CacheModule(fact_caching_connection, fact_caching_timeout, fact_caching_prefix)
    assert cache.get_timeout() == 3600
    assert cache.get_connection() == "/tmp/ansible/facts/"
    assert cache.get_prefix() == "fact_"

# Generated at 2022-06-23 09:28:17.906701
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(connection="connection", prefix="prefix"))

# Generated at 2022-06-23 09:28:18.759687
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:28:21.758054
# Unit test for constructor of class CacheModule
def test_CacheModule():
    a = CacheModule()
    print("\nFinished test method test_CacheModule() originally defined in module " + a.__class__.__module__ + "\n")

# Generated at 2022-06-23 09:28:23.676002
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)



# Generated at 2022-06-23 09:28:33.807856
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from collections import namedtuple

    setattr(CacheModule, 'get', lambda self, key: None)
    setattr(CacheModule, 'set', lambda self, key, value: None)

    cache_plugin_options = namedtuple('Options', ('fact_caching', 'fact_caching_connection', 'fact_caching_timeout', 'fact_caching_prefix'))
    options = cache_plugin_options('jsonfile', '/tmp/ansible/cache', 3600, '')
    cache = CacheModule(None, options, False)
    assert cache.get_cache_dir() == '/tmp/ansible/cache'
    assert cache.get_timeout() == 3600

# Generated at 2022-06-23 09:28:34.750493
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()


# Generated at 2022-06-23 09:28:36.272668
# Unit test for constructor of class CacheModule
def test_CacheModule():
    parsed = CacheModule(connection='/root/file')
    assert parsed._connection == '/root/file'

# Generated at 2022-06-23 09:28:39.295952
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    cache_plugin.set_options(direct)
    cache_plugin.flush()

# Generated at 2022-06-23 09:28:40.382877
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-23 09:28:41.859479
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-23 09:28:46.692337
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.file_extension == 'json'
    assert c.file_prefix == 'ansible_facts'
    assert c.file_cache_dir == '/var/tmp/ansible_fact_cache'
    assert c.file_cache_max_age == 86400

# Generated at 2022-06-23 09:28:48.481100
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filepath = 'testcache'
    cm = CacheModule(filepath)


# Generated at 2022-06-23 09:28:51.705235
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule(task_vars=dict())
    assert cache_plugin._timeout == 86400

# Generated at 2022-06-23 09:28:56.110108
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule('test', 'test')
    assert cm.path == 'test'
    assert cm.plugin_name == 'test'
    assert cm.lockfile == 'test.lock'
    assert cm.cache_lock is False

# Generated at 2022-06-23 09:28:58.795927
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule._load.func_name == '_load'
    assert cacheModule._dump.func_name == '_dump'


# Generated at 2022-06-23 09:29:04.239411
# Unit test for constructor of class CacheModule
def test_CacheModule():
        cache = CacheModule()
        assert hasattr(cache,'_load')
        assert hasattr(cache,'_dump')
        
m = CacheModule()
m.set('a', 'b')
m.set('a', 'b')
m.get('a')

# Generated at 2022-06-23 09:29:05.529444
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-23 09:29:06.553976
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module

# Generated at 2022-06-23 09:29:12.681592
# Unit test for constructor of class CacheModule
def test_CacheModule():
	# Test for cache file exists
    cache = CacheModule()
    hostvars = cache.get('hostvars')
    hostvars['host1'] = {'var1': 'val1'}
    cache.set('hostvars', hostvars)
    # Test for cache file absent
    cache1 = CacheModule()
    hostvars1 = cache1.get('hostvars')
    assert hostvars1['host1'] == {'var1': 'val1'}

# Generated at 2022-06-23 09:29:15.500516
# Unit test for constructor of class CacheModule

# Generated at 2022-06-23 09:29:17.505842
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # This is a default constructor to create an object of class CacheModule
    assert CacheModule()

# Generated at 2022-06-23 09:29:21.542829
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert isinstance(cache_module, CacheModule)
    assert isinstance(cache_module, BaseFileCacheModule)

# Unit test to exercise the _load method of class CacheModule

# Generated at 2022-06-23 09:29:23.097361
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(None).module_name == 'jsonfile'

# Generated at 2022-06-23 09:29:24.799265
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-23 09:29:29.266334
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with open('test_cache_module.json', 'r') as f:
        ansible_json = json.load(f)
        cm = CacheModule()
        assert ansible_json == cm._load('test_cache_module.json')

# Generated at 2022-06-23 09:29:30.854044
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._load(None, None) == None

# Generated at 2022-06-23 09:29:31.427957
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:29:33.167181
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()

# Generated at 2022-06-23 09:29:34.722291
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None


# Generated at 2022-06-23 09:29:35.637380
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module

# Generated at 2022-06-23 09:29:37.316080
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    print(cache_plugin)

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:29:37.800560
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:29:50.074860
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ca = CacheModule()
    assert type(ca) == CacheModule
    ca.set_options(dict(
        _timeout=86400,
        _prefix='',
        _uri='/root/.ansible/cache'
    ))
    assert ca.get_timeout() == 86400
    assert ca.get_prefix() == ''
    assert ca.get_basedir() == '/root/.ansible/cache'

    # .set_options() ignores not listed options
    ca.set_options(dict(
        _timeout=123,
        _prefix='prefix',
        _uri='/root/.ansible/cache',
        _xxxxx='xxxxx'
    ))
    assert ca.get_timeout() == 123
    assert ca.get_prefix() == 'prefix'

# Generated at 2022-06-23 09:29:52.696177
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin != None
    assert cache_plugin._load("cache_plugin_test.TestCacheModule.test_load") != None

# Generated at 2022-06-23 09:29:57.338011
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = "test_data"
    x = CacheModule()
    x.set('test_data', data)
    assert x.get('test_data') == data

# Generated at 2022-06-23 09:29:58.777009
# Unit test for constructor of class CacheModule
def test_CacheModule():
  cm = CacheModule({})
  assert type(cm) == CacheModule
  assert cm._timeout == 86400
  assert cm._prefix == 'ansible-fact-cache'
  assert cm._load({}) == NotImplemented
  assert cm._dump({}, {}) == NotImplemented

# Generated at 2022-06-23 09:30:04.476680
# Unit test for constructor of class CacheModule
def test_CacheModule():
    fpath = "/tmp"
    prefix = "foo"
    timeout = 0
    cm = CacheModule(fpath, prefix, timeout)
    assert cm.file_path == fpath
    assert cm.plugin_name == 'jsonfile'

# Generated at 2022-06-23 09:30:07.618442
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.HAS_TREE == True
    assert module._timeout == 86400
    assert module._prefix == ''


# Generated at 2022-06-23 09:30:09.776361
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._prefix == 'ansible_facts'
    assert plugin._timeout == 86400
    assert plugin._connection is None

# Generated at 2022-06-23 09:30:11.462695
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-23 09:30:18.300281
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule({'ANSIBLE_CACHE_PLUGIN_CONNECTION': 'test',
                          'ANSIBLE_CACHE_PLUGIN_PREFIX': 'test',
                          'ANSIBLE_CACHE_PLUGIN_TIMEOUT': 10})
    assert module.cache_path == 'test'
    assert module.cache_key_name == 'test'
    assert module.cache_max_age == 10
    assert module._load == json.load
    assert module._dump == json.dump
    assert module.get_cache_path == 'test'

# Generated at 2022-06-23 09:30:19.477675
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-23 09:30:22.423746
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = CacheModule(task_vars=dict(ansible_connection='local'))
    assert connection._connection == 'local'

# Generated at 2022-06-23 09:30:23.508241
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache=CacheModule()
    assert True

# Generated at 2022-06-23 09:30:27.929004
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_json = CacheModule({"_uri": "/tmp"})

    assert cache_json._prefix == ""
    assert cache_json._timeout == 86400
    assert cache_json._load == cache_json._load
    assert cache_json._dump == cache_json._dump
    assert cache_json._uri == "/tmp"

# Generated at 2022-06-23 09:30:29.512083
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-23 09:30:30.235712
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert len(CacheModule())

# Generated at 2022-06-23 09:30:36.446069
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule()
    assert instance.__class__.__name__ == "CacheModule"

    # Test object methods
    assert instance.get() is None
    assert instance.set() is None
    assert instance.keys() is None
    assert instance.contains() is None
    assert instance.delete() is None
    assert instance.flush() is None

# Generated at 2022-06-23 09:30:37.437740
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:30:44.472877
# Unit test for constructor of class CacheModule
def test_CacheModule():
    class Options():
        _plugin_name = 'jsonfile'
        _timeout = 60
    current = CacheModule(Options())
    exp = {
        '_plugin_name': 'jsonfile',
        '_prefix': 'ansible_facts',
        '_timeout': 60,
        '_uri': '~/.ansible/tmp/ansible-local/tmpvTzguD'
    }
    assert current.get_options() == exp

# Generated at 2022-06-23 09:30:54.847495
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test with minimal params
    cache_jsonfile = CacheModule()
    assert cache_jsonfile.cachedir == '~/.ansible/tmp'
    assert cache_jsonfile.timeout == 86400
    assert cache_jsonfile.plugin_name == 'jsonfile'
    assert cache_jsonfile.plugin_prefix == 'ansible_fact_cache_'
    assert cache_jsonfile.plugin_timeout == 86400

    # test with all params
    test_jsonfile_cache = CacheModule(cachedir='/test/cachedir', timeout=500)
    assert test_jsonfile_cache.cachedir == '/test/cachedir'
    assert test_jsonfile_cache.timeout == 500
    assert test_jsonfile_cache.plugin_name == 'jsonfile'
    assert test_jsonfile_cache.plugin_

# Generated at 2022-06-23 09:30:55.950726
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_module = CacheModule()
    assert isinstance(test_module, CacheModule)

# Generated at 2022-06-23 09:30:58.561557
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m

# Generated at 2022-06-23 09:30:59.606478
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule(dict())

# Generated at 2022-06-23 09:31:00.538719
# Unit test for constructor of class CacheModule
def test_CacheModule():
    global n    
    n = CacheModule()

# Generated at 2022-06-23 09:31:03.322896
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachemodule = CacheModule()
    assert isinstance(cachemodule, CacheModule)


# Generated at 2022-06-23 09:31:04.683873
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-23 09:31:11.210825
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._connection == '$HOME/.ansible/tmp/ansible-local'
    assert cache._prefix == 'ansible_fact_'
    assert cache._timeout == 86400

# Generated at 2022-06-23 09:31:16.164264
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = 'mydir'
    cache_prefix = 'prefix_'
    cache_timeout = 1800
    c = CacheModule({'_uri': cache_dir,
                     '_prefix': cache_prefix,
                     '_timeout': cache_timeout})
    assert c._cache_dir == cache_dir
    assert c._cache_prefix == cache_prefix
    assert c._cache_timeout == cache_timeout

# Generated at 2022-06-23 09:31:17.694362
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule('/tmp/foo')
    assert module._connection == '/tmp/foo'

# Generated at 2022-06-23 09:31:20.053074
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule() is not None


# Generated at 2022-06-23 09:31:24.548156
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """ test constructor of class CacheModule """

    cache_plugin = CacheModule()

    assert cache_plugin.plugin_name == 'jsonfile'
    assert cache_plugin._connection.uri == '~/.ansible/tmp/ansible-caching'
    assert cache_plugin._options['_timeout'] == 86400

# Generated at 2022-06-23 09:31:26.791029
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Just try to instantiate the class module, no error expected"""
    cm = CacheModule()
    assert cm is not None

# Generated at 2022-06-23 09:31:27.721617
# Unit test for constructor of class CacheModule
def test_CacheModule():
    facts_jsonfile = CacheModule()

# Generated at 2022-06-23 09:31:30.902940
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with default plugin settings
    plugin = CacheModule()
    assert plugin._connection == ''
    assert plugin._timeout == 86400

    # Test with specified plugin settings
    plugin = CacheModule(timeout=10)
    assert plugin._connection == ''
    assert plugin._timeout == 10

# Generated at 2022-06-23 09:31:32.662771
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    This function returns the documentation for the constructor of class CacheModule
    """
    return CacheModule.__doc__

# Generated at 2022-06-23 09:31:40.461602
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    assert(cache._timeout == 86400)

    # Overriding the timeout
    setattr(cache, "_timeout", 120)
    assert(cache._timeout == 120)

    # Setting the timeout back to default value
    setattr(cache, "_timeout", None)
    assert(cache._timeout == 86400)

    # Make sure that the name of the cache plugin is set
    assert(cache._plugin_name == "jsonfile")

    # Make sure the _plugin_name cannot be changed via _plugin_name property
    try:
        setattr(cache, "_plugin_name", "new_jsonfile")
        assert(False)
    except:
        assert(True)

    # Make sure the _plugin_name is set to "jsonfile" even after
    # the setattr fails

# Generated at 2022-06-23 09:31:43.315450
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert hasattr(x, '_load')
    assert hasattr(x, '_dump')

# Generated at 2022-06-23 09:31:44.519292
# Unit test for constructor of class CacheModule
def test_CacheModule():
    new_CacheModule = CacheModule()
    assert isinstance(new_CacheModule, CacheModule)

# Generated at 2022-06-23 09:31:48.574386
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert isinstance(x, BaseFileCacheModule)
    assert hasattr(x, '_load')
    assert hasattr(x, '_dump')
    assert hasattr(x, 'get')
    assert hasattr(x, 'set')

# Generated at 2022-06-23 09:32:02.983782
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile

    cm = CacheModule({'_uri': None, '_prefix': None, '_timeout': None})
    try:
        os.system("rm -rf '%s'" % cm.cache_dir)
        os.system("mkdir -p '%s'" % cm.cache_dir)
    except Exception:
        pass

    # populate cache
    cm.set('host1', 'key1', 'value1')

    # get from cache
    assert cm.get('host1', 'key1') == 'value1'

    # get from cache again, now we should get it from memory
    assert cm.get('host1', 'key1') == 'value1'

    # create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-23 09:32:06.346336
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Constructor test for class CacheModule
    :return:
    """
    cache = CacheModule()

# Generated at 2022-06-23 09:32:07.712557
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule is not None


# Generated at 2022-06-23 09:32:12.505171
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # construct a CacheModule object
    jsonfile = CacheModule()
    assert jsonfile is not None

    # construct a CacheModule object which will use a file path different from ANSIBLE_CACHEDIR
    uri = '/my/path'
    jsonfile = CacheModule(uri)
    assert jsonfile is not None

# Generated at 2022-06-23 09:32:15.868498
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.cache_plugin_name == 'jsonfile'
    assert module.cache_plugin_timeout == 86400
    assert module.cache_plugin_connection == None
    assert module.cache_plugin_prefix == None

# Generated at 2022-06-23 09:32:16.373196
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-23 09:32:18.153689
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._load is not None
    assert plugin._dump is not None

# Generated at 2022-06-23 09:32:24.088987
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.utils.path import makedirs_safe
    from tempfile import mkdtemp
    test_dir = mkdtemp()
    makedirs_safe(test_dir)
    cache = CacheModule({'_uri': test_dir, '_timeout': 0}, False)
    return cache


# Generated at 2022-06-23 09:32:27.006747
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create test object and test if it is an instance of the class CacheModule
    test_object = CacheModule()
    assert isinstance(test_object, CacheModule)

# Generated at 2022-06-23 09:32:29.323928
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(task=None)

# Generated at 2022-06-23 09:32:30.870403
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = CacheModule()
    assert isinstance(connection, BaseFileCacheModule)

# Generated at 2022-06-23 09:32:34.540481
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()

    assert cacheModule.get('key') == None
    assert cacheModule.set('key', 'value') == True
    assert cacheModule.get('key') == 'value'
    assert cacheModule.delete('key') == True
    assert cacheModule.get('key') == None

# Generated at 2022-06-23 09:32:36.191029
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache

# Generated at 2022-06-23 09:32:38.668449
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module is not None
    assert isinstance(module, BaseFileCacheModule)



# Generated at 2022-06-23 09:32:44.695828
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.file_extension == '.json'
    assert cache._load.__name__ == '_load'
    assert cache._dump.__name__ == '_dump'
    assert cache.get_cache_file_path('hostname', 'prefix') == 'hostname.json'
    assert cache.get_cache_file_path('hostname', 'prefix', 'dir', 'ext') == 'dir/hostname.ext'


# Generated at 2022-06-23 09:32:50.377886
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': '/tmp/', '_prefix': 'foo'})
    assert cache.plugin_name == 'jsonfile'
    assert isinstance(cache, CacheModule)



# Generated at 2022-06-23 09:33:02.747299
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    cm.set_options(filename='test.json',valid=False)
    cm.set_options(filename='test.json',valid=True)
    assert cm.get_valid_option('valid') == True
    assert cm.get_valid_option('filename') == "test.json"
    cm.set_options(filename='test.json',valid=False)
    assert cm.get_valid_option('valid') == False
    cm.set_options(filename='test.json',valid=True)
    assert cm.get_valid_option('valid') == True
    assert cm.get_valid_option('filename') == "test.json"

    assert cm._load("test/data/tmp1.json") == {"a": 1, "b": 2, "c": 3}
    assert cm._load

# Generated at 2022-06-23 09:33:04.175975
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule is not None

# Generated at 2022-06-23 09:33:08.444563
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachemodule = CacheModule()
    assert cachemodule._load("C:\\Users\\Mehul\\PycharmProjects\\Ansible\\lib\\ansible\\plugins\\cache\\jsonfile.py")

# Generated at 2022-06-23 09:33:10.491938
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert hasattr(obj, '_load')
    assert hasattr(obj, '_dump')

# Generated at 2022-06-23 09:33:11.613831
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-23 09:33:13.047248
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'test'}) is not None

# Generated at 2022-06-23 09:33:14.389225
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheplugin = CacheModule()
    assert isinstance(cacheplugin,BaseFileCacheModule)

# Generated at 2022-06-23 09:33:15.755925
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c

# Generated at 2022-06-23 09:33:18.941504
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    # Checks if class is subclass of BaseFileCacheModule
    assert issubclass(CacheModule, BaseFileCacheModule)
    assert isinstance(plugin, BaseFileCacheModule)

# Generated at 2022-06-23 09:33:21.428884
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cs = CacheModule()
    assert cs is not None

# Generated at 2022-06-23 09:33:22.119925
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert True

# Generated at 2022-06-23 09:33:27.173706
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule('/tmp')._uri == '/tmp'
    assert CacheModule('/tmp', 'cache')._uri == '/tmp'
    assert CacheModule('/tmp', 'cache', timeout=6000)._timeout == 6000
    assert CacheModule('/tmp', timeout=6000)._timeout == 6000
    assert CacheModule('/tmp', 'cache', timeout=6000)._prefix == 'cache'
    assert CacheModule('/tmp', prefix='cache')._prefix == 'cache'

# Generated at 2022-06-23 09:33:30.229487
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert 'cache_plugin_timeout' not in cm.get_options()

# Generated at 2022-06-23 09:33:31.304612
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.__class__.__name__ == 'CacheModule'

# Generated at 2022-06-23 09:33:33.097538
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_cache = CacheModule()
    assert test_cache is not None

# Generated at 2022-06-23 09:33:36.396421
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule.get_option('_uri') is None
    assert cacheModule.get_option('_prefix') is None
    assert cacheModule.get_option('_timeout') == 3600

# Generated at 2022-06-23 09:33:39.372678
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test_CacheModule: Plugin cache.jsonfile should be registered
    from ansible.plugins.cache.jsonfile import CacheModule
    c = CacheModule()
    assert c

# Generated at 2022-06-23 09:33:49.488464
# Unit test for constructor of class CacheModule
def test_CacheModule():

    class C_CacheModule(CacheModule):
        def __init__(self, *args, **kwargs):
            self.data = {'C_CacheModule': 'C_CacheModule'}
            super(C_CacheModule, self).__init__(*args, **kwargs)

        def get(self, key):
            return self.data

        def set(self, key, value):
            self.data = value

    cache = C_CacheModule()
    assert cache.get('cache') == {'C_CacheModule': 'C_CacheModule'}
    cache.set('1', 'value')
    assert cache.get('1') == 'value'