

# Generated at 2022-06-23 09:23:42.497944
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.__class__.__name__ == "CacheModule"

# Generated at 2022-06-23 09:23:45.877422
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, BaseFileCacheModule)

# Generated at 2022-06-23 09:23:51.533386
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = '/tmp'
    cache_prefix = 'ansible-cache'
    cache_timeout = 86400
    plugin = CacheModule({'_uri': cache_dir, '_prefix': cache_prefix, '_timeout': cache_timeout})
    assert plugin.cache_dir == cache_dir
    assert plugin.cache_prefix == cache_prefix
    assert plugin.cache_timeout == cache_timeout

# Generated at 2022-06-23 09:23:53.694574
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})._plugin_name



# Generated at 2022-06-23 09:23:54.398833
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-23 09:23:58.757498
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.path == ''
    assert cache.timeout == ''
    assert cache.plugin_timeout == 86400
    assert cache.plugin_prefix == ''
    assert cache.plugin_connection == ''
    assert cache.get_value('host_one') is None

# Generated at 2022-06-23 09:23:59.902354
# Unit test for constructor of class CacheModule
def test_CacheModule():
   cache = CacheModule()


# Generated at 2022-06-23 09:24:08.870339
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._load() is None
    assert plugin._dump() is None
    assert plugin._load_cache() is None
    assert plugin._dump_cache() is None
    assert plugin._load_cache_plugin() == []
    assert plugin._load_cache_plugin("data") is None
    assert plugin._save_cache_plugin("host", "data") is None
    assert plugin._delete_cache_plugin("host") is None
    assert plugin.get("host") == []
    assert plugin.set("host", "data") is None

# Generated at 2022-06-23 09:24:19.830362
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import pytest
    from ansible.plugins.cache.jsonfile import CacheModule
    from ansible.plugins.cache import BaseFileCacheModule
    from ansible.utils.path import makedirs_safe
    from os import path

    # Create a cache plugin object
    cache_plugin_obj = CacheModule()

    # Assert that the class is derived from the BaseFileCacheModule class
    assert issubclass(CacheModule, BaseFileCacheModule)

    # Assert that the constructor successfully initialized the required instance variables
    assert cache_plugin_obj._connection == 'ansible_test_directory'
    assert cache_plugin_obj._timeout == 600
    assert cache_plugin_obj._prefix == 'ansible_test_prefix'


# Generated at 2022-06-23 09:24:21.887307
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'my_uri'})

# Unit test to test the BaseFileCacheModule method get

# Generated at 2022-06-23 09:24:25.355240
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('test') is None
    assert cache_module._dump('test', 'test') is None

# Generated at 2022-06-23 09:24:27.673035
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._encoder == AnsibleJSONEncoder
    assert cache._decoder == AnsibleJSONDecoder
    assert cache._extension == 'json'
    assert cache._prefix == 'ansible_facts_'

# Generated at 2022-06-23 09:24:28.497774
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin

# Generated at 2022-06-23 09:24:31.379774
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert (obj._timeout == 86400)
    assert (obj._prefix == '')

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:24:34.313316
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.get_valid_extensions() == ['.json']

# Generated at 2022-06-23 09:24:35.824687
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m.file_extension == ".json"

# Generated at 2022-06-23 09:24:38.760627
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

# Generated at 2022-06-23 09:24:39.661335
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin is not None

# Generated at 2022-06-23 09:24:47.530644
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    from ansible.plugins.cache import get_cache_plugin
    from ansible.module_utils._text import to_text

    module_name = '_jsonfile_'
    tmp_dir = tempfile.mkdtemp(prefix='ansible_test_cache')
    cache_plugin, lookup_plugin = get_cache_plugin(module_name, tmp_dir)
    result = cache_plugin.set('foo', 'bar')

    assert result is True
    data = cache_plugin.get('foo')
    assert to_text(json.dumps(data)) == '"bar"'

# Generated at 2022-06-23 09:24:48.645559
# Unit test for constructor of class CacheModule
def test_CacheModule():
    backend = CacheModule()
    assert isinstance(backend,CacheModule)

# Generated at 2022-06-23 09:24:56.224220
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_name = 'jsonfile'
    cache_plugin_timeout = 86400
    cache_plugin_prefix = 'ansible_facts'
    cache_plugin_connection = '~/.ansible/fact_cache'
    cache_plugin_expires = 'test'
    cache_plugin_validate_extensions = 'test'

    cache_plugin = CacheModule(cache_plugin_name, cache_plugin_timeout, cache_plugin_prefix,
                               cache_plugin_connection, cache_plugin_expires, cache_plugin_validate_extensions)
    assert cache_plugin.name == 'jsonfile'
    assert cache_plugin.timeout == 86400
    assert cache_plugin.prefix == 'ansible_facts'
    assert cache_plugin.connection == '~/.ansible/fact_cache'
    assert cache_plugin

# Generated at 2022-06-23 09:24:57.065049
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj is not None

# Generated at 2022-06-23 09:24:59.952836
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._uri == '~/.ansible/cache'
    assert cache_plugin._prefix == 'ansible-factcache'
    assert hasattr(cache_plugin, 'get')
    assert hasattr(cache_plugin, 'set')

# Generated at 2022-06-23 09:25:00.799459
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Make sure the class was constructed
    assert CacheModule()

# Generated at 2022-06-23 09:25:06.782342
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create a CacheModule
    c = CacheModule()

    # Assert all class variables have been initialized with data type
    assert type(c._timeout) is int
    assert type(c._connection) is dict
    assert (type(c._prefix) is str
            or (type(c._prefix) is unicode and type(c._prefix) is not str))
    assert (type(c._cache_dir) is str
            or (type(c._cache_dir) is unicode and type(c._cache_dir) is not str))
    assert type(c._CACHE_PLUGIN_CHECK_MODE) is bool
    assert type(c._CACHE_PLUGIN_DEBUG) is bool

# Generated at 2022-06-23 09:25:10.950073
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Basic test for class CacheModule constructor
    """
    data = {}
    data["_uri"] = "/tmp/ansible_cache"
    data["_prefix"] = "ansible"
    data["_timeout"] = 86400
    CacheModule(data)

# Generated at 2022-06-23 09:25:11.696607
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._load

# Generated at 2022-06-23 09:25:14.916422
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule({'file': '/path/to/cache',
                        '_timeout': '600',
                        '_prefix': 'test_caching'})
    assert module.file == '/path/to/cache'
    assert module._timeout == 600
    assert module._prefix == 'test_caching'


# Generated at 2022-06-23 09:25:17.613919
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm_module = CacheModule()


if __name__ == '__main__':
    cm_module = CacheModule()
    print(cm_module)

# Generated at 2022-06-23 09:25:19.589450
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    from ansible.plugins.cache.memory import BaseFileCacheModule
    myCacheModule = CacheModule()
    assert isinstance(myCacheModule, BaseFileCacheModule)

# Generated at 2022-06-23 09:25:21.618159
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._loaded == False
    assert plugin.cache_dir == None
    assert plugin._timeout == 86400

# Generated at 2022-06-23 09:25:24.074700
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:25:28.837103
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Use the CacheModule constructor
    params = {'_uri': '.', '_prefix': 'abc', '_timeout': 100}
    cm = CacheModule(params)
    # assert that the correctly initialized parmaeters is set
    assert cm.path == '.'
    assert cm.prefix == 'abc'
    assert cm.timeout == 100

# Generated at 2022-06-23 09:25:29.852800
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-23 09:25:35.058831
# Unit test for constructor of class CacheModule
def test_CacheModule():
    (connection, prefix, timeout) = 'test_connection', 'test_prefix', 10
    cache_module = CacheModule()
    assert cache_module._connection == ''
    assert cache_module._prefix == ''
    assert cache_module._timeout == 86400

    cache_module = CacheModule(connection=connection,
                               prefix=prefix,
                               timeout=timeout)
    assert cache_module._connection == connection
    assert cache_module._prefix == prefix
    assert cache_module._timeout == timeout


# Generated at 2022-06-23 09:25:40.036695
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule( task=None, play=None, new_stdin='', connection=None,
                         ansible=None, pin_this_thread=False, runner_cache=None )
    assert module is not None


# Generated at 2022-06-23 09:25:41.776822
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.plugin_name == 'jsonfile'
    assert cache.get_options() == {'_timeout': 86400, '_prefix': 'ansible_facts', '_uri': None}

# Generated at 2022-06-23 09:25:42.881875
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule(), '_load')

# Generated at 2022-06-23 09:25:46.525030
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(None, task_uid='foo')
    assert cache.cache_prefix == 'foo'

# Generated at 2022-06-23 09:25:49.679363
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule({})
    assert plugin._connection == '$HOME/.ansible/cache'
    assert plugin._prefix == 'ansible-facts'
    assert plugin._timeout == 86400

# Generated at 2022-06-23 09:25:54.614061
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Constructor of class CacheModule.
    """

    args = dict(
        _uri="test_uri",
        _prefix="test_prefix",
        _timeout=123,
    )

    obj = CacheModule(**args)
    assert obj.plugin_name == 'jsonfile'
    assert obj._timeout == 123
    assert obj._prefix == args["_prefix"]
    assert obj._cache_dir == args["_uri"]



# Generated at 2022-06-23 09:25:55.776020
# Unit test for constructor of class CacheModule
def test_CacheModule():
    anonymous_CacheModule = CacheModule()

# Generated at 2022-06-23 09:25:59.245066
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_cache_size() == 0


# Generated at 2022-06-23 09:26:03.688613
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.data == {}
    assert c.plugin_name == 'jsonfile'
    assert c._timeout == 86400
    assert c.path == '~/.ansible/cache'
    assert c._prefix == 'ansible-cache'

# Generated at 2022-06-23 09:26:06.118561
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_obj = CacheModule()
    assert isinstance(cache_plugin_obj, CacheModule)


# Generated at 2022-06-23 09:26:06.887420
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:26:07.935262
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m is not None

# Generated at 2022-06-23 09:26:14.136788
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = "file:///tmp/ansible/cachedir"
    timeout = 3600
    prefix = "ansible_jsonfile"
    cache_module = CacheModule(uri, timeout, prefix)
    assert cache_module.timeout == timeout
    assert cache_module.cachefile == "%s/ansible_jsonfile" % uri[7:] # remove "file://"
    assert cache_module.fact_caching == True

# Generated at 2022-06-23 09:26:19.392441
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule, type)
    cache_plugin = CacheModule({
        '_uri': '/home/user/ansible_cached_facts',
        '_prefix': 'foobar',
        '_timeout': 3600
    })
    assert cache_plugin.basedir == '/home/user/ansible_cached_facts'
    assert cache_plugin.prefix == 'foobar'
    assert cache_plugin.timeout == 3600

# Generated at 2022-06-23 09:26:21.020056
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, '__call__')


# Generated at 2022-06-23 09:26:23.427104
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._timeout == 86400

# Generated at 2022-06-23 09:26:25.988125
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule("test", {'_uri': 'test'})
    assert cm
    return cm



# Generated at 2022-06-23 09:26:30.871129
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("Test_CacheModule constructor")
    assert isinstance(CacheModule().get_options(), dict)

# CacheModule instance and class variables
print("Test_CacheModule instance")
foo = CacheModule()
print("Test_CacheModule class")
foo.CacheModule()


# Generated at 2022-06-23 09:26:31.712129
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-23 09:26:37.536680
# Unit test for constructor of class CacheModule
def test_CacheModule():
    fact_cache = CacheModule()
    print("\n*** Class constructor test: ")
    print(fact_cache.__doc__)

    # Delete files in cache folder
    fact_cache.flush()
    print("\n*** Flush test: \nDeleting all files in temp folder '%s'" % fact_cache.plugin_vars['cache_dir'])

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:26:39.323357
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule().__class__.__base__.__name__ == "AnsibleCacheModule"

# Generated at 2022-06-23 09:26:40.581004
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-23 09:26:47.468746
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Test constructor.
    """
    cache_plugin = CacheModule()
    assert isinstance(cache_plugin, CacheModule)
    assert isinstance(cache_plugin, BaseFileCacheModule)
    assert hasattr(cache_plugin, "_load")
    assert hasattr(cache_plugin, "_dump")


# Generated at 2022-06-23 09:26:49.083878
# Unit test for constructor of class CacheModule
def test_CacheModule():
    a=CacheModule()
    assert a.CACHE_PLUGIN_DATA_DIR == 'caches'

# Generated at 2022-06-23 09:26:52.392878
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule({'_uri': '/tmp'}), CacheModule)

# Generated at 2022-06-23 09:26:57.034762
# Unit test for constructor of class CacheModule
def test_CacheModule():
    conf = {
        '_prefix': 'foobar',
        '_timeout': 1234,
    }
    m = CacheModule(**conf)
    assert m.plugin_name == 'jsonfile'
    assert m.timeout == 1234
    assert m.plugin_prefix == 'foobar'

# Generated at 2022-06-23 09:27:00.030298
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict({
        "_uri": "https://example.com",
        "_prefix": "test_prefix",
        "_timeout": 100
    }))

# Generated at 2022-06-23 09:27:01.900658
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-23 09:27:19.324615
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # CacheModule contructor have the right behavior
    cm = CacheModule()
    assert cm._timeout == 86400
    assert cm._prefix == 'ansible_facts_'
    assert cm._load == cm._load_default
    assert cm._dump == cm._dump_default

    # CacheModule contructor have the right behavior
    cm = CacheModule(timeout=1, prefix='prefix')
    assert cm._timeout == 1
    assert cm._prefix == 'prefix'
    assert cm._load == cm._load_default
    assert cm._dump == cm._dump_default

    # CacheModule contructor have the right behavior
    cm = CacheModule(timeout=1, prefix='prefix', _load = '_load', _dump = '_dump')
    assert cm._timeout == 1
    assert cm._prefix == 'prefix'
    assert cm._

# Generated at 2022-06-23 09:27:23.255449
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None
    assert cache_module._ext == ".json"
    assert cache_module._makedirs == True
    assert cache_module._contains_dots == True
    assert cache_module._illegal_characters == None
    assert cache_module._replace_illegal_characters == None

# Generated at 2022-06-23 09:27:25.842990
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = CacheModule()
    assert isinstance(CacheModule, object)

# Generated at 2022-06-23 09:27:28.349599
# Unit test for constructor of class CacheModule
def test_CacheModule():

    test = CacheModule()

    assert test
    assert isinstance(test, CacheModule)


# Generated at 2022-06-23 09:27:36.312177
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    from ansible.plugins.cache import CacheModule

    # Create a temporary file
    tempFile = tempfile.NamedTemporaryFile(mode='w+t', suffix='.json', prefix='ansible_fact_caching_', dir='.', delete=False)
    assert tempFile is not None
    tempFile.close()

    testCache = CacheModule(tempFile.name)
    assert testCache is not None

    # Cleanup
    import os
    os.remove(tempFile.name)

# Generated at 2022-06-23 09:27:37.508068
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': '/tmp/foo', '_prefix': 'bar'})

# Generated at 2022-06-23 09:27:39.009532
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_cache = CacheModule({'_uri': './test_cache'})
    assert test_cache is not None

# Generated at 2022-06-23 09:27:40.181556
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule() is not None

# Generated at 2022-06-23 09:27:42.308404
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print('Testing CacheModule #############')
    base_file_cache_module = BaseFileCacheModule()
    cache_module = CacheModule()
    assert isinstance(cache_module, BaseFileCacheModule)

# Generated at 2022-06-23 09:27:43.970576
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__name__ == 'CacheModule'

# Generated at 2022-06-23 09:27:48.110349
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)
    assert cache.keys() == []
    assert cache.get('key') is None

# Generated at 2022-06-23 09:27:52.021890
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_path = "/tmp/ansible_cache"
    prefix = 'test_'
    timeout = 3600
    ansible = CacheModule(cache_path, prefix, timeout)

    assert ansible.is_valid()

    assert ansible._path == cache_path
    assert ansible._prefix == prefix
    assert ansible._timeout == timeout

# Generated at 2022-06-23 09:27:59.579127
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test class constructor initialization
    print("Testing constructor initialization")
    cache = CacheModule(None)

    # Test _load
    print("Testing _load")
    cache._load()

    # Test _dump
    print("Testing _dump")
    cache._dump()

    # Test get
    print("Testing get")
    cache.get()

    # Test set
    print("Testing set")
    cache.set()

    # Test keys
    print("Testing keys")
    cache.keys()

    # Test contains
    print("Testing contains")
    cache.contains()

    # Test delete
    print("Testing delete")
    cache.delete()

    # Test flush
    print("Testing flush")
    cache.flush()

    # Test copy
    print("Testing copy")
    cache.copy()

    # Test get_timeout
   

# Generated at 2022-06-23 09:28:01.567310
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({}, {}) is not None

# Generated at 2022-06-23 09:28:13.192359
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from shutil import rmtree
    from tempfile import mkdtemp
    t = mkdtemp()
    plugin = CacheModule({'_uri': t})
    plugin.flush()
    assert(not plugin._exists(t, "test_mytag"))
    assert(plugin._is_expired(t, "test_mytag"))
    plugin._set(t, "test_mytag", "test_value")
    assert(plugin._exists(t, "test_mytag"))
    assert(not plugin._is_expired(t, "test_mytag"))
    assert(plugin._load_plugin_data(t, "test_mytag") == "test_value")
    rmtree(t)

# Generated at 2022-06-23 09:28:14.503841
# Unit test for constructor of class CacheModule
def test_CacheModule():
    json_cache = CacheModule()

    assert True

# Generated at 2022-06-23 09:28:16.995135
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:28:19.183095
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    # c = CacheModule(timeout=86400)

# Generated at 2022-06-23 09:28:20.511022
# Unit test for constructor of class CacheModule
def test_CacheModule():
    result = CacheModule()
    assert isinstance(result, CacheModule)

# Generated at 2022-06-23 09:28:20.994513
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print(CacheModule)

# Generated at 2022-06-23 09:28:21.651911
# Unit test for constructor of class CacheModule
def test_CacheModule():
	assert CacheModule()

# Generated at 2022-06-23 09:28:28.022387
# Unit test for constructor of class CacheModule
def test_CacheModule():
    class Options(object):
        def __init__(self, uri, prefix=None, timeout=None):
            self._uri = uri
            self._prefix = prefix
            self._timeout = timeout
    options = Options('tmp', 'prefix', 86400)
    cache = CacheModule(options)
    assert cache.path == 'tmp'

# Generated at 2022-06-23 09:28:34.116007
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create a CacheModule object
    obj = CacheModule()

    # Check the required parameters for the object
    for param in ('_uri', '_prefix', '_timeout'):
        assert hasattr(obj, param)

    # Check if the object can be used to load data from a file
    assert hasattr(obj, '_load')

    # Check if the object can be used to dump data from a file
    assert hasattr(obj, '_dump')

# Generated at 2022-06-23 09:28:36.983119
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Unit test for constructor of class CacheModule
    """
    assert CacheModule._cache_prefix == None
    assert CacheModule._cache_timeout == 86400

# Generated at 2022-06-23 09:28:45.783485
# Unit test for constructor of class CacheModule
def test_CacheModule():
    host = '127.0.0.1'
    timeout = 86400
    plugin_name = 'jsonfile'
    uri = '~/.ansible/cache'
    prefix = 'ansible_facts'
    env = dict(
        ANSIBLE_CACHE_PLUGIN_CONNECTION=uri,
        ANSIBLE_CACHE_PLUGIN_TIMEOUT=timeout
    )
    cm = CacheModule(plugin_name, host, timeout, uri, prefix)
    assert cm.env == env

# Generated at 2022-06-23 09:28:48.478773
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._timeout == 86400
    assert CacheModule._uri == '~/.ansible/cache'
    assert CacheModule._prefix == 'ansible-factcache'

# Generated at 2022-06-23 09:28:49.413082
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass


# Generated at 2022-06-23 09:28:51.987082
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("Testing CacheModule constructor.")
    print("Test passed.")

# Generated at 2022-06-23 09:28:54.683601
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache=CacheModule()
    assert cache.HAS_JSON is True
    assert cache.HAS_YAML is False

# Generated at 2022-06-23 09:28:56.683309
# Unit test for constructor of class CacheModule
def test_CacheModule():
  cm = CacheModule(module_name='jsonfile')
  assert isinstance(cm, CacheModule)

# Generated at 2022-06-23 09:29:01.383663
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mod = CacheModule('/tmp/ansible_test', 'prefix-')
    assert mod.file_extension == '.json'
    assert mod.file_prefix == 'prefix-'

# Generated at 2022-06-23 09:29:11.077546
# Unit test for constructor of class CacheModule
def test_CacheModule():
    options = {"_uri": 'C:\\Users\\ansible\\Ansible\\ansible-temp\\ansible-tmp-1458204545.8-80895532240901\\ansible_fact_caching',
               "_prefix": 'ansible_facts'}
    data = {"test_key":"test_value"}
    cacheModule = CacheModule(options)
    cacheModule._dump(data, options["_uri"])
    cacheModule._load('C:\\Users\\ansible\\Ansible\\ansible-temp\\ansible-tmp-1458204545.8-80895532240901\\ansible_fact_caching')

# Generated at 2022-06-23 09:29:12.722867
# Unit test for constructor of class CacheModule
def test_CacheModule():

    test_module = CacheModule()
    assert test_module.cache_plugin_name == 'jsonfile'

# Generated at 2022-06-23 09:29:22.198335
# Unit test for constructor of class CacheModule
def test_CacheModule():
    d1 = {'key1': 'val1', 'key2': {'subkey1': 'subval1'}}
    c1 = CacheModule(d1)
    assert c1.get('key1') == 'val1'
    assert c1.get('key2') == {'subkey1': 'subval1'}
    c1.set('key3', 'value3')
    assert c1.get('key3') == 'value3'
    assert c1.has_key('key3')


# Generated at 2022-06-23 09:29:24.614833
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert isinstance(cache_module, BaseFileCacheModule)

# Generated at 2022-06-23 09:29:26.745510
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.cache_plugin_name == 'jsonfile'

# Generated at 2022-06-23 09:29:29.761490
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert isinstance(module, CacheModule)
    assert hasattr(module, '_load')
    assert hasattr(module, '_dump')

# Generated at 2022-06-23 09:29:32.954139
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._get_cache_subdir() == 'ansible-cache'
    assert plugin._load_cache_file(None) is None
    assert plugin._dump_cache_file(None, None) is None

# Generated at 2022-06-23 09:29:33.971328
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module

# Generated at 2022-06-23 09:29:36.387587
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._init is True
    assert plugin._timeout == 86400
    assert plugin._cache_subdir == 'ansible_fact_cache'

# Generated at 2022-06-23 09:29:47.616628
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Check CacheModule constructor's logic to ensure
    # that the class gets initialized properly.
    cacheModule = CacheModule()

    assert cacheModule._connection == 'jsonfile'
    assert cacheModule._timeout == 86400
    assert cacheModule._prefix == ''
    assert cacheModule._load_cache == CacheModule._load
    assert cacheModule._dump_cache == CacheModule._dump
    assert cacheModule._cache_dir == '/tmp/.ansible/tmp'
    assert cacheModule._valid_characters == 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._:'

# Generated at 2022-06-23 09:29:50.045378
# Unit test for constructor of class CacheModule
def test_CacheModule():
    a = CacheModule({})
    assert getattr(a, '_uri') is not None, 'Failed to construct CacheModule with default values.'

# Generated at 2022-06-23 09:29:58.421880
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_connection = "/tmp/ansible-facts"
    cache_plugin_timeout = 600
    cache_plugin_prefix = "facts"
    module = CacheModule(cache_plugin_connection, cache_plugin_timeout, cache_plugin_prefix)
    # Tests that we have populated the class as expected
    assert module.cache_plugin_connection == cache_plugin_connection
    assert module.cache_plugin_timeout == cache_plugin_timeout
    assert module.cache_plugin_prefix == cache_plugin_prefix
    assert module.cache_plugin_socket_path == ''
    assert module.cache_plugin_lock_path == ''
    assert module.cache_plugin_lock_timeout == ''

    # Test for file path generation in subclass of class CacheModule
    cache_plugin_connection = "/tmp/ansible-facts"
    cache_plugin_timeout

# Generated at 2022-06-23 09:29:58.976036
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-23 09:30:09.392572
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ''' Unit test for the constructor of CacheModule class '''

    # Declare expected values
    expected_name = 'jsonfile'
    expected_args = [
        '_uri',
        '_prefix',
        '_timeout'
    ]

    # Create an instance of CacheModule
    cache_module_jsonfile = CacheModule()

    # Assert that the value of name attribute is as expected
    assert cache_module_jsonfile.name == expected_name

    # Assert that the value of the args attribute is as expected
    for arg_name in expected_args:
        assert arg_name in cache_module_jsonfile.args

# Generated at 2022-06-23 09:30:12.495595
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(parms={'_uri':"~/tmp/",'_timeout':"3600"})
    assert cache._prefix == 'ansible-cacheplugin'
    assert cache._timeout == 3600
    assert cache._connection == "~/tmp/"

# Generated at 2022-06-23 09:30:16.490739
# Unit test for constructor of class CacheModule
def test_CacheModule():
    def test_init():
        cache_module = CacheModule()
        assert cache_module._cache_dir_path == '/var/cache/ansible/facts'
        assert cache_module._timeout == 86400
        assert cache_module._prefix == 'ansible_facts'

# Generated at 2022-06-23 09:30:27.153853
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({
        u'_timeout': 86400,
        u'_prefix': u'ansible-fact',
        u'_uri': u'/home/vagrant/.ansible/tmp/ansible-local/ansible-fact',
        u'_fact_cache': False,
    })
    assert cache._timeout == 86400
    assert cache._prefix == u'ansible-fact'
    assert cache._uri == u'/home/vagrant/.ansible/tmp/ansible-local/ansible-fact'
    assert cache._fact_cache == False
    assert cache._source == 'file'


# Generated at 2022-06-23 09:30:28.381352
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert x

# Generated at 2022-06-23 09:30:30.837544
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test constructor of class CacheModule
    cache = CacheModule()
    assert cache._options['timeout'] == 86400

# Generated at 2022-06-23 09:30:36.543398
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.cache_dir == "~/.ansible/tmp/ansible-fact-cache"
    assert c.timeout == 86400
    assert c.plugin_name == 'jsonfile'
    assert c.file_extension == 'json'
    assert c.cache_prefix == 'ansible_facts'
    assert c.lock_path == '~/.ansible/tmp'
    assert c.lock_timeout == 300
    assert c.lock_sleep == 0

# Generated at 2022-06-23 09:30:37.915676
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    print(cache)

# Generated at 2022-06-23 09:30:39.920615
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.file_extension == '.json'

# Generated at 2022-06-23 09:30:41.268644
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.debug

# Generated at 2022-06-23 09:30:41.830401
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule != None

# Generated at 2022-06-23 09:30:42.906583
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-23 09:30:45.396760
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # pylint: disable=redefined-outer-name
    this_cache = CacheModule()
    assert this_cache._encoding == 'utf-8'

# Generated at 2022-06-23 09:30:55.446005
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    Test construction of this class
    '''
    # empty constructor
    cache = CacheModule()

    # constructor with parameters
    cache = CacheModule(timeout=3, plugin_name='custom-name', plugin_prefix='custom-prefix', plugin_connection='custom-connection', cache_key='my-key')

    # test properties
    assert cache.file_extension == '.json'
    assert cache.cache_key == 'my-key'
    assert cache.plugin_name == 'custom-name'
    assert cache.plugin_prefix == 'custom-prefix'
    assert cache.plugin_connection == 'custom-connection'
    assert cache.timeout == 3

    # test functions
    # CacheModule._load()
    # this function is called from BaseFileCacheModule._load()
    # CacheModule._dump()
    # this function is

# Generated at 2022-06-23 09:30:58.446199
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = '/var/tmp'
    prefix = 'CACHE'
    timeout = 1
    
    try:
        cache = CacheModule(connection, prefix, timeout)
    except Exception as err:
        print (err)
        raise
    assert cache is not None
    assert cache.cache._connection == connection
    assert cache.cache._prefix == prefix
    assert cache.cache._timeout == timeout

# end class CacheModule

# Generated at 2022-06-23 09:30:59.895180
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__name__ == 'CacheModule'

# Generated at 2022-06-23 09:31:00.492274
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:31:08.425921
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # creating an instance of the class
    _fileCacheModule = CacheModule()
    assert(True,_fileCacheModule)
    # validating the return type of constructor by passing the paramerters and accessing the properties
    assert(True,_fileCacheModule.get_options())

# Generated at 2022-06-23 09:31:10.378709
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """

    :return:
    """
    cache_plugin_test = CacheModule()

# Generated at 2022-06-23 09:31:13.030944
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.config == {'_prefix': '', '_timeout': 86400, '_uri': '~/.ansible/cache'}

# Generated at 2022-06-23 09:31:15.093427
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Placeholder for future unit tests
    print ('Test cache module')


if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:31:20.097583
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = {'ansible_facts':{'test':'A'}}
    module = CacheModule('/tmp', 'test1.json')
    module._dump(cache, '/tmp/test1.json')
    out = module._load('/tmp/test1.json')
    module.set('test2', cache)
    out = module.get('test2')
    assert(out['ansible_facts']['test'] == 'A')

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:31:27.831388
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule

    tmp_path = '/tmp/ansible.tests.cache.jsonfile.tmp'
    connection = tmp_path
    prefix = 'test'
    timeout = 86400

    cache = CacheModule()
    cache.set_options(direct=dict(
        _uri=connection,
        _prefix=prefix,
        _timeout=timeout
    ))

    assert cache._connection == tmp_path
    assert cache._prefix == prefix
    assert cache._timeout == timeout

# Generated at 2022-06-23 09:31:29.682160
# Unit test for constructor of class CacheModule
def test_CacheModule():
    json_file = CacheModule()
    assert json_file.__class__.__name__ == 'CacheModule'

# Generated at 2022-06-23 09:31:31.011853
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(None)._prefix == 'ansible_facts'

# Generated at 2022-06-23 09:31:37.227833
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test case 1:
    # Test if the constructor correctly creates a CacheModule instance
    try:
        cache = CacheModule('/tmp')
        assert hasattr(cache, '_load')
        assert hasattr(cache, '_dump')
        cache.set('testkey', 'testvalue')
        getvalue = cache.get('testkey')
        assert getvalue == 'testvalue'
        getvalue = cache.get('testkey1')
        assert getvalue == {}
    except Exception as e:
        print(e)
        assert False
    # Test case 2:
    # Test if the constructor throws an exception when passed with an invalid caching location
    try:
        cache = CacheModule('')
        assert False
    except Exception as e:
        assert isinstance(e, AssertionError)

# Generated at 2022-06-23 09:31:48.316002
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from collections import namedtuple
    from ansible.plugins.loader import cache_loader

    FakeOptions = namedtuple('FakeOptions', ('fact_caching', 'fact_caching_timeout', 'fact_caching_connection', 'fact_caching_plugin'))

    opts = FakeOptions('jsonfile', '1', 'C:\\ansible', 'jsonfile')
    cache_loader.find_plugin('jsonfile', 'cache')
    cm = cache_loader.get('jsonfile', 'cache')(opts)

    assert cm.get_basedir()     == 'C:\\ansible'
    assert cm.get_timeout()     == 1
    assert cm.get_plugin_name() == 'jsonfile'
    assert cm.get_plugin_type() == 'cache'

# Generated at 2022-06-23 09:31:51.919532
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert(cache.connection == '$HOME/.ansible/tmp/ansible-local')
    assert(cache.prefix == 'ansible-local')

# Generated at 2022-06-23 09:31:57.060492
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module_dir = ""
    config = dict()
    config["timeout"] = 10
    plugin = CacheModule(module_dir, config)
    assert plugin.timeout == config["timeout"]
    assert plugin.cache_dir == module_dir
    assert isinstance(plugin.last_write, dict)


# Generated at 2022-06-23 09:32:05.774096
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Variables for constructing CacheModule object
    _cache_plugin_connection = 'test_data/test'
    _cache_plugin_prefix = 'test'
    _cache_plugin_timeout = 86400
    _cache_plugin_expires = 86400
    _cache_plugin_max_file_size = 3145728
    _connection = None

    # Test case 1: Constructor test with valid data

# Generated at 2022-06-23 09:32:07.398689
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert BaseFileCacheModule("abc") is None

# Generated at 2022-06-23 09:32:13.801730
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_mock = CacheModule({})
    assert cache_mock._timeout == 86400
    cache_mock = CacheModule({'_timeout': 'a'})
    assert cache_mock._timeout == 86400
    cache_mock = CacheModule({'_timeout': '86400'})
    assert cache_mock._timeout == 86400
    cache_mock = CacheModule({'_timeout': '12345'})
    assert cache_mock._timeout == 12345

# Generated at 2022-06-23 09:32:22.137249
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create an instance of class CacheModule
    cm = CacheModule()

    # Verify that attributes are not initially set
    assert cm._connection is None
    assert cm._timeout is None

    # Set the connections attribute & verify that it is set correctly
    cm._connection = "test_connection"
    assert cm._connection == "test_connection"

    # Set the timeout attribute & verify that it is set correctly
    cm._timeout = 100
    assert cm._timeout == 100

    # Verify that get method works correctly
    assert not cm.get("test_key")

    # Verify that set method works correctly
    assert cm.set("test_key", "test_value")

    # Verify that keys method works correctly
    assert cm.keys() == ["test_key"]

    # Verify that contains method works correctly
    assert cm.contains("test_key")
   

# Generated at 2022-06-23 09:32:27.245149
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

    # This is what it should be, but is not currently.
    # assert c._prefix == 'ansible'

    assert isinstance(c._timeout, int) and c._timeout > 0
    assert isinstance(c._conn, (str, unicode)) and len(c._conn) > 0

# Generated at 2022-06-23 09:32:37.429702
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    filepath = cache_module._get_file_path("10.10.10.10")
    assert filepath == "/tmp/ansible_fact_caching/10.10.10.10"
    host_key = u"10.10.10.10"
    data = {
        'a': {},
        'b': True,
        'c': ['foo', 1, 2, 3],
        'd': {
            'foo': [1, 2, 3],
            'bar': 'baz',
            'foobar': {
                'foo': 'bar',
                'baz': 'bat',
                'bat': 'foo'
            }
        }
    }
    assert cache_module.set(host_key, data) == True
    # Verify set value in cache


# Generated at 2022-06-23 09:32:39.386779
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-23 09:32:45.509965
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()

    # Create a file
    test_file = open("test_file.json","w") 
    test_file.write("test_file") 
    test_file.close() 
    test_file = open("test_file.json","r")
    # Assign value
    ret = module._load(test_file)

    # Delete file
    import os
    os.remove("test_file.json")

    # Verify that a value was returned
    assert ret == "test_file"

# Generated at 2022-06-23 09:32:49.551967
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert type(cm) == CacheModule

# Generated at 2022-06-23 09:32:52.877500
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert isinstance(m._load, object)
    assert isinstance(m._dump, object)



# Generated at 2022-06-23 09:32:55.215691
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._cache_dir == '/tmp/ansible_fact_cache'
    assert cache_module._prefix == 'ansible_facts'
    assert cache_module._timeout == 86400


# Generated at 2022-06-23 09:33:01.487408
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test that if we try an unsupported version, we get an error
    from ansible.plugins.loader import cache_loader
    from ansible.module_utils.six import string_types
    cache_plugin1 = cache_loader._create_cache_instance("jsonfile", {'timeout': 0}, "ansible.cfg")
    assert isinstance(cache_plugin1.get("key"), dict)
    assert cache_plugin1.get("key") == {}
    assert isinstance(cache_plugin1.set("key", "value"), string_types)
    cache_plugin1.flush()

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:33:04.292305
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # testing the constructor of CacheModule
    # statements to be executed
    assert True

# Generated at 2022-06-23 09:33:06.587280
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None


# Generated at 2022-06-23 09:33:12.740996
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = 'testdir'
    cache_timeout = 1

    cache_plugin_args = dict()
    cache_plugin_args['dir'] = cache_dir
    cache_plugin_args['timeout'] = cache_timeout

    cache_plugin = CacheModule(plugin_options=cache_plugin_args)

    assert cache_plugin._connection['dir'] == cache_dir
    assert cache_plugin._connection['timeout'] == 1

# Generated at 2022-06-23 09:33:13.749917
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})._timeout == 86400

# Generated at 2022-06-23 09:33:15.063827
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:33:27.998349
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Access to protected member _load
    # pylint: disable=W0212
    config = {
        '_uri': 'True',
        '_prefix': True,
        '_timeout': 'True',
    }
    a = CacheModule(config)
    assert not a.cache
    assert not a.filepath
    assert not a.plugin_name

    assert not a._load('True')
    assert not a._dump('True', 'True')
    assert not a.get('True')

    a.put('True', 'True')
    assert a.get('True')

# Generated at 2022-06-23 09:33:29.914485
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    cache.set('test', 'test')
    assert cache.get('test') == 'test'


# Generated at 2022-06-23 09:33:31.161874
# Unit test for constructor of class CacheModule
def test_CacheModule():
    _test = CacheModule()
    assert _test.__class__.__name__ in "CacheModule"

# Generated at 2022-06-23 09:33:32.993687
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._connection == ""
    assert c._timeout == 0

# Generated at 2022-06-23 09:33:34.397097
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load(None) == {}

# Generated at 2022-06-23 09:33:37.802757
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._prefix is None
    assert cache._timeout == 86400
    assert not cache.collection_class.startswith('collections.defaultdict')

# Generated at 2022-06-23 09:33:39.711370
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-23 09:33:42.484596
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    This is just a basic test to make sure that nothing blows up
    """
    assert CacheModule == type(CacheModule({}))