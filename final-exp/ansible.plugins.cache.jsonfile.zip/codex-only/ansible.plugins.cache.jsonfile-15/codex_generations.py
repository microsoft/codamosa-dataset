

# Generated at 2022-06-23 09:23:43.959482
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._timeout == '86400'
    assert c._connection is None
    assert c._prefix == 'ansible-facts'
    assert c._cache_files_dir is None



# Generated at 2022-06-23 09:23:47.306869
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_path(module=None, module_path=None) == __file__

# Generated at 2022-06-23 09:23:47.944960
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-23 09:23:50.788437
# Unit test for constructor of class CacheModule
def test_CacheModule():
    host_cache_path = 'path_for_test'
    cache_module = CacheModule(host_cache_path)

    assert cache_module.cache_path == host_cache_path

# Generated at 2022-06-23 09:23:57.328704
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    assert(cache.get_basedir() == '~/.ansible/cache' or
           cache.get_basedir() == '/root/.ansible/cache')
    assert(cache.get_timeout() == 86400)

    cache = CacheModule(basedir='/tmp/ansible/cache', timeout=10)

    assert(cache.get_basedir() == '/tmp/ansible/cache')
    assert(cache.get_timeout() == 10)

# Generated at 2022-06-23 09:23:58.193615
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-23 09:23:58.710606
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-23 09:24:01.710478
# Unit test for constructor of class CacheModule
def test_CacheModule():
    result = CacheModule()

    # encoder should be AnsibleJSONEncoder
    assert isinstance(result._encoder, AnsibleJSONEncoder)
    # decoder should be AnsibleJSONDecoder
    assert isinstance(result._decoder, AnsibleJSONDecoder)

# Generated at 2022-06-23 09:24:05.839296
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._load('../data/') == ()
    assert CacheModule._dump('../data/') == ()

# Generated at 2022-06-23 09:24:07.675094
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = ansible.plugins.cache._load_cache_plugin('jsonfile')
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-23 09:24:19.338512
# Unit test for constructor of class CacheModule
def test_CacheModule():

    module = CacheModule()

    # Base constructor tests
    assert not module.contains('localhost.localdomain')
    assert not module.has_expired('localhost.localdomain')
    assert module.get('localhost.localdomain') is None
    module.set('localhost.localdomain', {u'a': 1})
    assert module.contains('localhost.localdomain')
    assert not module.has_expired('localhost.localdomain')
    assert module.get('localhost.localdomain') == {u'a': 1}
    module.remove('localhost.localdomain')
    assert not module.contains('localhost.localdomain')
    assert not module.has_expired('localhost.localdomain')

# Generated at 2022-06-23 09:24:19.756745
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-23 09:24:31.220509
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()

    assert plugin.cache_type is not None, 'Error: "cache_type" is None'
    assert plugin.cache_type == 'jsonfile', 'Error: "cache_type" is not "jsonfile"'

    assert plugin.cache_prefix is not None, 'Error: "cache_prefix" is None'

    assert plugin.cache_timeout is not None, 'Error: "cache_timeout" is None'
    assert type(plugin.cache_timeout) == int, 'Error: "cache_timeout" is not an integer'

    assert plugin.cache_connection is not None, 'Error: "cache_connection" is None'
    assert type(plugin.cache_connection) == str, 'Error: "cache_connection" is not a string'


# Generated at 2022-06-23 09:24:35.030458
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert isinstance(cache_plugin,BaseFileCacheModule) is True
    assert cache_plugin._timeout == 86400


# Generated at 2022-06-23 09:24:42.778638
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule

    ANSIBLE_CACHE_PLUGIN_CONNECTION = 'some/path'
    ANSIBLE_CACHE_PLUGIN_PREFIX = 'other'
    ANSIBLE_CACHE_PLUGIN_TIMEOUT = 100


# Generated at 2022-06-23 09:24:43.719376
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule is not None

# Generated at 2022-06-23 09:24:44.685766
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module

# Generated at 2022-06-23 09:24:50.975676
# Unit test for constructor of class CacheModule
def test_CacheModule():
  setup_path = './test/unit/lib/ansible/plugins/cache/jsonfile/setup.json'
  cachedir = './test/unit/lib/ansible/plugins/cache/jsonfile'
  fact_name = 'setup'
  data = {
    'host': 'hostname'
  }
  test = CacheModule(setup_path, cachedir, fact_name)
  test._dump(data, './test/unit/lib/ansible/plugins/cache/jsonfile/hostname.json')
  assert test.get() == data



# Generated at 2022-06-23 09:24:54.339235
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.plugin == 'jsonfile'
    assert cache.timeout == 86400

# Generated at 2022-06-23 09:25:02.544546
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Given
    connection_plugin = "jsonfile.json"
    plugin_timeout = "900"
    plugin_prefix = "cache_"
    plugin_connection = "~/test/result"
    plugin_name = 'jsonfile'
    plugin_options = {'_connection': plugin_connection, '_prefix': plugin_prefix, '_timeout': plugin_timeout}

    # When
    obj = CacheModule(connection_plugin, plugin_options)

    # Then
    assert obj.plugin_timeout == plugin_timeout
    assert obj.plugin_prefix == plugin_prefix
    assert obj.plugin_name == plugin_name
    assert obj.plugin_connection == plugin_connection

# Generated at 2022-06-23 09:25:03.908656
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_prefix == 'ansible_facts'

# Generated at 2022-06-23 09:25:07.406875
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Constructor of class CacheModule
    """
    # Create a cachemodule object
    cachemodule = CacheModule()
    assert cachemodule



# Generated at 2022-06-23 09:25:10.404836
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.get_timeout() == 86400
    assert cm.get_connection() is None
    cm.set_connection("/tmp")
    assert cm.get_connection() == "/tmp"

# Generated at 2022-06-23 09:25:14.662631
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachePlugin = CacheModule({'_uri': './test'})
    assert(cachePlugin is not None)

# Generated at 2022-06-23 09:25:18.097831
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filecache = CacheModule()
    assert filecache.timeout == 86400
    filecache = CacheModule(timeout=1000)
    assert filecache.timeout == 1000

# Generated at 2022-06-23 09:25:25.652887
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = '/tmp/jsonfile_tests'
    cache_dir = '%s/.ansible/tmp' % path
    connection = '%s/ansible-plugin-cache' % cache_dir
    timeout = 86400

    # Create module
    module = CacheModule({ '_uri' : connection, '_timeout' : timeout })

    # Validate Module
    assert module, "Module not created"
    assert module._cache_dir == cache_dir, "Cache dir doesn't match"
    assert module._connection == connection, "Connection doesn't match"
    assert module._timeout == timeout, "Timeout doesn't match"

# Generated at 2022-06-23 09:25:26.662658
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert type(CacheModule()) == CacheModule

# Generated at 2022-06-23 09:25:28.298839
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(uri='/tmp', _prefix='foobar_') is not None

# Generated at 2022-06-23 09:25:30.298212
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': '/tmp/ansible_cache'})
    assert cache is not None


# Generated at 2022-06-23 09:25:35.420571
# Unit test for constructor of class CacheModule
def test_CacheModule():  # pylint: disable=R0915
    """Test constructor"""
    module = CacheModule()
    assert module._connection is None
    assert module._timeout == 86400
    assert module._prefix is None
    assert module._load_cache  # pylint: disable=W0212
    assert module._dump_cache  # pylint: disable=W0212
    assert module._URI  # pylint: disable=W0212
    assert module._remove_file  # pylint: disable=W0212

# Generated at 2022-06-23 09:25:36.337191
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-23 09:25:40.820341
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacher = CacheModule()
    cacher.set_options(plugin_args={'_uri': 'test_uri'})
    assert cacher._get_cache_basedir() == 'test_uri'

# Generated at 2022-06-23 09:25:42.359377
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(CacheModule() is not None)

# Generated at 2022-06-23 09:25:44.139187
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test empty __init__
    obj = CacheModule()
    assert isinstance(obj, CacheModule)

# Generated at 2022-06-23 09:25:50.429731
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(namespace='test', purge_cache=False, host='localhost')
    cache_dir = cache._connection._uri + '/ansible_test'
    assert cache._connection._uri == '/tmp'
    assert cache._connection._prefix == 'ansible'
    assert cache._connection._timeout == 86400
    assert cache._cache_dir == cache_dir

# Generated at 2022-06-23 09:25:51.352020
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()


# Generated at 2022-06-23 09:25:54.532054
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.CACHE_PLUGIN_PREFIX == 'ansible_json'
    assert CacheModule.CACHE_PLUGIN_TIMEOUT == 86400
    assert CacheModule.CACHE_PLUGIN_CONNECTION == 'cache'

# Generated at 2022-06-23 09:26:06.833532
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # create and get the current directory
    cache = CacheModule()
    import os
    current_dir = os.getcwd()

    # Check if the path is correct
    if cache._plugin_path != current_dir + '/.cache/ansible/':
        raise Exception("path not correctly initialised")

    # Check if the default timeout is correct
    if cache._plugin_timeout != 86400:
        raise Exception("timeout not correctly initialised")

    # Check if the prefix is correct
    if cache._plugin_prefix != 'ansible_facts':
        raise Exception("prefix not correctly initialised")

    # Check if the path_cache is correct
    if cache._plugin_path_cache != current_dir + '/.cache/ansible/ansible_facts_':
        raise Exception("Path_cache isn't correct")

# Generated at 2022-06-23 09:26:07.460167
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()

# Generated at 2022-06-23 09:26:08.912024
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-23 09:26:19.028190
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile

    # Create a temporary directory to act as the CWD
    cwd = tempfile.mkdtemp()

    # Create a temporary environment and make sure it is empty
    env = os.environ.copy()
    for k in env.keys():
        if k.startswith("ANSIBLE_CACHE_PLUGIN"):
            del env[k]

    # Instantiate the plugin
    cm = CacheModule(env=env, task_vars={}, wrap_async=None, play_context=None)

    # Test if the cache directory has been created
    path = cm.get_cache_filepath(cwd, 'testhost')
    path = path.rstrip(os.sep)
    assert path.endswith('testhost')

# Generated at 2022-06-23 09:26:22.861340
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = 'test-dir'
    timeout = 3600
    prefix = 'test-prefix'

    test_obj = CacheModule({'_uri': cache_dir, '_timeout': timeout, '_prefix': prefix})

    assert 'test-dir' == test_obj._cache_dir
    assert '3600' == test_obj._plugin_timeout
    assert 'test-prefix' == test_obj._plugin_prefix

# Generated at 2022-06-23 09:26:25.101722
# Unit test for constructor of class CacheModule
def test_CacheModule():
  obj = CacheModule()
  assert obj.get_prefix() == 'ansible_'

# Generated at 2022-06-23 09:26:28.341908
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule(task_vars={})
    assert os.path.isdir(plugin._connection._options['_uri'])
    assert plugin._connection._prefix == 'ansible_cache'

# Generated at 2022-06-23 09:26:30.576744
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule(connection=None)
    assert cm.plugin_name == 'jsonfile'

# Generated at 2022-06-23 09:26:34.865723
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    This function unit tests the constructor of class CacheModule
    """
    print('Now testing the constructor of class cacheModule')

    temp_uri = ''
    temp_prefix = ''
    temp_timeout = 86400

    cm = CacheModule(temp_uri, temp_prefix, temp_timeout)

# Generated at 2022-06-23 09:26:37.072589
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get('test') is None

    # assert cache_module.get('test') is None
    # assert cache_module.get('test') != None

# Generated at 2022-06-23 09:26:37.854202
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:26:38.450737
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-23 09:26:42.371055
# Unit test for constructor of class CacheModule
def test_CacheModule():
  cache = CacheModule()
  assert isinstance(cache, BaseFileCacheModule)
  assert cache._load.__name__ == "_load"
  assert cache._load.__doc__ == "Load data from cache"
  assert cache._dump.__name__ == "_dump"
  assert cache._dump.__doc__ == "Write data to cache"

# Generated at 2022-06-23 09:26:47.768707
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create a CacheModule object
    cache_module = CacheModule()
    # Make sure prefix is empty string
    assert cache_module._prefix == ''
    # Make sure timeout is 86400
    assert cache_module._timeout == 86400



# Generated at 2022-06-23 09:26:53.377694
# Unit test for constructor of class CacheModule
def test_CacheModule():
    store = '/tmp/ansible-test'
    prefix = 'facts'
    timeout = 3600
    cache = CacheModule(store, prefix, timeout)
    assert cache.store == store
    assert cache.prefix == prefix
    assert cache.timeout == timeout


# Generated at 2022-06-23 09:26:55.061718
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule(None)
    del cm
    return 0

# Generated at 2022-06-23 09:26:59.203154
# Unit test for constructor of class CacheModule
def test_CacheModule():
    fc = CacheModule()
    assert fc.file_extension == 'json'

# Generated at 2022-06-23 09:27:00.215819
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.cache._timeout == 86400

# Generated at 2022-06-23 09:27:10.265623
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = 'foo'
    prefix = 'bar'
    timeout = '86400'
    config = {
        '_uri': connection,
        '_prefix': prefix,
        '_timeout': timeout
    }
    cache = CacheModule(config)
    assert cache._basedir == connection
    assert cache._prefix == prefix
    assert cache._timeout == 86400

# Generated at 2022-06-23 09:27:18.396234
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with valid options
    valid_options = {
        '_uri': 'tmp',
        '_prefix': 'localhost',
        '_timeout': 43200,
    }

    try:
        CacheModule(valid_options)
    except Exception:
        assert(False == True)

    # Test with invalid options
    invalid_options = {
        '_uri': 'tmp'
    }

    try:
        CacheModule(invalid_options)
    except Exception:
        assert(True == True)

# Generated at 2022-06-23 09:27:21.813141
# Unit test for constructor of class CacheModule
def test_CacheModule():
    fact_caching = CacheModule(task_vars=None, **{u'_uri': u'/home/vagrant/ansible-server', u'_prefix': u'fact_cache'})
    assert fact_caching._timeout == 86400

# Generated at 2022-06-23 09:27:26.164195
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._load('./testfile') is not None
    assert cm._dump(2,'./testfile') is not None

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:27:27.515142
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(None), CacheModule)

# Generated at 2022-06-23 09:27:29.541644
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None, 'Failed to create an instance of CacheModule'

# Generated at 2022-06-23 09:27:32.815941
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.__class__.__name__ == 'CacheModule'
    assert type(cm.get_timeout()) is int
    assert type(cm.get_connection()) is str
    assert type(cm.get_prefix()) is str

# Generated at 2022-06-23 09:27:37.737175
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with all required parameters
    jsonfile_cache_module = CacheModule({'_uri':'/tmp/ansible_cache'})
    # Test without all required parameters
    jsonfile_cache_module = CacheModule({'_uri':'ansible_cache'})

# Generated at 2022-06-23 09:27:39.151539
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Unit test construction of class AnsibleJSONEncoder

# Generated at 2022-06-23 09:27:41.548957
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module
    assert module._connection_info == {}
    assert module._timeout == 86400
    assert module._prefix == ''

# Generated at 2022-06-23 09:27:42.350016
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-23 09:27:48.023402
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert str(obj.__class__) == "<class 'ansible.plugins.cache.jsonfile.CacheModule'>"
    assert str(obj.get_cache_connection()).find('<ansible.plugins.cache.jsonfile.CacheModule object at') == 0


# Generated at 2022-06-23 09:27:51.863473
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # This is actually an empty test, but it'll do for now.
    # It does verify that the class is importable, and initializable.
    cm = CacheModule()
    assert cm is not None
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-23 09:27:54.560257
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        from ansible.plugins.cache.jsonfile import CacheModule
        cache = CacheModule()
        return cache
    except ImportError as e:
        return "Unable to load CacheModule {}".format(e)

# Generated at 2022-06-23 09:27:55.129535
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()

# Generated at 2022-06-23 09:27:56.905492
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(load_plugin_args=dict(plugin_args=dict(_uri='/path/')))
    assert cache.root is '/path'

# Generated at 2022-06-23 09:27:58.320962
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule()

# Generated at 2022-06-23 09:28:02.329545
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert isinstance(cache_plugin._enc, AnsibleJSONEncoder)
    assert isinstance(cache_plugin._dec, AnsibleJSONDecoder)

# Generated at 2022-06-23 09:28:06.838695
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = '/tmp'

    test_obj = CacheModule(cache_dir)
    assert(type(cache_dir) == str)
    assert(type(test_obj) == CacheModule)


# Generated at 2022-06-23 09:28:07.990801
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({}, "/dev/null")
    assert cache

# Generated at 2022-06-23 09:28:10.211618
# Unit test for constructor of class CacheModule
def test_CacheModule():
    json_file_cache_module = CacheModule()
    assert json_file_cache_module._load
    assert json_file_cache_module._dump

# Generated at 2022-06-23 09:28:15.081529
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # create a CacheModule instance and
    # verify that the class name and version
    # is set correctly
    cache_module = CacheModule()
    assert cache_module.__class__.__name__ == 'CacheModule'
    assert cache_module.CACHE_VERSION == 1

# Generated at 2022-06-23 09:28:15.813408
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

# Generated at 2022-06-23 09:28:19.730746
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ## instantiate an object of class CacheModule
    x = CacheModule()
    ## check if x is an object of class CacheModule
    assert isinstance(x, CacheModule)

# Generated at 2022-06-23 09:28:24.268223
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Arrange
    args = {
        'plugin': 'jsonfile',
        '_prefix': 'test',
        '_uri': '.'
    }

    # Act
    cm = CacheModule(**args)

    # Assert
    assert isinstance(cm, CacheModule)
    assert cm._uri == '.'
    assert cm._prefix == 'test'

# Generated at 2022-06-23 09:28:29.033632
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()

    assert plugin._options['_timeout'] == 86400
    assert plugin._options['_prefix'] == 'ansible_'
    assert plugin._options['_uri'] == '~/.ansible/tmp'

# Generated at 2022-06-23 09:28:30.535590
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()

    assert None != cache_plugin

# Generated at 2022-06-23 09:28:31.208807
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheObj = CacheModule()
    assert isinstance(cacheObj, CacheModule)

# Generated at 2022-06-23 09:28:32.630658
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-23 09:28:36.071362
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

    assert c is not None
    assert c.plugin_name == "jsonfile"
    assert c._timeout == 86400
    assert c._prefix == "ansible_fact_cache"
    assert c._connection == "/tmp/ansible_fact_cache"

# Generated at 2022-06-23 09:28:38.508235
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(task_vars={})
    assert cache_module._connection is None
    assert cache_module._timeout == 86400
    assert cache_module._prefix == ''
    assert cache_module._cache_files_dir is None

# Generated at 2022-06-23 09:28:39.601411
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert repr(CacheModule())

# Generated at 2022-06-23 09:28:42.439570
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()

    assert module._load("testfile") is not False
    assert module._dump("test1", "test1.txt") is not False

# Generated at 2022-06-23 09:28:46.320121
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule('')
    assert cache_module._timeout == 86400
    assert cache_module._prefix == ''
    assert cache_module._load([]) == 'not implemented'
    assert cache_module._dump([]) == 'not implemented'

# Generated at 2022-06-23 09:28:48.525719
# Unit test for constructor of class CacheModule
def test_CacheModule():
    class C(object):
        pass
    c = C()
    c.get_option = lambda x: ""
    CacheModule(c)

# Generated at 2022-06-23 09:28:50.012278
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()._plugin_name is not None

# Generated at 2022-06-23 09:28:52.828764
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test for constructor of class CacheModule
    cache_module = CacheModule()

# Generated at 2022-06-23 09:28:58.795470
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import CacheModule
    from ansible.plugins.cache.jsonfile import CacheModule as JsonFileCache
    cache_loader = CacheModule()
    jsonfile_loader = JsonFileCache()
    assert isinstance(cache_loader, CacheModule)
    assert isinstance(jsonfile_loader, JsonFileCache)
    assert issubclass(JsonFileCache, CacheModule)


# Generated at 2022-06-23 09:28:59.854713
# Unit test for constructor of class CacheModule
def test_CacheModule():
    #  ClassCacheModule constructor
    assert CacheModule()

# Generated at 2022-06-23 09:29:03.302668
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    cache = CacheModule()
    assert cache

# Generated at 2022-06-23 09:29:04.981415
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.file_extension == '.json'

# Generated at 2022-06-23 09:29:05.768989
# Unit test for constructor of class CacheModule
def test_CacheModule():
	assert CacheModule()

# Generated at 2022-06-23 09:29:10.619155
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = 'path/to/dir'
    cache_timeout = 3600
    uri = 'jsonfile://%s?timeout=%d' % (cache_dir, cache_timeout)
    cache_plugin = CacheModule(uri)
    assert cache_plugin._directory == cache_dir
    assert cache_plugin._timeout == cache_timeout

# Generated at 2022-06-23 09:29:11.487725
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module

# Generated at 2022-06-23 09:29:14.266612
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule({'_uri': 'foo'})
    assert m._connection == 'foo'

# Generated at 2022-06-23 09:29:23.850552
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    tmp = tempfile.NamedTemporaryFile(delete=False)
    tmp.write(json.dumps(dict(), cls=AnsibleJSONEncoder, sort_keys=True, indent=4))
    tmp.close()

    cm = CacheModule()
    cm.set_options(tmp.name)
    cm.flush()
    assert cm.get('test') is None
    cm.set('test', 'value')
    assert cm.get('test') == 'value'
    cm.flush()
    assert cm.get('test') is None

# Generated at 2022-06-23 09:29:30.758174
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_configuration = {'_uri': 'file:///tmp/ansible-cached', '_prefix': 'ansible_facts', '_timeout': 86400}
    module = CacheModule()
    module._load_config(cache_plugin_configuration)
    assert module._prefix == 'ansible_facts'
    assert module._get_cache_dir() == '/tmp/ansible-cached'

# Generated at 2022-06-23 09:29:33.175471
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, BaseFileCacheModule)
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-23 09:29:35.645441
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Unit test for constructor of class CacheModule
    """
    try:
        CacheModule()
    except Exception as e:
        print (e)

# Generated at 2022-06-23 09:29:41.982161
# Unit test for constructor of class CacheModule
def test_CacheModule():
    q = CacheModule()
    assert q._option_prefix == 'ANSIBLE_CACHE_PLUGIN_'
    assert q._cache_subdir == 'ansible'

# Generated at 2022-06-23 09:29:44.272753
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.valid()  # pylint: disable=protected-access

# Generated at 2022-06-23 09:29:45.707634
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert(module)


# Generated at 2022-06-23 09:29:48.053941
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    assert type(cache)==CacheModule
    assert cache._uri=='~/.ansible/tmp'

# Generated at 2022-06-23 09:29:49.232261
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert callable(CacheModule)

# Generated at 2022-06-23 09:29:50.592705
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'fake_path'})

# Generated at 2022-06-23 09:29:53.076625
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    __salt__ = {}
    jc = CacheModule(__salt__)
    assert isinstance(jc, CacheModule)

# Generated at 2022-06-23 09:29:56.198765
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("Testing CacheModule")
    assert True


# Generated at 2022-06-23 09:29:57.726617
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module is not None

# Generated at 2022-06-23 09:29:59.192807
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create a CacheModule object
    x = CacheModule()
    assert x.file_extension == 'json'
    assert x.plugin_name == 'jsonfile'

# Generated at 2022-06-23 09:30:02.572150
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(None)
    assert cache._timeout == 86400
    assert cache._prefix is None

# Generated at 2022-06-23 09:30:06.916536
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()

    # Test for class variables
    assert cache_plugin._cache_dir == '~/.ansible/tmp'
    assert cache_plugin._timeout == 86400
    assert cache_plugin._prefix == 'ansible-cache'

# Generated at 2022-06-23 09:30:08.276289
# Unit test for constructor of class CacheModule
def test_CacheModule():

    tmp = CacheModule()
    assert tmp is not None


# Generated at 2022-06-23 09:30:10.431569
# Unit test for constructor of class CacheModule
def test_CacheModule():
    class_object = CacheModule()
    assert class_object._connection is not None
    assert isinstance(class_object._connection, dict)

# Generated at 2022-06-23 09:30:12.021987
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert x != None

# Generated at 2022-06-23 09:30:13.631594
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = ansible.plugins.cache.jsonfile.CacheModule()

# Generated at 2022-06-23 09:30:15.291499
# Unit test for constructor of class CacheModule
def test_CacheModule():
	a = CacheModule()
	print(a)


# Generated at 2022-06-23 09:30:23.456390
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)
    assert cm.get_option('_uri') == '~/.ansible/tmp'
    assert cm.get_option('_prefix') is None
    assert cm.get_option('_timeout') == 86400
    assert cm.get_extension() == 'tmp'
    assert cm.get_directory_name() == 'facts'

# Generated at 2022-06-23 09:30:29.588614
# Unit test for constructor of class CacheModule
def test_CacheModule():
    global keys
    keys = {
        '_timeout': 86400,
        '_prefix': '',
        '_uri': '/tmp/ansible'
    }

    plugin = CacheModule(keys.copy())

    keys_returned = keys.copy()
    keys_returned['_timeout'] = 86400
    keys_returned['_prefix'] = ''
    keys_returned['_uri'] = '/tmp/ansible'
    assert plugin.get_options() == keys_returned

# Generated at 2022-06-23 09:30:31.395010
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.set_options({
        "_uri": "/some/path"
        }) == None
    assert c.get_options() == {"_uri": "/some/path", "_options": {}}

# Generated at 2022-06-23 09:30:37.969221
# Unit test for constructor of class CacheModule
def test_CacheModule():
    host = '127.0.0.1'
    cache = CacheModule({})
    cache.get(host)
    cache.set(host, {})

    # ansible.parsing.ajson.AnsibleJSONEncoder and json.JSONEncoder are not equals
    assert not json.dumps({}, cls=AnsibleJSONEncoder) == json.dumps({})

# Generated at 2022-06-23 09:30:42.237517
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._connection is None
    assert plugin._timeout == 86400
    assert plugin._prefix == 'ansible_facts'

    plugin = CacheModule(prefix='my-prefix')
    assert plugin._prefix == 'my-prefix'

# Generated at 2022-06-23 09:30:45.188211
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    cache_plugin.set_options({'_uri': '~/'})
    cache_plugin.flush()
    assert cache_plugin is not None

# Generated at 2022-06-23 09:30:45.811031
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-23 09:30:48.095743
# Unit test for constructor of class CacheModule
def test_CacheModule():
    testObj = CacheModule()
    assert testObj is not None

# Generated at 2022-06-23 09:30:49.425645
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache



# Generated at 2022-06-23 09:30:50.045902
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-23 09:30:54.018679
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__doc__ is not None
    assert CacheModule._load.__doc__ is not None
    assert CacheModule._dump.__doc__ is not None

# Generated at 2022-06-23 09:30:59.547774
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = 'test-connection'
    timeout = 1200
    prefix = 'test-'

    cm = CacheModule(plugin_name=__name__, timeout=timeout, connection=connection, plugin_prefix=prefix)
    print('Cache dir: %s' % (cm.cache_dir))
    print('Timeout: %d' % (cm.timeout))
    print('Plugin prefix: %s' % (cm.plugin_prefix))

    assert cm.timeout == timeout
    assert cm.plugin_prefix == prefix


if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-23 09:31:00.918985
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert( isinstance(CacheModule(), BaseFileCacheModule) )

# Generated at 2022-06-23 09:31:04.896543
# Unit test for constructor of class CacheModule
def test_CacheModule():
  cache = CacheModule()
  assert cache is not None
  assert cache.cache == {'_timeout': 86400, '_prefix': None, '_uri': None}

# Generated at 2022-06-23 09:31:14.007562
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pret = {'_timeout': 86400}
    p = CacheModule(pret)
    assert p._timeout == 86400

    pret = {'_uri': '/path/to/cache'}
    p = CacheModule(pret)
    assert p._uri == '/path/to/cache'

    pret = {'_prefix': 'test'}
    p = CacheModule(pret)
    assert p._prefix == 'test'

# Generated at 2022-06-23 09:31:15.317283
# Unit test for constructor of class CacheModule
def test_CacheModule():
    myCacheModule = CacheModule()
    assert myCacheModule != None

# Generated at 2022-06-23 09:31:21.782108
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule(task_vars=dict(ansible_user='root'))
    assert plugin._task_vars['ansible_user'] == 'root'
    assert plugin._timeout == 86400
    assert plugin._uri == '~/.ansible/tmp'
    assert plugin._prefix == 'ansible_'

# Generated at 2022-06-23 09:31:22.694288
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

# Generated at 2022-06-23 09:31:30.620277
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        from ansible.plugins.cache import BaseFileCacheModule
        from ansible.parsing.ajson import AnsibleJSONEncoder, AnsibleJSONDecoder
        import json
        import codecs
        caches = json.load(codecs.open('{0}/../../../lib/ansible/plugins/cache/jsonfile.py'.format(__file__), 'r', encoding='utf-8'), cls=AnsibleJSONDecoder)
        CacheModule()
    except Exception as e:
        print(e)

if __name__ == "__main__":
    test_CacheModule()

# Generated at 2022-06-23 09:31:31.974974
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({})
    assert cache._timeout_default == 86400

# Generated at 2022-06-23 09:31:33.890121
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # pylint: disable=redundant-unittest-assert
    c = CacheModule()
    assert c._load is not BaseFileCacheModule._load
    assert c._dump is not BaseFileCacheModule._dump

# Generated at 2022-06-23 09:31:34.415234
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-23 09:31:35.830080
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._load('/tmp/ansible-cache') is None

# Generated at 2022-06-23 09:31:36.650974
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule({})
    print(module)

# Generated at 2022-06-23 09:31:40.622800
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create a cache_plugin
    test_cache_plugin = CacheModule()

    # Check if _load and _dump have the desired effect.
    test_data = {'answer': 42}
    test_path = '/path/to/test_file'
    test_cache_plugin._dump(test_data, test_path)
    assert test_cache_plugin._load(test_path) == test_data

# Generated at 2022-06-23 09:31:41.439953
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-23 09:31:51.817953
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """ Unit test for constructor of class CacheModule
    """
    fact_caching_prefix = '.ansible_fact_cache'
    opts = {
        'fact_caching_connection': '/tmp/ansible_fact_cache',
        'fact_caching_prefix': fact_caching_prefix,
        'fact_caching_timeout': 86400
    }

    # Create an instance of class CacheModule
    cache = CacheModule(opts)

    # Assertions
    assert cache._connection == '/tmp/ansible_fact_cache'
    assert cache._prefix == fact_caching_prefix
    assert cache._timeout == 86400

# Generated at 2022-06-23 09:31:54.599759
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, '_load')
    assert hasattr(CacheModule, '_dump')

# Generated at 2022-06-23 09:31:55.743690
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule({'_uri': './'})

# Generated at 2022-06-23 09:31:58.742979
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.path == '~/.ansible/tmp'
    cache = CacheModule(path='/tmp')
    assert cache.path == '/tmp'

# Generated at 2022-06-23 09:32:05.430621
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    # Test default values
    assert cache.timeout == 86400
    assert cache.prefix == 'ansible_fact_cache'

    # Verify that None is the default value of addr, type and user
    assert cache.addr is None
    assert cache.type is None
    assert cache.user is None

    # Set value of _uri and verify it
    cache._uri = 'test/test.json'
    assert cache._uri == 'test/test.json'

    # Verify value of _load and _dump methods
    assert cache._load('test/test.json') == '{"test": "test"}'
    cache._dump('{"test": "test"}', 'test/test.json')

# Generated at 2022-06-23 09:32:07.290534
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jc = CacheModule()
    assert jc is not None

# Generated at 2022-06-23 09:32:09.997344
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import CacheModule
    from ansible.plugins.cache.jsonfile import CacheModule as JsonfCacheModule
    assert issubclass(JsonfCacheModule, CacheModule)

# Generated at 2022-06-23 09:32:12.855855
# Unit test for constructor of class CacheModule
def test_CacheModule():  
    cacheModule = CacheModule(connection='/tmp/test')
    assert cacheModule._connection == '/tmp/test'
    assert cacheModule._prefix == 'ansible_fact_cache'
    assert cacheModule._timeout == 86400


# Generated at 2022-06-23 09:32:15.302572
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Instantiates the class CacheModule
    test_obj = CacheModule()
    # The object is of type CacheModule
    assert isinstance(test_obj, CacheModule)

# Generated at 2022-06-23 09:32:16.813326
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filePath = "/home/admins/xyz.json"
    cache = CacheModule(filePath)

# Generated at 2022-06-23 09:32:24.429792
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = 'obj.cache'
    prefix = 'ansible-facts'
    timeout = 7200
    obj = CacheModule(connection=connection, prefix=prefix, timeout=timeout)
    assert obj
    assert obj._connection == 'obj.cache'
    assert obj._prefix == 'ansible-facts'
    assert obj._timeout == 7200

# Generated at 2022-06-23 09:32:26.025509
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None


# Generated at 2022-06-23 09:32:30.957324
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os, tempfile
    cache = CacheModule(tempfile.mkdtemp())
    os.rmdir(tempfile.mkdtemp())
    assert cache is not None

# Generated at 2022-06-23 09:32:32.667732
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Constructor for CacheModule
    """
    obj = CacheModule()
    assert bool(obj)

# Generated at 2022-06-23 09:32:44.991251
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Given
    uri = '/tmp/ansible/'
    cache_plugin_class = CacheModule
    # When
    cache_plugin = cache_plugin_class(uri)
    # Then
    assert cache_plugin.CAN_USE_BUNZIP2 is False
    assert cache_plugin.CAN_USE_GZIP is False
    assert cache_plugin.CACHE_DIR == "/tmp/ansible/facts"
    assert cache_plugin.CACHE_KEY_PLUGIN == "jsonfile"
    assert cache_plugin.CACHE_KEY_SUFFIX == ".cache"
    assert cache_plugin.CACHE_PLUGIN_PREFIX == 'ansible_facts'
    assert cache_plugin.CACHE_PLUGIN_TIMEOUT == 86400
    assert cache_plugin.CACHE

# Generated at 2022-06-23 09:32:56.765899
# Unit test for constructor of class CacheModule
def test_CacheModule():
  # TODO: test that the constructor works
  # TODO: test that the constructor sets the instance attribute self._basedir to the built-in function dirname of the argument URI with argument 1
  # TODO: test that the constructor sets the instance attribute self._timeout to the argument timeout
  # TODO: test that the constructor sets the instance attribute self._prefix to the argument prefix
  # TODO: test that the constructor calls the built-in function isdir on the value of self._basedir
  # TODO: test that the constructor calls the built-in function expanduser on the value of self._basedir
  # TODO: test that the constructor calls the built-in function expandvars on the value of self._basedir
  # TODO: test that the constructor calls the function makedirs of the module os on the value of self._basedir
  pass

# Generated at 2022-06-23 09:32:57.788995
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule(None, None)

# Generated at 2022-06-23 09:32:59.740825
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert isinstance(cache_module, CacheModule)

# Unit test to test _load() of class CacheModule

# Generated at 2022-06-23 09:33:07.953867
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    from ansible.plugins.cache.base import BaseFileCacheModule
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.parsing.ajson import AnsibleJSONDecoder
    from distutils.version import LooseVersion
    import copy
    import inspect
    import json
    import os
    import tempfile

    import pytest
    from pytest import raises

    # All tests require:
    # * Ansible 2.2 or higher
    # * python 2.6 or higher
    if LooseVersion(ansible_version) < LooseVersion('2.2.0.0'):
        pytest.skip("ansible 2.2 required for this module")

# Generated at 2022-06-23 09:33:09.204126
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache_plugin = CacheModule()

# Generated at 2022-06-23 09:33:16.009418
# Unit test for constructor of class CacheModule
def test_CacheModule():
    name = 'jsonfile'
    caching = 'yes'
    config = {'fact_caching_timeout': '3600', 'fact_caching_connection': '/tmp/facts'}
    module = CacheModule(name, caching, config)
    assert module.name == 'jsonfile'
    assert module.caching == 'yes'
    assert module.timeout == 3600
    assert module.config['fact_caching_connection'] == '/tmp/facts'
    assert module.config['fact_caching_timeout'] == 3600

# Generated at 2022-06-23 09:33:17.016094
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)

# Generated at 2022-06-23 09:33:18.424348
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.plugin_name == 'jsonfile'

# Generated at 2022-06-23 09:33:23.335953
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Unit test for constructor of class CacheModule"""
    module = CacheModule(task=None)

    if module._timeout != 86400:
        raise AssertionError("Unit test for AnsibleCacheModule failed")

# Generated at 2022-06-23 09:33:26.515418
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachePlugin = CacheModule()
    assert cachePlugin is not None

    # plugin should be converted to class instance, not module instance.
    assert not isinstance(cachePlugin, BaseFileCacheModule)

# Generated at 2022-06-23 09:33:27.849143
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_dir is not None

# Generated at 2022-06-23 09:33:31.212486
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._load == c.load
    assert c._dump == c.dump

# Generated at 2022-06-23 09:33:35.047771
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule('_uri', dict(plugin_timeout=1))
    assert cache_module._timeout == 1
    assert cache_module._prefix == ''
    assert cache_module._uri == '_uri'


# Generated at 2022-06-23 09:33:37.606305
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.lock_path == "/dev/shm"

    with_lock_path = CacheModule(lock_path="/lock")
    assert with_lock_path.lock_path == "/lock"

# Generated at 2022-06-23 09:33:40.624368
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule( '/tmp/ansible_cache_test')
    assert cache != None
    assert cache.cache_time == 86400

# Generated at 2022-06-23 09:33:41.978143
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({}, '')