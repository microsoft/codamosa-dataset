

# Generated at 2022-06-23 09:23:43.920758
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule(dict())
    # test some attributes
    for i in ['_timeout', '_cache', 'update', 'get']:
        assert hasattr(c, i), "%s must have %s attr" % (c, i)
    assert type(c._timeout) is int

# Generated at 2022-06-23 09:23:48.144907
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule({'_uri': 'foo'})
    assert isinstance(obj._uri, str)
    assert isinstance(obj._prefix, str)
    assert isinstance(obj._timeout, int)

# Generated at 2022-06-23 09:23:57.323218
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Given am instance of CacheModule with the arguments
    cacheModule = CacheModule(
        plugin = "Plugin",
        timeout = 12,
        task_uuid = "task_uuid",
        uri = "uri",
        task_vars = "task_vars"
    )

    # When I get the value for the attribute
    # Then I should get the expected value
    assert cacheModule.plugin == "Plugin"
    assert cacheModule.timeout == 12
    assert cacheModule.task_uuid == "task_uuid"
    assert cacheModule.uri == "uri"
    assert cacheModule.task_vars == "task_vars"


# Generated at 2022-06-23 09:23:57.922623
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-23 09:23:59.197937
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-23 09:24:02.868379
# Unit test for constructor of class CacheModule
def test_CacheModule():
    host_name = 'test_host'
    cache_module = CacheModule()
    cache_module.set_options({'_uri': '/tmp/'})
    cache_module.set_context({'collection_name': 'test_collection'})

    execution_result = {}

    execution_result['host_name'] = host_name
    cache_module.get_and_update_cache(execution_result)

# Generated at 2022-06-23 09:24:05.696567
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-23 09:24:06.123498
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-23 09:24:08.429087
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(None, {'_prefix': 'test_CacheModule', '_timeout': 30}),
                      CacheModule)


# Generated at 2022-06-23 09:24:12.597622
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule.load_cache_plugin(None, None, None)
    assert cache is not None

# Generated at 2022-06-23 09:24:16.254570
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': "test_host_ansible"})
    #print(cache.get_basedir())
    #print(cache.get_plugin_name())
    #print(cache.get_plugin_options())

# Generated at 2022-06-23 09:24:19.153076
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._extension == 'cache'
    # noinspection PyProtectedMember
    assert cache._load_name == '_load'

# Generated at 2022-06-23 09:24:22.409907
# Unit test for constructor of class CacheModule
def test_CacheModule():
    l = CacheModule()
    assert l.__class__.__name__ == 'CacheModule'
    assert l.__class__.__doc__ == "A caching module backed by json files."

# Generated at 2022-06-23 09:24:24.980959
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._connection is None
    assert plugin._prefix == ''
    assert plugin._timeout == 86400

# Generated at 2022-06-23 09:24:34.772439
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print('This test tests if the constructor of class CacheModule works.')
    file_name = './fact_cache.json'
    # initialization of the class
    cache_module = CacheModule(file_name)
    print('Testing if the attribute _files_cache is initialized properly.')
    print("Attribute '_files_cache' is: " + str(cache_module._files_cache))
    print("This should be a dictionary and should not be empty.")
    print("It should be: {'fact_cache': './fact_cache.json'}")
    print('Passed!')
    print("Testing if the attribute _cache_prefix is initialized properly.")
    print("Attribute '_cache_prefix' is: " + str(cache_module._cache_prefix))
    print("This should be a string and should be empty.")

# Generated at 2022-06-23 09:24:35.943612
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._encoder_class == AnsibleJSONEncoder
    assert cache._decoder_class == AnsibleJSONDecoder

# Generated at 2022-06-23 09:24:38.566961
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    print(cache_module)
    print(cache_module.get_options())

if __name__ == "__main__":

    test_CacheModule()

# Generated at 2022-06-23 09:24:42.379326
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test = CacheModule()
    assert test._timeout == 86400
    assert test._prefix == 'ansible-factcache'
    assert test._conn is not None

# Generated at 2022-06-23 09:24:43.911526
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule


# Generated at 2022-06-23 09:24:44.428401
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-23 09:24:44.969389
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

# Generated at 2022-06-23 09:24:46.776565
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filecache = {}

    # Constructor
    filecache = CacheModule()

    # Try to load a file
    filecache._load('test/path')

# Generated at 2022-06-23 09:24:48.976427
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_module = CacheModule()
    assert type(test_module) is not None

# Generated at 2022-06-23 09:24:51.292140
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule(None)

    assert module.get_extension() == 'json'
    assert module.get_timeout() == 86400

# Generated at 2022-06-23 09:24:54.633981
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(None)
    assert cache_module._load(None) == None
    assert cache_module._dump(None, None) == None

# Generated at 2022-06-23 09:24:55.619967
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert 'CacheModule' in globals()

# Generated at 2022-06-23 09:24:57.144370
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert isinstance(cache_module._load("test.json"), dict)

# Generated at 2022-06-23 09:25:02.508306
# Unit test for constructor of class CacheModule
def test_CacheModule():
    class Capturing(object):
        def __init__(self):
            self.out = None
        def __enter__(self):
            self.out = []
            return self.out.append
        def __exit__(self, *args):
            return True

    with Capturing() as cm:
        CacheModule()
    assert len(cm) == 1
    assert cm[0] == "Using default jsonfile cache plugin for facts"


# Generated at 2022-06-23 09:25:04.428677
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    cache_plugin.set_options({'_uri': 'test/'})
    cache_plugin.flush()

# Generated at 2022-06-23 09:25:06.141514
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-23 09:25:09.085875
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    # Regardless of the input, we should get a valid CacheModule object
    assert cacheModule != None
    assert isinstance(cacheModule, CacheModule)

# Generated at 2022-06-23 09:25:11.519058
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert(cache_plugin.get_path("localhost") == "/tmp/ansible_localhost.fact_cache")

# Generated at 2022-06-23 09:25:16.299720
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.timeout == 86400
    assert c.uri == '~/.ansible/tmp/ansible-caching'
    assert c.prefix == 'ansible-cache'

# Generated at 2022-06-23 09:25:26.455836
# Unit test for constructor of class CacheModule
def test_CacheModule():
    localhost = dict(hostname='localhost')
    localhost_facts = dict(hello='world')
    cm = CacheModule()
    assert int(cm._timeout) == 86400
    assert cm._load(cm._get_cache_path("localhost")) == {}
    assert cm.get("localhost", "localhost_facts") == dict()
    cm.set("localhost", "localhost_facts", localhost)
    assert cm.get("localhost", "localhost_facts") == localhost
    assert cm.get("localhost", "localhost_facts_invalid") == dict()
    cm.set("localhost", "localhost_facts", localhost_facts)
    assert cm.get("localhost", "localhost_facts") == localhost_facts
    cm.set("localhost", "localhost_facts", localhost_facts, expire=1)

# Generated at 2022-06-23 09:25:30.145248
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = 'Connection'
    prefix = 'Prefix'
    timeout = 1000
    cache = CacheModule(connection, prefix, timeout)
    assert cache._uri == 'Connection'
    assert cache._prefix == 'Prefix'
    assert cache._timeout == 1000

# Generated at 2022-06-23 09:25:33.468792
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Unit test for constructor of class CacheModule
    cache = CacheModule()
    assert cache.get_prefix() == 'ansible_facts'

# Generated at 2022-06-23 09:25:35.933046
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(task_vars={"ansible_facts": {'test_var': 1}})
    assert (cache_module.task_vars == {"ansible_facts": {'test_var': 1}})

# Generated at 2022-06-23 09:25:38.861325
# Unit test for constructor of class CacheModule
def test_CacheModule():
	cacheModule = CacheModule()
	assert cacheModule != None, "failed to instanciate CacheModule"

# Generated at 2022-06-23 09:25:39.936445
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule(dict())

# Generated at 2022-06-23 09:25:44.098279
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None
    assert cache_module.get('test_host', 'test_key') == {}
    assert cache_module.set('test_host', 'test_key', 'test_value') == True

# Generated at 2022-06-23 09:25:54.766752
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile

    # BaseFileCacheModule(self, *args, **kwargs)
    # Create a temporary directory
    tmp_folder = tempfile.mkdtemp()
    tmp_uri = os.path.join(tmp_folder, "data")

    cache = CacheModule(uri=tmp_uri)

    # clean_cache_dir()
    cache.clean_cache_dir()
    assert os.listdir(tmp_uri) == []

    # get(self, key)
    assert cache.get("key") == None

    # set(self, key, value)
    cache.set("key", "value")

    # get(self, key)
    assert cache.get("key") == "value"

    # flush(self)
    cache.flush()
    assert os.listdir(tmp_uri)

# Generated at 2022-06-23 09:25:56.049730
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._timeout == 86400

# Generated at 2022-06-23 09:26:04.502351
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = None
    _cache_module = CacheModule(uri, {}, {}, {})
    assert _cache_module is not None
    assert _cache_module._prefix == 'ansible_facts'
    assert _cache_module._cache_dir == '/tmp'
    assert _cache_module._timeout == 86400
    uri = '/tmp'
    _cache_module = CacheModule(uri, {}, {}, {})
    assert _cache_module._cache_dir == uri

# Generated at 2022-06-23 09:26:08.342927
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(task_vars={})
    assert isinstance(cache_module, BaseFileCacheModule)
    assert hasattr(cache_module,'_load')
    assert hasattr(cache_module,'_dump')

# Generated at 2022-06-23 09:26:08.967070
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:26:10.017739
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache_module = CacheModule()

# Generated at 2022-06-23 09:26:12.374948
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule({'ANSIBLE_CACHE_PLUGIN_CONNECTION': 'test'})
    print(obj.cache_dir)

# Generated at 2022-06-23 09:26:16.800302
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({
        "CACHE_PLUGIN_CONNECTION": "/tmp/",
        "CACHE_PLUGIN_TIMEOUT": "86400",
        "CACHE_PLUGIN_PREFIX": "ansible_facts"
    }, task_vars={})

# Generated at 2022-06-23 09:26:24.032552
# Unit test for constructor of class CacheModule

# Generated at 2022-06-23 09:26:30.022014
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Dummy unit test for CacheModule constructor.
    :return: None
    """
    plugin = CacheModule(task_vars={'fact_caching_connection': 'test/test_json.json'})

    # The file test/test_json.json may not exist.
    assert plugin._connection == 'test/test_json.json'

# Generated at 2022-06-23 09:26:32.684012
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule()
    assert isinstance(instance, CacheModule)
    assert isinstance(instance, BaseFileCacheModule)
    assert instance._timeout == 86400

# Generated at 2022-06-23 09:26:37.302645
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """ test_CacheModule: Test the constructor of class CacheModule """
    # Execute
    cache_module = CacheModule()
    # Verify
    assert cache_module.get_option('_prefix') is None
    assert cache_module.get_option('_timeout') == 86400
    assert cache_module.get_option('_uri') is None

# Generated at 2022-06-23 09:26:39.826990
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert 'jsonfile' in cache.__class__.__name__
    assert 'CacheModule' in cache.__class__.__name__

# Generated at 2022-06-23 09:26:41.009778
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Test the constructor of the CacheModule class
    """
    cache = CacheModule()

# Generated at 2022-06-23 09:26:45.397809
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert(cache_module._prefix == 'ansible_fact_cache')
    assert(cache_module._timeout == 86400)

# Generated at 2022-06-23 09:26:49.481891
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj._timeout == 86400
    assert obj._prefix == u''
    assert obj._connection == u'cache'

# We import the module only to test if it's well written
from ansible.plugins.cache.jsonfile import *  # noqa

# Generated at 2022-06-23 09:26:55.531806
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._connection is None
    assert cache_module._prefix is None
    assert cache_module._timeout == 86400
    assert cache_module._lock_path is None
    assert cache_module.lock is None


# Generated at 2022-06-23 09:26:56.511958
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

# Generated at 2022-06-23 09:27:00.235309
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.file_extension == 'json'
    assert c._prefix == ''
    assert c._timeout == 86400
    assert c._connection == ''


# Generated at 2022-06-23 09:27:07.643121
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Constructor of the class CacheModule
    :return:
    """
    cache_module = CacheModule()
    assert isinstance(cache_module, CacheModule)

# Generated at 2022-06-23 09:27:08.488331
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule



# Generated at 2022-06-23 09:27:17.113346
# Unit test for constructor of class CacheModule
def test_CacheModule():
    config={}
    config["_timeout"]=123
    config["_prefix"]=456
    config["_uri"]="test"

    cache_obj = CacheModule(config)
    assert(cache_obj["_uri"] == "test")
    assert(cache_obj["_prefix"] == 456)
    assert(cache_obj["_timeout"] == 123)

# Generated at 2022-06-23 09:27:18.722570
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c=CacheModule()

    assert c is not None, "Constructor creates a CacheModule object"

# Generated at 2022-06-23 09:27:19.900880
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert not cache is None

# Generated at 2022-06-23 09:27:22.556442
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.plugin == 'jsonfile'
    assert cache_module._timeout == 86400
    assert cache_module._prefix is None
    assert cache_module._uri is None

# Generated at 2022-06-23 09:27:23.683215
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None


# Generated at 2022-06-23 09:27:29.879751
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = get_cache_plugin(plugin='jsonfile', config={'_prefix': 'test_CacheModule'})
    assert cache is not None
    cache.set('test_CacheModule.test', {'test': 'test'})
    assert cache.get('test_CacheModule.test') == {'test': 'test'}

# Generated at 2022-06-23 09:27:32.773827
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    This function is a constructor test for the CacheModule class.
    """

    instance = CacheModule()

    # The test is good if no exception raised
    assert isinstance(instance, CacheModule)



# Generated at 2022-06-23 09:27:34.820328
# Unit test for constructor of class CacheModule
def test_CacheModule():
    fact_cache = CacheModule(None, [])
    assert fact_cache is not None

# Generated at 2022-06-23 09:27:35.528928
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:27:38.307015
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._timeout == 86400, 'expected 86400, got %i' % plugin._timeout

# Generated at 2022-06-23 09:27:41.009818
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule({'_uri': '/tmp'})
    assert module._uri == '/tmp'
    assert module._prefix == ''
    assert module._timeout == 86400

# Generated at 2022-06-23 09:27:44.428338
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_cachemodule = CacheModule()
    assert test_cachemodule.cache_plugin_name == 'jsonfile'
    assert test_cachemodule.file_extension == 'json'

# Generated at 2022-06-23 09:27:50.845491
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule(module_name='jsonfile', conn='/tmp/test_jsonfile')
    assert c.file is None
    # Create cache
    c.set('test_key', 'test_value')
    data = c.get('test_key')
    assert data == 'test_value'


# Generated at 2022-06-23 09:27:52.826439
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)
    assert CacheModule.__doc__ == __doc__.split('\n')[0]

# Generated at 2022-06-23 09:27:54.127039
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("Test CacheModule")
    assert isinstance(CacheModule(), BaseFileCacheModule)

# Generated at 2022-06-23 09:27:54.653514
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:27:55.881946
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test construction
    foo = CacheModule()
    assert foo is not None

# Generated at 2022-06-23 09:27:56.567152
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:27:58.014200
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(CacheModule)

# Generated at 2022-06-23 09:28:01.567820
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.plugin
    assert cache_plugin._load
    assert cache_plugin._dump

# Generated at 2022-06-23 09:28:09.264199
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    _uri = '/tmp'
    _timeout = 86400
    _prefix = 'ansible_'
    cache._uri = _uri
    cache._timeout = _timeout
    cache._prefix = _prefix
    assert cache._uri == _uri
    assert cache._timeout == _timeout
    assert cache._prefix == _prefix

# Generated at 2022-06-23 09:28:10.967549
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._load is not None
    assert cm._dump is not None

# Generated at 2022-06-23 09:28:12.291124
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-23 09:28:13.892959
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert x

# Generated at 2022-06-23 09:28:16.310807
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.plugin_name == 'jsonfile'

# Generated at 2022-06-23 09:28:16.997961
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-23 09:28:17.348236
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:28:22.086717
# Unit test for constructor of class CacheModule
def test_CacheModule():
  localhost = CacheModule('/root/.ansible/tmp', 'localhost')
  assert isinstance(localhost, CacheModule)
  assert localhost._cachefile == '/root/.ansible/tmp/localhost'
  assert localhost._timeout == 86400


# Generated at 2022-06-23 09:28:25.931841
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection_path = '/path/to/connection'
    prefix = 'test'
    timeout = 10
    c = CacheModule(connection_path, prefix, timeout)
    assert c._connection == '/path/to/connection/test'
    assert c._timeout == 10



# Generated at 2022-06-23 09:28:27.519125
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:28:29.685288
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule(None)
    assert isinstance(m, CacheModule)


# Generated at 2022-06-23 09:28:32.449996
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._prefix == 'ansible-factcache'
    assert cache._timeout == 86400
    assert cache._plugin_name == 'jsonfile'

# Generated at 2022-06-23 09:28:36.033368
# Unit test for constructor of class CacheModule
def test_CacheModule():

    config = {}
    config['_load'] = 'test_load'
    config['_dump'] = 'test_dump'

    cm = CacheModule(config)
    assert cm._load == 'test_load'
    assert cm._dump == 'test_dump'

# Generated at 2022-06-23 09:28:36.549434
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:28:38.916181
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(None) is not None


# Generated at 2022-06-23 09:28:39.554146
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-23 09:28:42.830211
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._uri == "file:///home/ansible/ansible_dir/ansible_cache"
    assert CacheModule._prefix == None
    assert CacheModule._timeout == 86400

# Generated at 2022-06-23 09:28:44.338337
# Unit test for constructor of class CacheModule
def test_CacheModule():
    myCache = CacheModule()
    assert(myCache.name == 'jsonfile')

# Generated at 2022-06-23 09:28:44.963531
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-23 09:28:57.401695
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test for constructor with fake data
    test_uri = '/cache_test/uri'
    test_prefix = 'cache_test_prefix'
    test_timeout = 86400
    test_plugin_name = 'jsonfile'
    test_plugin_version = '1.0'
    test_plugin_class = 'CacheModule'
    test_cache_module = CacheModule(test_uri, test_prefix, test_timeout)
    assert hasattr(test_cache_module, '_uri')
    assert hasattr(test_cache_module, '_prefix')
    assert hasattr(test_cache_module, '_timeout')
    assert hasattr(test_cache_module, '_plugin_name')
    assert hasattr(test_cache_module, '_plugin_class')

# Generated at 2022-06-23 09:29:01.605997
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_m = CacheModule()
    assert cache_m.CACHE_PLUGIN_NAME == 'jsonfile'
    assert cache_m.CACHE_PLUGIN_PATH == 'lib/ansible/plugins/cache'
    assert cache_m.CACHE_PLUGIN_ENV != None
    assert cache_m.CACHE_PLUGIN_CONFIG == None

# Generated at 2022-06-23 09:29:03.829634
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_case = CacheModule({})
    assert type(test_case) == CacheModule

# Generated at 2022-06-23 09:29:08.726895
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = '/tmp'
    prefix = 'ansible-fact-cache'
    timeout = 86400
    cache = CacheModule()
    assert cache._load == cache.load
    assert cache._dump == cache.dump
    assert cache._timeout == timeout
    assert cache._prefix == prefix
    assert cache._uri == path

# Generated at 2022-06-23 09:29:09.830449
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c

# Generated at 2022-06-23 09:29:22.149249
# Unit test for constructor of class CacheModule
def test_CacheModule():
    #Check if _load method raises TypeError
    try:
        assert isinstance(CacheModule(None)._load(None), TypeError)
    except NotImplementedError:
        pass
    # check if _dump method raises TypeError
    try:
        assert isinstance(CacheModule(None)._dump(None, None), TypeError)
    except NotImplementedError:
        pass
    # check if _dump method raises TypeError
    try:
        assert isinstance(CacheModule(None).dump(), TypeError)
    except NotImplementedError:
        pass
    #Check if _load method raises TypeError
    try:
        assert isinstance(CacheModule(None).load(), TypeError)
    except NotImplementedError:
        pass

# Generated at 2022-06-23 09:29:33.831962
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with a class name.
    parameter = {'_uri': '/tmp', '_prefix': 'test_prefix'}
    cache = CacheModule(parameter)
    assert cache._connection._prefix == 'test_prefix'
    parameter = {'_uri': '/tmp'}
    cache = CacheModule(parameter)
    assert cache._connection._prefix == ''
    assert cache._connection._timeout == 86400
    assert cache._connection._file_extension == 'json'
    assert cache._connection._serializer == 'json'
    assert cache._connection._serializer_ext == 'json'
    assert cache._connection._serializer_preferred_method == 'json'
    # Test with an instance of its parent class.
    parameter = {'_uri': '/tmp'}
    cache = CacheModule(parameter)

# Generated at 2022-06-23 09:29:35.838963
# Unit test for constructor of class CacheModule
def test_CacheModule():
    the_module = CacheModule()
    the_module.set_options({})
    # Should pass
    the_module.flush()

# Generated at 2022-06-23 09:29:36.638384
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

    assert cache_module

# Generated at 2022-06-23 09:29:44.378542
# Unit test for constructor of class CacheModule
def test_CacheModule():
    tempdir = os.path.realpath(tempfile.mkdtemp())
    data = {u"test": {u"somekey": u"somevalue"}}
    ttl = 1
    cache = CacheModule(tempdir, ttl, prefix='')
    cache.set(u"test", data)
    cache.get(u"test")
    cache.flush()

# Generated at 2022-06-23 09:29:46.261958
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    print(plugin)
    assert plugin  # to satisfy pylint

# Generated at 2022-06-23 09:29:49.587775
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule(config=None, params=None)
    assert cm.caches_folder_path == '~/.ansible/cache'
    assert cm.timeout == 86400

# Generated at 2022-06-23 09:29:51.220724
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheObj = CacheModule('/tmp')
    assert cacheObj is not None


# Generated at 2022-06-23 09:29:54.069833
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == "/tmp/ansible_fact_cache"
    assert cache_module.get_prefix() is None


# Generated at 2022-06-23 09:29:58.254505
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    jsonfile = CacheModule()
    assert jsonfile.file_extension == 'json'
    assert jsonfile._timeout == 86400

# Generated at 2022-06-23 09:30:04.948358
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_conf = dict(
        connection='$HOME/.ansible/tmp',
        prefix='ansible-facts'
    )
    cache = CacheModule()
    assert cache._connection is None
    assert cache._prefix is None

    cache.set_options(cache_plugin_conf)
    assert cache._connection == '$HOME/.ansible/tmp'
    assert cache._prefix == 'ansible-facts'

    assert cache.get_options() == cache_plugin_conf

    cache.flush()
    assert cache.get('gugus') is None



# Generated at 2022-06-23 09:30:14.663496
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, '__init__')
    assert CacheModule.__init__.__code__.co_argcount == 2
    assert CacheModule.__init__.__code__.co_varnames[:2] == ('self', 'task_vars')
    assert hasattr(CacheModule, 'get')
    assert CacheModule.get.__code__.co_argcount == 2
    assert CacheModule.get.__code__.co_varnames[:2] == ('self', 'file')
    assert hasattr(CacheModule, 'set')
    assert CacheModule.set.__code__.co_argcount == 3
    assert CacheModule.set.__code__.co_varnames[:3] == ('self', 'file', 'data')
    assert hasattr(CacheModule, '_load')


# Generated at 2022-06-23 09:30:15.629064
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule

# Generated at 2022-06-23 09:30:27.810529
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("\nstarting unit test for CacheModule")

    # construct CacheModule object
    obj = CacheModule()
    print(obj)

    # construct cache file path
    cache_file_path = './' + obj._get_cache_file_path('./', 'unit_test')

    # dump test data
    obj._dump('TestData', cache_file_path)

    # load test data
    loaded_data = obj._load(cache_file_path)
    print(loaded_data)
    assert(loaded_data == 'TestData')

    # remove test cache file
    obj._remove_file(cache_file_path)

    print("unit test passed!")

if __name__ == "__main__":
    test_CacheModule()

# Generated at 2022-06-23 09:30:29.408246
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-23 09:30:31.796022
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('test') == ''

# Generated at 2022-06-23 09:30:32.955160
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin is not None

# Generated at 2022-06-23 09:30:33.892742
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()

# Generated at 2022-06-23 09:30:35.190839
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:30:38.049653
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = "~/ansible"
    prefix = "ansible_"
    timeout = 1000
    cache_module = CacheModule(uri, prefix, timeout)
    assert(cache_module.file_extension() == u"json")
    assert(cache_module.get_timeout() == timeout)

# Generated at 2022-06-23 09:30:40.072160
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert hasattr(cache, '_load')
    assert hasattr(cache, '_dump')

# Generated at 2022-06-23 09:30:48.781452
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_connection = 'test'
    cache_plugin_prefix = 'test'
    cache_plugin_timeout = 'test'
    # Test constructor of class CacheModule
    cache = CacheModule(cache_plugin_connection, cache_plugin_prefix, cache_plugin_timeout)
    assert cache.cache_plugin_connection == cache_plugin_connection
    assert cache.cache_plugin_prefix == cache_plugin_prefix
    assert cache.cache_plugin_timeout == cache_plugin_timeout


# Generated at 2022-06-23 09:30:49.485542
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-23 09:30:53.156226
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create an instance of the CacheModule object for unit testing
    cache = CacheModule()
    assert cache

# Generated at 2022-06-23 09:30:53.981836
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule({'_uri': "test"})

# Generated at 2022-06-23 09:30:54.863322
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert True


# Generated at 2022-06-23 09:30:56.152935
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-23 09:31:01.249968
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test without passing in any arguments
    test = CacheModule()
    assert test == None

    # test with arguments
    test_arg = CacheModule(connection=1234, plugin_prefix='test', timeout=2345)
    assert test_arg == None

# Generated at 2022-06-23 09:31:10.638189
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(CacheModule.__doc__.strip() == __doc__.strip())
    assert(CacheModule._load.__func__.__doc__.strip() == CacheModule._load.__doc__.strip())
    assert(CacheModule._dump.__func__.__doc__.strip() == CacheModule._dump.__doc__.strip())

# Generated at 2022-06-23 09:31:15.255273
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._cache_dir() == '/tmp/ansible_jsonfile_fact_cache'
    assert cache._cache_path() == '/tmp/ansible_jsonfile_fact_cache/ansible_facts.cache'
    assert cache._load(cache._cache_path()) == {}
    cache._dump({'test':'test'}, cache._cache_path())
    assert cache._load(cache._cache_path()) == {'test':'test'}

# Generated at 2022-06-23 09:31:16.496082
# Unit test for constructor of class CacheModule
def test_CacheModule():
    a=CacheModule()
    assert a.file_extension == '.json'

# Generated at 2022-06-23 09:31:17.382568
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-23 09:31:22.048327
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert isinstance(cacheModule._connection, str)
    assert isinstance(cacheModule._timeout, int)
    assert isinstance(cacheModule._prefix, str)


# Generated at 2022-06-23 09:31:23.290109
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert(cache is not None)


# Generated at 2022-06-23 09:31:29.732677
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_file = "/tmp/test_jsonfile_cache"
    test_data = {'foo': 'bar'}
    with open(test_file, 'w') as f:
        json.dump(test_data, f)
    cache = CacheModule('jsonfile', "/tmp")
    saved_data = cache.get('test')
    # Make sure to remove test file
    os.remove(test_file)
    assert(saved_data == test_data)

# Generated at 2022-06-23 09:31:31.057288
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.timeout == 86400

# Generated at 2022-06-23 09:31:37.253993
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    cache.set('host1', 'var1', 'value1')
    assert cache.get('host1', 'var1') == 'value1'
    cache.set('host1', 'var1', 'value2')
    assert cache.get('host1', 'var1') == 'value2'
    cache.delete('host1', 'var1')
    assert cache.get('host1', 'var1') is None

    cache.set('host1', 'var2', 'value3')
    cache.set('host2', 'var2', 'value4')
    assert cache.get('host1', 'var2') == 'value3'
    assert cache.get('host2', 'var2') == 'value4'
    assert cache.get('host3', 'var2') is None


# Generated at 2022-06-23 09:31:38.040163
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()


# Generated at 2022-06-23 09:31:39.639567
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    cache.set("test", "test")
    value = cache.get("test")
    assert value == "test"

# Generated at 2022-06-23 09:31:40.361060
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

# Generated at 2022-06-23 09:31:43.577024
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import CacheModule
    instance = CacheModule('/tmp/', 'test_')
    assert isinstance(instance, CacheModule)

# Generated at 2022-06-23 09:31:54.191976
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonfile_test = CacheModule()
    jsonfile_test_key = 'Test'
    jsonfile_test_value = 'Test'
    jsonfile_test_plugin_name = 'jsonfile'
    assert jsonfile_test.get(jsonfile_test_key) == None
    assert jsonfile_test.set(jsonfile_test_key, jsonfile_test_value) == True
    assert jsonfile_test.get(jsonfile_test_key) == jsonfile_test_value
    assert jsonfile_test.contains(jsonfile_test_key) == True
    assert jsonfile_test.delete(jsonfile_test_key) == True
    assert jsonfile_test.contains(jsonfile_test_key) == False

# Generated at 2022-06-23 09:31:56.724359
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    # Test class attributes
    assert c.file_extension == '.json'
    assert c.should_cache_wrapper == BaseFileCacheModule.should_cache_wrapper

# Generated at 2022-06-23 09:31:57.938498
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-23 09:32:02.110410
# Unit test for constructor of class CacheModule
def test_CacheModule():
    def_cacheplug_conn = '~/.ansible/cache'
    def_cacheplug_prefix = 'ansible-fact'
    def_cacheplug_timeout = 86400

    jsonfile = CacheModule()
    assert jsonfile._connection == def_cacheplug_conn
    assert jsonfile._prefix == def_cacheplug_prefix
    assert jsonfile._timeout == def_cacheplug_timeout

# Generated at 2022-06-23 09:32:05.342308
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': "/tmp"})

# Generated at 2022-06-23 09:32:05.794775
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:32:12.129767
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test meta set
    module = CacheModule(load_path='/path/to/', plugin='jsonfile')
    assert module._load_path == '/path/to/'
    assert module._plugin == 'jsonfile'
    assert module._timeout == 86400
    assert module._plugin_prefix == 'ansible_facts_'

    # test meta not set
    module = CacheModule()
    assert module._load_path == '~/.ansible/tmp'
    assert module._timeout == 86400
    assert module._plugin_prefix == 'ansible_facts_'

# Generated at 2022-06-23 09:32:16.200176
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = {"_timeout": 100, "_prefix": "test", "_uri": "test"}
    cache = CacheModule.load(connection)
    assert isinstance(cache, CacheModule)
    assert cache._timeout == 100
    assert cache._prefix == "test"
    assert cache._uri == "test"

# Generated at 2022-06-23 09:32:18.646018
# Unit test for constructor of class CacheModule
def test_CacheModule():
    if __name__ == "__main__":
        cache = CacheModule()
        print("Success")
    else:
        print("Constructor of class CacheModule called successfully")

# Generated at 2022-06-23 09:32:27.168711
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule('/var/tmp', 'prefix', 'suffix', 86400)
    obj._dir = '/var/tmp/prefix'
    obj._path = '/var/tmp/prefix/suffix'
    obj._timeout = 86400
    obj._timeout_valid = False

    assert (obj._dir == '/var/tmp/prefix')
    assert (obj._path == '/var/tmp/prefix/suffix')
    assert (obj._timeout == 86400)
    assert (obj._timeout_valid == False)

    assert (obj.get_basedir() == '/var/tmp')
    assert (obj.get_prefix() == 'prefix')
    assert (obj.get_suffix() == 'suffix')
    assert (obj.get_timeout() == 86400)

# Generated at 2022-06-23 09:32:31.754515
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert(plugin._uri == '~/.ansible/tmp/ansible-caching-dir')
    assert(plugin._prefix == 'ansible_fact_cache_')
    assert(plugin._timeout == 86400)

# Generated at 2022-06-23 09:32:32.754909
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-23 09:32:38.871612
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # The constructor does not have any public functions or attributes
    cache_module = CacheModule()
    # Checking that the private attributes are initialized correctly
    assert cache_module._connection is not None
    assert cache_module._timeout == 86400
    assert cache_module._prefix == ''

# Generated at 2022-06-23 09:32:39.854944
# Unit test for constructor of class CacheModule
def test_CacheModule():
    my_obj = CacheModule()
    assert my_obj

# Generated at 2022-06-23 09:32:41.154043
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module



# Generated at 2022-06-23 09:32:44.669313
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Testing with various values for '_uri' parameter
    for uri in ['', '/tmp/test_uri']:
        # Creating an object of CacheModule class
        cache_obj = CacheModule(uri)
        assert cache_obj
        assert cache_obj.cache_dir == uri

# Generated at 2022-06-23 09:32:48.956161
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert hasattr(cache_plugin, '_cache') == True

# Generated at 2022-06-23 09:32:51.085817
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.__class__.__name__ == 'CacheModule'

# Generated at 2022-06-23 09:32:53.357286
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule(None)
    assert isinstance(m, CacheModule)

# Generated at 2022-06-23 09:32:58.027234
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(
        'path/to/cache',
        'prefix',
        10
    )
    assert cache._connection == 'path/to/cache'
    assert cache._prefix == 'prefix'
    assert cache._timeout == 10


# Generated at 2022-06-23 09:32:59.858909
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule("/tmp/")
    assert cache_module._path_prefix == "/tmp/"

# Generated at 2022-06-23 09:33:01.557206
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(u'some_dir', u'some_prefix', u'some_timeout')

# Generated at 2022-06-23 09:33:14.646409
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    # Unit test: __init__
    with patch('os.path.join', MagicMock(return_value='/home/user/caching/temp_file')):
        with patch('ansible.plugins.cache.BaseFileCacheModule._validate_cache_meta_data_file', MagicMock()) as validate_cache_meta_data_file_mock:
            with patch('ansible.plugins.cache.BaseFileCacheModule.get', MagicMock()) as get_mock:
                with patch('ansible.plugins.cache.BaseFileCacheModule.task_vars', MagicMock(return_value = {'inventory_hostname': 'test-host'})):
                    cm = CacheModule()

# Generated at 2022-06-23 09:33:16.715774
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._load({}) == None
    assert module._dump({}, '') == None

# Generated at 2022-06-23 09:33:20.169970
# Unit test for constructor of class CacheModule
def test_CacheModule():
    p = CacheModule('./')
    assert p._plugin_name == 'jsonfile'
    assert p._options['_uri'] == './'
    assert p._options['_timeout'] == 86400
    assert not p._options['_prefix']

# Generated at 2022-06-23 09:33:25.981554
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    expected_result = dict(
        _timeout=86400,
        _connection=None,
        _prefix=None,
    )
    assert cache._timeout == expected_result['_timeout'], 'Default timeout should be 86400'
    assert cache._connection == expected_result['_connection'], 'Default connection should be none'
    assert cache._prefix == expected_result['_prefix'], 'Default prefix should be none'

# Generated at 2022-06-23 09:33:26.486120
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-23 09:33:30.163746
# Unit test for constructor of class CacheModule
def test_CacheModule():
    con = CacheModule()
    assert 'jsonfile' == con._load_name()
    assert 'jsonfile' == con.get_name()
    assert '.json' == con._load_suffix()
    assert '.json' == con.get_suffix()


# Test load and dump

# Generated at 2022-06-23 09:33:31.267855
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-23 09:33:38.222341
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_location = '/tmp'
    prefix = 'ansible-cache'
    timeout = 3600

    _CacheModule = CacheModule()
    _CacheModule.set_options({'fact_caching_connection': cache_location,
                              'fact_caching_prefix': prefix,
                              'fact_caching_timeout': timeout})
    assert _CacheModule.cache_dir == cache_location
    assert _CacheModule.prefix == prefix
    assert _CacheModule.timeout == timeout

# Generated at 2022-06-23 09:33:43.302205
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(task_vars=dict(),
                        vault_password='secret')
    assert type(cache) is CacheModule
    assert cache.option('_timeout') == 86400
    assert cache.option('_prefix') == None
    assert cache.option('_uri') is None
    return cache
