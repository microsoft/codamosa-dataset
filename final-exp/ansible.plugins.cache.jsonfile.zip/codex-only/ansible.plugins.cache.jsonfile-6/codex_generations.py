

# Generated at 2022-06-23 09:23:45.877713
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print (CacheModule)


# Test creating the object - check if exception is thrown

# Generated at 2022-06-23 09:23:48.242723
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Given
    Config = {}
    # When
    jsonfile = CacheModule(Config)
    # Then
    assert jsonfile is not None

# Generated at 2022-06-23 09:23:58.819420
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile
    import shutil
    plugin_dir = tempfile.mkdtemp()
    plugin = CacheModule({'_uri': plugin_dir, '_prefix': 'test_'})
    host_name = b'test.example.org'
    host_name_string = host_name.decode('utf-8')

    data = {'foo': 'bar'}
    plugin.set(host_name, data)
    assert os.path.exists(os.path.join(plugin_dir, 'test_' + host_name_string + '.json'))

    new_data = plugin.get(host_name_string)
    assert new_data['foo'] == data['foo']

    plugin.set(host_name, data)
    file_list = os.listdir(plugin_dir)

# Generated at 2022-06-23 09:24:06.318040
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    cache.set('foo', 'bar', 1)
    assert cache.get('foo') == 'bar'
    assert cache.is_valid('foo') is True
    assert cache.is_valid('bar') is False
    cache.set('foo', None, 1)
    assert cache.get('foo') == None
    cache.delete('foo')
    assert cache.get('foo') == None

# Generated at 2022-06-23 09:24:11.705374
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cfg = {'path': '/some/path',
           'prefix': 'foo_',
           '_timeout': 1000,
           'valid': True,
           '_uri': 'test://test'}
    cache = CacheModule(cfg, 1)
    assert cache.valid == cfg['valid']
    assert cache._connection == 'test://test'
    assert cache._timeout == 1000
    assert cache._plugin_name == 'jsonfile'
    assert cache._prefix == 'foo_'

# Generated at 2022-06-23 09:24:12.699967
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

# Generated at 2022-06-23 09:24:13.276513
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert True

# Generated at 2022-06-23 09:24:16.325619
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    # Valid instance of class CacheModule created
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-23 09:24:18.041437
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-23 09:24:20.964362
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Constructor for CacheModule class
    """

    cacheModule = CacheModule()
    assert cacheModule._load is not None
    assert cacheModule._dump is not None

# Generated at 2022-06-23 09:24:23.459203
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = 'http://remote/path'
    cache = CacheModule(connection)
    assert cache._connection == connection

# Generated at 2022-06-23 09:24:25.724466
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule(None)
    assert isinstance(plugin, CacheModule)


# Generated at 2022-06-23 09:24:27.845660
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c=CacheModule()
    assert c._load_plugin_name() == 'jsonfile'

# Generated at 2022-06-23 09:24:30.114450
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._load.__name__ == '_load'
    assert plugin._dump.__name__ == '_dump'

# Generated at 2022-06-23 09:24:33.371075
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._pickle == 'json'
    assert cache._cache_prefix == 'ansible-fact'

# Generated at 2022-06-23 09:24:34.416708
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-23 09:24:36.316189
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None
    assert isinstance(cm, BaseFileCacheModule)

# Generated at 2022-06-23 09:24:43.831928
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        # Call to constructor of class
        test_CacheModule = CacheModule(connection=None, *[], **{})
    except Exception as e:
        # Unit test for constructor of class CacheModule
        print("Constructor of class CacheModule raised exception " + str(e))
        return False
    else:
        return True


# Generated at 2022-06-23 09:24:47.942808
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._cachefile_ext is None
    assert cache_module.HAS_TTL is True
    assert cache_module._connection is None
    assert cache_module._prefix is None
    assert cache_module._timeout == 86400

    assert cache_module._load is not None
    assert cache_module._dump is not None

# Generated at 2022-06-23 09:24:51.273488
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule('/tmp/test.json')
    assert obj._prefix == ''
    assert obj._timeout == 3600
    assert obj._connection == '/tmp/test.json'

# Generated at 2022-06-23 09:24:54.885031
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(
        {
            '_uri': 'file:///tmp/ansible_caching_test_dir',
        }
    )
    assert cache is not None

# Generated at 2022-06-23 09:25:02.037070
# Unit test for constructor of class CacheModule
def test_CacheModule():
    d = dict()
    d['_uri'] = 'test_uri'
    d['_prefix'] = 'test_prefix'
    d['_timeout'] = 10
    c = CacheModule(d)
    assert c._connection == 'test_uri'
    assert c._prefix == 'test_prefix'
    assert c._timeout == 10
    # Test without prefix
    d['_prefix'] = None
    c = CacheModule(d)
    assert c._connection == 'test_uri'
    assert c._prefix is None
    assert c._timeout == 10


# Generated at 2022-06-23 09:25:07.361412
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    # Test if module is inherited from BaseFileCacheModule and it's parent class is BaseCacheModule
    assert(issubclass(CacheModule, BaseFileCacheModule))
    assert(issubclass(BaseFileCacheModule, BaseCacheModule))

# Generated at 2022-06-23 09:25:15.069265
# Unit test for constructor of class CacheModule
def test_CacheModule():

    from ansible.plugins.cache import BaseFileCacheModule

    # Instantiation object CacheModule with attribute name 'JSON'
    jsonfile = CacheModule()


    # Define the test variables and expected results
    file_name = 'file.json'
    file_name_full = '/tmp/file.json'

    file_content = {
        "sections": [
            {"key1": "value1"},
            {"key2": "value2"}
        ]
    }

    file_content_expected = {
        "sections": [
            {"key1": "value1"},
            {"key2": "value2"}
        ]
    }


    #########################################################################
    # Unit test for method '_load' without prefix defined
    #########################################################################

    # Unit test for method _load to create a new file
    jsonfile._

# Generated at 2022-06-23 09:25:16.950685
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(env={}, ini={}))

# Generated at 2022-06-23 09:25:20.112154
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._timeout == 86400
    assert plugin._connection == '~/.ansible/tmp'

# Generated at 2022-06-23 09:25:23.614749
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test that the cache module can be created with valid parameters
    c = CacheModule({'_uri': 'tests/units/module_utils/files/', '_prefix': 'prefix', '_timeout': 0.01},
                    'jsonfile', 0)
    assert isinstance(c, CacheModule)



# Generated at 2022-06-23 09:25:25.804235
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachemodule = CacheModule()
    # test to make sure _prefix is a valid key for _options
    assert '_prefix' in cachemodule._options.keys()

# Generated at 2022-06-23 09:25:26.809471
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({}, ['localhost'], '')

# Generated at 2022-06-23 09:25:27.375073
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-23 09:25:27.880291
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

# Generated at 2022-06-23 09:25:30.778316
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(None, 'connection', 'prefix', 8640)
    assert cache_module

# Generated at 2022-06-23 09:25:36.530638
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': '', '_prefix': '', '_timeout': '', '_fact_name': '', '_fact_subdir': '', '_per_host': ''})
    assert cache.get_basedir() == ''
    assert cache.get_prefix() == 'ansible_'
    assert cache.get_timeout() == 86400
    assert cache.get_file_extension() == 'json'

# Generated at 2022-06-23 09:25:44.580272
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == BaseFileCacheModule._load
    assert cache._dump == BaseFileCacheModule._dump
    assert cache._load_cache_file == BaseFileCacheModule._load_cache_file
    assert cache._dump_cache_file == BaseFileCacheModule._dump_cache_file
    assert cache._get_cache_filepath == BaseFileCacheModule._get_cache_filepath
    assert cache._delete_cache_file == BaseFileCacheModule._delete_cache_file

# Generated at 2022-06-23 09:25:46.683503
# Unit test for constructor of class CacheModule
def test_CacheModule():
    myCacheModule = CacheModule()
    assert isinstance(myCacheModule,CacheModule)

# Generated at 2022-06-23 09:25:48.935501
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert isinstance(obj, BaseFileCacheModule)


# Generated at 2022-06-23 09:25:57.151819
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import pytest
    from ansible.plugins.cache.jsonfile import CacheModule
    filename = 'myfile'
    filepath = '/path/to/file/'
    file_content = '{\n    "param1": 1, \n    "param2": "two"\n}'
    my_timeout = 200
    my_prefix = 'cache'

    # Mocking the file.
    class mock_file(object):
        def __init__(self, name, mode):
            self.name = name
            self.mode = mode
            self.close_was_called = False
            self.contents = file_content
        def read(self):
            return self.contents
        def write(self, data):
            self.contents = data

# Generated at 2022-06-23 09:25:58.970445
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin is not None

# Generated at 2022-06-23 09:26:01.238918
# Unit test for constructor of class CacheModule
def test_CacheModule():
    h = CacheModule('/tmp/path')
    assert h._connection == '/tmp/path'

# Generated at 2022-06-23 09:26:04.906663
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test for constructor of class CacheModule
    test = CacheModule(task=None, manager=None)
    assert test._timeout == 86400
    assert test._prefix == ''
    assert test._cache == {}
    assert test._files == {}
    assert test._connection == None

# Generated at 2022-06-23 09:26:06.622379
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None


# Generated at 2022-06-23 09:26:11.930713
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    Test the initialization of a CacheModule object
    '''
    plugin = CacheModule()
    assert plugin.cache_type == 'jsonfile'
    assert plugin._timeout == 86400
    assert plugin.cache_initialized
    assert plugin._prefix == 'ansible_facts_cachefile_'
    assert plugin._cache_dir == '~/.ansible/caches/facts'

# Generated at 2022-06-23 09:26:17.133371
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(None)

    assert cache_module.cache_path is None
    assert cache_module.timeout == 86400
    assert cache_module.plugin_name == 'jsonfile'
    assert cache_module.tree == {}
    assert cache_module.lockfile == None
    assert cache_module.cache_lock_timeout == 10


# Generated at 2022-06-23 09:26:23.435816
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # withou connection
    with pytest.raises(SystemExit) as excinfo:
        cache_module = CacheModule()
        assert 'is required' in str(excinfo.value)

    # with connection
    cache_module = CacheModule(connection='_uri')
    assert isinstance(cache_module._timeout, int)
    assert isinstance(cache_module._load, object)
    assert isinstance(cache_module._dump, object)

# Generated at 2022-06-23 09:26:26.948547
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    assert cache.plugin == 'jsonfile'
    assert cache.timeout == 86400
    assert cache.get_basedir() == '~/.ansible/cache'

# Generated at 2022-06-23 09:26:30.772640
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert x._encoder == AnsibleJSONEncoder
    assert x._decoder == AnsibleJSONDecoder
    assert x._extension == 'json'
    assert x._valid_extension == '.json'

# Generated at 2022-06-23 09:26:32.167726
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with pytest.raises(Exception):
        CacheModule()

# Generated at 2022-06-23 09:26:39.463349
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_connection = "/tmp"
    cache_timeout = 1000
    cache_plugin_prefix = "plugin_prefix"
    cache_plugin = CacheModule(cache_plugin_prefix, cache_connection, cache_timeout)
    assert cache_plugin.cache_plugin_prefix == cache_plugin_prefix
    assert cache_plugin.cache_timeout == cache_timeout
    assert cache_plugin.file_extension == ".cache"
    assert cache_plugin.is_valid_cache_path(cache_connection) is True
    assert cache_plugin.cache_path == cache_connection


# Generated at 2022-06-23 09:26:41.069811
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        cachemodule = CacheModule({})
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-23 09:26:46.199001
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache._params, dict)
    assert cache._load('test_dir') is None
    assert cache._dump('test_dir', 'test_dir') is None

# Generated at 2022-06-23 09:26:49.125425
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert(cache._options['_uri'] == '')
    assert(cache._options['_prefix'] == '')
    assert(cache._options['_timeout'] == 86400)

# Generated at 2022-06-23 09:26:56.178015
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._cache_dir == '~/.ansible/tmp'
    assert cache_plugin._prefix == 'ansible-factcache'
    assert cache_plugin._timeout == 86400
    assert cache_plugin.valid is False
    assert cache_plugin.timeout == 86400

# Generated at 2022-06-23 09:26:59.156971
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module



# Generated at 2022-06-23 09:27:01.603056
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create CacheModule object
    cache_module = CacheModule()
    # Check object initialization
    assert isinstance(cache_module, CacheModule)
    # Check if object has _load method
    assert hasattr(cache_module, '_load')
    # Check if object has _dump method
    assert hasattr(cache_module, '_dump')

# Generated at 2022-06-23 09:27:05.588436
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict()) is not None

# Generated at 2022-06-23 09:27:08.369940
# Unit test for constructor of class CacheModule
def test_CacheModule():
    metadata = {'status': 'success'}
    cm = CacheModule(metadata)
    assert cm.cache_plugin_name == 'jsonfile'

# Generated at 2022-06-23 09:27:15.245269
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # # Create an instance of the cache module
    cm = CacheModule()

    # Verify that the correct file format is being used
    assert cm.file_extension == '.json'


# # Unit test for _dump() method

# Generated at 2022-06-23 09:27:18.736426
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

    assert cache_module.cache_type == "jsonfile"
    assert hasattr(cache_module, "_load")
    assert hasattr(cache_module, "_dump")
    assert hasattr(cache_module, "_validate_plugin_config")

# Generated at 2022-06-23 09:27:21.734883
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(plugin_options=dict(_uri='/var/tmp/cache_module'))
    assert cache_module._connection is not None
    assert cache_module._connection.basedir == '/var/tmp'

# Generated at 2022-06-23 09:27:27.213595
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._prefix == 'ansible-facts'
    assert cm._timeout == 86400
    assert cm.valid is False
    assert isinstance(cm._decoder, AnsibleJSONDecoder)
    assert isinstance(cm._encoder, AnsibleJSONEncoder)

# Generated at 2022-06-23 09:27:29.246629
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('/some/fake/path/')
    assert cache._connection == '/some/fake/path/'

# Generated at 2022-06-23 09:27:31.011610
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_plugin = CacheModule()
    assert isinstance(test_plugin, BaseFileCacheModule)


# Generated at 2022-06-23 09:27:33.771774
# Unit test for constructor of class CacheModule
def test_CacheModule():
    Connection = CacheModule('facts')
    assert isinstance(Connection, CacheModule)

# Generated at 2022-06-23 09:27:37.969970
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load("filepath") == json.load("filepath", cls=AnsibleJSONDecoder)
    assert cache._dump("value", "filepath") == json.dumps("value", cls=AnsibleJSONEncoder, sort_keys=True, indent=4)

# Generated at 2022-06-23 09:27:38.812135
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-23 09:27:41.202175
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin.cache_file_extension == '.json'
    assert plugin.cache_file_format == 'json'

# Generated at 2022-06-23 09:27:44.548005
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin
    assert plugin._connection == None
    assert plugin._prefix == 'ansible-retry'
    assert plugin._timeout == 86400


# Generated at 2022-06-23 09:27:56.206617
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

    # private variable '_cache_dir'
    assert cache_module._cache_dir == None, "failed to test _cache_dir"
    # private variable '_cache_prefix'
    assert cache_module._cache_prefix == "ansible_facts", "failed to test _cache_prefix"
    # private variable '_timeout'
    assert cache_module._timeout == 86400, "failed to test _timeout"

    # private variable '_valid_cache'
    assert cache_module._valid_cache == None, "failed to test _valid_cache"

    # private variable '_cache_has_expired'
    assert cache_module._cache_has_expired == None, "failed to test _cache_has_expired"

    # private variable '_valid_cache'
    assert cache_module

# Generated at 2022-06-23 09:27:58.098126
# Unit test for constructor of class CacheModule
def test_CacheModule():

    module = CacheModule()

    assert module is not None

# Generated at 2022-06-23 09:28:09.173442
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("TEST\n")
    cache_plugin_name = 'jsonfile'
    cache_plugin_connection = './'
    cache_plugin_timeout = 30
    cache_plugin_options = {'cache_path': './'}
    cache_module = CacheModule(cache_plugin_name, cache_plugin_connection, cache_plugin_timeout, cache_plugin_options)
    print(cache_module)
    print(dir(cache_module))
    print(cache_module.get_option('cache_path'))
    # ["./", "./", "jsonfile", {'cache_path': './'}, 30, "jsonfile"]

# Generated at 2022-06-23 09:28:09.773477
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule({})

# Generated at 2022-06-23 09:28:21.758096
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    This is a unit test to test the constructor of the class CacheModule in module:
    ansible.plugins.cache.jsonfile

    Additional info is stored in plugin on creation of the object.
    """
    cache_dir = '/root/ansible_cache'
    prefix = 'test_prefix'
    timeout = 3600

    # Call constructor of class CacheModule
    cache_plugin = CacheModule({'_uri': cache_dir, '_prefix': prefix}, timeout)

    # Check that cache_dir, prefix and timeout are stored in self.plugin
    assert cache_plugin.plugin['_uri'] == cache_dir
    assert cache_plugin.plugin['_prefix'] == prefix
    assert cache_plugin.timeout == timeout

# Generated at 2022-06-23 09:28:24.029918
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, BaseFileCacheModule)
    assert cm._timeout == 86400

# Generated at 2022-06-23 09:28:26.327959
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__doc__ == '''\
    A caching module backed by json files.
    '''


# Generated at 2022-06-23 09:28:28.029830
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-23 09:28:33.258232
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plug = CacheModule()
    hasattr(cache_plug, '_load')
    hasattr(cache_plug, '_get')
    hasattr(cache_plug, '_save')
    hasattr(cache_plug, '_delete')
    hasattr(cache_plug, '_dump')
    hasattr(cache_plug, '_load')
    hasattr(cache_plug, '_flush')
    hasattr(cache_plug, 'get')
    hasattr(cache_plug, 'set')
    hasattr(cache_plug, 'keys')
    hasattr(cache_plug, 'contains')
    hasattr(cache_plug, 'delete')
    hasattr(cache_plug, 'flush')
    hasattr(cache_plug, 'copy')



# Generated at 2022-06-23 09:28:34.669516
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, BaseFileCacheModule)

# Generated at 2022-06-23 09:28:35.549838
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict()) is not None

# Generated at 2022-06-23 09:28:39.509925
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mycache = CacheModule(task=None)
    assert 'jsonfile' == mycache._load_name
    assert mycache._connection is None
    assert None == mycache._prefix
    assert 'ANSIBLE_CACHE_PLUGIN_CONNECTION' == mycache._uri_env
    assert 'ANSIBLE_CACHE_PLUGIN_PREFIX' == mycache._prefix_env
    assert mycache._timeout == 86400

# Generated at 2022-06-23 09:28:50.483566
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # let's create dummy ini file, then we will read it
    with open("/tmp/ansible.cfg", 'w') as f:
        f.write("""[defaults]
fact_caching = jsonfile
fact_caching_timeout = 600
fact_caching_connection = /tmp/ansible_facts
fact_caching_prefix = ansible_facts""")
    from ansible.parsing.config.loader import ConfigLoader
    from ansible.plugins.cache.jsonfile import CacheModule
    config = ConfigLoader(None).load('/tmp/ansible.cfg')
    t = CacheModule(None, config, config._sections['defaults'])
    assert t._connection == u'/tmp/ansible_facts'
    assert t._timeout == 600
    assert t._prefix == u'ansible_facts'

# Generated at 2022-06-23 09:28:51.926524
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = '/tmp'
    timeout = 86400
    module = CacheModule(path, timeout)
    assert module.cache_dir == '/tmp'

# Generated at 2022-06-23 09:28:54.181014
# Unit test for constructor of class CacheModule
def test_CacheModule():
    a = CacheModule()
    assert isinstance(a, CacheModule)

# Generated at 2022-06-23 09:28:56.269351
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_obj = CacheModule(task_vars=dict())
    assert test_obj._timeout == 86400, 'Expected 86400, got: {0}'.format(test_obj._timeout)

# Generated at 2022-06-23 09:28:59.483301
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule({'_uri': 'tests/unit/cache/plugin/'})
    assert cache_plugin

# Generated at 2022-06-23 09:29:01.686311
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)


# Generated at 2022-06-23 09:29:07.253137
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._options['_uri'] is None
    assert cache._options['_prefix'] == 'ansible_facts'
    assert cache._options['_timeout'] == 86400
    assert cache._load("foo.json") is None
    assert cache._dump("foo.json") is None

# Generated at 2022-06-23 09:29:10.002455
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(
        _uri='/tmp/ansible-caching',
        _prefix='foo_json',
        _timeout=3600
    ))

# Generated at 2022-06-23 09:29:11.731298
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule()
    assert instance._load == CacheModule._load
    assert instance._dump == CacheModule._dump

# Generated at 2022-06-23 09:29:15.790408
# Unit test for constructor of class CacheModule
def test_CacheModule():
    args = dict()
    args['_uri'] = 'file:///test'
    args['_prefix'] = 'ansible_test'
    args['_timeout'] = '86400'

    cache = CacheModule(args)

    assert cache.url == 'file:///test'
    assert cache._prefix == 'ansible_test'
    assert cache._timeout == 86400
    assert cache.get('test_key') is None

# Generated at 2022-06-23 09:29:18.208143
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(get_config_obj()), BaseFileCacheModule)

# Generated at 2022-06-23 09:29:24.856169
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from types import ModuleType
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    basedir = tempfile.mkdtemp()
    paths = {}

# Generated at 2022-06-23 09:29:34.992886
# Unit test for constructor of class CacheModule
def test_CacheModule():
    loop_count = 10
    file_name = "test_file.json"
    cache_name = "jsonfile"
    cache_plugin_option = {'_uri': '/tmp/'}
    cache_plugin_option.update({'_prefix': 'prefix_'})
    cache_plugin_option.update({'_timeout': 60})

    # Test with saving and reading data
    # 1. Construct an instance of the CacheModule with the cache plugin option.
    cache_module = CacheModule(cache_plugin_option)

    # 2. Save the data in the cache.
    for i in range(0, loop_count):
        cache_module.set(cache_name, file_name, i)

    # 3. Read the data from the cache and check whether it is correct.

# Generated at 2022-06-23 09:29:36.585265
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.CACHE_PLUGIN_NAME == 'jsonfile'

# Generated at 2022-06-23 09:29:41.008900
# Unit test for constructor of class CacheModule
def test_CacheModule():
    encoding = 'utf-8'
    obj = CacheModule()

    # Check if objects are created
    assert obj._load is not None
    assert obj._dump is not None

# Generated at 2022-06-23 09:29:42.534438
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pax = CacheModule()
    assert pax is not None

# Generated at 2022-06-23 09:29:50.085792
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_path = '/test/path/for/cache'
    cache_prefix = 'test_prefix'
    cache_timeout = 86400

    # Test default values
    cm = CacheModule()
    assert cm._connection == '.'
    assert cm._prefix == ''
    assert cm._timeout == 86400

    # Test params
    cm = CacheModule(cache_path, cache_prefix, cache_timeout)
    assert cm._connection == cache_path
    assert cm._prefix == cache_prefix
    assert cm._timeout == cache_timeout

# Generated at 2022-06-23 09:29:59.437217
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.utils.path import unfrackpath
    import tempfile
    temp_dir = tempfile.mkdtemp()
    #create file and save json data
    uri = unfrackpath(temp_dir)
    json_data = {'a':{'b':{'c':1}, 'd':{'e':2}}}
    cache = CacheModule(uri=uri)
    cache._dump(json_data, uri)
    #retrive data from file
    data = cache._load(uri)
    assert json_data['a']['b']['c'] == data['a']['b']['c'] == 1
    assert json_data['a']['d']['e'] == data['a']['d']['e'] == 2

# Generated at 2022-06-23 09:30:01.048715
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule() is not None


# Generated at 2022-06-23 09:30:08.454039
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._connection is None
    assert cache._timeout == 86400
    assert cache._plugin_name == 'jsonfile'
    assert cache._load_name == '_load'
    assert cache._dump_name == '_dump'
    assert cache._load_options == {'encoding': 'utf-8'}
    assert cache._dump_options == {'encoding': 'utf-8'}

# Generated at 2022-06-23 09:30:09.492939
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule("foo")

# Generated at 2022-06-23 09:30:10.476783
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__name__ == 'CacheModule'

# Generated at 2022-06-23 09:30:18.394679
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj.get_cache_size() == 0, ("Expected cache size 0, got %d" % obj.get_cache_size())
    assert obj.get_cache_path(None) is None, ("Expected cache path None, got %s" % obj.get_cache_path(None))
    assert obj.validate_filepath(None) is None, ("Expected None, got %s" % obj.validate_filepath(None))
    assert obj.get_cache_leaf(None) is None, ("Expected None, got %s" % obj.get_cache_leaf(None))


# Generated at 2022-06-23 09:30:21.298298
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        _ = CacheModule()
    except Exception as e:
        assert False, "CacheModule constructor fails: " + str(e)


# Generated at 2022-06-23 09:30:22.533248
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:30:25.253148
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Test constructor"""
    cache = CacheModule({})
    assert cache._timeout == 86400  # pylint: disable=protected-access

# Generated at 2022-06-23 09:30:28.007706
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import CacheModule
    cache_module = CacheModule()
    assert hasattr(cache_module, '_load')
    assert hasattr(cache_module, '_dump')

# Generated at 2022-06-23 09:30:29.841116
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule({'_uri': 'test.cache'})

# Generated at 2022-06-23 09:30:40.740106
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache_module = CacheModule()

    assert(cache_module.get_option('_uri') == '')
    assert(cache_module.get_option('_prefix') == 'ansible_facts')
    assert(cache_module.get_option('_timeout') == 604800)
    
    assert(cache_module.CACHE_PLUGIN_NAME == 'JSON file')
    assert(cache_module.CACHE_PLUGIN_PREFIX == 'ansible_facts')
    assert(cache_module.CACHE_PLUGIN_TIMEOUT == 604800)
    assert(cache_module.CACHE_PLUGIN_CONNECTION == '')

# Generated at 2022-06-23 09:30:44.317863
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj.cache_root is None
    assert obj.timeout == 86400
    assert obj._cache_prefix is None
    assert obj._timeout == 86400

# Generated at 2022-06-23 09:30:46.356885
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    cache._load('filename')
    cache._dump('value', 'filename')

# Generated at 2022-06-23 09:30:47.511778
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()._load('/tmp/test')

# Generated at 2022-06-23 09:30:51.104291
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, "_load")
    assert hasattr(CacheModule, "_dump")
    assert hasattr(CacheModule, "_file_path")
    assert hasattr(CacheModule, "get")
    assert hasattr(CacheModule, "set")

# Generated at 2022-06-23 09:30:53.446415
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

if __name__ == '__main__':
    cm = CacheModule()
    print(cm._load('facts.cache'))

# Generated at 2022-06-23 09:30:55.254635
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache
    assert cache._connection == '/tmp/ansible_fact_cache'
    assert cache._timeout == 86400

# Generated at 2022-06-23 09:30:56.272698
# Unit test for constructor of class CacheModule
def test_CacheModule():
  cm = CacheModule()

# Generated at 2022-06-23 09:30:58.416772
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-23 09:30:59.851363
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__name__ == "CacheModule"

# Generated at 2022-06-23 09:31:04.027758
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, "set_options")
    assert hasattr(CacheModule, "_load")
    assert hasattr(CacheModule, "_dump")
    assert hasattr(CacheModule, "get")

# Generated at 2022-06-23 09:31:09.781648
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with no args
    cache_module = CacheModule()

    assert cache_module.get_extension() == "json"


# Generated at 2022-06-23 09:31:14.738956
# Unit test for constructor of class CacheModule
def test_CacheModule():
    host = 'localhost'
    plugin = CacheModule()
    plugin.set_options()

    cache_file = plugin.get_cache_path(host)
    plugin.set_host_cache(host, {'test': 'test'})
    data = plugin.get_host_cache(host)

    assert host in cache_file
    assert data['test'] == 'test'

# Generated at 2022-06-23 09:31:15.653649
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_obj = CacheModule()

# Generated at 2022-06-23 09:31:18.721634
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout('hostname') == 86400
    assert cache._connection == '$ANSIBLE_CACHE_PLUGIN_CONNECTION'
    assert cache._prefix == '$ANSIBLE_CACHE_PLUGIN_PREFIX'

# Generated at 2022-06-23 09:31:19.176068
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-23 09:31:19.618755
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-23 09:31:20.591932
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'test'})

# Generated at 2022-06-23 09:31:30.752178
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    import os
    import tempfile
    import json
    import codecs
    import shutil

    # Create temporary directory in OS temp folder
    temp_dir = tempfile.mkdtemp()
    # Create temporary file in OS temp folder
    temp_file = tempfile.mkstemp()[1]
    # Create fake data to cache
    fake_data = "This is fake data"
    # Store fake data in cache file
    with codecs.open(temp_file, 'w', encoding='utf-8') as f:
        json.dump(fake_data, f, cls=json.JSONEncoder)
    # Create new CacheModule
    cm = CacheModule()
    cm._load = lambda self, filepath: fake_data

# Generated at 2022-06-23 09:31:33.830285
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule({'_uri': '/tmp/ansible_test_CacheModule_cache_coad'})
    assert obj._connection == '/tmp/ansible_test_CacheModule_cache_coad' and obj._timeout == 86400

# Generated at 2022-06-23 09:31:45.438358
# Unit test for constructor of class CacheModule
def test_CacheModule():
    host_caches_dir = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible-testfile')
    plugin = CacheModule(task_vars={'local_temp': host_caches_dir}, 
        tmp=host_caches_dir, inject=dict(ansible_check_mode=False, ansible_connection='local', ansible_play_hosts=['localhost']))
    pprint(plugin._options)
    assert plugin._connection == os.path.join(host_caches_dir, 'localhost')
    assert plugin._timeout == 86400
    try:
        os.removedirs(host_caches_dir)
    except Exception as e:
        pass

# Generated at 2022-06-23 09:31:47.502453
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_inst = CacheModule()
    assert cache_plugin_inst

# Generated at 2022-06-23 09:31:49.524260
# Unit test for constructor of class CacheModule
def test_CacheModule():
    def dump(value, file_path):
        pass

    instance = CacheModule()
    assert isinstance(instance, CacheModule)
    assert instance._prefix == 'ansible-factcache'
    assert instance._timeout == 86400
    assert instance._dump == dump
    assert instance._load == instance._load

# Generated at 2022-06-23 09:32:01.502636
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    def main():
        import tempfile
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars import VariableManager
        from ansible.inventory.manager import InventoryManager

        loader = DataLoader()
        variable_manager = VariableManager()
        inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
        variable_manager.set_inventory(inventory)

        mycache = CacheModule()

        mycache.set_options({'_uri': tempfile.mkdtemp()})

        mycache.set_task_vars(variable_manager)

        mycache.store('dummyhost', {'foo': 'bar'})
        foo = mycache.get('dummyhost')
        print(foo)

    main()



# Generated at 2022-06-23 09:32:07.651350
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Test constructor of class CacheModule."""
    cache_config = {'_uri': 'test', '_prefix': 'ansible'}
    cache_data = {'cache_key_1': 'cache_value_1', 'cache_key_2': 'cache_value_2'}
    cache_module = CacheModule(cache_config)

    cache_module.flush()
    cache_module.set('cache_key_1', 'cache_value_1')
    cache_module.set('cache_key_2', 'cache_value_2')

    assert cache_module.get('cache_key_1') == 'cache_value_1'
    assert cache_module.get('cache_key_2') == 'cache_value_2'
    assert cache_module.has_key('cache_key_1') is True
   

# Generated at 2022-06-23 09:32:08.983405
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = BaseFileCacheModule()
    assert cache.get('abc', 'def') == None

# Generated at 2022-06-23 09:32:13.138707
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Test constructor, try to instantiate class
    module = CacheModule()

    # Test setting of class variables (see CacheModule class)
    assert module._connection == None

# Generated at 2022-06-23 09:32:15.215911
# Unit test for constructor of class CacheModule
def test_CacheModule():
    myTestClass = CacheModule()
    assert type(myTestClass) is CacheModule
    assert myTestClass.get_cache() is None

# Generated at 2022-06-23 09:32:16.731427
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_obj = CacheModule()
    assert isinstance(cache_module_obj, CacheModule)

# Generated at 2022-06-23 09:32:18.318008
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert isinstance(module, CacheModule), "Object instantiation failed"


# Generated at 2022-06-23 09:32:19.975070
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachemod = CacheModule()
    assert cachemod.get_cache_timeout() == 86400

# Generated at 2022-06-23 09:32:23.392473
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule({'_uri': '/var/tmp', '_timeout': 500}), CacheModule)

# Generated at 2022-06-23 09:32:32.602629
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_connection = '/some/path'
    cache_plugin_prefix = 'random_prefix_'
    cache_plugin_timeout = 86400
    module = CacheModule(cache_plugin_connection, cache_plugin_prefix, cache_plugin_timeout)
    assert module._connection == cache_plugin_connection
    assert module._prefix == cache_plugin_prefix
    assert module._timeout == 86400

if __name__ == '__main__':
    '''Unit tests'''
    import sys
    import os

    dir_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.append("%s/../../../../../" % dir_path)
    sys.path.append("%s/../../" % dir_path)

# Generated at 2022-06-23 09:32:41.849367
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.file_extension == '.cache'
    assert cm.expires == 3600 # In seconds

    cm = CacheModule('ansible/module_dir','module_name')
    assert cm.file_extension == '.cache'
    assert cm.expires == 3600 # In seconds

    cm = CacheModule('ansible/module_dir','module_name','ansible/cache/dir')
    assert cm.file_extension == '.cache'
    assert cm.expires == 3600 # In seconds

# Generated at 2022-06-23 09:32:44.591407
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._connection is None
    assert cache_plugin._prefix == 'ansible_facts_cache_'
    assert cache_plugin._timeout == 86400


# Generated at 2022-06-23 09:32:49.294825
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test initialization of class CacheModule
    from ansible.plugins.cache.jsonfile import CacheModule
    CacheModule(task_vars={})

# Generated at 2022-06-23 09:32:51.021692
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm


# Generated at 2022-06-23 09:32:54.796089
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        c = CacheModule()
    except Exception as e:
        print('Constructor of class CacheModule raised exception: %s' % e)
        assert False

# Generated at 2022-06-23 09:32:55.855748
# Unit test for constructor of class CacheModule
def test_CacheModule():
    chache = CacheModule()
    print(chache)

# Generated at 2022-06-23 09:33:05.695042
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # valid plugin name
    plugin=CacheModule()
    assert plugin._get_plugin_type() == "cache"
    assert plugin._validate_plugin_name('jsonfile') == True
    # invalid plugin name
    assert plugin._validate_plugin_name('jsonfile1') == False
    # valid connection options
    connection_options={'path': '/home/ansible/', 'host': 'localhost'}
    assert plugin._validate_plugin_connection_options(**connection_options) == True
    # valid connection options - relative path
    connection_options={'path': '../', 'host': 'localhost'}
    assert plugin._validate_plugin_connection_options(**connection_options) == True
    # invalid connection options - path
    connection_options={'path': 1, 'host': 'localhost'}
    assert plugin._valid

# Generated at 2022-06-23 09:33:13.844124
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # If a plugin inherits from BaseFileCacheModule it must specify these two attributes
    assert hasattr(CacheModule, '_load')
    assert hasattr(CacheModule, '_dump')
    # If a plugin inherits from BaseFileCacheModule it must use the same additions to CACHE_PLUGIN_CONNECTION
    assert '_uri' in CacheModule._get_cache_option_names()
    assert '_prefix' in CacheModule._get_cache_option_names()
    assert '_timeout' in CacheModule._get_cache_option_names()

# Generated at 2022-06-23 09:33:15.965388
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('test') == None

# Generated at 2022-06-23 09:33:17.192098
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule() != None


# Generated at 2022-06-23 09:33:18.179699
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache

# Generated at 2022-06-23 09:33:23.202975
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Randomly generated environment variable
    env_variable = u"%h\u03b9\u2113\u006a\u0368\u0052\u20b7\u201b\u009b\u00dc"
    test_cache = CacheModule({'ANSIBLE_CACHE_PLUGIN_CONNECTION': env_variable})
    assert test_cache._get_cache_basedir() == env_variable

# Generated at 2022-06-23 09:33:24.839824
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # try to create object of class CacheModule
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-23 09:33:26.059335
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule is not None

# Generated at 2022-06-23 09:33:27.820176
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule(task.args, task.task_vars)
    assert type(cache_plugin) is CacheModule


# Generated at 2022-06-23 09:33:30.798259
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(dict())
    assert cache_module is not None

# Generated at 2022-06-23 09:33:33.456841
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert isinstance(cache_module, CacheModule)
    assert cache_module._timeout == 86400

# Generated at 2022-06-23 09:33:38.379400
# Unit test for constructor of class CacheModule
def test_CacheModule():

    settings = dict(
        _uri='/path/to/module',
        _prefix='testplugin',
        _timeout=86400
    )

    plugin = CacheModule(settings=settings)

    assert plugin.path == settings['_uri']
    assert plugin.prefix == settings['_prefix']
    assert plugin.timeout == settings['_timeout']

# Generated at 2022-06-23 09:33:39.525313
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert True, "Failed to import"

# Generated at 2022-06-23 09:33:40.370545
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()

# Generated at 2022-06-23 09:33:45.778472
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # CacheModule object variables
    FileCacheModule = CacheModule()
    assert FileCacheModule.lock_path == '~/.ansible/tmp'
    assert FileCacheModule._cache_dir == '~/.ansible/cache'
    assert FileCacheModule.default_timeout == 0
    assert FileCacheModule.plugin_name == 'jsonfile'