

# Generated at 2022-06-21 03:44:36.161948
# Unit test for constructor of class CacheModule
def test_CacheModule():
  tmp_dir="/tmp"
  timeout=1
  prefix=""
  cache = CacheModule(tmp_dir, timeout, prefix)
  assert timeout == cache._timeout
  assert prefix == cache._prefix
  assert tmp_dir == cache._connection

# Generated at 2022-06-21 03:44:38.040581
# Unit test for constructor of class CacheModule
def test_CacheModule():
    json_cache = CacheModule()

# Generated at 2022-06-21 03:44:39.443253
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._uri == 'ansible/cache'

# Generated at 2022-06-21 03:44:41.982155
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # If the inputs are given then this will create object of class CacheModule
    cacheModuleObject = CacheModule()

# Generated at 2022-06-21 03:44:45.897762
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    plugin.set_options(dict(path='/tmp/testdir'))
    assert plugin._connection['path'] == '/tmp/testdir'

# Generated at 2022-06-21 03:44:52.210036
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)
    assert cache._cache_dir == '/tmp/ansible-caching-jsonfile-plugin'
    assert cache._timeout == 86400
    assert cache._plugin_name == 'jsonfile'


# Generated at 2022-06-21 03:44:55.596082
# Unit test for constructor of class CacheModule
def test_CacheModule():
	open("test_CacheModule_file.json","w").write("")
	test_cache_module = CacheModule("test_CacheModule_file.json")
	test_cache_module._load("test_CacheModule_file.json")

# Generated at 2022-06-21 03:44:58.233314
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': ''})
    assert CacheModule({'_uri': '', '_prefix': ''})
    assert CacheModule({'_uri': '', '_prefix': '', '_timeout': ''})

# Generated at 2022-06-21 03:44:59.638025
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache

# Generated at 2022-06-21 03:45:02.383504
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = "/var/tmp/ansible-cache/facts"
    prefix = ""
    timeout = 3600

# Generated at 2022-06-21 03:45:08.062538
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = "test"
    prefix = "file"
    timeout = 10

    # Testing cache module
    cache_module = CacheModule(connection, prefix, timeout)
    assert cache_module.connection == connection
    assert cache_module.prefix == prefix
    assert cache_module.timeout == timeout

    # Testing set and access
    # cache_module.set("key","value")
    # assert cache_module.get("key") == "value"

# Generated at 2022-06-21 03:45:10.820176
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'ANSIBLE_CACHE_PLUGIN_CONNECTION': '/tmp/ansible'})

# Generated at 2022-06-21 03:45:19.624745
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule(task_vars={'ansible_facts': {'testvar': 'testval'}}, task_data={'testvar2': 'testval2'},
                    options={}, disable_fact_cache=False)
    assert c.task_data == {'testvar2': 'testval2'}
    assert c.task_vars == {'ansible_facts': {'testvar': 'testval'}}
    assert c.get_options() == {}
    assert c.get_option('neverset') is None
    assert c.get_fact_cache_host_info() == {}

# Generated at 2022-06-21 03:45:22.321313
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('', {}, timeout=10)
    assert type(cache) == CacheModule

# Generated at 2022-06-21 03:45:25.526598
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module, 'test instantiated a new object for CacheModule'
    assert type(cache_module).__name__ == 'CacheModule', 'test returned an object of type CacheModule'

# Generated at 2022-06-21 03:45:27.304904
# Unit test for constructor of class CacheModule
def test_CacheModule():
    myplugin = CacheModule()
    myplugin.get_options()
    myplugin.load()
    myplugin.dump()
    myplugin.clear()

# Generated at 2022-06-21 03:45:28.460299
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-21 03:45:30.421894
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-21 03:45:37.625789
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert isinstance(obj, CacheModule)
    assert isinstance(obj, BaseFileCacheModule)
    assert obj._load(None) is None
    assert obj._dump(None, None) is None
    assert obj.get_file_extension() == 'json'
    assert obj.get_prefix() == 'ansible-factcache'
    assert obj.get_timeout() == 86400
    assert obj._connection is None

# Generated at 2022-06-21 03:45:39.240499
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-21 03:45:43.054265
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c=CacheModule()
    print('Success: CacheModule constructor')


# Generated at 2022-06-21 03:45:46.186615
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)
    assert CacheModule._load == BaseFileCacheModule._load
    assert CacheModule._dump == BaseFileCacheModule._dump

# Generated at 2022-06-21 03:45:47.927053
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# unit test for _load method of class CacheModule

# Generated at 2022-06-21 03:45:56.685197
# Unit test for constructor of class CacheModule
def test_CacheModule():
    hostvars = {u'localhost': {u'facts': {u'system': u'Darwin'}}}
    module = CacheModule()
    module.set_options({'_uri': '/tmp/test/json'})
    module.put('localhost', hostvars['localhost'])
    assert module.get('localhost') == hostvars['localhost']
    module.flush()

# Generated at 2022-06-21 03:46:01.062659
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # 1. no input
    CacheModule()

    # 2. config
    config = {"_uri": "test", "_prefix": "test", "_timeout": "test"}
    CacheModule(config)

# Generated at 2022-06-21 03:46:09.439959
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = new_CacheModule()
    # verify that we got the right class
    assert isinstance(cache, CacheModule), "Cache should be of type 'CacheModule'"

    # default template should use JSON
    assert "json" in cache._BASE_TEMPLATE_NAME, "Base template should include 'json'"

    # custom path should be overridable
    cache = new_CacheModule("/tmp/foobar")
    assert "/tmp/foobar" == cache._get_cache_basedir(), "Cache basedir should be overridable"



# Generated at 2022-06-21 03:46:12.667349
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ca = CacheModule()
    ca._load("test_tmp/test")
    ca._dump("test", "test_tmp/test")

# Generated at 2022-06-21 03:46:13.679034
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # By default, a CacheModule is instantiated
    # and tested.
    CacheModule()

# Generated at 2022-06-21 03:46:16.383263
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ansible_module = CacheModule()
    assert ansible_module.get_extension() == '.json'

# Generated at 2022-06-21 03:46:17.617468
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert dir(cache)

# Generated at 2022-06-21 03:46:25.309413
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    Function to test constructor of class CacheModule
    '''
    cache_module = CacheModule()
    assert cache_module


# Generated at 2022-06-21 03:46:27.127305
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({}, {}) is not None


# Generated at 2022-06-21 03:46:28.438984
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module is not None

# Generated at 2022-06-21 03:46:34.819703
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Tests CacheModule class constructor
    """

    cache_module = CacheModule()
    assert cache_module is not None
    # AnsibleJSONEncoder, AnsibleJSONDecoder
    assert isinstance(cache_module._encoder, AnsibleJSONEncoder)
    assert isinstance(cache_module._decoder, AnsibleJSONDecoder)
    assert cache_module._plugin_name == "jsonfile"
    assert cache_module._ext == ".json"


# Generated at 2022-06-21 03:46:42.962077
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with open('./test_data/test_cache_module.json', 'r') as test_data:
        test_data_json = json.load(test_data)
    cm = CacheModule(test_data_json)
    assert cm.plugin == 'jsonfile'
    assert cm.plugin_path == './test_data/my_cachedir'
    assert cm.plugin_prefix == 'ansible_facts'
    assert cm.plugin_timeout == 7200
    print('Constructor of class CacheModule passed')


# Generated at 2022-06-21 03:46:45.204692
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''Unit test for CacheModule constructor'''
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-21 03:46:47.678870
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule('/tmp', '', 86400)
    assert module.cache_plugin_name == 'jsonfile'
    assert module.get_file_extension() == '.json'

# Generated at 2022-06-21 03:46:48.784066
# Unit test for constructor of class CacheModule
def test_CacheModule():
    conn = CacheModule()
    assert conn is not None

# Generated at 2022-06-21 03:46:49.876526
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)

# Generated at 2022-06-21 03:46:53.583674
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, object)


# Generated at 2022-06-21 03:47:08.471132
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ''' instantiate the plugin '''
    p = CacheModule()

    assert p._prefix == 'ansible_fact_cache'
    assert p._timeout == 86400
    assert p._connection is None

# Generated at 2022-06-21 03:47:10.469813
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# vim: set et ts=4 sw=4:

# Generated at 2022-06-21 03:47:18.151063
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()

    # Defaults
    assert cache_plugin.get_option('_prefix') is None
    assert cache_plugin.get_option('_uri') == ''
    assert cache_plugin._timeout == 86400

    # Set values
    prefix = 'test_prefix'
    uri = '/test/path'
    timeout = 3600

    cache_plugin.set_options({'_prefix': prefix, '_uri': uri, '_timeout': timeout})
    assert cache_plugin.get_option('_prefix') == prefix
    assert cache_plugin.get_option('_uri') == uri
    assert cache_plugin._timeout == timeout

# Generated at 2022-06-21 03:47:20.540115
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._load == CacheModule._load
    assert cache_plugin._dump == CacheModule._dump

# Generated at 2022-06-21 03:47:21.594462
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule('/path', 'prefix-')

# Generated at 2022-06-21 03:47:22.506958
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-21 03:47:25.963180
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule({'_uri': '/path/to/plugin'})
    assert cm.plugin_name == 'jsonfile'
    assert cm._load('__main__') is not None
    assert cm._dump({}, '__main__') is None

# Generated at 2022-06-21 03:47:35.880383
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # create object of class CacheModule
    cache = CacheModule({})

    # set expected attributes
    cache.cache = {}
    cache.cache_max_age = 86400
    cache.cache_name = u"ansible-jsonfile"
    cache.cache_lock = None
    cache.cache_lock_timeout = None
    cache.cache_plugin_timeout = None

    # create object of class AnsibleJSONEncoder
    cache.AnsibleJSONEncoder = AnsibleJSONEncoder

    # create object of class AnsibleJSONDecoder
    cache.AnsibleJSONDecoder = AnsibleJSONDecoder

    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-21 03:47:38.503875
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule("uri", "prefix", "timeout")

    assert cache.plugin_name == "jsonfile"
    assert cache._timeout == "timeout"
    assert cache._base_path == "uri"
    assert cache._prefix == "prefix"

# Generated at 2022-06-21 03:47:39.287318
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-21 03:48:07.815193
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._timeout == 86400
    plugin = CacheModule(timeout=600)
    assert plugin._timeout == 600

# Generated at 2022-06-21 03:48:16.622314
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Constructor of class CacheModule
    """
    data_to_write = {"a":1, "b":2}
    data_expected = {"a":1, "b":2}
    # Without passing any argument
    cache = CacheModule()
    # For _load
    cache._load()
    # For _dump
    cache._dump(data_to_write)
    # With passing the argument
    cache = CacheModule(['/etc/ansible/facts'])
    cache.set('host1', data_to_write, timeout=86500)
    assert cache.get('host1') == data_expected
    cache.flush()
    assert cache.get('host1') is None

# Generated at 2022-06-21 03:48:28.263457
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.loader import cache_loader
    from ansible.module_utils._text import to_text

    # Get an instance of CacheModule
    plugin = cache_loader.get('fact_caching', 'jsonfile', {})
    # Make sure that it is an instance of CacheModule
    assert isinstance(plugin, CacheModule)

    # Set a random name for the file to test. We dont want to overwrite a real file.
    plugin._connection._uri = './test.json'

    value = {u'a': u'b'}

    # Test set method
    plugin.set(u'test', value)

    # Test get method
    assert value == plugin.get(u'test')

    # Test contains method
    assert plugin.contains(u'test')

    # Test delete method
    # We have to first

# Generated at 2022-06-21 03:48:30.422814
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_cache_prefix() == "ansible_facts"

# Generated at 2022-06-21 03:48:31.321616
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-21 03:48:37.712831
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Tests for CacheModule constructor with default values
    file_cache = CacheModule()
    assert file_cache._connection == '$HOME/.ansible/cache'
    assert file_cache._options['timeout'] == 86400
    # Tests for CacheModule constructor with custom values
    file_cache = CacheModule(timeout=999)
    assert file_cache._options['timeout'] == 999

# Generated at 2022-06-21 03:48:42.880618
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert hasattr(cache_plugin, '_load')
    assert hasattr(cache_plugin, '_dump')
    assert hasattr(cache_plugin, 'get')
    assert hasattr(cache_plugin, 'set')
    assert hasattr(cache_plugin, 'keys')
    assert hasattr(cache_plugin, 'contains')


# Generated at 2022-06-21 03:48:43.648724
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-21 03:48:44.192936
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()

# Generated at 2022-06-21 03:48:50.198080
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    # Passing a path that doesn't exist will cause the base class to raise
    # an exception.
    test_path = tempfile.mkdtemp()
    test_CacheModule = CacheModule({'_uri': test_path})
    test_CacheModule = CacheModule({'_uri': '/nonexistent_dir',
                                    '_prefix': 'ansible-test-prefix',
                                    '_timeout': 145000})

# Generated at 2022-06-21 03:49:50.840272
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule({'_uri': '/var/tmp', '_timeout': 10})
    assert module._timeout == 10
    assert module.plugin_name == 'jsonfile'

# Generated at 2022-06-21 03:49:52.370395
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule(task=None, blow=False, timeout=100)
    assert c._timeout == 100

# Generated at 2022-06-21 03:49:53.477849
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert isinstance(obj, CacheModule)

# Generated at 2022-06-21 03:49:54.857459
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # CacheModule constructor
    assert callable(CacheModule)


# Generated at 2022-06-21 03:49:55.751973
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert callable(CacheModule)

# Generated at 2022-06-21 03:49:56.318968
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

# Generated at 2022-06-21 03:50:01.712160
# Unit test for constructor of class CacheModule
def test_CacheModule():
    config = {}
    config["_uri"] = "jsonfile"
    config["_prefix"] = None
    config["_timeout"] = 86400
    testCacheModule = CacheModule(config)
    assert testCacheModule._connection == "jsonfile"
    assert testCacheModule._prefix is None
    assert testCacheModule._timeout == 86400
    assert testCacheModule.keys == {}

# Generated at 2022-06-21 03:50:11.601091
# Unit test for constructor of class CacheModule
def test_CacheModule():
    the_CacheModule = CacheModule()
    assert the_CacheModule.__doc__ == CacheModule.__doc__, "the_CacheModule.__doc__: %s, CacheModule.__doc__: %s" % (the_CacheModule.__doc__, CacheModule.__doc__)
    assert the_CacheModule._load.__doc__ == CacheModule._load.__doc__, "the_CacheModule._load.__doc__: %s, CacheModule._load.__doc__: %s" % (the_CacheModule._load.__doc__, CacheModule._load.__doc__)

# Generated at 2022-06-21 03:50:12.401474
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert not CacheModule.__name__ == 'CacheModule'

# Generated at 2022-06-21 03:50:14.401298
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # pylint: disable=unused-argument, unused-variable
    plugin = CacheModule({}, {}, {})
    assert isinstance(plugin, CacheModule)
    print('Success: CacheModule constructor')

# Generated at 2022-06-21 03:52:26.392866
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()    
    assert cache_plugin is not None


# Generated at 2022-06-21 03:52:29.060239
# Unit test for constructor of class CacheModule
def test_CacheModule():
    my_dict = {'1': '1', '2': '2'}
    cache = CacheModule(my_dict, 'my_dir', 'my_prefix', 3600)
    assert '1' in cache
    assert '2' in cache

    return cache


# Generated at 2022-06-21 03:52:38.639001
# Unit test for constructor of class CacheModule
def test_CacheModule():
    #print("Test: test_CacheModule")
    #settings
    setting = {'_prefix': 'some_prefix', '_timeout': '86400', '_uri': './'}
    #create instance
    testobj = CacheModule(setting)
    assert setting == testobj.get_settings(), "get_settings() returns wrong settings"
    #create temp file
    testfilename = "test_CacheModule.json"
    testobj.set(testfilename, {"Key1": "val1", "nested": {"x": "y"}})
    #read temp file
    result = testobj.get(testfilename)
    assert result == {"Key1": "val1", "nested": {"x": "y"}}, "get() returns wrong data"
    #delete temp file
    testobj.delete(testfilename)

# Generated at 2022-06-21 03:52:43.475008
# Unit test for constructor of class CacheModule
def test_CacheModule():
    config = dict(
        _prefix='prefix',
        _uri='/tmp/',
        _timeout='86400')
    cache = CacheModule(config)
    assert cache._prefix == 'prefix'
    assert cache._uri == '/tmp/'
    assert cache._timeout == 86400
    assert cache.get_basedir() == '/tmp/'

# Generated at 2022-06-21 03:52:49.252528
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert(not cache.validate_plugin_option("_timeout", "abc"))
    assert(cache.validate_plugin_option("_timeout", "1"))
    assert(not cache.validate_plugin_option("_timeout", "-1"))
    assert(not cache.validate_plugin_option("_timeout", "0"))
    assert(cache.validate_plugin_option("_timeout", "1.5"))
    assert(not cache.validate_plugin_option("_timeout", "-1.5"))

# Generated at 2022-06-21 03:52:50.541847
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Constructor test
    testobj = CacheModule()
    assert testobj is not None

# Generated at 2022-06-21 03:52:51.630519
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())==CacheModule(dict())

# Generated at 2022-06-21 03:52:53.808984
# Unit test for constructor of class CacheModule
def test_CacheModule():
    #Backward compatibility test
    from ansible.plugins.cache.jsonfile import CacheModule
    CacheModule({})

# Generated at 2022-06-21 03:52:54.872007
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module is not None

# Generated at 2022-06-21 03:52:59.031745
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module_path = 'ansible.plugins.cache.jsonfile'
    uri = '~/.ansible/tmp/facts'
    timeout = 86400
    cm = CacheModule(module_path, uri, timeout)
    assert cm.path == uri
    assert cm.timeout == timeout

