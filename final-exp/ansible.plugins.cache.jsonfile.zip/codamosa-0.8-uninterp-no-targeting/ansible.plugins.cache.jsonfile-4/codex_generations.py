

# Generated at 2022-06-21 03:44:35.811827
# Unit test for constructor of class CacheModule
def test_CacheModule():
    return CacheModule({'ANSIBLE_CACHE_PLUGIN_CONNECTION': 'test_uri'})

# Generated at 2022-06-21 03:44:42.791136
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._prefix == "ansible_facts"
    assert cache_plugin._timeout == 86400
    assert cache_plugin._uri == "~/.ansible/tmp"

    try:
        os.mkdir(cache_plugin._uri)
    except:
        pass

    assert os.path.exists(cache_plugin._uri)
    assert cache_plugin._load("unittest") == {}

    json_dict = {'k1': 'v1'}
    assert cache_plugin._load("unittest") == json_dict

    cache_plugin._validate_cache(".unittest")
    assert cache_plugin._load("unittest") == json_dict

    os.remove(".unittest")

# Generated at 2022-06-21 03:44:46.310502
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    cm.set_options({'_uri':'test'})
    assert cm.get_options()['_uri'] == 'test'

# Generated at 2022-06-21 03:44:47.801061
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._connection is None

# Generated at 2022-06-21 03:44:54.836885
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_class = CacheModule(None, task_vars=dict(ANSIBLE_CACHE_PLUGIN_CONNECTION='/myconnection', ANSIBLE_CACHE_PLUGIN_TIMEOUT=1000))
    assert cache_plugin_class.cache._uri == '/myconnection'
    assert cache_plugin_class.cache._timeout == 1000



# Generated at 2022-06-21 03:45:06.450079
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Initialize a cache plugin object
    p = CacheModule()
    assert p.is_valid() == True

    # Set prefix to test
    p._prefix = 'test_prefix'
    p.set_options({'_prefix': p._prefix})

    # Set timeout to test
    p._timeout = 100
    p.set_options({'_timeout': p._timeout})

    # Set uri to test
    p._uri = '/tmp'
    p.set_options({'_uri': p._uri})

    # Validate methods
    p.get('test_key')
    p.set('test_key', 'test_value')
    p.keys()

# Generated at 2022-06-21 03:45:09.544247
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj.get_cache_prefix() is None
    assert obj.get_cache_timeout() == 86400

# Generated at 2022-06-21 03:45:19.662187
# Unit test for constructor of class CacheModule
def test_CacheModule():
    files_dir = "./test"
    timeout = 86400
    plugin = CacheModule(files_dir, timeout)
    assert plugin.file_extension == '.cache'
    assert plugin.file_name_format == '{0}/ansible_{1}_{2}_{3}_' + plugin.file_extension
    
    cache = {'hello': "world"}
    plugin._save_cache(cache, 'localhost', 'facts', '/ansible/caching/json')
    print(plugin._load_cache(cache, 'localhost', 'facts', '/ansible/caching/json'))

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-21 03:45:26.732569
# Unit test for constructor of class CacheModule
def test_CacheModule():

    from ansible.plugins.cache import BaseFileCacheModule

    # Create a new CacheModule using the constructor
    cm = CacheModule()

    # Check if the created object is instance of BaseFileCacheModule
    assert isinstance(cm, BaseFileCacheModule)

    # Check if the created object is instance of CacheModule
    assert isinstance(cm, CacheModule)

# Special test for the method _load of CacheModule

# Generated at 2022-06-21 03:45:29.439783
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-21 03:45:33.382983
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._cache_path == '/tmp/ansible_fact_cache'

# Generated at 2022-06-21 03:45:41.826531
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    This function tests the constructor of the class `CacheModule`
    """
    from ansible.plugins.cache.jsonfile import CacheModule
    cache = CacheModule()
    assert cache._load == BaseFileCacheModule._load
    assert cache._dump == BaseFileCacheModule._dump
    assert cache.get == BaseFileCacheModule.get
    assert cache.set == BaseFileCacheModule.set
    assert cache.keys == BaseFileCacheModule.keys
    assert cache.contains == BaseFileCacheModule.contains
    assert cache.delete == BaseFileCacheModule.delete
    assert cache.flush == BaseFileCacheModule.flush
    assert cache._get_file_path_for_host == BaseFileCacheModule._get_file_path_for_host

# Generated at 2022-06-21 03:45:42.304822
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-21 03:45:47.690191
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule('/tmp/foo', 'test')
    assert c.cache_key == '/tmp/foo/test'
    assert c.timeout == 86400
    assert c.expire == 86400

    c = CacheModule('/tmp/foo', 'test', 2)
    assert c.cache_key == '/tmp/foo/test'
    assert c.timeout == 2
    assert c.expire == 2

# Generated at 2022-06-21 03:45:51.180197
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = CacheModule()
    assert data is not None

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-21 03:45:56.643174
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m.supports_multiple is False
    assert m.extension == '.json'
    assert m.cache_version is None
    assert m.cache_key_letter is None

# Generated at 2022-06-21 03:46:07.743451
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test if module can create an object.
    # Test if plugin_name is set to default value.
    # Test if file_extension is set to default value.
    # Test if timeout is set to default value.
    # Test if plugin_timeout is set to default value.
    # Test if plugin_prefix is set to default value.
    # Test if plugin_connection is set to default value.
    CacheModule()


if __name__ == '__main__':
    # Unit test code should run in stand alone mode.
    # If run within an ansible module, the parameters 'path', 'key', and
    # 'value' are required.
    test_CacheModule()

# Generated at 2022-06-21 03:46:10.514868
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-21 03:46:11.908440
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    print(c)

# Generated at 2022-06-21 03:46:15.774841
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('test_path')
    assert cache._timeout == 86400
    assert cache._encoding == 'utf-8'
    assert cache._prefix == ''


# Generated at 2022-06-21 03:46:19.569687
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(None, 'cache_module')
    assert cache_module is not None

# Generated at 2022-06-21 03:46:21.290812
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(
        dict(
            _uri='/tmp',
        )
    )

# Generated at 2022-06-21 03:46:30.953959
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.loader import cache_loader

    conn = {}
    prefix = None
    timeout = 86400

    cm = cache_loader.get(
        'jsonfile',
        conn=conn,
        prefix=prefix,
        timeout=timeout,
    )
    assert isinstance(cm, CacheModule)
    assert cm.get_options() == dict(
        _uri=conn,
        _prefix=prefix,
        _timeout=timeout,
    )
    assert isinstance(cm._conn, dict)
    assert cm._prefix == prefix
    assert cm._timeout == timeout
    assert cm._valid_con_types is None
    assert cm.get_valid_types() == 'fact,file,plugin'

# Generated at 2022-06-21 03:46:32.757288
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(task_vars={})
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-21 03:46:34.819555
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_root == '/tmp/ansible'
    assert cache.cache_timeout == 86400

# Generated at 2022-06-21 03:46:42.530980
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

# Generated at 2022-06-21 03:46:43.386306
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-21 03:46:47.037462
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._options['_prefix'] == ''
    assert cache._options['_timeout'] == 86400
    assert cache._options['_files'] == []
    assert cache._file_suffix == '.cache'

# Generated at 2022-06-21 03:46:47.799953
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

# Generated at 2022-06-21 03:46:48.594617
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # TODO
    assert False

# Generated at 2022-06-21 03:46:54.102850
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(runner=None, _uri='/tmp/facts', _prefix='prefix', _timeout=86400)
    assert cache_module._timeout == 86400

# Generated at 2022-06-21 03:46:56.133555
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Constructor test:
    """
    cache_plugin = CacheModule()

# Generated at 2022-06-21 03:46:58.280149
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-21 03:47:00.369933
# Unit test for constructor of class CacheModule
def test_CacheModule():
    temp_file = "/tmp/ansible_fact_caching_plugin"
    cache = CacheModule(temp_file)
    cache.flush()

# Generated at 2022-06-21 03:47:01.355888
# Unit test for constructor of class CacheModule
def test_CacheModule():
  assert CacheModule is not None

# Generated at 2022-06-21 03:47:02.857479
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-21 03:47:13.657104
# Unit test for constructor of class CacheModule
def test_CacheModule():
    config_data = {
        "cache_plugin": "jsonfile",
        "cache_plugin_timeout": "86400",
        "cache_plugin_connection": "/home/vagrant/zzz",
        "cache_plugin_prefix": "ansible_facts"
    }

    cache = CacheModule('setup', config_data)
    assert cache.plugin_name == "jsonfile"
    assert cache.plugin_timeout == "86400"
    assert cache.plugin_connection == "/home/vagrant/zzz"
    assert cache.plugin_prefix == "ansible_facts"

# Generated at 2022-06-21 03:47:15.054606
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Unit test for constructor of class CacheModule."""
    cache = CacheModule()
    assert cache is not None


# Generated at 2022-06-21 03:47:17.263901
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    cache_plugin = CacheModule()
    assert isinstance(cache_plugin, CacheModule)

# Generated at 2022-06-21 03:47:18.742210
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_obj = CacheModule()
    assert test_obj._load('/tmp/') == None

# Generated at 2022-06-21 03:47:25.675214
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m is not None

# Generated at 2022-06-21 03:47:28.805498
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert(cache_module._timeout == 86400)
    assert(cache_module._prefix == None)
    assert(cache_module._load == None)

# Generated at 2022-06-21 03:47:29.447085
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-21 03:47:34.036544
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test for constructor of class CacheModule
    # Test for parameter _uri and _prefix
    cache = CacheModule('/tmp/cache', 'test-', 3600)
    assert cache._connection == '/tmp/cache/'
    assert cache._prefix == 'test-'
    assert cache._timeout == 3600

# Generated at 2022-06-21 03:47:35.540991
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert(x is not None)

# Generated at 2022-06-21 03:47:37.028571
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert isinstance(cache_plugin, BaseFileCacheModule)

# Generated at 2022-06-21 03:47:40.784698
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule('test/test_dir', 'test/test_dir_prefix', 'test_timeout')
    assert cm._connection.replace('\\', '/') == cm._plugin_path.replace('\\', '/') + '/test/test_dir'
    assert cm._prefix == 'test/test_dir_prefix'
    assert cm._timeout == 'test_timeout'

# Generated at 2022-06-21 03:47:50.987062
# Unit test for constructor of class CacheModule
def test_CacheModule():
    class Options(object):
        def __init__(self, plugin_name=None, connection=None, timeout=None, prefix=None):
            self.plugin_name = plugin_name
            self.connection = connection
            self.timeout = timeout
            self.prefix = prefix

    class PlayContext(object):
        def __init__(self, remote_addr=None):
            self.remote_addr = remote_addr

    class Connection(object):
        def __init__(self, play_context=None, remote_addr=None):
            self.play_context = play_context
            self.remote_addr = remote_addr

    def get_option(self, option):
        if option in self.values:
            return self.values[option]
        else:
            return None


# Generated at 2022-06-21 03:47:55.766362
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # test without args
    cache_module = CacheModule()
    assert cache_module is not None

    # test with args
    cache_module = CacheModule({
        '_uri': '/test/test2'
    })
    assert cache_module._uri == '/test/test2'

# Generated at 2022-06-21 03:48:00.891146
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_uri = "/path/to/my/cache"
    test_prefix = "my_prefix"
    test_timeout = 300
    cache_module_test = CacheModule(uri=test_uri, prefix=test_prefix, timeout=test_timeout)
    assert cache_module_test._uri == test_uri, "URI mismatch"
    assert cache_module_test._prefix == test_prefix, "Prefix mismatch"
    assert cache_module_test._timeout == test_timeout, "Timeout mismatch"


# Generated at 2022-06-21 03:48:13.589564
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    print(obj)

# Generated at 2022-06-21 03:48:18.873054
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module_uri = "/tmp/some_uri"
    module_prefix = "some_prefix"
    module_timeout = 123
    cache_module = CacheModule(module_uri=module_uri, module_prefix=module_prefix, module_timeout=module_timeout)
    assert cache_module.module_uri == module_uri
    assert cache_module.module_prefix == module_prefix
    assert cache_module.module_timeout == module_timeout

# Generated at 2022-06-21 03:48:25.286728
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = '/tmp/ansible_facts'
    plugin = CacheModule(connection, 'plugin_prefix', 3600)
    isinstance(plugin, CacheModule)
    assert plugin._timeout == 3600
    assert plugin._connection == '%s/ansible_facts'  % connection
    assert plugin._cache == {}

# Generated at 2022-06-21 03:48:30.814616
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # CacheModule is a class
    assert hasattr(CacheModule, '__init__')
    # CacheModule is a type
    assert isinstance(CacheModule(), object)
    # CacheModule is BaseFileCacheModule
    assert isinstance(CacheModule(), BaseFileCacheModule)
    # CacheModule has a _load method
    assert hasattr(CacheModule(), '_load')
    # CacheModule has a _dump method
    assert hasattr(CacheModule(), '_dump')



# Generated at 2022-06-21 03:48:33.340670
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert isinstance(module, CacheModule)

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-21 03:48:37.056190
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_obj = CacheModule()

    assert(hasattr(cache_obj, 'get'))
    assert(hasattr(cache_obj, 'set'))
    assert(cache_obj.SUBDIR == 'facts')

# Generated at 2022-06-21 03:48:39.809384
# Unit test for constructor of class CacheModule
def test_CacheModule():
    json_file_path = "/path/to/cache/file"
    cache_timeout = 60
    cache_prefix = "my_prefix"
    cm = CacheModule({'_timeout': cache_timeout, '_prefix': cache_prefix, '_uri': json_file_path})

    assert cm._timeout == cache_timeout
    assert cm._prefix == cache_prefix
    assert cm._connection == json_file_path
    assert cm._file_extension == 'json'



# Generated at 2022-06-21 03:48:41.209923
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module is not None


# Generated at 2022-06-21 03:48:42.187628
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-21 03:48:48.142092
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # pylint: disable=unused-variable
    prefix = 'test'
    conn = 'conn'
    timeout = 'timeout'
    cache_plugin = CacheModule(prefix, conn, timeout)

    cache_plugin.get('test')
    cache_plugin.set('test', 'test')
    cache_plugin._load('test')
    cache_plugin._dump('test', 'test')
    cache_plugin.keys()

# Generated at 2022-06-21 03:49:25.170286
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cacheModule = CacheModule(None, task_uuid='test', vary_by=None)

    assert cacheModule.name == 'jsonfile'
    assert cacheModule.task_uuid == 'test'
    assert cacheModule.vary_by == None
    assert cacheModule.use_cache == True
    assert cacheModule.tree == None
    assert cacheModule.valid == False
    assert cacheModule.cache_items == {}
    assert cacheModule.data_size == 0
    assert cacheModule.file_path == None
    assert cacheModule.plugin_timeout == 86400
    assert cacheModule.plugin_prefix == ''
    assert cacheModule.content == None
    assert cacheModule.full_vary_by == {}
    assert cacheModule.expiration == None
    assert cacheModule.is_valid_lock_acquired == True

    assert cache

# Generated at 2022-06-21 03:49:26.258567
# Unit test for constructor of class CacheModule
def test_CacheModule():
    my_cachemodule = CacheModule()
    assert my_cachemodule._get_cache_prefix() == 'ansible_facts'

# Generated at 2022-06-21 03:49:30.996902
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Basic constructor test.
    """
    cache = CacheModule({'_uri': 'memory://', '_prefix': 'foo'})

    assert cache.timeout == 86400
    assert cache._connection == 'memory://'
    assert cache._prefix == 'foo'

# Generated at 2022-06-21 03:49:34.649884
# Unit test for constructor of class CacheModule
def test_CacheModule():
  # test init
  cache_plugin_connection = '.'
  cache_plugin_timeout = 60
  cache_plugin_prefix = 'custom_prefix'
  cache = CacheModule(cache_plugin_connection, cache_plugin_timeout, cache_plugin_prefix)

  # test set_data
  set_data_result = cache.set_data('some_key', 'some_value')
  assert set_data_result is True

  # test get_data
  get_data_result = cache.get_data('some_key')
  assert get_data_result == 'some_value'

# Generated at 2022-06-21 03:49:38.085595
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    my_dict = {'1':'2'}
    cache.set('key_1', my_dict)
    new_val = cache.get('key_1')
    assert new_val == my_dict

# Generated at 2022-06-21 03:49:44.962208
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert hasattr(cache_plugin, "_load")
    assert hasattr(cache_plugin, "_dump")
    assert hasattr(cache_plugin, "get")
    assert hasattr(cache_plugin, "set")
    assert hasattr(cache_plugin, "keys")
    assert hasattr(cache_plugin, "contains")
    assert hasattr(cache_plugin, "delete")
    assert hasattr(cache_plugin, "flush")



# Generated at 2022-06-21 03:49:48.108196
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin.get_cache_timeout == 86400
    assert plugin.configuration == {'_timeout': 86400}
    assert plugin.cache_plugin_name is not None

# Generated at 2022-06-21 03:49:52.941626
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    cache_connection = tempfile.mkdtemp()
    cache_plugin = CacheModule({'_uri': cache_connection, '_prefix': 'TestCacheModule'})
    cache_plugin.set('key1', 'value1')
    cache_plugin.set('key2', 'value2')
    assert cache_plugin.get('key1') == 'value1'
    assert cache_plugin.get('key2') == 'value2'

# Generated at 2022-06-21 03:49:58.916896
# Unit test for constructor of class CacheModule
def test_CacheModule():
    class DummyModule:
        def __init__(self):
            self.params = dict()
            self.params['_uri'] = 'root/test'
            self.params['_prefix'] = 'tac'
            self.params['_timeout'] = 100
    dm = DummyModule()
    t = CacheModule(dm)
    assert t._connection == 'root/test'
    assert t._prefix == 'tac'
    assert t._timeout == 100

# Generated at 2022-06-21 03:50:01.988383
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert '_timeout' in cm._config.__dict__
    assert '_uri' in cm._config.__dict__
    assert '_prefix' in cm._config.__dict__

# Generated at 2022-06-21 03:51:03.486757
# Unit test for constructor of class CacheModule
def test_CacheModule():
     cache = CacheModule()
     assert cache is not None

# Generated at 2022-06-21 03:51:04.381674
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("TESTING constructor")
    cache = CacheModule()
    print(cache)

# Generated at 2022-06-21 03:51:07.468115
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create instance of class CacheModule
    obj = CacheModule()
    # call methods of import class to ensure there are no errors
    obj.get('key')
    obj.set('key', 'val')

# Generated at 2022-06-21 03:51:09.421876
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._timeout == 86400

# Generated at 2022-06-21 03:51:09.765660
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-21 03:51:11.042055
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._prefix == 'ansible-cache'

# Generated at 2022-06-21 03:51:14.519844
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.cache_key_name() == 'ansible-cache'
    assert c.get_cache_path() == '/var/tmp/ansible_test_cache'
    assert c.get_cache_path() == '/var/tmp/ansible_test_cache'

# Generated at 2022-06-21 03:51:15.147403
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache_module = CacheModule()
    assert cache_module

# Generated at 2022-06-21 03:51:16.354024
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert isinstance(module, CacheModule)

# Generated at 2022-06-21 03:51:17.543936
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print(CacheModule('/tmp'))

# Generated at 2022-06-21 03:53:32.502725
# Unit test for constructor of class CacheModule
def test_CacheModule():
  module = CacheModule()
  assert type(module) == CacheModule

# Generated at 2022-06-21 03:53:36.026140
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create instance of class CacheModule
    o = CacheModule()
    assert o is not None

    # Get the name of the class
    cls = type(o)
    assert cls is not None
    assert cls.__name__ == 'CacheModule'

    # Get the module docstring
    doc = repr(cls.__doc__)
    assert doc is not None
    assert doc != 'None'
    assert len(doc) > 0

# Generated at 2022-06-21 03:53:38.738132
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        assert isinstance(CacheModule(None), CacheModule)
    except AssertionError:
        print("Error: CacheModule initialization failed.")


# Generated at 2022-06-21 03:53:39.535324
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

# Generated at 2022-06-21 03:53:40.800274
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(None)
    assert cache._timeout == 86400

# Generated at 2022-06-21 03:53:42.674568
# Unit test for constructor of class CacheModule
def test_CacheModule():
    modules = CacheModule(task_vars=dict(GATHERING_DATA='test'))
    assert modules is not None

# Generated at 2022-06-21 03:53:44.351958
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._load is not None
    assert cm._dump is not None

# Generated at 2022-06-21 03:53:46.565669
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, BaseFileCacheModule)

# Generated at 2022-06-21 03:53:50.640434
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = '/tmp'
    timeout = 7200
    prefix = 'cachetest'
    cache = CacheModule(connection=connection, timeout=timeout, prefix=prefix)
    assert cache.plugin_name == 'jsonfile'
    assert cache._connection == '/tmp'
    assert cache._timeout == 7200
    assert cache._prefix == 'cachetest'

# Generated at 2022-06-21 03:53:53.612112
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cfg = dict()
    c = CacheModule(cfg)
    assert c._cache is not None
    assert cfg == dict()