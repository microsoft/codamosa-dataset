

# Generated at 2022-06-21 03:44:35.529537
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.file_extension == '.cache'

# Generated at 2022-06-21 03:44:38.040738
# Unit test for constructor of class CacheModule
def test_CacheModule():
    inst = CacheModule()
    assert inst is not None


# Generated at 2022-06-21 03:44:44.516789
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache = CacheModule()
    assert cache._plugin_name == 'JSON file'
    assert cache.cache_plugin_timeout == 86400

    cache = CacheModule(timeout=3600)
    assert cache._plugin_name == 'JSON file'
    assert cache.cache_plugin_timeout == 3600

    cache = CacheModule(timeout='600')
    assert cache._plugin_name == 'JSON file'
    assert cache.cache_plugin_timeout == 600

    cache = CacheModule(timeout='600')
    assert cache._plugin_name == 'JSON file'
    assert cache.cache_plugin_timeout == 600

    # Test _load method
    test_cachefile = '/tmp/test.json'

# Generated at 2022-06-21 03:44:45.485704
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-21 03:44:51.047543
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert isinstance(cache_plugin, CacheModule)
    assert cache_plugin._connection == 'runs/'
    assert cache_plugin._prefix == 'ansible_facts'
    assert cache_plugin._timeout == 86400

# Generated at 2022-06-21 03:44:53.580288
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''Constructor of class CacheModule'''
    cache = CacheModule(task_vars={}, tmp=None)
    assert cache._load
    assert cache._dump

# Generated at 2022-06-21 03:44:55.767750
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(plugin_name = 'test_cache')
    assert(cache._cache_dir == '~/.ansible/test_cache')

# Generated at 2022-06-21 03:44:56.547464
# Unit test for constructor of class CacheModule
def test_CacheModule():
    Cache = CacheModule()
    assert(Cache)

# Generated at 2022-06-21 03:44:59.131104
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = '/tmp/robertdavidgraham/'
    _timeout = 86400
    cache = CacheModule(path, _timeout)
    assert(cache.path == path)
    assert(cache._timeout == _timeout)
    cache.flush()

# Generated at 2022-06-21 03:44:59.699790
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-21 03:45:05.110309
# Unit test for constructor of class CacheModule
def test_CacheModule():
    hast_obj = CacheModule()
    assert isinstance(hast_obj._uri, str)
    assert isinstance(hast_obj._prefix, str)
    assert isinstance(hast_obj._timeout, int)

# Generated at 2022-06-21 03:45:09.619108
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_obj = CacheModule()
    assert test_obj._load.__name__ == '_load'
    assert test_obj._dump.__name__ == '_dump'

# Generated at 2022-06-21 03:45:14.967241
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        CacheModule()
    except Exception as err:
        assert True, 'CacheModule failed to instantiate, reason: %s' % err
    else:
        assert False, 'Instantiated CacheModule without errors'

# Generated at 2022-06-21 03:45:15.772916
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-21 03:45:17.761902
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400

# Generated at 2022-06-21 03:45:23.692022
# Unit test for constructor of class CacheModule
def test_CacheModule():
   module = CacheModule(filename_prefix='my_prefix', filename_extension='.my_extension', timeout=300)
   assert module._prefix == 'my_prefix'
   assert module._extension == '.my_extension'
   assert module._timeout == 300

# Generated at 2022-06-21 03:45:24.369220
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache=CacheModule()

# Generated at 2022-06-21 03:45:31.839666
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.get_timeout() == 86400, 'Wrong timeout'
    assert c.get_connection() == '/tmp', 'Wrong connection'
    assert c.get_prefix() == '', 'Wrong prefix'

    # Test with env variables
    import os
    os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = '/tmp/env_connection'
    os.environ['ANSIBLE_CACHE_PLUGIN_PREFIX'] = 'env_prefix'
    os.environ['ANSIBLE_CACHE_PLUGIN_TIMEOUT'] = '60'

    c = CacheModule()
    assert c.get_timeout() == 60, 'Wrong timeout'

# Generated at 2022-06-21 03:45:33.594525
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule._timeout == 86400
    assert cacheModule._prefix == 'ansible_fact_cache_'

# Generated at 2022-06-21 03:45:34.418718
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-21 03:45:47.643297
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    Unit tests for cache_plugin class
    '''
    from ansible.plugins.cache.jsonfile import CacheModule

    test_opts = dict(
        fact_caching_connection='/tmp/',
        fact_caching_timeout='8649',
        fact_caching_prefix='test_'
    )

    # Class CacheModule should have the following attributes
    # _cache
    # _prefix
    # _timeout
    # _connection
    cache_connection = CacheModule(test_opts)
    assert cache_connection._timeout == 8649
    assert cache_connection._prefix == 'test_'
    assert cache_connection._connection == '/tmp/'

# Generated at 2022-06-21 03:45:49.138237
# Unit test for constructor of class CacheModule
def test_CacheModule():
    a = CacheModule()
    assert(a)

# Generated at 2022-06-21 03:45:57.286210
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import BaseCacheModule
    from ansible.parsing.ajson import AnsibleJSONEncoder, AnsibleJSONDecoder

    cm = CacheModule()

    assert isinstance(cm, BaseCacheModule)
    assert isinstance(cm._decoder, AnsibleJSONDecoder)
    assert isinstance(cm._encoder, AnsibleJSONEncoder)

# Generated at 2022-06-21 03:45:58.066435
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin is not None

# Generated at 2022-06-21 03:45:59.564370
# Unit test for constructor of class CacheModule
def test_CacheModule():
    result = CacheModule()
    assert result.get_cache_dir() is None
    assert result.get_timeout()



# Generated at 2022-06-21 03:46:07.079561
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Test that the constructor for class CacheModule works as expected.

    Test for expected attributes and expected methods.
    """
    cache_module = CacheModule()
    assert hasattr(cache_module, '_load')
    assert hasattr(cache_module, '_dump')
    assert callable(getattr(cache_module, '_load'))
    assert callable(getattr(cache_module, '_dump'))

# Generated at 2022-06-21 03:46:15.850806
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = "/tmp/ansible-cache-dir"
    timeout = 86400
    prefix = "ansible_cache"
    cache_module = CacheModule({'_timeout': timeout, '_prefix': prefix, '_uri': cache_dir})
    assert cache_module._timeout == timeout
    assert cache_module._prefix == prefix
    assert cache_module._cache.dir == cache_dir

# Generated at 2022-06-21 03:46:16.645716
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert True

# Generated at 2022-06-21 03:46:17.445590
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-21 03:46:19.896408
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.plugin_name == 'jsonfile'
    assert cache.plugin_path == '/tmp/ansible_faketc_plugin_jsonfile.0'

# Generated at 2022-06-21 03:46:35.039929
# Unit test for constructor of class CacheModule
def test_CacheModule():
    myCacheModule = CacheModule()
    assert myCacheModule.get_cache_prefix() == "cache_json"
    assert myCacheModule.get_cache_timeout() == 86400
    assert myCacheModule.get_cache_plugin_options() == {
        'cache_plugin_options': {
            'fact_caching_timeout': 86400,
            'fact_caching_connection': '$ANSIBLE_CACHE_PLUGIN_CONNECTION',
            'fact_caching_prefix': '$ANSIBLE_CACHE_PLUGIN_PREFIX',
        }
    }
    assert myCacheModule.get_path() == myCacheModule._connection['_uri']


# Generated at 2022-06-21 03:46:35.657509
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-21 03:46:38.169213
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create a new instance of the class. All required
    # parameters are set to None.
    c = CacheModule()

    # Check default values of the parameters.
    assert c._timeout == 86400
    assert c._prefix is None
    assert c._uri == '/tmp'

# Generated at 2022-06-21 03:46:47.258729
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Unit test of the base class constructor
    """
    cache_plugin = CacheModule()
    assert cache_plugin._plugin_type == 'cache'
    assert cache_plugin._timeout == 86400
    assert cache_plugin._connection == None
    assert cache_plugin._connection_info == {}
    assert cache_plugin._prefix == None
    assert cache_plugin._config._prefix == 'ansible_fact_caching_'
    assert cache_plugin._config._timeout == 86400

# Generated at 2022-06-21 03:46:48.256287
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule('./')

# Generated at 2022-06-21 03:46:48.748732
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-21 03:46:51.970674
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    jsonfile = CacheModule()
    assert (jsonfile is not None)

# Generated at 2022-06-21 03:46:55.122530
# Unit test for constructor of class CacheModule
def test_CacheModule():
    imp = __import__("ansible.plugins.cache.jsonfile")
    cf = imp.CacheModule()
    assert isinstance(cf, imp.BaseFileCacheModule)

# Generated at 2022-06-21 03:46:56.723340
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), dict)

# Generated at 2022-06-21 03:47:08.527624
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_name = 'jsonfile'
    cache_plugin_connection = '/tmp/ansible'
    cache_plugin_prefix = 'ansible'
    cache_plugin_timeout = 86400
    cache_plugin_data = {}

    cache_plugin = CacheModule(
        plugin_name=cache_plugin_name,
        timeout=cache_plugin_timeout,
        plugin_connection=cache_plugin_connection,
        plugin_prefix=cache_plugin_prefix)

    assert cache_plugin_name == cache_plugin.plugin_name
    assert cache_plugin_timeout == cache_plugin.timeout
    assert cache_plugin_connection == cache_plugin.plugin_connection
    assert cache_plugin_prefix == cache_plugin.plugin_prefix
    assert cache_plugin_data == cache_plugin.plugin_data



# Generated at 2022-06-21 03:47:21.239548
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_class = CacheModule()
    assert test_class

# Generated at 2022-06-21 03:47:23.833133
# Unit test for constructor of class CacheModule
def test_CacheModule():
    #check if class is initialized correctly
    CacheModule()

# Generated at 2022-06-21 03:47:25.387478
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-21 03:47:27.073120
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert(cache_module.get_timeout() == 86400)

# Generated at 2022-06-21 03:47:28.226887
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-21 03:47:30.026054
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Test the functionalities of the class CacheModule

# Generated at 2022-06-21 03:47:30.903919
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None


# Generated at 2022-06-21 03:47:32.629519
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), BaseFileCacheModule)


# Generated at 2022-06-21 03:47:33.559841
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert x._load

# Generated at 2022-06-21 03:47:35.374901
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert (CacheModule({'_uri': 'test'}) is not None)


# Generated at 2022-06-21 03:48:04.864061
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin
    assert plugin.cachefile
    assert plugin._load
    assert plugin._dump
    assert plugin.get
    assert plugin.set

# Generated at 2022-06-21 03:48:10.816281
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_attrs = dict(
        _uri='/tmp/ansible_cache',
        _prefix='ansible_cache_',
        _timeout=10,
    )
    cache = CacheModule(task_vars=dict(), **cache_attrs)
    for k, v in cache_attrs.items():
        assert v == getattr(cache, k)


# Generated at 2022-06-21 03:48:11.724529
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m

# Generated at 2022-06-21 03:48:14.361593
# Unit test for constructor of class CacheModule
def test_CacheModule():
	x = CacheModule()
	print("Testing CacheModule()")
	print("	returns:")
	print("		", x)

if __name__ == "__main__":
	test_CacheModule()

# Generated at 2022-06-21 03:48:21.247605
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create an instance of the CacheModule class
    cache_module = CacheModule()

    # The following tests should pass
    assert cache_module.get_cache_path() == "~/.ansible/tmp/ansible-cached-facts"
    assert cache_module.get_cache_path() == cache_module._connection._connection
    assert cache_module.get_cache_prefix() == "ansible_facts"
    assert cache_module.get_cache_expiration() == 86400

    # Make sure the above object is of type CacheModule and not of type BaseFileCacheModule
    assert isinstance(cache_module, CacheModule)
    assert not isinstance(cache_module, BaseFileCacheModule)

# Generated at 2022-06-21 03:48:25.332496
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Test CacheModule constructor"""
    # pylint: disable=unused-variable
    # constructor of class CacheModule requires no parameters
    cm = CacheModule()
    # pylint: enable=unused-variable

# Generated at 2022-06-21 03:48:29.954886
# Unit test for constructor of class CacheModule
def test_CacheModule():
    myCacheModule = CacheModule()
    assert myCacheModule.get_cache_timeout() == 86400
    assert myCacheModule.set_cache_timeout(1) is None
    assert myCacheModule.get_cache_timeout() == 1
    myCacheModule.set_cache_timeout(86400)
    assert myCacheModule.get_cache_timeout() == 86400

# Generated at 2022-06-21 03:48:34.381870
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test that the constructor runs without errors
    assert CacheModule({'_uri': 'test', '_prefix': 'pre', '_timeout': '123'})
    # Test that the constructor runs without errors
    assert CacheModule({'_uri': 'test'})
    # Test that the constructor runs without errors
    assert CacheModule({})

# Generated at 2022-06-21 03:48:36.840838
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule('fake_host')
    assert c._options == {'_prefix': 'fake_host'}

# Generated at 2022-06-21 03:48:48.101895
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test when prefix is not given
    connection = "/tmp/testing"
    prefix = None
    timeout = 7200
    cache = CacheModule(connection, prefix, timeout)
    assert cache._connection == connection
    assert cache._prefix == "ansible_facts"
    assert cache._timeout == timeout

    # test when prefix is given
    prefix = "testprefix"
    cache = CacheModule(connection, prefix, timeout)
    assert cache._connection == connection
    assert cache._prefix == prefix
    assert cache._timeout == timeout

    # test when timeout is not given
    connection = "/tmp/testing"
    prefix = None
    timeout = None
    cache = CacheModule(connection, prefix, timeout)
    assert cache._connection == connection
    assert cache._prefix == "ansible_facts"
    assert cache._timeout == 86400

# Generated at 2022-06-21 03:49:50.067181
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule(task=None)
    print(cache_plugin)

# Generated at 2022-06-21 03:49:51.246470
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, BaseFileCacheModule)

# Generated at 2022-06-21 03:49:56.050944
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = '/path/to/jsonfile'
    prefix = 'prefix'
    uri = 'uri'
    timeout = 100
    cache_module = CacheModule(path=path, prefix=prefix, uri=uri, timeout=timeout)
    assert cache_module.get_timeout() == timeout
    assert cache_module.get_prefix() == prefix
    assert cache_module.get_connection() == uri

# Generated at 2022-06-21 03:49:58.387451
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mock_task = None
    mock_subtask = None
    cache = CacheModule(mock_task, mock_subtask)

# Generated at 2022-06-21 03:49:59.845318
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule(), '_load')
    assert hasattr(CacheModule(), '_dump')


# Generated at 2022-06-21 03:50:02.563850
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.file_extension() == ".json"
    assert c.file_path("/tmp") == "/tmp/facts"

# Generated at 2022-06-21 03:50:12.079577
# Unit test for constructor of class CacheModule
def test_CacheModule():
    tmp_path = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_jsonfile_cache')

    import shutil
    try:
        shutil.rmtree(tmp_path)
    except OSError:
        pass

    cache = CacheModule({'_uri': 'file://' + tmp_path})

    facts = dict(foo='bar', bam='baz', full_hostname='foo.example.org')
    cache.set('foo.example.org', 'facts', facts)

    # This is deliberately *not* using cache.get() - we want to test that
    # the low-level cache functions work correctly.
    cache_file = os.path.join(tmp_path, cache._key_to_file('foo.example.org', 'facts'))
    cached_data

# Generated at 2022-06-21 03:50:13.154447
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._load
    assert cm._dump

# Generated at 2022-06-21 03:50:15.624694
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("\n\nTesting CacheModule constructor")

    # Create oject of class CacheModule
    t = CacheModule({'foo': 'bar'})
    
    # Display object of class CacheModule
    print(t)

# Call CacheModule constructor
test_CacheModule()

# Generated at 2022-06-21 03:50:16.286907
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-21 03:52:31.966359
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.fileext == 'json'

# Generated at 2022-06-21 03:52:32.988843
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-21 03:52:37.510078
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._prefix == 'ansible_facts_'
    assert cache_module._timeout == 86400
    assert cache_module._extension == 'json'
    assert isinstance(cache_module._decoder, AnsibleJSONDecoder)
    assert isinstance(cache_module._encoder, AnsibleJSONEncoder)

# Generated at 2022-06-21 03:52:39.507207
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # CacheModule() should succeed unless the test fails
    assert(CacheModule())

# Generated at 2022-06-21 03:52:41.219697
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.file_extension == ".json"

# Generated at 2022-06-21 03:52:43.475209
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._get_cache_prefix() == 'ansible-cache'

# Generated at 2022-06-21 03:52:45.824973
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    cm._timeout=5*60
    cm._prefix='Test'
    assert cm._timeout == 300
    assert cm._prefix is 'Test'

# Generated at 2022-06-21 03:52:47.271041
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None
    assert type(cm).__name__ == 'CacheModule'

# Generated at 2022-06-21 03:52:49.667372
# Unit test for constructor of class CacheModule
def test_CacheModule():
  # Check construction of CacheModule
  cacheModule = CacheModule()
  assert cacheModule != None
  assert cacheModule._load("test") != None
  assert cacheModule._dump({}, "test") != None

# Generated at 2022-06-21 03:52:50.617118
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert callable(CacheModule)