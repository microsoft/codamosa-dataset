

# Generated at 2022-06-21 03:44:36.730100
# Unit test for constructor of class CacheModule
def test_CacheModule():

  tt = CacheModule({
    "_uri" : "/home/terrago",
    "_prefix" : "pre_",
    "_timeout" : "3600"
  })

  assert(tt._timeout == "3600")
  assert(tt._uri == "/home/terrago")
  assert(tt._prefix == "pre_")


# Generated at 2022-06-21 03:44:37.985645
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test = CacheModule()
    assert test._load('test.json') == 'test'


test_CacheModule()

# Generated at 2022-06-21 03:44:48.273892
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import re
    import tempfile
    import unittest

    class TestCacheModule(unittest.TestCase):
        def setUp(self):
            self.cache_dir = tempfile.mkdtemp()
            self.URI = "%s/facts" % self.cache_dir
            self.test_content = {'test_key': 'test_value'}

        def tearDown(self):
            import shutil
            shutil.rmtree(self.cache_dir)

        def test_load_and_dump(self):
            cm = CacheModule({'_uri': self.URI})
            fake_host = 'fake_hostname'
            fake_data = {'foo': 'bar'}

            # test serialize
            fake_filepath = cm._file_path(fake_host)

# Generated at 2022-06-21 03:44:52.208460
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule('/fake/path')
    assert cache_module._cache_dir.startswith('/fake/path')

# Generated at 2022-06-21 03:44:54.631001
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert(cm.connection is None)
    assert(cm.prefix is None)
    assert(cm.timeout == 86400)

# Generated at 2022-06-21 03:44:57.608680
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin_obj = CacheModule()
    assert plugin_obj._encoding == 'utf-8'

# Generated at 2022-06-21 03:44:58.939078
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache

# Generated at 2022-06-21 03:44:59.709491
# Unit test for constructor of class CacheModule
def test_CacheModule():
    return CacheModule()

# Generated at 2022-06-21 03:45:05.704339
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = '/tmp'
    prefix = 'ansible-factcache_json'
    timeout = 17
    _plugin = CacheModule(cache_dir, prefix, timeout)
    assert _plugin.cache_dir == cache_dir
    assert _plugin.prefix == prefix
    assert _plugin.timeout == timeout

# Generated at 2022-06-21 03:45:15.954746
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    import os

    # Get the current directory
    current_dir = os.path.dirname(os.path.realpath(__file__))

    cache_module = CacheModule({
        '_uri': current_dir + "/data",
        "_prefix": "",
        "_timeout": 86400,
    })

    # Check whether the class of the cache module is CacheModule
    assert isinstance(cache_module, CacheModule)

    # Check whet

# Generated at 2022-06-21 03:45:25.721596
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule({'_uri': '/tmp/ansible'})

    assert c.filepath('localhost') == '/tmp/ansible/ansible-localhost'
    assert c.filepath('localhost', '/etc/ansible/facts.d') == '/tmp/ansible/ansible-localhost/etc/ansible/facts.d'

# Generated at 2022-06-21 03:45:28.999456
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert isinstance(plugin, CacheModule)
    assert isinstance(plugin, BaseFileCacheModule)

# Generated at 2022-06-21 03:45:30.430612
# Unit test for constructor of class CacheModule
def test_CacheModule():
	assert CacheModule()._load("facts.json") == None

# Generated at 2022-06-21 03:45:35.416477
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': '/var/tmp'})
    assert cache._uri == '/var/tmp'
    assert cache._prefix == 'ansible_facts_'
    assert cache._timeout == 86400
    assert cache


# Generated at 2022-06-21 03:45:36.420361
# Unit test for constructor of class CacheModule
def test_CacheModule():
    result = CacheModule()
    assert result

# Generated at 2022-06-21 03:45:39.960776
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

    #def get(self, key):
    return c.get("dummy")


# Generated at 2022-06-21 03:45:42.844617
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = './'
    prefix = 'test_prefix'
    cache_plugin = CacheModule(cache_dir, prefix, 3600)
    assert cache_plugin.cache_dir == cache_dir
    assert cache_plugin.prefix == prefix
    assert cache_plugin.timeout == 3600

# Generated at 2022-06-21 03:45:43.590872
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-21 03:45:45.238194
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(path='/my/cache/dir/'))

# Generated at 2022-06-21 03:45:49.143406
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonfile_cache = CacheModule()
    assert jsonfile_cache
    assert jsonfile_cache._timeout == 86400
    assert jsonfile_cache._prefix == ''
    assert jsonfile_cache._connection == ''
    assert jsonfile_cache._load_cache == jsonfile_cache._load
    assert jsonfile_cache._dump_cache == jsonfile_cache._dump

# Generated at 2022-06-21 03:45:53.879691
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__doc__

# Generated at 2022-06-21 03:45:58.599667
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.file_extension == '.json'
    assert cache_module._timeout == 86400
    assert cache_module._prefix == ''
    assert cache_module._loaded_info == None
    assert cache_module.get_timeout() == 86400

# Generated at 2022-06-21 03:46:09.239312
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile

    # create tempfile
    f = tempfile.NamedTemporaryFile()

    # create the CacheModule with tempfile
    cache_plugin = CacheModule({'path':f.name})

    # get temporary file name
    name = os.path.splitext(f.name)[0]
    cache_plugin.file_name = name

    # create mock data
    data = {'foo':'bar'}

    # insert data into cache_plugin
    cache_plugin.set('test_uri', data)

    # get data from cache_plugin
    rtn = cache_plugin.get('test_uri')

    # compare data
    assert rtn == data

    # delete file
    f.close()

# Generated at 2022-06-21 03:46:11.512111
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = './fooDir'
    prefix = 'testPrefix'
    timeout = 77
    cache_module = CacheModule(uri, prefix, timeout)
    assert cache_module.timeout == timeout
    assert cache_module.prefix == prefix
    assert cache_module.directory == uri

# Generated at 2022-06-21 03:46:12.960908
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule

# Generated at 2022-06-21 03:46:19.163815
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = "ansible/facts"
    # Test constructor of class CacheModule
    with CacheModule(uri) as f:
        assert f._prefix == "ansible_facts"
        assert f.__class__.__name.__ == "CacheModule"
        f._prefix = "ansible_facts_test"
        assert f._prefix == "ansible_facts_test"

# Generated at 2022-06-21 03:46:20.457044
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(volatile=False, _uri='my_uri'))

# Generated at 2022-06-21 03:46:23.633119
# Unit test for constructor of class CacheModule
def test_CacheModule():
  cm = CacheModule()
  assert cm
  assert cm['_prefix'] == "ansible_facts"
  assert cm['_timeout'] == 86400
  assert cm['_uri'] == "~/.ansible/tmp"

# Generated at 2022-06-21 03:46:33.266675
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = "test_path"
    timeout = 1000
    prefix = "test_prefix"
    data = "test_data"

    cache_module = CacheModule()

    assert cache_module._timeout == 86400
    assert cache_module._prefix == "ansible_fact_cache"
    assert cache_module._connection == "/tmp"

    cache = { "_ansible_cache" : 1000000, "role" : "test_role" }
    cache_module._set_cache(connection, timeout, prefix, data, cache)

    assert cache_module._timeout == timeout
    assert cache_module._prefix == prefix
    assert cache_module._connection == connection
    assert cache_module._cache == cache

# Generated at 2022-06-21 03:46:34.211546
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule() is not None

# Generated at 2022-06-21 03:46:41.613405
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-21 03:46:45.445077
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._expiration == 86400
    assert cm._prefix == 'ansible_facts'
    assert cm._connection == '/tmp'

# Generated at 2022-06-21 03:46:48.492380
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Test for `CacheModule()` constructor."""
    c = CacheModule()
    assert isinstance(c._timeout, int)
    assert isinstance(c._prefix, str)
    assert isinstance(c._uri, str)

# Generated at 2022-06-21 03:46:49.512858
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c

# Generated at 2022-06-21 03:46:51.928415
# Unit test for constructor of class CacheModule
def test_CacheModule():
    fact_caching = CacheModule()
    assert fact_caching._connection is None

# Generated at 2022-06-21 03:47:02.037501
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Init variables
    path  = "/tmp/cache_file"
    fname = "test_file.json"
    fact  = "test_fact"
    val   = "test_val"
    ttl   = "86400"

    # Create the plugin obj
    plugin_obj = CacheModule()

    # Create tmp dir and cache file
    plugin_obj.basedir = path
    plugin_obj.fname   = fname

    # Store a fact
    plugin_obj.get(fact, val)
    assert(plugin_obj.get(fact) == val)

    # Overwrite the fact

# Generated at 2022-06-21 03:47:03.139523
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj

# Generated at 2022-06-21 03:47:04.565322
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert x

# Generated at 2022-06-21 03:47:11.891694
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load.__name__ == '_load'
    assert cache._dump.__name__ == '_dump'
    assert cache.get.__name__ == 'get'
    assert cache.set.__name__ == 'set'
    assert cache.keys.__name__ == 'keys'
    assert cache.contains.__name__ == 'contains'

# Generated at 2022-06-21 03:47:19.224333
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile
    import time
    import shutil
    from datetime import timedelta


# Generated at 2022-06-21 03:47:32.314075
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-21 03:47:33.919139
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule(None)
    assert cm
    assert isinstance(cm,CacheModule)


# Generated at 2022-06-21 03:47:36.705802
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    # Note: this test is crash only due to assertion. It's not enough to make a unit test.
    assert cache != None

# make sure we work with Python 2.6

# Generated at 2022-06-21 03:47:38.412091
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonfile = CacheModule()
    assert jsonfile is not None
    assert jsonfile.cache_name == 'jsonfile'

# Generated at 2022-06-21 03:47:39.215221
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache

# Generated at 2022-06-21 03:47:40.278266
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-21 03:47:40.786569
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-21 03:47:41.921322
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c

# Generated at 2022-06-21 03:47:44.796290
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Constructor of class CacheModule
    # test_CacheModule(CacheModule)
    assert CacheModule(None)._cache_dir


if __name__ == '__main__':
    # Unit test for constructor of class CacheModule
    test_CacheModule()

# Generated at 2022-06-21 03:47:46.190175
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c=CacheModule()
    assert c != None

# Generated at 2022-06-21 03:48:20.003571
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachemodule = CacheModule()
    assert cachemodule
    assert hasattr(cachemodule, '_load')
    assert hasattr(cachemodule, '_dump')
    assert hasattr(cachemodule, 'get')
    assert hasattr(cachemodule, 'set')
    assert hasattr(cachemodule, 'has_expired')
    assert hasattr(cachemodule, 'keys')
    assert hasattr(cachemodule, 'delete')
    assert hasattr(cachemodule, 'flush')
    assert hasattr(cachemodule, '_timeout')
    assert hasattr(cachemodule, '_connection')
    assert hasattr(cachemodule, '_prefix')



# Generated at 2022-06-21 03:48:23.550926
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._uri == "~/.ansible_cache"
    assert cache._timeout is 86400

# Generated at 2022-06-21 03:48:25.615850
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache_plugin = None
    cache_plugin = CacheModule()
    assert(cache_plugin != None)



# Generated at 2022-06-21 03:48:26.205785
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-21 03:48:31.241647
# Unit test for constructor of class CacheModule
def test_CacheModule():
    simple_test = CacheModule()
    assert simple_test._timeout == 86400
    assert simple_test._plugin_name == 'jsonfile'
    assert simple_test._plugin_env == ('ANSIBLE_CACHE_PLUGIN', 'ANSIBLE_CACHE_PLUGIN_CONNECTION', 'ANSIBLE_CACHE_PLUGIN_PREFIX', 'ANSIBLE_CACHE_PLUGIN_TIMEOUT')

# Generated at 2022-06-21 03:48:38.744611
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonfile_path = '/tmp/test/'
    jsonfile_prefix = 'a'
    jsonfile_timeout = '1000'
    jsonfile = CacheModule(jsonfile_path, jsonfile_prefix, jsonfile_timeout)
    assert jsonfile.plugin_name == 'jsonfile'
    assert jsonfile.plugin_path == jsonfile_path
    assert jsonfile.plugin_prefix == jsonfile_prefix
    assert jsonfile.plugin_timeout == jsonfile_timeout

# Generated at 2022-06-21 03:48:39.311362
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-21 03:48:39.931243
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-21 03:48:43.518501
# Unit test for constructor of class CacheModule
def test_CacheModule():
    host = "http://myhost"
    name = "test"

    cm = CacheModule(host, name)

    assert cm._name == "test"
    assert cm._host_id == host

# Generated at 2022-06-21 03:48:44.064881
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

# Generated at 2022-06-21 03:49:46.833847
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create an instance of the CacheModule class
    c = CacheModule()

    # Check that the instance has been correctly created
    assert str(type(c)) == "<class 'ansible.plugins.cache.jsonfile.CacheModule'>"

# Generated at 2022-06-21 03:49:56.011409
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()

    # legacy tests
    assert plugin.get_cache_dir() == '~/.ansible/tmp'
    assert plugin.get_cache_socket_path() is None
    assert plugin.get_cache_timeout() == 86400

    # backwards compatibility
    assert plugin._load.__name__ == '_load'
    assert plugin._dump.__name__ == '_dump'

    # test that it works with a dict input
    data = dict(b=1, a=2, c=3)
    json_data = json.dumps(data)
    result = plugin._load(json_data)
    assert result == data == dict(a=2, b=1, c=3)

    # test that it works with a json input

# Generated at 2022-06-21 03:50:01.782333
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # creates a CacheModule object
    cacheModule = CacheModule()
    # creates a dictionary
    dictTest = {'ansible_facts': {'dir': {'stdout': 'test'}}}
    # tests the method _dump
    filepath = "myfile.json"
    cacheModule._dump(dictTest, filepath)
    # tests the method _load_
    dictLoaded = cacheModule._load(filepath)
    assert dictLoaded == dictTest

# Generated at 2022-06-21 03:50:03.966816
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert type(CacheModule(task=None, variables=None)) is CacheModule


# Generated at 2022-06-21 03:50:09.624268
# Unit test for constructor of class CacheModule
def test_CacheModule():
    json_object = {}
    cache = CacheModule()
    assert cache is not None
    assert cache._load is not None
    assert cache._dump is not None
    cache._dump(json_object, '/tmp/test_ansible_jsonfile.json')
    r_json_object = cache._load('/tmp/test_ansible_jsonfile.json')
    assert r_json_object is not None
    assert r_json_object == {}

# Generated at 2022-06-21 03:50:12.832927
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    #
    # test_path must be a valid path to an `.json` file
    #
    test_path = '/path/to/file.json'
    cm._load(test_path)
    cm._dump('{"key": "data"}', test_path)

# Generated at 2022-06-21 03:50:13.733145
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._plugin_name == 'jsonfile'

# Generated at 2022-06-21 03:50:14.722714
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._connection is None
    assert CacheModule._timeout == 86400

# Generated at 2022-06-21 03:50:17.192178
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.get_timeout() == 86400
    c = CacheModule(timeout=3600)
    assert c.get_timeout() == 3600
    c = CacheModule(timeout="3600")
    assert c.get_timeout() == 3600

# Generated at 2022-06-21 03:50:19.521090
# Unit test for constructor of class CacheModule
def test_CacheModule():
    options = {'_uri': '/tmp', '_prefix': 'test_cache_'}
    cache = CacheModule(options)
    assert options['_uri'] == cache.basedir
    assert options['_prefix'] == cache.prefix

# Generated at 2022-06-21 03:52:38.066009
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test without parameters
    cache = CacheModule()
    
    if not isinstance(cache, CacheModule):
        raise Exception("Cache module does not create CacheModule object")

    if not isinstance(cache, object):
        raise Exception("CacheModule does not inherit from object")

# Generated at 2022-06-21 03:52:42.578962
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create an instance of class CacheModule
    cache_plugin = CacheModule()

    # Test that _load, _dump, and get_file_path methods exist after instantiation
    methods = ('_load', '_dump', 'get_file_path')

    for x in methods:
        assert hasattr(cache_plugin, x)

# Generated at 2022-06-21 03:52:45.543720
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    cacheModule.set_options(direct)
    cacheModule.flush()
    cacheModule.get("host","var")
    cacheModule.set("host","var","val")

# Generated at 2022-06-21 03:52:49.986404
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # instantiate the class
    cache = CacheModule()

    # check class attributes
    for key, val in cache.__dict__.items():
        # special case: file_extension / timeout
        if key in ('file_extension', 'timeout'):
            assert val == 'json'
        # special case: mtime
        elif key == 'mtime':
            assert val == 0
        else:
            assert val == ''

# Generated at 2022-06-21 03:52:53.810028
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None
    assert bool(cache_module) is False
    assert cache_module._load is not None
    assert cache_module._dump is not None

# Generated at 2022-06-21 03:53:00.668557
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': '/dir/to/save/files'})
    assert cache.file_extension() == '.json'
    assert cache.file_prefix() == 'ansible-fact'
    assert cache.file_path() == '/dir/to/save/files/ansible-fact-9d4c2b8ec4e6544a52b1f5d5adf859a5.json'
    assert cache.get('_timeout') == 86400

# Generated at 2022-06-21 03:53:02.264403
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.plugin_name == 'jsonfile'

# Generated at 2022-06-21 03:53:07.089316
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # pylint: disable=import-error
    from ansible.plugins.loader import find_plugin_filepaths
    # pylint: enable=import-error
    plugin_paths = find_plugin_filepaths(os.path.dirname(os.path.realpath(__file__)))
    plugin = CacheModule(plugin_paths[0])
    assert plugin is not None



# Generated at 2022-06-21 03:53:08.184095
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Constructor of class CacheModule
    cacheModule = CacheModule()

# Generated at 2022-06-21 03:53:13.546837
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Testing class constructor
    import os, sys
    if sys.hexversion < 0x02070000:
        # Python 2.6 does not have unittest.mock
        import mock
    else:
        from unittest import mock

    # mock.patch for python 2.6
    patcher = mock.patch('ansible.plugins.cache.jsonfile.BaseFileCacheModule.__init__')
    patched = patcher.start()

    _ = CacheModule()
    patched.assert_called()
    patcher.stop()
