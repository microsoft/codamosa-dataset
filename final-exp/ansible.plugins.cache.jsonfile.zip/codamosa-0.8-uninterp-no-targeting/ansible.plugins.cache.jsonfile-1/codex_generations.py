

# Generated at 2022-06-21 03:44:32.975408
# Unit test for constructor of class CacheModule
def test_CacheModule():
    a = CacheModule()
    assert a is not None
    assert isinstance(a, BaseFileCacheModule)

# Generated at 2022-06-21 03:44:35.355285
# Unit test for constructor of class CacheModule
def test_CacheModule():
    facts = {'test1': 'testing'}
    try:
        CacheModule(facts)
    except:
        raise AssertionError('CacheModule() raised exception')

# Generated at 2022-06-21 03:44:38.169997
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({
        '_timeout': 86400,
        '_prefix': 'jsonfile',
        '_uri': '/tmp',
    })
    assert cache.cache_dir == '/tmp'
    assert cache.timeout == 86400
    assert cache.plugin_name == 'jsonfile'

# Generated at 2022-06-21 03:44:39.628938
# Unit test for constructor of class CacheModule
def test_CacheModule():
    chache_module_object = CacheModule()
    assert chache_module_object is not None

# Generated at 2022-06-21 03:44:43.147232
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    assert CacheModule
    test_instance = CacheModule({})

    assert test_instance.get_cache_basedir and test_instance.get_cache_basedir == "/tmp/ansible-fact-cache"
    assert test_instance.get_cache_prefix and test_instance.get_cache_prefix == "ansible_facts"

# Generated at 2022-06-21 03:44:46.923620
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    cache_plugin = CacheModule()
    cache_plugin.set_options({'_uri': os.path.join(os.getcwd(), 'TEST_CacheModule_DIR')})
    cache_plugin._flush()

# Generated at 2022-06-21 03:44:47.869162
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-21 03:44:58.804989
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert sys.version_info[:3] >= (2, 6)
    assert isinstance(CacheModule(), CacheModule)

if __name__ == '__main__':
    import sys
    import doctest
    print(doctest.testmod())

    # check __doc__ at runtime
    mod = sys.modules[__name__]
    if hasattr(mod, '__doc__'):
        print(mod.__doc__)
    doc = getattr(mod, '__doc__')
    if doc is None:
        print(doc)
        print("WARNING: module doc string is empty")
    else:
        print(doc)
    print('-' * 60)
    print(mod.__dict__)
    print('-' * 60)

    # check docstring of classes

# Generated at 2022-06-21 03:44:59.312249
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-21 03:45:00.001126
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module is not None



# Generated at 2022-06-21 03:45:06.165680
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = {'_uri': '/tmp'}
    prefix = 'test'
    timeout = 86400
    jm = CacheModule(connection, prefix, timeout)
    assert jm is not None

# Generated at 2022-06-21 03:45:12.117834
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # file = open("/tmp/test.txt","w")
    # file.write("an example of file write")
    # file.close()
    # print('/tmp/test.txt is created')

    cache = CacheModule()
    print(type(cache))
    print(cache)
    print(cache.get_basedir())
    print(cache.get_timeout())
    print(cache.get_prefix())
    print(cache.get_plugin_options())

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-21 03:45:13.948465
# Unit test for constructor of class CacheModule
def test_CacheModule():
    base_file_cache_module = BaseFileCacheModule(connection={'path':'./ansible_cache'},prefix=None,timeout=0)

# Generated at 2022-06-21 03:45:21.474124
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule(task=None, manager=None)
    json_file_path = '~/playbooks/test.json'
    cache_plugin.cache_prefix = '~/playbooks/test'
    cache_plugin.cache_dir = '~/playbooks'
    cache_plugin.cache = {}
    json_file_path_created = cache_plugin._get_cache_path('test')
    assert json_file_path == json_file_path_created

# Generated at 2022-06-21 03:45:22.322917
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-21 03:45:23.680502
# Unit test for constructor of class CacheModule
def test_CacheModule():
	obj1 = CacheModule()
	assert isinstance(obj1, CacheModule)

# Generated at 2022-06-21 03:45:29.219724
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    path_separator = '\\' if cache_plugin._uname.startswith('Windows') else '/'
    assert( cache_plugin.connection == 'ansible.cache.plugins.jsonfile.CacheModule' )
    assert( cache_plugin.get_basedir()[-1] == path_separator )
    assert( cache_plugin.get_timeout() == 86400 )
    assert( cache_plugin.get_prefix() == 'ansible_facts_' )

# Generated at 2022-06-21 03:45:30.061916
# Unit test for constructor of class CacheModule
def test_CacheModule():
    p = CacheModule()

# Generated at 2022-06-21 03:45:31.482528
# Unit test for constructor of class CacheModule
def test_CacheModule():
   CacheModule()

# Generated at 2022-06-21 03:45:36.216785
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('/tmp')
    assert cache.cache_root == '/tmp'
    assert cache.file_extension == '.json'
    assert cache.timeout == 86400
    assert cache.prefix == 'ansible_facts_'

# Generated at 2022-06-21 03:45:44.038760
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, BaseFileCacheModule)
    assert cm.get_timeout() == 86400

# Generated at 2022-06-21 03:45:47.054812
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Unit tests for constructor of class CacheModule
#   Must pass in a uri, otherwise it will fail

# Generated at 2022-06-21 03:45:52.883791
# Unit test for constructor of class CacheModule
def test_CacheModule():
    class SingleOpCacheModule(CacheModule):
        # Fake one cache operation so we can test the class constructor
        def get(self, key):
            pass
    cm = SingleOpCacheModule([])

    assert cm._plugin_name == 'jsonfile'

# Generated at 2022-06-21 03:45:57.900258
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = '/home/a/b/cde'
    prefix = 'ab'
    timeout = 400
    c = CacheModule(uri, prefix, timeout)
    assert c._uri == uri
    assert c._prefix == prefix
    assert c._timeout == timeout


# Generated at 2022-06-21 03:46:03.767815
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = {'a':1}
    plugin = CacheModule(data)
    assert plugin.get('a') == 1
    plugin.set('a', 2)
    assert plugin.get('a') == 2
    plugin.delobj('a')
    assert plugin.get('a') is None

# Generated at 2022-06-21 03:46:06.250902
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._prefix == "ANSIBLE_CACHE_PLUGIN"

# Generated at 2022-06-21 03:46:08.511131
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Call correct constructor of CacheModule
    assert CacheModule._load

# Generated at 2022-06-21 03:46:12.592686
# Unit test for constructor of class CacheModule
def test_CacheModule():
    hostname = 'localhost'
    config = {'_prefix':'prefix_', '_uri':'/tmp/'}
    CacheModule(hostname, config)

# Generated at 2022-06-21 03:46:18.533497
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule({'_uri': 'foo'})
    assert module._prefix == 'ansible-jsonfile'
    assert module._timeout == 86400

    module = CacheModule({'_uri': 'foo', '_prefix': 'foo', '_timeout': 1})
    assert module._prefix == 'foo'
    assert module._timeout == 1

# Generated at 2022-06-21 03:46:19.301783
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # this module should not require any initialization
    assert True

# Generated at 2022-06-21 03:46:35.172737
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule(task_vars=dict())
    assert module._timeout == 86400
    assert module._connection == ''
    assert module._plugin_name == 'jsonfile'
    assert module.filter_loader is not None
    assert module._prefix == 'ansible_fact_caching'
    if module._connection == '':
        assert module._use_backend is False
        assert module._cache_basedir is None
    assert module.set_options is not None
    assert module.get is not None
    assert module.set is not None
    assert module.keys is not None
    assert module.contains is not None
    assert module.delete is not None
    assert module.flush is not None
    assert module.close is not None

# Generated at 2022-06-21 03:46:36.912543
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m._cache_backend == "./"
    assert m._cache_timeout == 86400
    assert m._cache_prefix == ""

# Generated at 2022-06-21 03:46:38.169702
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Test the constructor of the class CacheModule
    """
    cache_module = CacheModule()

# Generated at 2022-06-21 03:46:49.454008
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # pylint: disable=protected-access
    # example of how to unit test _load, do not delete
    import tempfile
    test_dict = {"key1": "value1", "key2": "value2"}
    # tempfile to use for unit testing
    with tempfile.NamedTemporaryFile(prefix='ansible_test_jsonfile_CacheModule') as f:
        f.write(json.dumps(test_dict, cls=AnsibleJSONEncoder, sort_keys=True, indent=4).encode('utf-8'))
        c = CacheModule()
        c._load(f.name)
        assert test_dict == c.data
        assert c.filepath == f.name

# Generated at 2022-06-21 03:46:55.120570
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """ Unit test for constructor of class CacheModule
    """
    #test_plugin_instance = CacheModule(task, given_plugin_options)
    assert 1 == 1

# Generated at 2022-06-21 03:46:58.089430
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None
    assert isinstance(c, CacheModule)


# Generated at 2022-06-21 03:46:59.440556
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-21 03:47:03.841922
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    cache_module.get('test_fact_caching_prefix', 'test_fact_caching_connection')
    cache_module.set('test_fact_caching_prefix', 'test_fact_caching_connection', 'test_fact_caching_timeout', 'test_plugin')



# Generated at 2022-06-21 03:47:07.412912
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule({})
    assert not hasattr(plugin, "keys")
    keys = plugin.get("foo")
    assert plugin.keys() == []

# Generated at 2022-06-21 03:47:09.033845
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)


# Generated at 2022-06-21 03:47:21.978908
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert isinstance(c, CacheModule)


# Generated at 2022-06-21 03:47:23.500352
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Construct an instance of class CacheModule
    objCModule = CacheModule()


# Generated at 2022-06-21 03:47:25.626111
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._connection is None
    assert cache._timeout == 86400

# Generated at 2022-06-21 03:47:28.325177
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mod = CacheModule()
    assert mod._connection is None
    assert mod._timeout == 86400
    assert mod._prefix is None

# Generated at 2022-06-21 03:47:32.358199
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("Constructing BaseFileCacheModule()")
    fileCache = BaseFileCacheModule()
    print(fileCache)

# Executing test when the module is called directly
if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-21 03:47:32.948881
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()

# Generated at 2022-06-21 03:47:39.805730
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    from ansible.module_utils.six.moves import StringIO
    import ansible.errors as errors
    c = CacheModule()
    test_path = "/test/path"

    assert c is not None
    assert c.name == 'jsonfile'

    # Check exisiting path
    c.cache._uri = StringIO(test_path)
    assert c.cache._load_cache_from_source(c.cache) == errors.AnsibleError("Invalid JSON file")



# Generated at 2022-06-21 03:47:42.111911
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule({}, {'_uri': '.', '_prefix': 'prefix'})
    assert plugin.basedir == '.'
    assert plugin.prefix == 'prefix'

# Generated at 2022-06-21 03:47:45.081232
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)
    assert cache._timeout == 86400

    cache = CacheModule(timeout=3600)
    assert isinstance(cache, CacheModule)
    assert cache._timeout == 3600

# Generated at 2022-06-21 03:47:49.300892
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.plugin_name == 'jsonfile'
    assert c.plugin_config == {'_uri': '~/.ansible/tmp/ansible-local', '_prefix': 'ansible-local', '_timeout': 86400}

# Generated at 2022-06-21 03:48:17.842534
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    cache_plugin._load('/tmp/test_uri')
    cache_plugin._dump('value', '/tmp/test_uri')

# Generated at 2022-06-21 03:48:18.774811
# Unit test for constructor of class CacheModule
def test_CacheModule():
  assert CacheModule().get('/tmp') == {}

# Generated at 2022-06-21 03:48:20.576016
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule is not None


# Generated at 2022-06-21 03:48:23.550557
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Create cache and verify that it contains expected defaults."""
    cache = CacheModule()
    assert cache.timeout == 86400

# Generated at 2022-06-21 03:48:26.745517
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin_options = dict(
        _uri='.',
        _prefix='test_ansiballz',
        _timeout=100
    )
    module = CacheModule(plugin_options)
    assert module._connection is None

# Generated at 2022-06-21 03:48:32.201748
# Unit test for constructor of class CacheModule
def test_CacheModule():

    connection = '/var/cache/ansible/facts'
    timeout = 3600
    prefix = 'ansible_local'

    cache_plugin = CacheModule({'_uri': connection,
                                '_timeout': timeout,
                                '_prefix': prefix
                               })

    assert cache_plugin.timeout == timeout
    assert cache_plugin.plugin_prefix == prefix
    assert cache_plugin.connection == connection

# Generated at 2022-06-21 03:48:34.612079
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.connection is not None
    assert cache.prefix is None
    assert cache.timeout == 86400

# Generated at 2022-06-21 03:48:36.390948
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonfile = CacheModule()
    assert jsonfile is not None

# Generated at 2022-06-21 03:48:38.206291
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin.plugin_name == 'jsonfile'

# Generated at 2022-06-21 03:48:39.476815
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-21 03:49:40.362528
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert True

# Generated at 2022-06-21 03:49:41.706330
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-21 03:49:44.274687
# Unit test for constructor of class CacheModule
def test_CacheModule():
  cm = CacheModule()
  assert isinstance(cm, BaseFileCacheModule)


# Generated at 2022-06-21 03:49:51.430094
# Unit test for constructor of class CacheModule
def test_CacheModule():
    args = {"_uri": '/home/jmi/proj/ansible_test_data/cache/jsonfile'}
    cache = CacheModule(args)
    cache.set('test_key1', 'test_value1')
    cache.set('test_key2', 'test_value2')
    print(cache.get('test_key1'))
    print(cache.get('test_key2'))
    cache.set('test_key3', 'test_value3')
    print(cache.get('test_key3'))
    print(cache.get('test_key4'))

# Generated at 2022-06-21 03:49:55.396271
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()

    assert hasattr(cache_plugin, 'get')
    assert hasattr(cache_plugin, 'set')
    assert hasattr(cache_plugin, 'flush')

    assert cache_plugin._timeout == 86400
    assert cache_plugin._connection == ''
    assert cache_plugin._prefix == ''

# Generated at 2022-06-21 03:50:06.037615
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import shutil
    import tempfile
    import time
    import pytest

    plugin = CacheModule()
    tmpdir = tempfile.mkdtemp()
    plugin.set_options({'_uri': tmpdir, '_timeout': 1})
    assert os.path.exists(tmpdir)

    # test set
    plugin.set('test', 'value')
    assert plugin.get('test') == 'value'
    # test expire
    time.sleep(2)
    assert plugin.get('test') is None
    # test that the cache file has been removed
    assert not os.path.exists(tmpdir + '/test')

    # test that the cache dir has been removed, since it was empty
    assert not os.path.exists(tmpdir)

    # test get_many

# Generated at 2022-06-21 03:50:07.541394
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert isinstance(cacheModule, CacheModule)


# Generated at 2022-06-21 03:50:12.329182
# Unit test for constructor of class CacheModule
def test_CacheModule():
    C_M = CacheModule( '', '', '' )
    assert C_M.cache_dir == '', 'Cache directory is not empty'
    assert C_M.cache_name == '', 'Cache name is not empty'
    assert C_M.cache_key == '', 'Cache key is not empty'
    assert C_M.cache_lock_timeout == 3, 'Cache lock timeout is not 3'

# Generated at 2022-06-21 03:50:13.154756
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict()) == None

# Generated at 2022-06-21 03:50:13.822229
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-21 03:52:32.137462
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None


# Generated at 2022-06-21 03:52:32.889434
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test = CacheModule()
    assert test is not None

# Generated at 2022-06-21 03:52:37.134862
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()

    assert module._prefix == ''
    assert module._timeout == 86400

    module = CacheModule(
        _uri='data/ansible/cache',
        _prefix='test_',
        _timeout=60
    )

    assert module._prefix == 'test_'
    assert module._timeout == 60


# Generated at 2022-06-21 03:52:44.544483
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test for constructor of CacheModule
    cache_connection = '/var/tmp/'
    cache_prefix = 'ansible_facts'
    cache_timeout = 5
    cache_plugin = 'jsonfile'
    cm = CacheModule(None, cache_plugin,
                     connection=cache_connection,
                     prefix=cache_prefix,
                     timeout=cache_timeout)
    assert cm.prefix == 'ansible_facts'
    assert cm.timeout == 5
    assert cm.connection == '/var/tmp/'

# Generated at 2022-06-21 03:52:45.386527
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()


# Generated at 2022-06-21 03:52:45.864094
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-21 03:52:47.270755
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.file_extension == 'json'


# Generated at 2022-06-21 03:52:49.156687
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.file_extension is '.json'
    assert module.directory_name == 'fact_caching'

# Generated at 2022-06-21 03:52:52.010972
# Unit test for constructor of class CacheModule
def test_CacheModule():
    file_cache = CacheModule()
    assert file_cache.get('key') == dict(), file_cache.get('key')
    assert file_cache._load('/tmp/test.json') is None
    file_cache._dump('Value', '/tmp/test.json')
    assert file_cache._load('/tmp/test.json') == 'Value'

# Generated at 2022-06-21 03:52:55.269158
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    with pytest.raises(Exception):
        x._load(None)
    with pytest.raises(Exception):
        x._dump(None, None)
    assert True