

# Generated at 2022-06-21 03:44:34.029413
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-21 03:44:39.123379
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(get_connection = "", get_prefix = "", get_timeout = "")
    cache

# Test for _load() of class CacheModule
import os

# Generated at 2022-06-21 03:44:40.445824
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': 'test_CacheModule'})
    assert cache.plugin.__name__ == 'CacheModule'
    assert cache._connection == 'test_CacheModule'
    assert cache._timeout == 86400

# Generated at 2022-06-21 03:44:41.813791
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import ansible.plugins.cache.jsonfile as jsonfile
    assert jsonfile.CacheModule.__doc__

# Generated at 2022-06-21 03:44:49.220150
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # instantiate the plugin class
    plugin = CacheModule(
        task_vars={'cache_plugin': 'jsonfile', 'cache_connection': './cachedir'},
        inventory=dict(),
        loader=None,
        templar=None,
    )

    # test init
    assert plugin

    # test basic class functions
    assert plugin.get('_dummy', 'default') == 'default'
    plugin.set('_dummy', 'value')
    assert plugin.get('_dummy', 'default') == 'value'

    # test invalid directory
    plugin = CacheModule(
        task_vars={'cache_plugin': 'jsonfile', 'cache_connection': 'some/invalid/dir'},
        inventory=dict(),
        loader=None,
        templar=None,
    )

# Generated at 2022-06-21 03:44:50.606964
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)

# Generated at 2022-06-21 03:44:57.933577
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    try:
        b = BaseFileCacheModule()
    except:
        raise AssertionError("BaseFileCacheModule() constructor not available")
    try:
        c._load("")
    except:
        raise AssertionError("CacheModule._load() method is not available")
    try:
        c._dump("","")
    except:
        raise AssertionError("CacheModule._dump() method is not available")
    print("Test for class CacheModule is passed")

#if __name__ == '__main__':
#    test_CacheModule()

# Generated at 2022-06-21 03:45:03.478133
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, '_load')
    assert hasattr(CacheModule, '_dump')
    assert hasattr(CacheModule, 'get')
    assert hasattr(CacheModule, 'set')
    cm = CacheModule()
    assert cm is not None

# Generated at 2022-06-21 03:45:05.167482
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(connection='connection', config={})
    assert cache.connection == 'connection'
    assert cache.config == {}

# Generated at 2022-06-21 03:45:07.397803
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule() # noqa


# Generated at 2022-06-21 03:45:10.253543
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule(task_vars={'cache_plugin': 'jsonfile'})
    assert obj

# Generated at 2022-06-21 03:45:16.373355
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert 'jsonfile' == cache.cache_plugin_name
    assert 'json' == cache.cache_loader.extension
    assert 'json' == cache.cache_dumper.extension
    assert cache._prefix == 'ansible-factcache'
    assert cache._timeout == 86400

# Generated at 2022-06-21 03:45:18.336015
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # pylint: disable=W0212
    tmp = CacheModule()

# Generated at 2022-06-21 03:45:25.426607
# Unit test for constructor of class CacheModule
def test_CacheModule():
    file_cache = CacheModule()
    assert(file_cache is not None)
    assert(file_cache._load is not None)
    assert(file_cache._dump is not None)
    assert(file_cache.get_json_data is not None)
    assert(file_cache.set_json_data is not None)

# Generated at 2022-06-21 03:45:25.943966
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule

# Generated at 2022-06-21 03:45:29.138897
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_CacheModule_obj = CacheModule()
    assert test_CacheModule_obj._timeout == 86400

# Generated at 2022-06-21 03:45:39.802594
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(task_vars={'cache_plugin_timeout': '$timeout'}, config={'timeout': 1})
    assert cache._timeout == 1

    cache = CacheModule(task_vars={'cache_plugin_timeout': '1'}, config={'timeout': '$timeout'})
    assert cache._timeout == 1

    cache = CacheModule(task_vars={'cache_plugin_timeout': '$timeout'}, config={'timeout': '$timeout'})
    assert cache._timeout == 1

    # illogical combination, but valid, it should use the default config timeout
    cache = CacheModule(task_vars={'cache_plugin_timeout': '$timeout'}, config={'timeout': '$timeout'})
    assert cache._timeout == 1

# Generated at 2022-06-21 03:45:42.927863
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Unit test to check if the constructor of class CacheModule 
    """
    # calling the constructor
    CacheModule = CacheModule()



# Generated at 2022-06-21 03:45:44.839262
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule) == True

# Generated at 2022-06-21 03:45:48.257661
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.plugin_name == 'jsonfile', "CacheModule() should have 'jsonfile' as plugin_name by default"
    assert c.config_prefix == 'fact_caching', "CacheModule() should have 'fact_caching' as config_prefix by default"

# Generated at 2022-06-21 03:45:56.484878
# Unit test for constructor of class CacheModule
def test_CacheModule():
    if not isinstance(CacheModule, object):
        raise AssertionError()
    if not issubclass(CacheModule, object):
        raise AssertionError()

# Unit testing for method _load()

# Generated at 2022-06-21 03:45:57.959831
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Call the constructor of class CacheModule."""
    cache_plugin = CacheModule()
    cache_plugin.set_options()

# Generated at 2022-06-21 03:45:58.999274
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(task=dict(task_vars=dict()))

# Generated at 2022-06-21 03:46:02.634947
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    cm._load("/home/user/test")
    cm._dump("test","/home/user/test")

# Generated at 2022-06-21 03:46:03.478470
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-21 03:46:04.921832
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Constructor here
    assert CacheModule()

# Generated at 2022-06-21 03:46:07.450723
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._timeout == 86400
    assert c._plugin_name == 'jsonfile'
    assert c._extension == 'json'

# Generated at 2022-06-21 03:46:09.703725
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m is not None

# Generated at 2022-06-21 03:46:11.690313
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule({}), BaseFileCacheModule)

# Generated at 2022-06-21 03:46:13.108033
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule({})
    assert cache_module
    assert cache_module.name == 'jsonfile'

# Generated at 2022-06-21 03:46:19.742495
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Try to construct an instance of class CacheModule
    # This should succeed
    try:
        CacheModule()
    except NameError:
        assert False

# Unit test _dump function

# Generated at 2022-06-21 03:46:20.659383
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-21 03:46:24.944469
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin.cache_plugin_name == 'jsonfile'
    assert plugin.file_extension == '.cache'
    assert plugin._timeout == 86400
    assert plugin._load == plugin._load
    assert plugin._dump == plugin._dump

# Generated at 2022-06-21 03:46:26.971263
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache


# Generated at 2022-06-21 03:46:32.037897
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule.name == 'jsonfile'
    assert cacheModule.timeout == 86400
    assert cacheModule.backend is None
    assert cacheModule.plugin_specific_opts == {}
    assert (cacheModule.plugin_specific_options == ['_prefix', '_zones', '_ttl'])

# Generated at 2022-06-21 03:46:35.173930
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    This is an autogenerated test to verify the constructor and method
    signatures of the class.
    """

    c = CacheModule({'_uri': '', '_prefix': '', '_timeout': 86400})

# Generated at 2022-06-21 03:46:35.657990
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-21 03:46:38.369657
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    # Check the default value of attributes
    assert cm._timeout == 86400
    assert cm._prefix is None
    assert cm._uri == u'~/.ansible/tmp/ansible-fact-cache/'

# Generated at 2022-06-21 03:46:45.146198
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule('test_connection', 'test_prefix', 'test_timeout')
    assert plugin.filecache._connection == 'test_connection'
    assert plugin.filecache._prefix == 'test_prefix'
    assert plugin.filecache._timeout == 'test_timeout'

# Generated at 2022-06-21 03:46:46.131026
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module

# Generated at 2022-06-21 03:47:05.950485
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile
    from ansible.plugins.cache import BaseFileCacheModule
    from ansible.module_utils.six import text_type
    from ansible.parsing.ajson import AnsibleJSONDecoder

    # Constructor of class CacheModule
    module = CacheModule()

    # Unit tests for _load method of class CacheModule
    cache_dir1 = tempfile.mkdtemp()
    cache_dir2 = tempfile.mkdtemp()

    file1 = os.path.join(cache_dir1, 'test.json')
    file2 = os.path.join(cache_dir2, 'test.json')

    input_data = {"ansible_facts": {"os_family": "RedHat"}, "metadata": {"status": "ok"}}
    filepath1 = module._create_file_if_

# Generated at 2022-06-21 03:47:09.715609
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("test_CacheModule")
    hostname = 'localhost'
    args = {
        '_uri': '.',
        '_prefix': 'test_CacheModule',
        '_timeout': 100,
    }
    cm1 = CacheModule(plugin='jsonfile', args=args, host=hostname)
    assert cm1.host == hostname
    cm2 = CacheModule(plugin='jsonfile', args={}, host=hostname)
    assert cm2.host == hostname



# Generated at 2022-06-21 03:47:14.052485
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mod = CacheModule()
    assert mod._options['_prefix'] == 'ansible_facts'
    assert mod._options['_timeout'] == 86400
    assert mod._options['_uri'] == None

# Generated at 2022-06-21 03:47:23.833160
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("test_CacheModule")
    import ansible.plugins.cache.jsonfile
    c = ansible.plugins.cache.jsonfile.CacheModule()
    dir_ = c['_uri']
    fname = dir_ + "/" + "test_CacheModule"
    c['_load'](fname)
    c['_dump']("test",fname)
    c['set']("test", "val")
    c['get']("test")
    c['keys']()
    c['contains']('test')
    c['delete']('test')
    c['flush']()
    ansible.plugins.cache.jsonfile.CacheModule.remove_old_data()

# Generated at 2022-06-21 03:47:26.052247
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert "CacheModule" in str(module)



# Generated at 2022-06-21 03:47:28.797414
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    print(cache)

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-21 03:47:33.171626
# Unit test for constructor of class CacheModule
def test_CacheModule():
    prefix = 'test_'
    timeout = 86400
    connection = '/tmp/ansible_cache'
    cache = CacheModule(prefix, timeout, connection)
    assert cache._prefix == prefix
    assert cache._timeout == timeout
    assert cache._connection == connection

# Generated at 2022-06-21 03:47:36.369284
# Unit test for constructor of class CacheModule
def test_CacheModule():
    json_file = CacheModule()
    print (json_file._load)
    print (json_file._dump)
    print (json_file._flush)
    print (json_file._load_metadata)


test_CacheModule()

# Generated at 2022-06-21 03:47:42.767450
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

    # create a dummy fact_cache to test _load()
    fact_cache = {
        "ansible_facts": {
            "os_version": "12.3.9"
        }
    }

    fact_cache_json = json.dumps(fact_cache)
    cache_module.json_cache_path = 'test/unit/plugins/cache/temp_file.json'

    with codecs.open(cache_module.json_cache_path, 'w', encoding='utf-8') as f:
        f.write(fact_cache_json)

    assert cache_module._load(cache_module.json_cache_path) == fact_cache

# Generated at 2022-06-21 03:47:44.482236
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    cc = CacheModule()
    assert cc is not None

# Generated at 2022-06-21 03:48:11.121600
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), object)

# Generated at 2022-06-21 03:48:12.378720
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-21 03:48:13.918917
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test constructor
    cm = CacheModule()
    assert cm.file_extension == "json"

# Generated at 2022-06-21 03:48:15.272854
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert 'CacheModule' == CacheModule.__name__

# Generated at 2022-06-21 03:48:16.881387
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, '_load')
    assert hasattr(CacheModule, '_dump')

# Generated at 2022-06-21 03:48:17.873900
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj is not None

# Generated at 2022-06-21 03:48:23.550928
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Tests Class CacheModule
    """
    args = {'_uri': '.', '_prefix': 'file_'}
    cache_module = CacheModule(None, args)
    assert not cache_module.__doc__

# Generated at 2022-06-21 03:48:27.962173
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)
    assert cache.cache_type == 'jsonfile'
    assert cache._timeout == 86400
    assert cache.file_extension == 'json'
    assert cache._load is not None
    assert cache._dump is not None

# Generated at 2022-06-21 03:48:37.922266
# Unit test for constructor of class CacheModule
def test_CacheModule():

    module = 'jsonfile'
    tmp_dir = '/tmp'
    timeout = 86400

    cache_module = CacheModule(module, tmp_dir, timeout)

    assert cache_module._cache_module == 'jsonfile'
    assert cache_module._timeout == 86400
    assert cache_module._cache_dir == '/tmp'
    assert isinstance(cache_module._load, object)
    assert isinstance(cache_module._dump, object)
    assert cache_module._save_on_exit == False
    assert cache_module._fact_cache == {}
    assert cache_module._fact_cache_filepath == None



# Generated at 2022-06-21 03:48:39.969657
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None
    assert c._timeout == 86400
    assert c._prefix == ''

# Generated at 2022-06-21 03:49:35.929192
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()

# Generated at 2022-06-21 03:49:37.026796
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule() is not None

# Generated at 2022-06-21 03:49:39.736694
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    Construct a CacheModule
    '''
    cm = CacheModule()
    assert cm.get_cache_prefix() is None
    assert cm.get_cache_timeout() == 86400

# Generated at 2022-06-21 03:49:40.238514
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-21 03:49:50.652011
# Unit test for constructor of class CacheModule
def test_CacheModule():
    fc = CacheModule()
    print("test_CacheModule")
    print("----------------")
    print("=== Initial state:")
    print("fc.get_timeout() --> ", fc.get_timeout())
    print("fc.cache_dir()    --> ", fc.cache_dir())
    print("fc.cache_key()    --> ", fc.cache_key())
    print("fc.cacheable()    --> ", fc.cacheable())
    print("fc.get()          --> ", fc.get(""))
    print("fc.set()          --> ", fc.set("", ""))
    print("fc.get('foo')     --> ", fc.get("foo"))
    print("fc.set('foo', 'bar') --> ", fc.set("foo", "bar"))

# Generated at 2022-06-21 03:49:53.738371
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._timeout == 86400
    assert plugin._prefix == 'ansible_fact_cache_'
    assert plugin._valid_characters == 'abcdefghijklmnopqrstuvwxyz0123456789_-'

# Generated at 2022-06-21 03:50:03.210005
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri_path = "caching_path"
    cache_timeout = 10
    cache_prefix = 'test_prefix'

    # Test with both uri as string and as dict
    cache_module_1 = CacheModule({'_uri': uri_path,
                                  '_timeout': cache_timeout,
                                  '_prefix': cache_prefix})

    cache_module_2 = CacheModule({'_uri': {'path': uri_path},
                                  '_timeout': cache_timeout,
                                  '_prefix': cache_prefix})

    assert cache_module_1._uri == cache_module_2._uri
    assert cache_module_1._timeout == cache_timeout
    assert cache_module_1._prefix == cache_prefix

# Generated at 2022-06-21 03:50:11.638023
# Unit test for constructor of class CacheModule
def test_CacheModule():
    def test_with_empty_params():
        cache = CacheModule({})
        assert cache._cachefile == 'ansible-fact-cache'
        assert cache._connection == './'
        assert cache._timeout == 60
        assert cache._prefix == 'ansible_facts'

    def test_with_params():
        cache = CacheModule({'_uri': './', '_prefix': 'ansible_facts', '_timeout': 60})
        assert cache._cachefile == 'ansible-fact-cache'
        assert cache._connection == './'
        assert cache._timeout == 60
        assert cache._prefix == 'ansible_facts'

    test_with_empty_params()
    test_with_params()


# Generated at 2022-06-21 03:50:12.245961
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()

    assert obj is not None

# Generated at 2022-06-21 03:50:12.728895
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-21 03:52:19.717734
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    # Validate CacheModule object is initialized with defaults
    assert cm.get_timeout() == 86400

# Generated at 2022-06-21 03:52:21.522551
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = '/tmp/test_FileCache'
    plugin = CacheModule({'_uri': connection})
    assert plugin._connection == connection

# Generated at 2022-06-21 03:52:22.364908
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-21 03:52:22.830092
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-21 03:52:26.585861
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test = CacheModule(connection=None)
    assert test.get_timeout() == 86400
    assert test.get_prefix() == 'ansible_'
    assert test.get_connection() == None

# Generated at 2022-06-21 03:52:27.106404
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule(None)

# Generated at 2022-06-21 03:52:27.596643
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()

# Generated at 2022-06-21 03:52:34.321913
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    cache_module._timeout = 60
    prefix = cache_module._module.get_option('_prefix')
    timeout = cache_module._module.get_option('_timeout')
    assert(cache_module._timeout == timeout)
    assert(cache_module._prefix == prefix)
    uri = cache_module._module.get_option('_uri')
    assert(cache_module._uri == uri)

# Generated at 2022-06-21 03:52:36.300468
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule(task_vars=dict())
    assert c.task_vars == dict()
    if c._timeout != 86400:
        raise AssertionError()

# Generated at 2022-06-21 03:52:36.995213
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()