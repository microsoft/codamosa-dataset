

# Generated at 2022-06-21 03:44:33.605161
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400

# Generated at 2022-06-21 03:44:38.988486
# Unit test for constructor of class CacheModule
def test_CacheModule():
    def test():
        c = CacheModule(task_vars={'cache_plugin': 'jsonfile',
                                   'cache_plugin_connection': 'localhost',
                                   'cache_plugin_prefix': 'test_',
                                   'cache_plugin_timeout': 60})
        
        # Dir to cache test
        assert c.cache_dir == '/localhost'
        assert c._cache_prefix == 'test_facts'

        # Currect timout
        assert c._cache_timeout == 3600

        # Valid JSON is always UTF-8 encoded.
        assert c._cache_encoding == 'utf-8'
    
    test()

# Generated at 2022-06-21 03:44:39.661267
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-21 03:44:44.220220
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile

    test_dir = tempfile.mkdtemp()
    connection_path = test_dir + "/test.json"
    c = CacheModule({
        '_uri': connection_path,
        '_prefix': None,
        '_timeout': 86400,
        '_fact_namespace': 'plugin:jsonfile',
    })
    assert c.connection_path == connection_path

    # Clean up temp dir
    os.unlink(test_dir + "/test.json")
    os.rmdir(test_dir)

# Generated at 2022-06-21 03:44:49.440580
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # CacheModule constructor needs args which is AnsibleOptions type.
    # AnsibleOptions is a class that has a member variable named 'connection_info' which is a dictionary.
    # So, we need to create a dictionary type variable to pass to CacheModule constructor.
    dummy_connection_info = dict()
    dummy_connection_info["timeout"] = 0
    dummy_connection_info["connection"] = '.'

    # Create CacheModule object.
    test_object = CacheModule(None, dummy_connection_info)

    # Test if the instance is created. 
    assert test_object is not None

    # Test if the value is correctly assigned.
    assert test_object._timeout == 0

# Test for _load() method of class CacheModule

# Generated at 2022-06-21 03:44:56.968102
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_cache_option('namespace') == "ansible_facts"
    assert cache_module.get_cache_option('timeout') == 86400
    assert cache_module.get_cache_option('path') == ''
    assert cache_module.get_cache_option('plugin') == "jsonfile"
    assert cache_module.get_cache_option('_prefix') == ""
    assert cache_module.get_cache_option('_uri') == ''


# Generated at 2022-06-21 03:44:58.310792
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule("test_uri")

# Generated at 2022-06-21 03:45:00.074447
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None
    assert cache_module.cache_plugin_name == 'jsonfile'

# Generated at 2022-06-21 03:45:08.061853
# Unit test for constructor of class CacheModule
def test_CacheModule():
    class connection():
        def __init__(self):
            self.host = 'fake_host'
            self.port = 'fake_port'
            self.password = 'fake_password'
            self.username = 'fake_username'
            self.cache_path = '/fake_host/fake_cache_path'
            self.url = '/fake_host/fake_cache_path'

    cm = CacheModule(connection())
    assert cm.path == '/fake_host/fake_cache_path/facts'


# Generated at 2022-06-21 03:45:17.877362
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    cache.set('hostname', {'redhat': 7, 'suse': 11, 'ubuntu': 14})
    cache.get('hostname')
    cache.get_multiple('hostname')
    cache.has('hostname')
    cache.keys()
    cache.set_multiple('hostname', {'redhat': 7, 'suse': 11, 'ubuntu': 14})
    cache.get('hostname')
    cache.delete('hostname')
    cache.delete_pattern('hostname')
    cache.delete_keys('hostname')

# Generated at 2022-06-21 03:45:27.709028
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.get_cache_prefix() == "ansible", "Default Cache Module Prefix is 'ansible'"
    cm.set_cache_prefix("ansible_test")
    assert cm.get_cache_prefix() == "ansible_test", "Default Cache Module Prefix is 'ansible_test'"
    cm.set_cache_timeout(600)
    assert cm.get_cache_timeout() == 600, "Incorrect Cache Timeout"

# Generated at 2022-06-21 03:45:30.205498
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule.CacheModule({}, '/path/to/somewhere')
    assert cache

# Generated at 2022-06-21 03:45:31.396574
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(None)
    assert cache is not None
    assert cache.config is None

# Generated at 2022-06-21 03:45:33.042907
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Return a testinfra connection object
    conn_obj = CacheModule()


# Unit test to check the contents of plugin_name

# Generated at 2022-06-21 03:45:34.526639
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule()
    assert instance is not None

# Generated at 2022-06-21 03:45:38.769334
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri='/playbooks/dumps'
    prefix='facts'
    time_out=1800
    cb=CacheModule(uri, prefix, time_out)
    assert cb.prefix==prefix
    assert cb.timeout==time_out
    assert cb.basedir==uri
    assert cb.plugin_name=='jsonfile'

# Generated at 2022-06-21 03:45:49.252066
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile

    cache_module = CacheModule()

    # Test for default values
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() is None

    # Test for valid connection string
    cache_module = CacheModule(connection='/tmp')
    assert cache_module.get_connection() == os.path.abspath('/tmp')

    # Test for non-existent directory
    cache_module = CacheModule(connection='/tmp/non-existent-directory')
    assert cache_module.get_connection() == os.path.abspath('/tmp/non-existent-directory')
    try:
        os.rmdir('/tmp/non-existent-directory')
        assert True
    except:
        assert False

    # Test for valid timeout
    cache_

# Generated at 2022-06-21 03:45:56.251715
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filename = 'testfile.txt'
    prefix = 'test'
    timeout = 100
    cache = CacheModule(filename, prefix, timeout)
    assert cache._uri == filename
    assert cache._prefix == prefix
    assert cache._timeout == timeout


# Generated at 2022-06-21 03:45:56.826542
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert(module)

# Generated at 2022-06-21 03:45:58.553516
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-21 03:46:02.335154
# Unit test for constructor of class CacheModule
def test_CacheModule():
    return CacheModule()

# Generated at 2022-06-21 03:46:03.961847
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

if __name__ == '__main__':
    # Unit test for constructor of class CacheModule
    test_CacheModule()

# Generated at 2022-06-21 03:46:11.641705
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import glob
    import os
    from ansible.plugins.cache.jsonfile import CacheModule

    # Make directory to store cached files
    cache_dir = '/tmp/ansible_test/cache/jsonfile'
    os.makedirs(cache_dir, exist_ok=True)

    # Delete previously created cached files in this test run
    for f in glob.glob('{cache_dir}/*.json'.format(cache_dir=cache_dir)):
        os.remove(f)

    # Get the CacheModule plugin
    cache_plugin = CacheModule()

    # Get the 'set' method
    cache_set = cache_plugin._set

    # Build the path to the cached file. Use IP address as fact name.
    ip_address = '127.0.0.1'

    # Call _set method to store a value

# Generated at 2022-06-21 03:46:12.824449
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert isinstance(obj, CacheModule)

# Generated at 2022-06-21 03:46:13.805134
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule()
    assert isinstance(instance, CacheModule)

# Generated at 2022-06-21 03:46:24.326956
# Unit test for constructor of class CacheModule
def test_CacheModule():
    host_name = 'testport1'
    filename = 'testport1.json'
    cache_plugin_connection = 'test/test_cache/'
    timeout = 3600
    prefix = 'test_'

    cache = CacheModule()
    cache.plugin_name = 'jsonfile'
    cache.connection = {'_uri': cache_plugin_connection}
    cache._options = {'_timeout': timeout, '_prefix': prefix}

    # Constructor returns a valid object
    assert cache is not None

    # Default values assigned to member variables
    assert cache._dump_fn == cache._dump
    assert cache._load_fn == cache._load
    assert cache._timeout == timeout
    assert cache._prefix == prefix
    assert cache._cache == {}

    # _get_file_path returns valid path
    assert cache._get_file

# Generated at 2022-06-21 03:46:28.147752
# Unit test for constructor of class CacheModule
def test_CacheModule():

    plugin_name = 'jsonfile'
    test_plugin = CacheModule(plugin_name)
    assert test_plugin.plugin_name == plugin_name
    assert test_plugin.timeout == 86400

# Generated at 2022-06-21 03:46:28.890428
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()

# Generated at 2022-06-21 03:46:30.322394
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mod = CacheModule()
    assert mod.file_extension == '.json'

# Generated at 2022-06-21 03:46:35.388355
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Test if object is created
    result = CacheModule()
    assert result

    # Test if object is an instance of class BaseFileCacheModule
    assert isinstance(result, BaseFileCacheModule)

    # Test if object has required functions
    assert hasattr(result, 'get')
    assert hasattr(result, 'set')
    assert hasattr(result, 'delete')

# Generated at 2022-06-21 03:46:50.396258
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule(None, dict())
    assert obj


# class CacheModuleTestCase(unittest.TestCase):
#     ''' Unit test for CacheModule from jsonfile. this test case is not implement yet
#     '''
#     def setUp(self):
#         pass
#     def tearDown(self):
#         pass
#
#     def test_constructor(self):
#         '''Test for the constructor of CacheModule
#         '''
#         obj = CacheModule(None, dict())
#         assert obj
#
#
# from ansible.module_utils.six import PY3
#
# # Unit test for function has_expired in module jsonfile
# class HasExpiredTestCase(unittest.TestCase):
#     '''Unit test for jsonfile.has_expired
#    

# Generated at 2022-06-21 03:46:56.561231
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule({})
    assert isinstance(m, BaseFileCacheModule)
    assert not m.set('_test_key', '_test_value')
    assert m.get('_test_key') is None
    assert not m.keys()
    assert not m.contains('_test_key')
    assert not m.delete('_test_key')

# Generated at 2022-06-21 03:46:59.675684
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule("/tmp")
    assert cache.plugin_name == "jsonfile"
    assert cache.plugin_path == "/tmp/ansible_jsonfile_facts"

# Generated at 2022-06-21 03:47:02.858986
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Currently, the only way of instantiating the base class is to call it with valid arguments.
    # In that respect, we can just assert that the constructor does not raise an exception.
    assert CacheModule(None)

# Generated at 2022-06-21 03:47:04.743664
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.has_plugin_options() == False

# Generated at 2022-06-21 03:47:09.425174
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.get_timeout() == 86400
    assert cm._cachefile_extension == '.json'
    assert isinstance(cm._load, object)
    assert isinstance(cm._dump, object)

# Generated at 2022-06-21 03:47:11.069791
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-21 03:47:13.409464
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-21 03:47:14.065455
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

# Generated at 2022-06-21 03:47:15.282916
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert isinstance(cache_plugin, CacheModule)

# Generated at 2022-06-21 03:47:25.525825
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Constructor test of class CacheModule
    :return:
    """
    cache = CacheModule()
    cache.set('/tmp/test1', "test1")
    print (cache.get('/tmp/test1'))

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-21 03:47:26.427028
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-21 03:47:28.074701
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-21 03:47:28.711840
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-21 03:47:33.470100
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Unit test for constructor of class CacheModule.

    Args:
        None

    Returns:
        None

    Raises:
        None
    """

    cache = CacheModule()

    # This should always create a .json extension
    assert cache._get_extension() == '.json'

# Generated at 2022-06-21 03:47:34.376840
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c != None

# Generated at 2022-06-21 03:47:35.831525
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-21 03:47:39.648050
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test constructor of class CacheModule
    cachemodule = CacheModule()

    # Test _load function of CacheModule class
    assert cachemodule._load('test_file') == 0
    # Test _dump function of CacheModule class
    assert cachemodule._dump({'test_key': 'test_value'}, 'test_file_dump') == 0


# Test importing of CacheModule class

# Generated at 2022-06-21 03:47:43.771634
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import sys
    import os

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

    from ansible.plugins.cache.jsonfile import CacheModule

    cache = CacheModule()


if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-21 03:47:45.761595
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()

    assert plugin._timeout == 86400
    assert plugin._load == CacheModule._load

# Generated at 2022-06-21 03:48:01.524781
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), BaseFileCacheModule)
    assert CacheModule.__doc__, "No docstring for CacheModule"


# Generated at 2022-06-21 03:48:03.139556
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('/tmp', 'cache_')
    assert cache, "CacheModule constructor must return an object"

# Generated at 2022-06-21 03:48:05.998054
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    cache_plugin.get_options()


# Generated at 2022-06-21 03:48:16.318225
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Test the constructor from object CacheModule
    test_cache_module = CacheModule()

    assert test_cache_module.uri == "~/.ansible/tmp/ansible-local"
    assert test_cache_module.prefix == 'ansible_fact_cache_file'
    assert test_cache_module.timeout == 86400

    # Test the constructor from object CacheModule with modified parameters
    test_cache_module = CacheModule(
        uri='~/ansible-tests-folder/ansible-tmp',
        timeout=86401,
        prefix='ansible_fact_cache_file_prefix'
        )

    assert test_cache_module.uri == "~/ansible-tests-folder/ansible-tmp"
    assert test_cache_module.prefix == 'ansible_fact_cache_file_prefix'

# Generated at 2022-06-21 03:48:27.862579
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import shutil
    # Initialize CacheModule object
    cache_module = CacheModule()
    # Initialize some basic parameters
    cache_module.cache_dir = '/tmp/test_data'
    # Create cache_dir if not exist
    if not os.path.exists(cache_module.cache_dir):
        os.makedirs(cache_module.cache_dir)
    # Create testing data
    test_dict = {'key1': 'value1', 'key2': {'inner_key1': 'inner_value1', 'inner_key2': 'inner_value2'}}
    # Make sure the file path is proper
    assert cache_module._get_file_path('myfile') == '/tmp/test_data/myfile'
    # Test _dump and _load
    cache_module._dump

# Generated at 2022-06-21 03:48:31.229990
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    #assert 'hash_function' not in cache._options
    assert cache._prefix == 'ansible-cache'
    assert cache._timeout == 86400


# Generated at 2022-06-21 03:48:33.847384
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._uri == None
    assert CacheModule._prefix == 'ansible_'
    assert CacheModule._timeout == 86400

# Generated at 2022-06-21 03:48:34.918684
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert not CacheModule(dict())

# Generated at 2022-06-21 03:48:36.946165
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': '/cachedir'})

# Generated at 2022-06-21 03:48:38.565618
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.file_extension == "json"

# Generated at 2022-06-21 03:49:06.281931
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-21 03:49:08.133418
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.get_option('_uri') is not None
    assert c.get_option('_timeout') == 86400

# Generated at 2022-06-21 03:49:09.661885
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache

# Generated at 2022-06-21 03:49:11.247081
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''

# Generated at 2022-06-21 03:49:12.924221
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)
    module = CacheModule()
    assert isinstance(module, CacheModule)
    assert isinstance(module, BaseFileCacheModule)

# Generated at 2022-06-21 03:49:17.418392
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('')
    assert cache.uri == ''
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-cache'
    assert cache._valid_extensions == ['.cache']
    assert cache.valid

# Generated at 2022-06-21 03:49:25.779854
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Instansiate the CacheModule
    cache_module = CacheModule()
    # Test default values
    assert cache_module._cache_plugin_name == 'jsonfile'
    assert cache_module._cache_prefix == ''
    assert cache_module._timeout == 86400
    # Test prefix
    cache_module._setup_cache_prefix(None)
    assert cache_module._cache_prefix == 'ansible_cachefile_jsonfile'
    cache_module._setup_cache_prefix('unit')
    assert cache_module._cache_prefix == 'unit_cachefile_jsonfile'
    # Test timeout
    cache_module._setup_timeout(20)
    assert cache_module._timeout == 20
    # Test cache_prefix
    assert '_' in cache_module._cache_prefix

# Generated at 2022-06-21 03:49:31.974029
# Unit test for constructor of class CacheModule
def test_CacheModule():
    #Load a sample configuration
    config = {'ANSIBLE_CACHE_PLUGIN_PREFIX': 'sample'}
    #Declare a class instance
    cacheModule = CacheModule(config)
    #Test whether the configuration matches the expected value
    assert cacheModule.get_option('_prefix') == config['ANSIBLE_CACHE_PLUGIN_PREFIX']

# Generated at 2022-06-21 03:49:33.078025
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

# Generated at 2022-06-21 03:49:37.172093
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filepath = '/tmp/ansible-cache-plugin-jsonfile'
    connection = CacheModule(filepath)
    assert connection._path == filepath
    assert connection._prefix == 'ansible-fact'
    assert connection._timeout == 86400
    assert isinstance(connection, CacheModule)

# Generated at 2022-06-21 03:50:43.046837
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None


# Generated at 2022-06-21 03:50:44.806849
# Unit test for constructor of class CacheModule
def test_CacheModule():
  print('CacheModule test')
  print(CacheModule('json'))

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-21 03:50:47.403316
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Do nothing but only check whether the constructor of CacheModule is valid.
    dummy_param = '/tmp'
    cache_obj = CacheModule(dummy_param)

# Generated at 2022-06-21 03:50:49.429654
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_option('_prefix') == 'ansible-cache'
    assert cache.get_option('_timeout') == 86400

# Generated at 2022-06-21 03:50:50.493327
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({})
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-21 03:50:51.028680
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule(0)

# Generated at 2022-06-21 03:50:57.685378
# Unit test for constructor of class CacheModule
def test_CacheModule():
    temp = CacheModule.__new__(CacheModule)
    assert temp
    obj = CacheModule()
    assert obj
    obj = CacheModule({'_uri': '/hello/world'})
    assert obj
    assert obj._cachefile_path('/hello/world') == '/hello/world/facts//.cache'
    assert obj._cachefile_path('/hello/world/') == '/hello/world/facts//.cache'
    assert obj._cachefile_path('/hello/world', 'myhostname') == '/hello/world/facts/myhostname.cache'
    assert obj._cachefile_path('/hello/world/', 'myhostname') == '/hello/world/facts/myhostname.cache'

# Generated at 2022-06-21 03:51:00.623842
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()

    assert isinstance(obj, BaseFileCacheModule)
    assert obj._timeout == 86400
    assert not hasattr(obj, '_cache')
    assert not hasattr(obj, '_expiration')

# Generated at 2022-06-21 03:51:02.889703
# Unit test for constructor of class CacheModule
def test_CacheModule():
	assert CacheModule.__name__ == "CacheModule"
	assert CacheModule.__doc__ == "A caching module backed by json files."

# Generated at 2022-06-21 03:51:04.293159
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_basedir() is None
    assert cache.get_extension() == '.json'

# Generated at 2022-06-21 03:53:24.405615
# Unit test for constructor of class CacheModule
def test_CacheModule():
    AnsibleCache = CacheModule()
    assert AnsibleCache

# Generated at 2022-06-21 03:53:24.891710
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-21 03:53:26.422153
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert all(['CacheModule' in x for x in dir(CacheModule)])

# Generated at 2022-06-21 03:53:27.603271
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule
    obj = CacheModule(None)
    assert obj

# Generated at 2022-06-21 03:53:28.983993
# Unit test for constructor of class CacheModule
def test_CacheModule():
    if CacheModule():
        print("CacheModule constructor test passed")


# Generated at 2022-06-21 03:53:29.751085
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-21 03:53:30.789699
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.plugin_name == 'jsonfile'

# Generated at 2022-06-21 03:53:32.078750
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filename = "test.json"
    c = CacheModule(filename)
    assert c != None

# Generated at 2022-06-21 03:53:36.092900
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import BaseFileCacheModule
    config = {
        '_uri': '/home/ansible/cache',
        '_prefix': 'ansible',
        '_timeout': 86400,
    }
    cache = CacheModule(config)
    assert isinstance(cache, BaseFileCacheModule)
    assert cache._config == config
    assert cache._connection == config['_uri']
    assert cache._prefix == config['_prefix']
    assert cache._timeout == config['_timeout']


# Generated at 2022-06-21 03:53:37.449664
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.data == {}