

# Generated at 2022-06-21 03:44:41.020668
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._prefix == 'ansible-factcache'
    assert cache._flush_interval == 10
    assert cache._cachetime == 86400
    assert cache._cache_files_dir == '~/.ansible/tmp'



# Generated at 2022-06-21 03:44:42.085584
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.file_extension == '.cache'

# Generated at 2022-06-21 03:44:46.247057
# Unit test for constructor of class CacheModule
def test_CacheModule():
    tmpdir = tempfile.mkdtemp()
    cache_plugin = CacheModule({'_uri': tmpdir})
    assert cache_plugin is not None
    shutil.rmtree(tmpdir)



# Generated at 2022-06-21 03:44:53.580108
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filepath = 'test/jsonfile_example'
    obj = CacheModule()
    assert isinstance(obj, CacheModule)
    obj._dump(value={"1": "1", "2": "2"}, filepath=filepath)
    assert obj._load(filepath=filepath) == {'1': '1', '2': '2'}

# Generated at 2022-06-21 03:44:56.404028
# Unit test for constructor of class CacheModule
def test_CacheModule():

    from ansible.plugins.cache.jsonfile import CacheModule

    # Test the constructor of class CacheModule
    cache_plugin = CacheModule(timeout=0)

    assert cache_plugin._timeout == 0

# Generated at 2022-06-21 03:45:08.477881
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Without any configuration
    cache = CacheModule()
    assert hasattr(cache, '_uri')
    assert cache._uri == '/tmp'
    assert hasattr(cache, '_prefix')
    assert cache._prefix == ''
    assert hasattr(cache, '_timeout')
    assert cache._timeout == 3600

    # With configuration
    cache = CacheModule({'_uri': '/cachedir', '_prefix': 'test_', '_timeout': 1234})
    assert hasattr(cache, '_uri')
    assert cache._uri == '/cachedir'
    assert hasattr(cache, '_prefix')
    assert cache._prefix == 'test_'
    assert hasattr(cache, '_timeout')
    assert cache._timeout == 1234

    # With incorrect configuration

# Generated at 2022-06-21 03:45:16.045994
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, BaseFileCacheModule)
    # Make sure the module is at least functional
    cm._uri = 'test_uri'
    cm._prefix = 'test_prefix'
    cm._timeout = 0
    cm._load('/etc/hosts')
    cm._dump(['hello', 'world'], '/tmp/test_output.json')

# Generated at 2022-06-21 03:45:18.056424
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule(None)
    assert cache_plugin is not None

# Generated at 2022-06-21 03:45:19.721360
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert True


# Generated at 2022-06-21 03:45:21.154296
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-21 03:45:26.983518
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule()
    assert hasattr(instance, 'get')
    assert hasattr(instance, 'set')
    assert hasattr(instance, 'delobj')
    assert hasattr(instance, 'keys')
    assert hasattr(instance, 'contains')

# Generated at 2022-06-21 03:45:28.463242
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-21 03:45:29.438569
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert isinstance(obj, CacheModule)

# Generated at 2022-06-21 03:45:35.030123
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test = CacheModule('/some/path')
    assert test._prefix == 'ansible-facts'
    assert test._timeout == 86400
    test = CacheModule('/some/path', 'prefix-', 10)
    assert test._timeout == 10
    assert test._prefix == 'prefix-'

# Generated at 2022-06-21 03:45:36.586092
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert isinstance(x, CacheModule)

# Generated at 2022-06-21 03:45:39.603988
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400

# Generated at 2022-06-21 03:45:42.771542
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert 'CacheModule' == CacheModule.__name__
    assert 'cache_plugin.jsonfile' == CacheModule.__module__

# Generated at 2022-06-21 03:45:45.945198
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    import ansible.plugins.cache.jsonfile
    assert cache_plugin.__class__ == ansible.plugins.cache.jsonfile.CacheModule

# Generated at 2022-06-21 03:45:51.576100
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = {
        "_uri": ".",
        "_prefix": "",
        "_timeout": 100
    }

    module = CacheModule()
    module.set_options(data)
    assert module._uri == "."
    assert module._prefix == ""
    assert module._timeout == 100

# Generated at 2022-06-21 03:45:54.590702
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Test if CacheModule works."""

    # Construct an instance of CacheModule and test
    # that it has the correct attributes
    # We need to first create a connection to the
    # local filesystem
    conn = None
    # Now construct the CacheModule instance
    cache_module = CacheModule(conn)
    assert isinstance(cache_module, CacheModule)
    assert cache_module.timeout == 86400
    assert cache_module.connection == conn

# Generated at 2022-06-21 03:45:59.739047
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonfile = CacheModule()
    assert isinstance(jsonfile, CacheModule)
    assert isinstance(jsonfile, object)

# Generated at 2022-06-21 03:46:01.617755
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-21 03:46:06.376270
# Unit test for constructor of class CacheModule
def test_CacheModule():
    config = dict(path='/path/to/dir')
    cache_obj = CacheModule(config)
    assert cache_obj.plugin_name == 'jsonfile'
    assert cache_obj.plugin_path == '/path/to/dir'

# Generated at 2022-06-21 03:46:10.744049
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Constructor of class CacheModule"""
    c = CacheModule()
    assert c._timeout == 86400
    assert c._plugin_name == 'jsonfile'

# Generated at 2022-06-21 03:46:12.815142
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.cache_plugin_name == 'jsonfile'

# Generated at 2022-06-21 03:46:19.793212
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonfile_cache_module = CacheModule()
    
    assert jsonfile_cache_module.connection == './cache/ansible_facts'
    assert jsonfile_cache_module._timeout == 86400
    assert jsonfile_cache_module._module_name == 'ansible.cache.jsonfile'
    assert jsonfile_cache_module._plugin_name == 'jsonfile'
    assert jsonfile_cache_module._prefix == 'ansible_facts'

# Generated at 2022-06-21 03:46:23.009679
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create instance of CacheModule
    cache_obj = CacheModule({'_uri': '/tmp/ansible/cache'})

    # Check that _uri is set in cache_obj
    assert cache_obj._uri == '/tmp/ansible/cache'

# Generated at 2022-06-21 03:46:26.920811
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test-json-plugin.json') == json.load(open('/tmp/test-json-plugin.json'), cls=AnsibleJSONDecoder)

# Generated at 2022-06-21 03:46:36.913890
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

    assert(cm.get_cache_timeout() == 86400)

    cm._timeout = 10
    assert(cm.get_cache_timeout() == 10)

    with pytest.raises(Exception) as excinfo:
        cm._base_dir = 1
        cm._validate_base_dir()
    assert('must be a path to an existing directory' in str(excinfo.value))

    cm._base_dir = '/tmp'
    cm._validate_base_dir()
    assert(cm._validate_base_dir() is None)  # because it doesn't return anything

    cm._base_dir = '/tmp'
    cm._prefix = 'foo'
    cm._validate_prefix()
    assert(cm._validate_prefix() is None)  # because it doesn't return anything



# Generated at 2022-06-21 03:46:41.226206
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''Create cache object and use file cache module.'''
    cache_module = CacheModule()
    cache_module.set_options({'_timeout': 3})
    assert cache_module.get_options()['_timeout'] == 3

# Generated at 2022-06-21 03:46:48.292742
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None


# Generated at 2022-06-21 03:46:49.924378
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None, "Failed to create instance of CacheModule"

# Generated at 2022-06-21 03:46:53.109118
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule, type)
    c = CacheModule()
    assert c is not None, 'Failed to instantiate CacheModule()'

# Generated at 2022-06-21 03:46:59.872084
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cls=CacheModule()
    assert cls._prefix == '.ansible_cache'
    assert cls._connection == '/tmp'
    assert cls._timeout == 86400
    assert cls.validate_filepath() == None
    assert cls.get_cache_filepath() == '/tmp/.ansible_cache/ansible-fact-cache'
    assert cls.get_value_from_filepath() == None


# Generated at 2022-06-21 03:47:01.265072
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("Constructor CacheModule")
    cache = CacheModule()

# Generated at 2022-06-21 03:47:14.765828
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.errors import AnsibleError
    from ansible.plugins.cache import get_cache_plugin

    # Check that a default cache is found
    cache_plugin = get_cache_plugin()
    assert cache_plugin is not None

    # This will fail, as we don't have a cache plugin named 'does_not_exist'
    try:
        get_cache_plugin('does_not_exist')
        assert False, "Should've thrown"
    except AnsibleError:
        pass

    # Check that we can instantiate a CacheModule, and that it inherits from BaseFileCacheModule
    cache_plugin = get_cache_plugin('jsonfile')
    assert isinstance(cache_plugin, CacheModule)
    assert issubclass(CacheModule, BaseFileCacheModule)

    # Check that the CacheModule docstring and options are present
   

# Generated at 2022-06-21 03:47:16.279537
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test creation of an empty CacheModule object
    cacheobj = CacheModule()

# Generated at 2022-06-21 03:47:19.085243
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    Test the creation of a CacheModule object
    '''
    cm = CacheModule()

    # Make sure name is set
    assert cm.name == "jsonfile"

    # Make sure _timeout is set
    assert cm._timeout == 86400

# Generated at 2022-06-21 03:47:30.077022
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(config=dict(path='mypath'))
    assert cache.plugin_name == 'jsonfile', 'Expected plugin name: jsonfile, got: %s' % cache.plugin_name
    assert cache.plugin_prefix == 'ansible_fact_cache_', 'Expected plugin_prefix: ansible_fact_cache_, got: %s' % cache.plugin_prefix
    assert cache._connection == 'mypath', 'Expected _connection: mypath, got: %s' % cache._connection
    assert cache.timeout == 86400, 'Expected timeout: 86400, got: %s' % cache.timeout
    assert cache.plugin_path_exists() == False, 'Expected plugin_path_exists: False, got: %s' % cache.plugin_path_exists()

# Unit tests for

# Generated at 2022-06-21 03:47:34.199388
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Validate that constructor has no exceptions
    try:
        cache_mock = CacheModule()
    except Exception:
        assert True == False, "Exception when creating CacheModule object"
    else:
        assert True == True, "No exceptions thrown when creating CacheModule object"


# Generated at 2022-06-21 03:47:49.593039
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Arrange
    cache_module = CacheModule()
    # Action
    # Assert
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-21 03:47:54.014262
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('_uri','_prefix','_timeout')
    assert cache._uri == '_uri'
    assert cache._prefix == '_prefix'
    assert cache._timeout == '_timeout'
    assert cache._load() == None
    assert cache._dump() == None

# Generated at 2022-06-21 03:47:56.496443
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._load, '_load of CacheModule is not declared.'
    assert CacheModule._dump, '_dump of CacheModule is not declared.'

# Generated at 2022-06-21 03:48:03.024508
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_json_obj = CacheModule()

    assert isinstance(cache_json_obj.get_cache_prefix(), str)
    assert isinstance(cache_json_obj.get_cache_timeout(), int)

    assert isinstance(cache_json_obj.get_cache(), dict)
    assert isinstance(cache_json_obj._load('/test/test'), dict)
    assert isinstance(cache_json_obj._dump('test', '/test/test'), None)

    assert isinstance(cache_json_obj.get('test'), dict)
    assert isinstance(cache_json_obj.set('test', 'test'), None)
    assert isinstance(cache_json_obj.keys(), list)

# Generated at 2022-06-21 03:48:11.768927
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    #
    # Check if init class is set
    #
    assert hasattr(cache, '_load')
    assert hasattr(cache, '_dump')
    assert hasattr(cache, '_load')
    assert hasattr(cache, '_dump')
    assert hasattr(cache, '_load')
    assert hasattr(cache, '_dump')
    assert hasattr(cache, '_load')
    assert hasattr(cache, '_dump')
    assert hasattr(cache, '_load')
    assert hasattr(cache, '_dump')

# Generated at 2022-06-21 03:48:13.094411
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Unit tests for the ModuleCache
    """
    mod = CacheModule()
    assert mod._timeout == 86400
    assert mod._prefix == 'ansible-facts'
    assert mod._load == CacheModule._load
    assert mod._dump == CacheModule._dump

# Generated at 2022-06-21 03:48:14.357744
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        c = CacheModule()
    except:
        print('exception raised when creating an instance of CacheModule')
        assert False

# Generated at 2022-06-21 03:48:22.076327
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import BaseFileCacheModule
    from ansible.module_utils._text import to_bytes

    fake_module_name = 'foo.bar'
    fake_class = type('FakeClass', (object,), {'__module__': fake_module_name})
    cache_module = CacheModule()
    assert isinstance(cache_module, BaseFileCacheModule)
    assert cache_module._plugin_name == 'jsonfile'
    assert cache_module._timeout == 86400
    assert cache_module._connection is None
    assert cache_module._prefix is None
    assert cache_module._load_name == '_load'
    assert cache_module._dump_name == '_dump'
    assert cache_module._cache_class_name == 'CacheModule'

# Generated at 2022-06-21 03:48:23.822823
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    assert(isinstance(cache, CacheModule))


# Generated at 2022-06-21 03:48:27.820636
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.config == {
        '_timeout': 86400,
        '_prefix': u'ansible-',
        '_uri': u'/tmp/ansible'
    }
    assert module.applied_prefix == u'ansible-jsonfile'

# Generated at 2022-06-21 03:48:53.540933
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._prefix == 'ansible-facts'
    assert CacheModule._timeout == 86400

# Generated at 2022-06-21 03:48:54.992382
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """ instantiate the plugin to make sure it works """
    x = CacheModule()
    assert 1

# Generated at 2022-06-21 03:48:56.516511
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert(module.__class__.__name__ == 'CacheModule')

# Generated at 2022-06-21 03:48:57.562323
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule({'_uri': '/tmp/jsonfile'})
    assert c

# Generated at 2022-06-21 03:48:58.321502
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

# Generated at 2022-06-21 03:48:59.045877
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-21 03:49:05.498775
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache=CacheModule()
    #In BaseFileCacheModule constructor, self.path is initialized to None
    assert cache.path is None
    assert cache.file_extension is ".json"
    assert cache.plugin_name == 'jsonfile'
    # Base class has the following attributes
    assert cache.timeout == 86400
    assert cache.prefix == ''

# Generated at 2022-06-21 03:49:06.908358
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert type(cache_plugin) == CacheModule

# Generated at 2022-06-21 03:49:08.075845
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-21 03:49:09.661793
# Unit test for constructor of class CacheModule
def test_CacheModule():
    implementation = CacheModule()
    assert implementation._connection is None

# Generated at 2022-06-21 03:50:13.827793
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache

# Generated at 2022-06-21 03:50:14.912315
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.get_plugin_options() == {
        "timeout": 86400
    }

# Generated at 2022-06-21 03:50:19.198943
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os

    _tmp_dir = "/tmp"
    _uri = os.path.join(_tmp_dir, "ansible_cache_plugin")
    _prefix = "jsonfile"
    _timeout = 100

    cache = CacheModule(_uri, _prefix, _timeout)
    assert cache._uri == _uri
    assert cache._prefix == _prefix
    assert cache._timeout == _timeout
    assert cache._load_cache() is None
    assert cache._save_cache() is None
    assert cache._purge_cache() is None

# Generated at 2022-06-21 03:50:22.040282
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule({'_uri':'test_path'})
    assert(module)
    assert(module.filecache_plugin)
    assert(module.filecache_ext)


# Generated at 2022-06-21 03:50:29.970026
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Load the json file
    filepath_json_file = '../../../plugins/cache/jsonfile.py'
    # Load the cache module and initialize the cacheplugin with default parameters
    _cachemodule = CacheModule()
    # Call the _load method
    #data = _cachemodule._load(filepath_json_file)
    # Call the _dump method
    #data_str = _cachemodule._dump(data, '/tmp/json_file_dump')

    #print('cachemodule._uri: %s' % _cachemodule._uri)
    print('cachemodule._prefix: %s' % _cachemodule._prefix)
    #print('cachemodule._timeout: %s' % _cachemodule._timeout)

# Generated at 2022-06-21 03:50:34.299271
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    from ansible.plugins.cache.jsonfile import CacheModule

    cache_dir = tempfile.mkdtemp()
    cache_module = CacheModule({'_uri': cache_dir})
    assert cache_module.cache_dir == cache_dir

# Generated at 2022-06-21 03:50:35.779979
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.timeout == 86400

# Generated at 2022-06-21 03:50:46.331469
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test constructor of class CacheModule
    class PluginManager(object): pass
    class BaseCacheModule(object): pass
    plugin_manager = PluginManager()
    bcache = BaseCacheModule()
    plugin_name = 'test'
    task_uuid = 'test_uuid'
    cache_key = 'test_cache_key'
    data = 'test_data'
    cm = CacheModule(plugin_manager, bcachemodule=bcache, cache_key=cache_key, data=data, task_uuid=task_uuid, plugin_name=plugin_name)
    assert isinstance(cm, CacheModule)
    assert cm.cache_key == cache_key
    assert cm.data == data
    assert cm.task_uuid == task_uuid
    assert cm.plugin_name == plugin_name

# Generated at 2022-06-21 03:50:49.956673
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Create a CacheModule object
    """
    CacheModule({
        'config': {
            'fact_caching_timeout': 3600
        },
        'env': {
            'ANSIBLE_CACHE_PLUGIN_TIMEOUT': '86400'
        }
    })

# Generated at 2022-06-21 03:50:53.881710
# Unit test for constructor of class CacheModule
def test_CacheModule():
    json_data = {'Ansible': 'AWESOME'}
    obj = CacheModule()
    assert obj is not None
    filename = obj._get_cache_file_path(json_data)
    assert filename is not None
    data = obj._load(filename)
    assert data is not None
    assert data == json_data

# Generated at 2022-06-21 03:53:13.192911
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule(connection='path')
    assert module._connection == 'path'
    assert module._prefix == None

# Generated at 2022-06-21 03:53:19.803103
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, '_load')
    assert hasattr(CacheModule, '_dump')
    assert hasattr(CacheModule, 'get')
    assert hasattr(CacheModule, 'set')
    assert hasattr(CacheModule, 'keys')
    assert hasattr(CacheModule, 'contains')
    assert hasattr(CacheModule, 'delete')
    assert hasattr(CacheModule, 'flush')
    assert hasattr(CacheModule, 'copy')
    assert hasattr(CacheModule, '_prefix_path')

# Generated at 2022-06-21 03:53:21.273251
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert (CacheModule('/tmp/test').__class__.__name__ == 'CacheModule')

# Generated at 2022-06-21 03:53:25.073381
# Unit test for constructor of class CacheModule
def test_CacheModule():
    hostvars = dict(
        inventory_hostname='web01',
        environment='production',
        foo='bar'
    )

    plugin = CacheModule()

    plugin.set(hostvars, 'web01')

    result = plugin.get('web01')

    assert result == hostvars

# Generated at 2022-06-21 03:53:27.379241
# Unit test for constructor of class CacheModule
def test_CacheModule():
    params = {'_uri': '/tmp'}
    cache = CacheModule(params)
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-21 03:53:29.332688
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    cache = CacheModule()
    assert cache is not None


# Generated at 2022-06-21 03:53:35.913228
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    # If the plugin support 'get_option' method
    assert cache_plugin.get_option('_timeout') == 86400
    # If the plugin will be saved in a directory called 'filecache'
    assert cache_plugin.get_option('_prefix') == 'filecache'

# Generated at 2022-06-21 03:53:39.274982
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert isinstance(obj, CacheModule)
    assert isinstance(obj, BaseFileCacheModule)
    assert hasattr(obj, '_prefix')
    assert not hasattr(obj, '_timeout')


# Generated at 2022-06-21 03:53:49.360171
# Unit test for constructor of class CacheModule

# Generated at 2022-06-21 03:53:50.801825
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)
