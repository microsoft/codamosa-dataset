

# Generated at 2022-06-21 03:44:34.219711
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule(None, None)
    assert isinstance(module, BaseFileCacheModule)

# Generated at 2022-06-21 03:44:38.749974
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # assertCanChangeSystemConfiguration should be True because CacheModule does not change system configuration
    assertCacheModule(CacheModule(), True, True)


# Generated at 2022-06-21 03:44:45.688011
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_cache_timeout() == 86400
    assert cache_module.get_cache_prefix() == 'ansible-cache'
    assert cache_module.get_cache_uri() == "$HOME/.ansible/tmp/${ANSIBLE_REMOTE_USER}/cache/"

# Generated at 2022-06-21 03:44:55.731264
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm=CacheModule()
    assert hasattr(cm, '_get_file_path')
    assert hasattr(cm, '_load')
    assert hasattr(cm, '_dump')
    assert hasattr(cm, '_load_data')
    assert hasattr(cm, '_save_data')
    assert hasattr(cm, '_flush_data')
    assert hasattr(cm, 'get')
    assert hasattr(cm, 'set')
    assert hasattr(cm, 'has_expired')
    assert hasattr(cm, 'flush')

# Generated at 2022-06-21 03:44:56.834803
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert(isinstance(cm, BaseFileCacheModule))

# Generated at 2022-06-21 03:44:57.970314
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule, object)



# Generated at 2022-06-21 03:44:58.444523
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c=CacheModule()

# Generated at 2022-06-21 03:45:02.073035
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_name = 'test_CacheModule'
    cache_dir  = '/tmp/ansible-%s' % cache_name
    plugin     = CacheModule(cache_name)
    plugin._uri = cache_dir
    assert plugin._store == cache_dir
    assert plugin.cache_name == cache_name


# Generated at 2022-06-21 03:45:02.861067
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': '/tmp'})

# Generated at 2022-06-21 03:45:08.515394
# Unit test for constructor of class CacheModule
def test_CacheModule():

    filename = 'test_CacheModule.json'
    test_cache = CacheModule(config=dict(
        _uri='/path/to/cache',
        _prefix=None,
        _timeout=86400,
        _ext='.json'),
        ds=dict(path=filename, data=dict(test=True),))

    assert test_cache == {}

    test_cache._dump(dict(test=True), filename)

# Generated at 2022-06-21 03:45:18.945136
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Test the constructor of class CacheModule
    """
    data = {
        '_cache' : {
            'plugin_name': 'jsonfile',
            'has_expired': False,
            'expires': 0,
            '_connection': {
                'plugin_name': 'jsonfile',
                '_options': {
                    '_uri': '/tmp/ansible_test/ansible_facts',
                    '_timeout': 86400
                }
            }
        }
    }
    cache = CacheModule(data=data)
    assert cache._dump == cache._save

# Generated at 2022-06-21 03:45:23.502745
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': 'test/'})
    print(cache)


if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-21 03:45:24.983226
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule('file', 'file', 'file')

# Generated at 2022-06-21 03:45:25.902556
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm

# Generated at 2022-06-21 03:45:38.919065
# Unit test for constructor of class CacheModule
def test_CacheModule():

    import os

    try:
        # Create a directory for CacheModule
        os.mkdir('/tmp/ansible_CacheModule/')
    except OSError:
        pass

    CacheModuleClass = CacheModule()
    # Set the values to '_timeout', '_prefix' and '_uri'
    CacheModuleClass._timeout = 43200
    CacheModuleClass._prefix = 'test_'
    CacheModuleClass._uri = '/tmp/ansible_CacheModule/'
    # Get the path of the file
    test_file = CacheModuleClass._get_cache_path('test_file')
    # Write to the file for testing purpose
    CacheModuleClass._dump(['fetch_test_data'], test_file)
    # Read from the file
    result = CacheModuleClass._load(test_file)
    # Assert

# Generated at 2022-06-21 03:45:39.749868
# Unit test for constructor of class CacheModule
def test_CacheModule():
    return True

# Generated at 2022-06-21 03:45:40.502724
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module

# Generated at 2022-06-21 03:45:41.906320
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()


# Generated at 2022-06-21 03:45:50.015979
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os.path import join
    from os import listdir
    from ansible.module_utils.basic import EnvironmentError

    ansible_vars = dict(
        ansible_connection='local',
        ansible_host=None
    )
    uri = mkdtemp()
    try:
        cache = CacheModule(uri, ansible_vars=ansible_vars)
        cache.set('foo', dict(bar='baz'))
        assert cache.get('foo') == dict(bar='baz')
        # Test that there's only one file for 'foo':
        assert len(listdir(uri)) == 1
    finally:
        rmtree(uri)

# Generated at 2022-06-21 03:45:51.501147
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-21 03:45:55.905842
# Unit test for constructor of class CacheModule
def test_CacheModule():
    myCachedData = CacheModule({'_uri': 'cache_data_file'})
    assert myCachedData.get_basedir() == 'cache_data_file'

# Generated at 2022-06-21 03:45:59.063024
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._load('tests/unit/output/json_file_cache_module/hello.json') == {'a': 'b'}
    assert module._load('tests/unit/output/json_file_cache_module/non-existing.json') == {}

# Generated at 2022-06-21 03:46:01.154148
# Unit test for constructor of class CacheModule
def test_CacheModule():
    my_uri = '/path/to/cache_file'
    my_timeout = 86400
    cache_module = CacheModule(my_uri, my_timeout)
    assert cache_module is not None

# Generated at 2022-06-21 03:46:06.775419
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = '/home/bob/somefile.json'
    prefix = 'pre'
    timeout = 10

    end = CacheModule(uri=uri, prefix=prefix, timeout=timeout)

    assert end._uri == uri
    assert end._prefix == prefix
    assert end._timeout == timeout

# Generated at 2022-06-21 03:46:13.627569
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._load == c.load
    assert c._dump == c.dump
    assert c._prefix == c.cache_prefix
    assert c._timeout == c.cache_timeout
    assert c._connection == c.cache_connection
    assert c._load('test')


# Generated at 2022-06-21 03:46:18.849372
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule

    cacheModule = CacheModule(connection='connection.txt')
    assert cacheModule.get_connection() == 'connection.txt'

    cacheModule = CacheModule(connection='connection.txt', timeout='900')
    assert cacheModule.get_timeout() == '900'

# Generated at 2022-06-21 03:46:20.514645
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    # Testing the constructor
    assert cache._prefix == ''
    assert cache._timeout == 86400

# Generated at 2022-06-21 03:46:22.737255
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule(None, task_vars=dict(ansible_check_mode=False))
    assert module


# Generated at 2022-06-21 03:46:24.944190
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mod = CacheModule()
    assert mod != None

# Generated at 2022-06-21 03:46:25.893767
# Unit test for constructor of class CacheModule
def test_CacheModule():
    a = CacheModule()

# Generated at 2022-06-21 03:46:32.621678
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-21 03:46:39.129429
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filename = 'tmp.json'
    cache = CacheModule()
    # Constructor without arguments
    assert cache.cache_dir == '/tmp'
    assert cache.cache_name == 'ansible-fact-cache'
    assert cache.cache_maxage == 86400
    assert cache.plugin_prefix == 'ansible_facts'
    # Constructor with arguments
    cache = CacheModule(filename, 'minutes', 666, 'prefix')
    assert cache.cache_dir == filename
    assert cache.cache_name == 'minutes'
    assert cache.cache_maxage == 666
    assert cache.plugin_prefix == 'prefix'

# Generated at 2022-06-21 03:46:40.151443
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj.file_extension == 'json'

# Generated at 2022-06-21 03:46:48.569297
# Unit test for constructor of class CacheModule
def test_CacheModule():
    global plugin
    #test for default cache_timeout value
    plugin = CacheModule(connection='/path',contrib_dir=None)
    assert plugin._cache_timeout == 86400
    #test for proper initialization
    plugin = CacheModule(connection='/path',contrib_dir=None,cache_timeout=30)
    assert plugin._cache_timeout == 30
    assert plugin._cache_prefix == ''
    assert plugin._connection == '/path'
    assert plugin.get_prefix() == ''
    assert plugin.get_timeout() == 30


# Generated at 2022-06-21 03:46:53.583032
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(
        _prefix='cache_test_1',  # noqa
        _timeout=15,  # noqa
        _uri='/tmp/json_file_cache/ansible_test_json_cache'  # noqa
    )
    return cache

# Generated at 2022-06-21 03:46:55.121342
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(CacheModule() is not None)

# Generated at 2022-06-21 03:46:57.680376
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule()
    assert isinstance(instance, CacheModule)


# Generated at 2022-06-21 03:46:58.655639
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache

# Generated at 2022-06-21 03:47:04.436257
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(
        task_vars={
            'ansible_user_dir': '~/.ansible',
            'ansible_cache_plugin': 'jsonfile',
            'ansible_cache_plugin_connection': 'jsonfile',
            'ansible_cache_plugin_timeout': '8',
        }
    )
    assert cache._timeout == int(8)
    assert cache._plugin_name == 'jsonfile'
    assert cache._connection == 'jsonfile'

# Generated at 2022-06-21 03:47:05.167381
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-21 03:47:16.810447
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    path = tempfile.mkdtemp()
    plugin = CacheModule({'_uri':path})
    assert plugin._PluginBase__plugin_name == 'jsonfile'
    assert plugin._PluginBase__connection == path
    assert plugin.timeout == 86400
    assert plugin.has_expired("somedata", 3660) is False
    assert plugin.has_expired("somedata", 3600) is True

# Generated at 2022-06-21 03:47:18.042056
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({}).cache_plugin_name == 'jsonfile'

# Generated at 2022-06-21 03:47:18.582418
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-21 03:47:21.465872
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({})
    assert cache._timeout == 86400
    assert cache._loaded is False
    assert cache._connection is None
    assert cache._prefix is None

# Generated at 2022-06-21 03:47:22.384977
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with empty dictionary
    CacheModule({})

# Generated at 2022-06-21 03:47:23.226174
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c

# Generated at 2022-06-21 03:47:25.295060
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    print(cache_module.__dict__)


# Generated at 2022-06-21 03:47:30.707010
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(dict(path="path", prefix="prefix", timeout="timeout"))
    assert cache_module._connection == "path"
    assert cache_module._prefix == "prefix"
    assert cache_module._timeout == "timeout"
    assert cache_module.PLUGIN_CACHE_KEYS == ["_prefix", "_timeout", "_connection"]

# Generated at 2022-06-21 03:47:34.200086
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module
    assert cache_module._cache_dir is None
    assert cache_module._cache_prefix == 'ansible-facts'
    assert cache_module._cache_max_age == 86400

# Generated at 2022-06-21 03:47:36.628275
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj._connection['_uri'] == '~/.ansible/tmp'
    assert obj._timeout == 86400


# Generated at 2022-06-21 03:47:57.955492
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    import shutil
    cache_dir = tempfile.mkdtemp()

    try:
        # Check init
        cache_path = cache_dir + "/ansible-test-cache"
        cache_prefix = "ansible-test-cache"
        cache_timeout = 100
        cache_plugin = CacheModule(cache_path, cache_prefix, cache_timeout)

        assert cache_plugin._timeout == 100, \
            "Cache timeout should be 100 but is " + str(cache_plugin._timeout)
    finally:
        shutil.rmtree(cache_dir)

# Generated at 2022-06-21 03:47:59.701742
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    This is a constructor test to check if the object is constructed properly
    '''
    obj = CacheModule()
    assert obj


# Generated at 2022-06-21 03:48:01.310172
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert isinstance(plugin, CacheModule)

# Generated at 2022-06-21 03:48:02.201700
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert isinstance(cache_module, CacheModule)

# Generated at 2022-06-21 03:48:13.591161
# Unit test for constructor of class CacheModule
def test_CacheModule():
    fake_host = 'database.example.com'
    fake_directive = 'set_fact'
    fake_value = 'foo: bar'
    test_plugin = CacheModule(plugin=None)
    test_plugin._connection = '/home/user/.ansible/tmp'
    test_plugin.get_cache_path()
    test_plugin.get_cache_path(fake_host, fake_directive)
    test_plugin.has_expired(fake_host, fake_directive)
    test_plugin.flush()
    test_plugin.flush(fake_host)
    test_plugin.set(fake_host, fake_directive, fake_value)
    test_plugin.get(fake_host, fake_directive)
    test_plugin.keys()
    test_plugin.keys(fake_host)
   

# Generated at 2022-06-21 03:48:17.994260
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filepath = '/some/path'
    prefix = 'test'
    timeout = 42

    cm = CacheModule({'_uri': filepath, '_prefix': prefix, '_timeout': timeout})
    assert cm.filepath == filepath
    assert cm.prefix == prefix
    assert cm.timeout == timeout
    assert cm.plugin_specific_vars == {}

# Generated at 2022-06-21 03:48:23.550940
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin_name = 'plugin_name'
    config = dict()
    config['plugin'] = plugin_name
    cache = CacheModule(config, plugin_name)
    assert cache != None

# Generated at 2022-06-21 03:48:26.746024
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plug = CacheModule()
    assert cache_plug.validate_filepath("/root/ansible_fact/")
    assert cache_plug.validate_filepath("/root/ansible_facts/")

# Generated at 2022-06-21 03:48:27.871933
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass


# Generated at 2022-06-21 03:48:39.579340
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''Instantiation of cache module.
    Within this one test, the fact_caching_prefix environmental variable
    is set to override the default prefix value of 'ansible_cached_facts_',
    and the fact_caching_timeout environmental variable is set to override
    the default timeout of 86400.
    '''
    from os import environ

    from ansible.plugins.loader import cache_loader

    environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = '/tmp/cache/ansible'
    environ['ANSIBLE_CACHE_PLUGIN_PREFIX'] = 'test_prefix_'
    environ['ANSIBLE_CACHE_PLUGIN_TIMEOUT'] = '600'

    cm = cache_loader.get('jsonfile')
    assert type(cm) == CacheModule


# Generated at 2022-06-21 03:49:11.001683
# Unit test for constructor of class CacheModule
def test_CacheModule():
    t = CacheModule()
    assert t.type == 'jsonfile'
    assert isinstance(t.ext, str)
    assert t.ext == 'json'


# Generated at 2022-06-21 03:49:13.987123
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule(None)
    assert cm._connection == None
    assert cm._prefix == None
    assert cm._timeout == 86400


# Generated at 2022-06-21 03:49:20.950288
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule({})
    assert plugin.key_name is None
    assert plugin.value_name is None
    assert plugin.timeout == 86400
    assert plugin.tree == {}

    plugin = CacheModule({'_prefix': 'test_', '_timeout': 10, '_uri': '/tmp'})
    assert plugin.key_name == 'test_'
    assert plugin.value_name is None
    assert plugin.timeout == 10
    assert plugin.tree == {}

# Generated at 2022-06-21 03:49:23.763425
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.plugin_name == 'jsonfile'

# Generated at 2022-06-21 03:49:26.809988
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule(None, {})
    assert c._connection is None
    assert c._timeout == 86400
    assert c._prefix is None

# Generated at 2022-06-21 03:49:27.502175
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-21 03:49:29.017048
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-21 03:49:30.998095
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule({})
    assert module is not None
    assert module.timeout == 86400

# Generated at 2022-06-21 03:49:33.127113
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': '/tmp'})
    assert cache


# Generated at 2022-06-21 03:49:38.215505
# Unit test for constructor of class CacheModule
def test_CacheModule():
    theCacheModule = CacheModule()
    assert theCacheModule._connection == "/tmp/ansible_fact_cache"

    theCacheModule = CacheModule(connection="/tmp/ansible_fact_cache_test", prefix="test_prefix")
    assert theCacheModule._connection == "/tmp/ansible_fact_cache_test"
    assert theCacheModule._prefix == "test_prefix"

# Generated at 2022-06-21 03:50:43.507878
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None
    assert c.get('setup', 'test.test') is None

# Generated at 2022-06-21 03:50:44.364860
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__doc__

# Generated at 2022-06-21 03:50:45.317617
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module

# Generated at 2022-06-21 03:50:49.003866
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        c = CacheModule()
        x = c._load('data')
        y = c._dump('data', 'data')
    except:
        print('test_CacheModule: FAILURE')
    else:
        print('test_CacheModule: SUCCESS')


# Generated at 2022-06-21 03:50:51.298113
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'cache_plugin_timeout': '43200',
                        'cache_plugin_connection': '~/ansible_cache',
                        'cache_plugin_prefix': 'ansible_cache'})

# Generated at 2022-06-21 03:50:52.381970
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(persistdir='/tmp'))

# Generated at 2022-06-21 03:50:53.646350
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)
    assert cache._timeout == 86400

# Generated at 2022-06-21 03:50:56.839958
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module_obj = CacheModule()
    assert module_obj, 'failed to create CacheModule object'

# Generated at 2022-06-21 03:50:58.637709
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # cache = CacheModule(None, None, None, '["test1", "test2"]')
    # json.loads(cache)
    pass

# Generated at 2022-06-21 03:51:02.159551
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = '/var/tmp'
    prefix = 'ansible-facts'
    timeout = 86400
    cm = CacheModule(cache_dir, prefix, timeout)
    assert cm._cache_dir == cache_dir
    assert cm._cache_prefix == prefix
    assert cm._cache_timeout == timeout

# Generated at 2022-06-21 03:53:24.406013
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule('/test/path')
    assert plugin._prefix == 'ansible-facts'
    assert plugin._cachefile == '/test/path/ansible-facts.cache'

# Generated at 2022-06-21 03:53:29.578998
# Unit test for constructor of class CacheModule
def test_CacheModule():
    #create an instance
    t = CacheModule()
    #test if it is an instance of CacheModule
    assert isinstance(t, CacheModule)
    #test if the instance has an attribute _timeout
    assert hasattr(t, '_timeout')
    #test if the instance has an attribute _prefix
    assert hasattr(t, '_prefix')
    #test if the instance has an attribute _uri
    assert hasattr(t, '_uri')

# Generated at 2022-06-21 03:53:32.749655
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = '/home/user/dir'
    prefix = 'pref'
    timeout = 86400

    module = CacheModule({
        '_uri': path,
        '_prefix': prefix,
        '_timeout': timeout
    })

    assert module.connection == path
    assert module.prefix == prefix
    assert module.timeout == timeout

# Generated at 2022-06-21 03:53:35.842919
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c_module = CacheModule()
    assert c_module._timeout == 86400
    assert c_module._prefix is None
    assert c_module._uri is None

# Generated at 2022-06-21 03:53:39.536858
# Unit test for constructor of class CacheModule
def test_CacheModule():
    def fake_get_vault_secret(secret):
        return None
    cache = CacheModule(get_vault_secret=fake_get_vault_secret)
    assert cache.__class__.__name__ == "CacheModule"
    assert cache._timeout == 86400

# Generated at 2022-06-21 03:53:42.507050
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__doc__ == """
    A caching module backed by json files.
    """
    jsonfile = CacheModule()
    assert jsonfile.__class__.__name__ == "CacheModule"


# Generated at 2022-06-21 03:53:43.381796
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache

# Generated at 2022-06-21 03:53:46.086021
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.valid is True, "valid should be true"

# Generated at 2022-06-21 03:53:48.283501
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test for class 'CacheModule'
    cacheModule = CacheModule()
    assert cacheModule

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-21 03:53:49.433729
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Stub for testing __init__
    """
    pass