

# Generated at 2022-06-25 08:25:44.795385
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_z = CacheModule()
    assert isinstance(cache_module_z, CacheModule)

# Generated at 2022-06-25 08:25:45.619782
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_case_0()

# Generated at 2022-06-25 08:25:46.722127
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()


# Generated at 2022-06-25 08:25:49.293607
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Initialize the class
    cache_module = CacheModule()

    # Check attributes
    assert cache_module._connection == '~/.ansible/tmp/ansible-local'
    assert cache_module._prefix == 'ansible-local'
    assert isinstance(cache_module._timeout, int)

# Generated at 2022-06-25 08:25:52.484296
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()



# Generated at 2022-06-25 08:25:54.511400
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache_module = CacheModule()

    assert cache_module.cache_prefix == None
    assert cache_module.cache_plugin_timeout == 86400



# Generated at 2022-06-25 08:25:55.428261
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()


# Generated at 2022-06-25 08:25:56.130371
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule

# Generated at 2022-06-25 08:25:56.896179
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-25 08:25:58.374711
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == None


# Generated at 2022-06-25 08:26:00.943304
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-25 08:26:01.526804
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-25 08:26:03.976940
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Unit test function for function _load of class CacheModule

# Generated at 2022-06-25 08:26:05.015243
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachedir = "/tmp/ansible_test"
    CacheModule(cachedir)

# Generated at 2022-06-25 08:26:10.224988
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': '/tmp'})
    assert cache.get_basedir() == '/tmp'

# Generated at 2022-06-25 08:26:14.697621
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)
    x = CacheModule()
    assert x is not None

# Generated at 2022-06-25 08:26:15.715368
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule('/tmp/test')
    assert os.path.exists('/tmp/test')

# Generated at 2022-06-25 08:26:16.390455
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-25 08:26:18.832583
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Tests for class AnsibleCoreCI
    cache = CacheModule()
    assert cache._prefix == 'ansible-factcache'
    assert cache._timeout == 86400
    assert cache._uri == '/var/tmp/ansible/local'
    assert cache.supported_changes == ('set', 'delete')

# Generated at 2022-06-25 08:26:20.360232
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        c = CacheModule(tmpdirname)
        assert c.cache._timeout == 86400

# Generated at 2022-06-25 08:26:28.081944
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule(
            {'_uri': 'test_uri',
             '_prefix': 'test_prefix',
             '_timeout': 'test_timeout'})

    assert obj._uri == 'test_uri'
    assert obj._prefix == 'test_prefix'
    assert obj._timeout == 'test_timeout'

# Generated at 2022-06-25 08:26:32.891924
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Expected values
    _uri = "URI"
    _timeout = 86400
    _cache = {
        "_uri": _uri,
        "_timeout": _timeout
    }

    # Actual
    cache = CacheModule(_uri)

    # Assert
    assert cache._uri == _uri
    assert cache._timeout == _timeout

# Generated at 2022-06-25 08:26:35.289346
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    cache._setup_cache_dir()
    cache.set("test", "value", "test")
    assert cache.get("test") == "value"

# Generated at 2022-06-25 08:26:35.843482
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin is not None

# Generated at 2022-06-25 08:26:43.390641
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    cache_module._connection = 'path'
    cache_module._options = None
    cache_module._load = lambda x: json.load(x, cls=AnsibleJSONDecoder)
    cache_module._dump = lambda x, y: json.dump(x, y, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)

    # Test _load
    # Create proper json file and test if data is returned

# Generated at 2022-06-25 08:26:45.152744
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj._connection is None
    assert obj._options is None

# Generated at 2022-06-25 08:26:56.713927
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ############################################################################################
    # Select 'jsonfile' cache plugin
    from ansible.plugins.cache.jsonfile import CacheModule
    ############################################################################################

    # Instance for class CacheModule
    cm = CacheModule(playbook=None, variables={})

    # Action - get
    # Get data from cache
    ds = cm.get('10.0.0.1', 'key')

    # Action - set
    # Set data to cache
    cm.set('10.0.0.1', 'key', 'value')

    # Action - keys
    # Get all keys list in host cache
    lks = cm.keys('10.0.0.1')

    # Action - has_key
    # Check if host cache has key

# Generated at 2022-06-25 08:27:03.555749
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = 'jsonfile'
    timeout = 3600
    plugin_options = {
        'connection': '/var/cache/ansible/facts',
        'timeout': timeout,
        'prefix': 'ansible_fact_'
    }
    obj = CacheModule(cache_plugin, plugin_options)

    assert obj.get_option('connection') == '/var/cache/ansible/facts'
    assert obj.get_option('timeout') == timeout
    assert obj.get_option('prefix') == 'ansible_fact_'

# Generated at 2022-06-25 08:27:07.252629
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule

    cm = CacheModule()
    assert(cm is not None)
    assert(cm._valid_cache == True)
    assert(cm.cache_type == 'jsonfile')

# Generated at 2022-06-25 08:27:10.197471
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ca = CacheModule({'_uri': './test_cache'})

    assert ca._uri == './test_cache'
    assert ca._timeout == 86400
    assert ca._prefix == 'ansible-fact'

# Generated at 2022-06-25 08:27:16.693595
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule(dict())

# Generated at 2022-06-25 08:27:18.651877
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_cache_timeout() == 0.0
    assert cache_module.get_cache_prefix() == 'ansible-facts'

# Generated at 2022-06-25 08:27:20.191777
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.file_extension == '.json'

# Generated at 2022-06-25 08:27:21.826388
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''Test the constructor of class CacheModule'''
    assert CacheModule()

# Generated at 2022-06-25 08:27:27.533843
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Initializing an instance of CacheModule
    cache = CacheModule(None)

    # Unit test for _load()
    cache._load(r'C:\Users\t_xiafa\PycharmProjects\ansible\lib\ansible\plugins\cache\jsonfile.py')

    # Unit test for _dump()
    cache._dump('test_value', r'C:\Users\t_xiafa\PycharmProjects\ansible\lib\ansible\plugins\cache\jsonfile.py')

# Generated at 2022-06-25 08:27:32.007953
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._connection == None
    assert cache_plugin._prefix == None
    assert cache_plugin._timeout == 86400
    assert cache_plugin._cache_files == []

# Generated at 2022-06-25 08:27:33.289340
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.CACHE_PLUGIN_PREFIX == 'ansible_facts'



# Generated at 2022-06-25 08:27:34.928420
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert type(module) == CacheModule

# Generated at 2022-06-25 08:27:38.732672
# Unit test for constructor of class CacheModule
def test_CacheModule():
    #Stub values for test
    connection = {
        '_uri': 'home/somelocation/',
        '_prefix': 'hiddenfile',
        '_timeout': '86400'
    }
    assert CacheModule(connection).plugin_name == "jsonfile"

# Generated at 2022-06-25 08:27:47.918174
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test without uri and without prefix
    cache = dict(CacheModule(dict(), 'foo'))
    assert cache['path'] == '/tmp'
    assert cache['plugin_name'] == 'jsonfile'
    assert cache['_timeout'] == 86400
    assert cache['_prefix'] == 'ansible-facts'

    # test with uri and with prefix
    cache = dict(CacheModule(dict(uri='/tmp/foo'), 'foo'))
    assert cache['path'] == '/tmp/foo'
    assert cache['plugin_name'] == 'jsonfile'
    assert cache['_timeout'] == 86400
    assert cache['_prefix'] == 'ansible-facts'

    # test with uri and without prefix
    cache = dict(CacheModule(dict(uri='/tmp/foo'), 'foo'))

# Generated at 2022-06-25 08:28:02.661111
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.plugin_name == 'jsonfile'

# Generated at 2022-06-25 08:28:05.470378
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(None)

# Generated at 2022-06-25 08:28:07.767554
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = 'data/cache/json'   # path of the cache
    prefix = 'prefix'                # user defined prefix
    timeout = 10                     # expiration time

    cache = CacheModule(connection=connection, prefix=prefix, timeout=timeout)

    assert cache._connection == connection
    assert cache._prefix == prefix
    assert cache._timeout == timeout

# Generated at 2022-06-25 08:28:09.123170
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.file_extension == ".json"
    assert cache._timeout == 86400

# Generated at 2022-06-25 08:28:16.363456
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_cache_plugin_connection = "unittest_cache_plugin_connection"
    test_cache_plugin_prefix = "unittest_cache_plugin_prefix"
    test_cache_plugin_timeout = 12345
    test_cache_plugin_max_age = 10
    test_cache_plugin_data = {"test_key": "test_value"}
    test_cache_plugin_file_name = test_cache_plugin_prefix + "localhost.json"
    test_cache_plugin_file_path = test_cache_plugin_connection + "/" + test_cache_plugin_file_name

    # Test CacheModule constructor
    test_cache_module = CacheModule(test_cache_plugin_connection, test_cache_plugin_prefix,
                                    test_cache_plugin_timeout, test_cache_plugin_max_age)



# Generated at 2022-06-25 08:28:19.944077
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Constructor
    cm = CacheModule()
    # Test case: ret = cm.get(None, 'test')
    # Exception

# Generated at 2022-06-25 08:28:23.784655
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with non-existing directory
    with pytest.raises(Exception) as e_info:
        assert CacheModule({'_uri': '/no/such/dir'})

    # Test with existing directory
    assert CacheModule({'_uri': '/tmp/'})

# Generated at 2022-06-25 08:28:24.309363
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-25 08:28:27.054691
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filename = '/tmp/ansible/cache/ansible-facts/localhost/ansible_facts.cache'
    connection = 'local'
    value = {}
    cache = CacheModule(connection,filename,value)
    assert cache is not None

# Generated at 2022-06-25 08:28:29.630479
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._uri is None
    assert CacheModule._prefix is None

    cache_module = CacheModule()
    assert cache_module is not None

    assert cache_module._uri == '/tmp/ansible-fact-cache'
    assert cache_module._prefix == 'ansible_facts'
    assert cache_module._timeout == 86400

# Generated at 2022-06-25 08:29:00.269001
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        conn = CacheModule(
            {
                '_uri': 'ansible_cache_path',
                '_timeout': 'ansible_fact_caching_timeout',
                '_prefix': 'ansible_cache_prefix'
            }
        )
        assert hasattr(conn, '_load')
    except Exception as ex:
        print(ex)
        assert False

# Generated at 2022-06-25 08:29:00.784645
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-25 08:29:05.598627
# Unit test for constructor of class CacheModule
def test_CacheModule():
    value = {1:2, 3:4}
    filepath = '/tmp/test_cache.json'
    
    # Create a JSON cache file
    cache = CacheModule()
    cache._dump(value, filepath)

    # Read the file using _load method
    dict_from_cache = cache._load(filepath)

    # Check for the equality
    assert value == dict_from_cache

# Generated at 2022-06-25 08:29:14.739400
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # set the class_vars to use for the test
    CacheModule.filelock_path = '/tmp/ansible_cache_lock'
    CacheModule.cache = '/tmp/ansible_cache'

    # Call the constructor for class CacheModule
    cache_plugin = CacheModule()

    # Test that _load, _dump, and get are available
    assert hasattr(cache_plugin, '_load')
    assert hasattr(cache_plugin, '_dump')
    assert hasattr(cache_plugin, 'get')
    assert hasattr(cache_plugin, 'set')
    assert hasattr(cache_plugin, 'keys')
    assert hasattr(cache_plugin, 'has_key')
    assert hasattr(cache_plugin, 'delete')
    assert hasattr(cache_plugin, 'contains')

# Generated at 2022-06-25 08:29:17.092044
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(None)

    # Base file cache module should get initialized
    assert cache_module.timeout == 86400
    assert cache_module.plugin_name == 'jsonfile'

# Generated at 2022-06-25 08:29:18.154628
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-25 08:29:18.823544
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert type(CacheModule) == type

# Generated at 2022-06-25 08:29:22.146750
# Unit test for constructor of class CacheModule
def test_CacheModule():
    facts = {
        'foo': 'ok'
    }

    cache = CacheModule(path='/tmp', timeout=10)
    cache._dump(facts, '/tmp/dummy')

    assert cache._load('/tmp/dummy') == facts

# Generated at 2022-06-25 08:29:24.063131
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._connection == 'ansible-facts'
    assert cache_plugin._prefix == 'ansible_facts'
    assert cache_plugin._timeout == 86400

# Generated at 2022-06-25 08:29:25.188901
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': 'tmp.json'})
    assert cache.cachefile == 'tmp.json'

# Generated at 2022-06-25 08:30:32.035750
# Unit test for constructor of class CacheModule
def test_CacheModule():
    json_str = '{"a": "b"}'
    json_dict = json.loads(json_str, cls=AnsibleJSONDecoder)
    cache_obj = CacheModule()
    cache_obj._dump(json_dict, 'test.json')
    assert cache_obj._load('test.json') == json_dict

# Generated at 2022-06-25 08:30:32.544711
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule

# Generated at 2022-06-25 08:30:33.286006
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

# Generated at 2022-06-25 08:30:37.676007
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.get_timeout() == 86400
    assert c.get_connection() == os.path.join(urllib.parse.urlsplit(c.get_prefix()).path, urllib.parse.urlsplit(c.get_prefix()).hostname + ".json")
    assert isinstance(c.get_connection(), str)
    assert c.get_prefix() == "success"

# Generated at 2022-06-25 08:30:38.492059
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'timeout': 1})

# Generated at 2022-06-25 08:30:48.159813
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test is using localhost as hostname, fact_caching_connection is "local/", which is passed to CacheModule as path
    # Create object of clss CacheModule
    cache_module = CacheModule()
    # Test if object is of class CacheModule
    assert isinstance(cache_module,CacheModule)
    # Test if object is of class BaseFileCacheModule
    assert isinstance(cache_module,BaseFileCacheModule)

    # check if tmp dir is created
    assert "local/" in cache_module.path_prefix == True

    # Test attributes of class CacheModule
    assert getattr(cache_module,"path_prefix") == "local/"
    assert getattr(cache_module,"show_content") == True
    assert getattr(cache_module,"expire_time") == 86400

# Generated at 2022-06-25 08:30:49.770710
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Test to see if it has propertied after constructor
    """
    cache = CacheModule()
    assert cache._timeout == 86400

# Generated at 2022-06-25 08:30:52.121222
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.get_cache_prefix() == "ansible_facts"

# Generated at 2022-06-25 08:30:53.893704
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert (cache.name == 'jsonfile')

# Generated at 2022-06-25 08:30:54.647947
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule(None)
    assert cache_plugin is not None

# Generated at 2022-06-25 08:33:03.820881
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c

# Generated at 2022-06-25 08:33:07.549674
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert hasattr(module, 'get')
    assert hasattr(module, 'set')
    assert hasattr(module, 'del_key')
    assert hasattr(module, 'keys')
    assert hasattr(module, 'close')
    assert hasattr(module, 'peek_lock')
    assert hasattr(module, 'release_lock')

# Generated at 2022-06-25 08:33:13.541360
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_path = '/tmp/ansible-test-cache'
    prefix = 'prefix'
    timeout = 1200

    # Create cache object
    jsonfile_cache = CacheModule(
        cache_plugin_timeout=timeout,
        cache_plugin_path=cache_path,
        cache_plugin_prefix=prefix,
        cache_plugin_wrk_dir=cache_path
    )

    # Populate cache
    jsonfile_cache._makedirs('/tmp/ansible-test-cache')

    # Get a cache hit
    data = {'cache': 'hit'}
    result = jsonfile_cache.set('cache-hit', data)
    assert data == result['changed']['_ansible_cache_plugin_origdata']
    assert result['changed']['_ansible_cache_plugin_data'] == jsonfile

# Generated at 2022-06-25 08:33:18.386484
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({})
    assert cache.file_extension == ".json"
    assert cache.BASE_CACHE_PLUGIN_PATH == "~/.ansible/cache/ansible-facts"
    assert cache.DEFAULT_TIMEOUT == 86400
    assert cache.plugin_name == "jsonfile"

# Generated at 2022-06-25 08:33:19.234699
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert isinstance(obj, CacheModule)

# Generated at 2022-06-25 08:33:19.648236
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-25 08:33:20.903668
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj._connection is None
    assert obj._timeout == 86400
    assert obj._prefix is None


# Generated at 2022-06-25 08:33:25.372921
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Create an instance of the module
    cache_module = CacheModule()

    assert cache_module

# Generated at 2022-06-25 08:33:27.104847
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert isinstance(cache_module, CacheModule)

# Generated at 2022-06-25 08:33:29.355872
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = '/tmp'
    prefix = 'ansible-cache'
    timeout = 60
    cache = CacheModule(cache_dir, prefix, timeout)
    assert cache._uri == cache_dir
    assert cache._prefix == prefix
    assert cache._timeout == timeout