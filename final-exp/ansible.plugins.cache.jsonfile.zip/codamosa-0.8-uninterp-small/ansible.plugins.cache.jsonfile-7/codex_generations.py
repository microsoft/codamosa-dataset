

# Generated at 2022-06-25 08:25:45.065063
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module


# Generated at 2022-06-25 08:25:46.722193
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._load
    assert CacheModule._dump

    assert cache_module_0._load
    assert cache_module_0._dump


# Generated at 2022-06-25 08:25:47.992125
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:25:54.341810
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create a CacheModule object
    cache_module_obj = CacheModule()

    # Try to load a non-existing file
    result = cache_module_obj.load('/test_file')

    assert result is None



# Generated at 2022-06-25 08:25:55.986113
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()
    assert cache_module_0 is not None
    assert cache_module_0.get_timeout() == 86400


# Generated at 2022-06-25 08:26:01.969193
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()
    cache_module_0._uri = "/Users/zhaozhen/mine/ansible_plugable_cache_plugin/example/file.jsonfile"
    assert cache_module_0._prefix is None
    cache_module_0._timeout = 86400
    host_0 = "TEST_HOST"
    assert host_0.find(".") == -1
    assert host_0.find("/") == -1
    assert host_0.find("\\") == -1
    assert host_0.find("@") == -1
    filepath = "/Users/zhaozhen/mine/ansible_plugable_cache_plugin/example/file.jsonfile/TEST_HOST"
    assert filepath.find("/") != -1

# Generated at 2022-06-25 08:26:03.883264
# Unit test for constructor of class CacheModule
def test_CacheModule():
  # Calling the constructor of class CacheModule
  cache_module_0 = CacheModule()


# Generated at 2022-06-25 08:26:05.420168
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None
    assert cache_module._prefix == 'ansible_'


# Generated at 2022-06-25 08:26:06.156471
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()

# Generated at 2022-06-25 08:26:12.094375
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Initialize CacheModule object
    cache_module = CacheModule()

    # Check attributes of class CacheModule for default values
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() is None

    # Check attributes of class BaseFileCacheModule for default values
    assert cache_module.get_prefix() is None
    assert cache_module.get_directory() is None

    # Check attributes of class CacheModule for non-default values
    assert cache_module.set_timeout(1234)
    assert cache_module.set_connection('/tmp')
    assert cache_module.get_timeout() == 1234
    assert cache_module.get_connection() == '/tmp'

    # Check attributes of class BaseFileCacheModule for non-default values
    assert cache_module.set_prefix('foo')

# Generated at 2022-06-25 08:26:14.646703
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule("/tmp/path", "", "")
    assert module is not None

# Generated at 2022-06-25 08:26:16.663496
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mod = CacheModule()
    assert mod._prefix == 'ansible-fetch_facts'
    assert mod._timeout == 86400

# Generated at 2022-06-25 08:26:21.660795
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # We must have the class attribute 'filecache_connector' defined.
    assert hasattr(CacheModule, 'filecache_connector')
    assert isinstance(CacheModule.filecache_connector, str)

    # The string value of 'filecache_connector' should be equal to 'jsonfile'.
    assert CacheModule.filecache_connector == 'jsonfile'

# Generated at 2022-06-25 08:26:23.511702
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-25 08:26:28.219797
# Unit test for constructor of class CacheModule
def test_CacheModule():
    enc = AnsibleJSONEncoder()
    dec = AnsibleJSONDecoder()
    # test loading and dumping
    filepath = 'tmp_test_file'
    value = {'a': 1, 'b': 'b'}
    CacheModule()._dump(value, filepath)
    assert(CacheModule()._load(filepath) == value)

# Generated at 2022-06-25 08:26:32.410394
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = 'path'
    timeout = 'timeout'
    prefix = 'prefix'

    module = CacheModule(path, timeout, prefix)
    assert module.plugin_name == 'jsonfile'
    assert module.plugin_path == path
    assert module.timeout == timeout
    assert module.plugin_prefix == prefix

# Generated at 2022-06-25 08:26:33.500144
# Unit test for constructor of class CacheModule
def test_CacheModule():
    the_CacheModule = CacheModule()

# Generated at 2022-06-25 08:26:34.823771
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c
    assert c._load
    assert c._dump

# Generated at 2022-06-25 08:26:37.157572
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, BaseFileCacheModule) == True
    assert cache.get_timeout() == 86400


# Generated at 2022-06-25 08:26:40.144467
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
        This function creates a CacheModule object with all the required parameters and returns
        the created object.
    """
    cache = {}
    CacheModule(cache, 'fact_caching_connection=/test', 'fact_caching_timeout=0', 'fact_caching_prefix=/test')

# Generated at 2022-06-25 08:26:44.714231
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert(cm is not None)



# Generated at 2022-06-25 08:26:46.075125
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.get_value("hostname") == None

# Generated at 2022-06-25 08:26:50.294682
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert hasattr(obj, '_get_cache_prefix')
    assert hasattr(obj, '_load')
    assert hasattr(obj, '_dump')

    # Test _load() method with a bad filepath
    try:
        obj._load('/test_data/test_file_does_not_exist.json')
    except Exception as e:
        assert isinstance(e, IOError)

# Generated at 2022-06-25 08:26:55.811906
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Call the constructor of the class
    cm = CacheModule()
    assert type(cm) == CacheModule

# Generated at 2022-06-25 08:26:56.685713
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-25 08:27:00.011348
# Unit test for constructor of class CacheModule
def test_CacheModule():

    _uri = 'path/to/ansible/caching'
    _prefix = 'prefix'
    _timeout = 3600

    cache = CacheModule(_uri, _prefix, _timeout)
    assert cache._uri == _uri
    assert cache._prefix == _prefix
    assert cache._timeout == _timeout

# Generated at 2022-06-25 08:27:01.730938
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-25 08:27:03.294211
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert x.FILENAME_EXTENSION == '.cache'

# Generated at 2022-06-25 08:27:04.763965
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-25 08:27:06.904647
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # _load exists
    CacheModule(None)
    # _dump exists
    CacheModule(None)

# Generated at 2022-06-25 08:27:15.425468
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = {'hello': 'world'}
    # cache = CacheModule('/tmp/cache_mock_test.json',data)
    print("Testing Class Successful")

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-25 08:27:18.138304
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

    assert c.filecache_path == "~/.ansible/tmp/ansible-fact-cache"
    assert c.filecache_prefix == "ansible_fact_cache"
    assert c.filecache_timeout == 86400

# Generated at 2022-06-25 08:27:19.586852
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule()
    assert isinstance(instance, CacheModule) is True

# Generated at 2022-06-25 08:27:23.060979
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.plugin_name == 'jsonfile'
    assert c._timeout is None
    assert c._connection_info == {}
    assert c._prefix == 'ansible-facts'

# Generated at 2022-06-25 08:27:29.787980
# Unit test for constructor of class CacheModule
def test_CacheModule():
    my_module = CacheModule()

    # Test for raising an exception for missing path for _uri
    try:
        my_module.set_options({'_uri': None})
    except Exception:
        pass

    # Test with a valid path
    path = "/tmp/uri"
    my_module.set_options({'_uri': path})

    # Test for exception for wrong prefix
    try:
        my_module.set_options({'_prefix': 123456})
    except Exception:
        pass

    # Test with a valid prefix
    prefix = "prefix"
    my_module.set_options({'_prefix': prefix})

    # Test with a valid timeout
    timeout = 12345
    my_module.set_options({'_timeout': timeout})

# Generated at 2022-06-25 08:27:34.357918
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("TEST: test_CacheModule")
    x = CacheModule()

# Generated at 2022-06-25 08:27:35.708815
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._get_cache_prefix() == "ansible_facts", "CacheModule initialization failed"

# Generated at 2022-06-25 08:27:38.438889
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.get_timeout() == 86400
    assert cm.get_prefix() == ''



# Generated at 2022-06-25 08:27:44.631116
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_timeout': 1}, 'host1')
    assert cache._timeout == 1
    assert cache._prefix == 'host1'
    assert cache._module_name is None
    assert cache._connection is None
    assert cache._encoding is None
    assert cache._plugin_name == 'jsonfile'
    assert cache._plugin_type == 'cache'
    assert cache._cache == {}
    assert cache._cache_dir is None
    assert cache._cache_filename is None
    assert cache._cache_path is None

# Generated at 2022-06-25 08:27:46.173686
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._load == CacheModule._load
    assert plugin._dump == CacheModule._dump

# Generated at 2022-06-25 08:28:01.619701
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    jsonfile.CacheModule()
    '''
    cache_module = CacheModule(None)

# Generated at 2022-06-25 08:28:02.585626
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_cache_path() == ""

# Generated at 2022-06-25 08:28:07.463385
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    # Constructor should set attributes
    assert cache._options is None, 'Constructor should set _options'
    assert cache._connection is None, 'Constructor should set _connection'
    assert cache._task_vars is None, 'Constructor should set _task_vars'

# pylama:ignore=W0212

# Generated at 2022-06-25 08:28:11.259670
# Unit test for constructor of class CacheModule
def test_CacheModule():
    config = dict()
    config['_uri'] = "/tmp/ansible/dir"
    config['_prefix'] = "ansible"
    config['_timeout'] = "10"
    cache = CacheModule(config)
    assert cache._uri == "/tmp/ansible/dir"
    assert cache._prefix == "ansible"
    assert cache._timeout == 10

# Generated at 2022-06-25 08:28:17.912075
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # CWD below is the directory where this source file is located
    mycache = CacheModule({'_uri': "./mycachetest", '_connection': "./mycachetest"})

    # Test 'save' method in class CacheModule
    mycache.save("mykey", {"myvalue1": 1, "myvalue2": 2})
    # Test 'get' built-in method in class CacheModule
    assert mycache.get("mykey") == {"myvalue1": 1, "myvalue2": 2}

    # Test 'exists' built-in method in class CacheModule
    assert mycache.exists("mykey") is True

    # Test 'delete' built-in method in class CacheModule
    mycache.delete("mykey")
    assert mycache.exists("mykey") is False

# Generated at 2022-06-25 08:28:26.946391
# Unit test for constructor of class CacheModule
def test_CacheModule():
    moduleinfo = dict()
    moduleinfo['_timeout'] = 10
    moduleinfo['_uri'] = 'directory'
    moduleinfo['_prefix'] = 'host'

    cache = CacheModule()
    # Call _load_cache method
    assert cache._load_cache() is None
    # Call _flush_cache method
    assert cache._flush_cache() is None
    # Call _save_cache method
    assert cache._save_cache(moduleinfo, 'hostname1') is None
    # Call _load_cache method
    assert cache._load_cache('hostname1') == moduleinfo
    # Call _remove_cache method
    assert cache._remove_cache('hostname1') is None

# Generated at 2022-06-25 08:28:28.485588
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # create instance
    cm = CacheModule()
    
    # check type
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-25 08:28:33.903384
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__name__ is 'CacheModule'
    assert CacheModule.__doc__ is '\n    A caching module backed by json files.\n    '
    x = CacheModule()
    assert x._timeout == 86400
    assert x._prefix == 'ansible-cache'



# Generated at 2022-06-25 08:28:39.109100
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with open("/tmp/test_jsonfile_cache.json", "w") as f:
        json.dump("{}", f, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)
    f.close()

    c = CacheModule("/tmp/test_jsonfile_cache.json", 1)
    c.set("key1", "value1")
    assert c.get("key1") == "value1"
    c.delete("key1")
    assert c.get("key1") is None

# Generated at 2022-06-25 08:28:46.053582
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('/path')
    assert cache._basedir == '/path'
    assert cache._prefix == 'ansible_facts'
    assert cache._timeout == 3600
    assert cache._plugin_name == 'jsonfile'
    assert cache._dump == json.dump
    assert cache._load == json.load

# Generated at 2022-06-25 08:29:10.658270
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Arrange
    file_cache = CacheModule()

    # Act
    file_cache._load()
    # Assert
    assert True

# Generated at 2022-06-25 08:29:18.471702
# Unit test for constructor of class CacheModule
def test_CacheModule():
    
    # Expected instance variables
    _timeout = 86400
    _connection = 'None'
    _prefix = None
    _load_unit_test = None
    _dump_unit_test = None


    # Test the constructor with no arguments
    test_cache = CacheModule()
    assert test_cache._timeout == _timeout
    assert test_cache._connection == _connection
    assert test_cache._prefix == _prefix
    assert test_cache._load == _load_unit_test
    assert test_cache._dump == _dump_unit_test


    # Test the constructor with arguments
    test_cache = CacheModule(timeout=12345, connection='foo', prefix='bar')
    assert test_cache._timeout == 12345
    assert test_cache._connection == 'foo'
    assert test_cache._prefix == 'bar'


# Generated at 2022-06-25 08:29:19.234075
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cs = CacheModule()
    pass

# Generated at 2022-06-25 08:29:21.831251
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugins = BaseFileCacheModule._load_plugins()
    assert('jsonfile' in plugins)
    assert(plugins['jsonfile'] == CacheModule)

# Generated at 2022-06-25 08:29:23.038893
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule({'_uri': '~/.ansible/tmp/facts'})
    assert cache_plugin

# Generated at 2022-06-25 08:29:26.197684
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._find_path('') == '/tmp/'
    assert CacheModule._find_path('/tmp/mydir/') == '/tmp/mydir/'
    assert CacheModule._find_path('~') == '/tmp/'
    assert CacheModule._find_path('~/mydir/') == '/tmp/mydir/'

# Generated at 2022-06-25 08:29:27.506387
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Empty constructor
    CacheModule(None)

# Generated at 2022-06-25 08:29:28.342010
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin is not None

# Generated at 2022-06-25 08:29:32.452507
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    assert isinstance(cache._get_cache_basedir(), str)
    assert not cache._get_cache_basedir().endswith('/')

    cache._get_cache_basedir('/path/to/cache_basedir')
    assert cache._get_cache_basedir().endswith('/')

# Generated at 2022-06-25 08:29:33.440799
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule('/tmp/some_path', 'ansible-')

# Generated at 2022-06-25 08:30:36.754019
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-25 08:30:46.118366
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Arrange
    expected_connection = 'test_dir'
    expected_prefix = 'test_prefix'
    expected_timeout = 86400
    cm = CacheModule(expected_connection, expected_prefix, expected_timeout)

    # Act
    actual_connection = cm._connection
    actual_connection = actual_connection._uri
    actual_prefix = cm._prefix
    actual_timeout = cm._timeout
    actual_load = cm._load
    actual_dump = cm._dump

    # Assert
    assert expected_connection == actual_connection
    assert expected_prefix == actual_prefix
    assert expected_timeout == actual_timeout
    assert type(actual_load) == type(test_CacheModule)
    assert type(actual_dump) == type(test_CacheModule)


# Generated at 2022-06-25 08:30:46.894988
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c

# Generated at 2022-06-25 08:30:47.980271
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin != None

# Generated at 2022-06-25 08:30:54.345038
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import sys
    import os
    import stat
    import shutil
    import tempfile
    from ansible.plugins.cache import BaseFileCacheModule
    from ansible.utils.path import makedirs_safe

    cache_dir = os.path.join(tempfile.gettempdir(), 'test_ansible_cache')
    makedirs_safe(cache_dir, 0o700)

    # place files in the cache
    C = CacheModule()
    C.set_plugin_options(cache_dir=cache_dir, plugin_timeout=60)
    assert C.get('Test') == {}
    assert C.set('Test', 'Value') == True
    assert C.get('Test') == 'Value'
    C.invalidate('Test')
    assert C.get('Test') == {}

    # test the auto invalidate

# Generated at 2022-06-25 08:30:56.244615
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, '_load')
    assert hasattr(CacheModule, '_dump')

# Generated at 2022-06-25 08:30:57.106772
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())



# Generated at 2022-06-25 08:31:01.471308
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': '/home/temp/'}) is not None

# Generated at 2022-06-25 08:31:10.002079
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Clear all keys present
    test_dict = {'a': 'b', 'c': 'd'}
    CacheModule(test_dict)

    test_dict = {'a': 'b', 'c': 'd'}
    CacheModule(test_dict, 'test_prefix')

    test_dict = {'a': 'b', 'c': 'd'}
    CacheModule(test_dict, 'test_prefix', test_timeout=1)

    test_dict = {'a': 'b', 'c': 'd'}
    CacheModule(test_dict, 'test_prefix', test_timeout=1, connection='test_connection')



# Generated at 2022-06-25 08:31:13.656541
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Instanciation of a CacheModule
    cache = CacheModule()
    # Verify if the instance is correctly created
    assert cache._load is not None
    assert cache._dump is not None

# Generated at 2022-06-25 08:33:25.826377
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'some/path'})

# Generated at 2022-06-25 08:33:28.945399
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load.__name__ == '_load'
    assert cache_module._dump.__name__ == '_dump'

# Generated at 2022-06-25 08:33:29.750527
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(path="/tmp"))

# Generated at 2022-06-25 08:33:32.897485
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Creates a CacheModule object and performs some basic tests
    """
    cache = CacheModule()
    assert cache
    assert cache._options == {'_prefix': 'ansible_facts', '_timeout': 86400, '_uri': '~/.ansible/fact_cache'}

# Generated at 2022-06-25 08:33:33.618279
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-25 08:33:37.711335
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = "test"
    prefix = "tst"
    timeout = "t"
    mod = CacheModule(uri, prefix, timeout)
    assert mod.file_extension == '.json'
    assert mod.basedir == 'test'
    assert mod.timeout == 't'
    assert mod._prefix == 'tst'

# Generated at 2022-06-25 08:33:41.000965
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uut = CacheModule(task_vars=None)
    assert uut.supports_expires is True
    assert uut.file_extension == 'json'

    assert uut._load.__name__ == '_load'
    assert uut._dump.__name__ == '_dump'

# Generated at 2022-06-25 08:33:42.670594
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module


# Generated at 2022-06-25 08:33:50.312685
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    #Test 1
    assert module._load == "<bound method CacheModule._load of <ansible.plugins.cache.jsonfile.CacheModule object at 0x10ca5b350>>"
    #Test 2
    assert module._dump == "<bound method CacheModule._dump of <ansible.plugins.cache.jsonfile.CacheModule object at 0x10ca5b350>>"
    #Test 3
    assert module.get_supported_types() == ['fact', 'file']
    #Test 4
    assert module.get_cache_prefix() is None
    #Test 5
    assert module.get_cache_timeout() == 86400
    #Test 6
    assert module.get_cache_uri() is None

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-25 08:33:56.735610
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert isinstance(module, CacheModule), "CacheModule object creation failure"
    assert module._loaded is False, "CacheModule object creation failure"
    print ("CacheModule object info: " + str(module))