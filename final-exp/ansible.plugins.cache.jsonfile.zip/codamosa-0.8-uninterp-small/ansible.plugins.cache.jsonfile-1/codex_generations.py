

# Generated at 2022-06-25 08:25:44.900901
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert cache_module_0


# Generated at 2022-06-25 08:25:45.992196
# Unit test for constructor of class CacheModule
def test_CacheModule():

    assert "CacheModule" == CacheModule.__name__


# Generated at 2022-06-25 08:25:46.755985
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule


# Generated at 2022-06-25 08:25:49.113331
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_prefix('./test_jsonfile_cache/', None) == 'ansible_'
    assert cache_module.get_timeout('./test_jsonfile_cache/', None) == 86400


# Generated at 2022-06-25 08:25:53.280970
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert(cache_module != None)



# Generated at 2022-06-25 08:25:55.321534
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()
    try:
        assert cache_module_0.__class__.__name__ == 'CacheModule'
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 08:26:01.318984
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Reset cache
    cache_module_0 = CacheModule()
    cache_module_0._reset()

    # Cache data
    cache_module_0._cache('hostname', 'key', 'value')
    cache_content = cache_module_0._load('hostname')
    assert cache_content['key'] == 'value'

    # Get data from cache
    cache_result = cache_module_0._get_cache('hostname', 'key')
    assert cache_result == 'value'

    # Get data from cache with default value
    cache_result = cache_module_0._get_cache('hostname', 'key2', 'default_value')
    assert cache_result == 'default_value'

    # Get data from cache with default value (no hostname)

# Generated at 2022-06-25 08:26:06.199667
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()
    #Test1: Test the properties of cache_module_0
    assert cache_module_0._options == {'_uri': None, '_timeout': 86400, '_prefix': None,
                                       '_basedir': None, '_expires': None}
    #Test2: Test the values of static members of cache_module_0
    assert cache_module_0._FILENAME_FMT == '{0}_{1}.json'
    assert cache_module_0._DATAFILE_EXT == '.json'
    assert cache_module_0._CACHE_PLUGIN_NAME == 'jsonfile'
    #Test3: Test the values of members of cache_module_0 after calling _load_options
    cache_module_0._load_options()
    #assert cache

# Generated at 2022-06-25 08:26:07.217578
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()


# Generated at 2022-06-25 08:26:07.673113
# Unit test for constructor of class CacheModule
def test_CacheModule():

    assert (True)

# Generated at 2022-06-25 08:26:15.727516
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # With no config
    cache = CacheModule()
    assert cache is not None

    # With config
    config = {
        'unit_test': True,
        '_uri': '/path/to'
    }
    cache = CacheModule(config)
    assert cache is not None

# Generated at 2022-06-25 08:26:17.774076
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.file_extension is not None
    assert c._timeout is not None
    assert c._load('/tmp/test') is None
    assert c._dump(['test'], '/tmp/test') is None

# Generated at 2022-06-25 08:26:21.047802
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Constructor of class CacheModule
    :return:
    """
    cacheModule = CacheModule()
    assert cacheModule._cache is None
    assert cacheModule._cache_name == 'jsonfile'
    assert cacheModule._load('./tests/unit/plugins/cache/files/') == {'17512': {'b': [1, 2, 3]}, '17514': {'b': [4, 5, 6]}}

# Generated at 2022-06-25 08:26:24.941729
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule('testName', {'path': 'test_path'})
    assert obj.plugin_name == 'testName'
    assert obj._get_options()['path'] == 'test_path'

# Generated at 2022-06-25 08:26:31.312787
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = "/tmp/ansible-cache"
    cm = CacheModule(cache_dir)
    assert cm.cache_dir == cache_dir
    assert cm.cache_timeout == 86400
    assert cm.cache_prefix == "ansible_facts"
    assert cm.plugin_name == "jsonfile"
    assert cm.plugin_options == {
        "cache_dir": cache_dir,
        "cache_prefix": "ansible_facts",
        "cache_timeout": 86400
    }

# Generated at 2022-06-25 08:26:36.199737
# Unit test for constructor of class CacheModule
def test_CacheModule():
    hostvars = {"test": "test"}
    path = "/etc/ansible"
    prefix = "test"
    timeout = 10
    newCacheModule = CacheModule(hostvars, path, prefix, timeout);
    assert newCacheModule.path == path
    assert newCacheModule.prefix == prefix
    assert newCacheModule.timeout == timeout

# Generated at 2022-06-25 08:26:37.072003
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule.CacheModule(), CacheModule)

# Generated at 2022-06-25 08:26:38.238745
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # initialize CacheModule object
    cache = CacheModule()
    assert cache

# Generated at 2022-06-25 08:26:39.961906
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print('start test_CacheModule')
    cache = CacheModule()
    print(cache)
    print('end test_CacheModule')


# Generated at 2022-06-25 08:26:41.500477
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule(0, None)
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-25 08:26:44.804259
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(None)) == NotImplemented

# Generated at 2022-06-25 08:26:45.786318
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.plugin_timeout == 86400

# Generated at 2022-06-25 08:26:48.121128
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None
    assert cache._load is not None
    assert cache._dump is not None

# Generated at 2022-06-25 08:26:51.566537
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._prefix == 'ansible-facts'
    assert c._timeout == 86400
    assert c._connection is None

# Generated at 2022-06-25 08:26:54.578158
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule

# Generated at 2022-06-25 08:26:56.707747
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule({'_uri': '/tmp', '_timeout': 3600})
    assert cache_module is not None

# Generated at 2022-06-25 08:27:00.309676
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Provision an instance of class CacheModule
    cache_module = CachePlugin(module_name='fakestack', module_args={'_uri': 'fakedir'})
    # Validate constructor
    assert cache_module.module_name == 'fakestack'
    assert cache_module.module_args == {'_uri': 'fakedir'}

# Generated at 2022-06-25 08:27:04.529254
# Unit test for constructor of class CacheModule
def test_CacheModule():
    backend = CacheModule()
    assert backend._timeout == 86400
    # Test for ignoring the ANSIBLE_CACHE_PLUGIN_PREFIX environment variable.
    assert backend._prefix is None

# Generated at 2022-06-25 08:27:13.113584
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible_fact_cache'
    assert cache._load('/tmp') is None
    assert cache._dump('tmp', '/tmp') is None
    assert cache.get('/tmp', 'tmp') is None
    assert cache.set('/tmp', 'tmp', 't') is None
    assert cache.keys('/tmp', 'tmp') is None
    assert cache.contains('/tmp', 'tmp') is None
    assert cache.delete('/tmp', 'tmp') is None
    assert cache.flush() is None
    assert cache.file_local_cache_path() is None
    assert cache.file_local_cache_filename() is None

# Generated at 2022-06-25 08:27:15.920079
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule().cache_plugin_name == 'jsonfile'
    assert CacheModule().cache_plugin_timeout == 86400
    assert CacheModule().cache_plugin_connection is None
    assert CacheModule().cache_plugin_prefix == ''

# Generated at 2022-06-25 08:27:29.126495
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Test the constructor of class CacheModule"""
    # set env
    import os
    os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = 'ansible/caching/jsonfile/connection'
    os.environ['ANSIBLE_CACHE_PLUGIN_TIMEOUT'] = '60'

    # create a instance of class CacheModule
    cm = CacheModule()

    # check the result of initializing the instance
    assert cm._connection == 'ansible/caching/jsonfile/connection'
    assert cm._load_file == CacheModule._load
    assert cm._dump_file == CacheModule._dump
    assert cm._timeout == 60

# Generated at 2022-06-25 08:27:33.158182
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-25 08:27:35.474827
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test constructor
    c = CacheModule()

    # No custom fields present
    assert c._timeout == 86400
    assert c._connection == None
    assert c._prefix == ''


# Generated at 2022-06-25 08:27:38.772461
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule('/tmp', 9999, 'test')
    # TODO: write test that it works when called on a nonexistent directory?
    # TODO: write test that it works when called on a file?

# Generated at 2022-06-25 08:27:39.326519
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-25 08:27:39.906857
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connector = CacheModule()

# Generated at 2022-06-25 08:27:42.686616
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    print(cm._prefix)
    print(cm._timeout)
    print(cm._load)
    print(cm._dump)


# Generated at 2022-06-25 08:27:44.247185
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Instantiation of class CacheModule
    cache_json_file = CacheModule()
    assert cache_json_file is not None

# Generated at 2022-06-25 08:27:46.466881
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert(module._prefix == 'ansible_facts')
    assert(module._timeout == 86400)
    assert(module._serializer == 'json')

# Generated at 2022-06-25 08:27:56.888368
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.cache import BaseCacheModule
    import tempfile
    import shutil
    import time

    dirpath = tempfile.mkdtemp()
    files = []

    # Test the constructor of CacheModule
    cache = CacheModule(connection=dirpath)

    # Test cache methods
    key = 'some_key'
    data = {'foo': 'bar'}
    cache.set(key=key, value=data)
    assert cache.get(key=key) == data

    cache.set(key='hello', value={'foo': 'bar'})
    cache.set(key='world', value={'baz': 'qux'})
    assert cache.has_key('hello')
    assert cache.has_key('world')

# Generated at 2022-06-25 08:28:11.157718
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_instance = CacheModule()
    assert cache_instance
    assert isinstance(cache_instance, CacheModule)
    assert cache_instance.file_extension == 'json'
    assert cache_instance._timeout == 86400
    assert cache_instance._prefix == ''
    assert cache_instance._get_options()
    assert cache_instance._load_plugin_options()


# Generated at 2022-06-25 08:28:16.229853
# Unit test for constructor of class CacheModule
def test_CacheModule():
    conn_settings = {'_uri': 'ansible-cache-directory', '_timeout': 86400, '_prefix': 'ansible_cache'}
    cache_module_instance = CacheModule(conn_settings)
    assert cache_module_instance._connection_settings == conn_settings
    assert cache_module_instance._valid_cache is True
    assert cache_module_instance._cache_dir == 'ansible-cache-directory'
    assert cache_module_instance._cache_prefix == 'ansible_cache'
    assert cache_module_instance._cache_timeout == 86400

# Generated at 2022-06-25 08:28:25.927362
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin_inst = CacheModule()

    assert isinstance(plugin_inst, CacheModule) is True
    assert plugin_inst._load('/root/.ansible/tmp/ansible-local-9186b5aacf5a0c74/tmp_0eAc') is None
    plugin_inst._dump({"key": "value"}, '/root/.ansible/tmp/ansible-local-9186b5aacf5a0c74/tmp_0eAc')
    assert plugin_inst._load('/root/.ansible/tmp/ansible-local-9186b5aacf5a0c74/tmp_0eAc') == {"key": "value"}

# Generated at 2022-06-25 08:28:26.764200
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.should_cache_fn is None

    # Clean up
    c = None

# Generated at 2022-06-25 08:28:28.457538
# Unit test for constructor of class CacheModule
def test_CacheModule():
    t = CacheModule()
    assert isinstance(t, CacheModule)
    assert isinstance(t, BaseFileCacheModule)

# Generated at 2022-06-25 08:28:29.872418
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-25 08:28:33.737722
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    Unit test for constructor of class CacheModule
    '''
    module = CacheModule()
    assert module.connection_info == (None, None)
    assert module.get_timeout() == 86400
    assert module.get_prefix() == ''

# Generated at 2022-06-25 08:28:34.860811
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(path="/tmp"))


# Generated at 2022-06-25 08:28:36.507631
# Unit test for constructor of class CacheModule
def test_CacheModule():
    testCache = CacheModule()
    testCache.set_options()
    assert testCache


# Generated at 2022-06-25 08:28:39.570161
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({}, {'_uri': 'file://', '_timeout': 60})

# Generated at 2022-06-25 08:29:05.874019
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = '/path/to/cache'
    timeout = 100
    plugin_prefix = 'prefix'

    cache = CacheModule()
    cache.set_options(path=path, timeout=timeout)
    # The plugin_prefix will be set after the CacheModule object has been created.
    cache.plugin_prefix = plugin_prefix

    assert cache._plugin_path == path
    assert cache._plugin_timeout == timeout
    assert cache._plugin_prefix == 'prefix'

# Generated at 2022-06-25 08:29:06.546961
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-25 08:29:08.078293
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create instance of CacheModule
    cm = CacheModule()
    assert cm
    assert cm._load
    assert cm._dump

# Generated at 2022-06-25 08:29:09.398641
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({})
    assert(cache._timeout == 86400)

# Generated at 2022-06-25 08:29:13.894783
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # pylint: disable=attribute-defined-outside-init,protected-access
    obj = CacheModule()
    assert obj._get_cache_prefix() == "ansible_facts"
    assert obj._get_cache_basedir() == "~/.ansible/tmp/ansible_fact_cache"
    assert obj._get_cache_expiration() == 86400

# Generated at 2022-06-25 08:29:17.416646
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Store a fake cache value for a host
    cache_module = CacheModule()
    cache_module._dump({'a': '1'}, "/tmp/test_jsonfile/abc.json")
    # Load the cache value from the host
    print(cache_module._load("/tmp/test_jsonfile/abc.json"))

# test_CacheModule()

# Generated at 2022-06-25 08:29:19.157678
# Unit test for constructor of class CacheModule
def test_CacheModule():
    args = {
        '_uri': '/tmp',
        '_prefix': 'pre',
        '_timeout': 86400
    }
    c = CacheModule(None, **args)

# Generated at 2022-06-25 08:29:20.712171
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({}, {})

# Generated at 2022-06-25 08:29:21.399343
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)

# Generated at 2022-06-25 08:29:22.481724
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-25 08:30:24.452027
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test is_valid
    # Test invalid (is_valid)
    assert CacheModule().is_valid is False

    # Test valid (is_valid)
    m = CacheModule()
    m.set_options({'_uri': '/tmp/test'})
    assert m.is_valid is True

# Generated at 2022-06-25 08:30:26.056669
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module=CacheModule()
    cache_module.path='/tmp/ansible_cache'
    assert cache_module.path == '/tmp/ansible_cache'

# Generated at 2022-06-25 08:30:32.733011
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Creates a CacheModule object and tests the constructor
    """
    cache_module = CacheModule([])
    assert cache_module.timeout == 86400
    assert cache_module._plugins_key == "ANSIBLE_CACHE_PLUGINS"
    assert cache_module._cache_prefix == None
    assert cache_module._timeout == 86400
    assert cache_module._connection == None

# Generated at 2022-06-25 08:30:35.248292
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule('deadbeef')
    assert cache_module._connection
    assert cache_module._prefix == 'ansible-cache'
    assert cache_module._timeout == 86400


# Generated at 2022-06-25 08:30:38.492120
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None
    assert cache.get_basedir() and cache.get_prefix() == "ansible_facts"
    assert cache.get_timeout() == 86400
    assert cache._load("") is None
    assert cache._dump({}, "") is None

# Generated at 2022-06-25 08:30:43.630370
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Instance of the class CacheModule
    cache_module = CacheModule()
    # Check that base_cache_dir is empty string
    assert cache_module.base_cache_dir == ''
    # Check that cache_plugin_timeout is integer 86400
    assert cache_module.cache_plugin_timeout == 86400



# Generated at 2022-06-25 08:30:45.564995
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)
    cache_module = CacheModule()
    assert isinstance(cache_module, BaseFileCacheModule)

# Generated at 2022-06-25 08:30:50.720607
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # always use the main content class, never the cache module
    # class directly to test things related to the cache
    import os

    cache_connection = os.path.join(os.getcwd(), 'fact_cache')
    cache_timeout = 3600

    cache = CacheModule({}, cache_connection, cache_timeout)

    assert cache._timeout == cache_timeout
    assert cache._load_plugin == cache._load
    assert cache._dump_plugin == cache._dump
    assert cache._connection == cache_connection + '/'

    # Cleanup
    cache.flush()

# Generated at 2022-06-25 08:31:00.050488
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        import __main__
        import builtins
    except ImportError:
        import __builtin__ as builtins

    try:
        import builtins.open as open
    except ImportError:
        import __builtin__ as open

    try:
        import builtins.property as property
    except ImportError:
        import __builtin__ as property

    try:
        import builtins.str as str
    except ImportError:
        import __builtin__ as str

    try:
        import builtins.super as super
    except ImportError:
        import __builtin__ as super


# Generated at 2022-06-25 08:31:03.511193
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-25 08:33:09.676834
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None
    assert c._connection is None
    assert c._timeout == 86400
    assert c._prefix is None
    assert c._load_cache() == {}
    assert c._dump_cache({}) is None
    assert c._flush_cache() == {}

# Generated at 2022-06-25 08:33:10.922380
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert str(type(cm)) == "<class 'ansible.plugins.cache.jsonfile.CacheModule'>"

# Generated at 2022-06-25 08:33:12.040718
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test the constructor of class CacheModule
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-25 08:33:15.661747
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = '/var/tmp/ansible_direct/'
    plugin_prefix = 'test_prefix_'
    cache_plugin_timeout = 60

    cache_plugin = CacheModule({'_uri': cache_dir, '_prefix': plugin_prefix, '_timeout': cache_plugin_timeout})

    assert cache_plugin.cache_dir == cache_dir
    assert cache_plugin.plugin_prefix == plugin_prefix
    assert cache_plugin.cache_plugin_timeout == cache_plugin_timeout
    assert cache_plugin.cache_plugin_timeout_tester == 12

# Generated at 2022-06-25 08:33:16.499074
# Unit test for constructor of class CacheModule
def test_CacheModule():
    json_file = CacheModule()
    assert json_file.__class__.__name__ == 'CacheModule'


# Generated at 2022-06-25 08:33:17.446824
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import ansible.plugins
    c = CacheModule()
    assert c

# Generated at 2022-06-25 08:33:18.105144
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    print(cache)

# Generated at 2022-06-25 08:33:19.795396
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachePlugin = CacheModule({'_uri':'/tmp/', '_prefix':'prefix', '_timeout':'timeout'})

    assert cachePlugin._uri == '/tmp/'
    assert cachePlugin._prefix == 'prefix'
    assert cachePlugin._timeout == 'timeout'

# Generated at 2022-06-25 08:33:20.333308
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-25 08:33:24.753989
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Constructor test : with and without uri
    assert CacheModule()
    assert CacheModule(get_option=lambda x:'/tmp/ansible-test')