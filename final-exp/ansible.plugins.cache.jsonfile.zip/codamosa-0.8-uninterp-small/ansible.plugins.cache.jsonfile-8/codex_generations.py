

# Generated at 2022-06-25 08:25:42.739944
# Unit test for constructor of class CacheModule
def test_CacheModule():
    global cache_module_0
    cache_module_0 = CacheModule()
    assert isinstance(cache_module_0, CacheModule), "test_CacheModule: constructor of class CacheModule is not working"



# Generated at 2022-06-25 08:25:49.790885
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    config = dict(
        _uri='/tmp/ansible/tmpk9Hmv8',
        _prefix='ansible_facts_',
        _expires=7200
    )
    cache_module.set_options(config)

    data = dict(
        guests=['Fedora', 'Debian', 'Arch Linux'],
        distro='Debian'
    )
    assert cache_module.get('127.0.0.1', data) == dict(
        guests=['Fedora', 'Debian', 'Arch Linux'],
        distro='Debian'
    )
    assert cache_module.has_expired('127.0.0.1', data) == False
    cache_module.set_options(config)

# Generated at 2022-06-25 08:25:52.831943
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule().__class__.__name__ == 'CacheModule'


# Generated at 2022-06-25 08:25:55.177253
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj._plugin_name == 'jsonfile'
    assert obj._options is None
    assert obj._connection is None
    assert obj._prefix == 'ansible_facts'
    assert obj._timeout == 86400
    assert obj._valid is True

# Generated at 2022-06-25 08:25:56.592819
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()


if __name__ == '__main__':
    import coverage
    coverage.run_tests()

# Generated at 2022-06-25 08:26:00.998281
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test constructor
    cache_module_0 = CacheModule()

    # Test constructor accessors
    assert cache_module_0 is not None, \
        "CacheModule constructor object set failed"
    assert cache_module_0.path == "/tmp/ansible_fact_cache", \
        "CacheModule constructor object path set failed"
    assert cache_module_0.plugin_name == "jsonfile", \
        "CacheModule constructor object name set failed"
    assert cache_module_0.timeout == 86400, \
        "CacheModule constructor object timeout set failed"
    assert cache_module_0.prefix == "ansible_fact_cache", \
        "CacheModule constructor object prefix set failed"


# Generated at 2022-06-25 08:26:02.025111
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()

# Generated at 2022-06-25 08:26:05.349442
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create a new CacheModule instance
    cache_module = CacheModule()
    assert isinstance(cache_module, CacheModule)


# Generated at 2022-06-25 08:26:09.441451
# Unit test for constructor of class CacheModule
def test_CacheModule():
   cache_module = CacheModule()


# Generated at 2022-06-25 08:26:15.767767
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()
    assert cache_module_0._uri == '/tmp/ansible'
    assert cache_module_0._timeout == 86400
    assert cache_module_0._prefix == 'ansible-fact'



# Generated at 2022-06-25 08:26:20.180573
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert (cache_module.file_extension == '.json')


# Generated at 2022-06-25 08:26:25.561686
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()
    assert cache_module_1._timeout == 86400
    assert cache_module_1._connection == 'ANSIBLE_CACHE_PLUGIN_CONNECTION'
    assert cache_module_1._prefix == 'ANSIBLE_CACHE_PLUGIN_PREFIX'


# Generated at 2022-06-25 08:26:27.928897
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Empty values in constructor
    cache_module_1 = CacheModule()
    assert cache_module_1.get_options() == {}


# Generated at 2022-06-25 08:26:29.262256
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()
    assert cache_module_1

# Generated at 2022-06-25 08:26:30.553037
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module != None


# Generated at 2022-06-25 08:26:37.485552
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        # Expected: object of class 'ansible.plugins.cache.jsonfile.CacheModule'
        assert isinstance(CacheModule(), CacheModule)
    except AssertionError:
        # Test will fail if actual value is not equal to expected value
        # Print a message and exit program
        print("test_CacheModule: FAILED")
        sys.exit(1)
    print("test_CacheModule: PASSED")

if __name__ == '__main__':
    test_case_0()
    test_CacheModule()

# Generated at 2022-06-25 08:26:38.631891
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()


# Generated at 2022-06-25 08:26:39.355962
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-25 08:26:45.458908
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()
    cache_module_1._timeout = 30
    cache_module_1._uri = "./test_cache_plugin/tmp"
    cache_module_1._prefix = "ansible"

    assert(cache_module_1._timeout == 30)
    assert(cache_module_1._uri == "./test_cache_plugin/tmp")
    assert(cache_module_1._prefix == "ansible")


# Generated at 2022-06-25 08:26:47.004234
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()

# Generated at 2022-06-25 08:26:53.997910
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj != None

# Unit test to check if JSON file is created

# Generated at 2022-06-25 08:27:03.945040
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache_module_0 = CacheModule()
    # Check if cache_module_0 is an instance of CacheModule
    assert isinstance(cache_module_0, CacheModule)

    # Check _load method
    cache_module_0._load(filepath="tests/tools/filecache/test.json")

    # Check _dump method
    cache_module_0._dump(value="value", filepath="tests/tools/filecache/test.json")

    # Check flush method
    cache_module_0.flush(host='host_1')

    # Check populate method
    cache_module_0.populate()

    # Check get method
    assert cache_module_0.get(host='host_1') == "host_cache_data"

    # Check set method

# Generated at 2022-06-25 08:27:13.285781
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin_options = {
        '_uri': '.',
        '_prefix': '',
        '_timeout': 86400
    }

    cache_module = CacheModule()
    assert(cache_module.path == '.')

    cache_module = CacheModule(plugin_options)
    assert(cache_module.path == '.')

    plugin_options_2 = {
        '_uri': '/var/tmp',
        '_prefix': '',
        '_timeout': 86400
    }
    cache_module = CacheModule(plugin_options_2)
    assert(cache_module.path == '/var/tmp')

    plugin_options_3 = {
        '_uri': '/var/tmp',
        '_prefix': '',
        '_timeout': 400
    }
    cache_module = CacheModule

# Generated at 2022-06-25 08:27:15.491499
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.fileext == 'json'
    assert cache_module.data == {}
    assert cache_module.plugin_name == 'jsonfile'

# Generated at 2022-06-25 08:27:15.996252
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule

# Generated at 2022-06-25 08:27:17.541275
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()
    assert isinstance(cache_module_1,CacheModule)

# Generated at 2022-06-25 08:27:18.845976
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()
    assert type(cache_module_1) == CacheModule


# Generated at 2022-06-25 08:27:20.587694
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print('\n')
    print ('Unittest for CacheModule class constructor started')

    print ('Unittest for CacheModule class constructor finished')
    print('\n')



# Generated at 2022-06-25 08:27:21.495511
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-25 08:27:28.094327
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == '.'
    assert cache_module.get_prefix() is None

    connection = '/path/to/cache'
    cache_module.set_connection(connection)
    assert cache_module.get_connection() == connection

    timeout = 3600
    cache_module.set_timeout(timeout)
    assert cache_module.get_timeout() == timeout

    prefix = 'test'
    cache_module.set_prefix(prefix)
    assert cache_module.get_prefix() == prefix

# Generated at 2022-06-25 08:27:36.408640
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    cache_plugin._init_plugin({'_uri': '/tmp'})
    assert cache_plugin.plugin_name == 'jsonfile'
    assert cache_plugin.cache_time == 86400
    assert cache_plugin.cache_path == '/tmp'
    assert cache_plugin.cache_prefix == ''

# Generated at 2022-06-25 08:27:44.257193
# Unit test for constructor of class CacheModule
def test_CacheModule():
    conn = CacheModule()
    assert conn._timeout == 86400
    assert conn._prefix == 'ansible-factcache'
    assert conn._load({'_timeout': 3600, '_prefix': 'ansible-cache', '_uri': '/tmp/ansible/cache'}) is None
    assert conn._load({'_timeout': 3600, '_prefix': 'ansible-factcache', '_uri': '/tmp/ansible/cache'}) is None
    assert conn._dump({'data': 'test'}, '/tmp/test') is None
    assert conn._dump({'data': 'test'}, '/') is None

# Generated at 2022-06-25 08:27:49.588970
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__name__ == 'CacheModule'

    # CacheModule(self, module, **kwargs)
    cache = CacheModule()

    # get(self, key)
    assert cache.get('foobar') == None

    # set(self, key, value)
    cache.set('foobar', 'baz')
    assert cache.get('foobar') == 'baz'
    cache.set('foobar', 'spam')
    assert cache.get('foobar') == 'spam'

# Generated at 2022-06-25 08:27:50.166980
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-25 08:27:57.353773
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    try:
        os.mkdir('/tmp/cachetest')
    except OSError as e:
        import errno
        if e.errno != errno.EEXIST:
            raise e

    m = CacheModule()
    m._timeout = 2
    m.set('test', 'data')
    assert m.get('test') == 'data'

    import time
    time.sleep(m._timeout + 1)
    assert m.get('test') is None

# Generated at 2022-06-25 08:28:02.623806
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Instantiate an object of class CacheModule
    cache = CacheModule()


# Generated at 2022-06-25 08:28:06.697270
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    An unit test for testing the constructor of class CacheModule
    """
    arg_spec = BaseFileCacheModule._load_arg_spec()
    test = CacheModule(**arg_spec)
    assert test._load(test.plugin_path)

# Generated at 2022-06-25 08:28:07.654899
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(CacheModule()!=None )

# Generated at 2022-06-25 08:28:15.036014
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import shutil
    import tempfile
    import errno

    temp_dir = tempfile.mkdtemp()
    cache = CacheModule(temp_dir)

    # Check directory exists
    assert os.path.isdir(temp_dir)

    # Check directory is empty
    assert len(os.listdir(temp_dir)) == 0

    # Cache one value
    cache.set('key', 'value')
    assert os.listdir(temp_dir) == ['key.json']

    # Check content of file
    with codecs.open(os.path.join(temp_dir, 'key.json'), 'r', encoding='utf-8') as f:
        data = json.load(f, cls=AnsibleJSONDecoder)
    assert data == 'value'

    # Check we can get value back

# Generated at 2022-06-25 08:28:16.380392
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

# Unit test to test load and dump functions of class CacheModule

# Generated at 2022-06-25 08:28:28.503977
# Unit test for constructor of class CacheModule
def test_CacheModule():
    a = CacheModule()

# Generated at 2022-06-25 08:28:31.100499
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache_module = CacheModule()

    assert cache_module.file_extension == 'json'

# Generated at 2022-06-25 08:28:33.507468
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m._prefix == "ansible-facts"
    assert m._timeout == 86400

# Generated at 2022-06-25 08:28:36.793713
# Unit test for constructor of class CacheModule
def test_CacheModule():
    timeout = 30 # sec
    cache_dir = '.'
    prefix = 'test'
    plugin = CacheModule(timeout, cache_dir, prefix)
    assert plugin.cache_dir == cache_dir
    assert plugin.prefix == prefix
    assert plugin.timeout == timeout

# Generated at 2022-06-25 08:28:41.842161
# Unit test for constructor of class CacheModule
def test_CacheModule():

    assert issubclass(CacheModule, BaseFileCacheModule)
    # Verify that an instance of the class can be constructed
    cache_module = CacheModule()
    assert isinstance(cache_module, CacheModule)
    # Verify that an instance of the class does not have a 'tmp_dir' attribute
    assert not hasattr(cache_module, 'tmp_dir')

# Generated at 2022-06-25 08:28:43.697933
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ''' cache_jsonfile.py:CacheModule '''
    module = CacheModule()
    assert module.set(module.name, module.name) is True
    assert module.get(module.name) == module.name

# Generated at 2022-06-25 08:28:45.975747
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule) is True, "Wrong class inheritance"

# Generated at 2022-06-25 08:28:48.949640
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = {}
    data['connection'] = 'test'
    cm = CacheModule(data)

    # Test the CacheModule constructor
    assert cm._connection == 'test'
    assert cm._timeout == 86400
    assert cm._prefix is None
    assert cm._cache_files == {}
    assert cm._cache_file_ttls == {}

# Test validate function in class CacheModule

# Generated at 2022-06-25 08:28:49.861394
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-25 08:28:55.108219
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert isinstance(m, BaseFileCacheModule)
    assert isinstance(m._load, __builtins__['object'])
    assert isinstance(m._dump, __builtins__['object'])
    assert isinstance(m.get_options(), __builtins__['dict'])

# Generated at 2022-06-25 08:29:21.768529
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachedir = '/tmp/cachedir'
    timeout = 3600
    prefix = 'ansible-fact_cache'

    plugin = CacheModule({'_prefix': prefix, '_uri': cachedir, '_timeout': timeout})

    assert cachedir == plugin._CacheModule__cachedir
    assert timeout == plugin._CacheModule__timeout
    assert plugin._CacheModule__prefix == prefix

# Generated at 2022-06-25 08:29:23.220106
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None
    assert type(cm) is CacheModule
    assert cm.get_cache_enabled() is True

# Generated at 2022-06-25 08:29:28.550862
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = "localhost"
    module_name = "jsonfile"
    timeout = 86400
    prefix = "ansible_"
    cls = CacheModule
    cache_plugin = cls(connection, module_name, timeout, prefix)
    assert cache_plugin._connection == "localhost"
    assert cache_plugin._module_name == "jsonfile"
    assert cache_plugin._timeout == 86400
    assert cache_plugin._prefix == "ansible_"
    assert cache_plugin.validate_file(connection) == True
    assert cache_plugin.validate_file("localhost") == True
    assert cache_plugin.validate_file("a") == False
    assert cache_plugin.validate_file("") == False


# Generated at 2022-06-25 08:29:30.091853
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule() is not None


# Generated at 2022-06-25 08:29:34.026877
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = 'jsonfile'
    tmp = '/tmp/ansible_fact_cache'
    timeout = 0
    cm = CacheModule(tmp, cache, timeout)
    assert cm.cache == 'jsonfile'
    assert cm.cache_dir == '/tmp/ansible_fact_cache'
    assert cm.timeout == 0
    assert cm.plugin_name == cache

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-25 08:29:38.312680
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ch = CacheModule()
    assert not ch.is_valid('localhost', 'master')
    assert ch._load is not None
    assert ch.get is not None
    assert ch.get('master') is None
    assert ch.load_cache_plugin is not None
    assert ch.save is not None
    assert ch._dump is not None


# Generated at 2022-06-25 08:29:38.820412
# Unit test for constructor of class CacheModule
def test_CacheModule():
    f = CacheModule()

# Generated at 2022-06-25 08:29:41.516601
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_case = CacheModule()
    assert isinstance(test_case, BaseFileCacheModule)

# Generated at 2022-06-25 08:29:44.631771
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_name = 'jsonfile'
    cache_plugin = CacheModule()
    cache_plugin.set_options({'_uri': '/tmp/ansible'})
    assert cache_plugin.get_name() == cache_name

# Generated at 2022-06-25 08:29:45.381736
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-25 08:30:48.804804
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule(None)
    assert x is not None
    assert isinstance(x, CacheModule)

# Generated at 2022-06-25 08:30:49.842370
# Unit test for constructor of class CacheModule
def test_CacheModule():
    the_plugin=CacheModule()
    assert the_plugin is not None


# Generated at 2022-06-25 08:30:55.584254
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = '/root/path'
    timeout = '86400'
    prefix = 'ansible'

    assert CacheModule({'_uri':path})._uri == '/root/path'
    assert CacheModule({'_timeout':timeout})._timeout == '86400'
    assert CacheModule({'_prefix':prefix})._prefix == 'ansible'

# Generated at 2022-06-25 08:30:56.158575
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-25 08:31:00.966116
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(dict()), CacheModule)

# Generated at 2022-06-25 08:31:05.954623
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with default values
    cache = CacheModule()
    assert cache._connection == '$HOME/.ansible/cache'
    assert cache._prefix == 'ansible-cache'
    assert cache._timeout == 86400

    # Test with parameters
    cache = CacheModule(connection='test/test', prefix='test', timeout=3600)
    assert cache._connection == 'test/test'
    assert cache._prefix == 'test'
    assert cache._timeout == 3600


# Generated at 2022-06-25 08:31:13.772192
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    print(x)
    x._load('/tmp/ansible.fact_cache/v2/1/localhost/ansible_facts')
    x._dump(
        {'test': 'jsonfile'},
        '/tmp/ansible.fact_cache/v2/1/test/test'
    )

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-25 08:31:15.888761
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__doc__

# Generated at 2022-06-25 08:31:21.771762
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # This code is executed when this file is imported by test-cache.py
    # We are trying to test all the cases where an exception is raised
    # if the required parameter _uri is missing
    this = {
        '_prefix': 'test',
        '_timeout': 10
    }
    try:
        cm = CacheModule(this)
        assert False
    except:
        pass

    this = {
        '_uri': 'test',
        '_timeout': 10
    }
    try:
        cm = CacheModule(this)
        assert False
    except:
        pass

    this = {
        '_uri': 'test',
        '_prefix': 10
    }
    try:
        cm = CacheModule(this)
        assert False
    except:
        pass

    # test loading from config file
    this

# Generated at 2022-06-25 08:31:22.988435
# Unit test for constructor of class CacheModule
def test_CacheModule():
    result = CacheModule.__init__()
    assert result == None

test_CacheModule()

# Generated at 2022-06-25 08:33:35.082324
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    print(c)

# Generated at 2022-06-25 08:33:43.873397
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Constructor of class CacheModule
    # params:
    #   _uri       : A connection string or URI for the cache path
    #   _timeout   : The timeout for the cache plugin data (Defaults to 86400)
    #   _prefix    : A prefix for the plugin. This should be a string that is
    #                unique to this plugin (Defaults to jsonfile if not set)
    #   _data      : A dictionary of the current cache data
    plugin = CacheModule(_uri='/tmp/test', _timeout=86400, _prefix='jsonfile', _data={'a':1, 'b':2})

    # get(self, host): Get data from the cache
    data = plugin.get('host1')
    assert data == {'a': 1, 'b': 2}

    # set(self, host, value):


# Generated at 2022-06-25 08:33:45.976805
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create a cache instance
    cache = CacheModule()
    # Check the _timeout, which should be 86400 as in our docstring
    assert cache._timeout == 86400

# Generated at 2022-06-25 08:33:46.719627
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule is not None

# Generated at 2022-06-25 08:33:47.999018
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.get_timeout() == 86400, 'Default timeout should be 86400'

# Generated at 2022-06-25 08:33:49.735760
# Unit test for constructor of class CacheModule
def test_CacheModule():
    args = {"_uri": "/tmp/ansible_fact_cache/", "_prefix": "", "_timeout": 3600}
    cache = CacheModule(**args)
    assert cache != None

# Generated at 2022-06-25 08:33:55.253814
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    from ansible.plugins.cache import BaseFileCacheModule
    assert isinstance(CacheModule(), BaseFileCacheModule)

# Generated at 2022-06-25 08:34:00.522497
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule('/path/to/data')


# Generated at 2022-06-25 08:34:07.128094
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    assert cache is not None
    assert cache.cache_plugin_name == 'jsonfile'
    assert cache._connection._prefix is None
    assert cache._connection._timeout == 86400
    assert cache._connection._context is None
    assert cache._connection._lock_path is None
    assert cache._connection._uri is None
    assert cache._connection._lock_timeout == 30
    assert cache._connection._lock_sleep is 0.01


# Generated at 2022-06-25 08:34:16.335927
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

    # c is an object of class CacheModule
    assert isinstance(c, CacheModule)

    # c is an object of class BaseFileCacheModule
    assert isinstance(c, BaseFileCacheModule)

    # c has a set of methods
    assert 'get' in vars(c)
    assert 'set' in vars(c)
    assert 'delkey' in vars(c)
    assert 'keys' in vars(c)
    assert 'flush' in vars(c)
    assert '_load' in vars(c)
    assert '_dump' in vars(c)

    # c has no set of attributes
    assert 'plugin_name' not in vars(c)
    assert 'plugin_timeout' not in vars(c)