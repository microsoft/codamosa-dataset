

# Generated at 2022-06-25 08:25:42.999408
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule


# Generated at 2022-06-25 08:25:44.755521
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400

# Generated at 2022-06-25 08:25:45.581922
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()


# Generated at 2022-06-25 08:25:46.929513
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_case_0()


if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-25 08:25:47.669091
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert type(CacheModule) == type


# Generated at 2022-06-25 08:25:53.515459
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)
    cache_module_0 = CacheModule()


# Generated at 2022-06-25 08:25:53.983723
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-25 08:25:54.575619
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_case_0()

# Generated at 2022-06-25 08:25:55.285114
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()

# Generated at 2022-06-25 08:25:57.593559
# Unit test for constructor of class CacheModule
def test_CacheModule():


    # Get ansible.plugins.cache.jsonfile.CacheModule object
    cache_module_1 = CacheModule()

    # Get ansible.plugins.cache.jsonfile.CacheModule object
    cache_module_2 = CacheModule()

    assert cache_module_1 is cache_module_2


# Generated at 2022-06-25 08:26:02.495059
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create instance of CacheModule and call it's methods to get a feel of how it works
    plugin = CacheModule()
    plugin.set_options(connection = 'jsonfile',
                       _prefix = 'test')
    _dump_name = plugin._dump_name('uno', 'dos')
    _load_name = plugin._load_name('uno', 'dos')

# Generated at 2022-06-25 08:26:03.051206
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert True

# Generated at 2022-06-25 08:26:04.175185
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule({})
    assert module.plugin_name == "jsonfile"

# Generated at 2022-06-25 08:26:05.424093
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_module = CacheModule()
    assert isinstance(test_module, CacheModule)


# Generated at 2022-06-25 08:26:11.160807
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.get("test_base_file_cache_module_get") is None
    assert cm.set("test_base_file_cache_module_set", "test_base_cache_module") is None
    assert cm.get("test_base_file_cache_module_get") == "test_base_cache_module"
    assert cm.keys() == ["test_base_file_cache_module_set"]
    assert cm.contains("test_base_file_cache_module_set") is True
    assert cm.delete("test_base_file_cache_module_set") is True
    assert cm.delete("test_base_file_cache_module_delete") is None
    assert cm.flush() is None

# Generated at 2022-06-25 08:26:13.578762
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # create new CacheModule
    CacheModule()

# Generated at 2022-06-25 08:26:17.623075
# Unit test for constructor of class CacheModule
def test_CacheModule():
    file_cache_data = { '_uri': '/tmp/ansible', '_prefix':'ansible' }
    cache_module = CacheModule(file_cache_data)
    assert cache_module.file_prefix == 'ansible'
    assert cache_module.basedir == '/tmp/ansible'

# Generated at 2022-06-25 08:26:28.985792
# Unit test for constructor of class CacheModule
def test_CacheModule():
    key = 'localhost'
    path = '/tmp/ansible-cache'
    timeout = 300
    value = {'test': 'value'}

    file_cache = CacheModule()
    file_cache._connection = path
    file_cache._prefix = 'prefix'
    file_cache._timeout = timeout

    file_name = file_cache._create_file_name(key)


# Generated at 2022-06-25 08:26:35.290325
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule('/tmp/foo')

    assert c._connection != None
    assert c._connection == '/tmp/foo'
    assert c._prefix == None
    assert c._timeout == 86400

    c = CacheModule('/tmp/foo', 'bar', 42)

    assert c._connection != None
    assert c._connection == '/tmp/foo'
    assert c._prefix != None
    assert c._prefix == 'bar'
    assert c._timeout == 42

# Generated at 2022-06-25 08:26:35.835122
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-25 08:26:39.739462
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Don't do anything
    assert True

# Generated at 2022-06-25 08:26:40.786406
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create an instance of CacheModule
    # with the default constructor
    cache = CacheModule()

# Generated at 2022-06-25 08:26:41.245944
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-25 08:26:41.745899
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-25 08:26:42.206582
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule(dict())

# Generated at 2022-06-25 08:26:48.068796
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c1 = CacheModule()
    c2 = CacheModule()
    c3 = CacheModule()
    c1.get("KEY")
    c1.set("KEY", "VALUE")
    c1.get("KEY")
    c2.get("KEY")
    c3.set("KEY", "VALUE")
    c3.get("KEY")
    c3.set("KEY", "VALUE")
    c1.get("KEY")
    c2.get("KEY")

# Generated at 2022-06-25 08:26:52.288098
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule(connection='connection')
    assert obj._connection == 'connection'
    assert obj._prefix == 'ansible-cache'
    assert obj._timeout == 86400


# Generated at 2022-06-25 08:26:55.939464
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._encoder_class == AnsibleJSONEncoder


# Generated at 2022-06-25 08:26:56.793813
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print(CacheModule())


# Generated at 2022-06-25 08:26:57.333899
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-25 08:27:04.377950
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm

# vim: set expandtab:

# Generated at 2022-06-25 08:27:04.947746
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert True

# Generated at 2022-06-25 08:27:06.223529
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(isinstance(CacheModule(), CacheModule))

# Generated at 2022-06-25 08:27:14.458726
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import shutil
    import tempfile
    import time

    test_dir = tempfile.mkdtemp()
    test_file = 'test_file.json'
    test_file_full = os.path.join(test_dir, test_file)

    test_file_data = {'test_key': 'test_value', 'test_key2': ['test_value2', 'test_value3'], 'test_key3': {'test_key3_1': 'test_key3_2'}}

    c = CacheModule()
    c.set_options(direct={'_uri': test_dir})
    c.set_context(play=dict(basedir=test_dir))

    c.set(test_file, test_file_data)

    # Test that file exists

# Generated at 2022-06-25 08:27:15.667587
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('/tmp')

    assert(cache)

# Generated at 2022-06-25 08:27:22.440995
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(task=None)
    assert cache._key_cache_prefix == 'ansible_facts'
    assert cache._key_connection == 'localhost'
    assert cache._key_timeout == 86400
    assert cache._key_content_type == 'json'
    assert cache._key_file_extension == 'json'

    # Ensure set_options() overwrites defaults
    cache.set_options(connection='/tmp', timeout=1, content_type='json', prefix='prefix', plugin_name='json')
    assert cache._key_cache_prefix == 'prefix'
    assert cache._key_connection == '/tmp'
    assert cache._key_timeout == 1
    assert cache._key_content_type == 'json'
    assert cache._key_file_extension == 'json'

# Generated at 2022-06-25 08:27:32.883911
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Given: Ansible.cfg has the following settings
    # fact_caching_connection=/caching/plugins/connection
    # fact_caching_timeout=86400
    # fact_caching_prefix=ansible_facts
    # When: I execute the command
    cache = CacheModule()
    # Then: The instance of the CacheModule class should be returned
    assert type(cache) is CacheModule
    # And: The settings passed to the class should be as expected
    assert cache._connection == "/caching/plugins/connection"
    assert cache._timeout == 86400
    assert cache._prefix == "ansible_facts"
    # And: The file name prefix should be correct
    assert cache._file_prefix == "ansible_facts"

# Generated at 2022-06-25 08:27:34.937582
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.__class__.__name__ == "CacheModule"

# Generated at 2022-06-25 08:27:38.396403
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''Unittest for constructor for CacheModule'''
    cache = CacheModule('cache/json')
    assert not os.path.exists(cache._directory)
    cache.flush()
    assert os.path.exists(cache._directory)

# Generated at 2022-06-25 08:27:38.939755
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-25 08:27:50.701402
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache

# Generated at 2022-06-25 08:27:51.235811
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-25 08:27:54.166152
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachemodule = CacheModule()
    assert isinstance(cachemodule, CacheModule) is True


# Generated at 2022-06-25 08:27:55.575850
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c
    assert c._timeout == 86400

# Generated at 2022-06-25 08:28:03.059635
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import datetime
    import os
    import time

    # Create a temporary empty file for testing
    tmpfile = os.tmpnam()
    open(tmpfile, 'a').close()

    # Create a test class for constructor
    test_class = CacheModule()
    test_class.set_options({'_uri': tmpfile,
                            '_timeout': 1,
                            '_prefix': 'test'})

    # Write test data to temporary file
    test_class._dump({'test1': 'test1'}, tmpfile)
    assert(test_class.get('test1') == 'test1')

    # Validate timeout
    time_now = datetime.datetime.now()
    test_class._dump({'test2': 'test2'}, tmpfile)
    # Wait 1 second

# Generated at 2022-06-25 08:28:07.399121
# Unit test for constructor of class CacheModule
def test_CacheModule():
    dir = 'dir'
    plugin = 'plugin'
    timeout = 10
    prefix = 'prefix'
    _CacheModule = CacheModule(dir, plugin, timeout, prefix)
    assert _CacheModule._connection == dir
    assert _CacheModule._plugin_name == plugin
    assert _CacheModule._timeout == (60 * 60 * 24 * timeout)

# Generated at 2022-06-25 08:28:08.786898
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.__class__.__name__ == 'CacheModule'

# Generated at 2022-06-25 08:28:10.672063
# Unit test for constructor of class CacheModule
def test_CacheModule():
   cache_module = CacheModule()
   assert isinstance(cache_module, CacheModule)

if __name__ == '__main__':
   test_CacheModule()

# Generated at 2022-06-25 08:28:12.510665
# Unit test for constructor of class CacheModule
def test_CacheModule():
    f_path = "./ansible_file"
    c = CacheModule(f_path)
    assert c.file_path == f_path

# Generated at 2022-06-25 08:28:15.695978
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.loader import cache_loader
    cache_plugin = cache_loader.get("jsonfile", {})
    assert cache_plugin is not None
    assert isinstance(cache_plugin, CacheModule)


# Generated at 2022-06-25 08:28:40.451967
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    cache._load("")

# Generated at 2022-06-25 08:28:41.259497
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule({'_uri': '/tmp'})
    assert c

# Generated at 2022-06-25 08:28:42.950276
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert isinstance(cache_plugin, CacheModule)

# Generated at 2022-06-25 08:28:45.687084
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c
    assert c.get_db_file_path('test') == 'test.json'

# Generated at 2022-06-25 08:28:46.955953
# Unit test for constructor of class CacheModule
def test_CacheModule():
   cache_module = CacheModule()
   assert hasattr(cache_module, '_load')
   assert hasattr(cache_module, '_dump')

# Generated at 2022-06-25 08:28:49.289607
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Construct expected attributes of a CacheModule instance.
    cache = CacheModule()
    assert cache.cache_dir == 'cachedir'
    assert cache.timeout == 86400
    assert cache.extension == 'cache'
    assert cache.basekey == '_prefix'

# Generated at 2022-06-25 08:28:50.165045
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()

# Generated at 2022-06-25 08:28:51.816639
# Unit test for constructor of class CacheModule
def test_CacheModule():
    a = CacheModule()
    assert (a)


# Generated at 2022-06-25 08:28:54.589001
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert None is cache_plugin._load()
    #assert 'JSON' is cache_plugin._dump()

# Generated at 2022-06-25 08:28:56.694368
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({}) != None

# Generated at 2022-06-25 08:29:51.731715
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)
    assert isinstance(cache, BaseFileCacheModule)
    
    # Test the _load and _dump functions
    data = {
        'hello': 'world',
        'today': {
            'answer':42
        }
    }
    assert cache._load("./test_jsonfile_load.json") == data
    cache._dump(data, './test_jsonfile_dump.json')
    assert cache._load("./test_jsonfile_dump.json") == data

# Generated at 2022-06-25 08:29:57.847285
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Unit test for constructor of CacheModule class
    """
    try:
        cache = CacheModule()

        assert cache._options is not None
        assert cache._load is not None
        assert cache._dump is not None

    finally:
        cache = None


# Generated at 2022-06-25 08:29:59.780137
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.get_cache_prefix() == "ansible-cache"

# Generated at 2022-06-25 08:30:00.317875
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-25 08:30:04.769367
# Unit test for constructor of class CacheModule
def test_CacheModule():
    _uri = 'path'
    _prefix = 'prefix'
    _timeout = 'timeout'
    _plugin = CacheModule(_uri, _prefix, _timeout)
    assert _plugin._basedir == 'path'
    assert _plugin._prefix == 'prefix'
    assert _plugin._timeout == 'timeout'


# Generated at 2022-06-25 08:30:11.079789
# Unit test for constructor of class CacheModule
def test_CacheModule():
    temp = CacheModule()
    assert(temp._timeout == 86400)


# Generated at 2022-06-25 08:30:14.941041
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_timeout == 86400
    assert cache.cache_prefix == 'ansible_'
    assert cache.cache_connection == os.path.join(os.path.expanduser('~'), '.ansible/tmp/ansible-caching-files')

# Generated at 2022-06-25 08:30:15.793241
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert False

# Generated at 2022-06-25 08:30:17.926139
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create the object instance
    cm = CacheModule()

    # Check its class
    assert(cm.__class__.__name__ == 'CacheModule')

# Generated at 2022-06-25 08:30:19.933657
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert hasattr(module, 'get')
    assert hasattr(module, 'set')
    assert hasattr(module, 'del')

# Generated at 2022-06-25 08:32:29.084664
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Test class CacheModule.
    """
    # Import jsonfile plugin using __init__.py of ansible.plugins.cache
    import ansible.plugins.cache.jsonfile  # pylint: disable=import-error
    CACHEPLUGIN = ansible.plugins.cache.jsonfile.CacheModule("_uri")
    assert CACHEPLUGIN is not None
    assert CACHEPLUGIN.plugin_name == "jsonfile"
    assert CACHEPLUGIN.cache_prefix == ""
    assert CACHEPLUGIN.timeout == 86400
    assert CACHEPLUGIN.plugin_path == "_uri"

    # Instantiate CacheModule class
    CACHEPLUGIN = CacheModule("_uri")
    assert CACHEPLUGIN is not None
    assert CACHEPL

# Generated at 2022-06-25 08:32:29.766240
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert not hasattr(CacheModule, 'CacheModule')

# Generated at 2022-06-25 08:32:32.212097
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test default values
    cache = CacheModule("test_uri")
    assert cache.timeout == 86400

    # Test custom values
    cache = CacheModule("test_uri", timeout=10)
    assert cache.timeout == 10

# Generated at 2022-06-25 08:32:33.318036
# Unit test for constructor of class CacheModule
def test_CacheModule():
   plugin = CacheModule()
   assert plugin._load is not None
   assert plugin._dump is not None

# Generated at 2022-06-25 08:32:36.988155
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = 'tmp/'
    tests = [
        [False, True, 'tmp/'],
        [True, True, 'tmp/'],
        [False, False, 'tmp/'],
        [True, False, 'tmp/']
    ]
    for test in tests:
        prefix = test[0]
        cache = CacheModule(path, test[0], test[1])
        assert cache.get_basedir() == test[2]


# Generated at 2022-06-25 08:32:37.882463
# Unit test for constructor of class CacheModule
def test_CacheModule():
    con = CacheModule()
    assert con



# Generated at 2022-06-25 08:32:39.932523
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create an instance of class CacheModule
    cache = CacheModule()

    # If a class has a constructor, then an instance of that class will be created.
    # Therefore, the following assertion will be true.
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-25 08:32:42.539812
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    cm.get_cache_path  # make pyflakes happy
    cm.get_expiration_time  # make pyflakes happy
    cm.get_valid_content  # make pyflakes happy
    cm.load_from_file  # make pyflakes happy
    cm.save_to_file  # make pyflakes happy

# Generated at 2022-06-25 08:32:44.037595
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert(cache_module.config is None)
    assert(cache_module._connection is None)
    assert(cache_module._timeout == 86400)


# Generated at 2022-06-25 08:32:46.684335
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule() is not None