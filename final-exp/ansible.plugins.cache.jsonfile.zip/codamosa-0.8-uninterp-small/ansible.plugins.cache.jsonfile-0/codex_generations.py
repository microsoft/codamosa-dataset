

# Generated at 2022-06-25 08:25:46.928048
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = {"foo": "12345"}
    cache_module = CacheModule()
    cache_module.set("bar/baz", data)
    assert data == cache_module.get("bar/baz")


# Generated at 2022-06-25 08:25:48.176457
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_case_0()

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-25 08:25:57.382796
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import BaseFileCacheModule
    from copy import deepcopy
    from os.path import dirname
    
    try:
        import json
    except Exception as exception:
        raise ImportError(str(exception))
        
    try:
        from ansible.parsing.ajson import AnsibleJSONEncoder, AnsibleJSONDecoder
    except Exception as exception:
        raise ImportError(str(exception))
        
    try:
        from ansible.plugins.cache.jsonfile import CacheModule
    except Exception as exception:
        raise ImportError(str(exception))
        
    # Test the constructor of class BaseFileCacheModule

# Generated at 2022-06-25 08:26:04.285267
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Testing constructor with args
    cache_module_args = CacheModule(
        "dir",
        0,
        "filename"
    )
    if not hasattr(cache_module_args, '_connection'):
        raise AssertionError("Expected '_connection' to be defined as an attribute of cache_module_args, but is not defined")
    cache_module_args._connection = None
    if not hasattr(cache_module_args, '_timeout'):
        raise AssertionError("Expected '_timeout' to be defined as an attribute of cache_module_args, but is not defined")
    cache_module_args._timeout = None

# Generated at 2022-06-25 08:26:06.363486
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = {'test': 'test'}
    cache = CacheModule()
    cache.set('test', data)
    assert cache.get('test') == data
    cache.delobj('test')

# Generated at 2022-06-25 08:26:09.397335
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()
    # Check if obj is an instance of class CacheModule and BaseFileCacheModule.
    assert isinstance(cache_module_0, CacheModule) and isinstance(cache_module_0, BaseFileCacheModule), 'AnsiballZ runtime error'

# class BaseFileCacheModule

# Generated at 2022-06-25 08:26:11.653408
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None


# Generated at 2022-06-25 08:26:15.100236
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule(timeout=10)
    assert cache_module_1._timeout == 10


# Generated at 2022-06-25 08:26:25.987512
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()
    assert cache_module_0._load({'key': 'value'}) == {'key': 'value'}
    assert cache_module_0._load(None) is None
    assert cache_module_0._dump({'key': 'value'}, 'filepath_0') is None
    assert cache_module_0._dump(None, 'filepath_0') is None
    assert cache_module_0.set('key_0', 'value_0') is None
    assert cache_module_0.get('key_0') == 'value_0'
    assert cache_module_0.get('key_1') is None
    assert cache_module_0.keys() == ['key_0']
    assert cache_module_0.contains('key_1') is False
    assert cache_

# Generated at 2022-06-25 08:26:27.979928
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_test = CacheModule()
    assert cache_module_test._load('test') == None

# Generated at 2022-06-25 08:26:29.977727
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-25 08:26:34.632469
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get('test') == None
    assert cache_module.get('test', True) == True
    assert cache_module.set('test', True)
    assert cache_module.get('test') == True
    assert cache_module.get('test', True) == True
    cache_module.delete('test')
    assert cache_module.get('test') == None
    assert cache_module.get('test', True) == True
    assert cache_module.is_valid('test') == False
    assert cache_module.is_valid('test', True) == True
    assert cache_module.is_expired('test') == True
    assert cache_module.is_expired('test', False) == False

# Generated at 2022-06-25 08:26:35.195553
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-25 08:26:35.791026
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()

# Generated at 2022-06-25 08:26:38.631967
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()

    # Test default values
    assert cache_plugin.timeout == 86400 # 24 hours
    assert cache_plugin.connection == ''
    assert cache_plugin.get_timeout("localhost") == 86400 # 24 hours

# Generated at 2022-06-25 08:26:39.635815
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin

# Generated at 2022-06-25 08:26:41.781810
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._load == CacheModule._load
    assert module._dump == CacheModule._dump
    assert module.get_file_path('foo') == 'foo.cache'

# Generated at 2022-06-25 08:26:44.051311
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule.filecache != None
    assert cacheModule.plugin_name == 'jsonfile'

# Generated at 2022-06-25 08:26:44.541520
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module

# Generated at 2022-06-25 08:26:49.500834
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    Unit testing for the constructor of the class CacheModule.
    :return: Nothing
    '''

    test_settings = {'_uri': '.', '_prefix': 'testprefix', '_timeout': 100}
    test_cache_module = CacheModule(module_settings=test_settings)

    assert test_cache_module._uri == '.'
    assert test_cache_module._prefix == 'testprefix'
    assert test_cache_module._timeout == 100

# Generated at 2022-06-25 08:26:57.458567
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachemodule = CacheModule()
    assert cachemodule.type_is_cacheable('set') == True
    assert cachemodule.type_is_cacheable('dict') == True
    assert cachemodule.type_is_cacheable('str') == False
    assert cachemodule.type_is_cacheable('list') == False
    assert cachemodule.type_is_cacheable('bool') == False
    assert cachemodule.type_is_cacheable('int') == False

# Generated at 2022-06-25 08:26:58.666182
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule_constructor = CacheModule()
    assert(CacheModule_constructor)

# Generated at 2022-06-25 08:27:02.116534
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """ Test all class methods """

    assert CacheModule

# Generated at 2022-06-25 08:27:06.904146
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with open('test_CacheModule.json', 'r') as f:
        data = json.load(f)
    cache_plugin = CacheModule()
    cache_plugin._dump(data, 'test_CacheModule.json')
    assert cache_plugin._load('test_CacheModule.json') == data

# Generated at 2022-06-25 08:27:10.255609
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection, prefix, timeout = 'test.json', 'ansible', 1000
    obj = CacheModule(connection, prefix, timeout)
    assert obj._path == connection
    assert obj._orig_prefix == prefix
    assert obj._timeout == 1000

# Generated at 2022-06-25 08:27:15.873881
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    cache = CacheModule(None, None)
    assert cache
    cache = CacheModule(None, 'test_connection')
    assert cache
    connection = cache._connection
    assert connection

    # Constructor of class CacheModule sets self._connection
    # as an absolute path to test_connection.
    assert os.path.isabs(connection)

    # We can create the connection if it does NOT exist.
    if os.path.exists(connection):
        shutil.rmtree(connection)
    assert not os.path.exists(connection)
    cache.get('test_get')
    assert os.path.exists(connection)
    shutil.rmtree(connection)

# Generated at 2022-06-25 08:27:17.693079
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule({'_uri': "/tmp/ansible_test_cache"})
    assert isinstance(cache_plugin, CacheModule)

# Generated at 2022-06-25 08:27:19.238618
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.file_extension == '.json'
    assert c.default_timeout == 86400

# Generated at 2022-06-25 08:27:20.562338
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c=CacheModule()
    assert c.plugin_name == 'jsonfile'

# Generated at 2022-06-25 08:27:22.716804
# Unit test for constructor of class CacheModule
def test_CacheModule():
  assert isinstance(CacheModule(dict()), BaseFileCacheModule)

# Generated at 2022-06-25 08:27:33.170252
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    return cache_module != None

# Generated at 2022-06-25 08:27:35.642200
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create a new object of class CacheModule
    cache_module = CacheModule()

    # Check the timeout value of object
    assert cache_module.timeout == 86400

# Generated at 2022-06-25 08:27:39.726192
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.get_timeout() == 86400

    cm = CacheModule({'_timeout': 900})
    assert cm.get_timeout() == 900

    cm = CacheModule({})
    assert cm.get_timeout() == 86400



# Generated at 2022-06-25 08:27:42.513413
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = '{"answer": 42, "foo": "bar"}'
    cache = CacheModule()
    assert data == cache._dump(cache._load(data), '')

# Generated at 2022-06-25 08:27:43.747615
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule(None)
    assert cache_plugin

# Generated at 2022-06-25 08:27:44.968976
# Unit test for constructor of class CacheModule
def test_CacheModule():
    #import pudb; pudb.set_trace()
    cm = CacheModule()

# Generated at 2022-06-25 08:27:47.798743
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filepath = "test.json"
    value = {"list": [1, 2, 3], "string": "ansible"}
    instance = CacheModule()
    instance._dump(value, filepath)
    assert value == instance._load(filepath)

# Generated at 2022-06-25 08:27:49.950199
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule(dict(connection='/a/path'))
    assert c.plugin_name == 'jsonfile'
    assert c._connection == '/a/path'

# Generated at 2022-06-25 08:27:51.156611
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert type(cm) == CacheModule

# Generated at 2022-06-25 08:27:53.258932
# Unit test for constructor of class CacheModule
def test_CacheModule():
	cm = CacheModule()
	assert isinstance(cm, CacheModule)

# Generated at 2022-06-25 08:28:05.707489
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)

# Generated at 2022-06-25 08:28:06.565269
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, '_load')
    assert hasattr(CacheModule, '_dump')

# Generated at 2022-06-25 08:28:08.269903
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    A test method for the constructor of CacheModule class.
    """
    assert CacheModule(task=None)


# Generated at 2022-06-25 08:28:08.753849
# Unit test for constructor of class CacheModule
def test_CacheModule():
    t = CacheModule()

# Generated at 2022-06-25 08:28:09.550669
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-25 08:28:11.874152
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    from ansible.plugins.cache.base import BaseFileCacheModule

    m = CacheModule()
    assert isinstance(m, BaseFileCacheModule)

# Generated at 2022-06-25 08:28:15.102786
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = "/tmp/ansible_cache_dir_test"
    timeout = 86400
    per_host = True
    cache = CacheModule(cache_dir, timeout, per_host)
    assert(cache.cache_dir == cache_dir)
    assert(cache.timeout == timeout)
    assert(cache.per_host == per_host)

# Generated at 2022-06-25 08:28:15.923818
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict()) is not None

# Generated at 2022-06-25 08:28:17.026266
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module

# Generated at 2022-06-25 08:28:18.687018
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c

# Generated at 2022-06-25 08:28:44.815377
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-25 08:28:47.116934
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.Config == dict(
        _uri='~/.ansible/tmp',
        _prefix='ansible-solr',
        _timeout=86400,
    )

# Generated at 2022-06-25 08:28:51.873848
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

    # Assert that the configuration is what we expect.
    assert c.config == {'_prefix': 'ansible_facts', '_timeout': 86400, '_uri': '~/.ansible/cachedir'}

    # Assert thay the plugin has the right paths.
    assert c.cache_fn == 'ansible_facts.cache'
    assert c.lock_path == 'ansible_facts.cache.lock'

# Unit tests for the load method of class CacheModule

# Generated at 2022-06-25 08:28:55.234127
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._load is not None
    assert plugin._dump is not None
    assert plugin._prefix is None
    assert plugin._timeout == 86400

# Generated at 2022-06-25 08:28:56.859621
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule(dict())

# Generated at 2022-06-25 08:29:01.888233
# Unit test for constructor of class CacheModule
def test_CacheModule():
    fact_caching_connection = 'tmp/unittest_fact_caching_connection'

    cache_module = CacheModule({
        'fact_caching_connection': fact_caching_connection,
    })
    cache_module.flush()

    value = {'some': 'key'}
    cache_module.set(value)

    saved_value = cache_module.get()

    assert saved_value == value

# Generated at 2022-06-25 08:29:05.438237
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    cache_location = tempfile.gettempdir()

    cache_plugin = CacheModule({'_uri': cache_location})
    assert cache_plugin._cache_dir == cache_location
    assert cache_plugin._prefix == 'ansible_cache_'

# Generated at 2022-06-25 08:29:08.414531
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = "./"
    prefix = "test"
    timeout = 5000

    actual = CacheModule(path, prefix, timeout)

    assert not actual.cache_needs_flush(path, prefix, timeout)

# Generated at 2022-06-25 08:29:09.398426
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-25 08:29:10.791425
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_obj = CacheModule()
    assert isinstance(test_obj, CacheModule)


# Generated at 2022-06-25 08:30:12.585054
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    keys = ['_uri', '_prefix', '_timeout']
    for key in keys:
        assert key in cache_module
    assert cache_module._timeout == 86400

# Generated at 2022-06-25 08:30:14.413974
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert isinstance(cacheModule, CacheModule)

# Generated at 2022-06-25 08:30:18.461607
# Unit test for constructor of class CacheModule
def test_CacheModule():
    acm = CacheModule(None)
    # Tests for the attributes of the class
    assert acm is not None
    assert acm.timeout == 86400
    assert acm.prefix == 'ansible_cache_'
    assert acm._conn is not None
    assert acm.cache_file_name('test') == 'ansible_cache_test'

# Generated at 2022-06-25 08:30:23.199020
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()

    assert cache_plugin._connection == '~/.ansible/tmp/ansible-local/'
    assert cache_plugin._prefix == 'ansible_facts_'
    assert cache_plugin._timeout == 86400

    cache_plugin = CacheModule({'_uri': '/tmp/testing/'})

    assert cache_plugin._connection == '/tmp/testing'
    assert cache_plugin._prefix == 'ansible_facts_'
    assert cache_plugin._timeout == 86400

# Generated at 2022-06-25 08:30:23.613154
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-25 08:30:24.913451
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    cache = CacheModule()
    assert cache.get_timeout() == 86400

# Generated at 2022-06-25 08:30:30.274402
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() is None
    assert cache.get_prefix() is None
    #assert cache.get_cache_plugin_name() == 'jsonfile'

# Generated at 2022-06-25 08:30:31.201031
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert x

# Generated at 2022-06-25 08:30:32.341753
# Unit test for constructor of class CacheModule
def test_CacheModule():
    temp_path = "tmp"
    cache = CacheModule(temp_path)

# Generated at 2022-06-25 08:30:32.830518
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-25 08:32:41.545490
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    res = isinstance(cache, CacheModule)
    assert(res == True)

# Generated at 2022-06-25 08:32:42.902067
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    Unit test for constructor of class CacheModule
    '''
    cache = CacheModule()

    assert cache is not None
    assert cache is not False
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-25 08:32:43.280679
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-25 08:32:46.641269
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    # In ctor, we set the properties, but we'll need
    # to set them as a test since we don't have a callback context
    cache.set_options({'timeout': 3600,
                       'plugin_name': 'jsonfile',
                       '_prefix': 'ansible_facts',
                       '_uri': '/tmp/ansible_cache'})
    cache.get_cache_path()
    cache.get('a')
    cache.set('a', 'b')
    cache.keys()

# Generated at 2022-06-25 08:32:48.143674
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule('/var/lib/awx/fact_caching', 'no_prefix', 3600)

# Generated at 2022-06-25 08:32:51.119459
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = '~/some/path'

    bcm = CacheModule()
    bcm.set_options({'_uri': path})
    uri = bcm.get_options()
    assert uri.get('_uri') == path

# Generated at 2022-06-25 08:32:52.589101
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Calling constructor of class CacheModule without any parameter to generate instance
    obj = CacheModule()
    # To check if instance generated successfully
    assert obj is not None

# Generated at 2022-06-25 08:32:56.593524
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create object of class CacheModule and test the object is created or not
    cache = CacheModule()



# Generated at 2022-06-25 08:33:00.001193
# Unit test for constructor of class CacheModule
def test_CacheModule():
    f = open("~/.ansible_cache/fact_cache.json", 'r')
    cache = CacheModule()
    cache.set("ansible", "engine", "yes")
    assert cache.get("ansible", "engine") == "yes"

# Generated at 2022-06-25 08:33:01.897106
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test constructor
    c = CacheModule()