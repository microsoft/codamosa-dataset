

# Generated at 2022-06-25 08:25:45.326890
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test if initial value of _plugin_options is correct
    cache_module_0 = CacheModule()
    cache_module_0._plugin_options = {'_prefix': '', '_timeout': 86400, '_uri': ''}


# Generated at 2022-06-25 08:25:46.137631
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

# Generated at 2022-06-25 08:25:46.893628
# Unit test for constructor of class CacheModule
def test_CacheModule():
  cache_module_0 = CacheModule()

# Generated at 2022-06-25 08:25:47.641449
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()


# Generated at 2022-06-25 08:25:54.923093
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()

    assert cache_module_0.get_option('_uri') == '~/.ansible/tmp/ansible-fact-cache'
    assert cache_module_0.get_option('_prefix') == 'ansible_facts'
    assert cache_module_0.get_option('_timeout') == 86400

# Generated at 2022-06-25 08:25:55.618885
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()



# Generated at 2022-06-25 08:26:00.460873
# Unit test for constructor of class CacheModule
def test_CacheModule():
    src_file_path = "/etc/ansible/facts"
    prefix = "ansible_facts."
    timeout = 3600
    cache_module_0 = CacheModule()
    for x in range(0,2):
        cache_module_0.set(src_file_path, prefix, timeout)
        for y in range(0,2):
            cache_module_0.get(src_file_path, prefix, timeout)
        for y in range(0,2):
            cache_module_0.has_expired(src_file_path, prefix, timeout)
        cache_module_0.delete(src_file_path, prefix, timeout)

# Generated at 2022-06-25 08:26:01.814605
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        cache_module_1 = CacheModule()
    except NameError:
        assert False
    assert True


# Generated at 2022-06-25 08:26:07.053118
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.module_utils.six import PY3

    cache_module_1 = CacheModule()

    assert cache_module_1._plugin_name == 'jsonfile'
    assert cache_module_1._connection == None
    assert cache_module_1._timeout == 86400
    assert cache_module_1._prefix == None

    if PY3 is False:
        assert isinstance(cache_module_1._template, str)
    else:
        assert isinstance(cache_module_1._template, bytes)

# Generated at 2022-06-25 08:26:09.509868
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.timeout == 86400
    assert cache_module.prefix == ""
    assert cache_module.cache_plugin == 'jsonfile'
    assert cache_module._connection == '_ansible_cache'


# Generated at 2022-06-25 08:26:13.875541
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()


# Generated at 2022-06-25 08:26:21.306874
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Initialize module
    cache_module_0 = CacheModule()

    # Check if initialization is expected
    assert cache_module_0.default_timeout == 86400

    # Check if initialization is expected
    assert cache_module_0.timeout == 86400

    # Check if initialization is expected
    assert cache_module_0.plugin_name == 'jsonfile'

    # Check if initialization is expected
    assert cache_module_0.prefix == 'ansible-factcache'

    # Check if initialization is expected
    assert cache_module_0.expires == -1.0


# Generated at 2022-06-25 08:26:23.610923
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-25 08:26:24.586924
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert test_case_0() == None

# Generated at 2022-06-25 08:26:28.446310
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._load.__doc__ == '''
        this function is used to load the data from the cache plugin.
        '''
    assert CacheModule._dump.__doc__ == '''
        this function is used to dump the data to the cache plugin.
        '''

# Generated at 2022-06-25 08:26:32.897551
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()
    assert cache_module_0.data == {}
    assert cache_module_0.get_timeout() == 86400
    assert cache_module_0.get_connection() == ''
    assert cache_module_0.get_prefix() == ''


# Generated at 2022-06-25 08:26:33.860896
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule() is not None


# Generated at 2022-06-25 08:26:37.282628
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, '_load')
    assert callable(getattr(CacheModule, '_load', None))
    assert hasattr(CacheModule, '_dump')
    assert callable(getattr(CacheModule, '_dump', None))



# Generated at 2022-06-25 08:26:39.666399
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Instanciate class
    cache_module_1 = CacheModule()

    # Check if class is correctly instanciated
    assert(isinstance(cache_module_1, CacheModule))


# Generated at 2022-06-25 08:26:42.337899
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with pytest.raises(Exception) as error:
        CacheModule()
    assert str(error.value) == "TypeError: 'NoneType' object is not iterable"


# Generated at 2022-06-25 08:26:48.762176
# Unit test for constructor of class CacheModule
def test_CacheModule():

  module = CacheModule(None)
  assert module.validate_filepath('/tmp/test.json') == True
  assert module.validate_filepath('/tmp/test.xyz') == False

# Generated at 2022-06-25 08:26:55.156044
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with empty _connection.
    module = CacheModule()

    assert module is not None

    # Test with bad _connection.
    connection = 'some value that is not a dictionary'
    module = CacheModule(connection = connection)

    assert module is not None

    # Test with valid _connection.
    connection = { '_uri' : 'some value' }
    module = CacheModule(connection = connection)

    assert module is not None

# Generated at 2022-06-25 08:26:59.477640
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'CACHE_PLUGIN_CONNECTION': '/tmp',
                         'CACHE_PLUGIN_PREFIX': 'localhost.localdomain',
                         'CACHE_PLUGIN_TIMEOUT': '0'})
    text = cache.get('test_key')
    assert text is None

# Generated at 2022-06-25 08:27:02.614082
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj.file_extension == ".json"

# Generated at 2022-06-25 08:27:06.172442
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.name == 'jsonfile'
    assert c.hash_algo == 'sha1'
    assert c.default_timeout == '86400'
    assert c.default_prefix == ''

# Generated at 2022-06-25 08:27:10.317926
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.cache_type == 'jsonfile'
    cache_plugin.put('test', data=dict(k1=3, k2=4))
    res = cache_plugin.get('test')
    assert res['data']['k1'] == 3

# Generated at 2022-06-25 08:27:11.758923
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # call function and test result
    tc = CacheModule()
    assert isinstance(tc, CacheModule)

# Generated at 2022-06-25 08:27:16.065434
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = 'database://mysql'
    prefix = 'cache'
    timeout = '86400'
    path = '/'
    cm = CacheModule(connection, path, prefix, timeout)
    assert cm.connection == 'database://mysql'
    assert cm.prefix == 'cache'
    assert cm.path == '/'
    assert cm.timeout == '86400'

# Generated at 2022-06-25 08:27:21.036122
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # without parameters
    cm = CacheModule()
    assert isinstance(cm, CacheModule)
    assert cm.connection is None
    assert cm.is_valid() is False
    # with parameter
    test_param = {'_uri': '/tmp/', '_prefix': 'test_', '_timeout': 3600}
    cm = CacheModule(**test_param)
    assert cm.connection == '/tmp/'
    assert cm.prefix == 'test_'
    assert cm.timeout == 3600
    assert cm.is_valid()

# Generated at 2022-06-25 08:27:22.219852
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'file:///var/tmp/ansible-caching'})

# Generated at 2022-06-25 08:27:33.103786
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._load is None
    assert module._dump is None

# Generated at 2022-06-25 08:27:37.494909
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import shutil

    testdir = os.path.dirname(os.path.abspath(__file__))
    factdir = os.path.join(testdir, 'cachedir')

    try:
        shutil.rmtree(factdir)
    except OSError:
        pass

    conn = CacheModule({'_uri': factdir})

    c = conn.get_conn()
    assert c == dict()

    conn.set_conn({"answer": 42})
    conn.flush()

    c = conn.get_conn()
    assert c == {"answer": 42}

# Generated at 2022-06-25 08:27:38.733503
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin

# Generated at 2022-06-25 08:27:40.335842
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('/tmp')
    assert cache != None
    assert cache.plugin_name == 'jsonfile'

# Generated at 2022-06-25 08:27:42.729544
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._prefix == 'ansible-cache'
    assert cache_module._timeout == 86400

# Generated at 2022-06-25 08:27:44.629538
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.get('somekey') == {}
    assert cm.set('somekey', {'key': 'value'}) == True

# Generated at 2022-06-25 08:27:46.112891
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        cm = CacheModule()
    except Exception:
        print("Failed to create CacheModule Object")
        raise
    else:
        print("Created CacheModule Object successfully")

# Generated at 2022-06-25 08:27:48.271701
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() is None
    assert cache.get_prefix() is None



# Generated at 2022-06-25 08:27:50.459917
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(plugin=None)
    assert cache._plugin == None
    assert cache._cache == {}
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible_facts'

# Generated at 2022-06-25 08:27:55.212112
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_dir = './testdir'
    test_timeout = 7200

    test_cache_plugin = CacheModule({'_uri': test_dir, '_timeout': test_timeout})

    assert test_cache_plugin.uri == test_dir
    assert test_cache_plugin.timeout == test_timeout

# Generated at 2022-06-25 08:28:10.768997
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Load/save only accept one argument
    # call to constructor
    test_cacheModule = CacheModule(None)
    json_load = test_cacheModule.load({})
    assert json_load == {}
    json_dump = test_cacheModule.dump({})
    assert json_dump == {}

# Generated at 2022-06-25 08:28:14.460018
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os, tempfile
    dirpath = tempfile.mkdtemp()
    os.rmdir(dirpath)
    cachedir = dirpath + "/cachedir"
    cache = CacheModule(cachedir)
    assert cache._connection == cachedir
    assert cache._prefix is None

# Generated at 2022-06-25 08:28:17.409410
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(task_vars=dict())
    assert cache_module._connection == cache_module.get_option('_connection')
    assert cache_module._prefix == cache_module.get_option('_prefix')
    assert cache_module._timeout == cache_module.get_option('_timeout')


# Generated at 2022-06-25 08:28:19.901323
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load

# Generated at 2022-06-25 08:28:26.690162
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Instantiate with uri = tempfile.tempdir
    # and timeout = 10
    # and prefix = 'ansible'
    c = CacheModule(timeout=10, uri=tempfile.tempdir, prefix='ansible')
    # _cache_dir should be path.join(tempfile.tempdir, 'ansible')
    assert c._cache_dir == path.join(tempfile.tempdir, 'ansible')
    # _timeout should be 10
    assert c._timeout == 10
    # _prefix should be 'ansible'
    assert c._prefix == 'ansible'

# Generated at 2022-06-25 08:28:30.680103
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Creating an instance of class CacheModule
    cm = CacheModule()

    # Testing the __init__() method
    assert isinstance(cm, BaseFileCacheModule),"CacheModule must be instance of BaseFileCacheModule"

# Generated at 2022-06-25 08:28:36.793321
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.__class__ == CacheModule # check instance type
    assert cache_module._connection_name == 'jsonfile'    
    assert cache_module._connection_info == {}
    assert cache_module._timeout == 86400
    assert cache_module._prefix == ''
    assert cache_module._cache == {}
    assert cache_module._cache_dir == cache_module._connection_info
    assert cache_module._fact_names == False

# Generated at 2022-06-25 08:28:40.672184
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_prefix() == ""


# Generated at 2022-06-25 08:28:41.929070
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-25 08:28:42.878365
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()._timeout == 86400

# Generated at 2022-06-25 08:29:12.194630
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, '_load')
    assert hasattr(CacheModule, '_dump')
    assert hasattr(CacheModule, 'get')
    assert hasattr(CacheModule, 'set')
    assert hasattr(CacheModule, 'keys')
    assert hasattr(CacheModule, 'contains')
    assert hasattr(CacheModule, 'delete')
    assert hasattr(CacheModule, 'flush')

# Generated at 2022-06-25 08:29:13.316537
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache = CacheModule()
    assert cache.is_valid()

# Generated at 2022-06-25 08:29:20.429287
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import shutil
    import tempfile

    # Load config file
    config = {}

    # Define cache dir
    config['_uri'] = os.path.join(tempfile.gettempdir(), 'jsonfile_test_cache')

    # Cleanup cache dir
    if os.path.exists(config['_uri']):
        shutil.rmtree(config['_uri'])

    cache_class = CacheModule(config)

    # Test a key in the cache object
    data = cache_class.get_cache_value('get_fail')
    assert data is None, "Cache test: Got unexpected data from the cache"

    # Test that a get failure does not write to the cache
    cache_class.set_cache_value('get_fail', 'This will fail')
    data = cache_class.get

# Generated at 2022-06-25 08:29:26.015574
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()

    assert(module.root == '~/.ansible/cache/')
    assert(module.timeout == 86400)
    assert(module.plugin_name == 'jsonfile')

    test_plugin_name = 'test_plugin'
    test_plugin_timeout = 123
    test_plugin_root = 'test_plugin_root'

    module = CacheModule(test_plugin_name, test_plugin_timeout, test_plugin_root)

    assert(module.root == test_plugin_root)
    assert(module.timeout == test_plugin_timeout)
    assert(module.plugin_name == test_plugin_name)


# Generated at 2022-06-25 08:29:27.755310
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule({}, 'localhost')
    assert c.cachedir == 'localhost'

# Generated at 2022-06-25 08:29:28.565572
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m is not None

# Generated at 2022-06-25 08:29:35.893994
# Unit test for constructor of class CacheModule
def test_CacheModule():
    if __name__ != '__main__':
        # Skip when imported.
        return None

    import sys
    import os.path
    import tempfile
    import shutil
    import unittest

    # Define the basic class.
    class TestCacheModule(unittest.TestCase):
        def setUp(self):
            # Create a temporary directory and instantiate the plugin.
            self.tmpdir = tempfile.mkdtemp()
            self.plugin = CacheModule({
                '_prefix': '',
                '_uri': self.tmpdir,
            })
            assert self.plugin._dirpath == self.tmpdir

        def tearDown(self):
            # Delete the temporary directory.
            shutil.rmtree(self.tmpdir)

    # Create a test suite, add the unit test and run it.
   

# Generated at 2022-06-25 08:29:41.476497
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with open("test.json", 'w') as f1:
        f1.write("""{
            "_ansible_parsed": true
        }""")
    cacheobj = CacheModule("test.json")
    data = cacheobj._load("test.json")
    assert data == {"_ansible_parsed": True}

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-25 08:29:43.251894
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load is not None
    assert cache._dump is not None

# Generated at 2022-06-25 08:29:48.009372
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = "'connection': 'test/'"
    prefix = "'prefix': 'test_prefix/'"
    timeout = "'timeout': '60'"
    testConfig = '{"plugin": "test_plugin", "plugin_args": {' + connection + ', ' + prefix + ', ' + timeout + '}}'
    config = json.loads(testConfig)
    cache_module = CacheModule(config)
    assert cache_module._connection == 'test/'
    assert cache_module._prefix == 'test_prefix/'
    assert cache_module._timeout == 60

# Generated at 2022-06-25 08:30:51.975797
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-25 08:30:56.672636
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Creating a CacheModule object with some arguments
    plugin = CacheModule({"_uri": "/my/dir"})
    # Now we can test the name and value of the CacheModule
    assert plugin.name == 'jsonfile'
    assert plugin.config == {"_uri": "/my/dir"}

# Generated at 2022-06-25 08:30:58.301162
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj

# Generated at 2022-06-25 08:31:02.450441
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._load == module.load
    assert module._dump == module.dump



# Generated at 2022-06-25 08:31:07.387710
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''Tests the constructor of the class CacheModule'''
    obj = CacheModule(task=None)
    assert obj != None
    assert obj._timeout != None

# Generated at 2022-06-25 08:31:08.227698
# Unit test for constructor of class CacheModule
def test_CacheModule():
 cache_module = CacheModule()

# Generated at 2022-06-25 08:31:10.110125
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert isinstance(x._load, object)
    assert isinstance(x._dump, object)

# Generated at 2022-06-25 08:31:12.263768
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)

# Generated at 2022-06-25 08:31:16.911795
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    # verify _default_prefix
    assert cache_module._prefix == "ansible_facts"

# Generated at 2022-06-25 08:31:20.117721
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile

    # Create the temporary directory
    test_dir = tempfile.mkdtemp()

    # Create an instance of the class CacheModule
    cache = CacheModule({'_uri': test_dir})

    # Check if the directory is used
    assert cache._cache._directory == test_dir

    # Cleanup temporary directory
    os.rmdir(test_dir)

# Generated at 2022-06-25 08:33:39.076809
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), BaseFileCacheModule)

# Generated at 2022-06-25 08:33:47.133502
# Unit test for constructor of class CacheModule
def test_CacheModule():
    params = {'_uri': 'test_dir'}
    cache_module = CacheModule(params)
    assert cache_module._uri == 'test_dir'
    assert cache_module._prefix == 'ansible_facts'
    assert cache_module._timeout == 86400
    assert cache_module._validate_time == False

    params = {'_uri': 'test_dir', '_prefix': 'test_prefix', '_timeout': 12345}
    cache_module = CacheModule(params)
    assert cache_module._uri == 'test_dir'
    assert cache_module._prefix == 'test_prefix'
    assert cache_module._timeout == 12345
    assert cache_module._validate_time == False

# Generated at 2022-06-25 08:33:48.906939
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.get_cache_timeout() == 86400
    assert c.get_prefix() == ''
    assert c._cache_dir is None

# Generated at 2022-06-25 08:33:51.837906
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = 'test-dir'
    prefix = 'facts'
    timeout = 86400
    cache = CacheModule(uri, prefix, timeout)
    assert hasattr(cache, 'get')
    assert hasattr(cache, 'set')
    assert hasattr(cache, 'is_valid')
    assert hasattr(cache, 'invalidate')

# Generated at 2022-06-25 08:33:57.315662
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        cm = CacheModule()
    except NameError:
        pass

# Generated at 2022-06-25 08:34:00.137181
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test constructor of Class CacheModule
    test_CacheModule = CacheModule(None)
    # Check for existence of method _load
    assert hasattr(test_CacheModule, '_load')
    # Check for existence of method _dump
    assert hasattr(test_CacheModule, '_dump')

# Generated at 2022-06-25 08:34:01.160406
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'dummy'})

# Generated at 2022-06-25 08:34:11.314062
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # setup
    from ansible.plugins.cache import BaseFileCacheModule

    class TestCacheModule(BaseFileCacheModule):
        pass

    with TestCacheModule.construct("test", "ansible", "facts", "cache/fact_caching/") as test_cache:
        # check if attributes were added
        assert test_cache.name is not None
        assert test_cache.name == "test"

        # check if base class's attributes were added
        assert test_cache.user is not None
        assert test_cache.user == "ansible"
        assert test_cache.plugin_type is not None
        assert test_cache.plugin_type == "facts"
        assert test_cache.connection is not None
        assert test_cache.connection == "cache/fact_caching/"

# Generated at 2022-06-25 08:34:15.201453
# Unit test for constructor of class CacheModule
def test_CacheModule():
    dummy = {}
    dummy['plugin_name'] = 'jsonfile'
    dummy['plugin_args'] = {'_prefix': 'foo_', '_uri': '/tmp/foo'}
    cache = CacheModule(dummy, {}, {}, {})
    assert cache._prefix == 'foo_'
    assert cache._uri == '/tmp/foo'

# Generated at 2022-06-25 08:34:15.716012
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()