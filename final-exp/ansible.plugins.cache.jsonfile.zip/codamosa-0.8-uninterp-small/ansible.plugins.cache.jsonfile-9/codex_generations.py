

# Generated at 2022-06-25 08:25:43.124407
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Set up the object
    cache_module_1 = CacheModule()

    # Test the additions/modifications to __init__



# Generated at 2022-06-25 08:25:44.865837
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert isinstance(cache_module, CacheModule)


# Generated at 2022-06-25 08:25:46.859428
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import CacheModule
    cache_module_0 = CacheModule()
    assert(isinstance(cache_module_0, CacheModule))


# Generated at 2022-06-25 08:25:47.879379
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None


# Generated at 2022-06-25 08:25:52.329278
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

# Generated at 2022-06-25 08:25:54.178162
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()
    assert isinstance(cache_module_0, CacheModule)
#

# Generated at 2022-06-25 08:26:00.234878
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import pytest
    # Test an exception is raised when the _uri is not set.
    test_CacheModule_args = {
            '_uri' : ''
    }
    with pytest.raises(AnsibleCacheError) as excinfo:
        CacheModule(**test_CacheModule_args)
    assert excinfo.value.error_key == 'CACHE_PLUGIN_MISSING_REQUIRED_PARAMETERS'
    assert '_uri' in excinfo.value.error_data
    assert '_uri' in CacheModule._required_variables
    # Test an exception is raised when the _timeout is less than zero.
    test_CacheModule_args = {
            '_uri' : '',
            '_timeout' : -1
    }

# Generated at 2022-06-25 08:26:01.474942
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()._prefix == 'ansible-factcache'
    assert CacheModule()._timeout == 86400


# Generated at 2022-06-25 08:26:02.458719
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()

    assert isinstance(cache_module_1, CacheModule)


# Generated at 2022-06-25 08:26:09.465274
# Unit test for constructor of class CacheModule
def test_CacheModule():
    def test_case_0():
        cache_module_0 = CacheModule()
        assert 1 == 1
    def test_case_1():
        cache_module_0 = CacheModule()
        assert 1 == 1
    def test_case_2():
        cache_module_0 = CacheModule()
        assert 1 == 1
    def test_case_3():
        cache_module_0 = CacheModule()
        assert 1 == 1
    def test_case_4():
        cache_module_0 = CacheModule()
        assert 1 == 1
    def test_case_5():
        cache_module_0 = CacheModule()
        assert 1 == 1
    def test_case_6():
        cache_module_0 = CacheModule()
        assert 1 == 1
    def test_case_7():
        cache_module_0 = Cache

# Generated at 2022-06-25 08:26:15.810294
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_obj = CacheModule()
    assert isinstance(cache_obj, BaseFileCacheModule), "not an instance"
#
# END OF UNIT TEST
#
test_case_0()
test_CacheModule()

# Generated at 2022-06-25 08:26:20.138105
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.set('localhost', 'name', {'name':'kyaw'}) == True
    assert cache_module.get('localhost', 'name') == {'name': 'kyaw'}
    assert cache_module.get('localhost', 'age') == None

# Generated at 2022-06-25 08:26:23.460437
# Unit test for constructor of class CacheModule
def test_CacheModule():
	# Create instance of class CacheModule
	cache_module_0 = CacheModule()
	assert isinstance(cache_module_0, CacheModule)


# Generated at 2022-06-25 08:26:32.753247
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

    # This is a good test, as it would generate an exception if the "filename" key did not exist
    # as the key is a required key
    filename_key = "filename" in cache_module.cache_opts

    # Tests the following
    # 1. Check that the "filename" key exists
    # 2. Check the type of the value of the key "filename" to be a string
    # 3. Check the type of the value of the key "content" to be a dict
    assert filename_key is True and isinstance(cache_module.cache_opts["filename"], str) and isinstance(cache_module.cache_opts["content"], dict)


# Generated at 2022-06-25 08:26:33.678198
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()


# Generated at 2022-06-25 08:26:36.448992
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()
    # assert statement
    assert isinstance(cache_module_1,BaseFileCacheModule), "cache_module_1 is not instance of BaseFileCacheModule class"


# Generated at 2022-06-25 08:26:37.963617
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()
    assert cache_module_1


# Generated at 2022-06-25 08:26:39.395981
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert(isinstance(cache_module, CacheModule))


# Generated at 2022-06-25 08:26:42.103543
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()
    assert isinstance(cache_module_1, CacheModule)
    assert isinstance(cache_module_1, BaseFileCacheModule)


# Generated at 2022-06-25 08:26:42.796716
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_case_0()

# Generated at 2022-06-25 08:26:53.405369
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()
    assert cache_module_1._timeout == 86400, "Default timeout should be 86400 (24 hours)"
    assert cache_module_1._prefix == "ansible_facts", "Default prefix should be ansible_facts"


# Generated at 2022-06-25 08:26:54.816557
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_obj = CacheModule()
    assert cache_module_obj != None


# Generated at 2022-06-25 08:26:59.082594
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._connection == '', \
        'Constructor is not working as expected'
    assert cache_module._timeout == 86400, \
        'Constructor is not working as expected'
    assert cache_module._prefix == '', \
        'Constructor is not working as expected'


# Generated at 2022-06-25 08:27:02.614080
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(isinstance(CacheModule(), CacheModule)), "Cannot create an instance"

# Generated at 2022-06-25 08:27:06.129317
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._timeout == 86400
    assert cache_module._connection == "ansible_facts"
    assert cache_module._prefix == "ansible_facts"

# Generated at 2022-06-25 08:27:07.596147
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert len(CacheModule.__doc__) > 1


# Generated at 2022-06-25 08:27:09.210032
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()


# Generated at 2022-06-25 08:27:11.638168
# Unit test for constructor of class CacheModule
def test_CacheModule():

    module = CacheModule()

    assert module._timeout == 86400
    assert module.timeout == 86400

    module.timeout = 5

    assert module._timeout == 5
    assert module.timeout == 5


# Generated at 2022-06-25 08:27:14.027496
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()
    assert cache_module_0._load('') == {}
    assert cache_module_0._dump(filepath='', value='') == None

# Generated at 2022-06-25 08:27:14.973160
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()

# Generated at 2022-06-25 08:27:37.586997
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with pytest.raises(TypeError):
        cache_module_1 = CacheModule(42)
    assert not hasattr(cache_module_1, "uri")
    assert not hasattr(cache_module_1, "_timeout")
    assert not hasattr(cache_module_1, "_prefix")

    #test if default values are set
    cache_module_2 = CacheModule()
    assert cache_module_2.uri == "/tmp/ansible_fact_cache"
    assert cache_module_2._timeout == 86400
    assert cache_module_2._prefix == ""

# Generated at 2022-06-25 08:27:40.867856
# Unit test for constructor of class CacheModule

# Generated at 2022-06-25 08:27:41.866392
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__doc__

# Generated at 2022-06-25 08:27:43.206014
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()


# Generated at 2022-06-25 08:27:44.082269
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

# Generated at 2022-06-25 08:27:45.639599
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_0 = CacheModule()
    assert cache_module_0._prefix == 'ansible_facts_'

# Generated at 2022-06-25 08:27:47.481890
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonfile_cache_module = CacheModule()
    assert isinstance(jsonfile_cache_module, CacheModule)


# Generated at 2022-06-25 08:27:49.259139
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_1 = CacheModule()
    assert(isinstance(cache_module_1, CacheModule))


# Generated at 2022-06-25 08:27:50.154497
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()


# Generated at 2022-06-25 08:27:52.409882
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    CacheModule():

    Constructor of class CacheModule
    """
    cache_module = CacheModule()

# Generated at 2022-06-25 08:28:05.403532
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-25 08:28:06.501202
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule


# Generated at 2022-06-25 08:28:06.872559
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-25 08:28:08.714167
# Unit test for constructor of class CacheModule
def test_CacheModule():
    a = CacheModule()
    assert a is not None
    assert issubclass(CacheModule, BaseFileCacheModule)


# Generated at 2022-06-25 08:28:10.608347
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        cm = CacheModule()
        res = cm.name()
    except Exception as e:
        res = False
    assert res == 'jsonfile'

# Generated at 2022-06-25 08:28:11.527614
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache_module = CacheModule()

# Generated at 2022-06-25 08:28:13.653904
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp') == None
    # assert cache_module._dump(AnsibleJSONEncoder, AnsibleJSONDecoder, '/tmp') == None

# Generated at 2022-06-25 08:28:16.758306
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule("/tmp")
    
    assert cacheModule._connection == '/tmp'
    assert cacheModule._timeout == 86400
    assert cacheModule._prefix == 'ansible-fact'
    assert cacheModule._valid_extensions == ('.cache', )
    assert cacheModule._BASE_FILE_PATH == '/tmp/ansible-fact'

# Generated at 2022-06-25 08:28:21.977593
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.get_cache_path() == '~/.ansible/tmp/ansible-local/'

    module = CacheModule()
    assert module.get_cache_path('/tmp/') == '/tmp/ansible-local/'


# Generated at 2022-06-25 08:28:23.574200
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m is not None


# Generated at 2022-06-25 08:28:50.055674
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-25 08:28:50.732425
# Unit test for constructor of class CacheModule
def test_CacheModule():
  cache = CacheModule()

# Generated at 2022-06-25 08:28:51.967236
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-25 08:29:03.486626
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mod = CacheModule()

# Generated at 2022-06-25 08:29:05.700981
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    t = CacheModule()
    t._load('jsonfile.py')
    t._dump('{}', 'jsonfile.py')

# Generated at 2022-06-25 08:29:06.783450
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()


# Generated at 2022-06-25 08:29:07.927443
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert isinstance(obj, BaseFileCacheModule) == True

# Generated at 2022-06-25 08:29:08.967494
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

# Generated at 2022-06-25 08:29:11.265881
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert isinstance(obj, BaseFileCacheModule)
    assert obj.get_cache_timeout == 86400


# Generated at 2022-06-25 08:29:14.584068
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Unit test for constructor of class CacheModule()
    """
    import os
    c = CacheModule()
    temp_filename = os.path.join(c.get_options()['_uri'], "my_key")
    assert c.get_options()['_uri'] == temp_filename

# Generated at 2022-06-25 08:30:23.383550
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        assert type(CacheModule) == type
    except AssertionError:
        print("Test 1 - FAILED")
    try:
        assert type(CacheModule._load) == type(test_CacheModule)
    except AssertionError:
        print("Test 2 - FAILED")
    try:
        assert type(CacheModule._dump) == type(test_CacheModule)
    except AssertionError:
        print("Test 3 - FAILED")
    try:
        assert type(CacheModule.get) == type(test_CacheModule)
    except AssertionError:
        print("Test 4 - FAILED")
    try:
        assert type(CacheModule.set) == type(test_CacheModule)
    except AssertionError:
        print("Test 5 - FAILED")

# Generated at 2022-06-25 08:30:26.428269
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    desc = 'this is a test'
    timeout = 10
    prefix = 'ansible_cache'
    cache = CacheModule(path=tempfile.mkdtemp(), desc=desc, timeout=timeout, prefix=prefix)
    assert desc == cache._desc
    assert timeout == cache._timeout
    assert prefix == cache._prefix

# Generated at 2022-06-25 08:30:30.732320
# Unit test for constructor of class CacheModule
def test_CacheModule():
    my_cache = CacheModule(None, None, None)
    assert my_cache is not None

# Generated at 2022-06-25 08:30:31.570186
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()


# Generated at 2022-06-25 08:30:32.116957
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule(dict())

# Generated at 2022-06-25 08:30:33.791553
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Instantiate CacheModule with a hostname and its arguments
    c = CacheModule('hostname', dict(_timeout=1))
    assert c.timeout == 1

# Generated at 2022-06-25 08:30:37.302470
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert isinstance(cache_plugin, CacheModule)
    assert isinstance(cache_plugin.cache, dict)
    assert isinstance(cache_plugin._timeout, int)
    assert isinstance(cache_plugin._connection, str)
    assert isinstance(cache_plugin._prefix, str)

# Generated at 2022-06-25 08:30:38.379848
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400

# Generated at 2022-06-25 08:30:39.449571
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.cache_plugin is True

# Generated at 2022-06-25 08:30:42.939156
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__name__ == 'CacheModule'
    assert CacheModule._load.__name__ == '_load'
    assert CacheModule._dump.__name__ == '_dump'

# Generated at 2022-06-25 08:32:58.799150
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_mod = CacheModule()
    assert cache_mod.cache
    assert cache_mod._timeout == 86400

# Generated at 2022-06-25 08:33:02.168822
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None


# Generated at 2022-06-25 08:33:05.280809
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = str("data.cache")
    timeout = int(86400)

    cm = CacheModule()
    cm.set_options(direct={'connection': connection, 'timeout': timeout})
    assert cm.connection == connection
    assert cm.get_option('timeout') == timeout
    assert cm.get_option('prefix') == 'ansible_'



# Generated at 2022-06-25 08:33:10.870575
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Default values (cannot be changed)
    module_name = 'jsonfile'
    # 64 character prefix is the limit
    module_prefix = ''
    module_timeout = 86400

    # Create object to invoke constructor
    object = CacheModule()

    # Get constructor invocation attributes
    object_attributes = vars(object)

    # Assert that the module_name is as expected
    assert object_attributes['module_name'] == module_name

    # Assert that the _prefix is as expected
    assert object_attributes['_prefix'] == module_prefix

    # Assert that the _timeout is as expected
    assert object_attributes['_timeout'] == module_timeout

# Generated at 2022-06-25 08:33:12.189032
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    # print(c)
    return True

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-25 08:33:15.240560
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.value_version == 2
    assert cache_module.timeout == 86400
    assert cache_module._CacheModule__ext == 'json'
    assert cache_module._CacheModule__ext_len == 4
    assert cache_module.name == 'jsonfile', 'CacheModule should be named jsonfile'
    assert cache_module.args == {'_uri': None, '_prefix': None, '_timeout': 86400}

# Generated at 2022-06-25 08:33:15.641471
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-25 08:33:16.317741
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._connection_class
    assert CacheModule._cache_plugin_class

# Generated at 2022-06-25 08:33:16.820953
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule

# Generated at 2022-06-25 08:33:17.818325
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(None)._connection == None
    assert CacheModule(None)._prefix == None
    assert CacheModule(None)._timeout == 86400