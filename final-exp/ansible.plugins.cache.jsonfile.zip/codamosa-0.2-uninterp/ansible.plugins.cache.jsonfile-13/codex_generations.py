

# Generated at 2022-06-17 10:28:26.232648
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:28:28.755092
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400

# Generated at 2022-06-17 10:28:30.954883
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_prefix() == ''
    assert cache_plugin.get_connection() == ''


# Generated at 2022-06-17 10:28:36.252382
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''
    assert cache.get_validate_certs() == True

# Generated at 2022-06-17 10:28:42.741828
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-fact'
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump
    assert cache._load_cache == CacheModule._load_cache
    assert cache._dump_cache == CacheModule._dump_cache
    assert cache._flush_cache == CacheModule._flush_cache

# Generated at 2022-06-17 10:28:45.860451
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None
    assert cache_module._load is not None
    assert cache_module._dump is not None

# Generated at 2022-06-17 10:28:46.651505
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:28:52.009963
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == {}
    cache._dump({'test': 'test'}, '/tmp/test')
    assert cache._load('/tmp/test') == {'test': 'test'}

# Generated at 2022-06-17 10:28:53.628688
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:28:59.002049
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None
    assert cache_module._load is not None
    assert cache_module._dump is not None

# Generated at 2022-06-17 10:29:04.227052
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:05.766431
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:29:09.576277
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:29:12.376269
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._timeout == 86400
    assert cache_plugin._prefix == 'ansible_facts'
    assert cache_plugin._connection == '~/.ansible/cache'

# Generated at 2022-06-17 10:29:15.237204
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-cache'
    assert cache._load_name == '_load'
    assert cache._dump_name == '_dump'

# Generated at 2022-06-17 10:29:19.803390
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache_module.get_prefix() == 'ansible_fact_cache_'

# Generated at 2022-06-17 10:29:21.059613
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_plugin_name == 'jsonfile'

# Generated at 2022-06-17 10:29:25.207071
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:29:29.430294
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:29:32.932036
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:29:41.347244
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-factcache'
    assert cache._connection == '~/.ansible/fact_cache'

# Generated at 2022-06-17 10:29:42.354725
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:29:47.903410
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''
    assert cache.get_validate_certs() is False
    assert cache.get_plugin_options() == {}
    assert cache.get_plugin_path() == ''
    assert cache.get_plugin_name() == 'jsonfile'

# Generated at 2022-06-17 10:29:49.929747
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == None
    assert cache._dump('test', '/tmp/test') == None

# Generated at 2022-06-17 10:29:53.585536
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_type == 'jsonfile'
    assert cache.cache_prefix == 'ansible-fact'
    assert cache.cache_timeout == 86400
    assert cache.cache_connection == '~/.ansible/cache'

# Generated at 2022-06-17 10:29:55.654433
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:30:00.781394
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp'
    assert cache.get_prefix() == 'ansible-factcache'

# Generated at 2022-06-17 10:30:04.532961
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:09.130502
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:30:11.035583
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load is not None
    assert cache_module._dump is not None

# Generated at 2022-06-17 10:30:25.579158
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load is not None
    assert cache._dump is not None

# Generated at 2022-06-17 10:30:36.792612
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_prefix() == ''
    assert cache_module.get_connection() == ''
    assert cache_module.get_validate_certs() is False
    assert cache_module.get_client_cert() == ''
    assert cache_module.get_client_key() == ''
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_timeout() == 8

# Generated at 2022-06-17 10:30:39.330275
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:44.874081
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('test') is None
    assert cache_module._dump('test', 'test') is None

# Generated at 2022-06-17 10:30:46.482573
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == None
    assert cache._dump('test', '/tmp/test') == None

# Generated at 2022-06-17 10:30:51.317815
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:30:53.616310
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:30:56.430413
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-facts'
    assert cache._connection == '~/.ansible/cache/facts'

# Generated at 2022-06-17 10:31:00.332566
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:31:01.828658
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:31:31.097680
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_fact_cache_'

# Generated at 2022-06-17 10:31:37.901923
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with default values
    cache = CacheModule()
    assert cache._connection == '~/.ansible/tmp/ansible-local'
    assert cache._prefix == 'ansible_fact_cache'
    assert cache._timeout == 86400

    # Test with custom values
    cache = CacheModule(connection='/tmp/ansible-local', prefix='ansible_fact_cache', timeout=3600)
    assert cache._connection == '/tmp/ansible-local'
    assert cache._prefix == 'ansible_fact_cache'
    assert cache._timeout == 3600

# Generated at 2022-06-17 10:31:40.023518
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:31:44.952311
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == None
    cache._dump('test', '/tmp/test')
    assert cache._load('/tmp/test') == 'test'

# Generated at 2022-06-17 10:31:49.755248
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-fact'
    assert cache.get_connection() == '~/.ansible/cache'

# Generated at 2022-06-17 10:31:55.497290
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''
    assert cache.get_validate_certs() is True

# Generated at 2022-06-17 10:31:56.658871
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:32:02.392360
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:32:06.447548
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:32:08.893560
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-fact'
    assert cache.get_connection() == '~/.ansible/tmp/ansible-fact'

# Generated at 2022-06-17 10:33:01.598262
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-factcache'
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:33:02.454140
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:33:05.837564
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:33:13.604561
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.plugin_name == 'jsonfile'
    assert cache_plugin.cache_type == 'json'
    assert cache_plugin.config_prefix == 'fact_caching_'
    assert cache_plugin.default_timeout == 86400
    assert cache_plugin.default_connection == '~/.ansible/cache/facts'
    assert cache_plugin.default_prefix == 'ansible_facts_'

# Generated at 2022-06-17 10:33:16.033556
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:33:19.117655
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:33:20.172820
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None


# Generated at 2022-06-17 10:33:25.525034
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._timeout == 86400
    assert cache_plugin._prefix == 'ansible_facts'
    assert cache_plugin._connection == '~/.ansible/cache'

# Generated at 2022-06-17 10:33:30.533291
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_fact_cache'

# Generated at 2022-06-17 10:33:34.126083
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_prefix() == 'ansible-cache'
    assert cache_plugin.get_connection() == '~/.ansible/tmp/ansible-fact-cache'

# Generated at 2022-06-17 10:35:27.529978
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:35:28.909312
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:35:33.187184
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test_file') == None
    cache_module._dump('test_value', '/tmp/test_file')
    assert cache_module._load('/tmp/test_file') == 'test_value'

# Generated at 2022-06-17 10:35:35.740867
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:35:37.893372
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_connection() == '~/.ansible/cache'
    assert cache_plugin.get_prefix() == 'ansible-fact'

# Generated at 2022-06-17 10:35:47.123545
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-fact'
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump
    assert cache._load_cache == CacheModule._load_cache
    assert cache._flush_cache == CacheModule._flush_cache
    assert cache._save_cache == CacheModule._save_cache
    assert cache._load_cache_plugin_options == CacheModule._load_cache_plugin_options
    assert cache._get_cache_plugin_options == CacheModule._get_cache_plugin_options
    assert cache._get_cache_plugin_option == CacheModule._get_cache_plugin_option
    assert cache._get_cache_plugin_option_value == CacheModule._get_cache_plugin_option_value

# Generated at 2022-06-17 10:35:49.807567
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-factcache'
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:35:54.195031
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-factcache'
    assert cache._uri == '/tmp'

# Generated at 2022-06-17 10:35:58.995804
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:36:05.043209
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with default values
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

    # Test with custom values
    cache_module = CacheModule(timeout=3600, connection='/tmp/', prefix='test_')
    assert cache_module.get_timeout() == 3600
    assert cache_module.get_connection() == '/tmp/'
    assert cache_module.get_prefix() == 'test_'