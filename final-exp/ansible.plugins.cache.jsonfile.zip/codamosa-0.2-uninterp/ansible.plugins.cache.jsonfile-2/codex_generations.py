

# Generated at 2022-06-17 10:28:23.098492
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-factcache'
    assert cache._load.__name__ == '_load'
    assert cache._dump.__name__ == '_dump'

# Generated at 2022-06-17 10:28:23.552396
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-17 10:28:25.368619
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == None
    assert cache._dump('test', '/tmp/test') == None

# Generated at 2022-06-17 10:28:29.036675
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:28:32.414480
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:28:37.606851
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_prefix() == ''
    assert cache_module.get_connection() == ''


# Generated at 2022-06-17 10:28:38.194985
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-17 10:28:42.773688
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_prefix() == ''
    assert cache_plugin.get_connection() == ''

# Generated at 2022-06-17 10:28:45.613673
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test.json') == {}
    assert cache_module._dump({'test': 'test'}, '/tmp/test.json') == None
    assert cache_module._load('/tmp/test.json') == {'test': 'test'}

# Generated at 2022-06-17 10:28:48.030551
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-fact'
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:28:52.998305
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache_plugin.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:28:57.655083
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400

# Generated at 2022-06-17 10:29:00.575122
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:29:02.591874
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:29:08.603420
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test.json') == {}
    cache._dump({'test': 'test'}, '/tmp/test.json')
    assert cache._load('/tmp/test.json') == {'test': 'test'}

# Generated at 2022-06-17 10:29:11.623183
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test') is None
    assert cache_module._dump({'test': 'test'}, '/tmp/test') is None

# Generated at 2022-06-17 10:29:13.832837
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test.json') == None
    assert cache._dump('test', '/tmp/test.json') == None

# Generated at 2022-06-17 10:29:16.248062
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-facts'
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:20.729392
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_plugin_name == 'jsonfile'
    assert cache.cache_plugin_timeout == 86400
    assert cache.cache_plugin_connection == ''
    assert cache.cache_plugin_prefix == ''

# Generated at 2022-06-17 10:29:23.367050
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:32.490027
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._connection is None
    assert cache._prefix == 'ansible_facts'
    assert cache._timeout == 86400

# Generated at 2022-06-17 10:29:37.822150
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:39.951032
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load(None) is None
    assert cache._dump(None, None) is None

# Generated at 2022-06-17 10:29:41.423157
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load is not None
    assert cache_module._dump is not None

# Generated at 2022-06-17 10:29:45.027178
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp'
    assert cache.get_prefix() == 'ansible-factcache'

# Generated at 2022-06-17 10:29:46.204218
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:48.450386
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:29:50.302266
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:51.249833
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:29:53.420854
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400

# Generated at 2022-06-17 10:30:11.529594
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test.json') == {}
    cache._dump({'test': 'test'}, '/tmp/test.json')
    assert cache._load('/tmp/test.json') == {'test': 'test'}

# Generated at 2022-06-17 10:30:14.282520
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400

# Generated at 2022-06-17 10:30:19.094521
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-facts'
    assert cache._load('/tmp/test') == {}
    assert cache._dump({'test': 'test'}, '/tmp/test') == None

# Generated at 2022-06-17 10:30:20.858442
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:21.637918
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:30:22.427026
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-17 10:30:25.648012
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:28.744026
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:32.363665
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test') == None
    assert cache_module._dump(None, '/tmp/test') == None

# Generated at 2022-06-17 10:30:35.632737
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache_plugin.get_prefix() == 'ansible_fact_cache_'

# Generated at 2022-06-17 10:31:01.017944
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-17 10:31:01.870890
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-17 10:31:05.269504
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('test') == None
    assert cache._dump('test', 'test') == None

# Generated at 2022-06-17 10:31:08.133015
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:31:10.573838
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-factcache'
    assert cache._connection == '~/.ansible/tmp/ansible-factcache'

# Generated at 2022-06-17 10:31:11.799267
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:31:14.056764
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_connection() == ''
    assert cache_plugin.get_prefix() == ''

# Generated at 2022-06-17 10:31:17.636934
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp'
    assert cache.get_prefix() == 'ansible-fact'

# Generated at 2022-06-17 10:31:21.314324
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:31:22.632772
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-17 10:31:49.238216
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == None
    assert cache._dump('test', '/tmp/test') == None

# Generated at 2022-06-17 10:31:54.717253
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:31:55.809171
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:31:58.107597
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_connection() == '~/.ansible/cache'
    assert cache_plugin.get_prefix() == ''

# Generated at 2022-06-17 10:32:02.133251
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == {}
    cache._dump('test', '/tmp/test')
    assert cache._load('/tmp/test') == 'test'

# Generated at 2022-06-17 10:32:03.361000
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test.json') == None
    assert cache._dump('test', '/tmp/test.json') == None

# Generated at 2022-06-17 10:32:04.646423
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-facts'
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:32:07.487692
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_fact_cache_'

# Generated at 2022-06-17 10:32:11.505030
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load is not None
    assert cache._dump is not None

# Generated at 2022-06-17 10:32:13.222038
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:33:01.210360
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:33:06.222657
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == None
    assert cache._dump({'test': 'test'}, '/tmp/test') == None

# Generated at 2022-06-17 10:33:11.886670
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test') == None
    assert cache_module._dump('test', '/tmp/test') == None

# Generated at 2022-06-17 10:33:13.717024
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-fact'
    assert cache.get_connection() == '~/.ansible/cache'

# Generated at 2022-06-17 10:33:18.629622
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:33:20.691218
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:33:25.775884
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-fact'
    assert cache.get_connection() == '/tmp/ansible_fact_cache'

# Generated at 2022-06-17 10:33:28.345374
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:33:32.706235
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp'
    assert cache.get_prefix() == 'ansible-factcache'

# Generated at 2022-06-17 10:33:36.413116
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None


# Generated at 2022-06-17 10:35:23.673130
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-17 10:35:28.412719
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:35:31.568100
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == None
    assert cache._dump('test', '/tmp/test') == None

# Generated at 2022-06-17 10:35:34.926030
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:35:35.367753
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-17 10:35:36.915790
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:35:43.884743
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-facts'
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:35:47.577179
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load is not None
    assert cache._dump is not None

# Generated at 2022-06-17 10:35:49.331599
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:35:53.048886
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == ''
    assert cache._connection == ''