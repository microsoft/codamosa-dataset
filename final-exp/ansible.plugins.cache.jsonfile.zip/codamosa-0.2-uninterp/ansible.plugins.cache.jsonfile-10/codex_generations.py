

# Generated at 2022-06-17 10:28:21.433957
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'test_uri', '_prefix': 'test_prefix', '_timeout': 'test_timeout'})

# Generated at 2022-06-17 10:28:28.332876
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_basedir() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible-local'
    assert cache.get_timeout() == 86400
    assert cache.get_plugin_name() == 'jsonfile'

# Generated at 2022-06-17 10:28:35.019412
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load is not None
    assert cache._dump is not None
    assert cache._timeout == 86400
    assert cache._prefix == ''
    assert cache._uri == ''

# Generated at 2022-06-17 10:28:37.110214
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400

# Generated at 2022-06-17 10:28:39.065420
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._load == CacheModule._load
    assert cache_plugin._dump == CacheModule._dump

# Generated at 2022-06-17 10:28:44.517260
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-fact'
    assert cache.get_connection() == '~/.ansible/cache/facts'

# Generated at 2022-06-17 10:28:46.817582
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load is not None
    assert cache._dump is not None

# Generated at 2022-06-17 10:28:48.695158
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-17 10:28:51.318786
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.cache_type == 'jsonfile'

# Generated at 2022-06-17 10:28:52.455797
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:28:57.473108
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''


# Generated at 2022-06-17 10:29:05.259214
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.file_extension == 'json'
    assert cache.file_prefix == 'ansible-fact'
    assert cache.file_suffix == ''
    assert cache.file_perms == 0o644
    assert cache.file_basedir == '~/.ansible/tmp'
    assert cache.file_basedir_mode == 0o700
    assert cache.file_encoding == 'utf-8'
    assert cache.file_errors == 'strict'
    assert cache.file_backup == False
    assert cache.file_atomic_action == True
    assert cache.file_diff == False
    assert cache.file_remote_src == False
    assert cache.file_follow == False
    assert cache.file_force == False
    assert cache.file_gid == -1

# Generated at 2022-06-17 10:29:07.703902
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:09.630209
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'test_uri'}) is not None

# Generated at 2022-06-17 10:29:12.754779
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:29:13.631139
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'test'})

# Generated at 2022-06-17 10:29:18.636843
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_connection() == ''
    assert cache_plugin.get_prefix() == ''

# Generated at 2022-06-17 10:29:27.445579
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''
    assert cache.get_validate_certs() == True
    assert cache.get_plugin_name() == 'jsonfile'
    assert cache.get_plugin_path() == 'ansible.plugins.cache.jsonfile'
    assert cache.get_plugin_type() == 'cache'
    assert cache.get_plugin_load_prio() == 0
    assert cache.get_plugin_version() == 1.0
    assert cache.get_plugin_multiprocess_safe() == True
    assert cache.get_plugin_lock_path() == None
    assert cache.get_plugin_write_lock() == False
    assert cache.get_plugin_read

# Generated at 2022-06-17 10:29:28.337485
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-17 10:29:31.346381
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:39.993043
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:29:42.693645
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:46.831054
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache_plugin.get_prefix() == 'ansible_fact_cache_'

# Generated at 2022-06-17 10:29:49.118090
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:29:52.097904
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-factcache'
    assert cache._connection == '~/.ansible/fact_cache'

# Generated at 2022-06-17 10:29:54.089091
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == None
    assert cache._dump('test', '/tmp/test') == None

# Generated at 2022-06-17 10:29:55.517742
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load is not None
    assert cache._dump is not None

# Generated at 2022-06-17 10:29:59.117577
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': '/tmp'})

# Generated at 2022-06-17 10:30:00.661190
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:06.120509
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache_module.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:30:18.991782
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:30:20.162322
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400

# Generated at 2022-06-17 10:30:21.528585
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:22.315752
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:30:26.733621
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_connection() == ''
    assert cache_plugin.get_prefix() == ''

# Generated at 2022-06-17 10:30:31.501581
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-fact'
    assert cache.get_connection() == '~/.ansible/cache'

# Generated at 2022-06-17 10:30:34.490729
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test_cache') == None
    assert cache._dump('test_cache', '/tmp/test_cache') == None

# Generated at 2022-06-17 10:30:39.090321
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._load == CacheModule._load
    assert cache_plugin._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:44.720619
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:46.133315
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:31:10.456868
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:31:12.302944
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:31:13.670812
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:31:15.604396
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-17 10:31:20.116916
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test.json') == {}
    cache._dump({'test': 'test'}, '/tmp/test.json')
    assert cache._load('/tmp/test.json') == {'test': 'test'}

# Generated at 2022-06-17 10:31:22.625211
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-fact'
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:31:24.038352
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:31:28.427955
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_prefix() == ''
    assert cache_plugin.get_connection() == ''

# Generated at 2022-06-17 10:31:30.663946
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.get_timeout() == 86400
    assert c.get_prefix() == ''
    assert c.get_connection() == ''

# Generated at 2022-06-17 10:31:33.617834
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:32:32.973977
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with no arguments
    cache = CacheModule()
    assert cache.plugin_name == 'jsonfile'
    assert cache.timeout == 86400
    assert cache.plugin_prefix == 'ansible_facts'
    assert cache.plugin_basedir == '/tmp/ansible_fact_cache'

    # Test with arguments
    cache = CacheModule(timeout=3600, plugin_prefix='test', plugin_basedir='/tmp/test')
    assert cache.plugin_name == 'jsonfile'
    assert cache.timeout == 3600
    assert cache.plugin_prefix == 'test'
    assert cache.plugin_basedir == '/tmp/test'

# Generated at 2022-06-17 10:32:38.615059
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test') == json.load('/tmp/test', cls=AnsibleJSONDecoder)
    assert cache_module._dump('/tmp/test') == json.dumps('/tmp/test', cls=AnsibleJSONEncoder, sort_keys=True, indent=4)

# Generated at 2022-06-17 10:32:41.684798
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_prefix() == ''
    assert cache_module.get_connection() == ''

# Generated at 2022-06-17 10:32:46.715372
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''
    assert cache.get_plugin_name() == 'jsonfile'

# Generated at 2022-06-17 10:32:52.151248
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:32:53.866902
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == None
    assert cache._dump('test', '/tmp/test') == None

# Generated at 2022-06-17 10:32:54.662539
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-17 10:32:57.058073
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:33:02.051249
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-fact'
    assert cache.get_connection() == '~/.ansible/tmp/ansible-fact'

# Generated at 2022-06-17 10:33:06.503564
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-fact'
    assert cache.get_connection() == '~/.ansible/cache'

# Generated at 2022-06-17 10:34:09.092463
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._connection is None
    assert cache._timeout == 86400
    assert cache._prefix == ''

# Generated at 2022-06-17 10:34:10.586814
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:34:13.155095
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:34:15.448209
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:34:19.512783
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test.json') == {}
    cache._dump({'test': 'test'}, '/tmp/test.json')
    assert cache._load('/tmp/test.json') == {'test': 'test'}

# Generated at 2022-06-17 10:34:20.345218
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:34:22.696241
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.plugin_name == 'jsonfile'
    assert cache.file_extension == 'json'
    assert cache.cache_prefix == 'ansible_facts'
    assert cache.cache_timeout == 86400

# Generated at 2022-06-17 10:34:24.244558
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:34:26.911847
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-factcache'

# Generated at 2022-06-17 10:34:32.579956
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._load == CacheModule._load
    assert cache_plugin._dump == CacheModule._dump
    assert cache_plugin._timeout == 86400
    assert cache_plugin._prefix == ''

# Generated at 2022-06-17 10:36:36.632360
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible-local'

# Generated at 2022-06-17 10:36:40.432796
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with default values
    cache = CacheModule()
    assert cache._connection == '~/.ansible/tmp'
    assert cache._prefix == 'ansible-factcache'
    assert cache._timeout == 86400

    # Test with custom values
    cache = CacheModule(connection='/tmp', prefix='test', timeout=3600)
    assert cache._connection == '/tmp'
    assert cache._prefix == 'test'
    assert cache._timeout == 3600

# Generated at 2022-06-17 10:36:42.408016
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:36:43.349253
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:36:46.551452
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == None
    assert cache._dump('test', '/tmp/test') == None

# Generated at 2022-06-17 10:36:48.936725
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''


# Generated at 2022-06-17 10:36:51.232971
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.file_extension == '.json'
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:36:54.760602
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-17 10:36:55.939968
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:37:02.225879
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') is None
    cache._dump({"test": "test"}, '/tmp/test')
    assert cache._load('/tmp/test') == {"test": "test"}