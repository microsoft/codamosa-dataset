

# Generated at 2022-06-17 10:28:22.729259
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_prefix() == ''
    assert cache_module.get_connection() == ''

# Generated at 2022-06-17 10:28:24.333766
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == ''
    assert cache._uri == ''

# Generated at 2022-06-17 10:28:28.369462
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:28:34.077914
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-factcache'

# Generated at 2022-06-17 10:28:37.957068
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_type == 'jsonfile'
    assert cache.cache_prefix == 'ansible-cache'
    assert cache.cache_timeout == 86400
    assert cache.cache_connection == '~/.ansible/cache'

# Generated at 2022-06-17 10:28:39.447198
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:28:43.557991
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test.json') == None
    assert cache_module._dump('test', '/tmp/test.json') == None

# Generated at 2022-06-17 10:28:45.686821
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == 'ansible_facts_'

# Generated at 2022-06-17 10:28:50.994139
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:28:53.347396
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_connection() == ''
    assert cache_plugin.get_prefix() == ''

# Generated at 2022-06-17 10:28:57.055854
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:28:58.552045
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:29:01.161007
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:29:02.841900
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._load == CacheModule._load
    assert cache_plugin._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:09.051224
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._load('/tmp/test.json') == {}
    cache_plugin._dump({'test': 'test'}, '/tmp/test.json')
    assert cache_plugin._load('/tmp/test.json') == {'test': 'test'}

# Generated at 2022-06-17 10:29:10.274681
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._connection is None
    assert cache._prefix == 'ansible_facts'
    assert cache._timeout == 86400

# Generated at 2022-06-17 10:29:11.247350
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:29:17.732024
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache_module.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:29:22.555826
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == '$HOME/.ansible/tmp/ansible-local'
    assert cache_module.get_prefix() == 'ansible_local_facts'

# Generated at 2022-06-17 10:29:27.873750
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:29:37.159462
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:29:40.328475
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-factcache'
    assert cache._connection == '~/.ansible/tmp/ansible-factcache'

# Generated at 2022-06-17 10:29:44.959514
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == {}
    cache._dump({'test': 'test'}, '/tmp/test')
    assert cache._load('/tmp/test') == {'test': 'test'}

# Generated at 2022-06-17 10:29:46.820526
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._connection == '~/.ansible/tmp/ansible-local'
    assert cache._prefix == 'ansible-local'
    assert cache._timeout == 86400

# Generated at 2022-06-17 10:29:47.678178
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:29:48.538477
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:29:52.266468
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_type == 'jsonfile'
    assert cache.cache_prefix == 'ansible-factcache'
    assert cache.cache_timeout == 86400
    assert cache.cache_connection == '~/.ansible/fact_cache'

# Generated at 2022-06-17 10:29:54.602526
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache._load('test') == None
    assert cache._dump('test', 'test') == None

# Generated at 2022-06-17 10:29:58.958646
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:30:01.112116
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('test_file') == None
    assert cache_module._dump('test_value', 'test_file') == None

# Generated at 2022-06-17 10:30:14.348849
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-17 10:30:19.619786
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._connection is None
    assert cache_plugin._timeout == 86400
    assert cache_plugin._prefix == ''
    assert cache_plugin._load_cache() == {}
    assert cache_plugin._dump_cache({}) == None
    assert cache_plugin._flush_cache() == None

# Generated at 2022-06-17 10:30:21.602076
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:30:22.711317
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.file_extension == '.json'

# Generated at 2022-06-17 10:30:25.372735
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:27.662767
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:30:29.944640
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:30:34.067035
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible_facts_'
    assert cache._connection == '~/.ansible/cache'

# Generated at 2022-06-17 10:30:40.167097
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._timeout == 86400
    assert cache_plugin._prefix == 'ansible-factcache'
    assert cache_plugin._connection == '~/.ansible/fact_cache'

# Generated at 2022-06-17 10:30:41.129834
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:31:06.519555
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:31:09.434709
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test.json') == json.load('/tmp/test.json')
    assert cache._dump('/tmp/test.json') == json.dump('/tmp/test.json')

# Generated at 2022-06-17 10:31:11.279354
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('test') == None
    assert cache._dump('test', 'test') == None

# Generated at 2022-06-17 10:31:15.956174
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test.json') == {}
    cache._dump({'test': 'test'}, '/tmp/test.json')
    assert cache._load('/tmp/test.json') == {'test': 'test'}

# Generated at 2022-06-17 10:31:27.232980
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-factcache'
    assert cache._load_cache_plugin_options() == {'_timeout': 86400, '_prefix': 'ansible-factcache'}
    assert cache._get_cache_prefix() == 'ansible-factcache'
    assert cache._get_cache_timeout() == 86400
    assert cache._get_cache_basedir() == '/tmp/ansible_fact_cache'
    assert cache._get_cache_basedir('/tmp/ansible_fact_cache') == '/tmp/ansible_fact_cache'
    assert cache._get_cache_basedir('/tmp/ansible_fact_cache/') == '/tmp/ansible_fact_cache'
    assert cache._get_cache_based

# Generated at 2022-06-17 10:31:32.232671
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test_file') is None
    cache_module._dump('test_value', '/tmp/test_file')
    assert cache_module._load('/tmp/test_file') == 'test_value'

# Generated at 2022-06-17 10:31:34.758052
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test.json') == None
    assert cache_module._dump('test', '/tmp/test.json') == None

# Generated at 2022-06-17 10:31:45.534697
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._connection is None
    assert cache._timeout == 86400
    assert cache._prefix == ''
    assert cache._cache_dir == ''
    assert cache._cache_files == {}
    assert cache._cache_lock_timeout == 10
    assert cache._cache_lock_path == ''
    assert cache._cache_lock_id == ''
    assert cache._cache_lock_handle == None
    assert cache._cache_lock_refresh_timeout == 5
    assert cache._cache_lock_refresh_time == 0
    assert cache._cache_lock_last_refresh_time == 0
    assert cache._cache_lock_max_age == 300
    assert cache._cache_lock_max_age_buffer == 30
    assert cache._cache_lock_max_age_jitter == 0.1

# Generated at 2022-06-17 10:31:48.563200
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:31:51.523319
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-17 10:32:45.373339
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:32:47.946557
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == {}
    cache._dump({'test': 'test'}, '/tmp/test')
    assert cache._load('/tmp/test') == {'test': 'test'}

# Generated at 2022-06-17 10:32:52.299811
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:32:54.625542
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == None
    cache._dump('test', '/tmp/test')
    assert cache._load('/tmp/test') == 'test'

# Generated at 2022-06-17 10:33:00.222091
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''


# Generated at 2022-06-17 10:33:02.693673
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:33:06.336141
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:33:07.356309
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:33:12.526927
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_fact_cache_'

# Generated at 2022-06-17 10:33:15.582377
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_prefix() == 'ansible_facts'
    assert cache_plugin.get_connection() == '~/.ansible/cache'

# Generated at 2022-06-17 10:35:06.071225
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == None
    assert cache_module.get_prefix() == None

# Generated at 2022-06-17 10:35:07.602735
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:35:08.707503
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:35:10.003181
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_plugin_name == 'jsonfile'

# Generated at 2022-06-17 10:35:15.118989
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_fact_cache_'

# Generated at 2022-06-17 10:35:17.694366
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:35:19.428201
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-17 10:35:21.757702
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'test'})

# Generated at 2022-06-17 10:35:25.725101
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test') == None
    assert cache_module._dump('test', '/tmp/test') == None

# Generated at 2022-06-17 10:35:28.908240
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump