

# Generated at 2022-06-17 10:28:23.100502
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:28:26.038067
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == None
    assert cache.get_prefix() == None
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:28:34.812580
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() is None
    assert cache_module.get_prefix() is None

    cache_module = CacheModule(timeout=100)
    assert cache_module.get_timeout() == 100
    assert cache_module.get_connection() is None
    assert cache_module.get_prefix() is None

    cache_module = CacheModule(connection='/tmp/', prefix='test_')
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == '/tmp/'
    assert cache_module.get_prefix() == 'test_'

# Generated at 2022-06-17 10:28:36.747204
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:28:38.505983
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:28:43.786286
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:28:46.998001
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:28:50.646975
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:28:52.558923
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:28:56.868638
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_prefix() == 'ansible_facts'
    assert cache_module.get_connection() == '~/.ansible/cache'

# Generated at 2022-06-17 10:29:01.580148
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:02.375224
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:29:05.314967
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:07.221519
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-17 10:29:08.901666
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:29:09.528043
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-17 10:29:11.022224
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_prefix() == 'ansible-fact'
    assert cache_plugin.get_connection() == '~/.ansible/cache'

# Generated at 2022-06-17 10:29:14.262655
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test.json') == None
    cache._dump({'test': 'test'}, '/tmp/test.json')
    assert cache._load('/tmp/test.json') == {'test': 'test'}

# Generated at 2022-06-17 10:29:15.151370
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:29:17.971928
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:29:25.531710
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:29:31.581609
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test.json') == {}
    cache._dump({'test': 'test'}, '/tmp/test.json')
    assert cache._load('/tmp/test.json') == {'test': 'test'}

# Generated at 2022-06-17 10:29:35.233145
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:29:37.991101
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'test_uri', '_prefix': 'test_prefix', '_timeout': 'test_timeout'})

# Generated at 2022-06-17 10:29:41.384749
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_facts_'

# Generated at 2022-06-17 10:29:44.960151
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._connection == '$HOME/.ansible/tmp/ansible-local'
    assert cache._prefix == 'ansible-local'
    assert cache._timeout == 86400

# Generated at 2022-06-17 10:29:45.917300
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None


# Generated at 2022-06-17 10:29:48.497344
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump
    assert cache._timeout == 86400
    assert cache._prefix == ''
    assert cache._uri == ''

# Generated at 2022-06-17 10:29:49.789853
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.file_extension == 'json'

# Generated at 2022-06-17 10:29:52.001632
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == ''
    assert cache._uri == ''

# Generated at 2022-06-17 10:30:05.786340
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:30:10.031458
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:13.218905
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:30:14.923264
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:30:19.350822
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:30:21.058530
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load is not None
    assert cache_module._dump is not None

# Generated at 2022-06-17 10:30:23.302047
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:30:25.920928
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:29.624954
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/cache'
    assert cache.get_prefix() == 'ansible-fact'

# Generated at 2022-06-17 10:30:34.481610
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''
    assert cache.get_validate_certs() == True

# Generated at 2022-06-17 10:31:01.367506
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:31:04.412291
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:31:06.658707
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:31:08.573037
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:31:10.725301
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/foo') == {}
    assert cache._dump({'foo': 'bar'}, '/tmp/foo') == None

# Generated at 2022-06-17 10:31:12.574099
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == None
    assert cache._dump('test', '/tmp/test') == None

# Generated at 2022-06-17 10:31:15.562387
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:31:17.781300
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._timeout == 86400
    assert cache_plugin._prefix == 'ansible_facts'

# Generated at 2022-06-17 10:31:21.748797
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:31:27.040303
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_fact_cache_'

# Generated at 2022-06-17 10:32:23.350186
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:32:24.071362
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-17 10:32:30.631615
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-cache'
    assert cache.get_connection() == '~/.ansible/tmp'

# Generated at 2022-06-17 10:32:35.622558
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test.json') == None
    assert cache._dump({"test": "test"}, '/tmp/test.json') == None

# Generated at 2022-06-17 10:32:40.564645
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''
    assert cache.get_plugin_name() == 'jsonfile'

# Generated at 2022-06-17 10:32:45.016610
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:32:46.390960
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.file_extension == '.json'

# Generated at 2022-06-17 10:32:48.321067
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:32:51.924728
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:32:54.224295
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:33:59.436610
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache_plugin.get_prefix() == 'ansible_fact_cache_'

# Generated at 2022-06-17 10:33:59.972301
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-17 10:34:02.725593
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-17 10:34:06.219751
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-fact'
    assert cache.get_connection() == '~/.ansible/fact_cache'

# Generated at 2022-06-17 10:34:08.072315
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:34:10.544423
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.file_extension == '.json'
    assert cache.file_permissions == 0o644
    assert cache.file_mode == 'wb'
    assert cache.file_encoding == 'utf-8'

# Generated at 2022-06-17 10:34:15.192285
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache_plugin.get_prefix() == 'ansible_fact_cache'

# Generated at 2022-06-17 10:34:17.540228
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._load == CacheModule._load
    assert cache_plugin._dump == CacheModule._dump

# Generated at 2022-06-17 10:34:20.342437
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_connection() == ''
    assert cache_plugin.get_prefix() == ''

# Generated at 2022-06-17 10:34:22.227737
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:36:26.690908
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:36:30.805559
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:36:33.765486
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == None
    assert cache.get_prefix() == None
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:36:35.624486
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:36:39.909714
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with no parameters
    cache = CacheModule()
    assert cache._connection == '$HOME/.ansible/tmp/ansible-local'
    assert cache._prefix == 'ansible_facts'
    assert cache._timeout == 86400

    # Test with parameters
    cache = CacheModule(connection='/tmp', prefix='test', timeout=60)
    assert cache._connection == '/tmp'
    assert cache._prefix == 'test'
    assert cache._timeout == 60

# Generated at 2022-06-17 10:36:41.793515
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:36:46.103317
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:36:48.794875
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == {}
    cache._dump({'test': 'test'}, '/tmp/test')
    assert cache._load('/tmp/test') == {'test': 'test'}

# Generated at 2022-06-17 10:36:51.661378
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_cache_timeout() == 86400
    assert cache_plugin.get_cache_prefix() == 'ansible-factcache'
    assert cache_plugin.get_cache_connection() == '~/.ansible/fact_cache'

# Generated at 2022-06-17 10:36:55.594339
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump