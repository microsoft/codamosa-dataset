

# Generated at 2022-06-17 10:28:26.377875
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-fact'
    assert cache.get_connection() == '~/.ansible/cached'

# Generated at 2022-06-17 10:28:28.380444
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-cache'
    assert cache.get_connection() == '~/.ansible/cache'

# Generated at 2022-06-17 10:28:34.305564
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == ''
    assert cache._connection == ''

# Generated at 2022-06-17 10:28:37.912324
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:28:39.409900
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:28:42.309171
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:28:45.748083
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_prefix() == ''
    assert cache_module.get_connection() == ''

# Generated at 2022-06-17 10:28:46.817644
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.file_extension == '.json'

# Generated at 2022-06-17 10:28:54.495278
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with no arguments
    cache = CacheModule()
    assert cache.plugin_name == 'jsonfile'
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible_facts'
    assert cache._connection == '~/.ansible/cache'

    # Test with arguments
    cache = CacheModule(timeout=3600, prefix='test', connection='/tmp')
    assert cache.plugin_name == 'jsonfile'
    assert cache._timeout == 3600
    assert cache._prefix == 'test'
    assert cache._connection == '/tmp'

# Generated at 2022-06-17 10:28:59.082120
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:29:03.211703
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:05.108903
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:29:10.149969
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_type == 'jsonfile'
    assert cache.cache_prefix == 'ansible-factcache'
    assert cache.cache_timeout == 86400
    assert cache.cache_connection == '~/.ansible/tmp/ansible-factcache'

# Generated at 2022-06-17 10:29:11.533490
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:29:14.380339
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_prefix() == 'ansible_facts'
    assert cache_plugin.get_connection() == '~/.ansible/cache'

# Generated at 2022-06-17 10:29:17.035919
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:29:18.664960
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:29:23.741104
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:29:29.514475
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_cache_prefix() == 'ansible-factcache'
    assert cache.get_cache_timeout() == 86400
    assert cache.get_cache_connection() == '~/.ansible/fact_cache'

# Generated at 2022-06-17 10:29:33.550133
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:29:40.773919
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-cache'

# Generated at 2022-06-17 10:29:43.185216
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:46.282293
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == ''
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:48.538251
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test') == None
    assert cache_module._dump('test', '/tmp/test') == None

# Generated at 2022-06-17 10:29:51.472858
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_prefix() == ''
    assert cache_module.get_connection() == ''

# Generated at 2022-06-17 10:29:53.160808
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:29:55.027884
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:00.102743
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == None
    assert cache._dump('test', '/tmp/test') == None

# Generated at 2022-06-17 10:30:06.298824
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test.json') == {}
    cache_module._dump({'test': 'test'}, '/tmp/test.json')
    assert cache_module._load('/tmp/test.json') == {'test': 'test'}

# Generated at 2022-06-17 10:30:12.227786
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_prefix() == ''
    assert cache_plugin.get_connection() == ''
    assert cache_plugin.get_cache_dir() == ''
    assert cache_plugin.get_cache_file_for_host('') == ''

# Generated at 2022-06-17 10:30:28.096791
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:32.294086
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-fact'
    assert cache.get_connection() == '~/.ansible/cached'

# Generated at 2022-06-17 10:30:34.860034
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:30:37.747340
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-17 10:30:38.638054
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:30:42.524037
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.cache_type == 'jsonfile'
    assert cache_module.cache_prefix == 'ansible_facts'
    assert cache_module.cache_timeout == 86400
    assert cache_module.cache_connection == '/tmp/ansible_fact_cache'

# Generated at 2022-06-17 10:30:45.252922
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:47.405987
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == '~/.ansible/tmp'
    assert cache_module.get_prefix() == 'ansible-fact'

# Generated at 2022-06-17 10:30:50.229138
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.file_extension == 'json'

# Generated at 2022-06-17 10:30:51.872424
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.cache_type == 'jsonfile'

# Generated at 2022-06-17 10:31:16.898663
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.file_extension == 'json'
    assert cache.file_prefix == 'ansible-fact'

# Generated at 2022-06-17 10:31:20.947095
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test') is None
    cache_module._dump('test', '/tmp/test')
    assert cache_module._load('/tmp/test') == 'test'

# Generated at 2022-06-17 10:31:25.973279
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_prefix() == ''
    assert cache_module.get_connection() == ''

# Generated at 2022-06-17 10:31:28.423320
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:31:29.413783
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-17 10:31:32.204185
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-facts'
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:31:34.757685
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''


# Generated at 2022-06-17 10:31:36.305853
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible_facts'
    assert cache._load(None) is None
    assert cache._dump(None, None) is None

# Generated at 2022-06-17 10:31:37.522826
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-17 10:31:39.368852
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:32:30.917598
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:32:34.616461
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:32:40.227585
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.plugin_name == 'jsonfile'
    assert cache.timeout == 86400
    assert cache.plugin_prefix == 'ansible_facts'
    assert cache.plugin_path == '/tmp/ansible_fact_cache'

# Generated at 2022-06-17 10:32:44.858710
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400

# Generated at 2022-06-17 10:32:48.036160
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test.json') == None
    cache_module._dump({'test': 'test'}, '/tmp/test.json')
    assert cache_module._load('/tmp/test.json') == {'test': 'test'}

# Generated at 2022-06-17 10:32:52.817336
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == '~/.ansible/cache'
    assert cache_module.get_prefix() == 'ansible-facts'

# Generated at 2022-06-17 10:32:57.589760
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:32:59.779784
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:33:00.847926
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.file_extension == 'json'

# Generated at 2022-06-17 10:33:06.162038
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:35:00.086166
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_type == 'jsonfile'

# Generated at 2022-06-17 10:35:05.490421
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:35:06.520949
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:35:08.662597
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_prefix() == ''
    assert cache_plugin.get_connection() == ''

# Generated at 2022-06-17 10:35:11.149091
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:35:14.720924
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:35:16.425332
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == CacheModule._load
    assert cache_module._dump == CacheModule._dump

# Generated at 2022-06-17 10:35:18.380456
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test') == None
    assert cache_module._dump('test', '/tmp/test') == None

# Generated at 2022-06-17 10:35:21.579226
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:35:26.804330
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-factcache'
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump