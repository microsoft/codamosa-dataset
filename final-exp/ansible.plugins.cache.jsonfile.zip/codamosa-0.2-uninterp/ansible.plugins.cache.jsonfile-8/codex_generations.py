

# Generated at 2022-06-17 10:28:21.817026
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_facts'

# Generated at 2022-06-17 10:28:25.292605
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:28:28.969899
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:28:32.383193
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:28:37.213072
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test_jsonfile') == None
    assert cache._dump('test', '/tmp/test_jsonfile') == None

# Generated at 2022-06-17 10:28:38.827374
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load is not None
    assert cache._dump is not None

# Generated at 2022-06-17 10:28:49.153647
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with no arguments
    cache = CacheModule()
    assert cache._connection is None
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible_facts_'
    assert cache._cache_dir == '/tmp/ansible_fact_cache'

    # Test with arguments
    cache = CacheModule(connection='/tmp/ansible_fact_cache', timeout=3600, prefix='ansible_facts_')
    assert cache._connection == '/tmp/ansible_fact_cache'
    assert cache._timeout == 3600
    assert cache._prefix == 'ansible_facts_'
    assert cache._cache_dir == '/tmp/ansible_fact_cache'

# Generated at 2022-06-17 10:28:51.507858
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400

# Generated at 2022-06-17 10:28:54.435899
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400

# Generated at 2022-06-17 10:28:59.384062
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_connection() == None
    assert cache_plugin.get_prefix() == None

# Generated at 2022-06-17 10:29:04.906514
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:07.221252
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:11.666341
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_dir == '~/.ansible/tmp/ansible-local'
    assert cache.timeout == 86400
    assert cache.plugin_name == 'jsonfile'
    assert cache.plugin_prefix == 'ansible_local'

# Generated at 2022-06-17 10:29:13.221323
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:21.665250
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''
    assert cache.get_validate_certs() == True
    assert cache.get_cache_plugin_timeout() == 86400
    assert cache.get_cache_plugin_connection() == ''
    assert cache.get_cache_plugin_prefix() == ''
    assert cache.get_cache_plugin_validate_certs() == True
    assert cache.get_cache_plugin_name() == 'jsonfile'

# Generated at 2022-06-17 10:29:25.831350
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-fact'
    assert cache._connection == '~/.ansible/cache/facts'

# Generated at 2022-06-17 10:29:28.961130
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:29:30.915870
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.get_timeout() == 86400
    assert cache_plugin.get_connection() == ''
    assert cache_plugin.get_prefix() == ''

# Generated at 2022-06-17 10:29:35.494291
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test') == None
    cache_module._dump('test', '/tmp/test')
    assert cache_module._load('/tmp/test') == 'test'

# Generated at 2022-06-17 10:29:37.139908
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:44.065231
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:29:47.037359
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:29:48.629712
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load is not None
    assert cache_module._dump is not None

# Generated at 2022-06-17 10:29:51.959071
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') == {}
    cache._dump({'test': 'test'}, '/tmp/test')
    assert cache._load('/tmp/test') == {'test': 'test'}

# Generated at 2022-06-17 10:29:52.915833
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-17 10:29:55.102151
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None
    assert cache_plugin._load is not None
    assert cache_plugin._dump is not None

# Generated at 2022-06-17 10:30:01.002593
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''
    assert cache.get_validate_certs() == True

# Generated at 2022-06-17 10:30:05.126715
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test') is None
    assert cache._dump('test', '/tmp/test') is None

# Generated at 2022-06-17 10:30:10.918962
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:30:13.687757
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-17 10:30:25.152404
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'test'})

# Generated at 2022-06-17 10:30:28.243724
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.cache_type == 'jsonfile'

# Generated at 2022-06-17 10:30:34.400651
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache.get_prefix() == 'ansible_fact_cache_'

# Generated at 2022-06-17 10:30:38.762003
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load is not None
    assert cache._dump is not None

# Generated at 2022-06-17 10:30:40.478294
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:43.283387
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-facts'
    assert cache._load(cache._file_path('localhost')) == {}

# Generated at 2022-06-17 10:30:44.088729
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:30:46.331456
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible_facts'
    assert cache._uri == '~/.ansible/cached_facts'

# Generated at 2022-06-17 10:30:50.455959
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:30:55.692159
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-factcache'
    assert cache._connection == '~/.ansible/fact_cache'

# Generated at 2022-06-17 10:31:21.555321
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:31:23.377544
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:31:27.248941
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''


# Generated at 2022-06-17 10:31:30.831348
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-factcache'
    assert cache._connection == '~/.ansible/fact_cache'

# Generated at 2022-06-17 10:31:31.781168
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:31:33.190402
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:31:34.719444
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-17 10:31:37.253235
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:31:38.400700
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-17 10:31:38.978072
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-17 10:32:30.558962
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_connection() == ''
    assert cache.get_prefix() == ''

# Generated at 2022-06-17 10:32:36.297659
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('/tmp/test.json') == {}
    cache._dump({'test': 'test'}, '/tmp/test.json')
    assert cache._load('/tmp/test.json') == {'test': 'test'}

# Generated at 2022-06-17 10:32:40.915594
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-fact'
    assert cache.get_connection() == '~/.ansible/cache/facts'

# Generated at 2022-06-17 10:32:46.642550
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.plugin_name == 'jsonfile'
    assert cache.timeout == 86400
    assert cache.plugin_prefix == 'ansible_facts'
    assert cache.plugin_path == '~/.ansible/cached'

# Generated at 2022-06-17 10:32:52.423100
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == 'ansible-fact'
    assert cache.get_connection() == '~/.ansible/cached'

# Generated at 2022-06-17 10:32:55.276203
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == '~/.ansible/tmp/ansible-local'
    assert cache_module.get_prefix() == 'ansible_fact_cache_'

# Generated at 2022-06-17 10:33:03.260194
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''
    assert cache_module.get_validate_certs() == True
    assert cache_module.get_plugin_name() == 'jsonfile'
    assert cache_module.get_plugin_path() == 'ansible.plugins.cache.jsonfile'

# Generated at 2022-06-17 10:33:04.328394
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-17 10:33:06.112995
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:33:12.131575
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:35:05.796421
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_plugin_name == 'jsonfile'
    assert cache.cache_plugin_timeout == 86400
    assert cache.cache_plugin_connection == ''
    assert cache.cache_plugin_prefix == ''

# Generated at 2022-06-17 10:35:06.754524
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-17 10:35:08.337605
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.get_timeout() == 86400
    assert cm.get_prefix() == ''
    assert cm.get_connection() == ''

# Generated at 2022-06-17 10:35:09.965803
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_timeout() == 86400
    assert cache_module.get_connection() == ''
    assert cache_module.get_prefix() == ''

# Generated at 2022-06-17 10:35:16.871839
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test with default values
    cache = CacheModule()
    assert cache._connection == '~/.ansible/tmp'
    assert cache._prefix == 'ansible-facts'
    assert cache._timeout == 86400

    # Test with custom values
    cache = CacheModule(connection='/tmp', prefix='test', timeout=3600)
    assert cache._connection == '/tmp'
    assert cache._prefix == 'test'
    assert cache._timeout == 3600

# Generated at 2022-06-17 10:35:17.661586
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:35:18.414137
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-17 10:35:22.034055
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': '/tmp/ansible_cache'})

# Generated at 2022-06-17 10:35:26.803933
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400
    assert cache.get_prefix() == ''
    assert cache.get_connection() == ''

# Generated at 2022-06-17 10:35:32.140916
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._timeout == 86400
    assert cache._prefix == 'ansible-fact'
    assert cache._load_cache_plugin_options()
    assert cache._get_cache_file_path('localhost') == 'localhost.json'