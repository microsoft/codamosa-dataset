

# Generated at 2022-06-11 13:15:14.851515
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-11 13:15:15.682161
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(hasattr(CacheModule, "set_options"))

# Generated at 2022-06-11 13:15:16.515097
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({}, [])

# Generated at 2022-06-11 13:15:21.273793
# Unit test for constructor of class CacheModule
def test_CacheModule():
     test_cache_plugin_connection = "/etc/ansible/facts_cache"
     test_cache_plugin_prefix = ""
     test_cache_plugin_timeout = 86400
     cm = CacheModule()
     assert cm._connection == test_cache_plugin_connection
     assert cm._prefix == test_cache_plugin_prefix
     assert cm._timeout == test_cache_plugin_timeout

# Generated at 2022-06-11 13:15:23.336149
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    cm = CacheModule()

    assert (isinstance(cm, CacheModule))
    assert (cm._load is not None)
    assert (cm._dump is not None)

# Generated at 2022-06-11 13:15:23.968341
# Unit test for constructor of class CacheModule
def test_CacheModule():
  cache = CacheModule()

# Generated at 2022-06-11 13:15:25.627904
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        CacheModule()
    except Exception:
        raise AssertionError('Failed to instantiate class CacheModule')

# Generated at 2022-06-11 13:15:28.566914
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule({})
    assert module._get_cache_basedir() == '/tmp/ansible-local-cache/jsonfile', module._get_cache_basedir()

# Generated at 2022-06-11 13:15:32.225986
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_module = CacheModule()
    if test_module is None:
        print("test CacheModule() OK")
    else:
        print("test CacheModule() Failed")

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-11 13:15:35.838234
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.CACHE_TYPE == 'memory'
    assert cm.ext == '.json'
    assert cm._connection is None
    assert cm._prefix is None
    assert cm._timeout == 86400


# Generated at 2022-06-11 13:15:38.098687
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule() is not None

# Generated at 2022-06-11 13:15:38.594685
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-11 13:15:39.721742
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ob = CacheModule()
    assert ob is not None

# Generated at 2022-06-11 13:15:42.771866
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert hasattr(cache, 'name') and hasattr(cache, 'get') and hasattr(cache, 'set') and hasattr(cache, 'delate') and hasattr(cache, 'flush')

# Generated at 2022-06-11 13:15:45.967635
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Constructor of class CacheModule
    # Class CacheModule(BaseFileCacheModule)
    CacheModule()

    #   def _load(self, filepath):

    #   def _dump(self, value, filepath):

# Generated at 2022-06-11 13:15:46.657927
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-11 13:15:47.316590
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-11 13:15:50.690984
# Unit test for constructor of class CacheModule
def test_CacheModule():
    global cache_module
    cache_module = CacheModule()
    cache_module._load('/tmp/json_test')
    cache_module._dump({"key":"value"}, '/tmp/json_test')

# Generated at 2022-06-11 13:15:53.968383
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = '/tmp'
    timeout = 7200
    connection = CacheModule({'_uri': cache_dir, '_timeout': timeout})
    assert connection.get_basedir() == cache_dir
    assert connection.get_timeout() == timeout

# Generated at 2022-06-11 13:16:03.760146
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # param _uri
    uri_path = "/tmp/ansible/tmp"
    cache_instance = CacheModule(uri = uri_path)
    result_uri = cache_instance.get_uri()
    assert result_uri == uri_path

    # param _uri and _prefix
    cache_instance = CacheModule(uri = uri_path, prefix = "prefix")
    result_uri = cache_instance.get_uri()
    assert result_uri == uri_path

    # param _uri and _timeout
    timeout = 5
    cache_instance = CacheModule(uri = uri_path, timeout = timeout)
    result_timeout = cache_instance.get_timeout()
    assert result_timeout == timeout

    # param _prefix and _timeout
    cache_instance = CacheModule(prefix = "prefix", timeout = timeout)

# Generated at 2022-06-11 13:16:10.934801
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    # Ensure that module is constructed with the following attributes
    assert cm._cache_prefix == 'ansible-factcache/'
    assert cm._cache_lock_path == '.ansible/tmp'
    assert cm._cache_connection == '.ansible/tmp'
    assert cm._cache_timeout == 86400

# Generated at 2022-06-11 13:16:12.397478
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_mgr = CacheModule()
    assert cache_mgr

# Generated at 2022-06-11 13:16:14.126206
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin._load is not None
    assert plugin._dump is not None

# Generated at 2022-06-11 13:16:16.435374
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._prefix == ''
    assert module._timeout == 86400
    assert module._connection == ''

# Generated at 2022-06-11 13:16:23.018860
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin

    # Check ANSIBLE_CACHE_PLUGIN_CONNECTION environ.
    cache_plugin = CacheModule()
    assert cache_plugin

    # Check ANSIBLE_CACHE_PLUGIN_PREFIX environ.
    cache_plugin = CacheModule()
    assert cache_plugin

    # Check ANSIBLE_CACHE_PLUGIN_TIMEOUT environ.
    cache_plugin = CacheModule()
    assert cache_plugin

# Generated at 2022-06-11 13:16:26.446635
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.cache_path == "./"
    assert cache.cache_path_name == ''
    assert cache.cache_max_size == 0
    assert cache.cache_size == 0
    assert not cache.cache_files


# Generated at 2022-06-11 13:16:29.666485
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule({'_uri': '/tmp', '_prefix': 'prefix'})
    assert c._uri == '/tmp'
    assert c._cache_file == '/tmp/prefix.json'

# Generated at 2022-06-11 13:16:31.917007
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with codecs.open('my_file.json', 'r', encoding='utf-8') as f:
        assert 0 == f.read()

# Generated at 2022-06-11 13:16:34.075378
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)
    assert isinstance(cache, BaseFileCacheModule)


# Generated at 2022-06-11 13:16:34.640481
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-11 13:16:41.041478
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), BaseFileCacheModule)

# Generated at 2022-06-11 13:16:43.282540
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert(module._load == CacheModule._load)
    assert(module._dump == CacheModule._dump)

# Generated at 2022-06-11 13:16:45.893212
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, '__init__')
    assert hasattr(CacheModule, 'get')
    assert hasattr(CacheModule, 'set')


# Generated at 2022-06-11 13:16:46.529138
# Unit test for constructor of class CacheModule
def test_CacheModule():
	a = CacheModule()

# Generated at 2022-06-11 13:16:47.437741
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module

# Generated at 2022-06-11 13:16:48.371089
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule('/tmp') == None

# Generated at 2022-06-11 13:16:49.604157
# Unit test for constructor of class CacheModule
def test_CacheModule():
    fc = CacheModule()
    assert isinstance(fc, BaseFileCacheModule)

# Generated at 2022-06-11 13:16:52.447356
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = '/tmp/ansible/cache/'
    prefix = 'TEST'
    cache = CacheModule(uri=uri, prefix=prefix)
    assert(cache.cachefile == '/tmp/ansible/cache/TEST.json')
    assert(cache._timeout == 86400)

# Generated at 2022-06-11 13:17:00.335186
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.get("localhost", "ansible_facts_cache") == (False, None)
    assert cm.set("localhost", "ansible_facts_cache", "cache") == True
    assert cm.get("localhost", "ansible_facts_cache") == (True, "cache")
    assert cm.keys() == ["localhost"]
    assert cm.contains("localhost", "ansible_facts_cache") == True
    assert cm.delete("localhost", "ansible_facts_cache") == True
    assert cm.delete("localhost") == True
    assert cm.delete() == True

# Generated at 2022-06-11 13:17:04.585997
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_timeout': 60, '_prefix': 'test_'})
    expected_cache_timeout = 60
    expected_cache_prefix = 'test_'

    assert cache.cache_timeout == expected_cache_timeout
    assert cache.cache_prefix == expected_cache_prefix


# Generated at 2022-06-11 13:17:15.822791
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-11 13:17:17.308368
# Unit test for constructor of class CacheModule
def test_CacheModule():
    a = CacheModule()
    assert a is not None

# Generated at 2022-06-11 13:17:20.912642
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test = CacheModule()
    assert test is not None
    assert test.file_extension == '.cache'
    assert test.timeout == 86400
    test.set("test", "key", "value")
    assert test.get("test", "key") == "value"

# Generated at 2022-06-11 13:17:24.341930
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    cache = CacheModule('/tmp', 'test', 0)
    assert cache._prefix == 'test'
    assert cache._timeout == 0

# Generated at 2022-06-11 13:17:28.722378
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with open('cache_unit_test_1.json', 'r') as f:
        test_json = json.load(f, cls=AnsibleJSONDecoder)
    print(test_json)
    cm = CacheModule('test')._dump(test_json, 'test.json')
    assert cm is not None

# Generated at 2022-06-11 13:17:36.832940
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ansible_cache_connection_path = "/home/ansible/cache"
    ansible_cache_plugin_prefix = "ansible_host_"
    ansible_cache_plugin_timeout = 86400  #24 * 60 * 60

    cache = CacheModule(ansible_cache_connection_path, ansible_cache_plugin_prefix, ansible_cache_plugin_timeout)
    assert cache.filecache == {}
    assert cache.timeout == ansible_cache_plugin_timeout
    assert cache.file_prefix == ansible_cache_plugin_prefix
    assert cache.file_path == "/home/ansible/cache"

# Generated at 2022-06-11 13:17:37.446494
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-11 13:17:41.252990
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = {
        "foo": "this is foo",
        "bar": "this is bar",
        "baz": {
            "one": 1,
            "two": 2
        }
    }

    cache = CacheModule()
    cache.set("ansible_test", data)
    assert cache.get("ansible_test") == data

# Generated at 2022-06-11 13:17:41.965281
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-11 13:17:47.185663
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = 'some/path'
    timeout = 60
    prefix = 'prefix'
    cm = CacheModule(path, timeout, prefix)
    assert cm._plugin_options['_uri'] == path
    assert cm._plugin_options['_prefix'] == prefix
    assert cm._plugin_options['_timeout'] == timeout


# Generated at 2022-06-11 13:18:10.959095
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-11 13:18:14.490237
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    # Verify the constructor of class CacheModule returns the expected result
    assert cache_plugin.__class__.__name__ == "CacheModule"
    assert cache_plugin._timeout == 86400


# Generated at 2022-06-11 13:18:17.871639
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = '/tmp/ansible-test'
    cache = CacheModule({'_uri': uri})
    assert cache._basedir == uri
    assert cache._timeout == 86400


# Generated at 2022-06-11 13:18:18.820145
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule().__init__() == None

# Generated at 2022-06-11 13:18:21.351471
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule({'_uri': 'localhost'})
    assert cm is not None

    assert cm.lock_path is not None
    assert cm.cache_lock is not None

# Generated at 2022-06-11 13:18:23.217360
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule(connection='/path/to/cache', config={'timeout': 2})
    assert isinstance(module, CacheModule)

# Generated at 2022-06-11 13:18:24.677817
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin._prefix == ''
    assert cache_plugin._timeout == 86400

# Generated at 2022-06-11 13:18:25.638321
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)

# Generated at 2022-06-11 13:18:29.727671
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin.get_cache_prefix() == 'ansible-cache'
    assert plugin.get_cache_timeout() == 86400
    assert plugin.get_cache_uri() == '~/.ansible/tmp/ansible-fact-cache'
    assert plugin.get_cache_plugin_name() == 'jsonfile'



# Generated at 2022-06-11 13:18:30.458654
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())


# Generated at 2022-06-11 13:19:16.710785
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """ test if a CacheModule can be instantiated"""
    a = CacheModule(None)
    assert a != None


# Generated at 2022-06-11 13:19:17.598806
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(None, None, None, None, None, None)

# Generated at 2022-06-11 13:19:22.205391
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os.path
    import sys
    import tempfile

    (fd, path) = tempfile.mkstemp(prefix='ansible_test_')

    try:
        cache = CacheModule(path)

        assert cache.file != None
        assert cache._connection == path
        
        cache._load(cache._get_file_path(cache.file))
    finally:
        os.close(fd)
        os.unlink(path)

# Generated at 2022-06-11 13:19:23.740851
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache = CacheModule()
    cache.set('testcache', 'testvalue')
    cache.get('testcache')

# Generated at 2022-06-11 13:19:25.721852
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.get_basedir() == 'ansible-cachedir'

# Generated at 2022-06-11 13:19:26.244350
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

# Generated at 2022-06-11 13:19:27.380987
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # This will fail if an exception is raised
    assert CacheModule()

# Generated at 2022-06-11 13:19:28.753585
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule('/tmp/.ansible/caching/facts') == None

# Generated at 2022-06-11 13:19:31.773346
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = "/root/.ansible/tmp/ansible-cache"
    my_module = CacheModule(cache_dir)
    assert isinstance(my_module, CacheModule)
    assert my_module._connection[0] == cache_dir

# Generated at 2022-06-11 13:19:36.237137
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = {
        "some": "data",
        "a_list": [1, 2, 3],
        "a_dict": {"a_key": "a_value"},
        "unicode": u'\u2713',
    }
    connection = '/tmp/test_cache'
    prefix = 'test_prefix'
    timeout = 1234
    cache_module = CacheModule(connection=connection,
                               prefix=prefix,
                               timeout=timeout)
    cache_module.flush()
    # Test set method
    cache_module.set('test_key', data)
    assert data == cache_module.get('test_key')

    # Test get_multi method
    cache_module.set('test_key1', data)
    cache_module.set('test_key2', data)

# Generated at 2022-06-11 13:21:14.447965
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

if __name__ == '__main__':
    print(test_CacheModule())

# Generated at 2022-06-11 13:21:15.527875
# Unit test for constructor of class CacheModule
def test_CacheModule():
    a = CacheModule()
    assert a._timeout == 86400

# Generated at 2022-06-11 13:21:16.052086
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-11 13:21:17.329630
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin.file_extension == '.json'

# Generated at 2022-06-11 13:21:17.836336
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-11 13:21:19.242306
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({})
    assert cache.plugin_name == 'jsonfile'
    assert cache.timeout == 86400

# Generated at 2022-06-11 13:21:20.171483
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ins = CacheModule()
    assert ins is not None

# Generated at 2022-06-11 13:21:28.980331
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = "cachedir"
    cache_connection_dir = "Cacheconnectiondir"
    timeout = 5
    prefix = "test_"
    cache_plugin_class = "jsonfile"
    cache_plugin_spec = 'ansible.plugins.cache.%s' % cache_plugin_class

    try:
        plugin = CacheModule.load_plugin(cache_plugin_class)
    except Exception as e:
        print("Failed to initialize CacheModule base class with error: %s" % e)

    try:
        instance = plugin(cache_plugin_spec, cache_timeout=timeout, cache_connection=cache_connection_dir, fact_caching_prefix=prefix)
    except Exception as e:
        print("Failed to initialize CacheModule with error: %s" % e)
    assert instance.cache_timeout == timeout

# Generated at 2022-06-11 13:21:34.018481
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Arrange
    cache_plugin_connection = '/path/to/cache/'
    cache_plugin_prefix = 'prefix'
    cache_plugin_timeout = 1000
    # Act
    cm = CacheModule(cache_plugin_connection,
                     cache_plugin_prefix,
                     cache_plugin_timeout)
    # Assert
    assert cm is not None
    assert cm._connection == cache_plugin_connection
    assert cm._prefix == cache_plugin_prefix
    assert cm._timeout == cache_plugin_timeout

# Generated at 2022-06-11 13:21:34.800173
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._connection == 'ansible_facts'