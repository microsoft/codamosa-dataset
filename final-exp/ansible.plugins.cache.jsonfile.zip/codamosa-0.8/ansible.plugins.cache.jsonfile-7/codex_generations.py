

# Generated at 2022-06-11 13:15:26.999949
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    if cm.cache_type != 'jsonfile':
        raise ValueError("CacheModule instance cache_type, %s, not as expected, %s" % 'jsonfile', cm.cache_type)

    # check that BaseFileCacheModule.add_to_cache is set correctly
    if not isinstance(cm.add_to_cache, BaseFileCacheModule.add_to_cache.__class__):
        raise ValueError("CacheModule instance add_to_cache, %s, not as expected, %s" %
                         ('BaseFileCacheModule.add_to_cache', cm.add_to_cache))

    # check that BaseFileCacheModule.get_from_cache is set correctly

# Generated at 2022-06-11 13:15:28.938787
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'foo', '_options': {}})

# Generated at 2022-06-11 13:15:30.016738
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-11 13:15:34.950746
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj.get_cache_path() == '~/.ansible/tmp'
    assert obj._options['_timeout'] == 86400
    assert obj._options['_prefix'] == 'ansible_'
    assert obj.get_timeout() == 86400
    assert obj.get_prefix() == 'ansible_'

# Generated at 2022-06-11 13:15:42.154367
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import BaseFileCacheModule
    import os

    # Setup test
    test_cache = CacheModule()
    uri = os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION']

    # Test init
    if uri != test_cache._connection:
        raise Exception('Incorrect _connection')
    if 'ansible-fact-cache-' != test_cache._prefix:
        raise Exception('Incorrect _prefix')
    if 86400 != test_cache._timeout:
        raise Exception('Incorrect _timeout')
    if test_cache._cache_files_mode != BaseFileCacheModule.DEFAULT_CACHE_FILE_MODE:
        raise Exception('Incorrect _cache_files_mode')

    # Test connection
    if uri != test_cache.get_connection():
        raise

# Generated at 2022-06-11 13:15:47.533121
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert hasattr(x, '_load')
    assert hasattr(x, '_dump')
    assert hasattr(x, '_get')
    assert hasattr(x, '_set')
    assert hasattr(x, '_del')
    assert hasattr(x, 'flush')
    assert hasattr(x, 'show')

# Generated at 2022-06-11 13:15:51.672463
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.loader import cache_loader
    cache_plugin = cache_loader.get('jsonfile')
    print(cache_plugin)
    print(cache_plugin.get_options())
    print(cache_plugin.get_cache_plugin_options())

# Generated at 2022-06-11 13:15:53.423370
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, '_load')
    assert hasattr(CacheModule, '_dump')

# Generated at 2022-06-11 13:15:55.541459
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)
    assert issubclass(CacheModule, object)


# Generated at 2022-06-11 13:15:57.722712
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule(play_context=None)
    assert isinstance(module, CacheModule)
    assert isinstance(module, BaseFileCacheModule)

# Generated at 2022-06-11 13:16:07.611135
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection='connection'
    prefix='prefix'
    timeout=3600
    cm = CacheModule()
    assert isinstance(cm, CacheModule), 'Create CacheModule failed!'
    assert cm._connection == '~/.ansible/tmp', 'Default connection is wrong!'
    assert cm._prefix == 'ansible_facts_', 'Default prefix is wrong!'
    assert cm._timeout == 86400, 'Default timeout is wrong!'

    cm = CacheModule(connection=connection, prefix=prefix, timeout=timeout)
    assert isinstance(cm, CacheModule), 'Create CacheModule failed!'
    assert cm._connection == connection, '_connection is wrong!'
    assert cm._prefix == prefix, '_prefix is wrong!'
    assert cm._timeout == timeout, '_timeout is wrong!'

# Unit test of the method _load in CacheModule

# Generated at 2022-06-11 13:16:09.761350
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load("") == None
    assert cache_module._dump("", "") == None

# Generated at 2022-06-11 13:16:11.508734
# Unit test for constructor of class CacheModule
def test_CacheModule():
  from ansible.plugins.cache.jsonfile import CacheModule
  cm = CacheModule(connection=None)

# Generated at 2022-06-11 13:16:14.381864
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)
    assert CacheModule.__module__ == 'ansible.plugins.cache.jsonfile'
    # check for instantiation without params
    assert CacheModule()

# Generated at 2022-06-11 13:16:16.755892
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    # Assert that the attributes are created as expected
    assert module._connection is None
    assert module._timeout == 86400

# Generated at 2022-06-11 13:16:24.678468
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_plugin = CacheModule()
    assert test_plugin.plugin == 'jsonfile'
    assert test_plugin.file_extension == '.cache'
    assert test_plugin.timestamp_format == '%Y-%m-%dT%H:%M:%SZ'
    assert test_plugin.max_cache_size == None
    assert test_plugin._connection.get_option('_uri') == ''
    assert test_plugin._connection.get_option('_prefix') == 'ansible_fact_cache'
    assert test_plugin._connection.get_option('_timeout') == 86400

# Generated at 2022-06-11 13:16:27.534652
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule(None)
    # check if instance variable _password_salt has been set
    assert cache_plugin._password_salt

# Generated at 2022-06-11 13:16:28.870932
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.file_extension == '.json'

# Generated at 2022-06-11 13:16:30.317877
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert not CacheModule() is None

# Generated at 2022-06-11 13:16:36.045966
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Test the constructor.
    """
    cache_plugin = CacheModule()
    assert cache_plugin.tmpfile.startswith('/tmp/ansible_cache_')
    assert cache_plugin.tmpfile.endswith('.json')
    assert cache_plugin.tmpfile.endswith('.json')
    assert cache_plugin.timeout == 86400
    assert cache_plugin.plugin_name == 'jsonfile'

# Generated at 2022-06-11 13:16:50.725909
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create temporary file for the CacheModule class
    from tempfile import NamedTemporaryFile
    # Create instance of CacheModule
    cache_instance = CacheModule()
    # Set the temporary file to the _uri for the cache instance
    cache_instance._uri = NamedTemporaryFile().name
    # Create empty json object to save as cache
    test_dict = {"test_key" : "test_value"}
    a = cache_instance.set("test_file", test_dict)
    # Should return None if the cache is set
    assert a == None
    # Should return cache item
    b = cache_instance.get("test_file")
    assert b == test_dict
    # Should return None, cache doesn't exist
    c = cache_instance.get("test_file1")
    assert c == None

# Generated at 2022-06-11 13:16:55.713575
# Unit test for constructor of class CacheModule
def test_CacheModule():
    options = {'_uri': 'cache_plugin_connection',
               '_prefix': 'ansible_facts',
               '_timeout': 86400}
    result = CacheModule(None, options=options)

    # result is an instance of `ansible.plugins.cache.FileCacheModule`
    assert isinstance(result, CacheModule)

# Generated at 2022-06-11 13:17:05.784255
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Unit test for constructor of class CacheModule
    """
    cache_config = {
        '_timeout': 1000,
        '_uri': '/tmp'
    }
    cache_instance = CacheModule()
    cache_instance.set_options(cache_config)

    assert cache_instance.get_timeout() == 1000

    cache_config['_uri'] = ''
    try:
        cache_instance.set_options(cache_config)
        raise AssertionError('CacheModule did not throw exception')
    except:
        pass

    cache_config['_uri'] = None
    try:
        cache_instance.set_options(cache_config)
        raise AssertionError('CacheModule did not throw exception')
    except:
        pass


# Generated at 2022-06-11 13:17:06.407782
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()

# Generated at 2022-06-11 13:17:09.070322
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule
    assert cacheModule._timeout == 86400
    assert cacheModule._prefix is None
    assert cacheModule._connection is None

# Generated at 2022-06-11 13:17:11.261162
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({})
    assert isinstance(cache, CacheModule)
    assert isinstance(cache, BaseFileCacheModule)

# Generated at 2022-06-11 13:17:16.146757
# Unit test for constructor of class CacheModule
def test_CacheModule():
    my_cache_module = CacheModule(None, None, None)
    if my_cache_module.root_path is None:
        raise RuntimeError("Root path should be set after instantiation")
    if not my_cache_module.plugin_name.startswith("jsonfile"):
        raise RuntimeError("Plugin name is wrong")
    if my_cache_module.timeout != 86400:
        raise RuntimeError("Timeout should be set to default after instantiation")

# Generated at 2022-06-11 13:17:17.024754
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-11 13:17:19.067965
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load("") == None
    assert cache_module._dump("", "") == None

# Generated at 2022-06-11 13:17:25.486647
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile

    temp_path = tempfile.mkdtemp()

    # The caching plugin depends on an environment variable.
    # We need a temp directory for it.
    import os
    os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = temp_path

    test_cache = CacheModule()
    assert isinstance(test_cache, CacheModule)
    assert temp_path == test_cache._connection

# Generated at 2022-06-11 13:17:41.015957
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    cm._load = lambda x: x
    cm._dump = lambda x: x
    # We do not expect any output from this unit test
    cm.set('testkey', 'testval')
    cm.get('testkey')
    cm.get_multi(['testkey'])
    cm.delete('testkey')
    cm.flush()

# Generated at 2022-06-11 13:17:42.952027
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({})
    assert(cache.root == "/tmp/ansible-fact-cache")

# Generated at 2022-06-11 13:17:45.301353
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cs = CacheModule()
    assert cs.cache_dir == '~/.ansible/tmp/ansible-cach-plugin'

# Generated at 2022-06-11 13:17:57.028248
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection=None
    prefix=None
    timeout=None
    plugin = CacheModule(connection=connection,prefix=prefix,timeout=timeout)

    # Mock method BaseFileCacheModule._load
    def mock_load(self, filepath):
        return {'foo': 'bar'}
    plugin._load = mock_load

    # Mock method BaseFileCacheModule._dump
    plugin._dump = lambda self, value, filepath: None

    host = "TEST_HOST"
    value = plugin.get(host)
    assert value == None, "_load should be called when value is not found"
    value = plugin.set(host, 'foo')
    assert plugin._cache[host] == 'foo', "_load should be called when value is not found"
    value = plugin.get(host)

# Generated at 2022-06-11 13:18:01.012952
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_vars_json_file = 'ansible/test/units/plugins/cache/test_vars.json'
    m = CacheModule({'_uri': test_vars_json_file, '_prefix': 'test', '_timeout': '3600'})
    assert m.prefix == 'test'

# Generated at 2022-06-11 13:18:06.509469
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create an instance of the CacheModule class
    cache_module = CacheModule()

    # Check cache_name
    assert cache_module.cache_name == 'jsonfile'

    # Check file_suffix
    assert cache_module.file_suffix == '.json'

    # Check default_timeout
    assert cache_module.default_timeout == 86400

    # Check options
    assert cache_module.options == {'_uri': {'default': None, 'required': True},
                                    '_prefix': {'default': None},
                                    '_timeout': {'default': 86400}}

# Generated at 2022-06-11 13:18:10.595581
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(
        '',
        uri='/tmp/test',
        timeout='86400',
        prefix='test')

# Generated at 2022-06-11 13:18:11.584407
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module is not None

# Generated at 2022-06-11 13:18:12.316199
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert True

# Generated at 2022-06-11 13:18:15.545339
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._plugin_name == 'jsonfile'
    assert c._base_path is None
    assert c._timeout == 86400

# Generated at 2022-06-11 13:18:29.898963
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin_settings = {'_uri': '~/home/ec2-user'}
    cache_plugin = CacheModule(cache_plugin_settings, None, 0)
    assert cache_plugin

# Generated at 2022-06-11 13:18:30.984545
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-11 13:18:32.706039
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), BaseFileCacheModule),\
        "CacheModule constructor doesn't return an instance of class BaseFileCacheModule"

# Generated at 2022-06-11 13:18:33.423674
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-11 13:18:37.279273
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

    # test the __init__ function
    assert cache_module._timeout == 86400  # pylint: disable=protected-access
    assert cache_module._connection == None  # pylint: disable=protected-access
    assert cache_module._prefix == None  # pylint: disable=protected-access

# Generated at 2022-06-11 13:18:42.694338
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile
    connection = tempfile.mkdtemp()
    prefix = u'asdf'
    timeout = 12345
    cache = CacheModule({'_uri': connection, '_prefix': prefix, '_timeout': timeout})
    assert cache.timeout == timeout
    assert cache.basedir == connection
    assert cache.prefix == prefix
    os.rmdir(connection)

# Generated at 2022-06-11 13:18:49.526528
# Unit test for constructor of class CacheModule
def test_CacheModule():
  m = CacheModule()
  assert m.get_timeout() == 86400
  assert m.get_connection() == None
  assert m.get_prefix() == None
  assert m.get_configured_timeout() == 86400
  assert m.get_configured_prefix() == "ansible_facts_"
  assert m.get_configured_connection() == None
  assert m.get_cache_plugin_options() != None

# Generated at 2022-06-11 13:18:51.405092
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Constructor test
    """
    assert(CacheModule(None) is not None)

# Generated at 2022-06-11 13:18:54.843225
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = '/tmp/bogusfile/'
    prefix = 'bogus_'
    timeout = 86400
    cache_plugin = CacheModule(uri, prefix, timeout)

    assert( cache_plugin._uri == uri )
    assert( cache_plugin._prefix == prefix )
    assert( cache_plugin._timeout == timeout )

# Generated at 2022-06-11 13:18:56.430644
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._load == CacheModule._load
    assert module._dump == CacheModule._dump

# Generated at 2022-06-11 13:19:20.527695
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_cache_module = CacheModule()
    assert test_cache_module


# Generated at 2022-06-11 13:19:21.892665
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)



# Generated at 2022-06-11 13:19:25.321145
# Unit test for constructor of class CacheModule
def test_CacheModule():
    config = {'_uri': '../test/'}
    cache = CacheModule()
    cache.set_options(config)
    assert cache._uri == '../test/'
    assert cache._prefix is None
    assert cache._timeout == 86400


# Generated at 2022-06-11 13:19:34.172550
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert hasattr(CacheModule, '_load')
    assert hasattr(CacheModule, '_dump')
    assert hasattr(CacheModule, '_cache_key')
    assert hasattr(CacheModule, 'get')
    assert hasattr(CacheModule, 'set')
    assert hasattr(CacheModule, 'keys')
    assert hasattr(CacheModule, 'contains')
    assert hasattr(CacheModule, 'delete')
    assert hasattr(CacheModule, 'flush')
    assert hasattr(CacheModule, 'copy')
    assert hasattr(CacheModule, 'copy_to_file')
    assert hasattr(CacheModule, 'copy_from_file')
    assert hasattr(CacheModule, 'get_bin_path')
    assert hasattr(CacheModule, 'is_executable')

# Generated at 2022-06-11 13:19:36.966638
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_dir = None
    test_timeout = None
    test_prefix = None
    cacheModule = CacheModule( test_dir, test_timeout, test_prefix)
    assert cacheModule != None


# Generated at 2022-06-11 13:19:37.792477
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm

# Generated at 2022-06-11 13:19:38.973250
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-11 13:19:42.538507
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({})
    assert cache._uri == '~/.ansible/tmp'
    assert cache._prefix == 'ansible-factcache'
    assert cache._timeout == 86400


if __name__ == '__main__':
    # Unit test code
    test_CacheModule()

# Generated at 2022-06-11 13:19:43.783904
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-11 13:19:46.943734
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._uri == 'ANSIBLE_CACHE_PLUGIN_CONNECTION'
    assert CacheModule._prefix == 'ANSIBLE_CACHE_PLUGIN_PREFIX'
    assert CacheModule._timeout == 'ANSIBLE_CACHE_PLUGIN_TIMEOUT'

# Generated at 2022-06-11 13:20:40.296836
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj._timeout == 86400
    assert obj._prefix == ''

# Generated at 2022-06-11 13:20:41.499949
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-11 13:20:42.036188
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()

# Generated at 2022-06-11 13:20:42.774886
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-11 13:20:45.003119
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, BaseFileCacheModule)
    assert cm.timeout == 86400



# Generated at 2022-06-11 13:20:45.546857
# Unit test for constructor of class CacheModule
def test_CacheModule():
  x = CacheModule()

# Generated at 2022-06-11 13:20:46.735904
# Unit test for constructor of class CacheModule
def test_CacheModule():
    con = CacheModule()
    assert isinstance(con, CacheModule)

# Generated at 2022-06-11 13:20:49.205799
# Unit test for constructor of class CacheModule
def test_CacheModule():
    args = {'_uri':'/tmp','_prefix':'abc','_timeout': 3600}
    ca = CacheModule(args)
    print (ca._base_dir)
    print (ca._timeout)

# Generated at 2022-06-11 13:20:52.334986
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """This function is used to test constructor of class CacheModule."""
    cache_module = CacheModule(task_vars=dict(fact_caching="jsonfile"))
    assert 'jsonfile' == cache_module._connection



# Generated at 2022-06-11 13:20:56.129666
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule(task_vars=dict(ANSIBLE_CACHE_PLUGIN_CONNECTION="/tmp/ansible_test", ANSIBLE_CACHE_PLUGIN_TIMEOUT=30))
    assert obj._timeout == 30
    assert obj._base_path == "/tmp/ansible_test"

# Generated at 2022-06-11 13:22:50.697646
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = "/tmp/"
    timeout = 3600
    prefix = "invalid-prefix"

    # reload constructor
    c = CacheModule(connection, timeout, prefix)

    # verify
    assert c.connection == connection
    assert c.timeout == timeout
    assert c.prefix == prefix
    assert c.cachedir == "/tmp/"


# Generated at 2022-06-11 13:22:51.977347
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-11 13:22:54.476550
# Unit test for constructor of class CacheModule
def test_CacheModule():
    result = CacheModule()
    assert result is not None

if __name__ == '__main__':
    # Unit test this module
    test_CacheModule()

# Generated at 2022-06-11 13:23:00.872019
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule('./tests/test_file_cache', 'test_prefix', 3600).filename_prefix == 'test_prefix'
    assert CacheModule('./tests/test_file_cache', 'test_prefix', 3600).valid_extensions == ('.cache',)
    assert CacheModule('./tests/test_file_cache', 'test_prefix', 3600).expire == 3600
    assert CacheModule('./tests/test_file_cache', None, 3600).filename_prefix is None
    assert CacheModule('./tests/test_file_cache', None, None).expire is None

# Generated at 2022-06-11 13:23:01.943560
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule(None)

# Generated at 2022-06-11 13:23:03.975030
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert type(cm.plugins) == dict
    assert type(cm.aliases) == list



# Generated at 2022-06-11 13:23:11.152973
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # testing with required parameters
    module = CacheModule({'_uri': '/var/tmp/ansible_cache'})

    assert module._uri == '/var/tmp/ansible_cache'
    assert module._prefix == 'ansible_facts'
    assert module._timeout == 86400

    # testing with all parameters
    module = CacheModule({'_uri': '/var/tmp/ansible_cache', '_prefix': 'ansible_cache', '_timeout': 1234})

    assert module._uri == '/var/tmp/ansible_cache'
    assert module._prefix == 'ansible_cache'
    assert module._timeout == 1234

# Generated at 2022-06-11 13:23:12.447385
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-11 13:23:15.936230
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load == None
    assert cache_module._dump == None
    assert cache_module._load('filepath') == None
    assert cache_module._dump('value', 'filepath') == None
    assert isinstance(CacheModule(), BaseFileCacheModule)


# Generated at 2022-06-11 13:23:22.269203
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        cm = CacheModule()
        assert(cm.cache_timeout == 3600)
        assert(cm.cache_prefix == u'ansible_facts_')
        assert(cm.cache_basedir == u'/tmp')
        assert(cm.cache_dirname == u'ansible-facts')
        assert(cm.cache_plugin == u'jsonfile')
    except TypeError:
        raise
    except Exception:
        assert False, "Unexpected exception raised."

# Unit tests for _load function
import os