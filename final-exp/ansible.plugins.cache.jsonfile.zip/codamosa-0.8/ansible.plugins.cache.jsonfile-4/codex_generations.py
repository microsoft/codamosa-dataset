

# Generated at 2022-06-11 13:15:24.848533
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_cache_connection = '/etc/ansible/facts'
    test_cache_timeout = '9999'
    test_cache_prefix = 'ansible_facts'
    config = {'fact_caching_connection': test_cache_connection,
              'fact_caching_timeout': test_cache_timeout,
              'fact_caching_prefix': test_cache_prefix}
    CacheModule(config)
    assert test_cache_connection == config['fact_caching_connection']
    assert test_cache_timeout == config['fact_caching_timeout']
    assert test_cache_prefix == config['fact_caching_prefix']

# Generated at 2022-06-11 13:15:27.438759
# Unit test for constructor of class CacheModule
def test_CacheModule():
    my_cache = CacheModule()
    assert isinstance(my_cache, CacheModule)
    assert isinstance(my_cache, BaseFileCacheModule)


# Generated at 2022-06-11 13:15:29.197943
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None

# Generated at 2022-06-11 13:15:32.030105
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    # First test to see if cache exists
    assert cache is not None
    # Verify type of cache is of class CacheModule
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-11 13:15:40.829349
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ansible_module = CacheModule({
        '_uri': 'htp://google.com',
        '_prefix': 'python',
        '_timeout': '10'
        })
    assert ansible_module.plugin_name == 'jsonfile'
    assert ansible_module.plugin_path == 'ansible.plugins.cache.jsonfile'
    assert ansible_module._options['_uri'] == 'htp://google.com'
    assert ansible_module._options['_prefix'] == 'python'
    assert ansible_module._options['_timeout'] == '10'
    assert ansible_module._cache_path is None
    assert ansible_module._timeout is None

# Test the load and dump method of class CacheModule
# Which will call the function _load and _dump of class CacheModule

# Generated at 2022-06-11 13:15:42.819584
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert isinstance(module, CacheModule)

# Unit tests for function _load

# Generated at 2022-06-11 13:15:48.901512
# Unit test for constructor of class CacheModule
def test_CacheModule():
    def test_uri(uri):
        cache_plugin = CacheModule()
        cache_plugin._uri = uri
        assert cache_plugin._get_path_for_host('test_host') == '/tmp/ansible_fact_cache/test_host'
        return
    test_uri('/tmp/ansible_fact_cache')
    test_uri('/tmp/ansible_fact_cache/')

# Generated at 2022-06-11 13:15:50.738383
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None, "CacheModule() failed to return a valid instance."

# Generated at 2022-06-11 13:15:52.508433
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test = CacheModule(dict(connection='.'))
    assert isinstance(test, CacheModule)

# Generated at 2022-06-11 13:15:53.130426
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-11 13:16:01.829142
# Unit test for constructor of class CacheModule
def test_CacheModule():
  test = CacheModule({ "ANSIBLE_CACHE_PLUGIN_CONNECTION": "/tmp",
                     "ANSIBLE_CACHE_PLUGIN_PREFIX": "foo",
                     "ANSIBLE_CACHE_PLUGIN_TIMEOUT": "500"})
  assert( test._connection == "/tmp" )
  assert( test._prefix == "foo" )
  assert( test._timeout == 500 )


# Generated at 2022-06-11 13:16:02.674774
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()


# Generated at 2022-06-11 13:16:03.184004
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()

# Generated at 2022-06-11 13:16:04.273462
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-11 13:16:05.442326
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachemodule = CacheModule()
    assert cachemodule is not None

# Generated at 2022-06-11 13:16:06.434671
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_obj = CacheModule()

# Generated at 2022-06-11 13:16:07.327035
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict(), '/tmp/localdir')

# Generated at 2022-06-11 13:16:09.057405
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Test CacheModule constructor
    """
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-11 13:16:11.625021
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._timeout == 86400
    assert cache_module._connection == None
    assert cache_module._prefix == None


# Generated at 2022-06-11 13:16:14.127065
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import ansible.plugins.cache.jsonfile
    config = dict(fact_caching='jsonfile')
    plugin = ansible.plugins.cache.jsonfile.CacheModule(config)

# Generated at 2022-06-11 13:16:21.298182
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = CacheModule()
    assert isinstance(connection, BaseFileCacheModule)

# Generated at 2022-06-11 13:16:22.279416
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-11 13:16:24.183006
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule(None, None)
    assert cm._plugin_name == 'jsonfile'



# Generated at 2022-06-11 13:16:26.515047
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-11 13:16:28.658984
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule._load('test.json')
    assert cacheModule._dump('test', 'test.json')

# Generated at 2022-06-11 13:16:30.458115
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert isinstance(c, CacheModule)


# Generated at 2022-06-11 13:16:37.299296
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with open('test_module.json', 'w') as outfile:
       json.dump(calculateTest(), outfile, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)
    cacheModule = CacheModule()
    print('original cache:')
    print(cacheModule._load('test_module.json'))
    print('updated cache:')
    cacheModule._dump(calculateTest(),'test_module.json')
    print(cacheModule._load('test_module.json'))


# Generated at 2022-06-11 13:16:43.793062
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_connection = '/tmp/'
    cache_timeout = 86400
    cache_prefix = ''
    cache = CacheModule()
    cache.set_options(cache_connection, cache_timeout, cache_prefix)
    assert(cache.plugin_name == 'jsonfile')
    assert(cache.plugin_path == cache_connection)
    assert(cache.cache_timeout == cache_timeout)
    assert(cache.cache_prefix == cache_prefix)


# Generated at 2022-06-11 13:16:45.558141
# Unit test for constructor of class CacheModule
def test_CacheModule():
    myCache = CacheModule()
    assert(isinstance(myCache, CacheModule))
test_CacheModule()

# Generated at 2022-06-11 13:16:50.092248
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import PluginLoader

    cache_plugin = PluginLoader.get('jsonfile', 'CacheModule')
    plugin = cache_plugin()

    assert hasattr(cache_plugin, '_load')
    assert hasattr(cache_plugin, '_dump')
    assert hasattr(plugin, '_options')
    assert hasattr(plugin, '_display.warning')

# Generated at 2022-06-11 13:16:56.738648
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.timeout == 86400

# Generated at 2022-06-11 13:16:59.973126
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load is not None
    assert cache._dump is not None
    assert cache._mtime is not None
    assert cache._load_update_file_if_changed_newer is not None

# Generated at 2022-06-11 13:17:01.007882
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)

# Generated at 2022-06-11 13:17:02.424341
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({}).__class__.__name__ == 'CacheModule'

# Generated at 2022-06-11 13:17:03.370369
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module

# Generated at 2022-06-11 13:17:04.962862
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_timeout() == 86400

# Generated at 2022-06-11 13:17:09.349592
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._connection is None
    assert cache_module._timeout == 86400
    assert cache_module._prefix == 'ansible-facts'
    assert cache_module._load_cache == CacheModule._load
    assert cache_module._dump_cache == CacheModule._dump

# Generated at 2022-06-11 13:17:10.763530
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachemodule = CacheModule()
    assert cachemodule is not None

# Generated at 2022-06-11 13:17:12.228109
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    test case for CacheModule class
    """
    p = CacheModule()
    assert p._connection._prefix == 'ansible_fact_cache_'  # pylint:disable=protected-access

# Generated at 2022-06-11 13:17:16.622273
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_ConnectionCache = CacheModule()
    assert(test_ConnectionCache.cache_plugin_timeout == 86400)
    test_ConnectionCache.hash_digest = 'foo'
    assert(test_ConnectionCache.cache_plugin_prefix == 'ansible_lvm_')
    test_ConnectionCache._connection = 'TestConnection'
    assert(test_ConnectionCache.cache_plugin_connection == 'TestConnection')

# Generated at 2022-06-11 13:17:29.072048
# Unit test for constructor of class CacheModule
def test_CacheModule():
    global cache
    cache = CacheModule()
    assert cache.plugin_serializer == 'json'

# Generated at 2022-06-11 13:17:34.241988
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = '/tmp'
    prefix = 'test_cache_prefix'
    timeout = '1000'

    cacheModule = CacheModule(uri, prefix, timeout)

    assert cacheModule.plugin_name == 'jsonfile'
    assert cacheModule.plugin_path == '/tmp'
    assert cacheModule.plugin_prefix == 'test_cache_prefix'
    assert cacheModule.plugin_timeout == 1000

# Generated at 2022-06-11 13:17:35.818341
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cach = CacheModule()
    assert isinstance(cach, BaseFileCacheModule)

# Generated at 2022-06-11 13:17:37.981840
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    Set up a fake cache for testing.
    :return:
    '''
    cache = CacheModule()
    return cache._load()

# Generated at 2022-06-11 13:17:39.313183
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_class = CacheModule()
    assert cache_module_class._connection == "/tmp/ansible_fact_cache"

# Generated at 2022-06-11 13:17:41.781348
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Check for invalid args
    try:
        CacheModule()
    except TypeError:
        pass
    else:
        assert False, "Calling constructor with no args should fail, but it did not"



# Generated at 2022-06-11 13:17:44.546699
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.cache_dir == None
    assert cache_module._timeout == 86400
    assert cache_module._prefix == None

# Generated at 2022-06-11 13:17:47.247252
# Unit test for constructor of class CacheModule
def test_CacheModule():
    fc = CacheModule(config=dict())
    assert fc


# unit test for method _load of class CacheModule

# Generated at 2022-06-11 13:17:49.956347
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.connection == None
    assert module.prefix == None
    assert module.timeout == 86400

# Generated at 2022-06-11 13:17:56.297061
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.utils.path import makedirs_safe

    import tempfile
    tmp_dir = tempfile.mkdtemp()
    makedirs_safe(tmp_dir)

    try:
        cache = CacheModule({'_uri': tmp_dir})
        cache.set('foo', 'bar')
        assert cache.get('foo') == 'bar'
    finally:
        import shutil
        shutil.rmtree(tmp_dir)

# Generated at 2022-06-11 13:18:19.252431
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert x._OptionClass is None
    assert x._options is not None

# Generated at 2022-06-11 13:18:23.452915
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    When an object is created and the constructor is used we want to make sure it
    has the correct attributes for the plugin.
    '''
    temp_cache = CacheModule()
    assert temp_cache._options['_prefix'] == 'ansible-fact'
    assert temp_cache._options['_timeout'] == 86400

# Generated at 2022-06-11 13:18:24.285093
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), BaseFileCacheModule)

# Generated at 2022-06-11 13:18:30.002678
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test defaults
    cache = CacheModule()
    assert cache._connection.endswith('/cache')
    assert cache._prefix == 'ansible_facts_'
    assert cache._timeout == 86400

    # Test user provided values
    connection = '/tmp'
    prefix = 'ansible_facts_'
    timeout = 3000
    cache = CacheModule({'_uri': connection, '_prefix': prefix, '_timeout': timeout})
    assert cache._connection == connection
    assert cache._prefix == prefix
    assert cache._timeout == timeout

# Generated at 2022-06-11 13:18:35.737891
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Use defaults
    cache_plugin = CacheModule()
    assert cache_plugin._timeout == 86400  # the default

    # Use custom settings
    options = {'_uri': './testuri', '_prefix': 'testprefix', '_timeout': '3600'}
    cache_plugin = CacheModule(options)
    assert cache_plugin._connection == './testuri'
    assert cache_plugin._prefix == 'testprefix'
    assert cache_plugin._timeout == 3600
    assert cache_plugin._extension == 'json'

# Generated at 2022-06-11 13:18:38.646599
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.lock_path is None
    assert cache._options == {'_uri': None,
                              '_prefix': '',
                              '_timeout': 86400}

# Generated at 2022-06-11 13:18:39.847488
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # TODO
    assert False


# Generated at 2022-06-11 13:18:41.893183
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Test to create an instance of CacheModule
    """
    obj = CacheModule()
    assert obj is not None

# Generated at 2022-06-11 13:18:44.326337
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.CacheModule

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-11 13:18:44.961235
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-11 13:19:07.170112
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()

# Generated at 2022-06-11 13:19:08.394037
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-11 13:19:12.149181
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._cachefile_extension == '.json'
    assert cache_module._connection is None
    assert cache_module._expires is None
    assert cache_module._dump == CacheModule._dump
    assert cache_module._load == CacheModule._load

# Generated at 2022-06-11 13:19:15.269441
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.filename == 'ansible-fact-cache'
    assert cache_plugin._timeout == 86400
    assert cache_plugin._connection is None
    assert cache_plugin._prefix is None

# Generated at 2022-06-11 13:19:18.442456
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    assert cache.base_path is not None
    assert cache.timeout == 86400
    assert cache.plugin_name == 'jsonfile'
    assert cache.lock_path == "%s/jsonfile.lock" % cache.base_path
    assert cache.file_extension == ".json"

# Generated at 2022-06-11 13:19:19.261913
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm

# Generated at 2022-06-11 13:19:22.471566
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test '_uri' parameter
    uri1 = 'test_uri'

    # test '_prefix' parameter
    prefix1 = 'test_prefix'

    # test '_timeout' parameter
    timeout1 = 12345

    CacheModule(uri=uri1, prefix=prefix1, timeout=timeout1)

# Generated at 2022-06-11 13:19:22.976494
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-11 13:19:26.001628
# Unit test for constructor of class CacheModule
def test_CacheModule():
  obj = CacheModule()
  assert obj.__class__.__name__ == 'CacheModule'
  assert obj._load_filepath == '_load'
  assert obj._dump_filepath == '_dump'

# Generated at 2022-06-11 13:19:27.460904
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj.__class__.__name__ == 'CacheModule'

# Generated at 2022-06-11 13:20:17.512711
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)

# Generated at 2022-06-11 13:20:20.369386
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.settings is not None
    assert module.cache_dir is not None
    assert module.cache_dir == '/tmp/ansible-cache'

# Generated at 2022-06-11 13:20:22.271309
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin_inst = CacheModule()
    assert isinstance(plugin_inst, CacheModule)
    assert plugin_inst._timeout == 86400

# Generated at 2022-06-11 13:20:24.475992
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.plugin_name == 'jsonfile'
    assert cache_plugin.keys_to_ignore == ['_timeout']

# Generated at 2022-06-11 13:20:24.979445
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-11 13:20:29.769305
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = '/path/to/json/file'
    prefix = 'test_fact_caching'
    timeout = 3600
    cache = CacheModule()
    cache.set_options(direct={'_uri': uri, '_prefix': prefix})
    assert cache._connection == uri
    assert cache._prefix == prefix
    assert cache._timeout == 86400

# Generated at 2022-06-11 13:20:37.258344
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    path = tempfile.mkdtemp()
    ttl = 1
    cm = CacheModule('jsonfile', path, ttl)
    cm._dump({"a": "b"}, "/tmp/yum/1_1")
    cm._dump({"a": "b"}, "/tmp/yum/2_1")
    print(cm._load("/tmp/yum/1_1"))
    print(cm._load("/tmp/yum/2_1"))
    cm._flush("/tmp/yum")
    cm.get("1")
    cm.set("1", "2")
    print(cm.get("1"))

# Generated at 2022-06-11 13:20:38.289462
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule() is not None

# Generated at 2022-06-11 13:20:40.120342
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacher = CacheModule({}, {}, {})
    print(cacher)
    assert True

# Generated at 2022-06-11 13:20:44.875493
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_cache_prefix() == 'ansible-fact-cache'
    assert cache.get_cache_timeout() == 86400
    assert cache.get_cache_connection() == '/tmp/ansible-fact-cache'


if __name__ == "__main__":
    test_CacheModule()

# Generated at 2022-06-11 13:22:36.441456
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = '/var/tmp/ansible-cache'
    prefix = 'test'
    timeout = 3600

    try:
        cache = CacheModule({'_uri': path, '_prefix': prefix, '_timeout': timeout})
    except Exception as e:
        raise AssertionError("An exception was raised testing the CacheModule constructor: {}".format(e))

    assert cache.file_extension == 'json'
    assert cache.timeout == timeout
    assert cache.file.startswith(path)
    assert cache.file.endswith('.json')
    (host,) = cache.file.split('.', 1)
    assert host.endswith(prefix)

# Generated at 2022-06-11 13:22:36.934552
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-11 13:22:42.829029
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule('{"uri":"./cache", "_prefix":".prefix", "_timeout":3600}') is not None

if __name__ == '__main__':
    module = CacheModule('{"uri":"./cache", "_prefix":".prefix", "_timeout":3600}')
    module.set('host', 'key', dict(foo='bar'))
    print('set done')
    print(module.get('host', 'key'))
    print(module.keys())
    module.flush()
    print(module.keys())

# Generated at 2022-06-11 13:22:44.740819
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert isinstance(plugin._load('tests/test.json'), dict)

# Generated at 2022-06-11 13:22:49.273549
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.utils.path import unfrackpath
    from ansible.plugins.cache.jsonfile import CacheModule

    # Create CacheModule object
    cm = CacheModule()

    # Test init
    assert cm._timeout == 86400
    assert cm._connection == unfrackpath('~/.ansible/tmp/ansible-fact-cache')
    assert cm._prefix is None

# Generated at 2022-06-11 13:22:50.954497
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert isinstance(module._load, object)
    assert isinstance(module._dump, object)

# Generated at 2022-06-11 13:22:51.875517
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

# Generated at 2022-06-11 13:22:53.322345
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert isinstance(module, CacheModule)

# Generated at 2022-06-11 13:22:54.235633
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(None)

# Generated at 2022-06-11 13:22:55.048161
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(None)