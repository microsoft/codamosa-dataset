

# Generated at 2022-06-11 13:15:19.093676
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj1 = CacheModule()
    assert(obj1._connection == None)
    assert(obj1._prefix == 'ansible_facts')
    assert(obj1._timeout == 86400)

# Generated at 2022-06-11 13:15:25.954457
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ansible = DummyAnsibleModule()
    filepath = ansible.params['_uri']
    prefix = ansible.params['_prefix']
    timeout = ansible.params['_timeout']

    unit = CacheModule(ansible)
    assert isinstance(unit, BaseFileCacheModule)
    assert unit.filecache == ansible.filecache
    assert unit.timeout == timeout
    assert unit.ext == u'.json'

    assert unit.filecache.filecache == filepath
    assert unit.filecache.prefix == prefix


# Generated at 2022-06-11 13:15:29.393155
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with CacheModule(['/tmp/foo']) as cache:
        # Expecting the cache module to have a dict like attributes
        assert cache._options

    # Test the _load() method
    # Test the _dump() method

# Generated at 2022-06-11 13:15:30.558108
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj != None

# Generated at 2022-06-11 13:15:35.500846
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = {}
    data['uri'] = 'cache_dir'
    data['_prefix'] = 'jsonfile_prefix'
    data['_timeout'] = '3600'
    _CacheModule = CacheModule(data)
    assert _CacheModule.get_timeout() == 3600
    assert _CacheModule.get_prefix()  == 'jsonfile_prefix'

# Generated at 2022-06-11 13:15:37.351723
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''Unit test for constructor of class CacheModule'''
    cache_module = CacheModule()
    assert cache_module

# Generated at 2022-06-11 13:15:41.385466
# Unit test for constructor of class CacheModule
def test_CacheModule():
  import os
  import tempfile
  cache_plugin_connection = os.path.join(tempfile.mkdtemp(), 'jsoncache')
  cache_plugin_timeout = 6
  cm = CacheModule(cache_plugin_connection, cache_plugin_timeout)
  # test that the object was correctly initialized by the constructor
  assert os.path.isdir(cache_plugin_connection)
  assert cm.cache_plugin_timeout == cache_plugin_timeout


# Generated at 2022-06-11 13:15:43.361129
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    # Check if obj is CacheModule type
    assert type(obj) is CacheModule

# Generated at 2022-06-11 13:15:44.382994
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(None, dict())

# Generated at 2022-06-11 13:15:48.792852
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # None of the calls below should fail
    cm = CacheModule({})
    cm = CacheModule({'_uri': '/some/random/path'})
    cm = CacheModule({'_uri': '/some/random/path', '_prefix': 'perf'})

# Generated at 2022-06-11 13:15:51.716974
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert (cm is not None)

# Generated at 2022-06-11 13:15:55.403109
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.cache_type == 'jsonfile'
    assert c.get_cache_timeout('') == 0
    assert c.get_cache_prefix('') == ''
    assert c.get_cache_uri('') == ''

# Generated at 2022-06-11 13:15:56.009142
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-11 13:16:05.320981
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ''' test constructor of class CacheModule '''
    # This is a 'fake' module, but it is mostly the same
    module = CacheModule()
    assert module._cache._options['timeout'] == 86400, 'Default timeout should be set on _options'
    assert module._cache.directory == '/tmp/ansible_fact_cache', 'Default directory should be set'
    assert module._cache.plugin_name == 'jsonfile', 'Plugin name should be set'

    module = CacheModule({'timeout': 42, 'fact_caching_connection': '/dev/null', 'fact_caching_prefix': 'prefix_'})
    assert module._cache._options['timeout'] == 42, 'Timeout should be set from fact_caching_timeout'

# Generated at 2022-06-11 13:16:06.620546
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache != None


# Generated at 2022-06-11 13:16:07.899956
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule is not None

# Generated at 2022-06-11 13:16:09.369369
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin != None

# Generated at 2022-06-11 13:16:11.952652
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule('/tmp/somejsonfile')
    assert cache_plugin
    assert cache_plugin.plugin == 'jsonfile'



# Generated at 2022-06-11 13:16:12.973540
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-11 13:16:13.532009
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-11 13:16:19.569505
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data_dir = "/tmp"
    uri = "file://" + data_dir
    prefix = "ansible_file"
    timeout = 3600
    CacheModule(uri, prefix, timeout)

# Generated at 2022-06-11 13:16:21.630880
# Unit test for constructor of class CacheModule
def test_CacheModule():
    f = CacheModule()
    assert f._load is not None
    assert f._dump is not None

# Generated at 2022-06-11 13:16:22.924434
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with CacheModule()._cache_locker:
        CacheModule()
        pass

# Generated at 2022-06-11 13:16:24.822243
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None
    assert cm.root == "/tmp"

# Generated at 2022-06-11 13:16:34.457622
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # This test uses pytest magic to pass a test fixture as an argument to the test
    # see https://docs.pytest.org/en/latest/fixture.html#fixtures-as-function-arguments
    def __init__(self, tmpfile):
        self.path = tmpfile

    CacheModule.__init__ = __init__

    cm = CacheModule()
    # Ensure that _prefix and _prefix_sep from BaseCacheModule are used.
    assert cm._prefix == 'ansible-facts'
    assert cm._prefix_sep == '-'

    # Ensure that the _uri parameter is initialized and used as the directory
    # where the cache is created.
    assert cm._uri == tmpfile

# Generated at 2022-06-11 13:16:35.962847
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert type(c) is CacheModule


# Generated at 2022-06-11 13:16:37.776468
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert not hasattr(cache, '_timeout'), "CacheModule has _timeout set"

# Generated at 2022-06-11 13:16:39.301109
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(task_vars={}), CacheModule)

# Generated at 2022-06-11 13:16:41.985400
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.plugin_name == 'jsonfile'
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-11 13:16:42.621776
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-11 13:16:49.157031
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()

# Generated at 2022-06-11 13:16:54.137061
# Unit test for constructor of class CacheModule
def test_CacheModule():

    with open('/tmp/test_jsonfile.json', 'w') as f:
        f.write('{"ansible_facts": {"a": "b"}}')

    c = CacheModule()
    c._connection = '/tmp'
    c._prefix = 'test_jsonfile'

    c._load_cache()
    c.get('localhost')
    assert c._cache == {'localhost': {'a': 'b'}}

    c.set('localhost', {'a': 'b'})

# Generated at 2022-06-11 13:16:55.109753
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # cache = CacheModule()
    assert True

# Generated at 2022-06-11 13:16:56.779574
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = 'test'
    prefix = 'test'
    timeout = 1000
    CacheModule(connection, prefix, timeout)

# Generated at 2022-06-11 13:16:57.797699
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()


# Generated at 2022-06-11 13:17:03.419488
# Unit test for constructor of class CacheModule
def test_CacheModule():
    class env_mock():
        def __init__(self):
            self.connection = "conn"
            self.prefix = "test"
            self.timeout = "timeout"
    cache_module = CacheModule(env_mock())
    assert cache_module.cache_path == "conn"
    assert cache_module.prefix == "test"
    assert cache_module.timeout == "timeout"

# Generated at 2022-06-11 13:17:08.087353
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test required options
    c = CacheModule({
        '_uri': '/tmp/cache/path',
    })

    assert c._uri == '/tmp/cache/path'
    assert c._options['_timeout'] == 86400
    assert c._options['_prefix'] == 'ansible_facts_'

# Generated at 2022-06-11 13:17:10.228763
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Test if class CacheModule could be initialized, if the class
    could be initialized, the unit test passes
    """
    CacheModule()

# Generated at 2022-06-11 13:17:10.813124
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert True

# Generated at 2022-06-11 13:17:13.598574
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.get_cache_size() == 0
    cache_module.set_cache_size(1)
    assert cache_module.get_cache_size() == 1
    cache_module.flush()
    assert cache_module.get_cache_size() == 0
    cache_module.set_cache_size(0)
    assert cache_module.get_cache_size() == 0

# Generated at 2022-06-11 13:17:36.051693
# Unit test for constructor of class CacheModule
def test_CacheModule():
  cache_module=CacheModule()
  assert cache_module.plugin_name == 'jsonfile'

  # check the expected class properties
  assert hasattr(cache_module,'_prefix') == True
  assert hasattr(cache_module,'_timeout') == True
  assert hasattr(cache_module,'_connection') == True
  assert hasattr(cache_module,'_load_from_file') == True
  assert hasattr(cache_module,'_dump_to_file') == True
  assert hasattr(cache_module,'_load') == True
  assert hasattr(cache_module,'_dump') == True

  assert hasattr(cache_module,'get') == True
  assert hasattr(cache_module,'set') == True
  assert hasattr(cache_module,'keys') == True
  assert hasattr(cache_module,'contains')

# Generated at 2022-06-11 13:17:40.531906
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    # Add some data
    cache.set('test', 1)
    assert cache.get('test') == 1

    # Add more data
    cache.set('test', 2)
    assert cache.get('test') == 2

    # Make sure it was actually written to disk
    cache2 = CacheModule()
    assert cache2.get('test') == 2

# Generated at 2022-06-11 13:17:51.179135
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(run_context=None)
    content = {'status': 'success', 'payload': 'CacheModule'}
    tmp_result = cache_module._dump(value=content, filepath='/tmp/file.json')
    assert tmp_result is None
    assert cache_module._load(filepath='/tmp/file.json') == content
    assert cache_module.get('host') is None
    cache_module.set('host', content)
    assert cache_module.get('host') == content
    cache_module.set('host', content)
    assert cache_module.get('host') == content
    cache_module.set('host', content)
    assert cache_module.get('host') == content

# Generated at 2022-06-11 13:17:56.122165
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.cache_type == 'memory'
    assert cache_plugin.lock_path == '~/.ansible/tmp'
    assert cache_plugin._timeout == 86400
    assert cache_plugin._flush_cache == False
    assert cache_plugin._cachedir == '~/.ansible/cached'

# Generated at 2022-06-11 13:17:58.765333
# Unit test for constructor of class CacheModule
def test_CacheModule():

    test_file_name = "test_CacheModule.txt"
    test_timeout = 86400

    cache = CacheModule(test_timeout, test_file_name)

# Generated at 2022-06-11 13:18:01.729998
# Unit test for constructor of class CacheModule
def test_CacheModule():
    facts = {}
    cache_connection = '/tmp/ansible_facts'
    cache_timeout = 7200
    cache_plugin_name = 'json_fact'
    cache_prefix = 'prefix_'
    cache = CacheModule(facts, cache_connection, cache_timeout, cache_plugin_name, cache_prefix)
    assert cache.timeout == cache_timeout
    assert cache.plugin_name == cache_plugin_name
    assert cache.prefix == cache_prefix
    assert cache.connection == cache_connection

# Generated at 2022-06-11 13:18:03.501532
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._connection_info['path'] == '/tmp'
    assert cache._timeout == 86400

# Generated at 2022-06-11 13:18:10.072712
# Unit test for constructor of class CacheModule
def test_CacheModule():
    for var in ['ANSIBLE_CACHE_PLUGIN_CONNECTION', 'ANSIBLE_CACHE_PLUGIN_PREFIX', 'ANSIBLE_CACHING_PLUGIN_TIMEOUT']:
        try:
            del os.environ[var]
        except KeyError:
            pass
    cache = CacheModule()
    assert cache._timeout == 86400


# Generated at 2022-06-11 13:18:11.634500
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.ext == '.json'

# Generated at 2022-06-11 13:18:12.840264
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__doc__ is not None

# Generated at 2022-06-11 13:18:40.691398
# Unit test for constructor of class CacheModule

# Generated at 2022-06-11 13:18:41.894737
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), BaseFileCacheModule)

# Generated at 2022-06-11 13:18:43.119027
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c

# Generated at 2022-06-11 13:18:44.902350
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm,CacheModule)

# Generated at 2022-06-11 13:18:45.987093
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(isinstance(CacheModule(), CacheModule))

# Generated at 2022-06-11 13:18:49.122931
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule is not BaseFileCacheModule
    assert CacheModule()._load is not BaseFileCacheModule.__load
    assert CacheModule()._dump is not BaseFileCacheModule.__dump

# Generated at 2022-06-11 13:18:50.878653
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert isinstance(module, CacheModule)
    assert isinstance(module, BaseFileCacheModule)

# Generated at 2022-06-11 13:18:51.513040
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-11 13:18:56.123600
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_option('_prefix') is None
    assert cache.get_option('_timeout') == 86400
    assert cache.get_option('_uri') is None

    cache = CacheModule(**{'_prefix': 'foo', '_timeout': 1234, '_uri': 'bar'})
    assert cache.get_option('_prefix') == 'foo'
    assert cache.get_option('_timeout') == 1234
    assert cache.get_option('_uri') == 'bar'

# Generated at 2022-06-11 13:19:00.992566
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._encoder == json.JSONEncoder
    assert module._decoder == json.JSONDecoder
    assert module._dump_args == {"cls": json.JSONEncoder,
                                 "indent": 4,
                                 "sort_keys": True}
    assert module._load_args == {"cls": json.JSONDecoder}
    assert module._extension == ".json"

# Generated at 2022-06-11 13:19:51.558165
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-11 13:19:54.970389
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonfile_cache = CacheModule({'_uri': 'dummy'})

    assert jsonfile_cache.plugin_name == 'jsonfile'
    assert jsonfile_cache.plugin_path == 'plugins/caching'
    assert jsonfile_cache.plugin_type == 'cache'

# Generated at 2022-06-11 13:19:56.279979
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule("./test/")


# Generated at 2022-06-11 13:19:56.981534
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._load

# Generated at 2022-06-11 13:20:04.981828
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # To instantiate a class, one must first use "CacheModule".
    # The CacheModule is passed in to the class for the purpose of using _load, _dump, etc...
    # The "uri" is the path to the json file where the data is going to be stored.
    # The "timeout" is how long the plugin will wait before refreshing the data.
    module = CacheModule(CacheModule, uri='/tmp/ansible/facts', timeout=60)
    # Since this is the first time the module has been called, the variable "changed" is set to True.
    assert module.changed == True
    # The variable "data" is empty as there is no data saved yet.
    assert module.data == {}
    assert module.expires == 0
    # Test the get method of CacheModule.

# Generated at 2022-06-11 13:20:08.117396
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # pylint: disable=redefined-outer-name
    _cache = CacheModule()
    _cache.get('asdf')
    _cache.set('asdf', 'asdf')
    _cache.keys()

# Generated at 2022-06-11 13:20:09.970655
# Unit test for constructor of class CacheModule
def test_CacheModule():
    base_path = 'xxx'
    cm = CacheModule(base_path)
    assert cm._timeout == 86400
    assert cm._prefix is None

# Generated at 2022-06-11 13:20:13.244514
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cmodule = CacheModule()
    # TODO: Make this a full test, setting values and testing get_set_del.
    assert cmodule._load == cmodule.load
    assert cmodule._dump == cmodule.dump
    assert cmodule._backend == cmodule.backend

# Generated at 2022-06-11 13:20:14.707210
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._prefix == "ansible_facts_"
    assert cache._timeout == 86400

# Generated at 2022-06-11 13:20:15.217132
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-11 13:22:12.484195
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """ Unit test for class CacheModule. """
    plugin = CacheModule()
    assert plugin._cachefile_suffix == 'fact_cache.json'
    assert plugin._cachefile_basedir == '~/.ansible/cache'
    assert plugin._timeout == 86400
    assert not plugin._load('')

# Generated at 2022-06-11 13:22:17.348504
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Ensure monolithic `ansible.plugins.cache.jsonfile` can be loaded and instantiated.
    # (The `ansible.plugins.cache.jsonfile` module imports its parent class from `lib/ansible/plugins/cache`.
    # The parent class import is relative and plugin loading will fail on Windows if path is not absolute.)
    assert CacheModule({'_prefix': 'test_prefix',
                        '_uri': 'test_uri',
                        '_timeout': 'test_timeout'})

# Generated at 2022-06-11 13:22:20.440561
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonfile = CacheModule()
    assert jsonfile.connection == '_ansible_cache'
    assert jsonfile._options == {'_prefix': 'ansible-', '_timeout': 86400, '_uri': ''}



# Generated at 2022-06-11 13:22:24.078462
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test CacheModule constructor
    cm = CacheModule()
    assert cm._cache is None
    assert cm._timeout == 86400
    assert cm._plugin_name == 'jsonfile'
    assert cm._encoder_class == AnsibleJSONEncoder
    assert cm._decoder_class == AnsibleJSONDecoder

# Generated at 2022-06-11 13:22:24.720559
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-11 13:22:26.036760
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert(module.cache_plugin_name == 'jsonfile')

# Generated at 2022-06-11 13:22:27.931281
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.connection is not None
    assert cache.get_file_extension() == "json"

# Generated at 2022-06-11 13:22:28.740063
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert(cache)

# Generated at 2022-06-11 13:22:37.248582
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    temp_dir = tempfile.gettempdir()
    cm = CacheModule({'_uri': temp_dir})

    assert cm._connection == temp_dir
    assert cm._prefix == 'ansible_fact_cacheplugin'
    assert cm._timeout == 86400

    # Arrange
    plugin_dir = '{}/{}'.format(temp_dir, cm._prefix)
    import os
    os.system('rm -rf {}'.format(plugin_dir))
    assert os.path.exists(plugin_dir) == False

    # NOTE: for the following test, a file has to be created using the
    #       Ansible file module.
    # Example:
    #   - name: Loads first facts
    #     file:
    #       path: /tmp/test
    #       state: touch

# Generated at 2022-06-11 13:22:38.637711
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)