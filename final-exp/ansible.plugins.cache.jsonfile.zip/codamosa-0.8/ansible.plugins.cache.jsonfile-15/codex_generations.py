

# Generated at 2022-06-11 13:15:18.044503
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_data_path = "/tmp"
    _timeout = 8
    cache_plugin = CacheModule(cache_data_path, _timeout)
    assert cache_plugin.cache_data_path == "/tmp"
    assert cache_plugin._timeout == 8
    assert cache_plugin._cache_files == {}
    assert cache_plugin._cache_file_names == {}
    assert cache_plugin._cache_backup_files == {}
    assert cache_plugin._last_purged == 0


# Generated at 2022-06-11 13:15:28.164082
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.parsing.ajson import AnsibleJSONEncoder, AnsibleJSONDecoder
    from ansible.plugins.cache import BaseFileCacheModule
    from ansible import constants as C
    cm = CacheModule()
    assert type(cm._load) == type(CacheModule()._load)
    assert type(cm._dump) == type(CacheModule()._dump)
    assert type(cm) == CacheModule
    assert type(cm._load) == classmethod
    assert type(cm._dump) == classmethod
    assert cm._timeout == C.CACHE_PLUGIN_TIMEOUT
    assert type(cm._timeout) == int
    assert cm._connection == C.CACHE_PLUGIN_CONNECTION
    assert type(cm._connection) == str
    assert cm._prefix == C.CACHE_PLUG

# Generated at 2022-06-11 13:15:31.982673
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''Test class CacheModule.'''
    cache = CacheModule().get_cache_file('test.json', 'inventory.prefix,inventory.hostname')
    assert cache == 'inventory.prefix,inventory.hostname/test.json'

# Generated at 2022-06-11 13:15:36.929734
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_connection = '~/.ansible/cachedir'
    cache_timeout = 8000
    obj = CacheModule(cache_connection, cache_timeout)
    assert obj._connection == cache_connection
    assert obj._prefix == ''
    assert obj._timeout == cache_timeout
    assert obj._cache == 'jsonfile.pickle'

# Generated at 2022-06-11 13:15:40.622957
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri='/root/ansible/lirctestenv/ansible/jason'
    prefix=''
    timeout='86400'
    mc = CacheModule(uri, prefix, timeout)
    assert mc._prefix == ''
    assert mc._timeout == '86400'
    assert mc._cache == {}

# Generated at 2022-06-11 13:15:41.218109
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-11 13:15:48.250350
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    cm._prefix = 'ansible-test'
    cm._uri = './'
    cm._load = 'None'
    cm._dump = 'None'
    cm._timeout = 600
    cm._validate_file = 'None'
    cm._list_objects = 'None'
    cm._flush = 'None'
    assert cm._uri == './'
    assert cm._prefix == 'ansible-test'
    assert cm._timeout == 600

# Generated at 2022-06-11 13:15:54.513409
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert (CacheModule({u'_uri': u'/tmp', u'_prefix': u'myprefix'}).ENV_PREFIX == 'myprefix')
    assert (CacheModule({u'_uri': u'/tmp', u'_prefix': u'myprefix'}).ENV_TIMEOUT == 3600)
    assert (CacheModule({u'_uri': u'/tmp', u'_timeout': u'3600'}).ENV_TIMEOUT == 3600)

# Generated at 2022-06-11 13:15:56.191381
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load is not None
    assert cache._dump is not None

# Generated at 2022-06-11 13:15:57.679734
# Unit test for constructor of class CacheModule
def test_CacheModule():
    global CacheModule
    CacheModule = CacheModule("/tmp/")
    assert True == True

# Generated at 2022-06-11 13:16:01.870190
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Call constructor of class CacheModule
    cache_module_instance = CacheModule()

# Generated at 2022-06-11 13:16:03.646173
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = CacheModule()
    assert connection._load == BaseFileCacheModule._load
    assert connection._dump == BaseFileCacheModule._dump

# Generated at 2022-06-11 13:16:05.301152
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)
    assert callable(CacheModule)

# Generated at 2022-06-11 13:16:10.746442
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_file_dir_path = '/temp'
    cache_file_path = '/temp/play_1.json'
    cache_file_prefix = 'play_'
    cache_file_timeout = 86400

    cache = CacheModule(cache_file_dir_path,
                        cache_file_path,
                        cache_file_prefix,
                        cache_file_timeout)
    assert cache.file_path == '/temp/play_1.json'

# Generated at 2022-06-11 13:16:21.017492
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule._get_cache_file_path('/tmp', 'localhost') == '/tmp/ansible-local-facts/ansible_facts_localhost.json'
    assert CacheModule._get_cache_file_path('/tmp', 'localhost', '?') == '/tmp/ansible-local-facts/ansible_facts_localhost.json'
    assert CacheModule._get_cache_file_path('/tmp', '?', '?') == '/tmp/ansible-local-facts/ansible_facts_.json'
    assert CacheModule._get_cache_file_path('/tmp', 'localhost', '?', 'prefix') == '/tmp/prefix-localhost.json'
    assert CacheModule._get_cache_file_path('/tmp', '?', '?', 'prefix') == '/tmp/prefix_.json'

# Generated at 2022-06-11 13:16:27.237994
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._get_file_path(None) == '/dev/shm/ansible_localhost_facts'
    assert cache_module._load_cache() == {}
    assert cache_module._load_cache(None) == {}
    assert cache_module._dump_cache({}) == None
    assert cache_module._dump_cache({}, None) == None
    assert cache_module._load_cache_plugin_options({}) == {}
    cache_module._write_file({}, None)



# Generated at 2022-06-11 13:16:31.244138
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule('/tmp/cachepath')
    assert cache_module.cache._uri =='/tmp/cachepath'
    assert cache_module.cache._timeout == 86400
    assert cache_module.cache._prefix == 'ansible-factcache'

# Generated at 2022-06-11 13:16:35.405119
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_connection = u'/home/ubuntu/ansible/facts/'
    cache_module = CacheModule(cache_connection)
    print(cache_module)   # Ansible will print a lot of information about module

# Verify the class CacheModule has function get(). If no, Ansible will report error.

# Generated at 2022-06-11 13:16:36.741712
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin


# Generated at 2022-06-11 13:16:42.039131
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = CacheModule()
    assert isinstance(data, CacheModule)
    assert not data.get('test', 'nonexistent')
    assert data.set('test', 'existing', 'old')
    assert data.get('test', 'existing') == 'old'
    assert data.set('test', 'existing', 'new')
    assert data.get('test', 'existing') == 'new'

# Generated at 2022-06-11 13:16:46.523955
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = BaseFileCacheModule('/tmp/')
    assert isinstance(connection, BaseFileCacheModule)

# Generated at 2022-06-11 13:16:47.089037
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert True

# Generated at 2022-06-11 13:16:48.008357
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule.__name__ == 'CacheModule'

# Generated at 2022-06-11 13:16:49.401909
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None

# Generated at 2022-06-11 13:16:50.580216
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule("cache", 1, "cache_uri", "cache_prefix")

# Generated at 2022-06-11 13:16:52.445298
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.cache_type == 'jsonfile'

# Generated at 2022-06-11 13:16:53.578716
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()


# Generated at 2022-06-11 13:16:57.505371
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)
    cacheModule = CacheModule()
    # test methods
    assert callable(getattr(cacheModule, '_dump'))
    assert callable(getattr(cacheModule, '_load'))
    # test variables
    assert cacheModule._cache_options is not None

# Generated at 2022-06-11 13:17:00.806592
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mod = CacheModule({'_uri': 'test_file'})
    assert mod._cache_dir == 'test_file'
    assert mod._prefix == ''
    assert mod._timeout == 86400

# Generated at 2022-06-11 13:17:02.567189
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    # Test that the json module has been instantiated
    assert cache._json is not None

# Generated at 2022-06-11 13:17:09.305510
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_uri = '/tmp/ansible/'
    cm = CacheModule(test_uri)
    assert cm.cache._uri == test_uri
    assert cm.cache._prefix == 'ansible_facts'
    assert cm.cache._timeout == 86400


# Generated at 2022-06-11 13:17:16.751560
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test that _dump, load, set and get properties are set properly
    instance_CacheModule = CacheModule()
    assert instance_CacheModule.config is not None
    assert instance_CacheModule._dump == json.dumps
    assert instance_CacheModule._load == json.load
    assert instance_CacheModule.set is not None
    assert instance_CacheModule.get is not None
    assert instance_CacheModule.keys is not None
    assert instance_CacheModule.contains is not None
    assert instance_CacheModule.delete is not None
    assert instance_CacheModule.flush is not None
    assert instance_CacheModule.close is not None
    assert instance_CacheModule.list is not None

# Generated at 2022-06-11 13:17:18.555247
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # just check we can create an object and that it has the right baseclass
    CacheModule('/tmp/ansible-test')

# Generated at 2022-06-11 13:17:19.069724
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()

# Generated at 2022-06-11 13:17:24.160830
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    cache = CacheModule('/some/path', 'some_prefix')
    assert cache.plugin_name == 'jsonfile'
    assert cache.plugin_timeout == 86400
    assert cache.plugin_connection == '/some/path'
    assert cache.plugin_prefix == 'some_prefix'

# Generated at 2022-06-11 13:17:26.538319
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''Unit test for constructor of class CacheModule.'''
    cache = CacheModule()
    assert cache.file_extension == 'json'

# Generated at 2022-06-11 13:17:27.887318
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert isinstance(cache_module, CacheModule)

# Generated at 2022-06-11 13:17:28.538137
# Unit test for constructor of class CacheModule
def test_CacheModule():
    pass

# Generated at 2022-06-11 13:17:30.092279
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert type(cm) is CacheModule

# Generated at 2022-06-11 13:17:33.059136
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._connection is None
    assert cm._prefix == 'ansible_facts'
    assert cm._timeout == 86400
    assert cm._extension == '.cache'

# Generated at 2022-06-11 13:17:39.078208
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache

# Generated at 2022-06-11 13:17:39.477691
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert True

# Generated at 2022-06-11 13:17:40.620590
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm.__class__, type)

# Generated at 2022-06-11 13:17:42.024118
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plug = CacheModule()
    assert cache_plug.url == ''

# Generated at 2022-06-11 13:17:47.247398
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = '/tmp/ansible-test-cache'
    prefix = 'test'
    timeout = 60
    CM = CacheModule(connection,prefix,timeout)
    print(CM._connection)
    print('---')
    print(CM._prefix)
    print('---')
    print(CM._timeout)


# Generated at 2022-06-11 13:17:47.972712
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert True

# Generated at 2022-06-11 13:17:50.592442
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Unit test for constructor of class CacheModule
    """
    cache = CacheModule({}, [])
    assert isinstance(cache, BaseFileCacheModule)

# Generated at 2022-06-11 13:17:53.858828
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    c = CacheModule()
    print(c)
    assert c
    # get_data()
    # put_data()
    # flush()

# Generated at 2022-06-11 13:17:55.724964
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert hasattr(module, '_load')
    assert hasattr(module, '_dump')

# Generated at 2022-06-11 13:18:00.270212
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test constructor of class CacheModule with 'ANSIBLE_CACHE_PLUGIN_CONNECTION'
    # test parameter of environment variables.
    #
    # Expected:
    #   CacheModule.filepath = 'cache.file.path'
    #   CacheModule.timeout = 3600
    #   CacheModule.data = {}
    import os
    import tempfile

    module_name = 'ansible.plugins.cache.jsonfile'
    cache_plugin_connection = tempfile.mkdtemp()
    cache_plugin_timeout = 3600
    os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = cache_plugin_connection
    os.environ['ANSIBLE_CACHE_PLUGIN_TIMEOUT'] = str(cache_plugin_timeout)

# Generated at 2022-06-11 13:18:13.382956
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri':'/tmp', '_timeout': 12345, '_prefix': 'test_prefix'})

# Generated at 2022-06-11 13:18:14.434158
# Unit test for constructor of class CacheModule
def test_CacheModule():
    return CacheModule()


# Generated at 2022-06-11 13:18:16.988829
# Unit test for constructor of class CacheModule
def test_CacheModule():
  assert CacheModule(task_uuid = 'uuid', data = 'data', file_prefix = 'file')


# Generated at 2022-06-11 13:18:20.229507
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)
    assert cm._load('/foo') is None
    assert cm._dump('bar', '/foo') is None


if __name__ == "__main__":
    CacheModule()

# Generated at 2022-06-11 13:18:21.299151
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # create a CacheModule instance
    CacheModule()

# Generated at 2022-06-11 13:18:22.188423
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert x != None

# Generated at 2022-06-11 13:18:26.637523
# Unit test for constructor of class CacheModule
def test_CacheModule():
	# test constructor with valid URI
	try:
		cm = CacheModule({'_uri': '/path/to/file'})
		assert cm != None
	except Exception as e:
		assert False

	# test constructor without URI
	# should throw exception
	try:
		cm = CacheModule({})
		assert False
	except Exception as e:
		assert True


# Generated at 2022-06-11 13:18:28.044312
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule, type)


# Generated at 2022-06-11 13:18:29.100022
# Unit test for constructor of class CacheModule
def test_CacheModule():
    fc = CacheModule()
    assert isinstance(fc, BaseFileCacheModule)

# Generated at 2022-06-11 13:18:30.283038
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    assert CacheModule(None) is not None

# Generated at 2022-06-11 13:18:55.498118
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Unit test for CacheModule module constructor"""
    fc = CacheModule()
    assert isinstance(fc, BaseFileCacheModule)

# Generated at 2022-06-11 13:18:58.096882
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cls = CacheModule()
    assert cls._get_cache_basedir("_uri")
    assert cls._get_cache_prefix("_prefix")
    assert cls._get_timeout("_timeout")

# Generated at 2022-06-11 13:19:00.614873
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    parameters = cache.get_options()
    assert parameters['_uri']
    assert parameters['_prefix']
    assert parameters['_timeout'] == 86400

# Generated at 2022-06-11 13:19:02.918373
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule("/path/to/somewhere")._connection == "/path/to/somewhere"

# Generated at 2022-06-11 13:19:05.513623
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_instance = CacheModule()
    assert test_instance.get_cache_timeout() == 86400

# vim: set expandtab:ts=4:sw=4:

# Generated at 2022-06-11 13:19:06.093359
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-11 13:19:09.584873
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None
    assert cache_plugin._connection is None
    assert cache_plugin._prefix == 'ansible_facts'
    assert cache_plugin._timeout == 86400
    assert cache_plugin._cache == {}

# Generated at 2022-06-11 13:19:11.981804
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test instantiation of a CacheModule
    try:
        module = CacheModule()
    except:
        assert False, 'Error: Unable to instantiate a CacheModule'

# Generated at 2022-06-11 13:19:13.582314
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule("test")
    assert x is not None
    assert x.plugin_name == "jsonfile"

# Generated at 2022-06-11 13:19:19.623720
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheplugin_uri = '~/ansible_cache'
    cacheplugin_prefix = 'cache'
    cacheplugin_timeout = 3600

    cacheplugin = CacheModule(cacheplugin_uri, cacheplugin_prefix, cacheplugin_timeout)
    assert cacheplugin.cache
    assert cacheplugin.get('foo') == None
    # this should not raise an error
    try:
        cacheplugin.set('foo', 'bar')
        assert cacheplugin.get('foo') == 'bar'
    except (OSError, IOError) as e:
        pytest.fail("Unexpected exception raised: " + repr(e))

# Generated at 2022-06-11 13:20:10.552402
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin_instance = CacheModule()
    assert plugin_instance is not None

# Generated at 2022-06-11 13:20:15.533206
# Unit test for constructor of class CacheModule
def test_CacheModule():
    u = CacheModule()

    # Following assertion fails since by default the DB file is set to '/tmp/ansible_facts.db'
    # This defaults is written to the ansible.cfg
    # assert u._db_path == '/tmp/ansible_facts.db'

    assert u._db_name == 'ansible_facts'
    assert u._prefix == 'ansible_facts_'
    assert u._timeout == 86400

# Generated at 2022-06-11 13:20:19.625521
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    This is a test to assert that the CacheModule constructor
    """
    assert CacheModule.__module__ == 'ansible.plugins.cache.jsonfile'
    assert '_load' in dir(CacheModule)
    assert '_dump' in dir(CacheModule)

# Generated at 2022-06-11 13:20:20.922990
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule('/tmp/ansible_caching')
    assert cache

# Generated at 2022-06-11 13:20:22.386802
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj is not None
    assert type(obj) is type(CacheModule)

# Generated at 2022-06-11 13:20:22.891570
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(CacheModule)

# Generated at 2022-06-11 13:20:25.433253
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = {'path': '/my/path'}
    plugin = CacheModule(connection)
    assert plugin._connection == connection
    assert plugin._timeout == 86400
    assert plugin._prefix == 'ansible_facts_'

# Generated at 2022-06-11 13:20:34.770524
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._cache is None
    assert cm._cache_file is None
    assert cm.tree is None
    assert cm._timeout is None
    cm._timeout = 86400
    assert cm._timeout == 86400
    cm._timeout = 86401
    assert cm._timeout == 86401
    assert cm.get_timeout() == 86401
    cm.set_timeout(86400)
    assert cm._timeout == 86400
    cm.set_timeout(86401)
    assert cm._timeout == 86401
    cm._cache_file = 'cache_file'
    assert cm._get_cache_file() == 'cache_file'
    cm._cache = 'cache'
    assert cm._get_cache() == 'cache'
    cm._persist = False
    assert cm._is

# Generated at 2022-06-11 13:20:41.836413
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Initialize a plugin object
    plugin = CacheModule()
    # Associate an arbitrary actions with the plugin object
    plugin.actionable = ['get']
    # Testing initialization using this method
    assert plugin._init(timeout=600) is None
    assert plugin._prefix == "ansible_facts"
    assert plugin._timeout == 600
    assert plugin._connection == plugin.config.cache_dir
    assert plugin._backup_name is None
    assert plugin._refresh_delay is None
    # Testing reset function
    assert plugin.reset() == {}



# Generated at 2022-06-11 13:20:42.425425
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-11 13:22:35.399904
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = {'cache_plugin': 'jsonfile', 'cache_plugin_connection': 'jsonfile', 'cache_plugin_prefix': 'ansible-', 'cache_plugin_timeout': 86400}
    uri = 'jsonfile'
    prefix = 'ansible-'
    timeout = 86400
    cm = CacheModule(x)
    assert cm._uri == uri
    assert cm._prefix == prefix
    assert cm._timeout == timeout

# Generated at 2022-06-11 13:22:36.815673
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert isinstance(obj, BaseFileCacheModule)
    assert isinstance(obj, CacheModule)

# Generated at 2022-06-11 13:22:37.322451
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-11 13:22:41.953706
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = 'cache_dir'
    cache_prefix = 'cache_prefix'
    timeout = 25
    cache_plugin = CacheModule(cache_dir=cache_dir, cache_prefix=cache_prefix, timeout=timeout)

    assert cache_plugin.cache_dir == 'cache_dir'
    assert cache_plugin.cache_prefix == 'cache_prefix'
    assert cache_plugin.timeout == 25

# Generated at 2022-06-11 13:22:46.094522
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj.get_db_dir() is not None
    assert obj.get_db_dir() == '/tmp/.ansible/tmp/ansible-cache'
    assert obj.get_extension() is not None
    assert obj.get_extension() == 'json'
    assert obj.get_timeout() == 86400

# Generated at 2022-06-11 13:22:48.082409
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    print(cache._timeout)

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-11 13:22:48.746249
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-11 13:22:49.748942
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonfile = CacheModule()
    assert jsonfile

# Generated at 2022-06-11 13:22:55.960041
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """This is a contrived test which just checks that the constructor works
    """
    cfg = dict(_uri='/var/tmp/ansible/cache', _prefix='foo', _timeout=42)
    cache_plugin = CacheModule(cfg)
    assert cache_plugin.uri == cfg['_uri']
    assert cache_plugin.plugin_name == 'jsonfile'
    assert cache_plugin.timeout == cfg['_timeout']
    assert cache_plugin.prefix == cfg['_prefix']
    assert cache_plugin.cache == {}

# Generated at 2022-06-11 13:23:01.326904
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = '/tmp/path'
    _prefix = 'prefix'
    _timeout = 86400

    cacheModule = CacheModule()
    assert cacheModule._connection == '/tmp/ansible_fact_cache'
    assert cacheModule._prefix == 'ansible_facts'
    assert cacheModule._timeout == 86400

    cacheModule = CacheModule(path, _prefix, _timeout)
    assert cacheModule._connection == path
    assert cacheModule._prefix == _prefix
    assert cacheModule._timeout == _timeout