

# Generated at 2022-06-11 13:15:23.227855
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.loader import cache_loader
    cm = cache_loader.get('jsonfile', class_only=True)
    assert issubclass(cm, CacheModule)
    assert cm().should_cache_fn({'cache_valid_until': '123'}) is True
    assert cm().should_cache_fn({'cache_valid_until': '999', '_ansible_cache_valid': True}) is True
    assert cm().should_cache_fn({'cache_valid_until': '0'}) is False
    assert cm().should_cache_fn({'cache_valid_until': '0', '_ansible_cache_valid': True}) is False
    assert cm().should_cache_fn({'cache_valid_until': '999'}) is False
    assert cm().should_cache_fn() is False

# Generated at 2022-06-11 13:15:25.017031
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'ansible/test'}) == {'_uri': 'ansible/test'}

# Generated at 2022-06-11 13:15:26.362647
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)


# Generated at 2022-06-11 13:15:27.439284
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), BaseFileCacheModule)

# Generated at 2022-06-11 13:15:31.030496
# Unit test for constructor of class CacheModule
def test_CacheModule():
    rm = CacheModule(None, task_uuid='test_task_uuid', play_context=None, new_stdin=None)
    assert rm.task_uuid == "test_task_uuid"

# Generated at 2022-06-11 13:15:33.044522
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_obj = CacheModule()
    assert cache_obj is not None
    assert isinstance(cache_obj, CacheModule)

# Generated at 2022-06-11 13:15:35.311142
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule('./test_cache/')
    assert module != None
    assert module.base_path == './test_cache/'

# Generated at 2022-06-11 13:15:38.393196
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule({'_connection': 'fake'})
    assert cm.get_value('fake') is None
    cm.set_value('fake', 'value')
    assert cm.get_value('fake') == 'value'

# Generated at 2022-06-11 13:15:42.215919
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule({})
    c = CacheModule({'_timeout': 1})
    c = CacheModule({'_timeout': 1, '_uri': '/path'})
    c = CacheModule({'_timeout': 1, '_uri': '/path', '_prefix': 'foo'})

# Generated at 2022-06-11 13:15:42.822097
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()

# Generated at 2022-06-11 13:15:47.259339
# Unit test for constructor of class CacheModule
def test_CacheModule():
    conn = CacheModule({'_uri': 'example.com'})
    assert conn._plugin_name == 'jsonfile'
    assert conn._uri == 'example.com'

# Generated at 2022-06-11 13:15:55.296180
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = 'uri-test'
    timeout = 'timeout-test'
    prefix = 'prefix-test'
    plugin = CacheModule(uri, timeout, prefix)
    assert uri == plugin.connection, 'The expected value "%s" does not match the actual value "%s"' % (uri, plugin.connection)
    assert timeout == plugin.timeout, 'The expected value "%s" does not match the actual value "%s"' % (timeout, plugin.timeout)
    assert prefix == plugin.get_prefix(), 'The expected value "%s" does not match the actual value "%s"' % (prefix, plugin.get_prefix())


# Generated at 2022-06-11 13:15:56.239936
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    return cache_module

# Generated at 2022-06-11 13:15:58.654253
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-11 13:16:06.692322
# Unit test for constructor of class CacheModule
def test_CacheModule():
    C = CacheModule()

    assert C.get_timeout() == 86400
    assert C._timeout == 86400
    # Prefix and Connection are only set when running through ansible
    assert C._prefix is None
    assert C._load == CacheModule._load
    assert C._dump == CacheModule._dump
    assert C.cache_dir() == '~/.ansible/cache/ansible'

    # Override timeout
    C = CacheModule(timeout=0)
    assert C.get_timeout() == 0
    assert C._timeout == 0

    # Override prefix
    C = CacheModule(prefix="foo")
    assert C._prefix == "foo"
    assert C.cache_dir() == '~/.ansible/cache/foo'

    # Override connection
    C = CacheModule(uri="foo")
    assert C

# Generated at 2022-06-11 13:16:07.284334
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()

# Generated at 2022-06-11 13:16:09.420430
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert isinstance(cache_plugin, CacheModule)
    assert cache_plugin._timeout == 86400

# Generated at 2022-06-11 13:16:11.164508
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': '/tmp/ansible-cache'},task=None) is not None


# Generated at 2022-06-11 13:16:13.391255
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Verify an instance of CacheModule can be instantiated."""
    cache_plugin = CacheModule()
    assert(cache_plugin is not None)

# Generated at 2022-06-11 13:16:14.643768
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert type(cm) is CacheModule


# Generated at 2022-06-11 13:16:19.616281
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    # assert isinstance(cache, BaseFileCacheModule)
    assert cache != None


# Generated at 2022-06-11 13:16:21.678528
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module is not None
    assert cache_module._cache is None

# Generated at 2022-06-11 13:16:23.496280
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test constructor
    cache = CacheModule()
    assert isinstance(cache, CacheModule)



# Generated at 2022-06-11 13:16:29.240643
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''Unit test for CacheModule'''
    cache_module = CacheModule()
    assert cache_module.get_options() == {'_prefix': 'ansible_facts',
                                          '_timeout': 86400,
                                          '_uri': '~/.ansible/tmp'}

    # Specify different values for options of CacheModule class
    custom_options = {'_prefix': 'ansible_facts_test',
                      '_timeout': 86400,
                      '_uri': '/tmp/ansible/test'}

    cache_module = CacheModule(custom_options)
    assert cache_module.get_options() == custom_options

# Generated at 2022-06-11 13:16:34.225365
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule({'_uri': './ansible_tmp', '_timeout': 3600}, 'fake_data_1')
    module.flush()
    module = CacheModule({}, 'fake_data_2')
    module.flush()
    module = CacheModule({'_uri': './ansible_tmp'}, 'fake_data_3')
    module.flush()

# Generated at 2022-06-11 13:16:36.097722
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({'_uri': 'nonsense'}, timeout=100)
    assert cache is not None

# Generated at 2022-06-11 13:16:37.927915
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.cachedir == '~/.ansible/tmp/ansible-fact-cache'

# Generated at 2022-06-11 13:16:38.689008
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule(dict())

# Generated at 2022-06-11 13:16:48.792241
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Exercise constructor of CacheModule (which invokes the one in the parent class)
    cache = CacheModule({'_uri': '/some/path', '_prefix': 'bar', '_timeout': '17'})
    assert cache
    assert cache.path == '/some/path'
    assert cache.timeout == 17
    assert cache.prefix == 'bar'
    # Exercise _load() (which "returns None when cache file is nonexistent")
    assert cache._load('/some/nonexistent/file') is None
    # Exercise _dump()
    import tempfile
    (fd, temp_file_path) = tempfile.mkstemp()
    cache._dump({'foo': 'bar'}, temp_file_path)
    # Exercise _load() again

# Generated at 2022-06-11 13:16:50.916052
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("Testing CacheModule")
    assert isinstance(CacheModule(), BaseFileCacheModule)

if __name__ == '__main__':
    test_CacheModule()


# Generated at 2022-06-11 13:16:58.992806
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    _prefix = 'test-prefix'
    _timeout = 1
    _cache_dir = tempfile.mkdtemp('', 'cache_dir-')
    cache = CacheModule(_prefix, _cache_dir, _timeout)
    assert cache._cache_dir == _cache_dir
    assert cache._prefix == _prefix
    assert cache._timeout == _timeout

# Generated at 2022-06-11 13:17:00.758874
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()

    assert(not plugin.is_valid)
    assert(plugin.cache == {})

# Generated at 2022-06-11 13:17:02.523388
# Unit test for constructor of class CacheModule
def test_CacheModule():
    sample = CacheModule()
    assert sample._config == dict()
    assert sample._pipe_path == ''

# Generated at 2022-06-11 13:17:05.292328
# Unit test for constructor of class CacheModule
def test_CacheModule():
	a = CacheModule()
	assert a.timeout == 86400, a.timeout
	assert a.file_extension == '.cache', a.file_extension

# Generated at 2022-06-11 13:17:10.763293
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonfile = CacheModule()
    assert jsonfile.BASE_CACHE_PLUGIN_PATH == 'ansible_facts'
    jsonfile = CacheModule(path='/tmp')
    assert jsonfile.BASE_CACHE_PLUGIN_PATH == '/tmp'
    assert jsonfile.plugin_name == 'jsonfile'
    assert jsonfile.cache_prefix == 'ansible_facts'

# Generated at 2022-06-11 13:17:12.623020
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Class CacheModule: To test the constructor of class CacheModule

    Return:
        A instance object of class CacheModule
    """
    cache_dir = ""
    timeout = 0
    prefix = ""

    return CacheModule(cache_dir, timeout, prefix)

# Generated at 2022-06-11 13:17:13.597258
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj=CacheModule()
    print(obj)

# Generated at 2022-06-11 13:17:15.758164
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test = CacheModule()
    assert test._load('/tmp/jsonfilecache')
    assert test._dump('/tmp/jsonfilecache', 'some_tmp_file')

# Generated at 2022-06-11 13:17:17.257571
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin is not None

# Generated at 2022-06-11 13:17:22.441924
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Ensures that a complete constructor was built.
    cachedir = "test_dir"
    prefix = "test_prefix"
    timeout = 3
    cache = CacheModule(cachedir=cachedir, prefix=prefix, timeout=timeout)
    assert cache.cachedir == "test_dir"
    assert cache.prefix == "test_prefix"
    assert cache.timeout == 3

# Generated at 2022-06-11 13:17:29.404227
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({}, '')

# Generated at 2022-06-11 13:17:30.931532
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module.x is None
    assert module.y is None

# Generated at 2022-06-11 13:17:32.269677
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert isinstance(cache_plugin, CacheModule)

# Generated at 2022-06-11 13:17:36.699380
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._data == dict()
    assert cache_module._filepath == None
    assert cache_module._cache == dict()
    assert cache_module._plugin_name == 'jsonfile'
    assert cache_module._timeout == 86400
    assert cache_module._prefix == ''

# Generated at 2022-06-11 13:17:38.625209
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m._load is not None
    assert m._dump is not None

# Generated at 2022-06-11 13:17:39.761515
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule({}, {})
    assert cm is not None

# Generated at 2022-06-11 13:17:43.184221
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert isinstance(cache_plugin, CacheModule)
    assert isinstance(cache_plugin._config, dict)
    assert isinstance(cache_plugin._timeout, int)
    assert isinstance(cache_plugin._prefix, str)


# Generated at 2022-06-11 13:17:52.286903
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule(path='~')
    assert cache_module.plugin_name == 'jsonfile'

    # Plugin should have default timeout of 86400 seconds
    assert cache_module._timeout == 86400

    # Plugin should have default prefix of 'ansible_'
    assert cache_module._prefix == 'ansible_'

    # Plugin should have proper setters and getters
    cache_module.set('test', 'data')
    assert cache_module.get('test') == 'data'

    cache_module.delete('test')
    assert cache_module.get('test') is None

# Generated at 2022-06-11 13:17:54.228567
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Test that the constructor of the CacheModule class doesn't fail.
    """
    cache_module = CacheModule()

# Generated at 2022-06-11 13:17:55.212862
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module is not None

# Generated at 2022-06-11 13:18:09.551488
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-11 13:18:11.251910
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, BaseFileCacheModule)

# Generated at 2022-06-11 13:18:12.313109
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule, object)

# Generated at 2022-06-11 13:18:12.981246
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-11 13:18:23.139522
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import shutil
    import tempfile

    test_dir = tempfile.mkdtemp()


# Generated at 2022-06-11 13:18:24.907237
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_m = CacheModule()
    assert cache_m is not None
    assert cache_m.plugin_name == 'jsonfile'

# Generated at 2022-06-11 13:18:26.141608
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule.load()
    print(dir(cache))

# Generated at 2022-06-11 13:18:27.732536
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': 'fake', '_prefix': 'fake2', '_timeout': 'fake3'})

# Generated at 2022-06-11 13:18:29.729125
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """Unit test for constructor of class CacheModule."""
    cache_module_obj = CacheModule()
    assert cache_module_obj is not None, "Failed to create CacheModule"

# Generated at 2022-06-11 13:18:31.050433
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = "abcd1234"
    module = CacheModule(data)
    assert module is not None

# Generated at 2022-06-11 13:18:57.696772
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = BaseFileCacheModule()
    assert cm is not None
    assert cm.path == "."
    assert cm.timeout == 86400

# Generated at 2022-06-11 13:19:01.240489
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    c.set('testdata', 'testkey', b'{"test" : "data"}')
    data = c.get('testdata', 'testkey')
    assert data == {'test': 'data'}
    c.flush()

# Generated at 2022-06-11 13:19:04.723841
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module_test = CacheModule()
    assert module_test._plugin_name == 'jsonfile'
    assert module_test._timeout == 86400
    assert module_test._connection is None

# Generated at 2022-06-11 13:19:06.323957
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.opt_names == ["_uri", "_prefix", "_timeout"]

# Generated at 2022-06-11 13:19:09.811328
# Unit test for constructor of class CacheModule
def test_CacheModule():
    uri = 'test_uri'
    prefix = 'test_prefix'
    timeout = 10
    cache_module = CacheModule(uri, prefix, timeout)
    assert cache_module._uri == uri
    assert cache_module._prefix == prefix
    assert cache_module._timeout == timeout

# Generated at 2022-06-11 13:19:15.080783
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache import BaseFileCacheModule
    cache_plugin = CacheModule()
    assert isinstance(cache_plugin, BaseFileCacheModule)
    assert hasattr(cache_plugin, 'get')
    assert hasattr(cache_plugin, 'set')
    assert hasattr(cache_plugin, 'keys')
    assert hasattr(cache_plugin, 'contains')
    assert hasattr(cache_plugin, 'delete')

# Generated at 2022-06-11 13:19:17.763440
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test the constructor of class CacheModule
    cm1 = CacheModule()
    assert cm1 is not None

    # Test the constructor of class CacheModule with the default values of the arguments
    cm2 = CacheModule({'_prefix':'hostname','_timeout':86400,'_uri':'.'})
    assert cm2 is not None

# Generated at 2022-06-11 13:19:19.086568
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-11 13:19:23.210550
# Unit test for constructor of class CacheModule
def test_CacheModule():

    c = CacheModule()

    assert c.plugin_name == 'jsonfile', "Default plugin_name should be 'jsonfile'; got %s instead" % c.plugin_name
    assert c.timeout == 86400, "Default timeout should be 86400 seconds; got %d instead" % c.timeout
    assert c.extension == 'json', "Default extension should be 'json'; got %s instead" % c.extension

# Generated at 2022-06-11 13:19:24.639172
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-11 13:19:52.159916
# Unit test for constructor of class CacheModule
def test_CacheModule():

    plugin = CacheModule()

    for attr in ['get', 'set', 'keys', 'contains', 'delete', 'flush']:
        assert hasattr(plugin, attr)

# Generated at 2022-06-11 13:19:55.197177
# Unit test for constructor of class CacheModule
def test_CacheModule():
    conn = [(
        '{0}/ansible_facts/'
        .format(os.getcwd()),
        {'_timeout': 3600}
    )]
    plugin = CacheModule(conn)
    assert plugin._timeout == 3600

# Generated at 2022-06-11 13:20:03.015930
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Make sure we do not have a cache yet.
    # This can happen if the previous unit test is not successful.
    path_cache_plugin = '/tmp/ansible-cache-plugin'
    if os.path.exists(path_cache_plugin):
        shutil.rmtree(path_cache_plugin)
    cache_plugin = CacheModule({'_uri': 'file://' + path_cache_plugin})
    assert cache_plugin.path == path_cache_plugin
    assert cache_plugin.hash_name('localhost') == 'localhost'
    assert cache_plugin.get_cache_path(cache_plugin.hash_name('localhost')) == os.path.join(path_cache_plugin, 'localhost')



# Generated at 2022-06-11 13:20:03.837162
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin

# Generated at 2022-06-11 13:20:07.844281
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj._connection is None
    assert obj._timeout == 86400
    assert obj._prefix == ''
    assert obj._cache_lockfile is False
    assert obj._cache_files_dir is None
    assert obj._cache_lock_timeout == 0


# Generated at 2022-06-11 13:20:09.312483
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mycache = CacheModule()
    assert isinstance(mycache, CacheModule)


# Generated at 2022-06-11 13:20:10.464716
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None


# Generated at 2022-06-11 13:20:11.463088
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module

# Generated at 2022-06-11 13:20:13.357680
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    print("This is CacheModule's constructor: " + str(cache_plugin))


# Generated at 2022-06-11 13:20:14.174772
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert(CacheModule)


# Generated at 2022-06-11 13:20:40.744440
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert isinstance(module, CacheModule)

# Generated at 2022-06-11 13:20:42.422689
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m._load == m.load
    assert m._dump == m.dump

# Generated at 2022-06-11 13:20:43.890323
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.plugin_name == "jsonfile"

# Generated at 2022-06-11 13:20:46.290295
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filename = "test.json"
    connection = '/tmp/cache'
    cache = CacheModule(connection)
    cache.set(filename, "我爱你")
    assert cache.get(filename) == "我爱你"
    assert cache.has_changed is True

if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-11 13:20:47.134374
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None

# Generated at 2022-06-11 13:20:49.675029
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule(task_vars={ 'cache_plugin': 'jsonfile', 'cache_connection': '/tmp/jsonfileCachingCache' })
    print(module)
    assert isinstance(module, BaseFileCacheModule)

# Generated at 2022-06-11 13:20:51.386562
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert(isinstance(cache, CacheModule))


# Generated at 2022-06-11 13:20:52.259174
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(dict())

# Generated at 2022-06-11 13:20:54.905910
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule(None)

    assert isinstance(obj, CacheModule)
    assert isinstance(obj, BaseFileCacheModule)

    assert hasattr(obj, "_load")
    assert hasattr(obj, "_dump")

# Generated at 2022-06-11 13:20:56.674020
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)
    assert cache._load('test_file.json')

# Generated at 2022-06-11 13:21:59.582016
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    cache = CacheModule({'_uri': '/tmp'})
    assert cache is not None

# Generated at 2022-06-11 13:22:02.337947
# Unit test for constructor of class CacheModule
def test_CacheModule():
    datadir = '/tmp/ansible_cachedir'
    timeout = 2
    connection = CacheModule(datadir, timeout)
    assert connection._timeout == timeout
    assert connection._basedir == datadir
    assert connection._prefix == ''

# Generated at 2022-06-11 13:22:03.685026
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None


# Generated at 2022-06-11 13:22:05.628560
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.__class__.__name__ == 'CacheModule', "Didn't instantiate the class"

# Generated at 2022-06-11 13:22:08.680404
# Unit test for constructor of class CacheModule
def test_CacheModule():
    #We can not directly test the constructor since we need to setup the configuration. Here we test the instance creation.
    cache = CacheModule()
    assert isinstance(cache._cache, dict)
    # _connection property should exist
    assert hasattr(cache, '_connection')

# Generated at 2022-06-11 13:22:15.189168
# Unit test for constructor of class CacheModule
def test_CacheModule():
    try:
        import pytest
    except Exception:
        pytest = None

    @pytest.mark.skipif(pytest is None, reason='requires pytest')
    def test_load_dump(tmpdir):
        data = {'a': {'b': {'c': 'd'}}}
        fp = tmpdir.join('testfile')
        CacheModule(fp.strpath).set('default', 'foo', data)
        assert CacheModule(fp.strpath).get('default', 'foo') == data

    # Run the unit tests
    if pytest:
        test_load_dump(tmpdir)

# Generated at 2022-06-11 13:22:16.346454
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachemodule = CacheModule()
    assert isinstance(cachemodule, CacheModule)

# Generated at 2022-06-11 13:22:22.311397
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._opts[u'_timeout'] == 86400

    cm = CacheModule.load(u'''
       _timeout: 86401
       _uri: test/uri
       _prefix: test/prefix
    ''')
    assert cm._opts[u'_timeout'] == 86401
    assert cm._opts[u'_uri'] == u'test/uri'
    assert cm._opts[u'_prefix'] == u'test/prefix'

# Generated at 2022-06-11 13:22:25.547100
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import ansible.plugins.cache.jsonfile
    from ansible.plugins.cache.jsonfile import CacheModule
    cache_module_instance = ansible.plugins.cache.jsonfile.CacheModule()
    assert isinstance(cache_module_instance, CacheModule)

# Generated at 2022-06-11 13:22:28.211428
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.timeout == cache.DEFAULT_TIMEOUT
    assert cache.timeout == 86400
    cache = CacheModule(50)
    assert cache.timeout == 50

# Generated at 2022-06-11 13:24:32.748386
# Unit test for constructor of class CacheModule
def test_CacheModule():
    file_cache = CacheModule()
    assert file_cache != None
    assert isinstance(file_cache, CacheModule)
    assert isinstance(file_cache, BaseFileCacheModule)

# Generated at 2022-06-11 13:24:38.756423
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test data
    _uri = 'URI'
    _prefix = 'PREFIX'
    _timeout = 'TIMEOUT'
    options = {'_uri': _uri, '_prefix': _prefix, '_timeout': _timeout}
    cache_module = CacheModule(None, options)
    cache_plugin_connection = cache_module._uri
    cache_plugin_prefix = cache_module._prefix
    cache_plugin_timeout = cache_module._timeout

    # Assertions
    assert _uri == cache_plugin_connection
    assert _prefix == cache_plugin_prefix
    assert _timeout == cache_plugin_timeout

# Generated at 2022-06-11 13:24:41.364863
# Unit test for constructor of class CacheModule
def test_CacheModule():
    _jsonfile = CacheModule()
    
    # TODO: class methods & attributes
    assert hasattr(_jsonfile, 'get')
    assert hasattr(_jsonfile, 'set')
    assert hasattr(_jsonfile, 'delcache')

# Generated at 2022-06-11 13:24:42.925636
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Create an object of class CacheModule
    test_obj = CacheModule()
    assert test_obj is not None

# Generated at 2022-06-11 13:24:43.415980
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ch = CacheModule()

# Generated at 2022-06-11 13:24:44.852533
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mod = CacheModule()
    assert mod.file_extension == 'json'
    assert mod._timeout == 86400

# Generated at 2022-06-11 13:24:46.444916
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule('/tmp/fakedirconnect', '/tmp/fakedirprefix')
    assert cache_module


# Generated at 2022-06-11 13:24:48.133167
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm.get_timeout() == 86400

# Generated at 2022-06-11 13:24:48.947572
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()

# Generated at 2022-06-11 13:24:53.396618
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # GIVEN
    conn = 'test'
    prefix = 'test'
    timeout = 'test'

    # WHEN
    test_cache = CacheModule(conn, prefix, timeout)

    # THEN
    assert test_cache._connection == 'test'
    assert test_cache._prefix == 'test'
    assert test_cache._timeout == 'test'