

# Generated at 2022-06-11 13:15:14.540789
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule({})
    assert module

# Generated at 2022-06-11 13:15:17.452702
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule

    cache = CacheModule(connection='none', config={}, tmpdir='/tmp')
    assert cache._connection == 'none'
    assert cache._tmpdir == '/tmp'

###

# Generated at 2022-06-11 13:15:20.733900
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Unit test for CacheModule class constructor.
    :return:
    """
    cache_module = CacheModule()
    assert cache_module is not None
    assert cache_module.get_timeout() == 86400


# Generated at 2022-06-11 13:15:22.511579
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-vv'] + ["-s"])

# Generated at 2022-06-11 13:15:23.925144
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()  # instantiate the class

# Generated at 2022-06-11 13:15:25.221756
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, BaseFileCacheModule)

# Generated at 2022-06-11 13:15:26.917859
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None
    assert isinstance(c, CacheModule)

# Generated at 2022-06-11 13:15:30.131407
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache=CacheModule()
    assert isinstance(cache, BaseFileCacheModule)
    assert isinstance(cache._load, object)
    assert isinstance(cache._dump, object)

# Generated at 2022-06-11 13:15:37.512786
# Unit test for constructor of class CacheModule
def test_CacheModule():
    with open('./tests/unit/module_utils/jsonfile_cache_test.json', 'w') as f:
        json.dump({"example": "example"}, f)
    cachemodule = CacheModule()
    assert cachemodule.get("example") == {"example": "example"}
    assert cachemodule.set("example", {"example": "example"})
    n = 10
    for i in range(n):
        cachemodule.set(i, {})
    assert cachemodule.facts == [i for i in range(n)]

# Generated at 2022-06-11 13:15:41.734360
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin is not None
    assert cache_plugin.plugin_name == 'jsonfile'
    assert cache_plugin.plugin_path == "/Users/mingchun.wang/workspace/ansible2/lib/ansible/plugins/cache/jsonfile.py"

# Generated at 2022-06-11 13:15:46.441138
# Unit test for constructor of class CacheModule
def test_CacheModule():
    test_class = CacheModule()
    assert test_class.file_extension == 'json'

# Generated at 2022-06-11 13:15:49.929288
# Unit test for constructor of class CacheModule
def test_CacheModule():
    a = CacheModule({})
    assert a._timeout == 86400
    assert a._prefix is None
    assert a._load is None
    assert a._dump is None
    assert a._options['_uri'] is None

# Generated at 2022-06-11 13:15:52.445256
# Unit test for constructor of class CacheModule
def test_CacheModule():
  obj = CacheModule()
  assert 'CacheModule' in str(obj)
  assert obj._load(None) == None
  assert obj._dump(None,None) == None

# Generated at 2022-06-11 13:15:54.978430
# Unit test for constructor of class CacheModule
def test_CacheModule():
    d = {}
    d['plugin_name'] = 'jsonfile'
    d['plugin_args'] = {}
    cache = CacheModule(d)
    assert cache == CacheModule

# Generated at 2022-06-11 13:16:03.381481
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._connection == '~/.ansible/tmp/ansible-fact-cache'
    assert cache._prefix == 'ansible_fact_cache_'
    assert cache._timeout == 86400
    assert cache._timeout_nonce == cache._timeout * 4

    cache2 = CacheModule({'_uri': 'test', '_prefix': 'test_prefix_', '_timeout': 86400 * 10})
    assert cache2._connection == 'test'
    assert cache2._prefix == 'test_prefix_'
    assert cache2._timeout == 86400 * 10
    assert cache2._timeout_nonce == cache2._timeout * 4

# Generated at 2022-06-11 13:16:04.238502
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance( CacheModule(), CacheModule)

# Generated at 2022-06-11 13:16:13.758963
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile
    import shutil
    # Test the constructor
    plugin = CacheModule()
    # the plugin should have certain attributes
    assert plugin._connection is None
    assert plugin._prefix == ''
    assert plugin._timeout == 86400
    # Test the constructor with parameters
    tmp_path = tempfile.mkdtemp()
    plugin = CacheModule({'_uri':tmp_path, '_prefix':'test_prefix', '_timeout':'42'})
    assert plugin._connection == tmp_path
    assert plugin._prefix == 'test_prefix'
    assert plugin._timeout == 42
    # _load the json files in the tmp_path
    plugin.get('test_file')
    plugin._timeout = 0
    # Create files
    plugin.set('test_file', {'key': 'value'})
   

# Generated at 2022-06-11 13:16:16.435900
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

    #assert cache.FILES is False
    #assert cache._timeout == 60
    #assert cache._connection.run() == (1, '', '')

# Generated at 2022-06-11 13:16:18.605339
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert(cm._prefix == 'ansible_facts_')
    assert(cm._timeout == 86400)

# Generated at 2022-06-11 13:16:26.481873
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule(task_vars=dict(ansible_facts=dict(foo='bar')))
    assert plugin._connection.geturl() == '/tmp/ansible_fact_cache'
    assert plugin._timeout == 86400
    assert plugin._prefix == ''
    assert isinstance(plugin._connection, type(plugin._connection))
    facts = dict(foo='bar')
    facts_cache = plugin.get(plugin.key)
    assert facts_cache is None
    plugin.set(plugin.key, facts)
    facts_cache = plugin.get(plugin.key)
    assert facts_cache == facts
    plugin.flush()

# Generated at 2022-06-11 13:16:30.783125
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cachemodule = CacheModule()
    assert cachemodule._encoder == AnsibleJSONEncoder

# Generated at 2022-06-11 13:16:32.101426
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, BaseFileCacheModule)

# Generated at 2022-06-11 13:16:33.901202
# Unit test for constructor of class CacheModule
def test_CacheModule():
    my_test_obj = CacheModule()
    assert isinstance(my_test_obj, CacheModule)

# Generated at 2022-06-11 13:16:36.561198
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule({'_uri': "ansible_cache", '_prefix': ""})
    assert module._timeout == 86400
    assert module._prefix == ""

# Generated at 2022-06-11 13:16:37.162855
# Unit test for constructor of class CacheModule
def test_CacheModule():
    tmp = CacheModule()

# Generated at 2022-06-11 13:16:41.683056
# Unit test for constructor of class CacheModule
def test_CacheModule():
    connection = '/tmp'
    prefix = 'test_CacheModule_file'
    timeout = 1
    cache = CacheModule(connection, prefix, timeout)

    assert cache.plugin_name == 'jsonfile'
    assert cache._connection == connection
    assert cache._prefix == prefix
    assert cache._timeout == timeout

# Generated at 2022-06-11 13:16:42.378107
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-11 13:16:43.747506
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._load
    assert cm._dump

# Generated at 2022-06-11 13:16:48.628730
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = BaseFileCacheModule()
    assert c._prefix == 'ansible-cache'
    assert c._timeout == 86400
    assert c._plugin_name == 'jsonfile'

    c = BaseFileCacheModule(timeout=1)
    assert c._prefix == 'ansible-cache'
    assert c._timeout == 1
    assert c._plugin_name == 'jsonfile'

# Generated at 2022-06-11 13:16:54.007859
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    print(cache)
    assert isinstance(cache.get('localhost', 'ansible_os_family'), str)
    assert cache.get('localhost', 'ansible_os_family') == "Debian"
    assert cache.set('localhost', 'ansible_os_family', 'RedHat') == True
    assert cache.get('localhost', 'ansible_os_family') == "RedHat"
    assert cache.set('localhost', 'ansible_os_family', 'Windows') == True
    assert cache.get('localhost', 'ansible_os_family') == "Windows"

# Generated at 2022-06-11 13:17:01.859497
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Create an instance of CacheModule and verify the result.
    """
    x = CacheModule()
    assert(isinstance(x, CacheModule))

# Generated at 2022-06-11 13:17:04.049842
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert "jsonfile" == x._connection.split("://", 1)[0]
    assert "/tmp" == x._prefix

# Generated at 2022-06-11 13:17:04.720367
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({})

# Generated at 2022-06-11 13:17:05.891162
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)

# Generated at 2022-06-11 13:17:08.619493
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Unit test for constructor of class CacheModule.
    """
    cache = CacheModule(task_vars=dict())
    assert cache is not None


# Generated at 2022-06-11 13:17:09.917496
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert isinstance(obj, CacheModule)

# Generated at 2022-06-11 13:17:10.921049
# Unit test for constructor of class CacheModule
def test_CacheModule():
    mock_config = {}
    cm = CacheModule(mock_config)
    assert cm.config == mock_config
    assert cm.cache_key == 'jsonfile'



# Generated at 2022-06-11 13:17:12.318282
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.file_extension == '.cache'

# Generated at 2022-06-11 13:17:13.597517
# Unit test for constructor of class CacheModule
def test_CacheModule():
    jsonFileCache = CacheModule()
    assert jsonFileCache is not None


# Generated at 2022-06-11 13:17:15.407819
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    print(plugin)


if __name__ == '__main__':
    test_CacheModule()

# Generated at 2022-06-11 13:17:28.815001
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert isinstance(cacheModule,CacheModule)
    assert isinstance(cacheModule,BaseFileCacheModule)

# Generated at 2022-06-11 13:17:29.925168
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule(None, None, None)

# Generated at 2022-06-11 13:17:35.585701
# Unit test for constructor of class CacheModule
def test_CacheModule():
    data = dict()
    data[u'foo'] = u'bar'

    # Cache data
    cache = CacheModule({'_uri': '/tmp/ansible_cache'})
    cache['test'] = data

    assert cache['test'] == data

    # Load data
    cache = CacheModule({'_uri': '/tmp/ansible_cache'})
    assert cache['test'] == data


# Generated at 2022-06-11 13:17:37.270172
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print('Initializing...')
    cm = CacheModule()
    print('done.')


# Generated at 2022-06-11 13:17:42.158433
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filename = 'test.json'
    timeout = 90
    prefix = 'test_'
    cache = CacheModule()
    cache.set_options(direct={'timeout': timeout, '_uri': filename, '_uri': filename, '_prefix': prefix})
    assert cache.timeout == timeout
    assert cache.plugin_name == 'jsonfile'
    assert cache.plugin_vars == {}
    assert cache.file_name == filename
    assert cache.prefix == prefix

# Generated at 2022-06-11 13:17:44.015930
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule('/tmp/lol') is not None
    assert CacheModule('/tmp/lol/') is not None

# Generated at 2022-06-11 13:17:45.037620
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({}, {}) is not None

# Generated at 2022-06-11 13:17:56.843345
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert x is not None
    assert hasattr(x, 'get')
    assert hasattr(x, 'set')
    assert hasattr(x, '_load')
    assert hasattr(x, '_dump')
    # test constructor of BaseFileCacheModule
    assert hasattr(x, '_prefix')
    assert hasattr(x, '_timeout')
    assert hasattr(x, '_cache_dir')
    assert hasattr(x, '_get_cache_path')
    assert hasattr(x, '_get_cache_filename')
    assert hasattr(x, '_get_valid_file_keys')
    assert hasattr(x, '_get_cache_dir_contents')
    assert hasattr(x, 'get_valid_file_keys')

# Generated at 2022-06-11 13:18:03.501575
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Calling CacheModule's constructor with the following parameters results in the instance variable values asserted.
    # _uri: Path in which the cache plugin will save the JSON files
    # _prefix: User defined prefix to use when creating the JSON files
    # _timeout: Expiration timeout for the cache plugin data
    cache = CacheModule(
        'tmp/ansible_cached',
        'ansible_facts',
        86400
    )
    assert cache._cache_dir == 'tmp/ansible_cached'
    assert cache._prefix == 'ansible_facts'
    assert cache._timeout == 86400

# Generated at 2022-06-11 13:18:04.356750
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()
    assert plugin

# Generated at 2022-06-11 13:18:28.129161
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c

# Generated at 2022-06-11 13:18:28.513280
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-11 13:18:29.231407
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert isinstance(cache_module,CacheModule)

# Generated at 2022-06-11 13:18:31.050133
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule("/tmp/")
    assert cache._connection == "/tmp/"
    assert cache._timeout == 86400
    assert cache._prefix == "ansible-cache"

# Generated at 2022-06-11 13:18:32.779514
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.cache_prefix == 'ansible-fact'
    assert c.cache_timeout == 86400


# Generated at 2022-06-11 13:18:35.091293
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule(task_vars=dict(ansible_facts=dict(ansible_local=dict(a=1, b=2))))
    assert m is not None

# Generated at 2022-06-11 13:18:37.363062
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule({'_uri': '.', '_timeout': 1}).path == '.'
    assert CacheModule({'_uri': '.', '_timeout': 1}).timeout == 1

# Generated at 2022-06-11 13:18:39.872446
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(None, task_vars={})
    assert os.path.exists(cache.plugin_basedir)

# Generated at 2022-06-11 13:18:40.906953
# Unit test for constructor of class CacheModule
def test_CacheModule():
    main = CacheModule()
    assert main

# Generated at 2022-06-11 13:18:42.529746
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert(cache is not None)

# Generated at 2022-06-11 13:19:37.281177
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import os
    import tempfile

    # pylint: disable=too-many-function-args
    temp_dir = tempfile.mkdtemp(prefix='ansible-unittest')
    options = dict(
        _uri=temp_dir,
        _prefix=None,
        _timeout=None,
        # TODO: would be nice to make this configurable
        byte=False,
    )

    cache_module = CacheModule(**options)

    # Tests if files are created with correct name format
    cache_module.set('test_host_1', 'test_set_1', 'test_data_1')
    cache_module.set('test_host_2', 'test_set_2', 'test_data_2')

    host_files = [f for f in os.listdir(temp_dir)]



# Generated at 2022-06-11 13:19:40.582647
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule(uri=None, *{})
    assert isinstance(cache._decoder, AnsibleJSONDecoder)
    assert isinstance(cache._encoder, AnsibleJSONEncoder)
    assert cache._prefix == ''

# Generated at 2022-06-11 13:19:41.765166
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-11 13:19:42.609086
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-11 13:19:43.867700
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule()
    assert instance


# Generated at 2022-06-11 13:19:45.493941
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module_obj = CacheModule(task=None)
    assert cache_module_obj is not None

# Generated at 2022-06-11 13:19:46.607904
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert obj._load_cache_file('something') == None

# Generated at 2022-06-11 13:19:52.608326
# Unit test for constructor of class CacheModule
def test_CacheModule():
    def __new__(self, *args, **kwargs):
        return [args, kwargs]
    module_name = "jsonfile"
    cache_path = "ansible_fact_cache"
    plugin_timeout = 86400
    plugin_prefix = "ansible_facts"

    BaseFileCacheModule.__new__ = __new__
    result = CacheModule(module_name, cache_path, plugin_timeout, plugin_prefix)
    assert result == [[module_name, cache_path, plugin_timeout, plugin_prefix], {}]

# Generated at 2022-06-11 13:19:53.909704
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Test: constructor should not raise exception
    CacheModule(dict())

# Generated at 2022-06-11 13:19:56.233179
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    cache =  CacheModule()
    assert cache
    assert cache.__class__.__name__ == 'CacheModule'

# Generated at 2022-06-11 13:21:41.797624
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ca = CacheModule()
    assert ca is not None, "Failed to create CacheModule instance"


# Generated at 2022-06-11 13:21:43.116594
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache



# Generated at 2022-06-11 13:21:43.545741
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()

# Generated at 2022-06-11 13:21:45.451101
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule(module_args = dict(connection = './test_dir', prefix = 'prefix'))
    assert c.connection == './test_dir'
    assert c.prefix == 'prefix'


# Generated at 2022-06-11 13:21:51.123135
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_connection = '~/ansible/fact_caching'
    cache_prefix = 'prefix_testing'
    cache_timeout = 259200
    test_CacheModule = CacheModule(cache_connection, cache_prefix, cache_timeout)
    assert(test_CacheModule.cache_connection == cache_connection)
    assert(test_CacheModule.cache_prefix == cache_prefix)
    assert(test_CacheModule.cache_timeout == cache_timeout)

# Generated at 2022-06-11 13:21:59.544144
# Unit test for constructor of class CacheModule
def test_CacheModule():

    cache_plugin = CacheModule()

    assert cache_plugin._timeout == 86400
    assert cache_plugin._prefix == ''
    assert cache_plugin._load('jsonfile.py') == {'file_name': 'jsonfile.py', 'file_type': 'file', 'file_exists': True}

    cache_plugin = CacheModule(None, 'prefix')

    assert cache_plugin._timeout == 86400
    assert cache_plugin._prefix == 'prefix'
    assert cache_plugin._load('jsonfile.py') == {'file_name': 'jsonfile.py', 'file_type': 'file', 'file_exists': True}

    cache_plugin = CacheModule(None, 'prefix', 3600)

    assert cache_plugin._timeout == 3600
    assert cache_plugin._prefix == 'prefix'
    assert cache_

# Generated at 2022-06-11 13:22:01.710248
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Attempt to instantiate an instance of the CacheModule class and test whether object is successfully instantiated
    cm = CacheModule()
    assert isinstance(cm, CacheModule)

# Generated at 2022-06-11 13:22:03.028616
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), BaseFileCacheModule)

# Generated at 2022-06-11 13:22:04.838265
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache=CacheModule()

    assert(cache._load==CacheModule._load)
    assert(cache._dump==CacheModule._dump)

# Generated at 2022-06-11 13:22:05.785352
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(), CacheModule)