

# Generated at 2022-06-11 13:15:15.604631
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Checks for a valid instance of CacheModule.
    """

    assert CacheModule(None, {}, 'jsonfile', '/tmp') is not None

# Generated at 2022-06-11 13:15:16.783320
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None


# Generated at 2022-06-11 13:15:18.550438
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c._timeout == 86400
    assert c._prefix == u''

# Generated at 2022-06-11 13:15:19.141650
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-11 13:15:20.826402
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ans_obj = CacheModule()
    assert isinstance(ans_obj, CacheModule)


# Generated at 2022-06-11 13:15:22.076309
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.file_extension == 'json'

# Generated at 2022-06-11 13:15:25.171737
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # test constructor
    cm = CacheModule()
    # validate proper type
    assert isinstance(cm, CacheModule)
    # validate inherited properties
    assert hasattr(cm, "get")
    assert hasattr(cm, "set")
    assert hasattr(cm, "keys")
    assert hasattr(cm, "contains")
    assert hasattr(cm, "delete")
    assert hasattr(cm, "flush")
    assert hasattr(cm, "copy")


# Generated at 2022-06-11 13:15:25.725986
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()

# Generated at 2022-06-11 13:15:28.673064
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm is not None 
    assert dict == type(cm.cache_variables)
    assert 1 == len(cm.cache_variables)

# Generated at 2022-06-11 13:15:34.903451
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

    parameters = {'_uri': 'tmp'}
    cache_module.set_options(parameters)

    cached_data = {'this': 'that'}
    key = 'test'
    cache_module.set(key, cached_data)
    assert cache_module.get(key) == cached_data

    cache_module.flush()
    assert cache_module.get(key) is None  # noqa

# Generated at 2022-06-11 13:15:43.804754
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from collections import namedtuple
    from ansible.plugins.cache import BaseFileCacheModule

    def test_BaseFileCacheModule():
        BaseFileCacheModule()

    # Test normal funtionality:
    # If no exceptions are raised, the constructor works.
    test_BaseFileCacheModule()

    # Test handling of custom plugin options
    plugin_options = {'_ansible_base_cache_plugin_timeout': 10}
    test_BaseFileCacheModule(plugin_options)

# Generated at 2022-06-11 13:15:45.368937
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule({})

    assert plugin._value_version is None

# Generated at 2022-06-11 13:15:46.017258
# Unit test for constructor of class CacheModule
def test_CacheModule():
    CacheModule()

# Generated at 2022-06-11 13:15:47.144552
# Unit test for constructor of class CacheModule
def test_CacheModule():
  module = CacheModule()
  assert module is not None

# Generated at 2022-06-11 13:15:48.899919
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, BaseFileCacheModule)

# Generated at 2022-06-11 13:15:51.935864
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """ Test constructor of class CacheModule """
    cache_obj = CacheModule(task_vars={})
    assert isinstance(cache_obj, BaseFileCacheModule)
    assert isinstance(cache_obj, CacheModule)

# Generated at 2022-06-11 13:15:56.753758
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert module._prefix == 'ansible_facts'
    assert module._timeout == 86400
    assert module._plugin_name == 'jsonfile'
    assert module._plugin_env_var == 'ANSIBLE_CACHE_PLUGIN'
    assert module._load == CacheModule._load
    assert module._dump == CacheModule._dump


# Generated at 2022-06-11 13:16:05.840079
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_dir = '/tmp/ansible-test'
    cache_prefix = 'ansible-test'
    timeout = 50
    cache_plugin_connection = cache_dir
    cache_plugin_prefix = cache_prefix
    cache_plugin_timeout = timeout

    # Successfully loads module object
    assert CacheModule(cache_plugin_connection, cache_plugin_prefix, cache_plugin_timeout)

    # Module object - invalid cache_plugin_timeout
    cache_plugin_timeout = 'invalid'
    assert CacheModule(cache_plugin_connection, cache_plugin_prefix, cache_plugin_timeout)

    # Module object - invalid cache_plugin_prefix
    cache_plugin_prefix = b'invalid'
    assert CacheModule(cache_plugin_connection, cache_plugin_prefix, cache_plugin_timeout)

    # Module object - invalid cache_

# Generated at 2022-06-11 13:16:15.480415
# Unit test for constructor of class CacheModule
def test_CacheModule():
    from ansible.plugins.cache.jsonfile import CacheModule
    cache = CacheModule('/tmp')
    assert cache._prefix == ''
    assert cache._timeout == 86400
    assert cache._connection == '/tmp'
    cache = CacheModule('/tmp', 'ansible_test_')
    assert cache._prefix == 'ansible_test_'
    assert cache._timeout == 86400
    assert cache._connection == '/tmp'
    cache = CacheModule('/tmp', prefix='ansible_test_', timeout=5)
    assert cache._prefix == 'ansible_test_'
    assert cache._timeout == 5
    assert cache._connection == '/tmp'
    cache = CacheModule('/tmp', prefix='ansible_test_', timeout='6')
    assert cache._prefix == 'ansible_test_'
    assert cache._timeout

# Generated at 2022-06-11 13:16:16.944012
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert not isinstance(cache, CacheModule)

# Generated at 2022-06-11 13:16:24.053644
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # CacheModule constructor does not have any args
    assert CacheModule()

# Generated at 2022-06-11 13:16:26.393885
# Unit test for constructor of class CacheModule
def test_CacheModule():
    obj = CacheModule()
    assert isinstance(obj, CacheModule)

# Generated at 2022-06-11 13:16:28.911966
# Unit test for constructor of class CacheModule
def test_CacheModule():
    module = CacheModule()
    assert(callable(getattr(module, "_load")))
    assert(callable(getattr(module, "_dump")))


# Generated at 2022-06-11 13:16:30.690016
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache, "CacheModule() method did not return an object"

# Generated at 2022-06-11 13:16:33.581114
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._load == CacheModule._load
    assert cm._dump == CacheModule._dump
    assert cm._load('../../../../library/plugins/cache/jsonfile.py')

# Generated at 2022-06-11 13:16:43.999845
# Unit test for constructor of class CacheModule
def test_CacheModule():
    import tempfile
    import os
    import shutil

    temp_dir = tempfile.mkdtemp()
    test_cache = CacheModule({'_uri': temp_dir})
    test_entry = {"test_key": "test_value"}

    test_cache.set('test_entry', test_entry)
    assert test_cache.has_expired('test_entry') is False
    assert test_cache.get('test_entry') == test_entry
    assert os.path.exists(os.path.join(temp_dir, 'ansible_test_entry.cache')) is True

    test_cache.delete('test_entry')
    assert os.path.exists(os.path.join(temp_dir, 'ansible_test_entry.cache')) is False


# Generated at 2022-06-11 13:16:46.196494
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    # Check if object is an instance of class CacheModule
    assert isinstance(cacheModule, CacheModule)

# Generated at 2022-06-11 13:16:47.483568
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert isinstance(CacheModule(None), CacheModule)


# Generated at 2022-06-11 13:16:48.911554
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-11 13:16:51.027184
# Unit test for constructor of class CacheModule
def test_CacheModule():
    p = CacheModule(plugin_options=dict(plugin_option='plugin_option_value'))
    assert p.plugin_options['plugin_option'] == 'plugin_option_value'

# Generated at 2022-06-11 13:17:04.005284
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule(None).get_cache_prefix() == 'ansible-cache'

# Generated at 2022-06-11 13:17:06.868161
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule(['/tmp'])
    c._connection=None
    c._prefix='/tmp/123'
    c._load([])
    c._dump({},[])

# Generated at 2022-06-11 13:17:08.759621
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule({})
    assert cache.BASE_DIR == "/tmp/ansible-test-caching/"

# Generated at 2022-06-11 13:17:10.519752
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m._prefix == 'ansible-factcache'
    assert m._timeout == 86400

# Generated at 2022-06-11 13:17:11.890909
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, CacheModule)

# Generated at 2022-06-11 13:17:14.869821
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule('dummy_connection', 'dummy_prefix', 10)
    assert instance
    assert instance._connection == 'dummy_connection'
    assert instance._prefix == 'dummy_prefix'
    assert instance._timeout == 10

# Generated at 2022-06-11 13:17:15.238883
# Unit test for constructor of class CacheModule
def test_CacheModule():

    CacheModule()

# Generated at 2022-06-11 13:17:17.832422
# Unit test for constructor of class CacheModule
def test_CacheModule():

    assert CacheModule(plugin_name = 'test', task_vars = {}).plugin_name == 'test', \
        "Error: constructor of class CacheModule"

# Generated at 2022-06-11 13:17:18.711229
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert Callable(CacheModule())

# Generated at 2022-06-11 13:17:21.289487
# Unit test for constructor of class CacheModule
def test_CacheModule():

    # Prevent lookup_plugin from looking up string as a class
    from ansible.plugins.cache.jsonfile import CacheModule
    CacheModule(None).get_cache_plugin_options()

# Generated at 2022-06-11 13:17:34.663478
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert isinstance(cache, BaseFileCacheModule)

# Generated at 2022-06-11 13:17:35.405270
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

# Generated at 2022-06-11 13:17:37.093778
# Unit test for constructor of class CacheModule
def test_CacheModule():
    ma = CacheModule()
    assert ma._load == CacheModule._load
    assert ma._dump == CacheModule._dump

# Generated at 2022-06-11 13:17:38.078663
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    cache_plugin._load('file/path/json')
    cache_plugin._dump('value', 'file/path/json')

# Generated at 2022-06-11 13:17:46.131995
# Unit test for constructor of class CacheModule
def test_CacheModule():
    '''
    This is a constructor test for the CacheModule Class.
	
    This function will do the following:
	1. Instance creation
	2. Checking the default settings in the plugin
	3. Test the instance variables
	
    Test input:
    [1] Instance of the class CacheModule
	
	Expected output:
	[1] _uri: /tmp/ansible_fact_cache
	    _prefix: ansible_facts
	    _timeout: 86400

    '''

    cache_module = CacheModule()

    assert cache_module._uri == '/tmp/ansible_fact_cache'
    assert cache_module._prefix == 'ansible_facts'
    assert cache_module._timeout == 86400



# Generated at 2022-06-11 13:17:49.945423
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module.file_extension == '.cache'
    assert cache_module.cache_type == 'jsonfile'
    assert cache_module.cache_timeout == 86400

# Generated at 2022-06-11 13:17:57.504497
# Unit test for constructor of class CacheModule
def test_CacheModule():
    file_cache_conn = 'test/path'
    file_cache_prefix = 'prefix'
    file_cache_timeout = 34567
    cache_module = CacheModule()
    args = dict()
    args['_uri'] = file_cache_conn
    args['_prefix'] = file_cache_prefix
    args['_timeout'] = file_cache_timeout
    cache_module.set_options(args)
    assert cache_module.path == file_cache_conn
    assert cache_module.plugin_name == 'jsonfile'

# Generated at 2022-06-11 13:17:58.955056
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None

# Generated at 2022-06-11 13:18:06.559797
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    filepath = ''
    # value is a string
    value = 'test value'
    cacheModule._dump(value, filepath)
    assert cacheModule._load(filepath) == value
    # value is a dict
    value = {'key1': 'value1', 'key2': None}
    cacheModule._dump(value, filepath)
    assert cacheModule._load(filepath) == value
    # value is a list
    value = ['value1', 'value2']
    cacheModule._dump(value, filepath)
    assert cacheModule._load(filepath) == value
    # value is a list which contains a dict
    value = ['value1', {'key1': 'value1'}]
    cacheModule._dump(value, filepath)

# Generated at 2022-06-11 13:18:09.479972
# Unit test for constructor of class CacheModule
def test_CacheModule():
    m = CacheModule()
    assert m.plugin == "jsonfile"

# Generated at 2022-06-11 13:18:37.846596
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load('test_file') == None
    assert cache._dump('test_string', 'test_file') == None
    assert cache.get('test_file') == None
    assert cache.set('test_file', 'test_dict') == True

# Generated at 2022-06-11 13:18:43.542802
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # TODO: test if the cache module can be constructed, run and has the expected results
    cache_plugin = CacheModule()
    cache_plugin.set('localhost', 'example', 'sample')
    if cache_plugin.get('localhost', 'example') == 'sample':
        print('test passed!')

if __name__ == "__main__":
    test_CacheModule()

# Generated at 2022-06-11 13:18:53.839577
# Unit test for constructor of class CacheModule

# Generated at 2022-06-11 13:18:55.210948
# Unit test for constructor of class CacheModule
def test_CacheModule():
    instance = CacheModule(sys.argv[0])
    assert isinstance(instance, CacheModule)

# Generated at 2022-06-11 13:18:58.136636
# Unit test for constructor of class CacheModule
def test_CacheModule():
    path = "TestPath"
    timeout = "TestTimeout"
    cacheMod = CacheModule(None, path, timeout)
    assert (path == cacheMod._connection._uri)
    assert (timeout == cacheMod._connection._timeout)


# Generated at 2022-06-11 13:18:59.191462
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm != None

# Generated at 2022-06-11 13:19:00.084839
# Unit test for constructor of class CacheModule
def test_CacheModule():
    raise NotImplementedError

# Generated at 2022-06-11 13:19:01.282723
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule()._load('/tmp/ansible_json.json') == "json"

# Generated at 2022-06-11 13:19:04.362944
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._connection is None
    assert cache._timeout == 86400
    assert cache._prefix == ''

# Generated at 2022-06-11 13:19:05.951484
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache._load == CacheModule._load
    assert cache._dump == CacheModule._dump

# Generated at 2022-06-11 13:19:32.342257
# Unit test for constructor of class CacheModule
def test_CacheModule():
    print("Testing CacheModule::__init__")
    module = CacheModule()
    assert isinstance(module, BaseFileCacheModule)

# Generated at 2022-06-11 13:19:33.203815
# Unit test for constructor of class CacheModule
def test_CacheModule():
    """
    Constructor for class CacheModule
    """
    assert CacheModule(None)

# Generated at 2022-06-11 13:19:34.095129
# Unit test for constructor of class CacheModule
def test_CacheModule():
    plugin = CacheModule()


# Generated at 2022-06-11 13:19:35.862658
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cacheModule = CacheModule()
    assert cacheModule._load() is None
    assert cacheModule._dump() is None

# Generated at 2022-06-11 13:19:36.769089
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c is not None

# Generated at 2022-06-11 13:19:37.595489
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()


# Generated at 2022-06-11 13:19:38.747405
# Unit test for constructor of class CacheModule
def test_CacheModule():
  assert CacheModule is not None


# Generated at 2022-06-11 13:19:42.036399
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_plugin = CacheModule()
    assert cache_plugin.name == 'jsonfile'
    assert cache_plugin.extension == '.json'
    assert cache_plugin.supports_encrypt is False
    assert cache_plugin.supports_path_general is True

# Generated at 2022-06-11 13:19:43.328631
# Unit test for constructor of class CacheModule
def test_CacheModule():
    x = CacheModule()
    assert x.name().startswith('jsonfile')

# Generated at 2022-06-11 13:19:44.513889
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c.file_extension == 'json'

# Generated at 2022-06-11 13:20:43.153144
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert issubclass(CacheModule, BaseFileCacheModule)
    assert callable(CacheModule)
    cache_module = CacheModule()
    assert cache_module._load('/tmp/test') is None
    cache_module._dump('test', '/tmp/test')
    assert cache_module._load('/tmp/test') == "test"

# Generated at 2022-06-11 13:20:47.622640
# Unit test for constructor of class CacheModule
def test_CacheModule():
    filename = "/tmp/test"
    key = 'testkey'
    value = 'testvalue'
    cache_module = CacheModule()
    cache_module.set(filename, key, value)
    assert cache_module.get(filename, key) == value
    cache_module.delete(filename, key)
    assert cache_module.get(filename, key) == None

# Generated at 2022-06-11 13:20:49.564644
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module._load({}) == {}
    assert cache_module._dump({}, "") == None

# Generated at 2022-06-11 13:20:51.345776
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()

    # Check for type object
    assert isinstance(c, CacheModule)

# Generated at 2022-06-11 13:20:52.593090
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache is not None


# Generated at 2022-06-11 13:20:54.823897
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert_args = {'_uri': '/tmp/ansible'}
    cache_module = CacheModule(assert_args)
    assert cache_module.plugin == 'jsonfile'

# Generated at 2022-06-11 13:20:58.962041
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.get_basedir() == '~/.ansible/tmp/ansible-fact-cache'
    cache = CacheModule(basedir='/tmp')
    assert cache.get_basedir() == '/tmp'
    cache = CacheModule(timeout=1)
    assert cache.get_timeout() == 1

# Generated at 2022-06-11 13:21:00.327455
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()
    assert cache_module

# Generated at 2022-06-11 13:21:02.919586
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()
    assert cache.URI == '~/.ansible/tmp/ansible-local'
    assert cache.TIMEOUT == 86400

# Generated at 2022-06-11 13:21:04.896556
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    # Just test that we get back an instance of LazyFile
    assert isinstance(cm, BaseFileCacheModule)

# Generated at 2022-06-11 13:23:03.295427
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cm = CacheModule()
    assert cm._prefix == u'ansible-cache'
    assert cm._timeout == 86400
    assert cm._connection == u''

# Generated at 2022-06-11 13:23:04.122375
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

# Generated at 2022-06-11 13:23:04.606605
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache = CacheModule()

# Generated at 2022-06-11 13:23:05.086387
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule

# Generated at 2022-06-11 13:23:06.910380
# Unit test for constructor of class CacheModule
def test_CacheModule():
    cache_module = CacheModule()

    assert isinstance(cache_module, CacheModule)

# Generated at 2022-06-11 13:23:07.818409
# Unit test for constructor of class CacheModule
def test_CacheModule():
    c = CacheModule()
    assert c

# Generated at 2022-06-11 13:23:08.857868
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # Should not raise an exception
    CacheModule()

# Generated at 2022-06-11 13:23:14.117059
# Unit test for constructor of class CacheModule
def test_CacheModule():
    # create object CacheModule()
    my_mock = {}
    my_mock['src'] = 'tests/unit/lib/ansible/plugins/cache/test_jsonfile.py'

    with patch.object(BaseFileCacheModule, '__init__', return_value=None) as mock_method:
        a = CacheModule()
        mock_method.assert_called_once_with(my_mock)

        assert a._timeout == 86400


# Generated at 2022-06-11 13:23:16.511068
# Unit test for constructor of class CacheModule
def test_CacheModule():

    a = CacheModule()
    result = a.get('a')
    assert result == None
    a.set('a',5)
    result = a.get('a')
    assert result != None

# Generated at 2022-06-11 13:23:17.204826
# Unit test for constructor of class CacheModule
def test_CacheModule():
    assert CacheModule