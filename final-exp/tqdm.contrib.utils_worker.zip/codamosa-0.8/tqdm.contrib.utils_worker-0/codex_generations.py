

# Generated at 2022-06-12 14:58:14.442998
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def run_lengthy_task(name):
        sleep(2)
        tqdm_auto.write(name)

    mono_worker = MonoWorker()
    runner1 = mono_worker.submit(run_lengthy_task, "A")
    runner2 = mono_worker.submit(run_lengthy_task, "B")
    runner3 = mono_worker.submit(run_lengthy_task, "C")
    runner4 = mono_worker.submit(run_lengthy_task, "D")
    assert runner1.cancel()
    assert runner1.done()
    assert tqdm_auto.write.last_line == "B"
    assert runner2.cancel()
    assert runner2.done()
    assert tqdm_auto.write.last_line == "C"

# Generated at 2022-06-12 14:58:20.827138
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    def two(): sleep(2); return 2

    mw = MonoWorker()
    res = []  # mimic an actual main code/user
    for i in tqdm_auto.tqdm([1, 1, 1, 1], 'Testing', file=tqdm_auto.sys.stderr):
        # Should be: 1| 2| 3 or 1|> 2|> 3 or 1|> 2| 3
        res.append(int(mw.submit(two).result()))
        sleep(1)
    assert res == [1, 2, 2, 2], 'got {}'.format(res)



# Generated at 2022-06-12 14:58:30.477633
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    m = MonoWorker()
    def f():
        pass

    assert len(m.futures) == 0
    assert m.futures.maxlen == 2
    m.submit(f)
    assert len(m.futures) == 1
    m.submit(f)
    assert len(m.futures) == 1
    m.submit(f)
    assert len(m.futures) == 0
    m.submit(f)
    assert len(m.futures) == 1
    m.submit(f)
    assert len(m.futures) == 1
    m.submit(f)
    assert len(m.futures) == 0
    m.submit(f)
    assert len(m.futures) == 1
    m.submit(f)

# Generated at 2022-06-12 14:58:35.998953
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import tqdm

    def f(s):
        time.sleep(s)
        return s

    MW = MonoWorker()
    for i in tqdm.trange(3):
        MW.submit(f, i)
    for i in tqdm.trange(2):
        assert f(i).result() == i
    MW.submit(f, 3)
    assert f(2).result() == 2

# Generated at 2022-06-12 14:58:45.013666
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from contextlib import contextmanager
    from distutils.version import LooseVersion
    from subprocess import Popen, PIPE
    from threading import Event
    import sys
    try:
        from subprocess import DEVNULL
    except ImportError:
        DEVNULL = -3

    import pytest
    try:
        import pytest_timeout
        pytest_timeout = pytest_timeout.plugin
    except ImportError:
        pytest_timeout = None
        print("Install `pytest-timeout` for more efficient unit tests.")


# Generated at 2022-06-12 14:58:55.759055
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 14:59:03.108714
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import Value
    from time import sleep

    running = Value('i', 0)

    def start_and_stop(delay):
        """Start and stop running/waiting function."""
        sleep(delay)
        running.value += 1

    mono = MonoWorker()
    assert running.value == 0
    mono.submit(start_and_stop, 0.1)
    mono.submit(start_and_stop, 0.1)
    mono.submit(start_and_stop, 0.1)
    mono.submit(start_and_stop, 0.1)
    sleep(0.2)
    assert running.value == 2

    mono = MonoWorker()
    assert running.value == 2
    mono.submit(start_and_stop, 0.5)

# Generated at 2022-06-12 14:59:10.243726
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .tqdm_test_utils import FakeTTY, StringIO

    class Noop(object):
        def __init__(self):
            self.s = ''
        def __call__(self, s):
            sleep(0.01)
            self.s += s

    f = FakeTTY(StringIO())

    a = Noop()
    b = Noop()
    c = Noop()
    worker = MonoWorker()

    worker.submit(a, '1')
    worker.submit(b, '2')
    worker.submit(c, '3')  # b is discarded
    sleep(0.05)
    worker.submit(a, '4')  # b is discarded
    sleep(0.05)
    worker.submit(b, '5')  # a is discarded

# Generated at 2022-06-12 14:59:17.576542
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def report(status, *args, **kwargs):
        # print("\033[K", '', sep='', end='')
        tqdm_auto.write("  status = {0}; args = {1}; kwargs = {2}".format(
            status, args, kwargs))

    def task(sleep_time, status='', a=0, b=0):
        sleep(sleep_time)
        report(status, a, b)

    tqdm_auto.write("|---------+---------+---------|")
    tqdm_auto.write("|         |         |         |")
    tqdm_auto.write("|         |         |         |")
    tqdm_auto.write("|         |         |         |")

# Generated at 2022-06-12 14:59:27.188736
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures

    def long_running():
        time.sleep(1)
        return 'long_running'

    def long_waiting():
        time.sleep(5)
        return 'long_waiting'

    def short_running():
        time.sleep(1)
        return 'short_running'

    def short_waiting():
        time.sleep(0.5)
        return 'short_waiting'

    with MonoWorker() as pool:
        result = []
        future = pool.submit(long_running)
        result.append(future.result())
        future = pool.submit(long_waiting)
        future = pool.submit(short_running)
        result.append(future.result())
        future = pool.submit(short_waiting)
        future.result

# Generated at 2022-06-12 14:59:39.030915
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Simple test of `MonoWorker.submit` that tests that
    only the most recent submit is running.
    """
    from multiprocessing import Process, Queue
    from time import sleep

    def method1(q):
        q.put(1)
        sleep(2)
        q.put(2)

    def method2(q):
        q.put(3)
        sleep(2)
        q.put(4)

    q = Queue()
    mw = MonoWorker()
    mw.submit(method1, q)
    sleep(0.1)
    mw.submit(method2, q)
    p = Process(target=q.get)
    p.start()
    p.join(0.1)

# Generated at 2022-06-12 14:59:45.707029
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from os import getpid

    def check_pid(proc_id):
        sleep(1)
        assert proc_id == getpid()

    worker = MonoWorker()
    _ = worker.submit(check_pid, getpid())
    _ = worker.submit(check_pid, getpid())
    _ = worker.submit(check_pid, getpid())
    worker.pool.shutdown(False)
    worker.submit(check_pid, getpid())
    worker.pool.shutdown(False)
    worker.submit(check_pid, getpid())
    worker.pool.shutdown(False)

# Generated at 2022-06-12 14:59:54.867264
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .utils import _sleep
    import time
    import sys

    # Check that it works for no waiting/running tasks
    mw = MonoWorker()
    t0 = time.time()
    mw.submit(_sleep, 1)
    assert time.time() - t0 <= 1

    # Check that it works for a waiting task
    mw = MonoWorker()
    t0 = time.time()
    mw.submit(_sleep, 100)
    mw.submit(_sleep, 1)
    assert time.time() - t0 <= 1

    # Check that it works for a running task
    mw = MonoWorker()
    t0 = time.time()

# Generated at 2022-06-12 15:00:04.907005
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import random

    # Randomly sleeps between 1 and 2 seconds (and prints to stdout)
    def test_func(strarg):
        time.sleep(random.randint(1, 2))
        print(strarg)

    # Initialize
    mw = MonoWorker()

    # Submit task1 and wait for it to finish
    mw.submit(test_func, "task1_finished")
    time.sleep(1)  # make sure task1 has started

    # Submit task2 and wait for it to finish
    mw.submit(test_func, "task2_finished")

    threading.Event().wait(6)  # wait at most 6 seconds (long enough)
    # The behavior is not deterministic but should result in:
    #   task1_finished
    #   task

# Generated at 2022-06-12 15:00:15.133393
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def worker(timeout, string=""):
        """Simulate some blocking IO for a given time."""
        tqdm_auto.sleep(timeout)
        return string

    mono_worker = MonoWorker()

    # Test method submit of class MonoWorker
    from .tests import TestCase
    TestCase().assertEqual(mono_worker.submit(worker, 0, "first").result(), "first")
    TestCase().assertEqual(mono_worker.submit(worker, 0.1, "second").result(), "second")
    TestCase().assertEqual(mono_worker.submit(worker, 0.5, "third").result(), "second")
    TestCase().assertEqual(mono_worker.submit(worker, 0, "fourth").result(), "second")

# Generated at 2022-06-12 15:00:19.259959
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    m = MonoWorker()
    running = m.submit(lambda: 1)
    try:
        m.submit(lambda: 1)
        raise RuntimeError("Should never reach here")
    except Exception as e:
        tqdm_auto.write("Exception reached: " + str(e))
    running.result()
    tqdm_auto.write("Result reached: " + str(running.result()))

# Generated at 2022-06-12 15:00:29.663153
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from threading import Thread
    mw = MonoWorker()

    def f1():
        #print("f1 start")
        time.sleep(10)
        #print("f1 end")

    def f2():
        #print("f2 start")
        time.sleep(10)
        #print("f2 end")

    def f3():
        #print("f3 start")
        time.sleep(10)
        #print("f3 end")

    def f4():
        #print("f4 start")
        time.sleep(10)
        #print("f4 end")

    if 0:
        mw.submit(f1)
        time.sleep(1)
        mw.submit(f2)
        time.sleep(1)


# Generated at 2022-06-12 15:00:37.626925
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    '''
    This is a test function to do the following:
    1. Create a MonoWorker object, called w
    2. For i from 1 to 5
       (1) submit a task to w
       (2) If the task is running, set time.sleep(1), if the task is waiting,
           cancel the task.
       (3) After 5 seconds, examine the result
    '''
    import time
    cnt = 0
    def dummyfunc():
        '''This is a dummy function to be executed by w'''
        global cnt
        time.sleep(1)
        cnt += 1

    w = MonoWorker()

    for _ in range(5):
        w.submit(dummyfunc)
        if w.futures[0].running():
            time.sleep(1)

# Generated at 2022-06-12 15:00:45.635489
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event, Thread
    from itertools import permutations

    mw = MonoWorker()

    # Case: empty, only running
    # -func1-
    res = []
    mw.submit(res.append, 1)
    time.sleep(0.01)
    assert res == [1]
    mw.submit(time.sleep, 0.05)
    time.sleep(0.01)
    assert res == [1]
    mw.submit(res.append, 2)
    time.sleep(0.01)
    assert res == [1, 2]

    # Case: running + waiting
    # -func2-
    evt2 = Event()
    def func2(res):
        time.sleep(0.03)
        res.append(2)
       

# Generated at 2022-06-12 15:00:55.367290
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from . import StatusPrinter, time_sleep

    def slow_fib(n):
        if n < 2:
            return n
        else:
            return slow_fib(n-1) + slow_fib(n-2)

    t = MonoWorker()

    def func(n: int, printer: StatusPrinter, sleep: float = 0, name: str = 'fibonacci number') -> int:
        with printer:
            time_sleep(sleep)
            fib_n = slow_fib(n)
            printer.write('The {} of {} is:'.format(name, n))
            return fib_n

    p = StatusPrinter()

    t.submit(func, 10, p, sleep=0.5, name='10th')
    time_sleep(0.25)
   

# Generated at 2022-06-12 15:01:07.622596
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from os import getpid
    from os.path import basename
    from concurrent.futures import Future
    from unittest import TestCase, main

    def make_slow_func(indent):
        def func(name, sleep_time):
            sleep(sleep_time)
            tqdm_auto.write(indent*" " + basename(name) + " " + str(getpid()))

        return func

    class MonoWorkerTest(TestCase):
        def test_empty_wait(self):
            mono = MonoWorker()
            self.assertEqual(len(mono.futures), 0)
            mono.submit(make_slow_func(0), "test_empty_wait", 0)
            sleep(0.01)

# Generated at 2022-06-12 15:01:11.321242
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from math import sqrt
    from tqdm import trange
    mw = MonoWorker()
    for i in trange(10):
        mw.submit(sleep, 1)
        sleep(0.1)
        mw.submit(sqrt, i)
        sleep(0.1)

# Generated at 2022-06-12 15:01:18.382172
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import traceback

    def func(n):
        time.sleep(2)
        return n

    mono = MonoWorker()

    for i in range(5):
        fut = mono.submit(func, i)
        print('Running', fut.running())
    for i in range(5):
        print('Running', mono.futures[0].running())
        time.sleep(1)
    for i in range(5):
        fut = mono.submit(func, i)
        print('Running', fut.running())
    for i in range(5):
        print('Running', mono.futures[0].running())
        time.sleep(1)

# Generated at 2022-06-12 15:01:27.546154
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    # define a dummy task
    def test_task(delay):
        time.sleep(delay)
        return delay
    # create a MonoWorker
    mono_worker = MonoWorker()
    # start several tasks
    task_list = []
    for i in range(5):
        task_list.append(mono_worker.submit(test_task, 0.2))
    time.sleep(0.1)
    assert len(mono_worker.futures) == 1
    time.sleep(0.3)
    assert len(mono_worker.futures) == 0
    # start another task
    task_list.append(mono_worker.submit(test_task, 0.3))
    assert len(mono_worker.futures) == 1
    #

# Generated at 2022-06-12 15:01:35.156406
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(x):
        import time
        time.sleep(x)
        return x

    from timeit import default_timer as timer
    mw = MonoWorker()
    a = mw.submit(f, 1)
    b = mw.submit(f, 1)
    c = mw.submit(f, 1)
    assert mw.futures == deque([a, b])
    t0 = timer()
    assert not a.done()
    assert b.result() == 1
    assert a.result() == 1
    assert timer() - t0 > 1.9

# Generated at 2022-06-12 15:01:43.931335
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    def test(i):
        import time
        time.sleep(i + 1)
        return i
    mw = MonoWorker()
    # test simple running
    f1 = mw.submit(test, 1)
    assert f1.result() == 1
    # test simple waiting
    f2 = mw.submit(test, 2)
    f3 = mw.submit(test, 3)
    assert f3.result() == 3
    assert f2.cancelled()
    # test running and waiting
    test_done = False
    f6 = mw.submit(test, 6)
    f4 = mw.submit(test, 4)
    f5 = mw.submit(test, 5)
    def result_cb(f):
        non

# Generated at 2022-06-12 15:01:51.595769
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from .tests_tqdm import disc_time, disc_callable
    m = MonoWorker()
    lock = Lock()
    tmp = []

    def with_lock(func, *args, **kwargs):
        with lock:
            return func(*args, **kwargs)

    def add(x, y, sleep_for=None):
        if sleep_for:
            sleep(sleep_for)
        return x + y
    with_lock(tmp.append, m.submit(add, 1, 2))
    with_lock(tmp.append, m.submit(add, 3, 4, sleep_for=0.1))
    with_lock(tmp.append, m.submit(add, 5, 6, sleep_for=0.2))

    # test that the

# Generated at 2022-06-12 15:01:59.987783
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, time
    from random import randrange
    from threading import Thread
    from multiprocessing import Queue, cpu_count

    num_threads = cpu_count() * 2
    num_tasks = num_threads * 2
    max_delay = 10
    timeout = max_delay * num_threads * 2

    def run(worker, results):
        def task(i):
            sleep(randrange(max_delay))
            results.put((i, time()))
        for i in range(num_tasks):
            worker.submit(task, i)

    t = time()
    results = Queue()
    worker = MonoWorker()
    Thread(target=run, args=(worker, results)).start()

# Generated at 2022-06-12 15:02:03.406994
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(x):
        time.sleep(1)
        return x

    worker = MonoWorker()
    for i in tqdm_auto.tqdm(range(4)):
        worker.submit(f, i)
        time.sleep(0.5)


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:02:07.806516
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=missing-docstring
    import time
    from multiprocessing import cpu_count
    mw = MonoWorker()

    # Make sure only max_workers - 1 tasks running
    def f(time_to_sleep):
        time.sleep(time_to_sleep)
    mw.submit(f, 1e-99)
    mw.submit(f, 0.1)
    mw.submit(f, 0.2)
    for _ in range(2048):
        mw.submit(f, 1e-99)
    time.sleep(0.1)

    # Test max_workers
    def f_max_workers(max_workers_):
        mw.pool._max_workers = max_workers_

# Generated at 2022-06-12 15:02:20.341430
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    tqdm_auto.write('start')
    mw.submit(lambda: time.sleep(5))
    tqdm_auto.write('first .5s')
    time.sleep(.5)
    tqdm_auto.write('second .5s')
    time.sleep(.5)
    mw.submit(lambda: time.sleep(5), wait=False)
    tqdm_auto.write('third .5s')
    time.sleep(.5)
    mw.submit(lambda: time.sleep(5), wait=False)
    tqdm_auto.write('end')

# Generated at 2022-06-12 15:02:25.526473
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import randint
    from time import sleep
    from ..utils import SafeException, _environ_cols_wrapper

    method_name = "test_MonoWorker_submit"
    method_name_length = len(method_name) + 5  # add length of "test_" and "()"

    def _print(*args):
        """
        Prints arguments with a timestamp and indentation.
        """
        tqdm_auto.write("{:.3f}".format(tqdm_auto.default_timer()),
                        end="\t|\t" * depth)
        tqdm_auto.write(*args)


# Generated at 2022-06-12 15:02:33.002154
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from functools import partial
    from ..utils import CloseableResult
    from ..utils import _supports_unicode
    from ..utils import _environ_cols_wrapper

    # On Python 2, `sys.stdout.write` doesn't support `unicode` in
    # `PYTHONIOENCODING` mode, so we use ANSI escape codes.
    # See: https://bugs.python.org/issue23051
    if not _supports_unicode(tqdm_auto.write):
        ansi_support = True
    else:
        ansi_support = False
    tqdm_auto.write('\n' * 10)
    sleep(0.01)

# Generated at 2022-06-12 15:02:35.833527
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..auto import trange
    w = MonoWorker()

    def push(x):
        sleep(.1)

    for _ in trange(10, leave=True):
        w.submit(push, _)



# Generated at 2022-06-12 15:02:45.720427
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    m = MonoWorker()
    f = m.submit(lambda: 'hi')
    try:
        assert f.result() == 'hi'
        assert f.cancel() == False
        f = m.submit(lambda: 'bye')
        assert f.cancel() == True
        f = m.submit(lambda: 'bye')
        assert f.result() == 'bye'
        f = m.submit(lambda: 'hello')
        assert m.futures[0] != f
        f.cancel()
        assert len(m.futures) == 1
        assert m.futures[0].result() == 'bye'
        f = m.submit(lambda: 'hello')
        assert f.result() == 'hello'
    except Exception as e:
        print(e)
        assert False
        return

# Generated at 2022-06-12 15:02:52.603905
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .utils import TestCase
    from .utils import TestCaseOrdered
    from .utils import TestCaseTime
    from .utils import test_kwargs

    def ret(x, sleep=0.1, **kwargs):
        time.sleep(sleep)
        return x

    # Test usual use case
    TestCase(MonoWorker().submit(ret, 'a')).assert_equal('a')
    TestCase(MonoWorker().submit(ret, sleep=0.2, **test_kwargs)
             ).assert_equal(test_kwargs)
    # Test that a task can be cancelled
    TestCaseTime(MonoWorker().submit(ret, 'a', sleep=2)).assert_time_ok(0.5)

# Generated at 2022-06-12 15:03:03.702512
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    class Test:
        def __init__(self):
            self.called = False
            self.waiting = False

        def __call__(self):
            self.called = True
            while self.waiting:
                pass

    t = Test()
    m = MonoWorker()
    assert not t.called
    fut = m.submit(t)
    assert not t.called
    t.waiting = True
    while not t.called:
        pass
    assert t.called
    del t.waiting
    fut.result()
    fut = m.submit(t)
    fut2 = m.submit(t)
    assert fut is fut2
    with tqdm_auto.disable_external_write_mode():
        # Don't pollute stdout
        t.waiting = True

# Generated at 2022-06-12 15:03:08.828928
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def idx_as_x(idx):
        return lambda x: x + idx
    mono = MonoWorker()
    tasks_idxs = [mono.submit(idx_as_x(idx), idx) for idx in range(5)]
    assert tasks_idxs == [0, 1, 3, 4, 4], tasks_idxs
    assert tasks_idxs[-1].result() == 9
    assert tasks_idxs[-2].result() == 8
    print()
    print('MonoWorker.submit() unit test passed')
    print()


# Generated at 2022-06-12 15:03:17.609527
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def test_func(name):
        sleep(0.1)
        return name

    mw = MonoWorker()

    assert len(mw.futures) == 0
    f1 = mw.submit(test_func, '1')
    assert len(mw.futures) == 1
    assert f1.result() == '1'
    f1.result()  # shouldn't raise

    f2 = mw.submit(test_func, '2')
    assert len(mw.futures) == 1
    f3 = mw.submit(test_func, '3')
    assert len(mw.futures) == 1
    assert f2.done()
    assert not f2.cancelled()

# Generated at 2022-06-12 15:03:25.117292
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time

    def myfunc(k):
        time.sleep(0.001)
        return k * k

    m = MonoWorker()
    a = m.submit(myfunc, 2)  # a = 4
    b = m.submit(myfunc, 3)  # b = 9
    c = m.submit(myfunc, 0)  # c = 0: no effect due to same work
    d = m.submit(myfunc, 1)  # d = 1: no effect due to newer work
    print(a, b, c, d)

    e = m.submit(myfunc, 1)  # e = 1: replaces waiting task
    # c, d die
    time.sleep(0.01)

# Generated at 2022-06-12 15:03:49.482323
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def run_play():
        play_event.wait()
        time.sleep(0.1)
        time.sleep(0.1)
        time.sleep(0.1)

    def run_record():
        record_event.wait()
        time.sleep(0.2)
        time.sleep(0.2)
        time.sleep(0.2)

    play_event = threading.Event()
    record_event = threading.Event()
    w = MonoWorker()
    play_f = w.submit(run_play)
    record_f = w.submit(run_record)
    play_event.set()
    record_event.set()
    assert play_f.done()
    assert record_f.done()
    assert play_f.result()

# Generated at 2022-06-12 15:03:58.310588
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 15:04:06.115128
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    global _TEST_MONO_WORKER
    _TEST_MONO_WORKER = MonoWorker()

    def run(n):
        time.sleep(random.random())
        return n

    def run2(n, m):
        """this should never run"""
        m += 1  # will cause error in main loop
        time.sleep(random.random())
        return n

    # submit the first task before main loop
    _TEST_MONO_WORKER.submit(run, 0)

    for i in range(1, 10):
        # submit a new task every ~0.5 sec
        time.sleep(random.random() * 0.5)
        _TEST_MONO_WORKER.submit(run, i)

        # submit a new task every ~0.4 sec

# Generated at 2022-06-12 15:04:16.853559
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """https://github.com/tqdm/tqdm/pull/799"""
    from time import sleep
    from unittest.case import TestCase

    import tqdm as tqdm_no_auto

    with tqdm_no_auto.external_write_mode():
        import tqdm.contrib as tqdm_contrib

        class MyTestCase(TestCase):  # pragma: no cover
            def setUp(self):
                self.maxDiff = None

            def test_1(self):
                """Test basic usage."""
                mw = tqdm_contrib.MonoWorker()
                future = mw.submit(sleep, 0.5)
                self.assertFalse(future.done())
                future.result()
                self.assertTrue(future.done())

# Generated at 2022-06-12 15:04:22.992451
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    tqdm_auto.write("*** Testing MonoWorker.submit ***")

    def output(number):
        """Outputs a number and waits up to 1 second, randomly."""
        sleep(random())
        tqdm_auto.write("output {}".format(number))

    mw = MonoWorker()

    for i in tqdm_auto.trange(5, desc="submitting"):
        mw.submit(output, i)



# Generated at 2022-06-12 15:04:28.492133
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from tqdm import tqdm

    mono_worker = MonoWorker()

    # Submit functions
    def func(i):
        sleep(random())  # use this to make the results non-deterministic
        return i

    futures = []
    for i in tqdm(range(10), desc="Submit"):
        sleep(random())
        futures.append(mono_worker.submit(func, i))

    # Get results
    for future in tqdm(futures, desc="Get Results", dynamic_ncols=True):
        print(future.result())

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:04:34.491283
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    def time_spent(seconds):
        import time
        start = time.time()
        while time.time() - start < seconds:
            pass
    runner = MonoWorker()
    result = []
    for i in range(1, 7):
        result.append(runner.submit(time_spent, i))
    for i in range(1, 7):
        result[-i].result()
    for i in range(1, 7):
        result[-i].cancel()

# Generated at 2022-06-12 15:04:38.954427
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Here, submit will be called 5 times in a row.
    Only the latest call should really be executed.
    """
    mw = MonoWorker()
    assert len(mw.futures) == 0

    def f(x):
        import time
        time.sleep(x)

    assert str(mw.submit(f, 1)) == '<Future at 0x7f5b5bc57b70 state=running>'
    assert str(mw.submit(f, 2)) == '<Future at 0x7f5b5bc57b38 state=pending>'
    assert len(mw.futures) == 1
    import time
    time.sleep(0.5)
    assert len(mw.futures) == 0  # Lazy clearing even if the worker is alive


# Generated at 2022-06-12 15:04:46.437122
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed, wait
    from threading import current_thread

    global result_wrapper
    result_wrapper = []

    def sleep_for(t, msg):
        try:
            time.sleep(t)
            result_wrapper.append((t, msg, current_thread()))
        except Exception as e:
            tqdm_auto.write(str(e))

    worker = MonoWorker()
    for i in range(10):
        worker.submit(sleep_for, 0.01, i)

    time.sleep(0.1)
    assert len(result_wrapper) == 1  # only one thread can run at a time

    worker.submit(sleep_for, 0.1, None)  # this should kill the previous task
    # it would kill the first submitted one

# Generated at 2022-06-12 15:04:54.599802
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    mw = MonoWorker()

    # submit the first task
    mw.submit(sleep, 0.1)

    # submit another task and make it wait
    task = mw.submit(sleep, 0.5)
    assert task in mw.futures
    assert len(mw.futures) == 2

    # submit another task and make it replace the waiting task
    task2 = mw.submit(sleep, 0.2)
    assert len(mw.futures) == 1
    assert task2 in mw.futures
    assert task not in mw.futures
    
    # submit the last task, replace the running task
    task = mw.submit(sleep, 0.1)
    assert len(mw.futures) == 1

# Generated at 2022-06-12 15:05:34.367122
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test MonoWorker.submit"""
    import os, time
    mw = MonoWorker()

    def func_running():
        time.sleep(3)
        return 'running'

    def func_waiting():
        time.sleep(1)
        return 'waiting'

    def func_discarded():
        time.sleep(1)
        return 'discarded'

    assert mw.submit(func_running)
    assert mw.submit(func_waiting)
    assert mw.submit(func_discarded)

    print('Main process: pid={}'.format(os.getpid()))  # should be main pid
    print('Running: {}'.format(mw.futures[0].result()))
    print('Waiting: {}'.format(mw.futures[1].result()))

# Generated at 2022-06-12 15:05:41.754263
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from math import sqrt

    def sqrt_sleep(x, sleep_time=0.1):
        sleep(sleep_time)
        return sqrt(x)

    mono_worker = MonoWorker()
    futures = []
    for i in tqdm_auto.trange(10):
        futures.append(mono_worker.submit(sqrt_sleep, i, i/10))
    while futures:
        sleep(0.01)
        futures = [f for f in futures if not f.done()]



# Generated at 2022-06-12 15:05:49.670360
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(a, b=0):
        return a + b
    m = MonoWorker()
    assert m.submit(func, 1) is not None
    assert len(m.futures) == 1
    assert m.submit(func, 2, b=1) is not None
    assert len(m.futures) == 2
    assert m.submit(func, 3, b=1) is not None
    assert len(m.futures) == 2
    assert m.submit(func, 3, b=1) is None
    assert len(m.futures) == 2
    assert m.submit(func, 5, b=1) is not None
    assert len(m.futures) == 2

# Generated at 2022-06-12 15:05:56.356549
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, sys, os
    from concurrent.futures import ThreadPoolExecutor
    from traceback import format_exc as format_exception

    pool = ThreadPoolExecutor(max_workers=3)
    futs = []
    def wait(secs):
        time.sleep(secs)
    def submit_wait(secs):
        return pool.submit(wait, secs)
    def submit_wait_and_append(secs):
        fut = submit_wait(secs)
        futs.append(fut)
    def wait_all(futs):
        for fut in futs:
            fut.result()

    # wait(3)
    # wait(3) # not collected
    submit_wait(3)
    submit_wait(3) # collected
    wait_all(futs)
   

# Generated at 2022-06-12 15:06:06.616654
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    def _test_submit(test_number):
        print('test_number:', test_number)
        time.sleep(10)
        return test_number
    assert mw.submit(_test_submit, 1).result() == 1
    assert mw.submit(_test_submit, 2).result() == 1
    assert mw.submit(_test_submit, 3).result() == 2
    assert mw.submit(_test_submit, 4).result() == 3
    assert mw.submit(_test_submit, 5).result() == 3
    assert mw.submit(_test_submit, 6).result() == 4
    assert mw.submit(_test_submit, 7).result() == 5
    assert mw.submit(_test_submit, 8).result() == 5
    assert m

# Generated at 2022-06-12 15:06:13.554683
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import ThreadPoolExecutor
    from tqdm import tqdm_gui, tqdm_notebook

    mw = MonoWorker()

    def do_pbar():
        with tqdm_gui(total=100) as pbar:
            for _ in range(100):
                sleep(.01)
                pbar.update(1)

    def do_pbar_on_submit():
        mw.submit(do_pbar)

    do_pbar_on_submit()
    do_pbar_on_submit()
    do_pbar_on_submit()
    do_pbar_on_submit()

    mw = MonoWorker()


# Generated at 2022-06-12 15:06:22.565250
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import queue

    def printit():
        def printer():
            while True:
                s = q.get(block=True)
                print(s)
                q.task_done(s)

        threading.Thread(target=printer).start()

    # q is a queue for threads to share print messages
    q = queue.Queue()
    # t is threading.local() for threads to share t.id
    t = threading.local()
    t.id = 0

    def f1(n, runner=None):
        t.id += 1
        id = t.id
        q.put("Start %d: %d" % (id, n))
        if runner is not None:
            q.put("Wait %d: %d" % (id, n))
            runner

# Generated at 2022-06-12 15:06:30.191598
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def submit_equal_sleep(worker, i):
        import time
        time.sleep(0.01)
        # tqdm.write('(%s) sleep %s' % (i, 0.01))
        assert '%s' % i == worker.submit(lambda x : '%s' % x, i).result()

    def test_MonoWorker(func):
        for _ in tqdm_auto.tqdm(range(10), desc='Test submit()'):
            worker = MonoWorker()
            func(worker, _)

    test_MonoWorker(submit_equal_sleep)

    def submit_sleep_return_i(worker, i, sleep_time=0.01):
        import time
        time.sleep(sleep_time)
        # tqdm.write('(%s) sleep

# Generated at 2022-06-12 15:06:39.934447
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def fun(a, b):
        time.sleep(a)
        return a + b

    mw = MonoWorker()

    t = time.time()
    f = mw.submit(fun, 1, 0)
    assert f.result() == 1
    assert (time.time() - t) >= 1

    t = time.time()
    f = mw.submit(fun, 2, 0)
    assert (time.time() - t) < 2
    assert f.result() == 2

    t = time.time()
    f = mw.submit(fun, 1, 0)
    assert (time.time() - t) < 1
    assert f.result() == 1

    t = time.time()
    f = mw.submit(fun, 2, 0)

# Generated at 2022-06-12 15:06:44.947922
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    # this should display "hello" & "world"
    def hello():
        time.sleep(1.5)
        tqdm_auto.write("hello")

    def world():
        time.sleep(1)
        tqdm_auto.write("world")

    mw = MonoWorker()
    mw.submit(hello)
    time.sleep(0.5)
    mw.submit(world)

# Generated at 2022-06-12 15:07:57.382150
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .tests import print_error

    m = MonoWorker()
    for i in range(4):
        try:
            m.submit(sleep, 1)
        except Exception:
            print_error(str(i+1) + ": failed")

# Generated at 2022-06-12 15:08:03.272876
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import random

    # Test conditions
    ntask = 10
    nsleep = 30
    ntask_to_cancel = ntask // 2

    mw = MonoWorker()

    # Test task-cancellation
    work_func = lambda val: time.sleep(nsleep * random())
    work_args = map(str, list(range(ntask)))
    for i, arg in enumerate(work_args):
        tqdm_auto.write('Submitting task %s' % arg)
        future = mw.submit(work_func, arg)
        time.sleep(nsleep * random())
        if i == ntask_to_cancel:
            future.cancel()
            tqdm_auto.write('Cancelled task %s' % arg)

    # Run tasks
