

# Generated at 2022-06-12 14:58:16.209442
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    def printer(text, time):
        sleep(time)
        tqdm_auto.write(text)

    # Instantiating MonoWorker
    mw = MonoWorker()
    # Task taking 1s
    task_1s = mw.submit(printer, "1s", 1)
    # Task taking 5s
    task_5s = mw.submit(printer, "5s", 5)
    # Task taking 0.5s
    task_05s = mw.submit(printer, "0.5s", 0.5)
    # Task taking 3s
    task_3s = mw.submit(printer, "3s", 3)
    # Task taking 2s
    task_2s = mw.submit(printer, "2s", 2)

    #

# Generated at 2022-06-12 14:58:23.265555
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def worker(name, time):
        sleep(time)
        return name

    def test_submit(worker, **kwargs):
        from collections import defaultdict

        mw = MonoWorker()
        for name, time in kwargs.items():
            mw.submit(worker, name, time)
        results = defaultdict(int)
        for future in mw.futures:
            results[future.result()] += 1
        return results

    assert test_submit(worker, A=1, B=1) == {'B': 1}
    assert test_submit(worker, A=3, B=1, C=2) == {'C': 1}

# Generated at 2022-06-12 14:58:25.922077
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm import tqdm

    def wait_n_print(s):
        sleep(0.01)
        tqdm.write(s)

    w = MonoWorker()
    for i in range(3):
        w.submit(wait_n_print, 'start {}'.format(i))
        w.submit(wait_n_print, 'finish {}'.format(i))

# Generated at 2022-06-12 14:58:33.295335
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .compat import TimeoutError
    from .common import PY3

    def task_sleep(secs):
        from time import sleep
        sleep(secs)

    def task_raise(secs):
        raise ValueError("dummy exception")

    def task_cancel(secs):
        # dummy task that cancels itself immediately
        try:
            while True:
                tqdm_auto.write("still running (BUG?)!")
                raise TimeoutError("infinite loop should be interrupted")
        except TimeoutError:
            pass

    def task_print(*args, **kwargs):
        tqdm_auto.write("{0} {1}".format(args, kwargs))

    mw = MonoWorker()

    # First task not finished by second task

# Generated at 2022-06-12 14:58:42.914614
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Tests for method submit of class MonoWorker."""
    from time import sleep
    from functools import partial

    def print_and_sleep(text, interval, **kwargs):
        """Run a task that prints `text` and sleeps for `interval` seconds.

        Parameters
        ----------
        text : str
        interval : float
        """
        tqdm_auto.write(text)
        sleep(interval)

    # instantiate
    mono_worker = MonoWorker()
    # use it
    task_0 = mono_worker.submit(partial(print_and_sleep, "task 0", interval=10))
    task_1 = mono_worker.submit(partial(print_and_sleep, "task 1", interval=2))

# Generated at 2022-06-12 14:58:54.486976
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    class AssertionError(Exception):
        pass

    def ret(*args):
        return sum(args)

    def wait(*args):
        import time
        time.sleep(1)
        return sum(args)

    def fail(*args):
        raise AssertionError()

    mw = MonoWorker()

    assert mw.submit(ret, 1, 2, 3).result() == 6
    assert mw.submit(ret, 4, 5, 6).result() == 15

    f1 = mw.submit(wait, 7, 8, 9)
    tqdm_auto.write(mw.submit(ret, 10, 11, 12).result())
    assert f1.result() == 7 + 8 + 9

    # consecutive fails
    mw.submit(fail)

# Generated at 2022-06-12 14:59:02.449140
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import atexit
    from multiprocessing import Process
    from threading import Thread
    from concurrent.futures import ThreadPoolExecutor

    def pseudo_tqdm(i):
        pbar = tqdm_auto.tqdm(total=100, unit_scale=True, smoothing=0)
        for _ in range(100):
            time.sleep(0.1)
            pbar.update(1)
            if pbar.n == 50:
                raise Exception('test exception')

    def main_test_submit():
        mw = MonoWorker()
        for i in range(10):
            mw.submit(pseudo_tqdm, i)
        time.sleep(0.1)

    # Run `main_test_submit` in a separate process then join it

# Generated at 2022-06-12 14:59:06.438416
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _time as tm
    from ..utils import _range

    mw = MonoWorker()
    # Submit a "slow" task
    f1 = mw.submit(time.sleep, 2)
    mw.submit(time.sleep, 3)  # Should be discarded
    # Submit a "fast" task
    t0 = tm.time()
    f2 = mw.submit(time.sleep, 0.1)
    f2.result()
    t1 = tm.time()
    # Submit a "fast" task that would be cancelled
    t2 = tm.time()
    mw.submit(time.sleep, 0.1)
    mw.submit(time.sleep, 0.1)
    f1.result(timeout=1)  # Will timeout and raise exception

# Generated at 2022-06-12 14:59:12.740310
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    def wait_awile(period):
        sleep(random() * period)
    with MonoWorker() as worker:
        dummy = worker.submit(wait_awile, period=0.5)
        current = worker.submit(wait_awile, period=1)
        assert current == dummy
        next = worker.submit(wait_awile, period=0.25)
        assert current != next

# Generated at 2022-06-12 14:59:18.670637
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import multiprocessing
    import sys

    time_taken = multiprocessing.Value('L', 0)  # long int (c types)

    def slow_inc(x, delta):
        global time_taken
        time.sleep(delta)
        with time_taken.get_lock():
            time_taken.value += delta
        return x + delta

    def slow_dec(x, delta):
        global time_taken
        time.sleep(delta)
        with time_taken.get_lock():
            time_taken.value += delta
        return x - delta


# Generated at 2022-06-12 14:59:28.505373
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    r"""Unit test for :meth:`~tqdm.contrib.IO_utils.MonoWorker.submit`."""
    from time import sleep

    def twice(x):
        sleep(0.1)
        return 2 * x

    def _test(num_submits):
        tqdm_auto.write('submitting {} tasks...'.format(num_submits))
        mw = MonoWorker()
        mw_futures = [mw.submit(twice, i) for i in tqdm_auto(range(num_submits))]
        assert len(mw.futures) <= 2, mw.futures
        assert len(mw_futures) == num_submits

# Generated at 2022-06-12 14:59:38.036380
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method MonoWorker.submit."""
    worker = MonoWorker()

    def _try_one(func, args, kwargs):
        """Helper to try one function."""
        print('\nfunc: {}\nargs: {}\nkwargs: {}'.format(func, args, kwargs))
        with tqdm_auto.tqdm(leave=True) as t:
            future = worker.submit(func, *args, **kwargs)
            while not future.done():
                t.update()
        print('result: {}'.format(future.result()))

    # Test for exceptions
    _try_one(lambda: 1 / 0, (), {})

    # Test for different functions
    _try_one(lambda: 1, (), {})

# Generated at 2022-06-12 14:59:45.277442
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func1():
        from time import sleep
        sleep(1)
        return 1
    def func2():
        from time import sleep
        sleep(1)
        return 2
    def func3():
        from time import sleep
        sleep(1)
        return 3
    m = MonoWorker()
    print("sub1")
    res1 = m.submit(func1)
    print("sub2")
    res2 = m.submit(func2)
    print("sub3")
    res3 = m.submit(func3)
    print("Wait for 1")
    print(res1.result())
    print("Wait for 3")
    print(res3.result())

# Generated at 2022-06-12 14:59:52.663440
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import wait, as_completed
    from time import sleep
    def f(delay):
        sleep(delay)
        return delay
    mw = MonoWorker()
    mw.submit(f, 0.2)
    sleep(1)
    mw.submit(f, 0.1)  # replaces waiting task
    wait(mw.futures)
    assert abs(as_completed(mw.futures).next().result() - 0.1) <= 0.1

# Generated at 2022-06-12 14:59:59.410706
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from os import getpid

    pid = lambda: str(getpid())
    def test_func(s):
        sleep(s)
        return pid()

    w = MonoWorker()
    last_pid = ['']
    def runner(s):
        future = w.submit(test_func, s)
        last_pid[0] = future.result()
        return future

    # First submit: should spawn a new thread
    future = runner(1.0)
    assert future.result() == pid()

    # Second submit: should wait for current thread to finish
    future = runner(1.0)
    assert future.result() == last_pid[0]

    # Third submit: should spawn a new thread and discard waiting task
    future = runner(1.0)

# Generated at 2022-06-12 15:00:07.521549
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from . import test_cases
    from tqdm.contrib.test_utils import TestTqdmType
    from time import sleep

    def runner(t, args, kwargs, output):
        sleep(0.2)
        output.append('result is: {}'.format(t + sum(args) + kwargs['x']))

    for t in test_cases.TESTCASES:
        mw = MonoWorker()
        output = []
        assert len(mw.pool._threads) == 1
        mw.submit(runner, t, [1, 2], {'x': 3}, output)
        assert len(mw.pool._threads) == 1  # no new thread yet
        mw.submit(runner, t + 1, [4, 5], {'x': 6}, output)
       

# Generated at 2022-06-12 15:00:16.273318
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    def double(x):
        time.sleep(random.randint(1, 2))
        return x * 2

    mono_worker = MonoWorker()

    class RandomKwargs(dict):
        def __missing__(self, key):
            if key == 'x':
                return random.randint(1, 10)
            elif key == 'label':
                return 'label'
            else:
                raise KeyError(key)
    # !!! should be replaced with:
    # import random
    # from operator import attrgetter
    # from itertools import tee
    # from concurrent.futures import as_completed
    # from tqdm.contrib.concurrency import MonoWorker
    # with tqdm.wrapattr(MonoWorker(), 'submit') as mono

# Generated at 2022-06-12 15:00:22.430389
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    # Test parallelism
    def wait(duration):
        time.sleep(duration)
        return duration
    mono_worker = MonoWorker()
    assert mono_worker.submit(wait, 1).result() == 1
    assert mono_worker.submit(wait, 2).result() == 2
    assert mono_worker.submit(wait, 3).result() == 3
    assert mono_worker.submit(wait, 4).result() == 4
    assert mono_worker.submit(wait, 5).result() == 5
    assert mono_worker.submit(wait, 6).result() == 6

    # Test sequence
    mono_worker = MonoWorker()
    assert mono_worker.submit(wait, 1).result() == 1
    assert mono_worker.submit(wait, 2).result() == 2

# Generated at 2022-06-12 15:00:28.132319
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def foo(i):
        return i**2
    m = MonoWorker()

    ret = m.submit(foo, 1)
    assert ret.result() == 1

    ret = m.submit(foo, 2)
    assert ret.result(timeout=1) is None

    ret = m.submit(foo, 3)
    assert ret.result(timeout=1) == 9

# Generated at 2022-06-12 15:00:36.490519
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import current_thread

    worker = MonoWorker()
    futures = []
    for _ in tqdm_auto.range(2):
        futures.append(worker.submit(sleep, .1))

    sleep(.3)

    for future in futures:
        if not future.done():
            if future.running():
                assert len(worker.futures) == 1, 'Running future was killed'
            else:
                assert future.cancelled()
                assert len(worker.futures) == 1, 'Waiting future was killed'

    futures = []
    for _ in tqdm_auto.range(5):
        futures.append(worker.submit(print, current_thread().name))

    # wait until all tasks terminated
    for future in futures:
        future.result()

# Generated at 2022-06-12 15:00:50.107763
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    worker = MonoWorker()

    def cmd(arg, sleep_time=0):
        sleep(sleep_time)
        return arg

    def cmd_with_error(arg, sleep_time=0):
        sleep(sleep_time)
        raise Exception(arg)

    # submitted and running
    running = worker.submit(cmd, 1, sleep_time=1)
    assert running == worker.futures[0]
    assert running.running()

    # submitted and running (last one will be discarded)
    waiting = worker.submit(cmd, 2, sleep_time=0)
    assert running == worker.futures[0]
    assert waiting == worker.futures[1]  # waiting to replace running
    assert running.running()
    assert not waiting.running()

    # waiting completes and replaces

# Generated at 2022-06-12 15:00:57.607502
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def print_time():
        time.sleep(0.1)
        tqdm_auto.write("TIME: " + str(time.time()))

    worker = MonoWorker()

    t1 = worker.submit(print_time)
    t2 = worker.submit(print_time)
    t3 = worker.submit(print_time)
    t4 = worker.submit(print_time)
    t5 = worker.submit(print_time)
    time.sleep(0.3)
    tqdm_auto.write("------------")
    t6 = worker.submit(print_time)
    time.sleep(0.3)

# Generated at 2022-06-12 15:01:04.171534
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread

    def long_job():
        sleep(3)
        return "long_job"

    def short_job():
        return "short_job"

    MonoWorker = MonoWorker()
    MonoWorker.submit(func=long_job)
    from time import sleep
    sleep(1)
    short_future = MonoWorker.submit(func=short_job)
    assert short_future.result() == "short_job"

    # Count down to end
    Thread(target=lambda: sleep(9)).start()
    import tqdm
    with tqdm.trange(10) as t:
        for _ in t:
            sleep(1)

# Generated at 2022-06-12 15:01:13.274070
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from itertools import count

    workers = []
    for X in count():
        worker = MonoWorker()
        workers.append(worker)
        results = list(range(10))
        for i in tqdm_auto(results, desc='loop' + str(X), leave=False):
            def do_something(i):
                sleep(0.3)
                return i

            def do_something_else(i):
                sleep(0.3)
                return i * 2

            if i % 3 == 0:
                curr = worker.submit(do_something, i)
            else:
                curr = worker.submit(do_something_else, i)
            results[i] = curr.result()


# Generated at 2022-06-12 15:01:24.146401
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def succ(a):
        time.sleep(0.1)
        return a

    def fail():
        time.sleep(0.1)
        raise Exception()

    mono = MonoWorker()
    future = mono.submit(succ, 1)
    assert future.result() == 1, "assign priority to most recent argument"

    future = mono.submit(succ, 2)
    assert future.result() == 1, "wait for previous task"

    future = mono.submit(succ, 3)
    assert future.result() == 2, "wait for previous task"

    future = mono.submit(succ, 4)
    assert future.result() == 2, "discard waiting task"

    future = mono.submit(succ, 5)

# Generated at 2022-06-12 15:01:31.824596
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Tests that MonoWorker.submit() behaves as expected."""
    from time import sleep
    import sys

    def worker(sleep_time):
        sleep(sleep_time)
        return sleep_time

    def print_result(future):
        print(future.result())

    worker_queue = MonoWorker()
    worker_queue.submit(worker, 0.25, callback=print_result)

    for _ in range(5):
        worker_queue.submit(worker, 0.5, callback=print_result)

    worker_queue.submit(sys.exit)

# Generated at 2022-06-12 15:01:37.799534
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def randwait():
        time.sleep(random.random())

    mw = MonoWorker()
    r = mw.submit(randwait)
    r.result()
    r = mw.submit(randwait)
    rr = mw.submit(randwait)
    rr.result()
    rr = mw.submit(randwait)
    rr.result()
    try:
        r.result()
    except Exception as e:
        pass
    else:
        raise AssertionError("Did not raise expected exception.")



# Generated at 2022-06-12 15:01:48.861053
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import sys
    import random

    def write(*args):
        print(*args)
        sys.stdout.flush()

    def sys_input():
        return sys.stdin.readline()[:-1]

    def _do_test(n=3, m=5, s='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'):
        worker = MonoWorker()
        futures = [worker.submit(lambda: ''.join(random.choice(s) for _ in range(m)))
                   for _ in range(n)]

# Generated at 2022-06-12 15:01:52.210634
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> mwork = MonoWorker()
    >>> def i(x): return x  # identity function
    >>> f1 = mwork.submit(i, 1)
    >>> f2 = mwork.submit(i, 2)
    >>> assert f1.result() == 1
    >>> assert f2.result() == 2
    """
    pass

# Generated at 2022-06-12 15:02:00.672588
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .concurrency import MonoWorker

    def slow_fibonacci(n):
        from time import sleep
        from functools import lru_cache

        @lru_cache(maxsize=10)
        def fib(n):
            if n < 3:
                return 1
            sleep(1)
            return fib(n - 1) + fib(n - 2)
        sleep(1)
        return fib(n)

    l = []
    m = MonoWorker()
    for i in range(3):
        m.submit(slow_fibonacci, l.append(i))
    m.submit(slow_fibonacci, l.append(3))
    m.submit(slow_fibonacci, l.append(4))

# Generated at 2022-06-12 15:02:17.118391
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import active_count, Event
    # Before starting any thread
    N_threads = active_count()
    mw = MonoWorker()
    e1 = mw.submit(sleep, 1)
    e2 = mw.submit(sleep, 1)
    assert e1 is not e2
    e3 = mw.submit(sleep, 1)
    assert e1 is e3
    assert e1 not in e2, e2
    # After starting 3 threads
    assert active_count() == N_threads + 3
    # e1 is cancelable
    e1.cancel()
    assert e1.cancel()
    # e2 is not cancelable
    assert not e2.cancel()
    e2.result()  # should wait for it to finish
    # After cance

# Generated at 2022-06-12 15:02:27.436625
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import signal

    # returns an ascii bar for x in [0, 100]
    def make_bar(x):
        return '#' * (x // 2) + '-' * (50 - x // 2) + ' |'

    # set up MonoWorker instance
    n_multi = 2
    mw = MonoWorker()

    # make simple progress bars
    with tqdm_auto(desc='main loop',
                   total=100,
                   unit='%') as main_pbar, \
         tqdm_auto(desc='sub loop',
                   total=100) as sub_pbar:

        # call this function instead of time.sleep
        # to allow the while-loop to terminate
        def sleep_and_interrupt(secs):
            def handler(signum, frame):
                raise Exception

# Generated at 2022-06-12 15:02:33.610622
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from warnings import warn
    from itertools import count
    warn("Unit tests will run forever (if correct) and are not automatically cancelled")
    sleep_time = 1
    for i in count():
        try:
            tqdm_auto.write("Test #{}:".format(i))
            mw = MonoWorker()
            mw.submit(sleep, sleep_time)
            mw.submit(sleep, sleep_time)
            mw.submit(sleep, sleep_time)
            mw.submit(sleep, sleep_time)
            mw.submit(sleep, sleep_time)
            mw.submit(sleep, sleep_time)
        except Exception as e:
            tqdm_auto.write(str(e))
            raise

# Generated at 2022-06-12 15:02:43.606930
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from unittest import TestCase, main

    def id_generator(counter):
        while True:
            counter += 1
            yield counter

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.counter = 0
            self.generator = id_generator(self.counter)
            self.mono_worker = MonoWorker()
            self.times = (1, 3)

        def test_submit_a_function_with_args(self):
            counter = self.counter
            generator = self.generator
            mono_worker = self.mono_worker
            times = self.times
            for time in times:
                counter += 1
                mono_worker.submit(sleep, time)
                mono_worker.submit(next, generator)

# Generated at 2022-06-12 15:02:50.092642
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..pandas import trange

    def task(i):
        time.sleep(1)
        return i + 1

    worker = MonoWorker()

    total = 5
    with tqdm_auto.tqdm(total=total, desc='[task]') as t:
        results = []
        for i in trange(total):
            f = worker.submit(task, i)
            results.append(f)

        for i, f in enumerate(results):
            results[i] = f.result()
    assert results == list(range(total))

# Generated at 2022-06-12 15:03:00.869462
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .utils import TestBar
    from .async_generator import AioGenerator
    import threading
    import time

    comments = []
    mw = MonoWorker()

    def test_future():
        """returns true future"""
        time.sleep(0.01)
        comments.append('f1 future done')
        return 1

    def test_exception():
        """raises exception"""
        time.sleep(0.01)
        comments.append('f2 future done')
        raise ValueError('f2 error')

    def test_gen():
        """yields values"""
        for i in range(3):
            time.sleep(0.01)
            yield i
            comments.append('f{} gen done {}'.format(i + 3, i))
        # should never get here
        comments

# Generated at 2022-06-12 15:03:08.600749
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from os import system
    def task(id, sleep_time):
        pbar = tqdm_auto(total=int(sleep_time))
        pbar.set_description("{}".format(id))
        for _ in range(pbar.total):
            sleep(1)
            pbar.update()
        pbar.close()

    worker = MonoWorker()

    worker.submit(task, "task1", 3)
    worker.submit(task, "task2", 5)
    worker.submit(task, "task3", 7)
    worker.submit(task, "task4", 9)

    def on_click(e):
        worker.submit(task, "task5", 11)
        worker.submit(task, "task6", 13)

    on_click(None)


# Generated at 2022-06-12 15:03:16.213676
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import numpy as np

    def sleep_sort(seconds):
        time.sleep(seconds)
        return seconds

    def sort_and_print(s):
        seconds = np.random.randint(1, 3, size=(s,))
        fractions = np.random.random(size=(s,))

        with tqdm_auto.tqdm(total=s) as t:
            worker = MonoWorker()
            return [worker.submit(sleep_sort, i).result()
                    for i in seconds]

    assert sort_and_print(10) == sorted(sort_and_print(10),
                                        key=lambda x: random.random())

# Generated at 2022-06-12 15:03:23.870606
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    from threading import current_thread, active_count

    def func(*args, **kwargs):
        print('Hello MonoWorker!')
        for _ in tqdm_auto.trange(10, desc='Go', unit='packets'):
            pass
        return current_thread().name

    # Test 1
    mono_worker = MonoWorker()
    assert active_count() == 1

    assert mono_worker.submit(func) is None  # exception in func
    assert active_count() == 1  # nothing in thread pool

    # Test 2
    mono_worker = MonoWorker()
    assert active_count() == 1

    # This task should be discarded silently
    assert mono_worker.submit(func).result() == 'Thread-1'
    assert active_count() == 2  # one thread in thread pool

    # This

# Generated at 2022-06-12 15:03:29.443864
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def foo(x, sleep=0.1):
        time.sleep(sleep)
        return x + 1

    mw = MonoWorker()
    assert len(mw.futures) == 0
    expected = [2, 3, 4]
    for i in range(3):
        ret = mw.submit(foo, i, 0.1 - 0.01 * i).result()
        assert ret == expected[i]
    time.sleep(0.3)  # ensure foo(1, 0.09) did not run
    assert len(mw.futures) == 0

# Generated at 2022-06-12 15:03:49.937853
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..auto import tqdm

    def never_ready():
        time.sleep(1)  # takes > 0
        return "never"

    def ready():
        time.sleep(1)  # takes > 0
        return "ready"

    def too_slow():
        time.sleep(2)  # takes > 1
        return "too_slow"

    def too_slow_err(x):
        time.sleep(2)  # takes > 1
        raise ValueError(x)

    def always_err(x):
        time.sleep(1)  # takes > 0
        raise ValueError(x)

    def fetch_all(f):
        try:
            res = f.result()
        except Exception as e:
            res = repr(e)
        return res


# Generated at 2022-06-12 15:03:57.794619
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm import trange
    from .pandas_helpers import df_bar
    from .utils import set_postfix

    def map_func(i, desc, **kwargs):
        for _ in trange(3, disable=True, desc=desc, **kwargs):
            sleep(0.005)

    futures = []
    mw = MonoWorker()
    for i in trange(10):
        set_postfix(df_bar(futures), refresh=False)
        futures.append(mw.submit(map_func, i, 'map', leave=False))
    set_postfix(df_bar(futures), refresh=False)

# Generated at 2022-06-12 15:04:00.232652
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> fut = MonoWorker().submit(lambda x: x**x, 2**5)
    >>> fut.done()
    True
    >>> fut.result() == 2**32
    True
    """
    pass

# Generated at 2022-06-12 15:04:04.413973
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> worker = MonoWorker()
    >>> def foo():
    ...     import time
    ...     while True:
    ...         time.sleep(0.05)
    >>> futures = []
    >>> for _ in range(10):
    ...     futures.append(worker.submit(foo))
    >>> for _ in futures:
    ...     _.cancel()
    """
    pass

# Generated at 2022-06-12 15:04:15.048070
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from glob import glob
    from os import remove
    from os.path import expanduser, join
    from random import randint
    from time import sleep

    from .io import getpid
    from .utils import SafeIterator

    def test_submit():
        n = 100
        delay = 0.01
        nprocs = 2
        prefix = '.tmp.%d' % randint(0, 1000000)
        path = expanduser(join('~', prefix + '*'))
        out_paths = deque([], nprocs)

        def producer():
            for i in tqdm_auto(n, desc='submits', miniters=1):
                yield i

        def consumer(i):
            sleep(randint(1, int(delay * 10)))
            k = getpid()

# Generated at 2022-06-12 15:04:24.737512
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def bar(x):
        time.sleep(x)
        return x

    from tqdm import trange
    from tqdm import tqdm as tqdm_tqdm

    # Basic tests
    with tqdm_tqdm(total=1, position=0) as pbar:
        try:
            w = MonoWorker().submit(bar, 3)
            w.result()
        except:
            pass
        finally:
            pbar.close()
        if pbar.n == 0:
            raise AssertionError("Test 1: bar was not called")


# Generated at 2022-06-12 15:04:34.013720
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing
    import time
    from ..utils import _term_move_up

    with MonoWorker() as pool:
        # Slow task that takes 5 seconds, but is replaced by faster tasks
        slow_task = pool.submit(time.sleep, 5)
        # Fast task that takes 1 second
        fast_task = pool.submit(time.sleep, 1)
        # Another fast task that takes 1 second, replaces first fast one
        fast_task2 = pool.submit(time.sleep, 1)

        for _ in range(4):  # Wait for fast tasks to finish
            _term_move_up()
            print('Waiting for fast tasks...')
            time.sleep(.2)

        # fast_task2 is now running, while slow_task and fast_task are done
        assert fast_task.done()
       

# Generated at 2022-06-12 15:04:42.248829
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()

    def test_func(num):
        time.sleep(0.01)
        return num

    # Test 1:
    results = []
    for i in range(10):
        results.append(mw.submit(test_func, i))

    for i in range(10):
        assert results[i].result() == i

    # Test 2:
    results = []
    for i in range(10):
        results.append(mw.submit(test_func, (i + 1) * 10))

    for i in range(10):
        assert results[i].result() == (i + 1) * 10


if __name__ == '__main__':  # pragma: no cover
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:04:48.469876
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint
    from itertools import count

    def echo(n):
        sleep(0.1)
        return n

    bg = MonoWorker()
    for i in count():
        try:
            result = bg.submit(echo, i).result()
        except Exception as e:
            print(str(e))
        else:
            if result != i:
                raise ValueError(
                    "Out of sync: expected %d, got %d" % (i, result))
        sleep(0.01)

# Run unit tests with `python3 -m tqdm.contrib.tests.test_mono_worker`
if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:04:56.069369
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Thread
    from time import sleep

    class Repeat(object):
        """Repeat a string `reps` times."""
        def __init__(self, reps):
            self.reps = reps

        def __call__(self, s):
            return s * self.reps

    def wait_result(mw, future, s, reps):
        assert future.result() == s * reps

    mw = MonoWorker()

    future = mw.submit(Repeat(3).__call__, 'A')
    Thread(target=wait_result, args=(mw, future, 'A', 3)).start()
    sleep(0.1)
    future = mw.submit(Repeat(4).__call__, 'B')

# Generated at 2022-06-12 15:05:39.583309
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .._monitor import time as ttime

    def slow():
        time.sleep(.1)

    mw = MonoWorker()
    with ttime('t_worker: submit 1'):
        mw.submit(slow)
    with ttime('t_worker: submit 2'):
        mw.submit(slow)
    with ttime('t_worker: submit 3'):
        mw.submit(slow)
    with ttime('t_worker: submit 4'):
        mw.submit(slow)

# Sample usage
if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:05:48.637964
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    def is_waiting_cancelled(waiting):
        # TODO: check if waiting is cancelled
        time.sleep(random.uniform(0, 0.2))
        return random.choice((True, False))
    worker = MonoWorker()

    def func(val):
        time.sleep(0.5)
        return val

    # no waiting task
    f1 = worker.submit(func, 1)
    assert not f1.done()

    # waiting task
    f2 = worker.submit(func, 2)
    assert not f1.done()
    assert not f2.done()
    f2.cancel()

    # running task
    for _ in range(3):
        assert f1.done()
        assert f1.result() == 1

# Generated at 2022-06-12 15:05:55.796247
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def w(s):
        """
        Setup for test: wait for s seconds before returning "DONE"
        """
        from time import sleep
        sleep(s)
        return 'DONE'
    from time import time
    from multiprocessing import Pool
    from concurrent.futures import wait
    from contextlib import closing
    from random import random, seed
    seed(2)
    dl = [2 * random() for _ in range(30)]

    def first(dl):
        """
        Return the first `w` DONE result.
        Only try `w` functions in parallel (at any time).
        """
        res = []

# Generated at 2022-06-12 15:06:05.820287
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm import trange
    from concurrent.futures import as_completed
    from concurrent.futures import TimeoutError

    def bar(i, j=0):
        for _ in trange(i, desc='{}'.format(j)):
            time.sleep(.1)
    funcs = [lambda: bar(10, i) for i in range(5)]
    monoworker = MonoWorker()
    futures = [monoworker.submit(func) for func in funcs]
    for i in trange(len(futures), desc='overall'):
        try:
            next(as_completed(futures))
        except TimeoutError:
            pass

# Generated at 2022-06-12 15:06:12.987450
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import unittest

    class TestObject(object):
        def __init__(self, sleep_time=0.5):
            self.sleep_time = sleep_time

        def sleep(self):
            sleep(self.sleep_time)
            return 'sleep'

    class TestMonoWorker(unittest.TestCase):
        def setUp(self):
            self.monoworker = MonoWorker()
            self.testobject = TestObject(0.01)

        def test_submit_sleep(self):
            testobject = self.testobject
            monoworker = self.monoworker
            p1 = monoworker.submit(testobject.sleep)
            p2 = monoworker.submit(testobject.sleep)
            p3 = monoworker.submit

# Generated at 2022-06-12 15:06:18.001081
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..utils import FormatCustomText

    def f(x):
        sleep(.1)
        return x

    with tqdm_auto.tqdm(
            desc=FormatCustomText("Submit", "{postfix[0]}")) as t:
        w = MonoWorker()
        for i in range(4):
            w.submit(f, i)
            t.postfix = (i, )
        t.close()

# Generated at 2022-06-12 15:06:26.170173
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import TimeoutError

    import time

    mw = MonoWorker()

    # process should be executed synchronously
    assert mw.submit(time.sleep, 0.1).result() is None
    assert mw.submit(time.sleep, 0.1).result() is None

    # only one process (the most recent) should be waiting
    assert mw.submit(
        time.sleep, 0.1).result() is None
    t0 = time.time()
    try:
        mw.submit(
            time.sleep, 0.5).result(timeout=0.2)
    except TimeoutError:
        pass
    else:
        assert False
    t1 = time.time()
    assert 0.2 < t1 - t0 < 0.3


# Generated at 2022-06-12 15:06:32.954901
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def tqdm_test(itr):
        with tqdm_auto.tqdm(itr) as pbar:
            for i in pbar:
                yield i
    worker = MonoWorker()
    callback = object()
    # submit task 1
    worker.submit(tqdm_test, range(10), callback=callback)
    # submit task 2 (waiting)
    worker.submit(tqdm_test, range(10), callback=callback)
    # try re-submitting task 1 (should reject)
    assert worker.submit(tqdm_test, range(10), callback=callback) is None
    # test blocking
    import time
    sum(list(worker.futures[0].result()))
    time.sleep(.1)
    list(worker.futures[1].result())

# Generated at 2022-06-12 15:06:42.202716
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import unittest
    import functools

    def call_id(x):
        time.sleep(random.random())
        return id(x)

    class TestMonoWorker(unittest.TestCase):
        def test_submit(self):
            time.sleep(.1)  # sufficient time for foolproof printing
            mw = MonoWorker()
            x = [None] * 2
            x[1] = call_id(x)
            ids = [mw.submit(call_id, x).result() for _ in range(5)]
            self.assertEqual(ids, [x[1]] * 3 + [id(x)] * 2)

    unittest.main(module=__name__, argv=[__file__])

# Generated at 2022-06-12 15:06:48.861162
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    worker = MonoWorker()
    assert not worker.futures

    def task_n(n):
        sleep(0.2)
        return n

    def task_0():
        return task_n(0)

    def task_1():
        return task_n(1)

    # case 0:
    future_0 = worker.submit(task_0)
    assert future_0.result() == 0

    # case 1:
    future_0 = worker.submit(task_0)
    future_1 = worker.submit(task_1)
    assert future_0.cancelled()
    assert future_1.result() == 1

    # case 2:
    future_0 = worker.submit(task_0)
    future_1 = worker.submit(task_1)