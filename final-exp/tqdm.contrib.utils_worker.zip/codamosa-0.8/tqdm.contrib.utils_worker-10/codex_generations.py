

# Generated at 2022-06-12 14:58:06.837453
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures
    import time

    class Timer(object):
        def __init__(self):
            self.start = -1
            self.end = -1

        def __enter__(self):
            self.start = time.time()
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            self.end = time.time()

    task_length = 5
    timeout = 1.2
    mw = MonoWorker()
    timer = Timer()
    future1 = mw.submit(time.sleep, task_length)
    future2 = mw.submit(time.sleep, task_length)
    assert future1 == future2
    assert not future2.done()


# Generated at 2022-06-12 14:58:17.116478
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint
    from tempfile import NamedTemporaryFile
    from concurrent.futures import Future
    from tqdm.utils import _term_move_up

    # Create a temp file
    temp = NamedTemporaryFile(mode="w")
    temp.write("0\n")
    temp.flush()

    # Create a worker
    worker = MonoWorker()

    # Create a dummy function to replace the file with str(2**n)
    def replace_with_pow(n):
        sleep(randint(1, 5))
        _term_move_up()
        tqdm_auto.write("replacing file with 2**{}...".format(n))
        with open(temp.name, "w") as f:
            f.write(str(2**n))


# Generated at 2022-06-12 14:58:23.735726
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import sys
    import random
    import threading
    import unittest
    mw = MonoWorker()
    class Lock:
        def __init__(self):
            self.lock = threading.Lock()
        def __enter__(self):
            self.lock.acquire()
        def __exit__(self, t, v, tb):
            self.lock.release()
    def run(start, end):
        with Lock():
            sys.stdout.write('{}-{}'.format(start, end))
            sys.stdout.flush()
            for _ in range(start, end):
                sleep(random.randint(0, 10) * 0.001)

# Generated at 2022-06-12 14:58:31.417591
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func_0():
        time.sleep(1)
        return 0

    def func_1():
        time.sleep(1)
        return 1

    def func_2():
        time.sleep(1)
        return 2

    def func_3():
        time.sleep(1)
        return 3

    m = MonoWorker()
    for i in range(4):
        m.submit(globals()['func_{}'.format(i)])
    time.sleep(2)
    assert len(m.futures) == 2
    assert m.futures[0].result() == 0
    assert m.futures[1].result() == 3
    m.pool.shutdown(wait=True)

# Generated at 2022-06-12 14:58:39.755360
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from sys import exc_info

    pool = MonoWorker()

    # One test consists of three steps:
    # 1. Submit at least one `solve_with_sleep` task.
    # 2. Submit many `solve_with_sleep` tasks.
    # 3. Submit a `solve_with_cancel` task.

    # 1.
    def solve_with_sleep(t):
        sleep(t)
        tqdm_auto.write('slept {0} s\n'.format(t))

    # `submit(solve_with_sleep, random(), ...)` runs when there is no running
    # task, or the running task has taken more than `random()` seconds to
    # complete.
    pool.submit(solve_with_sleep, random())

# Generated at 2022-06-12 14:58:44.022749
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    def slow_func(num):
        time.sleep(random.random())
        return num


    def add1(num):
        return num + 1

    mw = MonoWorker()
    results = []
    for _ in range(10):
        res = mw.submit(add1, results[-1])
        results.append(res)
        # at this point, the last res is the only future in the MonoWorker
        for i in range(len(results) - 1):
            assert not results[i].done()



# Generated at 2022-06-12 14:58:54.743292
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from ..tqdm import tqdm
    from .helpers import strip_tqdm

    def _check_equal(worker, requests):
        for key, val in requests.items():
            if val != int(worker.futures[key].result()):
                raise Exception("fail")

    def _check_all(worker, requests):
        for i in range(max(len(worker.futures), len(requests))):
            key = i
            if key < len(worker.futures):
                if key in requests:
                    if requests[key] != int(worker.futures[key].result()):
                        raise Exception("fail")
            else:
                if key in requests:
                    raise Exception("fail")


# Generated at 2022-06-12 14:58:58.794127
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import numpy as np

    def addition(x, sleep=0.):
        time.sleep(sleep)
        return x + 1

    worker = MonoWorker()
    x = np.arange(5)
    x_plus_one = np.array([worker.submit(addition, (xx, .1))
                           for xx in x])
    assert (np.array([future.result() for future in x_plus_one]) == x + 1).all()

    x = np.arange(10)
    x_plus_one = np.array([worker.submit(addition, (xx, .1))
                           for xx in x])
    assert (np.array([future.result() for future in x_plus_one]) == x + 1).all()

# Generated at 2022-06-12 14:59:05.704886
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test MonoWorker.submit by submitting 2 tasks
    """
    # Create MonoWorker
    mono = MonoWorker()

    # Create 2 tasks
    def task1():
        return 1
    def task2():
        return 2
    tasks = [task1, task2]

    # Submit 2 tasks
    mono.submit(tasks[0])
    mono.submit(tasks[1])

    # Retrieve result
    result = []
    for future in mono.futures:
        result.append(future.result())
    assert result == [2, 1]

# Generated at 2022-06-12 14:59:15.836583
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import numpy as np

    def test_func(i):
        time.sleep(np.random.rand())
        return i

    mw = MonoWorker()
    N = 4
    futures = [mw.submit(test_func, i) for i in range(N)]
    out = [f.result() for f in futures]
    assert sorted(out) == list(range(N))

    mw = MonoWorker()
    futures = [mw.submit(test_func, i) for i in range(N)]
    running, waiting = futures
    time.sleep(0.1)
    assert running.done()
    assert waiting.result() == 3
    assert running.cancelled()

    mw = MonoWorker()

# Generated at 2022-06-12 14:59:27.188100
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    mw.submit(time.sleep, 5)
    mw.submit(time.sleep, 3)
    time.sleep(1)
    mw.submit(time.sleep, 7)
    assert mw.futures[0].exception() is None
    assert mw.futures[1].exception() is None
    assert mw.futures[0].cancel() is False
    assert mw.futures[1].cancel() is True
    assert mw.futures[0].done() is True
    assert mw.futures[1].done() is True
    assert mw.futures[0].result(timeout=0.1) is None

# Generated at 2022-06-12 14:59:36.391877
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import current_thread

    def f1(delay):
        sleep(delay)
        return current_thread().name

    def f2(delay):
        sleep(delay)
        assert False

    worker = MonoWorker()
    assert len(worker.futures) == 0
    worker.submit(f1, 0.1)  # task1
    assert len(worker.futures) == 1
    worker.submit(f1, 0.3)  # task2
    assert len(worker.futures) == 1
    assert worker.futures[0].result(timeout=2.0) != 'MainThread'  # task1
    assert len(worker.futures) == 0
    worker.submit(f1, 0.1)  # task1

# Generated at 2022-06-12 14:59:41.016198
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def test(arg1, arg2=""):
        """simply print arguments"""
        tqdm_auto.write("%s %s" % (arg1, arg2))
    MW = MonoWorker()
    MW.submit(test, "Output1")
    for i in range(1000):
        MW.submit(test, i)
    MW.submit(test, "Output2")

# Generated at 2022-06-12 14:59:47.636287
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Lock
    from concurrent.futures import ThreadPoolExecutor

    m = MonoWorker()
    lock = Lock()

    def slow(n, a, b, kw=1):
        sleep(a + b)
        with lock:
            print("%d: %r" % (n, (a, b, kw)))

    t = m.submit(slow, 1, 1, 2)
    m.submit(slow, 2, 2, 0)
    m.submit(slow, 3, 3, 2)
    t.result()  # wait for completition
    print("Done")
    with ThreadPoolExecutor(max_workers=1) as pool:
        pool.submit(slow, 4, 4, 2)

# Generated at 2022-06-12 14:59:55.170140
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    a = []

    def func(n):
        for i in range(n):
            # Simulate a long task
            time.sleep(1)
            a.append(i)

    m = MonoWorker()
    # Run the task and the next one
    f1 = m.submit(func, 5)
    # Wait only 'n-1' seconds
    time.sleep(1)
    f2 = m.submit(func, 5)
    # Wait 'n' seconds
    m.submit(func, 5)
    f1.result()
    f2.result()
    assert a == list(range(5))*3

# Generated at 2022-06-12 15:00:05.024467
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import TimeoutError
    import inspect

    def _assert_in_future(futures, expected):
        for f in futures:
            if f.result() == expected:
                break
        else:
            raise AssertionError(
                'expected {0!r} in {1!r}'.format(expected, futures))

    def _assert_not_in_future(futures, unexpected):
        for f in futures:
            if f.result() == unexpected:
                raise AssertionError(
                    'unexpected {0!r} in {1!r}'.format(unexpected, futures))

    def _submit(args):
        worker, func, args = args
        return worker.submit(func, *args)

    worker = MonoWorker()
    # test

# Generated at 2022-06-12 15:00:15.129547
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import traceback

    def do_task(i, wait=1):
        print('start task %d' % i)
        try:
            time.sleep(wait)
        except Exception as e:
            print('error when task %d' % i, str(e))
            traceback.print_exc()
            raise
        print('end task %d' % i)

    # do tasks, when the latest task is already running, all other tasks are
    # ignored, and the latest task may override the running one
    mono_worker = MonoWorker()
    for i in range(5):
        mono_worker.submit(do_task, i+1, 2)
        time.sleep(0.8)

    # when max_workers > 1, the last task can be overrided by the latest task


# Generated at 2022-06-12 15:00:18.858839
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test method MonoWorker.submit"""
    import time
    mw = MonoWorker()
    assert mw.submit(time.sleep, 0.001)
    assert mw.submit(time.sleep, 0.001)
    assert mw.submit(time.sleep, 0.001) is None

# Generated at 2022-06-12 15:00:29.157385
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Lock
    from time import sleep
    import random
    import unittest
    import warnings

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        import queue

    def test_func():
        sleep(2 * random.random())
        return 42

    q = queue.Queue()

    class TestMonoWorker(unittest.TestCase):
        def setUp(self):
            self.mono = MonoWorker()

        def test_submit(self):
            self.mono.submit(lambda: q.put(42))
            self.assertEqual(q.get(timeout=5), 42)
            self.mono.submit(lambda: q.put(43))
            self.assertEqual(q.get(timeout=5), 43)

# Generated at 2022-06-12 15:00:37.349644
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    r = random()
    a = ''

    def f(a, r):
        sleep(0.3)
        return a + r

    executor = MonoWorker()
    featured_fut = executor.submit(f, a, r)
    assert len(executor.futures) == 1

    # Start a second task while the first is still running
    task = executor.submit(f, a, r + 1)
    # it will replace the first task and the old first task will still running
    assert not task.done()
    assert len(executor.futures) == 1
    assert featured_fut.cancelled()

    task.result()
    assert len(executor.futures) == 0

    # Start a third task while the second one is

# Generated at 2022-06-12 15:00:50.735634
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 15:00:59.150964
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    from time import sleep
    from ..utils import FormatCustomText
    import sys

    def return_n(n):
        sleep(1)
        return n

    def print_n(n):
        sleep(1)
        FormatCustomText("%s\n", n)._writeln(sys.stderr)

    m = MonoWorker()
    for i in [1, 2, 3]:
        m.submit(print_n, i)
    for i in [4, 5, 6]:
        with tqdm_auto.tqdm(total=1) as f:
            m.submit(return_n, i).add_done_callback(f.update)
    del m
    check = Event()
    check.wait(10)

# Generated at 2022-06-12 15:01:04.204623
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def foo(i):
        return i + 1
    monoworker = MonoWorker()
    assert monoworker.submit(foo, 0).result() == 1
    assert monoworker.submit(foo, 1).result() == 2
    assert monoworker.submit(foo, 2).result() == 3
    try:
        monoworker.submit(foo, "string")  # raised AssertionError
    except AssertionError:
        pass
    else:
        raise AssertionError("Wrong output.")

# Generated at 2022-06-12 15:01:11.092295
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from queue import Queue
    from threading import Thread

    mw = MonoWorker()

    done = Queue()
    is_done = False
    sleep = .1

    def func(i):
        time.sleep(sleep)
        done.put(i)

    def other_thread():
        time.sleep(sleep)
        is_done = True

    Thread(target=other_thread).start()

    func01 = mw.submit(func, 0)
    func11 = mw.submit(func, 1)
    assert func01.done()



# Generated at 2022-06-12 15:01:18.699779
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def test(a, b):
        sleep(a)
        return b

    def test_cancel(a, b):
        sleep(a)
        return b

    mono = MonoWorker()
    mono.submit(test, 1.0, 1)
    mono.submit(test, 2.0, 2)
    mono.submit(test, 3.0, 3)
    res = [mono.futures[0].result(), mono.futures[1].result()]
    assert res == [3, 2], "res={}".format(res)

    mono = MonoWorker()
    mono.submit(test, 1.0, 1)
    mono.submit(test_cancel, 2.0, 2)
    mono.submit(test, 3.0, 3)

# Generated at 2022-06-12 15:01:27.738217
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from queue import Queue
    from concurrent.futures import Future
    from multiprocessing import cpu_count

    def sleep_and_return(secs, result, queue):
        if queue is not None:
            queue.put(id(secs))
        sleep(secs)
        return result

    def test_worker(mono):
        assert not mono.futures  # new worker has no futures
        f1 = mono.submit(sleep_and_return, 1, 'f1', None)
        assert isinstance(f1, Future)
        sleep(0.5)
        assert 1 == len(mono.futures)
        assert id(1) == queue.get_nowait()
        assert not f1.done()

# Generated at 2022-06-12 15:01:35.044805
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def function(x):
        time.sleep(x)
        tqdm_auto.write("function(%d)" % x)

    mw = MonoWorker()
    mw.submit(function, 1)
    time.sleep(0)
    mw.submit(function, 5)
    time.sleep(0)
    mw.submit(function, 1)

    time.sleep(2)
    mw.submit(function, 1)
    mw.submit(function, 1)
    mw.submit(function, 1)

# Generated at 2022-06-12 15:01:41.181448
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from itertools import count

    # noinspection PyUnusedLocal
    def wait(wait_time, counter):
        sleep(wait_time)
        return counter

    def test_submit(iter_n, wait_times):
        """Test MonoWorker.submit with a set of wait times."""
        wait_times = list(wait_times)  # make a list
        counter = count(1)
        worker = MonoWorker()
        for i in tqdm_auto.tqdm(list(range(iter_n)),
                                miniters=1, mininterval=0.01):
            wait_time = wait_times.pop(0)
            future = worker.submit(wait, wait_time, next(counter))
            assert future is not None


# Generated at 2022-06-12 15:01:49.947087
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    m = MonoWorker()
    N = 5000

    # test if running tasks are correctly replaced with waiting tasks
    r = []
    for i in range(N):
        r.append(m.submit(random.random).result())

    assert len(r) == len(set(r))
    assert set(r) == set(random.random() for _ in range(N))

    # test if run_and_wait freezes when a task is cancelled (no more exec)
    m = MonoWorker()
    r = []
    num_done = 0
    for i in range(N):
        if i == N // 2:  # cancel halfway for some
            m.futures[0].cancel()
        r.append(m.submit(random.random).result())

# Generated at 2022-06-12 15:01:57.781897
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test the method submit of the class MonoWorker."""
    import time
    import threading
    import tqdm.contrib as tqdm_contrib
    import numpy as np
    import os

    # Define a function that puts the test to sleep for a given time.
    def sleep(sleep_time):
        """
        Function that sets the test to sleep for sleep_time seconds.

        Parameters
        ----------
        sleep_time : float
            Duration of the sleep period in seconds.

        Returns
        -------
        None
        """
        time.sleep(sleep_time)

    # Define the parameters for the tests.
    test_times = [1, 5]
    sleep_times = [1, 10]


# Generated at 2022-06-12 15:02:15.329217
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import sys
    mw = MonoWorker()
    done = threading.Event()
    stdout = sys.stdout

# Generated at 2022-06-12 15:02:21.597356
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    # Test basic operation
    def f(x):
        return x
    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert mw.submit(f, 1) is not None
    assert len(mw.futures) == 1
    assert mw.submit(f, 1) is None
    assert len(mw.futures) == 1
    assert mw.futures[-1].result() == 1
    # Test that the running function is replaced with the waiting one
    def g(x):
        time.sleep(1)
        return x * 2
    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert mw.submit(f, 1) is not None

# Generated at 2022-06-12 15:02:24.699065
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Unit test for method submit.
    """
    import time
    worker = MonoWorker()
    assert len(worker.futures) == 0
    f0 = worker.submit(time.sleep, 0.1)
    assert len(worker.futures) == 1
    try:
        f1 = worker.submit(time.sleep, 0.1)
    except Exception as e:
        tqdm_auto.write(str(e))



# Generated at 2022-06-12 15:02:32.365356
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock

    m = MonoWorker()
    test_lock = Lock()


# Generated at 2022-06-12 15:02:42.045025
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import format_sizeof
    import random
    import string
    import time

    # Tests
    random.seed(1)
    for qsize in [1, 2]:
        for ntasks in [1, 10, 100, 1000]:
            for length in [1, 10, 100, 1000]:
                length_kbytes = format_sizeof(len(string.ascii_letters) * length)
                tqdm_auto.write(('testing:', qsize, ntasks, length_kbytes))
                worker = MonoWorker()
                futures = []
                start = time.time()
                for task in range(ntasks):
                    random.shuffle(string.ascii_letters)
                    letters = dict.fromkeys(string.ascii_letters[:length])

# Generated at 2022-06-12 15:02:47.078057
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    from .iterable_wrapper import IterableWrapper

    def randsleep(low=0, high=10):
        time.sleep(low + random.random() * (high - low))

    maw = MonoWorker()
    N = 4
    for r in range(N):
        randsleep()
        maw.submit(randsleep, 0, r)

    for _ in IterableWrapper(maw.futures, "tasks"):
        pass

# Generated at 2022-06-12 15:02:51.917327
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import gc
    mw = MonoWorker()
    fut = []
    super_fut = []

    def timeout(timeout):
        sleep(timeout)
        fut.append(None)

    for _ in range(5):
        fut.append(mw.submit(timeout, 0.010))

    del mw
    gc.collect()
    sleep(0.050)

    assert len(fut) == 2
    for i in range(2):
        assert fut[i] is None

# Generated at 2022-06-12 15:03:02.961431
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import math

    def f(x):
        time.sleep(x)
        return x

    def f_rand():
        """return random time and x to test in a random order"""
        x = random.random()
        return (x, math.cos(x))

    x = [0.1, 0.2, 0.3]
    assert list(map(f, tqdm_auto(x))) == x

    mw = MonoWorker()
    for x, _ in tqdm_auto(map(f_rand, range(3))):
        assert mw.submit(f, x).result() == x

    x = [0.1, 0.2, 0.3]
    assert list(map(f, tqdm_auto(x))) == x

    mw = Mono

# Generated at 2022-06-12 15:03:08.494607
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    worker = MonoWorker()

    def bar(t):
        sleep(t)
        return t

    a = worker.submit(bar, 7)
    b = worker.submit(bar, 4)
    sleep(1)
    worker.submit(bar, 1)  # replace waiting
    sleep(3)
    worker.submit(bar, 1)  # replace running
    sleep(5)
    c = worker.submit(bar, 2)
    sleep(2)

    assert a.result() == 7
    assert b.result() == 4
    assert c.result() == 2

# Generated at 2022-06-12 15:03:17.362028
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func_a():
        time.sleep(10)
        return 0

    def func_b():
        time.sleep(10)
        return 1

    mw = MonoWorker()
    a = mw.submit(func_a)
    if a.result(timeout=10) != 0:
        raise Exception('a.result != 0')

    a = mw.submit(func_a)
    b = mw.submit(func_b)
    if b.result(timeout=10) != 1:
        raise Exception('b.result != 1')
    if a.result(timeout=10) != 0:
        raise Exception('a.result != 0')
    if b.result(timeout=10) != 1:
        raise Exception('b.result != 1')



# Generated at 2022-06-12 15:03:37.544972
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing
    import time
    import sys

    mw = MonoWorker()

    def submitter(m, n):
        sleep = multiprocessing.Process(target=time.sleep, args=(n, ))
        sleep.start()
        mw.submit(sleep.join)
        sys.stderr.write(" {}".format(m))

    for m in range(10):
        for n in range(5, 10):
            submitter(m, n)
            time.sleep(.1)
    sys.stderr.write("\n")
    time.sleep(20)

# Generated at 2022-06-12 15:03:43.846132
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def _print_time(a):
        time.sleep(random.uniform(1, 3))
        return time.time()

    mono_worker = MonoWorker()

    tqdm_auto.write(str(mono_worker.submit(_print_time, 'a')))
    time.sleep(1)
    tqdm_auto.write(str(mono_worker.submit(_print_time, 'b')))
    time.sleep(2)
    tqdm_auto.write(str(mono_worker.submit(_print_time, 'c')))
    time.sleep(2)
    tqdm_auto.write(str(mono_worker.submit(_print_time, 'd')))
    time.sleep(2)

# Generated at 2022-06-12 15:03:53.834630
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Start with a clean slate from any previous tests
    from time import sleep
    import os
    import multiprocessing
    # Multiprocessing seems to leave behind some extra processes
    # when this test is run (see #416), so we kill them all
    for pid in os.listdir('/proc'):
        if pid.isdigit():
            os.kill(int(pid), 9)
    # This test may hang (and thus cause travis builds to fail) if
    # multiprocessing incorrectly spawns fresh python processes.
    # See #416 and #595.
    multiprocessing.set_start_method("spawn")

    def test_a():
        sleep(4)
        return "a"

    def test_b():
        sleep(2)
        return "b"


# Generated at 2022-06-12 15:04:02.752120
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from unittest import TestCase, main
    from unittest.mock import MagicMock

    class Test(TestCase):
        def setUp(self):
            self.dummy = MagicMock()
            self.worker = MonoWorker()

        def tearDown(self):
            tqdm_auto.write('tearDown: Nothing to do.')

        def test_1(self):
            self.worker.submit(self.dummy)
            self.dummy.assert_not_called()

        def test_2(self):
            self.worker.submit(self.dummy)
            sleep(0.1)
            self.dummy.assert_called_once_with()

        def test_3(self):
            self.worker.submit(sleep, 0.3)
            sleep

# Generated at 2022-06-12 15:04:07.188088
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures
    import time
    import random
    import sys

    def get_sleep_random(i):
        def sleep_random():
            time.sleep(random.uniform(0.1, 0.2) * i)
        return sleep_random

    for _ in range(4):  # execute several times
        worker = MonoWorker()
        for i in range(1, 5):
            worker.submit(get_sleep_random(i))
        worker.pool.shutdown(wait=True)

# Generated at 2022-06-12 15:04:12.560667
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    import threading

    def f(x):
        time.sleep(random.random())
        return x + 1

    m = MonoWorker()

    # case 1: no task
    m.submit(f, 1).result()

    # case 2: two tasks, second task is waiting
    waiting = m.submit(f, 2)
    waiting.result()

    # case 3: two tasks, first task is running
    waiting = m.submit(f, 3)
    waiting.result()

    # case 4: three tasks, test that second task is discarded
    running = m.submit(f, 4)
    time.sleep(0.3)  # let running task run for a while
    discard = m.submit(f, 5)
    waiting = m.submit(f, 6)
    assert discard

# Generated at 2022-06-12 15:04:17.390373
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from copy import copy
    from time import sleep

    results = []

    def func(i, sleep_time):
        sleep(sleep_time)
        results.append(i)

    mw = MonoWorker()
    # submit running
    future_running = mw.submit(func, 0, 0.1)
    # submit waiting
    future_waiting = mw.submit(func, 1, 1)
    # submit waiting
    future_waiting_2 = mw.submit(copy(future_waiting))
    # submit running
    future_running = mw.submit(func, 2, 0.1)
    # submit waiting
    future_waiting = mw.submit(func, 3, 1)
    assert not future_running.cancel()
    assert future_waiting.cancel()
    assert future_

# Generated at 2022-06-12 15:04:25.890989
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """MonoWorker method submit unit test."""

    import time
    import os
    import random

    def sleep_ms(ms):
        time.sleep(ms / 1000.0)

    def func(tq, n=10):
        with tqdm_auto.tqdm(total=n) as t:
            for _ in range(n):
                sleep_ms(random.random() * 10 + 1)
                t.update()

    if os.getenv('TRAVIS') == 'true':
        # Travis-CI has limited resources, so we make tests shorter
        func(None, n=2)
    else:
        m = MonoWorker()
        m.submit(func)
        m.submit(func, n=100)
        m.submit(func)

# Generated at 2022-06-12 15:04:34.490990
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from contextlib import contextmanager
    import sys

    @contextmanager
    def capture_stdout(stdout=None):
        if stdout is None:
            stdout = sys.stdout
        old = stdout.write
        capturer = []
        try:
            def capturing_write(s):
                capturer.append(s)
            sys.stdout.write = capturing_write
            yield capturer
        finally:
            sys.stdout.write = old

    def long_running(t):
        """long_running takes time to run, and prints when it finishes"""
        sleep(t)
        print("{}s finished".format(t))
        return t


# Generated at 2022-06-12 15:04:42.669176
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing.pool import ThreadPool as Pool
    import time
    import operator
    import random

    class MonoWorker(object):
        """
        Supports one running task and one waiting task.
        The waiting task is the most recent submitted (others are discarded).
        """
        def __init__(self):
            self.pool = Pool(processes=1)
            self.futures = deque([], 2)

        def submit(self, func, *args, **kwargs):
            """`func(*args, **kwargs)` may replace currently waiting task."""
            def add(x, y):
                return x + y
            a = reduce(add, range(1, 100), 0)

# Generated at 2022-06-12 15:05:12.993962
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from functools import partial

    def f(x):
        sleep(1)
        return x * x

    w = MonoWorker()
    xs = list(range(4))
    f_xs = [w.submit(f, x) for x in xs]
    for x, f_x in zip(xs, f_xs):
        assert f_x.result() == x * x

    w = MonoWorker()
    xs = list(range(6))
    f_xs = (w.submit(f, x) for x in xs)
    for x, f_x in zip(xs, f_xs):
        assert f_x.result() == x * x

    w = MonoWorker()
    f = partial(f, x=1)

# Generated at 2022-06-12 15:05:20.765709
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(arg):
        import time
        time.sleep(max(0, arg + 0.5))
        return arg

    def wait(futures, n=1):
        tqdm_auto.write("FUTURE: {0}".format(futures))
        while len(futures) < n:
            try:
                running = futures.popleft()
                running.result()
            except StopIteration:
                break
            except:
                pass
            tqdm_auto.write("FUTURE: {0}".format(futures))
        tqdm_auto.write("FUTURE: {0}".format(futures))
        assert len(futures) <= n

    def submit(pool, arg):
        return pool.submit(func, arg)


# Generated at 2022-06-12 15:05:26.633955
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    mw = MonoWorker()
    assert mw.submit(sleep, 1)  # wait a second

    f1 = mw.submit(sleep, 1)  # wait a second, but will get cancelled.
    assert f1
    assert f1.done() is False
    f2 = mw.submit(sleep, 1)  # wait a second, but will get cancelled.
    assert f2
    assert f2.done() is False
    assert f1 is not f2

    assert f2 == mw.submit(sleep, 1)
    assert f2.done() is False
    sleep(0.5)  # should be interrupted by now
    assert f2.done() is True

    f2 = mw.submit(sleep, 1)  # this one will wait 1 second
    assert f2
   

# Generated at 2022-06-12 15:05:35.392345
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from subprocess import call
    from .io_wrap import read, UnbufferedIO
    from .tqdm_pandas import tqdm_pandas

    with UnbufferedIO(tqdm_auto):
        tqdm_auto.write('\nTEST 1 - in-order execution of commands')
        pool = MonoWorker()
        for i in tqdm_auto(range(5), leave=False):
            pool.submit(call, 'sleep 1', shell=True)
        tqdm_auto.write('\nTEST 2 - out-of-order execution of commands')
        pool = MonoWorker()
        for i in tqdm_auto(range(5), leave=False):
            pool.submit(call, 'sleep 1', shell=True)

# Generated at 2022-06-12 15:05:45.517662
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import pytest

    overall_bar = tqdm_auto.tqdm(total=0)
    with overall_bar:
        mw = MonoWorker()
        for i in tqdm_auto.trange(3, leave=False):
            with tqdm_auto.tqdm(total=2, leave=False, desc='test_submit') as bar:
                for j, k in tqdm_auto.trange(2, leave=False, desc='in_loop'):
                    overall_bar.update()
                    bar.update()
                    mw.submit(sleep, 0.1)
                # 1 job + 1 waiting job
                assert len(mw.futures) == 2
                # remove waiting task (because another task is submitted)
                mw.futures.pop()

# Generated at 2022-06-12 15:05:53.651639
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def dummy_task(dur):
        time.sleep(dur)
        return dur

    mw = MonoWorker()

    threads = []

    def submit_task(dur, i, j):
        threads.append(threading.Thread(
            target=mw.submit, args=(dummy_task, dur), kwargs={}))

    # submit 20 tasks that take 1 second to complete
    for i in range(20):
        # submit first 10 tasks every 1 second
        if i < 10:
            time.sleep(1)
        submit_task(1, i, i)

    # submit 20 tasks that take 9 seconds to complete

# Generated at 2022-06-12 15:05:59.825844
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    mw = MonoWorker()
    s = set()
    def ran_func(x):
        time.sleep(random.random()/10)
        return x
    for i in range(10):
        s.add(mw.submit(ran_func, i).result())
        time.sleep(random.random()/10)
    assert set(range(10)) == s


# Generated at 2022-06-12 15:06:06.206522
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def silent_task(d, t):
        time.sleep(t)
        return d

    mw = MonoWorker()
    assert [i.result(timeout=0.01) for i in [
        mw.submit(silent_task,
                  'previous', 0.1),
        mw.submit(silent_task, 'current', 0.1),
        mw.submit(silent_task, 'next', 0.3)]] == ['current', 'next']

# Generated at 2022-06-12 15:06:13.271258
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def sleeping(t):
        time.sleep(t)
        return t

    mw = MonoWorker()
    # Execute 3 tasks
    f1 = mw.submit(sleeping, 1)
    f2 = mw.submit(sleeping, 2)
    f3 = mw.submit(sleeping, 3)
    time.sleep(0.1)
    assert f1.done()
    assert not f2.done()
    assert not f3.done()
    assert f2 is not f3
    f2.cancel()
    f3.cancel()
    assert f1.result() == 1
    assert f2.done()
    assert f3.done()
    assert f2.result() is None
    assert f3.result() is None
    f2 = mw.submit

# Generated at 2022-06-12 15:06:20.317933
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    dw = MonoWorker()
    a = []
    a_to_expect = [(1,), (2,), (3,), (4,), (5,),
                   (6,), (6,), (7,), (7,), (7,)]
    a_index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    for i in a_index:
        dw.submit(a.append, i)
        if i >= 5:
            time.sleep(0.1)
    assert a == a_to_expect

# Generated at 2022-06-12 15:07:18.302318
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import unittest

    class Test(unittest.TestCase):
        N = 1000
        M = 100
        K = 500
        L = 200

        @staticmethod
        def slow_long_func(x):
            time.sleep(0.1)
            return x
        @staticmethod
        def slow_short_func(x):
            time.sleep(0.1)
            return x

        def test_MonoWorker(self):
            """MonoWorker discard old tasks but running tasks may not be
            cancelled if they have already started.
            """
            mw = MonoWorker()
            # Submit K tasks to ensure that the first task is running
            # (we will wait to complete) and the next M-1 tasks are discarded
            ret = []

# Generated at 2022-06-12 15:07:23.134379
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Unit testing function for method submit of class MonoWorker.
    """
    # Parameter of this method
    func = lambda x: x
    args = (0, 1, 2)
    kwargs = {'zeta': 3}

    # Create a MonoWorker object
    monoWorker = MonoWorker()

    # Submit an object
    monoWorker.submit(func, *args, **kwargs)

    # Assertions
    assert isinstance(monoWorker, MonoWorker) == True
    assert isinstance(monoWorker.pool, ThreadPoolExecutor) == True


# Generated at 2022-06-12 15:07:30.902807
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import tqdm.contrib.concurrency as tc
    MW = tc.MonoWorker
    # weird test: the point is to test the code, not the functionality

    def func(x):
        time.sleep(0.2)
        return 2 * x
    def slow_func(x):
        time.sleep(0.8)
        return 2 * x
    def error_func(x):
        if x == 6:
            return x / 0
        return x

    t0 = time.time()
    mono = MW()
    for i in tqdm_auto.tnrange(10):
        mono.submit(func, i)
        time.sleep(0.1)

    time.sleep(0.1)
    mono.submit(slow_func, -1)

# Generated at 2022-06-12 15:07:36.160277
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    # Running task, add waiting task
    worker = MonoWorker()
    waiting_time = 1.5
    waiting_task = worker.submit(time.sleep, waiting_time)
    assert waiting_task.running() is True, "Waiting task should be running"
    assert waiting_task.done() is False, "Waiting task should not be done"
    before_time = time.time()
    # Running task, add second waiting task
    worker.submit(time.sleep, waiting_time * 2)
    # Waiting task should have been canceled, and replaced by second waiting task
    assert waiting_task.running() is False, "Waiting task should not be running"
    assert waiting_task.done() is False, "Waiting task should not be done"

# Generated at 2022-06-12 15:07:41.410197
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> import time; time.sleep = lambda x: None
    >>> import random; random.uniform = lambda x,y: 2.0
    >>> import sys; sys.stdout = open("/dev/null", "w")

    >>> worker = MonoWorker()
    >>> def foo(x,y): return x+y
    >>> def bar(x,y): return x+y
    >>> def baz(x,y): return x+y
    >>> f1 = worker.submit(foo, 1, 1)
    >>> f2 = worker.submit(bar, 3, 3)
    >>> f3 = worker.submit(baz, 5, 5)
    >>> f3.result()
    10
    >>> f2.result()
    6
    >>> f1.done()
    False
    """
    pass



# Generated at 2022-06-12 15:07:48.677174
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys

    def echo(x=0, y=0, z=0, delay=.5):
        time.sleep(delay)
        return (x, y, z)

    def time_echo(x=0, y=0, z=0, delay=.5):
        start = time.time()
        result = echo(x, y, z, delay)
        end = time.time()
        return end - start, result

    # Setup
    sys.stderr.write(
        '\nTesting tqdm.std.MonoWorker.submit(func, *args, **kwargs)...')
    sys.stderr.flush()
    mt = MonoWorker()

    # Initial wait
    mt.submit(time.sleep, .5)

# Generated at 2022-06-12 15:07:54.454094
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    # for checking the execution order
    counter = [0]

    def func(i):
        sleep(1)
        counter[0] += 1
        return i

    mw = MonoWorker()

    assert len(mw.futures) == 0
    assert counter[0] == 0

    w0 = mw.submit(func, i=0)
    assert len(mw.futures) == 1
    assert counter[0] == 0

    w1 = mw.submit(func, i=1)
    assert len(mw.futures) == 1
    assert counter[0] == 0

    # Following are executed in separate threads. They are not
    # guaranteed to finish in order.
    #assert w0.result() == 0
    w0.result()
    #assert

# Generated at 2022-06-12 15:08:01.604408
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    m = MonoWorker()

    def print_wait(wait_sec, *args):
        sleep(wait_sec)
        import sys
        print(*args, file=sys.__stdout__)

    m.submit(print_wait, 1, "succeed 1")
    m.submit(print_wait, 3, "succeed 3")
    m.submit(print_wait, 5, "succeed 5")
    m.submit(print_wait, 2, "succeed 2")
    m.submit(print_wait, 4, "succeed 4")
    m.submit(print_wait, 3, "fail 3")
    sleep(9)


if __name__ == '__main__':
    test_MonoWorker_submit()