

# Generated at 2022-06-12 14:58:06.108616
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from functools import partial
    from itertools import count

    l = [0]
    de = deque(maxlen=1)
    de.append(None)

    def f(i, d):
        def _():
            sleep(.2)
            l[0] = i
            d.append(None)

        return _

    for i in count(0):
        de[0] = i
        MonoWorker().submit(f(i, de))
        while de[0] is None:
            sleep(.1)
        if l[0] != i:
            raise RuntimeError("Test failed")

# Generated at 2022-06-12 14:58:16.210191
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import format_sizeof
    from ..utils import print_bytes as pb

    def test_task(i, j, sleep=0.0, msg=''):
        time.sleep(sleep)
        return msg + '#{0}x{1}#'.format(i, j)

    # Unit test to demonstrate the effect of consecutive calls

    def test_demo_consecutive_calls(sleep):
        # Without sleep: all tasks are executed
        # With sleep, only one task is executed while consecutive tasks wait
        mw = MonoWorker()

# Generated at 2022-06-12 14:58:23.260546
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import time
    from threading import Event
    mw = MonoWorker()
    fut = None

    def call_me(arg):
        """Use this method for ThreadPoolExecutor to call"""
        print("  Starting:", arg)
        time.sleep(1)
        print("  Finished:", arg)
        return arg

    def future_result(future):
        """Use this method for ThreadPoolExecutor to save result"""
        print("  Result:", future.result())

    def thread_1():
        """Call method 1"""
        global fut
        print("# 1")
        fut = mw.submit(call_me, "1")
        print("# 1.5")
        fut.add_done_callback(future_result)
        print("# 1.6")


# Generated at 2022-06-12 14:58:31.576434
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..auto import tqdm_pandas
    import time
    import pandas as pd

    def foo(x):
        time.sleep(1)
        return x

    N = 5

    tqdm_auto.write('\nTest 1')
    mw = tqdm_pandas.MonoWorker()
    for i in tqdm_pandas.tqdm(range(N)):
        mw.submit(foo, i)

    tqdm_auto.write('\nTest 2')
    mw = tqdm_pandas.MonoWorker()
    for i in tqdm_pandas.tqdm(range(N)):
        mw.submit(foo, i).result()

    tqdm_auto.write('\nTest 3')
   

# Generated at 2022-06-12 14:58:39.897362
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import FIRST_COMPLETED
    from time import sleep

    def f(x):
        """Idle for x seconds, returning x + 1"""
        sleep(x)
        return x + 1

    w = MonoWorker()
    w.submit(f, 2)
    w.submit(f, 0.1)
    w.submit(f, 0.2)
    w.submit(f, 0.3)
    w.submit(f, 0.4)
    result, _ = w.pool._work_queue.get(timeout=1)
    print(result.result())  # prints '1'
    results = w.pool.map(lambda x: x + 1, [1, 2, 3])
    print(list(results))  # prints [2, 3, 4]

# Generated at 2022-06-12 14:58:47.760735
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random, shuffle
    from operator import add

    worker = MonoWorker()
    tqdm_auto.write("[0]")
    worker.submit(sleep, 1.)
    tqdm_auto.write("[1]")
    sleep(.01)
    worker.submit(sleep, 1.)
    tqdm_auto.write("[2]")

    # The following can be used to test the whole class
    random_numbers = [random() for _ in range(1000)]
    # if not enough workers, `sum` becomes much slower
    shuffle(random_numbers)
    tqdm_auto.write(sum(random_numbers))
    tqdm_auto.write(worker.pool.map(add, random_numbers, random_numbers))



# Generated at 2022-06-12 14:58:52.279806
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Lock, Event
    import time

    def func_fails():
        raise RuntimeError('testing RuntimeError')

    def func_sleep_0(lock, event):
        with lock:
            event.wait()

    def func_sleep_1(lock, event, timeout=None):
        with lock:
            event.wait(timeout)

    def func_sleep_30(lock, event, timeout=30):
        with lock:
            event.wait(timeout)

    def func_sleep_60(lock, event, timeout=60):
        with lock:
            event.wait(timeout)

    def func_success():
        return 10

    def func_success_1(lock, event):
        with lock:
            event.wait(timeout=1)
        return 10


# Generated at 2022-06-12 14:59:00.939344
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def wait(x):
        sleep(x)
        return x

    def err(x):
        raise ValueError(x)

    worker = MonoWorker()

    # test maxlen=1: simple behavior
    worker.futures.maxlen = 1
    for i in range(4):
        worker.submit(wait, i)

    # test maxlen=1: basic error
    worker.futures.maxlen = 1
    worker.submit(err, "ValueError")

    # test maxlen=2: basic cancel
    worker.futures.maxlen = 2
    assert(worker.submit(wait, 1).done())
    f1 = worker.submit(wait, 2)
    assert(not f1.done())
    f2 = worker.submit(wait, 3)  # cancel f

# Generated at 2022-06-12 14:59:06.284879
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import os
    import random
    import time

    class MockExe(object):
        def __init__(self):
            self.activity = tqdm_auto.tqdm(total=10)

        def work(self):
            self.activity.update(1)
            time.sleep(random.random() * 0.2)
            self.activity.update(1)
            time.sleep(random.random() * 0.5)
            return random.random()

    exe = MockExe()
    mw = MonoWorker()

    def test(task):
        os.system('cls' if os.name == 'nt' else 'clear')

# Generated at 2022-06-12 14:59:15.970096
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test `MonoWorker.submit()`
    """
    from time import sleep
    from random import randint

    # `args` to be passed to func
    args = (1, 2)

    # `kwargs` to be passed to func
    kwargs = {'key': 'value'}

    # function to be submitted to thread
    def func(arg1, arg2, key='value'):
        """
        Adding arguments `args` and `kwargs`
        """
        sleep(randint(1, 5))
        return arg1 + arg2 + len(key)

    # creating MonoWorker object
    worker = MonoWorker()

    # submitting `func` to worker with `args` and `kwargs`
    future = worker.submit(func, *args, **kwargs)

    # checking the

# Generated at 2022-06-12 14:59:27.270881
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():  # pragma: no cover
    import time
    from inspect import getmembers, isfunction
    from os import system
    from time import sleep
    from traceback import format_exc
    import tqdm.contrib.concurrent as tc

    def test_func(arg):
        sleep(0.1)
        return arg

    # test clear waiting
    mw = tc.MonoWorker()
    mw.submit(test_func, 1)
    mw.submit(test_func, 2)
    assert [mw.futures[0].result(), mw.futures[1].result()] == [1, 2]

    # test clear and reinsert running
    mw = tc.MonoWorker()
    mw.submit(test_func, 1)

# Generated at 2022-06-12 14:59:36.391810
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test method `submit` for class `MonoWorker`."""
    from .autonotebook import tqdm as tqdm_notebook
    from subprocess import Popen, PIPE
    from time import sleep
    from sys import version_info

    tqdm = tqdm_notebook
    if version_info.major > 2:
        from subprocess import DEVNULL
        DEVNULL = DEVNULL
    else:
        import os
        DEVNULL = open(os.devnull, 'wb')

    def write_fifo_lines(fifo_name, lines):
        """Write lines to named_pipe."""

# Generated at 2022-06-12 14:59:45.395731
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import random
    import warnings
    from concurrent.futures import CancelledError
    from ..utils import _range

    ran = _range()

    def get_ran():
        return ran.next

    class Ran(object):
        """Callable object."""
        def __call__(self):
            return get_ran()
    r = Ran()

    # We need a "random" function that is constant between calls
    # but can be changed by the user
    def reset_random():
        # Remove the random.randrange() call from our history
        try:
            ran.next()
        except StopIteration:
            pass
        # Reset the random parameters
        random.seed(0)

    # This is necessary to generate the same random numbers
    # between processes
    reset_random()

    # The error

# Generated at 2022-06-12 14:59:54.079856
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def func(sleep_time):
        sleep(sleep_time)
        return "func({})".format(sleep_time)

    worker = MonoWorker()
    for i in range(10):
        worker.submit(func, 0.3 * random())
    assert not worker.futures[0].done()
    sleep(0.5)
    assert worker.futures[0].done()
    assert worker.futures[0].result() == "func(0.1289548882055931)"


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:00:04.074266
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--t1', type=float, default=0.5, help='max time for nop1')
    p.add_argument('--t2', type=float, default=0.5, help='max time for nop2')
    a = p.parse_args()

    # pylint: disable=unused-argument,missing-docstring,invalid-name

    def nop1(delay, *args, **kwargs):
        time.sleep(delay)
        return str()

    def nop2(delay, *args, **kwargs):
        time.sleep(delay)
        return str()

    worker = MonoWorker()
    for _ in range(10):
        d1 = random

# Generated at 2022-06-12 15:00:10.490914
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def foo(i):
        return i + 1

    def bar(i):
        return i - 1

    worker = MonoWorker()

    # case 1: waiting queue is empty, start a task
    first_task = worker.submit(foo, 2)
    assert first_task.result() == 3
    # case 2: task terminated, start a new task
    second_task = worker.submit(bar, 3)
    assert second_task.result() == 2
    # case 3: waiting queue is full, clear the waiting and start a new task
    third_task = worker.submit(foo, 3)
    assert third_task.result() == 4
    # case 4: waiting queue is full and running is not done, just being waiting
    fourth_task = worker.submit(bar, 4)
    assert fourth_task is None

# Generated at 2022-06-12 15:00:18.595430
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .utils import imported_submodules
    from sys import version
    from pprint import pprint
    from time import sleep

    def test_func(x):
        sleep(x)
        return x

    mw = MonoWorker()

# Generated at 2022-06-12 15:00:28.871938
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():  # pragma: no cover
    from time import time
    from random import randint
    from multiprocessing import Process, Event
    from random import randint
    from time import sleep

    class Finisher(Process):
        def __init__(self, *args, **kwargs):
            super(Finisher, self).__init__(*args, **kwargs)
            self.stop_received = Event()

        def stop(self):
            self.stop_received.set()

        def run(self):
            while not self.stop_received.is_set():
                sleep(randint(0, 10) * 10 ** -3)
            tqdm_auto.write("Finishing")

    finisher = Finisher()
    finisher.start()

# Generated at 2022-06-12 15:00:37.091005
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import math
    import traceback

    class Prefix(object):
        def __init__(self, prefix, tb, max_len=1024):
            self.prefix = prefix
            self.tb = tb
            self.deque = deque(maxlen=max_len)

        def __str__(self):
            return ''.join(self.deque)[:self.deque.maxlen]

        def __iadd__(self, text):
            if self.tb:
                self.deque.append(self.prefix + traceback.format_exc() + '\n')
            self.deque.append(self.prefix + str(text) + '\n')
            return self


# Generated at 2022-06-12 15:00:43.100148
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import subprocess as sp
    # Funtion to convert seconds to day, hours, minutes and seconds
    def convert(seconds):
        day = seconds // (24 * 3600)
        time = seconds % (24 * 3600)
        hour = time // 3600
        time %= 3600
        minutes = time // 60
        time %= 60
        seconds = time
        return "%d:%d:%02d:%02d" % (day, hour, minutes, seconds)

    # Expected output

# Generated at 2022-06-12 15:00:56.569745
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import random as rand
    from time import sleep
    from threading import Lock

    mw = MonoWorker()

    # A long-running task that alludes to the number of tasks submitted
    def long_running_task(total_count):
        with long_task_counter_lock:  # pylint: disable=E0602
            global long_task_counter  # pylint: disable=W0603
            long_task_counter += 1
        sleep(rand() * 0.1 + 0.1)  # random wait time <= 0.2
        with long_task_counter_lock:  # pylint: disable=E0602
            long_task_counter -= 1
        return total_count

    long_task_counter = 0
    long_task_counter_lock = Lock()

    total_count = 0


# Generated at 2022-06-12 15:01:02.704646
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time

    def worker(x):
        time.sleep(x)
        return x

    with tqdm_auto.tqdm(total=5, desc='Testing MonoWorker',
                        smoothing=0, miniters=1, leave=False) as pbar:
        mono_worker = MonoWorker()
        # Create a thread to iterate and update tqdm.
        # This helps to see the effect of MonoWorker, even under a single thread.
        for i in range(5, 0, -1):
            mono_worker.submit(worker, i)
            time.sleep(1)
            pbar.update()

# Generated at 2022-06-12 15:01:05.604652
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .. import trange

    def func(i):
        time.sleep(1)
        return i

    mw = MonoWorker()

    for i in trange(5):
        mw.submit(func, i)
        time.sleep(0.2)

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:01:11.512807
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from itertools import count
    from collections import Counter

    mw = MonoWorker()
    results = {}
    c = Counter()
    for i in count():
        time.sleep(0.015)
        k = i % 4
        mw.submit(lambda x, y=k: results.setdefault(x, y), i, y=k)
        c[k] += 1
        if c[k] > 10:
            break

    assert len(results) == 4
    assert len(set(results.values())) == 1

# Generated at 2022-06-12 15:01:14.736739
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def sleep_a_while():
        time.sleep(1)  # 1 seconds is a long time

    def run_sleep_a_while():
        return sleep_a_while()

    def cancel(future):
        future.cancel()


# Generated at 2022-06-12 15:01:21.517208
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import operator
    import threading
    from time import sleep

    from . import concurrent

    file_handle = concurrent.in_thread(print, "hello")  # thread output to stdout
    stdout = concurrent.DummyFile(file_handle)
    tqdm_auto.set_lock(threading.RLock())  # make tqdm threadsafe
    tqdm_auto.monitor_interval = 0  # disable the default tqdm monitor thread

    def func(i, j):
        sleep(0.01)
        return operator.mul(i, j)

    worker_1 = MonoWorker()
    worker_2 = MonoWorker()
    f1 = worker_1.submit(func, 10, 20)
    f2 = worker_2.submit(func, 10, 20)

# Generated at 2022-06-12 15:01:31.745611
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from collections import namedtuple

    # Dummy class to test method submit of MonoWorker
    class Dummy():
        def __init__(self):
            self.called = 0

        def __call__(self, wait=None):
            self.called += 1
            if wait:
                sleep(wait)
            return self.called

    dummy = Dummy()
    mw = MonoWorker()
    Result = namedtuple('Result', ['n', 'called'])
    expected = []
    for i in range(2):
        while True:
            sleep(0.1 + random() * 0.1)
            result = Result(i + 1, dummy.called)
            if dummy.called:
                expected.append(result)
                break

# Generated at 2022-06-12 15:01:37.701274
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker."""
    from time import sleep
    from concurrent.futures import as_completed

    mw = MonoWorker()

    # Submit the fast task first, the slower task later
    fast_task = mw.submit(sleep, 0.1)
    slow_task = mw.submit(sleep, 0.2)

    for task in as_completed([fast_task, slow_task]):
        print('{}: {}'.format(task, task.result()))


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:01:42.662822
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from sys import argv
    from six.moves import queue
    from tqdm import tqdm
    from .threads import thread

    def run():
        print("Running")
        sleep(1)

    mw = MonoWorker()
    print("Submit 1")
    mw.submit(run)
    print("Submit 2")
    mw.submit(run)
    print("Submit 3")
    mw.submit(run)
    print("Submit 4")
    mw.submit(run)
    print("Submit 5")
    mw.submit(run)

    @thread(max_workers=1)
    def t(q):
        while True:
            e = q.get()
            print("T", e)
            if e is None:
                q.task_done()

# Generated at 2022-06-12 15:01:46.539072
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def time_consume(sleep_time, idx):
        time.sleep(sleep_time)
        return idx

    mw = MonoWorker()
    for i in range(5):
        mw.submit(time_consume, i+1, i)

    assert len(mw.futures) == 1

# Generated at 2022-06-12 15:02:02.699702
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import itertools
    import random

    # To test race conditions, we must be able to:
    # 1) run two functions concurrently
    # 2) dynamically switch between which is which
    # 3) execute a wait-for-the-other-to-finish

    # Based on a "split/brute-force" algorithm
    def compute_one_password(password, digits, max_length):
        """This function is a computational work-horse and has no guarantees
        regarding output or runtime."""
        for length in range(1, max_length + 1):
            for index in itertools.product(digits, repeat=length):
                for offset in range(length):
                    possibility = "".join(digits[i] for i in index)
                    possibility = possibility[offset:] + possibility[:offset]

# Generated at 2022-06-12 15:02:11.694320
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time

    def f():
        time.sleep(0.1)

    def f_with_kwargs(a=0, b=0):
        time.sleep(0.1)

    def do_submit(func, *args, **kwargs):
        worker = MonoWorker()

        # submit, submit, submit
        f1 = worker.submit(func, *args, **kwargs)
        f2 = worker.submit(func, *args, **kwargs)
        f3 = worker.submit(func, *args, **kwargs)

        # wait for all to finish
        for f in [f1, f2, f3]:
            f.result()

    def do_submit_twice(func, *args, **kwargs):
        worker = MonoWorker()

        # submit, submit

# Generated at 2022-06-12 15:02:16.853715
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import queue as Queue

    def f(x):
        time.sleep(0.01)
        return x

    worker = MonoWorker()
    N = 10
    Q = Queue.Queue()  # All results
    for i in range(N):
        Q.put(worker.submit(f, i).result())
    for i in range(N):
        assert Q.get() == i

# Generated at 2022-06-12 15:02:22.587178
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def test_func_1():
        sleep(1)
        return "a"

    def test_func_2():
        sleep(1)
        return "b"

    def test_func_3():
        sleep(1)
        raise Exception("error")

    mw = MonoWorker()

    result = mw.submit(test_func_1)
    assert result.result() == "a"

    result = mw.submit(test_func_2)
    assert result.result() == "b"

    result = mw.submit(test_func_3)
    assert result.exception() is not None
    assert result.exception().args[0] == "error"

    result = mw.submit(test_func_1)
    assert result.result() == "a"



# Generated at 2022-06-12 15:02:27.385096
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time

    # Example: `submit(time.sleep, x)` will "sleep" for `x` seconds.
    def sleep(x):
        time.sleep(x)
        return x

    mono = MonoWorker()
    f1 = mono.submit(sleep, 1)  # wait 1 second
    f2 = mono.submit(sleep, 2)  # wait 2 seconds
    print('f1 start')
    print(f1.result())
    # this will start after f1.result()
    print('f2 start')
    print(f2.result())
    time.sleep(1)
    f3 = mono.submit(sleep, 3)  # wait 3 seconds
    print('f3 start')
    print(f3.result())

# Generated at 2022-06-12 15:02:33.777994
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    class Func(object):
        def __init__(self):
            self.counter = 0

        def __call__(self, a, b, c):
            self.counter += 1
            sleep(random() / 100)
            return self.counter

    # Submit function, while it is running, discard other waiting functions
    func = Func()
    mono_worker = MonoWorker()
    # Submit several functions, none of them should run
    print([mono_worker.submit(func, i, None, None) for i in range(10)])
    sleep(1e-1)
    print(func.counter)
    assert func.counter == 0
    # Submit a function, wait for it to be done
    mono_worker.submit(func, 10, None, None)
   

# Generated at 2022-06-12 15:02:43.713976
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def do_work():
        sleep(random() * 2)
        return 42

    pool = MonoWorker()
    for i in range(10):
        assert pool.futures == deque([], 2)
        pool.submit(do_work)
        assert len(pool.futures) == 1
    while pool.futures:
        sleep(1)
        old_futures = pool.futures.copy()
        pool.submit(do_work)
        futures = pool.futures
        assert len(futures) == 1
        assert len(old_futures) == 1
        assert old_futures[0] not in futures
        assert all(f.done() for f in old_futures)

# Generated at 2022-06-12 15:02:51.977504
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .tests import *

    mw = MonoWorker()
    tests = [
        (lambda: sleep(0.5) or "hi", (), dict(n=1), "hi"),
        (lambda: sleep(0.5) or "hello", (), dict(n=1), "hello"),
        (lambda: sleep(0.5) or "hey", (), dict(n=1), "hello"),
    ]
    tqdm_auto.write("Start")

# Generated at 2022-06-12 15:03:02.961703
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from threading import Event
    from time import sleep

    def func(n, e):
        e.wait()
        return n

    def assert_not_raised(e):
        assert not e.is_set()
        e.set()

    e = Event()
    m = MonoWorker()

    # submit running
    f1 = m.submit(func, 1, e)
    sleep(0.05)
    assert f1.running()
    assert_not_raised(e)

    # submit running
    f2 = m.submit(func, 2, e)
    sleep(0.05)
    assert f2.running()
    assert f1.cancelled()
    assert_not_raised(e)

    # submit waiting

# Generated at 2022-06-12 15:03:09.599269
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(x):
        if x >= 0:
            return x**2
        raise ValueError('negative input')

    m = MonoWorker()
    assert len(m.futures) == 0
    for i in range(4):
        m.submit(f, i)
    assert len(m.futures) == 2
    assert m.futures[-1].result() == 9
    assert m.futures[0].result() == 0
    assert m.futures[-1].exception() is None
    m.submit(f, -1)  # Exception
    assert len(m.futures) == 1
    try:
        m.futures[-1].result()
        assert False
    except Exception as e:
        assert str(e) == "negative input"


#

# Generated at 2022-06-12 15:03:26.693353
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..autonotebook import tqdm
    from .mono_threaded_functions import mapper_unordered
    from time import sleep

    def f(s):
        sleep(s)
        return s

    mw = MonoWorker()
    for i in tqdm(range(10)):
        mw.submit(f, i)

# Generated at 2022-06-12 15:03:35.758786
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def count():
        for i in tqdm_auto.tqdm(range(random.randint(1, 5))):
            time.sleep(0.2)
        return time.ctime()

    worker = MonoWorker()

    # Should have one running and one waiting tasks
    future_running = worker.submit(count)
    try:
        future_waiting = worker.submit(count)
    except Exception:  # in case of RuntimeError: can't start new thread
        pass
    else:
        assert len(worker.futures) == 2

        # Should clear the waiting task and re-insert the running one
        # and wait until the running task is done
        future_running_1 = worker.submit(count)
        assert len(worker.futures) == 2

# Generated at 2022-06-12 15:03:42.715402
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from collections import deque
    from threading import Event
    from multiprocessing import Value

    def worker(x, evt, counter):
        counter.value += 1
        while not evt.is_set():
            # print("sleeping %s" % x)
            time.sleep(x)
        counter.value -= 1
        return "done %s" % x

    class MonoWorkerSub(MonoWorker):
        """
        Supports one running task and one waiting *or* more.
        """
        def __init__(self):
            super(MonoWorkerSub, self).__init__()
            self.futures = deque()

    evt = Event()
    counter = Value('i', 0)
    mw = MonoWorkerSub()


# Generated at 2022-06-12 15:03:53.474794
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from queue import Queue, Empty
    from threading import Thread

    # Establish a coordinator of the worker threads, so that threads
    # can signal each other even if they all slept at once.
    coordinator = tqdm_auto.tqdm(range(2), bar_format='{l_bar}')

    q = Queue()

    def worker(func, *args, **kwargs):
        q.put(func(*args, **kwargs))
        coordinator.update()

    mw = MonoWorker()

    # Submit the tasks.
    mw.submit(worker, sleep, 1, q=q, a=1, b=2)
    mw.submit(worker, sleep, 1, q=q, a=2, b=3)

# Generated at 2022-06-12 15:04:02.275824
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def slow(x):
        time.sleep(x)
        return x

    #  f1   f2   f3   f1   f2'  f3'
    #  [-------]
    #  [------------]
    #  [-----------------]
    #  [------]
    #  [--------------]
    #  [-------------------]

    mw = MonoWorker()
    f1 = mw.submit(slow, 1)
    f2 = mw.submit(slow, 1)
    assert not f1.done()
    f3 = mw.submit(slow, 1)
    assert f1.done()
    assert not f2.done()
    assert not f3.done()
    f4 = mw.submit(slow, 1)
    assert not f2.done()


# Generated at 2022-06-12 15:04:09.089675
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Event
    from concurrent.futures import as_completed

    e = Event()
    e.set()
    def wait_func(timeout=1):
        return e.wait(timeout)

    mw = MonoWorker()
    mw.submit(wait_func)
    assert len(mw.futures) == 1
    assert mw.futures[0].done()

    for i in range(10):
        mw.submit(wait_func, timeout=0.1)
        assert len(mw.futures) == 1
        assert not mw.futures[0].done()

    e.clear()
    sleep(0.2)
    assert all(f.done() for f in mw.futures)
    assert sum

# Generated at 2022-06-12 15:04:19.278080
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def countdown(n, name):
        for i in tqdm_auto(range(n)):
            time.sleep(random.random())
        return 'done %s' % name

    N = 10
    tqdm_auto.write('\n')
    tqdm_auto.write('Countdown %d times' % N)

    tqdm_auto.write('\n')
    tqdm_auto.write('== %d tasks ==' % N)
    mw = MonoWorker()
    for i in tqdm_auto(range(N)):
        mw.submit(countdown, i, 'task %d' % i)
    tqdm_auto.write('Waiting for all tasks to complete.')
    mw.pool.shutdown(wait=True)

# Generated at 2022-06-12 15:04:27.196761
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..auto import trange

    import pytest
    from .utils import IGNORED_EXCEPTIONS

    def raise_exception(e):
        raise e

    def f(x):
        sleep(x)
        return x

    @pytest.mark.skipif(tqdm_auto.tqdm_gui.is_notebook(),
                        reason="Tkinter doesn't like threads")
    def test_MonoWorker(monkeypatch):
        monkeypatch.setattr(tqdm_auto, 'write', lambda *x: None)
        mw = MonoWorker()
        with pytest.raises(Exception):
            mw.submit(raise_exception, Exception('test'))

# Generated at 2022-06-12 15:04:33.117334
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, perf_counter as pc

    def sleeping_work(i, secs):
        sleep(secs)
        return i, pc()

    mono = MonoWorker()
    futures = []
    for i in range(3, 0, -1):
        futures.append(mono.submit(sleeping_work, i, i))
    assert futures[1] == futures[2]
    assert futures[0] != futures[1]
    assert futures[1].result() == (1, futures[0].result()[1])

# Generated at 2022-06-12 15:04:41.175274
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import sys
    import random
    import threading
    import pytest

    # pytest.mark.skipif(
    #     sys.platform == "darwin" and sys.version_info[:2] <= (3, 6),
    #     reason="threading bug (https://bugs.python.org/issue29564) on macOS")

    def append_to_list(arg, n=50, sleep_mu=0.01, sleep_sigma=0.02):
        """Sleep and append to result list."""
        with tqdm_auto.trange(n) as t:
            for _ in t:
                t.set_description(str(arg))
                sleep(random.gauss(sleep_mu, sleep_sigma))
        return arg

    def body():
        result = []


# Generated at 2022-06-12 15:05:19.898696
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def get_futures_calls(mw, n):
        """
        Run submit `n` times and return the list of functions called
        (`n` is the `maxlen` of a `deque`)
        """
        func = lambda i: (i, time.sleep(1))
        futures = []
        for i in range(n):
            futures.append(mw.submit(func, i))
        for f in futures:
            f.result()
        return [f.running_func for f in mw.futures]

    mw = MonoWorker()
    assert get_futures_calls(mw, 2) == [(0, time.sleep(1)), (1, time.sleep(1))]

# Generated at 2022-06-12 15:05:25.375926
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from tqdm.utils import _range
    from time import sleep
    from random import random

    def fib(n):
        if n <= 2:
            return 1
        return fib(n - 1) + fib(n - 2)

    mw = MonoWorker()

    def compute(i):
        sleep(random() * 4)
        return fib(i)

    results = []
    for i in _range(8):
        try:
            r = mw.submit(compute, i)
            if r is not None:
                results.append(r)
        finally:
            sleep(1)
    assert len(results) == 8
    assert [r.result() for r in results] == [1, 1, 2, 3, 5, 8, 13, 21]

# Generated at 2022-06-12 15:05:30.761020
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Lock
    import time

    lock = Lock()
    lock.acquire()  # released after 1 second
    worker = MonoWorker()

    def my_func(wait_time):
        with lock:
            time.sleep(wait_time)
            return wait_time

    future1 = worker.submit(my_func, 0.5)
    future2 = worker.submit(my_func, 2.)
    future3 = worker.submit(my_func, 1.)
    assert len(worker.futures) == 1
    assert future3 == worker.futures[0]
    assert tqdm_auto.format_interval(future3.result()) == '0.5s'
    # future2 is ignored
    assert len(worker.futures) == 1
    assert future3 == worker.fut

# Generated at 2022-06-12 15:05:41.284705
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Unit test for method submit of class MonoWorker.

    It must be run in a separate process to avoid sharing the same thread pool.
    """
    from time import time
    from threading import Lock
    from multiprocessing import Process

    lock = Lock()
    results = []

    def run(worker, func, *args, **kwargs):
        future = worker.submit(func, *args, **kwargs)
        outputs = []

        def record_output(output, _results=results, _lock=lock):
            """Method to record outputs and save them to the global var _results."""
            with _lock:
                _results.append(output)


# Generated at 2022-06-12 15:05:47.556653
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    running = mw.submit(time.sleep, 0.2)
    waiting = mw.submit(time.sleep, 0.1)
    assert(running.result() == None)
    assert(waiting.cancelled())
    running = mw.submit(time.sleep, 0.1)
    waiting = mw.submit(time.sleep, 0.2)
    assert(waiting.cancelled())
    assert(running.result() == None)
    mw.pool.shutdown()

# Generated at 2022-06-12 15:05:55.050435
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from ..compatibility import ThreadPoolExecutor

    # HACK: avoid concurrency issues
    ThreadPoolExecutor = ThreadPoolExecutor

    try:
        import queue
    except ImportError:
        import Queue as queue

    q = queue.Queue()

    def f(x):
        q.put(x)
        time.sleep(1)
        q.put(x)

    mw = MonoWorker()
    mw.submit(f, 0)
    mw.submit(f, 1)
    time.sleep(.1)
    assert q.qsize() == 0
    mw.submit(f, 2)
    time.sleep(.5)
    mw.submit(f, 3)
    time.sleep(1.1)
    assert q.qsize()

# Generated at 2022-06-12 15:06:05.823310
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import time
    import sys

    class Sleeper:
        def __init__(self, msg, sleep_time):
            self.msg = msg
            self.sleep_time = sleep_time
            self.n = 0

        def __call__(self):
            time.sleep(self.sleep_time)
            self.n += 1
            if self.n > 1:
                print("%s: %s" % (self.msg, self.n))
                print("%s: %s" % (self.msg, self.n), file=sys.stderr)
            return self.n

    mono = MonoWorker()
    sleeper = Sleeper("ZZZ", 0.1)
    sleeper2 = Sleeper("ZZZ2", 0.2)
    f

# Generated at 2022-06-12 15:06:12.987422
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def update_tqdm(tqdm, trange):
        for i in trange:
            assert i == tqdm.n
            tqdm.update(1)
            sleep(0.1)

    mw = MonoWorker()
    with tqdm_auto.tqdm(total=1000, leave=False) as tqdm:
        mw.submit(update_tqdm, tqdm, tqdm_auto.trange(tqdm.total,
                                                      desc='task_1'))
        mw.submit(update_tqdm, tqdm, tqdm_auto.trange(tqdm.total,
                                                      desc='task_2'))

# Generated at 2022-06-12 15:06:21.803201
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func(n):
        time.sleep(n)
        return n

    obj = MonoWorker()
    assert obj.pool._max_workers == 1
    assert len(obj.futures) == 0

    fut = obj.submit(func, 2)
    assert fut.done() is False
    assert len(obj.futures) == 1

    # Immediately submit another task
    fut2 = obj.submit(func, 1)
    assert fut2.done() is False
    assert len(obj.futures) == 2
    assert fut2 is obj.futures[1]  # Must be the latest

    # Wait for the previous task to complete
    assert fut.result(timeout=4) == 2
    assert fut.done() is True
    assert len(obj.futures) == 1
   

# Generated at 2022-06-12 15:06:29.549450
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 15:07:52.081345
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import Future
    from .multiprocessing import Value

    def waiter(i, sleep_time):
        time.sleep(sleep_time)
        return i * i

    def test_waiter(i, sleep_time):
        with lock:
            global fut
            fut = waiter(i, sleep_time)

    mw = MonoWorker()
    lock = Lock()
    fut = Future()

    for t in tqdm_auto.tqdm([0, 1, 2, 1, 2],
                           desc='Test MonoWorker.submit',
                           unit='task', dynamic_ncols=True):
        mw.submit(test_waiter, t, (3 - t) * .2)
        with lock:
            tqdm

# Generated at 2022-06-12 15:08:00.055105
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def wait(t): time.sleep(t)

    mw = MonoWorker()
    assert len(mw.futures) == 0
    f1 = mw.submit(wait, 2)
    assert len(mw.futures) == 1
    f2 = mw.submit(wait, 2)
    assert len(mw.futures) == 1
    assert f1.done()
    assert not f2.done()
    try:
        f2.result()
    except Exception:
        pass
    assert f2.done()
    f3 = mw.submit(wait, 2)
    assert len(mw.futures) == 1
    assert f2.done()
    assert not f3.done()