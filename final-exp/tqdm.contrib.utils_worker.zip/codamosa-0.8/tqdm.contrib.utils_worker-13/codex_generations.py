

# Generated at 2022-06-12 14:58:19.998016
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    values will not be printed because the running task will always be
    replaced by a new waiting task
    """
    from itertools import count
    from time import sleep
    from threading import Thread
    from tqdm.auto import trange

    worker = MonoWorker()

    def print_num(*args, **kwargs):
        """
        function used to test `submit` of `MonoWorker`
        :param args: arguments passed to print
        :param kwargs: keyword arguments passed to print
        :return:
        """
        print(*args, **kwargs)

    t = Thread(target=None, args=())
    with trange(10) as t:
        for i in t:
            t.set_description('worker test')
            t.update()
            sleep(0.1)
            worker

# Generated at 2022-06-12 14:58:29.890486
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import multiprocessing
    import concurrent.futures
    import threading
    from tqdm.auto import tqdm

    mw = MonoWorker()
    futures = []
    for _ in tqdm(range(10)):
        futures.append(mw.submit(time.sleep, 1))

    def _check(futures):
        for f in futures:
            assert f.done(), "future {} should already be done!".format(f)

    t = threading.Thread(target=_check, args=(futures,))
    t.daemon = True
    t.start()
    t.join()
    print("Test passed :)")


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-12 14:58:38.251002
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    wrk = MonoWorker()

    def func(*args, **kwargs):
        # print(args, kwargs)
        time.sleep(1)
        return args, kwargs

    running = wrk.submit(func, 0)

    waiting = wrk.submit(func, 1)  # clears waiting but not running
    assert running.result() == (0, )
    assert len(wrk.futures) == 1
    assert wrk.futures[0].done()
    assert wrk.futures[0].result() == (0, )

    running = wrk.submit(func, 2)  # clears running
    assert len(wrk.futures) == 1
    assert not wrk.futures[0].done()

# Generated at 2022-06-12 14:58:43.461785
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, time

    def debug(x):
        sleep(x)
        now = time()
        w = MonoWorker()
        w.submit(debug, 1.0)
        w.submit(debug, 0.5)
        w.submit(debug, 0.25)
        return time() - now

    expected, actual = 1.0, debug(0.0)
    assert actual >= expected, (actual, expected)



# Generated at 2022-06-12 14:58:49.857659
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import random
    import sys

    def loop(sleeps, width=10, unit_scale=False):
        """Loop with random sleeps."""
        sys.stdout.flush()
        with tqdm_auto.tqdm(total=sum(sleeps), unit_scale=unit_scale,
                            mininterval=0) as pbar:
            for s in sleeps:
                time.sleep(s)
                pbar.update(s)
        sys.stdout.flush()
        return len(sleeps)

    def run(MonoWorker):
        """Test a single MonoWorker."""
        def _run(MonoWorker):
            # submit jobs, with randomized sleep
            sleeper = MonoWorker()

# Generated at 2022-06-12 14:58:57.499766
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> from time import sleep
    >>> m = MonoWorker()
    >>> def f(a):
    ...     sleep(a)
    ...     return a * 2
    >>> m.submit(f, 0.1)
    >>> m.submit(f, 0.2)
    >>> assert m.futures[0].result() == f(0.1)
    >>> assert m.submit(f, 0.3).result() == f(0.3)
    """


if __name__ == "__main__":
    """Run the above doctests"""
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 14:59:07.587633
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from test_tqdm import with_setup  #, pretest
    # by creating separate instance, we isolate the running/waiting tasks
    tests = MonoWorker()

    def do_task_1(runtime):
        time.sleep(runtime)
        return 0

    def do_task_2(runtime):
        time.sleep(runtime)
        return 1

    do_task_1.waiting_runtime = .01
    do_task_1.running_runtime = .02
    do_task_1.waiting_runtime = .03
    do_task_2.running_runtime = .04

    def task_waiting_test():
        def main():
            tests.submit(do_task_1, do_task_1.waiting_runtime)

# Generated at 2022-06-12 14:59:16.605610
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from subprocess import check_output, STDOUT

    def test_func(x, y, z):
        time.sleep(1)
        return x + y + z

    mw = MonoWorker()
    f1 = mw.submit(test_func, 1, 2, z=3)
    f2 = mw.submit(test_func, 10, 20, z=30)
    assert f2.cancelled()
    f1.result()
    f2 = mw.submit(test_func, 100, 200, z=300)
    assert not f1.cancelled()
    f2.result()
    assert f1.cancelled()

    # Run with mw in a subprocess for basic coverage

# Generated at 2022-06-12 14:59:26.774361
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from unittest import TestCase
    import multiprocessing
    import time

    class _T(TestCase):
        def setUp(self):
            self.max_tasks = 2
            self.max_workers = 1
            self.pool = ThreadPoolExecutor(max_workers=self.max_workers)
            self.mw = MonoWorker()
            self.cpu_count = multiprocessing.cpu_count()

        def test_submit(self):
            num_tasks = self.max_tasks + 1
            for i in range(num_tasks):
                self.mw.submit(time.sleep, 0.1)
            num_workers = len(self.mw.pool._threads)
            self.assertEqual(num_workers, self.max_workers)
            num_fut

# Generated at 2022-06-12 14:59:36.355384
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from multiprocessing import Pool
    import sys
    import os

    mw = MonoWorker()

    def wait_for_task():
        # wait for task
        while len(mw.futures) == 0:
            time.sleep(0.01)

    def wait_for_task_done():
        if not mw.futures[0].done():
            time.sleep(0.05)

    tqdm_auto.write("\nTest 1 - submit tasks")
    # check task submitted on empty queue
    mw.submit(lambda x: x, "A")
    time.sleep(0.1)
    assert len(mw.futures) == 1, "Task not submitted!!"

    # submit second task
    mw.submit(lambda x: x, "B")


# Generated at 2022-06-12 14:59:46.446814
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time

    def sleeper(n):
        time.sleep(n)
        return 'done'

    mw = MonoWorker()
    assert len(mw.futures) == 0
    f1 = mw.submit(sleeper, 5)  # runs
    assert len(mw.futures) == 1
    f2 = mw.submit(sleeper, 5)  # waits
    assert len(mw.futures) == 1
    f3 = mw.submit(sleeper, 5)  # replaces waiting task
    assert len(mw.futures) == 1
    assert f1.done()  # running task
    assert f2.done()  # waiting task
    assert not f3.done()  # current waiting task
    time.sleep(3)
    f

# Generated at 2022-06-12 14:59:55.755865
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    finish_event = Event()
    tqdm_auto.write('start (123456)')

    def a():
        time.sleep(.5)
        tqdm_auto.write('a')
        finish_event.wait(1)
        tqdm_auto.write('end a')

    def b():
        tqdm_auto.write('b')
        finish_event.set()
        tqdm_auto.write('end b')

    def c():
        tqdm_auto.write('c')
        tqdm_auto.write('end c')

    m = MonoWorker()
    m.submit(a)
    m.submit(b)
    m.submit(c)
    finish_event.wait()



# Generated at 2022-06-12 15:00:05.060913
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from multiprocessing import cpu_count
    from concurrent.futures import ThreadPoolExecutor, as_completed

    if cpu_count() < 2:
        print('WARNING: skipping test_MonoWorker_submit()')
        return

    class _MonoWorker(MonoWorker):
        def __init__(self):
            super(_MonoWorker, self).__init__()
            self.pool = ThreadPoolExecutor(max_workers=2)
            self.complete = Event()
            self.progress = []

        def submit(self, func, *args, **kwargs):
            n = kwargs.pop('n')
            kwargs['tqdm'] = tqdm_auto.tqdm(total=n)

# Generated at 2022-06-12 15:00:15.126771
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from six.moves import queue
    from .utils import _test_reset

    _test_reset()

    def f(i):
        sleep(0.02)
        tqdm_auto.write(i)

    n = 5
    print('start')
    q = queue.Queue()
    mw = MonoWorker()
    for i in range(n):
        def target_f(i):
            mw.submit(f, i)
            q.put(i)  # index of current/last submitted task
        Thread(target=target_f, args=(i,)).start()
    sleep(0.001)  # wait for threads to start
    print('threads started')
    sleep(0.02 * n)
    print('should be all done')


# Generated at 2022-06-12 15:00:20.574703
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def long_task():
        time.sleep(2)

    worker = MonoWorker()
    worker.submit(long_task)
    worker.submit(long_task)  # should be canceled
    time.sleep(1)
    time0 = time.time()
    worker.submit(long_task)  # should replace the currently waiting task
    print("submit()+sleep(1) took", time.time() - time0)

# Generated at 2022-06-12 15:00:29.945858
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..utils import format_sizeof

    def worker(*args, **kwargs):
        sleep(1.5)  # simulate some task which takes time

    def print_every(worker, num):
        try:
            while True:
                print("Size of worker.futures: {}".format(format_sizeof(worker.futures)))
                yield
        except StopIteration:
            pass

    worker = MonoWorker()
    num = 0
    for _ in print_every(worker, num):
        num += 1
        worker.submit(worker, num)
    print("Finished submitting. Waiting for the last task to finish...")
    last = worker.futures.pop()
    last.result()

# Generated at 2022-06-12 15:00:37.829696
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import FormatCustomText
    import time

    def on_finish(waiting, running):
        assert waiting.done(), "Waiting task must be done"
        assert not running.done(), "Running task must not be done"

    worker = MonoWorker()
    futures = worker.futures
    # worker.submit(lambda: time.sleep(5))
    # worker.submit(lambda: time.sleep(5))
    # worker.submit(lambda: time.sleep(5))
    # worker.submit(lambda: time.sleep(5))
    # worker.submit(lambda: time.sleep(5))
    # worker.submit(lambda: time.sleep(5))
    # worker.submit(lambda: time.sleep(5))
    # worker.submit(lambda: time.sleep(5))

# Generated at 2022-06-12 15:00:43.637914
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def _sleep_n_print(n, string):
        time.sleep(n)
        print("slept for {0} secs".format(n))
        return string

    mw = MonoWorker()
    mw.submit(_sleep_n_print, 10, 'sleep 10')
    mw.submit(_sleep_n_print, 5, 'sleep 5')
    time.sleep(2)
    mw.submit(_sleep_n_print, 2, 'sleep 2')
    time.sleep(12)


# Generated at 2022-06-12 15:00:53.000074
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import random
    import time

    random.seed(0)
    min_t = 0.1

    def gen_delay():
        return min_t + random.random() * 0.1

    max_futures = 4

    def fib(n):
        if n <= 1:
            time.sleep(min_t)
            return 1
        time.sleep(gen_delay())
        return fib(n - 1) + fib(n - 2)

    mw = MonoWorker()

    with tqdm_auto.tqdm(total=max_futures) as pbar:
        for n in range(max_futures):
            future = mw.submit(fib, n + 1)

# Generated at 2022-06-12 15:01:01.223014
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import unittest

    def func(t):
        time.sleep(t)
        return t

    class MonoWorkerTest(unittest.TestCase):
        def test_replace(self):
            mw = MonoWorker()

            t1 = mw.submit(func, 0.1)
            time.sleep(0.05)
            t2 = mw.submit(func, 0.2)
            time.sleep(0.05)
            t3 = mw.submit(func, 0.3)
            time.sleep(0.05)
            t4 = mw.submit(func, 0.4)

            self.assertIs(t1, t3)
            self.assertIs(t2, t4)
            self.assertFalse(t1.done())
            self.assertFalse

# Generated at 2022-06-12 15:01:13.837783
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..utils import FormatCustomTextTest
    from ..utils import spawn_proc, ProcessHandler

    def child_process():
        for _ in range(5):
            sleep(0.5)

    with FormatCustomTextTest(custom_text="(unit test)") as t:
        # Example 6: Worker object
        tqdm_auto.write("Example 6: Worker object")
        worker = MonoWorker()
        with spawn_proc(child_process) as proc:
            # Put proc.pid in description to make it clear which process
            # is being waited on.
            with tqdm_auto(total=proc.pid, desc=str(proc.pid),
                           postfix="(unit test)") as t:
                worker.submit(ProcessHandler(proc, t))
                # Wait until worker is done.

# Generated at 2022-06-12 15:01:21.278024
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def loop(n):
        import time
        for _ in tqdm_auto(xrange(n),
                          desc='foo',
                          total=n):
            time.sleep(0.1)
    MW = MonoWorker()
    f1 = MW.submit(loop, n=1)
    f2 = MW.submit(loop, n=2)
    try:
        f1.result()
        f2.result()
    except Exception as e:
        tqdm_auto.write(str(e))
    return True

# Generated at 2022-06-12 15:01:31.468590
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from sys import stdout

    def f(x):
        sleep(x)
        return x

    mw = MonoWorker()
    for i in range(10):
        t = mw.submit(f, 0.1)
        if i < 9:
            t.cancel()

    for i in range(7):
        t = mw.submit(f, 0.3)
        if i < 6:
            t.cancel()

    mw.submit(f, 0.2)
    mw.submit(f).result()  # should wait for 0.2

    t = mw.submit(f, 1)
    sleep(0.5)
    t.cancel()

    t = mw.submit(f, 2)
    sleep(1.5)  # should cancel

# Generated at 2022-06-12 15:01:36.920722
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    import time
    import pytest

    def func(x):
        time.sleep(x)
        return x
    
    def future_time(x):
        return x.result()

    @pytest.mark.parametrize("futures", [[], [True], [True, True]])
    def test_submit(futures):
        mw = MonoWorker()
        for future in futures:
            mw.submit(func, future_time(future))
        assert len(mw.futures) == len(futures)

# Generated at 2022-06-12 15:01:42.516997
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import randint
    from multiprocessing import Pool
    from math import floor
    from time import sleep
    from contextlib import ExitStack
    from concurrent.futures import Future

    # Setup
    executor = MonoWorker()
    future_pool = Pool()

    def wait_for_future(future):
        # Wait up to 5 ms for the result
        # To avoid causing deadlocks as a result of thread-pool exhaustion
        for _ in range(50):
            if future.done():
                return
            sleep(0.1)
        # In case the future is not done, return 0 to indicate failure
        return 0

    def assert_future_equals(future, value):
        assert future.done()
        assert future.result() == value

    def make_future_with_result(result):
        future = Future

# Generated at 2022-06-12 15:01:50.659739
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    from concurrent.futures import TimeoutError

    def func(x):
        time.sleep(0.1)
        return x

    worker = MonoWorker()

    def check(expected_results, duration_in_secs):
        t = time.time()
        for expected_result in expected_results:
            result = worker.submit(func, expected_result).result(timeout=duration_in_secs)
            assert result == expected_result
        elapsed = time.time() - t
        assert elapsed <= duration_in_secs

    # a is expected to replace b and c, so b and c should be canceled
    check([1], 1.3)
    check([1, 2, 3], 0.25)
    check([1, 2, 3], 0.25)

# Generated at 2022-06-12 15:01:57.019636
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def bar(x):
        sleep(x)
        return x

    mw = MonoWorker()
    assert mw.submit(bar, 0.5)

    # check re-insert running
    mw.submit(bar, 0.01)  # the task is discarded
    assert not mw.futures[0].done()

    # check waiting replacement
    assert mw.submit(bar, 0.1)  # the task is waiting
    sleep(random() / 10)
    mw.submit(bar, 0.2)  # the task is replaced with waiting
    mw.futures[0].result()
    assert mw.submit(bar, 0.3)  # the waiting task is successfully replaced
    res = mw.futures[0].result()

# Generated at 2022-06-12 15:02:04.263568
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    requests = [0] * 10

    def f(i):
        sleep(0.1)
        requests[i] += 1
        return i

    # Test 1
    # Test current running task being replaced by new running task
    m = MonoWorker()
    m.submit(f, 6)
    sleep(0.05)
    m.submit(f, 7)
    sleep(0.2)
    assert requests[6] == 0
    assert requests[7] == 1

    # Test 2
    # Test current waiting task being replaced by new waiting task
    m = MonoWorker()
    m.submit(f, 7)
    sleep(0.05)
    m.submit(f, 8)
    sleep(0.2)
    assert requests[7] == 0
    assert requests[8]

# Generated at 2022-06-12 15:02:14.268956
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()

    # notes for this unittest:
    #   - output of print statements are ordered by statement calling sequence
    #   - output of print statements from threads other than main thread may be out-of-order
    #   - time.sleep(...) may not sleep for the full duration specified
    #   - time.sleep(...) will not sleep at all in main thread if any thread is executing
    #   - Python ThreadPoolExecutor starts threads upon requirement
    #   - Python ThreadPoolExecutor stops threads when idle for 5 seconds

    # no tasks
    assert len(mw.futures) == 0
    print("* submit: no tasks")
    mw.submit(print, "")
    assert len(mw.futures) == 1
    assert not mw.futures[0].done()
    print

# Generated at 2022-06-12 15:02:17.864567
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..auto import trange

    def f(x):
        time.sleep(1)
        return x

    m = MonoWorker()
    for i in trange(10, desc='running pool', leave=True):
        m.submit(f, i)
    m.submit(f, 'TIMEOUT')



# Generated at 2022-06-12 15:02:33.001898
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(n):
        return n*n

    # Test behaviour with no task submitted yet
    worker = MonoWorker()
    assert len(worker.futures) == 0
    worker.submit(func, 1)
    assert len(worker.futures) == 1

    # Test behaviour with one task already running, one task submitted
    worker = MonoWorker()
    assert len(worker.futures) == 0
    running = worker.submit(func, 1)
    assert len(worker.futures) == 1
    worker.submit(func, 2)
    assert len(worker.futures) == 1
    running.result()
    assert len(worker.futures) == 1

    # Test behaviour with two tasks already running, one task submitted
    worker = MonoWorker()

# Generated at 2022-06-12 15:02:42.890267
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    mw = MonoWorker()

    def wait_then_get_result(t):
        time.sleep(t)
        return t

    assert len(mw.futures) == 0
    res = mw.submit(wait_then_get_result, 1)
    assert res.result() == 1

    # Should be able to submit 2 jobs
    res2 = mw.submit(wait_then_get_result, 2)
    assert len(mw.futures) == 2
    # Should discard 'res2' because it is slow
    res3 = mw.submit(wait_then_get_result, 0.5)
    time.sleep(0.7)  # Sleep enough time for 'res3' to finish
    assert mw.futures[0].result() == 0.5


# Generated at 2022-06-12 15:02:50.484862
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    # test 1
    m = MonoWorker()
    assert len(m.futures) == 0
    f1 = m.submit(time.sleep, 0.1)
    assert len(m.futures) == 1
    f2 = m.submit(time.sleep, 0.1)
    assert len(m.futures) == 1
    assert f1 is not f2
    f3 = m.submit(time.sleep, 0.1)
    assert len(m.futures) == 1
    assert f2 is not f3
    f4 = m.submit(time.sleep, 0.1)
    assert f3 is not f4
    assert len(m.futures) == 1

# Generated at 2022-06-12 15:03:01.195802
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    class Foo(object):
        """A class to make a function with attributes."""
        def __init__(self, t=0.01, discard=False):
            """
            Args:
                t: sleep time
                discard: if True, discard this function
            """
            self.t = t
            self.discard = discard

        def __call__(self):
            """Call this function (with sleep)."""
            time.sleep(self.t)
            return self.discard

    # launch the test worker
    worker = MonoWorker()

    # create a random amount of random tasks
    ntasks = random.choice(range(3, 25))
    funcs = [Foo() for _ in range(ntasks)]

# Generated at 2022-06-12 15:03:05.356248
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def raise_exception():
        raise Exception('bar')

    def handle_exception(f):
        try:
            f.result()
        except Exception as e:
            tqdm_auto.write(str(e))

    worker = MonoWorker()
    worker.submit(handle_exception, worker.submit(raise_exception))

# Generated at 2022-06-12 15:03:14.715221
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():  # pragma: nocover
    from time import sleep
    from threading import Event
    from collections import namedtuple
    from concurrent.futures import Future
    EventKey = namedtuple('EventKey', ['id', 'event'])
    #
    def wait_for(*event_keys, **kwargs):
        seconds = kwargs.pop('seconds', 100)
        if not event_keys or seconds <= 0 or kwargs:
            raise ValueError
        #
        all_done = True
        for event_key in event_keys:
            all_done = event_key.event.wait(seconds) and all_done
        return all_done
    #
    def wait_for_any(*event_keys, **kwargs):
        seconds = kwargs.pop('seconds', 100)

# Generated at 2022-06-12 15:03:22.532816
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event

    class Stoppable(object):
        def __init__(self):
            self._stop = Event()

        def stop(self):
            self._stop.set()

        def stopped(self):
            return self._stop.is_set()

        def wait(self, timeout):
            return self._stop.wait(timeout)

    def pause(a, b, delay):
        self = Stoppable()
        while not self.stopped():
            self.wait(delay)
            yield self
        yield a + b

    max_workers = MonoWorker().pool._max_workers

    for _ in range(max_workers):  # start max_workers
        assert (pause(1, 2, 1).send(Stoppable()).result() == 3)


# Generated at 2022-06-12 15:03:25.834269
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func(x, y=None, z=None):
        time.sleep(z)
        return x + y

    n = 2
    mow = MonoWorker()
    for i in tqdm_auto.tqdm(range(n), disable=None):
        mow.submit(func, i, y=(10 * i), z=0.02)

# Generated at 2022-06-12 15:03:34.900748
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures
    import functools
    import itertools
    import signal
    import threading
    import time
    import traceback

    signal.signal(signal.SIGINT, signal.SIG_DFL)

    def test_func(n):
        time.sleep(n)
        return n

    def test_func_exception():
        raise Exception("Test exception")

    def test_func_timeout(n):
        time.sleep(n)
        raise concurrent.futures.TimeoutError("Test timeout error")

    def test_func_keyboard_interrupt():
        time.sleep(1)
        raise KeyboardInterrupt()

    def test_func_cancelled():
        time.sleep(1)
        if threading.current_thread().is_alive():
            raise Exception

# Generated at 2022-06-12 15:03:42.030162
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from ..utils import _range

    import pytest
    from .utils import closing
    from ..std import PY2, PY36

    if not PY2:
        from concurrent.futures import wait
        from concurrent.futures import FIRST_COMPLETED

    def wait_if(func):
        def wrapper(*args, **kwargs):
            if not PY2:
                waiting = args[0].submit(func, *args[1:], **kwargs)
                wait([waiting], timeout=10, return_when=FIRST_COMPLETED)
                return waiting.result()
            else:
                return func(*args, **kwargs)

        return wrapper

    def tqdm_if(it):
        if PY2:
            return it
        else:
            return t

# Generated at 2022-06-12 15:04:00.876378
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f():
        time.sleep(10)

    mw = MonoWorker()
    f1 = mw.submit(f)
    time.sleep(.1)
    f2 = mw.submit(f)
    assert f1.done()
    assert not f2.done()



# Generated at 2022-06-12 15:04:06.523225
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> import time, threading
    >>> def slow_square(x):
    ...     time.sleep(0.1)
    ...     return x ** 2
    >>> mw = MonoWorker()
    >>> futures = []
    >>> for i in range(3):
    ...     futures.append(mw.submit(slow_square, i))
    >>> for future in futures:
    ...     print(future.result())
    0
    1
    4

    """

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 15:04:16.949190
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    # Create a new MonoWorker
    mono = MonoWorker()
    # Create 3 dummy worker functions
    def worker_one():
        time.sleep(3)
        return 1
    def worker_two():
        time.sleep(3)
        return 2
    def worker_three():
        time.sleep(3)
        return 3
    # Submit first worker function
    first_future = mono.submit(worker_one)
    # Submit second worker function
    second_future = mono.submit(worker_two)
    # Submit third worker function
    third_future = mono.submit(worker_three)
    # Retrieve results
    assert second_future.result() == 3
    assert third_future.result() == 3
    assert first_future.result() == 1

# Generated at 2022-06-12 15:04:25.324597
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import TimeoutError
    from time import sleep

    mw = MonoWorker()

    def _mock_task():
        sleep(3)

    def _mock_cancel(fut):
        try:
            fut.result(timeout=0.1)
        except TimeoutError:
            pass  # expected

    def _submit():
        fut = mw.submit(_mock_task)
        sleep(0.1)
        return fut

    fut1 = _submit()
    fut2 = _submit()
    fut3 = _submit()
    # fut1 still running, fut2 waiting, fut3 cancelled
    assert fut3.cancelled()
    _mock_cancel(fut2)
    _mock_cancel(fut1)

# Generated at 2022-06-12 15:04:32.233257
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    @staticmethod
    def fake_thread(x):
        return x ** 2
    pool = MonoWorker()
    assert pool.submit(fake_thread, 2)
    assert pool.submit(fake_thread, 3)
    futures = list(pool.futures)
    assert len(futures) == 1
    assert futures[0].result() == 3 ** 2
    assert pool.submit(fake_thread, 4)
    futures = list(pool.futures)
    assert len(futures) == 1
    assert futures[0].result() == 4 ** 2

# Generated at 2022-06-12 15:04:40.351333
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import get_ident
    mw = MonoWorker()
    tid = get_ident()
    tid2 = mw.submit(get_ident).result()
    assert (tid == tid2), "Executor: %s ; Executed: %s" % (tid, tid2)
    tid = mw.submit(sleep, 1).result()
    assert (tid is None), "Executor: %s ; Executed: %s" % (tid, tid2)
    tid_slow = mw.submit(sleep, 0.5).result()
    assert (tid is None), "Executor: %s ; Executed: %s" % (tid, tid2)
    tid_fast = mw.submit(sleep, 0.1).result()

# Generated at 2022-06-12 15:04:47.453589
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    worker = MonoWorker()
    # test that:
    # 1. Running task is preserved (in spite of other tasks)
    # 2. Waiting task is the most recent
    # 3. Excess tasks are discarded
    # 4. task returns value (and future.add_done_callback() is called)
    import string
    import random
    alphabet = list(string.ascii_lowercase)
    random.shuffle(alphabet)
    tasks = []
    expected = ''
    for c in alphabet:
        task = worker.submit(lambda c=c: time.sleep(1) or c)
        def always_true(fut):
            nonlocal expected
            expected += fut.result()
        task.add_done_callback(always_true)
        tasks.append(task)

# Generated at 2022-06-12 15:04:55.336482
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import current_thread
    from traceback import print_exc
    import sys
    with MonoWorker() as mw:
        def some_slow_task():
            def task(n, sleep_time=2):
                tqdm_auto.write('running task {} in thread {}'
                                .format(n, current_thread()))
                sleep(sleep_time)
            try:
                task(1)
                task(2)
                task(3, 4)
                task(4, 1)
            except Exception as e:
                tqdm_auto.write(str(e))
                print_exc()
        mw.submit(some_slow_task)
        mw.submit(some_slow_task)
        sleep(3)

# Generated at 2022-06-12 15:05:01.614275
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(x):  # sleep and return
        time.sleep(x)
        return x

    mw = MonoWorker()
    first = mw.submit(f, 2)
    secnd = mw.submit(f, 1)  # replaces waiting task
    assert first is not secnd
    assert secnd.result() == 1
    assert first.result() == 2
    assert first.done()
    assert not first.cancelled()
    assert not secnd.cancelled()

    start = time.time()
    first = mw.submit(f, 2)
    assert first.result() == 2
    assert time.time() - start < 1.1

    start = time.time()
    for _ in range(10):
        first = mw.submit(f, 1)

# Generated at 2022-06-12 15:05:06.680050
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..tqdm import tqdm
    import time

    def slow_fib(n):
        if n < 2:
            return n
        return slow_fib(n - 1) + slow_fib(n - 2)

    mw = MonoWorker()

    for n in tqdm(range(40), leave=False, ncols=80):
        future = mw.submit(slow_fib, n)

        while not future.done():
            time.sleep(0.001)

# Generated at 2022-06-12 15:05:48.857595
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    # sleep 3s  # for your amusement
    # for i in range(2):  # add i=1 for your amusement

    def foo(kk):
        sleep(kk)
        return kk

    def bar(kk):
        sleep(kk)
        return -kk

    mw = MonoWorker()
    f = mw.submit(foo, 2)
    f2 = mw.submit(bar, 1)
    assert f is f2
    assert f.result() == -1

    mw.submit(bar, 3)
    with tqdm_auto.external_write_mode():
        tqdm_auto.tqdm.write("#" * 80)
    tqdm_auto.tqdm.write("Finished test_MonoWorker_submit")
    tqdm

# Generated at 2022-06-12 15:05:55.942584
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import multiprocessing
    from nose.tools import eq_

    def foo(*args):
        sleep(args[0])
        return args

    m = MonoWorker()
    m.submit(foo, 0, a=1)
    m.submit(foo, 0, a=2)
    eq_(m.futures[0].result(), (0, 'a'))

    m = MonoWorker()
    m.submit(foo, 2, a=1)
    m.submit(foo, 0, a=2)
    eq_(m.futures[0].result(), (0, 'a'))

    m = MonoWorker()
    m.submit(foo, 0, a=1)
    m.submit(foo, 2, a=2)

# Generated at 2022-06-12 15:06:06.579912
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..utils import _supports_unicode, StringIO

    # Simple MonoWorker example
    mw = MonoWorker()
    newfuture = mw.submit(sleep, 1)
    assert len(mw.futures) == 1
    assert mw.futures[0] == newfuture
    assert newfuture.running()

    # MonoWorker example with previous running
    sleep(3)
    newfuture = mw.submit(sleep, 1)
    assert len(mw.futures) == 1
    assert mw.futures[0] == newfuture
    assert newfuture.running()

    # MonoWorker example with previous waiting
    sleep(3)
    newfuture = mw.submit(sleep, 2)
    assert len(mw.futures) == 1

# Generated at 2022-06-12 15:06:13.105172
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def task(a, b, c):
        import time
        time.sleep(1)
        return a, b, c

    worker = MonoWorker()
    a = worker.submit(task, 1, 2, 3)
    assert a.result() == (1, 2, 3)
    b = worker.submit(task, 1, 2, 4)
    assert b.result() == (1, 2, 4)
    c = worker.submit(task, 1, 3, c='d')
    assert c.result() == (1, 3, 'd')
    worker.submit(task, b='c', a=1, c=2)  # won't be processed
    assert b.result() == (1, 2, 4)

# Generated at 2022-06-12 15:06:21.958325
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import wait

    def echo(i):
        time.sleep(1)
        return i

    W = MonoWorker()
    f1 = W.submit(echo, 1)
    f2 = W.submit(echo, 2)
    f3 = W.submit(echo, 3)

    def check_futures(expected_ids, wait_return):
        # Check return of wait
        assert sorted(r.result() for r in wait_return) == expected_ids
        # Check waiting futures
        assert len(W.futures) == 1
        assert sorted(future.result() for future in W.futures) == expected_ids

    check_futures([1, 2], wait([f1]))

# Generated at 2022-06-12 15:06:29.679796
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    from itertools import count
    from multiprocessing import current_process
    from threading import current_thread

    def sleeper(delay):
        print('{},{} sleeping {} seconds'.format(
            current_process().pid, current_thread().ident, delay))
        time.sleep(delay)
        print('{},{} woke up'.format(
            current_process().pid, current_thread().ident))
        return delay

    def test():
        mw = MonoWorker()
        for _ in count():
            delay = random.randrange(1, 7)
            print('Submitting task with delay {}'.format(delay))
            future = mw.submit(sleeper, delay)
            future.add_done_callback(lambda fut: print('Future {} done'.format(fut)))


# Generated at 2022-06-12 15:06:39.513511
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Lock

    from ..utils import format_sizeof, format_interval
    from ..std import time

    lock = Lock()
    q = MonoWorker()

    def func(*args, **kwargs):
        while True:
            with lock:
                print(format_interval(time.time() - t0),
                      format_sizeof(q.pool._work_queue.qsize()))
            time.sleep(0.01)

    q.submit(func, "hello")  # start the first task

    with lock:
        t0 = time.time()

    for i in range(10):
        with lock:
            print(format_interval(time.time() - t0),
                  format_sizeof(q.pool._work_queue.qsize()))

# Generated at 2022-06-12 15:06:43.634664
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> mw = MonoWorker()
    >>> mw.submit(id, 1)
    >>> mw.submit(id, 'a', 'b')
    >>> assert mw.futures[0]._key == mw.futures[-1]._key
    >>> assert mw.futures[0].result() == 'a'
    >>> assert mw.futures[-1].cancel() > 1  # should return num elements affected
    """
    pass

# Generated at 2022-06-12 15:06:48.610695
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def _raise(e):
        raise e

    def _pass():
        pass

    def _plus():
        return 1 + 1

    def _plus_after(t):
        import time
        time.sleep(t)
        return 1 + 1

    mw = MonoWorker()

    # Check basic functionality
    r = mw.submit(_plus)
    running = r.result()
    assert running == 2

    # Check exception handling
    r = mw.submit(_raise, RuntimeError)
    with tqdm_auto.catch_warnings(record=True):
        with tqdm_auto.utils.DisableLogger():
            running = r.result()
    assert not running

    # Check basic functionality
    r = mw.submit(_plus)
    running = r.result()
    assert running == 2

   

# Generated at 2022-06-12 15:06:56.831805
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    from . import _test_MonoWorker_submit

    def log(s):
        for c in s:
            sys.stdout.write(c)
            sys.stdout.flush()
            time.sleep(0.1)

    def task(s):
        log(s)
        time.sleep(float(s))
        log(s)

    with _test_MonoWorker_submit(MonoWorker):
        task('0')  # should be printed
        task('1')  # should be printed
        task('2')  # should be printed
    with _test_MonoWorker_submit(MonoWorker):
        task('0')  # should be printed
        task('1')  # should be printed
        task('2')  # should be printed