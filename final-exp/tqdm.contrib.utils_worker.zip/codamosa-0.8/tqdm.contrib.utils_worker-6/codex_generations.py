

# Generated at 2022-06-12 14:58:17.807760
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint
    from tqdm import tqdm

    def print_i(i, mid=False):
        """Sleep a little and print `i`"""
        sleep(randint(1, 3))
        if mid:
            print('\r{}'.format(i), end='')
        else:
            print(i)

    m = MonoWorker()
    for i in tqdm(range(100)):
        m.submit(print_i, i)

# Generated at 2022-06-12 14:58:28.605817
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint
    from concurrent.futures import Future  # For testing

    def s(x):
        sleep(randint(1, 10) / 10)
        return x

    def done(f: Future):
        print("Done {} {}".format(f, f.result()))

    m = MonoWorker()
    f = m.submit(s, 10)

    # f2 = m.submit(s, 20)  # Should discard
    # f3 = m.submit(s, 30)  # Should discard
    # f4 = m.submit(s, 40)  # Should discard

    m.submit(s, 50)  # Should make it
    m.submit(s, 60)  # Should discard


# Generated at 2022-06-12 14:58:34.105010
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> mw = MonoWorker()
    >>> mw.submit(lambda: 1 + 2)
    <Future at 0x... state=running>
    >>> mw.submit(lambda: 1 / 0)  # doctest: +IGNORE_EXCEPTION_DETAIL
    Traceback (most ... ZeroDivisionError: division by zero
    >>> mw.submit(lambda: {'answer': 42})
    <Future at 0x... state=running>
    """

# Generated at 2022-06-12 14:58:43.685082
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future

    class MockFuture(Future):
        def __init__(self):
            super(MockFuture, self).__init__()
            self.completed = False

        def done(self):
            return self.completed
        
        def _set_completed(self, completed=True):
            self.completed = completed

    a_MonoWorker = MonoWorker()

    def delay(done, time_delay):
        time.sleep(time_delay)
        done()
        
    def done():
        futures = a_MonoWorker.futures
        if len(futures) == 0:
            # the previous task is still running
            futures.appendleft(e.set_result(None))
            return
        waiting = futures[-1]


# Generated at 2022-06-12 14:58:54.570304
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing.pool import ThreadPool
    import time
    import sys
    import os

    def _time_it(func, *args, **kwargs):
        _t = time.time()
        _v = func(*args, **kwargs)
        return time.time() - _t, _v

    def test(func, args_list, kwargs_list, seconds=5, loop=True,
             log=sys.stderr, expected_overhead=1):
        """
        Test func(*args, **kwargs) with args in args_list and kwargs in
        kwargs_list.
        """
        overhead = 0
        for args, kwargs in zip(args_list, kwargs_list):
            overhead += expected_overhead
            _ = func(*args, **kwargs)

# Generated at 2022-06-12 14:59:02.504609
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from multiprocessing import current_process
    from multiprocessing import Pool
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            w = MonoWorker()
            f = w.submit(time.sleep, 0.1)

            def submit_test(i):
                if i < 5:
                    f = w.submit(time.sleep, 0.1)
                    return f.result()
            p = Pool(5)
            r = p.map_async(submit_test, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
            p.close()

            results = r.get()
            for result in results:
                self.assertEqual(result, None)
            p.terminate()

    unitt

# Generated at 2022-06-12 14:59:09.891401
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from . import assert_equals

    def _test(expected, *args, **kwargs):
        """Clear the mono worker, submit, check the mono worker
        resulted in `expected`."""
        mw = MonoWorker()
        mw.submit(*args, **kwargs)
        assert_equals(len(mw.futures), expected)

    import time
    import random

    class Busy(object):
        """Sleep for random amount of time."""
        def __call__(self):
            time.sleep(random.random())

    # Check that busy callables running side-by-side are stopped
    _test(0, Busy(), _test)
    _test(0, Busy(), _test)

    # Check that busy callables running one after another are stopped

# Generated at 2022-06-12 14:59:14.140958
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test the MonoWorker class."""
    from time import sleep
    from ..gui import tqdm
    from ..utils import _range

    mw = MonoWorker()

    def sleep_10(x):
        sleep(10)
        return x

    for i in tqdm(_range(10)):
        mw.submit(sleep_10, i)
        sleep(1)

# Generated at 2022-06-12 14:59:24.762621
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing
    import time

    class Counter(object):
        count = 0

        def inc(self):
            with self.lock:
                self.count += 1
                time.sleep(0.1)

        def set(self, count):
            with self.lock:
                self.count = count

        def __init__(self):
            self.lock = multiprocessing.Lock()

    counter = Counter()
    mw = MonoWorker()

    for i in range(4):
        mw.submit(counter.inc)
    mw.submit(counter.set, 5)

    time.sleep(0.2)
    assert counter.count == 5
# /test_MonoWorker_submit

if __name__ == '__main__':
    from ._version import __version__

# Generated at 2022-06-12 14:59:30.129834
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .tests import TqdmIterFuturesTestBase
    from tqdm.contrib import DummyExecutor
    t = DummyExecutor()

    with TqdmIterFuturesTestBase() as mock:
        # Submit a new job
        assert t.submit(sleep_for, 0.1).done()

        # Make sure progress bar is displayed
        mock.assert_empty()

        # Submit second job while first is still running
        t.submit(sleep_for, 0.5)

        # Make sure progress bar is hidden
        mock.assert_empty()

        # Wait until all jobs have finished
        t.shutdown(wait=True)

        # Make sure progress bar is still hidden
        mock.assert_empty()



# Generated at 2022-06-12 14:59:34.908418
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    mw.submit(mw.submit, lambda: 0)
    result = mw.submit(mw.submit, lambda: 1)
    assert result.result() == 1

# Generated at 2022-06-12 14:59:44.276304
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from collections import deque

    def f(x, start=None, stop=None):
        if start is not None:
            start.set()
        sleep(x)
        if stop is not None:
            stop.set()

    # Test 1
    mw = MonoWorker()
    done = Event()
    mw.submit(f, 0.1, stop=done)
    done.wait()

    # Test 2
    mw = MonoWorker()
    stops = deque([Event(), Event()], 2)
    mw.submit(f, 0.1, stop=stops[0])
    mw.submit(f, 0.1, stop=stops[1])
    stops[1].wait()
    assert not stops[0].is_set()

# Generated at 2022-06-12 14:59:55.022427
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from threading import Thread
    from tqdm import trange

    # Example: print number after a random delay

    def slow_print(x, delay=None):
        if delay is None:
            delay = random.randint(1, 4)
        time.sleep(delay)
        tqdm_auto.write(str(x))

    # Example: priority queue
    print('\nExample: priority queue')
    worker = MonoWorker()
    for i in trange(10):
        worker.submit(slow_print, i)
    worker.submit(slow_print, 'bye')
    print('done')

    # Example: slow web scraper
    print('\nExample: slow web scraper')


# Generated at 2022-06-12 15:00:05.027049
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    import numpy as np

    n_jobs = 10
    worker = MonoWorker()
    jobs = []
    for i in range(n_jobs):
        jobs.append(worker.submit(sleep, random()))

    tqdm_auto.write('Waiting for all jobs...')
    avg = 0
    for job in jobs:
        job.result()
        avg += job.result()
    tqdm_auto.write('Avg. wait time: {}'.format(avg / n_jobs))

    jobs = []
    for i in range(n_jobs):
        jobs.append(worker.submit(sum, np.random.randint(0, 3, size=5000)))

    tqdm_auto.write('Waiting for all jobs...')
    avg = 0


# Generated at 2022-06-12 15:00:11.027938
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from .tqdm_test_classes import TestNoDisplay, TestDefault

    with TestNoDisplay():
        exec_width = TestDefault.dynamic_miniters(500)
        count = 0
        jobs = []
        mono = MonoWorker()

        def slow(c):
            sleep(c * random())
            return c

        def spinner(i):
            return "|/-\\"[(i % exec_width) // (exec_width // 4)]

        # keep adding jobs until they've all completed
        with tqdm_auto.tqdm(total=exec_width) as t:
            while count < exec_width:
                # submit a job
                jobs.append(mono.submit(slow, count + 1))
                # display a spinner for each running job


# Generated at 2022-06-12 15:00:18.786221
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from threading import Event

    # Test data
    data_to_send = [('a', 1), ('b', 1), ('c', 1), ('d', 1), ('e', 1)]
    data_expected = [('a', 1), ('e', 1)]
    data_received = []
    lock = threading.Lock()
    lock.acquire()  # Hold lock to prevent receiving data until it is ready
    go_event = Event()

    # Test function
    def receiver(sender, data, go_event):
        go_event.wait()  # Wait for sender to be ready
        with lock:  # Prevent sender from sending data too early
            data_received.append((sender, data))
            lock.release()


# Generated at 2022-06-12 15:00:26.703083
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    counter = 0
    def f():
        global counter
        counter += 1
        import time
        time.sleep(5)
    mw = MonoWorker()
    mw.submit(f)
    mw.submit(f)  # <-- should not be called since already has a task running
    time.sleep(1)
    assert counter == 1  # task 1 is running
    mw.submit(f)  # <-- should cancel task 1 as it's running for too long
    import time
    time.sleep(1)
    assert counter == 2  # task 1 has been cancelled, now task 2 is running

# Generated at 2022-06-12 15:00:27.878314
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # TODO
    pass

# Generated at 2022-06-12 15:00:32.914244
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(x):
        return x*x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)
    assert mw.futures[0].result() == 4
    assert mw.futures[1].result() == 25

# Generated at 2022-06-12 15:00:38.199372
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(a, b=1):
        return a, b
    mw = MonoWorker()
    f1 = mw.submit(func, 1, b=2)
    f2 = mw.submit(func, 3, b=4)
    f3 = mw.submit(func, 5, b=6)
    assert f1.done()
    assert not f2.done()
    assert not f3.done()
    assert f3.result() == (5, 6)

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:00:50.624300
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def sleep_print_n(n):
        time.sleep(n)
        tqdm_auto.write('{}'.format(n))
    mw = MonoWorker()
    mw.submit(sleep_print_n, 3)
    assert mw.futures
    assert not mw.futures[0].done()
    mw.submit(sleep_print_n, 2)
    assert len(mw.futures) == 1
    assert mw.futures[0].done()
    for _ in mw.futures:
        _.set_running_or_notify_cancel()
    time.sleep(.1)  # give time for I/O operations to finish

# Generated at 2022-06-12 15:00:59.338612
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import traceback
    running = []
    waiting = []
    def func(n):
        """sleep for n seconds"""
        assert n >= 0
        time.sleep(n)
        running.append(n)
    mw = MonoWorker()
    assert len(mw.futures) == 0
    mw.submit(func, 0.5)
    assert len(mw.futures) == 1
    mw.submit(func, 1.5)
    assert len(mw.futures) == 2
    time.sleep(0.1)  # ensure that submitted calls were started before sleeping
    assert len(running) == len(waiting) == 0
    time.sleep(1)
    assert len(running) == 1
    assert len(waiting) == 0

# Generated at 2022-06-12 15:01:07.907162
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def test_wait(n):
        time.sleep(n)
        return n
    from unittest import TestCase
    test = TestCase()
    mworker = MonoWorker()
    test.assertEqual(mworker.submit(test_wait, 2).result(), 2)
    time.sleep(.5)  # ensure first worker is running
    test.assertEqual(mworker.submit(test_wait, 1).result(), 1)  # cancel 2
    test.assertEqual(mworker.submit(test_wait, 5).result(), 5)  # cancel 1
    time.sleep(.5)  # ensure first worker is running
    test.assertEqual(mworker.submit(test_wait, 3).result(), 3)  # cancel 5

# Generated at 2022-06-12 15:01:11.285217
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(i):
        import time
        time.sleep(2)
        return i + 1

    mw = MonoWorker()
    assert mw.submit(func, 0).result() == 1
    mw.submit(func, 2)
    assert mw.submit(func, 0).result() == 1

# Generated at 2022-06-12 15:01:15.677209
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    worker = MonoWorker()
    item = [0]
    worker.submit(lambda x: time.sleep(0.5) or (x.append(1) and "result"), item)
    worker.submit(lambda x: x.append(2) and "result", item)
    worker.submit(lambda x: x.append(3) and "result", item)
    assert item == [0, 2, 3]



# Generated at 2022-06-12 15:01:20.983317
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    def slow_add(a, b):
        sleep(1)
        return a + b

    worker = MonoWorker()
    a = worker.submit(slow_add, 2, 3)
    b = worker.submit(slow_add, 4, 5)
    worker.submit(slow_add, 6, 7)  # c is discarded
    worker.submit(slow_add, 8, 9)  # d is discarded
    print(a.result(), b.result())  # 7, 13


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:01:28.813678
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import unittest
    import time

    class TmpTest(unittest.TestCase):
        def test_MonoWorker_submit(self):
            def return_after(sec, ret):
                time.sleep(sec)
                return ret

            mw = MonoWorker()
            t1 = mw.submit(return_after, 0.1, 1)
            t2 = mw.submit(return_after, 0.3, 2)
            self.assertTrue(t1.cancel())
            self.assertEqual(t2.result(timeout=0.9), 2)

    unittest.main()

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:01:34.485613
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    count = 0
    def f(wait):
        time.sleep(wait)
        return wait
    for i in range(4):
        fw = mw.submit(f, i * .1)
        count += 1
        if fw:
            count += 1
            assert (fw.result() == i * .1)
    assert count == 4

# Generated at 2022-06-12 15:01:36.735004
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from functools import partial
    stops = [1.0, 2.0, 3.0]
    mw = MonoWorker()
    for stop in stops:
        mw.submit(partial(sleep, stop))
    for stop in stops:
        sleep(stop)

# Generated at 2022-06-12 15:01:42.317445
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    pool = MonoWorker()
    assert len(pool.futures) == 0
    pool.submit(lambda: 0)
    assert len(pool.futures) == 1

    # Should give up waiting task and re-run waiting
    pool.submit(lambda: 1)
    assert len(pool.futures) == 2
    assert dict(f.result() for f in pool.futures) == {0: 0, 1: 1}

    # Should give up waiting task
    pool.submit(lambda: 2, battle=False)
    assert len(pool.futures) == 2
    assert dict(f.result() for f in pool.futures) == {0: 0, 2: 2}

    # Should give up running task
    pool.submit(lambda: 3)
    assert len(pool.futures)

# Generated at 2022-06-12 15:01:57.530210
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(args, kwargs):
        return args, {x: kwargs[x][0] for x in kwargs}
    import time
    mw = MonoWorker()
    assert mw.submit(f, (1, 2), {"a": [1, 2], "b": [3, 4]}).result() == \
        ((1, 2), {"a": 1, "b": 3})
    assert mw.submit(f, (3, 4), {"a": [5, 6], "b": [7, 8]}).result() == \
        ((3, 4), {"a": 5, "b": 7})

# Generated at 2022-06-12 15:02:04.549105
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def task(val):
        if val == 0:
            return val
        time.sleep(0.2)
        return val

    tqdm_auto.write('Testing `MonoWorker`')
    worker = MonoWorker()
    tqdm_auto.write('Submitting 1...')
    a = worker.submit(task, 1)
    tqdm_auto.write('Submitting 1...')
    b = worker.submit(task, 2)
    assert b.done() and a.done() and b.result() == 2 and a.result() == 1
    tqdm_auto.write('Submitting 1...')
    c = worker.submit(task, 3)
    d = worker.submit(task, 4)
    assert not d.done() and c.result() == 3 and d.result

# Generated at 2022-06-12 15:02:14.831471
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from six.moves import queue

    def test_fn_discard(result_q, sentinel):
        result_q.put(sentinel)

    def test_fn_return(result_q, sentinel):
        result_q.put(sentinel)
        return sentinel

    def test_fn_exception(result_q, sentinel, raise_exc=Exception('testing')):
        try:
            raise raise_exc
        except Exception:
            result_q.put(sentinel)
            raise

    def check_running(mw, sentinel, expected):
        result = mw.futures.popleft()
        if expected == 'Error':
            assert result.exception() is not None, 'expected exception'

# Generated at 2022-06-12 15:02:21.206529
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .std import mock
    from .std import patch
    from .std import Queue
    from .std import StringIO

    with patch('sys.stdout'):
        out = StringIO()
        print_ = tqdm_auto.write  # save original
        tqdm_auto.write = out.write  # redirect to buffer

# Generated at 2022-06-12 15:02:29.803402
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import randint
    from time import sleep
    from collections import Counter

    cfg = dict(
        test_runs=10,
        test_run_iter=10,
        test_run_sleep_max=1,
        test_run_sleep_min=2,
        test_run_word_min=0,
        test_run_word_max=10,
    )

    def test_run(**kwargs):
        kwargs.update(cfg)
        words = []
        test_runs = range(kwargs['test_runs'])
        test_runs_pbar = tqdm_auto.tqdm(
            test_runs, ncols=80, total=kwargs['test_runs'],
            unit="test_run", desc="[1] Testing:",
        )

# Generated at 2022-06-12 15:02:33.352331
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    def slow_func(x):
        time.sleep(random.random())
        return x*2
    m = MonoWorker()
    for i in range(10):
        print(i, m.submit(slow_func, i).result())


# Generated at 2022-06-12 15:02:43.269590
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    from time import sleep

    def f(arg, time, event):
        """ Test func """
        sleep(time)
        event.set()
        return arg

    # use no event
    mw = MonoWorker()
    task_start = mw.submit(f, 1, 0.2)
    sleep(0.1)
    task_replace = mw.submit(f, 2, 0)
    assert task_replace == task_start
    assert task_replace.result() == 2

    # use event
    mw = MonoWorker()
    event = Event()
    task_start = mw.submit(f, 1, 1, event)
    sleep(0.1)
    task_replace = mw.submit(f, 2, 0.2, event)
    assert task_replace

# Generated at 2022-06-12 15:02:49.015948
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def basic_func(output):
        time.sleep(1)
        output.append(1)

    output = []
    mono = MonoWorker()
    mono.submit(basic_func, output)
    mono.submit(basic_func, output)
    mono.submit(basic_func, output)
    time.sleep(1)
    mono.submit(basic_func, output)
    time.sleep(1)
    assert len(output) == 2

# Generated at 2022-06-12 15:02:55.626160
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from itertools import cycle
    from os import system
    cmd = "pkill -f '^python tqdm/tests/test_sync.py'"  # kill all test_sync.py
    system(cmd)

    def sleeper():
        sleep(10)

    def clock(i):
        while True:
            sleep(1)
            yield '%02i' % i

    # Serial
    monos = [mono() for i in range(2) for mono in (MonoWorker,)]
    for i in range(100):
        for mono in monos:
            mono.submit(next, cycle(clock(i)))
    for mono in monos:
        mono.submit(sleeper)
    # This test should run forever as nothing gets cancelled

    # Parallel
    from threading import Thread


# Generated at 2022-06-12 15:03:05.803290
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import inspect
    import socket
    import time

    # Necessary for unit tests
    def slow_func(to_wait):
        time.sleep(to_wait)

    def dummy1():
        return

    def dummy2(*args, **kwargs):
        return

    dummy_method = dummy2.__get__(dummy1())  # bound method

    def verify(s):
        for i in (1, 2):
            for j in range(i):
                if s.submit(dummy_method) is not None:
                    raise AssertionError("{}*dummy_method #{} should be None"
                                         .format(i, j+1))

        # with args

# Generated at 2022-06-12 15:03:25.412420
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from queue import Queue

    def f(t, q):
        sleep(t)
        q.put(t)

    mw = MonoWorker()
    q = Queue()

    mw.submit(f, 1, q)
    mw.submit(f, 2, q)
    mw.submit(f, 3, q)
    mw.submit(f, 4, q)

    assert q.get(timeout=10) == 2



# Generated at 2022-06-12 15:03:34.285752
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def chunks(iterable, n):
        """Yield successive n-sized chunks from iterable."""
        for i in range(0, len(iterable), n):
            yield iterable[i:i + n]

    # set up MonoWorker
    from time import sleep
    from concurrent.futures import CancelledError

    mw = MonoWorker()
    d = deque([], 2)

    # Define this to be called from the worker
    def work(n):
        d.append(n)
        sleep(0.001 * n)

    # submit slow-function calls
    for i in tqdm_auto.trange(100):
        mw.submit(work, i)

    # submit fast-function calls

# Generated at 2022-06-12 15:03:39.102395
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def f(i):
        time.sleep(1)
        return i
    m = MonoWorker()
    r = m.submit(f, 0)
    time.sleep(0.1)
    s = m.submit(f, 1)
    time.sleep(0.1)
    t = m.submit(f, 2)
    for a in (r, s, t):
        assert a.result() == 2


# Generated at 2022-06-12 15:03:49.750322
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import numpy as np
    from tqdm import tqdm

    worker = MonoWorker()

    min1, min2 = 1000000, 1000000
    N = 10
    for _ in tqdm(range(N)):
        x = worker.submit(time.sleep, 0.1)
        y = worker.submit(time.sleep, 0.2)

        # x and y should only take 0.2s each
        # due to MonoWorker replacing the task
        now = time.time()
        x.result()
        min1 = min(min1, time.time() - now)
        now = time.time()
        y.result()
        min2 = min(min2, time.time() - now)

    assert np.isclose(min1, min2, 0.2)

# Generated at 2022-06-12 15:03:58.547357
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=global-variable-not-assigned
    global N
    N = None
    worker = MonoWorker()

    def func(a, b=None):
        global N
        N = a + b
        return N

    with tqdm_auto.external_write_mode():
        tqdm_auto.write("func(0, 1)")
        future1 = worker.submit(func, 0, 1)
        N = None
        tqdm_auto.write("func(1, 2)")
        future2 = worker.submit(func, 1, 2)
        tqdm_auto.write("func(2, 3)")
        future3 = worker.submit(func, 2, 3)
    assert future1.result() == 1
    assert future2.result() == 2
    assert future

# Generated at 2022-06-12 15:04:06.245940
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func(*args, **kwargs):
        time.sleep(1)
        return args, kwargs

    # this test runs for ~4-5 seconds
    mono = MonoWorker()
    f = mono.submit(func, 1, 2, 3, test=True)
    assert f.result() == ((1, 2, 3), {"test": True})
    time.sleep(0.1)
    f = mono.submit(func, 4, 5, 6)
    time.sleep(0.1)
    f = mono.submit(func, 7, 8, 9)
    time.sleep(0.1)
    f = mono.submit(func, 10, 11, 12)
    assert f.result() == ((10, 11, 12), {})
    time.sleep(0.1)

# Generated at 2022-06-12 15:04:14.412415
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    tqdm_auto.write('Testing submit of class MonoWorker ...')

    def f(i):
        time.sleep(1)

    def g(i):
        time.sleep(1 / i)

    def h(i):
        time.sleep(1 / i)
        raise Exception('fail')

    m = MonoWorker()
    for i in range(10):
        m.submit(f, i)

    for i in range(10):
        m.submit(g, i)

    for i in range(10):
        m.submit(h, i)

    tqdm_auto.write('Test passed')

# Generated at 2022-06-12 15:04:22.682383
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    times = [time.time()]
    mw.submit(times.append, time.time())
    time.sleep(0.01)
    mw.submit(times.append, time.time())
    time.sleep(0.02)
    mw.submit(times.append, time.time())
    mw.futures[0].result()
    mw.futures[1].result()
    assert len(times) == 3
    assert times[2] - times[1] < times[1] - times[0] < times[2] - times[0]

# Generated at 2022-06-12 15:04:28.772592
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from os import linesep
    from textwrap import dedent
    from threading import Event
    from concurrent.futures import ThreadPoolExecutor

    def wait_print(text, wait, lf):
        time.sleep(wait)
        tqdm_auto.write("wait_print" + str(text) + ('¶' if lf else ''))

    # Test submission order
    wait_times = [0.0, 0.1, 0.2, 0.05]
    worker = MonoWorker()
    for wait_time in wait_times:
        worker.submit(wait_print, wait_time, wait_time)
    time.sleep(0.3)
    tqdm_auto.write("Actual wait_print output below:")

    # Test multiple and simultaneous submissions

# Generated at 2022-06-12 15:04:37.237114
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from queue import Queue
    from .threads import tqdm
    from .misc import format_sizeof

    def gen_data(size):
        return bytes(range(0, size))

    def write_to_file(data, fpath):
        with open(fpath, 'wb') as f:
            f.write(data)

    def read_from_file(fpath):
        with open(fpath, 'rb') as f:
            data = f.read()
        return data

    def verify_data(data, fpath):
        assert data == read_from_file(fpath)
        return True

    def process_data(data):
        sleep(1)
        return data


# Generated at 2022-06-12 15:05:20.325219
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    expected = ["y = 1", "y = 2"]
    tqdm_auto.write("Expected: %s" % str(expected))
    y = 0

    def long_running(y):
        time.sleep(0.1)
        return y

    def waiting(y):
        time.sleep(0.06)
        return y

    # expected = ["y = 2", "y = 2"]
    mono_worker = MonoWorker()
    mono_worker.submit(long_running, 1)
    time.sleep(0.03)
    mono_worker.submit(waiting, 2)
    actual = []
    while mono_worker.futures:
        future = mono_worker.futures.popleft()
        actual.append("y = %s" % future.result())
   

# Generated at 2022-06-12 15:05:24.712479
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep as ts

    def task(i):
        ts(0.5)
        return i

    mw = MonoWorker()
    print(mw.submit(task, 1))
    print(mw.submit(task, 2))
    print(mw.submit(task, 3))
    print(mw.submit(task, 4))
    print(mw.submit(task, 5))
    print(mw.submit(task, 6))
    print(mw.submit(task, 7))
    print(mw.submit(task, 8))

    pass  # ok

# Generated at 2022-06-12 15:05:29.464309
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from time import sleep
    from tqdm.tests import pretest_posttest
    def get_status(future):
        if isinstance(future, Future):
            return future.done()
        return future.status()
    test_sleep = lambda sec: sleep(sec)

    f = MonoWorker()
    assert get_status(f.submit(test_sleep, 1)) is False
    assert get_status(f.submit(test_sleep, 1)) is False
    assert get_status(f.submit(test_sleep, 1)) is False
    assert get_status(f.submit(test_sleep, 1)) is False


# Generated at 2022-06-12 15:05:39.503738
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def dummy_func(wait_for):
        import time
        time.sleep(wait_for)
        return wait_for
    w = MonoWorker()
    assert w.pool.shutdown(wait=False)
    w = MonoWorker()
    a = w.submit(dummy_func, 2)
    b = w.submit(dummy_func, 1)
    assert b == a
    # Even if b was cancelled, it will not return until running future is done
    assert b.done()
    assert b.result() == 2

if __name__ == "__main__":
    try:
        from collections import UserDict as _dict
    except ImportError:
        from UserDict import DictMixin as _dict
    from functools import partial
    from concurrent.futures import ThreadPoolExecutor


# Generated at 2022-06-12 15:05:48.561663
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def _test():
        from time import sleep
        from collections import namedtuple

        MW = namedtuple('MonoWorker', ['max_workers'])
        class _MonoWorker(object):
            def __init__(self):
                self.pool = ThreadPoolExecutor(max_workers=1)
                self.futures = deque([], 2)
            def submit(self, func, *args, **kwargs):
                """`func(*args, **kwargs)` may replace currently waiting task."""
                futures = self.futures
                if len(futures) == futures.maxlen:
                    running = futures.popleft()
                    if not running.done():
                        if len(futures):  # clear waiting
                            waiting = futures.pop()
                            waiting.cancel()
                       

# Generated at 2022-06-12 15:05:53.920722
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Create a MonoWorker (with the default settings)
    worker = MonoWorker()
    # Submit a task that waits for 10 seconds and returns
    future = worker.submit(lambda: time.sleep(10))
    # Submit another task, but it will not be executed since the previous task is still running
    worker.submit(lambda: print("This line should not be printed"))
    # Wait until the previous task finishes
    future.result()
    # Submit another task to see if it is executed
    worker.submit(lambda: print("This line should be printed"))

# Generated at 2022-06-12 15:06:04.481841
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Thread
    import time
    import random

    mw = MonoWorker()
    seq = [i for i in range(random.randint(5, 10))]

    def task(i):
        time.sleep(2)
        return i

    tqdm_auto.write("{} tasks submitted:".format(len(seq)))
    for i in seq:
        tqdm_auto.write('{0:2d}'.format(i))
        mw.submit(task, i)

    tqdm_auto.write("Waiting on all futures:")

    for i in seq:
        tqdm_auto.write('{0:2d}'.format(mw.futures[0].result()))

    Thread(target=mw.submit, args=(task, 5)).start() 

# Generated at 2022-06-12 15:06:08.543256
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    mp = MonoWorker()
    with tqdm_auto.tqdm(total=100) as pbar:
        while pbar.n < 100:
            pbar.update(1)
            sleep(random())
            mp.submit(sleep, random())
    assert mp.pool.shutdown(wait=False)


# Generated at 2022-06-12 15:06:16.375682
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=protected-access
    import time, sys
    import tqdm.contrib
    tqdm_auto.write = print

    def usage():
        print("Usage: %s wait time sec, run time sec" % (sys.argv[0], ))

    def test(t_sleep_run, t_sleep_wait):
        """
        test_MonoWorker_submit:
        args: run, wait
        sleep time of run, time of wait
        """
        def run(arg):
            time.sleep(arg)
            print("run")
        def wait(arg):
            time.sleep(arg)
            print("wait")

        if len(sys.argv) == 1:
            usage()

# Generated at 2022-06-12 15:06:24.664655
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()

    def _test(t):
        time.sleep(t)
        return t

    # submit several tasks
    assert mw.submit(_test, 1) == mw.submit(_test, 2)
    assert mw.submit(_test, 3) != mw.submit(_test, 4)
    assert not mw.futures  # task 3 and 4 waited for task 1 and 2
    time.sleep(2)
    assert len(mw.futures) == 2  # task 3 and 4 are running
    time.sleep(1)  # task 4 is completed, task 3 is running
    assert len(mw.futures) == 2
    time.sleep(1)  # task 3 is completed
    assert not mw.futures

    # submit a task with sleep

# Generated at 2022-06-12 15:07:44.230089
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .tests import MockTqdmFile

    def slow_print(i, sleep_for=0.1):
        """Print i and sleep for sleep_for secs."""
        sleep(sleep_for)
        tqdm_auto.write(str(i))

    # Clear buffer
    out = MockTqdmFile()
    print('', end='', file=out, flush=True)
    out.truncate(0)

    # Single thread
    with out:
        mono = MonoWorker()
        for i in tqdm_auto.trange(1, 5):
            mono.submit(slow_print, i)

    # Multiple threads
    with out:
        mono = MonoWorker()

# Generated at 2022-06-12 15:07:50.774115
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from .utils import Future
    from .utils import _range

    def main():
        import traceback

        MONO_WORKER = MonoWorker()
        for task in [functools.partial(Future, random(), _)
                     for _ in _range(10)]:
            with tqdm_auto.tqdm(disable=True) as t:
                try:
                    done = False
                    while not done:
                        future = MONO_WORKER.submit(task, sleep=sleep)
                        done = future.wait()
                except Exception as e:
                    tqdm_auto.write(str(e))
                    tqdm_auto.write(str(traceback.format_exc()))

    main()

# Generated at 2022-06-12 15:07:55.825707
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures
    import itertools
    import os
    import random
    import threading
    import time

    def _is_running(futures):
        return len(futures) and not futures[0].done()
    def _test_func(i, delay, duration):
        time.sleep(delay)
        t_start = time.time()
        while (time.time() - t_start) < duration:
            pass
        return i
    def _worker(func, futures):
        while len(futures):
            try:
                futures.popleft().result()
            except concurrent.futures.CancelledError:
                pass
    def _sleep_ms(delay_ms):
        time.sleep(delay_ms / 1000.)

# Generated at 2022-06-12 15:08:01.899230
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def write(x):
        time.sleep(x)
        tqdm_auto.write(str(x))
        return x

    m = MonoWorker()
    f1 = m.submit(write, 0.1)
    f2 = m.submit(write, 0.2)
    f3 = m.submit(write, 0.3)
    f4 = m.submit(write, 0.4)
    f5 = m.submit(write, 0.5)
    f6 = m.submit(write, 0.6)

    assert f1.result() == f2.result() == f3.result() == 0.3
    assert f4.result() == f5.result() == f6.result() == 0.6

# Generated at 2022-06-12 15:08:05.129000
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    assert mw.submit(lambda: 1 / 0)  # should be cancelled
    assert mw.submit(lambda: 1 / 0)  # should raise
    assert mw.submit(lambda x: x, 1) == 1

# Generated at 2022-06-12 15:08:06.160345
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    @MonoWorker.submit
    def foo(x):
        return x + 1
    assert foo.result() == 2

# Generated at 2022-06-12 15:08:11.085018
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..auto import tqdm
    from time import sleep

    def myfunc(t, sleep_t=0):
        sleep(t)
        return sleep_t

    with MonoWorker() as mw:
        f1 = mw.submit(myfunc, 1)
        with tqdm(leave=False) as t:
            while not f1.done():
                sleep(0.1)
                t.update()
        assert f1.result() == 0
        f2 = mw.submit(myfunc, 1, 1)
        with tqdm(leave=False) as t:
            while not f2.done():
                sleep(0.1)
                t.update()
        assert f2.result() == 1