

# Generated at 2022-06-12 14:58:17.770171
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm.contrib import ParallelLockedIterator
    from multiprocessing import freeze_support
    freeze_support()  # For Windows support

    def _func(arg):
        sleep(1)
        return arg

    with ParallelLockedIterator(range(5)) as it:
        for i in it:
            _func(i)

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-12 14:58:27.292829
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def run(x):
        return 2*x
    mw = MonoWorker()
    _ = [mw.submit(run, i) for i in range(5)]
    mw.futures[-1].result()
    assert(len(mw.futures) == 2)
    assert(mw.futures[-1].result() == 8)
    _ = [mw.submit(run, i) for i in range(5, 10)]
    mw.futures[-1].result()
    assert(len(mw.futures) == 2)
    assert(mw.futures[-1].result() == 16)

# Generated at 2022-06-12 14:58:31.413059
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> mw = MonoWorker()
    >>> d1 = mw.submit(lambda: 0)
    >>> d2 = mw.submit(lambda: 1)
    >>> d3 = mw.submit(lambda: 2)
    >>> assert d2.cancelled()
    >>> assert d1.result() == 0
    >>> assert d3.result() == 2
    """
    pass

# Generated at 2022-06-12 14:58:39.755762
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    from ..tqdm import tqdm_notebook as tqdm

    class Operation(object):
        def __init__(self, max_num):
            self.num = 0
            self.max_num = max_num
            self.pbar = tqdm(total=max_num, leave=False)
            self.is_done = threading.Event()
        def __call__(self):
            self.pbar.update(self.num)
            while self.num < self.max_num:
                self.num += 1
                time.sleep(0.01)
                self.pbar.update(self.num)
            self.is_done.set()

    operation_a = Operation(5)  # this operation will be interrupted

# Generated at 2022-06-12 14:58:47.701458
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from unittest import TestCase

    class Result:
        def __init__(self):
            self.seq = 0
            self.t = time.time()

    def worker_step(result):
        if result.seq == 0:
            time.sleep(0.2)
            result.seq = 1
        else:
            result.seq = 2
            time.sleep(0.1)

    class TestMonoWorker(TestCase):
        def test_mono_worker(self):
            result = Result()
            mw = MonoWorker()
            mw.submit(worker_step, result)
            self.assertAlmostEqual(result.t, time.time(), delta=0.1)
            self.assertEqual(result.seq, 0)

# Generated at 2022-06-12 14:58:58.081026
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def test_function(*args):
        time.sleep(1)
        return args

    worker = MonoWorker()

    # test that function works when it is not cancelled
    w1 = worker.submit(test_function, 'arg1', 'arg2')
    w2 = worker.submit(test_function, 'arg3', 'arg4')
    assert w2.result() == ('arg3', 'arg4')
    assert w1.result() == ('arg1', 'arg2')

    # test that function is cancelled and does not return a result
    w1 = worker.submit(test_function, 'arg1', 'arg2')
    w2 = worker.submit(test_function, 'arg3', 'arg4')
    assert w1.cancelled() is True

# Generated at 2022-06-12 14:59:07.661158
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def slow(n, offset=0, sleep=0.2):
        time.sleep(sleep)
        return n + offset
    mw = MonoWorker()
    # Check that the first call is not discarded.
    f1 = mw.submit(slow, 1, 0)
    assert f1.result() == 1
    # Check that the second call is not discarded.
    f2 = mw.submit(slow, 2, 0)
    assert f2.result() == 2
    # Check that the second waiting task is discarded.
    assert mw.submit(slow, 3, 0).result() == 3
    # Check that the third waiting task is discarded.
    assert mw.submit(slow, 4, 0).result() == 4
    # Check that the fourth waiting task is discarded.

# Generated at 2022-06-12 14:59:16.633634
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import time
    import traceback
    from concurrent.futures import CancelledError

    sys.stderr.write("Waiting for 2 seconds ...\n")
    time.sleep(2)
    num = 0

    def background_task(num, delay, *args):
        try:
            sys.stderr.write("(%3d) Waited for %.3f seconds "
                             "before starting\n" % (num, time.time() - delay))
            time.sleep(2)
            sys.stderr.write("(%3d) Finished after %.3f seconds\n" %
                             (num, time.time() - delay))
        except CancelledError:
            traceback.print_exc()
            raise

    mw = MonoWorker()

# Generated at 2022-06-12 14:59:26.805820
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import itertools as it
    from multiprocessing import cpu_count

    from . import _range
    from .tpool import ThreadPoolExecutor

    class Context(ThreadPoolExecutor):
        """Context manager for `ThreadPoolExecutor`."""
        def __init__(self, max_workers=None):
            super(Context, self).__init__(max_workers=max_workers)

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            self.shutdown()

    def tst(func, n=2):
        """
        Run a function `n` times and return the running time.
        """

# Generated at 2022-06-12 14:59:35.110783
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def slow_square(x):
        time.sleep(0.1)
        return x ** 2
    tqdm_auto.write('running test_MonoWorker_submit...')
    m = MonoWorker()
    f1 = m.submit(slow_square, 5)
    f2 = m.submit(slow_square, 7)
    f3 = m.submit(slow_square, 9)
    assert f3.done()
    assert not f3.cancelled()
    assert f3.result() == 81
    assert f1.cancelled()
    assert not f2.cancelled()  # f2 is currently running

# Generated at 2022-06-12 14:59:45.424864
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    class _TestMonoWorker(MonoWorker):
        def f(self, x, y=0):
            time.sleep(x)
            return x + y

    worker = _TestMonoWorker()
    assert worker.submit(worker.f, 0.3) is not None
    time.sleep(0.1)
    assert worker.submit(worker.f, 0.2) is not None  # replace waiting
    time.sleep(0.1)
    assert worker.submit(worker.f, 0.2) is not None  # replace waiting
    time.sleep(0.5)
    assert worker.submit(worker.f, 0.3) is not None
    time.sleep(0.5)
    assert worker.submit(worker.f, 0.3) is not None
    time.sleep

# Generated at 2022-06-12 14:59:55.586136
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .utils import _range
    from .utils import _range_count

    mw = MonoWorker()

    def test_func(arg):
        sleep(arg)
        return arg

    r = mw.submit(test_func, 0.01)

    mw.submit(test_func, 0.01)
    for _ in tqdm_auto.trange(_range_count):
        sleep(0.02)

    mw.submit(test_func, 0.01)
    for _ in tqdm_auto.trange(_range_count):
        sleep(0.02)

    mw.submit(test_func, 0.009)
    for _ in tqdm_auto.trange(_range_count):
        sleep(0.02)

# Generated at 2022-06-12 15:00:03.129674
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time

    def f(x):
        time.sleep(1)
        return x

    m = MonoWorker()
    with m.pool:
        m.submit(f, 0)
        m.submit(f, 1)
        m.submit(f, 2)
        assert m.futures[0].result() == 1
        m.submit(f, 3)
        for _ in range(4):
            t = threading.Thread(target=m.submit, args=(f, _))
            t.start()
        assert m.futures[0].result() == 3

# Generated at 2022-06-12 15:00:09.930983
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(x):
        from time import sleep
        sleep(0.01)
        return x

    w = MonoWorker()
    assert len(w.futures) == 0

    future1 = w.submit(f, 1)
    assert len(w.futures) == 1
    assert future1 == w.futures[0]

    future2 = w.submit(f, 2)
    assert len(w.futures) == 1
    assert future2 == w.futures[0]

    assert future1.done()
    assert future1.result() == 1
    assert future2.done()
    assert future2.result() == 2

    future3 = w.submit(f, 3)
    assert len(w.futures) == 1

# Generated at 2022-06-12 15:00:18.134972
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test to ensure the submit() method of MonoWorker works as
    expected and concurrency is handled properly.
    """
    import time
    import multiprocessing
    import queue
    import random

    n_processes = multiprocessing.cpu_count() + 1
    retval_q = queue.Queue()
    monoWorker = MonoWorker()

    # wrapper to put the return value into the queue
    def retval_wrapper(func, *args, **kwargs):
        retval_q.put(func(*args, **kwargs))

    # submit jobs and wait for completion

# Generated at 2022-06-12 15:00:28.090228
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test method submit of class MonoWorker"""
    from time import sleep

    def test_func(*args, **kwargs):
        return args, kwargs

    worker = MonoWorker()
    args = [0, 1, 2]
    kwargs = dict(a=3, b=4, c=5)
    # Clear waiting task
    waiting = worker.submit(sleep, 0.01)
    sleep(0.02)  # wait for waiting task to start
    assert not waiting.done()
    running = worker.submit(test_func, *args, **kwargs)
    sleep(0.02)  # wait for running task to complete
    assert not waiting.done()
    assert running.done()
    assert running.result() == (args, kwargs)

# Generated at 2022-06-12 15:00:36.456467
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    from time import sleep

    def task(t=0.1, output=None):
        """Each task takes 0.1s, then writes its `output` if specified."""
        sleep(t)
        if output:
            tqdm_auto.write(output)

    # Create a MonoWorker and some tasks
    mw = MonoWorker()
    fut1 = mw.submit(task, 1, 'task1')
    fut2 = mw.submit(task, 2, 'task2')
    tqdm_auto.write('-')

    # Add another task, should replace waiting but not running
    fut3 = mw.submit(task, 3, 'task3')

    # Await tasks in order: (2, 3, 1)
    fut2.result(); fut3.result(); fut

# Generated at 2022-06-12 15:00:42.576856
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint
    import sys
    import os

    def callback(i):
        sleep(0.1)
        return i

    # test timing of calls
    mw = MonoWorker()
    wall = tqdm_auto(total=10, desc="wall")
    for i in range(10):
        wall.update()
        sleep(0.1)
        mw.submit(callback, i)
    wall.close()

    # test that multiple threads are not running at the same time
    mw = MonoWorker()
    wall = tqdm_auto(total=10, desc="wall")
    for i in range(10):
        wall.update()
        sleep(0.1)
        mw.submit(callback, i)

# Generated at 2022-06-12 15:00:52.030913
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test method submit of class MonoWorker"""
    from time import sleep
    from random import random
    from itertools import repeat
    from tqdm import tqdm

    def func(n_secs):
        sleep(n_secs)
        return n_secs

    tqdm.write("TESTING {}".format(test_MonoWorker_submit.__name__))
    # check no problem with one task
    worker = MonoWorker()
    future = worker.submit(func, 1)
    tqdm.write("Task submitted")
    future.result()
    tqdm.write("Task finished")
    # check that queued task get's cancelled
    future = worker.submit(func, 1)
    future_queued = worker.submit(func, 1)

# Generated at 2022-06-12 15:01:00.378937
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import _term_move_up
    from ..auto import trange
    from time import sleep, time
    from concurrent.futures import Future
    start = time()

    def func1(sleep_time=0.05, total=10):
        return sum(x for x in trange(total, desc='1', position=1,
                                     leave=True, mininterval=0.01))

    def func2(sleep_time=0.2, total=50):
        return sum(x for x in trange(total, desc='2', position=2,
                                     leave=True, mininterval=0.01))

    def time_limit():
        while True:
            sleep(0.01)
            if time() - start > 1:
                break

    worker = MonoWorker()

    # Ensure that

# Generated at 2022-06-12 15:01:12.796727
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .mono_worker import MonoWorker
    from threading import Event
    from time import sleep, time

    ev = Event()
    f_list = []

    test_func = lambda x: (sleep(1), x, ev.set())[-1]
    mw = MonoWorker()
    t0 = time()

    # Run
    f_list.append(mw.submit(test_func, 'a'))
    ev.wait()

    # No new task, delay will be zero
    f_list.append(mw.submit(test_func, 'a'))
    ev.clear()
    assert not ev.is_set()
    assert len(f_list) == 2
    assert f_list[1].done() and f_list[1].result() == 'a'

# Generated at 2022-06-12 15:01:23.846776
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    m = MonoWorker()
    assert len(m.futures) == 0
    assert m.futures.maxlen == 2
    m.submit(tqdm_auto.sleep, 0.01, x=2)
    assert len(m.futures) == 1
    running = m.futures[0]
    assert not running.done()
    m.submit(tqdm_auto.sleep, 0.01, x=1)
    assert len(m.futures) == 1
    assert m.futures[0] is running
    m.submit(tqdm_auto.sleep, 0.01, x=0)
    assert len(m.futures) == 2
    assert m.futures[0].done()  # discarded

# Generated at 2022-06-12 15:01:31.783585
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(x, a=1, b=2, c=3):
        for i in range(a):
            for j in range(b):
                for k in range(c):
                    time.sleep(x)
        return x

    m = MonoWorker()
    from itertools import product

    for a, b, c in product(range(3), range(3), range(3)):
        for x in 'abcde':
            t = m.submit(f, x, a=a, b=b, c=c)
            assert t.result() == x

# Generated at 2022-06-12 15:01:36.920002
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, random
    from .threaded_utils import MonoWorker

    random.seed(42)
    to_process = [n for n in range(10)]

    def rsleep(n, n_max=10):
        time.sleep(random.random() * n_max)
        return n  # return something so that the future is not discarded

    mw = MonoWorker()
    for n in to_process:
        mw.submit(rsleep, n, n_max=n)


# Generated at 2022-06-12 15:01:42.516798
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    import sys
    from six.moves import StringIO

    def worker(work_id, sleep_time=0.001):
        import threading
        from time import sleep
        from os import getpid
        from .prange import pbar
        with pbar(total=1000, desc='Work {} in Process {}'.format(work_id, getpid())) as pb:
            for x in range(1000):
                sleep(sleep_time)
                pb.update(1)

    mw = MonoWorker()
    threads = []

    # Unit test for MonoWorker.submit
    # Use a string buffer to catch output
    # Catch output on both stdout and stderr with the same buffer
    out = StringIO()
    sys.stderr = out
    sys

# Generated at 2022-06-12 15:01:47.136837
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .tests_tqdm import TestTqdm
    import time
    import re

    with TestTqdm() as t:
        mono_worker = MonoWorker()

        def func(arg):
            time.sleep(0.1)
            return arg

        def func_fail(arg):
            raise Exception('An exception')

        # No exception
        mono_worker.submit(func, 1)
        mono_worker.submit(func, 2)
        assert mono_worker.futures[1].result() == 2, "Wrong result"

        # Second submit failed (1st not done)
        mono_worker.submit(func_fail, 3)
        assert mono_worker.futures[0].exception() is not None

# Generated at 2022-06-12 15:01:53.614231
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    mw.submit(time.sleep, 0.2)
    mw.submit(time.sleep, 0.1)
    mw.submit(time.sleep, 0.3)
    mw.submit(time.sleep, 0.05)
    mw.submit(time.sleep, 0.15)
    mw.submit(time.sleep, 0.1)
    mw.submit(time.sleep, 0.1)
    mw.submit(time.sleep, 0.1)
    mw.submit(time.sleep, 0.1)
    mw.submit(time.sleep, 0.1)

# Generated at 2022-06-12 15:02:02.230116
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import time

    mw = MonoWorker()
    vals = []

    def foo():
        tqdm_auto.write('foo started')
        time.sleep(0.1)
        vals.append('foo finished')
        tqdm_auto.write('foo finished')
        return 'foo finished'

    def bar():
        tqdm_auto.write('bar started')
        time.sleep(0.1)
        vals.append('bar finished')
        tqdm_auto.write('bar finished')
        return 'bar finished'

    def baz():
        tqdm_auto.write('baz started')
        time.sleep(0.1)
        vals.append('baz finished')
        tqdm_auto.write('baz finished')
        return 'baz finished'

# Generated at 2022-06-12 15:02:04.791094
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def delay(t=1):
        time.sleep(t)
        return True

    worker = MonoWorker()
    assert worker.submit(delay, 1).result()
    assert worker.submit(delay, 1).result()
    assert worker.submit(delay, 1).result()
    assert worker.submit(delay, 1).result()

# Generated at 2022-06-12 15:02:10.615373
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def f(x):
        print("running: {}".format(x))
        threading.Timer(1, lambda x=x: print("finished: {}".format(x))).start()
        time.sleep(2)

    mw = MonoWorker()
    for t in range(4):
        mw.submit(f, t)
        time.sleep(.5)

# Generated at 2022-06-12 15:02:27.512086
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random as rd
    from itertools import chain
    from tqdm import trange

    # unit test setup
    random_delay = lambda seed: time.sleep(rd.random() * seed + 0.5)
    get_seed = lambda future: future.args[0]

    # unit test implementation
    def run_test(test_seed, sleep_seed, test_max_len, qty):
        tqdm_auto.write("\n{}".format(test_seed))
        worker = MonoWorker()
        queue = deque([], test_max_len)
        for _ in trange(qty):
            seed = rd.random() * sleep_seed
            future = worker.submit(random_delay, seed)
            queue.append(seed)

# Generated at 2022-06-12 15:02:30.713460
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    for i in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]:
        tqdm_auto.write('submit %d' % i)
        mw.submit(time.sleep, 0.1)
    tqdm_auto.write('submit done')

# Generated at 2022-06-12 15:02:41.528062
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import cpu_count
    from time import sleep
    from pickle import dumps, loads

    NUM_CPU = cpu_count()
    _TEST_DATA = {i: i for i in range(NUM_CPU)}

    def worker(i):
        sleep(i)
        return dumps(i)

    def done(future):
        assert future.result() == dumps(i)

    def cancelled(future):
        assert future.cancelled()

    mw = MonoWorker()
    for i in _TEST_DATA:
        mw.submit(worker, i).add_done_callback(done)
    for i in range(NUM_CPU):
        assert mw.futures[i].result() == dumps(i)
    # Now ensure that works that take longer than NUM_CPU * MAX_INT_

# Generated at 2022-06-12 15:02:49.577186
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 15:03:00.421324
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import active_count

    def fn(n, output=False):
        time.sleep(n)
        if output:
            print('slept {}s'.format(n))
        return n

    # should terminate in about 1s and output 'slept 1s',
    # no matter which of the following commented lines you uncomment,
    # because tqdm_auto.write and print have race conditions
    n = 10
    mw = MonoWorker()
    t0 = time.time()
    for _ in range(n):
        mw.submit(fn, 1, output=True)
    # for _ in range(n):
    #     mw.submit(fn, 1)
    # for _ in range(n):
    #     mw.submit(fn, 1, output=tqdm

# Generated at 2022-06-12 15:03:08.355399
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    This test is not a full coverage unit test, as it only covers
    some of the possible tasks/cancellation orders (which are listed in
    the comments below).
    """
    import time
    import threading
    mworker = MonoWorker()

    def long_run(t):
        time.sleep(t)
        return time.time(), t

    def test_thread(ms, i_iter, i, n_iter, n, expected_runtimes, expected_output):
        # Submit tasks
        for i_iter in range(n_iter):
            for i in range(n):
                t = mworker.submit(long_run, ms * i)
        # Sleep to ensure all submitted
        time.sleep(ms * 0.01)
        # Cancel waiting tasks with max delay `ms * 0.1`

# Generated at 2022-06-12 15:03:16.653200
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # The worker only supports one running task and one waiting task,
    # so the first task should be finished before the second one starts.
    worker = MonoWorker()
    tqdm_auto.write('--- Test waiting, then running ---')
    task1 = worker.submit(tqdm_auto.sleep, 1)
    task2 = worker.submit(tqdm_auto.sleep, 1)
    assert task1.done()
    task2.result()
    tqdm_auto.write('--- Test running, then waiting ---')
    task1 = worker.submit(tqdm_auto.sleep, 1)
    task2 = worker.submit(tqdm_auto.sleep, 1)
    task2.result()
    assert task1.done()

# Generated at 2022-06-12 15:03:24.308612
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import traceback

    def test_func(timeout):
        time.sleep(timeout)

    def test_case(timeout1, timeout2):
        with tqdm(total=2) as t:
            a = 1  # noqa
            t.update()   # 1
            mw = MonoWorker()
            ret = mw.submit(test_func, timeout1)
            a = 2  # noqa
            t.update()   # 2
            try:
                ret = mw.submit(test_func, timeout2)
                a = 3  # noqa
            except Exception as e:
                if "future already done" in str(e):
                    traceback.print_exc()

    test_case(1, 2)
    # test_case(2, 1)

# Generated at 2022-06-12 15:03:31.451375
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    from .utils import test_cls_docstr

    cls = MonoWorker
    test_cls_docstr(cls)

    def print_time(*args, **kwargs):
        tqdm_auto.write(time.time())
        time.sleep(5)

    mw = cls()
    # Run three tasks so that the first is replaced
    mw.submit(print_time)
    time.sleep(random.random())
    mw.submit(print_time)
    time.sleep(random.random())
    mw.submit(print_time)
    time.sleep(random.random())

    # Wait until all tasks are finished
    for future in mw.futures:
        future.result()

# Generated at 2022-06-12 15:03:40.384747
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # import sys
    import time

    def f(x, t):
        time.sleep(t)
        return t + x

    def g(x, t):
        time.sleep(t)
        return t - x

    def h(x, t):
        time.sleep(t)
        return t * x

    a = MonoWorker()
    assert a.submit(f, 1, 3).result() == 4
    assert a.submit(f, 2, 2).result() == 4
    assert a.submit(f, 3, 1).result() == 4
    assert a.submit(g, 1, 3).result() == 2
    assert a.submit(g, 2, 2).result() == 0
    assert a.submit(h, 1, 5).result() == 5

# Generated at 2022-06-12 15:04:01.854280
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Tests `submit` method of class `MonoWorker`."""
    import time

    def sleeper(n):
        """Sleep `n` seconds."""
        time.sleep(n)
        return n

    worker = MonoWorker()
    worker.submit(sleeper, 0.1)
    worker.submit(sleeper, 0.5)
    worker.submit(sleeper, 0.1)
    worker.submit(sleeper, 0.5)
    worker.submit(sleeper, 0.1)

    time.sleep(1.0)

    assert len(worker.futures) == 1
    assert worker.futures[0].result() == 0.5

# Generated at 2022-06-12 15:04:08.784842
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test for `MonoWorker`"""
    import time

    class Test_func(object):
        """A function for test purposes"""
        def __init__(self, sleep=0.01):
            """Construct the function to be tested"""
            self.sleep = sleep
            self.call = ""

        def __call__(self, *args, **kwargs):
            """Execute the function"""
            time.sleep(self.sleep)
            self.call = "func(*{}, **{})".format(args, kwargs)

    mw = MonoWorker()
    func = Test_func(sleep=1)

    assert not func.call

    # submit func for the first time
    assert mw.submit(func, 1, 2, k=3)
    time.sleep(0)  # wait for func to execute

# Generated at 2022-06-12 15:04:19.202272
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    worker = MonoWorker()
    is_failed = False
    expected_sequence_first = [0, 1, 2]
    expected_sequence_second = [5, 6]
    output_sequence = []
    def run(arg):
        time.sleep(arg)
        output_sequence.append(arg)

    worker.submit(run, 0)
    worker.submit(run, 1)
    worker.submit(run, 2)
    worker.submit(run, 3)
    worker.submit(run, 4)
    worker.submit(run, 5)
    worker.submit(run, 6)
    for _ in output_sequence:
        time.sleep(1)
    expected_sequence = expected_sequence_first + expected_sequence_second

# Generated at 2022-06-12 15:04:25.618871
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def f(x):
        sleep(2)
        return x * 2

    mw = MonoWorker()
    assert mw.futures == deque()
    mw.submit(f, 2)
    assert mw.futures == deque([mw.pool._threads[0].get_future()])
    mw.submit(f, 3)
    assert len(mw.futures) == 1
    mw.submit(f, 4)
    assert mw.futures[0].result() == 8



# Generated at 2022-06-12 15:04:34.121105
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def test_func(delay):
        sleep(delay)
        return delay

    worker = MonoWorker()
    worker.submit(test_func, 2)
    worker.submit(test_func, 2)
    worker.submit(test_func, 2)
    worker.submit(test_func, 1)
    worker.submit(test_func, 3)
    worker.submit(test_func, 2)
    worker.submit(test_func, 1)
    worker.submit(test_func, 1)
    worker.submit(test_func, 1)


if __name__ == '__main__':
    from tqdm.contrib import test_MonoWorker_submit
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:04:42.352952
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    stopper = Event()

    class Sleeper(object):

        def __init__(self):
            self.stop_flag = False

        def __call__(self):
            while self.stop_flag:
                sleep(0.1)

        def terminate(self):
            self.stop_flag = False

    sleeper = Sleeper()
    worker = MonoWorker()
    f1 = worker.submit(sleeper)
    f2 = worker.submit(lambda: 1 + 1)
    assert not f1.done() and f2.done()
    sleeper.terminate()

    def wait_for_event():
        print("wait for stopper")
        stopper.wait()
        print("stopper called")


# Generated at 2022-06-12 15:04:45.638663
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def add(a, b):
        return a + b

    mono_worker = MonoWorker()
    assert mono_worker.submit(add, 2, 3).result() == 5
    assert mono_worker.submit(add, 3, 4).result() == 7
    assert mono_worker.submit(add, 4, 5).result() == 9

# Generated at 2022-06-12 15:04:51.974946
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    class Foo(object):
        def bar(self, sleep_, return_):
            sleep(sleep_)
            return return_

    foo = Foo()
    mono = MonoWorker()

    assert mono.submit(foo.bar, .01, 1).result() == 1
    assert mono.submit(foo.bar, .02, 2).result() == 2  # takes the longest
    assert mono.submit(foo.bar, .01, 3).result() == 2  # takes the longest
    assert mono.submit(foo.bar, .02, 4).result() == 4  # takes the longest



# Generated at 2022-06-12 15:04:58.800083
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    try:
        # Python 2.x
        xrange, ansi_cols = xrange, 75
    except NameError:
        # Python 3.x
        from decorator import decorate
        xrange, ansi_cols = range, 76
        decorate = decorate(decorate)

    @decorate
    def f(i, k):
        time.sleep(k)
        return i

    mw = MonoWorker()

    # submit a task
    t0 = time.time()
    for i in xrange(4):
        mw.submit(f, i, 1)
    assert time.time() - t0 < 2  # the first task is actually running
    t0 = time.time()
    mw.submit(f, 4, 1)
    assert time.time() - t

# Generated at 2022-06-12 15:05:04.517958
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from heapq import nlargest

    def execute(seconds, pid_str):
        """Sleep for `seconds` seconds, print pid."""
        sleep(seconds)
        tqdm_auto.write(pid_str)
        return pid_str

    duration = 2
    # generate tasks for this duration
    tasks = [(random(), execute) for _ in range(10 * duration)]
    # simulate some exceptions
    tasks[-1] = (0.1, execute, 1 / 0, str(len(tasks) + 1))  # do not clear waiting
    tasks.append((1.1, execute, 1 / 0, str(len(tasks) + 1)))  # clear waiting

    class Args(object):
        """Hold arguments."""
        def __init__(self):
            self

# Generated at 2022-06-12 15:05:55.279216
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import inspect
    import traceback

    def slow_sum(*args):
        sleep(0.5)
        return sum(args)

    def fast_sum(*args):
        sleep(0.1)
        return sum(args)

    def slow_sum_exception(*args):
        sleep(0.5)
        raise Exception("error")

    def slow_sum_exception_2(*args):
        sleep(0.5)
        raise Exception("error")

    def fast_sum_exception(*args):
        sleep(0.1)
        raise Exception("error")

    def fast_sum_exception_2(*args):
        sleep(0.1)
        raise Exception("error")

    def fast_sum_exception_3(*args):
        sleep(0.1)
        raise

# Generated at 2022-06-12 15:06:06.053093
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from tornado import gen
    import tornado.ioloop
    evt = Event()
    evt.set()
    def bar():
        evt.wait()
        while True:
            time.sleep(1)
        return 'bar'
    @gen.coroutine
    def foo():
        yield gen.sleep(0.5)
        return 'foo'

    worker = MonoWorker()
    assert worker.submit(bar)
    future = worker.submit(foo)
    future.add_done_callback(lambda fut: evt.set())

    start = time.time()
    tornado.ioloop.IOLoop.current().run_sync(future.result)
    end = time.time()
    assert future.result() == 'foo'
    assert end - start < 0.

# Generated at 2022-06-12 15:06:13.192671
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time as sleep
    from concurrent.futures import TimeoutError
    from ..utils import write
    write('test_MonoWorker_submit')
    def test_func(*args, **kwargs):
        sleep(kwargs.get('delay', 0.1))
        return 'args={}, kwargs={}'.format(args, kwargs)
    mw = MonoWorker()
    try:
        mw.submit('a', 'b')
        assert False, 'should fail'
    except Exception:
        pass
    assert mw.futures == deque([])
    # submit first task
    fut1 = mw.submit(test_func, 'a', 'b', delay=0.5)
    assert mw.futures == deque([fut1])
    # submit many tasks
   

# Generated at 2022-06-12 15:06:22.112358
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def sleep_func(sleep_time):
        return time.sleep(sleep_time)

    mono_worker = MonoWorker()

    future1 = mono_worker.submit(sleep_func, 1)
    future2 = mono_worker.submit(sleep_func, 1)
    assert len(mono_worker.futures) == 1
    assert not future1.done() and not future2.done()
    future1.result()  # wait for first task to finish
    assert future2.done()  # ensure that the second task is discarded

    future1 = mono_worker.submit(sleep_func, 1)
    future2 = mono_worker.submit(sleep_func, 2)
    assert len(mono_worker.futures) == 1
    assert not future1.done() and not future2.done()

# Generated at 2022-06-12 15:06:29.813624
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test `MonoWorker` class."""
    import time
    s = MonoWorker()

    def wait_then_print(i):
        time.sleep(.07)
        print(i)
        return i

    def wait_then_raise():
        time.sleep(.01)
        raise ValueError('fail')

    def wait_then_cancel():
        time.sleep(.01)
        s.futures[-1].cancel()
        raise Exception('cancelled')
    # test no discard
    print('no discard:')
    for i in tqdm_auto.tqdm(range(4), desc='no discard'):
        s.submit(wait_then_print, i)
        time.sleep(0.05)

    # test first discard
    print('first discard:')

# Generated at 2022-06-12 15:06:39.629617
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""

    import time
    import sys
    import os

    import tqdm

    def worker():
        time.sleep(1)

    with tqdm.tqdm(desc="MonoWorker_submit", total=3) as main_tqdm:
        def update(**kwargs):
            main_tqdm.update()

        MonoWorker_submit = MonoWorker()

        for _ in range(4):
            future = MonoWorker_submit.submit(worker)

# Generated at 2022-06-12 15:06:45.663110
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from Queue import Queue, Empty

    q = Queue()
    mw = MonoWorker()
    for _ in range(4):
        mw.submit(q.put, _)
    for _ in range(4):
        assert q.get() == _
    assert q.qsize() == 0

    def subtest_workers(n, limit):
        q = Queue()
        mw = MonoWorker()
        futures = []
        res = []
        def put_n_wait(n, t):
            time.sleep(t)
            q.put(n)
        for i in range(n):
            f = mw.submit(put_n_wait, i, 1)
            futures.append(f)

# Generated at 2022-06-12 15:06:52.768657
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import queue

    def time_ncalls(ncalls, sleep=0.05):
        """Returns time and number of calls"""
        def inner():
            for i in range(ncalls):
                time.sleep(sleep)
                yield
        return time, inner

    # Start a worker with 1 task running and 1 waiting
    worker = MonoWorker()
    worker.submit(*time_ncalls(10))
    t, inner = time_ncalls(1)
    waiting = worker.submit(t, inner, sleep=0.01)

    # Submit should replace waiting with new task
    t, inner = time_ncalls(10)
    waiting2 = worker.submit(t, inner)

    # Ensure waiting2 is the only waiting task
    assert waiting.done()
    assert not waiting2.done()
    # Wait for

# Generated at 2022-06-12 15:06:58.393797
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed

    class Foo(object):
        def __init__(self, x):
            self.x = x
            self.results = {}

        def __call__(self, key):
            time.sleep(0)
            if key in self.results:
                raise AssertionError("must not be called twice with same key")
            self.results[key] = self.x
            return key

    foo = Foo("foo")
    mw = MonoWorker()

    def submit(*args):
        return mw.submit(foo, *args)

    f1 = submit("f1")
    f2 = submit("f2")
    f3 = submit("f3")
    f4 = submit("f4")
    f5 = submit("f5")


# Generated at 2022-06-12 15:07:03.673679
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from os import environ
    from unittest import TestCase
    from sys import stdout

    class UnitTest(TestCase):
        def setUp(self):
            environ['TQDM_UNIT_TEST_STDOUT'] = 'tqdm_unit_test_stdout.txt'
            self.stdout = open('tqdm_unit_test_stdout.txt', 'w')
            self.owd = environ['TQDM_UNIT_TEST_STDOUT']
            stdout.write = self.stdout.write

        def tearDown(self):
            environ['TQDM_UNIT_TEST_STDOUT'] = self.owd
            self.stdout.close()

        def test_submit(self):
            def foo(*args, **kwargs):
                sleep