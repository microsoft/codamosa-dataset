

# Generated at 2022-06-12 14:58:18.980189
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed
    from ..std import time as time_std

    def countdown3():
        time_std.sleep(3)
        return '3 seconds'

    def countdown1():
        time_std.sleep(1)
        return '1 second'

    mw = MonoWorker()
    mw.submit(countdown3)
    mw.submit(countdown1)
    mw.submit(countdown1)
    mw.submit(countdown1)
    assert len(mw.futures) == 2
    for future in as_completed(mw.futures):
        try:
            result = future.result()
        except Exception as e:
            tqdm_auto.write(str(e))
        else:
            tqdm

# Generated at 2022-06-12 14:58:29.078580
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..auto import trange
    from multiprocessing import cpu_count
    from time import sleep

    def time_sleep(t):
        sleep(t)
        return t

    def test_func(*args, **kwargs):
        assert args == (1, 2, 3)
        assert kwargs == {"a": 1, "b": 2, "c": 3}

    mw = MonoWorker()
    mw.submit(test_func, 1, 2, 3, a=1, b=2, c=3)

    def sum_nums(*args, **kwargs):
        return sum(args) + sum(kwargs.values())

    mw = MonoWorker()

# Generated at 2022-06-12 14:58:35.571487
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def test_func(a, b=1):
        return a + b
    tqdm_auto.write("Testing MonoWorker with test_func({}, {})".format(1, 1))
    mw = MonoWorker()
    x0 = mw.submit(test_func, 1, 1)
    x1 = mw.submit(test_func, 2, 2)
    assert x0.result() == 2
    assert x1.result() == 4
    x2 = mw.submit(test_func, 3, b=3)
    assert x2.result() == 6

# Generated at 2022-06-12 14:58:44.696447
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    class CountingThreadPoolExecutor(ThreadPoolExecutor):
        def __init__(self, *args, **kwargs):
            super(CountingThreadPoolExecutor, self).__init__(*args, **kwargs)
            self.count = 0

        def submit(self, *args, **kwargs):
            self.count += 1
            return super(CountingThreadPoolExecutor, self).submit(*args, **kwargs)

    def exe(*args, **kwargs):
        time.sleep(1)
        return args, kwargs

    def wai(*args, **kwargs):
        time.sleep(3)
        return args, kwargs

    p = CountingThreadPoolExecutor(max_workers=1)
    m = MonoWorker()
    m.pool = p

# Generated at 2022-06-12 14:58:50.610040
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .._utils import _term_move_up
    from ..utils import _range

    class FakeTqdmFile(object):
        file = None

        @staticmethod
        def write(s):
            print(s, end="")

        @staticmethod
        def flush():
            pass

    def func(t):
        time.sleep(t)
        if t >= 10:
            raise ValueError("bad sleep %s" % t)
        return t

    class MonitoredWorker(MonoWorker):
        pbar = None

        @property
        def total(self):
            return len(self.futures)

        @property
        def completed(self):
            return sum(f.done() for f in self.futures)

    mw = MonitoredWorker()


# Generated at 2022-06-12 14:58:56.490808
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def sleep_then_return(x):
        sleep(0.1)
        return x

    mw = MonoWorker()
    futures = []
    for i in range(10):
        futures.append(mw.submit(sleep_then_return, i))
    for f in futures:
        assert f.result() == 9


if __name__ == '__main__':
    from time import sleep
    test_MonoWorker_submit()

# Generated at 2022-06-12 14:59:02.504384
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, queue
    _ = tqdm_auto.write
    q = queue.Queue()
    mw = MonoWorker()
    assert mw.submit(lambda: q.put(1)) is not None, \
        "Nothing returned by MonoWorker.submit()"
    assert mw.submit(lambda: q.put(2)) is not None, \
        "Nothing returned by MonoWorker.submit()"
    time.sleep(0.01)
    assert q.get() == 2, \
        "MonoWorker.submit() did not replace running task with waiting task"
    _("test_MonoWorker_submit() passed")

# Generated at 2022-06-12 14:59:11.347486
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    worker = MonoWorker()

    def noop(delay, *args, **kwargs):  # pylint: disable=unused-argument
        time.sleep(delay)
    t0 = time.time()
    worker.submit(noop, 1)
    worker.submit(noop, 2)
    t1 = time.time()
    # Should be called with delay=2
    tqdm_auto.write("Took {0:.3f}s to execute 2 second task.".format(t1 - t0))

# Generated at 2022-06-12 14:59:17.367123
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> import time, threading
    >>> def wait(seconds):
    ...     time.sleep(seconds)
    ...     return seconds
    >>> worker = MonoWorker()
    >>> worker.submit(wait, 10)
    <Future at 0x... state=running>
    >>> worker.submit(wait, 5)
    >>> worker.submit(wait, -1)
    >>> worker.submit(wait, 5)
    <Future at 0x... state=running>
    >>> worker.submit(wait, 1)
    >>> worker.submit(wait, -1)
    >>> worker.submit(wait, 3)
    <Future at 0x... state=running>
    """
    pass

# Generated at 2022-06-12 14:59:27.168874
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test the MonoWorker submit method.
    """
    def func_print(string):
        """
        Print a given string.
        """
        tqdm_auto.write(string)

    test_string = "testing string"
    mono = MonoWorker()
    result = mono.submit(func_print, test_string)
    # Check that submit returns a future value
    assert result is not None
    result.result()
    # Check that submit can replace a previous future
    result_1 = mono.submit(func_print, test_string)
    assert result_1 is not None
    result_1.result()
    result_2 = mono.submit(func_print, test_string)
    assert result_2 is not None
    result_2.result()
    # Check that submit has the right behavior of passing

# Generated at 2022-06-12 14:59:41.967865
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures
    from time import sleep
    from ..utils import format_sizeof, B

    def error_func():
        raise ValueError("Error")

    def sleep_func(t=1):
        sleep(t)
        return t

    mw = MonoWorker()

    # Submit a jobs that raise an exception
    assert mw.submit(error_func) == mw.futures[0]
    assert str(mw.futures[0].exception()) == "Error"
    assert mw.futures[0].done() is True

    # Submit several jobs that raises an exception and check that
    # only the last exception is kept
    assert mw.submit(error_func) == mw.futures[0]

# Generated at 2022-06-12 14:59:52.800374
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import pytest

    class Counting(object):
        def __init__(self):
            self.n = 0

        def incr(self):
            self.n += 1
            return self.n

    counting = Counting()

    worker = MonoWorker()

    # submit
    f1 = worker.submit(counting.incr)
    assert f1.running()
    assert len(worker.futures) == 1
    assert f1.result() == 1
    time.sleep(0.1)  # give time for the worker to complete `f1`
    assert len(worker.futures) == 0
    assert not f1.done()

    # submit and discard waiting
    f1 = worker.submit(counting.incr)
    time.sleep(0.1)  # give time

# Generated at 2022-06-12 15:00:02.292966
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from multiprocessing import Queue
    r = Queue(maxsize=1)
    m = MonoWorker()

    def func(*args, **kwargs):
        # print("doing", args, kwargs)
        time.sleep(2)
        r.put(args[0])
        # print("done", args, kwargs)

    assert m.submit(func, 1) is not None
    assert m.submit(func, 2) is not None
    assert m.submit(func, 3) is not None
    # print(r.get())
    assert r.get() == 2  # 1 is discarded, 2 & 3 are both submitted and
                         # waiting, so 2 is the only one running
    # print(r.get())
    assert r.get() == 3  # 3

# Generated at 2022-06-12 15:00:09.448624
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=undefined-variable
    from time import sleep
    from random import random
    from asynctest import TestCase, CoroutineMock, Mock, patch
    from asynctest.mock import call
    mock_sleep_random = Mock()
    mock_sleep_random.side_effect = [random()]
    m_sleep_random = patch('time.sleep', mock_sleep_random)
    m_write = patch('tqdm.auto.tqdm.write', CoroutineMock())
    # m_is_coroutine = patch('tqdm.auto.tqdm.is_coroutine', CoroutineMock())


# Generated at 2022-06-12 15:00:15.108199
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import wait
    from .utils import process_map
    from .utils import exception_stub
    import random
    import time

    sleep = random.randint(1, 5)
    max_workers = 1
    args = list(range(10))
    processed = []

    worker = MonoWorker()

    try:
        worker.submit(exception_stub)
    except ValueError:
        pass
    else:
        raise AssertionError("Exception not thrown by exception_stub()")

    def append_to_processed(arg):
        start = time.time()
        while time.time() - start < sleep:
            pass
        processed.append(arg)

    futures = []

# Generated at 2022-06-12 15:00:21.700947
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def work(sec):
        time.sleep(sec)
        return sec

    monoworker = MonoWorker()
    futures = []
    with tqdm_auto.trange(10) as t:
        for i in t:
            # randomly decide whether to cancel
            if random.random() > 0.3:
                # submit a task
                future = monoworker.submit(work, random.random() * 5)
                futures.append(future)
            else:
                # try to cancel a task
                if futures:
                    futures.pop().cancel()
    print()

# Generated at 2022-06-12 15:00:31.906239
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    import os
    import sys

    class Test(MonoWorker):
        def func(self, i):
            """sleep"""
            # Should not be called twice for the same i
            assert self.cur == i - 1 or self.cur == i
            self.cur = i

            # May be cancelled
            if random() < .5:
                raise ValueError("Cancelled")

            # Will sleep between 0 and 1 second
            sleep(0.2 * random())
            assert self.futures[0].done()  # will be clean by then

    test = Test()
    for i in range(10):
        test.submit(test.func, i)

    # Test cancellation

# Generated at 2022-06-12 15:00:39.015766
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func_1():
        print("Task 1 running")
        time.sleep(1)
        print("Task 1 done")

    def func_2():
        print("Task 2 running")
        time.sleep(1)
        print("Task 2 done")

    def func_3():
        print("Task 3 running")
        time.sleep(1)
        print("Task 3 done")

    def func_4(x):
        print("Task 4 running")
        time.sleep(1)
        print("Task 4 done")
        return x

    def func_5(x):
        print("Task 5 running")
        time.sleep(1)
        print("Task 5 done")
        return x

    class Obj:
        def __init__(self):
            self.state = 0


# Generated at 2022-06-12 15:00:45.162068
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    def throw(*args, **kwargs):
        raise ValueError("did not submit")
    worker = MonoWorker()
    assert len(worker.futures) == 0
    assert worker.submit(throw).cancel()
    assert len(worker.futures) == 1
    assert worker.submit(throw).cancel()
    assert len(worker.futures) == 1
    assert worker.submit(throw).cancel()
    assert len(worker.futures) == 1



# Generated at 2022-06-12 15:00:54.803361
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method MonoWorker.submit"""
    from .future import FutureWrapper
    from .util import _nonblocking_read
    from .tqdm import format_interval, StatusPrinter

    def _test(x):
        import time
        time.sleep(x)
        return x

    def _print(s, n, n_fmt, total, desc=None, elapsed=None,
               bar_format=None, rate=None, rate_noinv=None, rate_noinv_fmt=None,
               postfix=None, ascii=None):
        print("\r" + s)

    print("Executing function 0.1s twice")
    with StatusPrinter(_print, disable=True):
        mwrk = MonoWorker()

# Generated at 2022-06-12 15:01:06.651150
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> from time import sleep
    >>> from subprocess import call
    >>> mw = MonoWorker()
    >>> mw.submit(call, ['ls'])  # doctest: +SKIP
    <Future at 0x... state=running>
    >>> mw.submit(sleep, 10)
    >>> mw.submit(call, ['ls'])  # doctest: +SKIP
    <Future at 0x... state=running>
    >>> mw.submit(sleep, 10)
    >>> mw.submit(call, ['ls'])  # doctest: +SKIP
    <Future at 0x... state=running>
    >>> mw.submit(sleep, 10)
    """
    pass

# Generated at 2022-06-12 15:01:08.469550
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(i, j):
        return i + j

    MonoWorker().submit(func, 1, j=2)



# Generated at 2022-06-12 15:01:13.120177
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(x):
        time.sleep(x)  # Blocks if x>0 else returns instantly
        return x+1
    mw = MonoWorker()
    assert [mw.submit(f, 1).result() for _ in range(4)] == [2, 2, 2, 2]
    assert [mw.submit(f, 0).result() for _ in range(4)] == [1, 1, 1, 1]



# Generated at 2022-06-12 15:01:24.144806
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    from time import sleep
    from multiprocessing import cpu_count
    from time import time as now

    num_procs = cpu_count()
    mono = MonoWorker()

    def long_running_func(i, delay=0.1, jit=0.05):
        sleep(delay + random.uniform(-jit, jit))
        return i

    def test_func(num_submits):
        num_submits = int(num_submits)
        results = []

        def submit(i):
            fut = mono.submit(long_running_func, i)
            if fut is not None:
                results.append(fut)

        futures = [submit(i) for i in range(num_submits)]

        while results:
            i = 0

# Generated at 2022-06-12 15:01:34.111002
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys

    def sleeper(sec):
        time.sleep(sec)
        return sec

    mw = MonoWorker()

    res1 = mw.submit(sleeper, 1)
    print(res1.result())

    res2 = mw.submit(sleeper, 2)
    print(res2.result())

    res3 = mw.submit(sleeper, 3)
    print(res3.result())

    res4 = mw.submit(sleeper, 4)
    print(res4.result())

    res5 = mw.submit(sleeper, 5)
    # res5 is discarded since the pool is full
    if hasattr(res5, 'result'):
        print(res5.result())
        sys.exit(1)

    # time.sleep(1)
   

# Generated at 2022-06-12 15:01:40.593098
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    from time import sleep
    from tqdm import trange
    for msg in trange(4):
        mw.submit(sleep, 1.5)
        print(mw.futures[0].result())
        print(msg)
    for msg in trange(4):
        mw.submit(sleep, 0.5)
        print(mw.futures[0].result())
        print(msg)
    for msg in trange(4):
        mw.submit(sleep, 1)
        print(mw.futures[0].result())
        print(msg)
    for msg in trange(4):
        mw.submit(sleep, 2)
        print(mw.futures[0].result())
        print(msg)

# Generated at 2022-06-12 15:01:49.835080
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()

    tqdm_auto.write('1')
    mw.submit(f, 0.5)  # long running
    time.sleep(0.1)
    tqdm_auto.write('2')
    mw.submit(f, 0.5)  # discards waiting
    time.sleep(0.1)
    tqdm_auto.write('3')
    mw.submit(f, 0.5)  # discards running
    time.sleep(0.1)
    tqdm_auto.write('4')
    mw.submit(f, 0.5)  # discards running
    time.sleep(0.1)
    tqdm

# Generated at 2022-06-12 15:01:55.109060
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, threading
    mw = MonoWorker()

    def f(i):
        time.sleep(1)
        print(i)

    # a, b, c, d, e, f, g
    mw.submit(f, "a")
    thr = [threading.Thread(target=mw.submit, args=(f, i)) for i in "bcdefg"]
    for th in thr:
        th.start()
    for th in thr:
        th.join()

# Generated at 2022-06-12 15:02:02.885661
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test whether the right task is being dropped and the right task is being
    # run
    import os
    import time
    import subprocess
    import signal

    def ident(x):
        return x

    def kill(pid):
        os.kill(pid, signal.SIGKILL)

    worker = MonoWorker()
    p = subprocess.Popen(['python', '-c', 'import time; time.sleep(5)'])
    pid = p.pid
    for i in range(4):
        worker.submit(ident, i)
        time.sleep(1)

    time.sleep(0.1)  # give concurrent.futures some time to start the thread
    # kill process
    worker.submit(kill, pid)
    time.sleep(0.1)

# Generated at 2022-06-12 15:02:09.635632
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func(x):
        time.sleep(x)
        return x

    worker = MonoWorker()
    worker.submit(func, 1)  # start running
    time.sleep(0.2)

    # waiting func will be replaced
    futures = []
    futures.append(worker.submit(func, 2))
    time.sleep(0.1)
    futures.append(worker.submit(func, 3))

    # waiting func will be discarded
    futures.append(worker.submit(func, 4))
    for f in futures:
        f.result()

# Generated at 2022-06-12 15:02:23.517535
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import logging
    logging.getLogger('concurrent.futures').setLevel(logging.ERROR)
    logging.getLogger('urllib3').setLevel(logging.ERROR)
    logging.getLogger('requests').setLevel(logging.ERROR)
    from .tqdm_test_cases import pretest_posttest

    def mytask(*args, **kwargs):
        sleep(0.05)

    def test_MonoWorker_submit_lambda(b):
        with pretest_posttest(b, leave=False):
            with MonoWorker() as w:
                b.set_description("Submit tasks")
                f1 = w.submit(mytask)
                f2 = w.submit(mytask)
                b.set_description("Wait for tasks")
               

# Generated at 2022-06-12 15:02:28.372051
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import traceback
    from unittest import TestCase
    from itertools import product

    def fail_after(n):
        time.sleep(n)
        raise Exception("fail_after {}".format(n))

    class TestMonoWorker(TestCase):
        """
        Only the 2 most recently submitted tasks should ever run at the same
        time. This means that the 2nd task submitted might start, while
        the first has not yet finished. But, the 2nd should not finish until
        the 3rd is submitted.
        """
        def setUp(self):
            self.mw = MonoWorker()

        def test_submit(self):
            for i in range(9):
                self.mw.submit(fail_after, i)


# Generated at 2022-06-12 15:02:32.816159
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    mw = MonoWorker()

    # f(x) = x
    def func(x):
        sleep(random())  # simulate asynchronous
        return x

    # Submit 1000, but only one should run at a time
    fs = [mw.submit(func, i) for i in range(1000)]
    assert len(fs) == 1000

    # f.result() == f.args[0]
    for f in fs:
        assert f.result() == f.args[0]



# Generated at 2022-06-12 15:02:42.661058
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from queue import Queue

    from .tests_env import pretest_posttest
    from ..utils import _range

    q = Queue()

    def test_func(a):
        for i in _range(a):
            q.put(i)
            time.sleep(0.1)
        return a

    with pretest_posttest(test_func, q) as (test_func, q):

        def test_runner(args):
            w = MonoWorker()
            prev_val = -1
            for arg in args:
                res = w.submit(test_func, arg)
                while res.running():
                    new_val = q.get()

# Generated at 2022-06-12 15:02:47.219239
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    pool = MonoWorker()

    def foo(*args):
        sleep(0.1)
        return sum(args)
    assert pool.submit(foo, 1, 2).result() == 3
    assert pool.submit(foo, 3, 4).result() == 7

    def bar(*args):
        raise ValueError()
    assert pool.submit(bar) is None


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:02:53.194937
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import sys

    def f(i=0, n=1, file=sys.stdout):
        """
        >>> import time
        >>> test_MonoWorker_submit()
        3
        0
        2
        1
        """
        sleep(0.5)  # ensure all jobs finish
        tqdm_auto.write(i, file=file)
        return i

    with MonoWorker() as m:
        for i, n in enumerate([3, 0, 2, 1]):
            m.submit(f, i, n)


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-12 15:03:04.332215
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # import time
    def add(a, b=2):
        return a + b

    w = MonoWorker()
    f = w.submit(add, 1, b=3)
    assert f.result() == 4

    f_list = []

    f = w.submit(add, 1, b=4)
    assert f.result() == 5

    f = w.submit(add, 2, b=4)
    assert f.result() == 6

    f_list.append(w.submit(add, 3, b=4))
    f_list.append(w.submit(add, 4, b=4))

    # time.sleep(1)

    f = w.submit(add, 5, b=4)
    assert f.result() == 9
    assert f_list[0].result() == 7


# Generated at 2022-06-12 15:03:11.739228
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f1(a):
        time.sleep(.5)
        return sum(a)
    def f2(a):
        time.sleep(.5)
        raise Exception('test exception')
    def f3(a):
        time.sleep(2)
        return sum(a)


# Generated at 2022-06-12 15:03:20.532802
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    # Test only the logic of submit.
    # tqdm has no control over the time taken by a task.
    # Even time.sleep(1) is not precise enough.
    # Hence a task that takes time.sleep(0) is a good compromise.
    def no_op():
        time.sleep(0)
        return 'no-op'

    mw = MonoWorker()

    f1 = mw.submit(no_op)
    f2 = mw.submit(no_op)
    f3 = mw.submit(no_op)
    assert f1.done()
    assert f2.done()
    assert f3.done()
    assert f1.cancelled()
    assert f2.cancelled()
    assert not f3.cancelled()

    f4 = m

# Generated at 2022-06-12 15:03:27.093873
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    worker = MonoWorker()

    def func_worker(arg):
        sleep(0.2)
        return arg

    for i in range(1, 5):
        if len(worker.futures) == worker.futures.maxlen:
            sleep(0.1)  # wait for first future to finish
        assert len(worker.futures) < worker.futures.maxlen
        assert worker.submit(func_worker, i).result() == i

    assert len(worker.futures) == worker.futures.maxlen
    assert worker.submit(func_worker, None).result() == 4

    assert len(worker.futures) == worker.futures.maxlen
    assert not worker.futures[0].done()  # first future should be running
   

# Generated at 2022-06-12 15:03:46.679163
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .tests import _MonoWorker_test_submit
    _MonoWorker_test_submit()

# Generated at 2022-06-12 15:03:55.710016
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def slow_fn(arg):
        time.sleep(.5)
        return arg

    mw = MonoWorker()

    # initial waiting task
    res = mw.submit(slow_fn, 0)
    assert res.result() == 0

    # waiting task cancelled by running task
    res = mw.submit(slow_fn, 1)
    res = mw.submit(slow_fn, 2)  # also take .5s
    assert res.result() == 2

    # running task completes, then waiting task completes
    res = mw.submit(slow_fn, 3)
    res = mw.submit(slow_fn, 4)  # also take .5s
    assert res.result() == 4

    # waiting task completes, then running task completes

# Generated at 2022-06-12 15:04:04.126944
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..tqdm_gui import tqdm

    def f(i):
        for _ in tqdm(range(10)):
            sleep(.1)

    from multiprocessing import Pool
    p = Pool(3)
    mw = MonoWorker()
    for i in range(4):
        tqdm_auto.write("round {}".format(i))
        assert len(mw.futures) < 2
        mw.submit(p.apply_async, f, args=(i,))
    sleep(2)
    assert [f.done() for f in mw.futures] == [False, True]
    while not mw.futures[0].done():
        sleep(.1)
    mw.futures.popleft()


# Generated at 2022-06-12 15:04:14.959265
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import CancelledError
    import pytest
    _test_MonoWorker_submit.counter = 0 # pylint: disable=attribute-defined-outside-init

    class _test_MonoWorker_submit(object):
        """
        Supports one running task and one waiting task.
        The waiting task is the most recent submitted (others are discarded).
        """
        def __init__(self):
            self.pool = ThreadPoolExecutor(max_workers=1)
            self.futures = deque([], 2)

        @staticmethod
        def _assert_equal(future, result):
            assert future.result() == result
            with pytest.raises(CancelledError):
                future.cancel()


# Generated at 2022-06-12 15:04:24.736999
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import queue

    def func(a, b):
        return a + b

    def func_exception(a, b):
        raise Exception

    def func_blocking(a, b):
        time.sleep(4)
        return a + b

    def test_thread(q, w, e, t, func, *args, **kwargs):
        res = q.get()
        assert res is True
        w.wait()
        try:
            assert not e.isSet()
            res = func(*args, **kwargs)
            q.put(True)
            q.put(res)
        except Exception as exc:
            q.put(False)
            q.put(exc)
        t.wait()

    q = queue.Queue(maxsize=2)

# Generated at 2022-06-12 15:04:34.013730
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from numpy.random import randint
    from numpy.testing import assert_allclose
    from collections import Counter

    def worker(dur):
        sleep(dur)
        return dur

    worker = MonoWorker()
    results = []
    with tqdm_auto.tqdm(total=100, smoothing=0, ascii=True) as t:
        for dursec in randint(10, size=100):
            f = worker.submit(worker, dursec)
            if f is not None:
                f.add_done_callback(lambda r:
                                    results.append(r.result()))
            t.update()
    assert_allclose([dursec] * 100, results)
    assert hasattr(t, '_sp')  # sanity check
    assert Counter

# Generated at 2022-06-12 15:04:42.213823
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import time
    from time import sleep

    def func(a, sleep=sleep):
        sleep(a)
        return time()

    mw = MonoWorker()

    # Submit 1st task
    run0 = mw.submit(func, 1)
    assert not run0.done()
    time0 = time()
    assert time0 < run0.result()  # 1st task is running

    # Submit 2nd task
    run1 = mw.submit(func, 2)
    assert not run1.done()
    time1 = time()
    assert time0 < time1 < run1.result()  # 2nd task cancelled 1st task

    # Submit the 3rd task
    run2 = mw.submit(func, 3)
    assert not run2.done()
    time2 = time()
    assert time

# Generated at 2022-06-12 15:04:48.623141
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    worker = MonoWorker()
    # Do nothing
    worker.submit(lambda x: None)
    # Do nothing
    worker.submit(lambda x: None)
    # Do nothing
    worker.submit(lambda x: None)
    # Kill first task
    worker.submit(lambda x: time.sleep(1))
    # Do nothing
    worker.submit(lambda x: None)
    # Do nothing
    worker.submit(lambda x: None)
    # Do nothing
    worker.submit(lambda x: None)
    # Kill second task
    worker.submit(lambda x: time.sleep(1))
    # Do nothing
    worker.submit(lambda x: None)
    # Kill third task
    worker.submit(lambda x: time.sleep(1))
    # Do nothing

# Generated at 2022-06-12 15:04:56.201834
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from os import getpid

    def foo(i):
        for _ in tqdm_auto.tqdm(range(10000), leave=False):
            sleep(.000001)
        return i

    def top_func(i, k):
        print("pid:\t{}".format(getpid()))
        print("k:\t{}".format(k))
        print("i:\t{}".format(i))
        return foo(i)

    print("Testing MonoWorker")
    mw = MonoWorker()
    j = mw.submit(top_func, 1, 'a')
    print("Done submit 1, waiting")
    print("j:\t{}".format(j.result()))
    i = mw.submit(top_func, 2, 'b')
   

# Generated at 2022-06-12 15:04:58.355285
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()

    def dp(i):
        time.sleep(2)
        return i

    for i in range(6):
        mw.submit(dp, i)
        time.sleep(0.5)

# Generated at 2022-06-12 15:05:53.073680
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .format_bytes import autoinf
    from .generate_iteration import generate_iterations

    print('\nTesting MonoWorker submit method')
    print('Generating test data')
    l = 100000
    iterations = list(generate_iterations(l))
    total_iterations = len(iterations)
    print('  Generated {0} iterations ({1})'.format(total_iterations,
                                                    autoinf(iterations)))

    print('Testing MonoWorker submit method')
    print('  Creating MonoWorker with one worker')
    mw = MonoWorker()
    print('  Submitting 1st task')
    future = mw.submit(time.sleep, 0.1)
    print('  Submitting 2nd task')

# Generated at 2022-06-12 15:06:03.191332
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test MonoWorker.submit()."""
    from random import randint
    from time import sleep
    from ..utils import freeze_support

    def myfunc(n):
        if n == 0:
            sleep(1)
        elif n == 1:
            sleep(10)
        elif n == 2:
            sleep(100)
        else:
            sleep(4)
        return n

    mw = MonoWorker()

    def test_it(n, second=False):
        f = mw.submit(myfunc, n)
        while not f.done():
            sleep(0.001)
        assert f.result() == n
        if second:
            assert len(mw.futures) == 2
            assert mw.futures[0].result() == n


# Generated at 2022-06-12 15:06:11.080124
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    from concurrent.futures import Future
    from unittest import TestCase
    from unittest.mock import patch

    class Checker(object):
        def __init__(self):
            self.vals = []

    def func(val, checker):
        time.sleep(random.random())
        checker.vals.append(val)

    class TestMonoWorker(TestCase):
        def test(self):
            checker = Checker()
            mono = MonoWorker()
            n = 10
            for i in range(n):
                mono.submit(func, i, checker)
            for j in range(n):
                time.sleep(0.01)
                self.assertEqual(j, len(checker.vals))

# Generated at 2022-06-12 15:06:15.656330
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from math import sqrt
    from random import random
    from concurrent.futures import FIRST_COMPLETED
    from unittest import TestCase

    TEST_CASES = [
        # (Seed, Number of calls, Number of discarded calls)
        (1, 5, 2),
        (2, 5, 2),
        (3, 5, 3),
        (4, 5, 3),
        (5, 5, 4),
        (6, 5, 4),
        (7, 5, 5),
        (8, 5, 6),
        # it is not possible to have 7
        (9, 5, 7),
        (10, 5, 7),
        # it is not possible to have 8
        (11, 5, 8),
    ]


# Generated at 2022-06-12 15:06:16.481572
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

# Generated at 2022-06-12 15:06:24.069858
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing as mp
    import time

    wait = 0.001

    def f(x):
        time.sleep(wait)
        return x

    worker = MonoWorker()
    assert len(worker.futures) == 0
    assert worker.submit(f, 1) is not None
    assert len(worker.futures) == 1
    assert worker.submit(f, 2) is not None
    assert len(worker.futures) == 2
    assert worker.submit(f, 3) is not None
    assert len(worker.futures) == 2
    assert worker.submit(f, 4) is not None
    assert len(worker.futures) == 2
    assert mp.active_children() == []

# Generated at 2022-06-12 15:06:31.473746
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    # A function which takes time, while waiting for a signal
    def task(name, wait, signal):
        time.sleep(wait)
        signal.wait()
        return name

    # Start of test
    signal = Event()   # Signals all running tasks to exit
    signal.clear()     # Reset the event
    mw = MonoWorker()  # Create a MonoWorker object

    # Start a task
    task1 = mw.submit(task, 'task1', 1, signal)
    time.sleep(0.1)   # Wait a bit
    assert len(mw.futures) == 1
    assert str(mw.futures[0]) != 'task1'
    time.sleep(1)   # Wait until task1 is done

# Generated at 2022-06-12 15:06:38.660391
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func1():
        time.sleep(0.5)
        return 1

    def func2():
        time.sleep(2)
        return 2

    mw = MonoWorker()
    mw.submit(func1)
    mw.submit(func2)

    time.sleep(1)

    f1 = mw.submit(func1)
    f2 = mw.submit(func2)

    assert f1.result() == 1
    assert f2.cancelled()

    assert func2() == 2

# Generated at 2022-06-12 15:06:43.270300
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def test_sleeper(t):
        import time
        time.sleep(t)
        return t

    def check_MonoWorker_submit():
        import random
        random.seed(42)
        mw = MonoWorker()
        t = [random.random() for _ in range(200)]
        for _ in tqdm_auto.tqdm(t, unit="ms", miniters=1, mininterval=0):
            sleep_time = random.choice(t)
            mw.submit(test_sleeper, sleep_time)

    check_MonoWorker_submit()

# Generated at 2022-06-12 15:06:48.199993
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test method MonoWorker.submit."""

    # import time
    import random

    N = 10
    rng = random.Random()

    with tqdm_auto.tqdm(total=N) as pbar:
        def _job(i):
            rng.random()
            pbar.update(1)
            # time.sleep(rng.random() / 10)
            return i

        obj = MonoWorker()
        for i in range(N):
            future = obj.submit(_job, i)
            # print("[{}/{}] future = {}".format(i, N, future))
            future.result()


# Launch unit test
if __name__ == "__main__":
    test_MonoWorker_submit()