

# Generated at 2022-06-12 14:58:14.052891
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import unittest

    class TestMonoWorker(unittest.TestCase):
        def test_submit(self):
            def delay(name, dur):
                time.sleep(dur)
                return name

            mw = MonoWorker()
            name = '123'
            f1 = mw.submit(delay, name, 1)
            self.assertEqual(mw.futures.pop().result(), name)

            mw.submit(delay, '456', .5)
            mw.submit(delay, '789', .1)
            self.assertEqual(mw.futures.pop().result(), '789')

            mw.submit(delay, 'aaa', .1)
            self.assertEqual(mw.futures.pop().result(), 'aaa')


# Generated at 2022-06-12 14:58:21.899572
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Unit tests for method `MonoWorker.submit`.
    """
    import unittest
    import warnings
    from functools import reduce
    import random
    import time
    import concurrent.futures
    from ..auto import tqdm as tqdm_auto

    class TestMonoWorker(unittest.TestCase):
        def test_submit(self):
            """
            Tests `MonoWorker.submit`.
            """
            def _f(x):
                time.sleep(random.random())
                return x

            import itertools
            import tqdm.contrib.concurrency as tqdm_concurrency
            max_workers = 2
            max_tasks_at_once = 2
            mw = tqdm_concurrency.MonoWorker()

            all_nums

# Generated at 2022-06-12 14:58:29.431895
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint:disable=protected-access
    from ..tqdm import trange
    from time import sleep

    def f(x):
        sleep(1)
        return x*x

    mono = MonoWorker()
    with trange(10) as t:
        for i in t:
            future = mono.submit(f, i)
            t.set_description(str(i))
            if future is not None:
                t.set_postfix(result=future.result())
    assert len(mono.futures) == 0
    assert len(mono.pool._threads) == 0
    # pylint:enable=protected-access

# Generated at 2022-06-12 14:58:37.852820
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    from time import sleep
    from threading import Event
    from Queue import Queue, Empty

    q = Queue()

    def func(arg, delay=1):
        # No lock needed, since thread-safe
        q.put(arg)
        sleep(delay)

    def run_test(futures, expected_results):
        """
        Ensure that the expected results are produced by
        the given (non-empty) iterable of futures.
        """
        with ThreadPoolExecutor(max_workers=1) as executor:
            for future in futures:
                executor.submit(future.result)

# Generated at 2022-06-12 14:58:46.286257
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test MonoWorker.submit()'s one-runner/one-waiter guarantee"""
    from math import exp
    from time import sleep
    from .tqdm_test_utils import DiscreteTimer, StringIO

    with DiscreteTimer() as timer:
        m = MonoWorker()

        assert str(m) == '<MonoWorker: (), 0 running, 0 pending>'

        def foo():
            sleep(exp(exp(exp(0.000001))))  # slow function

        # Run a foo() task in another thread
        r = m.submit(foo)
        # Make sure it's running
        assert not r.done()
        assert str(m) == '<MonoWorker: (running), 1 running>'

        # Run another foo() task but that should be ignored
        m.submit(foo)

# Generated at 2022-06-12 14:58:56.941947
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures, time

    def sleep():
        time.sleep(1)
        return '=^.^='

    event = threading.Event()
    def until_set():
        event.wait()
        return ':peace: '

    pool = MonoWorker()
    running = pool.submit(sleep)
    assert len(pool.futures) == 1
    assert not running.done()
    # waiting = pool.submit(until_set)  # continue reading source
    # assert len(pool.futures) == 1
    # assert waiting.done()
    # assert not running.done()
    # assert waiting.result() == ':peace: '
    event.set()  # continue reading source
    assert running.result() == '=^.^='

# Generated at 2022-06-12 14:59:07.479588
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import threading
    from threading import Event

    def writer(*args):
        sys.stdout.write(''.join(args))
        sys.stdout.flush()

    def print_wrapper(msg, sleep=1, end=None):
        writer('[{:08.02f}] print({})'.format(time.time() % 1, msg), end=end)
        time.sleep(sleep)
        writer(end=end)
        time.sleep(1 - sleep)

    def cancel_wrapper(fut, msg, sleep=1, end=None):
        writer('[{:08.02f}] cancel({})'.format(time.time() % 1, msg), end=end)
        fut.cancel()
        time.sleep(sleep)
        writer(end=end)

# Generated at 2022-06-12 14:59:16.517390
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from queue import Queue
    from threading import Thread

    mw = MonoWorker()

    threads = list()
    q = Queue()

    def thread_get_me_the_queue(name, q):
        sleep(3)
        q.put(name)

    for x in range(5):
        name = "Thread-{}".format(x)
        thread = Thread(target=thread_get_me_the_queue, args=(name, q,))
        # thread.daemon = True
        thread.start()
        threads.append(thread)
        mw.submit(thread_get_me_the_queue, name, q)  # submit to MonoWorker

    for thread in threads:
        thread.join()

    print("q.get():")

# Generated at 2022-06-12 14:59:26.675725
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    '''
    test_MonoWorker_submit: Unit test for method submit of class MonoWorker
    '''
    import time
    from threading import current_thread, Event, Thread
    import unittest
    import queue
    import random

    class MonoWorkerTest(unittest.TestCase):
        """
        This class is a unit test for the class MonoWorker
        """

        def test_monoworker_submit(self):
            """
            test_monoworker_submit : This method tests the submission of a
            task
            """
            def _runner(q, e):
                e.wait()
                q.put(current_thread().ident)

            def _runner2(q, e):
                e.wait()
                i = random.randint(1, 1E5)

# Generated at 2022-06-12 14:59:36.245666
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import random

    def sleep_and_return(n, sleep_sec):
        time.sleep(sleep_sec)
        return n

    m = MonoWorker()
    m.submit(sleep_and_return, 0, 0)
    m.submit(sleep_and_return, 1, 0.1)
    m.submit(sleep_and_return, 2, 0.4)
    m.submit(sleep_and_return, 3, random())
    m.submit(sleep_and_return, 4, random())
    m.submit(sleep_and_return, 5, random())
    while not m.futures[0].done():
        time.sleep(0.5)
    assert m.futures[0].result() == 5

# Generated at 2022-06-12 14:59:46.328123
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def identify(x):
        """function to be tested"""
        time.sleep(0.1)
        return x

    e = MonoWorker()
    if not e.futures:
        assert True
    else:
        assert False

    # Start first task
    r1 = e.submit(identify, 1)
    time.sleep(0.05)
    assert len(e.futures) == 1

    # Start second task
    r2 = e.submit(identify, 2)
    time.sleep(0.05)
    assert len(e.futures) == 2

    # Start third task
    r3 = e.submit(identify, 3)
    time.sleep(0.05)
    assert r2.done() and not r1.done()

# Generated at 2022-06-12 14:59:55.755424
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # test with two tasks
    def func1(n):
        import time
        time.sleep(n)
        return n + 1
    from collections import deque
    from concurrent.futures import as_completed
    from ..auto import tqdm as tqdm_auto
    tqdm_auto.write('\n--- testing MonoWorker.submit() with 2 tasks')
    mono = MonoWorker()
    n = 3  # seconds
    # submit 1st task
    tqdm_auto.write('submitting 1st task (func1({}))'.format(n))
    future1 = mono.submit(func1, n)
    # submit 2nd task
    n = 2  # seconds
    tqdm_auto.write('submitting 2nd task (func1({}))'.format(n))
    future2

# Generated at 2022-06-12 15:00:05.060335
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event, Lock
    from time import sleep
    from tqdm import tqdm
    from random import randint, random

    # init
    e = Event()
    l = Lock()
    m = MonoWorker()
    v1 = 1
    v2 = 0
    t = 0.1
    t1 = t2 = 0.0
    # test
    tqdm_auto.write('Starting test')
    with tqdm(total=v1 + v2, desc='test') as pbar:
        def do_update():
            nonlocal v1, v2, t1, t2
            l.acquire()
            sleep(t)
            pbar.update(1)
            if v1:
                v1 -= 1
                if random() < 0.5:
                    t1 += t

# Generated at 2022-06-12 15:00:15.126146
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    # returns True if num was not the last appended number
    def check_last(lst, num):
        if len(lst) == 2 and num != lst[-1]:
            return True
        return False

    def print_lst(lst):
        output = []
        for x in lst:
            output.append(str(x))
        print(' '.join(output))
        return len(lst)

    def dummy_func(arg1):
        delay = random.randint(0, 10)
        time.sleep(delay)
        return arg1


# Generated at 2022-06-12 15:00:21.701444
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of MonoWorker."""
    # Test usage of maxlen
    def append_a_fast(x):
        x.append('a')

    def append_b_slow(x):
        import time
        time.sleep(1)
        x.append('b')

    x = []
    worker = MonoWorker()
    worker.submit(append_a_fast, x)
    worker.submit(append_a_fast, x)
    worker.submit(append_b_slow, x)
    assert x == []
    from time import sleep
    sleep(1.1)
    assert x == ['b']

    # Test .cancel()
    x = []
    worker = MonoWorker()
    worker.submit(append_a_fast, x)

# Generated at 2022-06-12 15:00:31.904199
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    mw = MonoWorker()
    assert len(mw.futures) == 0
    running = mw.submit(sleep, 1)
    assert len(mw.futures) == 1
    assert running is mw.futures[0]
    mw.submit(sleep, 2)
    assert len(mw.futures) == 1
    assert running is not mw.futures[0]
    mw.submit(sleep, 3)
    assert len(mw.futures) == 1
    mw.submit(sleep, 4)
    assert len(mw.futures) == 1
    mw.submit(sleep, 5)
    assert len(mw.futures) == 1
    assert running.done() or running.cancelled()


# Generated at 2022-06-12 15:00:36.685329
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from os import getpid
    from time import time, sleep
    from concurrent.futures import wait
    from ..utils import _range
    from .utils import _le

    def foo(param):
        sleep(param)
        return param + 1

    def _test(n):
        w = MonoWorker()
        results = deque([], maxlen=2)
        for i in _range(n):
            t = time()
            results.append(w.submit(foo, i))
            dt = time() - t
            assert dt < 0.1

        # wait till all the results are finished
        wait(results)
        assert all(r.result() == r.args[0] + 1 for r in results)

    _test(1)
    _test(5)
    _test(10)
    _

# Generated at 2022-06-12 15:00:42.578075
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def sample_task(t):
        time.sleep(random.random())
        return t

    m1 = MonoWorker()
    m2 = MonoWorker()

    assert m1 is not m2, "Two instances of MonoWorker should not be equal."

    num_tasks = 100
    tasks = list(range(num_tasks))
    random.shuffle(tasks)

    for t in tasks:
        m1.submit(sample_task, t)
        m2.submit(sample_task, t)

    results1 = [future.result() for future in m1.futures]
    results2 = [future.result() for future in m2.futures]

    assert results1 == results2 == num_tasks - 1

# Generated at 2022-06-12 15:00:52.029931
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import functools
    mw = MonoWorker()
    tqdm_auto.write("Submit two jobs (A, B), A should start and return 1st")
    assert mw.submit(functools.partial(time.sleep, 1)) is None
    assert mw.submit(functools.partial(time.sleep, 1)) is None
    time.sleep(2)
    tqdm_auto.write("Submit one more job (C), which should start instantly")
    assert mw.submit(functools.partial(time.sleep, 1)) is None
    time.sleep(2)
    tqdm_auto.write("Submit another job (D), which schedule C to run next")
    assert mw.submit(functools.partial(time.sleep, 1)) is None

# Generated at 2022-06-12 15:00:56.412833
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Check that correct args are passed to function
    def func(arg1, arg2):
        """Function to be called with appropriate args."""
        assert arg1 == 1
        assert arg2 == 2
        return (arg1, arg2)
    assert MonoWorker().submit(func, 1, arg2=2).result() == (1, 2)


# Generated at 2022-06-12 15:01:07.095097
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys

    def this_should_be_printed():
        time.sleep(1.5)
        print("\n")

    def this_should_not_be():
        time.sleep(2)
        print("\n")

    mono_worker = MonoWorker()

    # Start first task.
    mono_worker.submit(this_should_be_printed)

    # Start second task.
    mono_worker.submit(this_should_be_printed)
    mono_worker.submit(this_should_not_be)

    mono_worker.pool.shutdown()
    sys.stdout.flush()

# Generated at 2022-06-12 15:01:12.083616
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from multiprocessing import Event

    event = Event()
    def func():
        event.set()
        time.sleep(2)
    MonoWorker().submit(func)
    assert event.wait(1)  # func ran in less than 1s
    assert not event.wait(1)  # func did not run again

# Run unit tests if executed directly
if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:01:19.527584
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    # Check in case the functions are not executed in order.
    # It is possible to have e1, e3, e2 instead.
    def check_execution(e1, e2, e3):
        return (sorted([e1, e2, e3]) == [e1, e2, e3])

    # Wrapper to add some sleeping
    def sleeping_func(e):
        time.sleep(random.random())
        return e

    # Test the method submit of the class MonoWorker
    e1, e2, e3 = 0, 1, 2
    worker = MonoWorker()
    f1 = worker.submit(sleeping_func, e1)
    f2 = worker.submit(sleeping_func, e2)
    f3 = worker.submit

# Generated at 2022-06-12 15:01:28.275739
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from traceback import print_exc as print_traceback
    import sys

    def do(i, *_):
        sleep(0.1)
        return i

    def fail(i, *_):
        raise ValueError(i)

    def check(worker, N=20):
        print("Waiting for {} tasks...".format(N))
        expected = sorted(range(N), reverse=True)
        for i in tqdm_auto.trange(N):
            try:
                result = worker.submit(do, i).result()
            except ValueError as e:
                print_traceback()
                print("Got exception {!r} instead of expected result".format(e), file=sys.stderr)
                return False
            else:
                assert result == i, str(i)


# Generated at 2022-06-12 15:01:36.991595
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random

    call_count = 0

    def f():
        nonlocal call_count
        call_count += 1

    m = MonoWorker()
    for i in range(5):
        m.submit(f)
    assert call_count == 0

    m.submit(f)
    assert call_count == 1

    m.submit(f)
    assert call_count == 2

    for i in range(5):
        m.submit(f)
    assert call_count == 2

    m.submit(f)
    assert call_count == 3

    for i in range(10):
        m.submit(f)
    assert call_count == 3

    m.submit(f)
    assert call_count == 4



# Generated at 2022-06-12 15:01:42.219443
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def test_func(x, y):
        return x ** y

    # Test that only one task is running
    mono = MonoWorker()
    for i in range(10):
        assert mono.submit(test_func, 2, i) is not None
    assert mono.pool._work_queue.maxsize == 1

    # Test that only one task is waiting
    mono = MonoWorker()
    first = mono.submit(test_func, 2, 5)
    for i in range(5):
        assert mono.submit(test_func, 2, i) is None
    assert len(mono.futures) == 2
    assert mono.futures.popleft() is first
    assert mono.futures.popleft() is not first

# Generated at 2022-06-12 15:01:44.116141
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(x):
        return x
    m = MonoWorker()
    assert m.submit(func, 1).result() == 1
    assert m.submit(func, 2).result() == 2
    # Only 2 tasks are allowed:
    assert m.submit(func, 3).result() == 2
    assert m.submit(func, 4).result() == 4

# Generated at 2022-06-12 15:01:50.788903
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import tqdm
    import numpy as np
    def f(i, j=None):
        sleep(np.random.rand())
        return i + (j or 0)
    mw = MonoWorker()
    with tqdm.trange(5) as t:
        for i in t:
            f2 = mw.submit(f, i)
            while not f2.done():
                t.set_description(str(f2.result(timeout=.1)))
                t.refresh()
            t.set_description('')
            t.set_postfix(i=f2.result())
            t.refresh()

# Generated at 2022-06-12 15:01:57.034249
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """A: running, W: waiting, -: empty"""
    def func(A):
        import time
        time.sleep(A)
        print('func', A)
        return A

    from multiprocessing import cpu_count
    import time
    w = MonoWorker()
    for _ in range(cpu_count() + 2):
        start_time = 0
        for A in range(5):
            start_time -= 1
            print('submit({})'.format(A))
            w.submit(func, A)
            time.sleep(1)
            if start_time < 0:
                print('start time fix')
                start_time = time.time()
            time.sleep(max(0, start_time + A - time.time()))
            print('check time')



# Generated at 2022-06-12 15:02:03.407060
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, time
    m = MonoWorker()

    def f(i):
        assert i == 1
        sleep(.1)

    def g(i):
        assert i == 2
        sleep(.1)

    def h(i):
        assert i == 3
        sleep(.1)
    t = time()
    m.submit(f, 1)
    m.submit(g, 2)
    m.submit(h, 3)
    while not (m.futures[0].done() and m.futures[1].done()):
        sleep(.01)
    m.futures.clear()
    assert time() < t + .2

# Generated at 2022-06-12 15:02:19.002750
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def _sleep(amount):
        time.sleep(amount)
        return amount * 2

    worker = MonoWorker()
    assert len(worker.futures) == 0

    futures = [worker.submit(_sleep, 1) for _ in range(3)]
    assert len(worker.futures) == 1

    # Wait for running
    assert futures[0].result() == 2

    # Wait for waiting
    assert futures[-1].result() == 2

    # Multiple short tasks for longer timeout
    futures = [worker.submit(_sleep, .1) for _ in range(50)]
    assert len(worker.futures) == 1

    # Wait for running
    assert futures[0].result() == .2

    # Wait for waiting
    assert futures[-1].result() == .2

    # Long tasks

# Generated at 2022-06-12 15:02:24.305991
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():  # TODO: add tqdm_auto.write to print
    import time

    def funcA():
        for _ in range(10):
            time.sleep(1)
            yield

    def funcB():
        for _ in range(10):
            time.sleep(1)
            yield

    def funcC():
        for _ in range(10):
            time.sleep(1)
            yield

    def funcD():
        for _ in range(10):
            time.sleep(1)
            yield

    mono = MonoWorker()
    fa = mono.submit(funcA)
    fb = mono.submit(funcB)
    fc = mono.submit(funcC)
    fd = mono.submit(funcD)

    print(fa.done())
    print(fb.done())

# Generated at 2022-06-12 15:02:32.080664
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    # Oldest task is cancelled because newest task is submitted
    t1 = mw.submit(func, 0.5)
    mw.submit(func, 0.1)
    assert not t1.done()
    # Oldest task ended, then 2nd oldest task is cancelled
    t3 = mw.submit(func, 0.9)
    mw.submit(func, 0.5)
    assert t1.done()
    assert t3.done()
    # Oldest task ended, then 2nd oldest task ends
    t5 = mw.submit(func, 0.5)
    mw.submit(func, 0.1)
    assert t5.done()


# Generated at 2022-06-12 15:02:41.813323
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import Event
    from time import sleep
    from warnings import warn

    class StopWorkerError(Exception):
        """Stopped from running because waiting thread done running."""

    def worker(sleep_time: float, stop: Event):
        """
        :param sleep_time: Number of seconds to `sleep()` for
        :param stop: `Event` to check for running
        """
        sleep(sleep_time)
        if stop.is_set():
            raise StopWorkerError
        warn("Stopped before running")
        return sleep_time


# Generated at 2022-06-12 15:02:49.382766
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> from multiprocessing import dummy
    >>> from tqdm import tqdm

    >>> def do_work(x):
    ...     pool = dummy.Pool()
    ...     for i in pool.imap_unordered(lambda i: i**i, range(10)):
    ...         tqdm.write('\r###########{}   '.format(i))

    >>> with tqdm_auto.tqdm(total=50, file=None) as t:
    ...     worker = MonoWorker()
    ...     worker.submit(do_work, 'foo')
    ...     for i in range(20):
    ...         worker.submit(do_work, 'bar')
    ...         t.update(1)

    """
    pass

# Generated at 2022-06-12 15:02:55.233841
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def test_func(i):
        time.sleep(0.1)
        print("\t{}".format(i))
        return i

    print("Test MonoWorker().submit(test_func, i) ...")

    mono = MonoWorker()
    for i in tqdm_auto.tqdm(range(10),
                            desc="MonoWorker.submit(test_func, i)",
                            leave=True,
                            dynamic_ncols=True):
        # print("Submit {} ...".format(i))
        mono.submit(test_func, i)


if __name__ == '__main__':
    import time
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:03:01.194459
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    done = []

    def foo(i):
        time.sleep(random.random() / 10)
        done.append(i)

    m = MonoWorker()
    for i in range(10):
        m.submit(foo, i)
        time.sleep(0.05)
    m.pool.shutdown(wait=True)

    assert done == sorted(done)

# Generated at 2022-06-12 15:03:07.424107
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, random
    def notify(x):
        tqdm_auto.write('{} started'.format(x))
        x *= 10.
        time.sleep(x / 70.)
        tqdm_auto.write('{} ended'.format(x))
        return x

    monoworker = MonoWorker()

    for i in range(10):
        x = random.random()
        monoworker.submit(notify, x)
        time.sleep(x / 10.)


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:03:17.015512
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from numpy.random import rand

    def work(t):
        # tqdm_auto.write('start work.')
        time.sleep(t)
        # tqdm_auto.write('end work.')
        return rand() * t

    # run in sequence
    t1 = rand()
    tqdm_auto.write('work 1, t = %f s' % t1)
    v1 = work(t1)
    t2 = rand()
    tqdm_auto.write('work 2, t = %f s' % t2)
    v2 = work(t2)

    # run with MonoWorker
    tqdm_auto.write('run with MonoWorker:')
    mw = MonoWorker()
    f1 = mw.submit(work, t1)

# Generated at 2022-06-12 15:03:24.632665
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=protected-access
    import time
    import itertools
    from threading import active_count
    from concurrent.futures import CancelledError

    def test_func(x, y):
        """
        :param x: int
        :param y: bool
        :return x+True: bool
        """
        time.sleep(0.1)
        return x + bool(y)

    mw = MonoWorker()
    ac0 = active_count()
    assert mw._pool._max_workers == 1
    assert len(mw._futures) == 0
    assert active_count() == ac0
    for i in itertools.count():
        f = mw.submit(test_func, i, bool(i % 2))

# Generated at 2022-06-12 15:03:50.404761
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import gauss

    def do_work():
        time.sleep(gauss(5, 1))
        return time.time()

    mw = MonoWorker()
    t0 = time.time()

    for i in range(5):
        w1 = mw.submit(do_work)
        print("\tSubmitted job #{}".format(i + 1))

        if i % 2 == 0:
            w1.result()  # wait for it to finish
            tqdm_auto.write("\t\tFinished job #{} in {:.1f}s".format(
                i + 1, time.time() - t0))

    # Finish the job and print
    w1.result()

# Generated at 2022-06-12 15:03:59.196213
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def sleep_a_while(t):
        time.sleep(t)
        return t

    mw = MonoWorker()
    f = mw.submit(sleep_a_while, 10)
    assert f.result() == 10
    f = mw.submit(sleep_a_while, 1)
    assert f.result() == 1     # 10s task cancelled
    f = mw.submit(sleep_a_while, 2)
    assert f.result() == 2     # 1s task was cancelled
    time.sleep(3)
    f = mw.submit(sleep_a_while, 0.5)
    assert f.result() == 0.5   # 2s task was cancelled

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:04:06.733415
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    e = Event()

    def task_factory():
        """Returns a task with a distinct id, which sleeps for a specific time."""
        i = 0
        while True:
            sleep_time = (yield i)
            if sleep_time is not None:
                sleep(sleep_time)
            i += 1

    def check_task(task, id_, time_):
        """Check if `task` corresponds to the expected input `id_` & `time_`."""
        return id_ == task.result() and time_ == task.submit_time

    task_0, task_1, task_2, task_3 = task_factory(), task_factory(), task_factory(), task_factory()
    worker = MonoWorker()


# Generated at 2022-06-12 15:04:17.533841
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    mw = MonoWorker()

    def _submit_and_return(s, sleep=.2):
        print('submitting {}'.format(s))
        ret = mw.submit(time.sleep, sleep)
        print('{} submitted'.format(s))
        return ret

    def _submit_and_return_to_output(s, sleep=.2):
        print('submitting {}'.format(s))
        ret = mw.submit(time.sleep, sleep)
        print('{} submitted, returning id {}'.format(s, id(ret)))
        return ret

    for i in range(10):
        print('submitting 0, id is {}'.format(id(_submit_and_return_to_output('0'))))
        _submit_and_return('1')

# Generated at 2022-06-12 15:04:22.834310
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import os

    def test_function(a):
        time.sleep(a)
        return os.getpid()

    a = MonoWorker()

    assert a.submit(test_function, 0.5).result() != a.submit(test_function, 0.5).result()

    assert not a.submit(test_function, 0.5).result() == a.submit(test_function, 0.5).result()



# Generated at 2022-06-12 15:04:28.406042
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def do_work(sleep_time=0.1):
        time.sleep(sleep_time)
        return sleep_time

    m = MonoWorker()

    f1 = m.submit(do_work, 0.5)
    assert f1.running()

    f2 = m.submit(do_work, 0.2)
    assert not f1.running()
    assert f2.running()

    f3 = m.submit(do_work, 0.3)
    assert f3.running()
    assert not f2.running()

    f4 = m.submit(do_work, 0.4)
    assert f4.running()
    assert not f3.running()

# Generated at 2022-06-12 15:04:36.897146
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test case 1
    temp_worker = MonoWorker()
    assert len(temp_worker.futures) == 0
    first_task = temp_worker.submit(test_MonoWorker_func_1, "1")
    assert len(temp_worker.futures) == 1
    second_task = temp_worker.submit(test_MonoWorker_func_1, "2")
    assert len(temp_worker.futures) == 1
    assert second_task.done()
    assert not first_task.done()

    # Test case 2
    temp_worker = MonoWorker()
    assert len(temp_worker.futures) == 0
    first_task = temp_worker.submit(test_MonoWorker_func_2, "1")

# Generated at 2022-06-12 15:04:44.904171
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    def foo():
        import time
        time.sleep(.1)
        return 'Foo'

    def bar():
        import time
        time.sleep(.1)
        return 'Bar'

    def baz():
        import time
        time.sleep(.1)
        return 'Baz'


    threads = []
    for i in range(5):
        mw = MonoWorker()
        t1 = threading.Thread(target=lambda: mw.submit(foo))
        t2 = threading.Thread(target=lambda: mw.submit(bar))
        t3 = threading.Thread(target=lambda: mw.submit(baz))
        threads.extend([t1, t2, t3])

    for t in threads:
        t.start()

# Generated at 2022-06-12 15:04:48.700737
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def plus(*nums):
        """sums the args"""
        return sum(nums)

    mw = MonoWorker()
    mw.submit(plus, 1, 2, 3)
    mw.submit(plus, 4, 5)
    mw.submit(plus, 6, 7, 8, 9)
    mw.submit(plus, 10, 11)
    assert mw.futures[0].result() == 6  # 10 + 11 (=21) replaced 4 + 5 (=9)

# Generated at 2022-06-12 15:04:56.267624
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError, as_completed

    fib = lambda n: 1 if n < 3 else fib(n - 1) + fib(n - 2)
    # fib(1)  # -> 1
    # fib(2)  # -> 1
    # fib(3)  # -> 2
    # fib(4)  # -> 3
    # fib(5)  # -> 5
    # fib(6)  # -> 8
    # fib(7)  # -> 13
    # fib(8)  # -> 21
    # fib(9)  # -> 34
    # fib(10)  # -> 55
    # fib(20)  # -> 6765
    # fib(30)  # -> 832040
    # fib(40)  # -> 102334155
    # fib

# Generated at 2022-06-12 15:05:38.946240
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .test_tqdm_gui import test_write

    def print_i(i):
        print(i)
        time.sleep(0.2)
        return i

    worker = MonoWorker()
    with test_write.testing_stdout():
        worker.submit(print_i, 1)
        time.sleep(0.1)
        worker.submit(print_i, 2)
        time.sleep(0.1)
        worker.submit(print_i, 3)
        time.sleep(0.1)
        worker.submit(print_i, 4)
        time.sleep(1)

# Generated at 2022-06-12 15:05:48.015395
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm.contrib import DummyTqdmFile
    from concurrent.futures import Future
    # for test report
    class DummyTqdmFile(_io.TextIOWrapper, DummyTqdmFile):
        pass
    # prepare
    print_ = tqdm_auto.write
    tqdm_auto.write = lambda s: None
    fake_stdout = DummyTqdmFile(sys.stdout)
    old_stdout = sys.stdout
    sys.stdout = fake_stdout
    # run
    mw = MonoWorker()
    f1 = mw.submit(time.sleep, 1)
    assert isinstance(f1, Future)
    f2 = mw.submit(time.sleep, 2)

# Generated at 2022-06-12 15:05:55.388118
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def foo(n):
        from time import sleep
        sleep(n)
        return n

    from threading import Thread

    def thread_submit(worker, n):
        from time import sleep
        sleep(.001)
        worker.submit(foo, n)

    threads = []
    worker = MonoWorker()
    threads.append(Thread(target=thread_submit, args=(worker, .1)))
    threads.append(Thread(target=thread_submit, args=(worker, 2)))
    threads.append(Thread(target=thread_submit, args=(worker, .5)))
    threads.append(Thread(target=thread_submit, args=(worker, 1)))
    # threads.append(Thread(target=thread_submit,
    #                       args=(worker, .5)))  # too late to be submitted

# Generated at 2022-06-12 15:06:06.166965
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from contextlib import closing
    work_done = Event()
    wait_done = Event()
    running = None
    waiting = None

    def work():
        time.sleep(0.1)
        running.set()

    with closing(MonoWorker()) as mw:
        running = mw.submit(work)
        assert not running.done()
        running.wait()
        wait_done.wait()
        waiting = mw.submit(work)
        running = mw.submit(work)
        assert not wait_done.is_set()
        assert not waiting.done()
        waiting.wait()
        assert not wait_done.is_set()
        running.wait()
        wait_done.set()
        running = mw.submit(work)
        work

# Generated at 2022-06-12 15:06:13.245902
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, math, pytest
    mw = MonoWorker()
    r = [2, 3, 5]  # test input
    x = [math.factorial(i) for i in r]  # test output

    # submit one task at a time and check output
    for i in r:
        f = mw.submit(math.factorial, i)
        assert f.result(timeout=1.0) == x[r.index(i)]

    # submit all tasks together and check output (even when ordering is random)
    def _test_submit_all_at_once(r, x):
        fs = [mw.submit(math.factorial, i) for i in r]
        results = [None] * len(fs)

# Generated at 2022-06-12 15:06:22.187011
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm import tqdm
    from concurrent.futures import ThreadPoolExecutor

    # Create worker and submit an infinite print loop
    worker_pool = ThreadPoolExecutor(max_workers=1)
    worker = MonoWorker()

    def print_loop():
        while True:
            time.sleep(0.1)
            tqdm_auto.write("print_loop")

    worker_pool.submit(print_loop)

    # Create a worker and submit an infinite print hello
    def print_hello():
        while True:
            time.sleep(0.1)
            tqdm_auto.write("hello")
    fut = worker.submit(print_hello)

    # Wait for 0.4 second, print loop should ran 4 times
    time.sleep(0.4)

    # Submit a

# Generated at 2022-06-12 15:06:29.912547
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import randrange
    from ordered_set import OrderedSet
    from concurrent.futures import ThreadPoolExecutor

    def func(i):
        tqdm_auto.write('[{}] in'.format(i))
        time.sleep(0.5)
        tqdm_auto.write('[{}] out'.format(i))
        return i

    num_tests = 100
    NUM_TASKS = 3
    m = MonoWorker()

    # Constant collection of all tasks
    tasks = OrderedSet()
    for _ in range(num_tests):
        i = randrange(NUM_TASKS)
        t = m.submit(func, i)
        tasks.add(t)
        time.sleep(0.1)

    # The waiting task
    waiting = m

# Generated at 2022-06-12 15:06:39.715800
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    random.seed(0)

    class Worker(MonoWorker):
        def __init__(self):
            super(Worker, self).__init__()
            self.counter = 0
            self.last_start = None
            self.last_stop = None

        def process(self, sleep=None):
            self.counter += 1
            self.last_start = time.time()
            if sleep is not None:
                time.sleep(sleep)
            self.last_stop = time.time()

        def process_slow(self, x):
            self.process(1)
            return x

        def process_fast(self, x):
            self.process(0.1)
            return x

        def test_wait(self):
            self.last_start = None
            self

# Generated at 2022-06-12 15:06:45.731805
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    start = time.time()
    worker = MonoWorker()
    # 1st job
    f1 = worker.submit(lambda: sum(random.random() for _ in xrange(10**6)))
    print('submitted task 1')
    # 2nd job
    f2 = worker.submit(lambda: sum(random.random() for _ in xrange(10**6)))
    print('submitted task 2')
    # 3rd job
    f3 = worker.submit(lambda: sum(random.random() for _ in xrange(10**6)))
    print('submitted task 3')
    for r in f1, f2, f3:
        print(r.result())  # will print the result of the last job

# Generated at 2022-06-12 15:06:52.785288
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    m = MonoWorker()
    t0 = time.time()
    f1 = m.submit(time.sleep, 1)
    f2 = m.submit(time.sleep, 1)  # should REPLACE f1
    t1 = time.time()
    f3 = m.submit(time.sleep, 1)  # should replace f2
    t2 = time.time()
    assert (t1 - t0) < 1
    assert (t2 - t1) >= 1  # f2 execution time
    for i in range(4, 11):
        m.submit(time.sleep, 1)  # should clear all pending tasks
    time.sleep(1)  # clear all submitted tasks
    assert (time.time() - t2) >= 9