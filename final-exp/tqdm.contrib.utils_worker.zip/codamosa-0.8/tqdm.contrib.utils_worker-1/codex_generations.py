

# Generated at 2022-06-12 14:58:17.843132
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    mw.submit(time.sleep, 0.2)
    mw.submit(time.sleep, 0.1)
    mw.submit(time.sleep, 0.3)
    mw.submit(time.sleep, 0.4)
    mw.submit(time.sleep, 0.5)
    mw.submit(time.sleep, 0.6)


# Generated at 2022-06-12 14:58:24.366220
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 14:58:31.157730
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def test_submit_goodness(mw, expected_result):
        result = {}
        def fake_func(i):
            result['future{}'.format(i)] = i
            return i
        for i in range(5):
            f = mw.submit(fake_func, i)
            if f:
                result[f] = f.result()
        assert result == expected_result
    expected = {
        'future0': 0,
        'future4': 4,
        'future4': 4,
    }
    mw = MonoWorker()
    test_submit_goodness(mw, expected)

# Generated at 2022-06-12 14:58:37.028743
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import logging

    logging.basicConfig(level=logging.INFO)
    m = MonoWorker()
    for i in range(5):
        g = m.submit(time.sleep, i / 8)
        logging.info("SLEEPING %s", i)
        time.sleep(1)
        logging.info("DONE %s", i)
    logging.info("FINAL POOL: %s", m.pool._threads)

# Generated at 2022-06-12 14:58:43.763972
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def foo(a, b=0):
        sleep(0.01)
        return a + b

    worker = MonoWorker()

    for _ in tqdm_auto.tqdm(
            range(10),
            desc='test_MonoWorker_submit',
            leave=False,
            dynamic_ncols=True):
        try:
            future = worker.submit(foo, 1, b=2)
            assert future.result() == 3
        except Exception as e:
            tqdm_auto.write(str(e))

# Generated at 2022-06-12 14:58:53.809853
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def wait_func(i):
        import time
        time.sleep(3)
        return i

    def wait_second_func(i):
        import time
        time.sleep(2)
        return i

    worker = MonoWorker()
    start = time.time()
    worker.submit(wait_func, 5)
    # worker.submit(wait_func, 6) # Commented to test waiting
    worker.submit(wait_second_func, 7)
    for future in worker.futures:
        print(future.result())

    # Output should be 7 (5 not submitted, 6 replaced by 7 for waiting,
    # and 7 finished before 6)
    print('Total time: {}'.format(time.time() - start))

# Generated at 2022-06-12 14:58:58.348956
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def job(n):
        time.sleep(n)
        return n

    m = MonoWorker()
    t = m.submit(job, 1)
    assert list(m.futures) == [t]
    m.submit(job, 1)
    assert [t.done() for t in m.futures] == [True, False]

# Generated at 2022-06-12 14:59:07.694723
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import copy
    from time import sleep
    from operator import add
    from operator import floordiv
    from itertools import chain
    from concurrent.futures import as_completed
    from concurrent.futures import CancelledError
    N = int(1e2)
    M = int(1e2)
    L = int(1e2)
    mono = MonoWorker()
    sources = [xrange(N), xrange(M, M + N)]
    with tqdm_auto.tqdm(total=L) as pbar:
        for source in sources:
            for x in source:
                y = copy.copy(x)
                def func(x, y):
                    """No side-effects, only calling it from here."""
                    assert x == y
                    sleep(0.01)
                    return

# Generated at 2022-06-12 14:59:16.622771
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import Future
    def f(x):
        sleep(1)
        return x

    m = MonoWorker()
    print("f1")
    f1 = m.submit(f, 1)
    print("f2")
    f2 = m.submit(f, 2)
    print("f3")
    f3 = m.submit(f, 3)
    print("f4")
    f4 = m.submit(f, 4)
    assert(f1.done() and f1.result() == 2)
    assert(f2.cancelled() or (f2.running() and f2.result() == 3))
    assert(f3.done() and f3.result() == 4)

# Generated at 2022-06-12 14:59:26.774054
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    sleep = lambda: time.sleep(random.randint(1, 3))
    out = ''
    def print_A(*args, **kwargs):
        global out
        out += 'A'
        sleep()
    def print_B(*args, **kwargs):
        global out
        out += 'B'
        sleep()
    def print_C(*args, **kwargs):
        global out
        out += 'C'
        sleep()
    mono = MonoWorker()

    # start A -> B
    mono.submit(print_A)
    mono.submit(print_B)
    sleep()  # wait for a bit
    assert out == 'A'
    time.sleep(3)
    assert out == 'AB'

    # submit C -> A

# Generated at 2022-06-12 14:59:40.821535
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(x):
        return 'f' + str(x)
    def g(x):
        return 'g' + str(x)
    def h(x):
        return 'h' + str(x)

    worker = MonoWorker()
    # Intermediate result: running = None, waiting = None
    assert worker.futures.maxlen == 2
    assert len(worker.futures) == 0

    # Replace None: running = f(1), waiting = None
    worker.submit(f, 1)
    assert len(worker.futures) == 1

    # Discard g(1): running = f(1), waiting = f(2)
    worker.submit(g, 1)
    worker.submit(f, 2)
    assert len(worker.futures) == 1

    # Discard h(

# Generated at 2022-06-12 14:59:44.643367
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def print_time():
        time.sleep(1)
        print('function print_time()')

    mw = MonoWorker()
    mw.submit(print_time)
    time.sleep(1)
    mw.submit(print_time)
    mw.submit(print_time)

# Generated at 2022-06-12 14:59:55.206639
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import string

    def factory(n):
        def _f(arg):
            time.sleep(arg)
            return arg
        return _f

    def _wait_finish(timing, sleep, cancel=None):
        for i in tqdm_auto.trange(timing):
            time.sleep(sleep)
            if cancel is not None:
                cancel.set()

    def _wait_finish_nonblock(timing, sleep, cancel=None):
        for i in tqdm_auto.trange(timing):
            time.sleep(sleep)
            if cancel is not None:
                cancel.set()
            if not worker.futures:  # actually an assert
                return i

    worker = MonoWorker()


# Generated at 2022-06-12 15:00:05.023772
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(i):
        time.sleep(0.1)
        return i

    monow = MonoWorker()
    """Warning: since we're discarding results, if
    any of the following lines raises, this will only
    be visible if run with -O flag"""
    monow.submit(f, 0)
    assert monow.futures
    monow.submit(f, 1)
    assert monow.futures
    monow.submit(f, 2)
    assert monow.futures
    monow.submit(f, 3)
    assert monow.futures
    monow.submit(f, 4)
    assert monow.futures
    monow.submit(f, 5)
    assert monow.futures

# Generated at 2022-06-12 15:00:11.027868
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm import tqdm
    from . import md5sum
    sleep = lambda: sleep(0.01)

    test_file = __file__
    w = MonoWorker()

    # should raise exception
    try:
        w.submit(1, 2, 3, 4)
    except TypeError:
        pass

    # should raise IOError
    try:
        w.submit(md5sum, 'Unexistent file')
    except IOError as e:
        tqdm_auto.write(str(e))

    # should wait, but never compute
    w.submit(md5sum, test_file)
    w.submit(md5sum, test_file)
    w.submit(md5sum, test_file)
    sleep()

    # should compute 2, discard 3rd

# Generated at 2022-06-12 15:00:18.785496
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from ..contrib.concurrent import thread_map, MonoWorker

    def f(i):
        return ('f(%d) - ' % i) + ('waiting' if i else 'running')
    def g(i):
        # time.sleep(0.1)  # test cancel
        time.sleep(0.1 + int(i != 0))  # test cancel
        return ('g(%d) - ' % i) + ('waiting' if i else 'running')

    def run_thread_map():
        out = list(thread_map(f, range(3)))
        assert out == ['f(0) - running', 'f(1) - waiting', 'f(2) - waiting']
    def run_MonoWorker():
        mw = MonoWorker()
       

# Generated at 2022-06-12 15:00:29.079957
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 15:00:37.257199
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 15:00:44.947402
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 15:00:54.507159
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .._utils import ThreadGen
    from multiprocessing import Value
    import time

    def wait_for_nb_tasks(mw, nb):
        """Wait until all running tasks are done"""
        while True:
            try:
                running = all(
                    f.done() for f in mw.futures if f.running())
            except Exception:
                running = False
            if not running:
                return
            time.sleep(0.1)

    def f(x, v):
        """Add x to value v"""
        time.sleep(0.1)
        with v.get_lock():
            v.value += x

    nb_tasks = Value('i', 0)


# Generated at 2022-06-12 15:01:07.017801
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from collections import deque
    from tqdm.contrib import MonoWorker
    # Note: This has two global side-effects (tqdm.write and getattr)
    # which cannot be tested in a fork-safe manner (using multiprocessing)
    def test_func(x):
        sleep(x)
        tqdm_auto.write("test_func(%s)" % x)
        return x
    tqdm_auto.write = deque(maxlen=100)
    mw = MonoWorker()

    # test immediate execution
    mw.submit(test_func, 0.4)
    assert not mw.futures[0].done()
    sleep(0.5)
    assert mw.futures[0].done()

# Generated at 2022-06-12 15:01:15.016082
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock

    def func1(*args, **kwargs):
        with lock:
            with tqdm_auto.tqdm(total=args[0]) as progress:
                sleep(2)
                progress.update(1)

    def func2(*args, **kwargs):
        with lock:
            with tqdm_auto.tqdm(total=args[0]) as progress:
                sleep(2)
                progress.update(2)

    lock = Lock()
    with tqdm_auto.tqdm(total=12) as progress:
        mono_worker = MonoWorker()

# Generated at 2022-06-12 15:01:21.695784
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing
    from time import sleep
    from .helpers import mp_is_notebook
    from .tqdm import tqdm

    if mp_is_notebook():
        return

    def main():
        mw = MonoWorker()
        mw_submit = mw.submit
        tqdm(range(5), desc='main')
        # sleep(1)  # force queue overflow
        mw_submit(sleep, 1, desc='sleep')  # import sleep
        mw_submit(sleep, 2, desc='sleep2')
        mw_submit(sleep, 3, desc='sleep3')
        mw_submit(sleep, 4, desc='sleep4')

    multiprocessing.freeze_support()
    multiprocessing.set_start_method('spawn')
    m = multip

# Generated at 2022-06-12 15:01:23.456230
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from contextlib import closing
    with closing(MonoWorker()) as mw:
        for i in tqdm_auto.tqdm(range(10)):
            sleep(random())
            mw.submit(lambda i: sleep(random()), i)

# Generated at 2022-06-12 15:01:33.396815
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import os
    import time
    class TestFunc:
        def __init__(self):
            self.count = 0
        def __call__(self, t):
            self.count += 1
            tqdm_auto.write('test')
            time.sleep(3)
            tqdm_auto.write('test_end')
            return str(self.count)

    test_func = TestFunc()
    mw = MonoWorker()

    test_time = [1, 1, 2, 3, 3, 3, 3]
    test_count = [1, 1, 2, 3, 3, 3, 3]

    t = time.time()
    for i, tt in enumerate(test_time):
        now_t = time.time() - t

# Generated at 2022-06-12 15:01:40.157333
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import string
    import time
    N = 1000
    M = 55
    L = [''.join(random.choice(string.ascii_letters) for _ in xrange(7)) for _
         in xrange(N)]
    random.shuffle(L)
    # L = [2, 6, 1, 4, 7, 3, 8, 5, 9, 0]

    def log_sleep(arg):
        tqdm_auto.write(arg)
        time.sleep(random.randint(1, 20) * 0.1)

    with tqdm_auto.tqdm(total=N) as t:
        mono_worker = MonoWorker()
        for string in L:
            mono_worker.submit(log_sleep, string)
            t.update()

# Generated at 2022-06-12 15:01:49.757654
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test"""
    import time
    mw = MonoWorker()
    res = []
    tqdm_auto.write('\nSubmit x1, x2, x3, x4')
    f = mw.submit(time.sleep, 3)
    res.append(f.result())
    f = mw.submit(time.sleep, 2)
    time.sleep(0.5)
    res.append(f.result())
    f = mw.submit(time.sleep, 1)
    time.sleep(2)
    res.append(f.result())
    f = mw.submit(time.sleep, 0.5)
    res.append(f.result())
    assert res == [None, None, None, None]

# Generated at 2022-06-12 15:01:56.952256
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    worker = MonoWorker()

    def f1():
        return time.strftime('%H:%M:%S')

    def f2():
        time.sleep(1)
        return time.strftime('%H:%M:%S')

    def slow_call(result):
        time.sleep(2)
        return 'slow result'

    def run():
        t = threading.current_thread()
        while True:
            print('\nCurrent job: %s' % worker.futures[-1])
            print(worker.submit(f1).result())
            print(worker.submit(f2).result())
            slow_call(worker.submit(slow_call).result())
            print('Done!')

    thread = threading.Thread(target=run)

# Generated at 2022-06-12 15:02:04.214602
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Process
    from concurrent.futures import TimeoutError

    def test_func(t):
        """Dummy test function"""
        sleep(t)
        return t

    def test_submit(t):
        """Dummy test function"""
        return t

    def do_submit_tests(mono, expected_result):
        """Calls test_submit several times with different timeouts"""
        ret = []
        ret.append(mono.submit(test_submit, (1, 1)) == expected_result)
        ret.append(mono.submit(test_submit, (1, 2)) == expected_result)
        ret.append(mono.submit(test_submit, (1, 3)) == expected_result)

# Generated at 2022-06-12 15:02:14.200388
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future
    from contextlib import contextmanager
    from unittest import TestCase

    mworker = MonoWorker()

    @contextmanager
    def worker_exec(mworker, seconds):
        """Executes the following code in a thread with a worker"""
        fut = mworker.submit(time.sleep, seconds)
        try:
            yield fut
        finally:
            if not isinstance(fut, Future) or not fut.done():
                mworker.pool.shutdown(wait=False)
        if isinstance(fut, Future):
            assert fut.done()
            mworker.pool.shutdown()

    class TestMonoWorkerSubmit(TestCase):
        """Tests method submit of class MonoWorker."""


# Generated at 2022-06-12 15:02:26.702100
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test submit method of class MonoWorker"""
    from time import sleep
    from threading import Thread

    def wait(duration):
        """Wait for a while"""
        sleep(duration)

    def test(duration_waiting, duration_running):
        """Test submit method of class MonoWorker"""
        thread_running = None
        def wait_or_cancel(duration):
            """Wait or cancel depending on duration"""
            sleep(duration)
            # Cancel waiting if running is not yet finished
            if thread_running is not None and thread_running.is_alive():
                with tqdm_auto.external_write_mode(False):
                    print('Cancel waiting')
                waiting.cancel()

        mono_worker = MonoWorker()

# Generated at 2022-06-12 15:02:29.907944
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def func(sleep_time):
        sleep(sleep_time)
        return sleep_time

    worker = MonoWorker()

    assert not worker.futures

    for i in [0, 1, 4, 2]:
        future = worker.submit(func, i)
        assert len(worker.futures) == 1
        assert not worker.futures[0].done()

    assert future.result() == 2

    assert len(worker.futures) == 1
    assert worker.futures[0].result() == 0

    assert len(worker.pool._threads) == 1

# Generated at 2022-06-12 15:02:33.859053
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    n = 0
    worker = MonoWorker()
    for i in tqdm_auto.trange(1, 3, ncols=100):
        n = i
        worker.submit(time.sleep, 0.5)
    assert n == 2
    assert len(worker.futures) == 2


# Generated at 2022-06-12 15:02:43.821435
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test thread submission order"""
    import time

    class Event(object):
        def __init__(self):
            self._trace = []

        def __call__(self, n):
            time.sleep(.2)
            self._trace.append(n)

    evt = Event()

    mw = MonoWorker()
    mw.submit(evt, 1)  # first
    time.sleep(.01)
    mw.submit(evt, 2)  # replaced by 2
    time.sleep(.01)
    mw.submit(evt, 3)  # replaced by 3
    time.sleep(.01)
    mw.submit(evt, 4)  # replaced by 4
    time.sleep(.4)
    assert evt._trace == [4]  # running 1 discarded by

# Generated at 2022-06-12 15:02:51.724825
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    mw = MonoWorker()

    class Dummy:
        def __init__(self, name):
            self.name = name
        def say(self, s, t=1):
            print(self.name, "says", s, "for", t, "secs")
            sleep(t)
        def __repr__(self):
            return self.name

    john = Dummy("John")
    paul = Dummy("Paul")
    mw.submit(john.say, "hello")
    mw.submit(paul.say, "world")
    sleep(0.2)
    mw.submit(john.say, "cancelled")
    sleep(1.1)
    return john, paul, mw

# Generated at 2022-06-12 15:03:02.842673
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import wait, as_completed

    # initialize MonoWorker
    mw = MonoWorker()

    n = 0
    lock = Lock()
    def func(i):
        sleep(i)
        with lock:
            global n
            n += 1
        return i

    # submit 10 futures
    futures = []
    for i in range(10):
        future = mw.submit(func, i)
        futures.append(future)

    # wait for them to all finish
    done, not_done = wait(futures)
    assert not not_done
    assert len(done) == 10

    # check that only two were called
    with lock:
        assert n == 2, 'expected(2) actual({})'.format(n)

# Generated at 2022-06-12 15:03:09.538217
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Eagerly test the `submit` method of class `MonoWorker`."""
    from time import sleep
    from nose.tools import eq_
    from .utils import silent

    def work(n):
        sleep(n / 1000.0)

    # test MonoWorker.submit()
    mw = MonoWorker()
    eq_(len(mw.futures), 0)
    eq_(mw.submit(work, 100).result(timeout=0), None)
    eq_(len(mw.futures), 1)
    eq_(mw.submit(work, 200).result(timeout=0), None)
    eq_(len(mw.futures), 1)
    eq_(mw.submit(work, 300).result(timeout=0), None)

# Generated at 2022-06-12 15:03:18.265849
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Thread
    from random import randint
    from mock import Mock, MagicMock

    def run():
        def sleep():
            global waiting
            time.sleep(randint(1, 2))
            waiting = False

        def loop():
            global waiting
            for _ in range(4):
                waiting = True
                # print "trying"
                worker.submit(sleep)
                # print "done"
                time.sleep(randint(1, 2))
            worker.pool.shutdown()
            waiting = False

        def consume():
            global waiting
            while waiting:
                # print "waiting"
                time.sleep(0.5)

        thread.start_new_thread(loop, ())
        thread.start_new_thread(consume, ())

    worker = MonoWorker()

# Generated at 2022-06-12 15:03:25.587697
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func(n, msg):
        time.sleep(n)
        tqdm_auto.write(msg)


    tqdm_auto.write('Normal case:')
    mw = MonoWorker()
    mw.submit(func, 1, '1')
    mw.submit(func, 2, '2')
    mw.submit(func, 3, '3')
    time.sleep(1.1)
    mw.submit(func, 1, '3+')

    tqdm_auto.write('\n\nCancel:')
    mw.submit(func, 0, 'Canceled')
    mw.submit(func, 1, 'Should be canceled')
    mw.submit(func, 2, 'should be skipped')
    time.sleep(2.1)

# Generated at 2022-06-12 15:03:34.481979
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # For a complete test, use `pip install pytest` and run `py.test -v`
    from time import sleep
    from subprocess import CalledProcessError as CPE
    from subprocess import check_output, Popen
    import sys
    if sys.version_info[:2] >= (3, 3):
        from multiprocessing import Process
    else:
        from multiprocessing.dummy import Process

    mw = MonoWorker()

    def assert_value(future, val):
        assert future.result() == val

    def assert_exception(future, exc=CPE):
        try:
            future.result()
        except exc:
            pass
        else:
            assert False

    def assert_OSerror(future, exc=CPE):
        assert_exception(future, exc)

   

# Generated at 2022-06-12 15:03:56.234646
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def _wait(sec):
        import time
        time.sleep(sec)
        return sec

    from .cls_add_example import Example

    t = Example()
    worker = MonoWorker()
    t.update(0)
    worker.submit(_wait, 0.1)
    worker.submit(_wait, 0.2)
    worker.submit(_wait, 0.3)
    worker.submit(_wait, 0.4)
    worker.submit(_wait, 0.5)
    worker.submit(_wait, 0.6)
    worker.submit(_wait, 0.7)
    worker.submit(_wait, 0.8)
    worker.submit(_wait, 0.9)
    worker.submit(_wait, 1.0)

# Generated at 2022-06-12 15:04:04.441524
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from pandas import DataFrame
    from pandas.io.gbq import read_gbq

    def foo():
        time.sleep(1)
        return DataFrame()

    mono = MonoWorker()
    futures = [mono.submit(foo) for _ in tqdm_auto(range(5))]
    # Assert that only one future will return a result
    assert len([f for f in futures if not f.cancelled()]) == 1

    # Assert that read_gbq with same credentials works as expected
    credentials_path = '~/.credentials/gae-service-account.json'
    sql = ('SELECT 123')
    query = {'query': sql, 'dialect': 'standard'}

# Generated at 2022-06-12 15:04:15.048278
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, time
    from multiprocessing import Value
    from .lock import ThreadLock

    results = [1, 2, 3]
    start_ids = [0, 0, 0]
    end_ids = [0, 0, 0]
    def add_one(i, start_id, end_id, sleep_duration):
        start_id.value = i
        sleep(sleep_duration)
        end_id.value = i
        return i

    max_workers = 1
    num_tests = 3
    sleep_durations = [1, 0.5, 0.1]

    mw = MonoWorker()
    lock = ThreadLock()
    lock.acquire()

# Generated at 2022-06-12 15:04:24.736416
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from time import sleep
    from math import sqrt
    from . import TerminableThread, naturals

    # Note: this test is by no means exhaustive

    start_time = 0
    running = False

    def job():
        # Test that job is called once and no more
        nonlocal start_time, running
        assert not running
        running = True
        start_time = tqdm_auto.format_interval(start_time)

    def job1():
        # Test that job1 is called before job
        nonlocal running
        assert not running
        sleep(0.1)

    def job2():
        # Test that job2 is not even called
        assert True is False

    # Test (1): "job" should be called
    worker = MonoWorker()
    p = worker

# Generated at 2022-06-12 15:04:29.821333
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures as futures
    import time
    def test_func(n):
        time.sleep(n)

    w = MonoWorker()
    assert w.futures.maxlen == 2
    for i in range(4):
        if i < 3:
            assert w.submit(test_func, i) is not None
        else:
            assert w.submit(test_func, i) is None

# Generated at 2022-06-12 15:04:35.943496
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    def gener():
        while True:
            yield random.random()
            time.sleep(0.1)

    def do(x):
        if x < 0.5:
            assert True
        else:
            assert False

    with MonoWorker() as w:
        time.sleep(0.05)
        w.submit(do, 1)
        time.sleep(0.1)
        w.submit(do, 0)

    w = MonoWorker()
    for x in gener():
        w.submit(do, x)

# Generated at 2022-06-12 15:04:37.955964
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    input_ = MonoWorker()
    for i in range(10):
        input_.submit(time.sleep, 1)

# Generated at 2022-06-12 15:04:45.649090
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test the `MonoWorker.submit` method."""
    from time import sleep

    def time_task(n):
        """Sleep for `n` seconds."""
        sleep(n)
        return n

    worker = MonoWorker()
    task1 = worker.submit(time_task, 1)
    # task2 = worker.submit(time_task, 2)  # will cancel
    task3 = worker.submit(time_task, 3)
    # task4 = worker.submit(time_task, 4)  # will cancel
    task5 = worker.submit(time_task, 5)
    assert task1.result() == 1
    assert task3.result() == 3
    assert task5.result() == 5
    try:
        task2.result()
    except Exception:
        assert True

# Generated at 2022-06-12 15:04:53.732636
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test for MonoWorker.submit."""
    import time
    import random
    from .threaded_utils import non_blocking_stdout
    from .threaded_utils import non_blocking_sleep
    from .threaded_utils import non_blocking_stderr
    from .threaded_utils import non_blocking_stdout_error
    mw = MonoWorker()
    expected = []
    #
    assert NonBlockingStdout(mw).run() is None
    assert NonBlockingStdoutError(mw).run() is None
    assert NonBlockingSleep(mw).run() is None
    assert NonBlockingStderr(mw).run() is None
    assert len(mw.futures) == 0
    #
    expected += [None]

# Generated at 2022-06-12 15:05:00.206016
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from concurrent.futures import ThreadPoolExecutor
    from tqdm.contrib import MonoWorker as MW
    from tqdm.utils import _term_move_up

    def running(t):
        sleep(t)

    def waiting(t):
        sleep(t)

    max_secs = 0.05
    wait_secs = 0.02
    pool = ThreadPoolExecutor()
    mw = MW()

    threads = [
        Thread(target=running, args=(max_secs,), daemon=True),
        Thread(target=waiting, args=(wait_secs,), daemon=True),
        Thread(target=waiting, args=(wait_secs,), daemon=True),
    ]
    for thread in threads:
        thread.start

# Generated at 2022-06-12 15:05:47.146493
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import platform
    if platform.system() == 'Windows':
        # Python 3.4 on Win7 doesn't support 'io.StringIO' below
        return
    from io import StringIO
    from contextlib import contextmanager

    # context manager that captures sys.stdout
    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    # do not run test if python version is too low

# Generated at 2022-06-12 15:05:54.793820
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import threading
    from itertools import count
    from ..utils import sizeof_fmt

    mw = MonoWorker()
    w = tqdm_auto.tqdm(total=0, ncols=80, bar_format="{percentage:03.0f}%|{bar:40}{r_bar:40}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]")

    def set_desc(desc):
        w.desc = desc

    def print(x):
        print(x)
        sys.stdout.flush()

    def submit():
        args = list(range(10))
        mw.submit(print, sizeof_fmt)
        mw.submit(print, sizeof_fmt)
        m

# Generated at 2022-06-12 15:06:03.510475
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def helper_func(i):
        time.sleep(0.1)
        return i

    def test():
        mw = MonoWorker()
        mw.submit(helper_func, 1)
        time.sleep(0.05)
        mw.submit(helper_func, 2)
        time.sleep(0.05)
        mw.submit(helper_func, 3)
        time.sleep(0.2)
        assert mw.futures[0].result() == 3
        assert mw.futures[1].result() == 3

    test()

# Generated at 2022-06-12 15:06:08.508127
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import choice
    from threading import Lock

    N = 1000
    K = 100

    with tqdm_auto.tqdm(total=N, desc="test") as pbar:
        def worker(name):
            sleep(choice(range(K)))
            pbar.update(1)

        mw = MonoWorker()
        while pbar.n <= N:
            mw.submit(worker, str(pbar.n))

# Generated at 2022-06-12 15:06:14.787711
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    worker = MonoWorker()
    i = 0
    assert len(worker.futures) == 0

    def task():
        global i
        i += 1
        time.sleep(0.1)

    for _ in range(5):
        worker.submit(task)
    assert len(worker.futures) == 1

    worker.submit(task)
    assert len(worker.futures) == 2

    worker.submit(task)
    assert len(worker.futures) == 2

    worker.submit(task)
    assert len(worker.futures) == 2

    worker.submit(task)
    assert len(worker.futures) == 2

    assert i == 0
    worker.futures[0].result()
    assert i == 1

# Generated at 2022-06-12 15:06:21.607825
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import threading
    import time

    def s(x):
        print("Thread id: %d. Waiting %d seconds. Random number: %d" % (
            threading.currentThread().ident, x, random.random()))
        time.sleep(x)

    # Create thread pool with only one worker thread
    worker = MonoWorker()
    # Submit 7 jobs to thread pool.
    for i in range(7):
        worker.submit(s, i)
        time.sleep(1)


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:06:29.380726
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import random
    from time import sleep
    from threading import Lock
    import traceback

    class Thread(object):
        """
        Locking thread-like object.
        """
        def __init__(self, lock):
            self.lock = lock

        def __enter__(self):
            self.lock.acquire()
            return self

        def __exit__(self, *args, **kwargs):
            self.lock._release()

        def delay(self, seconds):
            """
            Pause current thread-like object for `seconds` seconds.
            """
            sleep(seconds)
            return seconds

    with MonoWorker() as mono:
        with Lock() as lock:
            tqdm_auto.write("Attempting lock.acquire()")
            lock.acquire()


# Generated at 2022-06-12 15:06:39.241117
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    mw = MonoWorker()

    def log(*args):
        tqdm_auto.write(' '.join(map(str, args)))

    def wait(duration):
        log('> wait', duration)
        time.sleep(duration)
        log('< wait', duration)
        return duration

    # initial task is running
    mw.submit(wait, 0.1)
    log('first task submitted!')
    time.sleep(0.04)

    # second task is waiting
    mw.submit(wait, 0.1)
    log('second task submitted!')
    time.sleep(0.06)

    # third task is running, second task is discarded
    mw.submit(wait, 0.1)
    log('third task submitted!')
    time.sleep(0.1)
   

# Generated at 2022-06-12 15:06:40.716018
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=missing-docstring
    import time

    def test_func(*args, **kwargs):
        time.s

# Generated at 2022-06-12 15:06:43.335163
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from ..utils import _range

    mw = MonoWorker()
    for i in _range(10):
        mw.submit(sleep, random() * 3)