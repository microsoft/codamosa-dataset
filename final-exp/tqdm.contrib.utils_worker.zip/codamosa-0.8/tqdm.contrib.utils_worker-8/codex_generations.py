

# Generated at 2022-06-12 14:58:20.333496
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..contrib import _fallback_format_time as ft

    def slow_fib(a, b, sleep=0.05, print_marker=None):
        """
        Take a, b and return a + b.
        Sleep for sleep seconds to simulate slow computation.
        Print marker if given.
        """
        if print_marker is not None:
            print('%s: slow_fib(%d, %d) started' % (print_marker, a, b))
        time.sleep(sleep)
        if print_marker is not None:
            print('%s: slow_fib(%d, %d) done' % (print_marker, a, b))
        return a + b


# Generated at 2022-06-12 14:58:27.711843
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .counter import Counter
    from .monitor import LogMonitor

    def func(x):
        sleep(x)
        return x + 1

    counter = Counter()
    with LogMonitor(counter.para) as monitor:
        pool = MonoWorker()
        pool.submit(func, 1)
        pool.submit(func, 2)
        pool.submit(func, 3)
        pool.submit(func, 4)

    assert counter.value() == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-12 14:58:34.152685
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test that we can do a single submit
    from time import sleep
    from threading import Event, Thread
    from tqdm import tqdm
    from . import _ExtendedWait

    # tqdm.write redirects to stderr
    import sys
    tqdm.write = lambda *args, **kwargs: print(*args, **kwargs, file=sys.stdout)

    def get_queue(func, *args):
        from concurrent.futures import Future
        return {'result': Future.result, 'func': func, 'args': args}

    def task(ev, name, timeout):
        """Sleep for timeout seconds then print 'done' and set the event"""
        sleep(timeout)
        print(name)
        ev.set()
        return name


# Generated at 2022-06-12 14:58:43.684948
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import unittest
    import warnings

    class _TestMonoWorker(unittest.TestCase):
        def test_MonoWorker_submit(self):
            N = 100
            mw = MonoWorker()

            def blocking_f():
                time.sleep(1)
                return 0

            def blocking_f_wrong():
                time.sleep(1)
                raise ValueError("this is intentional")

            futures = [mw.submit(blocking_f)]
            for _ in range(N):
                futures.append(mw.submit(blocking_f))
            for f in futures:
                f.result()

            for _ in range(N):
                mw.submit(blocking_f_wrong)

            mw = MonoWorker()
            futures = []


# Generated at 2022-06-12 14:58:54.572821
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method `MonoWorker.submit`."""
    import time
    from concurrent.futures import as_completed
    import pytest

    mono_worker = MonoWorker()
    n = 5
    waiting_durations = range(n)  # [0, 1, 2...]
    running_duration = 1
    running_futures = []

    def task(duration):
        """Basic sleeping task."""
        time.sleep(duration)
        return duration

    for duration in waiting_durations:
        waiting_future = mono_worker.submit(task, duration)
        if duration == running_duration:
            running_futures.append(waiting_future)
        else:
            assert waiting_future.done()
            assert waiting_future.result() == duration

# Generated at 2022-06-12 14:59:02.505415
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    class TestClass(object):
        def __init__(self):
            self.lock = threading.Lock()
            self.call_counter = 0
            self.interrupt_after_time = None

        def func(self, *args, **kwargs):
            time.sleep(1)
            with self.lock:
                if self.interrupt_after_time:
                    time_left = self.interrupt_after_time - time.time()
                    if time_left <= 0:
                        self.call_counter += 1
                        self.interrupt_after_time = None
                        raise RuntimeError("Interrupting")
                self.call_counter += 1

    test = TestClass()
    worker = MonoWorker()
    assert test.call_counter == 0

# Generated at 2022-06-12 14:59:13.875153
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    s = 1.234  # time.sleep

    def sleep_then_return(t, out):
        time.sleep(t)
        return out

    f1 = mw.submit(sleep_then_return, s, 1)
    f2 = mw.submit(sleep_then_return, s, 2)
    f3 = mw.submit(sleep_then_return, s, 3)
    f4 = mw.submit(sleep_then_return, s, 4)
    f5 = mw.submit(sleep_then_return, s, 5)
    f6 = mw.submit(sleep_then_return, s, 6)

    assert (len(mw.futures) == 1)
    running = mw.futures.popleft

# Generated at 2022-06-12 14:59:24.500073
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import random

    def long_operation(arg):
        time.sleep(random()*5)
        return arg
    mw = MonoWorker()
    t = mw.submit(long_operation, 'a')
    status = t.status()
    assert (status == 'RUNNING') or (status == 'PENDING')
    t = mw.submit(long_operation, 'b')
    try:
        t.result(timeout=2)
        assert False, 'should have failed with timeout'
    except Exception:
        pass
    t = mw.submit(long_operation, 'c')
    try:
        t.result(timeout=2)
        assert False, 'should have failed with timeout'
    except Exception:
        pass

# Generated at 2022-06-12 14:59:30.295083
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from math import sqrt
    mw = MonoWorker()
    start_times = []
    lock = threading.Lock()
    for i in tqdm_auto.tqdm(range(50)):
        def task(i):
            with lock:
                start_times.append((i, time.time()))
            time.sleep(sqrt(i) * 0.1)
        mw.submit(task, i)
    for i in range(50):
        time.sleep(0.1)
    start_times.sort()
    st = [t[1] for t in start_times]
    assert len(start_times) > 0
    assert st[0] < st[-1]
    assert st[-1] - st[0] < 1.0

# Generated at 2022-06-12 14:59:40.067341
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    worker = MonoWorker()
    assert len(worker.futures) == 0

    def run_longer(delay):
        import time
        time.sleep(delay)

    def run_shorter(delay):
        import time
        time.sleep(delay)

    worker.submit(run_longer, 2)
    assert len(worker.futures) == 1
    worker.submit(run_shorter, 1)
    assert len(worker.futures) == 2
    worker.submit(run_shorter, 1)
    assert len(worker.futures) == 2
    worker.submit(run_shorter, 1)
    assert len(worker.futures) == 2
    worker.submit(run_shorter, 1)
    assert len(worker.futures) == 2

# Generated at 2022-06-12 14:59:50.931436
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from unittest import TestCase

    class MyTest(TestCase):
        def setUp(self):
            self.lock = Lock()
            self.worker = MonoWorker()
            self.n = 0
        def inc(self):
            self.n += 1
        def test_submit(self):
            self.assertEqual(self.worker.submit(self.inc), None)
            self.assertEqual(self.worker.submit(self.inc), None)
            sleep(0.1)
            self.assertEqual(self.n, 1)
    MyTest().test_submit()

# Generated at 2022-06-12 14:59:58.521431
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def worker(v, delay=0.0):
        from time import sleep
        sleep(delay)
        return v
    m = MonoWorker()

    # test substitution of waiting task
    v1 = m.submit(worker, 1, 0.1)
    m.submit(worker, 2, 0.2)
    assert v1.cancelled()  # v1 was cancelled
    v2 = m.submit(worker, 3, 0.3)
    assert v2.result() == 3  # v2 is still waiting

    # test substitution of running task
    v1 = m.submit(worker, 1, 0.5)
    v2 = m.submit(worker, 2, 0.1)
    assert v1.result() == 1  # v1 was re-inserted
    assert v2.cancelled()  # v

# Generated at 2022-06-12 15:00:06.788434
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def print_time_slept(n):
        sleep(n)
        print("time slept:", n)
        return n

    mw = MonoWorker()
    f1 = mw.submit(print_time_slept, 1)
    assert f1.result() == 1
    f2 = mw.submit(print_time_slept, 2)
    assert f2.result() == 2
    f3 = mw.submit(print_time_slept, 3)
    assert f3.result() == 3
    f4 = mw.submit(print_time_slept, 4)
    assert f4.result() == 4
    f5 = mw.submit(print_time_slept, 5)
    assert f5.result() == 5

# Generated at 2022-06-12 15:00:15.763787
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm.contrib import MonoWorker
    import threading
    from queue import Queue

    def throws(e):
        raise e

    # Test empty MonoWorker
    mw = MonoWorker()

    # Test first task
    q = Queue()
    threading.Thread(target=mw.submit, args=(q.put, 'ok')).start()
    assert q.get() == 'ok'

    # Test second task
    q = Queue()
    threading.Thread(target=mw.submit, args=(q.put, 'ok')).start()
    assert q.get() == 'ok'

    # Test third task (discards second task)
    q = Queue()

# Generated at 2022-06-12 15:00:17.409854
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import _thread

    def f(x):
        raise ValueError(x)

    def g(x):
        _thread.exit()

    m = MonoWorker()
    m.submit(f, 1)
    m.submit(f, 2)
    m.submi

# Generated at 2022-06-12 15:00:27.520990
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    rv = mw.submit(time.sleep, 0)
    time.sleep(0.1)
    assert rv.done()
    rv = mw.submit(time.sleep, 1)
    time.sleep(1)
    assert rv.done()
    rv = mw.submit(time.sleep, 2)
    time.sleep(0.1)
    assert not rv.done()
    rv = mw.submit(time.sleep, 3)
    time.sleep(0.1)
    assert not rv.done()
    time.sleep(2.2)
    assert rv.done()
    rv = mw.submit(time.sleep, 4)
    time.sleep(0.1)

# Generated at 2022-06-12 15:00:36.075301
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading as th
    mw = MonoWorker()
    lock = th.Lock()

    def _func(sleep, lock):
        with lock:
            print("enter %.3fs" % sleep)
        time.sleep(sleep)
        with lock:
            print("exit  %.3fs" % sleep)
        return sleep
    run_futures = dict()
    print("   0:", run_futures)
    run_futures[0.5] = mw.submit(_func, 0.5, lock)
    print("   2:", run_futures)
    run_futures[1.5] = mw.submit(_func, 1.5, lock)
    print("   3:", run_futures)

# Generated at 2022-06-12 15:00:42.225957
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    stdout = tqdm_auto.stdout
    tqdm_auto.stdout = None

# Generated at 2022-06-12 15:00:51.721745
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # noinspection PyUnresolvedReferences
    from contextlib import contextmanager
    from time import time, sleep
    from threading import current_thread

    @contextmanager
    def assert_equal(expected):
        """`with assert_equal(a): b` asserts `a == b`"""
        # print('assert_equal({})'.format(expected))
        yield
        # print('<assert_equal({})'.format(expected))
        assert expected == b

    @contextmanager
    def assert_true(expr):
        """`with assert_true(expr): ...` asserts `expr`"""
        yield
        assert bool(expr)

    @contextmanager
    def assert_false(expr):
        """`with assert_false(expr): ...` asserts `not expr`"""
        yield
        assert not bool(expr)


# Generated at 2022-06-12 15:01:00.079768
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    class FakePopen:
        """Fake Handle"""
        def __init__(self, o):
            self.o = o

        def communicate(self):
            time.sleep(1)
            return (str(self.o), "")

    class FakePopen2:
        """Fake Handle"""
        def __init__(self, o):
            self.o = o

        def communicate(self):
            time.sleep(3)
            return (str(self.o), "")

    def fake_shell_out(call1, call2):
        return FakePopen(call1), FakePopen2(call2)

    def job1():
        fake_shell_out("call1", "call2")

    def job2():
        fake_shell_out("call3", "call4")

    mw

# Generated at 2022-06-12 15:01:13.688194
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from collections import namedtuple
    import operator

    Result = namedtuple('Result', 'retval elapsed')

    # A multiprocessing-safe version of a function that returns the
    # given function's name and run time (in seconds).
    def func_wrapper(func, *args, **kwargs):
        import time
        start = time.time()
        retval = func(*args, **kwargs)
        elapsed = time.time() - start
        return Result(retval, elapsed)

    # A function that takes 1 second to execute and returns its name.
    def foo():
        sleep(1)
        return 'foo'

    # A function that takes 2 seconds to execute and returns its name.
    def bar():
        sleep(2)
        return 'bar'


# Generated at 2022-06-12 15:01:21.572738
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def foo(sleep_time):
        sleep(sleep_time)
        return sleep_time

    worker = MonoWorker()
    future1 = worker.submit(foo, 0.5)
    assert future1.result() == 0.5, 'test 1 failed'
    future2 = worker.submit(foo, 0.3)  # waiting
    assert future2.result() == 0.3, 'test 2 failed'
    future3 = worker.submit(foo, 0.4)
    assert future3.result() == 0.4, 'test 3 failed'

# Generated at 2022-06-12 15:01:31.825752
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from functools import partial
    from collections import deque
    from unittest.mock import Mock

    exec_queue = deque()
    ret_queue = deque()
    future = Mock()

    def _exec(*a):
        exec_queue.append(a)
        if len(ret_queue):
            r = ret_queue.popleft()
        else:
            r = None  # to simulate a failure
        return r

    def _submit(f, *a):
        future.result.side_effect = partial(f, a)
        return future

    def _done():
        return False

    def _result():
        return ('done', True)

    def _cancel():
        pass

    _submit.side_effect = _submit

# Generated at 2022-06-12 15:01:39.205446
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, sys

    def long_func():
        time.sleep(1)
        return "Some result"

    def short_func():
        return "Some other result"

    def res_pending(res):
        print('.', end='', file=sys.stderr)
        return not res.done()

    def res_waiting(res):
        return res.done() and res.result() == "Some result"

    # Imports are local to allow running `test_MonoWorker_submit` from command-line
    from concurrent.futures import as_completed
    from multiprocessing import TimeoutError
    from threading import Thread

    worker = MonoWorker()
    # Running
    res = worker.submit(long_func)
    # Waiting

# Generated at 2022-06-12 15:01:49.724329
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    import tqdm.contrib
    # Monkey-Patching
    prev_Update = tqdm.contrib.setup_or_update
    def tqdm_update(w, *args, **kwargs):
        if w.interrupted:
            raise KeyboardInterrupt
        elif w.cancelled:
            raise Exception('Task canceled')
        elif w.skipped:
            raise Exception('Task skipped')
        prev_Update(w, *args, **kwargs)
    tqdm.contrib.setup_or_update = tqdm_update

    def assert_eq(a, b):
        assert a == b, '{} != {}'.format(a, b)


# Generated at 2022-06-12 15:01:56.927588
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import unittest
    import numpy as np
    from concurrent.futures import as_completed

    class MonoWorkerTest(unittest.TestCase):
        def test1(self):
            """Test non-concurrency."""
            mw = MonoWorker()
            fut12 = mw.submit(time.sleep, 0.12)
            fut34 = mw.submit(time.sleep, 0.34)
            for _ in tqdm_auto.tqdm(as_completed([fut12]), unit="fut"):
                break
            self.assertFalse(fut12.done())
            for _ in tqdm_auto.tqdm(as_completed([fut34]), unit="fut"):
                break
            self.assertFalse(fut34.done())

# Generated at 2022-06-12 15:02:04.189518
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from traceback import format_exc
    from warnings import warn

    def print_sleep(x, t):
        print('{} sleeping for {:.2f} secs'.format(x, t))
        sleep(t)
        print('{} done'.format(x))

    def run_test(test_name, input, output):
        worker = MonoWorker()
        for tup in input:
            worker.submit(print_sleep, *tup)
            sleep(0.01)
        sleep(1)

        try:
            assert [f.result() for f in worker.futures] == output
        except Exception as e:
            warn('Test {} failed\n{}'.format(test_name, format_exc()))

# Generated at 2022-06-12 15:02:09.434886
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import current_thread
    from time import sleep

    def func(val):
        sleep(1)
        return val

    mf = MonoWorker()
    futures = []
    for i in range(10):
        futures.append(mf.submit(func, i, thread=current_thread().name))
    for future in futures:
        print(future.result())

# Generated at 2022-06-12 15:02:17.989769
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    # Note: this is a unit test and not a doctest because it needs to run
    #   slow tasks concurrently and stdout is captured by "nosetests" but not
    #   by "python" (which uses doctest)

    def slow_factorial(n):
        time.sleep(n * 0.1)
        if n < 1:
            return 1
        return n * slow_factorial(n - 1)

    worker = MonoWorker()

    assert 0 == worker.pool.running()

    p1, p2 = worker.submit(slow_factorial, 3), worker.submit(slow_factorial, 2)
    time.sleep(0.1)
    assert 1 == worker.pool.running()
    assert 0 == p2.done()
    assert 3 == p1.result()

    p3,

# Generated at 2022-06-12 15:02:27.231212
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ._utils import _range
    from threading import Lock
    lock = Lock()

    def worker(num):
        with lock:
            tqdm_auto.write('Started worker #{}'.format(num))
            time.sleep(0.5)
        return 'Returned from worker #{}'.format(num)

    mw = MonoWorker()
    for i in _range(10):
        with lock:
            tqdm_auto.write('Submitted worker #{}'.format(i))
        future = mw.submit(worker, i)
        # Prints the return value of the worker upon completion
        if future is not None:
            print(future.result())

# Generated at 2022-06-12 15:02:45.721511
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from unittest import TestCase

    class DummyException(Exception):
        pass

    def dummy_func(a, i, interval=0.3,
                   raise_exc=False,
                   raise_exc_finished_task=False,
                   raise_exc_discard_task=False,
                   raise_exc_exchange_task=False):
        if raise_exc:
            raise DummyException()
        sleep(interval)
        if raise_exc_finished_task:
            raise DummyException()
        if raise_exc_discard_task:
            raise DummyException()
        if raise_exc_exchange_task:
            raise DummyException()
        return (a, i)


# Generated at 2022-06-12 15:02:52.601964
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing
    import time

    def sleeper(duration):
        time.sleep(duration)
        return duration

    mw = MonoWorker()

    #   +---+---+---+
    #   | S | W | F |
    #   +---+---+---+
    #   ∩____|___|___|
    #       ∩____|___|
    #           ∩____|
    #               ∩
    #               T
    #
    # S: Submit
    # W: Waiting
    # F: Finished

    # Long-lasting task starts immediately
    S = time.time()
    F = mw.submit(sleeper, 5).result()
    T = time.time()
    assert 1 < F == T - S < 5

    # Short-lasting task starts after long-lasting task finishes


# Generated at 2022-06-12 15:03:01.852422
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import random
    from six.moves import input as raw_input

    def worker(i, r):
        time.sleep(r)
        sys.stdout.write('{} finished!\n'.format(i))

    mw = MonoWorker()
    rnd = random.Random(1)

    while True:
        i = raw_input('Task {} > '.format(len(mw.futures)))
        if i.strip() == 'quit':
            break
        if i.strip() == '':
            continue
        mw.submit(worker, i, rnd.random()*10)

# Generated at 2022-06-12 15:03:09.012830
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import cpu_count
    from concurrent.futures import as_completed
    from contextlib import closing

    number_of_workers = cpu_count() + 1

    def busy_waiting(seconds, id_):
        sleep(seconds)
        return id_

    def submit_waiting(mono_worker, seconds, id_):
        future = mono_worker.submit(busy_waiting, seconds, id_)
        # None if not waitable
        return id_ if future is None else future.result()

    with closing(MonoWorker()) as mono_worker, \
            closing(ThreadPoolExecutor(max_workers=number_of_workers)) as pool:
        futures = deque([], number_of_workers + 1)

# Generated at 2022-06-12 15:03:17.746529
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Lock
    from time import sleep
    from unittest import TestCase

    from ..utils import _range

    def is_sorted(l):
        return all(l[i] <= l[i+1] for i in _range(len(l) - 1))

    class MonoWorkerTest(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.results = list()
            self.lock = Lock()

        def test_submit1(self):
            n = 5
            with tqdm_auto.tqdm(desc='test_submit1', total=n) as t:
                for i in range(n):
                    self.mw.submit(sleep, 0.1)
                    with self.lock:
                        self.results.append(i)
                   

# Generated at 2022-06-12 15:03:22.739567
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import traceback
    from ..utils import _term_move_up

    def caller(work, i):
        time.sleep(1)
        try:
            print(i)
        finally:
            _term_move_up()

    work = MonoWorker()
    for i in range(10):
        work.submit(caller, work, i)
        try:
            work.futures[-1].result()
        except Exception:
            traceback.print_exc()

# Generated at 2022-06-12 15:03:28.542929
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import os
    import sys
    import time

    from .common import ThreadWithReturn

    worker = MonoWorker()

    def test_func(i):
        time.sleep(0.1)
        return i ** 2

    def wait_until_ready(f):
        """Wait until all jobs submitted before this job are done."""
        while len(worker.futures) > 1:  # not the last submitted
            if not worker.futures[1].done():
                time.sleep(0.03)
            else:
                worker.futures.popleft()  # clear done

    f1 = worker.submit(test_func, 1)
    f2 = worker.submit(test_func, 2)
    time.sleep(0.03)
    f3 = worker.submit(test_func, 3)



# Generated at 2022-06-12 15:03:35.380763
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    future1 = mw.submit(time.sleep, 0.5)
    future2 = mw.submit(time.sleep, 0.5)
    future3 = mw.submit(time.sleep, 0.5)
    assert future1 == future2
    assert future2 != future3
    assert future1.running()
    assert future3.running()
    assert not future3.done()
    time.sleep(1)
    assert future1.done()
    assert future2.done()
    assert future3.done()

# Generated at 2022-06-12 15:03:37.544585
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    import time

    # Fake threading events
    running = Event()
    waiting = Event()

    # Define an example worker function
    def worker():
        running.set()

    

# Generated at 2022-06-12 15:03:40.683028
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import current_thread

    def consume_time(n):
        sleep(n)

    m = MonoWorker()
    for i in [1, 2, 3, 4, 5]:
        print(m.submit(consume_time, i))
        print(current_thread())

# Generated at 2022-06-12 15:04:02.715128
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    # import pdb; pdb.set_trace()
    def f(n):
        time.sleep(n)
        # raise Exception("failed")
        return "hi " + str(n)
    mw = MonoWorker()
    for i in range(5, 0, -1):
        mw.submit(f, i)
    for i in range(5):
        time.sleep(0.25)
        print("futures:", mw.futures)

# Generated at 2022-06-12 15:04:06.997323
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import random

    def f(i):
        sleep(random.random() / 2)
        return i * 10

    queue = MonoWorker()

    # test that running task is preserved
    for i in range(4):
        queue.submit(f, i)

    sleep(2.5)
    assert queue.futures[0].result() == 40, "Running task was discarded"
    assert len(queue.futures) == 1, "Too many waiting tasks"

    # test that only latest waiting task is preserved
    for i in range(4, 8):
        queue.submit(f, i)

    sleep(0.5)
    assert queue.futures[0].result() == 60, "Wrong waiting task was preserved"

# Generated at 2022-06-12 15:04:17.642023
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..tqdm_gui import tqdm_gui  # import here to avoid tkinter issues
    import threading
    import sys
    import os
    import re

    def run_sleep_print(i, pause=0.1, stdout='', stderr=''):
        time.sleep(pause)
        with open(stdout, 'a') as f:
            f.write(str(i))
        with open(stderr, 'a') as f:
            f.write(str(i))
        return i

    def catch_output(stdout='', stderr=''):
        with open(stdout, 'w') as f:
            f.write('')
        with open(stderr, 'w') as f:
            f.write('')
        return std

# Generated at 2022-06-12 15:04:26.093116
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 15:04:34.085661
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    # Test case function count_to
    def count_to(n):
        """Sleep 0.5 sec per integer, return number of integers"""
        for i in range(n):
            sleep(0.5)
        return n

    # Test case input
    rands = [1, 5, 4]
    # Expected results
    results = [5, 5, 4]

    # Initialize test case
    mw = MonoWorker()
    jobs = []
    # Execute test case
    for n in rands:
        jobs.append(mw.submit(count_to, n))
    # Check results
    for job, result in zip(jobs, results):
        assert job.result() == result

# Generated at 2022-06-12 15:04:41.578724
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def worker(text, delay):
        time.sleep(delay)
        print(text)

    print("Start test")
    mw = MonoWorker()
    mw.submit(worker, 'First', 0.1)
    mw.submit(worker, 'Second', 0.1)
    mw.submit(worker, 'Third', 0.1)
    threading.Thread(target=mw.submit, args=('First', 0.1)).start()
    threading.Thread(target=mw.submit, args=('Second', 0.1)).start()
    threading.Thread(target=mw.submit, args=('Third', 0.1)).start()

    print("End test")

# Generated at 2022-06-12 15:04:48.126678
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()

    # Check that nothing breaks when no running task (ex: after init)
    mono_worker.submit(lambda: 1)
    assert len(mono_worker.futures) == 1

    # Check that nothing breaks when no waiting task
    mono_worker.submit(lambda: 1)
    assert len(mono_worker.futures) == 1

    # Check that nothing breaks when no running task
    mono_worker.futures.pop().set_result(None)
    mono_worker.submit(lambda: 1)
    assert len(mono_worker.futures) == 1

    # Check that waiting task is replaced by running task
    mono_worker.submit(lambda: 1)
    assert len(mono_worker.futures) == 1

# Generated at 2022-06-12 15:04:55.899714
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..auto import tqdm as tqdm_auto
    from time import sleep
    from queue import Empty, Queue
    from traceback import format_exc
    from concurrent.futures import ThreadPoolExecutor, Future

    def f(task, to_cancel, result_q, exc_q, time=0.01, result=True, fail=False):
        if fail:
            raise Exception('fail')
        elif to_cancel.get():
            to_cancel.put(False)
            raise Exception('cancelled')
        else:
            sleep(time)
            if result is not None:
                result_q.put(result)
        return task


# Generated at 2022-06-12 15:05:02.071686
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # queue up some tasks
    q = MonoWorker()
    import inspect
    import random
    import time

    def wait(n):
        s = 0
        for _ in range(n):
            s += random.random()
            time.sleep(0.5)
        return s

    input_1 = [1, 2, 3]
    input_2 = [4, 5, 6]
    input_3 = [7, 8, 9]
    assert len(tuple(filter(inspect.isfunction, locals().values()))) > 0
    # this waits for the tasks in the queue to complete
    for i in input_1:
        q.submit(wait, i)
    for i in input_2:
        q.submit(wait, i)

# Generated at 2022-06-12 15:05:08.858276
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from concurrent.futures import ThreadPoolExecutor
    from contextlib import closing

    stop = False

    def long_task():
        sleep(1)
        return 'long'

    def short_task():
        sleep(0.001)
        return 'short'

    def thread_test(test_func, expected, stop_event=None):
        stop_event = Event() if stop_event is None else stop_event
        test_thread = ThreadPoolExecutor(max_workers=1)
        with closing(test_thread):
            pbar = test_func()
            short = test_thread.submit(short_task)
            long = test_thread.submit(long_task)
            sleep(0.002)  # wait for long_task to finish and clear waiting queue


# Generated at 2022-06-12 15:05:45.585046
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .tests import test_MonoWorker_submit
    return test_MonoWorker_submit(MonoWorker)

# Generated at 2022-06-12 15:05:53.685254
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from multiprocessing import Event

    ev = Event()
    def wait(timeout):
        ev.wait(timeout)
        return "OK " + str(timeout)

    mw = MonoWorker()
    for i in range(5):
        tqdm_auto.write("{0}.1: {1}".format(i, mw.submit(wait, i).result()))
        time.sleep(1)
        tqdm_auto.write("{0}.2: {1}".format(i, mw.submit(wait, i).result()))
        time.sleep(1)
        tqdm_auto.write("{0}.3: {1}".format(i, mw.submit(wait, i).result()))
        ev.set()
        ev.clear()

# Generated at 2022-06-12 15:06:03.590297
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from nose2 import tools

    def sleep_1():
        time.sleep(1)

    def sleep_2():
        time.sleep(2)

    def sleep_3():
        time.sleep(3)

    m = MonoWorker()
    tools.eq_(True, m.submit(sleep_1).done())
    tools.assert_not_isinstance(m.submit(sleep_2), type(None))

    # wait for the sleep_2() task to finish
    time.sleep(3)
    tools.assert_not_isinstance(m.submit(sleep_3), type(None))
    tools.assert_not_isinstance(m.submit(sleep_2), type(None))


# Generated at 2022-06-12 15:06:11.407813
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def echo(delay, msg):
        time.sleep(delay)
        tqdm_auto.write(msg)

    def random_delay(i):
        delay = random.random()
        msg = "i={0} delay={1:.2f}".format(i, delay)
        echo(delay, msg)

    start = time.time()
    mono = MonoWorker()
    for i in range(100):
        mono.submit(random_delay, i)
        assert len(mono.futures) == 1
        assert mono.futures[0].running() == (i == 0)
    mono = MonoWorker()
    assert mono.submit(echo, 0.5, 'ho') is None

# Generated at 2022-06-12 15:06:13.726983
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm import trange

    def track(mw, i):
        for _ in trange(100, desc='thread-{}'.format(i), leave=False):
            sleep(0.01)

    mw = MonoWorker()
    for i in range(6):
        mw.submit(track, mw, i)

# Generated at 2022-06-12 15:06:22.807819
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(delay, arg):
        time.sleep(delay)
        return 'f({}, {})'.format(delay, arg)

    mw = MonoWorker()
    assert mw.submit(f, 1, 'a') == None
    time.sleep(0.1)
    assert mw.submit(f, 2, 'b') == None
    time.sleep(1.5)
    assert mw.submit(f, 3, 'c') == None
    time.sleep(2.5)
    assert mw.futures[0].result() == 'f(2, b)'
    assert mw.futures[1].result() == 'f(3, c)'
    # with 4 workers, 2 slow and 2 fast
    mw = MonoWorker()

# Generated at 2022-06-12 15:06:26.547110
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def wait(t):
        time.sleep(t)

    worker = MonoWorker()
    worker.submit(wait, 0.1)
    worker.submit(wait, 0.1)
    assert len(worker.futures) == 1
    worker.submit(wait, 0.1)
    assert len(worker.futures) == 1

# Generated at 2022-06-12 15:06:30.723942
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..auto import tqdm
    # Create a MonoWorker
    worker = MonoWorker()
    # Create a Progress bar
    t = tqdm(desc="Testing MonoWorker", total=10)
    # Method loop
    for i in range(10):
        # Create the future task
        worker.submit(time.sleep, 1)
        t.update(1)
    # Close
    t.close()

# Generated at 2022-06-12 15:06:36.415714
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(x):
        import time
        time.sleep(x)
        return x
    m = MonoWorker()
    futures = []
    for i in range(3):
        futures.append(m.submit(f, i))
    for i in range(len(futures)):
        assert futures[i].result() == i



# Generated at 2022-06-12 15:06:44.195823
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def f(event):
        event.wait()

    e1 = Event()
    e2 = Event()
    e3 = Event()

    mw = MonoWorker()

    with tqdm_auto.tqdm() as t:
        f1 = mw.submit(f, e1)
        f2 = mw.submit(f, e2)
        f3 = mw.submit(f, e3)

        sleep(0.01)
        e1.set()
        sleep(0.01)
        assert f1.done()
        sleep(0.01)
        e2.set()
        sleep(0.01)
        assert f2.done()

        # f3 should be canceled when the following line is invoked,
        # and the reason

# Generated at 2022-06-12 15:08:10.638948
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Process

    def run(mw):
        """Spawn a subprocess to submit functions to `mw`."""
        def printer(n):
            print('updating')
            return n
        for i in range(5):
            mw.submit(printer, i)
            sleep(.5)

    mw = MonoWorker()
    p = Process(target=run, args=(mw,))
    p.start()