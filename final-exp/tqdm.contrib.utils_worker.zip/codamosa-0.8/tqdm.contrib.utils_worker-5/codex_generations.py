

# Generated at 2022-06-12 14:58:15.430258
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import unittest

    def f(x):
        time.sleep(0.1)
        return str(x)

    def f_exc(x):
        raise RuntimeError("This is a test")

    class Test(unittest.TestCase):
        def test_submit(self):
            m = MonoWorker()
            self.assertEqual(m.submit(f, 1).result(), "1")
            self.assertEqual(m.submit(f, 2).result(), "2")
            self.assertEqual(m.submit(f, 3).result(), "3")

        def test_submit_exc(self):
            m = MonoWorker()
            m.submit(f_exc, 1)

        def test_submit_cancel(self):
            m = MonoWork

# Generated at 2022-06-12 14:58:20.696070
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from numpy import random

    def run_task():
        rand = random.rand(1000)
        for i in range(len(rand)):
            sleep(rand[i] * 0.1)

    mw = MonoWorker()

    def run_task_n_times(n):
        buf = []
        for i in range(n):
            buf.append(mw.submit(run_task))
        for i in range(n):
            buf[i].result()

    run_task_n_times(3)

# Generated at 2022-06-12 14:58:30.370797
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from contextlib import closing
    import time
    from .utils import _test_throw_exception
    with closing(MonoWorker()) as worker:
        t0 = time.time()
        with tqdm_auto.trange(8, desc='Elapsed', ascii=True) as t:
            for i in t:
                if worker.futures and worker.futures[0].done():
                    worker.futures.popleft()
                if i == 0:
                    worker.submit(time.sleep, 0.05)  # long-time running
                elif i == 1:
                    worker.submit(time.sleep, 0.02)  # discardable
                elif i == 2:
                    worker.submit(time.sleep, 0.03)  # discardable

# Generated at 2022-06-12 14:58:38.756382
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # TODO: use pytest
    import time

    # Define function to task
    def f(i):
        time.sleep(i)
        return i * 10

    # Initialise class and submit function
    m = MonoWorker()
    w = m.submit(f, 1)
    time.sleep(0.2)
    v = m.submit(f, 2)
    time.sleep(0.1)
    u = m.submit(f, 3)
    time.sleep(0.1)
    t = m.submit(f, 4)
    time.sleep(0.1)
    s = m.submit(f, 5)
    time.sleep(0.1)
    r = m.submit(f, 6)
    time.sleep(0.1)

# Generated at 2022-06-12 14:58:46.971065
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 14:58:57.836315
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test method submit of class MonoWorker.
    """
    import time
    MonoWorker = tqdm_auto.tqdm.contrib.MonoWorker
    MonoWorker.submit = __import__('inspect').getargspec(MonoWorker.submit)

    def func(a, b, c):
        """Submitted function with side-effect on globals."""
        assert not globals()['running'], "running should be false"
        globals()['waiting'] = True
        for i in range(a):
            time.sleep(b)
        return c

    def add_tests(tests, *args, **kwargs):
        """Add tests for a range of arguments."""

# Generated at 2022-06-12 14:59:07.659951
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import time
    from ..auto import trange, tqdm

    mw = MonoWorker()

    results = []

    def set_result():
        time.sleep(0.1)
        results.append(1)

    def set_error():
        1 + '1'  # pylint: disable=pointless-statement

    def wait_all(args):
        """Wait for all to finish."""
        for arg in args:
            arg.result()

    args = [None] * 9 + [(set_result,), (set_error,)]
    with trange(len(args), leave=False) as t:
        t.set_description('Unit test for method submit of class MonoWorker')
        t.update = lambda x: results.append(x)

# Generated at 2022-06-12 14:59:16.508378
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from traceback import format_exc
    from random import choice as rc, randrange

    def task(i, v):
        print('Task {} started, sleeping for {} seconds...'.format(i, v))
        sleep(v)
        return i

    def run_test():
        for _ in range(4):

            worker = MonoWorker()
            print('\n===== NEW WORKER =====\n')
            
            tasks = [(i, randrange(3, 6)) for i in range(10)]
            while tasks:
                
                i, v = tasks.pop(rc(range(len(tasks))))
                f = worker.submit(task, i, v)

                print('Task {} submitted'.format(i))


# Generated at 2022-06-12 14:59:26.676033
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    from multiprocessing import Event
    from threading import Thread
    from time import sleep

    def worker(task_id, secs=1, block_event=None):
        if block_event is not None:
            block_event.wait()
        sleep(secs)
        print("task %s finished" % task_id)

    worker_state = [0]  # worker_done, worker_done_event
    def worker_done():
        worker_state[0] = 1
        worker_state[1].set()


# Generated at 2022-06-12 14:59:36.245327
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def mock_func(time_to_sleep):
        time.sleep(time_to_sleep)
        return time_to_sleep

    mock_work_times = [0.2, 0.1, 0.15, 0.2, 0.4]
    worker = MonoWorker()
    for work_time in mock_work_times[:-1]:
        submit = worker.submit(mock_func, work_time)
        assert submit.done()
        assert submit.result() == work_time
        time.sleep(random.random() / 10)

    r1 = worker.submit(mock_func, mock_work_times[-2]).result()
    time.sleep(mock_work_times[-2] * 2)

# Generated at 2022-06-12 14:59:46.538903
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    class Worker(MonoWorker):
        """Stub (for testing)"""
        def __init__(self):
            super(Worker, self).__init__()
            self.op_reset()

        def op_reset(self):
            self.was_set = []
            self.was_got = []

        def was_done(self, *args):
            """Check if the worker has done a certain operation"""
            return args in self.was_set

        def op_set(self, *args):
            """Placeholder for testing"""
            sleep(0.1)  # Emulate a long operation
            self.was_set.append(args)
            return args

        def op_get(self, *args):
            """Placeholder for testing"""
            sleep(0.1)  # Em

# Generated at 2022-06-12 14:59:55.825050
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import as_completed

    def my_func(x):
        sleep(x)
        return x

    MW = MonoWorker()
    assert MW.futures == deque([], 2)
    f1 = MW.submit(my_func, 0.6)
    assert MW.futures == deque([f1], 2)
    f2 = MW.submit(my_func, 0.4)
    assert len(MW.futures) == 2
    assert as_completed([f1, f2]) == [f2, f1]
    assert MW.futures == deque([f2, f1], 2)
    f3 = MW.submit(my_func, 0.5)
    assert len(MW.futures) == 2

# Generated at 2022-06-12 15:00:05.096141
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from contextlib import closing
    from threading import Lock
    from ..utils import format_sizeof
    from ..utils import format_interval

    # Create a dummy class that simulates a ThreadPoolExecutor
    # with an explicit lock
    class DummyPoolExecutor(object):
        def __init__(self, lock):
            self.lock = lock

        def submit(self, func, *args, **kwargs):
            self.lock.acquire()

            print("executing...")
            # Sleep for 5 second to simulate a doing work
            time.sleep(5)

            self.lock.release()
            return func(*args, **kwargs)

    # Create a lock
    lock = Lock()

    # Create a MonoWorker with a dummy ThreadPoolExecutor with lock
    worker = MonoWorker()
   

# Generated at 2022-06-12 15:00:11.068593
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    n = 5
    execs = n // 3  # execute n/3 tasks postponed
    execs = min(execs, 1)
    x = MonoWorker()

    def do_work(i):
        x = random()
        sleep(1)
        return x

    for i in range(n):
        tqdm_auto.write("Submitting task {0}".format(i))
        x.submit(do_work, i)
        if i >= execs:
            tqdm_auto.write("Waiting for task {0}".format(i - execs))
            x.futures[0].result()
    tqdm_auto.write("Waiting for all the remaining tasks")

# Generated at 2022-06-12 15:00:18.785966
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import string
    import time
    from threading import Thread
    from queue import Queue
    from concurrent.futures import as_completed

    # seed randomness
    random.seed(0)

    # setup
    charset = string.ascii_letters + string.digits
    qsize = 10
    record = []
    queue = Queue()
    def producer():
        for i in tqdm_auto.trange(qsize, desc='producer'):
            time.sleep(0.5)
            if i < (qsize - 1):
                record.append(''.join(random.choice(charset) for j in range(4)))
            else:
                record.append(None)  # exception
            queue.put(i)


# Generated at 2022-06-12 15:00:29.079254
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.mono = MonoWorker()
            self.lock = threading.Lock()
            self.job_ids = []

            def job(self, jid):
                with self.lock:
                    self.job_ids.append(jid)
                time.sleep(.01)

        def tearDown(self):
            self.mono.pool.shutdown()
            self.lock.acquire()
            for jid in self.job_ids:
                if jid is None:
                    continue
                self.assertFalse(jid % 3, jid)
            self.lock.release()

        def test_submit(self):
            futures = []

# Generated at 2022-06-12 15:00:37.255902
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import as_completed

    def func_a():
        func_a.lock.acquire(True)
        func_a.lock.release()
        raise Exception("we need to get rid of this")

    def func_b():
        func_b.lock.acquire(True)
        func_b.lock.release()

    func_a.lock = Lock()
    func_b.lock = Lock()

    worker = MonoWorker()
    # submit the first task (task a)
    func_a.lock.acquire(True)
    worker.submit(func_b)
    worker.submit(func_a)
    worker.submit(func_b)
    func_a.lock.release()

    # wait for the first task (

# Generated at 2022-06-12 15:00:44.947508
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import traceback
    def func(*args, **kwargs):
        time.sleep(0.5)
        raise Exception(*args, **kwargs)
    # 1
    executor = MonoWorker()
    future1 = executor.submit(func, "testing 1")
    future2 = executor.submit(func, "testing 2")
    try:
        future1.result()
    except Exception:
        tb = sys.exc_info()[2]
        tqdm_auto.write(repr(traceback.format_exception_only(type(tb), tb)))
        tqdm_auto.write(repr(traceback.format_tb(tb)))
    try:
        future2.result()
    except Exception:
        tb = sys.exc_

# Generated at 2022-06-12 15:00:54.554949
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from multiprocessing import Process

    mobj = MonoWorker()

    def test_fun(arg):
        """Intentionally slow function."""
        time.sleep(arg)
        return arg

    def tester():
        """Test asynchronous execution of MonoWorker."""
        def submitter():
            """Submit tasks."""
            mobj.submit(test_fun, 0.3)
            mobj.submit(test_fun, 0.1)
            time.sleep(0.1)
            mobj.submit(test_fun, 0.5)
            mobj.submit(test_fun, 0.2)
            time.sleep(0.2)
            mobj.submit(test_fun, 0.7)
            mobj.submit(test_fun, 0.4)

# Generated at 2022-06-12 15:01:02.466044
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Thread
    from multiprocessing import Process
    from concurrent.futures import Future
    m = MonoWorker()

    # test simple no blocking task
    start = time.time()
    f = m.submit(time.sleep, 0)
    assert f.done()
    end = time.time()
    assert end-start > 0

    # test blocking task
    start = time.time()
    f = m.submit(time.sleep, 3)
    assert f.done() is False
    assert m.futures[0] is f
    end = time.time()
    assert end-start > 0

    # test cancel running
    start = time.time()
    f = m.submit(time.sleep, 3)
    assert f.done() is False
    f2 = m

# Generated at 2022-06-12 15:01:15.118121
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import functools
    import sys
    import time

    from .utils import FakeTQDM

    def run(func, length, sleep_time, count, delta_time):
        try:
            with FakeTQDM(total=count) as faketqdm:
                with tqdm_auto(total=count, file=sys.stderr) as pbar:
                    for i in range(count):
                        func(length, sleep_time)
                        time.sleep(delta_time)
                        pbar.update(1)
                        faketqdm.update(1)
        except Exception as e:
            tqdm_auto.write(str(e))

    def test(length, sleep_time=0.01, count=6, delta_time=0.01):
        from .utils import get_thread_

# Generated at 2022-06-12 15:01:21.753874
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    from time import sleep

    def wait(wait_time, func, *args, **kwargs):
        """
        Sleep for `wait_time` seconds, then `func(*args, **kwargs)`.
        """
        result = wait_time
        sleep(wait_time)
        if func:
            result = func(*args, **kwargs)
        return result

    # Initialize
    worker = MonoWorker()
    future_finished = Event()

    # Placeholder
    expected = "placeholder"
    future = worker.submit(lambda: expected)
    assert future.result() == expected
    assert future_finished.is_set()

    # Submit 1
    future_finished.clear()
    expected = 5
    future = worker.submit(wait, expected, future_finished.set)

# Generated at 2022-06-12 15:01:25.710363
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from six import print_
    from unittest import TestCase

    class Test(TestCase):
        def test(self):
            mw = MonoWorker()
            sleep_duration = 0.01  # seconds
            echo_str = "hello world"
            expected_str = echo_str + "\n"

            def echo(sleep_duration, echo_str):
                sleep(sleep_duration)
                return echo_str

            result = mw.submit(echo, sleep_duration, echo_str)
            result.result()  # wait for the result
            with tqdm_auto.trange(2):
                # Make sure that no result is printed if cancelled
                result = mw.submit(echo, sleep_duration, echo_str)
                result.cancel()
            # Print the second result
           

# Generated at 2022-06-12 15:01:35.553807
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import unittest

    class FailingWorker(object):
        """Simulate a worker that fails when given too many arguments."""
        def __init__(self, max_args=1):
            self.max_args = max_args

        def __call__(self, *args):
            if len(args) > self.max_args:
                raise ValueError("Too many arguments! {0}".format(args))

    class Callback(object):
        """Monkey-patch sys.stdout to collect printed messages."""
        lines = []
        def write(self, msg):
            self.lines.append(msg)

    class TestMonoWorker(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(TestMonoWorker, self).__

# Generated at 2022-06-12 15:01:41.003841
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from functools import partial

    def func0(*args, **kwargs):
        time.sleep(0.1)
        return 10

    def func1(*args, **kwargs):
        time.sleep(0.1)
        return 20

    def func2(*args, **kwargs):
        time.sleep(0.1)
        return 30

    def func3(*args, **kwargs):
        time.sleep(0.1)
        return 40

    def func4(*args, **kwargs):
        time.sleep(0.1)
        return 50

    def func5(*args, **kwargs):
        time.sleep(0.1)
        return 60

    def func6(*args, **kwargs):
        time.sleep(0.1)
        return 70


# Generated at 2022-06-12 15:01:45.274803
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def foo():
        time.sleep(0.2)
        return 5

    m = MonoWorker()
    e1, e2 = m.submit(foo), m.submit(foo)
    assert e1.result() == e2.result() == 5
# /test



# Generated at 2022-06-12 15:01:52.696128
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys, time

    def myfunc(x, y):
        time.sleep(0.1)
        return x + y

    def print_myfunc(x, y):
        print(myfunc(x, y))

    # -- test with print
    mono_worker = MonoWorker()
    print("\nTest submit with print():")
    mono_worker.submit(print_myfunc, 1, y=2)
    mono_worker.submit(print_myfunc, 2, y=3)
    mono_worker.submit(print_myfunc, 3, y=4)
    time.sleep(0.2)
    mono_worker.submit(print_myfunc, 4, y=5)
    mono_worker.submit(print_myfunc, 5, y=6)
    time.sleep(0.2)


# Generated at 2022-06-12 15:02:01.253369
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import pytest
    m = MonoWorker()
    with pytest.raises(TypeError):
        m.submit(4)
    r1 = m.submit(time.sleep, 0.01)
    with pytest.raises(AttributeError):
        m.submit([], 4)
    m.submit(time.sleep, 0.1)
    m.submit(time.sleep, 0.1)
    m.submit(time.sleep, 0.1)
    m.submit(time.sleep, 0.1)
    m.submit(time.sleep, 0.1)
    m.submit(time.sleep, 0.1)
    m.submit(time.sleep, 0.1)
    m.submit(time.sleep, 0.1)

# Generated at 2022-06-12 15:02:06.013138
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    def async_print(arg):
        sleep(0.1)
        print(arg)
    def do_submit(monoworker, arg):
        print("Beginning submit for arg", arg)
        return monoworker.submit(async_print, arg)

    monoworker = MonoWorker()
    first = do_submit(monoworker, "first")
    second = do_submit(monoworker, "second")
    third = do_submit(monoworker, "third")

    sleep(0.2)
    first.cancel()
    second.cancel()
    third.cancel()



# Generated at 2022-06-12 15:02:15.500139
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import as_completed
    from random import randint

    def func(x):
        sleep(1)
        return x

    mono = MonoWorker()
    with mono:
        run_futures = []
        num_submits = randint(3, 5)
        tqdm_auto.write(str(num_submits))
        for i in range(num_submits):
            run_futures.append(mono.submit(func, i))
            sleep(.1)
            tqdm_auto.write('submitted: {}'.format(i))
        for f in as_completed(run_futures):
            tqdm_auto.write(str(f.result()))
            tqdm_auto.write('finished')
   

# Generated at 2022-06-12 15:02:28.836536
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Lock
    from time import sleep
    from concurrent.futures import ThreadPoolExecutor
    from ..auto import tqdm as tqdm_auto
    import random
    import sys
    #from tqdm.contrib import MonoWorker
    ## from . import MonoWorker

    tqdm_auto.write = tqdm_auto.write
    lock = Lock()

    def get_random_number():
        with lock:
            return random.randint(0, 10)

    def generator():
        time = 0
        while time < 3:
            worker.submit(get_random_number)
            time += 1
            sleep(0.5)

    def info():
        while True:
            ran_num = worker.futures[0].result()
            sleep(0.001)
            t

# Generated at 2022-06-12 15:02:34.649960
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from traceback import format_exc

    def test_func(*args, **kwargs):
        tqdm_auto.write('running {}({}, {})'.format(
            test_func.__name__, args, kwargs))
        sleep(0.5)
        return 'result'

    def test_submit(runner, *args, **kwargs):
        result = runner.submit(test_func, *args, **kwargs)
        tqdm_auto.write('submitted {}({}, {})'.format(
            test_func.__name__, args, kwargs))

# Generated at 2022-06-12 15:02:44.487340
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .threading import LazyThread, ThreadTracker
    from .tqdm import TqdmTypeError
    from .utils import Struct

    class DummyTrackable(object):
        """Dummy example class that can be tracked by the thread pool"""
        def __init__(self, num):
            self.num = num

        def __str__(self):
            return str(self.num)

    def _dummy_func(trackable: DummyTrackable, raise_exc: bool=False) -> None:
        """Waits 0.1 second before setting it as tracking"""
        thread_tracker.set_trackable(trackable)
        sleep(0.1)
        if raise_exc:
            thread_tracker.unset_trackable()
            raise TypeError('Exception raise')

    thread_

# Generated at 2022-06-12 15:02:50.828871
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def delayed_print(i):
        sleep(0.5)
        return i

    mw = MonoWorker()
    mw.submit(delayed_print, 5)
    sleep(0.1)
    mw.submit(delayed_print, 4)
    sleep(0.1)
    mw.submit(delayed_print, 3)
    sleep(0.1)
    mw.submit(delayed_print, 2)
    sleep(0.1)
    mw.submit(delayed_print, 1)
    sleep(0.1)
    assert mw.futures[-1].result() == 5

# Generated at 2022-06-12 15:02:55.433621
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import current_thread
    worker = MonoWorker()

    def f():
        sleep(0.5)
        return current_thread()

    def g():
        sleep(0.5)
        return current_thread()

    assert worker.submit(f).result() != worker.submit(g).result()

# Generated at 2022-06-12 15:03:05.635362
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """ `MonoWorker.submit` should not execute multiple concurrent tasks """
    import time

    def check_idle(worker):
        """ Assert that there are no busy threads in `worker.pool` """
        assert not any(worker.pool._threads)

    def check_busy(worker):
        """ Assert that there is exactly one busy thread in `worker.pool` """
        assert len(worker.pool._threads) == 1
        assert any(worker.pool._threads)

    def dummy_task(count, threshold, sleep_secs):
        """ Returns `count` after sleeping for `sleep_secs`
        if `count` < `threshold` """
        if count < threshold:
            time.sleep(sleep_secs)
            return count
        else:
            return count

    # Initialize a `Mon

# Generated at 2022-06-12 15:03:14.897363
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from random import seed
    from sys import stdout, exc_info
    from time import sleep
    import unittest as ut  # noqa: E402

    class TestMonoWorker(ut.TestCase):
        def test(self):
            stdout.write('\n')
            seed(0)

            def submit(mworker, n):
                stdout.write('.')
                stdout.flush()
                future = mworker.submit(sleep, 10 * random())
                self.assertIsInstance(future, Future)

# Generated at 2022-06-12 15:03:22.601361
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from unittest import TestCase

    class _TestCase(TestCase):
        def test_submit(self):
            mw = MonoWorker()

            future = mw.submit(sleep, 0.1)
            self.assertEqual(len(mw.futures), 1)
            self.assertEqual(mw.futures.pop(), future)

            future0 = mw.submit(sleep, 0.1)
            future1 = mw.submit(sleep, 0.1)
            self.assertEqual(len(mw.futures), 2)
            self.assertEqual(mw.futures.pop(), future1)
            self.assertEqual(mw.futures.pop(), future0)
    test_MonoWorker_submit = _Test

# Generated at 2022-06-12 15:03:28.459122
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys

    def f(x):
        time.sleep(1)
        return x

    mw = MonoWorker()
    mw.submit(f, 'hello')
    mw.submit(f, 'world')
    time.sleep(0.5)
    mw.submit(f, 'python')
    time.sleep(0.75)
    mw.submit(f, '!' * 80)
    assert 'hello' in mw.pool.shutdown()
    assert 'python' not in mw.pool.shutdown()
    assert 'world' in mw.pool.shutdown()
    assert '!' * 80 in mw.pool.shutdown()

    mw.submit(f, sys.stdout.fileno())  # Should not break anything
    assert sys.stdout.fil

# Generated at 2022-06-12 15:03:34.517709
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def wait(t):
        time.sleep(t)
        return t

    mw = MonoWorker()
    mw.submit(wait, 1)
    mw.submit(wait, 3)
    mw.submit(wait, 5)
    mw.submit(wait, 7)
    mw.submit(wait, 9)
    for t in range(1, 10):
        if mw.futures:
            assert mw.futures[-1].result() == t

# Generated at 2022-06-12 15:03:57.675409
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import TimeoutError
    from time import sleep

    def myfunc(sec):
        sleep(sec)
        return sec

    def wait(future):
        try:
            ret = future.result(1)  # timeout after 1s
        except TimeoutError:
            return 'timeout'
        return ret

    # Initialise worker
    worker = MonoWorker()
    assert not worker.futures

    # Submit 1 task
    f1 = worker.submit(myfunc, 1.1)
    assert f1 == worker.futures[0]
    assert not f1.done()
    assert len(worker.futures) == 1

    # Submit 2nd task
    f2 = worker.submit(myfunc, 2.2)
    assert f2 == worker.futures[0]
   

# Generated at 2022-06-12 15:04:04.711975
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import time, sleep
    from ..utils import rate
    from .tgrange import tgrange
    from .asyncio import tgrange

    mw = MonoWorker()
    start = time()

    def task(idx):
        # sleep(.001)
        sleep(1)
        return idx

    for i in tgrange(10, desc="Submitting", leave=True):
        mw.submit(task, i)
        sleep(.001)
    for i in tgrange(10, desc="Checking", leave=False):
        print(mw.futures[i].result())

    duration = time() - start
    rate(duration, "task")

# Generated at 2022-06-12 15:04:10.678987
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test method submit of class MonoWorker"""
    from concurrent.futures import as_completed
    import time

    worker = MonoWorker()
    max_workers = worker.pool._max_workers

    def func(a, b, c=1):
        time.sleep(c)
        return a + b + c

    res = [0] * max_workers

    # sanity check
    res[0] = worker.submit(func, 1, 2, 0.5)
    res[0].result()
    res[0] = worker.submit(func, 1, 2, 0.5)
    res[0].result()

    # submit multiple tasks
    res[0] = worker.submit(func, 1, 2, 1)
    res[1] = worker.submit(func, 3, 4, 1)
    res

# Generated at 2022-06-12 15:04:15.731010
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def test(s, *args):
        with tqdm_auto.tqdm(total=1, desc=s) as t:
            time.sleep(args[0])
            t.update(1)
        return "OK " + s
    mw = MonoWorker()
    tqdm_auto.write("\nOne running and one waiting tasks:")  # test(4) won't run
    test1 = mw.submit(test, "test1", 2.0)
    test2 = mw.submit(test, "test2", 2.0)
    test3 = mw.submit(test, "test3", 2.0)
    test4 = mw.submit(test, "test4", 1.0)

# Generated at 2022-06-12 15:04:22.258890
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def test_func(*args, **kwargs):
        """Return received arguments plus a timestamp."""
        return time.time(), args, kwargs

    mw = MonoWorker()
    for i in range(4):
        kwargs = dict(x=1, y=i, z='abc')
        args = (i**2, i**3)
        res = mw.submit(test_func, *args, **kwargs)
        assert res.result() == (time.time(), args, kwargs)

# Generated at 2022-06-12 15:04:28.239042
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, random
    mw = MonoWorker()
    # Done task = 3
    # Max task = 2 (overwritten)
    # Max total tasks = 3
    # Cancelled tasks = 0
    def test(i):
        """Test function"""
        if i == 2:
            raise ValueError("i = 2")
        time.sleep(random.random())

    for i in range(3):
        print("{} submited".format(i))
        mw.submit(test, i)
    time.sleep(1)
    for i in mw.futures:
        print("{} running".format(i))

# if __name__ == '__main__':
#     test_MonoWorker_submit()

# Generated at 2022-06-12 15:04:36.719170
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f():
        for _ in tqdm_auto.trange(4):
            tqdm_auto.sleep(0.1)
        return True
    from time import sleep

    f = MonoWorker().submit(f)
    sleep(0.2)
    f = MonoWorker().submit(f)
    sleep(0.1)
    assert not f.done()
    sleep(0.3)
    assert f.done()
    assert f.result()
    f = MonoWorker().submit(f)
    sleep(0.2)
    assert f.done()
    assert not f.result()
    sleep(0.2)
    f = MonoWorker().submit(f)
    sleep(0.1)
    assert not f.done()
    sleep(0.1)
    f = MonoWork

# Generated at 2022-06-12 15:04:44.737691
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def func_1(*args, **kwargs):
        tqdm_auto.write('func_1: ' + str(args) + str(kwargs))
        time.sleep(1)
    def func_2(*args, **kwargs):
        tqdm_auto.write('func_2: ' + str(args) + str(kwargs))
        time.sleep(2)
    def func_3(*args, **kwargs):
        tqdm_auto.write('func_3: ' + str(args) + str(kwargs))
        time.sleep(3)
    def func_4(*args, **kwargs):
        tqdm_auto.write('func_4: ' + str(args) + str(kwargs))
        time.sleep(4)

# Generated at 2022-06-12 15:04:49.876318
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def _t():
        import time
        time.sleep(0.01)
        return 0

    mw = MonoWorker()
    mw.submit(_t)
    assert 0 == mw.futures[0].result()

    mw.submit(_t)
    mw.submit(_t)
    import time
    t0 = time.time()
    mw.submit(_t)
    t1 = time.time()
    assert len(mw.futures) <= 2
    assert t1 - t0 < 0.11

    def _t():
        import time
        time.sleep(2)
        return 0

    mw.submit(_t)
    mw.submit(_t)
    import time
    t0 = time.time()
    mw.submit(_t)

# Generated at 2022-06-12 15:04:57.229078
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from tqdm import tqdm

    T = 10

    mw = MonoWorker()

    def time_to_sleep(i):
        sleep(0.05 + i * 0.02)

    def worker(i):
        sleep(0.5 + random())  # random time for worker to complete
        return i  # worker returns

    pbars = {}  # {i: pbar} where i is worker i's index
    results = []

    for i in range(T):
        pbars[i] = pbar = tqdm(total=1,
                               bar_format="{desc}{bar}{r_bar}")
        pbar.set_description("worker #{}".format(i))
        mw.submit(worker, i)

# Generated at 2022-06-12 15:05:37.140992
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def foo(fut, s):
        time.sleep(s)
        tqdm_auto.write("\n{}: {}".format(fut, s))

    # Run test
    s = 0.5
    num = 20
    tqdm_auto.write("Testing MonoWorker.submit with {} {}-second tasks:\n"
                    .format(num, s))
    mono = MonoWorker()
    for i in tqdm_auto.tqdm(range(num), ascii=True):
        mono.submit(foo, i, s)
    # Give it some time to finish
    time.sleep(s * 2)
    tqdm_auto.write("\nDone.\n")

# Generated at 2022-06-12 15:05:47.226426
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    from contextlib import contextmanager

    @contextmanager
    def _synchronized(lock):
        with lock:
            yield

    @contextmanager
    def _pool_executor(max_workers):
        lock = Lock()
        fn = []
        worker = lambda: fn.append(None)
        pool = ThreadPoolExecutor(max_workers=max_workers)

        @contextmanager
        def _pool_executor_submit(*args, **kwargs):
            nonlocal lock, fn

# Generated at 2022-06-12 15:05:53.885730
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    def test_func(arg):
        time.sleep(random.random() * 3)
        return arg
    worker = MonoWorker()
    res = []
    for i in range(10):
        if i % 2:
            t = threading.Thread(target=worker.submit,
                                 args=(test_func, i))
            t.start()  # submit from new thread(s)
        else:
            res.append(worker.submit(test_func, i))  # submit from main thread
        time.sleep(random.random() * 2)
    for r in res:
        assert r.result() % 2 == 0

# Generated at 2022-06-12 15:06:04.443266
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import time
    import threading
    import traceback

    #---------------------------------------------------------------------------
    # Test-classes
    #---------------------------------------------------------------------------
    class test_class(threading.Thread):
        """
        Test-class for testing method submit of MonoWorker.
        """
        def __init__(self, number, bar):
            """
            Initialise the test_class.

            :param number: (int) count of threads
            :param bar: (tqdm) progressbar
            """
            super(test_class, self).__init__()
            self.number = number
            self.count = 0
            self.bar = bar
            self.count_lock = threading.Lock()
            self.bar_lock = threading.Lock()


# Generated at 2022-06-12 15:06:12.118539
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Event, Value, Process
    from sys import stderr
    from queue import Empty

    def test_func(out, in_q, out_q, halt):
        """
        * out: for each int x in in_q, out.value += x
        * out_q: put out.value and halt.is_set()
        """
        while not halt.is_set():
            try:
                x = in_q.get(timeout=.1)
                out.value += x
            except Empty:
                pass
            else:
                out_q.put(out.value)
                out_q.put(halt.is_set())


# Generated at 2022-06-12 15:06:16.746106
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from nose.tools import assert_equal
    from threading import Event

    def slowprint(arg):
        e.wait()
        time.sleep(0.1)
        print(arg)

    mw = MonoWorker()
    e = Event()

    e.set()  # unblock

    print("\nSubmitting first 1")
    f1 = mw.submit(slowprint, 1)
    print("Submitting second 2")
    f2 = mw.submit(slowprint, 2)
    print("Submitting third 3")
    f3 = mw.submit(slowprint, 3)

    print("\nWaiting for first (1)")
    f1.result()  # -> 3 (replaced)
    print("Waiting for second (2)")
    f2.result()  #

# Generated at 2022-06-12 15:06:25.043825
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    worker = MonoWorker()
    import time

    def slow_func(f_id, seconds):
        tqdm_auto.write("Task %d started" % f_id)
        time.sleep(seconds)
        tqdm_auto.write("Task %d done" % f_id)
        return "Task %d result" % f_id

    f1 = worker.submit(slow_func, 1, 3)
    time.sleep(1)
    f2 = worker.submit(slow_func, 2, 2)
    time.sleep(1)
    f3 = worker.submit(slow_func, 3, 1)
    time.sleep(1)
    assert f1.running()
    assert not f1.done()
    assert f2.running()
    assert not f2.done()
    assert not f

# Generated at 2022-06-12 15:06:32.115879
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import operator
    from contextlib import closing
    from itertools import chain
    import unittest

    class TestMonoWorkerSubmit(unittest.TestCase):
        @staticmethod
        def echo(n):
            """
            Return the value of n after waiting a random delay.
            """
            time.sleep(n * random())
            return n

        def test_submit(self):
            with closing(MonoWorker()) as mw:
                state = set()
                def set_state(n):
                    state.add(n)
                    return n
                futures = [mw.submit(set_state, i) for i in range(4)]
                self.assertTrue(all(f.result() == n for n, f in
                                    enumerate(futures)))
                self.assertE

# Generated at 2022-06-12 15:06:41.851254
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from numpy.random import binomial
    from numpy import array

    N = 100  # number of trials
    k = 1  # number of trials per second
    delay = 1. / k  # seconds
    p = 0.5  # probability of being discarded

    lock = Lock()
    monitor = 0

    def f():
        sleep(delay)
        with lock:
            global monitor
            monitor += 1
            return monitor

    with MonoWorker() as w:
        futures = [w.submit(f) for i in range(N)]

    assert len(futures) == N
    results = [f.result() for f in futures]
    # We only keep the most recent results, so the non-discarded results
    # should be in ascending order

# Generated at 2022-06-12 15:06:45.043828
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    mw = MonoWorker()

    for i in range(4):
        sleep(random() / 100)
        mw.submit(sleep, random() / 100)

    for i in range(4):
        mw.submit(sleep, random() / 100).result()