

# Generated at 2022-06-12 14:58:12.502056
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(n):
        import time
        time.sleep(n)
    worker = MonoWorker()
    assert worker.submit(func, n=2).result() is None
    assert worker.submit(func, n=1).result() is None
    assert worker.submit(func, n=1).result() is None
    assert worker.futures.maxlen == 2

# Generated at 2022-06-12 14:58:21.079374
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .util import print_exc
    from .tqdm import tqdm

    worker = MonoWorker()
    task_id = 0

    def next_task():
        nonlocal task_id
        task_id += 1
        return task_id

    def worker_task(*args):
        task_id = args[0]
        sleep(0.5)
        with tqdm(desc="Task %s" % task_id, leave=False) as t:
            for i in t:
                sleep(0.5)
                if task_id > 2:
                    raise RuntimeError("Boom #%s!" % task_id)


# Generated at 2022-06-12 14:58:26.399605
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def factorial(n):
        if n < 0:
            raise ValueError("n={}".format(n))
        elif n == 0:
            return 1
        else:
            return n * factorial(n - 1)

    def test_submit(submit, maxlen, sleep=0.0, err=None):
        # Note: can't use `tqdm` to track in parallel,
        # because we need to track the `submit` method itself
        # (i.e. thread-safety of the class)
        N = 10
        if err is not None:
            if err not in (0, 1, N // 2, N - 1):
                raise ValueError("`err` value must be 0, 1, N/2, or N-1")
        else:
            err = N - 1
       

# Generated at 2022-06-12 14:58:33.438418
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures as futures

    def mono_submit(mw, func, *args, **kwargs):
        mw.submit(func, *args, **kwargs)
        time.sleep(0.1)
        for f in mw.futures:
            try:
                r = f.result()
            except futures.CancelledError:
                r = 'cancelled'
            except futures.TimeoutError:
                r = 'timeout'
            tqdm_auto.write('state: ' + r)

    def p(t):
        time.sleep(t)
        return t

    mw = MonoWorker()
    mono_submit(mw, p, 0.2)  # first task
    mono_submit(mw, p, 0.1)  # second task is

# Generated at 2022-06-12 14:58:43.111677
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import time
    from .std_out_err import _patched_std_out_err

    mw = MonoWorker()
    delay = 1

    with _patched_std_out_err() as (out_, err):
        # Submit task 1
        f = mw.submit(time)
        assert len(mw.futures) == 1
        assert not f.done()
        # Submit task 2
        f = mw.submit(time)
        assert len(mw.futures) == 1
        assert not f.done()
        # Wait for task 2
        f.result(timeout=delay)
        assert f.done()
        assert len(mw.futures) == 0
        assert out_.getvalue() == ''
        assert err_.getvalue() == ''


# Generated at 2022-06-12 14:58:54.484256
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from multiprocessing.pool import ThreadPool
    try:
        import queue  # Python 3
    except ImportError:
        import Queue as queue  # Python 2

    def f(x, sleep=False):
        if sleep:
            time.sleep(random.uniform(0.01, 0.1))
        return x + 1

    q = queue.Queue(maxsize=3)
    def producer(worker):
        for i in range(10):
            worker.submit(f, i, sleep=True)
            q.put(i)

    def consumer(worker):
        for _ in range(10):
            i = q.get()
            future = worker.futures[-1]
            x = future.result()

# Generated at 2022-06-12 14:59:02.449519
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    test_count = 10
    slow_count = 5

    mono_worker = MonoWorker()
    wait_time = 0.2
    slow_time = 0.5
    slow_tasks = deque([], maxlen=slow_count)

    def _test_func(num):
        print("test_func{}".format(num))
        time.sleep(wait_time)

    def _slow_func(num):
        print("slow_func{}".format(num))
        slow_tasks.append(num)
        time.sleep(slow_time)

    # test fast tasks
    for i in tqdm_auto.trange(test_count):
        mono_worker.submit(_test_func, i)
        time.sleep(wait_time)

    # test slow tasks, last 5

# Generated at 2022-06-12 14:59:13.847788
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=unused-variable, missing-docstring
    import time
    import os

    def func(a, b, c='c'):
        return a + b + c

    def wait(_):
        time.sleep(0.1)

    # No waiting task
    mw = MonoWorker()
    assert mw.submit(func, 1, 2)
    assert mw.submit(func, 1, 2)
    assert mw.submit(func, 1, 2)
    assert mw.submit(wait, None)
    os.system('sleep 0.2')  # Wait for func to finish
    assert mw.futures[0].result() == '123'

    # Waiting task
    mw = MonoWorker()
    assert mw.submit(wait, None)
    assert mw

# Generated at 2022-06-12 14:59:24.500089
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():  # pragma: no cover
    from math import hypot
    import time
    mw = MonoWorker()

    # define the function to be called with the thread
    def print_hypot(x, y):
        time.sleep(1)
        print("The hypotenuse of a %s by %s triangle is %s." % (
            x, y, hypot(x, y)))

    # submit the function to the thread
    mw.submit(print_hypot, 3, 4)

    # submit another function with separate args
    mw.submit(print_hypot, 5, 4)

    # submit the same function with args
    mw.submit(print_hypot, 5, 4)

    # submit the same function with args
    mw.submit(print_hypot, 5, 4)

    # submit the same function with

# Generated at 2022-06-12 14:59:30.318724
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from collections import namedtuple
    from contextlib import ExitStack
    from time import sleep

    from . import nrange

    def return_after(secs):
        """Returns after `secs` seconds."""
        sleep(secs)
        return secs

    def assert_result(futures, secs):
        """Assert that `futures` returns `secs` seconds."""
        assert futures.result() == secs

    def test_case(secs, delay):
        """Start two tasks, the second should be discarded."""
        with ExitStack() as stack:
            mono = stack.enter_context(MonoWorker())
            stack.enter_context(nrange(3))
            for s in secs:
                sleep(delay)

# Generated at 2022-06-12 14:59:42.129260
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Run an IO-bound method on one thread."""
    from time import sleep

    def sig_sleep(signum, frame):
        """Raise exception to test cancelling."""
        # tqdm_auto.write("SIGINT")
        raise KeyboardInterrupt

    import signal
    signal.signal(signal.SIGINT, sig_sleep)

    def _send(*args):
        """Method to submit concurrent task with."""
        from time import sleep
        from random import random
        sleep(random() * 5)
        return [int(x) for x in args]

    result_list = []

    def _catch(result):
        """Callback to catch results."""
        result_list.append(result)

    obj = MonoWorker()


# Generated at 2022-06-12 14:59:48.465401
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def add(x, y):
        time.sleep(x+y)
        return x + y
    mw = MonoWorker()
    for i in range(10):
        mw.submit(add, i, 1)
        mw.submit(add, i, 2)
        mw.submit(add, i, 3)
        assert mw.futures[0].result() == i + 3

# Generated at 2022-06-12 14:59:57.042383
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def patch(tqdm_auto, tqdm_cls):
        def gui_update_with_screenshot(self):
            return self.gui_update()

        def gui_update(self):
            self._last_gui_update = tqdm_auto.monotonic()
            # self.desc = "test"
            self.n = 1

        tqdm_cls.gui_update_with_screenshot = gui_update_with_screenshot
        tqdm_cls.gui_update = gui_update

        return tqdm_auto, tqdm_cls

    from .tests_tqdm import with_setup, pretest, posttest

    pretest(patch)

    import sys
    import threading
    import time
    import unittest


# Generated at 2022-06-12 15:00:05.799115
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    # test case
    def test(i):
        time.sleep(0.01)
        return i
    # init
    current = MonoWorker()
    # submit
    futures = []
    for i in range(10):
        current.submit(test, i)
    # check
    for i in range(10):
        futures.append(test(i))
    # compare
    assert current.futures[-1].done()
    for i in range(10):
        assert futures[i].result() == current.futures[-1].result()
    # test case
    def test2(i):
        time.sleep(0.1)
        return i
    # submit
    futures = []
    for i in range(10):
        current.submit(test2, i)
    #

# Generated at 2022-06-12 15:00:15.427079
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()

    def waitn(n):
        time.sleep(n)
        return n

    a = mw.submit(waitn, 1)
    assert len(mw.futures) == 1
    b = mw.submit(waitn, 2)
    assert len(mw.futures) == 2
    assert not a.done() and not b.done()
    c = mw.submit(waitn, 3)
    assert len(mw.futures) <= 1
    assert b.done() and b.result() == 3
    assert a.done() or c.done() and (a.result() == 1 or c.result() == 1)
    time.sleep(1)
    assert not c.done()
    time.sleep(2)

# Generated at 2022-06-12 15:00:21.602715
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    class FooThread(object):
        def __init__(self, x):
            self._x = x

        def foo(self):
            time.sleep(1)
            return self._x * self._x
    f = MonoWorker()
    assert f.submit(lambda: 0) == None  # error, e.g. thread start failed
    for i in range(5):
        assert f.submit(FooThread(i).foo).result() == i * i
        time.sleep(0.1)

# Generated at 2022-06-12 15:00:31.657087
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    import time
    import concurrent.futures

    class Task(object):
        def __init__(self, name, seconds):
            self.name = name
            self.seconds = seconds
        def __call__(self):
            time.sleep(self.seconds)
            return self.name

    task = Task('dummy', 2)
    mw = MonoWorker()
    for i in range(1, 4):
        if i == 2:
            task.seconds = 0.2
        if i == 3:
            task.name = 'dummy2'
        mw.submit(task)


# Generated at 2022-06-12 15:00:38.891810
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import gc

    def func(x):
        return x * x

    MW = MonoWorker()

    assert MW.futures == deque([], 2)
    res = MW.submit(func, 5)
    assert len(MW.futures) == 1
    assert isinstance(MW.futures[0].result(), int)
    assert MW.futures[0].result() == 25

    res = MW.submit(func, 5)
    assert len(MW.futures) == 1
    assert isinstance(MW.futures[0].result(), int)
    assert MW.futures[0].result() == 25

    res = MW.submit(func, 6)
    assert len(MW.futures) == 2
    assert isinstance(MW.futures[1].result(), int)

# Generated at 2022-06-12 15:00:48.408702
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import _range
    from time import sleep
    from .monitor import TMonitor

    def long_task(n, t):
        sleep(t)
        return 'f{}'.format(n), t

    def execute_tasks(tasks, worker):
        for n, t in _range(tasks):
            worker.submit(long_task, n, t)

    def print_tasks(tasks, worker):
        with TMonitor(unit='tasks', leave=True):
            for n, t in _range(tasks):
                worker.submit(long_task, n, t)
                print(worker.futures[-1].result())

    if __name__ == '__main__':
        worker = MonoWorker()
        execute_tasks(tasks=4, worker=worker)
       

# Generated at 2022-06-12 15:00:53.530813
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    mw = MonoWorker()

    def func_a():
        sleep(0.5)
        return 'A'

    def func_b():
        sleep(0.5)
        return 'B'

    mw.submit(func_a)
    mw.submit(func_b)

    ret = mw.futures[0].result()
    assert ret == 'B'



# Generated at 2022-06-12 15:01:02.223671
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    MonoWorker.test_flag = False

    def test_func():
        time.sleep(0.1)
        MonoWorker.test_flag = True

    mono_worker = MonoWorker()

    mono_worker.submit(test_func)
    time.sleep(0.05)
    assert not MonoWorker.test_flag

    mono_worker.submit(test_func)
    time.sleep(0.2)
    assert MonoWorker.test_flag

# Generated at 2022-06-12 15:01:07.598690
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import time
    from time import sleep

    def foo(i):
        sleep(abs(1-i))  # any positive number
        return i

    def bar(i):
        sleep(0.1)
        return i * 2

    t = time()
    m = MonoWorker()
    m.submit(foo, 0)
    m.submit(foo, 1)
    m.submit(foo, 2)
    m.submit(bar, 3)
    m.submit(foo, 4)
    assert m.futures[0].result() == 0  # attempts 1, 2, and 3 already done
    assert m.futures[1].result() == 6  # attempts 4 and 5 already done
    assert time() - t < 3.2  # to make sure that the above works

# Generated at 2022-06-12 15:01:15.511880
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from functools import partial
    from operator import add
    from time import sleep

    def f(x, y):
        sleep(.1)
        return add(x, y)

    mw = MonoWorker()
    assert mw.futures == deque()

    partial_f = partial(f, 1)  # x=1
    # Submit first task
    f1 = mw.submit(partial_f, y=1)  # f1.kwargs = {'y': 1}
    assert f1.done() is False
    assert mw.futures == deque([f1])

    # Submit second task
    f2 = mw.submit(partial_f, y=2)  # f2.kwargs = {'y': 2}
    assert f2.done() is False
    assert m

# Generated at 2022-06-12 15:01:21.956307
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from six import reraise as raise_
    from ..std import sys

    def get_delay(n):
        return n, sleep(n)

    def get_print(n):
        return n, print(n)

    def get_fut(t):
        return t, MonoWorker().submit(*t)

    def get_res(f):
        return f[0], f[1].result()


# Generated at 2022-06-12 15:01:31.863266
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from os import unlink
    import tempfile

    test_file = tempfile.NamedTemporaryFile()
    test_file_path = test_file.name
    unlink(test_file_path)

    def save_file(filename, delay):
        sleep(delay)
        with open(filename, 'w') as f:
            f.write('success')
    MonoWorker().submit(save_file, test_file_path, delay=0.05)
    MonoWorker().submit(save_file, test_file_path, delay=0.01)
    MonoWorker().submit(save_file, test_file_path, delay=0.10)

    # Waiting for success
    while not open(test_file_path, 'rb').read():
        sleep(0.01)

   

# Generated at 2022-06-12 15:01:39.233686
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint
    from concurrent.futures import Future, TimeoutError

    def _worker(seq):
        sleep(randint(1, 5))
        seq.append(None)
        return None

    for _ in tqdm_auto.trange(100, desc="test_MonoWorker_submit()"):
        seq = []
        worker = MonoWorker()

        # submit() is blocking when no worker is running
        worker.submit(_worker, seq)
        assert len(seq) == 1
        assert len(worker.futures) == 0

        # submit() returns Future when worker is running
        f = worker.submit(_worker, seq)
        assert isinstance(f, Future)
        assert len(seq) < 2
        assert len(worker.futures) == 1



# Generated at 2022-06-12 15:01:49.726458
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def time_consuming_task(i, sleep=0.1):
        time.sleep(sleep)
        return i

    mono_worker = MonoWorker()
    assert not mono_worker.futures
    waiting_1 = mono_worker.submit(time_consuming_task, 1, sleep=0.01)
    assert len(mono_worker.futures) == 1
    assert waiting_1.result() == 1
    assert not mono_worker.futures

    waiting_2 = mono_worker.submit(time_consuming_task, 2, sleep=0.01)
    assert (waiting_2.result() == 2
            and len(mono_worker.futures) == 1
            and mono_worker.futures[0] == waiting_2)

    waiting_3 = mono_worker

# Generated at 2022-06-12 15:01:56.070140
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    concurrent_worker = MonoWorker()
    def t(n):
        time.sleep(random.random() * n)
        return n

    n = [0, 0]
    for _ in range(100):
        i = random.randint(0, 2)
        concurrent_worker.submit(t, (i % 2) * 10)
        n[i % 2] += 1
        time.sleep(random.random() * 0.02)  # a small delay to prevent futex issues

    # check that all were executed
    assert sum(n) == 100

    # check that no more than 2 were executed in parallel
    assert max(n) <= 2

# Generated at 2022-06-12 15:02:03.572529
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, time
    from random import randrange

    def randprint(delay=0.1, randrange=3):
        sleep(delay)
        tqdm_auto.write("success {}".format(randrange))
    mw = MonoWorker()
    t0 = time()
    mw.submit(randprint)
    mw.submit(randprint)
    # take longer than 0.1s
    mw.submit(randprint, delay=0.5, randrange=0)
    assert len(mw.futures) == 2
    assert time() - t0 > 0.5

    mw.submit(randprint, delay=0.5, randrange=1)
    assert len(mw.futures) == 2
    assert mw.futures[0].done()
   

# Generated at 2022-06-12 15:02:13.322900
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing.dummy import Pool as ThreadPool
    from time import sleep
    from random import random

    def my_func(arg):
        sleep(random())
        return arg * 2

    thread_pool = ThreadPool(4)
    mono_worker = MonoWorker()

    thread_pool.map(my_func, range(10))
    mono_worker.submit(my_func, 1)
    mono_worker.submit(my_func, 2)
    mono_worker.submit(my_func, 3)
    mono_worker.submit(my_func, 4)
    mono_worker.submit(my_func, 5)
    mono_worker.submit(my_func, 6)
    mono_worker.submit(my_func, 7)
    mono_worker.submit(my_func, 8)
    mono

# Generated at 2022-06-12 15:02:26.344313
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def print_and_sleep(s, sleep_time):
        tqdm_auto.write('Sleeping for %ss...' % sleep_time)
        sleep(sleep_time)
        tqdm_auto.write(s)

    # Only prints "Done!", never "Done?":
    worker = MonoWorker()
    worker.submit(print_and_sleep, 'Done?', 1)
    worker.submit(print_and_sleep, 'Done!', 3)
    assert len(worker.futures) == 2
    worker.futures[0].result()
    worker.futures[1].result()
    assert len(worker.futures) == 2



# Generated at 2022-06-12 15:02:32.788906
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import random

    class Shared(object):  # pylint: disable=too-few-public-methods
        """Unit test shared class"""
        def __init__(self):
            self.lock = threading.Lock()
            self.result = 0

    def runner(worker, shared, value):
        """Unit test runner"""
        time.sleep(random.random() / 10)
        with shared.lock:
            shared.result = value

    shared = Shared()
    mono = MonoWorker()
    for _ in tqdm_auto.trange(100):
        mono.submit(runner, mono, shared, _)
    mono.pool.shutdown(wait=True)
    assert shared.result == 99

# Generated at 2022-06-12 15:02:42.672082
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import unittest

    class TestMonoWorker(unittest.TestCase):
        def test_submit(self):
            with MonoWorker() as mw:
                with tqdm_auto.tqdm(total=1, unit='sec') as t:
                    def wait(i):
                        time.sleep(1)
                        return i

                    def wait_cancel(i):
                        time.sleep(1)
                        return i

                    for i in range(5):
                        t.write("{i}: f{i} added to pool".format(i=i))
                        mw.submit(wait_cancel, i)

                    for i in range(5, 10):
                        t.write("{i}: f{i} added to pool".format(i=i))

# Generated at 2022-06-12 15:02:49.194184
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(x, y=1):
        return x+y
    monoworker = MonoWorker()
    running = monoworker.submit(func, 4)
    waiting = monoworker.submit(func, 1, y=2)
    waiting.result()
    assert waiting.done()
    assert not running.done()
    running.result()
    assert running.done()
    waiting = monoworker.submit(func, 2)
    running = monoworker.submit(func, 3)
    running.result()
    assert running.done()
    for f in monoworker.futures:
        assert f.done()

# Generated at 2022-06-12 15:02:51.387201
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    mw = MonoWorker()
    for i in range(5):
        print('submit', i)
        try:
            mw.submit(sleep, i)
        except Exception as e:
            print(str(e))

# Generated at 2022-06-12 15:02:55.822787
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from operator import add

    class test(object):

        def __init__(self):
            self.a = 0
            self.b = 0
            self.c = 0

        def func1(self):
            self.a = 1

        def func2(self, i):
            self.a = 2
            self.b = i

        def func3(self, i, j):
            self.a = 3
            self.b = i
            self.c = j

        def main(self):
            class MonoWorker(object):
                """
                Supports one running task and one waiting task.
                The waiting task is the most recent submitted (others are discarded).
                """
                def __init__(self):
                    self.pool = ThreadPoolExecutor(max_workers=1)

# Generated at 2022-06-12 15:03:05.974169
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    class _ThreadSafeF(object):
        """Helper thread-safe appendable futurifier"""
        def __init__(self):
            if hasattr(self, '_futures'):
                self._futures.clear()
            else:
                self._futures = []

        def __call__(self, func, *args, **kwargs):
            """Appends that future's result in its own list"""
            f = func(*args, **kwargs)
            self._futures.append(f)
            return f

        @property
        def results(self):
            """Get results of futures"""
            return [f.result() for f in self._futures]

    def f(x):
        sleep(x / 10.0)
        return x


# Generated at 2022-06-12 15:03:15.477822
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError

    def get_futures(mw):
        return sorted(mw.futures, key=lambda f: f.running())
    mw = MonoWorker()
    assert mw.submit(time.sleep, 0) == get_futures(mw)[0]
    assert mw.submit(time.sleep, 0) == get_futures(mw)[1]
    assert mw.submit(time.sleep, 0, timeout=0) == get_futures(mw)[0]
    try:
        mw.submit(time.sleep, 0, timeout=0)
    except TimeoutError:  # no timeout is abused
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-12 15:03:22.245504
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def target(t):
        sleep(t)
        return t

    mono = MonoWorker()
    assert mono.submit(target, 0.5) == mono.submit(target, 0.1)
    assert mono.submit(target, 0.7) == mono.submit(target, 0.2)
    assert 0.2 == mono.futures.pop().result()
    assert 0.1 == mono.futures.pop().result()
    assert mono.submit(target, 0.4) == mono.submit(target, 0.3)
    assert 0.4 == mono.futures.pop().result()
    assert 0.3 == mono.futures.pop().result()

# Generated at 2022-06-12 15:03:28.211605
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def fib(n):
        """
        fibonacci number generator
        """
        a, b, counter = 0, 1, 0
        while True:
            if (counter > n):
                return
            yield a
            a, b = b, a + b
            counter += 1

    # Note: To run unit test, `$ nosetests -s test_concurrent.py:test_MonoWorker_submit`
    def test_fib(n):
        for _ in range(n):
            time.sleep(0.001)
            yield next(fibgen)

    fibgen = fib(12)

    with MonoWorker() as monowork:
        tqdm_auto.tqdm.write("Running fib(12), (1)&(2) should complete")

# Generated at 2022-06-12 15:03:41.296056
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func():
        time.sleep(2)
        return 1

    mw = MonoWorker()
    with tqdm_auto.tqdm() as t:
        f1 = mw.submit(func)
        f2 = mw.submit(func)
        f3 = mw.submit(func)
        f4 = mw.submit(func)
        t.update()
        f3.result()
        while f2.running():
            t.update()
            time.sleep(1)
        f2.result()
        f1.result()

# Generated at 2022-06-12 15:03:43.283446
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    mm = MonoWorker()
    for _ in tqdm_auto.trange(10):
        r = random.random()
        mm.submit(lambda r=r: time.sleep(abs(r)))

# Generated at 2022-06-12 15:03:48.258335
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import FormatCustomText

    def _make_submit(d, n, n_thread=1, n_time=0.2):
        def submit(*args, **kwargs):
            time.sleep(n_time)
            n.set_postfix({'_': n.n + 1})
            n.update(1)
            return args, kwargs
        for i in tqdm_auto.tqdm(range(d),
                                desc='', miniters=1, mininterval=0,
                                file=FormatCustomText('[]', '[')):
            yield submit

    def _check_submit(d):
        def check(*args, **kwargs):
            assert args == (i, i + 1)
            assert kwargs == {'foo': i}


# Generated at 2022-06-12 15:03:57.367806
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import local

    ret = local()

    # Test a function which will return the threading.local() data
    def f(v):
        ret.v = v
        return ret.v

    # Create a MonoWorker
    mw = MonoWorker()

    # Submit an initial task
    mw.submit(f, 1)

    # Submit a second task which will replace the waiting task
    mw.submit(f, 2)

    # Submit a third task
    mw.submit(f, 3)

    # Submit a forth task which will replace the waiting task
    mw.submit(f, 4)

    # Wait for all tasks to be completed
    while len(mw.futures) > 1:
        sleep(0.001)

    # Check results

# Generated at 2022-06-12 15:04:05.242382
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # import time

    import time

    def f(x, y):
        # time.sleep(2)
        return x * y

    # mw = MonoWorker()
    # mw.submit(f, 2, 2)
    # mw.submit(f, 3, 3)
    # mw.submit(f, 4, 4)
    # print(mw.futures)
    # print(mw.futures[0].result())
    # print(mw.futures[0].result())
    # print(mw.futures[0].result())

    mw = MonoWorker()
    mw.submit(f, 2, 2)
    mw.futures[0].result()
    mw.submit(f, 3, 3)
    mw.fut

# Generated at 2022-06-12 15:04:16.035031
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm.contrib import asyncio
    worker = MonoWorker()
    n = 1000
    # Get list of futures
    futures = []
    for _ in range(n):
        futures.append(worker.submit(time.sleep, 0.1))
    assert worker.futures
    # Get future generator
    futures = []
    for f in worker.futures:
        futures.append(worker.submit(time.sleep, 0.1))
    # Get future generator with tqdm
    with tqdm_auto.tqdm(total=n) as pbar:
        for f in worker.futures:
            futures.append(worker.submit(time.sleep, 0.1))
            pbar.update()
    asyncio.tqdm(futures)

# Generated at 2022-06-12 15:04:21.884296
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, os, signal

    def f():
        os.kill(os.getpid(), signal.SIGINT)
        time.sleep(10)
        return 2

    with tqdm_auto.tqdm(total=2) as t:
        try:
            with MonoWorker() as p:
                p.submit(f)
                p.submit(f)
                t.update()
                t.update()
        except KeyboardInterrupt:
            pass

# Generated at 2022-06-12 15:04:28.405522
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import sys
    import traceback
    from functools import wraps

    def print_traceback(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                func(*args, **kwargs)
            except:
                tqdm_auto.write("".join(traceback.format_exception(*sys.exc_info())))
        return wrapper

    @print_traceback
    def slow(i):
        sleep(.1)
        return i

    def assert_value(expected, actual, msg=None):
        if actual != expected:
            raise AssertionError("{} != {} : {}".format(actual, expected, msg))

    ################################################################################
    # Simple submit

    worker = MonoWorker()
    i = 40
   

# Generated at 2022-06-12 15:04:36.896578
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import gc

    mw = MonoWorker()

    # wait for completion and get or display exception
    def wait_for(future):
        exc = future.exception()
        if exc is None:
            return future.result()
        else:
            tqdm_auto.write(str(exc))

    # Test future is replaced
    def long_waiting():
        time.sleep(10)  # wish this was a timed wait for future replacement
        return "long"

    def short_waiting():
        time.sleep(1)
        return "short"

    start = time.time()
    lw = mw.submit(long_waiting)
    sw = mw.submit(short_waiting)
    assert wait_for(sw) == "short"
    sw.cancel()
   

# Generated at 2022-06-12 15:04:44.905200
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    worker = MonoWorker()
    # Test behavior with no task running
    assert len(worker.futures) == 0
    def func():
        time.sleep(1.0)
    def func_maxlen():
        worker.futures.maxlen = 5  # remove len limitation to trigger `if len(futures) == futures.maxlen:`.
        time.sleep(1.0)
    assert worker.submit(func) is not False
    assert len(worker.futures) == 1
    time.sleep(0.1)
    assert len(worker.futures) == 1
    # Test behavior with a running task
    assert worker.submit(func) is not False
    assert len(worker.futures) == 1
    time.sleep(0.1)

# Generated at 2022-06-12 15:05:03.858046
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()

    class F(object):
        """Mock Future"""
        def __init__(self, name, value=None, sleep=0):
            self.name = name
            self.value = value
            self.sleep = sleep
        def result(self):
            time.sleep(self.sleep)
            return self.value
        def done(self):
            return self.value is not None
        def cancel(self):
            self.value = "CANCELLED"
        def __str__(self):
            return "F({})".format(self.name)
        def __repr__(self):
            return str(self)

    # Pending
    mw.submit(lambda: F('a', sleep=0.05))
    time.sleep(0.2)


# Generated at 2022-06-12 15:05:12.050026
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from time import sleep
    from threading import Event
    from multiprocessing import cpu_count
    from functools import partial
    from math import sqrt
    from itertools import count

    def make_task(s, d):
        def _task(_s, _d):
            sleep(_d)
            return _s
        return partial(_task, s, d)

    def fake_tqdm(it):
        return it


# Generated at 2022-06-12 15:05:20.067634
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(x):
        import time
        time.sleep(0.1)
        return x

    mw = MonoWorker()
    tasks = [mw.submit(f, i) for i in range(25)]
    try:
        assert all(not t.done() for t in tasks)
    except AssertionError:
        from time import sleep
        sleep(0.11)
        assert all(t.done() for t in tasks)

    assert tasks[4].result() == 4
    assert all(tasks[5].done() for t in tasks[:5])
    assert all(tasks[5].done() for t in tasks[6:])
    assert all(tasks[-1].done() for t in tasks[:-1])

# Generated at 2022-06-12 15:05:25.864045
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from itertools import count
    from time import sleep
    from concurrent.futures import as_completed
    from ..utils import _range

    mw = MonoWorker()

    def func(i):
        sleep(0.01)
        return i

    futures = [mw.submit(func, i) for i in range(10)]
    for f in as_completed(_range(10)):
        assert f.result() == 2

    for i in count(10):
        mw.submit(func, i)
        if i % 100:
            continue
        for f in as_completed(_range(i)):
            assert f.result() == i
        assert mw.futures[0].running()
        assert mw.futures[1].done()

# Generated at 2022-06-12 15:05:29.611212
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def _func(arg):
        return arg

    worker = MonoWorker()
    assert worker.submit(_func, 1) == worker.submit(_func, 2)
    assert worker.submit(_func, 3) != worker.submit(_func, 4)
    assert worker.submit(_func, 5) != worker.submit(_func, 6)

# Generated at 2022-06-12 15:05:39.695108
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import time
    import threading
    import concurrent.futures

    def func(sleep):
        """Sleep for `sleep` seconds"""
        time.sleep(sleep)
        return True

    def func_exc(exc):
        """Raise `exc`"""
        raise exc()

    def test_worker(mworker, func, args, kwargs, nb_iter):
        """Test `mworker.submit` with `mworker`"""
        for _ in range(nb_iter):
            mworker.submit(func, *args, **kwargs)

        for _ in range(5):
            if threading.active_count() == 1:
                break
            time.sleep(0.01)

# Generated at 2022-06-12 15:05:48.785112
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from unittest import TestCase, main
    from threading import Event
    from itertools import count

    class test_submit(TestCase):
        def setUp(self):
            self.num_threads = 0
            self.stopped = Event()
            self.worker = MonoWorker()

        def tearDown(self):
            if self.stopped.is_set():
                return
            self.stopped.set()
            self.worker.pool.shutdown()

        def test_basic_usage(self):
            def func():
                self.num_threads += 1
                self.stopped.wait()

            self.worker.submit(func)
            self.worker.submit(func)
            self.assertTrue(self.num_threads > 0)


# Generated at 2022-06-12 15:05:55.894646
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from contextlib import contextmanager

    # Map function `func` with `args` and `kwargs` to method `name` of `obj`
    @contextmanager
    def method_context(obj, name, func, args=None, kwargs=None):
        method = getattr(obj, name)
        orig = method
        try:
            if func:
                setattr(obj, name, func)
        except Exception as e:
            tqdm_auto.write(str(e))
        yield
        try:
            setattr(obj, name, orig)
        except Exception as e:
            tqdm_auto.write(str(e))

    def call(obj, *args, **kwargs):
        return obj.submit(*args, **kwargs)


# Generated at 2022-06-12 15:06:00.745072
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import pytest

    MonoWorker.submit(sleep, 1)
    w = MonoWorker()
    w.submit(sleep, 0.5)
    sleep(1)
    with pytest.raises(Exception):
        w.submit(sleep, 0.5)
    sleep(1)

# Generated at 2022-06-12 15:06:09.689311
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import math
    import time
    from threading import Lock, RLock
    from contextlib import contextmanager
    from ..utils import format_sizeof

    stdout_lock = Lock()

    sleepy_fib = lambda n: time.sleep(math.pow(1.618, n) / 1000.0) or n
    fib = lambda n: math.pow(1.618, n)

    @contextmanager
    def double_submit_test(giga=True, f=fib, worker=None):
        """Replace the longest running task with a new task."""
        t = tqdm_auto.tqdm(total=2)
        if worker is None:
            worker = MonoWorker()

# Generated at 2022-06-12 15:06:41.772121
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def run_test(test_cases):
        for i, test in enumerate(test_cases):
            assert isinstance(test, tuple)
            assert isinstance(test[0], ThreadPoolExecutor)
            for execution_arg in test[1:]:
                assert isinstance(execution_arg, tuple)
                assert execution_arg[0] == 'submit'
                assert len(execution_arg) == 3
                assert isinstance(execution_arg[1], tuple)
                assert isinstance(execution_arg[2], dict)
                assert len(execution_arg[1]) == 1
                assert len(execution_arg[2]) == 0
                assert callable(execution_arg[1][0])

# Generated at 2022-06-12 15:06:48.576618
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from threading import Lock
    from concurrent.futures import CancelledError
    from numpy import random as nprnd

    n, nworkers = 10000, 8
    nprnd.seed(0)
    data = nprnd.randn(n)
    lock = Lock()
    tqdm_auto.tqdm.write("Testing `tqdm.contrib.MonoWorker.submit()`...")
    mw = MonoWorker()
    assert len(mw.futures) == 0

    def worker(data):
        """Dummy worker"""
        sleep(max(1, random() * random()))
        mean = data.mean()

# Generated at 2022-06-12 15:06:56.831767
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()

    waiting = mw.submit(func, 1)
    time.sleep(0.1)
    running = mw.submit(func, 2)
    time.sleep(0.1)
    assert running.cancel() is False  # cannot cancel running
    assert waiting.cancel() is True  # waiting was cancelled

    waiting = mw.submit(func, 2)
    time.sleep(0.1)
    running = mw.submit(func, 3)
    time.sleep(0.1)
    assert running.cancel() is True  # running takes priority over waiting

    running = mw.submit(func, 1)
    time.sleep(0.1)
    assert running.done

# Generated at 2022-06-12 15:07:02.351882
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    def fsleeper(total_sleep=.1):
        time.sleep(random.uniform(0, total_sleep))
        return random.uniform(0, total_sleep)

    mw = MonoWorker()

    # First result comes after 500ms (in random time)
    time_start = time.time()
    mw.submit(fsleeper, .5)
    r1 = mw.futures[0].result()
    t1 = time.time()

    # Second result comes after 300ms (in random time)
    time_end = time.time()
    mw.submit(fsleeper, .3)
    r2 = mw.futures[0].result()
    t2 = time.time()
    assert t1 < t

# Generated at 2022-06-12 15:07:07.892088
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def wait_print(wait_time, args, kwargs):
        sleep(wait_time)
        print(args, kwargs)

    from concurrent.futures import TimeoutError
    from unittest import TestCase

    class MonoWorkerTest(TestCase):
        def test_MonoWorker_submit(self):
            w = MonoWorker()
            w.submit(wait_print, 1, 1, 2)  # submission 1
            sleep(0.1)  # ensure submission 1 is now running
            # Error case: submission 2 replaces submission 1
            with self.assertRaises(TimeoutError):
                w.submit(wait_print, 0.1, 3, 4).result(timeout=0.05)
            # submission 3 replaces submission 1

# Generated at 2022-06-12 15:07:17.860954
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import warnings

    def start(sleep, name=None):
        print("{} start".format(name))
        time.sleep(sleep)
        print("{} done".format(name))

    worker = MonoWorker()
    assert len(worker.futures) == 0

    # test initial (running) task
    worker.submit(start, 1, name="task1")
    assert len(worker.futures) == 1
    time.sleep(0.1)  # wait for task to start
    assert len(worker.futures) == 1

    # test insert new task while one running
    worker.submit(start, 0.1, name="task2")
    assert len(worker.futures) == 1
    assert len(worker.futures) == 1

# Generated at 2022-06-12 15:07:23.560579
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Example of how to use MonoWorker.
    """
    import time
    from random import random

    def waiter(seconds):
        """Example of a task that takes time to execute"""
        time.sleep(seconds)
        return seconds

    def waiter_p(seconds):
        """Example of a task that takes time to execute and prints status"""
        print('Hello from task')
        print('I will sleep for %ds' % seconds)
        time.sleep(seconds)
        print('Task finished')
        return seconds

    mono = MonoWorker()

    for ii in range(10):
        mono.submit(waiter, random())
    mono.submit(waiter_p, 10)
    mono.submit(waiter_p, 2)

# Generated at 2022-06-12 15:07:31.325086
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    random.seed(0)
    mw = MonoWorker()

    def _func(idx, sec):
        time.sleep(sec)
        return idx

    vals = []  # expected results

    def reset():
        vals.append('reset')
        mw.futures.clear()

    def check(vals):
        for i, v in zip(mw.futures, vals):
            assert i.result() == v, \
                "expected '%s' but got '%s'" % (v, i.result())

    def submit(idx, sec):
        vals.append(idx)
        return mw.submit(_func, idx, sec)

    # base
    reset()
    future0 = submit(0, 0.05)


# Generated at 2022-06-12 15:07:37.793808
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import sys
    import threading
    from collections import defaultdict
    from ..utils import _range

    def _rand_delay(x, delay_C1=.3, delay_C2=.7):
        '''
        delay = C1 * |x| + C2 * |random()|
        '''
        return abs(x) * delay_C1 + abs(random.random()) * delay_C2

    Xs = defaultdict(bool)
    res = defaultdict(list)
    running = defaultdict(bool)

    def _fut_update(fut, x):
        res[x].append(fut.result())
        running[x] = False

    def _myfunc(x):
        running[x] = True

# Generated at 2022-06-12 15:07:45.782240
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    max_workers = 1
    task_duration = 1
    waiting_time = task_duration + 1e-2  # short delay to prevent race-condition

    m = MonoWorker()
    assert m.pool._max_workers == max_workers

    def func(n):
        time.sleep(task_duration)
        return n

    assert not m.futures  # queue is empty?
    n = 1
    assert n == m.submit(func, n).result()
    time.sleep(waiting_time)
    assert n - 1 == m.submit(func, n - 1).result()
    assert n - 1 == m.submit(func, n).result()
    time.sleep(waiting_time)
    assert n - 1 == m.submit(func, n - 1).result()