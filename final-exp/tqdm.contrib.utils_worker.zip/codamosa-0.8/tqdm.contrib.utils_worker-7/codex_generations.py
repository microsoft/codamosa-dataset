

# Generated at 2022-06-12 14:58:19.522715
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import operator
    import random

    def op_plus(i, j):
        time.sleep(0.1)
        return i + j

    mw = MonoWorker()

    # Nothing is canceled
    list_of_futures = []
    for i in range(10):
        list_of_futures.append(
            mw.submit(op_plus, i, random.randrange(1, 10)))

    print(sorted(map(operator.methodcaller('result'), list_of_futures)))

    # This should cancel f1
    for i in range(10):
        mw.submit(op_plus, i, random.randrange(1, 10))

    print(sorted(map(operator.methodcaller('result'), list_of_futures)))

# Generated at 2022-06-12 14:58:29.626915
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    
    worker = MonoWorker()
    
    def run(x):
        # tqdm_auto.write('running '+str(x))
        time.sleep(0.1)
        return x
    
    def wait(f):
        time.sleep(0.2)
        # tqdm_auto.write('running '+str(f.result()))
        return f.result()
    
    ts = []
    for i in range(10):
        # tqdm_auto.write('request '+str(i))
        t = threading.Thread(target=wait, args=(worker.submit(run, i),))
        t.start()
        ts.append(t)
    
    for t in ts:
        t.join()

# Generated at 2022-06-12 14:58:38.085600
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def _test(seconds):
        time.sleep(seconds)
        return seconds

    tqdm_auto.write("MonoWorker.submit(0.001) * 3 ...", end='')
    w = MonoWorker()
    for _ in range(3):
        w.submit(_test, 0.001)
    tqdm_auto.write("OK", refresh=True)

    tqdm_auto.write("MonoWorker.submit(0.010) * 3 ...", end='')
    first = w.submit(_test, 0.010)
    for _ in range(2):
        w.submit(_test, 0.010)
    tqdm_auto.write("OK", refresh=True)


# Generated at 2022-06-12 14:58:42.396661
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(x):
        print("Hello %s" % x)
        return x

    mw = MonoWorker()
    mw.submit(f, 1)
    mw.submit(f, 2)
    mw.submit(f, 3)
    mw.submit(f, 4)
    mw.submit(f, 5)

# Generated at 2022-06-12 14:58:49.958751
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys

    def test(x):
        time.sleep(x)
        sys.stderr.write('finished {0}\n'.format(x))

    m = MonoWorker()
    m.submit(test, 1)
    m.submit(test, 2)
    m.submit(test, 3)
    m.submit(test, 4)
    m.submit(test, 5)
    m.submit(test, 6)

# Generated at 2022-06-12 14:58:59.447318
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    # Will raise Exception if it fails
    results = []

    def append_result(x):
        results.append(x)
        time.sleep(0.01)

    mw = MonoWorker()
    results = []
    with tqdm_auto.tqdm(total=3) as pbar:
        mw.submit(append_result, 0)
        mw.submit(append_result, 1)
        mw.submit(append_result, 2)
        mw.submit(append_result, 3)
        mw.submit(append_result, 4)
        pbar.update(1)
        mw.submit(append_result, 3)
        mw.submit(append_result, 4)
        pbar.update(1)
        mw.submit

# Generated at 2022-06-12 14:59:07.726307
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    from time import sleep
    from collections import Counter
    from concurrent.futures import FIRST_COMPLETED

    def func():
        sleep(.01)
        return True

    MonoWorker = MonoWorker
    cnt = Counter()
    mw = MonoWorker()
    futs = [mw.submit(func) for _ in range(50)]
    while futs:
        done, not_done = tuple(futs[:1]), tuple(futs[1:])
        done, futs = FIRST_COMPLETED(futs), not_done
        cnt[len(done)] += 1
        if not futs:
            break
        futs.extend(mw.submit(func) for _ in done)
    assert cnt == {0: 49, 1: 50}

# Generated at 2022-06-12 14:59:16.664581
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread

    def foo(n):
        sleep(n)
        return n

    mw = MonoWorker()
    assert mw.submit(foo, 1)
    assert mw.submit(foo, 2)
    assert mw.submit(foo, 4)
    assert mw.submit(foo, 8)
    assert mw.submit(foo, 16)

    def baz(n):
        sleep(n)  # loop forever

    t = Thread(target=baz, args=(8e10,))
    t.daemon = True
    t.start()
    mw.submit(foo, 7)  # replaces 16
    mw.submit(foo, 5)  # replaces 7
    mw.submit(foo, 3)  # replaces 5
    mw.submit

# Generated at 2022-06-12 14:59:20.202775
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .test import test_MonoWorker_submit
    return test_MonoWorker_submit(MonoWorker)

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-12 14:59:27.158607
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def wait_then_print(n):
        sleep(n)
        tqdm_auto.write("{} sec.".format(n))

    with tqdm_auto.external_write_mode():
        mono = MonoWorker()
        mono.submit(wait_then_print, 2)  # 2 secs
        mono.submit(wait_then_print, 1)  # 1 secs
        mono.submit(wait_then_print, 3)  # 3 secs
        mono.submit(wait_then_print, 4)  # 4 secs

# Generated at 2022-06-12 14:59:42.090975
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import humanize_time
    from .tests import is_monotonic
    from time import sleep
    from sys import stderr

    N = 2
    mw = MonoWorker()
    f1 = mw.submit(sleep, 1)
    f2 = mw.submit(sleep, 2)
    f3 = mw.submit(sleep, 3)
    f4 = mw.submit(sleep, 4)
    mw.submit(sleep, 5)
    mw.submit(sleep, 6)
    mw.submit(sleep, 7)
    mw.submit(sleep, 8)
    mw.submit(sleep, 9)
    mw.submit(sleep, 10)

    assert len(mw.futures) == 1  # only running


# Generated at 2022-06-12 14:59:52.481292
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import current_process

    def f(sec):
        sleep(1)
        return current_process()

    results = []
    w = MonoWorker()

    def collect(result):
        results.append(result)

    w.submit(f, 1).add_done_callback(collect)
    sleep(1)
    w.submit(f, 2).add_done_callback(collect)
    sleep(1)
    w.submit(f, 3).add_done_callback(collect)
    sleep(1)

    assert len(results) == 2, "Job 2 and 3 should have been run"
    assert results[0].pid != results[1].pid, "Jobs should have been run on " \
                                             "different processes"

# Generated at 2022-06-12 14:59:59.312913
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    if sys.version_info[0] < 3:
        from Queue import Queue
    else:
        from queue import Queue
    outq = Queue()

    def f_print(out, i=0):
        outq.put(i)
        print(out, file=sys.stderr)

    mw = MonoWorker()
    for i in range(4):
        mw.submit(f_print, 'x' + str(i), i)
    assert outq.get() == 3
    assert outq.get() == 3
    assert outq.empty()

    mw = MonoWorker()
    for i in range(4):
        mw.submit(f_print, 'x' + str(i))
    assert outq.get() == 0
    assert outq

# Generated at 2022-06-12 15:00:07.425825
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint as ri
    from threading import Event as event

    for _ in range(30):
        r = event()
        r.set()
        with MonoWorker() as m:
            for _ in range(ri(1, 5)):
                sleep(ri(0, 25) / 1000.)
                r.wait()
                m.submit(lambda: sleep(ri(0, 25) / 1000.))
            sleep(ri(0, 25) / 1000.)
            m.submit(lambda: sleep(ri(0, 25) / 1000.))
        r.clear()
    r = event()
    r.set()

# Generated at 2022-06-12 15:00:13.510005
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .helpers import Test_Futures
    from .helpers import Test_Futures_Threads
    from .helpers import Test_IO
    from .helpers import Test_Threads
    tests = [Test_Futures.test_MonoWorker_submit,
             Test_Futures_Threads.test_MonoWorker_submit,
             Test_IO.test_MonoWorker_submit,
             Test_Threads.test_MonoWorker_submit]
    for test in tests:
        test()

# Generated at 2022-06-12 15:00:20.746814
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import tempfile
    from ..utils import _range
    import os

    # create a file to work with
    f = tempfile.NamedTemporaryFile(mode='w', delete=False)
    local_filename, local_filepath = None, f.name
    try:
        with open(f.name, 'w') as f:
            for i in _range(100):
                f.write(str(i) + '\n')
            local_filename = f.name
    finally:
        f.close()

    # test MonoWorker
    mw = MonoWorker()
    remote_filepath = tempfile.NamedTemporaryFile(mode='w').name
    mw.submit(lambda: os.rename(local_filepath, remote_filepath))
    # wait for the previous submit request

# Generated at 2022-06-12 15:00:30.847935
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from unittest import TestCase, main

    class Test(TestCase):
        def setUp(self):
            self.worker = MonoWorker()

        def tearDown(self):
            self.worker.pool.shutdown(wait=True)

        def test_submit(self):
            def take_10_seconds(*args, **kwargs):
                sleep(10)
                return args, kwargs

            self.assertEqual(len(self.worker.futures), 0)

            t0 = self.worker.submit(take_10_seconds, 0)
            self.assertEqual(len(self.worker.futures), 1)
            self.assertEqual(t0.result(), ((0,), {}))


# Generated at 2022-06-12 15:00:35.452509
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import Value
    from time import sleep

    x = Value('i', 0)
    def inc_x(sleep_time):
        sleep(sleep_time)
        with x.get_lock():
            x.value += 1
    def dec_x(sleep_time):
        sleep(sleep_time)
        with x.get_lock():
            x.value -= 1

    t = MonoWorker()
    t.submit(inc_x, 0.1)
    t.submit(dec_x, 0.1)
    sleep(0.15)
    assert x.value == 0, x.value

    t.submit(inc_x, 0.1)
    sleep(0.15)
    assert x.value == 1, x.value

    t.submit(dec_x, 0.1)


# Generated at 2022-06-12 15:00:39.294719
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def add_one(x):
        time.sleep(1)
        return x+1

    monoworker = MonoWorker()
    f1 = monoworker.submit(add_one, 1)
    f2 = monoworker.submit(add_one, 5)
    monoworker.submit(add_one, 3)
    assert f1.result(3) == 2
    assert f2.result(3) == 6

# Generated at 2022-06-12 15:00:43.826923
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    mw = MonoWorker()

    def long_task():
        time.sleep(1 + random.random() * 0.5)
        return random.randrange(1 - 0.5, 1 + 0.5)

    def slow_task():
        time.sleep(0.7)
        return 0.7

    def fast_task():
        return random.random()

    n = 10
    tasks = [long_task, slow_task, fast_task]
    for i in tqdm_auto.tqdm(range(n), leave=False, desc="MonoWorker"):
        if i == 4:
            # trigger, but not replace
            func = random.choice([fast_task, slow_task])

# Generated at 2022-06-12 15:00:58.518947
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from os import getpid
    import time

    def echo(msg):
        time.sleep(2)
        return "{} (pid: {})".format(msg, getpid())

    echo_worker = MonoWorker()
    f1 = echo_worker.submit(echo, "hello")
    f2 = echo_worker.submit(echo, "world")
    f1.result() == "hello (pid: {})".format(getpid())
    f2.result() == "world (pid: {})".format(getpid())

# Generated at 2022-06-12 15:01:07.016920
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    import time

    assert len(mw.futures) == 0
    mw.submit(time.sleep, 1)
    assert len(mw.futures) == 1
    mw.submit(time.sleep, 1)
    assert len(mw.futures) == 2
    mw.submit(time.sleep, 1)
    assert len(mw.futures) == 2
    mw.submit(time.sleep, 1)
    assert len(mw.futures) == 2

    mw.futures[0].result()
    mw.futures[1].result()

    mw.submit(time.sleep, 1)
    mw.submit(time.sleep, 1)

# Generated at 2022-06-12 15:01:15.016710
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, time
    from math import factorial

    def fast_fib(n):
        return int(factorial(n) / (factorial(n-2) * factorial(2)))

    def slow_fib(n):
        sleep(1)
        return fast_fib(n)

    def slow_fib_error(n):
        raise ValueError('Input {} is too large'.format(n))

    def test_worker_func(func, *args):
        worker = MonoWorker()
        futures = []
        t0 = time()
        for _ in range(5):
            futures.append(worker.submit(func, *args))
            sleep(0.5)
        for i, future in enumerate(futures, 1):
            print(i, future.result())

# Generated at 2022-06-12 15:01:21.695419
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 15:01:28.237272
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    tqdm_auto.write = print
    mw = MonoWorker()

    def sleeper(secs):
        time.sleep(secs)
        return secs

    assert mw.submit(sleeper, 1)
    assert mw.submit(sleeper, 1.5).result() == 1.5
    time.sleep(0.5)
    assert mw.submit(sleeper, 1).result() == 1
    time.sleep(0.5)
    assert mw.submit(sleeper, 0.5).result() == 0.5

# Generated at 2022-06-12 15:01:37.495499
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import time
    from queue import Queue
    from threading import Event

    completed = Event()
    lock = Event()

    def completed_future_task(duration):
        """A helper function that creates a future that is completed after
        `duration` seconds."""
        import concurrent.futures
        def _future_task(duration):
            """A helper function that creates a future that is completed after
            `duration` seconds."""
            time.sleep(duration)
            return True
        future = concurrent.futures.Future()
        future.set_result(_future_task(duration))
        return future

    def running_task(duration):
        """A helper function that delays execution for `duration` seconds."""
        time.sleep(duration)
        completed.set()

   

# Generated at 2022-06-12 15:01:42.845477
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from math import sin
    from time import sleep

    def f(a):
        sleep(.01)
        return sin(a), a

    mw = MonoWorker()

    # No arguments -> no worker started
    assert mw.submit() == None
    # Try with basic function
    assert mw.submit(f, 1) == None
    assert mw.futures[0].done()
    assert mw.futures[0].result() == (0.8414709848078965, 1)

    # Start another, which will discard the completed one
    assert mw.submit(f, 2) == None
    assert mw.futures[0].done()
    assert mw.futures[0].result() == (0.9092974268256817, 2)

    # Start a third,

# Generated at 2022-06-12 15:01:47.532459
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures

    def test_func(sleep_time):
        time.sleep(sleep_time)

    worker = MonoWorker()
    worker.submit(test_func, 0.1)
    time.sleep(0.05)  # sleep time shorter than previous submitted task
    with tqdm_auto.tqdm(total=1, desc='test1') as t:
        worker.submit(test_func, 0.5)
        t.update(1)
    print('done test1')
    with tqdm_auto.tqdm(total=1, desc='test2') as t:
        with tqdm_auto.tqdm(total=1, desc='test2-1') as t1:
            worker.submit(test_func, 1.)

# Generated at 2022-06-12 15:01:55.338855
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import traceback
    from tqdm.utils import _range
    from tqdm.auto import tqdm

    def func_1(arg):
        with tqdm(_range(arg), leave=True, ascii=True) as t:
            for i in t:
                time.sleep(0.01)
        return arg
    def func_2(arg):
        time.sleep(arg)
        return arg

    mono_worker = MonoWorker()
    with mono_worker:
        args_1 = [0.4, 0.4, 0.4, 0.4, 0.4, 0.2]
        for arg in args_1:
            mono_worker.submit(func_1, arg)
            time.sleep(arg)

# Generated at 2022-06-12 15:02:03.037295
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 15:02:18.773461
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import ClosingContext

    def _sleep(x):
        time.sleep(x / 10)
        return x

    with ClosingContext(MonoWorker()) as mono:
        f = mono.submit(_sleep, 10)
        mono.submit(_sleep, 5)
        assert f.result() == 10
        assert f.cancelled()

        f = mono.submit(_sleep, 10)
        time.sleep(1)  # ensure first task is running
        mono.submit(_sleep, 5)
        assert f.result() == 5
        assert f.cancelled()

        f = mono.submit(_sleep, 10)
        time.sleep(1)  # ensure first task is running
        mono.submit(_sleep, 5)
        time.sleep(1)  # ensure second task is running
        mono.submit

# Generated at 2022-06-12 15:02:28.870986
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from itertools import product
    from threading import active_count
    from contextlib import ExitStack
    from numpy import allclose

    # Value of the argument `delay` in `f`
    # and the time taken for each call to `f`
    dt = 0.1

    def f(delay, x):
        sleep(delay)
        return x

    for remove_waiting_task in [False, True]:
        args_prod = list(product(range(3), [1, 2]))
        with ExitStack() as stack:
            mono = stack.enter_context(MonoWorker())
            t = stack.enter_context(
                tqdm_auto.trange(len(args_prod), leave=False)
            )
            futures = []

# Generated at 2022-06-12 15:02:36.230535
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test the top-level API"""
    import time
    c = MonoWorker()
    c.submit(time.sleep, 1)
    c.submit(time.sleep, 2)
    c.submit(time.sleep, 3)
    c.submit(time.sleep, 4)
    c.submit(time.sleep, 2)
    c.submit(time.sleep, 2)
    c.submit(time.sleep, 2)
    c.submit(time.sleep, 2)
    c.submit(time.sleep, 2)
    c.submit(time.sleep, 2)
    c.submit(time.sleep, 2)
    c.submit(time.sleep, 2)
    c.submit(time.sleep, 2)
    c.submit(time.sleep, 2)

# Generated at 2022-06-12 15:02:45.755015
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import pytest
    # import multiprocessing as mp
    mw = MonoWorker()
    barrier = tqdm_auto.tqdm(total=1, leave=False)

    def foo(x):
        time.sleep(x)
        return x

    r1 = mw.submit(foo, 0.5)
    r2 = mw.submit(foo, 0.1)
    r3 = mw.submit(foo, 1.5)
    # print(mp.active_children())
    assert not r1.done()
    barrier.update()
    for r in [r1, r2, r3]:
        try:
            r.result(timeout=0.0001)
        except AssertionError:
            pass
        else:
            assert False
    assert r2.done

# Generated at 2022-06-12 15:02:52.626931
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import signal

    ctrlc = False
    signal.signal(signal.SIGINT, lambda *args: signal.default_int_handler())
    time.sleep(0.1)

    def get_nums():
        return random.randint(1, 100000)

    def test_subproc(subproc_func, results, append_func):
        def _append_subproc(subproc_func, append_val, results, append_func):
            results = results  # For lint
            append_func(subproc_func(append_val))

        return _append_subproc(subproc_func, get_nums(), results, append_func)


# Generated at 2022-06-12 15:03:00.466375
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def foo1(a=1, b=2, c=3):
        time.sleep(0.01)
        return a + b + c
    def foo2(a=1, b=2, c=3):
        time.sleep(0.01)
        return a + b + c

    mw = MonoWorker()
    assert mw.submit(foo1, 1, 2, c=3).result() == 6
    assert mw.submit(foo2, 1, 2, c=3).result() == 6



# Generated at 2022-06-12 15:03:03.720580
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time

    def test_func(*args):
        time.sleep(1)
        return threading.current_thread().name

    mono = MonoWorker()

    # Test standard submission
    f1 = mono.submit(test_func, 1)
    time.sleep(0.5)
    assert f1.result() == f1.result()

    # Test replacement
    f2 = mono.submit(test_func, 2)
    time.sleep(0.5)
    assert f2.done()
    assert f2.result() != f1.result()

    # Test replacement
    f3 = mono.submit(test_func, 3)
    time.sleep(0.5)
    assert f3.done()
    assert f3.result() != f2.result()


# Generated at 2022-06-12 15:03:05.668915
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .misc import test_MonoWorker_submit as _test_MonoWorker_submit
    return _test_MonoWorker_submit(MonoWorker)

# Generated at 2022-06-12 15:03:15.111614
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> from tqdm.contrib.concurrency import MonoWorker, test_MonoWorker_submit

    The waiting task is the most recent submitted (others are discarded).
    >>> Futures = tqdm_auto.format_executors([MonoWorker], [('a', 'b')],
    ...                                      globals(), locals())
    >>> for _ in Futures: pass
    a
    b

    >>> test_MonoWorker_submit()
    """
    from time import sleep

    def f(x):
        sleep(1)
        print(x)

    with MonoWorker() as w:
        w.submit(f, 'a')
        sleep(0.01)  # give a chance to start
        w.submit(f, 'b')
        sleep(1.5)  # wait

# Generated at 2022-06-12 15:03:22.774980
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    tqdm_auto.write("Starting unit test for method submit of class 'MonoWorker'")

    def wait(n):
        time.sleep(n)
        return n

    mw = MonoWorker()

    # Test basic insertion and execution
    res = mw.submit(wait, 1)
    assert res.result() == 1

    # Test fast insertion and execution
    res = mw.submit(wait, 2)
    assert res.result() == 2

    # Test stored execution
    res = mw.submit(wait, 3)
    time.sleep(1)
    res = mw.submit(wait, 4)
    assert res.result() == 4
    assert mw.futures[0].result() == 3

    # Test error handling

# Generated at 2022-06-12 15:03:41.494397
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from contextlib import closing

    def side_effect(n):
        return n + 1

    def wait():
        time.sleep(2)

    with closing(MonoWorker()) as worker:
        # test waiting task is replaced
        worker.submit(wait)
        worker.submit(wait)
        assert len(worker.futures) == 1
        worker.futures[0].cancel()  # kill the waiting task

        # test only waiting task is cancelled
        w1 = worker.submit(wait)
        w2 = worker.submit(wait)
        assert len(worker.futures) == 2
        assert not w1.done()
        assert not w2.done()
        time.sleep(1)
        w2.cancel()
        assert not w1.done()

# Generated at 2022-06-12 15:03:48.538586
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm import tqdm

    def _(x):
        sleep(.5)
        return x + 1

    mw = MonoWorker()
    for i in tqdm(range(3)):
        res = mw.submit(_, i)
        assert res.result() == _(i)


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:03:57.596242
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from unittest import TestCase

    class TestMonoWorker(TestCase):
        def test(self):
            def fake_func(x, seconds):
                sleep(seconds)
                return x

            w = MonoWorker()

            f1 = w.submit(fake_func, 1, 3)
            f2 = w.submit(fake_func, 2, 2)  # will replace f1
            f3 = w.submit(fake_func, 3, 1)  # will replace f2
            self.assertEqual(f1.done(), False)
            self.assertEqual(f2.done(), False)
            self.assertEqual(f3.done(), False)
            sleep(5)  # to allow f1 to finish (if not cancelled)

# Generated at 2022-06-12 15:04:03.810653
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    Mono = MonoWorker()
    # Test method submit of class MonoWorker
    print("TEST: submit(sleep, 0.01)")
    Mono.submit(sleep, 0.01)
    sleep(0.02)
    print("TEST: submit(sleep, 0.01)")
    Mono.submit(sleep, 0.01)
    sleep(0.02)
    print("TEST: submit(sleep, 0.01)")
    Mono.submit(sleep, 0.01)

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-12 15:04:14.959524
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    def func(x):
        time.sleep(x)  # sleep
        return x

    mw = MonoWorker()
    N = 6

    # declare function to be run in a thread
    def run_MonoWorker_submit(id):
        for _ in range(N):
            t = random.randint(1, 3)
            mw.submit(func, t)
            time.sleep(1)

    # create and start threads
    threads = [threading.Thread(target=run_MonoWorker_submit, args=(i,))
               for i in range(4)]
    for t in threads:
        t.start()

    # wait for threads to finish
    for t in threads:
        t.join()

    # ensure that each thread has submitted

# Generated at 2022-06-12 15:04:24.736812
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def proc_timed(n, sleep_period=0.1):
        """Process n seconds
        """
        print("Starting proc {}".format(n))
        sleep(n)
        print("Finished proc {}".format(n))
        return sleep_period

    def proc_err(n, sleep_period=0.1):
        """Process n seconds
        """
        print("Starting proc {}".format(n))
        sleep(n)
        raise RuntimeError("proc_err raised")

    worker = MonoWorker()
    worker.submit(proc_timed, 1)
    worker.submit(proc_timed, 2)
    worker.submit(proc_timed, 3)
    worker.submit(proc_timed, 4)
    worker.submit(proc_timed, 5)
   

# Generated at 2022-06-12 15:04:34.014290
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from . import sq
    from threading import Event
    from time import sleep
    from multiprocessing import cpu_count

    # 1. Test replace waiting task
    # 1.1. cancelled task
    n = 1
    w = MonoWorker()
    e = Event()

    def done():
        e.set()

    sq.submit(done, 1)
    e.wait()
    e.clear()

    assert len(w.futures) == 0

    task0 = w.submit(sq.submit, done, n)
    assert task0 is not None
    sleep(0.1)
    assert task0.running()
    assert not e.is_set()
    task1 = w.submit(sq.submit, done, n+1)
    assert task1 is not None
    sleep(0.1)


# Generated at 2022-06-12 15:04:42.213219
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures
    from itertools import count

    def foo(n):
        time.sleep(n)
        return n

    with MonoWorker() as w:
        # submit some tasks, first one waits, others replaced
        for i in count():
            w.submit(foo, i)
            if i >= 3:
                break

        for i in count(4):
            w.submit(foo, i)
            if i >= 6:
                break

    # check that futures were replaced
    assert len(w.futures) == 1
    future = w.futures[0]
    assert future.cancelled()
    assert future.done()
    try:
        future.result()
    except concurrent.futures.CancelledError:
        pass  # we want this


# Generated at 2022-06-12 15:04:48.624189
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import unittest

    class TestMonoWorker(unittest.TestCase):
        def setUp(self):
            self.pool = MonoWorker()

        @staticmethod
        def delayed_msg(msg, delay=0.3):
            time.sleep(delay)
            tqdm_auto.write(msg)

        def test_submit_delay(self):
            self.pool.submit(self.delayed_msg, 'first')
            self.assertEqual('first', threading.currentThread().getName())
            self.pool.submit(self.delayed_msg, 'second')
            self.assertEqual('first', threading.currentThread().getName())
            self.pool.submit(self.delayed_msg, 'third')

# Generated at 2022-06-12 15:04:53.178513
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from monotonic import monotonic

    def worker(dur):
        time.sleep(dur)

    worker_mono = MonoWorker()
    worker_mono.submit(worker, 2)
    start = monotonic()
    worker_mono.submit(worker, 1)
    stop = monotonic()

    assert stop - start < 1.1
    assert (stop - start) > 0.9

# Generated at 2022-06-12 15:05:15.402434
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def worker(r, t=1):
        time.sleep(t)
        return r * t

    w = MonoWorker()
    res = [w.submit(worker, i, i) for i in range(3)]
    print(list(res))

# Generated at 2022-06-12 15:05:21.933399
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method `submit` of class `MonoWorker`."""
    from time import sleep
    from multiprocessing import Event
    from concurrent.futures import CancelledError

    N = 6
    # dummy task
    jobs = [tqdm_auto.tqdm(desc='%i' % i) for i in range(N)]

    # testing code
    def _do_work(job, event):
        """Dummy task."""
        while (not job.n) or job.n > 0:
            job.update(1)
            sleep(0.1)
            if event.is_set():
                break

    event = Event()
    worker = MonoWorker()
    for job in jobs:
        worker.submit(_do_work, worker, event)
    event.set()
    sleep

# Generated at 2022-06-12 15:05:24.250395
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def hello(sleep):
        time.sleep(sleep)
        return 'hello'

    from ..auto import tqdm
    worker = MonoWorker()
    for _ in tqdm(range(10)):
        worker.submit(hello, 1)



# Generated at 2022-06-12 15:05:29.867152
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 15:05:34.364621
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> import time
    >>> def outputter(x):
    ...     time.sleep(0.1)
    ...     print('output:', x)
    >>> mw = MonoWorker()
    >>> mw.submit(outputter, 'a')
    >>> time.sleep(0.3)
    output: a
    """
    pass

# Generated at 2022-06-12 15:05:44.539383
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    # check that only one task is running at once
    fir = mw.submit(time.sleep, 2)
    sec = mw.submit(time.sleep, 2)
    assert fir.done()
    sec.result()
    # check that only one task is waiting at once
    fir = mw.submit(time.sleep, 2)
    sec = mw.submit(time.sleep, 2)
    fir.result()
    assert sec.done()
    # check that running task is not canceled by waiting task
    fir = mw.submit(time.sleep, 2)
    sec = mw.submit(time.sleep, 10)
    assert not fir.cancelled()
    sec.cancel()
    fir.result()
    # check that running task is not canceled by

# Generated at 2022-06-12 15:05:52.661139
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def my_func(a, b):
        sleep(1)
        return a + b

    mono = MonoWorker()
    assert len(mono.futures) == 0

    # test initial submission
    future = mono.submit(my_func, 1, 2)
    assert len(mono.futures) == 1

    # test submission while first is still running (discards second)
    future2 = mono.submit(my_func, 2, 3)
    assert len(mono.futures) == 1
    assert future2.done()

    # test submit while first is still running, with try/except (discards
    # second)
    future2 = mono.submit(my_func, 2, 3)
    assert len(mono.futures) == 1
    assert future2

# Generated at 2022-06-12 15:06:01.670541
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import time, sleep
    from itertools import count
    import logging
    logging.basicConfig(format='%(asctime)s %(levelname)s %(message)s',
                        level=logging.DEBUG)
    from ..auto import tqdm as tqdm_auto

    worker = MonoWorker()

    # nominal case:
    t = time()
    for i in tqdm_auto(range(4), desc='nominal', smoothing=0):
        t1 = time()
        worker.submit(sleep, 1)
        t2 = time()
        tqdm_auto.write('submit {:.1f}s'.format(t2 - t1))

    # cancel case:
    t = time()

# Generated at 2022-06-12 15:06:10.315185
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import unittest
    import multiprocessing as mp
    from multiprocessing.dummy import Pool

    def start_worker(args):
        "Execute loop in parallel process to let GIL free in main process"
        from .threaded import loop
        return (args, loop(*args))

    class TestWorker(unittest.TestCase):
        def setUp(self):
            self.result = [6, 24]
            self.args = [(range(3), 'result1', 0.1),
                         (range(6), 'result2', 0.01)]
            self.queue = mp.Queue()

        def test_process(self):
            "Test with actual processes"

# Generated at 2022-06-12 15:06:15.869422
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def identity(*args):
        return args

    f = MonoWorker().submit

    _ = f(identity, 0)
    _ = f(identity, 1)
    assert _.result() == (1,)

    _ = f(identity, 2)
    time.sleep(1e-2)  # let 1st job finish
    assert _.result() == (2,)

    _ = f(identity, 3)
    time.sleep(1e-2)  # let 2nd job finish & 3rd replace 1st
    assert _.result() == (3,)

    _ = f(identity, 4)
    time.sleep(1e-2)  # let 1st job finish & 4th replace 2nd
    assert _.result() == (4,)



# Generated at 2022-06-12 15:06:57.681908
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time
    from six.moves import queue
    from itertools import count
    def foo(i, q):
        q.put(i); time.sleep(1)
    q = queue.Queue()
    mw = MonoWorker()
    q.put(None)  # failsafe        
    for i in tqdm_auto(list(range(3)), desc='test_MonoWorker_submit', leave=False):
        mw.submit(foo, i, q)
        assert q.get() is None  # failsafe
    mw.submit(foo, 3, q)
    assert q.get() == 3
    assert q.empty()
    time.sleep(1)
    assert q.empty()



# Generated at 2022-06-12 15:07:03.101204
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    import sys

    n = 0
    m = 0
    lock = Lock()

    def incr(step):
        with lock:
            nonlocal n
            n += step
        sleep(0.01)

    def print_n():
        with lock:
            nonlocal m
            m += 1
        sleep(0.1)
        tqdm_auto.write('n: ' + str(n))

    mw = MonoWorker()
    # Should print a bunch of different values of `n`
    for i in tqdm_auto.trange(50):
        mw.submit(incr, i)
        mw.submit(print_n)
    mw.pool.shutdown(wait=True)

    # No other task should have been dropped
   

# Generated at 2022-06-12 15:07:08.253869
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-12 15:07:18.025022
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import sys
    import six
    if six.PY2:
        from StringIO import StringIO
    else:
        from io import StringIO

    def slow(i, exc=False):
        sleep(0.2)
        if exc:
            raise Exception('exc{}'.format(i))
        return i

    tqdm_auto.write = lambda *a, **k: None

    # basic
    w = MonoWorker()
    for i in range(3):
        print(w.submit(slow, i).result())
    assert i == 2

    # exception
    w = MonoWorker()
    for i in range(3):
        try:
            print(w.submit(slow, i, exc=True).result())
        except Exception:
            pass
    assert i == 2



# Generated at 2022-06-12 15:07:24.098669
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    
    g_running_time = 0
    g_wait_time = 0.5
    
    def f1():
        time.sleep(g_running_time)
        return 1
    
    def f2():
        time.sleep(g_running_time)
        return 2
    
    def f3():
        time.sleep(g_running_time)
        return 3
    
    assert mw.submit(f1) == None
    assert mw.submit(f2) == None  # f2 replaces f1 because f1 is still running
    assert mw.submit(f3) == None  # f3 replaces f2 because f2 is waiting
    time.sleep(g_wait_time)
    assert mw.submit(f1) != None
   

# Generated at 2022-06-12 15:07:31.463931
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import as_completed
    def long_running_task():
        sleep(1.0)
        return 'OK'

    mw = MonoWorker()
    mw.submit(long_running_task)

    # test if future submit is accepted (it won't be executed)
    f = mw.submit(long_running_task)
    assert len(mw.futures) == 1
    assert not f.done()

    # test if old future is overwritten
    f1 = mw.submit(long_running_task)
    assert len(mw.futures) == 1
    assert not f1.done()

    f2 = mw.submit(long_running_task)
    # make sure that old f1 is canceled

# Generated at 2022-06-12 15:07:37.940613
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm import trange
    from . import nonblocking_iter
    from .util import ThreadWithReturnValue

    def f(x):
        time.sleep(0.2)
        return x

    m = MonoWorker()

    # Test disregarding results
    m.submit(f, 1)
    m.submit(f, 2)
    m.submit(f, 3)
    m.submit(f, 4)
    m.submit(f, 5)

    # Test using results
    names = ['a', 'b', 'c', 'd', 'e']
    futures = []
    for n in trange(5, desc='started'):
        futures.append(m.submit(f, n))
        time.sleep(0.2)


# Generated at 2022-06-12 15:07:42.973975
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from .utils import command_out, default_timer

    print(command_out("python -m tqdm.contrib.test_MonoWorker_submit"))
    random.seed(0)
    mono = MonoWorker()

    def _slow_function(x):
        """Sleep a random amount of time, then return number multiplied by 5."""
        time.sleep(random.random()/100)
        return x*5

    # run a bunch of jobs to make sure they're running in sequence
    start = default_timer()
    for ii in tqdm_auto.tqdm(range(100), smoothing=0):
        mono.submit(_slow_function, ii)

        # this should take ~1000ms
        if ii < 50:
            assert threading.active_

# Generated at 2022-06-12 15:07:49.624931
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from os import getpid
    from threading import Lock
    from concurrent.futures import ThreadPoolExecutor
    from tqdm.utils import _environ_cols_wrapper

    def test_func(pid=None, sleepsec=None, lst=None, lock=None, quiet=False):
        """Prints current pid and id(lst) to stderr"""
        with lock:  # check lock is shared between all threads
            sleep(sleepsec)  # sleep to let other threads run
            lst.append(None)  # change to test lock is global
            cols = _environ_cols_wrapper()

# Generated at 2022-06-12 15:07:52.799925
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    progress = tqdm_auto.trange(5, desc='Looping')
    mw = MonoWorker()
    for i in progress:
        time.sleep(0.1)
        mw.submit(time.sleep, 0.5)
    # short-circuit execute last task
    mw.futures.pop().result()