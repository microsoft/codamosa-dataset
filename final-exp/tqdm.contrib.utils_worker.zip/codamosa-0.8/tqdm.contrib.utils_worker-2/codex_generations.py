

# Generated at 2022-06-12 14:58:17.406725
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from unittest import main
    from time import sleep as time_sleep
    from _thread import get_ident as thread_get_ident

    class MyError(Exception):
        pass

    class MonoWorkerTest(MonoWorker):
        def submit(self, func, *args, **kwargs):
            """replace with str()"""
            while len(self.futures):
                self.futures.popleft().cancel()
            try:
                return super(MonoWorkerTest, self).submit(str, *args, **kwargs)
            except Exception as e:
                tqdm_auto.write(str(e))

    def task(sleep_time):
        time_sleep(sleep_time)
        if sleep_time < 0.5:
            raise MyError('error')
        return thread_get

# Generated at 2022-06-12 14:58:28.559727
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import choice
    from string import ascii_letters

    import time
    from tqdm import tqdm

    def func(letter):
        time.sleep(1)
        return letter

    worker = MonoWorker()
    with tqdm(ascii_letters, ncols=80, unit='char') as pbar:
        for letter in pbar:
            time.sleep(0.5)  # let the progress bar advance
            pbar.set_description(letter)
            new_char = choice(ascii_letters)
            pbar.update(max(len(new_char) - len(letter), 0))
            fut = worker.submit(func, new_char)
            if fut is not None:
                try:
                    fut.result()
                except:  # ignored
                    pass



# Generated at 2022-06-12 14:58:35.016777
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    tqdm_auto.write = print
    mw = MonoWorker()
    def sleep_print(i, duration):
        time.sleep(duration)
        return i
    to_execute = [(0, 1.2), (1, 0.2), (2, 0.6), (3, 0.1), (4, 0.3)]
    for i, d in to_execute:
        mw.submit(sleep_print, i, d)
    # set(x.result() for x in mw.futures) == set(range(5))

# Generated at 2022-06-12 14:58:44.036058
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    random.seed(0)
    mw = MonoWorker()

    def f(n):
        print('start', n)
        time.sleep(random.random() * 0.1)
        print('exit', n)
        return n

    def g(n):
        print('start', n)
        time.sleep(random.random() * 0.5)
        print('exit', n)
        return n

    for _ in range(50):
        n = random.randint(0, 1)
        for i in range(n):
            mw.submit(f, i)
        mw.submit(g, n)


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-12 14:58:50.209539
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def c_fib(n):
        if n < 2:
            return 1
        return c_fib(n - 2) + c_fib(n - 1)

    def fib(n):
        if n < 2:
            return 1
        return fib(n - 2) + fib(n - 1)

    def test_submit(n):
        print('now computing {!r}'.format(n))
        print('c_fib({!r})'.format(n), '->', c_fib(n))
        print('fib({!r})'.format(n), '->', fib(n))

    with MonoWorker() as pool:
        for n in range(30, 35):
            print('submitting {!r}'.format(n))

# Generated at 2022-06-12 14:58:59.658378
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    results = []

    # tests
    mw = MonoWorker()
    assert len(mw.futures) == 0
    first = mw.submit(time.sleep, 1)
    assert len(mw.futures) == 1
    second = mw.submit(results.extend, [(1,)])
    assert len(mw.futures) == 1
    assert len(results) == 0
    time.sleep(1.2)
    assert len(results) == 1
    assert first.result() is None
    assert second.result() is None

    def block():
        time.sleep(10)
        return 'block'

    def printblock(result):
        print(result)


# Generated at 2022-06-12 14:59:07.586624
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    random.seed(3)
    from time import sleep

    def run_time(t):
        sleep(random.uniform(0.1, 0.8))
        return t

    work = MonoWorker()
    res = None
    for _ in range(10):
        t = random.randint(1, 10)
        for _ in range(3):
            if res is None or res.done():
                res = work.submit(run_time, t)
            elif res.done():
                res = work.submit(run_time, t)
        assert res.result() <= t
        assert len(work.futures) == 1
    work.pool.shutdown(wait=True)



# Generated at 2022-06-12 14:59:12.845146
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from random import randrange

    def test_func(a, b):
        r = randrange(1, 3)
        time.sleep(r * 0.25)
        return a + b + r

    mw = MonoWorker()
    futures = []
    # Submit 4 tasks
    for _ in range(4):
        futures.append((mw.submit(test_func, 1, 2)))
    time.sleep(1)
    # Should be 4 results by now
    assert [f.result() for f in futures] == [5, 6, 7, 5]
    # Unordered submission
    for _ in range(4):
        futures.append((mw.submit(test_func, 1, 2)))
    time.sleep(1)

# Generated at 2022-06-12 14:59:18.705165
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time
    import unittest
    from concurrent.futures import as_completed

    class TestMonoWorker(unittest.TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.threads = []

        def test_submit(self):
            # Test maximum length and discarding old tasks
            for i in range(4):
                self.threads.append(
                    threading.Thread(target=self.mw.submit,
                                     args=(time.sleep, 1)))
                self.threads[-1].start()

            time.sleep(.5)
            self.assertEqual(len(self.mw.futures), 2)
            #for t in self.threads:
            #   t.join()

            #

# Generated at 2022-06-12 14:59:27.623626
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    mw = MonoWorker()

    n_running = 0  # number of tasks running
    n_waiting = 0

    def f(x):
        sleep(x)
        nonlocal n_running
        n_running -= 1
        return x

    def g(x):
        sleep(x)
        nonlocal n_waiting
        n_waiting -= 1
        return x

    # submit a waiting task
    n_waiting += 1
    t1 = mw.submit(f, 1)
    # submit a second waiting task
    n_waiting += 1
    t2 = mw.submit(g, 1)
    # simulate the first task starting
    n_waiting -= 1
    n_running += 1
    # submit a third waiting task
    n_waiting += 1
   

# Generated at 2022-06-12 14:59:39.496771
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    global the_call_order  # pylint: disable=global-statement
    the_call_order = []
    lock = Lock()

    def func(char):
        lock.acquire()
        the_call_order.append(char)
        lock.release()
        sleep(0.005)

    worker = MonoWorker()
    for char in 'abcdefghijklmnopqrstuvwxyz':
        worker.submit(func, char)
        sleep(0.001)
    last_task = worker.submit(func, 'z')
    last_task.result()
    assert set(the_call_order) == set('z')

# Generated at 2022-06-12 14:59:44.071747
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def run(x):
        import time
        time.sleep(1)
        return x

    worker = MonoWorker()
    future1 = worker.submit(run, 1)
    future2 = worker.submit(run, 2)
    tqdm_auto.write('{} == {}'.format(future1.result(), future2.result()))


# Generated at 2022-06-12 14:59:54.984370
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from . import in_thread

    def do_sleep(t):
        time.sleep(t)
        return 42

    mw = MonoWorker()
    # submit with blocking wait
    task = mw.submit(do_sleep, 0.1)
    assert task.result() == 42
    # submit without blocking wait
    task = mw.submit(do_sleep, 0.1)
    assert task.result() == 42
    # submit while already waiting
    task = mw.submit(do_sleep, 0.1)
    assert task.result() == 42
    # submit while already running
    with in_thread(do_sleep, 0.2) as it:
        task = mw.submit(do_sleep, 0.1)

# Generated at 2022-06-12 14:59:59.916235
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    from time import sleep
    mw = MonoWorker()
    future = mw.submit(sleep, 0.1)
    future.result()
    mw.submit(sleep, 0.2)
    future.cancel()



# Generated at 2022-06-12 15:00:07.822113
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from unittest import TestCase
    from time import sleep

    class _TestMonoWorker(TestCase):
        def setUp(self):
            self.worker = MonoWorker()

        def test_submit(self):
            def f(i):
                sleep(i)
                return i

            j = self.worker.submit(f, 0.1)
            self.assertEqual(self.worker.futures.maxlen, 2)
            self.assertEqual(j, list(self.worker.futures)[-1])
            i = self.worker.submit(f, 0.2)
            self.assertEqual(i, list(self.worker.futures)[-1])
            self.assertEqual(i, j)
            i = self.worker.submit(f, 0.3)


# Generated at 2022-06-12 15:00:16.524855
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, numpy as np
    monoworker = MonoWorker()
    f1 = monoworker.submit(time.sleep, 0.5)
    f2 = monoworker.submit(time.sleep, 0.5)
    f3 = monoworker.submit(time.sleep, 0.5)
    assert f1 is not f2 is not f3
    assert f1.done() is False
    assert f2.done() is False
    assert f3.done() is False
    assert len(monoworker.futures) == 2
    assert set(monoworker.futures).issubset([f1, f2])
    assert set(monoworker.futures).issuperset(monoworker.futures)

# Generated at 2022-06-12 15:00:25.567761
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unittest for MonoWorker.submit method"""
    import time
    # pylint: disable=E1101,C0103
    def demo_func(a):
        """Function to use in the unittest"""
        time.sleep(a)
        print('done')

    mono = MonoWorker()
    mono.submit(demo_func, 1)
    time.sleep(0.1)
    mono.submit(demo_func, 1.5)
    time.sleep(1.1)
    print(mono.futures)
    assert len(mono.futures) == 1

    mono.submit(demo_func, 1)
    time.sleep(1.1)

# Generated at 2022-06-12 15:00:35.077518
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    m = MonoWorker()
    assert m.futures.maxlen == 2
    assert len(m.futures) == 0
    assert m.submit(time.sleep, 0.1).done()

    def _wait(t, i):
        time.sleep(t)
        return i

    assert m.submit(_wait, 0.1, 0).done()
    assert len(m.futures) == 1
    assert m.submit(time.sleep, 0.1).done()
    assert len(m.futures) == 1
    assert m.submit(_wait, 0.1, 1).done()
    assert len(m.futures) == 2
    assert m.submit(_wait, 0.1, 2).done()
    assert len(m.futures) == 2

# Generated at 2022-06-12 15:00:37.621363
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def task(i):
        return time.sleep(1)

    w = MonoWorker()
    w.submit(task, 1)
    w.submit(task, 2)
    w.submit(task, 3)
    assert not w.futures[0].done()
    assert w.futures[1].done()

# Generated at 2022-06-12 15:00:43.434946
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Process
    from tqdm._utils import _term_move_up

    def foo():
        sleep(1)
        return 42

    worker = MonoWorker()
    with tqdm_auto.tqdm(total=1, leave=False) as t:
        future = worker.submit(foo)
        t.update(0)
        assert future.result() == 42
        t.clear(_term_move_up())  # clear the "bar"

    with tqdm_auto.tqdm(total=1, leave=False) as t:
        future = worker.submit(foo)
        t.update(0)
        assert future.result() == 42
        t.clear(_term_move_up())  # clear the "bar"


# Generated at 2022-06-12 15:00:57.354255
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def do(a, b, c=1, d=2, e=None, f=None):
        return (a, b, c, d, e, f)
    w = MonoWorker()
    w.submit(do, 1, 2)
    w.submit(do, 3, 4, 5, e=6, f=7)
    assert w.futures[1].result() == (3, 4, 5, 2, 6, 7)
    w.submit(do, 8, 9)
    assert w.futures[1].result() == (8, 9, 1, 2, None, None)
    w.submit(do, 10, 11, c=12, d=13)
    assert w.futures[1].result() == (10, 11, 12, 13, None, None)

# Generated at 2022-06-12 15:01:00.526866
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm import tqdm
    from .utils import _test_time
    mono_worker = MonoWorker()

    for i in tqdm(range(4)):
        sleep(1)
        mono_worker.submit(_test_time, 1.5)

# Generated at 2022-06-12 15:01:09.134069
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from queue import Queue, Empty as EmptyException

    def step(i, q, q0):
        time.sleep(float(i) / 10)
        print('step {}'.format(i))
        print('queue: {}'.format(q))
        print('queue0: {}'.format(q0))
        q.put(i)
        q0.put(i)

    def test_method_submit():
        q = Queue()
        q0 = Queue()
        mw = MonoWorker()
        for i in range(3):
            f = mw.submit(step, i, q, q0)
            time.sleep(0.1 * (i + 1))
            assert not f.done()
        f.result()
        assert f.done()

# Generated at 2022-06-12 15:01:15.227327
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def _func(x):
        time.sleep(x)
        return (x, x + 1)

    mw = MonoWorker()
    mw.submit(_func, 0.2)
    mw.submit(_func, 0.1)
    mw.submit(_func, 0.3)  # this one should be discarded
    mw.submit(_func, 0.1)
    mw.submit(_func, 0.1)  # this one should be discarded
    assert mw.futures[0].result() == (0.1, 0.1 + 1)

# Generated at 2022-06-12 15:01:20.622150
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    mw.submit(tqdm_auto.write, "hello")
    assert len(mw.futures) == 1
    mw.submit(tqdm_auto.write, "world")
    assert len(mw.futures) == 2
    mw.submit(tqdm_auto.write, "again")
    assert len(mw.futures) == 2
    assert mw.futures[1].result() == 6  # "again"
    assert mw.futures[0].result() == 5  # "world"

# Generated at 2022-06-12 15:01:27.544892
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random, shuffle

    def task(*args):
        sleep(random())
        return tuple(args)

    workers = [MonoWorker() for _ in tqdm_auto(range(4))]
    for n in tqdm_auto(range(100)):
        shuffle(workers)
        futures = [worker.submit(task, n, n) for worker in workers]
        futures = [f for f in futures if f is not None]
        assert len(futures) <= 1
        if len(futures) == 1:
            results = futures[0].result()

# Generated at 2022-06-12 15:01:36.884978
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import inspect
    from random import random

    def slow_square(x, pause_factor=1):
        sleep(random() * pause_factor)
        return x * x

    # Create a process pool with one worker
    pool = MonoWorker()

    # Submit two slow square jobs and sleep
    results = [pool.submit(slow_square, i, pause_factor=2) for i in range(2)]
    print("Submitted two jobs and sleeping")
    sleep(1)
    print("Sleep completed and checking status of results")
    assert len(results) == 2
    for result in results:
        assert result.done() == False

    # Send another job, sleep, and check status again
    results.append(pool.submit(slow_square, 2, pause_factor=2))

# Generated at 2022-06-12 15:01:42.221369
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from itertools import count
    from logging import info
    from ..utils import _term_move_up
    from ..tqdm_gui import tqdm as tqdm_gui
    from .tqdm_gui_common import tgrange

    # pylint: disable=bad-builtin
    def _sleep_random(i):
        sleep(random())
        return i

    def _submit_random(mw, k):
        mw.submit(_sleep_random, k)

    def _tqdm_random(mw, i, bar, desc=''):
        bar.set_postfix_str(str(i) + desc)
        _submit_random(mw, i)
        return i

    def test(gui, n=1000):
        info

# Generated at 2022-06-12 15:01:45.926119
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def print_word(word):
        sleep(.5)
        tqdm_auto.write('print_word: {0}'.format(word))

    mono_worker = MonoWorker()
    mono_worker.submit(print_word, 'hello')
    mono_worker.submit(print_word, 'world')
    mono_worker.submit(print_word, 'again')
    mono_worker.submit(print_word, 'now')
    sleep(.5)
    mono_worker.submit(print_word, 'parallel')


# class MonoWorker(object):
#     """
#     Supports one running task and one waiting task.
#     The waiting task is the most recent submitted (others are discarded).
#     """
#     def __init__(self):
#         self.pool

# Generated at 2022-06-12 15:01:53.042680
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def slow_throw(i):
        time.sleep(random.random() / i)
        return i

    def slow_nothrow(i):
        time.sleep(random.random() / i)
        return i

    def fast_throw(i):
        time.sleep(random.random() / 2e6)
        raise Exception("hell")

    def fast_nothrow(i):
        time.sleep(random.random() / 2e6)
        return i

    mw = MonoWorker()

    for _ in range(10):
        mw.submit(slow_throw, _)
        mw.submit(fast_throw, _)
        mw.submit(slow_nothrow, _)
        mw.submit(fast_nothrow, _)

# Generated at 2022-06-12 15:02:04.558167
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(*args, **kwargs):
        raise Exception("This should fail")
    worker = MonoWorker()
    worker.submit(func)  # should fail and raise
    worker.submit(func)  # should not raise

# Generated at 2022-06-12 15:02:14.832166
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def dummy(delay=0):
        sleep(delay)
        return delay

    # test with no waiting task
    mw = MonoWorker()
    assert mw.submit(dummy, 0.1).result() == 0.1

    # test with previous waiting task
    mw = MonoWorker()
    assert mw.submit(dummy, 0.5).result() == 0.5
    assert mw.submit(dummy, 0.1).result() == 0.1
    assert mw.submit(dummy, 0.3).result() == 0.3

    # test with current running task and previous waiting task
    mw = MonoWorker()
    assert mw.submit(dummy, 0.5).result() == 0.5

# Generated at 2022-06-12 15:02:24.188520
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import concurrent.futures

    def slow(n):
        time.sleep(n / 1e6)
        return n

    worker = MonoWorker()
    assert worker.pool.shutdown(wait=False) is None
    assert worker.futures == deque()
    assert worker.submit(slow, 1) is None
    assert worker.pool.shutdown(wait=False) is None
    assert worker.futures == deque()
    assert worker.submit(slow, 1) is None
    # Test second task `slow(2)` is waiting for `slow(1)` to finish
    assert worker.pool.shutdown(wait=False) is None
    assert worker.futures == deque()
    assert worker.submit(slow, 2) is None
    assert worker.pool

# Generated at 2022-06-12 15:02:30.257062
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def do_sleep(seconds):
        from time import sleep
        sleep(seconds)
    from time import time
    start_time = time()
    mw = MonoWorker()
    for _ in range(5):
        mw.submit(do_sleep, 0.1)
        mw.submit(do_sleep, 0.2)
    for f in mw.futures:
        f.result()
    end_time = time()
    assert (end_time - start_time) < mw.futures.maxlen  # no. of workers

# Generated at 2022-06-12 15:02:35.554606
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Process

    def f(x):
        sleep(x)
        return x

    def g(x, y):
        try:
            return x / y
        except ZeroDivisionError:
            return float('nan')

    def subproc(mw, q):
        q.put((mw.submit(f, 1), mw.submit(g, 1, 0)))
        sleep(0.5)
        q.put((mw.submit(f, 2), mw.submit(g, 1, 1)))

    mw = MonoWorker()
    q = mw.pool._queue
    q.put((mw.submit(g, 1, 1), mw.submit(g, 1, 1)))
    # intermediate thread with 2 jobs to block queue
    t = m

# Generated at 2022-06-12 15:02:45.440911
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import random
    import sys
    import os

    mw = MonoWorker()

    def task(msg, delay=random.random()/10):
        sleep(delay)
        sys.stderr.write(msg)
        sys.stderr.flush()

    tasks = [('task1\n',), ('task2\n',), ('task3\n',)]
    expected_stderr = None

    tqdm_auto.write('\nTesting MonoWorker.submit:')
    tqdm_auto.write(' - submitting tasks to worker:')
    results = [mw.submit(*t) for t in tasks]

    tqdm_auto.write(' - waiting for tasks to finish:')
    for r in results:
        r.result()


# Generated at 2022-06-12 15:02:52.370162
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    def do_work(n):
        sleep(n)

    worker = MonoWorker()
    worker.submit(do_work, 0.1)
    worker.submit(do_work, 0.2)
    worker.submit(do_work, 0.3)  # replace previous task
    worker.submit(do_work, 0.4)  # replace previous task
    worker.submit(do_work, 0.5)  # replace previous task
    assert len(worker.futures) == 1

    f = worker.submit(do_work, 0.6)
    assert len(worker.futures) == 1
    assert f.done()
    assert not f.result()

    f = worker.submit(do_work, 0.7)
    assert len(worker.futures) == 2

# Generated at 2022-06-12 15:03:01.335256
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    worker = MonoWorker()

    def f():
        time.sleep(1)
        return 1

    def f2():
        time.sleep(100)
        return 2

    def f3():
        time.sleep(100)
        return 3

    def f4():
        time.sleep(100)
        return 4

    f1 = worker.submit(f)
    f2 = worker.submit(f2)
    f3 = worker.submit(f3)
    f4 = worker.submit(f4)
    time.sleep(1)
    assert not f3.result()
    assert f4.result() == 1

# Generated at 2022-06-12 15:03:08.849727
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Set up:
    - add 2 tasks to fill up queue
    - start 1st task
    - submit 3rd task (should clear 2nd task)
    - recheck

    Expected output:
    - tasks 1-3 are submitted normally
    - tasks 4-5 are rejected, and respective exceptions are raised
    """
    import time
    # import os
    import logging

    def sleeper(dur, n, desc=None):
        time.sleep(dur / 10)
        tqdm_auto.write('Sleeping for {}s: {}'.format(dur, n))
        return n

    # tqdm_auto.set_slower_interval(slower_interval=0.01)
    # tqdm_auto.set_slower_interval(slower_interval=0.01

# Generated at 2022-06-12 15:03:17.610641
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from unittest import TestCase, main

    class Test(TestCase):
        def test(self):
            mw = MonoWorker()
            t = list(range(2))
            self.assertEqual(len(mw.futures), 0)
            mw.submit(sleep, t[0], 0.1)
            self.assertEqual(len(mw.futures), 1)
            mw.submit(sleep, t[1], 0.2)
            self.assertEqual(len(mw.futures), 2)
            mw.submit(sleep, t[0], 0.3)
            self.assertEqual(len(mw.futures), 2)
            mw.submit(sleep, t[1], 0.4)

# Generated at 2022-06-12 15:03:42.492529
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # import time
    import random
    import unittest
    import concurrent.futures

    class TestMonoWorkerSubmit(unittest.TestCase):
        def setUp(self):
            self.worker = MonoWorker()

        def test_submit_exception(self):
            self.assertRaises(ZeroDivisionError,
                              self.worker.submit, lambda: 1 / 0)

        def test_submit_success(self):
            future = self.worker.submit(lambda: 1)
            with self.assertRaises(concurrent.futures.CancelledError):
                future.cancel()
            self.assertEqual(future.result(), 1)


# Generated at 2022-06-12 15:03:53.279368
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def time_sleep(t):
        time.sleep(t)
        return t

    mono = MonoWorker()
    assert mono.futures == deque()

    mono.submit(time_sleep, 3)
    assert mono.futures == deque([3])

    mono.submit(time_sleep, 1)
    assert mono.futures == deque([3, 1])

    # submit but let it cancel
    mono.submit(time_sleep, 5)
    assert mono.futures == deque([3, 5])

    # free up a slot and then submit two
    mono.futures.popleft().result()
    assert mono.futures == deque([5])

    mono.submit(time_sleep, 1)

# Generated at 2022-06-12 15:04:02.086012
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import warnings

    def long_func(t):
        time.sleep(t)
        return t

    def short_func(t, v):
        time.sleep(t)
        return v

    def test_wait(submit, t, n):
        for i in range(n * 2):
            submit(long_func, t)
        assert len(submit.futures) == n

    def test_replace(submit, t, n):
        for i in range(n * 2):
            submit(short_func, t, i)
        assert len(submit.futures) == 1
        assert submit.futures[0].result() == n + 1

    def test_cancel(submit, t, n):
        with warnings.catch_warnings():
            warnings.simplefilter

# Generated at 2022-06-12 15:04:08.951584
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import time

    def eprint(*args, **kwargs):
        print(*args, file=sys.stderr, **kwargs)

    t = MonoWorker()
    eprint("submit slow")
    with tqdm_auto.tqdm(desc="slow", disable=not sys.stdout.isatty()) as s:
        for _ in range(5):
            t.submit(time.sleep, 0.5)
        s.postfix = ['postfix']
        s.close()

    eprint("submit fast")
    with tqdm_auto.tqdm(desc="fast", disable=not sys.stdout.isatty()) as f:
        for _ in range(5):
            t.submit(time.sleep, 0.1)
        f.update(1000)
        f

# Generated at 2022-06-12 15:04:19.240330
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method `submit` of class `MonoWorker`."""
    import time
    from queue import Queue

    M = MonoWorker()

    class PQ(Queue):
        """Queue for output."""
        def write(self, s):
            """Put string in queue."""
            self.put(s)

    q = PQ()
    tqdm_auto.write = q.write

    def sleep(t):
        """Function for testing."""
        q.write("sleeping for {}s".format(t))
        time.sleep(t)
        q.write("slept for {}s".format(t))

    # should not execute
    f1 = M.submit(sleep, 1)

    # should execute
    time.sleep(0.1)

# Generated at 2022-06-12 15:04:24.596313
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    with tqdm_auto.tqdm(ascii=True, desc='blah') as t:
        while t:
            time.sleep(0.2)
            cmd = 'done'
            mw.submit(tqdm_auto.write, cmd)
            t.set_description('cmd: %s' % cmd)
            t.update()



# Generated at 2022-06-12 15:04:32.229424
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    # Attempted execution of second and third jobs should not happen
    mw.submit(time.sleep, 1)
    mw.submit(time.sleep, 1)
    assert list(mw.futures) == [mw.futures[-1]]
    # first job should finish before second
    first = mw.futures[-1]
    second = mw.submit(time.sleep, 1)
    assert list(mw.futures) == [first, second]
    time.sleep(2)
    assert first.done() and second.done()

# Generated at 2022-06-12 15:04:40.352020
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Tests MonoWorker.submit with `tqdm` as a func.
    """
    import time
    import numpy as np
    from ..auto import tqdm

    tqdm_auto.write('Testing MonoWorker.submit', file=None, end='\n\n')

    fps = 20
    duration = 3

    def display(f):
        t = time.time()
        for i in tqdm(np.arange(fps * duration) / fps, desc=f.__name__, miniters=1,
                      mininterval=1 / fps):
            if fps * duration - i < 1:
                time.sleep(0.1)
            time.sleep(1 / fps - (time.time() - t))
            t = time.time()

    def display2(f):
        t

# Generated at 2022-06-12 15:04:47.457195
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test MonoWorker class

    Test the following:
        - The method MonoWorker.submit overrides the waiting task if it is the
          same function and if the waiting task is not running.
        - The method MonoWorker.submit keeps two tasks at most; the two tasks
          are the running task and the waiting one.
    """
    from time import sleep
    from random import random

    def func(x):
        sleep(x)
        return x

    m = MonoWorker()
    assert len(m.futures) == 0

    fut1 = m.submit(func, random())
    assert len(m.futures) == 1

    fut2 = m.submit(func, random())
    assert len(m.futures) == 2

    fut3 = m.submit(func, random())
    assert len

# Generated at 2022-06-12 15:04:54.532158
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    assert isinstance(mw.futures, deque)
    assert mw.submit(time.sleep, 2)
    # try to submit a new task without waiting for the first one to complete
    assert mw.submit(time.sleep, 2)
    assert mw.submit(time.sleep, 2, 1)
    # try to submit a new task without waiting for the first two to complete
    assert mw.submit(time.sleep, 2, 2)
    try:
        mw.submit(time.sleep, 2, 3, 4)
    except AssertionError:
        pass
    else:
        raise RuntimeError("Should have caught an AssertionError")

# Generated at 2022-06-12 15:05:35.389096
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def busy_work(n):
        time.sleep(n)
        return n

    with MonoWorker() as e:
        future = e.submit(busy_work, 1)
        assert (future.result() == 1)
        time.sleep(0.1)
        assert (e.submit(busy_work, 0.5).result() == 0.5)
        time.sleep(0.1)
        assert (e.submit(busy_work, 0.5).result() == 0.5)
        time.sleep(0.1)
        assert (future.result() == 1)
        time.sleep(0.1)
        assert (e.submit(busy_work, 0.5).result() == 0.5)
        time.sleep(0.1)

# Generated at 2022-06-12 15:05:45.516918
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import wait

    def plus(x, y): return x + y

    for _ in tqdm_auto.trange(100, desc='testing tqdm.contrib.concurrent'):
        m = MonoWorker()
        assert len(m.futures) == 0

        f1 = m.submit(plus, 1, 2)
        assert len(m.futures) == 1

        f2 = m.submit(plus, 3, 4)
        assert len(m.futures) == 1

        assert f2.done() and f2.result() == 7

        # interrupt f1
        wait([f1])
        assert len(m.futures) == 1
        assert f1.done() and f1.result() == 3
        assert f2.result() == 7

       

# Generated at 2022-06-12 15:05:53.650533
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test MonoWorker.submit method."""
    from time import sleep

    # test
    worker = MonoWorker()

    def echo(*args, **kwargs):
        sleep(1)
        return (args, kwargs)

    # test task queue
    def test_task_queue(worker, expected):
        for _ in range(worker.futures.maxlen):
            worker.submit(echo, 1, 2, a=3, b=4)
            assert len(worker.futures) == expected
            expected -= 1

    test_task_queue(worker, 1)
    test_task_queue(worker, 2)

    # test execution
    res1 = worker.submit(echo, 1, 2, a=3, b=4)

# Generated at 2022-06-12 15:06:04.214067
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def delay(x, t=0.02):
        time.sleep(t)
        return x

    x = MonoWorker()
    assert len(x.futures) == 0
    x.submit(lambda: delay(1))
    assert len(x.futures) == 1
    x.submit(lambda: delay(2))
    assert len(x.futures) == 2
    x.submit(lambda: delay(3))
    assert len(x.futures) == 2
    x.submit(lambda: delay(4))
    assert len(x.futures) == 2
    assert x.futures[-1].result() == 4

    def delay_exception(x, t=0.02):
        time.sleep(t)
        raise Exception(x)

    x

# Generated at 2022-06-12 15:06:11.922780
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm._utils import _term_move_up
    from ..gui import tqdm  # NOQA

    def slow_inc(x):
        sleep(0.01)
        return x + 1

    def slow_dec(x):
        sleep(0.01)
        return x - 1

    mono_worker = MonoWorker()

    pbar = tqdm(total=3)
    future = mono_worker.submit(slow_inc, 0)
    pbar.update()

    mono_worker.submit(slow_inc, 1)
    pbar.update()

    mono_worker.submit(slow_dec, 3)
    pbar.update()

    while not future.done():
        sleep(0.001)
        pbar.write('Waiting...')
    pbar

# Generated at 2022-06-12 15:06:16.577308
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import format_sizeof
    from .fate import fate

    def noop(*a, **k):
        pass

    # Override tqdm_auto.write to test it
    write = tqdm_auto.write
    printed = []

# Generated at 2022-06-12 15:06:24.873489
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import numpy as np
    import threading

    a = MonoWorker()
    b = MonoWorker()

    def f1(x):
        time.sleep(0.5)
        return x * np.random.randn(50)

    futures = []
    for x in range(1000):
        futures.append(a.submit(f1, x))
        futures.append(b.submit(f1, x))
        # print('x = {}'.format(x))
        # for future in futures:
        #     print("{}: {}".format(future, future.running()))
    for future in futures:
        assert not future.running()
        assert future.done()
        assert not future.cancelled()

    def f2(i, x):
        time.sleep(0.5)

# Generated at 2022-06-12 15:06:31.985564
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    # Unit test
    def raise_exception(*args, **kwargs):
        """Raises an exception."""
        raise Exception("E")

    def return_10(*args, **kwargs):
        """Returns 10."""
        return 10

    def return_after_10s(*args, **kwargs):
        """Sleeps for 10 seconds, then returns 10."""
        time.sleep(10)
        return 10

    def dummy_func(*args, **kwargs):
        """Returns 0."""
        return 0
    # Init
    mono = MonoWorker()
    # Test: exception
    tqdm_auto.write("Test: exception")
    ret = mono.submit(raise_exception)
    assert ret.done()

# Generated at 2022-06-12 15:06:41.732975
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Value
    from sys import argv as _argv
    max_time = 20.0
    if len(_argv) > 1:
        max_time = float(_argv[1])
    # max_time = 60.0


# Generated at 2022-06-12 15:06:48.550272
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import time

    mw = MonoWorker()

    def test_submit(n, t):
        time.sleep(t)
        tqdm_auto.write("%s @ %.3f" % (n, time.time()))

    # Queue 3 jobs - only the latest should run
    mw.submit(test_submit, 1, 1)
    mw.submit(test_submit, 2, 0.5)
    mw.submit(test_submit, 3, 0)

    time.sleep(0.5)
    tqdm_auto.write("-" * 36)

    # Queue 3 more jobs - only the latest should run
    mw.submit(test_submit, 4, 1)
    mw.submit(test_submit, 5, 0.5)