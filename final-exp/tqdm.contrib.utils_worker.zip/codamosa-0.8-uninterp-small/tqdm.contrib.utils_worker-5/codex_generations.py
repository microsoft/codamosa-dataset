

# Generated at 2022-06-26 09:33:05.750842
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, "hello")

# Generated at 2022-06-26 09:33:10.545802
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def test_func(duration):
        time.sleep(duration)
        assert duration == 1
        return duration

    mono_worker_1 = MonoWorker()

    mono_worker_1.submit(test_func, 1)
    mono_worker_1.submit(test_func, 2)
    mono_worker_1.submit(test_func, 3)
    mono_worker_1.submit(test_func, 4)
    mono_worker_1.submit(test_func, 5)
    mono_worker_1.submit(test_func, 6)


# Generated at 2022-06-26 09:33:19.931846
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
  from random import random
  from threading import Event
  from time import sleep, time
  from queue import Queue

  e = Event()
  q = Queue()

  def submit(args):
    q.put(mono_worker.submit(*args))  # may replace currently waiting task

  def wait_for(futures):
    sleep(0.1 * int(0.5 + 5 * random()))
    while not e.is_set():
      sleep(0.1 * int(0.5 + 10 * random()))
    while not q.empty():
      futures.append(q.get())
    for f in futures:
      f.cancel()


# Generated at 2022-06-26 09:33:23.309330
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def f():
        pass
    mono_worker_0.submit(f)


# Generated at 2022-06-26 09:33:26.202042
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit('hello', 'world')

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:33:33.984531
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    with tqdm_auto.tqdm(leave=False) as pbar:
        mono_worker_0 = MonoWorker()
        for i in range(0, 10):
            time.sleep(random.random())
            mono_worker_0.submit(print, i, 'hi')



# Generated at 2022-06-26 09:33:40.771522
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    tqdm_auto.write(str(5))
    tqdm_auto.write(str('xyz'))
    tqdm_auto.write(str('xyz'))
    tqdm_auto.write(str(5))
    tqdm_auto.write(str('xyz'))
    tqdm_auto.write(str(5))
    tqdm_auto.write(str(5))
    tqdm_auto.write(str('xyz'))
    tqdm_auto.write(str('xyz'))
    tqdm_auto.write(str(5))
    tqdm_auto.write(str(5))
    tqdm_auto.write(str('xyz'))
    tqdm_auto.write(str('xyz'))
    tq

# Generated at 2022-06-26 09:33:43.575037
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # mono_worker_0 = MonoWorker()
    # mono_worker_0.submit(func, *args, **kwargs)
    pass


# Generated at 2022-06-26 09:33:51.320649
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    from queue import Queue
    from threading import Thread
    from time import sleep

    EXECUTION_QUEUE = Queue(maxsize=1)
    RESULT_QUEUE = Queue(maxsize=1)

    def func(num):
        sleep(1)
        RESULT_QUEUE.put(num)

    def execute_func(execution_queue, result_queue):
        for i in range(10):
            execution_queue.get()
            mono_worker_0.submit(func,i)
            sleep(0.2)
        result_queue.put(1)

    t1 = Thread(target=execute_func, args=(EXECUTION_QUEUE,RESULT_QUEUE))
    t1.start()
    for i in range(10):
        EXECUTION_QUE

# Generated at 2022-06-26 09:33:52.681992
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

# Generated at 2022-06-26 09:34:07.844481
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert (mono_worker_0.submit(abs, -3) is not None)
    assert (mono_worker_0.submit(int, '3') is not None)

if __name__ == "__main__":
    print("Called __main__")

# https://coverage.readthedocs.io/en/coverage-4.4.2/
# https://stackoverflow.com/questions/10819959/python-unittest-how-to-pass-command-line-options-to-the-program
# python3 -m unittest tests/contrib/test_concurrent.py
# coverage run -m unittest tests/contrib/test_concurrent.py
# coverage report --include=tqdm/contrib/con

# Generated at 2022-06-26 09:34:19.278965
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Assert that multiple threads can be run concurrently.
    """
    import time
    from tqdm.contrib.concurrency import MonoWorker

    def sleep_f(duration=0.5):
        """Keep track of sleep time."""
        start_time = time.time()
        time.sleep(duration)
        return time.time() - start_time

    worker = MonoWorker()
    # Submit a thread that sleeps for 1 s
    t1 = worker.submit(sleep_f, 1.0)
    # Submit a thread that sleeps for 2 s
    t2 = worker.submit(sleep_f, 2.0)
    # Confirm thread #2 (2 s) is currently executing
    assert t1.done()
    assert not t2.done()
    # Submit a thread that sleeps for 0.5 s


# Generated at 2022-06-26 09:34:25.923031
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func():
        import time
        time.sleep(1)
        return "result"
    with tqdm_auto.tqdm(total=1) as pbar:
        future = mono_worker_0.submit(func)
        pbar.update(0)
        for _ in range(10):
            future.result()
            pbar.update(1)

# Generated at 2022-06-26 09:34:30.735903
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Testing for method submit
    # Test case 0
    mono_worker_0 = MonoWorker()
    def func():
	    return ""
    mono_worker_0.submit(func)

# Generated at 2022-06-26 09:34:33.740208
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, 'hello world!')



# Generated at 2022-06-26 09:34:36.528758
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert (mono_worker_0.submit(int, '5').result() == 5)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:34:42.198247
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .mono_worker import MonoWorker
    
    mono_worker_0 = MonoWorker()
    from time import sleep as sleep
    from sys import executable as python
    from subprocess import Popen as Popen
    
    def func_0(*args, **kwargs):
        pass
    
    mono_worker_0.submit(func_0)


if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:34:46.170366
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func(arg):
        return arg+1
    assert (mono_worker_0.submit(func, 1).result() == 2)


# Generated at 2022-06-26 09:34:58.454907
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures
    import threading
    import time
    import random

    def f(x):
        time.sleep(0.01 + 0.01 * random.random())
        return 10 / x

    mono_worker = MonoWorker()
    futures = []
    for _ in tqdm_auto.tqdm(range(4), desc='MonoWorker.submit'):
        # submit(func, *args, **kwargs)
        future = mono_worker.submit(f, 2)
        futures.append(future)
    for _ in tqdm_auto.tqdm(concurrent.futures.as_completed(futures),
                            desc='MonoWorker.result'):
        pass



# Generated at 2022-06-26 09:35:02.695828
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(int)

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:15.693044
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    MONO = MonoWorker()

    def print_time():
        print(time.time())
        time.sleep(1.5)
        print(time.time())

    res = MONO.submit(print_time)
    MONO.submit(print_time)
    MONO.submit(print_time)


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:28.068084
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import unittest
    import sys
    mono_worker_0 = MonoWorker()
    def test_func(arg0):
        time.sleep(arg0)
        return arg0
    result = 0
    for i in range(3):
        result = mono_worker_0.submit(test_func, i)
        if result != i:
            print("Test Fail: expecting {} for result, got {}".format(i, result))
            return
    if result != 2:
        print("Test Fail: expecting {} for result, got {}".format(2, result))
        return
    else:
        print("Test Pass")

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:33.687585
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(time.sleep,5)
    mono_worker_0.submit(time.sleep,5)
    mono_worker_0.submit(time.sleep,5)

# Generated at 2022-06-26 09:35:40.775942
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    assert len(mono_worker_1.futures) == 0

    # submit a first task
    t_0 = mono_worker_1.submit(lambda n: n, n=0)
    assert len(mono_worker_1.futures) == 1
    assert t_0 is mono_worker_1.futures[0]

    # submit a second task (should replace first)
    t_1 = mono_worker_1.submit(lambda n: n, n=1)
    assert len(mono_worker_1.futures) == 1
    assert t_1 is mono_worker_1.futures[0]

    # submit a third task (should replace second)

# Generated at 2022-06-26 09:35:47.103582
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from itertools import count
    from time import sleep
    def return_x(x):
        sleep(x)
        return x
    mono_worker_0 = MonoWorker()
    for i in count():
        j = mono_worker_0.submit(return_x, i)
        if i > 3 and i % 3 == 0:
            assert j.cancel() == False
    return True


# Generated at 2022-06-26 09:35:50.117950
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    m_mono_worker = MonoWorker()
    m_mono_worker.submit(func, *args, **kwargs)

# Generated at 2022-06-26 09:35:55.543946
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    for i in tqdm_auto.tqdm(range(2)):
        mono_worker_0.submit(self=mono_worker_0, func=lambda : None)

# Generated at 2022-06-26 09:35:59.602714
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Simple unit test for method submit of class MonoWorker.
    """
    # Test case #0
    test_case_0()

# Generated at 2022-06-26 09:36:03.874652
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    test_case_0()

# Generating and testing cases
if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:36:06.715006
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def test_submit_case_0():
        def func_0():
            return 0
        mono_worker_0.submit(func_0)
    test_submit_case_0()


# Generated at 2022-06-26 09:36:20.649686
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .render_utils import test_eq as _test_eq
    # set input values
    func = 1
    args = 1
    kwargs = 1
    # init instance
    w = MonoWorker()
    # expected values
    expected = 1
    # do test
    output = w.submit(func, args, kwargs)
    # assert test
    _test_eq(output, expected)

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()
    print("Done")

# Generated at 2022-06-26 09:36:31.842908
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    import threading
    from .utils import FakeTqdmFile

    mono_worker = MonoWorker()

    with FakeTqdmFile(leave=True) as fake_file:
        def callback(arg):
            fake_file.write(str(arg))
            return arg

        assert isinstance(mono_worker.submit(callback, 0), Future)
        assert len(mono_worker.pool._threads) == 1
        thread = list(mono_worker.pool._threads)[0]
        thread.join()

        mono_worker.submit(callback, 1)
        mono_worker.submit(callback, 2)
        thread = list(mono_worker.pool._threads)[0]
        thread.join()

        fake_file.seek(0)
        assert fake_

# Generated at 2022-06-26 09:36:39.378808
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    futures = mono_worker_0.futures
    assert(len(futures) == 0)
    mono_worker_0.submit(list, [1, 2, 3])
    assert(len(futures) == 1)
    mono_worker_0.submit(list, [4, 5, 6])
    assert(len(futures) == 1)

# Generated at 2022-06-26 09:36:43.038624
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(str, 1, 2)


# Generated at 2022-06-26 09:36:48.242048
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    tqdm_auto.write('Begin test_submit')
    tqdm_auto.write('...')
    tqdm_auto.write('End test_submit')


# Generated at 2022-06-26 09:36:51.431242
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(print, 'hello world')
    tqdm_auto.write('the task is submitting')


if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:36:59.203962
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def test(arg):
        return arg
    assert mono_worker_0.submit(test, 1).result() == 1
    assert mono_worker_0.submit(test, 2).result() == 2
    assert mono_worker_0.submit(test, 3).result() == 3

# Generated at 2022-06-26 09:37:03.734581
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    from ..auto import tqdm as tqdm_auto
    from time import sleep

    def _test_submit(n):
        mono_worker_0 = MonoWorker()
        with tqdm_auto.tqdm(desc="iteration 0") as t:
            sleep(1)
            t.update()

        with tqdm_auto.tqdm(desc="iteration 1") as t:
            sleep(1)
            t.update()

        def _submit_exception(x):
            raise ValueError("BOO!")

        mono_worker_0.submit(_submit_exception, 1)

        def _submit_warning(x):
            # sleep(1)
            sys.stderr.write("stderr\n")
            print("stdout")

        mono_worker_0

# Generated at 2022-06-26 09:37:08.101741
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    arg0 = None
    arg1 = None
    arg2 = None
    mono_worker_0.submit(arg0, arg1, arg2)

# Generated at 2022-06-26 09:37:14.142099
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    time_0 = time()
    time_diff_0 = time_0
    def _func_0(a_param_0=5, a_param_1=5):
        while time() - time_diff_0 < a_param_0:
            sleep(0.01)
        return time() - time_0
    _future_0 = mono_worker_0.submit(_func_0)
    time_diff_0 = time()
    while not _future_0.done():
        sleep(0.01)
    _1_ = _future_0.result()


# Generated at 2022-06-26 09:37:38.586160
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    tqdm_auto.write("Testing submit ...")
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(tqdm_auto.write, "Test 1")
    mono_worker_0.submit(tqdm_auto.write, "Test 2")
    mono_worker_0.submit(tqdm_auto.write, "Test 3")


# Generated at 2022-06-26 09:37:44.629072
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing
    cpu_count = multiprocessing.cpu_count()

    def mock(i, msec=0.5):
        import time
        time.sleep(msec)
        return i * 2

    mono_worker = MonoWorker()
    # test: submit few tasks and check results
    results = [mono_worker.submit(mock, i) for i in range(cpu_count)]
    while results:
        res = results.pop().result()
        print(res)
        assert res == len(results) * 2
    # test: submit few tasks and cancel them
    results = [mono_worker.submit(mock, i, msec=2) for i in range(cpu_count)]
    while results:
        res = results.pop().result()
        print(res)

# Generated at 2022-06-26 09:37:53.642174
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    assert mono_worker.submit(lambda x: 2 * x, 2)
    assert len(mono_worker.futures) == 1
    assert len(mono_worker.futures) == mono_worker.futures.maxlen
    assert mono_worker.submit(lambda x: 2 * x, 2)
    assert len(mono_worker.futures) == 0
    assert len(mono_worker.futures) == mono_worker.futures.maxlen
    assert mono_worker.submit(lambda x: 2 * x, 2)
    assert len(mono_worker.futures) == 1
    assert len(mono_worker.futures) == mono_worker.futures.maxlen

# Generated at 2022-06-26 09:38:03.697417
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test cases
    def test_case_0(func, args, kwargs):
        # Test arguments
        func0 = lambda: None
        args0 = ()
        kwargs0 = {}
        input0 = func0, args0, kwargs0
        expected0 = None
        # Perform the test
        test = MonoWorker()
        test.func, test.args, test.kwargs = func, args, kwargs
        output0 = test.submit(*input0)
        try:
            assert expected0 == output0
        except AssertionError:
            raise AssertionError(str(expected0) +
                ' != ' + str(output0))
    def test_case_1(func, args, kwargs):
        # Test arguments
        func1 = lambda: None

# Generated at 2022-06-26 09:38:15.167568
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    # Type check
    # Test if func is a function
    assert not mono_worker_0.submit('func', args, kwargs), 'Incorrect input. func should be a function.'

    # Test if arguments are correct
    assert not mono_worker_0.submit(func, "args", kwargs), 'Incorrect input. args should be a tuple.'
    assert not mono_worker_0.submit(func, args, "kwargs"), 'Incorrect input. kwargs should be a dict.'

    # Test if future is empty
    assert not mono_worker_0.submit(func, args, kwargs), 'Future is empty, should not submit tasks.'

    # Test if future is not empty
    assert not mono_worker_0.submit(func, args, kwargs), 'Future is not empty, should not submit tasks.'

# Generated at 2022-06-26 09:38:23.427207
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    self = MonoWorker()
    def foo():
        super().__init__(self, func, max_workers=self.max_workers)

# Generated at 2022-06-26 09:38:25.323571
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

# Generated at 2022-06-26 09:38:36.094366
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def worker(i):
        time.sleep(1)
        return i

    mono_worker_0 = MonoWorker()

    # Test that submit() replaces currently waiting task.
    # Submit task 1.
    future_1 = mono_worker_0.submit(worker, 1)
    time.sleep(0.1)
    # Submit task 2.
    future_2 = mono_worker_0.submit(worker, 2)
    time.sleep(0.1)
    # Results in running 2, waiting 1, and discarding 2.
    assert future_1.done()
    assert not future_2.done()
    assert not future_1.result() == 1
    assert not future_2.result() == 2


if __name__ == "__main__":
    test_case_0()
    test_

# Generated at 2022-06-26 09:38:48.211405
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    random.seed()
    limit = 6
    t0 = time.time()
    for i in range(limit):
        for x in range(3):
            tqdm_auto.write(str(i) + ': ' + str(mono_worker_0.submit(random.randint, 0, 100)))
            # print(i, ':', mono_worker_0.submit(random.randint, 0, 100))
            # print(str(i) + ': ' + str(mono_worker_0.submit(random.randint, 0, 100)))
        time.sleep(1)
    tqdm_auto.write('Time elapsed: {:.3f}s'.format(time.time() - t0))
    # print('Time elapsed: {:.3f}s'.format

# Generated at 2022-06-26 09:38:53.345680
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit tests for method submit of class MonoWorker.

    """

    def dummy_submit(func, *args, **kwargs):
        pass

    # Case(s) for verification of pre-conditions

    # Case(s) for verification of post-conditions

    # Case(s) for verification of invariants



# Generated at 2022-06-26 09:39:31.600797
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from time import time

    def do_work(i, worktime):
        t0 = time()
        sleep(worktime)
        return i, time() - t0

    worker = MonoWorker()
    for i in range(10):
        worker.submit(do_work, i, random() * 0.01)
        sleep(random() * 0.01)



# Generated at 2022-06-26 09:39:38.316076
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random

    mono_worker = MonoWorker()
    count = 0
    while True:
        mono_worker.submit(print, count)
        count += 1
        if random.randint(0, 3) == 1:
            break

test_case_0()
test_MonoWorker_submit()
print("Done.")


# Generated at 2022-06-26 09:39:43.702293
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    max_workers = 1
    test_MonoWorker = MonoWorker()
    test_func = lambda x: x ** 2
    test_args = (10,)
    test_kwargs = {'key0': 20}
    result = test_MonoWorker.submit(test_func, *test_args, **test_kwargs)
    assert result.result() == 100

# Generated at 2022-06-26 09:39:47.995366
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit()


if __name__ == "__main__":
    import sys
    test_case_0()
    test_MonoWorker_submit()
    sys.exit()

# vim: set sts=4 ts=4 sw=4 et:

# Generated at 2022-06-26 09:39:58.141525
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import ThreadPoolExecutor

    mono_worker_0 = MonoWorker()


# Generated at 2022-06-26 09:40:04.975763
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    futures_0 = mono_worker_0.futures
    assert(len(futures_0) == futures_0.maxlen)
    assert(mono_worker_0.submit(float, '3.14') != None)


# Generated at 2022-06-26 09:40:06.880017
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Basic test
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda : 1, )


# Generated at 2022-06-26 09:40:12.944551
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda a1, kw1=2: a1 + kw1, 1)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 09:40:17.650416
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    success = 0
    failure = 0
    try:
        mono_worker_0 = MonoWorker()
        future_0 = mono_worker_0.submit(print, 'hello')
        if wait_future(future_0):
            success += 1
        else:
            failure += 1
    except Exception:
        failure += 1
    assert success > 0 and failure == 0


# Generated at 2022-06-26 09:40:22.095614
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert 0
    mono_worker_0.submit(int, '1', base=2)


# Generated at 2022-06-26 09:41:31.588703
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    An test for function submit
    """
    mono_worker_0 = MonoWorker()
    func_0 = lambda: 0
    mono_worker_0.submit(func_0)

# Generated at 2022-06-26 09:41:39.384347
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Testing inputs for method `submit()` of class `MonoWorker`.
    """
    try:
        mono_worker_0 = MonoWorker()

        try:
            mono_worker_0.submit()
            assert False
        except TypeError:
            assert True

        try:
            mono_worker_0.submit(1)
            assert False
        except TypeError:
            assert True
    except Exception as e:
        assert False



# Generated at 2022-06-26 09:41:51.829432
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    try:
        time.time = time.time
    except:
        pass
    time_value_0 = time.time()
    time_value_1 = time.time()
    time_value_2 = time.time()
    time_value_3 = time.time()
    time_value_4 = time.time()
    time_value_5 = time.time()
    time_value_6 = time.time()
    time_value_7 = time.time()
    time_value_8 = time.time()
    time_value_9 = time.time()
    time_value_10 = time.time()
    time_value_11 = time.time()
    time_value_12 = time.time()
    time_value_13 = time.time()

# Generated at 2022-06-26 09:42:04.257034
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.MonoWorker()
    func_1 = object()
    result_2 = mono_worker_0.submit(func_1)
    assert result_2 is not None
    args_3 = (object(), object())
    result_4 = mono_worker_0.submit(func_1, *args_3)
    assert result_4 is not None
    kwargs_5 = {'a': object(), 'b': object()}
    result_6 = mono_worker_0.submit(func_1, **kwargs_5)
    assert result_6 is not None
    result_7 = mono_worker_0.submit(func_1, *args_3, **kwargs_5)
    assert result_7 is not None

# Generated at 2022-06-26 09:42:16.454025
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..contrib.concurrent.processes import thread_map
    from ..contrib.concurrent import thread_map

    mono_worker_0 = MonoWorker()
    num_tasks = 5
    num_executions = 5
    num_workers = 1
    time_tasks = [1 for n in range(num_tasks)]
    thread_map(time.sleep, time_tasks, num_workers=num_workers,
               mono_worker=mono_worker_0)
    execution_times = []
    for _ in range(num_executions):
        start = time.time()
        thread_map(time.sleep, time_tasks, num_workers=num_workers,
                   mono_worker=mono_worker_0)

# Generated at 2022-06-26 09:42:25.686958
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import Process
    import time, os

    def sleep_mkfile(secs, fname):
        time.sleep(secs)
        with open(fname, 'w') as tfile:
            tfile.write(str(os.getpid()))

    mono_worker = MonoWorker()
    fname_0 = 'test_worker0.txt'
    fname_1 = 'test_worker1.txt'
    mono_worker.submit(sleep_mkfile, 2, fname_0)
    mono_worker.submit(sleep_mkfile, 2, fname_1)
    time.sleep(3)
    assert not os.path.exists(fname_0)
    assert os.path.exists(fname_1)

# Generated at 2022-06-26 09:42:33.141308
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func_0(*args, **kwargs):
        while True:
            pass
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(func_0,  )

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:42:45.770293
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func_0(*args, **kwargs):
        # run line 5 of python script
        return

    for i in tqdm_auto.tqdm(range(10), desc='1st loop'):
        mono_worker_0.submit(func_0, *args, **kwargs)
    for i in tqdm_auto.tqdm(range(5), desc='2nd loop'):
        mono_worker_0.submit(func_0, *args, **kwargs)
    for i in tqdm_auto.tqdm(range(10), desc='3rd loop'):
        mono_worker_0.submit(func_0, *args, **kwargs)


if __name__ == '__main__':
    test_case_0()
   

# Generated at 2022-06-26 09:42:55.514654
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def dummy_func(*args, **kwargs):
        sleep(5)

    mono_worker_0 = MonoWorker()
    ret_value_0 = mono_worker_0.submit(dummy_func)
    assert ret_value_0 is not None
    ret_value_1 = mono_worker_0.submit(dummy_func)
    assert ret_value_1 is not None
    ret_value_2 = mono_worker_0.submit(dummy_func, args=(), kwargs={})
    assert ret_value_2 is not None



# Generated at 2022-06-26 09:43:06.938723
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    def _sleep_print(_t):
        sleep(_t)
        return _t
    mono_worker_1 = MonoWorker()
    assert mono_worker_1.submit(_sleep_print, 0.5).result() == 0.5
    assert mono_worker_1.submit(_sleep_print, 0.1).result() == 0.1
    assert mono_worker_1.submit(_sleep_print, 0.2).result() == 0.2
    assert mono_worker_1.submit(_sleep_print, 0.3).result() == 0.3
    assert mono_worker_1.submit(_sleep_print, 0.4).result() == 0.4
    assert mono_worker_1.submit(_sleep_print, 0.5).result() == 0.5