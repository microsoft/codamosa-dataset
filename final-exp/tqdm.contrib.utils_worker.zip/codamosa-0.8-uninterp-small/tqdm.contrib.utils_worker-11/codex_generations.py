

# Generated at 2022-06-26 09:33:19.237828
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from subprocess import Popen, PIPE, check_output
    from threading import Thread
    from Queue import Queue, Empty
    from time import sleep

    def run_process(mono_worker):
        process = Popen(['sleep', '7'], stdout=PIPE, stderr=PIPE)
        future = mono_worker.submit(process.wait)
        future.result()

    mono_worker_0 = MonoWorker()
    thread_0 = Thread(target=run_process, args=(mono_worker_0,))
    thread_0.start()
    sleep(1)
    run_process(mono_worker_0)
    thread_0.join()

    def run_command(mono_worker):
        command = ['sleep', '7']
        future = mono_worker

# Generated at 2022-06-26 09:33:21.726022
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(test_case_0)

# Generated at 2022-06-26 09:33:29.231876
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def echo(n):
        time.sleep(1)
        return n
    mono_worker_0 = MonoWorker()
    answer = mono_worker_0.submit(echo, 1)
    assert answer is not None
    assert 1 == answer.result()
    answer = mono_worker_0.submit(echo, 2)
    assert answer is not None
    assert 2 == answer.result()
    mono_worker_0.submit(echo, 3)
    answer = mono_worker_0.submit(echo, 4)
    assert 4 == answer.result()
    time.sleep(1)
    answer = mono_worker_0.submit(echo, 5)
    assert 5 == answer.result()



# Generated at 2022-06-26 09:33:39.762201
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import numpy as np
    from itertools import chain

    mono_worker_1 = MonoWorker()
    mono_worker_1.submit( np.random.randint, 100, size=10 )

    mono_worker_2 = MonoWorker()
    mono_worker_2.submit( np.random.randint, 100, size=10 )

    mono_worker_3 = MonoWorker()
    mono_worker_3.submit( np.random.randint, 100, size=10 )

    mono_worker_4 = MonoWorker()
    mono_worker_4.submit( np.random.randint, 100, size=10 )


# Generated at 2022-06-26 09:33:48.452870
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Testing only the MonoWorker class locally
    import sys
    import os

    # Changing working directory to the script directory
    # so all resources are relative to it.
    os.chdir(sys.path[0])

    if sys.version_info < (3, 0):
        print("MonoWorker testsuite needs Python 3")
        sys.exit(1)

    # Creating MonoWorker object
    mono_worker_0 = MonoWorker()

    # Testing submit method of MonoWorker
    try:
        mono_worker_0.submit(print, "hello world")
        if mono_worker_0.pool.submit(print, "hello world") is None:
            print("submit of MonoWorker was successful")
        else:
            print("submit of MonoWorker was not successful")
    except RuntimeError:
        print

# Generated at 2022-06-26 09:33:58.384204
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    import time

    import pytest

    def on_next(x):
        time.sleep(1)  # blocks for 1 second
        return x + 1

    def test_1():
        mono_worker_0 = MonoWorker()

        xs = [mono_worker_0.submit(on_next, i) for i in range(10)]
        assert len(mono_worker_0.futures) == 2
        for x in xs:
            x.result(timeout=100)

        assert len(mono_worker_0.futures) == 0

    def test_2():
        mono_worker_0 = MonoWorker()
        xs = [mono_worker_0.submit(on_next, i) for i in range(10)]

# Generated at 2022-06-26 09:34:08.709678
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    tqdm_auto.write('Testing MonoWorker submit method')
    from time import sleep
    import warnings
    mono_worker_1 = MonoWorker()

    # Testing 1. Simple submission
    mono_worker_1.submit(sleep, 1)

    # Testing 2. Concurrent submission
    mono_worker_1.submit(sleep, 1)
    mono_worker_1.submit(sleep, 1)

    # Testing 3. Overlapping submission
    mono_worker_1.submit(sleep, 3)
    mono_worker_1.submit(sleep, 1)

    # Testing 4. Replacement
    mono_worker_1.submit(sleep, 3)
    mono_worker_1.submit(sleep, 1)

    # Testing 5. Replacement of running task
    mono_worker_1.submit(sleep, 3)
    mono_worker

# Generated at 2022-06-26 09:34:12.474890
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(func=test_case_0, args=None, kwargs=None)

# Generated at 2022-06-26 09:34:17.554338
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    print_lock = threading.Lock()
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(print, 1, lock=print_lock)
    mono_worker_1.submit(print, 2, lock=print_lock)
    mono_worker_1.submit(print, 3, lock=print_lock)

# Generated at 2022-06-26 09:34:19.141274
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    pass

# Generated at 2022-06-26 09:34:23.524695
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(ll, 10)


# Generated at 2022-06-26 09:34:28.675707
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    assert mono_worker.submit(max, [1, 2, 3, 4, 5]) is not None
    assert mono_worker.pool.submit(max, [1, 2, 3, 4, 5]) is not None


if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()



# Generated at 2022-06-26 09:34:33.203474
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    try:
        mono_worker_0 = MonoWorker()
        assert mono_worker_0.submit("2")
    except ValueError:
        assert mono_worker_0.submit("3")


# Generated at 2022-06-26 09:34:42.709896
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures

    def f(x):
        import time
        time.sleep(100)
        return x*x

    pool = concurrent.futures.ThreadPoolExecutor(max_workers=10)
    futures = []
    for i in range(10):
        future = mono_worker_0.submit(f, i)
        futures.append(future)

    for future in futures[-3:]:
        assert future.result() == (9-i)*(9-i)

    for future in futures[:-3]:
        assert not future.done()



# Generated at 2022-06-26 09:34:50.220538
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import tqdm

    mono_worker = MonoWorker()
    lambda_func = lambda x: time.sleep(1)
    futures = [mono_worker.submit(lambda_func, i) for i in
               tqdm.tqdm(range(3))]
    [f.result() for f in futures]
    mono_worker.submit(lambda_func, 3)

    futures_0 = [mono_worker.submit(lambda_func, i) for i in
                 tqdm.tqdm(range(3))]
    time.sleep(1)
    futures_1 = [mono_worker.submit(lambda_func, i) for i in
                 tqdm.tqdm(range(3))]
    print('futures_1 =', futures_1)

# Generated at 2022-06-26 09:34:55.219371
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test 0
    mono_worker_0 = MonoWorker()
    # Test 1
    mono_worker_0 = MonoWorker()


if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:34:57.311386
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(time.sleep, 2)
    mono_worker_0.submit(time.sleep, 2)

# Generated at 2022-06-26 09:35:02.763771
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(time.sleep, 0.0)


if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:09.516384
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_2 = MonoWorker()

    def worker_func_1(a, b, c='d'):
        return a + b + c

    def output():
        print ("Result of worker_1: " + str(mono_worker_1.futures[0].result()))

    def output2():
        print ("Result of worker_2: " + str(mono_worker_2.futures[0].result()))

    mono_worker_1.submit(worker_func_1, 1, 2)
    mono_worker_1.futures[0].add_done_callback(output)
    mono_worker_1.submit(worker_func_1, 2, 3, c='e')

# Generated at 2022-06-26 09:35:12.900565
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    def func1():
        pass
    assert mono_worker_1.submit(func1) is non

# Generated at 2022-06-26 09:35:18.207278
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    assert False

# Generated at 2022-06-26 09:35:28.925542
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker."""
    def test_func(x):
        print("test_func is called with x="+str(x))
        return x*x

    def first_func():
        test_func(1)

    def second_func():
        test_func(2)

    print("Test submission of first_func:")
    mono_worker_1 = MonoWorker()
    future_1 = mono_worker_1.submit(first_func)
    print("Submit result: "+str(future_1))
    print("")
    print("Test submission of second_func:")
    mono_worker_2 = MonoWorker()
    future_2 = mono_worker_2.submit(second_func)
    print("Submit result: "+str(future_2))
    return


# Generated at 2022-06-26 09:35:32.206840
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    func_0 = ""
    mono_worker_0.submit(func_0, )

# Generated at 2022-06-26 09:35:41.573061
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def wait_5_seconds(x):
        for i in range(5):
            time.sleep(1)
            print(i)
    mono_worker_0 = MonoWorker()
    future_0 = mono_worker_0.submit(wait_5_seconds, 0)
    time.sleep(2)
    future_1 = mono_worker_0.submit(wait_5_seconds, 1)
    time.sleep(2)
    future_2 = mono_worker_0.submit(wait_5_seconds, 2)
    time.sleep(6)
    future_3 = mono_worker_0.submit(wait_5_seconds, 3)
    time.sleep(1)
    print(future_0.result())
    print(future_1.result())
    print(future_2.result())

# Generated at 2022-06-26 09:35:46.154762
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def test_func_0(test_var_0):
        assert test_var_0 == 1
    result = mono_worker_0.submit(test_func_0, 1)


# Generated at 2022-06-26 09:35:51.185091
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def _submit_no_return_func():
        pass
    mw = MonoWorker()
    a = mw.submit(_submit_no_return_func)
    print(a)
    assert True



# Generated at 2022-06-26 09:35:53.847443
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()


# Generated at 2022-06-26 09:36:00.424808
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    # Tests that don't require a thread pool
    mono_worker_0 = MonoWorker()
    # Testing "submit" method
    mono_worker_0.submit(randint, 0, 10)
    mono_worker_0.submi

# Generated at 2022-06-26 09:36:08.376596
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    print("Testing for method submit of class MonoWorker")
    mono_worker_0 = MonoWorker()
    func_0 = lambda x:x
    args_0 = 1
    kwargs_0 = {}
    mono_worker_0.submit(func_0, args_0, **kwargs_0)
    
if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:36:18.893377
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker_0 = MonoWorker()
    def f(num, sleep_time=0.01):
        time.sleep(sleep_time)
        return num + 1

    fut_0 = mono_worker_0.submit(f, 0, sleep_time=0.5)
    fut_1 = mono_worker_0.submit(f, 1)
    fut_2 = mono_worker_0.submit(f, 2)
    assert fut_0.result() == 1, "submit didn't work -- no worker available after first submission"
    assert fut_2.result() == 3, "submit didn't work -- to see if second submission could be run"

# Generated at 2022-06-26 09:36:28.750727
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
	test_case_0()

# Generated at 2022-06-26 09:36:41.040822
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    import traceback
    import os

# Generated at 2022-06-26 09:36:52.022701
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test that if no task is running, submitted task is put in waiting, else that
    already waiting task is removed in order to insert submitted task.
    """
    mono_worker_0 = MonoWorker()
    futures_0 = mono_worker_0.futures
    mono_worker_1 = MonoWorker()
    futures_1 = mono_worker_1.futures

    assert len(futures_0) == 0
    assert len(futures_1) == 0

    mono_worker_0.submit(lambda x: x*3, 2, end='')
    assert len(futures_0) == 1
    assert len(futures_1) == 0

    waiting_0 = futures_0.pop()

# Generated at 2022-06-26 09:36:53.991765
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()


# Generated at 2022-06-26 09:36:59.435612
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """test_MonoWorker_submit"""
    # set test values for testing the method
    mono_worker_0 = MonoWorker()
    # invoke the method
    mono_worker_0.submit()
    # test the expected result
    assert 1 == 1

# Generated at 2022-06-26 09:37:06.357814
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda: 1)
    mono_worker_0.submit(lambda: 2)
    mono_worker_0.submit(lambda: 3)
    mono_worker_0.submit(lambda: 4)


# Generated at 2022-06-26 09:37:10.794517
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # initialization of input data
    mono_worker_0 = MonoWorker()
    func = test_case_0
    args = ()
    kwargs = {}
    # run test
    mono_worker_0.submit(func, *args, **kwargs)


# Generated at 2022-06-26 09:37:21.888537
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import asyncio
    async def afunc(input_0,input_1):
        await asyncio.sleep(input_0)
        print('input_1: ' + str(input_1))
        return input_1

    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(afunc,0.1,1)
    mono_worker_0.submit(afunc,0.2,2)
    mono_worker_0.submit(afunc,0.2,3)
    mono_worker_0.submit(afunc,0.3,4)
    mono_worker_0.submit(afunc,0.4,5)
    mono_worker_0.submit(afunc,0.5,6)
    mono_worker_0.submit(afunc,0.6,7)


# Generated at 2022-06-26 09:37:28.992151
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

    def func_0(arg_0, arg_1):
        pass

    ret_0 = mono_worker_0.submit(func_0, 1, 2)
    print(type(ret_0))
    print(ret_0)


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:37:35.636044
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    assert mono_worker.pool.max_workers == 1
    assert mono_worker.futures.maxlen == 2

    # call submit first time
    assert len(mono_worker.futures) == 0
    mono_worker.submit(lambda x: None, 'test')
    assert len(mono_worker.futures) == 1

    # call submit second time
    mono_worker.submit(lambda x: None, 'test')
    assert len(mono_worker.futures) == 2
    assert mono_worker.futures.popleft().done() is True
    assert mono_worker.futures.popleft().done() is False

    # call submit third time
    mono_worker.submit(lambda x: None, 'test')

# Generated at 2022-06-26 09:38:03.050706
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Tests for the method `submit` of class MonoWorker.
    """
    import time
    import random

    mono_worker_0 = MonoWorker()

    def counting_operation(max_iter, increment=1, timeout=0.02,
                           cancel_after=0.01):
        for i in range(max_iter):
            if i % increment == 0:
                time.sleep(timeout)
            if i == max_iter - (max_iter // 4):
                time.sleep(cancel_after)
                raise ValueError('Something bad happened')
        return i


# Generated at 2022-06-26 09:38:11.991119
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    test_arg_0 = lambda: 2
    test_arg_1 = ()
    test_arg_2 = {}
    mono_worker_0.submit(test_arg_0)
    mono_worker_0.submit(test_arg_0, test_arg_1)
    mono_worker_0.submit(test_arg_0, test_arg_1, test_arg_2)

# Generated at 2022-06-26 09:38:18.449494
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    fu = mono_worker_0.submit(lambda x:x**2,5)
    assert fu.result() == 25

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:38:27.362636
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """submit method of class MonoWorker."""
    from time import sleep
    from .tqdm_tqdm import test_case_tqdm
    for _ in range(4):
        mono_worker_0 = MonoWorker()
        assert mono_worker_0._MonoWorker__pool.max_workers == 1
        for _ in tqdm_auto.tqdm(range(4)):
            mono_worker_0.submit(sleep, .01)
            sleep(.10)
        test_case_tqdm()
        sleep(.01)
        assert not len(mono_worker_0._MonoWorker__futures) == 0, \
            "Waiting tasks were not run."


if __name__ == '__main__':
    test_case_0()
    test_Mono

# Generated at 2022-06-26 09:38:32.869234
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, "hello world")

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:38:37.812485
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

# Generated at 2022-06-26 09:38:48.485046
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import time, sleep
    from threading import Lock

    N = 10**3
    lock = Lock()
    counter = 0

    def get_counter(sleep_time):
        nonlocal counter
        sleep(sleep_time)
        with lock:
            counter += 1

    mono_worker = MonoWorker()

    # first call
    start_time = time()
    mono_worker.submit(get_counter, 0)
    assert counter == 1
    assert time() - start_time > 0

    # second call
    start_time = time()
    mono_worker.submit(get_counter, 0)
    assert counter == 2
    assert time() - start_time > 0

    # third call
    start_time = time()
    mono_worker.submit(get_counter, 0.1)
    assert counter == 2

# Generated at 2022-06-26 09:38:57.812352
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f1(a, b):
        return a + b
    def f2(a, b, c):
        return a + b + c
    def f3(a, b, c, d):
        return a + b + c + d
    mono_worker = MonoWorker()
    mono_worker.submit(f1, 1, 2)
    mono_worker.submit(f2, 1, 2, 3)
    mono_worker.submit(f3, 1, 2, 3, 4)

# Generated at 2022-06-26 09:39:00.605463
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, "Hello!")

# Generated at 2022-06-26 09:39:03.295496
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit()


# Generated at 2022-06-26 09:39:53.373615
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Thread
    from time import sleep
    mono_worker_0 = MonoWorker()  # instance of class MonoWorker
    # Test 1
    def cb_0():
        # function to be executed by mono_worker_0.submit
        sleep(3)
        return 'Hello '
    fut_0 = mono_worker_0.submit(cb_0)  # concurrent.futures.Future object
    while not fut_0.done():
        print('Waiting...')
        sleep(1)
    print(fut_0.result())
    # Test 2
    def cb_1():
        # function to be executed by mono_worker_0.submit
        sleep(3)
        return 'World!'
    fut_1 = mono_worker_0.submit(cb_1)  # concurrent.fut

# Generated at 2022-06-26 09:39:59.297554
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func_2(*args, **kwargs):
        return 
    # The first call of method submit
    # 1. clears the deque
    # 2. adds the Future to the deque
    mono_worker_0.submit(func_2,*( ),**{ })
    # The second call of method submit
    # 1. clears the deque
    # 2. adds the Future to the deque
    mono_worker_0.submit(func_2,*( ),**{ })
    # The third call of method submit
    # 1. does nothing
    mono_worker_0.submit(func_2,*( ),**{ })
    # The fourth call of method submit
    # 1. does nothing

# Generated at 2022-06-26 09:40:01.951452
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    # Test for case when one of the test cases failed
    assert False

# Generated at 2022-06-26 09:40:04.767736
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    test_case_0()

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:40:12.720151
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing
    import time
    import unittest

    import numpy as np

    # Define some helper functions
    def sleep_fun(wait_time):
        time.sleep(wait_time)
        return wait_time

    def test_fun(sleep_time):
        t0 = time.time()
        MonoWorker_0 = MonoWorker()
        MonoWorker_0.submit(sleep_fun, sleep_time)
        assert MonoWorker_0.submit(sleep_fun, sleep_time) is None
        MonoWorker_0.submit(sleep_fun, sleep_time)
        t1 = time.time()
        MonoWorker_0.futures.popleft().result()
        t2 = time.time()

# Generated at 2022-06-26 09:40:19.626123
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from unittest import TestCase, main
    from concurrent.futures import wait
    from .thread_utils import sleep_a_bit

    class TestMonoWorker_submit(TestCase):
        def test_submit(self):
            mono_worker = MonoWorker()
            for _ in range(4):
                mono_worker.submit(sleep_a_bit, 0)
            self.assertEqual(len(mono_worker.futures), 1)
            wait(mono_worker.futures)

    main(exit=False, failfast=True, verbosity=2)


if __name__ == "__main__":
    test_case_0()

    test_MonoWorker_submit()

# Generated at 2022-06-26 09:40:23.079305
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    # Call method submit of class MonoWorker
    mono_worker_0.submit("func", "*args", "**kwargs")
    # self.futures.append(waiting) Line 52
    assert len(mono_worker_0.futures) == 1
    # if len(futures) == futures.maxlen: Line 29
    mono_worker_0.submit("func", "*args", "**kwargs")
    mono_worker_0.submit("func", "*args", "**kwargs")
    mono_worker_0.submit("func", "*args", "**kwargs")
    mono_worker_0.submit("func", "*args", "**kwargs")
    assert len(mono_worker_0.futures) == 2
   

# Generated at 2022-06-26 09:40:25.682519
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print())

# Generated at 2022-06-26 09:40:27.390146
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    assert mono_worker.submit(print, "0") is not None


# Generated at 2022-06-26 09:40:39.344058
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import numpy.random as npr
    import time
    import multiprocessing as mp

    npr.seed(0)
    mp.set_start_method('spawn')
    def g():
        time.sleep(3)
        return npr.randint(10)

    mono_worker_0 = MonoWorker()

    # case: 0
    mono_worker_0.submit(g)
    mono_worker_0.submit(g)
    mono_worker_0.submit(g)
    
    
    mono_worker_0.submit(g)
    # case: 1
    mono_worker_0.submit(g)
    mono_worker_0.submit(g)
    mono_worker_0.submit(g)
    mono_worker_0.submit(g)

# Generated at 2022-06-26 09:42:17.842067
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event

    _event = Event()

    def _event_set():
        _event.set()

    # 0
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(_event_set)
    assert not _event.is_set()
    mono_worker_0.submit(_event_set)
    assert _event.is_set()

    # 1
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(_event_set)
    assert not _event.is_set()
    mono_worker_1.submit(_event_set)
    assert _event.is_set()

# Generated at 2022-06-26 09:42:22.791958
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, 'test')
    assert len(mono_worker_0.futures) == 1

test_MonoWorker_submit()

# Generated at 2022-06-26 09:42:27.911932
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    mono_worker.submit(mul, 2, 8)
    mono_worker.submit(mul, 3, 7)
    mono_worker.submit(mul, 4, 6)

# Generated at 2022-06-26 09:42:31.250576
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(test_case_0, []) is None


# Generated at 2022-06-26 09:42:32.014737
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    assert False

# Generated at 2022-06-26 09:42:37.887133
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    class TestException(Exception):
        """
        Unit test exception
        """
    def assert_is_monoworker(mono_worker):
        """
        Asserts that mono_worker is a :class:`MonoWorker` instance
        """
        assert isinstance(mono_worker, MonoWorker)

    def assert_exception(expected_exception, func, *args, **kwargs):
        """
        Asserts that func(*args, **kwargs) raises expected_exception
        """
        assert_raises(expected_exception, func, *args, **kwargs)

    mono_worker_0 = MonoWorker()
    from threading import Thread
    from time import sleep
    from tqdm.utils import _enforce_unicode


# Generated at 2022-06-26 09:42:46.183723
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    from math import factorial
    from time import sleep
    numbers = [1, 2, 3, 4, 5]
    factorials = []
    with tqdm_auto.tqdm(numbers, desc='calculating factorials', mininterval=1) as t:
        for n in t:
            future = mono_worker_0.submit(factorial, n)
            future.add_done_callback(lambda fs: factorials.append(fs.result()))
            sleep(0.1)
    assert factorials == [1, 2, 6, 24, 120]

# Generated at 2022-06-26 09:42:56.728286
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker_1 = MonoWorker()
    def test_function(x, y):
        return x*y
    mono_worker_1.submit(test_function, 2, 4)
    print("first submit passed")
    mono_worker_1.submit(test_function, 2, 2)
    print("second submit passed")
    mono_worker_1.submit(test_function, 2, 3)
    print("third submit passed")
    mono_worker_1.submit(test_function, 2, 0)
    print("fourth submit passed")
    time.sleep(1)
    assert mono_worker_1.futures[0].result() == 0
    print("first result is correct")
    time.sleep(1)
    assert mono_worker_1.futures[1].result() == 8

# Generated at 2022-06-26 09:43:06.512031
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    a = tqdm_auto.tqdm(total=3)
    def test_func(x):
        return x * 2
    mono_worker = MonoWorker()
    a.update()
    mono_worker.submit(test_func, 1)
    a.update()
    mono_worker.submit(test_func, 2)
    a.update()
    mono_worker.submit(test_func, 3)
    a.update()
    mono_worker.submit(test_func, 4)
    a.update()

if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()