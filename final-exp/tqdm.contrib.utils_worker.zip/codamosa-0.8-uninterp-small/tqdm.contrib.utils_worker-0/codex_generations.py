

# Generated at 2022-06-26 09:33:25.884557
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    
    def sleep_echo(n):
        '''
        Sleep for n seconds and print out the number.
        '''
        time.sleep(n)
        return n

    print('Tests for MonoWorker.submit()')
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(sleep_echo, 1) 
    time.sleep(0.1)
    mono_worker_0.submit(sleep_echo, 0.5) 
    time.sleep(0.5)
    mono_worker_0.submit(sleep_echo, 1)
    
if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:33:38.750201
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(pow, 2, 10)
    mono_worker_0.submit(pow, 3, 10)
    mono_worker_0.submit(pow, 4, 10)
    mono_worker_0.submit(pow, 5, 10)
    mono_worker_0.submit(pow, 6, 10)
    mono_worker_0.submit(pow, 7, 10)
    mono_worker_0.submit(pow, 8, 10)
    mono_worker_0.submit(pow, 9, 10)
    mono_worker_0.submit(pow, 10, 10)
    mono_worker_0.submit(pow, 11, 10)
    mono_worker_0.submit(pow, 12, 10)


# Generated at 2022-06-26 09:33:43.223865
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    test_cases = [
        (0,),
        (1,),
        (2,),
    ]
    for i, tc in enumerate(test_cases):
        yield check_MonoWorker_submit, tc, i



# Generated at 2022-06-26 09:33:51.122273
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    delta_time = 0.0001  # seconds
    max_wait = delta_time * 5
    start_time = time.time()

    def new_submit(func, *args, **kwargs):
        while True:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                tqdm_auto.write("Exception: {0}".format(e))
                if (time.time() - start_time) > max_wait:
                    raise

    mono_worker_0 = MonoWorker()

    #new_submit(mono_worker_0.submit, lambda: time.sleep(delta_time), task_name="task_0")
    new_submit(mono_worker_0.submit, time.sleep, delta_time, task_name="task_0")


# Generated at 2022-06-26 09:33:56.112677
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    mono_worker_0 = MonoWorker()
    assert isinstance(mono_worker_0.submit(func=lambda x: x, args=1), Future)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 09:33:59.669209
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(None)

# Generated at 2022-06-26 09:34:02.742904
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(lambda : None) is not None
# Test callable with args

# Generated at 2022-06-26 09:34:06.161306
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker_0 = MonoWorker()
    # Case 1:
    mono_worker_0.submit(func=time.sleep, args=(0.5,))


# Generated at 2022-06-26 09:34:18.798121
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from unittest import skip
    from .testing import MonitoringThread

    class TestCase(object):
        def setUp(self):
            self.mw = MonoWorker()

        def tearDown(self):
            self.mw.pool.shutdown(wait=True)

        @skip('TODO')
        def test_waiting_is_replaced(self):
            with MonitoringThread() as monitor:
                future1 = self.mw.submit(monitor.wait)
                monitor.wait.set()
                future2 = self.mw.submit(monitor.wait)
                self.assertTrue(monitor.join(0.01))
                self.assertFalse(future1.done())
                self.assertTrue(future2.done())

    import unittest
    from .testing import CustomTestProgram


# Generated at 2022-06-26 09:34:24.565828
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(len, [1, 2])
    mono_worker_0.submit(len, [1, 2, 3, 4])
    mono_worker_0.submit(len, [1, 2, 3, 4, 5, 6, 7, 8])

# Generated at 2022-06-26 09:34:28.364015
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(tqdm_auto.tqdm, range(1, 101))


if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:34:38.620918
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test MonoWorker.submit()
    """
    mono_worker_1 = MonoWorker()
    mono_worker_2 = MonoWorker()

    from time import sleep
    from random import random

    def task(_):
        r = random()
        sleep(r)
        return r

    mono_worker_1.submit(task, 0)
    mono_worker_1.submit(task, 1)  # Should be discarded
    mono_worker_1.submit(task, 2)  # Should be discarded
    mono_worker_2.submit(task, 3)
    mono_worker_2.submit(task, 4)  # Should be discarded
    mono_worker_2.submit(task, 5)  # Should be discarded

    assert mono_worker_1.pool.done() == 0
    assert mono_worker_1

# Generated at 2022-06-26 09:34:43.316970
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_1 = MonoWorker()
    mono_worker_2 = MonoWorker()
    mono_worker_3 = MonoWorker()
    def tqdm_auto_callable_0(iterable):
        for x in tqdm_auto(iterable):
            yield x
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 09:34:49.586844
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit("'abcd'", "'cd'", "'a'", "'a'")


if __name__ == '__main__':
    import sys
    import os
    import io
    import re
    import pytest

    def test_generator(a, b):
        def check(got, expected):
            if got == expected:
                prefix = ' OK '
            else:
                prefix = '  X '
            print('{0} got: {1} expected: {2}'.format(
                prefix, repr(got), repr(expected)))


# Generated at 2022-06-26 09:35:00.210484
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    #### Testing with a local test server
    # This is the same as the test_MonoWorker_submit_local test, but uses a more complete
    # test server, running on a thread.
    #
    # We use this server to test that when a MonoWorker task is waiting, it can be
    # replaced with a different task, and that the original task does not run.  It is
    # possible that there is a race condition which means that the behaviour tested for
    # here could occasionally not work in real life.
    import threading
    import socket

    class TestServer(threading.Thread):
        def __init__(self, port=None, max_clients=None, max_length=None):
            super(TestServer, self).__init__()
            self.daemon = True
            self.port = port

# Generated at 2022-06-26 09:35:04.292659
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    func = lambda: None
    kwargs = {}
    args = ()
    mono_worker_0.submit(func, *args, **kwargs)

# Generated at 2022-06-26 09:35:06.914069
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    tqdm_auto.write("Testing MonoWorker.submit...")
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda : 'Test MonoWorker.submit')

test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:17.533566
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Case 0
    mono_worker_0 = MonoWorker()
    method_test_MonoWorker_submit = getattr(mono_worker_0, "submit", "not_there")
    args_test_MonoWorker_submit = [mono_worker_0]
    kwargs_test_MonoWorker_submit = dict()
    expected_result_test_MonoWorker_submit = mono_worker_0
    assert method_test_MonoWorker_submit(*args_test_MonoWorker_submit, **kwargs_test_MonoWorker_submit) == expected_result_test_MonoWorker_submit


if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:21.602345
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import os
    mono_worker = MonoWorker()
    for i in range(5):
        mono_worker.submit(os.getcwd())


# Generated at 2022-06-26 09:35:29.920192
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    mono_worker.submit(lambda s: tqdm_auto.write(s), 'XXX')
    mono_worker.submit(lambda s: tqdm_auto.write(s), 'YYY')
    mono_worker.submit(lambda s: tqdm_auto.write(s), 'ZZZ')
    mono_worker.submit(lambda s: tqdm_auto.write(s), 'AAA')
    mono_worker.submit(lambda s: tqdm_auto.write(s), 'BBB')
    mono_worker.submit(lambda s: tqdm_auto.write(s), 'CCC')
    mono_worker.submit(lambda s: tqdm_auto.write(s), 'DDD')

if __name__ == "__main__":
    import doctest


# Generated at 2022-06-26 09:35:40.416163
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert len(mono_worker_0.futures) == 0
    mono_worker_0.submit(int, "0x10", base=16)
    assert len(mono_worker_0.futures) == 1
    mono_worker_0.submit(int, "0x10", base=16)
    assert len(mono_worker_0.futures) == 1
    mono_worker_0.submit(int, "0x10", base=16)
    assert len(mono_worker_0.futures) == 2
    mono_worker_0.submit(int, "0x10", base=16)
    assert len(mono_worker_0.futures) == 2

# Generated at 2022-06-26 09:35:48.417049
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    from concurrent.futures import Future

    def function_0(string_in):
        return 'return: ' + string_in

    mono_worker_0 = MonoWorker()

    future_0 = mono_worker_0.submit(function_0, 'string_0')
    assert isinstance(future_0, Future)

    assert future_0.result() == 'return: string_0'

    # Submit a second time
    future_1 = mono_worker_0.submit(function_0, 'string_1')
    assert isinstance(future_1, Future)

    assert future_1.result() == 'return: string_1'

# Generated at 2022-06-26 09:35:58.653327
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    mono_worker_0 = MonoWorker()

    def function_0(x):
        sleep(x)

    # submit function_0 with argument 5
    mono_worker_0.submit(function_0, 5)

    # submit function_0 with argument 2
    mono_worker_0.submit(function_0, 2)

    # submit function_0 with argument 3
    mono_worker_0.submit(function_0, 3)

if __name__ == "__main__":
    import sys

    testcase_dict = {
        "test_case_0": test_case_0,
        "test_MonoWorker_submit": test_MonoWorker_submit
    }

# Generated at 2022-06-26 09:36:00.191581
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submi

# Generated at 2022-06-26 09:36:03.718498
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(print, 'bla')

# Generated at 2022-06-26 09:36:06.162665
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def return_one():
        return 1
    mono_worker_0.submit(return_one)


# Generated at 2022-06-26 09:36:11.036777
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, "test")


# Generated at 2022-06-26 09:36:17.411811
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func0(*args, **kwargs):
        return func0(*args, **kwargs)
    try:
        mono_worker_0.submit(func0, 3, 2, 3)
    except Exception as e:
        tqdm_auto.write(str(e))



# Generated at 2022-06-26 09:36:20.585946
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(func=None, *(None,), **(None,))

# Generated at 2022-06-26 09:36:24.932669
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def a():
        return 1
    mono_worker_0.submit(a)

# Generated at 2022-06-26 09:36:33.988001
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import subprocess
    import sys
    import time
    # try different values of args and kwargs
    args = (((0, 1),))
    def kwargs_0():
        # try different values of kwargs
        kwargs = {}
        # try different values of kwargs
        kwargs = {'sleep_time': 8}
        return (kwargs)

# Generated at 2022-06-26 09:36:35.398656
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    test_case_0()


# Generated at 2022-06-26 09:36:40.055335
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    # Testing if self.pool is an instance of ThreadPoolExecutor.
    assert isinstance(mono_worker_0.pool, ThreadPoolExecutor)

    # Testing if self.futures is an instance of deque
    assert isinstance(mono_worker_0.futures, deque)

# Generated at 2022-06-26 09:36:51.890088
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .thread import unit_test_task
    import threading
    from time import sleep
    from inspect import isgenerator

    mono_worker_0 = MonoWorker()
    for i in tqdm_auto.trange(10, desc='submit'):
        assert mono_worker_0.submit(unit_test_task, i, 2)
        sleep(.05)
    assert mono_worker_0.futures[0].result() == '5'
    assert mono_worker_0.futures[1].result() == '7'

    mono_worker_1 = MonoWorker()
    for i in tqdm_auto.trange(10, desc='submit'):
        assert mono_worker_1.submit(unit_test_task, i, 3)
        sleep(.05)
    assert mono_worker

# Generated at 2022-06-26 09:36:54.507576
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(0, 0)

# Generated at 2022-06-26 09:36:59.911233
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(foo, 1, 2)
    mono_worker_0.submit(foo, 2, 3)
    mono_worker_0.submit(foo, 2, 3)


# Generated at 2022-06-26 09:37:05.434985
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func0(arg0, arg1):
        return (arg0 + arg1)
    mono_worker_0.submit(func0, 'str', 4)

# Generated at 2022-06-26 09:37:13.547033
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    mono_worker_1 = MonoWorker()
    random.seed(0)
    for i in range(30):
        if random.random() >= 0.5:
            mono_worker_1.submit(time.sleep, 0.5)
            print("submitted sleep 0.5")
        else:
            mono_worker_1.submit(time.sleep, 1.0)
            print("submitted sleep 1.0")
        time.sleep(random.random() * 0.1 + 0.1)
    mono_worker_1.pool.shutdown()

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:37:18.979446
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func():
        import time
        time.sleep(1)
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(func)
    mono_worker_0.submit(func)
    mono_worker_0.submit(func)


# Generated at 2022-06-26 09:37:22.412981
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    mono_worker_0 = MonoWorker()
    mono_worker_0.submit("""\
    """)

# Generated at 2022-06-26 09:37:34.332457
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(int, "1")


# Generated at 2022-06-26 09:37:42.290536
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    m = MonoWorker()
    assert len(m.futures) == 0
    m.submit(int, '123')
    assert len(m.futures) == 1
    m.submit(int, '123')
    assert len(m.futures) == 2
    m.submit(int, '123')
    assert len(m.futures) == 2
    m.submit(int, '123')
    assert len(m.futures) == 2
    m.submit(int, '123')
    assert len(m.futures) == 2

# Generated at 2022-06-26 09:37:52.335271
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test inputs of various types in the method call
    # These are the test cases which are expected to pass
    print('Running test_MonoWorker_submit')
    try:
        mono_worker_0 = MonoWorker()

        def function(n):
            return n**2

        mono_worker_0.submit(function, 2)
    except Exception as e:
        assert False
    # noinspection PyUnreachableCode
    else:
        assert False  # unreachable
    # TODO: add more test cases
    print('--- PASS: test_MonoWorker_submit')


# Generated at 2022-06-26 09:38:01.625646
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    mono_worker.submit(lambda x: x, 1)
    mono_worker.submit(lambda x, y: x + y, 1, 2)
    mono_worker.submit(lambda: 3)
    mono_worker.submit(lambda x: x, 1)
    mono_worker.submit(lambda x, y: x + y, 1, 2)

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:38:10.697482
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import datetime
    time.sleep(2)
    time_0 = datetime.datetime.now().microsecond
    time.sleep(2)
    time_1 = datetime.datetime.now().microsecond
    assert time_0 < time_1 

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:38:16.750061
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # dummy task 1, which does not do anything
    def do_nothing(*args, **kwargs):
        pass
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(do_nothing)
    mono_worker_0.submit(do_nothing)
    mono_worker_0.submit(do_nothing)

if __name__ == "__main__":
    # for test only
    import sys

    def task(i, bar_format="{r_bar}"):
        tqdm_loc = tqdm_auto(total=10, desc="task", bar_format=bar_format,
                             initial=i)
        i += 1
        while i < 10:
            tqdm_loc.update(1)

# Generated at 2022-06-26 09:38:18.731296
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert False


# Generated at 2022-06-26 09:38:22.738632
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    futures_0 = mono_worker_0.submit(lambda x: x * x, 3)

# Generated at 2022-06-26 09:38:23.861920
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()


# Generated at 2022-06-26 09:38:35.763512
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import numpy as np
    from tqdm import tqdm
    from tqdm.contrib import MonoWorker
    
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(time.sleep, 0.5)
    mono_worker_0.submit(time.sleep, 0.5)
    mono_worker_0.submit(time.sleep, 0.5)
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(time.sleep, 0.5)
    mono_worker_1.submit(time.sleep, 0.5)
    mono_worker_1.submit(time.sleep, 0.5)
    
    mono_worker_2 = MonoWorker()
    mono_worker_2.submit(time.sleep, 0.01)

# Generated at 2022-06-26 09:38:57.595184
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(x, y=0):
        print('sleep for', y)
        time.sleep(y)
        return x * x

    mono_worker_0 = MonoWorker()
    for i in range(10):
        mono_worker_0.submit(f, i, y=i)



# Generated at 2022-06-26 09:39:00.311575
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit


# Generated at 2022-06-26 09:39:05.468369
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(print, "test_MonoWorker_submit")


if __name__ == '__main__':
    #test_MonoWorker_submit()
    pass

# Generated at 2022-06-26 09:39:08.601959
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    # Checking with a callable
    mono_worker.submit(lambda x, y: x+y, 1, 2)
    # Checking with a non-callable
    mono_worker.submit('hello')

# Generated at 2022-06-26 09:39:17.963780
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Submit task using benchmark function
    """
    mono_worker_1 = MonoWorker()
    def benchmark(x):
        """
        Perform an expensive task
        """
        import time
        time.sleep(x)
        return x
    for x in range(2):
        fut = mono_worker_1.submit(benchmark, x)
        print(fut.result())

# Generated at 2022-06-26 09:39:23.120146
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import current_thread
    from time import sleep
    from collections import defaultdict

    dd = defaultdict(list)

    def worker(name):
        dd[name] = current_thread()

        # Wait to be killed by another thread
        while True:
            sleep(0.1)

    mono_worker = MonoWorker()

    mono_worker.submit(worker, '1')
    mono_worker.submit(worker, '2')

    sleep(0.5)
    assert len(dd) == 2
    assert set(dd.keys()) == set(['1', '2'])

    # Submit a new task to replace a running task
    mono_worker.submit(worker, '3')

    sleep(0.5)
    assert len(dd) == 2

# Generated at 2022-06-26 09:39:25.146846
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()


# Generated at 2022-06-26 09:39:31.641372
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def function_0(arg_0): pass
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(function_0, 1)
    mono_worker_0.submit(function_0, 1)
    mono_worker_0.submit(function_0, 1)
    mono_worker_0.submit(function_0, 1)
    mono_worker_0.submit(function_0, 1)

# Generated at 2022-06-26 09:39:44.106941
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import Pool as multiprocessing_Pool
    from multiprocessing import cpu_count as multiprocessing_cpu_count
    from time import sleep as time_sleep
    from time import time as time_time
    from tqdm import trange as tqdm_trange

    def time_sleep_costy(t):
        time_sleep(t)
        return time_time()
    def time_sleep_costy_1(t):
        time_sleep(t)
        return time_time()

    # Create a pool of workers to run tasks
    pool = multiprocessing_Pool(multiprocessing_cpu_count())

    # Create a MonoWorker
    mono = MonoWorker()

    # Create a tqdm instance

# Generated at 2022-06-26 09:39:52.162089
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker_0 = MonoWorker()

    # Testing function sleep of module time
    def func():
        from time import sleep
        return sleep(0.1)

    mono_worker_0.submit(func)


if __name__ == "__main__":
    import sys

    if len(sys.argv) == 3 and sys.argv[1] == "test":
        if sys.argv[2] == "MonoWorker_submit":
            test_MonoWorker_submit()
        else:
            print("ERROR: Invalid method call")
    else:
        print("ERROR: Invalid call to {0}".format(__file__))

# Generated at 2022-06-26 09:40:28.742136
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda t: print('%s' % t), 'Hello')
    mono_worker_0.submit(lambda t: print('%s' % t), 'world')
    mono_worker_0.submit(lambda t: print('%s' % t), 'test')
    mono_worker_0.submit(lambda t: print('%s' % t), 'test2')
    mono_worker_0.submit(lambda t: print('%s' % t), 'test3')

# Generated at 2022-06-26 09:40:32.368645
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda x: x, 1)



# Generated at 2022-06-26 09:40:38.864905
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Arrange
    mono_worker_0 = MonoWorker()
    def dummy_function(arg_0_0, kwarg_0_0="kwarg_0_0"):
        pass

    # Act
    mono_worker_0.submit(dummy_function, "arg_0_0", kwarg_0_0="kwarg_0_0")

    # Assert
    assert len(mono_worker_0.futures) == 1



# Generated at 2022-06-26 09:40:40.513564
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker();
    def f(a,b):
        return a+b;
    assert mono_worker_1.submit(f, 1,2)


# Generated at 2022-06-26 09:40:45.010206
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import Process, Value
    from os import kill
    
    def input_func(val):
        val.value = int(input())
    def print_func(n):
        print(n)
    
    mono_worker_0 = MonoWorker()
    multi_process_0 = Process()
    multi_process_1 = Process()

# Generated at 2022-06-26 09:40:47.586913
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda: 'a')
    assert mono_worker_0.futures is not None


# Generated at 2022-06-26 09:40:50.625273
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda : None)

# Generated at 2022-06-26 09:40:57.734249
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(0, 1)
    mono_worker_0.submit(0, 1, 2)

if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:40:59.794290
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    base_path = 'd:\\'
    ff = FileFetcher(None, base_path)
    # test case
    mono_worker_0.submit(ff.run)


# Generated at 2022-06-26 09:41:10.770093
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import Value
    from time import sleep

    def hang_forever(*args, **kwargs):
        """Hang forever"""
        sleep_time = kwargs.pop('sleep_time', 0)
        sleeping_flag = kwargs.pop('sleeping_flag', None)
        if sleeping_flag is not None:
            sleeping_flag.value = 1
        sleep(sleep_time)
        return args, kwargs

    def return_one(*args, **kwargs):
        """return 1"""
        return 1

    def return_zero(*args, **kwargs):
        """return 0"""
        return 0


# Generated at 2022-06-26 09:42:24.619074
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker_0 = MonoWorker()
    for i in range(4):
        mono_worker_0.submit(time.sleep,0.1)

if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:42:36.099633
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    number_of_submit_calls = 5
    def test_func(arg):
        return arg*arg
    def test_arg(i):
        return i
    mono_worker = MonoWorker()
    for i in range(number_of_submit_calls):
        mono_worker.submit(test_func, test_arg(i))
    for i in range(number_of_submit_calls):
        assert mono_worker.pool._workers.qsize() <= 1
        assert mono_worker.pool._work_queue.qsize() <= 1

if __name__ == '__main__':
    for test_func in (test_case_0, test_MonoWorker_submit):
        try:
            test_func()
        except:
            import sys

# Generated at 2022-06-26 09:42:38.555549
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    test_case_0()


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:42:47.362862
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import threading
    import time

    def func(i, wait_forever=False):
        time.sleep(random.random() * 5 * (1. if wait_forever else 2))
        return i

    mono_worker_0 = MonoWorker()  # Subject Under Test
    thread_0 = threading.Thread(target=mono_worker_0.submit, args=[func, 3])
    thread_0.start()
    thread_0.join()
    mono_worker_0.submit(func, 3)
    mono_worker_0.submit(func, 4, wait_forever=True)
    mono_worker_0.futures[1].result()
    mono_worker_0.submit(func, 5)

# Generated at 2022-06-26 09:42:54.745757
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.mono_worker_0_submit(('foo', ), {'bar': 'baz'})
    mono_worker_0.mono_worker_0_submit(('foo', ), {'bar': 'baz'})
    mono_worker_0.mono_worker_0_submit(('foo', ), {'bar': 'baz'})

# Generated at 2022-06-26 09:42:59.740136
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit()

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:43:06.012912
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # arrange
    mono_worker_0 = MonoWorker()
    func = lambda: None
    args = ()
    kwargs = {}
    expected = None
    expected = 1 # moke test
    # act
    actual = mono_worker_0.submit(func, *args, **kwargs)
    # assert
    tqdm_auto.write('test_MonoWorker_submit', expected, actual)


# Generated at 2022-06-26 09:43:16.767808
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # create object of class MonoWorker
    mono_worker = MonoWorker()
    # call of method submit of class MonoWorker
    # mono_worker.submit(func, *args, **kwargs)
    try:
        mono_worker.submit()
    except TypeError as e:
        # test passed
        tqdm_auto.write(str(e))
    else:
        # test failed
        tqdm_auto.write("test case failed (expected TypeError)")


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_case_0()
    test_MonoWorker_submit()