

# Generated at 2022-06-26 09:33:11.721323
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..std import timeit

    def func(n):
        sleep(n)
        return n

    mono_worker_0 = MonoWorker()
    future_0 = mono_worker_0.submit(func, 1.0)
    future_1 = mono_worker_0.submit(func, 2.0)
    future_2 = mono_worker_0.submit(func, 3.0)
    assert future_0 is not future_1
    assert future_0 is not future_2
    assert future_1 is not future_2

    assert future_0.done()
    assert not future_1.done()
    assert not future_2.done()

    timeit('result_0 = future_0.result()')
    timeit('result_1 = future_1.result()')
    time

# Generated at 2022-06-26 09:33:20.219524
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test method `submit` of class MonoWorker.
    """
    mono_worker_0 = MonoWorker()
    func_0 = [
        lambda: None,
        lambda: mono_worker_0.submit(lambda: None, None),
        lambda: mono_worker_0.submit(lambda: None, None),
        lambda: mono_worker_0.submit(lambda: None, None),
        lambda: mono_worker_0.submit(lambda: None, None),
        lambda: mono_worker_0.submit(lambda: None, None),
        lambda: mono_worker_0.submit(lambda: None, None),
        lambda: mono_worker_0.submit(lambda: None, None),
        lambda: mono_worker_0.submit(lambda: None, None)]
    func_0[1]()
    func

# Generated at 2022-06-26 09:33:22.395612
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()



# Generated at 2022-06-26 09:33:29.901010
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    class ClassA(object):
        def __init__(self, name, t=1):
            self.name = name
            self.t = t

        def funcA(self, *args, **kwargs):
            time.sleep(self.t)
            with open('test0_A.txt', 'a') as f:
                f.write(self.name)

        def funcB(self, *args, **kwargs):
            time.sleep(self.t)
            with open('test0_B.txt', 'a') as f:
                f.write(self.name)

    a = ClassA('a')
    b = ClassA('b')


    a.funcA()
    mono_worker_1 = MonoWorker()
    a

# Generated at 2022-06-26 09:33:39.904000
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

    def f_0(*args):
        return len(args)

    ret_0 = mono_worker_0.submit(f_0, list(range(10)))

    assert ret_0.result() == 1, "Assertion error: {0} != {1}".format(ret_0.result(), 1)


if __name__ == "__main__":
    import sys
    import os
    sys.path.insert(0, os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..')))

    from .tests_python import test_Python

# Generated at 2022-06-26 09:33:46.907034
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import numpy as np
    mono_worker_1 = MonoWorker()

    def test_func_1(seconds):
        time.sleep(seconds)
        return seconds

    t0 = time.time()
    mono_worker_1.submit(test_func_1, 0.5)
    mono_worker_1.submit(test_func_1, 0.5)
    assert np.isclose(time.time() - t0, 0.5)
    t0 = time.time()
    mono_worker_1.submit(test_func_1, 1)
    mono_worker_1.submit(test_func_1, 0.5)
    assert np.isclose(time.time() - t0, 1)


if __name__ == "__main__":
    import pytest  # type

# Generated at 2022-06-26 09:33:53.024485
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    mono_worker.submit(lambda: 1)
    mono_worker.submit(lambda: 2)
    mono_worker.submit(lambda: 3)


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:33:55.977341
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func(a,b):
        return a+b
    mono_worker_0.submit(func,10,20)

# Generated at 2022-06-26 09:34:03.020455
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    # Test case 0
    mono_worker_0 = MonoWorker()

    # Test case 1
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(func='print("hello world")', mono_worker_1=mono_worker_1)


# Generated at 2022-06-26 09:34:09.695819
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    print()

    import time
    import random

    def sleeping(max_time, n):
        time.sleep(max_time)
        return n

    def random_sleeping(max_time=0.01):
        return sleeping(random.uniform(0, max_time), max_time)

    def callback_after_submit_success(future):
        print("submit callback w/ id: " + str(future.result()))

    def callback_after_submit_fail(future):
        print("submit failed: " + str(future.result()))

    def test_fucntion_async(max_time=0.1, max_concurrent=1, max_total=20):
        from concurrent.futures import Future
        from tqdm import trange
        from tqdm.contrib import thread_map

# Generated at 2022-06-26 09:34:20.589832
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(test_case_0)
    mono_worker_0.submit(test_case_0)
    mono_worker_0.submit(test_case_0)
    mono_worker_0.submit(test_case_0)
    mono_worker_0.submit(test_case_0)
    mono_worker_0.submit(test_case_0)
    mono_worker_0.submit(test_case_0)
    mono_worker_0.submit(test_case_0)
    mono_worker_0.submit(test_case_0)
    mono_worker_0.submit(test_case_0)
    mono_worker_0.submit(test_case_0)

# Generated at 2022-06-26 09:34:24.491818
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw0 = MonoWorker()
    mw0.submit(lambda x:x, "test case")
    assert(mw0.futures[0] != None)

test_MonoWorker_submit()

# Generated at 2022-06-26 09:34:30.726375
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing as mp
    mono_worker = MonoWorker()
    pool = mp.Pool(2)
    jobs = []

    # queue a single job
    jobs.append(mono_worker.submit(pool.map_async, list(range(10))))

    # wait for job to complete
    jobs[-1].result()

    # queue another job
    jobs.append(mono_worker.submit(pool.map_async, list(range(10))))

    # this will cancel the first job
    jobs.append(mono_worker.submit(pool.map_async, list(range(10))))

    # this will cancel the second job
    jobs.append(mono_worker.submit(pool.map_async, list(range(10))))

    # check that first and second jobs have been cancelled
   

# Generated at 2022-06-26 09:34:34.409039
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(fib, 10)

test_case_0()
test_MonoWorker_submit()

# Generated at 2022-06-26 09:34:42.350281
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    mw = MonoWorker()

    threads_count = [0]

    def foo(i):
        threads_count[0] += 1
        time.sleep(1)
        print(i)

    for i in range(10):
        mw.submit(foo, i)
        threading.active_count()
        time.sleep(0.3)
    time.sleep(0.1)
    assert threads_count[0] == 1


# Generated at 2022-06-26 09:34:50.144010
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from timeit import default_timer as timer

    # start time
    start = timer()

# Generated at 2022-06-26 09:34:58.279222
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    worker = MonoWorker()
    def hello_world(n):
        return 'Hello World {:03d}'.format(n)
    def sleep_seconds(n):
        import time
        time.sleep(n)
        return n
    print('\n### Test the method MonoWorker.submit.')
    futures = []
    for n in range(10):
        futures.append(worker.submit(hello_world, n))
    for n in range(10):
        futures.append(worker.submit(sleep_seconds, n))
    for n in range(10):
        futures.append(worker.submit(hello_world, n + 10))
    for n in range(10):
        futures.append(worker.submit(sleep_seconds, n + 10))

# Generated at 2022-06-26 09:35:08.168336
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
# Test multi submit
    def func_0(*args, **kwargs):
        return 0
    mono_worker_0.submit(func_0, 0, 1)
    mono_worker_0.submit(func_0, 0, 1)
# Test special exception
    def func_1(*args, **kwargs):
        return 1
    mono_worker_0.submit(func_1, 0, 1)
    mono_worker_0.submit(func_1, 0, 1)
# Test mono submit
    def func_2_1(*args, **kwargs):
        return 2
    def func_2_2(*args, **kwargs):
        return 2
    mono_worker_1 = MonoWorker()

# Generated at 2022-06-26 09:35:15.381439
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    try:
        mono_worker_0.submit()
    except NotImplementedError:
        pass
    except Exception:
        traceback.print_exc()
        raise AssertionError

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:26.777714
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import faker
    import time

    fake = faker.Faker()
    def dummy(t):
        time.sleep(t)
        return t

    w = MonoWorker()
    t = w.submit(dummy, 3)
    t1 = w.submit(dummy, 2)
    t2 = w.submit(dummy, 1)
    t3 = w.submit(dummy, 0)
    print(t.result())
    print(t1.result())
    print(t2.result())
    print(t3.result())

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:36.773379
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    time_0 = time.time()
    result = MonoWorker().submit(time.sleep, 0.01)
    result.result()
    time_1 = time.time()
    tqdm_auto.write('Slow function result:')
    tqdm_auto.write(str(result) + str(time_1 - time_0))



# Generated at 2022-06-26 09:35:44.651687
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    test_func_1 = lambda x: x
    assert mono_worker_1.submit(test_func_1, 1) is not None
    assert mono_worker_1.submit(test_func_1, 2) is not None
    assert mono_worker_1.submit(test_func_1, 3) is not None


# Generated at 2022-06-26 09:35:48.911163
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    if __name__ == "__main__":
        from time import sleep
        from random import randint


        def rand_sleep(dur):
            sleep(dur)
            return dur


        mono_worker_0 = MonoWorker()
        mono_worker_0.submit(rand_sleep, randint(1, 5))
        mono_worker_0.submit(rand_sleep, randint(1, 5))
        mono_worker_0.submit(rand_sleep, randint(1, 5))

# Generated at 2022-06-26 09:35:58.802911
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .test_utils import print_test_name, setup_test_output_file, verify_test_output_file
    import os
    import time

    test_case_num = 0
    print_test_name(test_case_num)
    setup_test_output_file('test_case_' + str(test_case_num))

    def print_sum(a, b):
        time.sleep(1)
        print(a + b)

    mono_worker_0 = MonoWorker()
    f = mono_worker_0.submit(print_sum, 1, 2)
    f = mono_worker_0.submit(print_sum, 2, 1)
    #f = mono_worker_0.submit(print_sum, 3, 2)

# Generated at 2022-06-26 09:36:00.526149
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit('f', 'a')


# Generated at 2022-06-26 09:36:11.099918
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Unit test for method submit of class MonoWorker
    """
    import time
    import os
    from .six import print_

    print_('\n ---- test_MonoWorker_submit() ----')

    output_name = 'test_MultiprocessWorker_submit.out'
    try:
        os.remove(output_name)
    except OSError:
        pass

    def f(i):
        msg = 'i = {}\n'.format(i)
        with open(output_name, 'a') as fd:
            fd.write(msg)
        print_(msg)
        return i

    def test_case_0():
        mono_worker = MonoWorker()
        mono_worker.submit(f, 0)
        # wait to terminate
        time.sleep(1)

# Generated at 2022-06-26 09:36:13.790123
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    futures = deque([], 2)


# Generated at 2022-06-26 09:36:24.490699
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from tqdm.contrib import MonoWorker
    from unittest import TestCase, main

    import time

    from .helpers import isclose

    class TestMonoWorker(TestCase):
        def test_submit(self):
            mw = MonoWorker()
            self.assertTrue(mw.submit(time.sleep, 0.1))
            self.assertTrue(mw.submit(time.sleep, 0.4))
            self.assertTrue(mw.submit(time.sleep, 0.5))
            self.assertFalse(mw.submit(time.sleep, 0.3))

            start = time.time()
            mw.submit(time.sleep, 0.1).result()
            end = time.time()

# Generated at 2022-06-26 09:36:32.466136
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Lock
    from time import sleep
    def test_case_0(mono_worker_0):
        mono_worker_0.submit(test_case_0, mono_worker_0)
        test_case_0(mono_worker_0)
        mono_worker_0.submit(test_case_0, mono_worker_0)
    lock_0 = Lock()
    def test_case_1(mono_worker_0):
        lock_0.acquire()
        lock_0.release()
    def test_case_2(mono_worker_0):
        lock_0.release()
    def test_case_3(mono_worker_0):
        lock_0.release()
    mono_worker_0 = MonoWorker()

# Generated at 2022-06-26 09:36:41.838229
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from os import getpid
    from multiprocessing import cpu_count
    from threading import Thread, Lock
    from subprocess import check_output
    from platform import system
    import pytest
    mono_worker_1 = MonoWorker()
    assert len(mono_worker_1.futures) == 0
    import random
    import time
    import pytest

    def _random_sleep():
        r = random.randint(1, 10)
        time.sleep(r)
        return r

    assert mono_worker_1.submit(_random_sleep) == mono_worker_1.futures[-1]
    assert mono_worker_1.submit(_random_sleep) is not mono_worker_1.futures[-1]
    assert mono_worker

# Generated at 2022-06-26 09:36:59.318939
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    func = print

    # test 0:
    mono_worker_0.submit(func, "hello")
    mono_worker_0.submit(func, "world")


if __name__ == "__main__":
    print(50 * '=')
    print(__doc__.strip())
    print(50 * '-')

    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:37:12.131721
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    # Test with `func` of type 'None'
    # Test with `args` of type 'None'
    # Test with `kwargs` of type 'None'
    mono_worker_0.submit(None, None, None)
    from builtins import locals
    # Test with `func` of type 'function'
    # Test with `args` of type 'None'
    # Test with `kwargs` of type 'None'
    mono_worker_0.submit(locals, None, None)
    # Test with `func` of type 'function'
    # Test with `args` of type 'tuple'
    # Test with `kwargs` of type 'None'
    mono_worker_0.submit(locals, (), None)
    # Test with `func` of type '

# Generated at 2022-06-26 09:37:22.155479
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    First tests asynchronous futures.
    Input:
        func: function returns a string
        *args: arguments for func
        **kwargs: keyword arguments for func
    Returns:
        a string that is output from func(*args, **kwargs)
    """
    import time
    import concurrent.futures
    def func(*args, **kwargs):
        start = time.time()
        while True:
            if time.time() - start > 0.1:
                return "MonoWorker running completed"
    mono_worker_1 = MonoWorker()
    future_1 = mono_worker_1.submit(func)
    time.sleep(0.1)
    assert future_1.result() == "MonoWorker running completed"
    future_2 = mono_worker_1.submit(func)
    future_

# Generated at 2022-06-26 09:37:31.798053
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    counter = [0, 0]


    def inc(idx):
        counter[idx] += 1


    mono_worker_0 = MonoWorker()
    # Test 1: normal execution
    mono_worker_0.submit(inc, 0)
    mono_worker_0.submit(inc, 1)
    mono_worker_0.submit(inc, 0)
    mono_worker_0.submit(inc, 1)
    if counter != [2, 2]:
        print('Test failed.\n')
    else:
        print('Test passed.\n')


if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:37:42.882338
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from queue import Queue

    queue = Queue(100)

    def nop(x, y=4):
        sleep(0.5)
        queue.put((x, y))

    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(nop, 1)
    sleep(0.1)
    mono_worker_1.submit(nop, 3)
    sleep(0.1)
    mono_worker_1.submit(nop, 4, y=3)
    sleep(0.1)
    mono_worker_1.submit(nop, 1, y=2)
    sleep(0.1)
    mono_worker_1.submit(nop, 5)
    sleep(0.1)

# Generated at 2022-06-26 09:37:52.259621
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import concurrent.futures

    mono_test_0 = MonoWorker()
    fut1 = mono_test_0.submit(time.sleep, 3)
    fut2 = mono_test_0.submit(time.sleep, 3)
    fut3 = mono_test_0.submit(time.sleep, 3)

    time.sleep(4)
    assert fut1.done()
    assert fut2.done()
    assert fut3.done()

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:38:03.314853
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures
    import threading

    def part_a(x, y):
        tqdm_auto.write("{}+{}".format(x,y))
        return threading.current_thread().name
    
    mono_worker = MonoWorker()
    future_a = mono_worker.submit(part_a, 3, 4)

    future_b = mono_worker.submit(part_b, 5, 6)

    try:
        concurrent.futures.wait([future_a, future_b])
    except:
        traceback.print_exc()
    else:
        print('success')


if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:38:15.146126
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

    def func1(x, y):
        return x + y

    def func2(x, y):
        return x - y

    def func3(x, y):
        return x * y

    def func4(x, y):
        return x / y

    def func5(x, y):
        return x + y

    # Prints 'future1'
    future1 = mono_worker_0.submit(func1, 5, 9)
    print(future1)

    # Prints 'future2'
    future2 = mono_worker_0.submit(func2, 5, 9)
    print(future2)

    # Prints 'future3'
    future3 = mono_worker_0.submit(func3, 5, 9)
    print(future3)

# Generated at 2022-06-26 09:38:26.134608
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Create instance of MonoWorker
    mono_worker = MonoWorker()

    # Check default state of work pool
    assert len(mono_worker.futures) == 0
    assert mono_worker.pool._work_queue.qsize() == 0

    # Submit a function to the work pool
    def _test_func(x):
        return x + 1

    mono_worker.submit(_test_func, 1)

    # Check that the function was correctly submitted to the pool
    assert len(mono_worker.futures) == 0
    assert mono_worker.pool._work_queue.qsize() == 1
    assert mono_worker.pool._work_queue.get()[0][0] == _test_func



# Generated at 2022-06-26 09:38:29.074103
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(str)

# Generated at 2022-06-26 09:38:46.476592
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit()
    mono_worker_0.submit()
    mono_worker_0.submit()
    mono_worker_0.submit()

# Generated at 2022-06-26 09:38:54.326523
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    result_0 = mono_worker_0.submit(int, '1')
    assert (result_0 == 1)
    result_0 = mono_worker_0.submit(int, '1', base=2)
    assert (result_0 == 1)


if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:38:58.799416
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def test_func(a):
        return (a + 10)
    test_args = ()
    test_kwargs_0 = {'a': 19}
    result_0 = mono_worker_0.submit(test_func, **test_kwargs_0)
    assert result_0.result() == 29


# Generated at 2022-06-26 09:39:09.751396
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import echo, stdout_encode_errors, utf8
    with stdout_encode_errors():  # FIXME: avoid stdout write in these tests
        mono_worker_0 = MonoWorker()
        assert not mono_worker_0.futures
        mono_worker_0.submit(echo, 'aaa')
        assert len(mono_worker_0.futures) == 1
        mono_worker_0.submit(echo, 'bbb')
        assert len(mono_worker_0.futures) == 2
        mono_worker_0.submit(echo, 'ccc')
        assert len(mono_worker_0.futures) == 2
        mono_worker_1 = MonoWorker()
        assert not mono_worker_1.futures
        mono_worker_1

# Generated at 2022-06-26 09:39:21.780991
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import os
    import sys
    import tempfile
    import time
    import random
    import traceback
    import tqdm.contrib.test_utils

    e = MonoWorker()
    # Ensure that we have a valid tempfile to save the output

    tmp_fname = tempfile.mktemp()
    tmp_f = open(tmp_fname, "w")

# Generated at 2022-06-26 09:39:26.238354
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    # create MonoWorker instance
    mono_worker = MonoWorker()
    # create new task, `func` will be called after 0.1 seconds
    task = mono_worker.submit(time.sleep, 0.1)
    # create a new task, `func` will be called immediately
    task = mono_worker.submit(time.sleep, 0.1)
    # create a new task, `func` will not be called because task pool is full
    task = mono_worker.submit(time.sleep, 0.1)
    # wait for task to complete
    task.result()

# Generated at 2022-06-26 09:39:29.597251
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(test_func_0) == None


# Generated at 2022-06-26 09:39:39.116011
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    for i in tqdm_auto.tqdm(range(0,1000), desc='MonoWorker.submit',
                             leave=False):
        mono_worker_0.submit(tqdm_auto.sleep,(0.01))


if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:39:44.336483
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def test_func(foo):
        """Just return"""
        return foo
    assert mono_worker_0.submit(test_func, 'a').result() == 'a'
    assert mono_worker_0.submit(test_func, 'b').result() == 'b'
    assert mono_worker_0.submit(test_func, 'c').result() == 'b'

# Generated at 2022-06-26 09:39:53.612981
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    print('test_MonoWorker_submit()')
    from time import sleep
    from random import uniform

    def func(s):
        sleep(s)
        return s

    mono_worker = MonoWorker()
    f0 = mono_worker.submit(func, uniform(0.5, 1))
    f1 = mono_worker.submit(func, uniform(0.5, 1))
    f2 = mono_worker.submit(func, uniform(0.5, 1))
    f3 = mono_worker.submit(func, uniform(0.5, 1))
    assert f3.result() == f2.result(), \
        "Test case FAILED, mono_worker.submit()"
    print('test_MonoWorker_submit() PASSED')


if __name__ == '__main__':
    test_

# Generated at 2022-06-26 09:40:38.290113
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, "test_case_1")
    mono_worker_0.submit(print, "test_case_2")
    mono_worker_0.submit(print, "test_case_3")

# Generated at 2022-06-26 09:40:47.673523
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Testing the argument 'func'
    # Testing the argument 'args'
    # Testing the argument 'kwargs'
    mono_worker = MonoWorker()
    with ThreadPoolExecutor(max_workers=1) as pool:
        with tqdm_auto.tqdm(total=3) as pbar:
            future_0 = mono_worker.submit(pool.submit, pbar.update, 3)
            future_1 = mono_worker.submit(pool.submit, pbar.update, 10)


# Generated at 2022-06-26 09:40:53.612160
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    for i in range(5):
        mono_worker.submit(lambda: 2*i)
    for i in range(5):
        assert mono_worker.futures[i].result() == 8


# Generated at 2022-06-26 09:40:59.904921
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    with tqdm_auto.tqdm(total=2) as t, \
            ThreadPoolExecutor(max_workers=2) as pool:
        results = []
        for i in range(2):
            results.append(pool.submit(t.update, 1))
        for i in range(2):
            mono_worker.submit(t.update, 1)
        for r in results:
            r.result()



# Generated at 2022-06-26 09:41:02.627439
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit("Hello")


# Generated at 2022-06-26 09:41:11.701532
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    class TestThreadPoolExecutor(object):
        def __init__(self):
            self.ran = 0
            self.raise_ = False
        def submit(self, *args, **kwargs):
            self.ran += 1
            if self.raise_:
                raise Exception("Test Failed")
            return self.ran
    test_inst = TestThreadPoolExecutor()
    mono_worker_inst = MonoWorker()
    mono_worker_inst.pool = test_inst
    mono_worker_inst.submit("","")
    assert test_inst.ran == 1
    mono_worker_inst.submit("","")
    assert test_inst.ran == 2
    mono_worker_inst.submit("","")
    assert test_inst.ran == 3
    test_inst.raise_ = True
    mono_worker_inst.submit

# Generated at 2022-06-26 09:41:24.095728
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    #test submit function with arguments and kwargs
    #test submit function with kwargs only
    #test submit function with arguments only
    #test submit function with no arguments and kwargs
    def testfun(a):
      return a*2
    for i in range(0,4):
      if i == 0:
        #call submit function with arguments and kwargs
        mono_worker_0.submit(testfun, a = 7)
      elif i == 1:
        #call submit function with kwargs only
        mono_worker_0.submit(testfun, a = 7)
      elif i == 2:
        #call submit function with arguments only
        mono_worker_0.submit(testfun, 7)

# Generated at 2022-06-26 09:41:27.224775
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    return_value = mono_worker_1.submit(lambda x:x,2)

# Generated at 2022-06-26 09:41:29.776719
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(nested_things,1,2)



# Generated at 2022-06-26 09:41:33.635718
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    result = MonoWorker.submit(mono_worker_0, 'func', str, dict)
    assert result == None
