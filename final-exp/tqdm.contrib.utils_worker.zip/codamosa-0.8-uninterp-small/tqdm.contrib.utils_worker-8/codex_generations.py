

# Generated at 2022-06-26 09:33:14.234181
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    import time

    def func():
        time.sleep(1)

    mono_worker_0.submit(func)

# Generated at 2022-06-26 09:33:15.786002
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit()

# Generated at 2022-06-26 09:33:27.439379
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import unittest
    import pytest

    class Cases(unittest.TestCase):
        def test_case_0(self):
            from unittest.mock import MagicMock
            mono_worker_0 = MonoWorker()
            futures_0_0 = mono_worker_0.futures
            futures_0_1 = [MagicMock(), MagicMock(), MagicMock(), MagicMock()]
            futures_0_0.appendleft(futures_0_1[0])
            futures_0_0.appendleft(futures_0_1[1])
            futures_0_0.append(futures_0_1[2])
            futures_0_0.append(futures_0_1[3])

# Generated at 2022-06-26 09:33:39.194364
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    with open('report.txt', 'w') as fout:
        try:
            mono_worker_0 = MonoWorker()
        except TypeError:
            print('Failed to create instance of class MonoWorker')
            print('TypeError: __init__() takes 1 positional argument but 2 were given')
        else:
            print('Successfully created instance of class MonoWorker')
            print('Begin testing method submit of class MonoWorker')
            try:
                assert callable(mono_worker_0.submit)
            except AssertionError:
                print('Failed to test if attribute submit of class MonoWorker is callable')
            else:
                print('Successfully tested if attribute submit of class MonoWorker is callable')

# Generated at 2022-06-26 09:33:45.071195
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def mock_func(arg_0):
        assert arg_0 == 'arg_0'
        return 'ret_0'
    ret_0 = mono_worker_0.submit(mock_func, 'arg_0')
    assert ret_0.result() == 'ret_0'


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 09:33:50.471695
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()

# Generated at 2022-06-26 09:33:54.125235
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(MonoWorker)


# Generated at 2022-06-26 09:33:59.841879
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Tests submit method.
    """
    import time
    import random

    def is_prime(n):
        """
        Tests if n is a prime number.
        """
        if n % 2 == 0:
            return False

        sqrt_n = int(n**0.5) + 1
        for divisor in range(3, sqrt_n, 2):
            if n % divisor == 0:
                return False
        return True

    # Create and start thread with MonoWorker
    mono_worker_0 = MonoWorker()

    # Submit multiplication
    for _ in range(0, 100):
        x, y = random.randint(0, 100), random.randint(0, 100)
        mono_worker_0.submit(lambda z, w: z * w, x, y)
       

# Generated at 2022-06-26 09:34:08.436496
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def closure_0():
        return int(10)
    def closure_1():
        return int(10 ** 2)
    def closure_2():
        return int(10 ** 3)
    assert str(int(10)) == str(mono_worker_0.submit(closure_0).result())
    assert str(int(10 ** 2)) == str(mono_worker_0.submit(closure_1).result())
    assert str(int(10 ** 3)) == str(mono_worker_0.submit(closure_2).result())
    assert str(int(10 ** 2)) == str(mono_worker_0.submit(closure_1).result())

# Generated at 2022-06-26 09:34:10.844056
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    return (mono_worker_0.submit('foo'))

# Generated at 2022-06-26 09:34:21.588935
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    # 1.
    mono_worker = MonoWorker()
    mono_worker.submit(lambda x: print(x), 3)
    assert len(mono_worker.futures) == 1
    mono_worker.submit(lambda x: print(x), 6)
    assert len(mono_worker.futures) == 1
    # 2.
    mono_worker = MonoWorker()
    mono_worker.submit(lambda x: print(x), 3)
    assert len(mono_worker.futures) == 1
    mono_worker.submit(lambda x: print(x), 6)
    mono_worker.submit(lambda x: print(x), 9)
    assert len(mono_worker.futures) == 1

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-26 09:34:24.960986
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    # test 0
    assert mono_worker_0.submit(lambda x, y : x + y, 0, 1)

# Generated at 2022-06-26 09:34:29.310662
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda: None)
    mono_worker_0.submit(lambda: 1)


# Generated at 2022-06-26 09:34:32.518579
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(repr, 1)


# Generated at 2022-06-26 09:34:37.033093
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    def test_func(x, y=3):
        return x + y

    assert mw.submit(test_func, 1) == 4
    assert mw.submit(test_func, y=4, x=2) == 6
    assert mw.submit(test_func, x=1) == 4

# Generated at 2022-06-26 09:34:47.892068
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import tqdm

    mono_worker_1 = MonoWorker()

    def countdown(n):
        for i in tqdm.trange(n):
            if i == n//2:
                time.sleep(1)
            time.sleep(0.05)
        return n

    for i in range(0, 5):
        mono_worker_1.submit(countdown, 15)
        time.sleep(0.3)

    time.sleep(1)  

    for i in range(0, 5):
        mono_worker_1.submit(countdown, 15)
        time.sleep(0.4)


# Generated at 2022-06-26 09:34:55.220609
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, random
    def test_func(i):
        time.sleep(random.random())
        print("{0} {1}".format(i, time.time()))
        return i

    mono_worker_1 = MonoWorker()
    for i in range(20):
        mono_worker_1.submit(test_func, i)


# Generated at 2022-06-26 09:34:57.068489
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    try:
        mono_worker.submit("")
        assert False
    except TypeError:
        pass
    

# Generated at 2022-06-26 09:35:04.236793
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker_1 = MonoWorker()
    try:
        mono_worker_1.submit(time.sleep, 2)
    finally:
        mono_worker_1.futures.popleft().cancel()


if __name__ == '__main__':
    from . import _main_test_case
    _main_test_case(__file__)

# Generated at 2022-06-26 09:35:05.343045
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    test_case_0()


# Generated at 2022-06-26 09:35:17.189055
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(x, y):
        return x + y
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(f, 1, 2)
    mono_worker_1.submit(f, 1, 2)
    mono_worker_1.submit(f, 1, 2)


# Generated at 2022-06-26 09:35:26.903230
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test case #0: Test MonoWorker with trivial methods
    """
    def trivial_method(sleep_time):#
        import time
        # print("trivial_method", sleep_time)
        time.sleep(sleep_time)
        return sleep_time

    mono_worker_0 = MonoWorker()

    for i in range(0,8):
        mono_worker_0.submit(trivial_method, i)
        # print("test_MonoWorker_submit: ", i)

test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:32.727031
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    func_0 = lambda x: x
    arg_0 = 'test'
    value_0 = mono_worker_0.submit(func_0, arg_0)
    assert isinstance(value_0, object)

# Generated at 2022-06-26 09:35:39.946856
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    x = MonoWorker()
    sum_ = 0
    for n in range(1, 5):
        for i in range(n):
            sum_ += n
            x.submit(lambda n=n: n)
    assert sum_ == 10
    assert len(x.futures) == 1
    assert x.futures[0].result() == 4
    for n in range(5, 8):
        for i in range(n):
            sum_ += n
            x.submit(lambda n=n: n)
    assert sum_ == 25
    assert len(x.futures) == 1
    assert x.futures[0].result() == 7

# Generated at 2022-06-26 09:35:46.805440
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(x, delay):
        time.sleep(delay)
        return x + delay

    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(f, (1), (1))
    mono_worker_0.submit(f, (2), (1))
    mono_worker_0.submit(f, (3), (1))



# Generated at 2022-06-26 09:35:49.860780
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Set up
    mono_worker = MonoWorker()

    # Test
    mono_worker.submit(test_case_0)

# Generated at 2022-06-26 09:35:54.714900
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    assert mono_worker.submit(print, "test")

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:59.895233
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    result = mono_worker.submit(print, "test")
    assert isinstance(result, concurrent.futures._base.Future)

# Generated at 2022-06-26 09:36:05.460761
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from nose.tools import assert_true

    def f():
        return 0

    mono_worker_0 = MonoWorker()
    assert_true(isinstance(mono_worker_0.submit(f), Future))

# Generated at 2022-06-26 09:36:19.235304
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import datetime as dt
    import threading


    class Timer(object):
        """
        Create a timer that can be used to delay code execution for a while
        """

        def __init__(self, number=None, seconds=0, minutes=0, hours=0, days=0):
            """
            Initialize the timer
            :param number: The number of times to repeat the timer
            :param seconds: Number of seconds to delay
            :param minutes: Number of minutes to delay
            :param hours: Number of hours to delay
            :param days: Number of days to delay
            """
            if number is not None:
                if seconds == 0 and minutes == 0 and hours == 0 and days == 0:
                    raise ValueError("You need to specify time intervals to use number")

# Generated at 2022-06-26 09:36:32.449295
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    def cost_30s(x, y=0):
        import time
        time.sleep(30)
        tqdm_auto.write(str(x) + ' ' + str(y))

    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(cost_30s, 42)  # submit first
    mono_worker_0.submit(cost_30s, 2, y=4)  # submit second


if __name__ == '__main__':
    """
    python -m tqdm.contrib.monoworker
    """
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:36:35.595964
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    result = mono_worker_0.submit("test")
    assert result == None


# Generated at 2022-06-26 09:36:37.603166
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Tests functionality of method submit of class MonoWorker
    """
    pass

# Generated at 2022-06-26 09:36:42.346250
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = test_case_0()
    func_0 = lambda x: (lambda y: y ** 2 + x ** 2)(x ** 2)
    args_0 = (2, )
    kwargs_0 = {}
    mono_worker_0.submit(func_0, *args_0, **kwargs_0)


if __name__ == "__main__":  # pragma: no cover
    import os
    import subprocess
    for t in dir():
        if t.startswith('test_'):
            subprocess.check_call(['python', '-m', 'unittest', t])

# Generated at 2022-06-26 09:36:50.603293
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_obj = MonoWorker()
    import time
    for i in range(5):
        mono_worker_obj.submit(time.sleep, 5)
        assert len(mono_worker_obj.futures) >= 1
        assert len(mono_worker_obj.futures) <= 2
    for i in range(5):
        mono_worker_obj.submit(time.sleep, 0.1)
        assert len(mono_worker_obj.futures) == 1

# Generated at 2022-06-26 09:37:01.879220
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test case 0
    mono_worker_0 = MonoWorker()
    input_func_0 = [
        lambda: None,
    ]
    input_args_0 = [
        None,
    ]
    input_kwargs_0 = [
        None,
    ]
    input_submit_args_0 = [
        input_func_0[0],
    ]
    input_submit_kwargs_0 = [
        input_kwargs_0[0],
    ]
    output_submit_0 = mono_worker_0.submit(*input_submit_args_0, **input_submit_kwargs_0)
    output_submit_1 = mono_worker_0.submit(*input_submit_args_0, **input_submit_kwargs_0)

test_case_0()
test_Mono

# Generated at 2022-06-26 09:37:09.994861
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(*args, **kwargs):
        return args, kwargs
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(func, 'args', kwargs = 'kwargs').result()[0] == 'args'
    assert mono_worker_0.submit(func, 'args', kwargs = 'kwargs').result()[1]['kwargs'] == 'kwargs'


# Generated at 2022-06-26 09:37:21.699388
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from collections import deque
    from multiprocessing.pool import ThreadPool

    def try_sleep(i, sleep_time=.5):
        for _ in tqdm(range(10), desc=str(i)):
            sleep(sleep_time)

    p = ThreadPool(1)
    submitted = deque()

    mw = MonoWorker()
    submitted.append(mw.submit(try_sleep, 0, sleep_time=.1))
    submitted.append(mw.submit(try_sleep, 1, sleep_time=.1))
    submitted.append(mw.submit(try_sleep, 2, sleep_time=.1))
    submitted.append(mw.submit(try_sleep, 3, sleep_time=.1))

    submitted[-1].result() 

# Generated at 2022-06-26 09:37:27.123288
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(globals)
    mono_worker_1.submit(globals)

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:37:34.459961
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from functools import partial

    def f(n):
        time.sleep(1)
        tqdm_auto.write('f{}'.format(n))

    def fail():
        raise RuntimeError('fail')

    mono_worker = MonoWorker()
    a = mono_worker.submit(partial(f, 1))
    b = mono_worker.submit(partial(f, 2))
    c = mono_worker.submit(partial(f, 3))
    try:
        mono_worker.submit(fail)
    except:
        pass

    mono_worker.submit(partial(f, 4))  # replace running f3
    mono_worker.submit(partial(f, 5))
    mono_worker.submit(partial(f, 6))  # replace waiting f5
    tq

# Generated at 2022-06-26 09:38:03.289560
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    if len(mono_worker_0.futures) == mono_worker_0.futures.maxlen:
        running = mono_worker_0.futures.popleft()
        if not running.done():
            if len(mono_worker_0.futures):  # clear waiting
                waiting = mono_worker_0.futures.pop()
                waiting.cancel()
            mono_worker_0.futures.appendleft(running)  # re-insert running
    try:
        waiting = mono_worker_0.pool.submit(None, None)
    except Exception as e:
        tqdm_auto.write(str(e))
    else:
        mono_worker_0.futures.append(waiting)
       

# Generated at 2022-06-26 09:38:06.430711
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit('abc')


# Generated at 2022-06-26 09:38:12.182479
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import string
    def func():
        return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
    mono_worker = MonoWorker()
    result = mono_worker.submit(func)
    result.result()

# Generated at 2022-06-26 09:38:16.328521
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit()


# Generated at 2022-06-26 09:38:22.679223
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import time
    from random import random

    # Generate dummy data
    data = {idx: random() for idx in range(40)}
    data_keys = list(data.keys())

    # Define dummy function with random delay
    def func(name):
        from time import sleep
        from random import random
        sleep(random())
        return name

    # Construct MonoWorker object
    mono_worker = MonoWorker()

    # Execute dummy function
    for idx in data_keys:
        mono_worker.submit(func, idx)

    # Check that only one task is running and no task is pending
    mono_worker_futures = mono_worker.futures
    assert len(mono_worker_futures) == 1

# Generated at 2022-06-26 09:38:26.335705
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(x):
        return x

    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(func, 1)
    mono_worker_1.submit(func, 1)
    mono_worker_1.submit(func, 1)

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:38:36.323817
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .test_tqdm import log
    import logging
    import sys
    import threading

    def startup():
        # Set up logging
        log.setLevel(logging.INFO)
        stream = logging.StreamHandler(sys.stderr)
        stream.setFormatter(logging.Formatter(
            '%(asctime)s %(levelname)s %(message)s'))
        log.addHandler(stream)

    def main(argv):
        tqdm_auto.write('{:=^80}'.format('test_MonoWorker_submit'))
        mono_worker = MonoWorker()


# Generated at 2022-06-26 09:38:42.604572
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(sys.exit, 0)

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:38:46.328141
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Create an instance of MonoWorker
    mono_worker_1 = MonoWorker()
    # Call the submit method of MonoWorker
    mono_worker_1.submit(str, 42)


# Generated at 2022-06-26 09:38:56.242863
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    `func(*args, **kwargs)` may replace currently waiting task
    """
    
    def hello(name):
        return "Hello " + name
    mono_worker_0 = MonoWorker()
    mono_worker_1 = mono_worker_0.submit(hello, "Soso")
    mono_worker_2 = mono_worker_0.submit(hello, "Jack")
    mono_worker_3 = mono_worker_0.submit(hello, "Daniels")
    mono_worker_4 = mono_worker_1.submit(hello, "Honey")


# Generated at 2022-06-26 09:39:41.672437
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    class task:
        def __init__(self, result):
            self.result = result
        def __call__(self, *args, **kwargs):
            return self.result
    e = Exception("An exception")
    worker = MonoWorker()
    assert worker.submit(task(42)) is worker.submit(task(17))
    assert worker.submit(task(e)) is worker.submit(task(17))
    assert worker.submit(task(e)) is worker.submit(task(e))


# Generated at 2022-06-26 09:39:45.397428
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func0(*args, **kwargs):
        print("func0")
    mono_worker_0.submit(func0)

# Generated at 2022-06-26 09:39:51.118042
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    with tqdm_auto.tqdm(total=1) as pbar:
        # Test 1: func with no return
        mono_worker.submit(test_MonoWorker_submit_0)
        # Test 2: func with return
        result = mono_worker.submit(test_MonoWorker_submit_1)

# Test 1: func with no return

# Generated at 2022-06-26 09:39:58.795570
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    import multiprocessing

    def foo(x):
        if x == 0:
            raise Exception("InvalidInput")
        import time
        time.sleep(x)
        return x

    def fn(x):
        mono_worker_0 = MonoWorker()
        mono_worker_0.submit(foo, x)

    manager = multiprocessing.Manager()
    pool = multiprocessing.Pool(1)

    ls = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0]
    t = pool.map_async(fn, ls)

    t.wait()

    if t.successful():
        print("Completed")

# Generated at 2022-06-26 09:40:09.874799
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def _job(tq_manager, seconds, message):
        pbar = tqdm_auto.tqdm(total=seconds, desc=message, leave=False)
        for i in range(seconds):
            time.sleep(1)
            pbar.update(1)
    mono_worker_0 = MonoWorker()

    job_0 = mono_worker_0.submit(_job, self, int(6), str('job_0'))
    job_1 = mono_worker_0.submit(_job, self, int(6), str('job_1'))
    job_2 = mono_worker_0.submit(_job, self, int(6), str('job_2'))
    job_3 = mono_worker_0.submit(_job, self, int(6), str('job_3'))
    

# Generated at 2022-06-26 09:40:16.314442
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    def function(arg1, arg2, arg3):
        return arg1*arg2/arg3

    res = mono_worker.submit(function,1,1,1)
    assert res.result() == 1
    res = mono_worker.submit(function,1,1,1)
    assert res.result() == 1

# Generated at 2022-06-26 09:40:17.432344
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # TODO: Write unit test
    pass

# Generated at 2022-06-26 09:40:28.010414
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(lambda x: x*x, 2)
    try:
        assert True
    except:
        assert False

if __name__ == '__main__':
    import sys
    args = sys.argv
    if len(args) > 0:
        func = globals().get(args[0])
        if func:
            func()
    else:
        print('Usage: <function>')
        print('Available functions:')
        for k in globals().keys():
            if k.startswith('test_') and callable(globals()[k]):
                print(k)

# Generated at 2022-06-26 09:40:32.013209
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    MonoWorker().submit(lambda x: x, 'test')

if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:40:40.490430
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    print("MonoWorker_submit:" + str(mono_worker_0.submit))
    print("MonoWorker_submit:" + str(mono_worker_0.submit))
    print("MonoWorker_submit:" + str(mono_worker_0.submit))
    print("MonoWorker_submit:" + str(mono_worker_0.submit))
    print("MonoWorker_submit:" + str(mono_worker_0.submit))
    print("MonoWorker_submit:" + str(mono_worker_0.submit))

if __name__ == "__main__":
    # test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:42:14.422701
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    MonoWorker_submit_1 = mono_worker_0.submit(lambda: print("Hello World"))
    MonoWorker_submit_1.result()


# Generated at 2022-06-26 09:42:25.309115
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, 1)
    mono_worker_0.submit(print, 2)
    mono_worker_0.submit(print, 3)
    mono_worker_0.submit(print, 4)


if __name__ == "__main__":
    import sys
    import os
    import time
    import math

    def print_str(string):
        print(string)
    def print_float(f):
        print(float(f))
    def sleep(sec):
        time.sleep(sec)
    def wait(sec):
        time.sleep(sec)

    t0 = time.time()
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print_float, 1.0)
    mono

# Generated at 2022-06-26 09:42:29.975860
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # case: 0
    mono_worker_0 = MonoWorker()
    # passed
    # case: 1
    mono_worker_0 = MonoWorker()
    # passed

# Generated at 2022-06-26 09:42:35.401681
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    n = 10
    results = []
    for i in reversed(range(n)):
        mono_worker_0.submit(lambda: (i,list(range(10**9))))
    mono_worker_0.submit(lambda: (i,list(range(10**9))))
    mono_worker_0.submit(lambda: (i,list(range(10**9))))


# Generated at 2022-06-26 09:42:38.555160
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    assert mono_worker_1.submit(lambda: None) is not None


# Generated at 2022-06-26 09:42:46.237382
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    from io import StringIO
    from unittest import TestCase

    from .test_tests import _monkey_patch

    @_monkey_patch(sys, '__stdout__', StringIO())
    def tests():
        # Unit test 0
        mono_worker_0 = MonoWorker()
        assert mono_worker_0.submit(lambda: "test_output_0") == None

    tests()
    monkey_stdout = sys.__stdout__
    sys.__stdout__ = sys.stdout
    assert monkey_stdout.getvalue() == 'test_output_0\n'

# Generated at 2022-06-26 09:42:55.293602
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Valid argument:
        args:
            func (function): any function
            args (list): a list of function arguments
            kwargs (dict): a dictionary of named function arguments
    Expected result:
        returns (object): a future
    """
    import math
    def _func(x):
        return x * math.sin(x)
    mono_worker_1 = MonoWorker()
    future = mono_worker_1.submit(_func, math.pi)
    assert hasattr(future, "_set_callback")
    

# Generated at 2022-06-26 09:42:59.600330
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    result = mono_worker_0.submit(lambda : 1)
    assert result.result() == 1


# Generated at 2022-06-26 09:43:03.145349
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, "Hello World")


# Generated at 2022-06-26 09:43:06.267785
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda : None)
    mono_worker_0.submit(lambda : None)
    mono_worker_0.submit(lambda : None)
    mono_worker_0.submit(lambda : None)
