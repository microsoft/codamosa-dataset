

# Generated at 2022-06-26 09:33:06.659716
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    print("Testing method submit")
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit()
    print("Test complete")

# Main function for unit tests

# Generated at 2022-06-26 09:33:10.423579
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit("info", "no", "idea")


# Generated at 2022-06-26 09:33:17.146569
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from math import factorial

    def f_slow(n):
        sleep(2)
        return factorial(n)
    mono_worker_0 = MonoWorker()
    # orig code: mono_worker_0.submit(f_slow, 42)
    mono_worker_0.submit(f_slow, 42)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 09:33:23.449093
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()

    from concurrent.futures import Future
    from unittest import mock

    def submit(func, *args, **kwargs):
        return Future()

    mono_worker.pool.submit = mock.Mock(side_effect=submit)



# Generated at 2022-06-26 09:33:27.392120
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Create a unit test
    mono_worker = MonoWorker()
    count = 0
    
    # Submits 2 tasks
    mono_worker.submit(lambda: count+1)
    mono_worker.submit(lambda: count+1)

    # Checks that there is only one task
    assert len(mono_worker.futures) == 1


# Generated at 2022-06-26 09:33:36.097688
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, 'hi')
    mono_worker_0.submit(print, 'hello')
    mono_worker_0.submit(print, 'how are you?')
    mono_worker_0.submit(print, 'I\'m fine')

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:33:44.712678
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, "hello world", end="")
    mono_worker_0.submit(print, "hello world")
    mono_worker_0.submit(print, "hello world", end="")
    mono_worker_0.submit(print, "hello world")
    mono_worker_0.submit(print, "hello world", end="")
    mono_worker_0.submit(print, "hello world")

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:33:51.566632
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Generate an object of class MonoWorker
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit("arg0", arg1=None, arg2=None)

if __name__ == "__main__":
    test_MonoWorker_submit()
    print("All tests passed!")

# Generated at 2022-06-26 09:33:55.186143
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit('asdf')
    mono_worker_0.submit('asdf')


# Generated at 2022-06-26 09:34:03.286129
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

    def func_0(*args, **kwargs):
        return args, kwargs

    mono_worker_0.submit(func_0, 1, 2, 3)
    mono_worker_0.submit(func_0, 1, 2, 3)
    mono_worker_0.submit(func_0, 1, 2, 3)

# Generated at 2022-06-26 09:34:19.129892
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from time import sleep
    from unittest import TestCase

    class Test(TestCase):
        def test(self):
            mono_worker_0 = MonoWorker()
            mono_worker_0.submit(sleep, 1, result=0)
            mono_worker_0.submit(sleep, 1, result=1)
            mono_worker_0.submit(sleep, 1, result=2)
            self.assertEqual(mono_worker_0.futures.pop().result(), 0)
            self.assertEqual(mono_worker_0.futures.pop().result(), 2)

    Test().test()

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:34:28.535408
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    This is a simple test case, to check the functionality of the submit
    method. When the do_something method is invoked, the join method is
    invoked too, with a timeout interval of 0.1 seconds. The join method will
    return only when the message 'hello' is printed to the console. This is
    done by invoking the do_something_else method after the do_something
    method. The test case will pass, only if the current time difference from
    the starting time is less than 0.2 seconds. The intention is to test if
    the join method is invoked, and the do_something_else method is
    invoked after the do_something method.
    """
    import time
    def do_something_else():
        print('hello')
    def do_something():
        mono_worker_0.submit(do_something_else)

   

# Generated at 2022-06-26 09:34:38.691357
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Checks `submit` method of class `MonoWorker`
    """
    # import necessary modules
    import time
    import random
    from queue import Queue
    from threading import Thread
    import unittest
    import sys

    # define necessary functions
    def test_func(i):
        time.sleep(0.1)
        print("test_func", i)
        return i

    def test_func2(i):
        time.sleep(0.1)
        print("test_func2", i)
        return i

    def test_func3(i):
        time.sleep(0.1)
        print("test_func3", i)
        return i

    def test_func4(i):
        time.sleep(0.1)
        print("test_func4", i)


# Generated at 2022-06-26 09:34:46.282928
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func(arg0, arg1):
        return (arg0, arg1)
    def func(arg0, arg1, arg2):
        return (arg0, arg1, arg2)
    mono_worker_0.submit(func, 1, 2)
    mono_worker_0.submit(func, 1, 2, 4)

# Generated at 2022-06-26 09:34:55.414859
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import ThreadPoolExecutor
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit('str')
    mono_worker_0.submit('str', 'str')
    mono_worker_0.submit('str', 'str', 'str')
    mono_worker_0.submit('str', 'str', 'str', 'str')
    mono_worker_0.submit('str', 'str', 'str', 'str', 'str')


# Generated at 2022-06-26 09:34:58.134871
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Declare the function and add tests

    def test_submit_0():
        # Declare the parameters
        func = None
        args = None
        kwargs = None

        # Execute the tested code
        result = mono_worker_0.submit(func, *args, **kwargs)

        # Check the results
        assert result is None

    # Execute the tests
    test_submit_0()

# Generated at 2022-06-26 09:35:03.949134
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    mono_worker_0 = MonoWorker()
    def func(x):
        return x
    args = (int, )
    kwargs = {}
    returnvalue = mono_worker_0.submit(func, *args, **kwargs)
    print(returnvalue)


# Generated at 2022-06-26 09:35:09.810951
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import pytest
    #
    #   Create an instance of MonoWorker
    #
    mono_worker = MonoWorker()
    #
    #   Assert that the MonoWorker object is empty
    #
    assert len(mono_worker.futures) == 0
    #
    #   Add five new tasks
    #
    tasks = []
    for i in range(5):
        #
        #   Add a task with a sleep of one second, and a task-specific return value
        #
        task = mono_worker.submit(time.sleep, 1)
        tasks.append(task)
    #
    #   Assert that two tasks have been added: the most recent and the current task
    #
    assert len(mono_worker.futures) == 2
    #
    #  

# Generated at 2022-06-26 09:35:14.190195
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(func=test_case_0)


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:16.486195
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit()

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:30.457994
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from . import mw_0
    from . import mw_1
    from . import mw_2
    from . import mw_3

    # Test 1:
    mono_worker_0 = MonoWorker()
    mw_0.submit(mono_worker_0)
    mw_1.submit(mono_worker_0)
    mw_2.submit(mono_worker_0)
    mw_3.submit(mono_worker_0)

    # Test 2:
    mono_worker_0 = MonoWorker()
    mw_0.submit(mono_worker_0)
    mw_1.submit(mono_worker_0)
    mw_0.submit(mono_worker_0)
    mw_0.submit(mono_worker_0)

# Generated at 2022-06-26 09:35:34.370440
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    for _ in range(MonoWorker.submit.__code__.co_argcount - 1):
        mono_worker_1.submit()

# Generated at 2022-06-26 09:35:36.299355
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda : 1)


# Generated at 2022-06-26 09:35:47.323088
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Lock
    from time import sleep
    lock = Lock()
    mono_worker = MonoWorker()

    def worker(time_to_sleep):
        with lock:
            print("Enter worker, sleep for " + str(time_to_sleep) + " seconds")
        sleep(time_to_sleep)
        with lock:
            print("Exit worker")

    mono_worker.submit(worker, 1)
    mono_worker.submit(worker, 2)
    mono_worker.submit(worker, 3)
    sleep(10)


if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:52.193736
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func(arg0, arg1, arg2):
        return
    func_exit = mono_worker_0.submit(func, '', True, 0)
    assert None is func_exit

# Generated at 2022-06-26 09:35:57.994795
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    mono_worker.submit(tqdm_auto.write, "This is first message\n")
    mono_worker.submit(tqdm_auto.write, "This is second message\n")
    mono_worker.submit(tqdm_auto.write, "This is third message\n")

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:36:00.773867
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # mono_worker_0 = MonoWorker()
    # mono_worker_0.submit()
    pass

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:36:09.350537
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    pbar = tqdm_auto.tqdm(total=1)
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(tqdm_auto.tqdm.get_lock, pbar)
    mono_worker_0.submit(tqdm_auto.tqdm.write, 'bar', file=pbar)
    mono_worker_0.submit(tqdm_auto.tqdm.set_description, 'baz', pbar)
    pbar.close()


# Generated at 2022-06-26 09:36:10.934744
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(x, y):
        return x + y
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(func, 1, 2) is not None

# Generated at 2022-06-26 09:36:18.861898
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint
    from multiprocessing import cpu_count

    mono_worker_1 = MonoWorker()
    tqdm_worker_1 = tqdm_auto.tqdm(total=10000000)
    cpus = cpu_count()
    futures = [mono_worker_1.submit(sleep, randint(1, cpus))
               for _ in tqdm_worker_1]
    for future in tqdm_worker_1:
        future.result()



# Generated at 2022-06-26 09:36:31.014728
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    pool = ThreadPoolExecutor(max_workers=1)
    futures = deque([], 2)
    def func(*args, **kwargs):
        return(*args,)
    with ThreadPoolExecutor(max_workers=1) as pool:
            futures.append(pool.submit(func, 1, 2))
            futures.append(pool.submit(func, 3, 4))
            assert futures.__sizeof__() == 48


# Generated at 2022-06-26 09:36:34.757634
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker();
    mono_worker_0.submit(func,*args,**kwargs)


# Generated at 2022-06-26 09:36:39.235191
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    # the following function should calculate 2**n
    def pow_2(n):
        return (2**n)
    
    assert(mw.submit(pow_2, 1) == 2)


# Generated at 2022-06-26 09:36:44.545133
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

    def a_func(*args, **kwargs):
        return args[0]

    x = mono_worker_0.submit(a_func, 10)



# Generated at 2022-06-26 09:36:52.647064
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    from time import sleep
    from concurrent.futures import Future
    x = mono_worker_0.submit(sleep, 2, True)
    mono_worker_1 = MonoWorker()
    x = mono_worker_1.submit(sleep, 2, True)

    mono_worker_2 = MonoWorker()
    x = mono_worker_2.submit(sleep, 2, True)
    x = mono_worker_2.submit(sleep, 2, True)
    x = mono_worker_2.submit(sleep, 2, True)
    x = mono_worker_2.submit(sleep, 2, True)
    x = mono_worker_2.submit(sleep, 2, True)
    x = mono_worker_2.submit(sleep, 2, True)

# Generated at 2022-06-26 09:36:59.647066
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Unit test for method __init__ of class MonoWorker
    worker0 = MonoWorker()
    # Unit test for method submit of class MonoWorker
    worker0.submit(lambda: 10)
    worker0.submit(lambda: 20)
    worker0.submit(lambda: 30)

test_MonoWorker_submit()

# Generated at 2022-06-26 09:37:12.288355
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import math
    
    from ..auto import tqdm as tqdm_auto
    
    
    
    
    
    
    
    
    
    
    def _tqdm_write_to(tfile, buf, file=sys.stdout):
        print(buf, file=tfile)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    list_items = range(100)
    def simulate_slow_task(item):
        print('Running task on item {}'.format(item))
        return math.log1p(item)
    
    def test_func(item):
        ret = simulate_slow_task(item)
        return ret
    

# Generated at 2022-06-26 09:37:17.179512
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    worker = MonoWorker()
    assert worker.submit(lambda: print('first')) is not None
    assert worker.submit(lambda: print('second')) is not None
    assert worker.submit(lambda: print('third')) is not None

# Generated at 2022-06-26 09:37:23.306271
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def sleep(x):
        import time
        time.sleep(x)
        return x

    from .tutils import get_free_port, get_free_unix_socket
    from .utils import split_port
    from .http_server import http_server
    from .websocket_server import websocket_server
    from .http_client import http_client
    from .websocket_client import websocket_client
    from .parallel_tqdm import parallel_map
    from .base_server import base_server
    #from .base_client import base_client
    from .shared_dict import SharedDict
    from .port_manager import PortManager
    from .port_manager_client import PortManagerClient
    from .shared_dict_client import SharedDictClient
    from .py3compat import is_iter

# Generated at 2022-06-26 09:37:26.492623
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    arg0 = lambda : None
    mono_worker_0.submit(arg0)


# Generated at 2022-06-26 09:37:40.784627
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    pass


# Generated at 2022-06-26 09:37:53.003940
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import tqdm

    mono_worker_0 = MonoWorker()

    test_args = ((1,), (2,), (3,), (4,), (5,), (6,), (7,))

    test_kwargs = ({"a" : 1}, {"a" : 2}, {"a" : 3}, {"a" : 4},
                   {"a" : 5}, {"a" : 6}, {"a" : 7})

    def test_function(i, a = None):
        time.sleep(0.2)
        tqdm.write("{} {}".format(i, a))

    for i in test_args:
        mono_worker_0.submit(test_function, *i)


# Generated at 2022-06-26 09:38:02.163032
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    test_case_0()
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(random.randint, -10, 10)

    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(random.random)

    mono_worker_2 = MonoWorker()
    mono_worker_2.submit(random.randrange, -10, 10)

    import time
    import concurrent.futures
    mono_worker_3 = MonoWorker()
    mono_worker_3.submit(time.sleep, 60)

# Generated at 2022-06-26 09:38:14.811978
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import math
    import os.path
    from os import remove
    from os.path import exists
    from shutil import rmtree
    from time import sleep
    from timeit import default_timer
    import tqdm
    import random
    # Initialisation of test variables
    n = 8
    time_to_sleep = 0.005
    short_sleep_time = 0.001
    long_sleep_time = 0.1
    
    # In order to make sure that the test function runs properly
    print("Entering test_MonoWorker_submit")
    # Test function
    def test_function(name):
        sleep(time_to_sleep)
        return name
    
    ### Initialisation
    # Initialisation of MonoWorker Object
    mono_worker_0 = MonoWorker()
    # Initialisation tqdm

# Generated at 2022-06-26 09:38:19.498716
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm import trange
    mw = MonoWorker()
    for i in trange(10):
        mw.submit(sleep, 0.01)

# Generated at 2022-06-26 09:38:27.562059
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import Pool
    from time import sleep
    from tqdm.contrib.concurrency import MonoWorker

    # Functions to test
    def f0(n):
        sleep(2)
        return n

    def f1(n):
        sleep(1)
        return n

    # Correctness tests
    mono_worker_0 = MonoWorker()
    results_0 = []
    for future in mono_worker_0.submit(f0, 1), mono_worker_0.submit(f0, 2), \
            mono_worker_0.submit(f1, 3), mono_worker_0.submit(f0, 4):
        results_0.append(future.result())
    assert results_0 == [1, 4, 4]
    results_1 = []

# Generated at 2022-06-26 09:38:32.861103
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def dummy_func():
        pass
    mono_worker_0.submit(dummy_func)
    expected = 0
    assert(len(mono_worker_0.futures) == expected)

# Generated at 2022-06-26 09:38:35.698216
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    print(mono_worker_0.submit("fibonacci", 30))



# Generated at 2022-06-26 09:38:40.007961
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda x: x, 1)


# Generated at 2022-06-26 09:38:44.915767
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    mono_worker.submit(print, 'Hello World')


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 09:39:18.345725
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from scipy.stats import tst
    from time import sleep
    from concurrent.futures import as_completed

    def tst_arg_0(df, a, b=None, c=None):
        sleep(a)
        return tst.ppf(b, df, loc=c, scale=1)

    mono_worker_0 = MonoWorker()
    res = mono_worker_0.submit(tst_arg_0, df=10, a=1, b=0.5, c=0)
    sleep(10)
    mono_worker_0.submit(tst_arg_0, df=3, a=1, b=0.75, c=0)
    sleep(10)

# Generated at 2022-06-26 09:39:21.918935
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm import tqdm

    def target(i):
        sleep(i * 0.1)
        tqdm.write("{}".format(i))
        return i * 2

    mw = MonoWorker()
    for i in tqdm(range(100)):
        mw.submit(target, i)


if __name__ == '__main__':
    from pytest import main

    main([__file__])

# Generated at 2022-06-26 09:39:25.621082
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    assert mono_worker.submit(lambda: None) is not None
    assert len(mono_worker.futures) == 1
    assert mono_worker.submit(lambda: None) is not None
    assert len(mono_worker.futures) == 2

if __name__ == "__main__":
    # Unit test
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:39:29.548087
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    assert(mono_worker.submit(-1) is None)  # no function

if __name__ == '__main__':
    pass

# Generated at 2022-06-26 09:39:43.986202
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import os

    mono_worker_0 = MonoWorker()

    def sleep_func(duration):
        import time
        time.sleep(duration)
        return duration

    f0 = mono_worker_0.submit(sleep_func, 1)
    f1 = mono_worker_0.submit(sleep_func, 2)
    f2 = mono_worker_0.submit(sleep_func, 3)
    assert f0.result() == 1
    assert f1.result() == 2
    assert f2.result() == 3

    try:
        mono_worker_0.submit(os.system, "echo")
    except Exception as e:
        tqdm_auto.write(str(e))
    else:
        assert False

    f3 = mono_worker_0.submit(os.system, "echo")
   

# Generated at 2022-06-26 09:39:47.205052
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    test_case_0()

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:39:56.952892
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker1 = MonoWorker()
    # waiting = mono_worker1.submit(func, *args, **kwargs)
    waiting = mono_worker1.submit(example_func, 0, 2)
    waiting = mono_worker1.submit(example_func, 1, 2)
    waiting = mono_worker1.submit(example_func, 2, 2)
    waiting = mono_worker1.submit(example_func, 3, 2)
    waiting = mono_worker1.submit(example_func, 4, 2)
    waiting = mono_worker1.submit(example_func, 5, 2)
    print(waiting.result())


# Generated at 2022-06-26 09:40:08.113896
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    with ThreadPoolExecutor(max_workers=1) as pool:
        for i in range(4):
            def func(i):
                import time
                time.sleep(0.5)
                tqdm_auto.write("Finished: {}".format(i))

            mono_worker.submit(func, i)
            result_future = pool.submit(func, i)
            try:
                result_future.result(timeout=0.5)
            except Exception as e:
                tqdm_auto.write(str(e))


if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:40:18.917728
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import current_thread
    from time import sleep, time

    def write_ln(text):
        tqdm_auto.write(str(current_thread()), text)

    mono_worker_0 = MonoWorker()

    #Testing 1st function call and giving it 2 seconds to run
    start = time()
    mono_worker_0.submit(write_ln, "Hello there")
    sleep(2)
    assert (time() - start >= 2)
    assert (time() - start < 4)

    #Testing 2nd function call and giving it 2 seconds to run
    start = time()
    mono_worker_0.submit(write_ln, "Hello theres")
    sleep(2)
    assert (time() - start >= 2)
    assert (time() - start < 4)

    #Testing 3rd function call

# Generated at 2022-06-26 09:40:29.150135
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    class TestValueError(ValueError):
        pass

    def test_func(value):
        if value == 1:
            raise TestValueError('value == 1')
        return value

    mono_worker_0 = MonoWorker()
    future_0 = mono_worker_0.submit(test_func, 0)
    assert future_0.result() == 0
    future_1 = mono_worker_0.submit(test_func, 1)
    assert future_1.result() is None
    future_2 = mono_worker_0.submit(test_func, 2)
    assert future_2.result() == 2
    future_3 = mono_worker_0.submit(test_func, 3)
    assert future_3.result() == 3
    future_4 = mono_worker_0.submit(test_func, 4)

# Generated at 2022-06-26 09:41:31.859829
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    mono_worker_0 = MonoWorker()
    for i in range(4):
        mono_worker_0.submit(sleep, 0.2)



# Generated at 2022-06-26 09:41:39.079010
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(x):
        time.sleep(10)
        return x

    mono_worker_0 = MonoWorker()

    mono_worker_0.submit(f, 1)
    mono_worker_0.submit(f, 2)
    mono_worker_0.submit(f, 3)

    assert mono_worker_0._futures[0].result() == 3

# Generated at 2022-06-26 09:41:46.287917
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    expected_0 = None
    actual_0 = mono_worker_0.submit(str, 1)
    assert actual_0 == expected_0, "Expected: %s, Actual: %s" % (expected_0, actual_0)


# Generated at 2022-06-26 09:41:55.734765
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading

    multi_iter = 5

    mock_sleep_iter = 5
    mock_sleep_time = 0.1
    mock_sleep_func = lambda: sleep(mock_sleep_time, mock_sleep_iter)

    def sleep(sleep_time, iterations):
        for _ in range(iterations):
            time.sleep(sleep_time)

    def get_number_of_threads():
        return len([thread for thread in threading.enumerate()
                    if thread.name != "MainThread"])

    for _ in range(multi_iter):
        print("\nIteration:", _+1)
        mono_worker_0 = MonoWorker()
        num_threads = get_number_of_threads()
        print("Number of threads:", num_threads)
        assert num_

# Generated at 2022-06-26 09:42:00.219303
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(lambda: None)


if __name__ == "__main__":
    pass

# Generated at 2022-06-26 09:42:03.155955
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(test_case_0) == None


if __name__ == '__main__':
    import pytest
    pytest.main(["-vv", __file__])

# Generated at 2022-06-26 09:42:14.451276
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Tests that `MonoWorker.submit` works as expected."""
    import threading
    import time

    def func_0(*args, **kwargs):
        while True:
            time.sleep(1)
            tqdm_auto.write(repr(args) + ' ' + repr(kwargs))
            return 0

    mono_worker_0 = MonoWorker()
    thread_0 = threading.Thread(target=mono_worker_0.submit,
                                args=(func_0, 1, 2))
    thread_0.start()
    time.sleep(0.5)
    thread_1 = threading.Thread(target=mono_worker_0.submit,
                                args=(func_0, 3, 4))
    thread_1.start()
    time.sleep(2.5)

# Generated at 2022-06-26 09:42:19.555204
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    assert mono_worker.submit(lambda: "Hello world")
    assert mono_worker.submit(lambda: "Hello world")

# Generated at 2022-06-26 09:42:24.056875
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func_0(*args, **kwargs):
        """func_1(*args, **kwargs) -> int"""
        return 1

    # Test with assert
    assert mono_worker_0.submit(func_0, *(2, 3), **{'x': 1, 'y': 1}) == 1

# Generated at 2022-06-26 09:42:30.414080
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(*args, **kwargs):
        print(args)
        print(kwargs)
    mono_worker_0 = MonoWorker()
    try:
        mono_worker_0.submit(func, *(1,))
    except:
        pass
