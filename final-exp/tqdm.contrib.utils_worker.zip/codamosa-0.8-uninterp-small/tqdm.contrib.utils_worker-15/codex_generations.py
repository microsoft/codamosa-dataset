

# Generated at 2022-06-26 09:33:18.618217
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    with tqdm_auto.tqdm(total=2, desc="testing MonoWorker.submit") as pbar:
        mono_worker_0 = MonoWorker()
        pbar.update(1)
        mono_worker_0.submit(tqdm_auto.write, "a")
        mono_worker_0.submit(tqdm_auto.write, "b")
        pbar.update(1)

if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()
    print("\nExit code 0 (success)")

# Generated at 2022-06-26 09:33:28.377527
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread, Event
    from unittest import TestCase
    for i in tqdm_auto.trange(100):
        # tqdm_auto.sleep(.001)
        mono_worker = MonoWorker()
        def func(evt, i):
            if evt.isSet():
                return
            evt.wait()
            return i
        evt = Event()
        for i in tqdm_auto.trange(1000):
            t = Thread(target=func, args=(evt, i))
            t.daemon = True
            t.start()
            fut = mono_worker.submit(func, evt, i)
            fut.result()
            if fut.done():
                TestCase().assertTrue(fut.result() == i)
            ev

# Generated at 2022-06-26 09:33:35.075019
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda : 0, ())
    mono_worker_0.submit(lambda : 1, ())

if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:33:37.063136
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    retval_0 = mono_worker_0.submit((lambda x : 2 * x), 2)

# Generated at 2022-06-26 09:33:44.042956
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def check_submit(mono_worker):
        for i in tqdm_auto.trange(10):
            mono_worker.submit(i)
    # MonoWorker.submit() test
    test_MonoWorker_submit.subtests = []
    test_MonoWorker_submit.subtests.append("MonoWorker.submit() test")
    check_submit(MonoWorker())

# Generated at 2022-06-26 09:33:51.332588
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import numpy
    from math import sqrt

    def is_prime(n):
        for i in range(2, int(sqrt(n))):
            if n % i == 0:
                return False
        return True

    def worker_function(n):
        for _ in range(4):
            sleep(0.5)
        return n if is_prime(n) else 0

    # Generate test input
    input_array = numpy.random.randint(100, size=100)

    # Execute test
    worker_pool = MonoWorker()
    output_array = []
    for number in input_array:
        output_array.append(worker_pool.submit(worker_function, number).result())
    print(sum(output_array))

# Generated at 2022-06-26 09:33:58.762935
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from collections import OrderedDict
    from threading import Thread
    from time import sleep

    mw = MonoWorker()

    def worker(i):
        sleep(1)
        return i

    futures = OrderedDict()
    for i in range(10):
        print('Submitting task {}...'.format(i))
        futures[i] = mw.submit(worker, i)

    counter = 0
    while futures:
        sleep(1)
        print('Checking {} tasks'.format(len(futures)))
        for i, future in list(futures.items()):
            if future.done():
                assert future.result() == i
                counter += 1
                del futures[i]

    assert counter == 10



# Generated at 2022-06-26 09:34:06.607790
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(lambda x: 2 * x, 2)
    mono_worker_1.submit(lambda x: 2 * x, 3)
    mono_worker_1.submit(lambda x: 2 * x, 4)
    mono_worker_1.submit(lambda x: 2 * x, 5)
    mono_worker_1.submit(lambda x: 2 * x, 6)


# Generated at 2022-06-26 09:34:14.003622
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    try:
        mono_worker_0.submit()
    except TypeError as e:
        if str(e) != "submit() missing 1 required positional argument: 'func'":
            raise Exception(str(e) + ' line: ' + str(sys.exc_info()[2].tb_lineno))

# Generated at 2022-06-26 09:34:17.937460
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def weird_func(index):
        time.sleep(3)
        return index

    mw = MonoWorker()
    for i in range(4):
        mw.submit(weird_func, i)


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:34:27.150557
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test case for MonoWorker.submit()

    """
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print)
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(print)

if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:34:36.854468
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import inspect
    import sys
    import tqdm.contrib

    args = [1]
    kwargs = {}

    f = tqdm.contrib.MonoWorker.submit
    f_args = inspect.getargspec(f)

    assert f_args.args == ['self', 'func', '*args', '**kwargs']
    assert f_args.varargs == 'args'
    assert f_args.keywords == 'kwargs'
    assert f_args.defaults == (None,)

    tqdm.contrib.MonoWorker.submit(*args, **kwargs)

# Generated at 2022-06-26 09:34:48.649274
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import wait
    mw = MonoWorker()

    def f():
        from test_tqdm import _range
        for _ in _range(5):
            yield
        raise Exception('f')

    fs = [mw.submit(f) for _ in range(6)]
    # Only the last is running, others are cancelled
    assert fs[-1].running()
    assert fs[-2].done()  # will return False because the timeout argument to wait was not used, hence no timeout occurred.
    #assert fs[-2].cancelled()

    wait(fs)
    assert isinstance(fs[-1].exception(), Exception)


if __name__ == '__main__':
    from test_tqdm import _test_mono_worker

    test_case_0()
    test

# Generated at 2022-06-26 09:34:56.434793
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    tqdm_auto.write("Welcome to test case")
    tqdm_auto.write("Enter a number:")
    a = int(input())
    b = int(input("Enter another number:"))
    tqdm_auto.write("The sum is:", mono_worker_0.submit(a+b))
    mono_worker_0.submit(test_case_0(), silent=True)


# Generated at 2022-06-26 09:35:07.403394
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import unittest
    import tqdm.contrib.concurrency as tqdm_concurrency
    class Test_MonoWorker(unittest.TestCase):
        def setUp(self):
            self.mono_worker_0 = tqdm_concurrency.MonoWorker()
        def tearDown(self):
            del self.mono_worker_0
        def test_submit_0(self):
            self.assertEqual(self.mono_worker_0.submit(lambda: 'bar', 'foo', spam='eggs'), None)

    t = Test_MonoWorker()
    t.setUp()
    t.test_submit_0()
    t.tearDown()


# Generated at 2022-06-26 09:35:12.185095
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func(value): return value
    # func(value) return value
    mono_worker_0.submit(func,25)


# Generated at 2022-06-26 09:35:18.702890
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from multiprocessing import Value

    lock = Lock()
    a = Value('i', 0)
    b = Value('i', 0)
    assert a.value == 0
    assert b.value == 0

    def a_():
        with lock:
            a.value = 3
            sleep(1.)

    def b_():
        with lock:
            a.value = 5
            b.value = 7
            sleep(1.)

    mono_worker_0 = MonoWorker()

    mono_worker_0.submit(a_)
    sleep(0.01)
    mono_worker_0.submit(b_)


# Generated at 2022-06-26 09:35:29.101784
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import randint
    from time import sleep

    mono_worker_1 = MonoWorker()

    def random_sleep_func():
        sleep(randint(1,9))

    def blocking_func():
        sleep(10)

    def tqdm_write_func(txt):
        tqdm_auto.write(txt)

    mono_worker_1.submit(tqdm_write_func, "Test 1")
    mono_worker_1.submit(tqdm_write_func, "Test 2")
    mono_worker_1.submit(tqdm_write_func, "Test 3")
    mono_worker_1.submit(random_sleep_func)
    mono_worker_1.submit(random_sleep_func)
    mono_worker_1.submit(random_sleep_func)
    mono

# Generated at 2022-06-26 09:35:37.665506
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from . import MonoWorker
    import concurrent.futures
    from tqdm.auto import tqdm
    from time import sleep

    expected_result = []

    # setup
    mono_worker = MonoWorker()

# Generated at 2022-06-26 09:35:45.151023
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func_0(arg0):
        pass
    mono_worker_0.submit(func_0, mono_worker_0)
#
# If this module is run from the command line, run all its tests
if __name__ == "__main__":
    from pytest import main
    main('mono_worker.py')

# Generated at 2022-06-26 09:36:03.981655
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # 1
    mono_worker_1 = MonoWorker()
    assert mono_worker_1.futures.maxlen == 2
    assert len(mono_worker_1.futures) == 0
    # 2
    def func_1_and_2(arg):
        from time import sleep
        from sys import stdout
        from tqdm.contrib import ascii
        sleep(0.4)
        stdout.write(ascii(arg))
        sleep(0.4)
        return 0
    # 3
    mono_worker_1.submit(func_1_and_2, '1')
    mono_worker_1.submit(func_1_and_2, '2')
    while len(mono_worker_1.futures) == 2:
        pass

# Generated at 2022-06-26 09:36:05.812440
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, 'test')



# Generated at 2022-06-26 09:36:11.841220
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda: 1/0)
    mono_worker_0.submit(lambda: "success")


# Generated at 2022-06-26 09:36:15.011906
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(print, "Thread 0 started") is not None

# Generated at 2022-06-26 09:36:25.186426
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    # unit tests
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(random.randint, 0x100)
    mono_worker_0.submit(random.randint, 0x100)
    mono_worker_0.submit(random.randint, 0x100)
    mono_worker_0.submit(time.sleep, 0.01)
    mono_worker_0.submit(random.randint, 0x100)
    mono_worker_0.submit(random.randint, 0x100)
    mono_worker_0.submit(random.randint, 0x100)
    mono_worker_0.submit(random.randint, 0x100)
    mono_worker_0.submit(random.randint, 0x100)
    mono_worker

# Generated at 2022-06-26 09:36:28.945945
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, "test")


# Generated at 2022-06-26 09:36:38.662955
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def method_0(*args, **kwargs):
        return func(*args, **kwargs)
    obj_0 = MonoWorker()
    func_0 = lambda: None
    func(func_0)


if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()
    try:
        import doctest
        doctest.testmod()
    except ImportError:  # pragma: no cover
        pass

# Generated at 2022-06-26 09:36:39.711300
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    del mono_worker_0

# Generated at 2022-06-26 09:36:50.424239
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    from . import test_MonoWorker_submit

    def _submit(seconds):
        time.sleep(seconds)
        return seconds

    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(func=_submit, seconds=3)
    mono_worker_0.submit(func=_submit, seconds=5)
    mono_worker_0.submit(func=_submit, seconds=7)
    time.sleep(1)
    mono_worker_0.submit(func=_submit, seconds=1)
    time.sleep(0.1)



# Generated at 2022-06-26 09:37:01.825098
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing
    import time
    import sys
    import pytest

    mono_worker_0 = MonoWorker()

    def func(x):
        return x*x

    def func1(x):
        time.sleep(3)
        return x*x

    def test_case_1():
        result = mono_worker_0.submit(func, 5)
        assert result.result() == 25

    def test_case_2():
        result = mono_worker_0.submit(func1, 5)
        assert result.result() == 25

    def test_case_3():
        result = mono_worker_0.submit(func1, 5)
        assert result.result() == 25

    def test_case_4():
        result = mono_worker_0.submit(func, 5)
        assert result

# Generated at 2022-06-26 09:37:21.393948
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    u = MonoWorker()
    t1 = time.time()
    waiting_task = u.submit(lambda: time.time(), t1)
    time.sleep(1)
    tqdm_auto.write('waiting task is done: ', waiting_task.done())
    tqdm_auto.write('mono_worker result: ', waiting_task.result())
    waiting_task = u.submit(lambda: time.time(), t1)
    tqdm_auto.write('waiting task is done: ', waiting_task.done())
    t2 = time.time()
    waiting_task = u.submit(lambda: time.time(), t2)
    tqdm_auto.write('waiting task is done: ', waiting_task.done())

# Generated at 2022-06-26 09:37:29.057554
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(__import__, "os")
    mono_worker_0.submit(__import__, "sys")
    mono_worker_0.submit(__import__, "abc")
    mono_worker_0.submit(__import__, "ppp")
    mono_worker_0.submit(__import__, "qqq")

# Generated at 2022-06-26 09:37:35.657005
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import _is_asyncio_coro
    from os import urandom
    from time import sleep
    from multiprocessing import Queue
    from threading import Thread
    import asyncio
    import inspect

    q = Queue()
    n = urandom(2)
    
    def f(x):
        q.put(x)

    def t0(self):
        f_is_coro = _is_asyncio_coro(f)
        assert(not f_is_coro)
        if f_is_coro:
            loop = asyncio.get_event_loop()
            loop.create_task(f)
            sleep(0.1)
        else:
            f(n)
        while q.empty():
            sleep(0.1)

# Generated at 2022-06-26 09:37:43.927530
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
  """
  Test that MonoWorker.submit works as intended
  """
  import time
  import math
  def check_submit(func, *args):
    """
    Function to check if submission works as intended.
    """
    mono_worker = MonoWorker()
    mono_worker.submit(func, *args)
    for i in range(2*tqdm_auto.UNIT_SCALE):
      time.sleep(1/tqdm_auto.UNIT_SCALE)
    mono_worker.submit(func, *args)
    for i in range(5*tqdm_auto.UNIT_SCALE):
      time.sleep(1/tqdm_auto.UNIT_SCALE)
    mono_worker.submit(func, *args)

# Generated at 2022-06-26 09:37:47.846926
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(func=lambda x: x, *(1,))

# Generated at 2022-06-26 09:37:50.307312
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    tqdm_auto.write('Unit testing: test case 0 of 1')
    test_case_0()

# Generated at 2022-06-26 09:37:54.998138
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import unittest
    import threading
    class test_case(unittest.TestCase):
        def setUp(self):
            self.mono_worker = MonoWorker()
            self.run_counter = [0]

        def tearDown(self):
            self.mono_worker.pool.shutdown()

        def count_runs(self):
            """Just a function that increments a counter"""
            self.run_counter[0] += 1

        def count_runs_with_delay(self):
            """
            Just a function that increments a counter, but waits some time
            before doing so
            """
            import time
            time.sleep(0.5)
            self.run_counter[0] += 1

        def test_basic_use(self):
            """Tests that a function is run only once"""


# Generated at 2022-06-26 09:37:59.152231
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit()

    mono_worker_0 = MonoWorker()
    mono_worker_0.submit()


# Generated at 2022-06-26 09:38:05.024573
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    tqdm_auto.write("Testing method submit of class MonoWorker")
    mono_worker_0 = MonoWorker()

    def worker_a():
        tqdm_auto.write("worker_a")
        return "worker_a"

    def worker_0():
        tqdm_auto.write("worker_0")
        return "worker_0"

    def worker_b():
        tqdm_auto.write("worker_b")
        return "worker_b"

    def worker_1():
        tqdm_auto.write("worker_1")
        return "worker_1"

    def worker_2():
        tqdm_auto.write("worker_2")
        return "worker_2"

    def worker_3():
        tqdm_auto.write("worker_3")
        return

# Generated at 2022-06-26 09:38:10.150927
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(tqdm_auto, [1]*10000)
    mono_worker_0.submit(tqdm_auto, [1]*10000)

# Generated at 2022-06-26 09:38:18.945669
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit()

# Generated at 2022-06-26 09:38:27.493497
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from time import time

    mono_worker_0 = MonoWorker()

    def wait_3(x):
        sleep(3)
        return x

    time_start = time()
    mono_worker_0.submit(wait_3, 1)
    mono_worker_0.submit(wait_3, 2)
    mono_worker_0.submit(wait_3, 3)
    mono_worker_0.submit(wait_3, 4)
    mono_worker_0.submit(wait_3, 5)
    mono_worker_0.submit(wait_3, 6)
    # x = mono_worker_0.futures.pop()
    # assert x.result() == 6
    # assert (time() - time_start) >= 6



# Generated at 2022-06-26 09:38:36.582800
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent
    import sys
    import time

    def wait_print(message, delay=0.1):
        time.sleep(delay)
        tqdm_auto.write(message)

    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(wait_print, message="1", delay=0.5)
    mono_worker_0.submit(wait_print, message="2", delay=1)
    try:
        mono_worker_0.submit(wait_print, message="3", delay=1)
        mono_worker_0.submit(wait_print, message="4", delay=1)
    except concurrent.futures._base.CancelledError:
        print("CancelledError")

# Generated at 2022-06-26 09:38:39.161201
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()


# Generated at 2022-06-26 09:38:48.801599
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed
    mono_worker_0 = MonoWorker()
    future_0 = mono_worker_0.submit(time.sleep, 10)
    assert future_0.running()
    future_1 = mono_worker_0.submit(time.sleep, 10)
    assert future_1.running()
    assert future_0.cancel()
    assert future_1.running()
    future_2 = mono_worker_0.submit(time.sleep, 10)
    assert future_2.running()
    assert future_1.cancel()
    assert future_2.running()
    future_2.result()
    assert future_2.done()
    mono_worker_1 = MonoWorker()

# Generated at 2022-06-26 09:38:59.058179
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    from concurrent.futures import Future
    future_0 = mono_worker_0.submit(lambda : None)
    assert isinstance(future_0, Future)
    assert mono_worker_0.futures == deque([future_0], 2)
    future_1 = mono_worker_0.submit(lambda : None)
    assert future_0.done()
    assert mono_worker_0.futures == deque([future_1], 2)
    future_2 = mono_worker_0.submit(lambda : None)
    assert future_1.done()
    assert mono_worker_0.futures == deque([future_2], 2)
    from concurrent.futures import CancelledError

# Generated at 2022-06-26 09:39:03.063455
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit('test_case_0')

# Generated at 2022-06-26 09:39:09.181594
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def myfunc_0(func, *args, **kwargs):
        return func(*args, **kwargs)

    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(myfunc_0, myfunc_0, lambda: MonoWorker().submit(myfunc_0, MonoWorker().submit, myfunc_0, *(), **{}), *(), **{})
    mono_worker_0.submit(MonoWorker, *(), **{})

# Generated at 2022-06-26 09:39:19.789444
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    # Trying with a function with 0 args
    mono_worker_0.submit(test_case_0)
    # Now with a function with args and kwargs
    mono_worker_0.submit(test_case_0, {}, {'d': 0})
    mono_worker_0.pool.shutdown()

if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:39:25.361018
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker = MonoWorker()
    future = mono_worker.submit(time.sleep, 0.1)


if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:39:42.053803
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    new_task = mono_worker_0.submit(test_case_0)
    new_task.result()

test_MonoWorker_submit()

# Generated at 2022-06-26 09:39:45.142799
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # test case #0
    mono_worker_0 = MonoWorker()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:39:49.137149
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test if the case where not 
    # executing a method of a class does not raise an exception
    try:
        test_case_0()
    except Exception as e:
        print("Failed, ", e)
        assert(0)
    else:
        print("Successful")
        assert(1)


# Generated at 2022-06-26 09:39:57.063323
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import tqdm
    class A():
        def f(self,x):
            return x
    a = A()

    b = A()
    c = A()

    mono_worker_0 = MonoWorker()

    def func_0(x):
        print(x)
        time.sleep(4)

    for i in tqdm.tqdm(range(5)):
        mono_worker_0.submit(func_0,i)
        time.sleep(1)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 09:40:08.857474
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import random
    from time import sleep
    from os import environ
    from unittest import TestCase

    def test_func(x):
        '''
        do something
        '''
        for _ in range(10):
            sleep(random.randint(1, 3))
        return x

    if environ.get('TEST_CASES'):
        tc = int(environ['TEST_CASES'])
    else:
        tc = random.randint(1, 3)
    sys.stdout.write('\nTest case {}/{} for method submit of class MonoWorker ...'.format(tc, 3))

# Generated at 2022-06-26 09:40:12.244668
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    True if `worker.submit()` runs without errors.
    """
    worker = MonoWorker()
    worker.submit(lambda: 1)

# Generated at 2022-06-26 09:40:15.272565
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(test_case_0) == False


# Generated at 2022-06-26 09:40:20.807272
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    lock = threading.Lock()
    num_waiting = 0
    num_running = 0
    num_executing = 0
    num_done = 0

    def _execute(task_num):
        nonlocal num_waiting, num_running, num_executing
        lock.acquire()
        try:
            assert num_waiting >= 0 and num_running >= 0 and num_executing >= 0
            if num_running == 0:
                num_running += 1
                num_waiting -= 1
            assert num_running == 1
            if num_waiting == 1:
                assert num_executing == 0
                num_executing += 1
                num_running -= 1
                num_waiting -= 1
            assert num_executing == 1
        finally:
            lock.release

# Generated at 2022-06-26 09:40:22.853365
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker.MonoWorker()


# Generated at 2022-06-26 09:40:25.397741
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit()


# Generated at 2022-06-26 09:40:59.246663
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    try:
        mono_worker_0 = MonoWorker()
        try:
            mono_worker_0.submit(pow, 2, 4)
        except Exception as e:
            return e
    except Exception as e:
        return e

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:41:10.233202
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, random
    # 1 worker, 1 pending
    tqdm_auto.write("Test 1 worker, 1 pending")
    tqdm_auto.write("=================================")
    mono_worker_1 = MonoWorker()
    futures = []
    for i in tqdm_auto.tnrange(3, desc='Test 1 worker, 1 pending'):
        print("submit task", i)
        futures.append(mono_worker_1.submit(time.sleep, random.randint(2, 10)))
    for i in tqdm_auto.trange(3, desc='Test 1 worker, 1 pending'):
        print("wait for task", i)
        futures[i].result()


# Generated at 2022-06-26 09:41:17.982128
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    def func(arg):
        return arg
    assert mono_worker_1.submit(func, 1) == None
    assert mono_worker_1.submit(func, 1) == None

if __name__ == "__main__":
    #test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:41:29.432112
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def get_abc(a, b, c):
        return a, b, c
    mono_worker_1 = MonoWorker()
    future_0 = mono_worker_1.submit(get_abc, 1, 2, 3)
    assert future_0.result() == (1, 2, 3)
    future_1 = mono_worker_1.submit(get_abc, 2, 3, 4)
    assert future_1.result() == (2, 3, 4)
    future_2 = mono_worker_1.submit(get_abc, 3, 4, 5)
    assert future_2.result() == (3, 4, 5)
    assert future_0.cancel()   # should be deferred
    future_3 = mono_worker_1.submit(get_abc, 4, 5, 6)
    assert future_

# Generated at 2022-06-26 09:41:35.053303
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(str)


if __name__ == '__main__':

    test_case_0()
    #test_MonoWorker_submit()

# Generated at 2022-06-26 09:41:43.062274
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Initialize class
    mono_worker_0 = MonoWorker()
    """Testing submit method"""
    # Test case 0

    # Test case 1
    mono_worker_1 = MonoWorker()
    # Test case 2
    mono_worker_2 = MonoWorker()
    # Test case 3
    mono_worker_3 = MonoWorker()
    assert str(type(mono_worker_3)) == "<class 'tqdm.contrib.concurrency.MonoWorker'>"
    # Test case 4
    mono_worker_4 = MonoWorker()
    assert isinstance(mono_worker_4, object)
    # Test case 5
    mono_worker_5 = MonoWorker()
    # Test case 6
    mono_worker_6 = MonoWorker()
    # Test case 7
    mono_worker_

# Generated at 2022-06-26 09:41:46.419385
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    func_0 = lambda: True
    mono_worker_0.submit(func_0)

# Generated at 2022-06-26 09:41:55.736068
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    # test 1
    fibs = [1, 1, 2, 3, 5, 8, 13, 21, 34]
    call_count = [0]

    def fib_up_to_count(n, count_to):
        while call_count[0] < count_to and n < 1e9:
            n += fibs[len(fibs) - 1] + fibs[len(fibs) - 2]
            fibs.append(n)
            call_count[0] += 1
        return n


# Generated at 2022-06-26 09:41:58.754456
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    res = mono_worker.submit(1)
    assert res == None

# Generated at 2022-06-26 09:42:03.615629
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    global tqdm_0
    global mono_worker_0
    mono_worker_0 = MonoWorker()
    res_tqdm_0 = tqdm_0.write((lambda x:mono_worker_0.submit((lambda y:tqdm_0.write(x)),x)), (1, 2, 3, 4, 5))
    return res_tqdm_0