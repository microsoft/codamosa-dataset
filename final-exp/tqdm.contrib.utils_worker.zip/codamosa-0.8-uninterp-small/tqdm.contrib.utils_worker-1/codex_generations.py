

# Generated at 2022-06-26 09:33:16.064537
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    try:
        mono_worker_1.submit()
    except Exception as e:
        pass
    else:
        raise Exception("Expected Exception")

# Generated at 2022-06-26 09:33:27.492502
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import math

    # initialize monkey-patching
    tqdm_auto.write = print

    mono_worker = MonoWorker()

    # random variables
    random.seed(0)
    delay_time = 1
    f1 = lambda: time.sleep(delay_time)
    f2 = lambda: math.sin(delay_time)

    # f1 cannot be replaced by f2
    f0 = mono_worker.submit(f1)
    time.sleep(0.1)
    mono_worker.submit(f2)
    f0.result()
    f1_result = mono_worker.futures[0].result()
    assert f1_result is None

    # sleep 1 second
    time.sleep(delay_time)

    # f1 can be replaced by f2


# Generated at 2022-06-26 09:33:39.194156
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test case 0
    mono_worker_0 = MonoWorker()
    futures_0 = mono_worker_0.futures
    assert futures_0.maxlen == 2
    assert len(futures_0) == 0
    assert futures_0 == deque([])
    assert futures_0 != []
    assert not futures_0
    assert futures_0 != deque([], 1)
    assert futures_0 != deque([], 0)
    assert futures_0 is not deque([])
    # Test case 1
    futures_1 = futures_0
    assert futures_1.maxlen == 2
    assert len(futures_1) == 0
    assert futures_1 == deque([])
    assert futures_1 != []
    assert not futures_1
    assert futures_1 != deque([], 1)


# Generated at 2022-06-26 09:33:41.589031
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit((lambda : 1))


# Generated at 2022-06-26 09:33:49.186735
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import inspect
    from concurrent.futures import Future
    from multiprocessing import Event

    class Mock_Future():
        def __init__(self,func,*args,**kwargs):
            self.args = (func,*args)
            self.kwargs = {**kwargs}
            self._myevent = Event()
        def done(self):
            return self._myevent.is_set()
        def cancel(self):
            self._myevent.set()
        def __str__(self):
            return str(self.args)+str(self.kwargs)+str(self._myevent)

    mono_worker_0 = MonoWorker()
    func = mono_worker_0.submit
    mono_worker_0.pool.submit = Mock_Future


    # Test case 0:
    # (1)

# Generated at 2022-06-26 09:33:55.908702
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    test_MonoWorker_submit:
    test method MonoWorker.submit
    """
    # Create instance of class MonoWorker
    mono_worker_0 = MonoWorker()
    # first submit
    mono_worker_0.submit(foo, 'hello')
    # second submit
    mono_worker_0.submit(foo, 'world')


# Generated at 2022-06-26 09:34:08.046712
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

    def _worker_0():
        return 0
    mono_worker_0.submit(_worker_0)

    def _worker_1():
        return 1
    mono_worker_0.submit(_worker_1)

    def _worker_2():
        return 2
    mono_worker_0.submit(_worker_2)

    def _worker_3():
        return 3
    mono_worker_0.submit(_worker_3)

    def _worker_4():
        return 4
    mono_worker_0.submit(_worker_4)

    def _worker_5():
        return 5
    mono_worker_0.submit(_worker_5)

    def _worker_6():
        return 6
    mono_worker_0.submit(_worker_6)


# Generated at 2022-06-26 09:34:11.968649
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    foo = MonoWorker()
    def func(a, b=2):
        return (a, b)
    foo.submit(func, 1, b=1)


# Generated at 2022-06-26 09:34:16.005532
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(1, 2, 3) == None
    assert mono_worker_0.submit(3, 2, 3) == None


# Generated at 2022-06-26 09:34:18.390410
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Case 0
    test_case_0()


# Generated at 2022-06-26 09:34:27.735690
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys

    class FakeFile(object):
        def __init__(self):
            self.stringio = StringIO()
        def write(self, string):
            self.stringio.write(string)
        def getvalue(self):
            return self.stringio.getvalue()

    sys.stdout = FakeFile()
    test_case_0()
    assert sys.stdout.getvalue() == ""



# Generated at 2022-06-26 09:34:32.314667
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    def f(x):
        """Dummy function."""
        return x + 1

    assert mono_worker.submit(f, 1).result() == 2
# End unit test

# Generated at 2022-06-26 09:34:38.083666
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test case 0:
    mono_worker_0 = MonoWorker()
    func_0 = lambda: "Hello"
    result_0 = mono_worker_0.submit(func_0)
    assert (result_0.done() == True)
    assert (result_0.result() == "Hello")
    result_1 = mono_worker_0.submit(func_0)
    assert (result_1.done() == True)
    assert (result_1.result() == "Hello")

# Generated at 2022-06-26 09:34:45.223972
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # instantiate MonoWorker object
    mono_worker = MonoWorker()
    # test 1: non-existent function
    try:
        mono_worker.submit(func = "a_fake_function")
    except Exception as e:
        assert str(e) == 'func is not callable'
    # test 2:
    from time import sleep
    from random import randint
    from threading import current_thread
    from unittest import mock
    def fake_func(arg):
        return randint(1, arg)
    test_args = [0, 1, 100]
    for arg in test_args:
        # create a mock function
        func = mock.MagicMock(spec_set = fake_func)
        # submit func to mono_worker

# Generated at 2022-06-26 09:34:49.434758
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    mono_worker_0 = MonoWorker()
    sub_lst = []
    for i in range(10):
        time.sleep(random.randint(0, 3))
        mono_worker_0.submit(time.sleep, random.randint(1, 5))
        sub_lst.append(mono_worker_0.futures[-1])


# Generated at 2022-06-26 09:34:56.803175
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    def test_func(x):
        return x+1

    mono_workers = MonoWorker()

    input_args = [0, 1, 2, 3, 4, 5]
    outputs = []

    for arg in input_args:
        outputs.append(mono_workers.submit(test_func, arg))

    print(outputs)

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:03.212651
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    assert mono_worker_1.submit(2, [2]) is None   # default return None
    mono_worker_1.futures.appendleft(3)
    assert mono_worker_1.submit(2, []) is None


# Generated at 2022-06-26 09:35:05.307619
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, 'hello', 'world!')

# Generated at 2022-06-26 09:35:14.755259
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Arrange
    mono_worker = MonoWorker()
    func = lambda a, b, c=None: a + b + c
    # Act
    mono_worker.submit(func, 1, 2)
    mono_worker.submit(func, 1, 2)
    mono_worker.submit(func, 1, 2)
    mono_worker.submit(func, 1, 2)
    # Assert
    assert len(mono_worker.futures) == 2

# Generated at 2022-06-26 09:35:17.598925
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # create an instance of MonoWorker
    mono_worker_0 = MonoWorker()

    # create a dummy function
    def func_0(a: int, b: int, c: int=5):
        return a + b + c

    # test if the MonoWorker is working
    mono_worker_0.submit(func_0, 5, 6)
    return

# Generated at 2022-06-26 09:35:37.989155
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .tqdm_pandas import tqdm
    # Process 1
    for n in tqdm(range(3), desc='Process 1'):
        print('Process 1: sleep', n)
        sleep(1)
    # Process 2
    for n in tqdm(range(5), desc='Process 2'):
        mono_worker_0.submit(print, 'Process 2: sleep', n)
        sleep(1)
    # Process 3
    for n in tqdm(range(3), desc='Process 3'):
        mono_worker_0.submit(print, 'Process 3: sleep', n)
        sleep(1)
    # Process 4

# Generated at 2022-06-26 09:35:46.702682
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

    mono_worker_0.submit(print, 'hi')

    mono_worker_0.submit(print, 'bye')

    mono_worker_0.submit(print, 'bye')

    mono_worker_0.submit(print, 'bye')

    mono_worker_0.submit(print, 'bye')


if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:50.924180
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    test_MonoWorker_submit
    """
    mono_worker_0 = MonoWorker()
    MonoWorker.submit(mono_worker_0, func=test_case_0)



# Generated at 2022-06-26 09:35:59.371110
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from nose import SkipTest
    from tqdm.contrib.concurrency import MonoWorker

    try:
        from pytest import skip
    except ImportError:
        from nose.plugins.skip import SkipTest as skip

    try:
        from multiprocessing import cpu_count
    except ImportError:
        cpu_count = lambda: 1

    def f(x):
        time.sleep(0.01)
        return x + 1

    def test_submit(n=10):
        mono_worker_0 = MonoWorker()
        r = [mono_worker_0.submit(f, x) for x in range(n)]
        assert all(x.result() == x.result() for x in r)
        assert all(x.result() == x.result() for x in r)

    # Test

# Generated at 2022-06-26 09:36:00.963482
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    a = test_case_0()

# Generated at 2022-06-26 09:36:11.176448
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    # Tests for when tasks are delayed
    delay_waiting_task = False

    # Tests for when tasks are not delayed
    delay_waiting_task = True

    mono_worker = MonoWorker()
    mono_worker.pool.submit = lambda func, *args, **kwargs: func(*args, **kwargs)
    mono_worker.futures = deque([], 2)
    action = [0, 1]
    order = []

    def run(index, delay_time=0, wait=False):
        order.append(index)
        if wait:
            while action:
                continue
        if delay_time:
            import time
            time.sleep(delay_time)
        return index

    mono_worker.submit(run, 0)
    mono_worker.submit(run, 1, delay_time=1)

# Generated at 2022-06-26 09:36:20.512450
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from collections import deque

    # Arrange
    mono_worker_1 = MonoWorker()
    expected_result_0 = [True, True, True, True, True, True, True, True, True, True]
    expected_result_1 = [1, 1, 1, 1, 1, 1, 1, 1]

    # Act
    result_0 = deque([], 10)
    mono_worker_1.submit(lambda: result_0.append(True))
    mono_worker_1.submit(lambda: result_0.append(True))
    mono_worker_1.submit(lambda: result_0.append(True))
    mono_worker_1.submit(lambda: result_0.append(True))
    mono_worker_1.submit(lambda: result_0.append(True))
   

# Generated at 2022-06-26 09:36:23.591867
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit()

# Generated at 2022-06-26 09:36:29.555729
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

    def func_0(arg_0):
        return arg_0

    future_0 = mono_worker_0.submit(func_0, arg_0)
    arg_0 = future_0.result(timeout=0.001)
    assert arg_0 is not None

# Generated at 2022-06-26 09:36:41.242080
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import os

    def update_test_file(test_file_name):
        with open(test_file_name, "a") as test_file:
            print("{}".format(os.getpid()), file=test_file)

    def test_submit():
        import random
        import os
        from time import sleep

        test_file_name = "test_MonoWorker_submit_file"
        mono_worker_0 = MonoWorker()
        mono_worker_0.submit(update_test_file, test_file_name)
        mono_worker_0.submit(update_test_file, test_file_name)
        sleep(random.random())
        mono_worker_0.submit(update_test_file, test_file_name)

# Generated at 2022-06-26 09:36:59.506602
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test that the first task submitted does not replace the running task when
    the running task is not done
    """
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(1, 2)
    len(mono_worker_0.futures) == 1


# Generated at 2022-06-26 09:37:08.799223
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random

    def work(i):
        import time
        time.sleep(random.randint(1,3))

    def main():
        import time
        mono_worker_0 = MonoWorker()
        for i in range(10):
            print("submit i=", i)
            mono_worker_0.submit(work, i)
            time.sleep(1)
        print("mw done")

    main()

# Generated at 2022-06-26 09:37:12.798352
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    global mono_worker_0
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit('test', 0)
    mono_worker_0.submit('test', 1)
    mono_worker_0.submit('test', 2)
    mono_worker_0.submit('test', 3)

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:37:15.566134
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(
        lambda : print("ok"))

# Generated at 2022-06-26 09:37:16.912185
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    MonoWorker.submit([])

# Generated at 2022-06-26 09:37:20.200256
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def worker():
        import time
        time.sleep(10)

    mono_worker = MonoWorker()
    waiting = mono_worker.submit(worker)
    assert waiting.done()


# Generated at 2022-06-26 09:37:26.236701
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(a, b):
        raise Exception('fail')
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(func, 1, 2)

if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:37:30.777817
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, 'new')
    mono_worker_0.submit(print, 'new again')
    mono_worker_0.submit(print, 'replace the second')
    mono_worker_0.submit(print, 'replace the second again')
    
    
    

# Generated at 2022-06-26 09:37:38.244090
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda : (1 + 0))
    mono_worker_0.submit(lambda : (1 + 0))
    mono_worker_0.submit(lambda : (1 + 0))

if __name__ == '__main__':
    #test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:37:41.449528
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    try:
        mono_worker_0.submit()
    except TypeError as err:
        tqdm_auto.write(str(err))

# Generated at 2022-06-26 09:38:04.432053
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    from time import sleep
    from threading import Thread
    import random
    e = Event()
    e.set() # This event should already be set
    def wait_random(max_time):
        sleep(random.random() * max_time)
        e.set()

    max_time = 0.5
    worker = MonoWorker()
    random.seed()
    e.clear()
    worker.submit(wait_random, max_time)
    assert not e.is_set()
    sleep(max_time * 0.9)
    assert not e.is_set()
    sleep(max_time * 0.2)
    assert e.is_set()

    # Test when starting a new thread before the previous thread has finished.
    e.clear()

# Generated at 2022-06-26 09:38:07.194718
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    mono_worker.submit("func", "args", "kwargs")

# Generated at 2022-06-26 09:38:12.826924
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, 4, 1, 2, 3)
    mono_worker_0.submit(print, 4, 1, 2, 3)

if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:38:13.628485
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    pass



# Generated at 2022-06-26 09:38:25.566255
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(i):
        from time import sleep
        sleep(0.2)
        return i**2
    mono_worker_0 = MonoWorker()

    futures = []
    for i in tqdm_auto.tqdm(range(5), desc='mono_worker_0.submit'):
        futures.append(mono_worker_0.submit(f, i))
    print([f.result() for f in futures])
    # [0, 1, 4, 4, 4]


if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:38:32.862101
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(lambda : print("hi"))
    mono_worker_1.submit(lambda : print("hi2"))
    mono_worker_1.submit(lambda : print("hi3"))
    mono_worker_1.submit(lambda : print("hi4"))


# Generated at 2022-06-26 09:38:33.815032
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    return None


# Generated at 2022-06-26 09:38:39.340725
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    mono_worker_0 = MonoWorker()

    def foo(x):
        return x + x

    try:
        mono_worker_0.submit(foo, 1)
    except Exception as e:
        tqdm_auto.write(str(e))
    else:
        time.sleep(2)
        mono_worker_0.submit(foo, 2)
        time.sleep(2)
        mono_worker_0.submit(foo, 3)
        time.sleep(2)
        mono_worker_0.submit(foo, 4)

# Generated at 2022-06-26 09:38:40.757849
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    mono_worker_0 = MonoWorker()
    def func():
            time.sleep(random.random())
    mono_worker_0.submit(func)

# Generated at 2022-06-26 09:38:47.764438
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker_0 = MonoWorker()
    assert all(
        [not x.done() for x in list(mono_worker_0.futures)])
    mono_worker_0.submit(time.sleep, 1)
    assert all([not x.done() for x in list(mono_worker_0.futures)])
    mono_worker_0.submit(time.sleep, 1)
    assert all([x.done() for x in list(mono_worker_0.futures)])

# Generated at 2022-06-26 09:39:16.190249
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit((lambda x: x),1)
    mono_worker_0.submit((lambda x: x),2)
    mono_worker_0.submit((lambda x: x),3)
    mono_worker_0.submit((lambda x: x),4)
    mono_worker_0.submit((lambda x: x),5)
    mono_worker_0.submit((lambda x: x),6)
    mono_worker_0.submit((lambda x: x),7)
    mono_worker_0.submit((lambda x: x),8)
    mono_worker_0.submit((lambda x: x),9)
    mono_worker_0.submit((lambda x: x),10)

# Generated at 2022-06-26 09:39:20.349366
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    assert mono_worker.submit(sleep_fn, 0.1) is not None
    assert mono_worker.submit(sleep_fn, 0.1) is not None  # Does not wait


# Generated at 2022-06-26 09:39:31.433715
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import string

    def task(x : str) -> str:
        import random
        import string

        #print("--" + x + "--")

        return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))


    for i in range(3):
        mono_worker_0 = MonoWorker()

        for j in range(5):
            x = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
            mono_worker_0.submit(task, x)



# Generated at 2022-06-26 09:39:44.078037
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    import multiprocessing
    import numpy as np
    import pandas as pd
    import pandas_datareader as pdr
    from sklearn.linear_model import LinearRegression
    from sklearn.preprocessing import StandardScaler
    import datetime
    import matplotlib.pyplot as plt

    tickers = ['^GSPC', '^IXIC', '^NYA', '^BUK100P', '^N225', '^HSI', '^STI',
               '^JKSE', '^TWII']
    print('MonoWorker: len', len(tickers))


# Generated at 2022-06-26 09:39:53.411135
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test submit method
    """
    import multiprocessing as mp
    import time

    def run_0():
        """
        args:
            tqdm_auto: tqdm_auto object
        """
        tqdm_auto.write("hello")
        time.sleep(0.0001)
        tqdm_auto.write("world")

    def run_1():
        """
        args:
            tqdm_auto: tqdm_auto object
        """
        tqdm_auto.write("world")

    def test_run_1():
        """
        args:
            tqdm_auto: tqdm_auto object
        """
        mono_worker_0 = MonoWorker()
        mono_worker_0.submit(run_0)

# Generated at 2022-06-26 09:39:56.542935
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    result = mono_worker_0.submit()
    assert result is None,\
        'Should return None, but returned: {}'.format(result)

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:40:08.778267
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    test the method submit of class MonoWorker
    """
    def f():
        return 0
    
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(f, ())
    mono_worker_0.submit(f, ())
    mono_worker_0.submit(f, ())
    mono_worker_0.submit(f, ())
    #
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(f, ())
    mono_worker_1.submit(f, ())
    mono_worker_1.submit(f, ())
    mono_worker_1.submit(f, ())
    #
    mono_worker_2 = MonoWorker()
    mono_worker_2.submit(f, ())
    mono_worker_2.submit(f, ())

# Generated at 2022-06-26 09:40:19.014626
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # test case 0
    mono_worker = MonoWorker()
    result = mono_worker.submit(lambda x: x+1, 5)
    assert result.result() == 6
    result = mono_worker.submit(lambda x: x+1, 5)
    assert result.result() == 6
    mono_worker.submit(lambda x: x+1, 5)
    assert result.result() == 6
    result = mono_worker.submit(lambda x: x+1, 5)
    assert result.result() == 6
    result = mono_worker.submit(lambda x: x+1, 5)
    assert result.result() == 6
    result = mono_worker.submit(lambda x: x+1, 5)
    assert result.result() == 6


# Generated at 2022-06-26 09:40:26.542924
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

    # Test: submit func, *args, **kwargs
    def lambda_func_0(x):
        return x
    mono_worker_0.submit(lambda_func_0, 1)

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:40:37.456752
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # TODO: Test different types of parameters
    # Test ERROR case of function `submit`
    try:
        mono_worker_0 = MonoWorker()
        mono_worker_0.submit(print, 'hello world')
    except Exception as e:
        print(repr(e))
    # Test ERROR case of function `submit`
    try:
        mono_worker_0 = MonoWorker()
        mono_worker_0.submit(print, 'hello world')
    except Exception as e:
        print(repr(e))
# End of Unit test for method submit of class MonoWorker


# Generated at 2022-06-26 09:41:28.483695
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(x):
        import time
        time.sleep(1)
        return x
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(func, 1)


# Generated at 2022-06-26 09:41:37.863821
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

    mono_worker_0.submit(lambda: 1)
    if len(mono_worker_0.futures) == 1:
        return 1
    else:
        return 0

if __name__ == "__main__":
    print("testing {0}...".format(__file__))
    print("testing submit()... {0}".format(test_MonoWorker_submit()))

# Generated at 2022-06-26 09:41:39.792336
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    print("Unit test for method submit starts")
    print("Unit test for method submit ends")


# Generated at 2022-06-26 09:41:44.675552
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker_1 = MonoWorker()
    assert(mono_worker_1.submit(time.sleep,0.0) is not None)

# Generated at 2022-06-26 09:41:52.831167
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import ThreadPoolExecutor
    from multiprocessing import cpu_count
    from .test_wrap_cls import test_wrap_cls

    n = cpu_count()

    mono_worker_0 = MonoWorker()
    assert isinstance(mono_worker_0, MonoWorker)
    assert len(mono_worker_0.futures) == 0

    def f_0(*args, **kwargs):
        return args, kwargs

    def f_1(*args, **kwargs):
        return args, kwargs

    def err_0(*args, **kwargs):
        raise Exception('err_0')

    # Submit first task
    assert len(mono_worker_0.futures) == 0

# Generated at 2022-06-26 09:41:57.701152
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    tqdm_auto.write(str(test_case_0()))
    return None

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:42:04.309402
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    '''
    Test for `submit`
    '''
    mono_worker_1 = MonoWorker()
    def func0():
        return
    assert mono_worker_1.submit(func0)
    def func1():
        return
    assert mono_worker_1.submit(func1)
    def func2(a):
        return
    assert mono_worker_1.submit(func2, 2)
    def func3(a,b):
        return
    assert mono_worker_1.submit(func3, 2, b=1)

# Generated at 2022-06-26 09:42:11.140261
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(test_case_0)

try:
    from unittest import TestCase
    from unittest import main as testmain
except ImportError:
    from unittest2 import TestCase
    from unittest2 import main as testmain



# Generated at 2022-06-26 09:42:16.845595
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

    # Original method: mono_worker_0.submit(worker_func, *args, **kwargs)
    # TODO: Currently, we are unable to automatically create tests for methods
    # with keyword arguments. If you know of a way to do so, please contribute.
    # assert False


if __name__ == "__main__":
    import doctest
    from .tester import run_tests

    run_tests(doctest)

# Generated at 2022-06-26 09:42:25.721447
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from qgis.core import QgsMapLayerRegistry
    from qgis.core import QgsCoordinateReferenceSystem
    from qgis.core import QgsCoordinateTransform
    from qgis.core import QgsMapLayer
    from qgis.core import QgsGeometry
    from qgis.core import QgsRectangle
    from qgis.core import QgsVectorLayer
    from qgis.core import QgsVectorFileWriter
    from qgis.core import QgsFeature
    from qgis.core import QgsField
    from PyQt4.QtGui import QColor

    #prepare a canvas
    canvas = iface.mapCanvas()
    #define the projection: replace with a EPSG code or use None for default
    EPSG_code = 28992