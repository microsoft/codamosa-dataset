

# Generated at 2022-06-26 09:33:05.914522
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    val_0 = mono_worker_0.submit(test_case_0)

# Generated at 2022-06-26 09:33:08.062077
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func(*args, **kwargs):
        return 0
    mono_worker_0.submit(func)

# Generated at 2022-06-26 09:33:12.801661
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    result_obj = mono_worker_0.submit(print, "Test MonoWorker")
    assert(result_obj != None)

# Generated at 2022-06-26 09:33:18.191709
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    time.sleep(0.8)


if __name__ == '__main__':
    import sys
    import time
    #print("Called directly")
    #test_case_0()
    test_MonoWorker_submit()
    #print(mono_worker_0.futures)
    try:
        input("Press enter to continue...")
    except:
        sys.exit(1)

# Generated at 2022-06-26 09:33:24.530123
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(int)

    # run tests
    test_case_0()


if __name__ == "__main__":
    # verify that a fresh instance of MonoWorker can be created
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:33:29.066465
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def test_func(*args):
        return [elt for elt in args]
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(test_func, 1, 2, 3) == [1, 2, 3]
    assert mono_worker_0.submit(test_func, 4, 5, 6) == [4, 5, 6]
    assert mono_worker_0.submit(test_func, 7, 8, 9) == [7, 8, 9]
    assert mono_worker_0.submit(test_func, 1, 2, 3) == [1, 2, 3]
    assert mono_worker_0.submit(test_func, 4, 5, 6) == [4, 5, 6]

# Generated at 2022-06-26 09:33:36.602706
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func0(arg0, arg1):
        return ((arg0 + arg1) * (arg1 + arg0))
    mono_worker_0.submit(func0, 2, 1)
    mono_worker_0.submit(func0, 4, 2)
    mono_worker_0.submit(func0, 6, 1)


# Generated at 2022-06-26 09:33:38.392779
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> test_case_0()
    """
    pass

# Generated at 2022-06-26 09:33:42.871032
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test that the arguments are passed correctly to the wrapper
    """
    def f(x):
        return x
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(f, 1) == 1

# Generated at 2022-06-26 09:33:47.654753
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def func(n):
        sleep(n)
        return n

    with tqdm_auto.tqdm(total=4) as t:
        mono_worker_0 = MonoWorker()
        for i in range(3):
            f = mono_worker_0.submit(func, 2)
            f.add_done_callback(t.set_postfix)
            t.update()


# Generated at 2022-06-26 09:33:58.236765
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(tqdm_auto.write, "This is a test")
    mono_worker_1.submit(tqdm_auto.write, "This is another test")
    mono_worker_1.submit(tqdm_auto.write, "This is a third test")


# Generated at 2022-06-26 09:34:08.711851
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_submit = MonoWorker()
    mfutures=mono_worker_submit.futures
    assert len(mfutures) == 0
    mono_worker_submit.submit(print,'Hello World')
    assert len(mfutures) == 1
    mono_worker_submit.submit(print,'Hello World 1')
    mono_worker_submit.submit(print,'Hello World 2')
    assert len(mfutures) == 2
    mono_worker_submit.submit(print,'Hello World 3')
    assert len(mfutures) == 1
    mono_worker_submit.submit(print,'Hello World 4')
    assert len(mfutures) == 1
    mono_worker_submit.submit(print,'Hello World 5')
    assert len(mfutures) == 1
    mono_

# Generated at 2022-06-26 09:34:16.110285
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    mono_worker_0 = MonoWorker()

    def func(a, b):
        return a * b
    
    mono_worker_0.submit(func, 2, 4)
    
    assert mono_worker_0.futures[0].result() == 8

    mono_worker_0.submit(func, 3, 6)
    
    assert mono_worker_0.futures[0].result() == 18

# Generated at 2022-06-26 09:34:26.080738
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    
    mono_worker = MonoWorker()
    
    t = time.time()
    for i in range(0, 20):
        mono_worker.submit(time.sleep, random.randint(0, 10))
    
    while mono_worker.futures:
        time.sleep(0.1)
    

# Generated at 2022-06-26 09:34:28.675628
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_submit_0 = MonoWorker()
    mono_worker_submit_0.submit(int, 'a')

# Generated at 2022-06-26 09:34:38.711637
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    futures_0 = mono_worker_0.futures
    assert len(futures_0) == 0
    assert futures_0.maxlen == 2
    mono_worker_0.submit(print, 'hi0')
    assert len(futures_0) == 1
    mono_worker_0.submit(print, 'hi1')
    assert len(futures_0) == 2
    mono_worker_0.submit(print, 'hi2')
    assert len(futures_0) == 2
    assert futures_0[0].done() == True
    assert futures_0[1].done() == False
    print(futures_0[0].result())
    assert futures_0[0].result() == None

# Generated at 2022-06-26 09:34:49.366536
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Unit test for method submit of class MonoWorker.

    """
    import time
    t_start = time.time()
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(time.sleep, 1)
    mono_worker_0.submit(time.sleep, 2)
    mono_worker_0.submit(time.sleep, 3)
    mono_worker_0.submit(time.sleep, 4)
    
    assert time.time()-t_start >= 1
    assert time.time()-t_start < 3
    mono_worker_0.submit(time.sleep, 5)
    mono_worker_0.submit(time.sleep, 6)
    mono_worker_0.submit(time.sleep, 7)

# Generated at 2022-06-26 09:35:00.138870
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    import random
    import subprocess
    global results_0
    results_0 = deque()

    def func(i):
        import random
        subprocess.call("sleep " + str(random.randint(0, 1) + 0.2), shell=True)
        global results_0
        results_0.append(i)

    mono_worker_0 = MonoWorker()
    for i in range(10):
        mono_worker_0.submit(func, i)
    tqdm_auto.write("\n")

    for i in range(0, 10):
        assert((i in results_0))

    tqdm_auto.write("test_case_0  passed\n")

    mono_worker_object_0 = MonoWorker()
    mono_worker_object_1 = MonoWorker()
   

# Generated at 2022-06-26 09:35:07.458257
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def f(x):
        return x*x
    
    print("\n---Unit test for submit---")
    print("Task 1:")
    mono_worker_0.submit(f, 2)
    print("Task 2 - should override task 1:")
    mono_worker_0.submit(f, 4)
    print("Task 3 - should be canceled and discarded:")
    mono_worker_0.submit(f, 6)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:35:16.079383
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    assert isinstance(mono_worker_1, MonoWorker)
    # Fill deque with Futures
    for i in range(3):
        mono_worker_1.submit(lambda: 1)
    # Fill deque to capacity; discard oldest task
    mono_worker_1.submit(lambda: 2)
    assert mono_worker_1.futures[-1].result() == 2
    # Submit another task after cancellation; discards waiti

# Generated at 2022-06-26 09:35:28.816451
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    for i in range(4):
        print(i)
        def print_num(n):
            print(f"Starting. N: {n}")
            for i in range(n):
                print(i)

        mw.submit(print_num, i+1)
        print(f"Submitted {i}")


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:35:36.684980
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(x, y=1):
        return x*y
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(func, 1, 2) == 2
    assert mono_worker_0.submit(func, 1, 3) == 3
    assert mono_worker_0.submit(func, 1, 4) == 3

if __name__ == '__main__':
    test_MonoWorker_submit()
    test_case_0()

# Generated at 2022-06-26 09:35:48.227633
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    ## 2.1
    # submit a simple task
    # __init__
    # A simple test for MonoWorker
    ## 2.2
    # submit a task before the worker has finished its previous task
    # __init__
    # A simple test for MonoWorker
    ## 2.3
    # submit a task after the worker has finished its previous task
    # __init__
    # A simple test for MonoWorker
    ## 2.4
    # submit a task while the worker has not finished its previous task
    # __init__
    # A simple test for MonoWorker
    ## 2.5
    # submit a task while the worker is running the submitted task
    # __init__
    # A simple test for MonoWorker

    tqdm_auto.write("Skipped tests 4 and 5 due to lack of time.")

# Generated at 2022-06-26 09:35:50.191782
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()


# Generated at 2022-06-26 09:35:54.496273
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(test_case_0)


########################
# End of file.         #
########################

# Generated at 2022-06-26 09:36:00.413493
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(int, '1')
    mono_worker_0.submit(int, '2')
    mono_worker_0.submit(int, '3')


# Generated at 2022-06-26 09:36:05.670026
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    mono_worker_1 = MonoWorker()

    for i in range(10):
        sleep(0.1)
        x = random()
        mono_worker_1.submit(sleep, x)

# Generated at 2022-06-26 09:36:19.317524
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_1 = MonoWorker()
    mono_worker_2 = MonoWorker()
    mono_worker_3 = MonoWorker()
    mono_worker_4 = MonoWorker()
    mono_worker_5 = MonoWorker()
    mono_worker_6 = MonoWorker()
    mono_worker_7 = MonoWorker()
    mono_worker_8 = MonoWorker()
    mono_worker_9 = MonoWorker()
    def a():
        pass
    mono_worker_0.submit(a)
    mono_worker_1.submit(a)
    mono_worker_2.submit(a)
    mono_worker_3.submit(a)
    mono_worker_4.submit(a)
    mono_worker_5.submit(a)

# Generated at 2022-06-26 09:36:31.567130
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    from multiprocessing import freeze_support

    def do_work(seconds, message):
        print('doing {0}s of work on {1}'.format(seconds, message))
        time.sleep(seconds)
        return 'done {0}s of work on {1}'.format(seconds, message)

    if __name__ == '__main__':
        freeze_support()
        with tqdm_auto.tqdm(total=60, desc='First loop') as t0:
            mono_worker_1 = MonoWorker()
            timeout = 0.1
            while t0.n < t0.total:
                tqdm_auto.write('submitting task')
                future = mono_worker_1.submit(do_work, random.randint(1, 10), 'something')

# Generated at 2022-06-26 09:36:40.149460
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    m = MonoWorker()
    def f(x):
        import time
        time.sleep(x)
        return x
    # print m.submit(f, 0.5).result()
    assert m.submit(f, 0.5).result() == 0.5
    assert m.submit(f, 0.5).result() == 0.5
    assert m.submit(f, 0.5).result() == 0.5
    assert m.submit(f, 0.5).result() == 0.5



# Generated at 2022-06-26 09:36:59.203892
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, 'test')
    assert mono_worker_0.futures
    mono_worker_0.submit(print, 'test2')
    assert len(mono_worker_0.futures) == 1

# Generated at 2022-06-26 09:37:01.164981
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    def f(*args, **kwargs):
        return str(*args)+str(kwargs)
    assert mono_worker.submit(f, 'test', k='test')


# Generated at 2022-06-26 09:37:12.561780
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()

    # Test Case 0.1
    # Test Case 0.1.1
    assert(mw._MonoWorker__futures == deque([], 2))

    # Test Case 0.1.2
    assert(mw._MonoWorker__pool._ThreadPoolExecutor__work_queue.qsize() == 0)

    # Test Case 0.2
    mw.submit(test_case_0)

    # Test Case 0.2.1
    assert(mw._MonoWorker__futures != deque([], 2))

    # Test Case 0.2.2
    assert(mw._MonoWorker__pool._ThreadPoolExecutor__work_queue.qsize() == 1)

    # Test Case 0.2.3

# Generated at 2022-06-26 09:37:15.836858
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Set up test variables
    mono_worker_0 = MonoWorker()
    # Submit request
    mono_worker_0.submit()


# Generated at 2022-06-26 09:37:20.714334
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Instantiate the class
    mono_worker_0 = MonoWorker()

    # Call method submit
    mono_worker_0.submit(lambda a, b: a + b, 4, 4)
    return

if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:37:30.673880
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func_0():
        for _ in tqdm_auto.trange(5):
            tqdm_auto.sleep(1)
            tqdm_auto.write('Printed from: {}'.format(func_0))
    mono_worker_0.submit(func_0)
    mono_worker_0.submit(func_0)
    mono_worker_0.submit(func_0)
    mono_worker_0.submit(func_0)
    mono_worker_0.submit(func_0)
    mono_worker_0.submit(func_0)



# Generated at 2022-06-26 09:37:40.583762
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def test_0(x):
        time.sleep(x)
        return x
    mono_worker_0 = MonoWorker()
    res_0 = mono_worker_0.submit(test_0, 0.5)
    res_1 = mono_worker_0.submit(test_0, 0.5)
    assert not res_0.done()
    assert res_1.done()
    time.sleep(0.6)
    assert res_0.done()


# Generated at 2022-06-26 09:37:48.111086
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    f = mw.submit(lambda: 1)
    assert f.result() == 1
    # Check that old future is replaced
    g = mw.submit(lambda: 2)
    assert g.result() == 2
    assert not f.done()


# Generated at 2022-06-26 09:37:51.984910
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker_0 = MonoWorker()
    def test_func(a):
        return a
    mono_worker_0.submit(test_func, 1)
    mono_worker_0.submit(test_func, 2)
    mono_worker_0.submit(test_func, 3)

# Generated at 2022-06-26 09:38:01.723995
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """test submit method of MonoWorker class
    """
    import sys
    import os
    import time
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    import contrib
    mw = contrib.MonoWorker()
    t = time.time()
    for i in range(20):
        r = mw.submit(time.sleep, 0.01)
        print(r)
    r.result()
    print(time.time()-t)


# Generated at 2022-06-26 09:38:32.561534
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(None) is None


# Generated at 2022-06-26 09:38:34.771344
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    # Nothing to do

# Generated at 2022-06-26 09:38:41.074986
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import tqdm.contrib as contrib

    def bar_plotter(V, name):
        if V == -1:
            contrib.bar_chart(name, [0])
        else:
            contrib.bar_chart(name, [V])

    V = 0
    mono_worker = contrib.MonoWorker()

    mono_worker.submit(bar_plotter, -1, "before")
    time.sleep(1)
    mono_worker.submit(bar_plotter, V, "after")
    time.sleep(2)
    mono_worker.submit(bar_plotter, -1, "before")

if __name__ == "__main__":
    from .mono_worker import *
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:38:46.670506
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

# Generated at 2022-06-26 09:38:50.659918
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit('str')


# Generated at 2022-06-26 09:38:59.098744
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # basic unit test
    mono_worker = MonoWorker()
    mono_worker.submit(sum, [1, 2])

    # unit test for action / state change
    mono_worker = MonoWorker()
    mono_worker.submit(sum, [1, 2])
    mono_worker.submit(sum, [3, 2])

    # unit test for action / state change
    mono_worker = MonoWorker()
    mono_worker.submit(sum, [1, 2])
    mono_worker.submit(sum, [2, 3])
    mono_worker.submit(sum, [3, 2])


# Generated at 2022-06-26 09:39:03.771934
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    # successful run
    import time
    mono_worker_0.submit(time.sleep, 3)



# Generated at 2022-06-26 09:39:14.859484
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def process_message(self):
        return 1
    def process_message_1(self):
        return 1
    mono_worker_0.submit(process_message)
    mono_worker_0.submit(process_message)
    mono_worker_0.submit(process_message)
    mono_worker_0.submit(process_message)
    mono_worker_0.submit(process_message)
    mono_worker_0.submit(process_message)
    mono_worker_0.submit(process_message)
    mono_worker_0.submit(process_message)
    mono_worker_0.submit(process_message_1)
    mono_worker_0.submit(process_message)
    mono_worker_0.submit(process_message)
    mono_

# Generated at 2022-06-26 09:39:19.789597
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    try:
        mono_worker_0.submit(MonoWorker)
    except Exception as e:
        pass
    else:
        raise Exception('Failed to raise exception')


# Generated at 2022-06-26 09:39:25.935760
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    while True:
        try:
            break
        except Exception:
            # no-op
            pass

if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:40:36.323796
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    new_future_2 = mono_worker_0.submit(lambda: 1)


# Generated at 2022-06-26 09:40:43.800958
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    tqdm_auto.write = tqdm_auto.write or (lambda x: None)  # "mock"
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda: tqdm_auto.write("1"))
    mono_worker_0.submit(lambda: tqdm_auto.write("2"))

# Generated at 2022-06-26 09:40:50.809162
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func(*args, **kwargs):
        return 0
    mono_worker_0.submit(func)


if __name__ == '__main__':
    import sys
    try:
        d = dict(globals())
        name = sys.argv[1]
        d[name]()
    except KeyError:
        name = [n for n in d.keys() if n.startswith('test_')]
        nfailed = 0
        ntotal = 0
        for n in name:
            try:
                d[n]()
            except Exception:
                print(n, 'failed.')
                nfailed += 1
            else:
                print(n, 'success.')
            finally:
                ntotal += 1

# Generated at 2022-06-26 09:40:58.162418
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()

    mono_worker.submit(lambda : 1 + 1)
    mono_worker.submit(lambda : 1 + 1)
    mono_worker.submit(lambda : 2 + 2)
    mono_worker.submit(lambda : 2 + 2)

    assert mono_worker.futures.__len__() == 2

# Generated at 2022-06-26 09:41:01.943713
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    mono_worker.submit(print, 'test')
    mono_worker.submit(print, 'test')
    mono_worker.submit(print, 'test')
    mono_worker.submit(print, 'test')
    mono_worker.submit(print, 'test')
    mono_worker.submit(print, 'test')
    mono_worker.submit(print, 'test')
    mono_worker.submit(print, 'test')
    mono_worker.submit(print, 'test')
    mono_worker.submit(print, 'test')
    mono_worker.submit(print, 'test')
    mono_worker.submit(print, 'test')


# Generated at 2022-06-26 09:41:07.307505
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, "Hello")
    mono_worker_0.submit(print, "World")
    mono_worker_0.submit(print, "!"*30)

# Generated at 2022-06-26 09:41:19.434834
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Define `func` as external function so that we can mock it.
    """
    import tqdm.contrib.concurrency; tqdm.contrib.concurrency.__name__  # noqa
    import mock

    def func(x):
        """
        This is used to test code execution.
        """
        func.called = True
        return x

    with mock.patch('concurrent.futures.ThreadPoolExecutor') as mock_ThreadPoolExecutor:
        mono_worker = MonoWorker()
        mock_obj = mock.Mock()
        mock_ThreadPoolExecutor.return_value = mock_obj
        mock_obj.submit.return_value = mock.Mock()
        mono_worker.submit(func, 1)
    assert mock_ThreadPoolExecutor.called
    assert mock_

# Generated at 2022-06-26 09:41:23.498715
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    result = mono_worker_0.submit(lambda: None)
    # Method submit executed without error
    assert True

# Generated at 2022-06-26 09:41:31.030861
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import Process
    from time import sleep

    mono_worker_0 = MonoWorker()
    mono_worker_1 = MonoWorker()
    mono_worker_2 = MonoWorker()
    mono_worker_3 = MonoWorker()
    mono_worker_4 = MonoWorker()
    mono_worker_5 = MonoWorker()
    mono_worker_6 = MonoWorker()
    mono_worker_7 = MonoWorker()

    def hello(name):
        print("hello", name)
        sleep(2)

    # In this case, 2 workers are started and the other 6 are discarded
    # The second worker replaces the first waiting one
    process_0=Process(target=mono_worker_0.submit, args=(hello, "sun",))

# Generated at 2022-06-26 09:41:37.536971
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert None is mono_worker_0.submit(lambda x: x**2, 3)
    assert None is mono_worker_0.submit(lambda x: x**2, 4)
    assert None is mono_worker_0.submit(lambda x: x**2, 6)