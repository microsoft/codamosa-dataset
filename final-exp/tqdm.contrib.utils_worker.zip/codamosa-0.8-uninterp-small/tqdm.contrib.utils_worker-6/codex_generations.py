

# Generated at 2022-06-26 09:33:13.600213
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert isinstance(mono_worker_0, MonoWorker)
    assert len(mono_worker_0.pool._threads) == 1


# Generated at 2022-06-26 09:33:17.113688
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    sleep_time = 0.2
    for _ in range(3):
        mono_worker_0.submit(tqdm_auto.sleep, (sleep_time))
    return sleep_time
test_MonoWorker_submit()

# Generated at 2022-06-26 09:33:23.966433
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    global mono_worker_1
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(int, "12")
    mono_worker_1.submit(int, "15")
    mono_worker_1.submit(int, "42")

test_case_0()
test_MonoWorker_submit()

# Generated at 2022-06-26 09:33:27.543404
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    class ClassA:
        def funcA(self):
            pass
    
    classB = ClassA()
    try:
        mono_worker_0.submit(classB)
    except Exception as e:
        assert "funcA() takes 1 positional argument but 2 were given" == str(e)
    
    
    


# Generated at 2022-06-26 09:33:39.221783
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import concurrent.futures
    import tqdm.contrib.concurrent

    def slow_fib(n):
        if n < 2:
            return n
        else:
            return slow_fib(n-1) + slow_fib(n-2)

    def fast_fib(n, mono_worker):
        if n < 2:
            return n

        mono_worker.submit(
            fast_fib, n-1, mono_worker).add_done_callback(lambda fut: fut.result())
        return fast_fib(n-2, mono_worker) + 1

    input = range(10)

# Generated at 2022-06-26 09:33:47.299109
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func_test_mono_worker_submit(args, kwargs):
        global args_rec, kwargs_rec
        args_rec = args
        kwargs_rec = kwargs
        return 0
    kwargs_rec = None
    args_rec = None
    mw = MonoWorker()
    mw.submit(func_test_mono_worker_submit,(1,), {"kwargs":1})
    assert args_rec == (1,)
    assert kwargs_rec == {"kwargs":1}
    mw.submit(func_test_mono_worker_submit,(2,), {"kwargs":2})


# Generated at 2022-06-26 09:33:58.068944
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    dct = {}

    def random_func(dct, n_iter = 10):
        j = random.randint(0, n_iter)
        while j > 0:
            k = random.randint(0, 1)
            if k == 0:
                time.sleep(0.01)
            else:
                time.sleep(0.0)
            j -= 1
            dct[k] += 1

    def run_test():
        dct[0] = 0
        dct[1] = 0
        mono_worker_0 = MonoWorker()
        func, args, kwargs = random_func, (dct, ), {}
        mono_worker_0.submit(func, *args, **kwargs)
        time.sleep(0.3)
        return d

# Generated at 2022-06-26 09:34:07.010009
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .main import unittest

    class TestCase(unittest.TestCase):
        def test_0(self):
            """submit doesn't block if task is running"""
            mono_worker_0 = MonoWorker()
            mono_worker_0.submit(sleep, 1)
            mono_worker_0.submit(sleep, 1)

    unittest.main()

if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:34:15.865571
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

    # testing if the number of arguments is correct
    try:
        mono_worker_0.submit()
    except TypeError as e:
        assert "0-1" in str(e)

    # testing if the number of arguments is correct
    try:
        mono_worker_0.submit(1)
    except TypeError as e:
        assert "0-1" in str(e)

# Generated at 2022-06-26 09:34:17.495804
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    if __name__ == '__main__':
        mono_worker = MonoWorker()

# Generated at 2022-06-26 09:34:23.065054
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
        return mono_worker_0.submit()


# Generated at 2022-06-26 09:34:29.894998
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    worker = MonoWorker()
    for i in range(1, 10):
        worker.submit(lambda: i)
    for i in range(10, 20):
        worker.submit(lambda: i)
    worker.submit(lambda: 2*2)
    worker.submit(lambda: 2*2)
    worker.submit(lambda: 2*2)
    worker.submit(lambda: 2*2)
    worker.submit(lambda: 2*2)
    worker.submit(lambda: 2*2)
    worker.submit(lambda: 2*2)
    worker.submit(lambda: 2*2)
    worker.submit(lambda: 2*2)
    worker.submit(lambda: 2*2)
    worker.submit(lambda: 2*2)

if __name__ == '__main__':
    test_case_

# Generated at 2022-06-26 09:34:40.108967
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from numpy import test

    def slow_inc(x):
        sleep(0.5)
        return x + 1

    mono_worker_0 = MonoWorker()

    f0 = mono_worker_0.submit(slow_inc, 0)
    f1 = mono_worker_0.submit(slow_inc, 0)

    test.assert_equal(f0.result(), f1.result())
    test.assert_equal(f0.result(), 1)


if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:34:42.238111
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    pass

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:34:45.608143
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(int, '1', 2) is not None

# Generated at 2022-06-26 09:34:52.056413
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # test case 0
    mono_worker_0 = MonoWorker()
    def func(i):
        return i
    task = mono_worker_0.submit(func, 0)


if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:34:55.802398
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    '''
    Tests MonoWorker.submit()
    '''
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit("echo hello")
    mono_worker_0.submit("echo goodbye")

# Generated at 2022-06-26 09:35:04.176350
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Unit test for method submit of class MonoWorker.
    """
    tasks = [
        [lambda: None, (), {}],
        [lambda: None, (), {}],
        [lambda: None, (), {}],
        [lambda: None, (), {}],
        [lambda: None, (), {}],
    ]
    worker = MonoWorker()

    for task in tasks:
        worker.submit(*task)



# Generated at 2022-06-26 09:35:07.746944
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(int, '0x10')
    mono_worker_1.submit(int, '0x20', base=16)
    mono_worker_1.submit(int, '1')
    mono_worker_1.submit(int, '2')
    mono_worker_1.submit(int, '3')

# Generated at 2022-06-26 09:35:15.162911
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(echo, "a")
    mono_worker_1.submit(echo, "b")
    mono_worker_1.submit(echo, "c")
    for i in range(3):
        assert mono_worker_1.futures[i].result() == "ab"[i]



# Generated at 2022-06-26 09:35:29.310282
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock

    n_tasks_finished = 0

    def fin():
        from os import getpid

        global n_tasks_finished
        n_tasks_finished += 1

        tqdm_auto.write("PID={0}: fin()".format(getpid()))

    mw = MonoWorker()

    # Submit the 0th task
    mw.submit(sleep, 10)

    # Submit the 1st task
    mw.submit(sleep, 5)

    # Submit the 2nd task
    mw.submit(fin)

    assert len(mw.futures) == 1

    # Submit the 3rd task (e.g. as a result of a user input)
    mw.submit(fin)

    assert len(mw.futures) == 1

# Generated at 2022-06-26 09:35:39.621110
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import randrange
    from multiprocessing import Process

    # test function
    def test_func(*args, **kwargs):
        time.sleep(randrange(2, 5))
        return sum(args) + len(kwargs)

    # define the event list
    event_list = []

    # Add element "start" to event_list
    def append_start():
        event_list.append("start")
    # Add element "end" to event_list
    def append_end():
        event_list.append("end")

    # define the process
    def test_process():
        # start process
        append_start()
        mono_worker_0 = MonoWorker()

# Generated at 2022-06-26 09:35:49.062065
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures
    import threading
    import time

    def slow_func(i, delay=0.5):
        time.sleep(delay)
        return i

    def test_case_1():
        mono_worker = MonoWorker()
        for i in tqdm_auto.trange(4):
            future = mono_worker.submit(slow_func, i, delay=0.2)
            assert isinstance(future, concurrent.futures.Future)
            # Wait on running task to finish before starting next
            while not future.done():
                time.sleep(0.001)  # wait on future to complete

        mono_worker.pool.shutdown()

    def test_case_2():
        mono_worker = MonoWorker()

# Generated at 2022-06-26 09:35:58.844282
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from tqdm.contrib import async_generator
    from .bar import Bar
    from .utils import _range
    from itertools import repeat
    from multiprocessing import Pool
    from time import sleep
    from os import getpid
    import sys
    import pytest

    # expected_futures_0 is a list of futures that `mono_worker_0.submit`
    # should return in the order called
    expected_futures_0 = [None, None, None, None, None, None, None, None, None]
    # expected_results is a list of expected results from each future
    expected_results = [1, 1, 2, 3, 4, 5, 6, 7, 8]

    # This is an example of using `MonoWorker` with `tqdm.contrib.async_gener

# Generated at 2022-06-26 09:36:04.852015
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from unittest import TestCase
    from unittest.mock import Mock, patch

    class MonoWorker_submitTestCase(TestCase):
        def setUp(self):
            self.mock_func = Mock()
            self.args = ()
            self.kwargs = {}
            self.mono_worker = MonoWorker()
            self.future = Future()

        @patch('tqdm.contrib.concurrent.ThreadPoolExecutor.submit')
        def test_submit_called(self, mock_submit):
            mock_submit.return_value = self.future
            self.mono_worker.submit(self.mock_func, *self.args, **self.kwargs)

# Generated at 2022-06-26 09:36:09.293889
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()


if __name__ == "__main__":
    """
    CommandLine:
        python -m tqdm.contrib.concurrent test_MonoWorker_submit
    """
    import xdoctest
    xdoctest.doctest_module(__file__)

# Generated at 2022-06-26 09:36:14.663349
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    from concurrent.futures import Future
    def echo(x):
        return x
    for x in range(4):
        result = mono_worker.submit(echo, x)
        assert isinstance(result, Future)
        assert result.result() == x


if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()
    from os import system
    system('python -m doctest -v -o NORMALIZE_WHITESPACE -o ELLIPSIS -o IGNORE_EXCEPTION_DETAIL' +
           ' --m=MonoWorker {0}'.format(__file__))

# Generated at 2022-06-26 09:36:19.369932
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.futures.append("YmVlY2xhZ2V0")
    mono_worker_0.pool = ThreadPoolExecutor(max_workers=1)
    mono_worker_0.submit("YmVlY2xhZ2V0", "YmVlY2xhZ2V0")

# Generated at 2022-06-26 09:36:31.589584
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test empty case
    mono_worker = MonoWorker()
    assert not mono_worker.futures
    assert mono_worker.submit(lambda:None)
    assert len(mono_worker.futures) == 1
    assert mono_worker.futures[0].running()
    assert mono_worker.submit(lambda:None)
    assert len(mono_worker.futures) == 2
    assert not mono_worker.futures[0].running()
    assert mono_worker.futures[1].running()
    assert mono_worker.futures[0].cancel()
    assert mono_worker.submit(lambda:None)
    assert len(mono_worker.futures) == 2
    assert mono_worker.futures[1].running()
    assert mono_worker.fut

# Generated at 2022-06-26 09:36:41.769075
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    from time import sleep
    sync_event = Event()
    glbl = {"i": 0, "j": 0, "k": 0}

    def incr(sync_event, glbl: dict, i: int):
        # sleep to simulate blocking
        sleep(0.01)
        glbl["i"] = i
        sync_event.set()

    # test "conflicting" requests
    sync_event.clear()
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(incr, sync_event=sync_event, glbl=glbl, i=1)
    mono_worker_0.submit(incr, sync_event=sync_event, glbl=glbl, i=2)
    assert sync_event.wait(timeout=1)

# Generated at 2022-06-26 09:37:01.454133
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()

    def function1():
        a = 0
        while a < 10000000:
            a = a + 1

    def function2():
        a = 0
        while a < 10000000:
            a = a + 1

    # There is no running and waiting task
    mono_worker.submit(function1)
    mono_worker.submit(function2)
    # The first one (function1) is running and the second one (function2) is waiting
    assert len(mono_worker.futures) == 2
    # The order of the functions is maintained
    assert mono_worker.futures[0]._func() == function1
    assert mono_worker.futures[1]._func() == function2
    # There is only one thread working in the thread pool

# Generated at 2022-06-26 09:37:06.346244
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert len(mono_worker_0.futures) == 0
    mono_worker_0.submit(int, '10')
    assert len(mono_worker_0.futures) == 1

# Generated at 2022-06-26 09:37:14.603487
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading, time
    from multiprocessing import Event
    from .testing import MultiTestCase

    def async_process_0(msg, evt):
        evt.wait()
        time.sleep(1)
        print(msg)

    class ThreadBlocks(MultiTestCase):
        def test_0(self):
            evt = Event()
            mono_worker_0 = MonoWorker()
            mono_worker_0.submit(async_process_0, "process_0", evt)
            mono_worker_0.submit(async_process_0, "process_1", evt)
            mono_worker_0.submit(async_process_0, "process_2", evt)
            mono_worker_0.submit(async_process_0, "process_3", evt)
           

# Generated at 2022-06-26 09:37:21.115532
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    # Test with args and kwargs
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(func=print, args=(0,), kwargs={'file': open('/dev/null', 'w')})
    mono_worker_0.submit(func=print, args=(0,), kwargs={'file': open('/dev/null', 'w')})

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:37:29.615124
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    # test case 0
    time.sleep(1)
    test_case_0()
    # test case 1
    time.sleep(1)
    test_case_1()
    # test case 2
    time.sleep(1)
    test_case_2()
    # test case 3
    time.sleep(1)
    test_case_3()
    # test case 4
    time.sleep(1)
    test_case_4()



# Generated at 2022-06-26 09:37:35.573088
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    import requests
    future_0 = mono_worker_0.submit(requests.get, "https://www.google.com")
    future_0.result().text[:100]


# Generated at 2022-06-26 09:37:43.909663
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import random
    from time import sleep
    from ..utils import FormatCustomText
    from ..utils import _range
    from .tests_tqdm import closing

    def _random_sleep(a, b):
        sleep(random() * (b - a) + a)

    with closing(tqdm_auto.tqdm(
            _range(100),
            file=FormatCustomText(fp=None, desc=None, total=100),
            disable=None, mininterval=0.1,
            miniters=1, dynamic_ncols=False)) as pbar:
        for i in pbar:
            mono_worker = MonoWorker()
            mono_worker.submit(_random_sleep, 0, 0.1)
            sleep(0.1)  # noqa



# Generated at 2022-06-26 09:37:53.727373
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    mono_worker_1 = MonoWorker()

    # Set up the callable function:
    def callable_func(n):
        time.sleep(n)
        return n

    # Check for single submission
    status = mono_worker_1.submit(callable_func, 0.1)
    assert status.result() == 0.1

    # Check for double submission
    status = mono_worker_1.submit(callable_func, 0.1)
    assert status.result() == 0.1
    status = mono_worker_1.submit(callable_func, 0.1)
    assert status.result() == 0.1

    # Check for triple submission
    status = mono_worker_1.submit(callable_func, 0.1)
    assert status.result() == 0.1
    status

# Generated at 2022-06-26 09:38:03.716986
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(pow, 2, 2)
    mono_worker_0.submit(pow, 2, 2)
    mono_worker_0.submit(pow, 2, 2)
    mono_worker_0.submit(pow, 2, 2)
    mono_worker_0.submit(pow, 2, 2)
    mono_worker_0.submit(pow, 2, 2)
    mono_worker_0.submit(pow, 2, 2)
    mono_worker_0.submit(pow, 2, 2)
    mono_worker_0.submit(pow, 2, 2)
    mono_worker_0.submit(pow, 2, 2)
    mono_worker_0.submit(pow, 2, 2)


# Generated at 2022-06-26 09:38:09.892214
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, "test_string_0")
    return


if __name__ == "__main__":
    import doctest
    print(doctest.testmod())
#     test_MonoWorker_submit()

# Generated at 2022-06-26 09:38:34.986451
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Create a custom function to test submit method
    def test0():
        pass
    # Create a new object of MonoWorker
    mono_worker_0 = MonoWorker()

    # Test case 0
    # method submit of class MonoWorker
    future1 = mono_worker_0.submit(test0)
    assert future1.done() == False

    # Test case 1
    # method submit of class MonoWorker
    future2 = mono_worker_0.submit(test0)
    assert future1.done() == False
    assert future2.done() == True

test_case_0()
test_MonoWorker_submit()

# Generated at 2022-06-26 09:38:41.133796
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from collections import namedtuple
    from concurrent.futures import TimeoutError
    import numpy as np
    from ..auto import tqdm
    from ..utils import _supports_unicode
    try:
        from colorama import Fore
    except ImportError:
        Fore = None
    RESET = Fore.RESET if Fore else ''

    print('\n*** test_MonoWorker_submit ***')
    print('numpy', np.__version__)

    def my_func(x):
        sleep(x)
        return x

    np.random.seed(0)
    test_cases = [
        (2,),
        (6,),
        (1, 3, 2),
        (4, 2, 6),
        (5, 4, 4, 2),
    ]


# Generated at 2022-06-26 09:38:49.155028
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import randint
    from concurrent.futures import TimeoutError

    def f(x):
        time.sleep(x)
        return None

    mono_worker_0 = MonoWorker()
    assert len(mono_worker_0.futures) == 0

    mono_worker_0.submit(f, 0)
    assert len(mono_worker_0.futures) == 1
    mono_worker_0.futures[0].result(timeout=0.1)
    assert len(mono_worker_0.futures) == 0

    mono_worker_0.submit(f, 0.3)
    assert len(mono_worker_0.futures) == 1

# Generated at 2022-06-26 09:38:57.425237
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def _func_0(*args, **kwargs):
        print('Hello world!')
    mono_worker_0.submit(_func_0)
    mono_worker_0.submit(_func_0)
    mono_worker_0.submit(_func_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:39:07.463138
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

    from time import sleep
    from .tqdm_threads import tqdm_test_sleep
    def test_fn_0(*args, **kwargs):
        return tqdm_test_sleep(*args, **kwargs)

    with tqdm_auto.tqdm(total=1) as t:
        for i in t:
            mono_worker_0.submit(test_fn_0, t, 0.5)
            sleep(5)

# Generated at 2022-06-26 09:39:21.217591
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    tasks = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
    counter = 0

    def func(task):
        global counter
        counter += 1
        return task

    # maxlen = 2
    mono_worker_2 = MonoWorker()
    tqdm_auto.write("\nmaxlen = 2\n")
    tqdm_auto.write("Submit: ")
    for task in tasks:
        tqdm_auto.write(task, end=" ")
        mono_worker_2.submit(func, task)
    tqdm_auto.write("\nResult: ")
    for future in mono_worker_2.futures:
        tqdm_auto.write("{} ".format(future.result()), end="")



# Generated at 2022-06-26 09:39:23.334968
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit(): 
    mono_worker_0 = MonoWorker()
    assert (compare_string(mono_worker_0.submit('foo', 'bar'), 'foo') == 0)


# Generated at 2022-06-26 09:39:25.934960
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    temp_0 = MonoWorker()
    temp_1 = temp_0.submit()


# Generated at 2022-06-26 09:39:30.669044
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def my_func(x):
        tqdm_auto.write("Inside my_func")
        return x
    my_func(1)
    mono_worker_0.submit(my_func, 1)

# Generated at 2022-06-26 09:39:35.901706
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    int_1 = mono_worker_0.submit(int, '123', base=10)
    assert int_1 is not None


# Generated at 2022-06-26 09:40:05.658608
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
  mono_worker_0 = MonoWorker()

  def blah(a, b):
    return a + b

  mono_worker_0.submit(blah, 1, 2)

# Generated at 2022-06-26 09:40:16.213496
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Non regression test for
    `MonoWorker().submit(func, *args, **kwargs)`.
    """
    # Empty MonoWorker
    mono_worker_0 = MonoWorker()

    # Two tasks
    mono_worker_0.submit(lambda: 1)
    mono_worker_0.submit(lambda: 2)

    # Three tasks
    mono_worker_0.submit(lambda: 3)


if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:40:28.233048
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import string
    import shutil
    import time

    def key_gen(n):
        return ''.join(random.choice(string.ascii_uppercase + string.digits)
                       for _ in range(n))

    def task_gen(n):
        def task():
            time.sleep(1)
            return key_gen(n)
        return task

    tasks = [task_gen(10), task_gen(10), task_gen(10), task_gen(10)]
    mono_worker = MonoWorker()
    for task in tasks:
        mono_worker.submit(task)

    with tqdm_auto.tqdm(total=len(tasks),
                    desc='Testing MonoWorker.submit') as pbar:
        for task in tasks:
            result = mono_

# Generated at 2022-06-26 09:40:31.123356
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit()


# Generated at 2022-06-26 09:40:40.604251
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import multiprocessing
    def test_func(x = 0):
        time.sleep(1)
        return x
    def test_func_2(x,y):
        time.sleep(1)
        return x
    def test_func_parallel(x, y):
        z = 0
        while z < x:
            z += 1
            time.sleep(y)
        return z
    from concurrent.futures import ThreadPoolExecutor,as_completed
    mono_worker_0 = MonoWorker()
    pool_executor_0 = ThreadPoolExecutor(max_workers=1)
    pool_executor_0.submit(test_func)
    x = 0

# Generated at 2022-06-26 09:40:45.073900
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    import time
    import random
    import operator
    futures = []
    count = 0
    methods = ['get', 'get', 'get', 'submit', 'submit', 'submit']
    def func(bar_desc, delay=0.1, cycle=True, total=100):
        for i in tqdm_auto(range(total), desc=bar_desc, leave=cycle):
            time.sleep(random.uniform(delay / 2.0, delay * 2))
    while True:
        count += 1
        method = random.choice(methods)
        tqdm_auto.write('\n[%2d] %s method...' % (count, method))
        if method == 'get':
            futures.sort(key=operator.attrgetter('id'))


# Generated at 2022-06-26 09:40:46.911910
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()


# Generated at 2022-06-26 09:40:53.475478
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # create a MonoWorker object
    mono_worker_1 = MonoWorker()

    # do a submit on MonoWorker to test if the output is None
    res = mono_worker_1.submit(input, "Enter the string to echo: ")
    assert res == None

# Generated at 2022-06-26 09:40:59.861529
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func_0(*args, **kwargs):
        mono_worker_0 = MonoWorker()
        mono_worker_0.submit(*args, **kwargs)
    def func_1(*args, **kwargs):
        mono_worker_0 = MonoWorker()
        mono_worker_0.submit(*args, **kwargs)
    func_0(1)
    func_1(2)

test_case_0()
test_MonoWorker_submit()

# Generated at 2022-06-26 09:41:07.235590
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Initialize the MonoWorker object
    mono_worker_0 = MonoWorker()
    # Submit a function with arguments to be executed by the thread pool
    result = mono_worker_0.submit(test_case_0)

if __name__ == '__main__':
    # Run tests
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:42:22.929156
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-26 09:42:30.346061
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    #test 0
    def task_0(arg):
        return arg

    tqdm_auto.write("Testing for MonoWorker.submit with normal inputs")
    res_0 = mono_worker_0.submit(task_0, "0")
    assert res_0 is not None


# Generated at 2022-06-26 09:42:37.521547
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from unittest.mock import patch, call
    mono_worker_0 = MonoWorker()
    with patch.object(mono_worker_0, 'submit', return_value=1) as mock_submit:
        ret = mock_submit(1, 2, 3)
        assert mock_submit.call_count == 1
        mono_worker_0.submit(1, 2, 3)
        assert mono_worker_0.submit.call_count == 1
        mono_worker_0.submit(1, 2, 3)
        assert mono_worker_0.submit.call_count == 2
    with patch.object(mono_worker_0, 'submit', return_value=1) as mock_submit:
        ret = mock_submit(1, 2, 3)
        assert mock_submit.call_count == 1

# Generated at 2022-06-26 09:42:40.011452
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

# Generated at 2022-06-26 09:42:47.828843
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from mock import MagicMock, patch

    mono_worker_0 = MonoWorker()
    mono_worker_0.pool = MagicMock()

    mono_worker_0.submit(test_case_0,test_case_0,test_case_0,test_case_0,test_case_0)

    assert mono_worker_0.pool.submit.using_count == 1
    assert mono_worker_0.pool.submit.using_params[0] == (test_case_0,)
    assert mono_worker_0.pool.submit.using_params[1] == {'args':(test_case_0,),'kwargs':(test_case_0,test_case_0,test_case_0)}

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:42:56.240178
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Only three tasks are kept track of in this test case"""
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(func=test_case_0, *(), **{}) == None
    assert mono_worker_0.submit(func=test_case_0, *(), **{}) == None
    assert mono_worker_0.submit(func=test_case_0, *(), **{}) == None

if __name__ == "__main__":
    import sys
    import pytest
    sys.exit(pytest.main(["-qq", __file__]))

# Generated at 2022-06-26 09:43:02.288167
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()

    def func_1(a, b):
        return a + b
    mono_worker_1.submit(func_1, 1, 1)

    assert mono_worker_1.futures.pop().result() == 2
    return

# Generated at 2022-06-26 09:43:04.640018
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Testing the method submit of class MonoWorker
    Input:  None
    Output: None
    """
    test_case_0()

# Generated at 2022-06-26 09:43:05.773309
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    test_case_0()
    test_case_1()
