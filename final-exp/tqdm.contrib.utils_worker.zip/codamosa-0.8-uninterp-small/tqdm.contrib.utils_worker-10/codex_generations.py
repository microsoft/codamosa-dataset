

# Generated at 2022-06-26 09:33:05.650224
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    thread_0 = mono_worker_0.submit()

# Generated at 2022-06-26 09:33:09.672571
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def f(n):
        return n
    mono_worker_0.submit(f, 0)


# Generated at 2022-06-26 09:33:19.707282
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import numpy as np
    import logging
    import os
    import sys

    # Build logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    # create file handler which logs even debug messages
    fileHandler = logging.FileHandler('output.log')
    fileHandler.setLevel(logging.DEBUG)
    # create console handler with a higher log level
    consoleHandler = logging.StreamHandler()
    consoleHandler.setLevel(logging.INFO)

    # create formatter and add it to the handlers
    formatter = logging.Formatter('%(asctime)s - %(module)s.%(funcName)s - %(lineno)d: - %(levelname)s - %(message)s')

# Generated at 2022-06-26 09:33:28.519413
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    tqdm_auto.write('lala')
    mono_worker_0.submit('lalala')
    mono_worker_0.submit(tqdm_auto.write, 'lala')
    mono_worker_0.submit(tqdm_auto.write, 'lala')
    mono_worker_0.submit(tqdm_auto.write, 'lala')
    mono_worker_0.submit(tqdm_auto.write, 'lala')
    mono_worker_0.submit(tqdm_auto.write, 'lala')

    for _ in range(10):
        mono_worker_0.submit(tqdm_auto.write, 'lala')



# Generated at 2022-06-26 09:33:33.383596
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert mono_worker_0.submit(func, *args, **kwargs).result() == result
    mono_worker_0.futures.clear()


# Generated at 2022-06-26 09:33:36.756271
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .test_MonoWorker import test_MonoWorker_submit
    test_MonoWorker_submit()


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:33:46.076572
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import subprocess
    mono_worker_0 = MonoWorker()

    tqdm_auto.write('submitting ls -l')
    future_0 = mono_worker_0.submit(subprocess.check_call, ['ls','-l'])
    tqdm_auto.write('submitting uname -a')
    future_1 = mono_worker_0.submit(subprocess.check_call, ['uname','-a'])
    tqdm_auto.write('submitting date')
    future_2 = mono_worker_0.submit(subprocess.check_call, ['date'])
    tqdm_auto.write('submitting sleep')
    future_3 = mono_worker_0.submit(subprocess.check_call, ['sleep','2'])

    tqdm_auto.write

# Generated at 2022-06-26 09:33:53.162136
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    result = mono_worker_0.submit('tqdm.contrib.utils.string_increment')
    result.get()

if __name__ == '__main__':
    # test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:33:56.904408
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    try:
        test_case_0()
        print("[pass] test_case_0()")
    except:
        print("[fail] test_case_0()")
    print('\n')

if __name__ == '__main__':
    test_MonoWorker_submit()



# Generated at 2022-06-26 09:34:08.345544
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    mono_worker_0 = MonoWorker()
    sleep_0 = lambda: sleep(0.01)
    sleep_0()
    mono_worker_0.submit(sleep_0)
    sleep_0()
    mono_worker_0.submit(sleep_0)
    sleep_0()
    mono_worker_0.submit(sleep_0)
    sleep_0()
    mono_worker_0.submit(sleep_0)
    sleep_0()
    mono_worker_0.submit(sleep_0)
    sleep_0()
    mono_worker_0.submit(sleep_0)
    sleep_0()
    mono_worker_0.submit(sleep_0)
    sleep_0()
    mono_worker_0.submit(sleep_0)
    sleep_0()
   

# Generated at 2022-06-26 09:34:13.056644
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    return 0

# Generated at 2022-06-26 09:34:16.212123
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def dummy_function():
        return
    assert mono_worker_0.submit(dummy_function) == None

# Generated at 2022-06-26 09:34:25.858832
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, 'foo')
    mono_worker_0.submit(print, 'bar')
    mono_worker_0.submit(print, 'baz')
    mono_worker_0.submit(print, 'quxx')


if __name__ == "__main__":

# print(__doc__)

# import doctest
    # doctest.testmod()
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:34:33.403059
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    func_0 = lambda: None
    mono_worker_0.submit(func_0)
    mono_worker_0.submit(func_0)
    mono_worker_0.submit(func_0)

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker()

# Generated at 2022-06-26 09:34:42.103822
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    f1 = lambda a: a + 1
    f2 = lambda a: a + 2
    f3 = lambda a: a + 3
    mono_worker = MonoWorker()
    mono_worker.submit(f1, 1)
    mono_worker.submit(f2, 2)
    mono_worker.submit(f3, 3)
    assert mono_worker.futures[0].result() == 2
    assert mono_worker.futures[1].result() == 4

# Generated at 2022-06-26 09:34:50.090839
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, concurrent.futures
    from .utils import SimpleNamespace

    def test_submit(name, delay, worker, verbose = False):
        try:
            worker.submit(time.sleep, delay)
            return SimpleNamespace(result = "ok")
        except concurrent.futures._base.CancelledError:
            result = "cancelled" if verbose else "canc"
            return SimpleNamespace(result = result)
        except concurrent.futures._base.BrokenExecutor:
            return SimpleNamespace(result = "broken")

    mono_worker_0 = MonoWorker()
    results = []
    results.append(test_submit("0", 0.010, mono_worker_0, verbose = True))

# Generated at 2022-06-26 09:34:54.828851
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test case #0
    mono_worker_0 = MonoWorker()

    # Test case #1
    mono_worker_1 = MonoWorker()

    # Test case #2
    mono_worker_2 = MonoWorker()



# Generated at 2022-06-26 09:35:02.131764
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(fn, a)
    mono_worker_0.submit(fn, a)
    mono_worker_0.submit(fn, a)
    mono_worker_0.submit(fn, a)
    mono_worker_0.submit(fn, a)
    mono_worker_0.submit(fn, a)
    mono_worker_0.submit(fn, a)
    mono_worker_0.submit(fn, a)
    mono_worker_0.submit(fn, a)
    mono_worker_0.submit(fn, a)
    mono_worker_0.submit(fn, a)
    mono_worker_0.submit(fn, a)
    mono_worker_0.submit(fn, a)
    mono_worker_

# Generated at 2022-06-26 09:35:09.376599
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    create a MonoWorker and submit two task to it and see if they 
    are executed in the right order.
    """
    mono_worker = MonoWorker()
    task1 = [1,2,3,4]
    task2 = [10,9,8,7]

    # add task1 to the first position of `futures`
    mono_worker.submit(sum, task1)
    
    # add task2 to the second position of `futures`
    mono_worker.submit(sum, task2)

    # check if the correct value is at element 1 in futures
    assert mono_worker.futures[1].result() == sum(task1)

    # check if the correct value is at element 0 in futures

# Generated at 2022-06-26 09:35:17.791212
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    futures = deque([], 2)
    length = len(futures)
    if length == futures.maxlen:
        running = futures.popleft()
        if not running.done():
            if len(futures):  # clear waiting
                waiting = futures.pop()
                waiting.cancel()
            futures.appendleft(running)  # re-insert running
    try:
        waiting = mono_worker_0.submit("func", "*args", "**kwargs")
    except Exception as e:
        tqdm_auto.write(str(e))
    else:
        futures.append(waiting)
        return waiting

# Generated at 2022-06-26 09:35:24.139191
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda x: x ** 2, 23)

# Generated at 2022-06-26 09:35:30.577382
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep  # from time import sleep
    import sys

    def func_0():
        print("func_0")
        print("func_0 result: 0")
        return 0  # return 0

    def func_1():
        sleep(1)
        print("func_1")
        print("func_1 result: 1")
        return 1  # return 1

    def func_2():
        sleep(1)
        print("func_2")
        print("func_2 result: 2")
        return 2  # return 2

    print("submit(func_0)")
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(func_0)
    print("submit(func_1)")
    mono_worker_0.submit(func_1)

# Generated at 2022-06-26 09:35:36.455941
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    n_futures = 10
    worker = MonoWorker()
    futures = []
    for i in range(n_futures):
        futures.append(worker.submit(lambda x: x, i))

    for i in range(n_futures):
        assert futures[i].result() == n_futures - 1

# Generated at 2022-06-26 09:35:48.156986
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    class TestMonoWorker_submit(object):
        """
        Test class for method MonoWorker.submit
        """
        def test_submit_0(self):
            """
            Tests for the case where the number of arguments is not the same as the default.
            """
            try:
                mono_worker_0 = MonoWorker()
                try:
                    mono_worker_0.submit(None)
                except Exception:
                    raise Exception("No exception should be thrown here.")
            except Exception as e:
                tqdm_auto.write("Exception thrown: %s" % str(e))

        def test_submit_1(self):
            """
            Tests for the case where the number of arguments is not the same as the default.
            """

# Generated at 2022-06-26 09:35:58.587180
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Just something to test class
    import sys
    import time

    mono_worker_0 = MonoWorker()

    def run_0_0():
        time.sleep(1.)
        return 0

    def run_0_1():
        print("RUNNING", file=sys.stderr)
        for _ in range(2):
            time.sleep(1.)
        print("DONE RUNNING", file=sys.stderr)
        return 0

    def run_0_2():
        time.sleep(1.)
        return 0

    mono_worker_0.submit(run_0_0)
    mono_worker_0.submit(run_0_1)
    mono_worker_0.submit(run_0_2)

    time.sleep(1.)
    time.sleep(1.)

# Generated at 2022-06-26 09:36:03.600517
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import monotonic
    mono_worker_0 = MonoWorker()
    # random function to test with
    f = lambda: random.randrange(0, 10)

    # Random inputs, 1-10 submits
    N = random.randrange(1, 11)
    start = monotonic.monotonic()
    for i in range(N):
        mono_worker_0.submit(f)
    for future in mono_worker_0.futures:
        print(future.result())
    print("MonoWorker.submit with N=" + str(N) + " inputs took " + str(monotonic.monotonic() - start) + " seconds.")

# Generated at 2022-06-26 09:36:10.254205
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .test_fragments import ThreadPoolTests
    tests = ThreadPoolTests()

    # Monoworker will replace currently waiting task with the most
    # recently submitted.
    for method_name in ("test_worker_thread_spawns_immediately",
                        "test_worker_thread_after_current_worker_done",
                        "test_worker_thread_after_n_workers_done"
                        ):
        method = getattr(tests, method_name)
        worker = MonoWorker()
        method(worker)



# Generated at 2022-06-26 09:36:20.256754
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import os
    if os.name == "nt":
        return  # don't bother testing on Windows
    import subprocess as sp
    # sleep outputs to stderr and has no stdout
    proc = sp.Popen(["sleep", "0.1"], stderr=sp.PIPE)
    # proc = sp.Popen(["cat", "/etc/passwd"], stdout=sp.PIPE)
    with tqdm_auto.tqdm(total=100, file=sys.stderr) as pbar:
        while proc.poll() is None:
            pbar.update(1)
            pbar.refresh()
            time.sleep(0.05)
    assert proc.returncode == 0
    print("\nnormal exit\n")


# Generated at 2022-06-26 09:36:31.650404
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys

    def get_time() -> str:
        return str(int(time.time() * 1000))

    monoworker = MonoWorker()
    t0 = get_time()
    assert monoworker.submit(lambda: t0)
    assert monoworker.submit(lambda: get_time())
    t1 = get_time()
    assert monoworker.submit(lambda: t1)
    assert monoworker.submit(lambda: get_time())
    t2 = get_time()

    assert not (t0 < t1 < t2)
    sys.exit(0)

if __name__ == "__main__":
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:36:40.821639
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
   mono_worker = MonoWorker()
   mono_worker.submit(print, 'Test 0')
   mono_worker.submit(print, 'Test 1')
   mono_worker.submit(print, 'Test 2')
   mono_worker.submit(print, 'Test 3')
   mono_worker.submit(print, 'Test 4')
   mono_worker.submit(print, 'Test 5')
   mono_worker.submit(print, 'Test 6')
   mono_worker.submit(print, 'Test 7')
   mono_worker.submit(print, 'Test 8')
   mono_worker.submit(print, 'Test 9')

# Generated at 2022-06-26 09:36:49.972921
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    # submit(function, args, kwargs)


# Generated at 2022-06-26 09:36:53.190106
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit(func, *args, **kwargs)


# Generated at 2022-06-26 09:37:02.499622
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from random import randint
    from tqdm._utils import _term_move_up
    from tqdm import tqdm
    for _ in tqdm(range(10), desc="Method submit of class MonoWorker"):
        mono_worker = MonoWorker()
        assert len(mono_worker.futures) == 0
        for i in tqdm(range(10)):
            mono_worker.submit(time.sleep, i)
            assert len(mono_worker.futures) == 1
            assert not mono_worker.futures[0].done()
            assert mono_worker.futures[0].running()
        mono_worker.futures[0].result()
        assert mono_worker.futures[0].done()

# Generated at 2022-06-26 09:37:04.459630
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """test method submit"""
    mono_worker_0 = MonoWorker()

# Generated at 2022-06-26 09:37:13.871747
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import choice
    from threading import Event
    from time import sleep

    tqdm_auto.write("")
    tqdm_auto.write("--- Testing submit")
    tqdm_auto.write("")

    def func_0(i):
        sleep(choice([0.1, 0.2, 0.3]))
        return i

    mono_worker_0 = MonoWorker()
    submitted_0 = mono_worker_0.submit(func_0, 0)
    # Cancel submitted_0
    submitted_0.cancel()
    try:
        result = submitted_0.result()
    except Exception:
        pass
    tqdm_auto.write("Submitted 0: {}".format(submitted_0))
    # Submit 0 to mono_worker_0
    mono_worker_0.submit

# Generated at 2022-06-26 09:37:18.112384
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    mono_worker.pool.submit(print, 'hello')
    mono_worker.pool.submit(print, 'world')
    mono_worker.pool.submit(print, 'there')

# Generated at 2022-06-26 09:37:21.394861
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import datetime
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(time.sleep, 5)
    mono_worker_0.submit(random.randint, 5, 8)
    mono_worker_0.submit(datetime.datetime.now, )

# Generated at 2022-06-26 09:37:24.558303
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit()
    mono_worker_0.pool.submit()


# Generated at 2022-06-26 09:37:33.577808
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    _mono_worker = MonoWorker()
    assert(len(_mono_worker.futures) == 0)
    import time
    import os
    def _test_func():
        time.sleep(0.1)
        return os.getpid()
    _futures = [_mono_worker.submit(_test_func) for _ in range(3)]
    assert(len(_mono_worker.futures) == 1)
    assert(_futures[2].result() == _futures[1].result())
    time.sleep(0.1)
    assert(len(_mono_worker.futures) == 0)
    _futures = [_mono_worker.submit(_test_func) for _ in range(3)]

# Generated at 2022-06-26 09:37:43.329100
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random, time
    def wait_time():
        return random.randint(1, 10) / 10.0
    mono_worker_0 = MonoWorker()
    ftr_0 = mono_worker_0.submit(wait_time)
    ftr_1 = mono_worker_0.submit(wait_time)
    ftr_2 = mono_worker_0.submit(wait_time)
    ftr_3 = mono_worker_0.submit(wait_time)
    ftr_4 = mono_worker_0.submit(wait_time)
    time.sleep(1)
    ftr_5 = mono_worker_0.submit(wait_time)
    time.sleep(1)
    ftr_6 = mono_worker_0.submit(wait_time)
    time.sleep(1)
   

# Generated at 2022-06-26 09:38:06.125926
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Initialize Variable mono_worker_0
    mono_worker_0 = MonoWorker()

    # Test Case 0
    mono_worker_0.submit(lambda : None)

# Generated at 2022-06-26 09:38:15.741374
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def submit_test_function(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6,
                             arg_7, arg_8, arg_9):
        return arg_0 * arg_1 * arg_2 * arg_3 * arg_4 * arg_5 * arg_6 * arg_7 * arg_8 * arg_9
    assert mono_worker_0.submit(submit_test_function, arg_0=1, arg_1=2, arg_2=3, arg_3=4, arg_4=5, arg_5=6, arg_6=7, arg_7=8,
                                arg_8=9, arg_9=10).result() == 3628800

# Generated at 2022-06-26 09:38:22.648494
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    test_func = lambda x: x+1
    for i in range(4):
        mono_worker_0.submit(test_func, i)
    for future in mono_worker_0.futures:
        assert future.result() == 3

# Generated at 2022-06-26 09:38:25.383111
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    with tqdm_auto.tqdm(total=1) as tqdm_0:
        mono_worker_0.submit(tqdm_0.update, 1)


# Generated at 2022-06-26 09:38:29.733657
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    # assert mono_worker_0.submit() == <>
    # assert mono_worker_0.submit() == <>


# Generated at 2022-06-26 09:38:40.520108
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import os
    import sys
    import random
    import threading

    if os.name == "posix":
        from time import time as time_time  # noqa
    else:
        from time import clock as time_time  # noqa
    time_sleep = time.sleep
    random_randint = random.randint

    times_current = []
    have_root_progress = False

    if False:
        def time_time():
            times_current.append(time.time())

    if False:
        def time_sleep(secs):
            now = time_time()
            last = times_current[-1] if times_current else now
            times_current.append(last + secs)
            return now


# Generated at 2022-06-26 09:38:49.046066
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    import multiprocessing

    class TestWorker(object):
        def __init__(self, id, l, threshold=3):
            self.id = str(id)
            self.l = l
            self.threshold = threshold

        def __call__(self, *args):
            time.sleep(random.random())
            self.l.append(self.id)
            return self.id

        def __lt__(self, other):
            return random.random() >= self.threshold

    lst = []
    mono_worker = MonoWorker()

    def test_submit(i):
        w = TestWorker(i, lst)
        mono_worker.submit(w)

    threads = []

# Generated at 2022-06-26 09:38:54.455716
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Usage as a context manager (threads are shut down upon exiting)::

        with MonoWorker(...) as mono_worker:
            mono_worker.submit(func, *args, **kwargs)

    """
    mono_worker_0 = MonoWorker()

# Generated at 2022-06-26 09:38:57.917223
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def func_0(*args, **kwargs):
        pass
    mono_worker_0.submit(func_0, )


# Generated at 2022-06-26 09:39:04.568820
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def dummy_func(arg_0):
        return arg_0
    mono_worker_0.submit(dummy_func, 'testing submit method')

# Add to test-suite
test_case_0()
test_MonoWorker_submit()

# Generated at 2022-06-26 09:39:45.202138
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys

    # First test case
    mono_worker_0 = MonoWorker()
    def task(i):
        time.sleep(1)
        return i*i
    assert mono_worker_0.submit(task, 3).result() == 9

    # Second test case
    def task(i):
        time.sleep(1)
        return i*i
    for i in tqdm_auto.trange(5, desc="test_2"):
        futures = mono_worker_0.submit(task, i)

    # Third test case, test cancel
    mono_worker_1 = MonoWorker()
    def task(i, raise_exception=False):
        time.sleep(1)
        if raise_exception:
            raise Exception

        return i*i

# Generated at 2022-06-26 09:39:54.292590
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    # test empty
    assert mono_worker_0.submit(print, 'test case 0') is not None

    # test add another
    assert mono_worker_0.submit(print, 'test case 1') is not None

    # test replace by another
    assert mono_worker_0.submit(print, 'test case 2') is not None
    assert mono_worker_0.submit(print, 'test case 3') is not None

    # test no running task
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(print, 'test case 4')
    mono_worker_0.submit(print, 'test case 5')
    assert mono_worker_0.submit(print, 'test case 6') is not None



# Generated at 2022-06-26 09:39:59.513480
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import RLock
    from concurrent.futures import Future
    from collections import Iterable
    from contextlib import contextmanager
    @contextmanager
    def _wrapper(obj):
        obj_class = obj.__class__
        immediate_base_classes = {obj_class}
        while obj_class.__bases__:
            obj_class = obj_class.__bases__[0]
            if issubclass(obj_class, RLock):
                immediate_base_classes.add(obj_class)
        immediate_base_classes = tuple(immediate_base_classes)
        with obj.__class__.__bases__[0]._release_save(obj):
            yield RLock(*immediate_base_classes)

# Generated at 2022-06-26 09:40:10.645451
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import subprocess
    import os
    import time
    import shutil
    
    class Future(object):
        def __init__(self, file_name, file_content):
            self.file_name = file_name
            self.file_content = file_content
            self.done = False
            self.canceled = False
            
        def cancel(self):
            self.canceled = True
            
        def is_canceled(self):
            return self.canceled

        def done(self):
            return self.done
        
        def set_done(self, done):
            self.done = done
    
    #reset test folder
    file_path = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-26 09:40:19.500263
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from unittest import TestCase
    from unittest.mock import patch
    mono_worker_0 = MonoWorker()
    with patch('tqdm._tqdm.tqdm_write') as _tqdm_write:
        mono_worker_0.submit(func=print, *(), args=[])
        with patch('concurrent.futures.ThreadPoolExecutor.submit'
                   ) as _submit:
            mono_worker_0.submit(func=print, *(), args=[])
            with patch('tqdm.contrib.MonoWorker.futures'
                       ) as _futures:
                mono_worker_0.submit(func=print, *(), args=[])
                _futures.popleft.return_value.done.return_value = True
                mono_worker_

# Generated at 2022-06-26 09:40:24.636379
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_1 = MonoWorker()
    mono_worker_1.submit("tqdm")

if __name__ == '__main__':
    test_case_0()
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:40:30.315170
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # When method submit is called with the arguments func, args, kwargs, where func is defined in a file
    # and is not a wrapper
    def foo(x):
        """Sample function"""
        return x ** 2

    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(foo, 2)
    # The function foo is executed and the result is used
    # When method submit is called with the arguments func, args, kwargs, where func is not defined in a file
    # and is not a wrapper
    mono_worker_0.submit(lambda x: x ** 2, 2)
    # The function func is executed and the result is used
    # When method submit is called with the arguments func, args, kwargs, where func is defined in a file
    # and is a wrapper

# Generated at 2022-06-26 09:40:34.940989
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    for _ in range(100):
        assert mono_worker_0.submit(lambda x: x, 1) is None


# Generated at 2022-06-26 09:40:41.559386
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    assert len(mono_worker_0.futures) == 0
    mono_worker_0_submit_fut_0 = mono_worker_0.submit(lambda: None)
    assert len(mono_worker_0.futures) == 1
    mono_worker_0_submit_fut_1 = mono_worker_0.submit(lambda: None)
    assert len(mono_worker_0.futures) == 2
    mono_worker_0_submit_fut_0.cancel()
    mono_worker_0_submit_fut_1.cancel()
    assert len(mono_worker_0.futures) == 0

# Generated at 2022-06-26 09:40:46.495613
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    print('test_MonoWorker_submit', end='...')
    mono_worker_0 = MonoWorker()
    print('passed')

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-26 09:41:19.148861
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def sleep_rand(n):
        time.sleep(random.random() * n)

    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(sleep_rand, 0.2)


# Generated at 2022-06-26 09:41:21.825021
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()

    test_case_0()

test_MonoWorker_submit()

# Generated at 2022-06-26 09:41:30.722897
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import numpy
    from tqdm import tqdm
    tqdm_auto.write('Testing MonoWorker submit')
    tqdm_auto.write('This test will last about 4 seconds')
    tqdm_auto.write('Generating random numbers...')
    outputs = []
    for i in tqdm(range(1000)):
    #numbers = numpy.random.randint(1,11,size=(10000,10000))
        def sum_rows(numbers):
            return numpy.sum(numbers, axis=0)

        #numbers = numpy.random.randint(1,11,size=(10000,10000))
        mono_worker_test = MonoWorker()
        numbers = numpy.random.randint(1,11,size=(10000,10000))
        future = mono

# Generated at 2022-06-26 09:41:37.337613
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker_0 = MonoWorker()
    def arg_00(x):
        return x
    with ThreadPoolExecutor(max_workers=1) as pool:
        assert mono_worker_0.submit(arg_00, x=1) == pool.submit(arg_00, x=1)

# Generated at 2022-06-26 09:41:43.408820
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from _io import TextIOWrapper
    from concurrent.futures import Future
    from unittest.mock import Mock, patch
    from multiprocessing.dummy import Pool as Pool
    from multiprocessing import Lock
    import tqdm.contrib as tqdm_contrib
    class _MonoWorker:
        def __init__(self):
            self._future_pool = tqdm_contrib.MonoWorker()

        def start(self):
            self.lock_0 = Lock()
            with self.lock_0:
                pass
            self._future_pool.submit(self.lock_0.acquire)
            self._future_pool.submit(self.lock_0.release)

        def stop(self):
            self.lock_0.acquire()
            self.lock

# Generated at 2022-06-26 09:41:45.608085
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    mono_worker.submit()

# Generated at 2022-06-26 09:41:55.715713
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono_worker = MonoWorker()
    assert mono_worker.futures.maxlen==2
    def func(a, b):
        return a+b
    mono_worker.submit(func, 1, 2)
    assert len(mono_worker.futures)==1
    mono_worker.submit(func, 1, 2)
    assert len(mono_worker.futures)==1 # Wont add the new submit because it still working the first one
    mono_worker.futures[0].result() # Wait until task is finished
    mono_worker.submit(func, 1, 2)
    assert len(mono_worker.futures)==1
    mono_worker.submit(func, 1, 2)
    assert len(mono_worker.futures)==1

# Generated at 2022-06-26 09:42:00.217368
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Only testing the argument calling (no return value)."""
    mono_worker_0 = MonoWorker()
    mono_worker_0.submit(lambda _: None, 1)



# Generated at 2022-06-26 09:42:05.439792
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    mono_worker_0 = MonoWorker()
    def f(x):
        time.sleep(random.randint(0,10)/10)
        return x
    t_list=[f(i) for i in range(10)]
    x_list=[mono_worker_0.submit(f,i) for i in range(10)]
    for x in x_list:
        assert x.result()==t_list.pop() # check the result of each x is correct
        assert not x.cancelled() # check each x is not cancelled

# Generated at 2022-06-26 09:42:07.163578
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    test_case_0()

