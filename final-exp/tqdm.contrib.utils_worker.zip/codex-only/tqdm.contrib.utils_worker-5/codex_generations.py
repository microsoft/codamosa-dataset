

# Generated at 2022-06-24 10:01:55.706921
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import subprocess
    from time import sleep
    from threading import Thread
    from concurrent.futures import wait
    from .tgrange import tgrange

    mw = MonoWorker()
    p = subprocess.Popen('ffprobe -i rtsp://admin:admin@192.168.1.88:554/h264/ch1/main/av_stream'
                         # 'ffprobe -i rtsp://admin:admin@192.168.1.88:554/h264/ch1/main/av_stream'
                         , shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    # ffmpeg = mw.submit(p.stdout.read)
    ffmpeg = mw.submit(p.stdout.readline)

# Generated at 2022-06-24 10:02:07.276488
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from datetime import datetime
    def first_func():
        sleep(3)
        return datetime.now()
    def second_func():
        sleep(2)
        return datetime.now()
    def third_func():
        sleep(1)
        return datetime.now()
    def fourth_func():
        sleep(3)
        return datetime.now()
    mw = MonoWorker()
    first_future = mw.submit(first_func)
    second_future = mw.submit(second_func)
    assert(first_future.done())
    assert(not second_future.done())
    third_future = mw.submit(third_func)
    assert(not first_future.done())
    assert(not second_future.done())

# Generated at 2022-06-24 10:02:16.694774
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def wait():
        time.sleep(0.1)

    with MonoWorker() as mono:
        mono.submit(wait)
        mono.submit(wait)
        mono.submit(wait)
        mono.submit(wait)
        # Now: [running, waiting, discarded, discarded]
        mono.submit(wait)
        # Now: [waiting, discarded, discarded, discarded]
        mono.submit(wait)
        # Now: [waiting, cancelled, discarded, discarded]
        mono.submit(wait)
        # Now: [waiting, discarded, discarded, discarded]
        mono.submit(wait)
        # Now: [waiting, cancelled, discarded, discarded]


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:02:22.867243
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def time_inc():
        time.sleep(1)
        return tqdm_auto.tqdm(list(range(5)))
    mw = MonoWorker()
    running = mw.submit(time_inc)
    # replaces waiting task
    waiting = mw.submit(time_inc)
    # doesn't replace running task
    mw.submit(time_inc)
    running.result()
    waiting.result()

# Generated at 2022-06-24 10:02:34.825016
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # pylint: disable=W0212
    from os import getpid
    from time import sleep
    from concurrent.futures import TimeoutError

    def task():
        sleep(1)
        return getpid()
    mw = MonoWorker()
    pid = task()
    assert pid == mw.pool._workers.worker_list()[0].pid  # sanity check
    assert pid == mw.submit(task).result(timeout=2)  # 1 sec for task
    try:
        mw.submit(task).result(timeout=0.5)
        assert False  # should timeout
    except TimeoutError:
        pass
    mw.submit(task).result(timeout=2)  # 1 sec + new task

if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:02:41.434340
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()

    def sleep_print(t):
        """Example function that sleeps for `t` seconds."""
        time.sleep(t)
        print("I slept for %s seconds." % t)

    t1 = mw.submit(sleep_print, 1)
    t2 = mw.submit(sleep_print, 2)
    t3 = mw.submit(sleep_print, 3)
    t4 = mw.submit(sleep_print, 4)

    for future in (t1, t2, t3, t4):
        future.result()


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:02:44.336479
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()
    assert True

# Generated at 2022-06-24 10:02:46.870366
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker"""
    worker = MonoWorker()
    assert worker.pool is not None
    assert worker.futures is not None



# Generated at 2022-06-24 10:02:57.982320
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import multiprocessing as mp
    import threading as th
    from queue import Queue, Empty
    from concurrent.futures import ThreadPoolExecutor as PoolExecutor
    import numpy as np
    n_proc = mp.cpu_count()

# Generated at 2022-06-24 10:03:04.443875
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Make sure it waits and discards waiting if running."""
    def f(x):
        return x
    worker = MonoWorker()
    assert worker.submit(f, 1) == worker.submit(f, 1)
    assert worker.submit(f, 2).result() == 2
    assert worker.submit(f, 3) is None

# Generated at 2022-06-24 10:03:11.684891
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import random
    from threading import Lock
    from multiprocessing.dummy import Pool

    def sleep(t):
        time.sleep(t)
        return t

    def sleep_faster(t):
        return sleep(t / 10.0)

    def sleep_random(t):
        return sleep(t * random())

    def sleep_until(t, until):
        while time.time() < until:
            time.sleep(t)
        return t

    def test_func(func, *args, **kwargs):
        """Test a function"""
        worker = MonoWorker()
        lock = Lock()

# Generated at 2022-06-24 10:03:21.018350
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    try:
        import builtins
        input = getattr(builtins, 'raw_input', input)
    except (ImportError, AttributeError):
        pass
    from concurrent.futures import TimeoutError
    from .test_environ import idx_test_environ, test_environ

    def foo(idx=0, block=True):
        print('Starting {}'.format(idx))
        if block:
            input('Press enter to terminate:')
        print('Terminating {}'.format(idx))
        return idx

    with test_environ():
        mw = MonoWorker()
        f1 = mw.submit(foo, 1)
        f2 = mw.submit(foo, 2)
        f3 = mw.submit(foo, 3)
        f4 = mw.submit

# Generated at 2022-06-24 10:03:29.534573
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    try:
        assert mw.submit(time.sleep, 0.1).result() is None
    except Exception as e:
        tqdm_auto.write(str(e))
    try:
        assert mw.submit(time.sleep, 0.1).result() is None
    except Exception as e:
        tqdm_auto.write(str(e))
    try:
        assert mw.submit(time.sleep, 0.1).result() is None
    except Exception as e:
        tqdm_auto.write(str(e))
    try:
        assert mw.submit(time.sleep, 0.1).result() is None
    except Exception as e:
        tqdm_auto.write(str(e))

# Generated at 2022-06-24 10:03:35.775092
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def f():
        time.sleep(1)

    mw = MonoWorker()
    f1 = mw.submit(f)
    f2 = mw.submit(f)
    f3 = mw.submit(f)

    assert f2 == f3
    assert f1 is None
    assert f2.result() is None

# Generated at 2022-06-24 10:03:36.864180
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """TODO"""
    pass

# Generated at 2022-06-24 10:03:46.095243
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    from concurrent.futures import as_completed
    class Running(object):
        def __init__(self):
            self.stop = Event()
        def do(self):
            while not self.stop.is_set():
                time.sleep(0.1)
    def func(arg):
        time.sleep(0.2)
        return 'arg: {}'.format(repr(arg))
    def wait(future):
        return future.result(timeout=0.5)

    mw = MonoWorker()
    running = Running()
    mw.submit(running.do)
    wait(mw.submit(func, '1'))
    wait(mw.submit(func, '2'))
    wait(mw.submit(func, '3'))

# Generated at 2022-06-24 10:03:53.056613
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    > python -m tqdm.contrib.concurrent.MonoWorker test_MonoWorker_submit
    """
    import time
    from random import random
    def func(a, kw=0):
        # print('func({}, {}) starting'.format(a, kw))  # optional
        for _ in tqdm_auto(range(int(2 + 3 * random()))):
            time.sleep(1 + 2 * random())
        # print('func({}, {}) returning'.format(a, kw))  # optional
        return a + kw
    worker = MonoWorker()
    fut = worker.submit(func, 5, kw=1)
    for _ in tqdm_auto(range(10)):
        worker.submit(func, 3 + random())
        time.sleep

# Generated at 2022-06-24 10:04:00.976598
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from concurrent.futures import Future
    from time import sleep
    from .test_utils import ThreadWithReturnValue

    def sleep_sort(n):
        sleep(n)
    sleep_sort_thread = ThreadWithReturnValue(target=sleep_sort)

    tqdm_auto.write("Single thread test:")
    mono = MonoWorker()
    sleep_sort_thread.start(0.5)
    sleep_sort_thread.join()
    tqdm_auto.write('Result: {}'.format(sleep_sort_thread.return_value))

    tqdm_auto.write("\nMultiple thread test:")
    mono = MonoWorker()
    f1 = mono.submit(sleep_sort, 0.5)
    f2 = mono.submit(sleep_sort, 0.3)
    f3 = mono

# Generated at 2022-06-24 10:04:09.841779
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import os
    from time import sleep
    from multiprocessing import cpu_count
    from multiprocessing.pool import ThreadPool
    from random import random
    from .tqdm_test_classes import ReliableTimer
    from .tqdm_pandas import trange

    def dummy(x):
        """Sleep for `x` secs and return `x`"""
        sleep(x)
        return x

    def dummy_exc(x):
        """Raise an exception after `x` secs"""
        sleep(x)
        raise RuntimeError("dummy error")

    def dummy_error(x):
        """Sleep for `x` secs, raise an exception and return `x`"""
        sleep(x)
        raise RuntimeError("dummy error")
        return x


# Generated at 2022-06-24 10:04:22.110574
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from ..utils import ThreadWithExc

    start = Event()  # for synchronization
    mono = MonoWorker()
    fin = Event()

    def mono_func(delay, log):
        """Target function for testing."""
        start.wait()
        sleep(delay)
        tqdm_auto.write(log)

    def test_function(delay, values, description='test'):
        """Test function to test_MonoWoker_submit."""
        with tqdm_auto(total=len(values), desc=description) as t:
            for value in values:
                start.set()
                waiting = mono.submit(mono_func, delay, value)
                waiting.add_done_callback(t.update)
                start.clear()

# Generated at 2022-06-24 10:04:30.382254
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> from time import sleep
    >>> i = [0]
    >>> def inc():
    ...     sleep(0.5)
    ...     from pprint import pprint
    ...     pprint(i[0])
    ...     i[0] += 1
    >>> w = MonoWorker()
    >>> w.submit(inc)
    >>> w.submit(inc)
    >>> w.submit(inc)
    >>> w.submit(inc)
    >>> w.submit(inc)
    >>> w.submit(inc)
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

    test_MonoWorker()

    print('Done')

# Generated at 2022-06-24 10:04:40.737213
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import warnings
    import unittest

    class TestThreadPoolExecutor(ThreadPoolExecutor):
        def __init__(self):
            super(TestThreadPoolExecutor, self).__init__(max_workers=1)
            self.test_queue = deque()

        def submit(self, func, *args, **kwargs):
            future = ThreadPoolExecutor.submit(self, func, *args, **kwargs)
            self.test_queue.append(future)
            return future

    class TestMonoWorker(MonoWorker):
        def __init__(self, *args, **kwargs):
            super(TestMonoWorker, self).__init__(*args, **kwargs)
            self.pool = TestThreadPoolExecutor()

    class TestError(Exception):
        pass



# Generated at 2022-06-24 10:04:49.572058
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .test_data import time, time_list, mp_print

    @time
    def test_func(*args, **kwargs):
        return time_list(3, *args, **kwargs)

    dic = dict(desc="MonoWorker", leave=False, dynamic_ncols=True)
    worker = MonoWorker()  # init
    mp_print("testing `MonoWorker().submit`")
    with tqdm_auto(total=1, **dic) as pbar:  # init
        worker.submit(test_func, pbar, "hello", "world")  # submit
        pbar.update()
    with tqdm_auto(total=1, **dic) as pbar:  # init
        worker.submit(test_func, pbar, "hello", "world") 

# Generated at 2022-06-24 10:04:54.918407
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import threading
    from ..auto import tqdm

    def run_threads(threads):
        with tqdm(total=len(threads)) as pbar:
            for t in threads:
                t.start()
                time.sleep(random.random()/10)
                pbar.update()

    def wait_for_threads(threads):
        for t in threads:
            t.join()

    def test_thread(thread_name, value):
        time.sleep(value)
        tqdm.write(thread_name)

    for _ in range(10):
        threads = []

# Generated at 2022-06-24 10:05:02.610238
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import tqdm.contrib.test_utils.common as tc
    with tc.captured_output() as (out, _):
        mw = MonoWorker()
        mw.submit(time.sleep, 0.75)
        time.sleep(0.1)
        mw.submit(time.sleep, 0.15)
        time.sleep(0.1)
        mw.submit(time.sleep, 0.5)
        time.sleep(0.1)
        mw.submit(time.sleep, 0.25)
        time.sleep(0.1)
        mw.submit(sum, (1, 2, 3))
        time.sleep(0.1)
        mw.submit(lambda: None)
        time.sleep(0.1)

# Generated at 2022-06-24 10:05:04.517596
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()

test_MonoWorker()

# Generated at 2022-06-24 10:05:14.760935
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    from multiprocessing import cpu_count
    from ..utils import FormatCustomTextTest
    old_cpu_count = cpu_count()

# Generated at 2022-06-24 10:05:17.978099
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()
    return (m.pool.max_workers == 1) & (m.futures.maxlen == 2)

# Generated at 2022-06-24 10:05:29.663913
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import unittest
    from unittest.mock import MagicMock

    def future_func(a, b, c=1, d=2):
        """This function is the one passed to the thread pool to test
        the non-blocking nature of the pool. It includes keywords as
        they are passed to the submit method of ThreadPoolExecutor
        object.
        """
        time.sleep(1)
        return a, b, c, d

    class TestClass(unittest.TestCase):
        """Unit tests for the MonoWorker class"""
        def test_submit_1(self):
            """general test for submit method"""
            mworker = MonoWorker()
            mworker.pool.submit = MagicMock(return_value=1)

# Generated at 2022-06-24 10:05:33.876490
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time  import sleep
    from random import randint
    mw = MonoWorker()
    ms = [mw.submit(sleep, randint(1, 10)) for _ in range(4)]
    for m in ms:
        print(m.result())
    print(repr(ms))

# Generated at 2022-06-24 10:05:44.414959
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import TimeoutError
    from itertools import count
    from random import randint
    from time import sleep

    N = 10
    M = 2
    worker = MonoWorker()
    for num in count():
        if num >= N:
            break
        if len(worker.futures) < M:
            worker.submit(sleep, randint(0.5, 2.5))
        try:
            running = worker.futures.popleft().result(timeout=0.1)
        except TimeoutError:
            worker.futures.appendleft(running)
            sleep(0.1)  # let it run a little longer
        except Exception as e:
            tqdm_auto.write(str(e))
    assert len(worker.futures) == 0

# Generated at 2022-06-24 10:05:54.105349
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep


# Generated at 2022-06-24 10:05:55.126038
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert len(worker.futures) == 0



# Generated at 2022-06-24 10:05:59.491750
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    '''
    def f(a, b=2):
        sleep(0.01)
        return (a, b)
    worker = MonoWorker()
    assert worker.submit(f, 1)
    '''

# Generated at 2022-06-24 10:06:08.252894
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor `MonoWorker`."""
    from . import tqdm as tqdm_contrib
    import time

    with tqdm_contrib.MonoWorker() as pool:
        for i in tqdm_auto.tqdm(range(4), unit='B', unit_scale=False):
            time.sleep(i)
            pool.submit(tqdm_auto.write, str(i), end=' ')

    with tqdm_contrib.MonoWorker() as pool:
        for i in tqdm_auto.tqdm(range(3), unit='B', unit_scale=False):
            time.sleep(i)
            pool.submit(tqdm_auto.write, str(i))
            time.sleep(i)

# Generated at 2022-06-24 10:06:11.395161
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import threading
    import time
    def wait(i):
        time.sleep(1)
        print("[{}] Done!".format(i))
    m = MonoWorker()
    for i in range(4):
        m.submit(wait, i)
    print("Done!")

# Generated at 2022-06-24 10:06:19.656479
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import time
    import multiprocessing
    from ..auto import tqdm as tqdm_auto

    def func(arg1):
        time.sleep(2)
        return arg1

    output_ = sys.stdout

# Generated at 2022-06-24 10:06:20.617213
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()


# Generated at 2022-06-24 10:06:27.634318
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .tests_class import discards_maxlen
    import sys

    kwargs = {}
    if sys.version_info.major >= 3:  # use timeout for Python3
        import concurrent.futures.process as thread_futures
        kwargs['timeout'] = 1

    # basic
    mw = MonoWorker()
    mw.submit(sleep, 2)
    sleep(0.5)
    mw.submit(sleep, 0.1)
    try:
        mw.submit(sleep, 0.1, **kwargs)
    except Exception as e:
        pass
    else:
        raise RuntimeError("did not expect previous submit to succeed")
    sleep(1.1)

# Generated at 2022-06-24 10:06:35.283209
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from concurrent.futures import Future
    from unittest import TestCase

    class TC(TestCase):
        def test_submit(self):
            def bad_func(*args, **kwargs):
                raise Exception('bad')

            def good_func(*args, **kwargs):
                pass

            worker = MonoWorker()
            self.assertFalse(worker.futures)
            bad_future = worker.submit(bad_func)
            self.assertIsInstance(bad_future, Future)
            self.assertTrue(bad_future.done())
            self.assertFalse(bad_future.cancelled())
            self.assertRaises(Exception, bad_future.result)
            self.assertTrue(worker.futures)
            good_future = worker.submit(good_func)

# Generated at 2022-06-24 10:06:37.898280
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 10:06:46.352159
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def f(x):
        sleep(x)
        return x

    mw = MonoWorker()
    s = mw.submit(f, 1)
    assert (not s.done())
    s = mw.submit(f, 0.5)  # (re-)sets waiting
    assert (not s.done())
    s = mw.submit(f, 0.8)  # (re-)sets waiting
    assert (not s.done())
    s.result()
    assert (s.result() == 0.8)
    s = mw.submit(f, 0.2)  # (re-)sets waiting
    assert (not s.done())
    s.result()
    assert (s.result() == 0.2)
    # ~ print('~done~')



# Generated at 2022-06-24 10:06:55.141256
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from sys import platform
    from random import randint

    class Z(object):
        def __init__(self):
            self.i = 0

        def j(self):
            self.i += 1
            sleep(0.1)
            return self.i

    z = Z()
    if platform == "win32":
        import time
        time.clock()

    def _submit(z):
        mw.submit(z.j)

    def _test(mono, z):
        z.i = 0
        for i in range(100):
            mono.submit(z.j)
            # print('\r', z.i, flush=True, end='')
            sleep(randint(1, 5) / 50)
        assert z.i == 1

    mw = MonoWork

# Generated at 2022-06-24 10:07:05.320862
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from collections import Counter
    from .utils import assert_eq, assert_issubclass
    from threading import Event
    from concurrent.futures import CancelledError

    class _MonoWorker(MonoWorker):
        def __init__(self):
            self.waiting_count = Counter()
            self.running_count = Counter()
            self.waiting_event = Event()
            super(_MonoWorker, self).__init__()

        def new_waiting(self):
            self.waiting_count += Counter()
            self.waiting_event.set()

        def new_running(self):
            self.running_count += Counter()
            self.waiting_event.clear()

        def submit(self, func, *args, **kwargs):
            self.new_

# Generated at 2022-06-24 10:07:16.635342
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading
    from collections import OrderedDict

    class WorkerThread(threading.Thread):
        def __init__(self, d):
            threading.Thread.__init__(self)
            self.d = d

        def run(self):
            time.sleep(self.d)

    m = MonoWorker()
    o = OrderedDict()
    for n in [5, 4, 3, 2]:
        wt = WorkerThread(n)
        wt.start()
        m.submit(wt.join)
        o[wt] = n
    time.sleep(2)
    m.submit(time.sleep, 3)
    time.sleep(10)
    while len(m.futures):
        assert m.futures.popleft().done()

# Generated at 2022-06-24 10:07:18.112298
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    '''Run test_MonoWorker'''
    foo = MonoWorker()
    print(foo)

# Generated at 2022-06-24 10:07:27.606809
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def square(x):
        time.sleep(1)
        return x**2

    worker = MonoWorker()
    future = worker.submit(square, 5)
    assert future.result() == future.result()
    assert not future.cancel()
    assert future.result() == 25

    future = worker.submit(square, 4)
    assert future.result() == future.result()
    assert not future.cancel()
    assert future.result() == 16

    # TODO: add test for cancelling waiting task (how?)

# Generated at 2022-06-24 10:07:35.704667
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from timeit import Timer
    from .utils import print_err, TEST_FILE
    from .pandas import tqdm_pandas
     
    try:
        import pandas as pd
    except ImportError:
        return  # skip test

    def test():
        def sleep(n):
            import time
            time.sleep(n)

        def f0(n):
            sleep(n)
            return n

        def f1(n):
            sleep(n)
            return 100

        with open(TEST_FILE, 'w'):
            pass

        # test clearing and overwriting
        worker = MonoWorker()
        worker.submit(f0, 0.5)
        worker.submit(f0, 0.5)

        # test waiting for the previous task

# Generated at 2022-06-24 10:07:40.570822
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from numpy.random import rand
    from ..utils import _term_move_up
    tqdm_len = len

    pool = MonoWorker()
    for _ in tqdm_auto.trange(10, disable=True):
        ftr = pool.submit(time.sleep, rand() / 20.)
        assert ftr.done() or len(pool.futures) <= 1
        _term_move_up()

# Generated at 2022-06-24 10:07:46.677658
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing import Pool
    from .utils import FormatMessages

    with FormatMessages() as fm:
        with tqdm_auto.tqdm(total=3) as t:
            with Pool(3) as pool:
                MonoWorker().submit(
                    pool.map, lambda x: t.update(), range(3))

    assert fm.messages == ['0/3', '1/3', '2/3']

# Generated at 2022-06-24 10:07:53.207613
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    x = 0
    mw = MonoWorker()
    t = threading.Thread(target=lambda: mw.submit(time.sleep, 3), daemon=True)
    t.start()
    t = threading.Thread(target=lambda: mw.submit(lambda: setattr(x, 'x', 1)),
                         daemon=True)
    t.start()
    t.join()
    assert x.x == 1

# Generated at 2022-06-24 10:07:56.711170
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert not worker.futures


# Generated at 2022-06-24 10:08:05.373412
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random

    def long_sleep(t):
        time.sleep(t)
        return t

    sleep_times = [random.uniform(0.1, 1) for _ in range(5)]

    mw = MonoWorker()

    assert len(mw.futures) == 0

    # Run a few tasks
    results = []
    for sleep_time in sleep_times:
        results.append(mw.submit(long_sleep, sleep_time))

    assert len(mw.futures) == 1

    # Wait for the tasks and verify that only the most recent task is retained
    t = 0
    for sleep_time, result in zip(sleep_times, results):
        t += sleep_time
        assert result.result() == sleep_time

# Generated at 2022-06-24 10:08:13.665266
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:08:23.462411
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def _test_monoworker(num_submit, num_call, sleep_duration):
        from sys import executable
        from signal import SIGINT
        from random import choice
        from subprocess import Popen
        from time import time
        from signal import signal, SIGALRM, alarm

        print()
        print("-" * 80)
        print("Testing mono worker (n_submit={0}, n_call={1},"
              " sleep_duration={2})".format(num_submit, num_call,
                                            sleep_duration))
        print("-" * 80)

        def timeout(*args, **kwargs):
            print("Timeout: force quit")
            exit(1)

        def run_calls(p):
            assert p < num_call
            m = MonoWorker()

            def f():
                start

# Generated at 2022-06-24 10:08:29.369640
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    try:
        import queue
    except ImportError:
        import Queue as queue

    tasks = queue.Queue()
    with MonoWorker() as worker:
        for i in range(5):
            tasks.put_nowait(i)
        prev_waiting = None
        while 1:
            try:
                i = tasks.get(False)
            except queue.Empty:
                if prev_waiting is None:
                    break
                prev_waiting.result()
                prev_waiting = None
            else:
                prev_waiting = worker.submit(time.sleep, 0.1)
                worker.submit(tasks.put_nowait, i-1)


# Generated at 2022-06-24 10:08:39.173117
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    executor = MonoWorker()
    done_futures = []
    def test_fn_done(*args):
        done_futures.append(args)

    def test_fn(arg1, arg2, arg3):
        sleep(arg1)
        return (arg1, arg2, arg3)
    futures = [executor.submit(test_fn, 0.2, -i, i) for i in range(3)]

    futures.append(executor.submit(test_fn, 0.1, 2, 1))
    assert not futures[0].done()
    assert not futures[1].done()
    assert     futures[2].done()
    assert     futures[3].done()

    assert not len(done_futures)

# Generated at 2022-06-24 10:08:43.653025
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from queue import Queue
    m = MonoWorker()
    q = Queue()
    for i in range(4):
        m.submit(sleep, 0.1)
        sleep(0.05)
        m.submit(q.put, i)
    for i in range(4):
        assert q.get() == i
    # noinspection PyUnreachableCode
    assert False, "This line shouldn't be reachable"

# Generated at 2022-06-24 10:08:48.101463
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()
    assert mw.pool is not None
    assert mw.futures is not None
    f = mw.submit(time.sleep, 1e-6)
    assert f is not None

# Generated at 2022-06-24 10:08:52.898233
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def status(phase):
        time.sleep(1)
        return "{} finished".format(phase)
    mw = MonoWorker()
    mw.submit(status, "A")
    mw.submit(status, "B")
    print(mw.futures[0].result())
    mw.submit(status, "C")
    print(mw.futures[0].result())
    mw.submit(status, "D")
    print([f.result() for f in mw.futures])

# Generated at 2022-06-24 10:08:57.678173
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def my_func():
        """This function does nothing."""
    w = MonoWorker()
    w.submit(my_func)
    w.submit(my_func)
    w.submit(my_func)
    print("Tests pass!")

if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:09:03.951589
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from collections import deque

    def worker(second):
        time.sleep(second)
        return second

    work_to_do = deque([1, 2, 3, 4, 5, 6, 7, 8])
    worker_thread = MonoWorker()

    def worker_callback(future):
        tqdm_auto.write("Worker finished {}".format(future.result()))

    while len(work_to_do):
        future = worker_thread.submit(worker, work_to_do.popleft())
        future.add_done_callback(worker_callback)
        time.sleep(0.5)

# Generated at 2022-06-24 10:09:09.701576
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test method `submit` of class MonoWorker."""
    from threading import current_thread, Thread
    from time import sleep

    def get_thread_id():
        try:
            return current_thread().ident
        except AttributeError:  # Python < 3.4
            return current_thread().name

    def do_nothing(sleep_time):
        return get_thread_id(), sleep(sleep_time)

    mw = MonoWo

# Generated at 2022-06-24 10:09:20.002658
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from functools import wraps
    def do_nothing(*args, **kwargs):
        pass
    def sleep_then_do_nothing(*args, **kwargs):
        sleep(0.1)
    @wraps(do_nothing)
    def slow_do_nothing(*args, **kwargs):
        sleep(0.1)
        do_nothing(*args, **kwargs)
    m = MonoWorker()
    for func, num in ((do_nothing, 2), (sleep_then_do_nothing, 4),
                      (slow_do_nothing, 6), (sleep_then_do_nothing, 8),
                      (do_nothing, 10), (sleep_then_do_nothing, 12)):
        for i in range(1, num, 2):
            m.submit(func, i)


# Generated at 2022-06-24 10:09:22.783393
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .tests import asyncio
    from .tests.utemplate import ut_MonoWorker
    ut_MonoWorker(MonoWorker(), asyncio.new_event_loop())

# Generated at 2022-06-24 10:09:30.416067
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    from time import sleep
    from concurrent.futures import CancelledError

    m = MonoWorker()

    def wait(t=1.0, r=None):
        sleep(t)
        if r is not None:
            return r

    def fail(t=0.1):
        sleep(t)
        raise RuntimeError("fail")

    # Wait for the pool to delete
    submit_return = m.submit(lambda: None)
    assert submit_return is None
    m.futures.popleft().result()

    # Submit, wait, cancel previous wait
    submit_return = m.submit(wait, 2.0, 2)
    previous_wait = m.futures.popleft()
    assert not previous_wait.done()

# Generated at 2022-06-24 10:09:38.175729
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test for constructor of class MonoWorker"""
    from . import MonoWorker
    import sys

    def func(string):
        print("Inside thread", file=sys.stderr)
        print("Inside thread", flush=True)
        print("Inside thread")
        print("Inside thread", end='')
        print("Inside thread", file=sys.stdout)

    worker = MonoWorker()
    for i in range(10):
        worker.submit(func, "test")
    worker.pool.shutdown(wait=True)


# Generated at 2022-06-24 10:09:46.758056
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    with MonoWorker() as mw:
        func1_id = id(lambda: None)
        func2_id = id(lambda: None)
        func3_id = id(lambda: None)
        func4_id = id(lambda: None)
        # func1, 2, 3 are running in order
        func1 = mw.submit(func1_id)
        assert func1_id == func1.result()
        func2 = mw.submit(func2_id)
        assert func2_id == func2.result()
        func3 = mw.submit(func3_id)
        assert func3_id == func3.result()
        # but now func4 is waiting
        func4 = mw.submit(func4_id)
        assert func4.result() == func4_id

# Generated at 2022-06-24 10:09:57.714973
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import logging
    logging.basicConfig(
        format="%(asctime)s %(levelname)-8s %(message)s",
        level=logging.INFO,
        datefmt="%H:%M:%S",
    )

    def dummy_func(i, delay):
        logging.info('{} started'.format(i))
        time.sleep(delay)
        logging.info('{} done'.format(i))

    w = MonoWorker()
    w.submit(dummy_func, '1', 2)
    w.submit(dummy_func, '22', 1)
    w.submit(dummy_func, '333', 4)

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:10:07.462650
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import re
    import sys
    import time

    lines = []
    in_ = lines.append
    out = sys.stdout
    if hasattr(out, 'getvalue'):
        out = out.getvalue()
        in_ = out.append
    print_ = lines.append

    def write(s):
        print_(s, end='')

    def slow_action(i, n):
        time.sleep(i)
        n.update()
        time.sleep(n.total - 2 * i)

    n = tqdm_auto(desc='A', total=10)
    m = tqdm_auto(desc='B', total=10)
    test = MonoWorker()
    test.submit(slow_action, 5, n)
    test.submit(slow_action, 2, m)


# Generated at 2022-06-24 10:10:12.636499
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    import random
    import time

    def func(n):
        time.sleep(random.uniform(0.1, 0.3))
        return n

    m = MonoWorker()
    l = list()

    for i in range(10):
        future = m.submit(func, i)
        if future:
            l.append(future)

    for future in l:
        print(future.result())



# Generated at 2022-06-24 10:10:21.478455
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import os
    import sys
    with open(os.devnull, 'wb') as devnull:
        sys.stderr = devnull
    def sleeper(num, delay):
        time.sleep(delay)
        return num
    worker = MonoWorker()
    # 1. Submitting a task is successful and does not raise an error
    wait1 = worker.submit(sleeper, 1, 1)
    assert wait1.done()
    # 2. When a running task is submitted, the task is replaced
    wait2 = worker.submit(sleeper, 2, 0.5)
    time.sleep(0.6)  # delay to finish wait2 before wait1
    assert wait1.result() == 2
    assert wait2.done()
    # 3. When a waiting task is submitted, the task is replaced
    wait

# Generated at 2022-06-24 10:10:27.607859
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import requests
    from . import tqdm

    def bg(url, t):
        time.sleep(t)
        return len(requests.get(url).content)

    mw = MonoWorker()

    for i in tqdm.tqdm(range(3), desc='test'):
        t = i / 10
        f = mw.submit(bg, 'http://google.com', t)
        if f.done():
            # website content is cached locally
            tqdm.write('bg({0:.1f}) = {1}'.format(t, f.result()))



# Generated at 2022-06-24 10:10:29.835583
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Unit test for constructor of class MonoWorker.
    """

    # Instantiate a MonoWorker
    mono = MonoWorker()

    # Call the MonoWorker
    mono.submit(print, 'hello world')

# Generated at 2022-06-24 10:10:38.355262
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    from threading import Event

    n = 5
    seen, iid = set(), 0
    stopevt = Event()

    def task(i, tt):
        time.sleep(tt)
        seen.add(i)

    worker = MonoWorker()
    while len(seen) < n and not stopevt.is_set():
        worker.submit(task, iid, random.random())
        iid += 1
        time.sleep(.1)
    stopevt.set()
    worker.pool.shutdown(wait=True)
    assert seen == set(range(n))



# Generated at 2022-06-24 10:10:43.652394
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    import time
    def foo():
        time.sleep(1)
        return 1
    def bar():
        time.sleep(1)
        raise Exception('failed')
    mw.submit(foo)
    time.sleep(0.5)
    f = mw.submit(bar)
    time.sleep(1.5)
    assert f.running()



# Generated at 2022-06-24 10:10:54.812879
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import time
    from multiprocessing import cpu_count
    from random import randint

    def simulate_task(t):
        time.sleep(t)
        return t

    timeout = 1
    num_tasks = num_cpus = cpu_count()
    worker = MonoWorker()
    ts = [randint(0.7, 1.3) for _ in range(num_tasks)]
    print("Simulating {} tasks of length in range ({}, {}) and timeout {}"
          " on {} cores".format(
              num_tasks, min(ts), max(ts), timeout, num_cpus))

    running_tasks = []
    for t in ts:
        worker.submit(simulate_task, t)
        # After timeout seconds, the second

# Generated at 2022-06-24 10:11:06.215510
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker."""
    import time

    def function(msg):
        time.sleep(0.1)
        print(msg)

    print('--')
    worker = MonoWorker()
    worker.submit(function, 'submited 1')
    time.sleep(0.05)
    worker.submit(function, 'submited 2')
    time.sleep(0.05)
    worker.submit(function, 'submited 3')
    worker.futures[1].result(timeout=0.2)
    worker.shutdown()
    print('--')

    print('--')
    worker = MonoWorker()
    worker.submit(function, 'submited 1')
    time.sleep(0.05)

# Generated at 2022-06-24 10:11:16.370232
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:11:26.520361
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def do_task(t):
        return t
    tqdm_auto.write(MonoWorker().submit(do_task, 't1'), end='')
    tqdm_auto.write(' ')
    tqdm_auto.write(MonoWorker().submit(do_task, 't2'), end='')
    tqdm_auto.write(' ')
    tqdm_auto.write(MonoWorker().submit(do_task, 't3'), end='')
    tqdm_auto.write(' ')
    tqdm_auto.write(MonoWorker().submit(do_task, 't4'), end='')
    tqdm_auto.write(' ')

if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:11:36.843539
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import random, time

    def slow_square(x):
        time.sleep(0.5 * random.random())
        return x ** 2

    mw = MonoWorker()
    for i in [0, 1, 2]:
        mw.submit(slow_square, i)
        time.sleep(0.05)

    for i in range(3):
        print(mw.futures.pop().result())  # should be 2, 1, 0

    for i in [0, 1, 2, 3, 4, 5]:
        mw.submit(slow_square, i)
        time.sleep(0.1)

    for i in range(3):
        print(mw.futures.pop().result())  # should be 5, 4, 3

# Generated at 2022-06-24 10:11:45.238695
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def foo(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(foo, 1)
    mw.submit(foo, 2)
    mw.submit(foo, 3)
    mw.submit(foo, 4)
    mw.submit(foo, 5)
    mw.submit(foo, 6)

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:11:56.713703
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Tests thread scheduler.
    """
    class Task(object):
        def __init__(self, idx, delay=.01):
            self.idx = idx
            self.delay = delay

        def __call__(self, *args, **kwargs):
            import time
            time.sleep(self.delay)
            return self.idx

    mt = MonoWorker()

    task1 = Task(1, delay=.3)
    future1 = mt.submit(task1)
    assert not future1.done()

    task2 = Task(2, delay=.1)
    future2 = mt.submit(task2)
    assert not future2.done()
    assert future1.cancel()
    assert not future1.done()
    assert future2.done()