

# Generated at 2022-06-24 10:01:49.418647
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def test_func(a, b, c=None):
        return a, b, c
    mono = MonoWorker()
    assert len(mono.futures) == 0
    future = mono.submit(test_func, 0, 1, c=2)
    assert len(mono.futures) == 1
    assert future == mono.futures[-1]
    assert future is not None
    assert future.done() is False


# Generated at 2022-06-24 10:01:52.181434
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Unit test for method submit of class MonoWorker
    """
    import time

    mw = MonoWorker()

    def func():
        time.sleep(0.1)
        return True

    assert all([mw.submit(func) for _ in range(4)])



# Generated at 2022-06-24 10:01:56.967973
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    for i in range(4):
        mwrk = MonoWorker()



# Generated at 2022-06-24 10:02:07.080601
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Example testing function for method submit of class MonoWorker
    """
    def func1(a=0, b=0):
        """Example function func1"""
        return a + b
    def func2(a=0, b=0):
        """Example function func2"""
        return a - b

    my_mono_worker = MonoWorker()
    future1 = my_mono_worker.submit(func1, a=5, b=10)
    assert func1(5, 10) == future1.result()
    future2 = my_mono_worker.submit(func2, a=20, b=10)
    assert func2(20, 10) == future2.result()

# Generated at 2022-06-24 10:02:14.700475
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..auto import trange
    mw = MonoWorker()

    def job(name, sleep_secs=0.1):
        print("{}: start".format(name))
        sleep(sleep_secs)
        print("{}: end".format(name))

    for _ in trange(4):
        mw.submit(job, "job1")  # let's submit forever!
    for f in mw.futures:
        f.result()


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:02:20.163491
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def func(value, sleep_):
        sleep(sleep_)
        return value

    worker = MonoWorker()
    max_ = 10
    val = 1
    for i in range(max_):
        worker.submit(func, val, 0.1)
        val += 1
    sleep(0.3)
    assert worker.futures[-1].done()
    assert worker.futures[-1].result() == max_

# Generated at 2022-06-24 10:02:27.421841
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import _range, format_sizeof

    mw = MonoWorker()
    f1 = mw.submit(format_sizeof, _range(1, 0))
    f2 = mw.submit(format_sizeof, _range(1, 0))
    f3 = mw.submit(format_sizeof, _range(1, 0))
    assert f1.done() and (f1.cancelled() or f1.exception())


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:02:34.853799
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test `MonoWorker.submit`."""
    from time import sleep

    def f(x):
        sleep(x)
        return x

    t = MonoWorker()  # test object
    r = t.submit(f, 1)  # test case
    assert r.result() == 1  # test result
    r = t.submit(f, 2)  # test case
    assert r.result() == 2  # test result
    r = t.submit(f, 3)  # test case
    assert r.result() == 3  # test result
    r = t.submit(f, 4)  # test case
    assert r.result() == 4  # test result

# Generated at 2022-06-24 10:02:42.269715
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def test_mono_worker_submit_func(time_delay):
        time.sleep(time_delay)
        return 1

    mw = MonoWorker()

    # Test 1: cancel before it's completed
    tag = 1
    f1 = mw.submit(test_mono_worker_submit_func, 0.05)
    time.sleep(0.02)
    f2 = mw.submit(test_mono_worker_submit_func, 0.05)
    time.sleep(0.02)
    f3 = mw.submit(test_mono_worker_submit_func, 0.05)
    time.sleep(0.02)
    f4 = mw.submit(test_mono_worker_submit_func, 0.05)

# Generated at 2022-06-24 10:02:54.172850
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep as time_sleep
    from random import randint

    def is_odd(x):
        time_sleep(randint(1, 3))
        return x % 2 == 1

    odd_number_generator = ((x, is_odd(x)) for x in range(10))

    mw = MonoWorker()

    list_odd_number = []
    while True:
        try:
            x, odd_number = next(odd_number_generator)
        except StopIteration:
            break

        future_odd_number = mw.submit(is_odd, x)
        if odd_number:
            list_odd_number.append(x)
            assert future_odd_number.result()


# Generated at 2022-06-24 10:02:55.922676
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> MonoWorker().__init__()
    """


# Generated at 2022-06-24 10:03:02.542957
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from threading import Event

    e = Event()

    def _foo(name):
        """sleep for 3 secs"""
        time.sleep(3)
        e.set()

    def _bar(name):
        """sleep for 5 secs"""
        time.sleep(5)

    MonoWorker().submit(_foo, 'foo')
    assert(e.is_set() == False)

    MonoWorker().submit(_bar, 'bar')
    assert(e.is_set() == False)

    MonoWorker().submit(_foo, 'foo')
    assert(e.is_set() == False)

    MonoWorker().submit(_foo, 'foo')
    assert(e.is_set() == True)

    MonoWorker().submit(_foo, 'foo')

# Generated at 2022-06-24 10:03:10.752200
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Event

    def slow_square(x, sleep_dur=0.1, terminate=False):
        sleep(sleep_dur)
        if terminate:
            raise ValueError("Terminated")
        return x ** 2

    mw = MonoWorker()
    n = 4
    with tqdm_auto.tqdm(total=n, desc="Calculating squares") as pbar:
        for i in range(n):
            mw.submit(slow_square, i)
            pbar.update()
        # Test using a non-callable
        mw.submit(3 ** 2)
        pbar.update()
        # Test using a callable with args and kwargs

# Generated at 2022-06-24 10:03:20.072788
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from collections import namedtuple
    from sys import argv
    from threading import Thread, Event
    from time import sleep
    from tqdm import trange
    from .tqdm_pandas import tqdm_pandas
    from ..utils import _environ_cols_wrapper

    def test(i):
        """Stub function. Does nothing."""
        sleep(1)
        return i

    worker = MonoWorker()
    # Create a list of range(10), where element # i has probability 1/(i+1)
    # of being a randomly selected integer in [0, 9]
    # (so as to make sure future i+1, if it runs, will always overwrite
    # future i, if it exists).
    lst = list(range(10))

# Generated at 2022-06-24 10:03:25.688229
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, time
    from traceback import format_exc
    import os

    class Foo(object):
        """Foo"""
        def __init__(self, sleep_time, args, kwargs):
            self.sleep_time = sleep_time
            self.args = args
            self.kwargs = kwargs
            self.pid = os.getpid()
            self._called = False
            self._started = None
            self._finished = None

        __repr__ = object.__repr__

        def __call__(self):
            self._called = True
            self._started = time()
            sleep(self.sleep_time)
            self._finished = time()
            return self.pid, self.args, self.kwargs

    def tqdm_write(string):
        tqdm_

# Generated at 2022-06-24 10:03:32.835139
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker."""
    from ..std import inspect
    from ..utils import devnull

    test_MonoWorker.__doc__ = MonoWorker.__doc__
    assert inspect.getsource(MonoWorker) == inspect.getsource(test_MonoWorker)

    mw = MonoWorker()

    import time
    import random

    def sleep_random(max_secs=1):
        time.sleep(random.uniform(0, max_secs))
        return 42

    def sleep_random_exception(max_secs=1):
        raise Exception('sleep_random_exception')

    assert mw.submit(sleep_random) is None  # must fail
    with devnull('stdout'):
        assert mw.submit(sleep_random_exception)

# Generated at 2022-06-24 10:03:37.064617
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    def _sum(iterable):
        return sum(iterable)

    def _raise_ValueError():
        raise ValueError('test error')

    mono_worker = MonoWorker()
    
    assert mono_worker.submit(_sum, [1,2,3]).result() == 6
    assert mono_worker.submit(_sum, [4,5,6]).result() == 15
    assert mono_worker.submit(_sum, [7,8,9]).result() == 24
    assert mono_worker.submit(_sum, [0,0,0]).result() == 0
    assert mono_worker.submit(_raise_ValueError).exception() == ValueError('test error')

# Generated at 2022-06-24 10:03:46.390485
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future

    def _test(i, j=0, sleep=0):
        time.sleep(sleep)
        return i + j

    mw = MonoWorker()
    futures = [mw.submit(_test, i, i) for i in range(3)]
    futures.append(mw.submit(_test, 0, 0, 1))
    futures.append(mw.submit(_test, 0, 0, 1))
    futures.append(mw.submit(_test, 0, 0, 1))
    assert futures[-3].done()  # last 2 are running + waiting
    assert futures[-1] is not futures[-2]  # discard the middle
    assert futures[-1] is not futures[-3]

# Generated at 2022-06-24 10:03:53.062784
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing.dummy import Pool
    from time import sleep

    def f(i):
        sleep(1)
        tqdm_auto.write('%s running' % i)
        return i

    pool = MonoWorker()
    futures = [pool.submit(f, i) for i in range(10)]

    sleep(1)  # 1 running
    with Pool(2) as p:
        p.map(lambda f: f.result(), futures)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 10:03:56.129387
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from .util import exec_

    class Submitter(MonoWorker):
        def __init__(self):
            super(Submitter, self).__init__()
            self.submit(self.job, 1)

        def job(self, x):
            time.sleep(1)
            exec_('.write({})'.format(x))
    Submitter()

# Generated at 2022-06-24 10:04:04.661278
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    workers = MonoWorker()

    def slow_func():
        """
        Helper function which sleeps for 30 seconds
        and returns 40
        """
        time.sleep(30)
        return 40

    def fast_func():
        """
        Helper function which sleeps for 2 seconds
        and returns 20
        """
        time.sleep(2)
        return 20

    # Submit a slow function.
    f1 = workers.submit(slow_func)

    # Submit a fast function. The slow function will be
    # cancelled and the fast function will be submitted.
    # f2 is waiting for completion
    f2 = workers.submit(fast_func)

    # Check if the slow function was cancelled.
    if f1.cancelled():
        print("f1 was cancelled")

# Generated at 2022-06-24 10:04:12.290415
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import threading
    from time import sleep
    from concurrent.futures import TimeoutError

    def waiting(pool):
        if not pool.futures:
            return True
        for future in pool.futures:
            if not future.done():
                return True
        return False

    def worker(pool, x):
        pool.submit(waiter, "a", x)
        pool.submit(waiter, "b", x)
        pool.submit(waiter, "c", x)
        assert len(pool.futures) == 2
        assert waiting(pool)
        assert pool.futures[0].done()
        assert not pool.futures[1].done()

    def waiter(a, x):
        sleep(x)
        tqdm_auto.write(a)


# Generated at 2022-06-24 10:04:22.988885
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def run(delay):
        time.sleep(delay)
        return delay

    def test(delays, maxlen=2, expected=None):
        tqdm_auto.write("delays={}".format(delays))
        expected = expected or delays
        maxlen = max(maxlen, len(delays))
        mw = MonoWorker()
        for i, delay in enumerate(delays):
            future = mw.submit(run, delay)
            if i >= maxlen:
                expected[i - maxlen] = -1
        results = [future.result() for future in mw.futures]
        tqdm_auto.write("  expected={}".format(expected))
        tqdm_auto.write("    result={}".format(results))


# Generated at 2022-06-24 10:04:29.901681
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    class A(object):
        def __init__(self):
            self.n = 0
        def inc(self):
            time.sleep(0.1)
            self.n += 1
            return self.n
    a = A()
    for _ in range(4):
        mw.submit(a.inc)
    for _ in range(4):
        mw.submit(a.inc)
        time.sleep(0.01)
    time.sleep(0.2)
    assert a.n == 3

# Generated at 2022-06-24 10:04:40.603084
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .util import new_bar, AddLoggingProcessPoolExecutor
    from .tests import _range
    from .file_tqdm import tqdm_file

    mw = MonoWorker()
    files = [str(i) for i in range(4)]
    test_iter = _range(10)
    file_iter = tqdm_file(files, total=len(files))
    with AddLoggingProcessPoolExecutor() as pool:
        for _ in file_iter:  # pylint: disable=unused-variable
            test_bar = new_bar(test_iter)
            mw.submit(test_bar.update, 1)

            test_iter2 = _range(100)
            test_bar2 = new_bar(test_iter2)

# Generated at 2022-06-24 10:04:46.808480
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .utils import PY3  # noqa

    def proc(iproc, nproc, interval):
        for i in tqdm_auto(range(nproc), desc=str(iproc)):
            sleep(interval)

    def assert_len(length):
        assert len(worker.futures) == length, \
            "len(worker.futures) = {} != {} = length".format(
                len(worker.futures), length)

    worker = MonoWorker()
    assert_len(0)
    worker.submit(proc, 0, 3, 0.1)
    assert_len(1)
    assert len(worker.futures[0].result()) == 3
    assert_len(0)
    worker.submit(proc, 1, 5, 0.1)

# Generated at 2022-06-24 10:04:53.142091
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def long_job(tqdm_dummy, msg):
        sleep(1)
        tqdm_auto.write(msg)
        return msg

    mw = MonoWorker()
    # Avoid raising concurrent.futures.CancelledError
    assert mw.submit(long_job, tqdm_dummy=None, msg='first')
    assert mw.submit(long_job, tqdm_dummy=None, msg='second')
    assert mw.submit(long_job, tqdm_dummy=None, msg='third')


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:04:57.342006
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # test without exception
    m = MonoWorker()
    assert(m.pool)
    assert(m.futures)
    assert(len(m.futures) == 0)
    assert(m.futures.maxlen == 2)


# Generated at 2022-06-24 10:05:04.330452
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    worker = MonoWorker()
    initial_value = [3.14,]
    def test_func(sleep_time, initial_value):
        time.sleep(sleep_time)
        initial_value[0] += 0.1
    worker.submit(test_func, 0.0, initial_value)
    worker.submit(test_func, 0.1, initial_value)
    worker.submit(test_func, 0.2, initial_value)
    worker.submit(test_func, 0.3, initial_value)
    worker.submit(test_func, 0.4, initial_value)
    # abort the running task
    time.sleep(0.1)
    worker.submit(test_func, 0.3, initial_value)
    time.sleep(0.4)
    assert initial

# Generated at 2022-06-24 10:05:06.676335
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert(len(mw.futures) == 0)
    assert(mw.pool.max_workers == 1)



# Generated at 2022-06-24 10:05:14.708741
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:05:26.096464
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    log = []
    def log_task(id_, t):
        tqdm_auto.write('id={} started'.format(id_))
        log.append((id_, 'started'))
        time.sleep(t)
        log.append((id_, 'ended'))
        tqdm_auto.write('id={} ended'.format(id_))

    def test_task(id_, delay=0.1, runtime=1, sleep_after_start=1):
        from concurrent.futures import wait
        from threading import Thread
        r = random.random()
        time.sleep(sleep_after_start)
        x = MonoWorker()

# Generated at 2022-06-24 10:05:32.252279
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    random.seed(1)
    worker = MonoWorker()

    @worker.submit
    def f(i):
        """Dummy function to start as task."""
        time.sleep(random.random() * 10)
        print('Func', i, 'Done')

    i = 0
    while i < 10:
        i = i + 1
        f(i)
        time.sleep(0.5)

# Generated at 2022-06-24 10:05:39.726017
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def _print(x):
        sleep(1)
        print(x)

    pool = MonoWorker()
    for i in tqdm_auto.tqdm(range(3), desc='t2'):
        pool.submit(_print, i)

    # Output:
    # t2:   0%|          | 0/3 [00:02<?, ?it/s]2
    # t2:  67%|██████▋   | 2/3 [00:02<00:01,  1.00it/s]
    # 1
    # t2: 100%|██████████| 3/3 [00:02<00:00,  1.00it/s]
    # 0
    # 1
    # 2

# Generated at 2022-06-24 10:05:42.214435
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    "Test the constructor of class MonoWorker."
    MonoWorker()

# Generated at 2022-06-24 10:05:53.039968
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Test the MonoWorker class.
    """
    from sys import version_info as py_version_info
    from subprocess import Popen, PIPE
    from platform import system
    if py_version_info[:2] < (3, 5):
        raise unittest.SkipTest('Python ' + str(py_version_info) +
                                ' is too old for this test.')
    if system() == 'Windows':
        raise unittest.SkipTest('This test is not compatible with Windows.')
    from .tests_tqdm_class import _range

    def _tqdm_kwargs():
        """Command-line arguments for this `tqdm` subprocess"""

# Generated at 2022-06-24 10:06:01.689851
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from threading import Thread
    from textwrap import dedent
    from uuid import uuid4

    class TestTask(object):
        # pylint: disable=too-few-public-methods
        def __init__(self, cancel_event, sleep_amount):
            self.sleep_amount = sleep_amount
            self.cancel_event = cancel_event

        def __call__(self):
            self.cancel_event.wait()
            sleep(self.sleep_amount)
            return str(uuid4())

        def __str__(self):
            return repr((self.sleep_amount, self.cancel_event))


# Generated at 2022-06-24 10:06:05.772967
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def test(x):
        time.sleep(x/2)
        return x
    m = MonoWorker()
    for x in [1, 2, 3, 4, 5]:
        m.submit(test, x)


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:06:11.405119
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def dummy(i):
        from time import sleep
        sleep(0.01)
        tqdm_auto.write(i)
        return i

    m = MonoWorker()
    for i in range(10):
        tqdm_auto.write(str(i) + ' submitted')
        m.submit(dummy, i)

    results = []
    for f in m.futures:
        results.append(f.result())
    tqdm_auto.write(str(results))


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:06:19.689265
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Class `MonoWorker` supports one running task and one waiting task.
    The waiting task is the most recent submitted (others are discarded).
    This test runs 5 tasks.
    """
    import threading
    import time

    def job(i):
        """
        Takes 1 second to complete and prints the argument and current time.
        """
        time.sleep(1)
        tqdm_auto.write("Current time: %s | Task %s" % (time.time(), i))

    mono = MonoWorker()
    # Add 5 jobs to pool
    for i in range(5):
        mono.submit(job, i)

    # Join main thread while jobs are running
    main_thread = threading.currentThread()

# Generated at 2022-06-24 10:06:27.169798
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def long_task(i):
        for _ in range(int(1e9)):
            pass
        return i

    def short_task(i):
        time.sleep(1)
        return i

    mw = MonoWorker()
    assert len(mw.futures) == 0
    mw.submit(short_task, 1)
    time.sleep(0.1)
    assert len(mw.futures) == 1
    mw.submit(short_task, 1)
    time.sleep(0.1)
    assert len(mw.futures) == 0  # 1st task is interrupted/cancelled
    mw.submit(short_task, 1)
    time.sleep(0.1)
    assert len(mw.futures) == 1

# Generated at 2022-06-24 10:06:32.190178
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """ Unit test for method submit of class MonoWorker """
    import time
    import concurrent.futures
    mw = MonoWorker()
    try:
        mw.pool.submit(time.sleep, 1)  # blocking, until below
        for i in range(4):
            mw.submit(time.sleep, 10)
            #time.sleep(1)
    except concurrent.futures.CancelledError:
        pass

# Generated at 2022-06-24 10:06:38.546330
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def sleep_and_print(t, *args):
        time.sleep(t)
        print(*args)

    mw = MonoWorker()
    mw.submit(sleep_and_print, 0.1, "A")
    mw.submit(sleep_and_print, 0.2, "B")
    mw.submit(sleep_and_print, 0.3, "C")
    time.sleep(0.11)
    mw.submit(sleep_and_print, 0.4, "D")
    time.sleep(0.11)
    mw.submit(sleep_and_print, 0.5, "E")
    time.sleep(0.21)
    mw.submit(sleep_and_print, 0.6, "F")

# Generated at 2022-06-24 10:06:46.628851
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import operator
    import collections
    import warnings
    warnings.filterwarnings("ignore")

    def test(n, sleep=True, rnd=True, sync=True):
        worker = MonoWorker()

        def t(x):
            return x + 100
        def s(x):
            if sleep:
                time.sleep(1)
            return x + 200
        def r(x):
            x += random.randint(0, n)
            if rnd:
                time.sleep(random.random())
            return x
        def m(x):
            x *= n
            if sync:
                with m.l:
                    m.done += 1
            return x

        m.l = m.done = None


# Generated at 2022-06-24 10:06:55.252059
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import time
    import tqdm

    m = MonoWorker()
    p = tqdm.tqdm(total=10, desc='f1', bar_format='{desc}: {percentage:3.0f}%')
    p.clear()
    for i in p:
        time.sleep(0.1)
        m.submit(tqdm.tqdm.write, 'f1', file=sys.stdout, end=' ')
        if i == 5:
            time.sleep(0.2)
            m.submit(tqdm.tqdm.write, 'f2', file=sys.stdout, end=' ')
        if i == 8:
            time.sleep(0.2)

# Generated at 2022-06-24 10:07:05.395425
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    worker = MonoWorker()
    def _test_exec(time):
        time.sleep(5)
    def _test_exec2(time):
        time.sleep(5)
    for i in range(4):
        worker.submit(_test_exec, time)
    time.sleep(1)
    assert len(worker.futures) == 1
    worker.submit(_test_exec, time)
    assert len(worker.futures) == 1
    time.sleep(1)
    worker.submit(_test_exec, time)
    assert len(worker.futures) == 0
    worker.submit(_test_exec, time)
    assert len(worker.futures) == 1
    time.sleep(1)
    worker.submit(_test_exec2, time)

# Generated at 2022-06-24 10:07:08.830568
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(i):
        import time
        time.sleep(1)
        return i

    mw = MonoWorker()
    for i in range(4):
        mw.submit(func, i)
    assert mw.futures[0].done()
    assert mw.futures[1].result() == 3

# Generated at 2022-06-24 10:07:19.180373
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:07:24.691609
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import multiprocessing
    pool = multiprocessing.Pool(processes=2)
    while True:
        res = pool.apply_async(func=time.sleep, args=(1,))
        print(res)
        if res.get() == None:
            print('sleep over')
test_MonoWorker()

# Generated at 2022-06-24 10:07:32.909092
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import sys
    import time
    import threading
    import requests

    class MockException(Exception):
        pass

    def mock_task():
        raise MockException("Task failed!")

    def mock_success_task():
        pass

    def running_submit_task(func, _):
        while True:
            try:
                func()
                time.sleep(0.1)
            except MockException as e:
                assert(str(e) == "Task failed!")
                break

    def running_submit_task_with_stop(func, stop_event):
        while not stop_event.is_set():
            try:
                func()
                time.sleep(0.1)
            except MockException as e:
                assert(str(e) == "Task failed!")
                break


# Generated at 2022-06-24 10:07:40.394324
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import multiprocessing
    import time
    threads = int(multiprocessing.cpu_count())

    def demo_func(idx, **kwargs):
        """demo func for tqdm/tqdm.cli/tqdm.contrib"""
        time.sleep(0.5)
        return idx * 2

    import threading
    from multiprocessing.dummy import Pool as ThreadPool
    # create thread pool
    pool = ThreadPool(threads)

    from tqdm import tqdm
    results = []
    for _ in tqdm(total=threads):
        thread = threading.Thread(target=pool.apply_async,
                                  args=(demo_func, 1), kwds={})

# Generated at 2022-06-24 10:07:50.806483
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test a non-exception future
    worker = MonoWorker()
    futures = worker.futures
    assert not futures  # Empty deque
    assert len(futures) == futures.maxlen == 2
    future = worker.submit(lambda: None)
    assert future in futures
    assert len(futures) == futures.maxlen == 1
    assert not futures[0].done()
    future.result()
    assert future.done()
    assert not futures
    # Test an exception future
    future = worker.submit(lambda: 1 / 0)
    assert future in futures
    assert len(futures) == futures.maxlen == 1
    future.result()
    assert future.done()
    assert not futures

# Generated at 2022-06-24 10:07:56.836534
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def do_something_useful(n):
        time.sleep(1)  # replace this with a useful task
        return n

    mono = MonoWorker()

    for i in range(5):
        # submit the task and discard the result
        mono.submit(do_something_useful, i).result()

        # wait one second - only the last task should have been run
        time.sleep(1)

        assert len(mono.futures) is 1

# Generated at 2022-06-24 10:08:05.425909
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from random import randint

    class Test(object):
        def __init__(self):
            self.cnt = 0
            self.worker = MonoWorker()

        def run_long_task(self, sleep_time):
            self.cnt += 1
            sleep(sleep_time)
            return self.cnt

        def run_short_task(self):
            return self.cnt

    test = Test()
    tasks = []

    def long_task():
        task = test.worker.submit(test.run_long_task, randint(1, 5))
        tasks.append(task)
        first = tasks[-2]
        if first:
            first.cancel()


# Generated at 2022-06-24 10:08:13.713164
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import sys, math
    from threading import Thread
    from time import sleep

    sys.stderr.write("== Testing MonoWorker class constructor\n")
    worker = MonoWorker()

    def foo():
        """Sleeps for 0.3 seconds, then returns 3."""
        sleep(0.3)
        return 3
    
    def bar():
        """Sleeps for 0.5 seconds, then returns 5."""
        sleep(0.5)
        return 5
    
    def fum():
        """Sleeps for 0.8 seconds, then returns 8."""
        sleep(0.8)
        return 8

    def foobar():
        """Sleeps for 1 second, then returns 3."""
        sleep(1)
        return 13

    run1 = worker.submit(foo)
    run2 = worker.submit

# Generated at 2022-06-24 10:08:23.493927
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def slow(n):
        time.sleep(n)
        return n

    m = MonoWorker()
    f1 = m.submit(slow, 2)
    assert f1.result() == 2
    f2 = m.submit(slow, 0.1)
    assert f2.result() == 0.1
    f3 = m.submit(slow, 0.1)
    assert f3.result() == 0.1
    f4 = m.submit(slow, 0.1)
    assert f4.result() == 0.1
    f5 = m.submit(slow, 2)
    assert f5.result() == 2
    time.sleep(3)
    f6 = m.submit(slow, 0.1)
    assert f6.result() == 0.1

# Generated at 2022-06-24 10:08:26.126908
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mono_worker = MonoWorker()
    # PoolExecutor and futures are created
    assert mono_worker.pool != None
    assert mono_worker.futures != None


# Generated at 2022-06-24 10:08:34.599079
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from mock import patch, MagicMock

    tqdm_auto.write = MagicMock()
    mw = MonoWorker()
    mock = MagicMock()
    mw.submit(mock, 'running', 1, 'a', key='a')
    mw.submit(sleep, 0.1)
    mw.submit(mock, 'waiting', 2, 'b', key='b')
    mw.submit(sleep, 0.1)
    sleep(0.3)
    assert mock.mock_calls == [
        ('running', ('running', 1, 'a'), {'key': 'a'}),
        ('waiting', ('waiting', 2, 'b'), {'key': 'b'})]
    assert tqdm_auto.write.mock_calls

# Generated at 2022-06-24 10:08:39.245217
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> from tqdm.contrib import MonoWorker
    >>> D = dict(count=0)
    >>> def increment():
    ...     D['count'] += 1
    >>> w = MonoWorker()
    >>> w.submit(increment)
    >>> w.submit(increment)
    >>> w.submit(increment)
    >>> w.submit(increment)
    >>> D['count']
    1

    """
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:08:45.059869
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    import sys
    import time
    import numpy as np
    m = MonoWorker()
    assert len(m.futures) == 0

    for r in range(33):
        sleep(1)
        m.submit(sys.exit, 0)
        assert len(m.futures) == 1

        future = m.futures[0]
        assert not future.done()
    assert len(m.futures) == 1

    with tqdm_auto.tqdm(total=1000) as t:
        for i in range(10):
            sleep(np.random.random())
            t.update(10)
            sleep(np.random.random())
            t.update(10)
            sleep(np.random.random())
            t.update(10)
           

# Generated at 2022-06-24 10:08:53.664343
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from functools import partial
    from unittest import TestCase
    from .tqdm_test_cases import DiscreteTimer

    # Execute the following in the parent directory
    #   python -m unittest tqdm.contrib.tests.test_MonoWorker

    timer = DiscreteTimer(1)
    with MonoWorker() as mono:
        mono.submit(sleep, 1)
        timer.sleep(2)
        mono.submit(partial(sleep, 1.5))
        assert mono.submit(sleep, 3).result() is None

    class Test(TestCase):
        def test_1(self):
            with MonoWorker() as mono:
                mono.submit(sleep, 1)
                timer.sleep(2)
                mono.submit(partial(sleep, 1.5))

# Generated at 2022-06-24 10:09:02.393307
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import inspect
    m_worker = MonoWorker()
    assert m_worker.pool is not None
    assert inspect.isclass(ThreadPoolExecutor)
    assert inspect.ismethod(MonoWorker.submit)
    assert inspect.ismethod(m_worker.submit)
    inc = lambda x: x + 1
    assert m_worker.submit(inc, 1).result() == 2  # run it
    assert m_worker.submit(inc, 2).result() == 3  # waiting task is replaced
    assert m_worker.submit(inc, 2).result() == 3  # waiting is cancelled
    m_worker.submit(time.sleep, 1)  # blocking task
    assert m_worker.submit(inc, 2) is None  # will be discarded

# Generated at 2022-06-24 10:09:12.018109
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    import unittest

    class TestMonoWorker(unittest.TestCase):
        def _test_action(self, func, *args, **kwargs):
            x, y = self.worker.submit(func, *args, **kwargs)
            self.assertEqual(self.worker.futures, deque([x, y], 2))

        def setUp(self):
            import tempfile
            self.fh = open(tempfile.mktemp(), 'w')
            self.worker = MonoWorker()

        def test_basic(self):
            def f(x):
                self.fh.write(str(x) + '\n')
                return x

            self._test_action(f, 1.)
            self._test_action(f, 2.)
           

# Generated at 2022-06-24 10:09:23.046972
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .tqdm_tqdm import trange

    def test_instance(n):
        # pylint: disable=unused-variable
        # This is a fake instance to test speed of class MonoWorker
        with trange(10, leave=True) as t:
            for _ in t:
                t.set_description("=" * n)
                time.sleep(1)

    MW = MonoWorker()
    # Run four instances sequentially
    with trange(4, leave=True) as t:
        for i in t:
            t.set_description("=" * i)
            MW.submit(test_instance, i)
            time.sleep(1)
    # Run four instances concurrently
    with trange(4, leave=True) as t:
        for i in t:
            t

# Generated at 2022-06-24 10:09:32.483618
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker."""
    from time import sleep

    class Dummy(object):
        """Dummy class for testing"""
        def __init__(self):
            self.t = 0

        def __call__(self):
            """Dummy callable that counts calls"""
            sleep(0.05)
            self.t += 1
            return self.t

    dummy = Dummy()
    monoworker = MonoWorker()
    assert len(monoworker.futures) == 0
    for _ in range(3):
        monoworker.submit(dummy)  # dummy: A, B, C
    sleep(0.03)
    assert monoworker.futures[0].result() == 1  # dummy: A

# Generated at 2022-06-24 10:09:42.389579
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    """
    import time
    from multiprocessing import cpu_count
    max_workers = 1  # cpu_count()
    assert max_workers >= 1
    pool = MonoWorker()
    assert isinstance(pool, MonoWorker)
    # submit f0

    def f0(x):
        time.sleep(x)
        return x

    t0 = time.time()
    future0 = pool.submit(f0, 0.01)
    future0.result(timeout=0.02)
    t1 = time.time()
    assert t1 - t0 < 0.02
    # submit f1, should be canceled by f2
    t1 = time.time()

    def f1(x):
        time.sleep(x)
        return x


# Generated at 2022-06-24 10:09:44.376770
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .thread_utils import _test_MonoWorker
    _test_MonoWorker(MonoWorker)


# Generated at 2022-06-24 10:09:55.217035
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from concurrent.futures import Future

    class NoopFuture(Future):
        """Do nothing on .cancel()"""
        def cancel(self):  # pylint: disable=useless-super-delegation
            super(NoopFuture, self).cancel()
            return False

    def dummy_async(*args):
        res = sum(args)
        sleep(1)
        return res

    with MonoWorker() as worker:
        assert isinstance(worker, MonoWorker)
        assert len(worker.futures) == 0

        # Run dummy async job
        assert worker.submit(dummy_async, 1, 2).result() == 3

        # Running job + one waiting job
        assert len(worker.futures) == 2

# Generated at 2022-06-24 10:09:59.496371
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from multiprocessing import current_process

    def slow(x, y):
        for _ in tqdm_auto.trange(10):
            sleep(0.1 * (1 + random()))
        return x + y

    worker = MonoWorker()
    for _ in range(3):
        worker.submit(slow, 1000, 1000)
    for _ in range(3):
        worker.submit(current_process().pid, None)
    worker.submit(1, 2)

# Generated at 2022-06-24 10:10:08.589330
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from . import BaseWrapper

    class TestTask(object):
        def __init__(self, desc, sec=1):
            self.desc = desc
            self.sec = sec

        def __call__(self):
            time.sleep(self.sec)
            tqdm_auto.write(self.desc)

    worker = MonoWorker()
    print('submit 10 tasks')
    for desc, sec in zip(range(10), [random.random() for _ in range(10)]):
        task = TestTask(desc, sec)
        tqdm_auto.tqdm.write('submitting task #%d, %s' % (desc, task))
        worker.submit(task)
    print('wait for all tasks to finish')

# Generated at 2022-06-24 10:10:12.714586
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import time, sleep
    worker = MonoWorker()
    start = time()
    sleep(1)
    worker.submit(sleep, 1)
    sleep(1)
    worker.submit(sleep, 1)
    sleep(1)
    worker.submit(sleep, 1)
    assert time() - start < 6


# Generated at 2022-06-24 10:10:20.843191
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures
    with tqdm_auto.trange(5) as t:
        for i in t:
            def func(x):
                time.sleep(x)
            t.set_description(str(i))
            try:
                # Submit to MonoWorker
                t.last_print_t = time.time()
                MonoWorker().submit(func, 0.1)
            except concurrent.futures.CancelledError:
                tqdm_auto.write(":( cancelled")


if __name__ == "__main__":
    test_MonoWorker_submit()


 # Needed so that Python doesn't think that this is a
# "pure Python" module.

# Generated at 2022-06-24 10:10:27.871424
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Test that old tasks are cancelled
    c = MonoWorker()
    c.submit(lambda: 0)
    c.submit(lambda: 1)
    c.submit(lambda: 2)
    assert c.futures[0]._state is None  # available
    assert c.futures[1]._state is None  # available
    assert c.futures[0].done() is False
    assert c.futures[1].done() is False
    assert c.futures[0].result() == 2
    assert c.futures[1].result() == 2

# Generated at 2022-06-24 10:10:38.454868
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test for MonoWorker class constructor."""

    # Unit tests for constructor
    import time
    import math

    def pi_master(nb_samples):
        return math.pi / 4 * nb_samples

    def pi_sequential(nb_samples, worker=None):
        nb_inside = 0
        if worker:
            worker.submit(pi_master, nb_samples)
        for _ in range(nb_samples):
            x, y = random.random(), random.random()
            if (x ** 2 + y ** 2) < 1.0:
                nb_inside += 1
        return nb_inside

    def pi_parallel(nb_samples, worker=None):
        num_cpus = multiprocessing.cpu_count()
        nb_inside = 0
       

# Generated at 2022-06-24 10:10:46.899494
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def sleep(seconds):
        for i in range(seconds):
            time.sleep(1)
            return seconds

    # Creation of test object
    worker = MonoWorker()
    # Test submit method
    assert worker.submit(sleep, 1).result() == 1
    assert worker.submit(sleep, 1).result() == 1
    assert worker.submit(sleep, 2).result() == 2
    assert worker.submit(sleep, 2).result() == 2
    assert worker.submit(sleep, 3).result() == 3
    assert worker.submit(sleep, 4).result() == 4
    assert worker.submit(sleep, 5).result() == 5
    assert worker.submit(sleep, 6).result() == 6

# Generated at 2022-06-24 10:10:57.890698
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f1():
        """do nothing"""
        return None

    def f2():
        """sleep 1 sec"""
        import time
        time.sleep(1)
        return None

    def f3():
        """sleep 2 sec"""
        import time
        time.sleep(2)
        return None

    mw = MonoWorker()
    # add a task that sleeps 1 second
    t1 = mw.submit(f2)
    # add a task that sleeps 2 seconds, ignore f2
    t2 = mw.submit(f3)
    # add a task that does nothing, ignore f3
    t3 = mw.submit(f1)
    # assert that t1, t2, t3 are done and their return values are None
    assert t1 is None
    assert t2 is None

# Generated at 2022-06-24 10:11:06.419623
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from . import test_bytesIO
    mw = MonoWorker()
    with test_bytesIO() as b:
        f1 = mw.submit(sleep, 5)
        print('Adding f2')
        f2 = mw.submit(sleep, 5)
        print('Adding f3')
        f3 = mw.submit(sleep, 5)
        print('Waiting')
        try:
            f2.result()
        except Exception as e:
            assert r"cancelled" in str(e), str(e)
        else:
            assert False, "Expected exception"
        print('Done')



# Generated at 2022-06-24 10:11:16.410537
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    test_lock = threading.Lock()

    class WaitFunc(object):
        def __init__(self):
            self.func_value = 0

        def func(self, value):
            with test_lock:
                self.func_value = value
            time.sleep(3)

    def worker(value):
        with test_lock:
            func(value)

    wait_func = WaitFunc()
    func = wait_func.func

    mono_worker = MonoWorker()
    # test single submit
    with tqdm_auto.external_write_mode():
        mono_worker.submit(worker, 1)
        assert wait_func.func_value == 0
        time.sleep(1)
        assert wait_func.func_value == 0
       

# Generated at 2022-06-24 10:11:25.870917
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    
    # The first task is running
    def func1(x):
        time.sleep(x)
        return x
    mw = MonoWorker()
    mw.submit(func1, 2)
    
    # The second task is discarded
    mw.submit(func1, 1)
    
    # The thrid task is waiting
    mw.submit(func1, 5)
    
    # The fourth task is discarded
    mw.submit(func1, 3)
    time.sleep(1)
    
    # The thrid task is discarded (because of the fifth task)
    mw.submit(func1, 4)


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:11:28.196821
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from .tests import test_MonoWorker
    test_MonoWorker(MonoWorker)

# Generated at 2022-06-24 10:11:35.426290
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep, time

    iw = MonoWorker()  # instantiate

    t0 = time()
    iw.submit(sleep, 1)
    iw.submit(sleep, 2)
    iw.submit(sleep, 3)
    iw.submit(sleep, 4)
    iw.submit(sleep, 5)
    iw.submit(sleep, 6)
    iw.futures[0].result()
    assert int(time() - t0) == 5

# Generated at 2022-06-24 10:11:47.134043
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures
    import time

    def slowprint(s):
        time.sleep(1)
        tqdm_auto.write(s)

    m = MonoWorker()
    m.submit(slowprint, '1')
    m.submit(slowprint, '2')
    m.submit(slowprint, '3')
    time.sleep(2)
    assert str(m) == '<MonoWorker running=0 done=1 pending=1 bad=0>'
    m.submit(slowprint, '4')
    time.sleep(2)
    assert str(m) == '<MonoWorker running=0 done=2 pending=0 bad=0>'

