

# Generated at 2022-06-24 10:01:54.434263
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    assert mw.submit(1).result() == 1

    import time

    def f(x):
        time.sleep(1)
        return x

    mw = MonoWorker()
    assert mw.submit(f, 1).result() == 1

    t = time.time()
    assert mw.submit(f, 2).result() == 2
    assert 1 < time.time() - t < 2  # 1 second

    t = time.time()
    assert mw.submit(f, 3).result() == 3
    assert 1 < time.time() - t < 2  # 1 second

    t = time.time()
    assert mw.submit(f, 4).result() == 3
    assert 1 < time.time() - t < 2  # 1 second

# Generated at 2022-06-24 10:01:58.752283
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .tqdm_contrib import MonoWorker
    mw = MonoWorker()
    assert mw.submit(sleep, 0.5)
    assert mw.submit(lambda: 1 + 1) == 4

# Generated at 2022-06-24 10:02:09.464117
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    import sys
    from threading import Thread, Event

    write = sys.stdout.write

    def _sleep(n):
        for i in tqdm_auto.trange(n):
            sleep(0)

    def _time_write():
        global write
        r = {i: sys.stdout.write for i in range(100)}
        for i in tqdm_auto.trange(100):
            sleep(0.001)
            write(u'.')
        return r

    executor = MonoWorker()

    print("Starting...")

    n = 100
    t_go = Event()
    t_stop = Event()
    def _thread(t_go_, t_stop_):
        t_go_.wait()

# Generated at 2022-06-24 10:02:18.817414
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(arg):
        return 'result_{}'.format(arg)

    def func2(arg):
        return 'result2_{}'.format(arg)

    pool = MonoWorker()

    # Submit initial task
    future1 = pool.submit(func, 'A')
    assert future1.result() == 'result_A'
    assert len(pool.futures) == 1

    # Submit task that does not replace any tasks
    future2 = pool.submit(func, 'B')
    assert future1.result() == 'result_A'
    assert future2.result() == 'result_B'
    assert len(pool.futures) == 2

    # Submit task that replaces future2
    future2.cancel()
    future3 = pool.submit(func2, 'C')
    assert future1.result

# Generated at 2022-06-24 10:02:19.723291
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()

# Generated at 2022-06-24 10:02:24.170872
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from random import random
    pool = MonoWorker()
    for i in range(5):
        sleep(random() / 2)
        pool.submit(sleep, random() * 2)
    pool.submit(sleep, random() * 3).result()

# Generated at 2022-06-24 10:02:29.576126
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    # Example of concurrent tasks
    def _func(i, delay=0.1):
        time.sleep(delay)
        return i
    # Initialise
    m = MonoWorker()
    # Submit task1
    i = 1
    m.submit(_func, i)
    # Submit task2 which will replace task1
    i = 2
    m.submit(_func, i)
    # Submit task3 which will replace task2
    i = 3
    m.submit(_func, i)
    # Wait for task3 to finish
    assert m.futures[0].result() == 3
    # Submit task4 which will replace task3
    i = 4
    m.submit(_func, i)
    # Wait for task4 to finish
    assert m.futures[0].result() == 4

# Generated at 2022-06-24 10:02:31.986252
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    foo = MonoWorker()
    assert foo.pool.max_workers == 1
    assert foo.futures.maxlen == 2
    assert len(foo.futures) == 0

# Generated at 2022-06-24 10:02:40.037954
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    worker = MonoWorker()

    # Queue: [ ]
    worker.submit(tqdm_auto.write, "1")
    # Queue: [1]
    assert len(worker.futures) == 1
    sleep(0.5)
    # Queue: [ ]
    assert len(worker.futures) == 0

    # Queue: [ ]
    worker.submit(tqdm_auto.write, "1")
    # Queue: [1]
    worker.submit(tqdm_auto.write, "2")
    # Queue: [2]
    assert len(worker.futures) == 1
    sleep(0.5)
    # Queue: [ ]
    assert len(worker.futures) == 0

    # Queue: [ ]

# Generated at 2022-06-24 10:02:46.354835
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import functools
    Q=MonoWorker()
    f1=Q.submit(time.sleep, 1)
    f2=Q.submit(time.sleep, 1)
    f3=Q.submit(time.sleep, 1)
    for f in [f1,f2,f3]: assert not f.done()
    f1.cancel()
    f2.cancel()
    f3.cancel()
    for f in [f1,f2,f3]: assert f.done()
    assert f1.cancelled()
    assert f2.cancelled()
    assert f3.cancelled()


# Generated at 2022-06-24 10:02:55.567699
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    worker = MonoWorker()

    def f(a):
        sleep(0.01)
        return a
    waiting = worker.submit(f, 1)
    sleep(0.02)
    next_waiting = worker.submit(f, 2)
    assert next_waiting == waiting
    assert not waiting.done()
    waiting.cancel()
    sleep(0.02)
    next_waiting = worker.submit(f, 2)
    assert next_waiting != waiting
    assert waiting.done()
    assert waiting.cancelled()
    assert next_waiting.result() == 2

# Generated at 2022-06-24 10:03:08.384184
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    evt = Event()
    timeouts_cancelled = []
    test_timeout = 0.5  # seconds

    def _test_timeout(timeout):
        sleep(timeout)
        if evt.is_set():
            timeouts_cancelled.append(timeout)
            return timeout
        return None

    def _assert_MonoWorker_submit():
        # verify that at most one thread is running at the same time
        # and that not all the threads created were cancelled

        # create MonoWorker object and submit some tasks
        worker = MonoWorker()
        timeouts = deque()
        for i in range(6):
            timeouts.append(i/10)
            worker.submit(_test_timeout, timeouts[-1])

        # replace last task with

# Generated at 2022-06-24 10:03:09.881088
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    print(worker)
test_MonoWorker()

# Generated at 2022-06-24 10:03:19.345526
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from ..utils import FormatSize

    def sleep_a_while(duration_seconds, sleep_start_seconds, text="", end=""):
        time.sleep(sleep_start_seconds)
        tqdm_auto.write(text + ":")
        time.sleep(duration_seconds)
        tqdm_auto.write(FormatSize.auto(35) + ": done" + end)

    max_workers = 1
    from concurrent.futures import ThreadPoolExecutor
    pool = ThreadPoolExecutor(max_workers=max_workers)
    futures = deque([], 2)

    start_time_seconds = time.time()

    print("\n" + "-" * 80)

# Generated at 2022-06-24 10:03:24.873377
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    # Constructor
    monoWorker = MonoWorker()

    # Function to test
    def time_task(index, sleep_seconds=1):
        sleep(sleep_seconds)
        return index

    # First task
    assert monoWorker.submit(time_task, 0, 3).result() == 0
    # Second task
    assert monoWorker.submit(time_task, 1, 3).result() is None
    # Third task
    assert monoWorker.submit(time_task, 2, 3).result() == 1

# Generated at 2022-06-24 10:03:34.026678
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    f = MonoWorker()

    # running, waiting
    assert [f.submit(lambda: 1), f.submit(lambda: 2)] == [1, 1]
    # running, finished, waiting
    assert [f.submit(lambda: 3), f.submit(lambda: 4)] == [4, 4]

    # running, waiting, waiting
    f.submit(lambda: 1)
    f.submit(lambda: 2)
    assert [f.submit(lambda: 3), f.submit(lambda: 4)] == [2, 4]

# Generated at 2022-06-24 10:03:39.345578
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Tests MonoWorker class."""
    import threading

    def _sleeptask(i):
        from time import sleep
        print("start", i)
        sleep(0.5)
        print("end  ", i)

    worker = MonoWorker()
    for i in range(4):
        worker.submit(_sleeptask, i)
    running = threading.Thread(target=worker.futures[0].result)
    running.daemon = True
    running.start()
    running.join()
    assert worker.futures[0].done()

# Generated at 2022-06-24 10:03:49.343511
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:04:00.196306
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import format_sizeof
    from concurrent.futures import Future
    from functools import partial
    from time import sleep, time

    def f(a, b=1, c=1):
        """Sleep for `a` seconds, then return the product of `b` and `c`."""
        sleep(a)
        return b * c

    mw = MonoWorker()

    assert len(mw.pool._threads) == 0
    assert len(mw.pool._work_queue) == 0

    assert isinstance(mw.submit(f, 3), Future)
    assert len(mw.pool._threads) == 1
    assert len(mw.pool._work_queue) == 0

    assert isinstance(mw.submit(f, 3, b=4), Future)
    assert len

# Generated at 2022-06-24 10:04:11.516802
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import unittest
    import time
    import sys

    if sys.version_info[:2] == (3, 2):
        raise unittest.SkipTest("multi-threading disabled on Python 3.2")

    def worker(x):
        "print()-like function for `MonoWorker`"
        time.sleep(.1)
        try:
            raise ValueError("error")
        except Exception as e:
            tqdm_auto.write(str(e))
            raise e
        return x

    class MonoWorkerTest(unittest.TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.res = []

        def test_submit_0(self):
            self.mw.submit(worker, 0)

# Generated at 2022-06-24 10:04:22.498430
# Unit test for constructor of class MonoWorker
def test_MonoWorker():  # pragma: no cover
    def pop_a():
        return A.pop_a()

    def pop_b():
        return B.pop_b()

    class A:
        @staticmethod
        def pop_a():
            return 'aaaaaaaaaa'

    class B:
        @staticmethod
        def pop_b():
            return 'bbbbbbbbbb'

    m = MonoWorker()

    f = m.submit(pop_a)
    g = m.submit(pop_b)
    assert f.result() == 'aaaaaaaaaa'
    assert g.result() == 'bbbbbbbbbb'

    f = m.submit(pop_a)
    g = m.submit(pop_b)
    assert f.result() == 'aaaaaaaaaa'

# Generated at 2022-06-24 10:04:31.307024
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import sys

    # Random number generator already seeded.
    # This can be done with a known seed value to force reproducible test results.

    def task_2sec(i):
        time.sleep(random.randint(1, 2))
        return i

    def task_1sec(i):
        time.sleep(random.randint(1, 1))
        return i

    output = []
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO

    tqdm_auto.write = output.append
    tqdm_auto.write("tqdm.write = sys.stdout.write")
    output.append("")
    output.append("")

    # Test 1: Run six tasks, two should overlap.
    # Start 2sec task 1

# Generated at 2022-06-24 10:04:40.148556
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import format_sizeof

    mw = MonoWorker()

    def gen_fib(n):
        a, b = 0, 1
        for i in range(n):
            yield a
            a, b = b, a + b

    gen1 = gen_fib(int(format_sizeof(10e9)))

    def consume(gen):
        for x in gen:
            pass

    consume1 = mw.submit(consume, gen1)
    time.sleep(1)

    gen2 = gen_fib(int(format_sizeof(10e9)))
    consume2 = mw.submit(consume, gen2)
    consume2.result()

# Generated at 2022-06-24 10:04:44.671529
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    # A function that will be called by the thread
    def foo(integer):
        time.sleep(5)
        return integer

    mow = MonoWorker()
    T = mow.submit(foo, 1)
    # Submit another task
    T2 = mow.submit(foo, 2)
    # foo(1) will be cancelled and foo(2) will be executed
    assert T.cancel()
    assert T2.result() == 2
    assert not T.done()

# Generated at 2022-06-24 10:04:48.454385
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    mono_worker = MonoWorker()
    mono_worker.submit(time.sleep, 5)
    mono_worker.submit(time.sleep, 5)
    mono_worker.submit(time.sleep, 5)  # replace waiting


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:04:54.418491
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import current_thread
    import subprocess
    import sys

    def time1_fn():
        sleep(1)
        return current_thread()

    def time3_fn():
        sleep(3)
        return current_thread()

    def time5_fn():
        sleep(5)
        return current_thread()

    m = MonoWorker()
    f = m.submit(time1_fn)
    assert f.result() is not current_thread()
    assert m.futures[0].result() == f.result()
    assert len(m.futures) == 1
    g = m.submit(time3_fn)
    assert g.result() is not current_thread()
    assert m.futures[0].result() == g.result()
    assert f

# Generated at 2022-06-24 10:05:02.292178
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import os
    import sys
    import threading
    import traceback
    import unittest
    from ..utils import format_sizeof, sec_to_str, time_unit

    from .bar import FloatProgress
    from .gui import tqdm_notebook

    class MonoWorkerTest(unittest.TestCase):
        def setUp(self):
            self.test_inst = MonoWorker()

        def test_submit(self):
            def _twopower(i):
                return str(_twopower_i ** i)

            def _float_power(i):
                return str(_float_power_i ** i)

            t = IntProgress(min=0, max=10)
            f = FloatProgress(min=0, max=1.0)

# Generated at 2022-06-24 10:05:13.947038
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from concurrent.futures import wait
    from contextlib import closing
    worker = MonoWorker()

    def f():
        sleep(0)
        return 1

    with closing(worker):
        a = worker.submit(f)
        wait([a])
        assert a.result() == 1

        b = worker.submit(f)
        wait([b])
        assert b.result() == 1
        assert a.done()

    # Exceptions should be propagated in order to be handled.
    def _raise():
        raise ValueError('Testing exceptions')

    worker = MonoWorker()
    with closing(worker):
        with tqdm_auto.tqdm() as t:
            a = worker.submit(lambda: t)  # Should not get cancelled
            b = worker.submit(_raise)


# Generated at 2022-06-24 10:05:22.042073
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    foo = MonoWorker()
    foo.submit(lambda: None, 0)
    foo.submit(lambda: None, 1)
    foo.submit(lambda: None, 2)
    foo.submit(lambda: None, 3)
    foo.submit(lambda: None, 4)
    foo.submit(lambda: None, 5)
    foo.submit(lambda: None, 6)
    assert foo.futures[0].running()
    foo.futures[0].result()
    assert foo.futures[1].cancelled()
    assert foo.futures[0].cancelled()

# Generated at 2022-06-24 10:05:32.245105
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing.pool import ThreadPool
    from threading import Thread
    from tqdm.contrib.concurrent import MonoWorker

    def test_func(x):
        sleep(x)
        return x

    tp = ThreadPool(1)
    tp.apply(test_func, (0.2,))
    tp.close()
    tp.join()
    tp = MonoWorker()

    def submit_task():
        tp.submit(test_func, 0.1)
        tp.submit(test_func, 0.1)
        tp.submit(test_func, 0.1)
        tp.submit(test_func, 0.1)

    # Submit a task that takes time 0.1s

# Generated at 2022-06-24 10:05:38.881015
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def _log(var, val, log_=tqdm_auto.write):
        log_("{}={!r}".format(var, val))

    # Test 1: submit 10 tasks with no delay
    mw = MonoWorker()
    for i in range(10):
        mw.submit(_log, 'i', i)
        time.sleep(0.01)

    # Test 2: submit 10 tasks with 10s delay
    mw = MonoWorker()
    for i in range(10):
        mw.submit(_log, 'i', i, log_=lambda x: time.sleep(10))
        time.sleep(0.01)

# Generated at 2022-06-24 10:05:48.191757
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import multiprocessing
    from multiprocessing import current_process
    from time import sleep
    from .utils import _supports_unicode
    from ..utils import _environ_cols_wrapper
    from ..tqdm import tqdm

    def worker_fun(n):
        sleep(1)
        return current_process().name + ': ' + n

    # Test threads
    worker = MonoWorker()
    n = multiprocessing.cpu_count()
    if n <= 2:
        n = 3
    t = tqdm(_environ_cols_wrapper(range(n)),
             desc='foo',
             dynamic_ncols=True,
             leave=True,
             unit='thread',
             unit_scale=True,
             ascii=not _supports_unicode())
   

# Generated at 2022-06-24 10:06:00.111560
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono = MonoWorker()
    def wait(t):
        time.sleep(t)

    # First task
    task1 = mono.submit(wait, .5)
    assert len(mono.futures) == 1
    assert not task1.done()
    task1.result()  # wait

    # Second task
    task2 = mono.submit(wait, .5)
    assert len(mono.futures) == 1
    assert not task2.done()
    task2.result()  # wait

    # Task 3 (missing)
    time.sleep(.1)
    assert len(mono.futures) == 1
    time.sleep(.2)
    task3 = mono.submit(wait, 5)
    assert len(mono.futures) == 1
   

# Generated at 2022-06-24 10:06:02.372550
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> MonoWorker()
    <__main__.MonoWorker object at ...>
    """
    pass



# Generated at 2022-06-24 10:06:03.308760
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker is not None

# Generated at 2022-06-24 10:06:10.085071
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm import tqdm

    MW = MonoWorker()
    def _test_func(t):
        sleep(t)
        return t

    # Ensure task gets executed
    assert MW.submit(_test_func, 0).result() == 0

    for t in tqdm(range(10), desc='1'):
        MW.submit(_test_func, 1)

    for t in tqdm(range(10), desc='3'):
        MW.submit(_test_func, 3)

    # Ensure at least one task gets executed
    assert MW.submit(_test_func, 0).result() == 0



# Generated at 2022-06-24 10:06:15.687927
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    from contextlib import closing
    from six.moves import xrange

    def f(i):
        print("f({}) started".format(i))
        import time
        time.sleep(0.1)
        print("f({}) stopped".format(i))

    with closing(MonoWorker()) as m:
        for i in xrange(10):
            m.submit(f, i)



# Generated at 2022-06-24 10:06:25.041003
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import pprint
    # pprint.pprint(vars(MonoWorker))
    # print(dir(MonoWorker))
    # print(MonoWorker.__dict__)
    # print(MonoWorker.__doc__)
    # print(MonoWorker.__name__)
    # print('\n')
    mw = MonoWorker()
    mw.submit(time.sleep, 2.5)
    mw.submit(time.sleep, 2.5)  # 1st is discarded
    mw.submit(time.sleep, 1.0)  # 1st is discarded
    mw.submit(time.sleep, 1.0)  # 2nd is discarded
    print(mw.futures)
    print(mw.futures[-1])

# Generated at 2022-06-24 10:06:33.855267
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..contrib import DummyExecutor as DummyPool
    from ..utils import _supports_unicode

    try:
        from unittest import mock
    except ImportError:
        import mock

    # from IPython import embed
    # embed()

    def func1():
        time.sleep(0.5)
        return "func1"

    def func2():
        time.sleep(1.0)
        return "func2"

    def func3():
        time.sleep(1.5)
        return "func3"

    def func_exception():
        raise Exception("this is an exception")

    pool = DummyPool()
    with mock.patch('tqdm.contrib.concurrent.MonoWorker.pool', new=pool):
        mw = MonoWorker()
       

# Generated at 2022-06-24 10:06:38.699545
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def run(a, b, c=None):
        import time
        time.sleep(a)
        return a, b, c
    mw = MonoWorker()
    tqdm_auto.write(mw.submit(run, 0.1, 1, c=2))  # wait 0.1s, then return
    tqdm_auto.write(mw.submit(run, 0.2, 3, c=4))  # wait 0.1s, then return
    tqdm_auto.write(mw.submit(run, 0.3, 5, c=6))  # wait 0.2s, then return
    # mw.submit(run, 0.4, 7, c=8)  # no return because waiting task has been cancelled
    mw.pool.shutdown()

# Generated at 2022-06-24 10:06:45.303912
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f():
        time.sleep(1)
        return True

    D = MonoWorker()
    D.submit(f)
    D.submit(f)
    D.submit(f)
    D.submit(f)
    assert D.futures[0].result()
    assert D.futures[1].result()
    assert not D.futures[0].done()
    assert not D.futures[1].done()
    time.sleep(2)
    assert D.futures[0].done()
    assert D.futures[1].done()

# Generated at 2022-06-24 10:06:48.737275
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test for method submit of class MonoWorker"""
    try:
        import time
    except ImportError:
        return
    try:
        from queue import Queue
    except ImportError:
        from Queue import Queue

    test_queue = Queue()

    def task(i):
        # time.sleep(1)
        test_queue.put(i)

    worker = MonoWorker()
    worker.submit(task, 10)
    worker.submit(task, 42)
    assert test_queue.get(timeout=1) == 42

# Generated at 2022-06-24 10:06:50.637339
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Test `MonoWorker` class constructor.
    """
    worker = MonoWorker()



# Generated at 2022-06-24 10:06:51.509539
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()

# Generated at 2022-06-24 10:06:58.692348
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def sleeper(x):
        time.sleep(x)
        return x

    worker = MonoWorker()
    assert not worker.futures
    worker.submit(sleeper, 1)
    assert len(worker.futures) ==  1
    worker.submit(sleeper, 2)
    assert len(worker.futures) ==  1
    assert worker.futures[0].result() == 2
    time.sleep(3)
    assert not worker.futures
    worker.submit(sleeper, 3)
    assert len(worker.futures) ==  1
    worker.submit(sleeper, 4)
    assert len(worker.futures) ==  1
    assert worker.futures[0].result() == 4

# Generated at 2022-06-24 10:07:04.934462
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    monkey_patch = False
    if monkey_patch:
        from ..tqdm import tqdm, trange
        from ..utils import _screen_shape, _io_wrapper
        old_screen_shape = _screen_shape
        old_io_wrapper = _io_wrapper

    def test_func(i):
        from time import sleep
        sleep(1)
        return i

    def test_func_exception(i):
        from time import sleep
        sleep(1)
        raise Exception('testing MonoWorker')


# Generated at 2022-06-24 10:07:16.378014
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from concurrent.futures import TimeoutError
    from random import randint

    def test_exception(msg):
        raise Exception(msg)

    def test_timeout(s):
        time.sleep(s)

    def test_timeout_then_exception(s):
        time.sleep(s)
        raise Exception(str(s))

    with tqdm_auto.tqdm() as t:
        mw = MonoWorker()
        try:
            mw.submit(test_exception, 'test_exception')
        except Exception:
            pass
        try:
            mw.submit(test_timeout_then_exception, randint(0, 5))
        except Exception:
            pass
        mw.submit(test_timeout, randint(0, 5))

# Generated at 2022-06-24 10:07:20.947005
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def task(i):
        time.sleep(random.randint(1, 5))
        return i

    worker = MonoWorker()
    task_list = []
    for i in range(6):
        task_list.append(worker.submit(task, i))

    time.sleep(7)
    tqdm_auto.write("\n".join(str(x.result()) for x in task_list if x.done()))

# Generated at 2022-06-24 10:07:30.209316
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def test_func():
        sleep(1)
        return 42

    def wrapper_func(*args, **kwargs):
        return 42

    obj = MonoWorker()
    assert(obj.submit(test_func) is not None)
    assert(len(obj.futures) == 1)
    assert(obj.submit(test_func) is None)
    assert(len(obj.futures) == 1)
    assert(obj.submit(wrapper_func) is not None)
    assert(len(obj.futures) == 0)

    obj = MonoWorker()
    assert(obj.submit(wrapper_func) is not None)
    assert(len(obj.futures) == 1)
    assert(obj.submit(test_func) is None)

# Generated at 2022-06-24 10:07:41.890455
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:07:52.850323
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import pytest
    from tqdm.utils import _range

    mp = MonoWorker()  # pragma: no cover
    # supported arguments
    mp.submit(lambda: 1)
    mp.submit(lambda a: a, 1)
    mp.submit(lambda a, b: a + b, 1, 2)
    mp.submit(lambda *a: a, 1, 2, 3)
    mp.submit(lambda **a: a, a=1)
    mp.submit(lambda a, *b, **c: b, 1, 2, 3, c=1)
    # properly handle waiting tasks
    _ = mp.submit(lambda: time.sleep(1))
    _ = mp.submit(lambda: time.sleep(1))
    _ = mp.submit(lambda: time.sleep(1))
   

# Generated at 2022-06-24 10:08:04.539223
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    mw = MonoWorker()
    assert mw.futures.maxlen == 2
    assert len(mw.futures) == 0

    # submit task a
    future_a = mw.submit(lambda a, kw=None: time.sleep(a), 2)
    assert future_a.done() is False
    assert len(mw.futures) == 1

    # submit task b
    future_b = mw.submit(lambda b, kw=None: time.sleep(b), 1)
    assert future_b.done() is False
    assert len(mw.futures) == 1

    # task a finishes
    time.sleep(3)
    assert future_a.done() is True

    # submit task c

# Generated at 2022-06-24 10:08:13.356438
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from unittest import TestCase
    import warnings

    warnings.simplefilter('always')

    class TestMonoWorker(TestCase):
        def test_submit_task(self):
            def f(x):
                sleep(x)
                return x

            mw = MonoWorker()
            self.assertEqual(mw.submit(f, 5), None)
            self.assertEqual(mw.submit(f, 0), None)
            self.assertEqual(mw.submit(f, 5), None)
            self.assertEqual(mw.submit(f, 0), None)
            self.assertEqual(mw.submit(f, 5), None)
            self.assertEqual(mw.submit(f, 4), None)

# Generated at 2022-06-24 10:08:23.250399
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from copy import copy
    tqdm_auto.write('Testing MonoWorker.submit()')

    def foo(i):
        sleep(i)
        return i

    def test(futures):
        futures[:] = [f.result() for f in futures]

    with MonickWorker() as w:
        fs = []
        for i in range(5):
            fs.append(w.submit(foo, 2))
        test(fs)
        assert copy(fs) == [2]
        for i in range(5):
            fs.append(w.submit(foo, 2))
        test(fs)
        assert copy(fs) == [2]
        for i in range(5):
            fs.append(w.submit(foo, 5))
        test(fs)

# Generated at 2022-06-24 10:08:34.152260
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test `MonoWorker.submit`."""
    import time
    import threading
    from ..utils import _range

    def id_func(i):
        time.sleep(1)
        return i
    def bad_func(i):
        raise Exception('test_MonoWorker_submit: ' + str(i))

    worker = MonoWorker()
    for i in _range(4):
        worker.submit(id_func, i)  # 4 sleeping tasks
    worker.submit(id_func, 4)  # 3rd task fails
    worker.submit(id_func, 5)  # 3rd task fails
    worker.submit(id_func, 6)  # 4th task fails
    worker.submit(id_func, 7)  # succeeds
    worker.submit(bad_func, 8)  # 5

# Generated at 2022-06-24 10:08:41.981787
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def test_submit():
        with tqdm_auto.tqdm(total=0, desc='MonoWorker', ncols=50,
                            dynamic_ncols=True) as pbar:
            pbar.set_postfix_str('your name (q to quit)')
            mono = MonoWorker()
            while True:
                name = yield
                if name in 'qQ':
                    break
                if name is not None:
                    mono.submit(pbar.write, 'Name: {}'.format(name))
    ts = test_submit()  # prime

    ts.send(next(ts))
    for i, name in enumerate(['Alice', 'Bob', 'Cathy', 'David', 'Eric'], 1):
        ts.send(name)

# Generated at 2022-06-24 10:08:50.862040
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def tfunc(n):
        for _ in range(n):
            sleep(.01)

    with MonoWorker() as worker:
        print('submit 1')
        f1 = worker.submit(tfunc, 10)
        print('submit 2')
        f2 = worker.submit(tfunc, 10)
        print('submit 3')
        f3 = worker.submit(tfunc, 10)
        print('wait 1')
        f1.result()
        print('wait 2')
        f2.result()
        print('wait 3')
        f3.result()



# Generated at 2022-06-24 10:08:58.333318
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from . import tqdm

    def foo(a):
        time.sleep(2)
        return a + 1

    with tqdm.tqdm(desc="Foo", total=6) as pbar:
        worker = MonoWorker()
        futures = []
        for i in range(6):
            f = worker.submit(foo, i)
            f.add_done_callback(lambda f, pbar=pbar: pbar.update())
            futures.append(f)
        for future in futures:
            future.result()

# Generated at 2022-06-24 10:09:01.144600
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def _test(pool, pool_max_workers):
        assert pool.__class__ == ThreadPoolExecutor
        assert pool._max_workers == pool_max_workers
    _test(MonoWorker().pool, 1)



# Generated at 2022-06-24 10:09:07.051467
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test method submit of class MonoWorker:
    """
    import time
    from concurrent.futures import Future
    from builtins import range

    def assert_equal(val1, val2):
        """
        Assert that the first value equals (`==`) the second value.
        """
        if val1 != val2:
            from .tests import get_exception_message
            raise AssertionError(get_exception_message(val1, val2))

    test_parameters_list = [
        (0,),
        (1,),
        (2,),
        (4,)]

    error_message = "Chosen max_workers parameter is not suitable!"

    for max_workers in test_parameters_list:
        mworker = MonoWorker()
        mworker.pool = ThreadPool

# Generated at 2022-06-24 10:09:12.814183
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    #wait here for 10 seconds
    def wait():
        time.sleep(10)

    #confirm waiting calls are dequeued and executed
    def wait_print():
        print("Waiting...")
        wait()
        print("Done!")

    m = MonoWorker()
    m.submit(wait)
    m.submit(wait_print)
    m.submit(wait_print)
    m.submit(wait_print)
    m.submit(wait_print)
    m.submit(wait)
    time.sleep(1)
    m.submit(wait_print)

# Generated at 2022-06-24 10:09:23.656662
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Tests:
        # normal (submit and run)
        # submit while running
        # submit while waiting
        # submit while running, waiting
        # cancel running
        # cancel waiting
        # cancel running and waiting
    from time import sleep

    def waiting_func(*args, **kwargs):
        sleep(4)
        return args

    mono = MonoWorker()

    # normal (submit and run)
    res = mono.submit(waiting_func, 1, 2, 3, a=4, b=5, c=6)
    assert res.result() == (1, 2, 3)
    assert res.done()

    # submit while running
    res = mono.submit(waiting_func, 1, 2, 3, a=4, b=5, c=6)
    assert res.done()

    # submit while waiting

# Generated at 2022-06-24 10:09:32.985251
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono = MonoWorker()
    def sleeper(n):
        time.sleep(n)
    mono.submit(sleeper, 1) # execution starts
    mono.submit(sleeper, 9) # execution of first task replaced by second one
    mono.submit(sleeper, 0.5) # execution of second task not replaced
    mono.submit(sleeper, 0.1) # does not have time to be executed
    time.sleep(0.5)
    # assert that only second task is done
    assert len(mono.futures) == 1
    assert mono.futures[0].result() == 9
    # assert there is no running task
    assert len(mono.pool._threads) == 0
    assert len(mono.pool._work_queue) == 0
    # empty all futures

# Generated at 2022-06-24 10:09:42.875664
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def foo(my_idx, wait_time, bar=None):
        time.sleep(wait_time)
        return my_idx

    # init
    mworker = MonoWorker()

    # submit 3 tasks: 1, 2, 3
    futs = [mworker.submit(foo, idx, 0) for idx in range(1, 4)]
    # wait for task 1 to finish
    time.sleep(0.01)
    # submit 3 more tasks: 4, 5, 6
    futs += [mworker.submit(foo, idx, 0) for idx in range(4, 7)]
    # wait for task 2 to finish
    time.sleep(0.01)
    # submit 2 more tasks: 7, 8

# Generated at 2022-06-24 10:09:49.604682
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Unit test for method submit of class MonoWorker
    import time

    mw = MonoWorker()
    a = 'a'
    b = 'b'
    results = []

    def foo(c, d):
        time.sleep(.2)
        results.append(c)
        return d

    tqdm_auto.write('before submit')
    future1 = mw.submit(foo, a, b)
    time.sleep(.1)
    tqdm_auto.write('before submit')
    future2 = mw.submit(foo, b, a)
    tqdm_auto.write(
        'future1.done() = {}, future2.done() = {}'.format(future1.done(),
                                                          future2.done()))
    time.sleep(.5)
   

# Generated at 2022-06-24 10:09:56.179037
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    n = 5
    mw = MonoWorker()

    def sleeptask():
        time.sleep(random.random() * 0.5 + 0.1)

    # Try to run task n times
    for _ in range(n):
        mw.submit(sleeptask)
    # Wait until all finished
    while (len(mw.futures) > 0):
        time.sleep(0.01)
    assert len(mw.futures) == 0



# Generated at 2022-06-24 10:10:05.038442
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from sys import stdout
    import logging
    logging.basicConfig(level=logging.DEBUG)

    def func(x, *args, **kwargs):
        from sys import stderr
        sleep(1)
        print("x: " + str(x), file=stderr)
        return x

    mw = MonoWorker()
    for x in tqdm_auto.trange(10, file=stdout):
        # Execute `func` asynchronously
        mw.submit(func, x)

# Generated at 2022-06-24 10:10:12.927608
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import queue
    import time
    import threading

    def concurrent_task(q, num_tasks=3):
        tqdm_auto.write('+ consumer ' + threading.current_thread().name)
        tasks = []
        for i in range(num_tasks):
            tasks.append(MonoWorker_obj.submit(task_factory, i))
        for i in range(num_tasks):
            q.put(tasks[i].result())
        tqdm_auto.write('- consumer ' + threading.current_thread().name)

    def task_factory(i):
        import time
        tqdm_auto.write('> producer ' + threading.current_thread().name +
                        ': ' + str(i))
        time.sleep(2)
        return i

   

# Generated at 2022-06-24 10:10:14.840852
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from . import MonoWorker
    mono = MonoWorker()
    assert mono.futures.maxlen == 2

# Generated at 2022-06-24 10:10:26.026714
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from Queue import Queue
    from ..std.weakref_backports import WeakMethod
    queue = Queue()
    mono = MonoWorker()
    func_1 = WeakMethod(queue.put, 1)
    func_2 = WeakMethod(queue.put, 2)
    func_3 = WeakMethod(queue.put, 3)
    func_4 = WeakMethod(queue.put, 4)
    mono.submit(func_1)
    assert queue.qsize() == 0
    mono.submit(func_2)
    mono.submit(func_3)
    assert queue.qsize() == 0
    time.sleep(1)
    assert queue.qsize() == 1
    assert queue.get() == 2
    mono.submit(func_4)

# Generated at 2022-06-24 10:10:27.763261
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    mw.submit(lambda: None)
    mw.submit(lambda: None)


# Generated at 2022-06-24 10:10:31.643600
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    def test_func():
        """Some unit-test function"""

    monoworker = MonoWorker()
    assert monoworker is not None

    # test submit a task
    task = monoworker.submit(test_func)
    assert task is not None

    # test get() method of task
    assert task.done() is False
    assert task.cancel() is False
    assert task.get() is None

# Generated at 2022-06-24 10:10:40.430023
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures
    import time

    def f(_):
        return _

    def test_submit(executor):
        import sys
        sys.stderr.write("")  # flush stderr
        t0 = time.time()
        futures = deque()
        for i in tqdm_auto.tqdm(range(1, 4 + 1)):
            futures.append(executor.submit(f, i))
            while len(futures) > 2:
                futures.popleft().result()
        for future in tqdm_auto.tqdm(futures):  # resolve remaining futures
            future.result()
        t1 = time.time()
        return time.time() - t1

    # Unit test for this module

# Generated at 2022-06-24 10:10:47.561193
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def test_func(start_time):
        """Test function with a sleep of length `start_time`"""
        time.sleep(start_time)
        return time.time()

    pool = MonoWorker()
    start = time.time()
    future = pool.submit(test_func, start)
    while not future.done():
        time.sleep(0.1)
        tqdm_auto.write('Still sleeping {0:.2f}'.format(time.time()-start))
        future2 = pool.submit(test_func, start)
        while not future2.done():
            time.sleep(0.1)
            tqdm_auto.write('Still sleeping {0:.2f} (2)'.format(time.time()-start))
    tq

# Generated at 2022-06-24 10:10:57.946254
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from threading import Thread
    from time import sleep

# Generated at 2022-06-24 10:11:03.054107
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Event
    from threading import Semaphore
    from multiprocessing import Queue

    sleep_data = 0.001

    def print_str(str_):
        sleep(sleep_data)
        return str_

    def print_str_sleep(str_):
        sleep(sleep_data * 2)
        return str_

    colon = ':'
    ma = 'ma'
    pa = 'pa'
    me = 'me'
    pe = 'pe'
    mp = 'mp'
    pp = 'pp'
    mo = 'mo'
    po = 'po'
    mq = 'mq'
    pq = 'pq'
    mm = 'mm'
    pm = 'pm'

    # unit test for _start and _retreive
   

# Generated at 2022-06-24 10:11:12.869095
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Event

    workers = MonoWorker()
    wait = Event()

    def wait_task():
        wait.wait()

    def busy_task():
        sleep(6)

    def fail_task():
        raise Exception("Should be discarded")

    wait.clear()
    workers.submit(wait_task)
    assert wait_task not in workers.futures

    wait.set()
    workers.futures[0].result()  # wait
    assert wait_task not in workers.futures

    workers.submit(busy_task)
    assert busy_task in workers.futures

    workers.submit(wait_task)
    assert busy_task in workers.futures
    assert wait_task not in workers.futures

    workers.submit(fail_task)

# Generated at 2022-06-24 10:11:20.864500
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    mono_worker = MonoWorker()
    assert mono_worker.futures == deque([], 2)

    mono_worker.submit(sleep, 0.1).result()
    assert len(mono_worker.futures) == 1
    mono_worker.submit(sleep, 0.1).result()
    assert len(mono_worker.futures) == 2
    mono_worker.submit(sleep, 0.1).result()
    assert len(mono_worker.futures) == 2
    mono_worker.futures[0].result()
    assert len(mono_worker.futures) == 1
    mono_worker.futures[0].result()
    assert len(mono_worker.futures) == 0

# Generated at 2022-06-24 10:11:25.327760
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    assert MonoWorker()
    mw = MonoWorker()
    f = mw.submit(time.sleep, 0.1)
    assert f.done()
    assert mw.submit(time.sleep, 10)
    time.sleep(0.1)
    assert f.done()
    assert mw.submit(time.sleep, 0.1)
    time.sleep(0.2)
    assert f.done()
    assert mw.submit(time.sleep, 0.1)

# Generated at 2022-06-24 10:11:35.784294
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time, random
    from concurrent.futures import as_completed
    from .remote_bar import RemoteBar

    rbar = RemoteBar()

    mono = MonoWorker()
    futures = []
    for i in range(3):
        futures.append(mono.submit(rbar, "foobar", "foo", i/5, i,
                                   incr=False, desc=str(i),
                                   desc_postfix_color='yellow'))
        time.sleep(random.uniform(0, 0.2))

    for f in as_completed(futures):
        tqdm_auto.write("{} returned: {}".format(f, f.result()))

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:11:40.195524
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> from ._utils import MonoWorker
    >>> MonoWorker()
    <tqdm._utils.MonoWorker object at 0x11e80e668>
    """

# Generated at 2022-06-24 10:11:46.097534
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> m = MonoWorker()
    >>> m.submit(print, '1')
    >>> m.submit(print, '2')
    >>> m.submit(print, '3')
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod(name="MonoWorker", verbose=False)

# Generated at 2022-06-24 10:11:50.224791
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()
    assert list(m.futures) == []
