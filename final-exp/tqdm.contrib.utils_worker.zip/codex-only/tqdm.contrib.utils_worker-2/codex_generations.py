

# Generated at 2022-06-24 10:01:59.237010
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func(x, y=0):
        import time
        time.sleep(1)
        return x + y

    worker = MonoWorker()

    worker.submit(func, 1)
    func2 = worker.submit(func, 2)
    worker.submit(func, 3)
    worker.submit(func, 4, y=4)

    assert func2.result() == 2

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:02:09.879254
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    from time import sleep
    from threading import Thread

    def func(n, x):
        sleep(x)
        return n, x

    mw = MonoWorker()
    a = mw.submit(func, 'a', 2)
    b = mw.submit(func, 'b', 1)  # replace waiting task
    c = mw.submit(func, 'c', 1.5)  # replace running task
    d = mw.submit(func, 'd', 1)  # replace running task

    def wait_for_a():
        assert a.result() == ('a', 2)

    assert b.result() == ('b', 1)
    assert c.result() == ('c', 1.5)
    assert d.result() is None

# Generated at 2022-06-24 10:02:19.180028
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import Value, Process

    def dosub(cnt, val, sleeptime=0.1, canceltime=1):
        from time import sleep
        with MonoWorker() as mw:
            for i in range(cnt):
                mw.submit(sleep, sleeptime)
                if i == canceltime:
                    val.value = 1
                    sleep(sleeptime * 1.5)
                    val.value = 0
    count = Value('i', 0)
    cnt = 10
    proc = Process(target=dosub, args=(cnt, count,),
                   kwargs={'canceltime': 6})

# Generated at 2022-06-24 10:02:25.934861
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    m = MonoWorker()
    assert len(m.futures) == 0
    m.submit(time.sleep, 1)
    assert len(m.futures) == 1
    m.submit(time.sleep, 2)
    assert len(m.futures) == 1
    m.submit(time.sleep, 3)
    assert len(m.futures) == 1
    time.sleep(2)
    assert len(m.futures) == 0

# Generated at 2022-06-24 10:02:34.530212
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f1():
        time.sleep(0.1)

    def f2():
        time.sleep(0.2)  # f2 takes longer

    def f3():
        time.sleep(0.3)  # f3 takes even longer

    def f4():
        time.sleep(0.4)  # f4 takes even longer

    mw = MonoWorker()
    # test that first task is executed in a timely manner
    t0 = time.time()
    mw.submit(f1)
    assert time.time() - t0 < 0.2

    # test that second task is replaced by third
    t0 = time.time()
    mw.submit(f2)  # queued without execution
    mw.submit(f3)  # queued (replaces f2)


# Generated at 2022-06-24 10:02:40.352970
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing
    import time
    import asyncio

    min_sleep = 1.0 / multiprocessing.cpu_count()

    # simulate real-world workload:
    #   heavy task, easily interruptible (e.g. waiting for socket IO)
    def heavy_work(n):
        time.sleep(min_sleep)
        return n

    async def async_heavy_work(n):
        await asyncio.sleep(min_sleep)
        return n

    async def main():
        for n in range(4):
            time.sleep(min_sleep / 2)
            r = await async_heavy_work(n)
            if r != n:
                print("test fail")
                print(n, r)
                return
            if n > 2:
                print("test success")
                return

    worker

# Generated at 2022-06-24 10:02:47.139175
# Unit test for constructor of class MonoWorker
def test_MonoWorker():

    import time
    import random
    import threading
    from ..utils import _term_move_up

    def t(x):
        _term_move_up()
        tqdm_auto.write("Wating {:.3f}s".format(x))
        time.sleep(x)
        _term_move_up()
        return x

    w = MonoWorker()
    running = w.submit(t, 1)
    time.sleep(.5)
    with tqdm_auto.tqdm() as t:
        while not running.done():
            tqdm_auto.write("Running")
            w.submit(t, random.random() * 1.5 + .5)
            t.update()
            time.sleep(.1)

# Generated at 2022-06-24 10:02:58.199596
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import random
    import threading
    import time
    import unittest

    class MonoWorkerTest(unittest.TestCase):
        def test_submit_monoworker(self):
            m = MonoWorker()
            # Simulate work
            ev = threading.Event()
            wait = 0.050  # s

            def worker_func(task_id, task_duration):
                time.sleep(task_duration)
                ev.set()

            for i in range(4):
                wait_seconds = (2 * random.random())
                m.submit(worker_func, i, wait_seconds)
                time.sleep(wait)
                ev.wait()
                ev.clear()

    if __name__ == '__main__':
        unittest.main(verbosity=2)

# Generated at 2022-06-24 10:03:09.278758
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import functools
    import multiprocessing
    from concurrent.futures import TimeoutError

    def _get_lbl(val):
        return '%d' % val

    def _sleep(exp, cmp=None, lbl='', lbl_f=_get_lbl):
        if cmp is None:
            cmp = functools.partial(operator.__gt__, exp)
        lbl = '(%s)' % lbl if lbl else ''

        with tqdm_auto.tqdm(
                desc='_sleep %d %s' % (exp, lbl),
                leave=True, dynamic_ncols=True,
                unit='times', unit_scale=1, unit_divisor=1) as t:
            times = 0

# Generated at 2022-06-24 10:03:18.951100
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .._tqdm import tqdm

    def wait(sec):
        with tqdm(total=sec, bar_format='{desc}:  {percentage:3.0f}%|{bar}|',
                  leave=False, disable=True) as pbar:
            for i in range(sec):
                time.sleep(1)
                pbar.update()

    def submit_list(list_seq, mono_w, func):
        for i in list_seq:
            mono_w.submit(func, i)

    mono_worker = MonoWorker()
    submit_list([6, 2, 5], mono_worker, wait)
    for i in range(4):
        time.sleep(1)
    submit_list([2, 3, 7], mono_worker, wait)

# Generated at 2022-06-24 10:03:26.154045
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    def task(i, dt):
        time.sleep(dt)
        return i
    MW = MonoWorker()
    max_workers = MW.pool._max_workers
    print('max_workers =', max_workers)
    # submit 2 * max_workers work items
    futs = [MW.submit(task, i, random.random()) for i in range(max_workers * 2)]
    assert len(MW.futures) == max_workers
    for f in futs:
        f.result()
    # submit one more -> discard waiting
    f = MW.submit(task, max_workers * 2, random.random())
    assert len(MW.futures) == max_workers
    f.result()

# Generated at 2022-06-24 10:03:37.946591
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(i, timeout=0):
        time.sleep(timeout)
        return i

    worker = MonoWorker()
    assert worker.submit(f, 0).result() == 0  # 1s
    assert worker.submit(f, 0, 1).result() == 0  # 2s
    assert worker.submit(f, 1, 1) is None  # 3s
    assert worker.submit(f, 1, 1).result() == 1  # 4s
    assert worker.submit(f, 2, 1).result() == 2  # 5s
    assert worker.submit(f, 2, 1) is None  # 6s
    assert worker.submit(f, 2, 1) is None  # 7s
    assert worker.submit(f, 3, 1).result() == 3  # 8s

# Generated at 2022-06-24 10:03:48.001333
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> from time import sleep
    >>> worker = MonoWorker()
    >>> fut1 = worker.submit(sleep, 0.5)  # a long sleeper...
    >>> fut2 = worker.submit(lambda x: x, 1)  # ...replaced by a quick returner
    >>> fut2.result()
    1
    >>> worker.submit(sleep, 0.5)  # ...but queued again after returner
    >>> fut1.result()
    """
    pass
    # print("\n{}\n{}\n{}".format(_test_MonoWorker_submit[0], _test_MonoWorker_submit[1], _test_MonoWorker_submit[2]))

    # from tqdm.contrib.tests._test_MonoWorker import _test_MonoWorker_submit


# Generated at 2022-06-24 10:03:51.299604
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    mw = MonoWorker()
    assert mw.pool.__class__.__name__ == 'ThreadPoolExecutor'
    assert mw.pool._max_workers == 1



# Generated at 2022-06-24 10:04:01.950363
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from unittest import TestCase, main

    def func(x):
        time.sleep(x)
        return x

    class _TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()

        def test_submit(self):
            t = time.time()
            self.mw.submit(func, 1)
            self.mw.submit(func, 1)
            self.mw.submit(func, 3)
            self.mw.submit(func, 2)
            self.assertAlmostEqual(time.time() - t, 3, delta=0.2)
            self.mw.submit(func, 1)

        def test_submit_exception(self):
            t = time.time()
            self.mw.submit

# Generated at 2022-06-24 10:04:03.089717
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    MonoWorker()



# Generated at 2022-06-24 10:04:08.889718
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import sys

    def test_print(text):
        sleep(0.01)
        print(text)
        sys.stdout.flush()

    mw = MonoWorker()
    for c in 'abcdefgh':
        mw.submit(test_print, c)
    for f in mw.futures:
        f.result()

# Generated at 2022-06-24 10:04:16.735242
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mono = MonoWorker()
    assert mono.futures.maxlen == 2
    assert len(mono.futures) == 0
    assert mono.pool._max_workers == 1
    assert mono.pool._workers  # should spawn a worker
    assert mono.pool.shutdown(wait=True)



# Generated at 2022-06-24 10:04:29.831784
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test `MonoWorker.submit`"""
    from ..auto import tqdm
    # toy function
    import time
    def f(x):
        time.sleep(0.1)
        return x

    # check that only one thread is active at a time
    mw = MonoWorker()
    results = []
    for i in tqdm_auto.tqdm([1, 2, 3, 4]):
        mw.submit(f, i)

    # wait for previous taks
    for i in tqdm_auto.tqdm([1, 2, 3, 4]):
        waiting = mw.futures.popleft()
        rets = waiting.result()
        results.append(rets)
        time.sleep(0.1)

    # check results
    assert rets == 4

# Generated at 2022-06-24 10:04:40.603177
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    mono = MonoWorker()

    def _F(i, d=1):
        sleep(d)
        return i

    def _G(i, d=1):
        sleep(d)
        return i

    assert mono.submit(_F, 1, d=1).result() == 1
    assert mono.submit(_F, 2, d=2).result() == 1  # discarded
    assert mono.submit(_F, 3, d=3).result() == 1
    assert mono.submit(_F, 4, d=4).result() == 1
    assert mono.submit(_F, 5, d=5).result() == 1
    assert mono.submit(_F, 6, d=6).result() == 1
    assert mono.submit(_F, 7, d=7).result() == 1
    assert mono.submit

# Generated at 2022-06-24 10:04:45.541593
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    for _ in [1, 2, 3, 4]:
        mw.submit(lambda: print('print'))

# print('result: ', end='')
# mw.submit(lambda: print('print'))
# print('result: ', end='')
# mw.submit(lambda: print('print'))
# print('result: ', end='')

# Generated at 2022-06-24 10:04:48.727713
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random

    def delayed_0(x):
        time.sleep(x)
        return x

    def test_worker(delayed):
        worker = MonoWorker()

        # submit 3 delayed tasks
        for _ in range(3):
            worker.submit(delayed, random.random())

        # retrieve 2 delayed tasks
        assert(len(worker.futures) == 2)
        [f.result() for f in worker.futures]

    test_worker(delayed_0)

# Generated at 2022-06-24 10:04:51.769613
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .utils import _get_mono_func

    mw = MonoWorker()

    # shouldn't work with default arguments
    assert mw.submit(lambda: None) is None

    # should work with two arguments
    assert mw.submit(_get_mono_func, 1, 2) is not None

# Generated at 2022-06-24 10:05:00.305312
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method `submit` of class `MonoWorker`."""
    import time

    def run_forever():
        while True:
            time.sleep(1)

    from contextlib import contextmanager

    @contextmanager
    def in_main_thread():
        try:
            yield
        except KeyboardInterrupt:
            pass

    try:
        with in_main_thread():
            worker = MonoWorker()
            for _ in tqdm_auto.trange(5, desc='Submitted', ascii=True):  # noqa
                worker.submit(run_forever)
                time.sleep(1)
    except KeyboardInterrupt:
        print('Interrupted by user')

# Generated at 2022-06-24 10:05:05.977504
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random

    def foo(x):
        time.sleep(random.random() / 5)
        return x

    mw = MonoWorker()

    # Testing infinite Iterable
    tqdm_auto.write("Testing infinite Iterable")
    for i in tqdm_auto.tqdm(mw.submit(foo, i) for i in range(100)):
        tqdm_auto.write("Output {0}".format(i))

# Generated at 2022-06-24 10:05:14.156848
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from inspect import getsource
    from time import sleep

    assert getsource(MonoWorker.__init__) == getsource(MonoWorker)

    mw = MonoWorker()

    def fake_func(*args, **kwargs):
        return args, kwargs

    def test_submit():
        """Test for `MonoWorker.submit`."""
        assert mw.submit(fake_func, 1, 2, x=3) is not None

    # try submitting twice
    test_submit()
    sleep(0.1)
    mw.submit(fake_func, 4, 5, x=6)

    # both should complete with correct arguments
    assert mw.submit(fake_func, 7, 8, x=9).result() == ((4, 5), {'x': 6})

# Generated at 2022-06-24 10:05:21.935587
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def print_msg(msg):
        sleep(0.2)

# Generated at 2022-06-24 10:05:28.548787
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test if MonoWorker is working well."""
    from ..utils import _range
    import time
    m = MonoWorker()

    def f(i):
        time.sleep(3)
        return i+1

    with tqdm_auto.tqdm(total=10, position=0, leave=True) as bar:
        for i in _range(bar.total):
            bar.update()
            m.submit(f, i)


# Generated at 2022-06-24 10:05:36.460406
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from unittest.mock import MagicMock

    mw = MonoWorker()
    f = MagicMock()
    waiting = mw.submit(f, 1)
    assert f.mock_calls == [('__call__', (1,), {})]
    f.mock_calls.clear()
    mw.submit(sleep, 3, 2)
    sleep_future = mw.submit(sleep, .1)
    assert f.mock_calls == []
    assert sleep_future.done()
    assert not waiting.done()



# Generated at 2022-06-24 10:05:37.786425
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker.pool._max_workers == 1, worker.pool._max_workers

# Generated at 2022-06-24 10:05:46.908094
# Unit test for constructor of class MonoWorker
def test_MonoWorker():

    from ..auto import trange
    from concurrent.futures import as_completed, TimeoutError
    from time import sleep

    def wait_until(predicate, delay=0.1, max_tries=10):
        """Wait until predicate is True or max_tries exceeded"""
        from itertools import count
        for _ in trange(max_tries, desc='wait_until'):
            if predicate():
                break
            sleep(delay)
        else:
            raise ValueError('wait_until max_tries exceeded')

    def is_one_running():
        return sum(1 for f in futures if f.running()) == 1

    mw = MonoWorker()
    futures = []
    with trange(10, desc='test_MonoWorker') as t:
        for _ in t:
            futures

# Generated at 2022-06-24 10:05:53.353002
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .utils import TestAsyncIter, TestException

    t = TestAsyncIter()

    async def async_await(message, sleep_time):
        await t.ping()
        await t.ping(exception=TestException(message))
        await t.ping(message=message)
        await async_sleep(sleep_time)
        await t.ping(message=message)

    async def async_sleep(sleep_time):
        await t.ping(message=None)
        sleep(sleep_time)
        await t.ping()

    def sleep_printer(sleep_time):
        for i in tqdm_auto.tqdm(MonoWorker().submit(async_sleep, sleep_time),
                                desc='Waiting',
                                unit='sec'):
            pass
    sleep_

# Generated at 2022-06-24 10:06:01.850758
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future  # import here to avoid errors
    from time import sleep
    from .utils import print_done  # noqa

    worker = MonoWorker()

    def task(duration):
        sleep(duration)
        return "done"

    task1 = worker.submit(task, 0.1)
    task2 = worker.submit(task, 0.2)
    task3 = worker.submit(task, 0.3)
    assert task1.cancelled()
    assert task2.done()
    assert task3.done()
    assert task3.result() == "done"
    assert task2.result() == "done"

    task1 = worker.submit(task, 0.1)
    task2 = worker.submit(task, 0.2)
    assert task1.running()
    assert task

# Generated at 2022-06-24 10:06:10.160420
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from os import getpid
    import time
    import resource
    pid = getpid()
    mw = MonoWorker()
    for i in range(4):
        mw.submit(time.sleep, 0.1)
    mw.submit(time.sleep, 0.1)
    mw.submit(time.sleep, 0.1)
    mw.submit(time.sleep, 0.1)
    mw.submit(resource.getrusage, resource.RUSAGE_SELF).result()
    mw.submit(resource.getrusage, resource.RUSAGE_CHILDREN).result()
    pgrp, unused_jobc = resource.getpgid(pid)

# Generated at 2022-06-24 10:06:14.290186
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    mw = MonoWorker()

    def run(s):
        time.sleep(s)
        tqdm_auto.write("Finished sleeping %s seconds." % s)

    mw.submit(run, 5)
    mw.submit(run, 3)
    mw.submit(run, 1)

# Generated at 2022-06-24 10:06:20.049015
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from itertools import count

    random.seed(4)
    mw = MonoWorker()

    def random_work():
        time.sleep(0.3 * random.random())

    def test_func(i):
        random_work()
        return i

    for i in count():
        mw.submit(test_func, i)
        time.sleep(0.03)
        if i == 20:
            break


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:06:24.732514
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    mw.submit(time.sleep, 0.01)
    t0 = time.time()
    mw.submit(time.sleep, 0.1)
    t1 = time.time()
    assert t1 - t0 < 0.03


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:06:26.210237
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test"""
    _ = MonoWorker()


# Generated at 2022-06-24 10:06:34.552385
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import os
    import sys
    import threading
    class SilentTqdmFile(tqdm_auto._file_like.FileWrapper):
        def write(self, x):
            pass
    def write(x):
        with tqdm_auto.tqdm(total=1,
                            file=SilentTqdmFile(sys.stdout),
                            miniters=1) as pbar:
            pbar.update()
    mworker = MonoWorker()
    def test_threader(i):
        time.sleep(0.1 * random.random())
        write("%s %s" % (i, os.getpid()))
    for i in range(20):
        mworker.submit(test_threader, i)

# Generated at 2022-06-24 10:06:39.898631
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test `MonoWorker` for consistency, thread safety, and deadlock."""
    worker = MonoWorker()

    def long_task():
        import time
        time.sleep(1)

    worker.submit(long_task)
    worker.submit(long_task).result()


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:06:44.892418
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from os import getpid
    from multiprocessing import cpu_count

    def test_func():
        sleep(0.5)
        return getpid()

    mw = MonoWorker()
    # submit 2 tasks concurrently
    f0 = mw.submit(test_func)
    f1 = mw.submit(test_func)
    # f1 should replace f0
    assert f1.result() != f0.result()

    # submit 10 tasks concurrently
    # they should all return the same pid
    pid = mw.submit(test_func).result()
    for i in range(cpu_count()):
        assert pid == mw.submit(test_func).result()

# Generated at 2022-06-24 10:06:51.428718
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()

    def wait_x_seconds(x):
        time.sleep(x)

    assert mw.submit(wait_x_seconds, 1).result() is None
    assert mw.submit(wait_x_seconds, 2).result() is None
    assert mw.submit(wait_x_seconds, 3).result() is None
    # 1st future + result are discarded

# Generated at 2022-06-24 10:06:58.950364
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Lock, Condition, Thread
    from time import sleep
    from collections import defaultdict
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.lock = Lock()
            self.cond = Condition()
            self.d = defaultdict(int)
            self.pool = MonoWorker()

        def test_submit_1(self):
            with self.lock, self.cond:
                self.pool.submit(self.a, 'a1')
                self.pool.submit(self.b, 'b1')
                self.pool.submit(self.a, 'a2')
                self.pool.submit(self.b, 'b2')
                self.d['a1'] += 1
                self.d['b2'] += 1
                self.validate

# Generated at 2022-06-24 10:07:07.891319
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _term_move_up
    from ..std import time as time_std

    def test_function(msg, t):
        time.sleep(t)
        tqdm_auto.write(msg)

    # Submit test function twice and then submit a third time
    # to force second task to go from waiting to running and back.
    # After test completes, all tasks should be done or cancelled.
    mono = MonoWorker()
    mono.submit(test_function, 'a', 1.0)
    mono.submit(test_function, 'b', 2.0)
    mono.submit(test_function, 'c', 0.1)
    time_std.sleep(3.0)

    f = mono.futures.pop()

# Generated at 2022-06-24 10:07:17.585504
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys

    def test_func(delay=0.1, x=2, y=3):
        time.sleep(delay)
        return x * y

    mw = MonoWorker()

    assert mw.submit(test_func, 0.1)  # should sleep for 0.1 s
    assert mw.submit(test_func, x=4, y=2)  # should overwrite #1
    assert mw.submit(test_func, 0.01, x=3)  # should overwrite #2
    assert mw.submit(test_func, x=5, y=3)  # should overwrite #3

    for _ in mw.futures:
        print(_.result())

# Generated at 2022-06-24 10:07:30.438385
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread

    def some_func(a):
        sleep(0.5)
        return a * a

    def test_thread_func(worker, n, n1):
        for i in range(n1):
            if i != n:
                worker.submit(some_func, i)
                # print('submit', i)

    # Test `MonoWorker` in multithreading
    N = 3
    N1 = 100
    MW = MonoWorker()
    for _ in range(N):
        Thread(target=test_thread_func, args=(MW, 1, N1)).start()
    sleep(0.1)
    assert MW.futures[0].result() == 1


# Generated at 2022-06-24 10:07:38.659600
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import _term_move_up

    def slow_print(string):
        from time import sleep
        from random import random
        from sys import stdout

        for char in string:
            stdout.write(char)
            stdout.flush()
            sleep(0.1 + random() * 0.2)

    def muint():
        try:
            from msvcrt import getch
        except ImportError:
            from getch import getch
        while True:
            while True:
                c = getch()
                if c == 'q':
                    break
                if c == 'r':
                    return
                print("\r" + " " * 20 + "\r", end="")
            else:
                print("\r" + " " * 20 + "\r", end="")
                return


# Generated at 2022-06-24 10:07:45.578082
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .tests import print_, naturals, values_of

    def delay(duration):
        sleep(duration)
        print_('Delayed for {} seconds.'.format(duration))

    mono_worker = MonoWorker()
    for _ in naturals():
        for duration in values_of(1):
            mono_worker.submit(delay, duration)
            sleep(duration)


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:07:55.449045
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from unittest.util import safe_repr
    from time import sleep
    from .tests_tqdm import with_setup

    def check_list(instance, expected_list=None, msg=None):
        """Check that `deque` is equal to expected list.
        Parameters
        ----------
        instance : :class:`~collections.deque`
        expected_list : :class:`~list`
        msg : :class:`~basestring`
            message passed to `assertEqual`
        """
        if expected_list is None:
            expected_list = []

# Generated at 2022-06-24 10:07:58.877937
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker"""
    mono = MonoWorker()
    assert mono.pool
    assert mono.futures

# Generated at 2022-06-24 10:08:10.667445
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from tqdm._utils import _term_move_up

    from time import sleep
    from random import randint

    def print_done(i):
        print(i)
        sleep(0.1)

    def print_slow(i):
        print(i)
        sleep(0.5)

    def print_cancel(i):
        print(i)
        sleep(0.5)
        raise Exception("cancelled")

    def print_error(i):
        sleep(0.1)
        raise Exception("Error %r" % i)

    def print_strange(i):
        sleep(0.1)
        return (1.0 - 1.0j) * i

    def print_very_strange(i):
        sleep(0.1)

# Generated at 2022-06-24 10:08:17.789333
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    from .utils import TestCase, open_atomic

    class Test(TestCase):
        def test_mono_worker(self):
            rng = random.Random(1)
            worker = MonoWorker()

            for _ in tqdm_auto.tqdm(range(100), desc="test"):
                time.sleep(rng.randint(0, 5) / 100)
                with open_atomic("test", "a") as f:
                    f.write('.')
                worker.submit(self.assertFalse, f.closed)

# Generated at 2022-06-24 10:08:28.885818
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import current_thread
    from random import randint
    from time import sleep
    from sys import stderr
    from itertools import islice
    from contextlib import contextmanager

    def slow_func(n, msg, running_str="running",
                  waiting_str="waiting", time=0.01):
        """Slow function."""
        thread = current_thread()
        sleep(time)
        if n % 2 == 0:
            raise RuntimeError("{} {}: {}: {}"
                               .format(n, type(thread).__name__,
                                       thread.getName(), msg))
        tqdm_auto.write("{} {}: {}: {}"
                        .format(n, type(thread).__name__,
                                thread.getName(), msg))

        tqdm_auto

# Generated at 2022-06-24 10:08:37.751846
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    evt = Event()
    tqdm_auto.write('(initial message)')

    def f(x):
        """Sleep x seconds and print a message."""
        sleep(x)
        tqdm_auto.write('test_MonoWorker_submit {0}'.format(x))
        evt.set()

    worker = MonoWorker()
    # Queue an expensive task
    worker.submit(f, 5)
    # Replace the task with an immediate one
    worker.submit(f, 0)
    # Check that it is executed and the other is discarded
    assert evt.wait(10), "MonoWorker test timed out"

# Generated at 2022-06-24 10:08:45.144253
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm._utils import _term_move_up
    from multiprocessing import Queue

    # The following code is for asserting that tasks are executed by
    # multiple threads without unwanted overlapping.
    queue = Queue()
    try:
        from queue import Empty  # Python 3.x
    except ImportError:
        from Queue import Empty  # Python 2.x

    def run_task(sleep_time, queue):
        time.sleep(sleep_time)
        queue.put(True)

    mw = MonoWorker()
    for expected_queue_length in range(1, 6):
        for sleep_time in range(5):
            mw.submit(run_task, sleep_time, queue)
        time.sleep(expected_queue_length)
        assert queue.qsize() == expected_

# Generated at 2022-06-24 10:08:53.683184
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from random import random as rand
    from concurrent.futures import as_completed
    def f(x):
        sleep(rand() * .02)
        return x
    pool = MonoWorker()
    futures = [pool.submit(f, i) for i in range(100)]
    assert len(futures) > futures[0]._work_queue.maxsize  # ensure enough work
    assert not set(futures) & set(futures[0]._work_queue.queue)
    assert all(f.result() == i for i, f in enumerate(as_completed(futures)))
    # test IO and cancellation
    import sys
    cancel, ioclass = futures[-1], tqdm_auto.tqdm.io.IOBase
    assert not isinstance

# Generated at 2022-06-24 10:09:02.588734
# Unit test for constructor of class MonoWorker

# Generated at 2022-06-24 10:09:12.113223
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Lock
    from collections import OrderedDict
    from concurrent.futures import CancelledError

    def func(sleep_time):
        sleep(sleep_time)
        with lock:
            outputs[i] += sleep_time
        return i

    n = 3
    sleep_time = 1
    lock = Lock()
    outputs = OrderedDict([(i, 0) for i in range(n)])
    mono_worker = MonoWorker()
    futures = []
    for i in range(n):
        futures.append(mono_worker.submit(func, sleep_time))
        sleep(sleep_time)

    for future in futures:
        try:
            future.result()
        except CancelledError:
            pass


# Generated at 2022-06-24 10:09:23.101033
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing
    import time

    def f1(x):
        time.sleep(0.5)
        return x + 1

    def f2(x):
        time.sleep(0.5)
        return x + 2

    def f3(x):
        time.sleep(0.5)
        return x + 3

    def f4(x):
        time.sleep(0.5)
        return x + 4

    def f5(x):
        time.sleep(0.5)
        return x + 5

    def test_threads(g):
        assert g.submit(f1, 0).result() == 1
        assert g.submit(f2, 0).result() == 2
        assert g.submit(f3, 0).result() == 3

# Generated at 2022-06-24 10:09:32.570222
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading
    from ..auto import tqdm as tqdm_auto

    N = 1
    M = 5
    workers = MonoWorker()

    def f1(x):
        """Print and sleep"""
        tqdm_auto.write('Started f1({})'.format(x))
        time.sleep(1e-1)  # simulates long computation
        return x ** 2

    def f2(x):
        """Print and sleep"""
        tqdm_auto.write('Started f2({})'.format(x))
        time.sleep(1e-1)  # simulates long computation
        return x ** 3

    def g1(x):
        """Print and sleep"""
        tqdm_auto.write('Started g1({})'.format(x))

# Generated at 2022-06-24 10:09:36.121975
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # import mock
    # with mock.patch('concurrent.futures.Executor.submit',
    #                 side_effect=[100, 200, 300, 400]):
    with MonoWorker() as worker:
        print("Test 1")
        print("Submit 1: ", worker.submit(lambda x: x, 20))
        print("Submit 2: ", worker.submit(lambda x: x, 21))
        print("Submit 3: ", worker.submit(lambda x: x, 22))
        print("Submit 4: ", worker.submit(lambda x: x, 23))

if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:09:45.217923
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from random import choice
    from functools import partial
    from contextlib import ExitStack

    def p(*args):
        """Python print helper to capture output."""
        tqdm_auto.write(*args)

    def do(x, y, name='', sleep_time=None, sleep_last=None):
        """Sleep then print and return."""
        sleep(sleep_time or 0)
        p(name, x, y)
        sleep(sleep_last or 0)
        return (x, y)

    class Callback(object):
        """Agitator callback."""
        def __init__(self):
            self.x = 0
            self.y = 0
            self.done = Event()


# Generated at 2022-06-24 10:09:57.595834
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def submitter(worker):
        """Sleeps for i seconds, then submits task that sleeps for 2i seconds."""
        for i in range(10):
            sleep(i)
            worker.submit(lambda x: sleep(x), 2 * i)

    m = MonoWorker()
    assert not m.futures
    assert not m.pool._threads
    submitter(m)
    assert m.pool._threads
    assert m.pool._threads.issuperset(m.futures)  # worker is running
    sleep(15)
    assert not m.pool._threads.issuperset(m.futures)  # worker is not running
    m.pool.shutdown(wait=True)


if __name__ == '__main__':
    test_Mon

# Generated at 2022-06-24 10:09:59.273483
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test `MonoWorker` constructor"""
    MonoWorker()

# Generated at 2022-06-24 10:10:08.438874
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import os
    import random
    import subprocess
    import time
    from itertools import count
    from multiprocessing import cpu_count
    from .tqdm_contrib_test import _range

    def worker():
        time.sleep(random.random())
        return "result"

    def worker_long():
        while True:
            time.sleep(random.random())

    def worker_crash():
        time.sleep(random.random())
        raise ValueError("Expected error")

    def no_worker():
        pass

    def complex_worker():
        time.sleep(random.random())
        return os.getpid(), subprocess.check_output(['uname', '-a']).decode()


# Generated at 2022-06-24 10:10:15.191541
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from contextlib import contextmanager

    @contextmanager
    def pool_ctx_manager(pool):
        # Just a convenience, for testing
        yield pool

    def test_status(worker):
        # Just a convenience, for testing
        return worker.futures.maxlen - len(worker.futures) == 1

    @contextmanager
    def running_waiting(worker):
        with tqdm_auto.tqdm(disable=True) as pbar:
            waiting = worker.submit(pbar.update, 1)
            assert test_status(worker)
            yield

    def test_func():
        import threading
        time.sleep(0.02)
        return id(threading.current_thread())

    def test_func_raise():
        # Just a convenience, for testing
        raise Value

# Generated at 2022-06-24 10:10:21.901227
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import logging
    logging.basicConfig(level=logging.WARN)
    # Creates a MonoWorker instance
    worker = MonoWorker()

    def fast():
        return time.time()

    def slow():
        time.sleep(5)
        return time.time()

    # The waiting task is the most recent submitted task
    # Other submitted tasks are discarded
    f1 = worker.submit(fast)
    f2 = worker.submit(slow)
    f3 = worker.submit(fast)
    # The fast task can only be executed after the slow task is completed
    assert f3.result() - f1.result() >= 5

# Generated at 2022-06-24 10:10:29.073265
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading as th

    class Listener(th.Thread):
        def __init__(self, ev):
            super(Listener, self).__init__()
            self.ev = ev
            self.child_thread_ids = []

        def run(self):
            self.child_thread_ids.append(th.current_thread().ident)
            self.ev.wait()

    def test_func(ev, a, b=3, c=4):
        ev.set()
        return a + b + c

    ev = th.Event()
    listener = Listener(ev)
    listener.start()

    worker = MonoWorker()
    worker.submit(test_func, ev, 1, c=10)

    # Check the waiting task is not canceled if there is a pending task
    waiting_future = worker.submit

# Generated at 2022-06-24 10:10:30.951340
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # pylint: disable=protected-access
    assert MonoWorker()._futures.maxlen == 2

# Generated at 2022-06-24 10:10:40.061868
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from concurrent.futures import as_completed
    time.sleep = as_completed.__init__
    tqdm_auto.write = Lock().acquire
    w = MonoWorker()
    w.submit(time.sleep, 0.1)
    w.submit(time.sleep, 0.5)
    w.submit(time.sleep, 0.3)
    w.submit(time.sleep, 0.2)
    w.submit(time.sleep, 0.1)
    w.submit(time.sleep, 0.5)
    w.submit(time.sleep, 0.3)
    w.submit(time.sleep, 0.2)
    w.submit(time.sleep, 0.1)

# Generated at 2022-06-24 10:10:47.295613
# Unit test for constructor of class MonoWorker

# Generated at 2022-06-24 10:10:57.947133
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Manager, Process
    from random import seed, randint
    from multiprocessing.managers import BaseManager
    seed(0)  # reproduce randomness for testing
    manager = Manager()
    m_cache = manager.dict()
    m_test = manager.dict()
    m_test.update({'cache': m_cache})

    class MyManager(BaseManager):
        pass

    MyManager.register('dict_test', dict, m_test)
    MyManager.register('dict_cache', dict, m_cache)
    manager = MyManager()
    manager = manager.get_server()

    def random_sleep():
        """ Random sleep in [0.0 .. 0.1[ seconds """
        sleep(randint(0, 10) / 100.0)


# Generated at 2022-06-24 10:11:03.016799
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from concurrent.futures import ThreadPoolExecutor
    from ..utils import _range
    from ..auto import tqdm as tqdm_auto

    n = 4
    with ThreadPoolExecutor(max_workers=2 * n) as pool:
        mw = MonoWorker()
        futures = [pool.submit(_range,
                               10**6,  # costly
                               desc=tqdm_auto.format_interval(2. * i / n))
                   for i in range(n)]

        wait = []
        for _ in _range(n):
            # Wait for the first to complete, then cancel the rest
            done, _ = mw.submit(futures[0].result).as_completed(wait)
            mw.submit(futures[0].result)  # add again

# Generated at 2022-06-24 10:11:12.773167
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    from .my_tqdm import tqdm
    #import tqdm  # is not required to run the test

    class FooBar(threading.Thread):
        def __init__(self, desc, progress, max_iter=1000000, sleep=0.001):
            self.desc = desc
            self.progress = progress
            self.max_iter = max_iter
            self.sleep = sleep
            threading.Thread.__init__(self)

        def run(self):
            for i in tqdm(range(self.max_iter),
                          desc=self.desc,
                          leave=True,
                          dynamic_ncols=True,
                          mininterval=0.1):
                self.progress.update()

# Generated at 2022-06-24 10:11:20.805572
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    tqdm_auto.write('Submitting 1...')
    fut1 = mw.submit(time.sleep, 3)
    tqdm_auto.write('Submitting 2...')
    mw.submit(time.sleep, 2)
    tqdm_auto.write('Submitting 3...')
    mw.submit(time.sleep, 1)
    tqdm_auto.write('Submitting 4...')
    mw.submit(time.sleep, 5)
    tqdm_auto.write('Submitting 5...')
    mw.submit(time.sleep, 4)
    tqdm_auto.write('Submitting 6...')
    mw.submit(time.sleep, 4)
    tqdm_auto.write('Submitting 7...')


# Generated at 2022-06-24 10:11:27.006026
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from os import getpid

    def run_forever(pid, i):
        while True:
            sleep(0.1)
            assert getpid() != pid, \
                (i, pid, getpid())
    w = MonoWorker()

    pids = [-1]*100
    for i in tqdm_auto.tqdm(range(100), dynamic_ncols=True):
        pids[i] = getpid()
        w.submit(run_forever, pids[i], i)
        sleep(0.01)

    pids = pids[::-1]
    for i in tqdm_auto.tqdm(range(100), dynamic_ncols=True):
        w.submit(run_forever, pids[i], i)
        sleep

# Generated at 2022-06-24 10:11:31.698547
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import random
    import sys
    import traceback

    def run(i):
        sleep(0.5 + random.random())
        if random.randint(0, 2) == 0:
            raise Exception(i)
        tqdm_auto.write(i)
        return i

    worker = MonoWorker()
    results = []
    n = 300
    try:
        for i in range(n):
            future = worker.submit(run, i)
            results.append(future.result())
    except KeyboardInterrupt:
        print('Interrupted by user')
        worker.pool.shutdown(wait=False)
        traceback.print_exc(file=sys.stdout)
        sys.stdout.flush()


# Generated at 2022-06-24 10:11:35.745031
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from inspect import isgeneratorfunction
    def do_sleep(t, msg):
        sleep(t)
        tqdm_auto.write(msg)
    mw = MonoWorker()
    assert isgeneratorfunction(mw.submit)
    assert len(mw.futures) == 0
    for j in range(4):  # test multi-threaded
        for i in range(4):  # test queuing
            assert isinstance(mw.submit(do_sleep, 1*j + .5*i, "sleep " + str(i)),
                              Exception if i > 1 else type(None))
        assert len(mw.futures) == 1

# Generated at 2022-06-24 10:11:48.071274
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import choice
    from string import ascii_letters
    from itertools import count

    class RandomLengthStr(object):
        """
        Generate random length string.
        """
        def __init__(self):
            super(RandomLengthStr, self).__init__()
            self.counter = count()

        def __call__(self, idx):
            if idx < len(self._strs):
                return self._strs[idx]
            else:
                self._strs = [(i, "".join(choice(ascii_letters)
                                          for _ in range(len(i))))
                              for i in self.counter]
                return self(idx)


# Generated at 2022-06-24 10:11:59.800787
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> from time import sleep
    >>> from tqdm import tqdm
    >>> from tqdm.contrib import MonoWorker

    >>> def test_print(i):
    ...     for _ in tqdm(range(1000)):
    ...         sleep(0.001)
    >>> worker = MonoWorker()
    >>> worker.submit(test_print, 1)
    >>> worker.submit(test_print, 2)
    >>> worker.submit(test_print, 3)
    >>> worker.submit(test_print, 4)
    >>> worker.futures[0].result()  # doctest: +SKIP
    1
    >>> worker.futures[1].result()  # doctest: +SKIP
    4
    """
    pass