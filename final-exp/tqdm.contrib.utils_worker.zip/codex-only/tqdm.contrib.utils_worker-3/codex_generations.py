

# Generated at 2022-06-24 10:01:57.430699
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm.contrib import asyncio
    asyncio.tqdm.clear()
    mw = MonoWorker()
    assert not mw.futures
    assert mw.pool._work_queue.empty()
    assert not mw.pool._threads
    # function with no args
    f0 = mw.submit(time.sleep)
    assert f0.done()  # completed immediately
    assert mw.futures
    assert mw.pool._work_queue.empty()
    assert not mw.pool._threads
    # normal function
    f1 = mw.submit(time.sleep, 0.1)
    assert not f1.done()
    assert len(mw.futures) == 1
    assert not mw.pool._work_queue.empty()


# Generated at 2022-06-24 10:02:02.180916
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def func(i):
        print('in:', i)
        sleep(0.05)
        print('out:', i)

    mw = MonoWorker()
    for i in range(5):
        mw.submit(func, i)


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:02:08.567607
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from string import ascii_lowercase
    import sys

    mw = MonoWorker()
    for i, c in enumerate(ascii_lowercase):
        def func():
            for j in tqdm_auto.tqdm(range(5), leave=False, desc=c):
                sleep(0.1)
        mw.submit(func)
    mw.pool.shutdown(wait=True)
    sys.stdout.write("\n")

# Generated at 2022-06-24 10:02:14.984760
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def simple(x):
        time.sleep(3)
        return x

    worker = MonoWorker()
    for i in range(4):
        worker.submit(simple, i)
    time.sleep(1)
    assert len(worker.futures) == 2
    worker.futures[1].result()
    print("concurrent.futures.MonoWorker ok")


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:02:24.402604
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from threading import Thread
    from time import sleep
    from queue import Queue

    # To check if the constructor has run totally
    init_queue = Queue()

    class TestThread(Thread):
        def __init__(self):
            Thread.__init__(self)
            init_queue.put(1)

        def run(self):
            sleep(1)
            init_queue.put(2)

    test_thread = TestThread()
    test_thread.start()

    mono_worker = MonoWorker()
    init_queue.get(timeout=5)
    # If there are 2 items in the init_queue, this means the constructor has
    # run totally
    assert init_queue.get(timeout=5) == 2

# Generated at 2022-06-24 10:02:33.044790
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import traceback

    def func0(x, delay=3):
        sleep(delay)
        return x * delay

    def func1(x, delay=3):
        sleep(delay)
        return x * delay

    def submit(i):
        if i == 0:
            x = worker.submit(func0, i + 1, delay=5)
            print("submitted:", i)
        elif i == 1:
            x = worker.submit(func0, i + 1, delay=2)
            print("submitted:", i)
        elif i == 2:
            x = worker.submit(func1, i + 1, delay=3)
            print("submitted:", i)

        print("status:", x)

# Generated at 2022-06-24 10:02:40.998496
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import pathlib

    def worker(msg):
        sys.stdout.write(pathlib.Path(__file__).stem +
                         ': ' + msg + '\n')
        time.sleep(0.5)
        return msg

    # print('test_MonoWorker_submit: start')
    mw = MonoWorker()
    # print('test_MonoWorker_submit: MonoWorker created')
    for i in range(4):
        msg = 'start ' + str(i)
        # print('test_MonoWorker_submit: submiting ' + msg)
        mw.submit(worker, msg)
        # print('test_MonoWorker_submit: submitted ' + msg)
    # print('test_MonoWorker_submit: calling MonoWorker

# Generated at 2022-06-24 10:02:46.991306
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    def foo(x):
        #raise Exception("foo")
        sleep(x)

    worker = MonoWorker()
    for i in range(4):
        tqdm_auto.write('submit %d' % i)
        worker.submit(foo, i)

# Generated at 2022-06-24 10:02:58.091487
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import _term_move_up
    import threading

    def func():
        import os
        import socket
        import random
        import string
        import time
        import signal
        with tqdm_auto.tqdm(total=1, leave=False) as pbar:
            signal.signal(signal.SIGINT, lambda *args: os._exit(1))
            while True:
                s = ''.join(random.choice(string.ascii_uppercase)
                            for _ in range(8))
                pbar.total = int(s, 16)
                time.sleep(0.01)
        return s

    def main():
        from time import sleep
        from signal import SIGINT

# Generated at 2022-06-24 10:03:07.381967
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test to check if the constructor of MonoWorker works"""
    from time import sleep
    from random import random

    def slow_f(x):
        sleep(random() * .2)
        return x

    m = MonoWorker()

    with tqdm_auto.tqdm() as t:
        while t.n < 10:
            m.submit(slow_f, t.n, t=t)
            sleep(.01)


if __name__ == "__main__":
    with tqdm_auto.external_write_mode():
        test_MonoWorker()

# Generated at 2022-06-24 10:03:09.423961
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert isinstance(mw.pool, ThreadPoolExecutor)
    assert isinstance(mw.futures, deque)

# Generated at 2022-06-24 10:03:16.328037
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed
    def task(i):
        time.sleep(0.2)
        if i == 1:
            raise RuntimeError('Failing task in test')
        return i
    mw = MonoWorker()
    # Asynchronously adds tasks (they may be discarded)
    tasks = [mw.submit(task, i) for i in range(5)]
    print('Running tasks:', [t.result() for t in as_completed(tasks)])



# Generated at 2022-06-24 10:03:24.577364
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test `submit` method of `MonoWorker`."""
    import time
    from nose.tools import assert_true, assert_equal, assert_not_equal
    def f1():
        time.sleep(0.2)
        return '1'
    def f2():
        time.sleep(0.3)
        return '2'
    def f3():
        time.sleep(0.1)
        return '3'
    mw = MonoWorker()
    futures = (mw.submit(f1), mw.submit(f2), mw.submit(f3))
    assert_equal(mw.futures[0].result(), '1')
    assert_equal(mw.futures[1].result(), '3')

# Generated at 2022-06-24 10:03:32.055676
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures

    # Test MonoWorker with a time-consuming function
    # The function returns a string and a float
    def func(string, float_num=1.0):
        time.sleep(float_num)
        return string, float_num

    monoworker = MonoWorker()

    # Create a task and run
    # It will be delayed for 1 second
    waiting = monoworker.submit(func, 'task1', 1.0)
    ret1 = waiting.result()
    assert ret1 == ('task1', 1.0), 'Task finished but return value error'

    # Create a task and run
    # It will be delayed for 2 seconds
    waiting = monoworker.submit(func, 'task2', 2.0)
    ret2 = waiting.result()
   

# Generated at 2022-06-24 10:03:36.796466
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..main import tqdm
    from future_builtins import map

    def time_f():
        time.sleep(1)
        return True

    mono = MonoWorker()
    # submit task that waits until another task is submitted
    mono.submit(time_f)
    # submit task that finishes before the previous task (and cancels it)
    t_ = mono.submit(time_f)
    # submit task that finishes before the previous task (and cancels it)
    t = mono.submit(time_f)

    assert t.cancelled()

    # submit tasks that waits until another task is submitted
    mono.submit(time_f)

# Generated at 2022-06-24 10:03:39.902547
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    test_MonoWorker.passed = False
    def f():
        time.sleep(1)
        test_MonoWorker.passed = True
    MonoWorker().submit(f)

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:03:47.060189
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from . import assertions as asrt

    m = MonoWorker()

    assert m.futures.maxlen == 2
    assert len(m.futures) == 0

    with asrt.check_durations(0.01, 0.2):
        for i in list(range(3)):
            m.submit(time.sleep, 1)

    assert len(m.futures) == 2
    assert m.submit(time.sleep, 1).done()  # previously running task cancelled
    m.futures.popleft().result()  # wait for running task completion

# Generated at 2022-06-24 10:03:53.436186
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    mw = MonoWorker()
    assert len(mw.futures) == 0
    mw.submit(sleep, 2)
    assert len(mw.futures) == 1
    mw.submit(sleep, 2)
    assert len(mw.futures) == 2
    mw.submit(sleep, 2)
    assert len(mw.futures) == 2
    mw.futures[0].result()  # wait for them to complete
    mw.futures[1].result()

# Generated at 2022-06-24 10:04:02.654435
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def current_thread():
        return threading.current_thread().getName()

    def wait(t):
        time.sleep(t)
        return current_thread()

    worker = MonoWorker()
    T = 0.2
    a = worker.submit(wait, T)
    time.sleep(T / 2)
    b = worker.submit(wait, T)
    time.sleep(T)
    c = worker.submit(wait, T)

    for i in [a, b, c]:
        assert i.done()

    assert c.result() == a.result()
    assert b.result() != c.result()

    worker.pool.shutdown(wait=True)

# Generated at 2022-06-24 10:04:07.662608
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(x):
        time.sleep(0.1)
        return x

    worker = MonoWorker()
    out = []
    for i in range(3):
        out.append(worker.submit(f, i))

    assert out[0].result() == 0
    assert out[0].done()
    assert out[1].result() is None
    assert out[1].done()
    assert out[2].result() == 2
    assert out[2].done()

# Generated at 2022-06-24 10:04:21.881412
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading

    class TestThread(threading.Thread):
        def __init__(self, n):
            super(TestThread, self).__init__()
            self.n = n

        def run(self):
            time.sleep(5.5)
            self.n += 2

    M = MonoWorker()

    n1, n2 = 1, 2
    t1 = M.submit(TestThread(n1).run)
    time.sleep(3)
    t2 = M.submit(TestThread(n2).run)

    t1.result()  # Wait for t1 finish
    assert t2.done()  # t1 is replaced by t2
    assert t1.cancelled()
    assert not t2.cancelled()
    assert n1 == 1
    assert n2

# Generated at 2022-06-24 10:04:31.070273
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from .delayed import delayed

    mw = MonoWorker()

    print("submit 1")
    result1 = mw.submit(delayed, 0.5)
    time.sleep(0.1)
    print("submit 2")
    result2 = mw.submit(delayed, 2)
    time.sleep(0.1)
    print("submit 3")
    result3 = mw.submit(delayed, 4)

    mw.submit(delayed, 6)
    mw.submit(delayed, 8)

    print("result 1:", result1.result())
    print("result 2:", result2.result())
    print("result 3:", result3.result())


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:04:40.830293
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from contextlib import contextmanager

    def wait(delay, done_event=None, value=None):
        sleep(delay)
        return value

    @contextmanager
    def wait_manager(delay, done_event=None, value=None):
        yield wait(delay, done_event, value)


# Generated at 2022-06-24 10:04:49.686808
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    print()
    from concurrent.futures import TimeoutError
    from time import sleep
    from random import random

    def wait(x):
        sleep(x)

    def wait_and_return(x):
        wait(x)
        return x

    def wait_and_print(x):
        wait(x)
        print('<{:.1f}s>'.format(x))
        return x

    print('Testing initialization of MonoWorker')
    m = MonoWorker()
    assert len(m.futures) == 0
    assert not m.pool._threads  # pylint: disable=protected-access
    assert not m.pool._work_queue.unfinished_tasks  # pylint: disable=protected-access

    print('Testing submit without waiting for future')

# Generated at 2022-06-24 10:04:59.862879
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time
    sleep_time = 0.5
    during_execution_sleep_time = 0.2
    max_worker = 1
    # Create a MonoWorker instance
    pool = MonoWorker()
    # Initialize an array to record all the executing time of the submitted functions
    comparing_array = []
    # Submit a function and a function with a parameter value to MonoWorker for execution
    for i in range(3):
        # time.sleep is a function with no parameter.
        pool.submit(time.sleep, during_execution_sleep_time)
        # The following is a function with no parameter.
        pool.submit(lambda: comparing_array.append(time.time()))
        # The following is a function with a parameter.

# Generated at 2022-06-24 10:05:05.761019
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from threading import Event
    from multiprocessing import Process

    ev = Event()
    worker = MonoWorker()

    def slow_func(*args, **kwargs):
        ev.wait()

    def fast_func(*args, **kwargs):
        time.sleep(.2)

    with Process():
        worker.submit(slow_func)
        try:
            worker.submit(fast_func).result()
            assert False, "Submitting a second task should never work"
        except Exception:
            pass

    ev.set()
    worker.submit(fast_func).result()

    worker.submit(slow_func, "arg")
    try:
        worker.submit(fast_func).result()
    except Exception:
        assert False, "Submitting a second task should work now"

# Generated at 2022-06-24 10:05:13.134335
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> from tqdm.contrib.concurrency import MonoWorker
    >>> mono_worker = MonoWorker()
    >>> mono_worker.submit("print", "abc")
    <Future at 0x... state=finished raised Exception>
    >>> mono_worker.submit("print", "123")
    <Future at 0x... state=finished returned None>
    >>> mono_worker.submit("print", "456")
    <Future at 0x... state=finished returned None>

    >>> mono_worker.submit("a.b", "456")
    <Future at 0x... state=finished raised Exception>

    >>> mono_worker.submit("a.b", "456")
    """
    pass

# Generated at 2022-06-24 10:05:22.007601
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Method `submit` of class `MonoWorker`."""
    def wait(t=1):
        """Sleep for `t` seconds."""
        import time
        time.sleep(t)

    mono_worker = MonoWorker()
    mono_worker.submit(wait, t=10)
    mono_worker.submit(wait, t=1)
    from time import time
    s = time()
    mono_worker.submit(wait, t=5)
    total_time = time() - s
    assert 4 < total_time < 6
    assert len(mono_worker.futures) == 1
    assert len(mono_worker.pool._threads) == 1

# Generated at 2022-06-24 10:05:22.533408
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    pass


# Generated at 2022-06-24 10:05:33.122560
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> worker = MonoWorker()
    >>> worker.submit(lambda: (print('running'), 1))
    >>> worker.submit(lambda: (print('waiting'), 2))
    >>> worker.submit(lambda: (print('canceled'), 3))
    >>> worker.submit(lambda: (print('running'), 4))
    >>> worker.submit(lambda: (print('waiting'), 5))
    """

if __name__ == "__main__":
    # print the docstring of current module to stdout.
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 10:05:42.175227
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..utils import TEST_CASES

    def write(s):
        tqdm_auto.write(s)

    worker = MonoWorker()

    for _ in worker.pool.map(write, TEST_CASES):
        pass  # wait for completion
    sleep(0.5)  # wait for writer queue to flush
    assert "HGef" in tqdm_auto.get_instances()

    worker.submit(write, "a")
    worker.submit(write, "b")
    worker.submit(write, "c")
    worker.submit(write, "d")
    worker.submit(write, "e")
    worker.submit(write, "f")
    for _ in worker.futures:
        pass  # wait for completion
    sleep(0.5)

# Generated at 2022-06-24 10:05:53.031375
# Unit test for constructor of class MonoWorker

# Generated at 2022-06-24 10:06:01.692324
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Event
    from random import randrange, uniform
    from itertools import cycle

    class RandomWait(object):
        """Wait for a random time and return a random value"""
        def __call__(self, *args):
            sleep(randrange(1))
            return uniform(*args)


# Generated at 2022-06-24 10:06:10.048486
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import collections
    import time
    from . import synchronize

    class TestException(Exception):
        pass

    def test_func():
        time.sleep(1)
        raise TestException()

    def test_func_no_exception():
        time.sleep(1)

    class Collector(object):
        def __init__(self):
            self.lst = []
            self.lock = synchronize.Lock()

        def append(self, el):
            with self.lock:
                self.lst.append(el)

        def __eq__(self, other):
            with self.lock:
                with other.lock:
                    return self.lst == other.lst

    class TestCollector(object):
        def __init__(self):
            self.passed = Collector()
            self.failed = Collector

# Generated at 2022-06-24 10:06:16.003520
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from random import choice as rc
    sleep_ = rc([lambda: sleep(0.1), lambda: sleep(1)])
    def do_task():
        sleep_()
        return True
    mw = MonoWorker()
    assert mw.submit(do_task) is None
    assert mw.submit(do_task) is None
    sleep_()
    assert mw.futures[0].done() is True
    assert mw.futures[1].done() is not None

# Generated at 2022-06-24 10:06:22.832896
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # import time
    import threading

    # test with 0 waiting time
    f1 = lambda x: x
    f2 = lambda x: x
    mw = MonoWorker()
    assert mw.futures.maxlen == 2
    assert len(mw.futures) == 0
    r1 = mw.submit(f1, 1)
    r2 = mw.submit(f2, 2)
    # time.sleep(0.1)
    assert mw.futures.maxlen == 2
    assert len(mw.futures) == 1
    assert mw.futures[0] == r2
    assert r2.done() is False
    assert r2.result() == 2
    assert r1.done() is True
    assert r1.cancelled() is True



# Generated at 2022-06-24 10:06:24.602038
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    o = MonoWorker()
    assert 0 == len(o.pool._threads)
    assert 1 == o.pool._max_workers


# Generated at 2022-06-24 10:06:25.220505
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    pass

# Generated at 2022-06-24 10:06:33.950752
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import threading
    import time
    from functools import wraps

    def wrap_sleep(duration, error=None):
        @wraps(wrap_sleep)
        def test_sleep():
            time.sleep(duration)
            if error:
                raise Exception(error)
        return test_sleep

    # Create MonoWorker for testing
    monoWorker = MonoWorker()

    # Submit a task to sleep for 1 second
    monoWorker.submit(wrap_sleep(1, 'error 1'))
    # Submit another task to sleep for 2 seconds
    monoWorker.submit(wrap_sleep(2, 'error 2'))

    # Start new thread to check MonoWorker tasks and their results

# Generated at 2022-06-24 10:06:44.051040
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import random
    import time
    import os
    import sys

    def _init_output(encoder=None):
        if sys.version_info >= (3,):
            return open(os.devnull, 'w', encoding=encoder or 'utf8')
        else:
            return open(os.devnull, 'wb')

    def _sleep_time():
        return random.random() / 100

    out = _init_output()
    mw = MonoWorker()
    for i in range(20):
        mw.submit(time.sleep, _sleep_time())
    for f in mw.futures:
        f.result()
    for i in range(10):
        mw.submit(time.sleep, _sleep_time())

# Generated at 2022-06-24 10:06:54.531011
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def wait_for(func1, func2, wait_time=0.5):
        # Wait until func1 is called
        i = 0
        while not i:
            time.sleep(0.5)
            i += 1
        time.sleep(wait_time)
        # Execute func2
        func2()

    def increment_counter(counter, pool):
        counter += 1
        time.sleep(0.2)
        counter += 1
        return counter

    mw = MonoWorker()
    counter = 0
    t1 = threading.Thread(target=wait_for, args=(
        mw.submit(increment_counter, counter, mw), lambda: counter.__add__(1)))

# Generated at 2022-06-24 10:07:04.682285
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def id(x):
        """identity"""
        return x

    def sleep(x):
        """random, bounded sleep"""
        return id(x), time.sleep(random.uniform(0, x) / 10)

    def rand0(x):
        """random, bounded 0"""
        return random.uniform(0, x)

    def rand1(x):
        """random, bounded 1"""
        return random.uniform(-x, x)

    def rand2(x):
        """random, bounded 2"""
        return random.uniform(-2 * x, 2 * x)

    def rand3(x):
        """random, unbounded"""
        return id(x), random.expovariate(1. / x)


# Generated at 2022-06-24 10:07:16.064145
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from math import sqrt, cos, sin
    import sys

    mw = MonoWorker()
    if sys.version_info[0] >= 3:
        import queue
        q = queue.Queue()

        def print_q(q, i, end='\n'):
            print(q.get(block=False), end=end)

        def put_q(q, i, end='\n'):
            q.put(i)

        put = put_q
        # put = tqdm_auto.write
    else:
        q = deque()

        def print_q(q, i, end='\n'):
            sys.stdout.write(str(q.popleft()))
            sys.stdout.write(end)


# Generated at 2022-06-24 10:07:22.633103
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def do_work(wait_time, *args, **kwargs):
        time.sleep(wait_time)
        return "done"

    worker = MonoWorker()
    worker.submit(do_work, 0.1, "A")
    worker.submit(do_work, 0.2, "B")
    worker.submit(do_work, 0.3, "C")
    print(str(worker.submit(do_work, 0.4, "D")))
    print(str(worker.submit(do_work, 0.4, "E")))
    print(str(worker.submit(do_work, 0.4, "F")))

# Generated at 2022-06-24 10:07:25.263057
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def f(*args, **kwargs):
        time.sleep(1)
    w = MonoWorker()
    r = w.submit(f)
    r.result()
    r = w.submit(f)  # waiting task
    time.sleep(0.5)
    r = w.submit(f)  # running task
    r.result()
    r = w.submit(f)  # waiting task
    r.result()

# Generated at 2022-06-24 10:07:33.634690
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import randint
    from time import sleep
    from sys import stdout

    mw = MonoWorker()

    def worker(i):
        sleep(randint(0, 6) / 10)
        stdout.write(str(i))
        stdout.flush()
        return i

    mw.submit(worker, 0)
    mw.submit(worker, 1)
    mw.submit(worker, 2)
    mw.submit(worker, 3)
    mw.submit(worker, 4)
    mw.submit(worker, 5)
    mw.submit(worker, 6)
    mw.submit(worker, 7)

    stdout.write("\n")
    stdout.flush()
# End unit test for method submit of class MonoWorker


# Generated at 2022-06-24 10:07:40.888353
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import time
    from collections import defaultdict
    from concurrent.futures import CancelledError

    def _input_func(input, output, msg=None):
        """
        Read from `input` and write to `output` (until EOF or exception).
        """
        try:
            if msg:
                output.write(msg)
            d = defaultdict(int)
            while True:
                c = input.read(1)
                if not c:
                    break
                d[c] += 1
                output.write(c)
        except Exception:
            output.write('\x1b[31;1m')
            output.write('\n### Exception in _input_func\n')
            output.write('\x1b[0m')
           

# Generated at 2022-06-24 10:07:51.984735
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    worker = MonoWorker()

    # one running task
    worker.submit(time.sleep, 1)
    assert len(worker.futures) == 1

    # two running tasks
    worker.submit(time.sleep, 1)
    assert len(worker.futures) == 1

    # discard running and wait for the new one
    worker.futures[0].cancel()
    time.sleep(1.1)
    assert len(worker.futures) == 1

    # one running task, one waiting
    worker.submit(time.sleep, 1)
    assert len(worker.futures) == 2

    # discard waiting and wait for the new one
    worker.futures[1].cancel()
    time.sleep(1.1)
    assert len(worker.futures)

# Generated at 2022-06-24 10:08:01.644384
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> from time import sleep
    >>> from threading import RLock
    >>> lock = RLock()
    >>> def func(x):
    ...     lock.acquire()
    ...     tqdm_auto.write('threaded {}'.format(x))
    ...     lock.release()
    ...     sleep(x)
    ...     return x**2
    >>> w = MonoWorker()
    >>> w.submit(func, 1)
    <Future at ...>
    >>> w.submit(func, 2)
    <Future at ...>
    >>> w.submit(func, 3)
    >>> w.submit(func, 4)
    >>> sleep(2)
    >>> w.submit(func, 5)
    >>> sleep(9)
    """


if __name__ == "__main__":
    import doctest

# Generated at 2022-06-24 10:08:09.484579
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def sleep_and_sum(x, y):
        time.sleep(0.1)
        return x + y
    
    mw = MonoWorker()
    num_tests = 10
    
    for i in tqdm_auto.tqdm(range(num_tests)):
        mw.submit(sleep_and_sum, i, i)
    
    for i in tqdm_auto.tqdm(range(num_tests)):
        assert mw.futures[0].result() == 2 * i

# Generated at 2022-06-24 10:08:15.875578
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from nose.tools import assert_equal

    def foo(n):
        return n

    mw = MonoWorker()

    res = mw.submit(foo, 1)
    # res.result()  # blocks
    assert_equal(res.result(), 1)
    assert_equal(len(mw.futures), 0)

    res = mw.submit(foo, 2)
    res.result()
    assert_equal(len(mw.futures), 1)

    res = mw.submit(foo, 3)
    res.result()
    assert_equal(len(mw.futures), 1)

    res = mw.submit(foo, 4)
    res.result()
    assert_equal(len(mw.futures), 1)


# Generated at 2022-06-24 10:08:24.741018
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .utils import unikwarg
    import time
    import threading
    from unittest import TestCase
    from concurrent.futures import CancelledError

    class _Test(TestCase):
        @unikwarg
        def _worker(self, t, **kwargs):
            time.sleep(t)
            return kwargs

        def test_submit(self):
            w = MonoWorker()
            a, b, c = w.submit(self._worker, 0.2, kwarg1='1', kwarg2='2'), \
                      w.submit(self._worker, 0.1, kwarg1='11', kwarg2='22'), \
                      w.submit(self._worker, 0.05, kwarg1='111', kwarg2='222')

# Generated at 2022-06-24 10:08:28.721533
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    import time
    import unittest

    class TestWorker(unittest.TestCase):
        def test_contruct_no_error(self):
            w = MonoWorker()

    unittest.main(verbosity=2)

test_MonoWorker()

# Generated at 2022-06-24 10:08:34.356698
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    for i in range(3):
        mw.submit(tqdm_auto.sleep, i)
    running = mw.futures[0]
    assert not running.done()
    assert len(mw.futures) == 1
    # re-submit while running
    mw.submit(tqdm_auto.sleep, running.result() + 1)
    assert len(mw.futures) == 2
    # cancel running
    running.cancel()
    assert running.done()
    assert len(mw.futures) == 1



# Generated at 2022-06-24 10:08:41.877185
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    import time
    import random
    import concurrent.futures
    import tqdm.contrib.concurrency

    # Test with a simple dummy function with random sleep
    def _dummy_func(a):
        """Random sleep dummy function"""
        sleep_time = random.random()
        time.sleep(sleep_time)
        return a + 1

    random.seed(0)
    mono = tqdm.contrib.concurrency.MonoWorker()
    futures = []
    for i in range(5):
        futures.append(mono.submit(_dummy_func, i))
    for future in futures:
        try:
            future.result()
        except concurrent.futures.CancelledError:
            pass

# Generated at 2022-06-24 10:08:46.801197
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from operator import mul
    from itertools import repeat
    import sys
    import os

    def test_post_one(func, *args, **kwargs):
        args = list(map(str, args)) + ["{}={}".format(*i) for i in kwargs.items()]
        post_one("executing {}{}...".format(func.__name__, '(' + ', '.join(args) + ')' if args else ''))

    def test_post_many(iterable):
        post_many("{:.3f}\n".format(i) for i in iterable)

    def post_one(s):
        sys.stderr.write(s + '\n')


# Generated at 2022-06-24 10:08:59.374873
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm.contrib import MonoWorker
    from tqdm.contrib._test_utils import fmt_time_interval

    def delay(t=5, msg="5s"):
        # time.sleep(t)
        for i in tqdm_auto.trange(t, desc="  test1"):
            time.sleep(1)
            yield i
        for i in tqdm_auto.trange(t, desc="  test2"):
            time.sleep(1)
            yield i
        for i in tqdm_auto.trange(t, desc="  test3"):
            time.sleep(1)
            yield i
        tqdm_auto.write(msg)
        yield msg


# Generated at 2022-06-24 10:09:11.619872
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from collections import defaultdict
    import numpy as np

    def func(x):
        sleep(x)
        return x

    mono = MonoWorker()
    rng = np.random.RandomState(1234)
    hist = defaultdict(int)
    for i in range(100000):
        x = 0.05 + rng.rand() * 0.95
        hist[x] += 1
        mono.submit(func, x)

    # hist is the count of each time value, to be compared to a poisson distribution
    # plot histogram: import matplotlib.pyplot as plt; plt.bar(hist.keys(), hist.values()); plt.show()
    import scipy.stats as stats

# Generated at 2022-06-24 10:09:22.941953
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    mw = MonoWorker()

    def slow_square(x):
        time.sleep(1)
        return x ** 2

    x1 = mw.submit(slow_square, 3)
    time.sleep(0.1)
    assert x1.running()
    x2 = mw.submit(slow_square, 4)
    time.sleep(0.1)
    assert x1.running()
    assert not x2.running()
    assert x1.result() == 9
    assert x2.result() == 16
    x2.result()

    x1 = mw.submit(slow_square, 3)
    x2 = mw.submit(slow_square, 4)
    assert x1.result() == 9
    assert x2.result() == 16



# Generated at 2022-06-24 10:09:32.360036
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    class App:
        def __init__():
            self.str = ""

        def write(self, str):
            self.str += str

        def flush(self):
            pass

    mono_worker = MonoWorker()
    mono_worker.submit(test_func1, 1)

    assert mono_worker.futures[0].result() == 1

    mono_worker.submit(test_func1, 2)
    assert mono_worker.futures[1].result() == 2
    assert mono_worker.futures[0].done()

    mono_worker.submit(test_func1, 3)
    assert mono_worker.futures[-1].result() == 3
    assert mono_worker.futures[-2].done()

    env = {"tqdm_write": App.write}
   

# Generated at 2022-06-24 10:09:42.305983
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time, sys

    def time_func(n):
        time.sleep(n)
        return n


# Generated at 2022-06-24 10:09:49.956600
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Thread
    import sys
    import traceback

    def err_func(n):
        raise RuntimeError("This is expected and should be ignored")

    def bad_func(n):
        sleep(1)
        raise RuntimeError("This should be detected")

    def gcd(a, b):
        """Return greatest common divisor using Euclid's Algorithm."""
        while b:
            a, b = b, a % b
        return a

    def lcm(a, b):
        """Return lowest common multiple."""
        return a * b // gcd(a, b)

    def lcmm(*args):
        """Return lcm of args."""
        return reduce(lcm, args)

    def is_prime(n):
        """Returns True if n is prime."""

# Generated at 2022-06-24 10:09:54.397112
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> t = MonoWorker()
    >>> f = t.submit(min, range(100))  # block until future is done
    >>> f.result()
    0
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 10:10:00.553106
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading

    class Foo(object):
        def __init__(self):
            self.x = 0
            self.lock = threading.Lock()

        def incr_safe(self):
            with self.lock:
                self.x += 1

        def incr_unsafe(self):
            self.x += 1

    def f_incr_safe(foo):
        foo.incr_safe()

    def f_incr_unsafe(foo):
        foo.incr_unsafe()

    foo_incr_safe = Foo()
    foo_incr_unsafe = Foo()

    mono = MonoWorker()

    # submit 1e7 unsafes
    mono.submit(f_incr_unsafe, foo_incr_unsafe)

# Generated at 2022-06-24 10:10:08.748375
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    from ..std.testing import _suppress_stdout

    futures = []
    mw = MonoWorker()
    def dummy_func_1(x):
        """Dummy function"""
        return x
    def dummy_func_2(x):
        """Dummy function"""
        return x

    with _suppress_stdout():
        for i in (1, 2, 3, 4, 5):
            if i <  4:
                futures.append(mw.submit(dummy_func_1, i))
            else:
                futures.append(mw.submit(dummy_func_2, i))
    assert all([f.done() for f in futures])

# Generated at 2022-06-24 10:10:19.188563
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import concurrent.futures

    worker = MonoWorker()

    # Note: this is only a sanity check, not a real unit test.
    #       Coverage is complete when test_tqdm.py passes.

    def f():
        time.sleep(1)

    def g():
        raise ValueError('error')

    # Length and maxlen of futures are 0
    assert len(worker.futures) == 0
    assert worker.futures.maxlen == 2

    # Throw away task
    for _ in range(worker.futures.maxlen - 1):
        f_future = worker.submit(f)
        assert len(worker.futures) == 1
        assert worker.futures.maxlen == 2
        assert worker.futures[0] == f_future

    # Throw away

# Generated at 2022-06-24 10:10:28.506162
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from .utils import Random
    import time
    import sys

    def _f1(num):
        time.sleep(0.01)
        _f1.called = True
        _f1.result = num
        return num + 1

    def _f2(num):
        time.sleep(0.02)
        _f2.called = True
        _f2.result = num
        return num + 2

    def _f3(num):
        time.sleep(0.03)
        _f3.called = True
        _f3.result = num
        return num + 3

    def _f4(num):
        time.sleep(0.04)
        _f4.called = True
        _f4.result = num
        return num + 4


# Generated at 2022-06-24 10:10:38.530443
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    # check 1-2-3-2
    start_time = time.time()
    mw.submit(sleep_and_print, 1)
    mw.submit(sleep_and_print, 2)
    mw.submit(sleep_and_print, 3)
    mw.submit(sleep_and_print, 2)
    end_time = time.time()
    assert end_time - start_time < 4.
    # check 1-2-3-2-1-2
    start_time = time.time()
    mw.submit(sleep_and_print, 1)
    mw.submit(sleep_and_print, 2)
    mw.submit(sleep_and_print, 3)

# Generated at 2022-06-24 10:10:46.931106
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import string

    result_list = []

    def fake_func(data_list, idx):
        result_list.append(idx)
        time.sleep(random.choice([1, 2, 3]))
        return idx

    mw = MonoWorker()
    mw.submit(fake_func, result_list, '0')
    mw.submit(fake_func, result_list, '1')
    mw.submit(fake_func, result_list, '2')
    mw.submit(fake_func, result_list, '3')

    for r in result_list:
        assert r in string.digits[1:4]

# Generated at 2022-06-24 10:10:51.308911
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    MonoWorker()

# Generated at 2022-06-24 10:10:57.676638
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test to create an object of the class MonoWorker"""
    test_instance = MonoWorker()
    assert test_instance is not None

# Generated at 2022-06-24 10:11:07.407526
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing import Manager
    from time import sleep
    from random import randint

    def waiting_status_display(m):
        for _ in tqdm_auto(range(randint(0, 10)),
                           desc='Waiting'):
            sleep(0.1)
        m['status'] = 'Done'

    def running_status_display(m):
        for _ in tqdm_auto(range(randint(0, 10)),
                           desc='Running'):
            sleep(0.1)
        m['status'] = 'Done'

    m = Manager().dict()
    mono_worker = MonoWorker()

    # Submit the first task
    m['status'] = 'Waiting'
    mono_worker.submit(waiting_status_display, m)
    sleep(1)

    # Submit

# Generated at 2022-06-24 10:11:17.134285
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import as_completed
    from time import sleep
    from unittest import TestCase, main
    from tqdm.contrib.concurrency import MonoWorker

    class Test_MonoWorker_submit(TestCase):
        def setUp(self):
            self.mw = MonoWorker()

        def test_submit(self):
            l = []
            f1 = self.mw.submit(sleep, 1)
            f2 = self.mw.submit(l.append, 1)
            f3 = self.mw.submit(l.append, 2)
            f4 = self.mw.submit(l.append, 3)
            self.assertEqual(set(as_completed([f2, f1, f3])), {f2, f1})

# Generated at 2022-06-24 10:11:17.609463
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()

# Generated at 2022-06-24 10:11:28.198231
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from ..utils import _term_move_up

    def wait_for_result(some_sleep, some_timeout, some_result=None, some_exception=None,
                        some_bar=None):
        """
        Wait some_timeout seconds while sleeping some_sleep seconds
        and then return some_result if some_exception is None,
        else raise some_exception.

        Note: used by unit tests.
        """
        if some_sleep:
            sleep(some_sleep)
        if some_timeout:
            sleep(some_timeout)
        if some_exception is None:
            return some_result
        elif some_bar is not None:
            some_bar.update(1)
            _term_move_up()

# Generated at 2022-06-24 10:11:38.411270
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:11:48.791041
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    def func(a):
        sleep(random())
        return a + 1
    # Test single-threaded
    monoworker = MonoWorker()
    fs = []
    for i in range(10):
        f = monoworker.submit(func, i)
        if f is not None:
            fs.append(f)
    assert len(fs) == 1
    assert all(f.result() == i + 1 for i, f in enumerate(fs))
    f = monoworker.submit(func, 5)
    assert f is None
    # Test multi-threaded
    mgr = Manager()
    monoworker = MonoWorker()
    fs = mgr.list()
    def runner():
        for i in range(10):
            f

# Generated at 2022-06-24 10:12:00.075459
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import os
    import time

    def worker(i):
        time.sleep(0.5)
        tqdm_auto.write("Worker{}: {}".format(i, os.getpid()))
        return i

    MonoWorker().submit(worker, 1)
    time.sleep(0.2)
    MonoWorker().submit(worker, 2)
    time.sleep(0.6)
    MonoWorker().submit(worker, 3)
    time.sleep(0.2)
    MonoWorker().submit(worker, 4)
    time.sleep(0.6)
    MonoWorker().submit(worker, 5)
    time.sleep(0.2)
    MonoWorker().submit(worker, 6)
    time.sleep(0.6)
    MonoWorker().submit(worker, 7)
