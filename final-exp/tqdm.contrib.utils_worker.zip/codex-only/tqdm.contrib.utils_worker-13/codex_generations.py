

# Generated at 2022-06-24 10:01:59.214120
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()



# Generated at 2022-06-24 10:02:09.709838
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class `MonoWorker`"""
    import time
    import datetime
    from concurrent.futures import ThreadPoolExecutor
    from ..std import threading
    from .asyncio import AsyncIOMonitor
    from ..utils import _environ_cols_wrapper

    async_print = AsyncIOMonitor().wrap_print(flush=True)

    def _test_thread(i):
        time.sleep(3)
        with _environ_cols_wrapper():
            async_print("{} at {}"
                        .format(i, datetime.datetime.utcnow().isoformat()))

    pool = ThreadPoolExecutor(max_workers=2)
    futures = deque([], 2)
    a = pool.submit(_test_thread, "a")
    futures

# Generated at 2022-06-24 10:02:19.049623
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from .tqdm_test_script import tqdm

    worker = MonoWorker()
    assert len(worker.futures) == 0
    t0 = time.time()
    worker.submit(time.sleep, 1.0)
    assert 1.0 <= time.time() - t0 <= 1.5
    assert len(worker.futures) == 1
    worker.submit(time.sleep, 1.0)  # should replace waiting
    assert len(worker.futures) == 1
    worker.submit(time.sleep, 1.0)
    assert 1.0 <= time.time() - t0 <= 2.0
    assert len(worker.futures) == 1
    t0 = time.time()
    worker.submit(time.sleep, 1.0)
    assert 1.0

# Generated at 2022-06-24 10:02:28.895687
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(num):
        for _ in tqdm_auto.tqdm_gui(range(num), desc='f'):
            time.sleep(0.1)
        return "abc"

    def g(num):
        time.sleep(num)
        return "def"

    m = MonoWorker()
    f2 = m.submit(f, 2)
    time.sleep(0.1)
    g2 = m.submit(g, 2)  # Must replace f2

    f1 = m.submit(f, 1)  # Must replace g2
    time.sleep(0.1)
    f0 = m.submit(f, 0)  # Must abort f1
    time.sleep(0.1)
    g1 = m.submit(g, 1)  # Must replace f

# Generated at 2022-06-24 10:02:33.774133
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def foo(i, n):
        time.sleep(n)
        return i

    mw = MonoWorker()
    futs = []
    for i in range(10):
        n = random.random() * 0.5
        futs.append(mw.submit(foo, i, n))
    time.sleep(1)
    assert (futs[-1].result() == 9)

# Generated at 2022-06-24 10:02:41.610946
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()

    assert m.futures == deque([], 2)

    def noop(ignore):
        pass

    assert m.submit(noop, 0)
    assert m.futures == deque([m.submit(noop, 0, _tqdm_gui=False)], 2)
    assert m.submit(noop, 1)
    assert m.futures == deque([m.submit(noop, 0, _tqdm_gui=False),
                               m.submit(noop, 1, _tqdm_gui=False)], 2)
    assert m.submit(noop, 2)

# Generated at 2022-06-24 10:02:54.131208
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import numpy as np

    max_workers = 1
    MonoWorker().pool.shutdown()

    worker = MonoWorker()
    a = np.random.random(size=(10000,10000))
    b = np.random.random(size=(10000,10000))
    c = np.random.random(size=(10000,10000))
    d = np.random.random(size=(10000,10000))
    def func(arr1, arr2, secs):
        time.sleep(secs)
        return arr1+arr2

    assert worker.pool.max_workers == max_workers
    worker.submit(func, a, b, 0.01)
    assert worker.pool._work_queue.qsize() == 0
    worker.pool.submit(func, a, c, 1.3)
    assert worker

# Generated at 2022-06-24 10:02:59.507923
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker.futures.maxlen == 2
    assert len(worker.futures) == 0
    assert worker.pool.max_workers == 1

# Generated at 2022-06-24 10:03:10.125826
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    import time
    import threading

    def _sleep_and_return(time_to_sleep):
        time.sleep(time_to_sleep)
        return time_to_sleep

    def _append_and_return(arr, val):
        arr.append(val)
        return arr

    worker = MonoWorker()
    # First task
    arr1 = []
    future1 = worker.submit(_append_and_return, arr1, 1)
    # Second task (should replace first)
    arr2 = []
    future2 = worker.submit(_append_and_return, arr2, 2)
    # Third task (should replace second)
    arr3 = []
    future3 = worker.submit(_append_and_return, arr3, 3)
    time.sleep

# Generated at 2022-06-24 10:03:18.525710
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def foo(*args, **kwargs):
        print("sleeping")
        import time
        time.sleep(2)
        print("done sleeping")
    mw = MonoWorker()
    mw.submit(foo)
    # Must print: "sleeping"
    print("Submitted")
    mw.submit(foo)
    # Must print: "sleeping", "Submitted"
    print("Submitted again")
    assert len(mw.futures) == 1
    import time
    time.sleep(1)
    mw.submit(foo)
    # Must print: "Submitted again", "Submitted"
    time.sleep(1)
    # Must print: "done sleeping"

# Generated at 2022-06-24 10:03:24.947082
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from collections import Counter
    from operator import sub
    from .testing_counters import ThreadPoolExecutorCounter
    from . import futures_utils

    def test(x):
        sleep(1)
        return x

    with ThreadPoolExecutorCounter(max_workers=10) as e:
        with futures_utils.MonoWorker() as m:
            for i in tqdm_auto.tqdm(xrange(10)):
                m.submit(e.submit, test, i)
            m.submit(e.shutdown, wait=False)
    assert e.executor._max_workers == [1]

# Generated at 2022-06-24 10:03:36.754605
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import inspect
    import multiprocessing
    from functools import partial
    from concurrent.futures import Future  # for python2 compatibility

    def is_future_running(future):
        # https://github.com/agronholm/apscheduler/blob/v3.3.0/apscheduler/util.py#L20
        return inspect.isgenerator(future._call_queue.__writers__[0][1].gi_frame.f_locals['gen'])

    # Casper's unit test
    mw = MonoWorker()
    assert not is_future_running(futures[0])
    mw.submit(partial(time.sleep, 1))
    futures = mw.futures  # should be [running] (1)

# Generated at 2022-06-24 10:03:40.967207
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from . import trange
    from .io import tqdm_notebook_failsafe
    with tqdm_notebook_failsafe():
        for i in trange(1, 4, desc='outer'):
            with MonoWorker() as mw:
                for j in trange(1, 3, desc='inner', leave=False):
                    time.sleep(.05)  # sleep
                    # yield
                    mw.submit(lambda: None)

# Generated at 2022-06-24 10:03:49.030754
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, time
    from random import random

    running = []
    results = []

    def foo():
        running.append(True)
        sleep(random())
        running.pop()
        results.append(time())

    mw = MonoWorker()

    mw.submit(foo)  # 1st run
    assert len(results) == 0
    assert len(running) == 1
    mw.submit(foo)  # no-op, already running
    assert len(results) == 0
    assert len(running) == 1
    sleep(.5 * random())
    assert results == [min(results)]  # 1st finished
    assert len(running) == 1
    sleep(.5 * random())
    assert results == [min(results)]  # 2nd finished
    assert len(running) == 0


# Generated at 2022-06-24 10:03:59.913895
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import concurrent.futures
    from tqdm.contrib.concurrent_utils import (MonoWorker, tqdm_worker_thread)

    def _unittest_tqdm_worker_thread(mw):
        try:
            mw.submit(time.sleep, 0.1)
            time.sleep(0.1)
            mw.submit(time.sleep, 0.1)
            time.sleep(0.1)
            mw.submit(time.sleep, 0.1)
            time.sleep(0.1)
            mw.submit(time.sleep, 0.1)
        finally:
            mw.pool.shutdown(wait=False)


# Generated at 2022-06-24 10:04:09.201199
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import os

    class MonoWorkerTest(MonoWorker):
        def __init__(self, n_jobs):
            super(MonoWorkerTest, self).__init__()
            self._n_jobs = n_jobs
            self.pid = os.getpid()

        def submit(self, func, *args, **kwargs):
            """`func(*args, **kwargs)` may replace currently waiting task."""
            # submit() should be called from the same process
            assert os.getpid() == self.pid, "submit() called from wrong process"
            if self._n_jobs < 1:
                raise ValueError("n_jobs=%d must be >=1" % self._n_jobs)

# Generated at 2022-06-24 10:04:16.178473
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import Pool
    from multiprocessing.pool import AsyncResult
    from .io import monitor_threads
    import time
    import sys

    def worker_join(n):
        """This is a worker function (blocking call)"""
        time.sleep(.1)  # emulating work
        return n

    def worker_raise(n):
        """This is a worker function (blocking call)"""
        time.sleep(.1)  # emulating work
        raise Exception("worker_raise raised!")

    def worker_futures(n):
        """This is a worker function (blocking call)"""
        time.sleep(1)  # emulating work
        return n

    def worker_pool_map(n):
        """This is a worker function (blocking call)"""
        time.sleep(1)

# Generated at 2022-06-24 10:04:29.829736
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .utils import _TestException, test_cls_docstrings
    import time
    test_cls_docstrings(MonoWorker)

    def func():
        time.sleep(1)

    worker = MonoWorker()
    running = worker.submit(func)

    # Moving on to second run
    worker.submit(func)
    time.sleep(0.1)
    assert running.running()

    # Submit to a closed pool
    worker.pool.shutdown(wait=False)
    worker.submit(func)

    # Check that running is still running
    assert running.running()

    # Exception handling
    worker = MonoWorker()
    running = worker.submit(_TestException().func)
    # Make sure exception was raised
    assert running.exception() is not None

    # Longer test

# Generated at 2022-06-24 10:04:38.570323
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys

    def time_printer(i):
        time.sleep(0.5)
        tqdm_auto.write('MonoWorker-test-{0}'.format(i))

    mworker = MonoWorker()
    mworker.submit(time_printer, 0)
    mworker.submit(time_printer, 1)
    mworker.submit(time_printer, 2)
    for i in tqdm_auto(range(10), file=sys.stderr):
        time.sleep(0.1)

# Generated at 2022-06-24 10:04:45.728717
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random

    class Task(object):
        def __init__(self, name):
            self.name = str(name)

        def __call__(self):
            time.sleep(random.random()/2)
            return self.name

        def __repr__(self):
            return self.name

    tasks = [Task(i) for i in ('a', 'a', 'a', 'b')]
    with tqdm_auto.tqdm(tasks, ncols=10, dynamic_ncols=True) as t:
        mw = MonoWorker()
        for task in t:
            t.set_postfix_str(repr(task))
            future = mw.submit(task)

# Generated at 2022-06-24 10:04:49.861329
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures as coefficients

    def func1(x):
        return x * x

    def func2(x):
        time.sleep(1)
        return x * x

    def func3(x):
        time.sleep(2)
        return x * x

    def func4(x):
        time.sleep(3)
        return x * x

    def test_single_submit():
        """Test single submit."""
        tqdm_auto.write("Test single")
        mono_worker = MonoWorker()
        future = mono_worker.submit(func2, 3)
        tqdm_auto.write("future: {}".format(future))
        tqdm_auto.write("wait until done")
        future.result()

# Generated at 2022-06-24 10:04:53.047880
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    worker = MonoWorker()
    assert worker.pool.__class__.__name__ == 'ThreadPoolExecutor'
    assert worker.futures.__class__.__name__ == 'deque'

# Generated at 2022-06-24 10:05:01.780562
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    mw = MonoWorker()

    fut1 = mw.submit(time.sleep, 0.5)
    assert fut1.result() is None

    fut2 = mw.submit(time.sleep, 0.5)
    assert fut2.result() is None

    fut3 = mw.submit(time.sleep, 0.5)
    assert fut3.result() is None
    assert fut2.cancel() is False

    fut4 = mw.submit(time.sleep, 0.5)
    assert fut4.result() is None
    assert fut3.cancel() is False

    mw2 = MonoWorker()
    fut5 = mw2.submit(lambda: 'a', 0.5)

# Generated at 2022-06-24 10:05:13.898280
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    import time
    import sys
    from tqdm._tqdm import trange

    class Periodic(object):
        """Repeats function call with given period."""
        def __init__(self, delay, func, args=()):
            self.delay = delay
            self.func = func
            self.args = args

        def start(self):
            """Start periodic calling, return `self`."""
            self.event = tqdm_auto.Events(unit='sec')
            self.event.register(self.func, *self.args)
            return self

        def stop(self):
            """Stop periodic calling, unregister handler."""
            self.event.unregister(self.func, *self.args)
            self.event.close()


# Generated at 2022-06-24 10:05:25.602583
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import time
    def wait(n):
        time.sleep(n)
        return n

    import pytest

    with pytest.raises(TypeError):
        MonoWorker().submit()

    mw = MonoWorker()
    assert mw.submit(wait, 1) is mw.submit(wait, 2)
    time.sleep(1.1)
    assert mw.submit(wait, 3) is mw.submit(wait, 4)
    time.sleep(1.1)
    assert mw.submit(wait, 5) is mw.submit(wait, 6)
    time.sleep(1.1)
    assert mw.submit(wait, 7) is mw.submit(wait, 8)
    time.sleep(1.1)


# Generated at 2022-06-24 10:05:28.350406
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test for constructor of class MonoWorker
    """
    mw = MonoWorker()
    assert mw.pool is not None
    assert len(mw.futures) == 0

# Generated at 2022-06-24 10:05:38.574517
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import random
    from time import sleep
    from threading import Thread
    from multiprocessing import Process
    from concurrent.futures import as_completed

    def _test(i, f, *args, **kwargs):
        assert i == 0
        sleep(2 * random())  # test that threading is correctly sequential
        return f(*args, **kwargs)

    def _test_threaded(f, *args, **kwargs):
        return Thread(target=_test, args=(0, f, ) + args, kwargs=kwargs).start()

    def _test_processed(f, *args, **kwargs):
        return Process(target=_test, args=(0, f, ) + args, kwargs=kwargs).start()


# Generated at 2022-06-24 10:05:47.228598
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    import random

    def running():
        sleep(random.random() + 2)
        return True

    def waiting():
        sleep(random.random() + 2)
        return False

    mw = MonoWorker()
    assert mw.futures.maxlen == 2
    assert mw.futures.maxlen == len(mw.futures)

    mw.submit(running)
    mw.submit(waiting)
    assert (mw.futures.pop()).result() == False

    sleep(1)
    mw.submit(waiting)
    assert (mw.futures.pop()).result() == False

    mw.pool.shutdown()

# Generated at 2022-06-24 10:06:00.078255
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Thread
    from concurrent.futures import ThreadPoolExecutor

    def submit(o, i):
        f = o.submit(time.sleep, i)
        return f, f.result()

    o = MonoWorker()
    assert o.submit(print, "x")
    assert o.submit(print, "x")
    assert o.submit(print, "x")

    # test cancel
    o = MonoWorker()
    assert o.submit(time.sleep, 1000)
    assert o.submit(time.sleep, 1000)
    assert o.submit(time.sleep, 1000)
    assert o.futures[0].cancel()

    pool = ThreadPoolExecutor(max_workers=10)
    times, n = [], 8


# Generated at 2022-06-24 10:06:07.818595
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import concurrent.futures
    import threading
    import time

    def func(x):
        time.sleep(x)
        return x

    # Test constructor of class MonoWorker
    mw = MonoWorker()
    assert isinstance(mw.pool, ThreadPoolExecutor)

    # Test submit(*args, **kwargs) of class MonoWorker
    assert mw.submit(func, 1)
    assert len(mw.futures) == 1
    assert mw.submit(func, 2)
    assert len(mw.futures) == 1
    assert mw.submit(func, 3)
    assert len(mw.futures) == 1
    assert mw.submit(func, 4)
    assert len(mw.futures) == 2

# Generated at 2022-06-24 10:06:13.206968
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    m = MonoWorker()
    assert m.submit(lambda: None).result() is None
    from time import sleep
    from contextlib import closing
    with closing(tqdm_auto.trange(2)) as pbar:
        for i in pbar:
            if i:  # discard first
                m.submit(sleep, 1).result()
                assert pbar.n == 0
                assert not m.futures[0].done()

    assert m.submit(lambda: None).result() is None
    assert m.submit(lambda: None).result() is None
    assert m.submit(lambda: None).result() is None

# Generated at 2022-06-24 10:06:13.648782
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    pass

# Generated at 2022-06-24 10:06:23.735504
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from threading import Lock
    from .tqdm import tqdm

    def a():
        time.sleep(1)

    def b():
        time.sleep(0.5)

    def c(lock):
        lock.acquire()
        time.sleep(0.5)
        lock.release()

    # 1) Get a MonoWorker
    mono = MonoWorker()
    assert mono.pool._max_workers == 1

    # 2) Submit
    lock = Lock()
    future_a = mono.submit(a)
    future_b = mono.submit(b)
    future_c = mono.submit(c, lock)
    future_c.result()

    # 3) Discard
    future_d = mono.submit(a)

    # 4) Iterate with tqdm, as

# Generated at 2022-06-24 10:06:30.609870
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, threading
    def myfunc(msg):
        time.sleep(.5)
        print(threading.current_thread())
        print(msg)
    worker = MonoWorker()
    worker.submit(myfunc, "AAA")
    worker.submit(myfunc, "BBB")
    worker.submit(myfunc, "CCC")
    worker.submit(myfunc, "DDD")

# To execute the unit test above, put them under if __name__ == '__main__'
if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:06:39.529312
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def func_to_test(*args, **kwargs):
        time.sleep(1)
        return 1
    test_MonoWorker = MonoWorker()
    future_task1 = test_MonoWorker.submit(func_to_test, 1)
    future_task2 = test_MonoWorker.submit(func_to_test, 2)
    future_task3 = test_MonoWorker.submit(func_to_test, 3)
    assert future_task3.result() == 1

# Generated at 2022-06-24 10:06:42.621185
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .tests import _test_instance
    from .tests import _test_results
    results = _test_results()
    _test_instance(MonoWorker, test_results=results)
    for k in ('submit', 'pool', 'futures'):
        assert hasattr(results['inst'], k), k



# Generated at 2022-06-24 10:06:45.194644
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def countdown(n):
        for i in tqdm_auto(range(n), desc='Counting down'):
            time.sleep(0.1)

    mono_worker = MonoWorker()
    f1 = mono_worker.submit(countdown, 10)
    f2 = mono_worker.submit(countdown, 10)
    f1.result()
    f2.result()


# Generated at 2022-06-24 10:06:49.723825
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test routine for class `MonoWorker`."""
    import time as tm
    import subprocess as sp

    def _f(cmd):
        """Helper function"""
        # tqdm.write("Running " + cmd)
        return sp.check_output("yes " + cmd + " | head -n 200000",
                               shell=True).decode("ascii")

    from tqdm.contrib.concurrency import MonoWorker

    MW = MonoWorker()
    for _ in range(4):
        for i in tqdm_auto.trange(3):
            MW.submit(_f, cmd=str(i))
            tm.sleep(0.5)

    pass  # todo: test not corrupting output

# Generated at 2022-06-24 10:06:54.968816
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from unittest import TestCase

    def func(msg):
        sleep(1)
        return msg

    class MonoWorkerTestCase(TestCase):
        def test_submit(self):
            worker = MonoWorker()
            self.assertEqual(worker.submit(func, "test1").result(), "test1")
            self.assertEqual(worker.submit(func, "test2").result(), "test2")

    MonoWorkerTestCase("test_submit").test_submit()

# Generated at 2022-06-24 10:06:56.802265
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    global worker
    worker = MonoWorker()

test_MonoWorker()

# Generated at 2022-06-24 10:07:06.460353
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:07:17.509086
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mono = MonoWorker()

    def sleeper(i):
        time.sleep(i)
        return i

    print()
    tqdm_auto.write('Testing MonoWorker.submit()/done()...')

    assert mono.futures == deque([], 2)
    mono.submit(sleeper, 3)
    assert mono.futures == deque([], 2)

    mono.submit(sleeper, 2)
    assert mono.futures == deque([], 2)

    mono.submit(sleeper, 1)
    assert mono.futures == deque([], 2)

    time.sleep(1.2)
    assert mono.futures == deque([], 2)

    time.sleep(1)
    assert mono.futures == deque([], 2)

   

# Generated at 2022-06-24 10:07:30.476712
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    try:
        import threading
    except ImportError:
        return
    mw = MonoWorker()
    # Add one task
    f1 = mw.submit(threading.Event().wait, 5)
    assert len(mw.futures) == 1
    f1.cancel()
    # Add two tasks
    f1 = mw.submit(threading.Event().wait, 5)
    assert len(mw.futures) == 1
    f2 = mw.submit(threading.Event().wait, 5)
    assert len(mw.futures) == 2
    f1.cancel()
    f2.cancel()
    # Add three tasks
    f1 = mw.submit(threading.Event().wait, 5)

# Generated at 2022-06-24 10:07:37.006398
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    pool = MonoWorker()
    # use return value to prevent short-circuit evaluation
    assert not (pool.submit(time.sleep, random.uniform(0.1, 0.2)) and
                pool.submit(time.sleep, random.uniform(0.1, 0.2)) and
                pool.submit(time.sleep, random.uniform(0.1, 0.2)))
    time.sleep(0.4)
    pool.pool.shutdown()

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:07:39.298326
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Initializes MonoWorker.
    """
    MonoWorker()


# Generated at 2022-06-24 10:07:50.599452
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import current_thread

    def t(i):
        """Sleep for i seconds, return i+1."""
        sleep(i)
        return i + 1

    worker = MonoWorker()

    # Initial population
    res = worker.submit(t, 1)
    assert res.result() == 2, "Bad result: {}.".format(res.result())
    assert current_thread().name == 'ThreadPoolExecutor-0_0', \
        "Submission in wrong thread: {}.".format(current_thread().name)

    # Long task discards short task
    res = worker.submit(t, 2)
    assert res.result() == 3, "Bad result: {}.".format(res.result())

# Generated at 2022-06-24 10:07:57.921890
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import numpy as np  # noqa
    from ..utils import _range

    def slow_add(a, b, delay=5, do_wait=False):
        """
        >>> slow_add(1, 2, 3, False)
        3
        >>> all(slow_add.is_alive for slow_add in _slows)
        True
        >>> _ = slow_add(1, 2, 3, True)
        >>> all(not slow_add.is_alive for slow_add in _slows)
        True
        """
        from threading import Thread
        slow_add.is_alive = True

        def wrapper():
            time.sleep(delay)
            slow_add.result = a + b
            slow_add.is_alive = False

        slow_add.thread = Thread

# Generated at 2022-06-24 10:08:10.628631
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures as _cf
    import threading as _th
    import unittest as _ut

    def func(i):
        time.sleep(1)
        return i

    class Test(object):
        def __init__(self):
            self.results = []
            self.evs = []
            self.mwo = MonoWorker()

        def run(self, i, should_fail=False):
            ev = _th.Event()
            self.evs.append(ev)

# Generated at 2022-06-24 10:08:13.281327
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()
    assert len(m.pool._threads) == 1
    assert m.futures.maxlen == 2
    assert len(m.futures) == 0


# Generated at 2022-06-24 10:08:22.198302
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing
    import time

    def foo(x):
        time.sleep(x)
        return x

    m = MonoWorker()
    a = m.submit(foo, 3)
    b = m.submit(foo, 4)
    assert a.result() == 3
    assert b.result() == 4

    a = m.submit(foo, 3)
    b = m.submit(foo, 4)
    c = multiprocessing.pool.ThreadPool(5).apply_async(foo, (5,))
    assert a.result() == 3
    assert b.result() == 4
    assert c.get() == 5
    assert not a.running()
    assert not b.running()

# Generated at 2022-06-24 10:08:33.664242
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import signal
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    tqdm_auto.write('Testing MonoWorker.submit')

    def time_sleep(value):
        time.sleep(value)
        return True

    def main():
        try:
            worker = MonoWorker()
            for i in range(10):
                worker.submit(time_sleep, 0.1)
                time.sleep(0.1)
        except KeyboardInterrupt:
            tqdm_auto.write('KeyboardInterrupt')
        except:
            import traceback
            tqdm_auto.write('Unknown exception:\n' + traceback.format_exc())

    main()

# Generated at 2022-06-24 10:08:41.525144
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from ..auto import tqdm as tqdm_auto
    def sleeper(n):
        time.sleep(n)
        return n

    w = MonoWorker()
    futures = []

    # some should be cancelled, prior to the maxlen
    for i in range(5):
        futures.append(w.submit(sleeper, 0.05))
    time.sleep(0.05)
    futures.append(w.submit(sleeper, 0.5))  # should be running

    # Append to maxlen
    futures.append(w.submit(sleeper, 0.5))
    time.sleep(0.05)

    # Append over maxlen
    futures.append(w.submit(sleeper, 0.5))
    time.sleep(0.01)

# Generated at 2022-06-24 10:08:52.197528
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def do_nothing():
        pass

    def do_something():
        raise Exception("do_something")

    def do_something_else():
        raise Exception("do_something_else")

    def do_another_thing():
        raise Exception("do_another_thing")

    def do_something_more():
        raise Exception("do_something_more")

    def do_nothing_more():
        pass

    mono_worker = MonoWorker()
    mono_worker.submit(do_nothing)
    mono_worker.submit(do_nothing)
    mono_worker.submit(do_nothing)
    mono_worker.submit(do_nothing)

    mono_worker.submit(do_something)
    mono_worker.submit(do_something_else)
    mono_worker.submit(do_another_thing)
    mono_

# Generated at 2022-06-24 10:09:01.688808
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from . import TMonitor
    from tqdm import tqdm

    m = MonoWorker()
    res = []
    monitor = TMonitor()
    monitor.start()

    def submit_threads(i):
        for j in tqdm(range(i)):
            time.sleep(0.1)  # replace
            m.submit(lambda n: n ** n, n=j)

        assert m.submit(lambda n: n, n=i) is None
        time.sleep(0.1)  # replace
        assert m.submit(lambda n: n, n=i + 1).result() == n

        res[0] = i

    tqdm_auto.write("\nstart")
    submit_threads(100)
    tqdm_auto.write("\nend")


# Generated at 2022-06-24 10:09:05.085436
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Thread

    def foo():
        sleep(0.1)

    def bar():
        sleep(0.1)

    def baz():
        sleep(0.1)

    mw = MonoWorker()
    mw.submit(foo)

    t = Thread(target=mw.submit, args=(bar,))
    t.start()
    sleep(0.01)
    mw.submit(baz)
    t.join()

# Generated at 2022-06-24 10:09:13.382407
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import math
    import random
    import threading
    with tqdm_auto.tqdm(desc="MonoWorker", disable=True) as t:
        m = MonoWorker()
        test_data = range(10)
        random.shuffle(test_data)
        res = [None] * len(test_data)
        t.refresh()
        for i in test_data:
            m.submit(_sleep_func, i, t, res, i)
        while None in res:
            time.sleep(0.1)
        assert res == sorted(test_data)
    with tqdm_auto.tqdm(desc="MonoWorker", disable=True) as t:
        m = MonoWorker()
        test_data = range(10)
        random.shuffle

# Generated at 2022-06-24 10:09:24.230339
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import operator
    import functools
    import itertools as itt
    from ..auto import tqdm
    TW = MonoWorker()

    def tmul(x, y):
        """Test sleep and multiply"""
        time.sleep(0.05)
        return x * y

    timemsg = functools.partial(tqdm_auto.write, end='', file=tqdm_auto._file)


# Generated at 2022-06-24 10:09:33.485145
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit tests for class MonoWorker"""
    import time

    def func():
        time.sleep(1)
        return 0

    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert mw.futures.maxlen == 2
    assert len(mw.pool._threads) == 0
    assert mw.pool._max_workers == 1

    mw.submit(func)
    assert len(mw.futures) == 1
    assert len(mw.pool._threads) == 1

    mw.submit(func)
    assert len(mw.futures) == 1
    assert len(mw.pool._threads) == 1

    time.sleep(0.1)
    mw.submit(func)

# Generated at 2022-06-24 10:09:43.315759
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    tqdm_auto.write("Start first task")
    tqdm_auto.write("Action 1")
    time.sleep(1)
    tqdm_auto.write("Action 2")
    time.sleep(2)
    tqdm_auto.write("Finish first task")

    tqdm_auto.write("Start second task")
    tqdm_auto.write("Action 3")
    time.sleep(3)
    tqdm_auto.write("Action 4")
    time.sleep(4)
    tqdm_auto.write("Finish second task")

    tqdm_auto.write("Start third task")
    tqdm_auto.write("Action 5")
    time.sleep(5)
    tqdm_auto.write("Action 6")
    time.sleep(6)

# Generated at 2022-06-24 10:09:52.301916
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Semaphore, Event
    from traceback import format_exc
    sem = Semaphore(value=2)
    ev = Event()
    # pylint: disable=W0613
    def f1():
        """start"""
        sem.acquire()
        ev.wait()
        sleep(2)

    def f2(n):
        """replace"""
        sem.acquire()
        sleep(n)

    def f3(n):
        """replace"""
        sem.acquire()
        sleep(n)

    def f4():
        """replace"""
        sem.acquire()
        raise KeyboardInterrupt

    # pylint: disable=W0621

# Generated at 2022-06-24 10:09:57.789981
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    from time import sleep

    # the tests:
    def test():
        def target(e):
            e.set()
            sleep(1)
            return 'foo'

        e = Event()
        w = MonoWorker()
        f = w.submit(target, e)
        assert f.done() is False
        assert e.wait()
        e.clear()
        assert f.done() is False
        g = w.submit(target, e)
        assert f.done() is True
        assert e.wait()
        e.clear()
        assert g.done() is False
        assert g.cancel() is False
        h = w.submit(target, e)
        assert g.cancel() is True
        assert g.done() is True
        assert h.done() is False


# Generated at 2022-06-24 10:09:58.431573
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()

# Generated at 2022-06-24 10:10:08.001166
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    thread_count_lock = threading.Lock()
    thread_count = 0

    def job():
        time.sleep(0.01)
        with thread_count_lock:
            thread_count += 1
        return thread_count

    def do_test(test_args):
        m = MonoWorker()
        with tqdm_auto.tqdm(total=sum(test_args)) as pbar:
            for i in test_args:
                waiting = m.submit(lambda: job())
                for _ in range(i):
                    result = waiting.result()
                    assert result == thread_count
                    pbar.update()

    test_args = [1, 2, 5, 10, 20, 50, 100]
    do_test(test_args)

# Generated at 2022-06-24 10:10:17.937951
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import os

    MONO_WORKER = MonoWorker()

    def slowprint(text):
        time.sleep(2)

    print('\nStart task 1')
    MONO_WORKER.submit(slowprint, 'Task 1 complete')
    time.sleep(1)

    print('\nStart task 2')
    MONO_WORKER.submit(slowprint, 'Task 2 complete')
    time.sleep(1)

    print('\nStart task 3')
    MONO_WORKER.submit(slowprint, 'Task 3 complete')
    time.sleep(1)

    print('\nStart task 4')
    MONO_WORKER.submit(slowprint, 'Task 4 complete')
    time.sleep(1)

    print('\nStart task 5')

# Generated at 2022-06-24 10:10:25.842914
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    random.seed(0)

    work = MonoWorker()

    # Disable tqdm auto
    tqdm_auto.tqdm = tqdm_auto._tqdm_default

    def do_work(seed):
        print('start', seed)
        time.sleep(random.random() * 0.5)
        print('finish', seed)
        return seed

    def do_work_error(seed):
        raise ValueError(seed)

    task = work.submit(do_work, 'work 1')
    task2 = work.submit(do_work, 'work 2')
    assert task.done()
    assert not task2.done()
    task2.result()
    task = work.submit(do_work_error, 'work err')
    assert task.done()

# Generated at 2022-06-24 10:10:30.040847
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    from time import sleep

    def func():
        sleep(5)

    mono_worker = MonoWorker()
    mono_worker.submit(func)

    assert mono_worker.futures  # there is now a task
    sleep(5)
    assert not mono_worker.futures  # task finished
    assert mono_worker.pool  # pool is still running

# Generated at 2022-06-24 10:10:39.840809
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import sys

    mono_worker = MonoWorker()

    def run(t=3):
        time.sleep(t)
        return random.randint(1, 10)

    print("Run without keyword")
    f1 = mono_worker.submit(run)
    f2 = mono_worker.submit(run)
    f3 = mono_worker.submit(run)
    print("f1: " + str(f1.result()))
    print("f2: " + str(f2.result()))
    print("f3: " + str(f3.result()))

    assert f1.result()  # f1 should be executed
    assert not f2.result()  # f2 should be cancelled
    assert f3.result()  # f3 should be executed


# Generated at 2022-06-24 10:10:48.690089
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .tqdm_test_class import TestCase  # noqa

    class TestMonoWorker(TestCase):
        """Test `MonoWorker` class"""
        @staticmethod
        def test_basic_usage():
            """Test basic usage"""
            def target(sleep_time):
                sleep(sleep_time)
                return sleep_time

            mono_worker = MonoWorker()
            future = mono_worker.submit(target, 2)
            self.assertEqual(future.result(), 2)
            future = mono_worker.submit(target, 2)
            self.assertEqual(future.result(), 2)

        @staticmethod
        def test_exc_in_arg():
            """Test arg handling"""
            def target(exc_in_arg):
                raise exc_in_arg

# Generated at 2022-06-24 10:10:55.397314
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import random
    countdown = threading.Event()
    countdown.clear()
    def slow_func(ms):
        countdown.wait(ms / 5000)
    workers = MonoWorker()
    count = 0
    for i in tqdm_auto.tqdm(range(100)):
        workers.submit(slow_func, random.randint(0, 10), )
        count += 1
        if i == 50:
            countdown.set()
    countdown.set()
    time.sleep(0.1)
    assert count >= 50
    time.sleep(0.1)
    assert count >= 100

# Generated at 2022-06-24 10:11:00.425200
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def func_1(arg):
        sleep(0.1)
        return arg

    def func_2(arg):
        sleep(0.2)
        return arg

    def func_3(arg):
        sleep(0.3)
        return arg

    test = MonoWorker()

    for i in range(1, 5):
        future = test.submit(func_1, i)
        assert future.done()

    for i in range(5, 10):
        future = test.submit(func_2, i)
        future.result()

    for i in range(10, 15):
        future = test.submit(func_2, i)
        assert future.done()

    for i in range(15, 20):
        future = test.submit(func_3, i)
        future

# Generated at 2022-06-24 10:11:07.483692
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    def sleep(t):
        time.sleep(t)
        return t

    mw = MonoWorker()
    for i in range(10):
        mw.submit(sleep, random.random() * 0.2)
    time.sleep(1)
    assert mw.pool.shutdown(wait=True)
    assert mw.futures.maxlen == 2
    assert len(mw.futures) == 2
    assert mw.futures[0].done()
    assert mw.futures[1].done()
# /test_MonoWorker_submit



# Generated at 2022-06-24 10:11:17.167245
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    from .std_out import std_out, std_err

    def run(n):
        """Slow task"""
        print('Waiting for %d seconds' % n)
        time.sleep(n)
        return n

    # Test with no task executed yet
    mono_worker = MonoWorker()
    future = mono_worker.submit(run, 10)
    future.result()  # 10
    assert(future in mono_worker.futures)
    assert(mono_worker.futures[0] is future)

    # Test with running task not finished
    future = mono_worker.submit(run, 10)
    assert(not future.done())
    assert(future in mono_worker.futures)

# Generated at 2022-06-24 10:11:17.906428
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()
    assert m is not None

# Generated at 2022-06-24 10:11:27.592786
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import concurrent.futures
    import unittest

    class TestMonoWorker(unittest.TestCase):
        def setUp(self):
            self.task = MonoWorker()

        def test_MonoWorker(self):
            def task(n):
                time.sleep(.1)
                return n

            for i in range(10):
                self.task.submit(task, i)
                time.sleep(.05)

            time.sleep(1)
            self.assertTrue(all(t.cancelled() for t in self.task.futures))
            self.assertEqual(len(self.task.futures), 0)

    unittest.main(module=__name__)

# Generated at 2022-06-24 10:11:37.932174
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def func_raises_exception():
        raise Exception("test exception")

    def func_runs_forever():
        while True:
            time.sleep(0.1)

    # test exception in main thread:
    worker = MonoWorker()
    assert len(worker.pool._threads) == 0  # before start
    worker.submit(func_raises_exception)
    assert len(worker.pool._threads) == 1  # after start
    time.sleep(0.1)
    for _ in range(2):
        worker.submit(func_runs_forever)
    time.sleep(0.1)
    assert len(worker.pool._threads) == 1  # still only 1 running thread
    time.sleep(0.1)
    assert len(worker.pool._threads)

# Generated at 2022-06-24 10:11:48.505670
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys

    def print_hello():
        time.sleep(1)
        tqdm_auto.write('hello')

    def print_world():
        time.sleep(1)
        tqdm_auto.write('world')

    worker = MonoWorker()

    for i in range(4):
        worker.submit(print_hello)
        time.sleep(0.5)
        tqdm_auto.write('waiting...')
        time.sleep(0.5)

    for i in range(4):
        worker.submit(print_world)
        time.sleep(0.5)
        tqdm_auto.write('waiting...')
        time.sleep(0.5)

    worker.shutdown()
    worker.await_shutdown()

# Generated at 2022-06-24 10:11:56.430179
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def foo(x, y):
        sleep(x + y)
        return x + y

    mw = MonoWorker()
    assert mw.submit(foo, 1, 1) is not None
    assert mw.submit(foo, 2, 1) is not None
    assert mw.futures[0].result() == 3

# Generated at 2022-06-24 10:12:05.170255
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from . import ThreadedWrapper

    def print_length(*args, **kwargs):
        sleep(0.2)
        tqdm_auto.write("Length: {}".format(len(args)))

    with ThreadedWrapper(MonoWorker()) as worker:
        worker.submit(print_length)
        worker.submit(print_length)
        worker.submit(print_length)
        worker.submit(print_length)
        worker.submit(print_length)
        worker.submit(print_length)