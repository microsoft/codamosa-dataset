

# Generated at 2022-06-24 10:02:07.369931
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func1(a, b=1):
        return a * b
    def func2(a, sleep=0.01):
        import time
        time.sleep(sleep)
        return a
    def func3(a):
        return a

    from time import sleep
    from .tests import pretest_posttest

    with pretest_posttest() as t:
        worker = MonoWorker()
        assert worker.submit(func1, 2)
        assert worker.submit(func3, 2) is not None
        assert worker.futures[0].cancel()
        sleep(0.5)
        # first is cancelled, second is in running, third is waiting
        assert [f.done() for f in worker.futures] == [True, False, None]
        # first is cancelled, second is in running, third is

# Generated at 2022-06-24 10:02:17.064822
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time


# Generated at 2022-06-24 10:02:25.203096
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit tests for MonoWorker"""
    import concurrent.futures
    import time

    def run_worker(worker):
        time.sleep(0.25)
        try:
            ret = worker.submit(lambda x: x*2, 4).result()
        except concurrent.futures.CancelledError:
            return 42
        return ret

    worker = MonoWorker()
    assert run_worker(worker) == 8
    assert run_worker(worker) == 42
    assert run_worker(worker) == 8
    assert run_worker(worker) == 42
    assert run_worker(worker) == 8

# Generated at 2022-06-24 10:02:33.196755
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    def do_work(work, time):
        sleep(time)
        return 'did ' + str(work)

    mono_worker = MonoWorker()
    results = []
    results.append(mono_worker.submit(do_work, 1, 1))
    results.append(mono_worker.submit(do_work, 2, 0.5))
    results.append(mono_worker.submit(do_work, 3, 0.1))
    results.append(mono_worker.submit(do_work, 4, 0.2))
    for r in results:
        print(r.result())
    # prints:
    # did 2
    # did 4
    # did 3
    # did 1

# Generated at 2022-06-24 10:02:39.694866
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    x = MonoWorker()
    x.submit(lambda: None)
    x.submit(lambda: None)
    x.submit(lambda: None)
    x.submit(lambda: None)
    x.submit(lambda: None)
    x.submit(lambda: None)
    x.submit(lambda: None)
    x.submit(lambda: None)


if __name__ == "__main__":  # pragma: no cover
    from . import test
    test.run_module("tqdm.contrib.tests.test_monoworker")
    test.run_module("tqdm.contrib.tests.test_threadpool")

# Generated at 2022-06-24 10:02:44.430591
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def test_func(x):
        import time
        time.sleep(1)
        return x * x

    worker = MonoWorker()
    f1 = worker.submit(test_func, 2)
    f2 = worker.submit(test_func, 3)
    f3 = worker.submit(test_func, 4)

    assert f2.result() == 9
    assert f3.cancelled()
    assert f1.result() == 4

# Generated at 2022-06-24 10:02:50.027885
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    worker = MonoWorker()
    tasks = [worker.submit(time.sleep, random.randint(0, 2))
             for _ in range(100)]
    while tasks:
        task = tasks.pop()
        if task.done():
            continue
        tasks.append(task)
        time.sleep(0.01)

# Generated at 2022-06-24 10:02:59.650265
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    import time
    import threading
    # pylint: disable=unused-variable

    def delay():
        time.sleep(0.5)

    t0 = time.time()
    mw = MonoWorker()

    # start a task
    task1 = mw.submit(delay)
    # submit 3 tasks and cancel 2 tasks
    task2 = mw.submit(delay)
    task3 = mw.submit(delay)
    task4 = mw.submit(delay)

    # wait for all tasks finish
    for task in [task1, task2, task3, task4]:
        task.result()
    # assert that mono-worker correctly cancels 2 tasks
    assert task2.cancelled()
    assert task3.cancelled()

# Generated at 2022-06-24 10:03:09.450083
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def fib(n):
        if n < 2:
            return 1
        return fib(n - 1) + fib(n - 2)

    def fib_threaded(i):
        time.sleep(.5)
        return fib(i), time.time()

    # Instantiate the worker
    worker = MonoWorker()

    # Submit 3 requests
    fib_futures = [
        worker.submit(fib_threaded, i)
        for i in tqdm_auto.trange(3, desc="fib", leave=False)
    ]
    # Wait for them to finish
    for future in fib_futures:
        future.result()

# Generated at 2022-06-24 10:03:19.031497
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test `MonoWorker.submit`."""
    from ..utils import flush

    @flush
    def f1(i):
        """`test_MonoWorker_submit` helper"""
        while True:
            pass

    @flush
    def f2(i):
        """`test_MonoWorker_submit` helper"""
        while True:
            pass

    @flush
    def f3(i):
        """`test_MonoWorker_submit` helper"""
        while True:
            pass

    mono = MonoWorker()
    f1(1)
    assert mono.submit(f2, 2) is not None
    # 1st arg must be func
    assert mono.submit(1, 2) is None
    # We expect the 2nd arg is replaced by the 3rd

# Generated at 2022-06-24 10:03:27.589264
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from os import getpid
    from multiprocessing import Process
    from time import sleep
    from random import random

    def run_MonoWorker(**kwargs):
        import os
        import random
        import time
        from tqdm.contrib.concurrency import MonoWorker

        print(os.getpid(), kwargs)
        w = MonoWorker(**kwargs)

        def sleep_random(**_):
            time.sleep(random.random() * 1)
            return os.getpid()

        futures = [w.submit(sleep_random) for _ in range(5)]

        def get_result(future):
            return (future.result(), future.done(), future.running(),
                    future.cancelled(), getpid(), os.getpid())


# Generated at 2022-06-24 10:03:38.473314
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:03:45.270608
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys
    sys.stderr.write('Starting test_MonoWorker ... ')
    sys.stderr.flush()
    mono_worker = MonoWorker()
    mono_worker.submit(time.sleep, 0.5)
    mono_worker.submit(time.sleep, 0.5)
    mono_worker.submit(time.sleep, 0.5)
    print('done.\n')

# Generated at 2022-06-24 10:03:52.834914
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import multiprocessing
    import time
    mw = MonoWorker()
    def func(x):
        time.sleep(x)
        return x
    assert mw.submit(func, 0.5).result() == 0.5
    assert mw.submit(func, 0.4).result() == 0.4
    assert mw.submit(func, 0.3).result() == 0.3
    assert mw.submit(func, 0.2).result() == 0.2
    assert mw.submit(func, 0.1).result() == 0.1
    assert mw.submit(func, 1).result() == 1
    assert mw.submit(func, 2).result() == 2
    assert mw.submit(func, 3).result() == 3
    assert mw.submit(func, 4).result

# Generated at 2022-06-24 10:04:03.131074
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    assert mw.futures
    assert mw.futures.maxlen == 2
    assert not mw.futures.maxlen in set([len(mw.futures)])
    assert not len(mw.futures)
    assert not mw.pool._work_queue.qsize()
    assert not mw.pool._threads
    assert not mw.pool._threads._queue
    assert not mw.pool._result_queue.qsize()
    mw.submit(lambda: time.sleep(3), wait=3)
    time.sleep(.5)
    assert len(mw.futures)
    assert mw.futures.maxlen in set([len(mw.futures)])
    assert m

# Generated at 2022-06-24 10:04:09.640225
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from .utils import _range

    def func(a):
        sleep(a / 10)
        return a

    n = 10
    with tqdm_auto.tqdm(total=n) as t:
        mw = MonoWorker()

        def cb(a, mw=mw, t=t, func=func):
            t.update()
            if a < n - 1:
                mw.submit(func, a + 1)

        for a in _range(n):
            mw.submit(func, a)
            mw.futures[-1].add_done_callback(cb)


# Generated at 2022-06-24 10:04:22.027599
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # dummy functions
    def sqr(x):
        import math
        import time
        time.sleep(x)
        return math.sqrt(x)

    def nonblock(x):
        return
    # Add a pool and submit dummy functions
    pool = MonoWorker()
    futures = []
    futures.append(pool.submit(nonblock, 2))
    futures.append(pool.submit(sqr, 2))
    futures.append(pool.submit(nonblock, 3))
    futures.append(pool.submit(sqr, 3))
    # Assert that nonblock is not executed
    for future in futures:
        assert(future.done() == False), "nonblock should not be completed"
    # Assert that sqr is executed
    for future in futures[1::2]:
        future.result()  # wait

# Generated at 2022-06-24 10:04:23.428662
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker


# Generated at 2022-06-24 10:04:31.809771
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import subprocess
    mw = MonoWorker()

    # test running and waiting task
    t = mw.submit(subprocess.call, ["ls", "-l"])
    t = mw.submit(subprocess.call, ["ls", "-lh"])
    assert not t.done()
    assert len(mw.futures) == 1

    # test only running task
    t = mw.submit(subprocess.call, ["sleep", "1"])
    assert not t.done()
    assert len(mw.futures) == 1

    # test waiting task
    t = mw.submit(subprocess.call, ["sleep", "0.5"])
    assert not t.done()
    assert len(mw.futures) == 1

    # test that waiting task is cleared
    t

# Generated at 2022-06-24 10:04:41.272141
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import multiprocessing as mp
    import concurrent.futures as cf

    def func(a, b, c=None):
        time.sleep(float(c))
        return a * b


# Generated at 2022-06-24 10:04:50.178504
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    class StdOut(object):
        def __init__(self):
            self.msg = ''
        def write(self, msg):
            self.msg = msg
    def func(a):
        if a < 0: raise Exception(a)
        return -a
    stdout = StdOut()
    mw = MonoWorker()
    mw.submit(func, -1)
    mw.submit(func, -2)
    mw.submit(func, -3)
    tqdm_auto.write = stdout.write
    assert stdout.msg == '-3'
    assert str(-mw.futures[0].result()) == stdout.msg
    mw.submit(func, 1)
    assert stdout.msg == '1'

# Generated at 2022-06-24 10:04:51.340099
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker.futures.maxlen == 2

# Generated at 2022-06-24 10:04:55.335186
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def sleeper(i):
        time.sleep(i)
        return i

    from tqdm import trange

    m = MonoWorker()
    for i in trange(7):
        m.submit(sleeper, i)

    for f in m.futures:
        f.result()

    m.pool.shutdown()



# Generated at 2022-06-24 10:04:56.271864
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()



# Generated at 2022-06-24 10:05:03.839110
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading

    def sleeper(sleep):
        threading.current_thread().name = 'I sleep'
        time.sleep(sleep)
        return sleep

    def printer(msg):
        threading.current_thread().name = 'I print'
        tqdm_auto.write(msg)
        time.sleep(2)

    mw = MonoWorker()

    mw.submit(sleeper, 2).result()
    time.sleep(1)
    mw.submit(printer, '1').result()
    time.sleep(3)
    mw.submit(printer, '2').result()
    time.sleep(3)
    mw.submit(printer, '3').result()



# Generated at 2022-06-24 10:05:14.189515
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from concurrent.futures import Future
    from functools import partial

    def _done(f):
        f.set_running_or_notify_cancel()
        f.set_result("Done")

# Generated at 2022-06-24 10:05:25.820876
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    from contextlib import contextmanager

    @contextmanager
    def fake_time(millis):
        start = time.time()
        yield
        end = time.time()
        time.sleep(millis / 1000 - (end - start))

    def fake_task():
        return random.randint(1, 100)

    def fake_timeout_task():
        time.sleep(10)

    def fake_false_task():
        raise RuntimeError('Error!')

    def test_func(func):
        with fake_time(200):
            monoworker = MonoWorker()
            all_tasks = []
            for _ in range(5):
                f = monoworker.submit(func)
                all_tasks.append(f)

# Generated at 2022-06-24 10:05:32.347429
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    mw = MonoWorker()

    def func(n):
        time.sleep(n)
        return n

    mw.submit(func, 5.0)

    # submit another task and expect it to be discarded
    mw.submit(func, 1.0)
    # confirm that the first task is still running
    assert not mw.futures[0].done()
    # wait for the first task to finish
    mw.futures[0].result()

# Generated at 2022-06-24 10:05:41.346645
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # testing concurrency of multiple tasks
    from time import sleep
    from random import random

    def my_task(num):
        sleep(random() / 3 + 0.1)
        return num

    mono = MonoWorker()
    max_tasks = 10
    tasks = range(max_tasks)
    # submit tasks
    with tqdm_auto.tqdm(total=max_tasks, desc="Submitting tasks") as pbar:
        for i in tasks:
            if mono.submit(my_task, i):
                pbar.update(1)

    # wait for result
    completed = []

# Generated at 2022-06-24 10:05:49.283430
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import os
    import sys
    import random

    def _sigint(signum, frame):
        print("\nTrying to exit gracefully ..\n")
        sys.exit(1)

    def sleep(wait=0, msg="", *args, **kwargs):
        """
        Sleep for wait seconds and print msg.
        """
        wait = random.random() * wait
        t0 = time.time()
        tqdm_auto.write("Sleeping for %d seconds with msg '%s'" % (wait, msg))
        time.sleep(wait)
        print("Ran for %d seconds with msg '%s'" % (time.time() - t0, msg))

    def task_A():
        sleep(wait=3, msg="A")


# Generated at 2022-06-24 10:05:53.544343
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    '''
    Test case for `MonoWorker` constructor,
    '''
    worker = MonoWorker()
    assert repr(worker) == "MonoWorker()"


# Generated at 2022-06-24 10:05:55.461516
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    try:
        mw.pool.shutdown()
    except Exception:
        pass



# Generated at 2022-06-24 10:06:03.308510
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    MonoWorker().submit(lambda: tqdm_auto.write("hello 1"))
    MonoWorker().submit(lambda: tqdm_auto.write("hello 2"))
    MonoWorker().submit(lambda: tqdm_auto.write("hello 3"))
    MonoWorker().submit(lambda: tqdm_auto.write("hello 4"))
    MonoWorker().submit(lambda: tqdm_auto.write("hello 5"))


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:06:05.190616
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for MonoWorker."""
    m = MonoWorker()
    assert len(m.futures) == 0



# Generated at 2022-06-24 10:06:12.367175
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    num_threads = 4
    tests = [num_threads * [0],
             num_threads * [(num_threads * [0])],
             num_threads * [num_threads * [0]],
             num_threads * [num_threads * [(num_threads * [0])]]]
    for test in tests:
        def print_result(result):
            print('\nresult = {}'.format(result))

        def run_test(test, i):
            for j in range(i):
                time.sleep(.1)
            return test[i]

        worker = MonoWorker()
        threads = []

# Generated at 2022-06-24 10:06:20.343968
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import string

    def random_string(length=8):
        return ''.join(random.choice(string.ascii_lowercase)
                       for _ in range(length))

    def slow():
        sleep_time = random.random()
        time.sleep(sleep_time)
        return sleep_time

    mw = MonoWorker()
    f1 = mw.submit(slow)
    f2 = mw.submit(slow)
    f3 = mw.submit(slow)
    f4 = mw.submit(slow)
    assert len(mw.futures) == 1
    assert mw.futures[0] == f4
    f5 = mw.submit(slow)
    f6 = mw.submit(slow)
    f7 = mw

# Generated at 2022-06-24 10:06:27.142793
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import set_start_method, current_process

    def wait_for_tqdm():
        # To test Windows-compatibility, start a new process
        sleep(1.5)  # ensure that process is running concurrently
        tqdm_auto.write(get_pid())

    def get_pid():
        return current_process().pid

    set_start_method('spawn')
    m = MonoWorker()
    print("pid =", get_pid())
    m.submit(wait_for_tqdm)
    m.submit(wait_for_tqdm)
    m.submit(wait_for_tqdm)
    m.submit(wait_for_tqdm)

# Generated at 2022-06-24 10:06:32.776736
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    from ..auto import trange
    from .utils import override_print

    n = 1000

    def worker(i):
        sleep(0.1)
        return i

    with override_print():
        with trange(n) as t:
            m = MonoWorker()
            for i in t:
                m.submit(worker, i)  # pylint: disable=no-value-for-parameter
                t.set_description(str(m.futures))

# Generated at 2022-06-24 10:06:38.672872
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import math
    import pytest
    from concurrent.futures import Future, TimeoutError

    def isprime(n):
        if n < 2:
            return False
        i = 2
        while i <= math.sqrt(n):
            if n % i == 0:
                return False
            i += 1
        return True

    def waitfor(x):
        for _ in tqdm_auto(range(10000), desc=str(x)):
            if x.done():
                return x.result()
            time.sleep(0.0001)
        raise TimeoutError()

    worker = MonoWorker()

    thread1 = worker.submit(isprime, 2**31-1)
    thread2 = worker.submit(isprime, 2**23-1)
    assert waitfor(thread2)



# Generated at 2022-06-24 10:06:46.706180
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from unittest import TestCase, main
    from .utils import time_ns

    class MonoWorkerTest(TestCase):
        def test_non_blocking(self):
            """Test that only 1 thread may be running simultaneously"""
            def func(delay, key):
                sleep(delay)
                return key
            worker = MonoWorker()
            with worker.pool:
                fast = worker.submit(func, 0.1, 'fast')
                fast_ns = time_ns()
                slow = worker.submit(func, 0.5, 'slow')
                slow_ns = time_ns()
                self.assertLess(fast_ns, slow_ns,
                                msg='fast execution scheduled before slow')
                self.assertEqual(slow.result(), 'slow')

# Generated at 2022-06-24 10:06:52.020588
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def func(x):
        time.sleep(x)
        return x
    mw = MonoWorker()
    waiting = mw.submit(func, 1)
    assert waiting.result() == 1
    mw.submit(func, 0.5)
    assert waiting.result() == 1
    waiting = mw.submit(func, 0.25)
    assert waiting.result() == 0.25

# Generated at 2022-06-24 10:06:59.388708
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    If a MonoWorker has only 1 worker, the waiting should always be None.
    """
    import time, unittest

    class Test(unittest.TestCase):
        """
        Unit test for method submit of class MonoWorker
        """
        def test_MonoWorker_submit(self):  # pylint: disable=invalid-name
            """
            testing cases
            """
            worker = MonoWorker()
            calling = worker.submit(time.sleep, 0.1)
            waiting = worker.futures[-1] if worker.futures else None
            self.assertEqual(waiting, None)
            calling.result()
            self.assertTrue(calling.done())

    unittest.main(argv=['first-arg-is-ignored'], exit=False)

# Generated at 2022-06-24 10:07:08.543603
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def test_func():
        pass
    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert mw.pool._max_workers == 1

    mw.submit(test_func)
    assert len(mw.futures) != 0
    assert mw.futures.maxlen == 2
    mw.submit(test_func)
    assert len(mw.futures) != 0
    assert mw.futures.maxlen == 2

# Generated at 2022-06-24 10:07:18.949692
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from subprocess import check_output
    from ..utils import _range

    def command(*args):
        output = check_output('whoami', *args, universal_newlines=True)
        return output.split()[0]

    def func(n):
        time.sleep(n)
        return n

    def test(maxlen):
        with MonoWorker() as mw:
            bar = tqdm_auto(total=maxlen, leave=False,
                            dynamic_ncols=True)
            for i in _range(maxlen):
                mw.submit(func, i/10)
                bar.update()
                time.sleep(.05)

    test(2)
    print(command(['-h']))
    test(3)

# Generated at 2022-06-24 10:07:30.514129
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    def long_running(t):
        sleep(t)
        return t

    mw = MonoWorker()
    f1 = mw.submit(long_running, 1.5)
    sleep(1)

    # only 1.5s task -- not complete, not cancelled
    assert f1.cancel() is False
    assert f1.done() is False

    # push new task -- 1.5s task is cancelled, and new task starts
    f2 = mw.submit(long_running, 1.0)
    sleep(1)
    assert f1.done() is True  # 1.5s task is cancelled
    assert f2.done() is False  # new task is running

    sleep(1)
    assert f2.done() is True  # new task is complete


# Generated at 2022-06-24 10:07:38.725769
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys
    worker = MonoWorker()

    def slow_func():
        time.sleep(2)
        return 2

    def fast_func():
        time.sleep(0.1)
        return 1

    # First submitted future are in progress
    with tqdm_auto.tqdm(
            bar_format="{l_bar}{bar} | {n_fmt}/{total_fmt}",
            total=100,
            file=sys.stdout.buffer) as pbar:
        for i in range(100):
            future = worker.submit(slow_func)
            result = future.result()
            pbar.update()

    # First submitted future are finished

# Generated at 2022-06-24 10:07:41.035232
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Unit test for constructor of class MonoWorker
    """
    mw = MonoWorker()
    assert mw is not None

# Generated at 2022-06-24 10:07:48.765873
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    from .external_write import external_write

    def func(arg, delay):
        external_write("func(" + str(arg) + ") running")
        time.sleep(delay)
        external_write("func(" + str(arg) + ") done")
        return delay

    def test(func, args, wait=None):
        external_write("\nTesting " + func.__name__ + "()...")
        external_write("Calling func with: " + str(args))
        s = MonoWorker()
        result = func(*args)
        external_write("Done (result=" + str(result) + ")")

        if wait is not None:
            external_write("Waiting " + str(wait) + "s...")
            time.sleep(wait)


# Generated at 2022-06-24 10:07:56.983909
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for class MonoWorker"""
    import concurrent.futures

    def fut(*args):
        yield args
        yield 1
        # Test whether 'while True' loops are not broken by yield
        while True:
            yield 2

    def test(future):
        c = iter(future.result)
        assert next(c) == (1,)
        assert next(c) == 1
        assert next(c) == 2
        assert next(c) == 2
        with tqdm_auto.tqdm(desc='Testing MonoWorker class', unit="items") as bar:
            bar.update()

    # generator
    mono = MonoWorker()
    future1 = mono.submit(fut, 1)
    future2 = mono.submit(fut, 2)
    assert future1 == future2

# Generated at 2022-06-24 10:08:05.475458
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures
    import time

    def f(x):
        time.sleep(x)
        return x

    w = MonoWorker()
    w.submit(f, 0.1)
    w.submit(f, 0.2)
    w.submit(f, 0.3)

    tqdm_auto.write('expected: 0.3, 0.2, 0.1')
    tqdm_auto.write('  actual: ' + ', '.join(map(str, [f.result() for f in w.futures])))
    assert [f.result() for f in w.futures] == [0.3, 0.2]

    w.submit(f, 0.1)
    w.submit(f, 0.4)
    w.submit(f, 0.5)

# Generated at 2022-06-24 10:08:09.901895
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    x = mw.submit(f, 2)
    assert not x.done()
    assert mw.submit(f, 1) is x
    assert x.done()
    assert x.result() == 2



# Generated at 2022-06-24 10:08:20.241012
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    from threading import Lock

    from .helpers import ThreadPoolExecutorWithHandlers, with_halt

    @with_halt
    def first_func(lock, delay, results, halt, *args, **kwargs):
        with lock:
            time.sleep(delay)
            results.append("first_func")
            if halt():
                raise RuntimeError("Halting {}".format(kwargs))

    @with_halt
    def second_func(lock, delay, results, halt, *args, **kwargs):
        with lock:
            time.sleep(delay)
            results.append("second_func")
            if halt():
                raise RuntimeError("Halting {}".format(kwargs))

    lock = Lock()
    results = []
    worker = MonoWorker()
    execut

# Generated at 2022-06-24 10:08:28.671323
# Unit test for constructor of class MonoWorker

# Generated at 2022-06-24 10:08:32.439340
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def f(x):
        return x**2
    m = MonoWorker()
    futures = []
    for i in range(10):
        m.submit(f, i)
        futures.append(m.futures[0])
    for f in futures:
        assert f.result() == (i**2)
        i -= 1



# Generated at 2022-06-24 10:08:39.250058
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mp = MonoWorker()
    mp.submit(time.sleep, 0.01)
    assert len(mp.futures) == 1
    mp.submit(time.sleep, 0.01)
    assert len(mp.futures) == 1
    mp.submit(time.sleep, 0.01)  # replace waiting
    assert len(mp.futures) == 1
    mp.submit(time.sleep, 0.01)  # blocks
    assert len(mp.futures) == 2
    mp.submit(time.sleep, 0.01)
    assert len(mp.futures) == 2
    mp.futures[-1].result()

# Generated at 2022-06-24 10:08:44.873651
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .geoip_tests import test_num_ip_samples
    import time

    # Test multiple submissions
    mw = MonoWorker()
    start = time.time()
    ip_counts = []
    for i in range(test_num_ip_samples):
        future = mw.submit(geoip, 'google.com')
        ip_counts.append(future)
    mw.pool.shutdown()
    end = time.time()
    assert sum(ip_counts) == 1  # Single IP counting result
    assert end - start < (test_num_ip_samples * 1.25), "Threaded test too slow (no parallelism?)"
    print("MonoWorker submit() test passed")


# util functions

# Generated at 2022-06-24 10:08:51.978276
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()
    assert not mw.submit(lambda:time.sleep(1)).finished()
    assert mw.submit(lambda:time.sleep(0.1)).done()
    mw.submit(lambda:time.sleep(0.1)).result()
    assert not mw.submit(lambda:time.sleep(1)).finished()
    assert mw.submit(lambda:time.sleep(0.1)).done()
    mw.submit(lambda:time.sleep(0.1)).result()
    for _ in range(4):
        assert mw.submit(lambda:time.sleep(0.1)).done()
        mw.submit(lambda:time.sleep(0.1)).result()

# Generated at 2022-06-24 10:09:00.880395
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def wait_until(t):
        while time.time() <= t:
            pass

    def sleep(t):
        wait_until(time.time() + t)

    def foo(t, msg):
        sleep(t)
        print(msg)

    worker = MonoWorker()
    worker.submit(foo, 1, 'foos')
    worker.submit(foo, 1, 'bars')
    worker.submit(foo, 1, 'foos')
    worker.submit(foo, 1, 'bars')
    worker.submit(foo, 1, 'foos')
    worker.submit(foo, 1, 'bars')
    worker.submit(foo, 1, 'sna')
    sleep(3)

# Generated at 2022-06-24 10:09:02.898249
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from . import ThreadPoolExecutor
    worker = MonoWorker()
    for i in tqdm_auto.tqdm(range(100)):
        future = worker.submit(time.sleep, i)
        future.result()



# Generated at 2022-06-24 10:09:12.268945
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import current_thread
    from concurrent.futures import Future
    from multiprocessing import Process
    from random import Random
    random = Random()
    random.seed(12345)

    def sleeper(duration):
        sleep(duration)
        return duration, current_thread()

    def generate_sleepers(n=110, max_duration=1.1):
        for _ in range(n):
            yield sleeper, random.random() * max_duration

    def test_futures(worker):
        submitted_futures = list(worker.submit(*sleeper_task)
                                 for sleeper_task in generate_sleepers())

        # Check that all but the last task are cancelled
        assert all(future.cancelled() for future in submitted_futures[:-1])

# Generated at 2022-06-24 10:09:22.889385
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from json import dumps
    from time import sleep
    from requests import post

    def post_json(url, data):
        return post(url, data=dumps(data).encode())

    worker = MonoWorker()

    class WorkerWrapper(object):
        def __init__(self, worker, msg):
            self.worker = worker
            self.msg = msg

        def post(self):
            return self.worker.submit(post_json, 'http://httpbin.org/post',
                                      {'msg': self.msg})

    wrapper = WorkerWrapper(worker, 'hello')
    futures = []
    for _ in range(10):
        futures.append(wrapper.post())
        sleep(0.01)
    for f in futures:
        f.result()

# Generated at 2022-06-24 10:09:23.479816
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    pass

# Generated at 2022-06-24 10:09:25.721192
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Test for constructor of class MonoWorker
    """
    test_obj = MonoWorker()
    assert isinstance(test_obj, MonoWorker)


# Generated at 2022-06-24 10:09:38.537719
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import tqdm

    def wait(n):
        for _ in tqdm.tqdm(range(n)):
            time.sleep(0.01)

    worker = MonoWorker()

    future0 = worker.submit(wait, 1000)
    future1 = worker.submit(wait, 1000)
    future2 = worker.submit(wait, 1000)

    assert future0.done() and not future1.done() and not future2.done()

    worker = MonoWorker()
    for i in range(1000):
        worker.submit(wait, 1000)

    assert len(worker.futures) == 2


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:09:45.943053
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from sys import stderr

    def func(*args):
        sleep(6 / args[1])
        return args[0]

    worker = MonoWorker()
    workers = []
    for i in range(2):
        worker.submit(func, i, i + 1)
        worker.submit(func, i + 2, i + 1)
        if len(worker.futures) == worker.futures.maxlen:
            workers.append(worker.futures.popleft())
    for w in workers:
        stderr.write(str(w.result()) + '\n')
    stderr.flush()

# Generated at 2022-06-24 10:09:55.987634
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import Process
    from time import sleep
    
    def f(x):
        sleep(2)
        return x + 1
    
    m = MonoWorker()
    m.submit(f, 1)
    m.submit(f, 2)
    
    # m.submit(f, 3)
    # m.submit(f, 4)
    
    a = m.futures[0].result()
    b = m.futures[1].result()
    assert a == 2
    assert b == 3

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:10:04.160079
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def do_work(input):
        time.sleep(input)
        return 100 / input

    mono = MonoWorker()
    tqdm_auto.write('submitting..')
    mono.submit(do_work, input = 2)
    tqdm_auto.write('submitting..')
    mono.submit(do_work, input = 1)
    tqdm_auto.write('submitting..')
    mono.submit(do_work, input = 3)
    time.sleep(2)
    tqdm_auto.write('submitting..')
    mono.submit(do_work, input = 2.3)
    time.sleep(3)

# Generated at 2022-06-24 10:10:12.201490
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from pytest import fixture
    import time

    def fail():
        raise RuntimeError("fail")

    def sleep(t):
        time.sleep(t)

    @fixture
    def mw():
        return MonoWorker()

    def test_submit_fail(mw):
        """Make sure to not hang with failed tasks"""
        f = mw.submit(fail)
        with tqdm_auto.tqdm(unit='s', dynamic_ncols=True) as t:
            while not f.done():
                t.update()
        assert f.done()
        assert f.cancelled()  # cancelled by worker

    def test_submit_sleep(mw):
        """Make sure to not hang with slow tasks"""
        f = mw.submit(sleep, 0.2)

# Generated at 2022-06-24 10:10:13.798985
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test MonoWorker constructor."""
    MonoWorker()

# Generated at 2022-06-24 10:10:16.515038
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Sanity test for MonoWorker constructor."""
    MonoWorker()
    print('MonoWorker constructor passed sanity test.')

if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:10:23.375992
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import threading
    import time

    def f(x):
        time.sleep(x)
        return x

    m = MonoWorker()
    t = m.submit(f, 2)
    time.sleep(1)
    assert t.running()
    assert t.result() is None
    time.sleep(2)
    assert t.result() == 2
    assert not t.running()

    tqdm_auto.write("Testing that only the latest submitted task is run")
    t = m.submit(f, 1)
    m.submit(f, 2)
    time.sleep(1)
    assert m.futures[0].result() == 2

# Generated at 2022-06-24 10:10:30.215949
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from threading import Thread
    from multiprocessing import Event

    evt = Event()

    def f():
        evt.wait()

    w = MonoWorker()
    w.submit(f)
    w.submit(f)
    w.submit(f)
    w.submit(f)
    w.submit(f)
    w.submit(f)
    w.submit(f)
    w.submit(f)
    w.submit(f)
    w.submit(f)
    evt.set()
    Thread(target=w.submit, args=(f,)).start()
    Thread(target=w.submit, args=(f,)).start()

# Generated at 2022-06-24 10:10:39.970071
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    # tests the case where two jobs are submitted before the first job completes
    def wait_n(n):
        time.sleep(n)
        return n

    mm = MonoWorker()
    r = mm.submit(wait_n, 1)
    assert r.result() == 1
    assert len(mm.futures) == 1
    r = mm.submit(wait_n, 1)
    assert len(mm.futures) == 1
    assert r.result() == 1
    assert len(mm.futures) == 1

    # tests the case where three jobs are submitted before the first job completes
    mm = MonoWorker()
    r = mm.submit(wait_n, 1)
    assert r.result() == 1
    assert len(mm.futures) == 1

# Generated at 2022-06-24 10:10:48.780285
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    # For testing: define a 'print' command to be executed in parallel
    # and that waits for 'wait' seconds, printing 'msg' each second.
    lock = threading.RLock()
    def print_wait(msg, wait):
        for _ in range(wait):
            time.sleep(1)
            lock.acquire()
            print(msg)
            lock.release()

    # For testing: use two delayed print commands.
    # First one (fast) is executed and then a longer one replaces it.
    pool = MonoWorker()
    fast = pool.submit(print_wait, "fast", 3)
    # The fast task is still running.
    slow = pool.submit(print_wait, "slow", 6)
    # The fast task has been canceled.

# Generated at 2022-06-24 10:10:53.467367
# Unit test for constructor of class MonoWorker
def test_MonoWorker():  # OK
    def run_job():
        pass

    with tqdm_auto.tqdm(total=10) as t:
        m = MonoWorker()
        for _ in range(10):
            assert m.submit(run_job)
            t.update()


# Generated at 2022-06-24 10:11:03.676254
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def list_append(i, slist):
        time.sleep(i)
        slist.append(i)

    worker = MonoWorker()

    slist = []
    worker.submit(list_append, 2, slist)
    worker.submit(list_append, 1, slist)
    worker.submit(list_append, 0, slist)
    worker.submit(list_append, 4, slist)
    worker.submit(list_append, 3, slist)

    assert len(worker.futures) == 1

# Generated at 2022-06-24 10:11:14.134015
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    # test function that raises exception after a random amount of time
    def foo():
        time.sleep(0.01 * random.randint(1, 100))
        raise AssertionError("foo raised exception")

    # test function that returns after a random amount of time
    def bar():
        time.sleep(0.01 * random.randint(1, 100))

    # test functions that return a list of numbers after a random amount of time
    def _list(start, end):
        time.sleep(0.01 * random.randint(1, 100))
        return list(range(start, end))

    with MonoWorker() as mw:
        yield mw.submit, None
        yield mw.submit, foo
        yield mw.submit, None
        yield mw.submit, foo


# Generated at 2022-06-24 10:11:15.894808
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test for MonoWorker constructor."""
    def func(x):
        return x + 2
    from time import sleep
    import functools
    functools.reduce(lambda x, y: x.submit(func, y), range(10), MonoWorker())
    sleep(1)

# Generated at 2022-06-24 10:11:16.432814
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Lint
    MonoWorker()

# Generated at 2022-06-24 10:11:20.382141
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from concurrent.futures import TimeoutError
    from threading import Event
    from time import sleep
    from tqdm import trange

    def noop():
        sleep(1)
        return 42

    def foo():
        sleep(1)
        raise NotImplementedError

    mw = M

# Generated at 2022-06-24 10:11:26.945391
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(x):
        time.sleep(x)
        return x

    # test 0-len wait queue
    w = MonoWorker()
    assert not w.futures
    # submit 1 func
    assert 63 == w.submit(f, 63).result()
    assert not w.futures
    # submit 2 funcs
    assert 63 == w.submit(f, 63).result()
    assert 127 == w.submit(f, 127).result()
    assert not w.futures

    # test 1-len wait queue
    w = MonoWorker()
    assert 63 == w.submit(f, 63).result()
    assert not w.futures
    # submit 1 func (replaces waiting)
    assert 127 == w.submit(f, 127).result()
    assert not w.fut

# Generated at 2022-06-24 10:11:30.083475
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    mw = MonoWorker()
    assert len(mw.futures) == 0
    for _ in range(4):
        sleep(0.2)
        mw.submit(lambda: sleep(0.5))

    for _ in range(4):
        sleep(0.2)
        mw.submit(lambda: sleep(2))
    sleep(0.5)
    assert len(mw.futures) == 1

# Generated at 2022-06-24 10:11:39.424656
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, time
    from random import random
    from threading import Thread
    from multiprocessing import cpu_count

    try:
        import pytest
    except ImportError:
        raise ImportError('Please run tests using "py.test"')

    def test_func(f, delay=1, cpu_mult=0.8):
        x = 0
        while x < f:
            x += random()
            sleep(random() * 0.01)
        sleep(delay)
        return x

    def test_submit(mw):
        sleep(mw.futures.maxlen)
        assert mw.futures.maxlen == 2
        assert len(mw.futures) == 2


# Generated at 2022-06-24 10:11:40.494355
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()


# Generated at 2022-06-24 10:11:49.942202
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def _log(x):
        """logging function"""
        tqdm_auto.write('  Running "{}"'.format(x))
        return x

    def _sleep(x):
        """sleep function"""
        import time
        tqdm_auto.write('  Sleeping "{}"'.format(x))
        time.sleep(1)
        return x

    with tqdm_auto.tqdm() as pbar:
        pbar.desc = 'Outer'
        with MonoWorker() as monoworker:
            pbar.set_description('Warmup')
            future = monoworker.submit(_log, 42)
            pbar.set_description('Running')
            pbar.write('\nResult: {}'.format(future.result()))
            pbar.set_description('Cooling down')

# Generated at 2022-06-24 10:12:00.098102
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import multiprocessing as mp
    import time
    import random

    def wait(delay):
        time.sleep(delay)
        return delay

    def seq(n, wait=0):
        for i in range(n):
            if wait:
                wait(wait)
            yield i

    def print_seq(s):
        while True:
            i = s.__next__()
            tqdm_auto.write("%s: %r" % (mp.current_process().name, i))

    # Single Threaded
    single_proc = mp.Process(target=print_seq, args=(seq(10, 1),))
    single_proc.start()
    single_proc.join()

    # Multiple Threaded
    nprocs = 4