

# Generated at 2022-06-24 10:01:54.434268
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import randrange

    def task1(i):
        from time import sleep
        sleep(.01)
        return i

    def task2(i):
        from time import sleep
        sleep(.02)
        return i

    def test_case(task, n_runs, n_cores):
        durations = []
        mono_worker = MonoWorker()
        for i in range(n_runs):
            duration = mono_worker.submit(task, i)
            durations.append(duration)
        assert n_cores == sum(1 for _ in durations)

    test_case(task1, 10, 1)
    test_case(task1, 10, 2)
    test_case(task2, 10, 1)
    test_case(task2, 10, 2)

# Generated at 2022-06-24 10:02:03.750758
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def sleeper(sleep_t):
        time.sleep(sleep_t)
        return sleep_t

    mw = MonoWorker()
    f1 = mw.submit(sleeper, 1)
    assert f1.result() == 1
    f2 = mw.submit(sleeper, 2)
    assert f2.done()
    assert f2.cancelled()
    f3 = mw.submit(sleeper, 3)
    f3.result()
    f4 = mw.submit(sleeper, 4)
    f4.result()
    f5 = mw.submit(sleeper, 5)
    assert f5.done()
    assert f5.cancelled()

# Generated at 2022-06-24 10:02:16.810711
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test method MonoWorker.submit."""

    import time

    def task(a):
        time.sleep(a)
        return 42 // a  # ZeroDivisionError

    m = MonoWorker()
    assert not m.futures
    m.submit(task, 0.1)
    assert len(m.futures) == 1
    t = m.submit(task, 100)
    assert len(m.futures) == 1
    assert t.done()
    assert t.result() == task(100)
    time.sleep(0.1)
    assert len(m.futures) == 1
    assert m.futures[0].done()
    assert m.futures[0].result() == task(0.1)
    t = m.submit(task, 0)

# Generated at 2022-06-24 10:02:21.922513
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures as futures
    import os
    import shutil
    import tempfile
    import time
    import unittest
    import warnings
    from ..auto import tqdm as tqdm_auto

    mw = MonoWorker()
    tmpd = tempfile.mkdtemp()

# Generated at 2022-06-24 10:02:30.821668
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint

    def run():
        sleep(randint(1, 4))
        return randint(1, 10)

    worker = MonoWorker()

    # f1
    f1 = worker.submit(run)
    assert isinstance(f1, type(worker.submit(run)))

    # f2
    f2 = worker.submit(run)
    assert isinstance(f2, type(worker.submit(run)))

    # f1 and f2
    try:
        assert f1.result() != f2.result()
    except Exception as e:
        tqdm_auto.write(str(e))

    # f3
    f3 = worker.submit(run, _suppress_exception=True)

# Generated at 2022-06-24 10:02:33.736539
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    mw = MonoWorker()
    assert mw.submit(sleep, 2).done() is True
    assert mw.submit(sleep, 2).done() is False
    assert mw.submit(sleep, 2).done() is True

# Generated at 2022-06-24 10:02:41.581357
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test"""
    import time
    import tqdm
    mw = MonoWorker()

    def _f(x):
        """Function to be submitted"""
        time.sleep(0.1)
        return x

    def _g(x):
        """Function to be submitted"""
        time.sleep(0.2)
        return x

    def _h(x):
        """Function to be submitted"""
        time.sleep(0.3)
        return x

    # Populate with 1 long job and 2 short jobs
    mw.submit(_f, (1,))
    mw.submit(_g, (2,))
    mw.submit(_h, (3,))

    # Start progress bar
    desc = 'TEST'

# Generated at 2022-06-24 10:02:54.131531
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import TimeoutError
    import time

    def task(i, delay=0):
        from six.moves import range
        for _ in range(10):
            time.sleep(delay)
            tqdm_auto.write("task %d" % i)
        return i

    tqdm_auto.write("submitting task 0")
    mw = MonoWorker()
    f0 = mw.submit(task, 0)
    tqdm_auto.write("submitting task 1")
    f1 = mw.submit(task, 1, 1)
    tqdm_auto.write("submitting task 2")
    f2 = mw.submit(task, 2, 2)
    tqdm_auto.write("submitting task 3")

# Generated at 2022-06-24 10:03:01.836979
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..manual import trange
    from ..utils import _supports_unicode

    def process_line(line, **kwargs):
        sleep(0.1)
        return line

    def process_sleep(time):
        sleep(time)

    def test_func():
        worker = MonoWorker()
        process_line_kwargs = dict(miniters=1, mininterval=0.1, desc='multi')
        for line in trange(5, desc='multi', miniters=1, mininterval=0.1):
            worker.submit(process_line, line, **process_line_kwargs)
            process_sleep(0.12)
        worker.submit(process_sleep, 0.15)
        worker.submit(process_sleep, 0.2)
    test

# Generated at 2022-06-24 10:03:10.649840
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import Pool
    import time

    import pytest

    class Logger(object):
        def __init__(self, max_len=2):
            self.data = deque(maxlen=max_len)

        def start(self, name, wait=0.1):
            print("{} start".format(name))
            time.sleep(wait)
            print("{} done".format(name))
            self.data.append(name)

        def get(self):
            return list(self.data)

    logger = Logger()
    mono = MonoWorker()

    def func1():
        logger.start('func1')

    def func2():
        logger.start('func2')

    def func3():
        logger.start('func3')


# Generated at 2022-06-24 10:03:19.965321
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Thread
    from time import sleep
    from .format_meter import RawTextMeter as Meter
    from .utils import write, reflush

    class MockedTqdm(object):
        def write(self, *args, **kwargs):
            pass

        def reflush(self):
            pass

    def func1(x, y, z, tqdm=None, sleep_time=0.2):
        with Meter(tqdm=tqdm) as m:
            m.write('test1', end=' ', reflush=reflush)
            sleep(sleep_time)
            m.write('done')

    def func2(x, y, z, tqdm=None, sleep_time=0.1):
        with Meter(tqdm=tqdm) as m:
            m

# Generated at 2022-06-24 10:03:29.036989
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """test_MonoWorker_submit"""
    from time import sleep
    from nose.tools import assert_equal, assert_true

    mw = MonoWorker()

    def test_func(n, sleep_sec=None):
        if sleep_sec:
            sleep(sleep_sec)
        return n

    f1 = mw.submit(test_func, 1, sleep_sec=0.5)
    assert_equal(mw.futures[-1].result(), 1)

    f2 = mw.submit(test_func, 2)
    assert_equal(mw.futures[-1].result(), 2)

    f3 = mw.submit(test_func, 4, sleep_sec=0.5)
    assert_true(f1.done())
    # assert_false(f1.

# Generated at 2022-06-24 10:03:36.312154
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def fake_work(x):
        sleep(0.1)
        return x

    mw = MonoWorker()

    # Submit 4 jobs and make sure only 3 get executed in order
    fs = []
    for i in range(5):
        fs.append(mw.submit(fake_work, i))

    assert fs[-1].result() == 4
    assert len(fs) - fs[0].done() == 1

# Generated at 2022-06-24 10:03:45.236093
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from .async_ import SerialWorker

    def sleep_for(time_in_seconds):
        time.sleep(time_in_seconds)
        return time_in_seconds

    def sleep_for_and_return_args(*args, **kwargs):
        time_in_seconds = args[1] if len(args) > 1 else kwargs['time_in_seconds']
        time.sleep(time_in_seconds)
        return args, kwargs

    worker = MonoWorker()
    # make sure we can submit things while they are still running
    assert worker.submit(sleep_for, time_in_seconds=0.2).result() == 0.2
    assert worker.submit(sleep_for, time_in_seconds=0.1).result() == 0.1

# Generated at 2022-06-24 10:03:52.544304
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    worker = MonoWorker()

    def sleeping(job, sec):
        sleep(sec)
        return job

    def print_result(future):
        return tqdm_auto.write(
            "Task {}; time taken {:.4f} seconds".format(
                future.result(), future.running_time()))

    for i in range(10):
        future = worker.submit(sleeping, i, 0.5)
        future.add_done_callback(print_result)

# Generated at 2022-06-24 10:04:02.876382
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> worker = MonoWorker()
    >>> running = worker.submit(tqdm_auto.sleep, 1)
    >>> waiting = worker.submit(tqdm_auto.sleep, 2)
    >>> running.result()
    >>> waiting.result()
    >>> waiting = worker.submit(tqdm_auto.sleep, 2)
    >>> running.result()
    >>> waiting.result()
    >>> running.result()
    Traceback (most recent call last):
      ...
    concurrent.futures.CancelledError
    >>> waiting.result()
    Traceback (most recent call last):
      ...
    concurrent.futures.CancelledError
    >>> worker.submit(tqdm_auto.sleep, 1)
    >>> worker.submit(tqdm_auto.sleep, 2)
    """
   

# Generated at 2022-06-24 10:04:10.535437
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():  # pragma: no cover
    import time

    mw = MonoWorker()
    count = 0
    tqdm_auto.write('Submitting tasks.')
    def func(i):
        nonlocal count
        count += 1
        time.sleep(10 / (i + 1))
        return count

    tqdm_auto.write('Submitting fast task.')
    f1 = mw.submit(func, 1)
    assert f1.done()
    tqdm_auto.write('Submitting slow task.')
    f2 = mw.submit(func, 10)
    assert f2.done()
    tqdm_auto.write('Submitting slow task.')
    f3 = mw.submit(func, 100)
    assert f3.done()


# Generated at 2022-06-24 10:04:17.193259
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import format_sizeof
    from ..utils import format_interval

    format_sizeof = lambda x: format_sizeof(x, suffix="B")
    files = [
        "../__init__.py",
        "../auto.py",
        "../bar.py",
        "../cli.py",
        "../main.py"]

    def get_file_size(filename):
        """Reads entire file, returning byte-size"""
        with open(filename, "rb") as f:
            data = f.read()
        return len(data)

    mw = MonoWorker()
    t = time.time()

# Generated at 2022-06-24 10:04:21.554640
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from six.moves import xrange
    import time

    for _dummy in xrange(4):
        with MonoWorker() as worker:
            for i in xrange(2):  # 2 tasks at a time
                worker.submit(time.sleep, .1)
        time.sleep(.3)  # wait for *all* threads to complete

# Generated at 2022-06-24 10:04:30.924437
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import concurrent.futures
    import time

    class Something(object):
        def __init__(self):
            self.val = 1
            self.max_val = 100000

        def __call__(self):
            self.val = 1
            t = tqdm_auto.tqdm(total=0, leave=False)
            self.worker = MonoWorker()

        def add(self):
            def _add(prev=self.val):
                time.sleep(.1)
                new_val = prev + 1
                if new_val < self.max_val:
                    self.worker.submit(self.add)
                    # self.worker.add(self.add)
                return new_val

            self.val = self.worker.submit(_add).result()
            # self.val = self.worker

# Generated at 2022-06-24 10:04:40.767385
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from queue import Queue

    def get_fid(this, i):
        return this.futures[i]

    def get_index(this, future):
        for i, f in enumerate(this.futures):
            if f is future:
                return i
        return None

    m = MonoWorker()
    queue = Queue()
    queues = []
    for i in range(3):
        def func():
            queue.get()  # block until queue.put()
            return i

        futures = m.submit(func)
        queues.append(queue)
        assert queue.empty()
        assert get_fid(m, 0) is futures
        assert len(m.futures) == 1
        assert get_index(m, futures) == 0


# Generated at 2022-06-24 10:04:49.611326
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import unittest

    def slow_inc(x, duration=0.05):
        """slow inc, used as func to be submitted to MonoWorker"""
        time.sleep(duration * random.random())
        return x + 1

    class TestMonoWorker(unittest.TestCase):
        """Testing for MonoWorker"""
        def setUp(self):
            """Setup for unittest.TestCase"""
            self.worker = MonoWorker()

        def test_submit(self):
            """MonoWorker.submit() test"""
            tqdm_auto.write('Testing MonoWorker.submit()')
            x = 0
            n = 10

# Generated at 2022-06-24 10:04:59.735440
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker."""
    import time

    def counter(n):
        """ Countdown from n to -1 """
        for i in reversed(range(n)):
            tqdm_auto.write('waiting {}'.format(i))
            time.sleep(1)
        tqdm_auto.write('done')
        return n

    mw = MonoWorker()
    res1 = mw.submit(counter, 2)

    time.sleep(0.1)

    res2 = mw.submit(counter, 3)

    time.sleep(1)
    res3 = mw.submit(counter, 1)

    time.sleep(2)
    print(res1.result())
    print(res2.result())
    print(res3.result())



# Generated at 2022-06-24 10:05:04.811675
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import wait as waitall

    def printer(*a, **kw):
        print(a, kw)

    mw = MonoWorker()

    a1 = mw.submit(printer, "1")
    a2 = mw.submit(printer, "2")
    sleep(0.1)
    assert a1.running()
    assert not a1.done()
    assert a2.done()
    assert a2.cancelled()

    a3 = mw.submit(printer, "3")
    assert not a3.done()
    assert len(mw.futures) == 1

    waitall([a1, a3])

# Generated at 2022-06-24 10:05:09.101180
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    with MonoWorker() as worker:
        waiting = worker.submit(time.sleep, 2)
        running = worker.submit(time.sleep, 2)
        assert len(worker.futures) == 1
        running.cancel()
        assert len(worker.futures) == 1
    assert waiting.done()
    assert running.cancelled()

# Generated at 2022-06-24 10:05:12.418827
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Tests the constructor of MonoWorker.
    """
    # Test with a normal argument
    a = MonoWorker()
    assert isinstance(a.pool, ThreadPoolExecutor)
    assert isinstance(a.futures, deque)


# Generated at 2022-06-24 10:05:22.405563
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from threading import Lock

    def worker(n, lock):
        with lock:
            return n

    lock = Lock()
    mw = MonoWorker()

    # Test input: worker with no args
    mw.submit(lock.acquire)
    assert len(mw.futures) == 1

    # Test input: worker with args and kwargs (n=1)
    result = mw.submit(worker, 1, lock)
    assert len(mw.futures) == 1
    assert result.result() == 1

    result = mw.submit(worker, 2, lock)
    assert len(mw.futures) == 1
    assert result.result() == 2

    assert len(mw.futures) == 0

# Generated at 2022-06-24 10:05:28.401220
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mono_worker = MonoWorker()
    waiting = mono_worker.submit(time.sleep, 1)
    assert not waiting.done()
    mono_worker.submit(time.sleep, 0.2)  # waiting is cleared
    waiting.result()  # wait until running finishes
    assert waiting.done()

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:05:38.617408
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Tests the method `submit` of the class `MonoWorker`."""
    # pylint: disable=protected-access
    from time import sleep
    from threading import Thread
    from multiprocessing import Event

    def do(n, event):
        """Simulate a slow thread that notifies an external event."""
        sleep(n)
        event.set()

    mw = MonoWorker()
    e1 = Event()
    e2 = Event()
    e3 = Event()
    assert not e1.is_set()
    assert not e2.is_set()
    assert not e3.is_set()

    assert mw.submit(do, 0.3, e1)
    assert mw.submit(do, 0.5, e2)

# Generated at 2022-06-24 10:05:47.894388
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    max_workers = 5
    max_futures = 3
    max_tasks = 5
    def func(t):
        time.sleep(t)
    worker =  MonoWorker()
    assert max_workers == worker.pool._max_workers
    assert len(worker.futures) == 0
    assert max_futures == worker.futures.maxlen
    # submit tasks
    last_task = 0
    for i in range(max_tasks):
        assert len(worker.futures) == min(i, max_futures)
        worker.submit(func, i)
        assert len(worker.futures) == min(i+1, max_futures)
        last_task = i
    # check result
    assert last_task == worker.futures

# Generated at 2022-06-24 10:06:00.110892
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def side_effect(*args, **kwargs):
        return '{} {}'.format(args, kwargs)
    def dummy(*args, **kwargs):
        return ''
    from unittest.mock import patch
    from time import sleep
    with patch('multiprocessing.pool.ThreadPool.apply_async', side_effect=side_effect):
        mw = MonoWorker()
        running = mw.submit(dummy)
        sleep(0.05)
        assert running.done()
        waiting = mw.submit(dummy, 1, 2, kw1=3, kw2=4)
        sleep(0.05)
        assert not running.done()  # running is not cancelled
        assert waiting.done()
        assert running.result() == ''

# Generated at 2022-06-24 10:06:08.742571
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # pylint: disable=too-many-locals
    import threading
    import time

    def func(i, s):
        time.sleep(s)
        return i

    n = 10
    mw = MonoWorker()
    assert len(mw.futures) == 0
    futures = []
    r = dict()
    lock = threading.Lock()
    for i in range(n):
        futures.append(mw.submit(func, i, .01))
        assert len(mw.futures) == 1
    for i in range(n):
        futures.append(mw.submit(func, i, .1))
        assert len(mw.futures) == 1
    for i in range(n - 1):
        t = futures.pop(0)
        assert len

# Generated at 2022-06-24 10:06:15.573915
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import warnings
    import os
    from .utils import dummy_context_mgr

    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    n_exec = 3
    period = 0.1
    n_sleep = 1

    def _worker(idx):
        time.sleep(n_sleep)
        return "done " + str(idx)

    def _worker_slow(idx):
        time.sleep(n_sleep + 0.1)
        return "done " + str(idx)

    mw = MonoWorker()
    msgs_io = StringIO()

# Generated at 2022-06-24 10:06:22.523260
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from sys import version_info as ver
    from .tqdm_test_utils import with_setup, pretest, posttest
    from .ti_test_utils import FakeTqdmFile, get_line_count, tqdm_iterable
    from . import _range  # NOQA
    from .bytes_counter import bytes_counter
    from .ascii import bar_thermometer, bar_ascii, percentage

    with_setup(pretest, posttest)

    mw = MonoWorker()

    assert get_line_count() == 0
    bytes_counter().start(0)
    mw.submit(tqdm_iterable, _range(100), desc="one")
    sleep(0.01)
    assert get_line_count() == 0

    assert get_line_

# Generated at 2022-06-24 10:06:32.995186
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import sys
    import queue

    if sys.version_info < (3, 2):
        return

    N = 10
    ran = random.Random()
    ran.seed(0)
    mw = MonoWorker()
    tqdm_auto.write("Starting MonoWorker tests")
    q = queue.Queue()

    # noinspection PyUnusedLocal
    def func(n):
        time.sleep(10 * ran.random())
        for _ in tqdm_auto.trange(n, desc='foo bar'):
            time.sleep(ran.random())

    # noinspection PyUnusedLocal
    def producer():
        while True:
            mw.submit(func, 100)

    def consumer():
        while True:
            res = q.get()

# Generated at 2022-06-24 10:06:38.581489
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def wait(i, seconds):
        time.sleep(seconds)
        return i

    mw = MonoWorker()

    assert mw.submit(wait, 0, 1).result() == 0
    assert mw.submit(wait, 1, 1).result() == 1
    assert mw.submit(wait, 2, 1).result() == 2
    assert mw.submit(wait, 3, 3)

    assert mw.submit(wait, 4, 2).result() == 4
    assert mw.submit(wait, 5, 1).result() == 5
    assert mw.submit(wait, 6, 2).result() == 6
    assert mw.submit(wait, 7, 3)

    assert mw.submit(wait, 8, 1).result() == 8

# Generated at 2022-06-24 10:06:46.629104
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test MonoWorker::submit method."""
    from ..auto import tqdm
    from time import sleep
    from traceback import format_exc

    def test_f():
        sleep(5)
        return 42

    def test_error():
        sleep(5)
        1 / 0
        return 666

    tqdm.write("\nFirst task (will take 5 seconds)")
    mw = MonoWorker()
    t = mw.submit(test_f)

    while not t.done():
        tqdm.write("\nSecond task (will be discarded)")
        t2 = mw.submit(test_error)

    tqdm.write("\nGot result: {0}".format(t.result()))

    tqdm.write("\nThird task (will take 5 seconds)")


# Generated at 2022-06-24 10:06:51.346697
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def wait(x):
        sleep(x)
        return x

    mw = MonoWorker()
    assert mw.submit(wait, 5)
    assert mw.submit(wait, 3)
    assert mw.submit(wait, 5)
    sleep(6)
    assert mw.submit(wait, 3)

# Generated at 2022-06-24 10:07:01.312942
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import subprocess
    import threading
    import time
    import random

    ip = tqdm_auto.trange(3)
    worker = MonoWorker()
    # print(list(worker.pool._threads))
    assert not list(worker.pool._threads)
    for i in ip:
        worker.submit(time.sleep, 0.5)
    worker.submit(time.sleep, 0.1)
    worker.submit(time.sleep, 0.2)
    assert not list(worker.pool._threads)
    for i in ip:
        worker.submit(time.sleep, 0.5)
    assert not list(worker.pool._threads)
    for i in ip:
        worker.submit(time.sleep, 0.5)

# Generated at 2022-06-24 10:07:09.490312
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    l = []
    def add_to_list(l, n):
        """Fake computation"""
        time.sleep(0.25)
        l.append(n)
        return l

    mw = MonoWorker()
    for i in range(9):
        mw.submit(add_to_list, l, i)

    # The last submitted task should be the only one running
    time.sleep(0.05)
    assert len(l) == 1
    # and the one waiting
    time.sleep(0.10)
    assert len(l) == 2
    # and the one that was running before
    time.sleep(0.10)
    assert len(l) == 3
    # but not the next one
    time.sleep(0.10)
    assert len(l) == 3


# Generated at 2022-06-24 10:07:18.185101
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, sys

    def sample_func(sleep_delay):
        time.sleep(sleep_delay)

    n = 10

    sys.stderr.write('MonoWorker\n')
    sys.stderr.flush()
    with tqdm_auto.tqdm(total=n) as pbar:
        mono_worker = MonoWorker()
        for i in range(n):
            mono_worker.submit(sample_func, sleep_delay=1.0)
            pbar.update(1)
        mono_worker.submit(sample_func, sleep_delay=1.0)
        pbar.update(1)

# Generated at 2022-06-24 10:07:28.390737
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from tqdm import tqdm

    mw = MonoWorker()

    def worker(tm, s):
        sleep(tm)
        tqdm.write(s)

    def submit(i, tm):
        mw.submit(worker, i, tm)

    for i in tqdm(range(3), leave=False):
        submit(i, 0.1)
    sleep(0.1)
    submit(0.5, 0.5)
    # ... 0.5 runs
    sleep(0.1)
    submit(0.0, 0)
    # ... 0.5 is replaced by 0
    sleep(0.5)
    submit(0.8, 0.8)
    submit(0.9, 0.9)
    # ... 0.8 is replaced by

# Generated at 2022-06-24 10:07:29.985008
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .tests import test_MonoWorker_submit
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:07:31.352598
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.futures == deque()



# Generated at 2022-06-24 10:07:41.914977
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import queue
    import threading

    def _thread(stop_event, queue):
        while not stop_event.is_set():
            stop_event.wait(0.1)
            queue.put(threading.current_thread().name)

    stop_event = threading.Event()
    queue = queue.Queue(10)
    threads = []
    for i in range(10):
        threads.append(threading.Thread(
            name=str(i), target=_thread, args=(stop_event, queue)))
        threads[-1].start()
    worker = MonoWorker()

    for i in range(100):
        worker.submit(_thread, stop_event, queue)
        time.sleep(0.1)

    stop_event.set()

# Generated at 2022-06-24 10:07:49.449533
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from threading import Utilization
    import time

    # call MonoWorker constructor
    worker = MonoWorker()

    # submit a non-blocking function to the worker
    worker.submit(Utilization, 0.01)

    # wait before testing the worker
    time.sleep(0.1)

    # test if MonoWorker is working
    if len(worker.futures) != 0:
        print ("MonoWorker test passed!")
    else:
        print ("MonoWorker test failed!")

# Generated at 2022-06-24 10:08:00.114873
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import unittest

    # Suppress printouts
    class LogCap(object):
        def __enter__(self):
            self.stdout = tqdm_auto.tqdm.write
            tqdm_auto.tqdm.write = lambda *a, **k: None
        def __exit__(self, *args):
            tqdm_auto.tqdm.write = self.stdout

    def wait(duration, *args, **kwargs):
        """Dummy function that waits `duration` seconds then returns."""
        time.sleep(duration)
        return (args, kwargs)

    class TestMonoWorker(unittest.TestCase):
        """Test class for method submit of class MonoWorker."""

# Generated at 2022-06-24 10:08:07.303784
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class `MonoWorker`."""
    m = MonoWorker()
    # first tqdm call
    m.submit(tqdm_auto.write, "hello 0")
    # first tqdm call
    m.submit(tqdm_auto.write, "hello 1")
    # first tqdm call
    m.submit(tqdm_auto.write, "hello 2")

# Generated at 2022-06-24 10:08:15.751271
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from timeit import default_timer as timer

    def run(x, duration=0.01):
        time.sleep(duration)
        return x * 2

    mw = MonoWorker()
    N = range(10)
    assert len(mw.futures) == 0
    for i in N:
        mw.submit(run, i, 0.01)
    assert len(mw.futures) == 1
    for i in reversed(N):
        mw.submit(run, i, 0.01)
    assert len(mw.futures) == 1

    def submit_plus_2(duration=0.01):
        t_start = timer()
        mw.submit(run, 2, duration)
        t_elapsed = timer() - t_

# Generated at 2022-06-24 10:08:24.654007
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from pprint import pprint
    from . import tqdm_function
    from . import tqdm_class

    def do_nothing(x):
        sleep(random())
        return x

    tqdm_auto.ncols = 90
    mw = MonoWorker()
    T = tqdm_class.tqdm(
        total=20, leave=False,
        bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{remaining}, {rate_fmt}{postfix}]",
        position=0)
    T.set_description("MonoWorker test")
    mw.submit(do_nothing, 0)  # warm-up (initialise)
    for i in T:
        res

# Generated at 2022-06-24 10:08:31.533540
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from operator import add
    from ..utils import format_sizeof

    def _worker(x, y):
        sleep(1)
        return add(x, y)

    mw = MonoWorker()
    for i, j, k in [(1, 2, 3), (4, 5, 6), (7, 8, 9)]:
        tqdm_auto.write('{} {} {}'.format(i, j, k))
        if i == 1:
            f_i_j = mw.submit(_worker, i, j)
            f_i_k = mw.submit(_worker, i, k)
            f_j_k = mw.submit(_worker, j, k)
            assert f_i_j.result() == 3
            assert f_i_k.result() == 4

# Generated at 2022-06-24 10:08:38.806027
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    #pylint: disable=missing-docstring
    import time

    worker = MonoWorker()
    assert (len([t for t in worker.futures if not t.done()]) == 0)
    # Submit 2 tasks
    task1 = worker.submit(time.sleep, 0.1)
    task2 = worker.submit(time.sleep, 0.1)
    # Check there is only 1 pending task
    assert (len([t for t in worker.futures if not t.done()]) == 1)
    time.sleep(0.2)
    # Check the second task is cancelled
    assert (task2.cancelled())
    # Check the first task is finished
    assert (task1.done())

# Generated at 2022-06-24 10:08:40.227542
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw=MonoWorker()

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:08:43.511536
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def run(x):
        return x + 1
    mw = MonoWorker()
    mw.submit(run, 6)
    mw.submit(run, 6)
    mw.submit(run, 6)
    assert mw.futures.popleft().result() == 7
    assert len(mw.futures) == 0

# Generated at 2022-06-24 10:08:52.258125
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def wait(d):
        """Simulate a slow task."""
        time.sleep(d)
        return d
    m = MonoWorker()
    # Submit slow tasks
    [m.submit(wait, d) for d in [.1, .2, .3]]
    # Check that the slowest task (the one taking .3s) is running
    assert len(m.futures) == 1
    assert m.futures[0].running()
    assert m.futures[0].result() == .3
    # Submit a fast task
    m.submit(wait, 0)
    # Check that the fast task has replaced the slow task (discarding it)
    assert len(m.futures) == 1
    assert m.futures[0].done()
    assert m.fut

# Generated at 2022-06-24 10:09:01.723525
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import CancelledError
    from threading import Lock
    from functools import partial

    def make_futures(num_workers=2, runner_time=3, waiter_time=5,
                     delay=0.1, verbose=True):
        def job(jobs_done, jobs_left, lock, wait_time, verbose):
            if verbose:
                tqdm_auto.write("Starting job, {} to go".format(jobs_left))
            time.sleep(wait_time)
            with lock:
                jobs_done.append("done")
                if verbose:
                    tqdm_auto.write("Job finished, {} to go".format(jobs_left))

        # Setup
        locks = [Lock() for _ in range(num_workers)]
        jobs_

# Generated at 2022-06-24 10:09:02.404757
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    MonoWorker()



# Generated at 2022-06-24 10:09:12.017692
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import unittest

    unittest.TestCase.setUp = lambda _: None
    unittest.TestCase.tearDown = lambda _: None

    class TestMonoWorker(unittest.TestCase):
        def test_submit(self):
            """Check that we do not invoke several workers"""
            # Only if not already running in a subprocess (doctest)
            if sys.argv[0].endswith("_doctest"):
                return
            def func(i):
                time.sleep(0.05)
                return i + 1
            with MonoWorker() as mono_worker:
                monos = [mono_worker.submit(func, i) for i in range(20)]
            self.assertEqual(len(monos), 20)
           

# Generated at 2022-06-24 10:09:23.047981
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from collections import defaultdict
    from time import sleep
    from unittest import TestCase
    import random

    def task(i):
        sleep(i)
        return i

    class TestMonoWorker(TestCase):
        def test(self):
            w = MonoWorker()
            d = defaultdict(lambda: None)
            N = 10000
            l = range(1, N)
            random.shuffle(l)
            for i in l:
                d[i] = w.submit(task, i)
            expected_keys = set(l)
            actual_keys = set(d)
            self.assertEqual(expected_keys, actual_keys)
            for i in l:
                self.assertEqual(i, d[i].result())
    t = TestMonoWorker()

# Generated at 2022-06-24 10:09:31.239610
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    from six.moves import range as xrange

    def func(delay, pos):
        time.sleep(delay)
        print('.' * pos)

    total = 6
    worker = MonoWorker()
    tasks = []
    for i in xrange(total):
        tasks.append(worker.submit(func, random.random() / 2, i + 1).result)
    for i, task in enumerate(tasks):
        task()
        time.sleep(0.5)
        print('-' * (i + 1))
        if i < total - 1:
            tasks[i + 1].cancel()



# Generated at 2022-06-24 10:09:41.610278
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures as futures

    mono = MonoWorker()

    def f_t(wait):
        time.sleep(wait)
        return "t"

    def f_a(wait, *args):
        time.sleep(wait)
        return "a"

    def f_b(wait, *args):
        time.sleep(wait)
        return "b"


# Generated at 2022-06-24 10:09:49.460729
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from nose.tools import assert_equal

    mw = MonoWorker()
    counter = [0]
    lock = Lock()
    fut1 = mw.submit(lambda: sleep(1) or counter.pop() and counter.append(1))
    fut2 = mw.submit(lambda: sleep(1) or counter.pop() and counter.append(2))
    fut3 = mw.submit(lambda: sleep(1) or counter.pop() and counter.append(3))
    lock.acquire()

# Generated at 2022-06-24 10:09:59.132329
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from six.moves import _thread
    from threading import Lock
    from time import sleep
    from datetime import datetime
    from tqdm.auto import trange

    def display_threads(p):
        for t in _thread._active.values():
            tqdm_auto.write("%s: %s" % (p, t.name))

    def test_func(i):
        sleep(1)
        display_threads("test_func")
        return i

    # Test successful thread submission
    print("\n(%s) Test successful thread submission" %
          (datetime.now().time().isoformat()[:-3],))
    mw = MonoWorker()

    display_threads("Main")

# Generated at 2022-06-24 10:10:08.321807
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from concurrent.futures import Future
    from unittest import TestCase, TextTestRunner, TestLoader

    class MonoWorkerTest(TestCase):
        def test_submit(self):
            mw = MonoWorker()
           
            self.assertEqual(len(mw.futures), 0)
            
            def f1():
                time.sleep(2)
                return 10

            def f2():
                time.sleep(2)
                return 20

            def f3():
                time.sleep(2)
                return 30

            def f4():
                time.sleep(2)
                return 40

            # submit new task, it's the running task
            future1 = mw.submit(f1)

# Generated at 2022-06-24 10:10:18.677289
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    def zero_or_one(n):
        """For testing MonoWorker.submit."""
        if n == 0:
            return 0
        else:
            return 1 / 0

    try:
        zero_or_one = test_MonoWorker_submit.zero_or_one
    except AttributeError:
        pass
    monow = MonoWorker()
    assert monow.submit(zero_or_one, 0).result() == 0

    try:
        monow.submit(zero_or_one, 1)
    except ZeroDivisionError:  # check for error
        pass
    assert monow.submit(zero_or_one, 0).result() == 0

    assert monow.pool._work_queue.qsize() == 0
    assert len(monow.futures) == 1
    assert monow

# Generated at 2022-06-24 10:10:19.785511
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()


# Generated at 2022-06-24 10:10:28.826313
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from random import random
    from threading import current_thread
    from ..utils import _range

    def foo(i):
        sleep(random())
        tqdm_auto.write('%s %i' % (current_thread(), i))

    # Test correct number of threads
    assert MonoWorker().pool._max_workers == 1

    # Test MAXLEN=2
    worker = MonoWorker()
    worker.submit(foo, 0)
    worker.submit(foo, 1)
    worker.submit(foo, 2)
    sleep(0.1)  # wait for threads to finish

    # Test that all jobs were executed
    assert all(future.done() for future in worker.futures)

    # Test that jobs are processed in right order

# Generated at 2022-06-24 10:10:36.849222
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import time
    # pylint: disable=missing-docstring

    def ctime_i(i):  # try this under different conditions
        time.sleep(0.2)
        return (i, time.ctime())

    tqdm_auto.write("start")
    mw = MonoWorker()
    fs = [mw.submit(ctime_i, i) for i in range(10)]
    tqdm_auto.write("requested: " + str([f.result() for f in fs]))

# Generated at 2022-06-24 10:10:46.483480
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from itertools import count

    def test(x):
        sleep(x + random())
        return x

    # Submit two tasks in sequence with 3 seconds lag
    w = MonoWorker()
    f0 = w.submit(test, 2)
    sleep(3)
    f1 = w.submit(test, 4)

    # Check that f0 has been cancelled
    assert f0.cancelled()

    # Check that f1 is currently executed
    assert f1.running()

    # Check that f1 will return 4
    assert f1.result() == 4

    # Submit several tasks in parallel
    f0 = w.submit(test, 0.1)
    f1 = w.submit(test, 0.2)

# Generated at 2022-06-24 10:10:54.411095
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def func(*args, **kwargs):
        time.sleep(1)

    mw = MonoWorker()
    mw.submit(func)
    mw.submit(func)  # Should get discarded
    mw.submit(func)  # Should get discarded
    mw.submit(func)  # Should get run
    time.sleep(2)


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:10:55.421087
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    obj = MonoWorker()
    for i in range(2):
        assert len(obj.futures) == i


# Generated at 2022-06-24 10:11:00.450678
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from collections import deque
    from multiprocessing import Process, Value
    from time import sleep
    from . import MonoWorker

    def put_slow(out, item, sleep_duration):
        sleep(sleep_duration)
        out.append(item)

    def append_slow(items, sleep_duration):
        out = []
        for item in items:
            worker.submit(put_slow, out, item, sleep_duration)
        worker.submit(lambda: out)
        return out

    for items in [[1, 2, 3], ['a', 'b', 'c']]:
        for sleep_duration in [0, 0.1, 1, 2]:
            for maxlen in [2, 3, 10]:
                out = []
                worker = MonoWorker()


# Generated at 2022-06-24 10:11:08.306691
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import Future  # type: ignore

    def run(future, i, sleep_time):
        sleep(sleep_time)
        future.set_result(i)

    def func(n, sleep_time):
        future = Future()  # type: ignore
        worker.submit(run, future, n, sleep_time)
        return future

    worker = MonoWorker()

    # f1 = func(1, 3)
    # f2 = func(2, 1)
    # assert f1._state == RUNNING
    # assert f2._state == CANCELLED
    # assert f1.result() == 1

    f3 = func(3, 1)
    f4 = func(4, 1)
    f5 = func(5, 1)
    f6 = func

# Generated at 2022-06-24 10:11:12.430301
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    fut = MonoWorker()
    fut.submit(lambda : 1)
    fut.submit(lambda : 1)
    fut.submit(lambda : 1)
    fut.submit(lambda : 1)
    fut.submit(lambda : 1)
    fut.submit(lambda : 1)
    fut.submit(lambda : 1)

# Generated at 2022-06-24 10:11:14.916640
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Tests MonoWorker constructor only"""
    mw = MonoWorker()
    return mw is not None


# Generated at 2022-06-24 10:11:15.947237
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from . import test_MonoWorker_submit
    test_MonoWorker_submit.test_MonoWorker_submit()

# Generated at 2022-06-24 10:11:19.612941
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    import threading

    def func(event):
        event.wait()

    event = threading.Event()

    mono_worker = MonoWorker()
    mono_worker.submit(func, event)
    event.set()

# Generated at 2022-06-24 10:11:26.879152
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def fn_raises_an_error():
        raise RuntimeError()

    def fn_with_return(return_value):
        time.sleep(1)
        return return_value

    def fn_with_side_effect(sleep=0, raise_=None):
        time.sleep(sleep)
        if raise_ is not None:
            raise raise_
        return None

    t = MonoWorker()
    t.submit(fn_raises_an_error)
    assert len(t.futures) == 1
    t.submit(fn_raises_an_error)
    t.submit(fn_raises_an_error)
    assert len(t.futures) == 1
    t.submit(fn_with_return, 1)

# Generated at 2022-06-24 10:11:37.523708
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import concurrent.futures

    def sleep(t):
        time.sleep(t)
        return t

    def fail(t):
        raise Exception('failing {0}'.format(t))

    with MonoWorker() as e:
        t = e.submit(sleep, 0.1)
        assert t.result() == 0.1

        t = e.submit(fail, 0.2)
        with tqdm_auto.external_write_mode():
            with tqdm_auto.disable_instance():
                with tqdm_auto.std_out_err_redirect_tqdm():
                    try:
                        t.result()
                    except concurrent.futures.CancelledError:
                        pass
                    else:
                        raise Exception('t.result() should have thrown')
                    assert t

# Generated at 2022-06-24 10:11:41.288687
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():  # pragma: no cover
    @MonoWorker.submit
    def f(x):
        print("Started {}".format(x))
        import time
        time.sleep(1.0)
        print("Finished {}".format(x))
        return x

    print(f(0))
    print(f(1))
    print(f(2))

if __name__ == "__main__":  # pragma: no cover
    # Run tests
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:11:50.025082
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def sleeper(arg, outq):
        time.sleep(arg)
        outq.append(arg)
        return arg

    from multiprocessing import Queue
    outq = Queue()  # list

    mw = MonoWorker()

    def print_outq():
        try:
            print(outq.get(timeout=0.1))
        except Exception:
            time.sleep(0.1)
            return False

    print_outq()
    assert not print_outq()

    mw.submit(sleeper, 1, outq)
    assert print_outq()
    mw.submit(sleeper, 2, outq)
    assert print_outq()
    mw.submit(sleeper, 3, outq)
    assert print_outq()