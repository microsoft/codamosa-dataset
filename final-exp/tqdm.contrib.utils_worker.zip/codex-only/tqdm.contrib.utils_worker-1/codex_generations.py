

# Generated at 2022-06-24 10:01:55.656236
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    mw = MonoWorker()
    def test_func(x):
        sleep(x)
        return x
    for i in range(4):
        mw.submit(test_func, i)
        for j in mw.futures:
            assert (i == j.result())
    sleep(0.5)
    assert (mw.futures[0].result() == 3)
    return mw

# Generated at 2022-06-24 10:01:57.732642
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert len(worker.futures) == 0


# Generated at 2022-06-24 10:02:03.752690
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def f1():
        time.sleep(1)
        return 'f1'

    def f2():
        time.sleep(2)
        return 'f2'

    def f3():
        time.sleep(3)
        return 'f3'

    mw = MonoWorker()
    mw.submit(f1)
    mw.submit(f2)
    mw.submit(f3)
    assert mw.futures.popleft().result() == 'f3'

# Generated at 2022-06-24 10:02:16.822931
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test `MonoWorker(1).submit`"""
    import pytest
    import time
    import sys
    if sys.version_info < (3, 2):
        pytest.skip("unittest requires unit test `unittest.mock.patch`")

    # noinspection PyUnresolvedReferences
    from unittest.mock import patch
    a = []

    def f():
        time.sleep(0)  # force to be scheduled as a new task
        with patch('tqdm.tqdm.write') as tqdm_write:
            a.append('f')
            raise ValueError

    def g():
        time.sleep(0)
        a.append('g')

    with MonoWorker() as mw:
        f1 = mw.submit(f)

# Generated at 2022-06-24 10:02:27.140021
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    # Setup
    from .misc import test_in_terminal
    test_in_terminal()

    def timeout(interval, value):
        time.sleep(interval)
        return value

    def len_len_futures(worker):
        return len(worker.futures), len(worker.pool._work_queue)

    worker = MonoWorker()
    assert len_len_futures(worker) == (0, 0)

    # Test submit
    for i in range(4):
        result = worker.submit(timeout, 0.05, i)
        assert result.result() == i

    # Test submit with delays on method timeout
    result = worker.submit(timeout, 0.2, 4)
    assert len_len_futures(worker) == (2, 1)
    time

# Generated at 2022-06-24 10:02:35.603627
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from threading import Event
    from time import sleep

    def wait_for_and_set_event(proc, *events):
        proc.event.wait()
        proc.event.clear()
        for event in events:
            event.set()

    def wait_for_events(events):
        for event in events:
            event.wait()
            event.clear()

    def start_proc(proc, *events):
        proc.event.set()
        wait_for_events(events)
        return proc.data

    class TestProcess(object):
        def __init__(self, data, *events):
            self.data = data
            self.event = Event()
            self.events = events
        def start(self):
            self.data = wait_for_and_set_event(self, *self.events)

# Generated at 2022-06-24 10:02:42.640031
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=too-many-locals,too-many-statements
    from time import sleep
    import threading
    from concurrent.futures import Future

    def task_succeed_after_seconds(seconds):
        sleep(seconds)
        return seconds

    def task_fail_after_seconds(seconds):
        sleep(seconds)
        raise ValueError("I failed after {} seconds.".format(seconds))

    def task_cancel_after_seconds(seconds):
        sleep(seconds)
        raise Future.cancelled()

    def test_task_after_seconds(task_func, seconds, arg_tuple):
        worker = MonoWorker()
        fut = worker.submit(task_func, seconds)
        assert isinstance(fut, Future)
        assert not fut.done()

# Generated at 2022-06-24 10:02:47.983300
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from nose.tools import assert_equal

    n = 5

    def func(*args):
        time.sleep(2 * n)
        return args

    mw = MonoWorker()

    # parallel runs
    last = mw.submit(func, 'last')
    first = mw.submit(func, 'first')

    assert_equal(last.cancel(), True)
    assert_equal(first.cancel(), False)
    assert_equal(last.result(), None)
    assert_equal(first.result(), 'first')

    # sequential runs
    for i in range(n):
        mw.submit(func, i)
    assert_equal(mw.futures[0].result(), n - 1)

# Generated at 2022-06-24 10:02:58.305447
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures._base import Future

    def func(num):
        time.sleep(0.5)
        return num

    mw = MonoWorker()
    res = mw.submit(func, 1)
    assert res.done()
    assert res.result() == 1

    res = mw.submit(func, 2)
    assert not res.done()  # blocks

    assert mw.futures[0] == res
    assert isinstance(mw.futures[0], Future)

    assert mw.futures[0].result() == 2
    assert len(mw.futures) == 1

    res = mw.submit(func, 3)
    assert res.done()
    assert res.result() == 2  # previous task was cancelled

    assert mw

# Generated at 2022-06-24 10:03:02.414866
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .tests import _test_MonoWorker_submit
    return _test_MonoWorker_submit(MonoWorker)

# Generated at 2022-06-24 10:03:05.811504
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert not worker.futures

# Generated at 2022-06-24 10:03:09.832939
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    def f(x):
        sleep(x)
        return x

    mono = MonoWorker()
    assert mono.submit(f, 0.5).result() == 0.5
    assert mono.submit(f, 0.25).result() == 0.25
    assert mono.submit(f, 0.5).result() == 0.5
    assert mono.submit(f, 0.25).result() == 0.25


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 10:03:12.248487
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    async_func = lambda : 1
    async_call = MonoWorker().submit(async_func)
    assert async_call.done()
    assert async_call.result() == 1

# Generated at 2022-06-24 10:03:16.825635
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def wait_by(seconds):
        import time
        time.sleep(seconds)


    worker = MonoWorker()
    worker.submit(wait_by, 1)
    worker.submit(wait_by, 2)
    worker.submit(wait_by, 3)


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:03:25.431776
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys

    a = MonoWorker()
    for i in tqdm_auto.tqdm(range(5), desc='total'):
        time.sleep(0.1)
        assert len(a.futures) < 2
        assert a.submit(sys.stdout.write, 'abc')
        assert len(a.futures) == 1
    assert len(a.futures)

    b = MonoWorker()
    for i in tqdm_auto.tqdm(range(10), desc='total'):
        time.sleep(0.1)
        assert len(b.futures) < 2
        assert b.submit(sys.stdout.write, 'abc')
        assert len(b.futures) < 3
        assert len(b.futures)

# Generated at 2022-06-24 10:03:27.380332
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Due to complications of Python's threading module, there's
    # no automatic way to test this module
    pass

# Generated at 2022-06-24 10:03:31.942935
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import threading
    import time

    def wait_a_sec(arg):
        time.sleep(1)
        return arg

    t = MonoWorker()
    result = None
    for i in range(0, 4):
        # print "submitting %s" % i
        result = t.submit(wait_a_sec, i)

    assert result is not None
    assert result.result() == 3


if __name__ == '__main__':  # pragma: no cover
    test_MonoWorker()

# Generated at 2022-06-24 10:03:33.973232
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from .utils import close_all
    from collections import deque

    mw = MonoWorker()
    deque([], maxlen=1).maxlen
    mw.submit(sleep, 0.2)
    mw.submit(sleep, 0.1)
    mw.submit(sleep, 0.3)
    close_all(mw.futures)

# Generated at 2022-06-24 10:03:36.500992
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # test with empty
    assert MonoWorker()
    return


if __name__ == '__main__':
    test_MonoWorker()
    print('Tests Successful')
    pass

# Generated at 2022-06-24 10:03:39.470319
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time


    def wait(n):
        time.sleep(n)
        return n


    m = MonoWorker()
    f = m.submit(wait, 0.1)
    time.sleep(0.2)
    assert f.done()



# Generated at 2022-06-24 10:03:40.457179
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()

# Generated at 2022-06-24 10:03:42.750108
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker.futures.maxlen == 2
    assert len(worker.futures) == 0

# Generated at 2022-06-24 10:03:54.561942
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from multiprocessing import current_process, Process, Value
    from threading import Lock
    from multiprocessing.pool import ThreadPool
    from ..utils import _range

    def func(sleep_time, i, j, lock, counter, total):
        with tqdm_auto.tqdm(total=total, unit_scale=True,
                            desc=str(current_process().name),
                            ncols=80) as t:
            sleep(sleep_time / 2)
            t.update(1)
            if lock:
                lock.acquire()
            counter.value += 1
            if lock:
                lock.release()
            sleep(sleep_time / 2)
            t.update(1)


# Generated at 2022-06-24 10:04:03.683774
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """TODO: run tests on travis"""
    import time
    from ..utils import _range

    class DummyException(Exception):
        pass

    mw = MonoWorker()

    # test 1
    def sleep_print(i, wait):
        time.sleep(wait)
        tqdm_auto.write('{0} waited {1}'.format(i, wait))
    for i in _range(3):
        mw.submit(sleep_print, i, 1)
        time.sleep(0.5)
    time.sleep(2)

    # test 2
    mw = MonoWorker()
    for i in _range(3):
        mw.submit(sleep_print, i, 1)
        time.sleep(3)
    time.sleep(2)

    # test 3
    m

# Generated at 2022-06-24 10:04:11.354684
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def w_new_future(worker, **kwargs):
        future = worker.submit(lambda: None, **kwargs)
        assert future is not None
        return future
    def test_w_new_future(worker, **kwargs):
        future = w_new_future(worker, **kwargs)
        assert future.done()
        return future
    worker = MonoWorker()
    assert list(worker.futures) == []
    assert w_new_future(worker)
    assert w_new_future(worker, foo='bar')
    futures = worker.futures

    assert list(futures) == []
    assert len(futures) == 0
    assert test_w_new_future(worker)
    assert len(futures) == 1
    old_future = test_w_new_

# Generated at 2022-06-24 10:04:22.381448
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test MonoWorker.submit"""
    import time
    from multiprocessing import Value

    # Ensure threadpool has stopped
    assert not _MonoWorker_stop.value.value
    _MonoWorker_stop.value.value = 1

    mw = MonoWorker()
    assert mw.pool.submit(lambda: time.sleep(1)).result(0.01) is None
    assert not mw.futures[0].done()
    assert mw.submit(lambda: time.sleep(1)).result(0.01) is None
    assert mw.futures[0].done()
    assert len(mw.futures) == 1
    assert mw.pool.submit(lambda: time.sleep(1)).result(0.01) is None

# Generated at 2022-06-24 10:04:27.880962
# Unit test for constructor of class MonoWorker
def test_MonoWorker():

    def func(*args, **kwargs):
        return args, kwargs

    mw = MonoWorker()
    for args in range(5):
        mw.submit(func, args)

    assert len(mw.futures) == 1
    assert mw.futures[0].done()
    assert mw.futures[0].result() == ((4,), {})

# Generated at 2022-06-24 10:04:32.722841
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert len(worker.futures) == 0


# Generated at 2022-06-24 10:04:41.639243
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    import pytest

    from .utils import TestException

    def target(n):
        sleep(2)
        return 10 / n

    @pytest.fixture(scope="module")
    def mono_worker():
        return MonoWorker()

    def test_mono_worker_submit(mono_worker):
        # Ensure that current job is replaced
        mono_worker.submit(target, 2)
        mono_worker.submit(target, 0)
        with pytest.raises(ZeroDivisionError):
            mono_worker.futures[0].result()

# Generated at 2022-06-24 10:04:50.527974
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Simulate the following execution:
    #
    # submit(3)
    # submit(1)
    # submit(2)
    # -> run 1, then run 2, then run 3
    import time
    import random
    def slow_print(val):
        time.sleep(val)
        print(val)
    # Asynchronous execution
    mono = MonoWorker()
    mono.submit(slow_print, 3)
    mono.submit(slow_print, 1)
    mono.submit(slow_print, 2)
    # Synchronous execution
    for val in [3, 1, 2]:
        time.sleep(val)
        print(val)
    # Compare
    assert [1, 2, 3] == sorted(map(int, open("test.log", "r").readlines()))
    import os


# Generated at 2022-06-24 10:05:00.423972
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time

    def echo(s):
        time.sleep(1)  # pretend that some work was done
        return s

    def run(worker):
        t1 = threading.Thread(target=worker.submit, args=(echo, 'foo'))
        t2 = threading.Thread(target=worker.submit, args=(echo, 'bar'))
        t1.start()
        time.sleep(0.1)
        t2.start()
        t1.join()
        t2.join()
        return worker

    mw = MonoWorker()
    mw = run(mw)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 'bar'

    # Same test as above, but with a different order
    m

# Generated at 2022-06-24 10:05:02.006394
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()
    assert m.futures.maxlen == 2
    assert m.pool._max_workers == 1


# Generated at 2022-06-24 10:05:13.899143
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from os import getpid
    from multiprocessing import Process
    from time import sleep
    from threading import Lock, Thread
    from multiprocessing.dummy import Pool as ThreadPool
    import pytest
    import concurrent.futures

    # monkey-patch threading.Lock.release to auto-acquire lock
    ModLock = Lock

    class Lock(ModLock):
        """Mock threading.Lock with dummy implementation"""
        _acquired = False

        def acquire(self, blocking=True, timeout=None):
            """Mock `Lock.acquire`"""
            assert not timeout, 'Deadlocks are undefined for mock Lock'
            if not blocking:
                return self._acquired
            while not self._acquired:
                sleep(0.001)
            return True


# Generated at 2022-06-24 10:05:15.048159
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()

# Generated at 2022-06-24 10:05:26.294369
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def b(x):
        """`b` is slow"""
        time.sleep(0.5)
        return x

    def f():
        """`f` is fast"""
        return 0

    t = MonoWorker()
    print("submitting slow tasks...")
    for i in range(2):
        t.submit(b, i)
        print("  submitted: `b({})`".format(i))
    print("submitting fast task...")
    t.submit(f)
    print("  submitted: `f()`")
    time.sleep(0.25)
    print("submitting slow task...")
    t.submit(b, 42)
    print("  submitted: `b(42)`")
    time.sleep(2)
    print("done")

# Generated at 2022-06-24 10:05:35.966963
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def sleep_then_return(i, x=None):
        from time import sleep
        sleep(i)
        return i, x

    mono = MonoWorker()
    task1 = mono.submit(sleep_then_return, 2, x=1)
    task2 = mono.submit(sleep_then_return, 0.5, x=2)
    task3 = mono.submit(sleep_then_return, 2, x=3)
    assert task1.done()
    assert task2.done()
    assert not task3.done()
    task4 = mono.submit(sleep_then_return, 0.1, x=4)
    assert not task4.done()
    assert task4.result(timeout=.2) == (0.1, 4)
    assert task4.done()



# Generated at 2022-06-24 10:05:44.891175
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import tqdm.contrib

    def done():
        pass

    def func(test_queue, test_results, *args, **kwargs):
        if test_queue is not test_results:
            test_results.append("MonoWorker.submit: queue mismatch")
        time.sleep(0.1)
        if test_results is not test_queue:
            test_results.append("MonoWorker.submit: results mismatch")
        test_results.append("MonoWorker.submit: success")

    test_queue = tqdm.contrib.MonoWorker()
    test_results = []
    test_queue.submit(func, test_queue, test_results, "arg1", "arg2")
    test_results.append("MonoWorker.submit: sync")
    test_

# Generated at 2022-06-24 10:05:54.354829
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from contextlib import contextmanager
    from time import sleep

    @contextmanager
    def timer(name):
        """Provides a timer for the using context."""
        start = time.time()
        yield
        tqdm_auto.write('{}: {}s'.format(name, time.time() - start))

    import time
    import threading

    def my_func(name, sleep_time=0.5):
        with timer(name):
            time.sleep(sleep_time)
            return name

    def test():
        tqdm_auto.write('Testing MonoWorker')
        mw = MonoWorker()
        tqdm_auto.write('Submitting tasks:')
        f1 = mw.submit(my_func, 'A', 0.1)

# Generated at 2022-06-24 10:05:59.339866
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    # pylint: disable=no-member
    worker = MonoWorker()
    assert worker.pool.__class__.__name__ == 'ThreadPoolExecutor'
    assert worker.futures.maxlen == 2
    assert len(worker.futures) == 0


# Generated at 2022-06-24 10:06:08.140182
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from .tqdm_contrib_test import tqdm_kwargs

    mono = MonoWorker()
    sleep_time = 0.01
    # There are 4 cases of sending the first function
    # and 6 cases of sending the second function,
    # so 24 cases in total.
    # Each case is tested 3 times.
    for _ in tqdm_auto.tqdm(range(3), desc="Case", **tqdm_kwargs):
        for send_first_now in [True, False]:
            for send_second_now in [True, False]:
                # Clear the deque first
                mono.futures.clear()
                # Send the first func
                if send_first_now:
                    func1 = lambda: sleep(sleep_time)

# Generated at 2022-06-24 10:06:11.534684
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()

    assert m.pool.__str__() == "<ThreadPoolExecutor(ThreadPoolExecutor-0, max_workers=1)>"
    assert m.futures.__str__() == "deque([], maxlen=2)"

# Testing for submit of class MonoWorker

# Generated at 2022-06-24 10:06:18.255146
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import os
    import random

    def launch_job(delay):
        import time
        tqdm_auto.write('Starting job #{} with delay: {}'.format(
            job_counter, delay))
        time.sleep(delay)
        tqdm_auto.write('Finished job #{} with delay: {}'.format(
            job_counter, delay))
        return os.getpid(), job_counter, delay

    worker = MonoWorker()
    for job_counter in range(5):
        job = worker.submit(launch_job, random.randint(1, 5))
        if job_counter == 3:
            job.cancel()

# Generated at 2022-06-24 10:06:25.618585
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Semaphore

    def test_wait(n, sema):
        """
        :param n: int
        :param sema: Semaphore
        :return: int
        """
        sema.release()
        time.sleep(n)
        return n

    sema = Semaphore(0)
    worker = MonoWorker()
    assert not worker.submit(test_wait, 1, sema).done()
    assert sema.acquire(timeout=2)
    assert worker.submit(test_wait, 2, sema).done()
    assert worker.submit(test_wait, 2, sema).done()

# Generated at 2022-06-24 10:06:33.622009
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    class Utils:
        def __init__(self):
            self.test_counter = 0

        def test_func(self, x):
            self.test_counter += x

    test_utils = Utils()

    def test_process(x, test_utils=test_utils):
        test_utils.test_func(x)

    mw = MonoWorker()

    mw.submit(test_process, 1)
    mw.submit(test_process, 2)
    mw.submit(test_process, 2)
    assert test_utils.test_counter == 3

    mw.submit(test_process, 1)
    mw.submit(test_process, 1)
    assert test_utils.test_counter == 5

# Generated at 2022-06-24 10:06:43.815918
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import multiprocessing
    from time import sleep
    from random import random
    from tqdm import trange

    def slow_square(tq, x):
        for _ in trange(x, desc=str(x) + '²', leave=False,
                        unit='it', total=x, initial=0, miniters=1, mininterval=0.1):
            sleep(random() / 100.)
        return x ** 2

    # Constructor of class MonoWorker
    num_cpus = multiprocessing.cpu_count()
    num_futures = 3
    mw = MonoWorker()
    _futs = []
    for _ in range(num_futures):
        _fut = mw.submit(slow_square, i)
        _futs.append(_fut)


# Generated at 2022-06-24 10:06:53.395845
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> test_MonoWorker_submit()
    True
    """
    import time
    from contextlib import closing

    def print_2sec(txt):
        time.sleep(2)
        print(txt)

    with closing(MonoWorker()) as mw:
        # Submit the first long-running task
        task = mw.submit(print_2sec, 'Once upon...')
        # Submit a second task that should not run
        mw.submit(print_2sec, 'There was a little girl...')
        task.result()
        # Submit a third task that should run immediately
        task = mw.submit(print_2sec, 'The End')
        task.result()
        return True

# Generated at 2022-06-24 10:06:54.437504
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:07:04.607104
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:07:14.620235
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import random
    import time
    def delay_func(x, random_delay=False):
        if random_delay:
            time.sleep(random.random())
        return x
    mw = MonoWorker()
    for i in range(2):
        mw.submit(delay_func, i, random_delay=True)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 1
    for i in range(2, 4):
        mw.submit(delay_func, i)
    results = [f.result() for f in [mw.futures[0], mw.futures[1]]]
    assert results == [2, 3]

# Generated at 2022-06-24 10:07:18.644703
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .test import test_MonoWorker_submit

    test_MonoWorker_submit()
    from ._version import get_versions
    __version__ = get_versions()['version']
    del get_versions

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:07:22.475435
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mo = MonoWorker()
    assert mo.pool.shutdown == False
    assert mo.futures.maxlen == 2

# Generated at 2022-06-24 10:07:29.981663
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint

    def g():
        sleep(randint(1, 3))
        return randint(0, 1)

    worker = MonoWorker()
    for _ in range(10):
        worker.submit(g)
    futures = list(worker.futures)
    assert len(futures) == 2
    sleep(1)
    futures = list(worker.futures)
    assert len(futures) == 1
    assert futures[0].done()
    assert futures[0].result() == 1

# Generated at 2022-06-24 10:07:37.347070
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from .write import DummyTqdmFile
    w = MonoWorker()

    def callback(i, out=DummyTqdmFile()):
        """Test callback"""
        if i > 40:
            time.sleep(2)
        out.write('progress: {}\n'.format(i))
        return i**2

    # Test with restarts and waiting
    for i in tqdm_auto.trange(100, desc='TEST'):
        waiting = w.submit(callback, i)
        while not waiting.done():
            waiting.result()
            time.sleep(0.01)


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:07:49.023790
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def foo(a, b):
        return a + b
    mono = MonoWorker()
    assert len(mono.futures) == 0
    assert mono.submit(foo, 1, 2)
    assert len(mono.futures) == 1
    assert mono.submit(foo, 2, b=1).result() == 3
    assert len(mono.futures) == 1
    assert mono.submit(foo, 3, b=2).result() == 5
    assert len(mono.futures) == 1
    assert mono.submit(foo, 4, b=3)
    assert len(mono.futures) == 1
    assert mono.submit(foo, 5, b=4).result() == 9
    assert len(mono.futures) == 1

# Generated at 2022-06-24 10:07:57.126606
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import wait
    from time import sleep
    from copy import copy

    # Test basic setup
    import warnings
    warnings.filterwarnings("ignore", category=ResourceWarning)  # concurrent.futures
    w = MonoWorker()
    assert w.pool._work_queue.qsize() == 0
    assert w.pool._threads == set()

    # Test basic submission
    import multiprocessing as mp
    mp_lock = mp.Lock()
    mp_var = mp.Value('i', 5)
    fut_inc = w.submit(mp_var.value.__iadd__, 1)
    fut_dec = w.submit(mp_var.value.__isub__, 1)
    assert len(w.futures) == 2
    assert w.pool._work_queue.q

# Generated at 2022-06-24 10:08:05.544477
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .tqdm import tnrange, tqdm

    # Define test functions
    def f(x):
        sleep(1)
        return x

    def g(x, y=None):
        sleep(1)
        return x, y

    # Initialize MonoWorker
    mw = MonoWorker()

    # One task running, one waiting
    for i in tnrange(2, desc="1st run"):
        mw.submit(f, i)

    # Both tasks running
    for i in tnrange(2, desc="2nd run"):
        mw.submit(g, i, "a")

    # One task running, one task waiting, one discarded

# Generated at 2022-06-24 10:08:11.814953
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def sleeper(t):
        import time
        time.sleep(t)
        return t

    mw = MonoWorker()
    f1 = mw.submit(sleeper, 1)
    f2 = mw.submit(sleeper, 2)
    assert f1 == f2
    assert not f1.done()
    assert f1.result() == 2
    assert f1.done()
    assert f2.done()

if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:08:21.667709
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .test_utils import import_
    from .test_utils import slow_func

    tqdm = import_('tqdm', min_version='4.4.0')
    tqdm.write = tqdm_auto.write

    class report(object):  # noqa: N801
        test_file = open(__file__, "r")
        fn = 'tqdm_tqdm.tqdm_contrib_test_utils'
        func = 'slow_func'
        n = 20
        desc = "Testing {}.{}(n={})".format(fn, func, n)
        tqdm_instance = tqdm(total=n, desc=desc)

    worker = MonoWorker()

# Generated at 2022-06-24 10:08:34.123437
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures
    from .threadpool_executor_patched import _patched_ThreadPoolExecutor
    from ..utils import _term_move_up
    tqdm_auto.write = \
        lambda s, file=None, end="\n", nolock=False, **kw: print(s, **kw)

    def worker(item, sleep):
        time.sleep(sleep)
        print(item)

    # running, cancel waiting
    with _patched_ThreadPoolExecutor(_patched_ThreadPoolExecutor):
        mw = MonoWorker()
        mw.submit(worker, 'a', 1)  # running
        mw.submit(worker, 'b', 0)  # cancel
        assert len(mw.futures) == 1

# Generated at 2022-06-24 10:08:35.621454
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    m = MonoWorker()

# Generated at 2022-06-24 10:08:42.701316
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import os
    import random
    import string

    def long_running_task():
        time.sleep(2)
        return ''.join(random.choice("ABCDEFGH") for i in range(10))

    def fast_task():
        return ''.join(random.choice("IJKLMNOP") for i in range(10))

    pool = MonoWorker()
    for i in range(0, 10):
        if random.choice([False, True]):
            pool.submit(fast_task)
        else:
            pool.submit(long_running_task)

        time.sleep(1)
        os.system("clear")
        for e in pool.futures:
            print(e.result())

# Generated at 2022-06-24 10:08:48.814267
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from concurrent.futures import CancelledError
    mw = MonoWorker()
    tqdm_auto.write('start')
    for i in range(2):
        mw.submit(time.sleep, 0.5)
        mw.submit(time.sleep, 0.5)
    tqdm_auto.write('middle')
    for i in range(2):
        mw.submit(time.sleep, 0.5)
        mw.submit(time.sleep, 0.5)
    tqdm_auto.write('end')
    mw.submit(time.sleep, 2)

# Generated at 2022-06-24 10:08:51.628305
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mono_worker = MonoWorker()
    print(mono_worker)

# A simple test for method submit of class MonoWorker

# Generated at 2022-06-24 10:09:01.221480
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ._async_doc_examples import async_doc_examples
    from ._async_doc_examples import get_doc_examples

    def func(text):
        # noinspection PyShadowingNames
        def func(text):
            return text.count(" ")

        return tqdm_auto.tqdm(func(text), len(text))

    with get_doc_examples() as docs:
        with tqdm_auto.tqdm(docs, unit='docs', miniters=1) as doc_t:
            worker = MonoWorker()
            for doc in async_doc_examples(docs):
                worker.submit(doc_t.update, func(doc))


# Generated at 2022-06-24 10:09:06.520034
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    # Return immediately
    assert mw.submit(time.sleep, 0).done()
    # Replace still running task
    assert not mw.submit(time.sleep, 0.1).done()
    assert not mw.submit(time.sleep, 0.1).done()
    # Replace waiting task
    assert not mw.submit(time.sleep, 0.1).done()
    time.sleep(0.1)
    assert not mw.submit(time.sleep, 0).done()
    # Still running task?
    assert not mw.submit(time.sleep, 0.1).done()
    time.sleep(0.1)
    assert mw.futures[0].done()
    assert mw.futures[1].done()

# Generated at 2022-06-24 10:09:10.042099
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    class UnitTest(MonoWorker):
        """"""
        pass
    ut = UnitTest()
    assert ut.pool.__class__.__name__ == 'ThreadPoolExecutor'
    assert ut.futures.maxlen == 2
    assert len(ut.futures) == 0



# Generated at 2022-06-24 10:09:10.755294
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # TODO
    pass



# Generated at 2022-06-24 10:09:21.746662
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import multiprocessing
    import numpy as np
    from tqdm.contrib import MonoWorker
    from concurrent.futures import ThreadPoolExecutor

    def run_task(n, x_init, delay=None):
        x = x_init
        with tqdm(total=n, desc='running') as pbar:
            for _ in range(n):
                x = 0.9 * x + 0.1
                pbar.update()
                if delay:
                    time.sleep(delay)
        return x

    def run_task_cancelled(n, x_init, delay=None):
        x = x_init
        with tqdm(total=n, desc='running(cancelled)') as pbar:
            for _ in range(n):
                x = 0.

# Generated at 2022-06-24 10:09:29.838185
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from ._utils import check_state
    from time import sleep
    import os

    if os.name == 'nt':
        sleep_time = 0.5
    else:
        sleep_time = 0.05

    def wait_for_future(f):
        """
        Wait until f is no longer pending.

        :param f: an instance of Future
        :return: None
        """
        from _thread import interrupt_main
        from concurrent.futures import CancelledError

        try:
            f.result()
        except CancelledError:
            pass
        except Exception as e:
            interrupt_main()
            raise e


# Generated at 2022-06-24 10:09:40.604200
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import numpy as np
    from numpy.random import choice

    def heavy_compute(i, sleep=None):
        time.sleep(sleep if sleep else np.random.random() / 2)  # 0.5
        return i

    def heavy_compute_fut(i, sleep=None):
        pass

    def heavy_compute_gen(n):
        for i in range(n):
            yield heavy_compute(i)

    mw = MonoWorker()

    assert len(mw.futures) == 0

    # Submit in order
    mw.submit(heavy_compute, 0, 0.0)
    assert len(mw.futures) == 1
    mw.submit(heavy_compute, 1, 0.2)
    assert len

# Generated at 2022-06-24 10:09:51.541033
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, random
    import concurrent.futures
    import threading
    import nose.tools as nt
    from unittest import TestCase

    random.seed(42)
    ###########################################################################
    ## MonoWorker tests
    ###########################################################################
    def run_tests(test_func, tests):
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(tests)) \
                as pool:
            def f(args):
                test_func(*args)
            for args in tests:
                pool.submit(f, args)

    def test_MonoWorker_submit_args(i, f, *args):
        nt.assert_equal(f(*args), i)

    def test_MonoWorker_submit_order(i, f, *args):
        nt

# Generated at 2022-06-24 10:10:01.448601
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def running():
        time.sleep(0.5)
        return "running"

    def waiting():
        time.sleep(0.5)
        return "waiting"

    def waiting_failure():
        time.sleep(0.5)
        raise Exception("Failure")

    mw = MonoWorker()

    # test waiting
    assert len(mw.futures) == 0
    fr = mw.submit(running)
    assert len(mw.futures) == 1
    fw = mw.submit(waiting)
    assert len(mw.futures) == 2
    assert fw.cancel()
    assert fr.result() == "running"
    assert len(mw.futures) == 0

    # test waiting failure

# Generated at 2022-06-24 10:10:09.161588
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Note: '%s' is not thread-safe, use %i instead
    from time import sleep

    def blah(i):
        sleep(0.01)
        return i
    mw = MonoWorker()
    with tqdm_auto.tqdm(desc="Running", total=1) as pbar:
        i = 0
        while True:
            print('\r%i' % i, end='')
            if i == 1:
                sleep(0.1)  # wait until first running task ends
            mw.submit(blah, i)
            i += 1
            if i == 5:
                pbar.update(1)
                break
            sleep(0.01)

# Generated at 2022-06-24 10:10:13.920712
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    r = MonoWorker()
    assert r.submit(time.sleep, 1).done()
    assert r.submit(time.sleep, 1).done()
    assert r.submit(time.sleep, 1).cancel()
    assert not r.submit(time.sleep, 1).cancel()
    assert r.submit(time.sleep, 1).done()
    assert r.submit(time.sleep, 1).cancel()

# Generated at 2022-06-24 10:10:18.475185
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def test_func(bar, sleep):
        with bar:
            time.sleep(sleep)

    t = MonoWorker()
    for i in tqdm_auto.tqdm(range(4)):
        t.submit(test_func, tqdm_auto.tqdm(), 0.2)

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:10:25.423472
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(n):
        time.sleep(.05)
        return n

    m = MonoWorker()
    print(m.pool)
    print(m.futures)
    for i in range(3):
        m.submit(f, i)
    time.sleep(.1)
    print(list(m.futures))
    for future in m.futures:
        print(future, future.result())


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:10:31.444094
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    done = 'done'
    mw = MonoWorker()
    for i in tqdm_auto.trange(2, desc='Setup'):
        sleep(1)
    assert mw.futures == deque([], 2)
    i = 0
    while i < 2:
        i += 1
        def func():
            sleep(2)
            return done
        future = mw.submit(func)
        assert future.result() == done
    assert mw.futures == deque([], 2)

# Generated at 2022-06-24 10:10:40.430167
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import time
    from time import sleep
    tqdm_auto.write("Testing MonoWorker ...")

    def dummy_func(i, sleep_time):
        sleep(sleep_time)
        return i

    mono = MonoWorker()

    t0 = time()
    r1 = mono.submit(dummy_func, 1, 1)
    sleep(0.5)
    r2 = mono.submit(dummy_func, 2, 1)
    sleep(1.5)
    r3 = mono.submit(dummy_func, 3, 1)
    for r in [r1, r2, r3]:
        assert r.result() == 3

    tqdm_auto.write("MonoWorker compliant. Elapsed time: {0:.1f}s".format(time() - t0))

# Generated at 2022-06-24 10:10:49.067116
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    from .thread import dummy_thread
    from .process import dummy_process

    def wait_submission(executor, func, *args, **kwargs):
        task = executor.submit(func, *args, **kwargs)
        while not task.done():
            sleep(0.01)

    executor = MonoWorker()

    counter = 0
    def increment(a):
        nonlocal counter
        counter += a

    # Test process
    try:
        counter_ = counter
        wait_submission(executor, dummy_process, increment, 1)
        # `counter` should not have changed (replaced by `dummy_process`)
        assert counter_ == counter
    except Exception:
        pass


# Generated at 2022-06-24 10:10:57.970051
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from subprocess import check_output

    from .tests import _main  # noqa
    with tqdm_auto.tqdm() as t:
        worker = MonoWorker()
        # first task is running
        running = worker.submit(lambda: check_output("echo -n 1; sleep 3", shell=True).decode("ascii"))
        t.clear()
        tqdm_auto.write("\t" * 3 + "1")
        # second task gets inserted
        waiting = worker.submit(lambda: check_output("echo -n 2; sleep 3", shell=True).decode("ascii"))
        t.clear()
        tqdm_auto.write("\t" * 3 + "2")
        # third task replaces second task, first task is still running
        waiting = worker

# Generated at 2022-06-24 10:11:03.033267
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.futures == deque([], 2)
    assert mw.pool.__class__.__name__ == 'ThreadPoolExecutor'
    assert mw.pool._max_workers == 1
    assert mw.submit([1,2,3,4,5]) == None
    assert mw.futures == deque([], 2)
    assert mw.submit(sum, [1,2,3,4,5]) == None
    assert mw.futures == deque([], 2)
    assert mw.pool.__class__.__name__ == 'ThreadPoolExecutor'
    assert mw.pool._max_workers == 1
    assert mw.submit(sum, [1,2,3,4,5]) == None
    assert mw.f

# Generated at 2022-06-24 10:11:04.928902
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert mw.futures.maxlen == 2



# Generated at 2022-06-24 10:11:15.556301
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=missing-docstring
    import time
    from . import workers

    mw = MonoWorker()

    # test limit of 1
    g = mw.submit(time.sleep, 0.1)
    assert len(mw.futures) == 1
    assert g == mw.futures[0]
    g = mw.submit(time.sleep, 0.2)
    assert len(mw.futures) == 1
    assert g == mw.futures[0]

    # test overwriting
    def gsleep(t):
        time.sleep(t)
        return "test"

    g = mw.submit(time.sleep, 0.1)
    assert len(mw.futures) == 1
    assert g == mw.futures

# Generated at 2022-06-24 10:11:19.757360
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import random
    from threading import Event, Thread
    from time import sleep
    from warnings import warn

    def is_test():
        try:
            import pytest
        except ImportError:
            return False
        else:
            return True

    def test_MonoWorker_submit_func():
        mw = MonoWorker()
        e = Event()

        # non-blocking
        e1 = mw.submit(sleep, 1)
        sleep(.2)
        assert not e1.done()
        assert e1 in mw.futures
        e1.cancel()
        assert e1.cancelled()
        assert e1 not in mw.futures
        e2 = mw.submit(sleep, 1)
        e2.set()
        assert e2.done()
       

# Generated at 2022-06-24 10:11:26.894101
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def test_it(func, *args, **kwargs):
        """some function"""
        return func(*args, **kwargs)
    if __name__ == "__main__":
        import time
        import multiprocessing as mp
        import threading as th

        def wait_and_finish(seconds, result):
            """blocking function"""
            time.sleep(seconds)
            return result

        def wait_and_raise(seconds, ex):
            """blocking function"""
            time.sleep(seconds)
            raise ex
        pool = MonoWorker()

# Generated at 2022-06-24 10:11:28.496080
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def do_nothing():
        time.sleep(2)
        return 'done'
    mono_worker = MonoWorker()
    mono_worker.submit(do_nothing)

# Generated at 2022-06-24 10:11:38.618879
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def _wait(n):
        try:
            from time import time, sleep
            start_time = time()
            sleep(n)
            end_time = time()
        except Exception as e:
            return str(e)
        return '%.2f' % (end_time - start_time)

    m = MonoWorker()
    # First submit a job
    t1 = m.submit(_wait, 1)
    # Second job queued and popped
    t2 = m.submit(_wait, 2)
    # Try cancelling the current job
    t1.cancel()
    # Third job queued and popped
    t3 = m.submit(_wait, 3)
    # Check results
    assert t2.exception() == 'Task was cancelled'

# Generated at 2022-06-24 10:11:45.842087
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker"""
    from time import sleep
    from .utils import threaded_worker

    worker = MonoWorker()
    worker.submit(sleep, 0.5)
    worker.submit(sleep, 0.4)
    worker.submit(sleep, 0.5)

    def test_threaded(i):
        """Test threaded worker"""
        worker.submit(sleep, 0.2)

    threaded_worker(test_threaded, (0, 5))

# Generated at 2022-06-24 10:11:55.369106
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=missing-docstring
    import time
    import random
    # pylint: disable=bare-except
    out = []

    def runner(x):
        time.sleep(random.random())
        out.append(x)

    MW = MonoWorker()
    for _ in range(8):
        MW.submit(runner, _)
        time.sleep(random.random())
    for i in range(len(out)):
        assert i == out[i], (i, out)
    assert len(out) == len(set(out)), out
    MW.pool.shutdown()
    time.sleep(.05)
    assert MW.pool.shutdown_threads

