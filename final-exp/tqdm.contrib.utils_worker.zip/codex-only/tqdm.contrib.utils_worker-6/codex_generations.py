

# Generated at 2022-06-24 10:02:07.036500
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import Future

    def sleep_func(t, arg):
        time.sleep(t)
        return arg

    worker = MonoWorker()
    assert isinstance(worker.submit(sleep_func, 1, 0), Future)
    assert isinstance(worker.submit(sleep_func, 1, 1), Future)
    assert isinstance(worker.submit(sleep_func, 1, 2), Future)
    assert isinstance(worker.submit(sleep_func, 1, 3), Future)


# Generated at 2022-06-24 10:02:16.655074
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Unit test for constructor of class MonoWorker.
    """
    mworker = MonoWorker()
    futures = mworker.futures
    assert(len(futures) == 0)
    assert(futures.maxlen == 2)
    mworker.submit(max, 1, 2)
    assert(len(futures) == 1)
    assert(futures[0].result() == 2)
    mworker.submit(max, 2, 3)
    assert(len(futures) == 2)
    assert(futures[0].result() == 2)
    mworker.submit(max, 3, 4)
    assert(len(futures) == 2)
    assert(futures[0].result() == 3)

# Generated at 2022-06-24 10:02:20.251989
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from threading import Event
    from concurrent.futures import Future
    _F = Future()
    _F.set_result(3)
    _E = Event()
    _E.set()
    _TF = MonoWorker()
    _TF.submit(Event.wait, _E)
    assert _TF.futures[0].wait(0.1)
    _TF.submit(Event.wait, _E)
    assert not _TF.futures[0].wait(0.1)

# Generated at 2022-06-24 10:02:29.990735
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Event

    def func1(e1, e2, sleep_time=0.01, blocking_time=0.03):
        sleep(blocking_time)
        e1.set()
        e2.wait()
        return blocking_time

    e1 = Event()
    e2 = Event()
    mono = MonoWorker()
    f1 = mono.submit(func1, e1, e2, 0.01)
    assert not f1.done()
    sleep(0.005)
    f2 = mono.submit(func1, e1, e2, 0.02)
    assert not f1.done()
    assert not f2.done()
    e1.wait()
    sleep(0.005)

# Generated at 2022-06-24 10:02:38.449106
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def f(i):
        time.sleep(1)
        return i * 10

    a = MonoWorker()
    print(a.submit(f, 1))
    print(a.submit(f, 2))
    print(a.submit(f, 3))
    print(a.submit(f, 4))
    print(a.submit(f, 5))
    print(a.submit(f, 6))
    print(a.submit(f, 7))
    print(a.submit(f, 8))
    print(a.submit(f, 9))
    print(a.submit(f, 10))
    print(a.submit(f, 11))
    print(a.submit(f, 12))
    print(a.submit(f, 13))

# Generated at 2022-06-24 10:02:44.115851
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import signal
    from ..utils import _term_move_up
    from ..utils import _range
    from ..utils import format_size
    from .filesystem import auto_open_files
    from .filesystem import tqdm_open
    from .filesystem import tqdm_hook
    from .filesystem import tqdm_hook_kwargs
    from .filesystem import tqdm_write
    from .filesystem import tqdm_writelines

    def mk_tests():
        class TestFile(object):
            def __init__(self, tqdm_cls):
                self.f = tqdm_cls(
                    _range(100),
                    position=0,
                    desc='testing')
                self.f.write('foo ')
                self.f.flush()
                self.f.close()



# Generated at 2022-06-24 10:02:45.144264
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()


# Generated at 2022-06-24 10:02:53.216838
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    timeout = 0.2

    def sleeper(n):
        time.sleep(n)

    mw = MonoWorker()

    # test simple
    mw.submit(sleeper, 1)
    time.sleep(timeout)
    mw.submit(sleeper, 2)

    # test full
    mw.submit(sleeper, 1)
    mw.submit(sleeper, 2)
    time.sleep(1.1)
    mw.submit(sleeper, 3)
    time.sleep(timeout)
    mw.submit(sleeper, 4)

# Generated at 2022-06-24 10:03:01.372594
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import as_completed
    from inspect import getsource
    from io import StringIO
    from unittest.case import skip

    worker = MonoWorker()

    output, err = StringIO(), StringIO()
    with tqdm_auto.tqdm(total=4, file=output, leave=False) as t:
        def inc(t, i):
            sleep(1)
            t.update()
            return i + 1

        future_0 = worker.submit(inc, t, 0)
        future_1 = worker.submit(inc, t, 0)
        future_2 = worker.submit(inc, t, 0)
        # future_3 = worker.submit(inc, t, 0)
        # future_4 = worker.submit(inc, t, 0)

# Generated at 2022-06-24 10:03:10.651207
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """test_MonoWorker_submit"""
    # pylint: disable=protected-access
    def run_test(n, elems):
        """run_test"""
        worker = MonoWorker()
        if elems:
            assert len(elems) == worker.futures.maxlen
            for i in elems:
                worker.futures.appendleft(i)
        for _ in range(n):
            worker.submit(id, object())
        for _ in range(n):
            worker.submit(id, object())
        assert len(worker._MonoWorker__futures) == worker.futures.maxlen
        assert len(worker._MonoWorker__pool._work_queue) == n + 1
        assert len(worker._MonoWorker__pool._threads) <= 1


# Generated at 2022-06-24 10:03:19.965539
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading

    class Counts(object):
        def __init__(self, val):
            self.val = val
            self.finished = threading.Event()

    def sleeper(x, n):
        time.sleep(n)
        x.val += n
        x.finished.set()

    # Instantiate MonoWorker object
    mono_worker = MonoWorker()

    # Create and submit multiple sleeper tasks
    x = Counts(0)
    mono_worker.submit(sleeper, x, 4)
    y = Counts(0)
    mono_worker.submit(sleeper, y, 4)
    z = Counts(0)
    mono_worker.submit(sleeper, z, 4)

    # Check if the latest sleeper task (z) is still running

# Generated at 2022-06-24 10:03:27.587985
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    mw = MonoWorker()

    def test(n):
        time.sleep(1)
        return n

    r1 = mw.submit(test, 1)
    assert not r1.done()
    r2 = mw.submit(test, 2)
    assert not r2.done()
    r3 = mw.submit(test, 3)
    assert r2.done() and r2.cancelled()
    assert not r1.done() and not r1.cancelled()
    assert not r3.done() and not r3.cancelled()

    r3.result()
    assert r3.done()

    r1.result()
    assert r1.done()

# Generated at 2022-06-24 10:03:28.844654
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    return 0


# Generated at 2022-06-24 10:03:39.078451
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Unit test for constructor of class MonoWorker
    """
    import sys
    import inspect
    import unittest

    class TestMonoWorker(unittest.TestCase):
        """
        Unit test for constructor of class MonoWorker
        """
        def test_init(self):
            """
            test_init
            """
            test_obj = MonoWorker()
            self.assertEqual(test_obj.pool.__class__.__name__, 'ThreadPoolExecutor')
            self.assertEqual(test_obj.futures.__class__.__name__, 'deque')
            self.assertTrue(len(test_obj.futures), 0)

    module = inspect.getmodule(inspect.stack()[0][0])

# Generated at 2022-06-24 10:03:40.889842
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def f(x):
        return x + 1
    worker = MonoWorker()
    assert worker.submit(f, 2)

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:03:45.033377
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    class function(object):
        count = -1
        args = kwargs = None

        def __call__(self, *args, **kwargs):
            self.count += 1
            self.args = (args, kwargs)
            sleep(0.1)
            return self.count

    f = function()
    pool = MonoWorker()
    assert list(map(pool.submit, [f for _ in range(4)])) == [0, 1, 2, 3]
    assert f.count == 3
    sleep(0.1)  # let first task finish
    assert list(map(pool.submit, [f for _ in range(4)])) == [4, 3, 3, 3]
    assert f.count == 4
    pool.futures[1].result()  # wait for

# Generated at 2022-06-24 10:03:54.613062
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from contextlib import contextmanager
    from time import sleep
    from io import StringIO
    from sys import stdout

    @contextmanager
    def capture_stdout(print_stdout):
        if print_stdout:
            new_stdout = StringIO()  # StringIO() required as StringIO redirect
            old_stdout = stdout
            try:
                stdout = new_stdout
                yield new_stdout
            finally:
                stdout = old_stdout
        else:
            yield None

    monoworker = MonoWorker()
    with capture_stdout(False) as _:
        assert len(monoworker.futures) == 0
    monoworker.submit(sleep, 0.3)

# Generated at 2022-06-24 10:04:03.720529
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import ALL_COMPLETED

    mw = MonoWorker()

    def sleep_print(i, delay=1.5):
        sleep(delay)
        print('sleep_print({})'.format(i))
        return i

    fs = list()
    for i in range(10):
        fs.append(mw.submit(sleep_print, i))
        tqdm_auto.write("Submitted {}".format(i))

    if not all(fs):
        raise RuntimeError("Not all futures were submitted")

    # Note that `fs[0].result()` will block, `fs[1].result()` won't

# Generated at 2022-06-24 10:04:11.425219
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Testing if the method `MonoWorker.submit` works as designed.
    """
    def _assert_submit(MonoWorker, func, *args, **kwargs):
        """
        Test task limitations of `MonoWorker` on the given `func`.
        """
        # Test two submissions to a functional MonoWorker:
        # 1) firstly submitted task should run;
        # 2) secondly submitted task should wait until first finishes.
        worker = MonoWorker()

        # Submit one new task
        fut1 = worker.submit(func, *args, **kwargs)
        assert len(worker.futures) == 1 and fut1 in worker.futures
        assert not fut1.done()
        assert fut1.result() == func(*args, **kwargs) # blocks until done

        # Test that future

# Generated at 2022-06-24 10:04:21.420971
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def slow_double(x, delay=3):
        import time
        time.sleep(delay)
        return 2 * x

    mw = MonoWorker()
    mw.submit(slow_double, 2)
    mw.submit(slow_double, 3)
    mw.submit(slow_double, 4)
    print(mw.futures[0].result(), mw.futures[1].result())
    assert mw.futures[0].result() == 8  # 3 * 2
    assert mw.futures[1].result() == 6  # 2 * 3

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:04:30.865886
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for MonoWorker class"""
    import time

    print('testing MonoWorker (1)'),
    assert MonoWorker().pool._max_workers == 1

    print('\ntesting MonoWorker (2)'),
    def f():
        time.sleep(1)

    w = MonoWorker()
    a = w.submit(f)
    time.sleep(0.1)
    assert len(w.futures), len(w.futures) == 1
    b = w.submit(f)
    time.sleep(0.1)
    assert len(w.futures), len(w.futures) == 1
    assert a.done(), a.done() is False
    assert b.running(), b.running() is True

# Generated at 2022-06-24 10:04:40.767226
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import string
    import concurrent.futures
    import sys
    # set up
    def func(*args, **kwargs):
        time.sleep(random.randint(5,10))
        return args, kwargs
    mw = MonoWorker()
    # test .submit()
    def test_submit(mw):
        for i in range(10):
            args = tuple([random.choice(string.ascii_letters) for j in range(random.randint(0,10))])
            kwargs = {'%s'%j:random.choice(string.ascii_letters) for j in range(random.randint(0,10))}
            r = mw.submit(func, *args, **kwargs)

# Generated at 2022-06-24 10:04:41.810250
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Just check if it runs without error
    a = MonoWorker()

# Generated at 2022-06-24 10:04:44.081487
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from tqdm import trange

    def foo(i):
        time.sleep(1)
        return i

    m = MonoWorker()

    for i in trange(3):
        m.submit(foo, i)

# Generated at 2022-06-24 10:04:47.026209
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def func():
        time.sleep(3)
    m = MonoWorker()
    for i in range(3):
        m.submit(func)

if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:04:51.623681
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import multiprocessing as mp
    from concurrent.futures import Future

    def _run_tests(q):
        """This function is run in a separate process with its own tqdm/IO."""
        from string import ascii_letters
        from random import randint, choice
        from threading import Thread, Event
        from functools import partial
        from tqdm.utils import _term_move_up
        from tqdm.auto import tqdm

        class _Event(object):
            def __init__(self, init=False):
                self._e = Event()
                self.set() if init else self.clear()

            def __bool__(self):
                return self._e.is_set()

            def set(self):
                self._e.set()


# Generated at 2022-06-24 10:05:01.303705
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import time
    import gc
    from collections import defaultdict
    from concurrent.futures import as_completed, TimeoutError
    from ..tests.common import with_bar, assert_reset

    class MonoWorkerTester(MonoWorker):
        # Helper class for testing
        def _check_futures(self):
            futures_dict = defaultdict(bool)
            for f in self.futures:
                futures_dict[f] = True
            assert futures_dict, futures_dict['futures'] is False
            assert len(self.futures) <= self.futures.maxlen
            assert len(futures_dict) <= self.futures.maxlen


# Generated at 2022-06-24 10:05:07.963312
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..std import time, sleep

    mw = MonoWorker()

    def foo(arg):
        sleep(arg)
        return time()

    a = mw.submit(foo, 1)
    time_a = a.result()
    time_b = mw.submit(foo, 1).result()

    assert (time_b - time_a) > 1

    # test that the **kwargs are forwarded
    time_c = mw.submit(tqdm_auto.write, "Hello").result()
    assert not isinstance(time_c, Exception)

# Generated at 2022-06-24 10:05:15.534190
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing import current_process
    from threading import current_thread
    from time import sleep
    from .utils import test_cls_args

    def _test_f(*args, **kwargs):
        sleep(1)
        if args or kwargs:
            return f"args={args}, kwargs={kwargs}, " \
                   f"thread={current_thread()}, " \
                   f"process={current_process()}"

    for mono in [MonoWorker(), MonoWorker()]:
        futures = [mono.submit(_test_f, i) for i in range(10)]

# Generated at 2022-06-24 10:05:26.581447
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import TimeoutError

    def sleep_then_return(duration, retval):
        from time import sleep
        sleep(duration)
        return retval

    mw = MonoWorker()
    f0 = mw.submit(sleep_then_return, 0.8, 0)
    f1 = mw.submit(sleep_then_return, 0.5, 1)
    f2 = mw.submit(sleep_then_return, 1.5, 2)
    try:
        f3 = mw.submit(sleep_then_return, 1.5, 3, timeout=1.0)
    except TimeoutError:
        pass
    else:
        raise Exception("Should have timed out")
    assert f0.result() == 0
    assert f1.result() == 1

# Generated at 2022-06-24 10:05:37.235390
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """This is a test function for the method submit of the class MonoWorker"""
    import time
    import numpy as np

    def worker(item):
        """To test the MonoWorker class"""
        time.sleep(np.random.random()) # Wait some time
        if item < 0:
            raise Exception('item < 0')
        if item > 1:
            print('item > 1')
        return item > 0.5

    # Init the MonoWorker class
    m = MonoWorker()

    # Test the submit method
    for item in np.random.random(10):
        f = m.submit(worker, item)
        if f is not None:
            if item > 0.5:
                if not f.result():
                    print('item > 0.5 but result is False')

# Generated at 2022-06-24 10:05:45.515666
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import threading
    import time

    def printer(x):
        time.sleep(3)
        print(x)

    def printer2(x):
        time.sleep(1)
        print(x)

    t = threading.Thread(target=MonoWorker)
    t.daemon = True
    t.start()

    m = MonoWorker()
    m.submit(printer, "A")
    m.submit(printer, "B")
    m.submit(printer, "C")
    m.submit(printer2, "D")
    m.submit(printer2, "E")
    m.submit(printer2, "F")
    m.submit(printer2, "G")
    m.submit(printer2, "H")



# Generated at 2022-06-24 10:05:52.421796
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    class MyClass(object):
        def __init__(self):
            self.clocks = []
            self.pool = MonoWorker()
            self.clocks.append(time.time())

        def submit(self, wait=0, timeout=0):
            self.clocks.append(time.time())
            clock = self.clocks[-1]
            if timeout:
                f = self.pool.submit(time.sleep, timeout)
                return f
            else:
                return self.pool.submit(self._sleep, wait, clock)

        def _sleep(self, wait, clock):
            time.sleep(wait)
            self.clocks.append(time.time())
            return clock

    mc = MyClass()
    # Check that Monoworker can actually run something

# Generated at 2022-06-24 10:06:00.628546
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    job_execution_time = 0.5
    job_count = 2

    def job():
        time.sleep(job_execution_time)

    mono_worker = MonoWorker()
    for i in range(job_count):
        mono_worker.submit(job)

    time.sleep(job_execution_time / 2)
    assert len(mono_worker.futures) == 1
    assert mono_worker.futures[0].running() is True

    time.sleep(job_execution_time * 1.5)
    assert len(mono_worker.futures) == 1
    assert mono_worker.futures[0].done() is True


# Generated at 2022-06-24 10:06:09.222270
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def _delay_infinite(d, _=random(), b=sleep):
        b(d)
        return d

    def _delay(d, _=random(), b=sleep):  # noqa: N803
        b(d)
        return d

    Delay = _delay_infinite  # _delay  #

    zero = MonoWorker()
    z = zero.submit(Delay, 0)
    assert z.result() == 0
    z = zero.submit(Delay, 0)
    x = zero.submit(Delay, 1)
    assert x.cancelled()
    assert z.result() == 0
    x = zero.submit(Delay, 1)
    z = zero.submit(Delay, 0)
    assert z.cancelled()
   

# Generated at 2022-06-24 10:06:18.695849
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Basic usage of MonoWorker."""
    from time import sleep
    from multiprocessing import Value
    from threading import Lock
    lock = Lock()
    counter = Value('i', 0)
    worker = MonoWorker()
    # add first task
    worker.submit(lambda _: sleep(1), 1,
                  lock=lock,
                  counter=counter)
    with lock:
        assert counter.value == 0
    sleep(1)
    with lock:
        assert counter.value == 1
    # add second task to replace the currently running task
    worker.submit(lambda _: sleep(1), 2,
                  lock=lock,
                  counter=counter)
    with lock:
        assert counter.value == 1
    sleep(1)
    with lock:
        assert counter.value == 2
    # add third task to

# Generated at 2022-06-24 10:06:22.935795
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    # Test that max_workers is configured
    assert mw.pool._max_workers == 1
    # Test that futures is configured
    assert len(mw.futures) == 0
    assert mw.futures.maxlen == 2


# Generated at 2022-06-24 10:06:28.676158
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    # Test case 1: check submit with only 1 task
    time_start = time.time()
    mono = MonoWorker()
    mono.submit(time.sleep, 0.1)
    task1 = mono.futures[0]
    task1.result()
    time_end = time.time()
    assert (time_end - time_start) > 0.1

    # Test case 2: check if future takes too long, newer ones will override
    # the former.
    time_start = time.time()
    mono = MonoWorker()
    mono.submit(time.sleep, 0.1)
    mono.submit(time.sleep, 0.05)
    task1 = mono.futures[0]
    time.sleep(0.08)

# Generated at 2022-06-24 10:06:29.691731
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker."""
    MonoWorker()

# Generated at 2022-06-24 10:06:31.341717
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    worker.submit(print, "test")

# Generated at 2022-06-24 10:06:42.850326
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import as_completed

    # Test with a time-consuming function
    def test_func(count):
        for i in range(count):
            with tqdm_auto.tqdm(total=count) as prg:
                for j in range(count):
                    prg.update()
                    sleep(0.05)

    def test_submit(objects, func, *args, **kwargs):
        from collections import Iterable
        if not isinstance(objects, Iterable):
            objects = (objects,)
        futures = []
        for obj in objects:
            r = obj.submit(func, *args, **kwargs)
            futures.append(r)
        return futures

    def test_result(futures):
        results = []

# Generated at 2022-06-24 10:06:52.853983
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    start = time.time()
    m = MonoWorker()
    assert len(m.futures) == 0

    def f(s):
        time.sleep(s)
        return s

    def check(t, s, expected_len=1, expected_t=None):
        assert len(m.futures) == expected_len
        if expected_t is not None:
            assert m.futures[0].result() == expected_t
        else:
            assert m.futures[0].cancelled()

    def wait_until(t):
        while time.time() - start < t:
            continue
        return t

    # one running
    m.submit(f, wait_until(0.2))
    time.sleep(0.01)

# Generated at 2022-06-24 10:06:59.675281
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import numpy as np
    from concurrent.futures import as_completed

    def wait_random():
        time.sleep(np.random.random() / 5)
        return 1

    mw = MonoWorker()
    mw.submit(wait_random)
    results = []
    while mw.futures:
        results.extend([f.result() for f in as_completed(mw.futures)])
    assert len(results) == 2



# Generated at 2022-06-24 10:07:08.358049
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test for `tqdm.contrib.MonoWorker`."""
    import os
    from time import sleep
    from .tests import pretest_posttest

    # pylint: disable=useless-object-inheritance
    class RunAndSleep(object):  # pragma: no cover
        """Run a function and sleep for a while."""
        def __init__(self, func, sleeptime=5):
            self.func = func
            self.sleep = sleeptime

        def __call__(self, *args, **kwargs):
            self.func(*args, **kwargs)
            sleep(self.sleep)
            return args[0]

    def testfunc(num):
        """A test function that runs (and sleeps)"""

# Generated at 2022-06-24 10:07:13.525429
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def foo_test(i):
        import time
        time.sleep(1)
        return i

    m = MonoWorker()

    for i in range(4):
        m.submit(foo_test, i)

    for i in range(4):
        j = m.futures.popleft().result()
        assert i == j

# Generated at 2022-06-24 10:07:19.245298
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mono = MonoWorker()
    running = mono.submit(lambda x: x, 1)
    waiting = mono.submit(lambda x: x, 2)  # should replace waiting
    waiting.cancel()  # for unit test only
    assert waiting.cancelled()
    assert not running.cancelled()
    assert running.result() == 1


if __name__ == "__main__":  # pragma: no cover
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:07:23.374272
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    p = MonoWorker()
    assert p.submit(0, 0)


if __name__ == '__main__':  # pragma: no cover
    from multiprocessing import Pool
    from time import sleep
    from os import cpu_count

    n_proc = cpu_count()

    with tqdm_auto.tqdm(total=n_proc, desc="Test") as pbar:
        def callback(*args):
            pbar.update()

        def run(idx):
            """Simple execution (but with a callback)"""
            sleep(1 / ((idx % 2) + 1))
            return idx
        p = Pool(n_proc)
        for _ in p.imap_unordered(run, range(n_proc),
                                  chunksize=1):
            pass
        pbar.close

# Generated at 2022-06-24 10:07:30.515923
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()
    test = [0.2, 0.6, 0.1, 0.8, 0.15, 0.1, 0.6]
    res = []
    for i, t in enumerate(test):
        res.append(mw.submit(time.sleep, t))
        print('{}\t({} running, {} waiting)'.format(i, len(res)-len(mw.futures), len(mw.futures)))
    for r in res:
        r.result()

# Generated at 2022-06-24 10:07:38.761921
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import multiprocessing.pool as mp_pool
    pool = mp_pool.ThreadPool(1)
    def slow_square_dummy(x):
        time.sleep(random.random())
        return x ** 2
    mw = MonoWorker()
    for i in range(6):
        num = random.randint(0, 100)
        f = mw.submit(slow_square_dummy, num)
        assert (f.result() == num ** 2) == (i <= 2)  # discard the last 3
    f = mw.submit(slow_square_dummy, 123)  # clear waiting task
    assert f.result() == 123 ** 2
    f = mw.submit(slow_square_dummy, (456,))  # don't clear running task

# Generated at 2022-06-24 10:07:49.972119
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import time, sleep
    from random import randint
    from multiprocessing.pool import ThreadPool
    from threading import Thread
    from _thread import LockType
    from concurrent.futures import ThreadPoolExecutor, as_completed
    import gc
    t = MonoWorker()
    def gen(lock, sleep_per, f_sleep_per):
        lock.acquire()
        while True:
            sleep(f_sleep_per)
            try:
                t.pool.submit(sleep, sleep_per)
            except:
                break
            else:
                lock.acquire()
    def test(lock, f_sleep_per, sleep_per, n_tasks):
        threads = []
        failures = 0
        start = time()

# Generated at 2022-06-24 10:08:00.560235
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import concurrent.futures

    # Create a thread pool with 2 threads
    pool = MonoWorker()

    random.seed(1)

    def my_func(num):
        time.sleep(random.random())
        return num, ' ' + str(num)

    def main():
        results = []
        results.append(pool.submit(my_func, 1).result())
        results.append(pool.submit(my_func, 1).result())
        results.append(pool.submit(my_func, 2).result())
        results.append(pool.submit(my_func, 2).result())
        results.append(pool.submit(my_func, 3).result())
        results.append(pool.submit(my_func, 3).result())

# Generated at 2022-06-24 10:08:06.749590
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    mw.submit(run, 1, 2)
    mw.submit(run, 3, 4)
    mw.submit(run, 5, 6)
    mw.submit(run, 7, 8)
    mw.submit(run, 9, 10)
    mw.submit(run, 11, 12)
    print("")



# Generated at 2022-06-24 10:08:14.240779
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import RLock
    from time import sleep
    from threading import Thread
    from unittest.case import TestCase

    class DummyFunc(object):
        def __init__(self):
            super(DummyFunc, self).__init__()
            self.lock = RLock()
            self.count = 0

        def __call__(self, interval, dummy=None):
            sleep(interval)
            with self.lock:
                self.count += 1
            return

    class TestMonoWorker(TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.df = DummyFunc()
            return

        def test_submit(self):
            self.mw.submit(self.df, 0.5)

# Generated at 2022-06-24 10:08:23.850388
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from datetime import datetime

    def task(name):
        sleep(5)
        tqdm_auto.write("{} completed".format(name))

    def time2str(t):
        return datetime.strftime(t, '%M:%S')

    start = datetime.now()
    tqdm_auto.write('time2str(start) = {}, start = {}'.format(time2str(start),
                                                              start))
    mw = MonoWorker()
    for i in range(8):
        tqdm_auto.write('time2str(datetime.now()) = {}, datetime.now() = {}'.
                        format(time2str(datetime.now()), datetime.now()))
        if i == 0:
            mw.submit

# Generated at 2022-06-24 10:08:29.997478
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    q = MonoWorker()

    def wait_for_event(event, timeout=1):
        """
        Waits until the internal flag of the event is set to true.
        `timeout` is the same as in `threading.Event.wait`.
        """
        event.wait(timeout)
        return 'finished' if event.is_set() else 'failed'

    ev = Event()
    # Submit a task which will finish in 0.5s
    future1 = q.submit(wait_for_event, ev)
    sleep(0.3)
    assert future1.done() == False, 'Thread should still be running'
    # Submit a task which will finish in 0.05s

# Generated at 2022-06-24 10:08:39.290081
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from multiprocessing import Event, Lock
    from concurrent.futures import FIRST_COMPLETED

    # Make sure that all threads/processes are finished before ending
    clean = Lock()
    clean.acquire()

    def cleanup():
        clean.release()
        clean.acquire()
        clean.release()

    # Fake thread, useful for testing
    def _wait_and_clean(delay, n, time_reqd=None):
        """Calculate 1/n and sleep `delay` seconds"""
        time.sleep(delay)
        tqdm_auto.write(str(1.0 / n))
        if time_reqd:
            time_reqd.set()
        cleanup()

    # Fake thread, useful for testing

# Generated at 2022-06-24 10:08:40.019079
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert MonoWorker()


# Generated at 2022-06-24 10:08:44.698162
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from queue import Queue

    q = Queue()
    def f(i):
        q.put(i)
        sleep(1)
        return i

    w = MonoWorker()
    futures = [w.submit(f, i) for i in range(4)]

    assert q.get() == 0
    assert q.get() == 1
    assert q.qsize() == 0

    for f in futures:
        assert f.done()
        assert f.result() == 1


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:08:52.119755
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time
    import tqdm

    mw = MonoWorker()

    # Create and submit some workers
    def task(i, delay=1):
        time.sleep(delay)
        tqdm.write("Worker {} finished.".format(i))

    for i in range(4):
        args = (i,)
        delay = 1 / (i + 1)
        mw.submit(task, *args, delay=delay)
        time.sleep(0.05)

    # Wait for the workers to finish
    time.sleep(2)
    print("\nThe output should be:")
    print("Worker 2 finished.")
    print("Worker 3 finished.")
    print("Worker 4 finished.")
    print("Check the source code to see what happens.")

# Generated at 2022-06-24 10:09:01.615295
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()

    x = []
    y = []

    def foo():
        x.append(True)
        time.sleep(1)

    def bar():
        y.append(True)
        time.sleep(1)

    mw.submit(foo)
    mw.submit(bar)
    time.sleep(0.1)
    assert len(x) == 1, 'x has {} elements'.format(len(x))
    assert len(y) == 0, 'y has {} elements'.format(len(y))

    time.sleep(2)
    assert len(x) == 1, 'x has {} elements'.format(len(x))
    assert len(y) == 1, 'y has {} elements'.format(len(y))

# Generated at 2022-06-24 10:09:06.114322
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random, time

    def randwait(N=10):
        time.sleep(random.randint(1, N))

    def func(i, kw):
        randwait()
        return i + kw['i']

    mw = MonoWorker()
    for ii in range(100):
        N = random.randint(1, 100)
        e1 = mw.submit(randwait, N)
        e2 = mw.submit(func, ii, {'i': -ii})

        for e in (e1, e2):
            try:
                e.result()
            except Exception as e:
                tqdm_auto.write(str(e))

# Generated at 2022-06-24 10:09:13.532504
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..contrib import objgraph

    def pr(msg, verbose=True):
        if verbose:
            tqdm_auto.write('\n{}'.format(msg))

    pr('MonoWorker: 1 job followed by 2 jobs')
    mw = MonoWorker()
    mw.submit(sleep, 1)
    mw.submit(sleep, 0.5)
    mw.submit(sleep, 0.3)
    pr('MonoWorker: 2 jobs followed by 1 job')
    mw = MonoWorker()
    mw.submit(sleep, 0.5)
    mw.submit(sleep, 0.3)
    mw.submit(sleep, 1)

    pr('verify no future objects left behind', verbose=False)
    assert objgraph.count

# Generated at 2022-06-24 10:09:19.482343
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    MONITOR = [0]  # use a mutable as a switch
    def do(key):
        time.sleep(0.1)
        MONITOR.append(key)
    worker = MonoWorker()
    for _ in range(10):
        worker.submit(do, key=_)
    worker.pool.shutdown(wait=True)
    assert len(MONITOR) == 3

# Generated at 2022-06-24 10:09:22.203815
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def foo():
        pass

    def bar():
        pass

    MonoWorker().submit(foo)
    MonoWorker().submit(foo)
    MonoWorker().submit(bar)

# Generated at 2022-06-24 10:09:26.317496
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading

    def slowprint(i):
        async_worker.submit(time.sleep, 2)
        print(i)

    async_worker = MonoWorker()

    for i in range(2):
        thread = threading.Thread(target=slowprint, args=[i])
        thread.start()



# Generated at 2022-06-24 10:09:39.623726
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Add the following lines **at the end of the file** `./tests/test_tqdm.py`:

        from tqdm.contrib import test_MonoWorker_submit
        test_MonoWorker_submit()

    Then, run `python -m tqdm.tests.test_tqdm`.
    """
    import time
    try:
        import numpy as np
    except ImportError:
        return

    def f(n):
        time.sleep(n)
        return n

    def compare(futures):
        assert futures[0].result() == futures[1].result()

    dt = 0.2
    futures = []
    worker = MonoWorker()

# Generated at 2022-06-24 10:09:47.816685
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    mw = MonoWorker()
    res = {}
    mx = Lock()
    def set_result(k, v):
        with mx:
            res[k] = v
    def wait(k, sec):
        d = mw.submit(time.sleep, sec)
        # we want to catch the different "return value" of the same task
        d.add_done_callback(lambda f: set_result(k, f.result()))
    wait(1, 0.5)
    wait(2, 1)
    wait(3, 0.75)
    wait(4, 0)
    wait(5, 1)
    wait(6, 0.5)
    wait(7, 0.5)
    wait(8, 0)

# Generated at 2022-06-24 10:09:53.469732
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    def sub_test(worker):
        from time import sleep
        from random import random
        from operator import add

        def run(n):
            sleep(n)
            return n

        def run_error(n):
            sleep(n)
            raise Exception("Error")

        worker.submit(run, 0.1)  # keep this running
        for i in tqdm_auto.trange(5):
            worker.submit(run, random())

        assert worker.futures[-1].running()
        worker.futures[-1].cancel()
        assert not worker.futures[-1].running()

        worker.submit(run_error, 0.1)

    worker = MonoWorker()
    sub_test(worker)

# Generated at 2022-06-24 10:10:02.434003
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from io import StringIO
    import sys

    sys.stderr = StringIO()  # capture stdout
    mono = MonoWorker()

    def long_running_task():
        sleep(0.5)
        return 'Hello'

    def quicker_task():
        sleep(0.05)
        return 'World'

    def exploding_task():
        raise Exception("boom")

    assert mono.submit(long_running_task).result() == 'Hello'
    # second task is discarded, replaced by this one
    assert mono.submit(quicker_task).result() == 'World'
    assert mono.submit(exploding_task) is None
    assert sys.stderr.getvalue() == 'boom\n'

# Generated at 2022-06-24 10:10:14.560703
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, time
    import subprocess as sp
    from threading import Thread

    def f_dummy(arg):
        sleep(0.5)
        return arg

    def f_print(arg):
        print(arg)
        return arg

    def f_tqdm(arg):
        return list(tqdm_auto.trange(10, desc=str(arg)))

    def f_raise(arg):
        raise ValueError('{}'.format(arg))

    def f_input(arg):
        return input('{}'.format(arg))

    def f_spwd(arg):
        return sp.check_output('pwd', shell=True)

    def f_pwd(arg):
        return sp.check_output('pwd')


# Generated at 2022-06-24 10:10:25.752880
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def long_task(t):  # delays t seconds
        sleep(t)
        return t

    mw = MonoWorker()
    future = mw.submit(long_task, 0.5)
    assert future.result() == 0.5

    future = mw.submit(long_task, 0.5)
    assert future.result() == 0.5

    future = mw.submit(long_task, 1)
    # Ensure task is running
    sleep(0.5)
    assert future.running()

    try:
        future = mw.submit(long_task, 0.5)
        future.result()

        assert False, 'Overload failed'
    except:
        pass  # this is expected

    # wait for long task to complete
    sleep(1.5)
   

# Generated at 2022-06-24 10:10:26.323694
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    pass

# Generated at 2022-06-24 10:10:36.891031
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import random
    import string
    import sys
    import time
    import traceback

    if sys.version_info >= (3,):
        string_ascii = string.ascii_letters
    else:
        string_ascii = string.lowercase

    mw = MonoWorker()
    for i in tqdm_auto.trange(1000):
        st = ''.join(random.choice(string_ascii) for _ in range(10))
        future = mw.submit(time.sleep, 0.5, st)
        if future is not None:
            try:
                future.result()
            except Exception:
                traceback.print_exc()
            else:
                print(st)

# Generated at 2022-06-24 10:10:46.483447
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import pytest
    from ..utils import _term_move_up

    def wait3sec(x):
        time.sleep(3)
        return x

    def wait2sec(x):
        time.sleep(2)
        return x

    worker = MonoWorker()
    with tqdm_auto.trange(10) as t:
        for i in t:
            if i % 2:
                future1 = worker.submit(wait3sec, i)
            else:
                future2 = worker.submit(wait2sec, i)

    assert future1.result() == 9
    assert future2.result() == 8
    for i in range(9, -1, -1):
        worker.submit(wait2sec, i)
        assert hasattr(worker.futures, 'maxlen')


# Generated at 2022-06-24 10:10:56.229103
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def _foo(n):
        return n + 1

    monoworker = MonoWorker()
    max_workers = monoworker.pool._max_workers  # pylint: disable=protected-access
    assert max_workers == 1
    assert len(monoworker.futures) == 0

    future = monoworker.submit(_foo, 2)
    assert len(monoworker.futures) == 1
    assert future.done() is False

    new_future = monoworker.submit(_foo, 3)
    assert len(monoworker.futures) == 1
    assert future.done() is False
    assert new_future.done() is False
    assert future.cancel() is False

    # Test if the 'future' _never_ finishes

# Generated at 2022-06-24 10:11:01.609306
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from sys import version_info

    from ..auto import tqdm
    from ..utils import _environ_cols_wrapper, _term_move_up

    from .tests_c import test_MonoWorker, test_MonoWorker_cancel

    # Configure tqdm for large screens
    with _environ_cols_wrapper({'COLUMNS': '100'}):
        with tqdm_auto.external_write_mode():
            tests = [(test_MonoWorker, (), {}),
                     (test_MonoWorker_cancel, (), {})]
            if version_info[:2] >= (3, 4):
                tests.append((test_MonoWorker, (False,), {}))
            for test, args, kwargs in tests:
                test(*args, **kwargs)


# Generated at 2022-06-24 10:11:07.300461
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def dummy_func():
        return None

    w = MonoWorker()
    assert isinstance(w.pool, ThreadPoolExecutor)
    assert w.futures.maxlen == 2
    assert not len(w.futures)
    w.submit(dummy_func)
    assert len(w.futures) == 1
    w.submit(dummy_func)
    assert len(w.futures) == 2
    w.submit(dummy_func)
    assert len(w.futures) == 2

# Generated at 2022-06-24 10:11:17.024615
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .utils import *
    from concurrent.futures import Future
    import time

    foo = lambda: time.sleep(1)
    bar = lambda: time.sleep(2)

    mw = MonoWorker()

    def assert_status(f1, f2, running, waiting, finished):
        assert isinstance(mw.futures[0], Future) is f1
        assert isinstance(mw.futures[1], Future) is f2
        assert is_running(mw.futures[0]) is running
        assert is_running(mw.futures[1]) is waiting
        assert is_finished(mw.futures[0]) is finished
        assert is_finished(mw.futures[1]) is False


# Generated at 2022-06-24 10:11:22.994722
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import wait
    from time import sleep
    from .internal import TextIOWrapper

    with TextIOWrapper("") as f:
        mw = MonoWorker()
        for i in range(10):
            mw.submit(f.write, str(i))
        ready, _ = wait(mw.futures)
        assert len(f.getvalue()) < 10
        f.write("")
        sleep(0.5)
        assert len(f.getvalue()) == 10

# Generated at 2022-06-24 10:11:28.148921
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing.pool import ThreadPool
    # from time import sleep

    def print_n(n):
        print(n)
    mw = MonoWorker()
    for n in range(10):
        mw.submit(print_n, n)
        # sleep(.5)

# Generated at 2022-06-24 10:11:33.287880
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def f(x):
        sleep(0.1)
        return x

    MonoWorker().submit(f, 1).result()
    MonoWorker().submit(f, 1).submit(f, 2).result()
    MonoWorker().submit(f, 1).submit(f, 2).submit(f, 3).result()

# Generated at 2022-06-24 10:11:41.545798
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import concurrent.futures as cf
    with tqdm_auto.tqdm(total=5) as t:
        mw = MonoWorker()
        def w():
            time.sleep(1)
            t.update(1)
        def w_slower():
            time.sleep(2)
            t.update(1)
        mw.submit(w)
        mw.submit(w_slower)
        mw.submit(w_slower)
        mw.submit(w)
        for f in cf.as_completed(mw.futures, 1):
            pass
        mw.submit(w_slower)
        for f in cf.as_completed(mw.futures, 1):
            pass

# Generated at 2022-06-24 10:11:50.052677
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import os
    import sys
    import time

    def test_f(x):
        return x + 1

    x = MonoWorker()
    f1 = x.submit(test_f, 1)
    f2 = x.submit(test_f, 2)
    f3 = x.submit(test_f, 3)
    f4 = x.submit(test_f, 4)
    f5 = x.submit(test_f, 5)
    
    if os.name == "posix":
        ps_command = 'ps -o pid,ppid,cmd,stat -p {}'
    elif os.name == "nt":
        ps_command = 'tasklist /fi "PID eq {}"'
    else:
        raise Exception('Unsupported operating system: {}'.format(os.name))
    
    t

# Generated at 2022-06-24 10:12:00.098549
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import TimeoutError
    mono_worker = MonoWorker()
    # Generate a list of futures
    futures = [mono_worker.submit(sleep, 10, 1)]
    futures.append(mono_worker.submit(sleep, 20, 1))
    futures.append(mono_worker.submit(sleep, 30, 1))
    # Wait for futures to be cancelled by MonoWorker
    for i in range(len(futures)):
        try:
            result = futures[i].result(timeout=1)
        except TimeoutError:
            assert futures[i].done()
            assert futures[i].cancelled()
        except Exception:
            assert False
        else:
            assert False
    # Return last future not cancelled by MonoWorker