

# Generated at 2022-06-24 10:02:08.587140
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock, Semaphore
    from concurrent.futures import wait
    from ..utils import _term_move_up
    from .printer import tqdm_printer

    # Copy last lines of tqdm to avoid interference with normal printing
    f = tqdm_printer._file
    tqdm_printer.off()
    print('First', file=f)
    print('Second', file=f)
    tqdm_printer.on()
    print('Third', file=f)

    # Create mock printer
    last_line_lock = Lock()
    last_line_sem = Semaphore(value=0)
    last_line = ''
    def write_mock(s):
        with last_line_lock:
            nonlocal last_line
            last_line

# Generated at 2022-06-24 10:02:10.632549
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Test for constructor of MonoWorker.
    """
    pass


# Generated at 2022-06-24 10:02:19.762948
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading
    from multiprocessing import Event

    def f(e):
        e.wait()
        return time.time()
    e = Event()
    e.clear()
    mw = MonoWorker()
    start_time = time.time()
    f1 = mw.submit(f, e)
    f2 = mw.submit(f, e)
    f3 = mw.submit(f, e)
    #self.futures = deque([f1, f2, f3], 3)
    assert len(mw.futures) == mw.futures.maxlen
    assert mw.futures[0].result() == start_time
    assert not f1.done()
    assert not f2.done()
    assert f3.done()

# Generated at 2022-06-24 10:02:26.497358
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from tqdm import tqdm

    # Unit tests
    from .tests import RandomByteStream

    m = MonoWorker()
    for _ in tqdm(range(10), desc='test'):
        m.submit(sleep, 0.01)

    # Test with interrupt
    rbs = RandomByteStream()
    m = MonoWorker()
    for _ in tqdm(range(10), desc='test-interrupt'):
        m.submit(rbs.read, 5)

# Generated at 2022-06-24 10:02:27.699744
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()



# Generated at 2022-06-24 10:02:29.000247
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of MonoWorker class"""
    MonoWorker()

# Generated at 2022-06-24 10:02:37.424814
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    timed_echo = lambda x: time.sleep(0.5) and tqdm_auto.write(x)
    old_write = tqdm_auto.write
    cnt = []
    try:
        tqdm_auto.write = lambda line: cnt.append(line)
        w = MonoWorker()
        w.submit(timed_echo, 1)
        w.submit(timed_echo, 2)
        assert cnt == [1]
        time.sleep(0.6)  # noqa
        assert cnt == [1, 2]
        w.submit(timed_echo, 3)
        w.submit(timed_echo, 4)
        assert cnt == [1, 2, 3]
    finally:
        tqdm_auto.write = old_write

# Generated at 2022-06-24 10:02:43.223454
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .tests import _is_expected
    from time import sleep
    from multiprocessing import cpu_count
    from concurrent.futures import TimeoutError

    # Test for MonoWorker.submit with timeout
    worker = MonoWorker()

    # Slow running task
    worker.submit(sleep, 1, 1)

    # Test running task with submission to the waiting
    assert _is_expected(worker.submit(sleep, 1, 1), expected_exc=TimeoutError,
                        args=(1,))

    # Test running task with deletion
    worker.submit(sleep, 1, 1)  # This one is not submitted (deleted)
    worker.submit(sleep, 2, 1)  # This one is the new waiting

    # Test waiting task with submission to the running

# Generated at 2022-06-24 10:02:54.254303
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    def random_sleep(i):
        time.sleep(random.random())
        return i

    #noinspection PyUnusedLocal
    def spin_wait(i):
        while True:
            pass

    #noinspection PyUnusedLocal
    def always_speed_limit(i):
        time.sleep(1)
        return i

    mw = MonoWorker()
    res = []

    mw.submit(random_sleep, 0)
    res.append(mw.futures[-1].result())

    mw.submit(random_sleep, 1)
    res.append(mw.futures[-1].result())

    mw.submit(random_sleep, 2)
    res.append(mw.futures[-1].result())

   

# Generated at 2022-06-24 10:02:57.578134
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .test_examples import test_MonoWorker
    test_MonoWorker(MonoWorker)  # if possible
MonoWorker().submit(test_MonoWorker)

# Generated at 2022-06-24 10:02:59.179851
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # TODO: fill in
    pass



# Generated at 2022-06-24 10:03:09.886891
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures as futures

    def f(x, sleep=0):
        print('f', x)
        time.sleep(sleep)
        print('g', x)
        return x

    worker = MonoWorker()
    assert len(worker.futures) == 0

    # first task submitted
    task_0 = worker.submit(f, 0, sleep=2)
    assert len(worker.futures) == 1
    assert task_0.result() == 0

    # second task submitted
    task_1 = worker.submit(f, 1, sleep=1)
    assert len(worker.futures) == 2
    with tqdm_auto.tqdm(leave=True, desc='task_1') as t:
        while not task_1.done():
            t.update

# Generated at 2022-06-24 10:03:19.268488
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Constructor of class MonoWorker"""
    from threading import Lock, Thread
    from time import sleep
    from .utils import _range

    e = MonoWorker()

    def long_task():
        sleep(0.1)
        return 42

    def short_task():
        sleep(0.01)
        return 42

    short = short_task
    long = long_task

    # No race condition
    assert e.submit(short).result() == 42
    assert e.submit(short).result() == 42
    assert e.submit(short).result() == 42

    # No race condition
    assert e.submit(long).result() == 42
    assert e.submit(long).result() == 42
    assert e.submit(long).result() == 42

    # But only one thread is used

# Generated at 2022-06-24 10:03:28.112034
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import os
    import concurrent.futures

    mworkers = MonoWorker()
    assert not mworkers.pool._shutdown

    def _test_func(sleep_time):
        time.sleep(sleep_time)
        return 1

    def _test_func_valueerror(sleep_time):
        time.sleep(sleep_time)
        raise ValueError("Testing ValueError in _test_func_valueerror")

    def _test_func_oserror(sleep_time):
        time.sleep(sleep_time)
        raise OSError("Testing OSError in _test_func_oserror")

    def _test_func_good(sleep_time):
        time.sleep(sleep_time)
        return 2

    def _test_func_exception(sleep_time):
        time.sleep

# Generated at 2022-06-24 10:03:38.684292
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()
    assert not mw.futures
    assert mw.futures.maxlen == 2  # default
    mw.futures.maxlen = 7
    assert mw.futures.maxlen == 7
    for i in range(mw.futures.maxlen):
        mw.submit(time.sleep, i)
    assert len(mw.futures) == mw.futures.maxlen
    # cancel the last added
    assert not mw.futures[-1].done()
    mw.futures[-1].cancel()
    # test deque removal
    mw.submit(time.sleep, i + 1)
    assert len(mw.futures) == mw.futures.max

# Generated at 2022-06-24 10:03:45.003452
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func(i):
        time.sleep(5 - i)
        return i

    mw = MonoWorker()
    for i in range(5):
        future = mw.submit(func, i)
        print(future.result())
    # The first two calls would take 5s, and the third would take 4s
    # The others are cancelled
    # If this works, the expected output is 01234

# Generated at 2022-06-24 10:03:54.613381
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from unittest.mock import patch

    class SleepyMonoWorker(MonoWorker):
        def submit(self, func, *args, **kwargs):
            waiting = super(SleepyMonoWorker, self).submit(
                func, *args, **kwargs)
            if len(self.futures) > 1:
                sleep(0.1)  # introduce race condition
            return waiting

    def func(arg):
        return arg

    with patch('sys.stdout') as mock_stdout:
        worker = SleepyMonoWorker()
        result1 = worker.submit(func, 1)
        result2 = worker.submit(func, 2)
        result3 = worker.submit(func, 3)
        assert result1.result() == 2

# Generated at 2022-06-24 10:04:03.720141
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .tests_tqdm import test_async_print
    m = MonoWorker()

    assert (len(m.futures) == 0)
    assert (m.submit(test_async_print, "task 1") ==
            m.submit(test_async_print, "task 2"))
    assert (len(m.futures) == 1)
    assert (m.submit(test_async_print, "task 3") ==
            m.submit(test_async_print, "task 4"))
    assert (len(m.futures) == 1)
    m.futures[0].result()
    assert (m.submit(test_async_print, "task 5") ==
            m.submit(test_async_print, "task 6"))

# Generated at 2022-06-24 10:04:05.095061
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert len(worker.futures) == 0


# Generated at 2022-06-24 10:04:10.421962
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from random import random

    def worker(i):
        sleep(1)
        return i

    with MonoWorker() as mw:
        for i in range(5):
            future = mw.submit(worker, i)
            if future is not None:
                tqdm_auto.write(str(future.result()))
        for i in range(5):
            future = mw.submit(worker, i)
            if future is not None:
                tqdm_auto.write(str(future.result()))

# Generated at 2022-06-24 10:04:17.111351
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from subprocess import Popen, PIPE
    from signal import SIGINT, SIGTERM

    def hello(name):
        """Hello function."""
        sleep(1)
        return "Hello, %s!" % name

    def world(name):
        """World function."""
        sleep(2)
        return "World, %s!" % name

    # Call functions in the background (in a different thread)
    mw = MonoWorker()
    future = mw.submit(hello, 'Casper')
    future = mw.submit(world, 'Claus')

    # Print result of the most recent submitted task
    print(future.result())

    # Crack the kernel by spawning a cat that we can't kill
    proc = Popen("cat", stdin=PIPE)
    proc.wait()

# Generated at 2022-06-24 10:04:20.793782
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():  # pragma: no cover
    import random
    import time

    random.seed(0)

    def worker(item):
        # Simulate time-consuming processing
        time.sleep(random.uniform(1, 5))
        return item

    N = range(10)
    mw = MonoWorker()
    for i in N:
        mw.submit(worker, i)
    for i in list(N):
        N.remove(mw.futures.popleft().result())
    assert not N

# Generated at 2022-06-24 10:04:30.513228
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import fmt_sizeof
    from .t_job import SlowFile
    from .t_unit_test import test_MonoWorker_submit

    def test_submit(tc, cfg):
        keep_file = SlowFile(cfg.file_name, cfg.file_size, cfg.step)
        keep_file.open()
        keep_file.touch()
        keep_file.close()
        keep_file.append(cfg.step)
        tc.submit(keep_file.read, cfg.read_size)
        keep_file.append(cfg.step)
        tc.submit(keep_file.read, cfg.read_size)
        keep_file.append(cfg.step)
        tc.submit(keep_file.read, cfg.read_size)

# Generated at 2022-06-24 10:04:38.415462
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert MonoWorker
    assert MonoWorker()
    assert MonoWorker().pool
    assert MonoWorker().pool._work_queue is None
    assert MonoWorker().pool._threads
    assert MonoWorker().pool._max_workers == 1
    assert MonoWorker().pool._work_ids
    assert MonoWorker().pool._call_queue
    assert MonoWorker().pool._result_queue
    assert MonoWorker().pool._shutdown
    assert MonoWorker().pool._broken
    assert MonoWorker().pool._shutdown_lock

# Generated at 2022-06-24 10:04:40.400179
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mono_worker = MonoWorker()
    assert mono_worker.pool
    assert mono_worker.futures == deque([], 2)

# Generated at 2022-06-24 10:04:46.705050
# Unit test for constructor of class MonoWorker
def test_MonoWorker():  # pragma: no cover
    from time import sleep
    from random import seed, uniform

    def p(*args):
        """Print args"""
        for arg in args:
            print(str(arg))
        print()

    def f(x):
        """Sleep random time and return int"""
        sleep(uniform(0, x))
        return int(x)

    seed(42)
    p("Testing MonoWorker()...")
    mw = MonoWorker()
    p("Submitting f(1.5)...")
    future_1_5 = mw.submit(f, 1.5)
    p("Submitting f(2.5)...")
    future_2_5 = mw.submit(f, 2.5)
    p("Submitting f(3.5)...")
    future_3_

# Generated at 2022-06-24 10:05:00.408377
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():  # pragma: no cover
    from inspect import getcallargs
    from multiprocessing.pool import ThreadPool
    from threading import Event
    from time import sleep

    def test_func(*args, **kwargs):
        sleep(.5)
        return args, kwargs

    N_TESTS = 5

    # test MonoWorker
    tqdm_auto.write('Testing MonoWorker')
    mw = MonoWorker()
    n = 0
    while n < N_TESTS:
        n += 1
        tqdm_auto.write('{}:'.format(n))
        sleep(.5)  # wait for any running tasks to finish
        assert len(mw.futures) <= 1
        args = (n,)
        kwargs = {"kw"+str(n): n}


# Generated at 2022-06-24 10:05:10.054904
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from random import randrange
    from subprocess import Popen, PIPE
    from threading import Thread

    def task1(arg):
        return None

    def task2(arg):
        return None

    def test():
        worker = MonoWorker()
        for i in range(10):
            worker.submit(task1, i)
        for i in range(5):
            worker.submit(task1, i)
        for i in range(5, 10):
            worker.submit(task2, i)
        time.sleep(0.1)
        assert len(worker.futures) == 1

    def test2():
        worker = MonoWorker()
        for i in range(5):
            worker.submit(task1, i)
        time.sleep(0.1)
        assert len

# Generated at 2022-06-24 10:05:17.923703
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker."""
    from time import sleep
    from .utils import test_task_executor

    def printer(s):
        with test_task_executor() as w:
            w.submit(lambda: print(s))

    printer("wait")
    sleep(2)
    printer("\nprint")
    sleep(2)
    printer("\nwait")
    sleep(2)
    printer("\nprint")

# Generated at 2022-06-24 10:05:29.668098
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import time
    import threading

    def report_done(futures):
        done_list = []
        for f in futures:
            try:
                done_list.append(f.result())
            except Exception:
                done_list.append(False)
        for i, fut in enumerate(futures):
            try:
                if not fut.done():
                    done_list[i] = False
                    break
            except Exception:
                done_list[i] = False
        done_list.reverse()
        tqdm_auto.write("Done: {}".format(done_list))

    def report(msg, *args):
        tqdm_auto.write(msg.format(*args))


# Generated at 2022-06-24 10:05:35.072263
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys

    mw = MonoWorker()

    i = 0
    while i < 2:
        mw.submit(time.sleep, 1)
        i += 1
        time.sleep(0.1)

    # submit one more job
    mw.submit(time.sleep, 1)

    # test job size - it should be 1
    assert len(mw.futures) == 1
    sys.stderr.write('\n')

# Generated at 2022-06-24 10:05:43.966637
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Run all interactive test cases."""
    from time import sleep

    tqdm_auto.write('Testing MonoWorker')
    mono_worker = MonoWorker()

    # test 1
    def test_mono_worker_1():
        mono_worker.submit(sleep, 0.1)
        mono_worker.submit(sleep, 0.1)
        mono_worker.submit(sleep, 0.1)

    def test_mono_worker_2():
        mono_worker.submit(sleep, 0.1)

    test_mono_worker_1()
    test_mono_worker_2()

    # test 2
    def test_mono_worker_3():
        mono_worker.submit(sleep, 0.1)

    test_mono_worker_3()
    test_mono_worker_2

# Generated at 2022-06-24 10:05:53.833648
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    def wait(sec):
        sleep(sec)
        return "slept for " + str(sec)

    worker = MonoWorker()
    r1 = worker.submit(wait, 0.5)
    sleep(0.1)
    r2 = worker.submit(wait, 1.0)
    sleep(0.3)
    r3 = worker.submit(wait, 2.0)
    sleep(0.7)
    r4 = worker.submit(wait, 3.0)
    assert r1.result(3) == "slept for 0.5"
    assert r2.result(3) == "slept for 1.0"
    assert r3.result(3) == "slept for 2.0"
    assert r4.result(3) == "slept for 3.0"

# Generated at 2022-06-24 10:06:02.084973
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .utils import r
    from .utils import r_list

    def f(x, d):
        try:
            sleep(d * .1)
        except Exception:
            pass
        return x * x

    n = 5
    worker = MonoWorker()
    assert len(worker.futures) == 0
    for i in range(n):
        worker.submit(r, 1, 2)
        assert len(worker.futures) == 1
        assert worker.futures[0].done() is False
    while len(worker.futures) == 1 and not worker.futures[0].done():
        sleep(r(.1))

    assert len(worker.futures) == 1
    assert worker.futures[0].done()


# Generated at 2022-06-24 10:06:10.337190
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import time
    import numpy

    numpy.random.seed(0)

    def f(i=0):
        return numpy.random.rand()

    def run_MonoWorker_submit(n=None):
        n = n or numpy.random.randint(1, 8)
        # numpy.random.uniform(1, 8)
        tic = time()
        worker = MonoWorker()
        for i in range(n):
            future = worker.submit(f, i)
            # future = worker.submit(numpy.random.rand)
            future.result()
        toc = time()
        return toc

    def run_ThreadPoolExecutor_submit(n=None):
        n = n or numpy.random.randint(1, 8)
        # numpy.

# Generated at 2022-06-24 10:06:14.805655
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()

    def task(n, i):
        import time
        time.sleep(n / 1000.0)
        return n + i

    import random

    for i in range(8):
        n = random.randint(1, 3)
        tqdm_auto.write(str(n))
        future = mw.submit(task, n, i)

# Generated at 2022-06-24 10:06:24.432197
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()

    def square(x):
        time.sleep(3)
        return x * x

    def prime(x):
        y = 1
        while True:
            if x % y == 0:
                return y
            else:
                y = y + 1

    mw.submit(square, 2)
    mw.submit(square, 3)
    mw.submit(square, 4)
    assert (mw.futures[0].result() == 25)

    mw.submit(square, 5)
    mw.submit(square, 6)
    mw.submit(prime, 10)
    assert (mw.futures[0].result() == 25)

# Generated at 2022-06-24 10:06:34.965398
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from unittest import TestCase

    def f(sleep):
        time.sleep(sleep)
        return time.time()

    class MonoWorkerTest(MonoWorker, TestCase):
        def setUp(self):
            self.sleep = 0
            super(MonoWorkerTest, self).__init__()

        def submit(self, sleep):
            return super(MonoWorkerTest, self).submit(f, sleep)

        def assert_future(self, expected_sleep):
            running = self.futures.popleft()
            assert not running.done()
            self.assertAlmostEqual(running.result(),
                                   time.time() + expected_sleep)
            assert running.done()
            assert not self.futures

    t = MonoWorkerTest()


# Generated at 2022-06-24 10:06:38.306570
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    def dummy_func():
        """Dummy function"""
        pass

    mono_worker = MonoWorker()
    mono_worker.submit(dummy_func)

# Generated at 2022-06-24 10:06:40.033082
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    class C(MonoWorker):
        def __init__(self):
            super(C, self).__init__()
            self.test = 'a'

    c = C()
    assert c
    assert c.test == 'a'



# Generated at 2022-06-24 10:06:47.518294
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from itertools import chain
    from time import sleep
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from ..utils import _term_move_up as up

    def worker(t):
        """Some blocked worker to be submitted"""
        sleep(t)
        return t

    # --- Testing MonoWorker ---
    workers = MonoWorker()
    workers.pool = ThreadPoolExecutor(max_workers=2)

    for t in tqdm_auto(range(4)):
        workers.submit(worker, t)

    if hasattr(workers.futures[0], 'exception'):
        raise workers.futures[0].exception()

    res = list(workers.futures)
    # --- Testing ThreadPoolExecutor ---

# Generated at 2022-06-24 10:06:55.317371
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    q = MonoWorker()
    f1 = q.submit(lambda: 1)
    f2 = q.submit(lambda: 2)
    f3 = q.submit(lambda: 3)
    f4 = q.submit(lambda: 4)
    assert f1 is None
    assert f2 is None
    assert f3.result() == 3
    assert f4.result() == 4


# Generated at 2022-06-24 10:07:05.469096
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    :return: True if passed
    :rtype: bool

    >>> test_MonoWorker()
    True
    """
    from time import sleep
    from threading import current_thread

    def worker(sleep_time):
        sleep(sleep_time)
        tqdm_auto.write("Running thread {} was here!"
                        .format(current_thread()))

    w = MonoWorker()

    c = w.submit(worker, 5)
    sleep(2)
    assert not c.done(), "First worker should not be done"
    assert w._waiting_task.done(), "Long task should have been cancelled"
    assert w.futures[-1] is c, "Running task should not have been cancelled"

# Generated at 2022-06-24 10:07:11.282652
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import wait
    from time import sleep

    def myprint(message):
        sleep(0.1)  # simulate long operation
        tqdm_auto.write("{0}".format(message))

    worker = MonoWorker()  # instantiate
    f1 = worker.submit(myprint, "1")  # submit 1st task
    f2 = worker.submit(myprint, "2")  # submit 2nd task (replace 1st task)
    f3 = worker.submit(myprint, "3")  # submit 3rd task (replace 2nd task)
    wait([f2, f3])  # wait for 2nd and 3rd task, but not 1st task
    tqdm_auto.write("done")  # done

# Generated at 2022-06-24 10:07:20.438455
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def good_worker(n):
        return n

    def bad_worker(n):
        raise ValueError("bad worker")

    m = MonoWorker()

    t = m.submit(good_worker, 1)
    assert t.result() == 1

    t = m.submit(bad_worker, 2)
    assert t is None

    t = m.submit(good_worker, 3)
    assert t.result() == 3

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:07:26.257688
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from concurrent.futures import wait
    mw = MonoWorker()
    sleep1 = lambda: sleep(1)
    sleep2 = lambda: sleep(2)
    mw.submit(sleep1)
    mw.submit(sleep2)
    mw.submit(sleep1)
    wait(mw.futures)

# Generated at 2022-06-24 10:07:34.758827
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from collections import namedtuple
    from concurrent.futures import TimeoutError
    from ..utils import _decode_str
    from ..utils import _term_move_up
    from ..utils import _range

    await_time = 0.001
    running_time = 0.01
    done_time = 0.00005
    num_tasks = 4

    def func(i):  # pragma: no cover
        sleep(running_time)
        return i

    def func_err(i):  # pragma: no cover
        sleep(running_time)
        raise Exception(i)

    def mock_tqdm(obj, i, msg=''):  # pragma: no cover
        obj.write(_decode_str(str(i)))
        sleep(done_time)
        obj

# Generated at 2022-06-24 10:07:42.339747
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test: method MonoWorker.submit"""
    from time import sleep

    # TypeError handling
    try:
        MonoWorker().submit(1)
    except Exception as exception:
        assert type(exception) == TypeError, "TypeError Exception should occur"
    else:
        assert False, "No Exceptions occured"

    import sys
    # Program OutPut handling
    try:
        MonoWorker().submit(sys.exit, 1)
    except Exception as exception:
        assert type(exception) == SystemExit, "SystemExit Exception should occur"
    else:
        assert False, "No Exceptions occured"

    # Checking running order
    m = MonoWorker()
    future1 = m.submit(sleep, 0.1)
    sleep(0.05)

# Generated at 2022-06-24 10:07:53.207481
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import sizeof_fmt
    from ..utils import _supports_unicode
    import string
    import os
    import operator
    import sys
    import tempfile
    from textwrap import dedent

    def check_worker():
        mw = MonoWorker()
        d = tempfile.mkdtemp()
        os.chdir(d)

# Generated at 2022-06-24 10:08:03.436123
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import concurrent.futures
    import time

    def wait(sec):
        time.sleep(sec)
        return sec

    pool = MonoWorker()
    assert isinstance(pool, MonoWorker)
    assert isinstance(pool.pool, concurrent.futures.ThreadPoolExecutor)
    assert len(pool.futures) == 0
    assert pool.futures.maxlen == 2

    with tqdm_auto.tqdm(disable=True) as t:
        for i in range(4):
            pool.submit(wait, i)
            t.write('\t'.join(list(map(str, pool.futures))))

# Generated at 2022-06-24 10:08:04.457868
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()

# Generated at 2022-06-24 10:08:10.824540
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    workers = MonoWorker()
    workers.submit(lambda: 'a')
    assert workers.futures[0].result() == 'a'
    workers.submit(lambda: 'b')
    assert workers.futures[0].result() == 'b'
    workers.submit(lambda: 'c')
    assert workers.futures[0].result() in ('b', 'c')
    workers.submit(lambda: 'd')
    assert workers.futures[0].result() in ('c', 'd')

# Generated at 2022-06-24 10:08:20.674912
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def throw(exception):
        raise exception
    # test single exception type
    mw = MonoWorker()
    mw.submit(throw, Exception('first'))
    mw.submit(throw, Exception('second'))
    exceptions = []
    for f in mw.futures:
        try:
            f.result(timeout=1)
        except Exception as e:
            exceptions.append(e)
    assert exceptions == [Exception('first'), Exception('second')]
    # test multiple exception types
    mw = MonoWorker()
    mw.submit(throw, Exception('first'))
    mw.submit(throw, RuntimeError('second'))
    exceptions = []

# Generated at 2022-06-24 10:08:24.142889
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from . import _test_MonoWorker_submit
    _test_MonoWorker_submit(MonoWorker)

# Generated at 2022-06-24 10:08:29.479673
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import queue
    def f0(s, q):
        time.sleep(s)
        q.put(s)
    q = queue.Queue()
    mw = MonoWorker()
    f0_0 = mw.submit(f0, 0.1, q)
    time.sleep(0.05)
    f0_1 = mw.submit(f0, 0.1, q)
    f0_0.result()
    f0_1.result()
    assert q.get() == 0.1
    assert q.get() == 0.1


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:08:31.809818
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    a = MonoWorker()


# Generated at 2022-06-24 10:08:34.065324
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Testing constructor of class MonoWorker"""
    mon = MonoWorker()
    assert mon.__class__.__name__ == 'MonoWorker'


# Generated at 2022-06-24 10:08:41.877947
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    from sys import platform as _platform
    if _platform != "win32":
        return

    import time
    import threading

    def thread_function():
        """function that prints out a message"""
        print("thread %s: starting" % threading.current_thread().name)
        time.sleep(5)
        print("thread %s: finishing" % threading.current_thread().name)

    # define workers
    mono_worker = MonoWorker()

    # submit 4 jobs to the mono_worker
    jobs = []
    for i in range(4):
        jobs.append(mono_worker.submit(thread_function))

    # wait for all threads to finish

# Generated at 2022-06-24 10:08:52.195935
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time
    import unittest

    class MonoWorkerTest(unittest.TestCase):
        def setUp(self):
            self.mw = MonoWorker()
            self.info = []

        def a_func(self):
            self.info.append(('begin', threading.current_thread()))
            time.sleep(1)
            self.info.append('end')

        def b_func(self):
            self.info.append(('begin', threading.current_thread()))
            time.sleep(.5)
            self.info.append('end')

        def test_submit(self):
            # Initial execution
            t0 = time.time()
            f1 = self.mw.submit(self.a_func)

# Generated at 2022-06-24 10:09:01.651791
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from sys import stdout
    from threading import Thread
    from unittest import TestCase

    # Higher value => more waiting, but less running
    # (up to ~2000)
    # (lower value => same running, but more waiting)
    N_SLEEP = 500

    # Higher value => more waiting, but less running
    # (up to ~2000)
    # (lower value => same running, but more waiting)
    N_PAUSE = 150

    class TestSubmit(TestCase):
        def setUp(self):
            self.w = w = MonoWorker()
            self.running = deque(maxlen=2)
            self.waiting = deque(maxlen=2)

        def record(self):
            self.running.append(1)

# Generated at 2022-06-24 10:09:06.673911
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    mw = MonoWorker()
    sleep = lambda: sleep(0.1)

    def mult(a, b):
        """Simple multiplicator."""
        sleep()
        return a * b

    def div(a, b):
        """Simple division."""
        sleep()
        return a / b

    f1 = mw.submit(mult, 1, 2)
    f2 = mw.submit(mult, 3, 4)
    f3 = mw.submit(div, 4, 2)
    sleep()
    assert f1.done()
    assert f2.done()
    assert not f3.done()
    assert f1.result() == 1 * 2, "f1 result not as expected"
    assert f2.result() == 3 * 4, "f2 result not as expected"


# Generated at 2022-06-24 10:09:13.752664
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from sys import stdout
    from contextlib import closing
    from traceback import format_exc

    def bar(x):
        stdout.write("bar %d" % x)
        stdout.flush()
        sleep(1.5 - x / 10)
        stdout.write("\b \b" * len("bar %d" % x))
        stdout.flush()

    with closing(MonoWorker()) as p:
        f = p.submit(bar, 1)
        sleep(0.5)
        f = p.submit(bar, 2)
        sleep(0.5)
        f = p.submit(bar, 3)
        sleep(0.5)
        f = p.submit(bar, 4)

# Generated at 2022-06-24 10:09:23.099579
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def task(x, t=0.1):
        time.sleep(t)
        return x

    mw = MonoWorker()
    mw.submit(task, 0, t=0.3)
    mw.submit(task, 1, t=0.1)
    mw.submit(task, 2, t=0.2)
    assert mw.futures[0].result() == 2
    assert mw.futures[1].result() == 1
    assert mw.submit(task, 3, t=0.2).result() == 3
    assert mw.submit(task, 4, t=0.1).result() == 4

# Generated at 2022-06-24 10:09:32.570262
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from nose.tools import timed
    from time import sleep
    from concurrent.futures import wait, as_completed

    class WWait(Exception):
        pass

    def function():
        sleep(0.05)
        return 'done'

    def contest(func, itr=None, sec=0.3, timeout=None):
        if itr is None:
            itr = range(int(2 * sec / 0.05))
        mw = MonoWorker()
        futures = []
        if timeout is not None:
            timeout = timed(timeout)
        for _ in itr:
            if timeout is not None:
                timeout(futures.append(func()))
            else:
                futures.append(func())
        try:
            wait(futures)
        except WWait:
            pass

   

# Generated at 2022-06-24 10:09:42.481478
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, random
    from time import sleep
    from threading import Thread
    from Queue import Queue
    from subprocess import PIPE, Popen


# Generated at 2022-06-24 10:09:51.958384
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import CancelledError
    from .hanoi import hanoi

    def wait(n_secs):
        sleep(n_secs)
        return n_secs

    mw = MonoWorker()
    for _ in range(4):
        mw.submit(wait, 1)  # should run only once
        print("test_MonoWorker_submit() passed")

    print("Testing cancel...")
    cancel_tasks = True
    future_towers = mw.submit(hanoi, 3, 'a', 'b', 'c')
    while cancel_tasks:  # wait forever but filling pipes with tasks
        mw.submit(wait, 100)

# Generated at 2022-06-24 10:09:57.490116
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import random

    def func():
        time.sleep(1 + random() * 0.1)
        return "func"

    worker = MonoWorker()
    try:
        worker.submit(func)
        time.sleep(0.1)
        worker.submit(func)
        time.sleep(0.1)
        worker.submit(func)
        time.sleep(0.1)
        worker.submit(func)
        time.sleep(1.2)
    except:
        print("ERROR: func test")
    assert worker.futures[0].done()
    assert not worker.futures[0].cancelled()
    assert worker.futures[1].done()
    assert not worker.futures[1].cancelled()

# Generated at 2022-06-24 10:10:07.241446
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:10:16.652419
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker"""
    # Imports
    import gc
    import time
    import sys
    if sys.version_info < (3, 3):
        raise unittest.SkipTest("MonoWorker can't be tested on Python older than 3.3")
    # Workers
    mw = MonoWorker()
    mw.submit(time.sleep, 10)
    # Invoking the garbage collector to ensure that the async def function doesn't block
    gc.collect()
    # Assertions
    assert mw

# Test class MonoWorker
if __name__ == "__main__":
    try:
        from unittest import mock
        from unittest import skipIf
        from unittest import TestCase
    except ImportError:
        import mock
        from unittest2 import skipIf

# Generated at 2022-06-24 10:10:24.609740
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # import os, time
    import unittest
    from concurrent.futures import TimeoutError

    def take_time(timeout=None):
        """Perform a long operation"""
        # if os.name == "nt":  # No SIGALRM on Windows
        #     time.sleep(timeout)
        # else:
        #     signal.alarm(timeout)
        #     try:
        #         signal.pause()  # Wait for signal
        #     except KeyboardInterrupt:
        #         raise TimeoutError()
        time.sleep(timeout)

    class MonoWorkerTest(unittest.TestCase):
        """Test for MonoWorker"""

        def setUp(self):
            """Create the MonoWorker"""
            self.mw = MonoWorker()


# Generated at 2022-06-24 10:10:30.713032
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> def foo(*args, **kwargs):
    ...     return (args, kwargs)
    >>> w = MonoWorker()
    >>> w.submit(foo, (), {}).result()
    ((), {})
    >>> w.submit(foo, (), {'a': 1}).result()
    ((), {'a': 1})
    >>> w.submit(foo, (1,), {}).result()
    ((1,), {})
    >>> w.submit(foo, (), {}).result()  # test if task is runnable
    ((), {})
    >>> w.submit(foo, (), {}).result()
    ((), {})
    >>> w.submit(foo, (), {}).result()
    ((), {})
    """
    pass

# Generated at 2022-06-24 10:10:40.150526
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys
    import threading
    import traceback

    def wlog(text):
        print("  {0}".format(text))

    def _test_MonoWorker(n_threads=20, log_progress=False):
        global _test_MonoWorker_results

# Generated at 2022-06-24 10:10:48.869812
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from multiprocessing import Pool

    mw = MonoWorker()
    test_futures = []
    for i in range(3):
        test_futures.append(mw.submit(time.sleep, 1))
        time.sleep(0.1)
    if test_futures[0].done():
        raise RuntimeError("task one should not be done")
    if not test_futures[1].done():
        raise RuntimeError("task two should be done")
    if not test_futures[2].done():
        raise RuntimeError("task three should be done")

    # Test with a class that can't be pickled
    mw = MonoWorker()
    test_futures = []

# Generated at 2022-06-24 10:10:57.267754
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    m = MonoWorker()

    def f(delay):
        import time
        time.sleep(delay)
        return delay

    # order of submit doesn't matter
    m.submit(f, 10)
    f1 = m.submit(f, 5)
    f2 = m.submit(f, 1)

    # order of results is guaranteed to be order of submit
    assert f2.result() == 1
    assert f1.result() == 5

    # submit replaces waiting task
    m.submit(f, 100)
    assert m.futures == deque([f2], 2)

if __name__ == '__main__':
    test_MonoWorker_submit()
    print('Test successful')

# Generated at 2022-06-24 10:11:06.715621
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import sys
    import random

    def rec(x):
        start.wait()  # all wait starting
        time.sleep(.01 + random.random() / 10)  # to have different outputs
        return x[::-1]  # reversed

    mw = MonoWorker()
    mw.submit(rec, 'a')
    start = threading.Event()
    for x in (range(100)):
        mw.submit(rec, str(x))
    start.set()

    for tv in tqdm_auto.tqdm(mw.futures):
        sys.stdout.write(tv.result() + '\n')
    print("PASSED")


# Generated at 2022-06-24 10:11:16.569247
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import time
    import unittest

    class TestMonoWorkerSubmit(unittest.TestCase):
        def test_MonoWorker_submit(self):
            from ..utils import _range
            from itertools import count, compress

            def _range_lazy(start, stop, step):
                for n in count(0):
                    if n * step >= stop:
                        break
                    yield start + n * step

            def range_lazy(start_stop_step):
                return _range_lazy(*start_stop_step)

            # test that MonoWorker.submit() replaces waiting (not running) tasks

# Generated at 2022-06-24 10:11:17.340873
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()



# Generated at 2022-06-24 10:11:27.967949
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint
    from threading import Event
    niter = 10
    nwaiting_list = []
    def task(niter, waiting_timeout, evt):
        evt.wait(waiting_timeout)
        sleep(randint(1, 4))
    evt_list = [Event() for _ in range(niter)]
    waiting_timeout_list = [randint(1, 4) for _ in range(niter)]
    worker = MonoWorker()
    for i in range(niter):
        worker.submit(task, niter, waiting_timeout_list[i], evt_list[i])
        nwaiting = len([f for f in worker.futures if f.running()])
        nwaiting_list.append(nwaiting)
        assert n

# Generated at 2022-06-24 10:11:33.925384
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    # Create a mono worker
    mono_worker = MonoWorker()
    # Submit first task
    mono_worker.submit(
        time.sleep, 1)
    # Submit second task but actually this task is cancelled
    mono_worker.submit(
        time.sleep, 2)
    # Submit third task, this task can be submitted successfully
    mono_worker.submit(
        time.sleep, 3)

# Generated at 2022-06-24 10:11:35.380481
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    MonoWorker()

# Generated at 2022-06-24 10:11:48.072535
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    from multiprocessing import Process, Queue
    from threading import Thread

    def worker(q):
        def subworker(q):
            q.put(get_pid())  # get pid
            time.sleep(random.randrange(0, 5))
            q.put(True)  # done
        mw = MonoWorker()
        for _ in range(10):
            mw.submit(subworker, q)
        q.put(None)  # no more

    def get_pid():
        return Process.current_process().pid

    q = Queue()
    p = Process(target=worker, args=(q,))
    p.start()
    pids = []
    while True:
        val = q.get()
        if val is None:
            break
       

# Generated at 2022-06-24 10:12:00.047442
# Unit test for method submit of class MonoWorker