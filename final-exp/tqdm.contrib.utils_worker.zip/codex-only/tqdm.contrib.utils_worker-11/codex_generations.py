

# Generated at 2022-06-24 10:02:08.176472
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> import time
    >>> mw = MonoWorker()
    >>> def sleep(duration):
    ...     time.sleep(duration)
    ...     return duration
    >>> mw.submit(sleep, 0.2)
    >>> mw.submit(sleep, 0.1)
    >>> mw.submit(sleep, 0.3)
    >>> time.sleep(0.25)
    >>> assert len(mw.futures) == 1
    >>> mw.futures[0].result()
    0.3
    """
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 10:02:16.018920
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert not mw.futures
    mw.submit(lambda: 3)
    assert len(mw.futures) == 1
    assert mw.futures
    mw.submit(lambda: 2)
    assert len(mw.futures) == 1
    assert not mw.futures[0].done()
    assert mw.futures[0].result() == 2


if __name__ == '__main__':  # pragma: no cover
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:02:19.943201
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func(i, j):
        print('{} {}\n'.format(i, j))
        time.sleep(1)

    mw = MonoWorker()

    def test_submit(i, j):
        mw.submit(func, i, j)

    mw.submit(func, 1, 2)
    test_submit(2, 3)
    test_submit(3, 4)



# Generated at 2022-06-24 10:02:29.685734
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=protected-access
    from time import sleep
    from unittest.case import TestCase

    # Insert running task
    mw = MonoWorker()
    running = mw.submit(sleep, 2); assert len(mw.futures) == 1
    assert not running.done(); running.cancel(); assert running.done()
    assert len(mw.futures) == 0; mw.pool._threads.clear()

    # Insert waiting task
    mw = MonoWorker()
    running = mw.submit(sleep, 2)
    waiting = mw.submit(sleep, 2)
    assert len(mw.futures) == 2; assert not running.done(); assert not waiting.done()

    # Insert other waiting task, i.e. replace

# Generated at 2022-06-24 10:02:38.139024
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from concurrent.futures import Future
    from ..utils import _supports_unicode, _environ_cols_wrapper
    from ..defaults import _term_move_up

    _environ_cols_wrapper.environ['COLUMNS'] = '80'

    with _supports_unicode():
        with tqdm_auto.tqdm(total=100) as t:
            worker = MonoWorker()
            future1 = worker.submit(sleep, 1)
            assert isinstance(future1, Future)
            t.update(10)
            future2 = worker.submit(sleep, 0.2)
            assert isinstance(future2, Future)
            assert future1 is not future2

# Generated at 2022-06-24 10:02:38.559298
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert 1 == 2

# Generated at 2022-06-24 10:02:46.353845
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import contextlib

    mw = MonoWorker()

    @contextlib.contextmanager
    def slow(sleep=1, **kwargs):
        time.sleep(sleep + random.random() * 2)
        try:
            yield
        finally:
            time.sleep(sleep + random.random() * 2)

    @slow(sleep=.1)
    def task_1():
        pass

    @slow(sleep=.2)
    def task_2():
        pass

    @slow(sleep=.3)
    def task_3():
        pass

    @slow(sleep=.1)
    def slow2():
        time.sleep(.5)

    @slow(sleep=.5)
    def slow3():
        time.sleep(.5)


# Generated at 2022-06-24 10:02:57.497489
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import inspect
    import multiprocessing as mp

    def print_idle_threads():
        """
        See https://stackoverflow.com/questions/136097/what-is-the-best-way-to-
        determine-if-a-python-thread-is-idle
        """
        threads = mp.util.active_children()
        for t in threads:
            if t.is_alive() and not t.ident:
                print("Active Child: " + str(t))
                print("Alive: " + str(t.is_alive()))
                print("Ident: " + str(t.ident))
                print("Name: " + str(t.name))
                print("Daemon: " + str(t.daemon))

# Generated at 2022-06-24 10:03:08.893485
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import timeit
    from .import_contrib import call_clocked_sleep, main_wrap
    from time import sleep

    def unittest():
        mw = MonoWorker()
        assert not mw.futures
        mw.submit(call_clocked_sleep, 1.5)
        assert len(mw.futures) == 1
        assert mw.futures[0].done()
        assert mw.futures[0].result() == 1.5
        sleep(0.5)
        mw.submit(call_clocked_sleep, 0.5)
        assert len(mw.futures) == 2
        assert mw.futures[0].done()
        assert mw.futures[0].result() == 1.5
        assert not m

# Generated at 2022-06-24 10:03:18.608008
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from collections import Counter
    from nose.tools import assert_equal as aeq

    def func(x):
        sleep(.5)
        return x * x

    mw = MonoWorker()
    aeq([mw.futures.maxlen, len(mw.futures)], [2, 0])
    mw.submit(func, 0)
    aeq(len(mw.futures), 1)
    mw.submit(func, 1)
    aeq(len(mw.futures), 2)
    mw.submit(func, 2)  # called immediately
    aeq(len(mw.futures), 2)
    mw.submit(func, 3)  # called immediately
    aeq(len(mw.futures), 2)

# Generated at 2022-06-24 10:03:27.009785
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    try:
        import unittest2 as unittest  # python 2.6
    except ImportError:
        import unittest

    class TestMonoWorker(unittest.TestCase):
        def test_submit(self):
            from time import time, sleep

            def time_waster(*args):
                sleep(0.5)
                return time()
            worker = MonoWorker()
            sleep(0.2)
            results = list(
                worker.submit(time_waster, "arg") for _ in range(4))
            for r in results:
                self.assertLess(time() - r.result(), 0.6)

    unittest.main(argv=['first-arg-is-ignored'], exit=False)

# Generated at 2022-06-24 10:03:30.961782
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker.pool.__class__.__name__ == 'ThreadPoolExecutor'


if __name__ == "__main__":  # pragma: no cover
    test_MonoWorker()

# Generated at 2022-06-24 10:03:39.928168
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from nose.tools import assert_equal

    def add(x, y):
        sleep(0.1)
        return x + y

    worker = MonoWorker()
    assert_equal(0, len(worker.futures))

    running = worker.submit(add, 1, 2)
    running.result()  # wait
    assert_equal(0, len(worker.futures))

    running = worker.submit(add, 1, 2)
    waiting = worker.submit(add, 3, 4)
    running.result()  # wait
    assert_equal(0, len(worker.futures))

    running = worker.submit(add, 1, 2)
    waiting = worker.submit(add, 3, 4)
    waiting.result()  # wait

# Generated at 2022-06-24 10:03:48.458520
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from . import _name_, _warnings_  # NOQA
    from time import sleep

    def test_submit(iterations=7, sleep_min=0.01, sleep_max=0.03):
        m = MonoWorker()
        expected = []
        for i in tqdm_auto.trange(iterations, desc='MonoWorker'):
            sleep_duration = sleep_min + (sleep_max - sleep_min) * (i / iterations)
            expected.append(sleep_duration)
            m.submit(sleep, sleep_duration)
            actual = [f.result() for f in m.futures]
            assert expected == actual, \
                'i={!r} expected={!r} actual={!r}'.format(i, expected, actual)

    test_submit()
    test_

# Generated at 2022-06-24 10:03:58.914804
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    global MonoWorker
    if not __name__ == "__main__":
        return
    from ..main import tqdm
    mw = MonoWorker()
    tqdm.write("Initialized")
    for i in range(10):
        tqdm.write("Submitting task {}".format(i))
        mw.submit(lambda i=i: (tqdm.write("Running task {}".format(i)),
                               tqdm.write("Done task {}".format(i))))
        tqdm.write("Submitted task {}".format(i))
    tqdm.write("Terminating")
    del MonoWorker


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:04:06.071907
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    tasks = [0]

    def func(t):
        tasks[0] = t
        time.sleep(t)
        return t + 1

    worker = MonoWorker()
    waiting = worker.submit(func, 1)
    assert tasks[0] == 1
    assert waiting.result() == 2
    for t in range(4, 0, -1):
        assert tasks[0], 1
        worker.submit(func, t)
        assert tasks[0] == t
        time.sleep(1)
        assert tasks[0] == 1

# Generated at 2022-06-24 10:04:11.389717
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    worker = MonoWorker()
    for _ in range(4):
        t = time.time()
        f = worker.submit(random.randint, 0, 10)
        print(f.result(), time.time() - t)
        f = worker.submit(random.randint, 0, 10)
        print(f.result(), time.time() - t)
    f = worker.submit(random.randint, 0, 10)
    print(f.result(), time.time() - t)

# Generated at 2022-06-24 10:04:21.372410
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()

    assert len(mw.futures) == 0
    assert mw.submit(time.sleep, 1).done()
    assert len(mw.futures) == 1
    assert not mw.submit(time.sleep, 1).done()
    assert len(mw.futures) == 2
    assert not mw.submit(time.sleep, 1).done()
    assert len(mw.futures) == 2
    assert not mw.submit(time.sleep, 1).done()
    assert len(mw.futures) == 2
    # asyncio.get_event_loop().run_until_complete()

# Generated at 2022-06-24 10:04:22.651986
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    MonoWorker()


# Generated at 2022-06-24 10:04:31.381620
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import time
    c = MonoWorker()
    c.submit(print, "1")
    c.submit(print, "2")
    c.submit(print, "3")
    c.submit(print, "4")
    c.submit(time.sleep, 2)
    c.submit(print, "5")
    c.submit(print, "6")
    sys.stderr.write("ok")
    c.submit(time.sleep, 2)
    c.submit(print, "7")
    c.submit(print, "8")
    c.submit(time.sleep, 2)
    c.submit(time.sleep, 2)
    c.submit(print, "9")
    c.submit(print, "10")
    sys.stderr.write("ok")
   

# Generated at 2022-06-24 10:04:40.465108
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time, sys

    def background_work(t):
        time.sleep(t)
        return 'x' * t

    def main():
        mw = MonoWorker()
        mw.submit(background_work, 1)
        mw.submit(background_work, 2)
        mw.submit(background_work, 4)
        mw.submit(background_work, 8)
        mw.submit(background_work, 16)
        mw.submit(background_work, 32)
        mw.submit(background_work, 64)
        time.sleep(4)
        mw.submit(background_work, 128)

    if __name__ == '__main__':
        main()
        sys.exit()

# Generated at 2022-06-24 10:04:46.748467
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def some_func(i):
        import time
        import random
        time.sleep(random.random())
        return i

    worker = MonoWorker()

    # test that most recent submitted task is running,
    # that previous submitted task is cancelled
    futures = [worker.submit(some_func, i) for i in [0, 1]]
    assert futures[0].done()
    assert futures[1].done()
    assert futures[0].cancelled()
    assert not futures[1].cancelled()
    assert futures[1].result() == 1

    # test that most recent submitted task is running,
    # test that running task is not cancelled
    futures = [worker.submit(some_func, i) for i in [0, 1, 2]]
    assert futures[0].done()
    assert futures[1].done()

# Generated at 2022-06-24 10:04:53.471297
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Value

    class Counter(object):
        def __init__(self):
            self.n = Value('i', 0)
        def count(self):
            self.n.value += 1
            sleep(1)
            self.n.value += 1
            sleep(1)
            self.n.value += 1
        def get(self):
            return self.n.value

    def test(n_submit):
        counter = Counter()
        with MonoWorker() as worker:
            jobs = [worker.submit(counter.count) for _ in range(n_submit)]
        return counter.get()

    assert test(1) == 3
    assert test(2) == 6
    assert test(3) == 9

# Generated at 2022-06-24 10:05:02.117560
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import queue
    import threading
    from threading import Thread
    import concurrent.futures

    q = queue.Queue()
    mw = MonoWorker()
    mw.pool = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    missed = []
    done = False

    def printer():
        try:
            while True:
                print(q.get(timeout=.1))
        except queue.Empty:
            pass
        except Exception as e:
            print(e)
        finally:
            print('Printer exiting')

    def f():
        try:
            for i in tqdm_auto.trange(10):
                time.sleep(.1)
                q.put('f')
        finally:
            done = True


# Generated at 2022-06-24 10:05:06.712454
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def run(x):
        return x

    m = MonoWorker()
    futures = []
    for i in tqdm_auto.trange(100, desc="T1"):
        futures.append(m.submit(run, i))
    for future in futures:
        assert future.result() == futures[-1].result()

# Generated at 2022-06-24 10:05:13.861762
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import threading
    import time
    import logging
    logging.basicConfig(format="%(asctime)s %(message)s",
                        level=logging.DEBUG)
    def threaded(n):
        # time.sleep(1e-5 * n)
        logging.info("threaded called with %s", n)
        return n

    pool = MonoWorker()
    futures = (pool.submit(threaded, i) for i in range(5))
    for _ in tqdm_auto.tqdm(futures):
        time.sleep(0.01)
    time.sleep(0.2)  # wait for last thread to finish

# Generated at 2022-06-24 10:05:22.276240
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Testing thread-pool"""
    def test_func(i):
        """Test function"""
        from time import sleep
        sleep(0.1)
        return i

    mw = MonoWorker()
    assert len(mw.futures) == 0
    for i in range(1, 4):
        mw.submit(test_func, i)
        assert len(mw.futures) == 1
        assert mw.futures[0].result() == 3

    for i in range(4, 7):
        mw.submit(test_func, i)
        assert len(mw.futures) == 2

# Generated at 2022-06-24 10:05:32.507230
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test for `MonoWorker`"""
    from .tqdm_contrib_test import test_MonoWorker as tmw
    from queue import Queue
    from nose.tools import raises, timed
    # Basic functionality
    wo = MonoWorker()
    wo.submit(tmw.wait, delay=0.2)
    wo.submit(tmw.wait, delay=0.1)
    wo.submit(tmw.wait, delay=0.3)
    assert wo.futures[0].result() == '0.2s done'
    # Blocking
    wo = MonoWorker()
    wo.submit(tmw.wait, delay=0.2)
    wo.submit(tmw.wait, delay=0.2)

# Generated at 2022-06-24 10:05:41.479942
# Unit test for constructor of class MonoWorker

# Generated at 2022-06-24 10:05:49.118861
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Lock, Event
    from time import sleep
    with tqdm_auto.tqdm(total=1) as pbar:
        count = [0]
        lock = Lock()
        event = Event()

        def fn(x):
            pbar.update()
            with lock:
                count[0] += x
                if count[0] >= 100:
                    event.set()
            if count[0] < 100:
                sleep(0.01)
            return x * 10

        mw = MonoWorker()
        count[0] = 0
        event.clear()
        for _ in tqdm_auto.trange(10):
            mw.submit(fn, 1)
        event.wait(timeout=5)
        assert count[0] == 100

# Generated at 2022-06-24 10:05:55.896442
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()

    def print_args(a, b):
        print('print_args:', a, b)
        time.sleep(2)
    print(mw.submit(print_args, 'hello world', 1))
    print(mw.submit(print_args, 'hello world', 2))
    print(mw.submit(print_args, 'hello world', 3))
    print(mw.submit(print_args, 'hello world', 4))
    print(mw.submit(print_args, 'hello world', 5))
    print(mw.submit(print_args, 'hello world', 6))
    print(mw.submit(print_args, 'hello world', 7))
    print(mw.submit(print_args, 'hello world', 8))
    print

# Generated at 2022-06-24 10:06:01.947549
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import inspect
    import logging
    import os
    import sys
    try:
        from subprocess import getoutput as cmd  # py3
    except ImportError:
        from commands import getoutput as cmd  # py2
    from .test_utils import _fake_streams

    def test_function():
        logging.error("test_function called")
        # must not raise exceptions
        with _fake_streams(stdout=True):
            sleep(1)

    fname = inspect.getsourcefile(test_function)
    fsize = os.path.getsize(fname)
    assert fsize > 0
    # the following logging line should be repeated only once
    logging.basicConfig(
        filename=os.devnull, format='%(message)s', level=logging.DEBUG)
    results

# Generated at 2022-06-24 10:06:10.234848
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .utils import SlowTest
    import time, unittest

    class TestMonoWorker(unittest.TestCase):
        @SlowTest
        def test_submit_2(self):
            mw = MonoWorker()
            mw.submit(time.sleep, 1.0)
            mw.submit(time.sleep, 0.5)
            mw.submit(time.sleep, 1.0)
            self.assertEqual(len(mw.futures), 2)
            self.assertIs(mw.futures[0], mw.futures[1].result(),
                          "waiting task overrode running task")
            self.assertEqual(len(mw.futures), 1)

        @SlowTest
        def test_submit_3(self):
            mw

# Generated at 2022-06-24 10:06:16.673755
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """test_MonoWorker()"""
    m = MonoWorker()
    assert m.futures.maxlen == 2
    assert not len(m.futures)
    m.submit(lambda: 1 / 0)
    m.submit(lambda a: 1 / a, 0)
    assert isinstance(m.pool, ThreadPoolExecutor)
    assert len(m.futures) == 2
    for f in m.futures:
        assert f.cancelled()

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:06:25.502819
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from contextlib import contextmanager
    from .tqdm_joblib import tqdm
    from .trange import trange

    # This part is not necessary for the class MonoWorker
    @contextmanager
    def bool_pending_job():
        """Returns a bool of whether there is a pending job."""
        pending_job = [False]

        def check_pending_job(func, *args, **kwargs):
            pending_job[0] = True
            return func(*args, **kwargs)

        yield check_pending_job
        assert not pending_job[0]

    # This part is not necessary for the class MonoWorker

# Generated at 2022-06-24 10:06:34.073821
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .utils import get_tqdm, seq_gen

    # test use case with exact results

    # no waiting task is expected
    with get_tqdm(total=5, leave=False) as pbar:
        pbar.set_description("first")
        mw = MonoWorker()
        mw.submit(pbar.update, 4)
        pbar.update(1)
        pbar.set_description("second")
        mw.submit(pbar.update, 4)
        pbar.update(1)
        pbar.set_description("third")
        mw.submit(pbar.update, 4)
    # the first waiting task should be the last one
    assert ("third", "fourth") == ("first", "second")

    # no waiting task is expected

# Generated at 2022-06-24 10:06:38.812799
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import re
    import sys
    import time
    from multiprocessing import Process, Value
    from threading import Thread
    import warnings

    n_iter = 10
    # n_iter = 100  # for profiling

    # Silence resource warnings
    warnings.filterwarnings('ignore', category=ResourceWarning)

    def print_progress(pos):
        sys.stderr.write('\x1b[2K\r{}'.format(pos.value))
        sys.stderr.flush()

    def print_complete(pos):
        sys.stderr.write('\x1b[2K\r{}'.format(pos.value))

    def test_submit(func, *args, **kwargs):
        mw = MonoWorker()
        for i in range(n_iter):
            mw.submit

# Generated at 2022-06-24 10:06:46.781169
# Unit test for constructor of class MonoWorker
def test_MonoWorker():  # pragma: no cover
    import multiprocessing as mp
    import time
    mono = MonoWorker()

    def slow_squarer(x):  # pragma: no cover
        time.sleep(0.1)
        return x ** 2

    def slow_adder(x, y):  # pragma: no cover
        time.sleep(0.1)
        return x + y

    # Start one long computation (will take 0.3s)
    future1 = mono.submit(slow_squarer, 5)
    # Start two shorter computations (will take 0.1s)
    future2 = mono.submit(slow_adder, 2, 3)
    future3 = mono.submit(slow_adder, 4, 5)
    # Wait for results
    print(future1.result())
    print(future2.result())

# Generated at 2022-06-24 10:06:53.539870
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    # Create a MonoWorker
    pool = MonoWorker()
    # Create a tqdm object to display progress
    n = 100
    pbar = tqdm_auto(total=n)
    total = 0
    # Submit tasks to the MonoWorker
    for i in range(n):
        total += pool.submit(time.sleep, 0.1).result()
        pbar.update(1)
        #sys.stdout.write('\n')
    pbar.close()
    assert total == n



# Generated at 2022-06-24 10:06:58.588632
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import subprocess
    mp = MonoWorker()
    mp.submit(subprocess.call, 'ls')
    mp.submit(subprocess.call, 'ls')
    mp.submit(subprocess.call, 'ls')
    mp.submit(subprocess.call, 'ls')
    mp.submit(subprocess.call, 'ls')

# Generated at 2022-06-24 10:07:05.320711
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    import sys

    def func(delay, val):
        time.sleep(delay)
        return val

    mw = MonoWorker()
    for i in range(4):
        delay = 1
        val = random.randint(1, 1001)
        f = mw.submit(func, delay, val)
        if f:
            sys.stdout.write("\nsubmitted " + str(val))
        else:
            sys.stdout.write("\nskipped " + str(val))
        time.sleep(delay)

# Generated at 2022-06-24 10:07:16.588231
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..utils import FormatCustomText, TestCommand

    command = TestCommand(interval=1, unit="x", total=4)
    pbar = command.pbar

    # Test .submit()
    mono = MonoWorker()
    fut = mono.submit(sleep, 4)
    fut = mono.submit(sleep, 3)  # replaces pending task
    assert len(mono.futures) == 1
    with tqdm_auto(**FormatCustomText(pbar, unit="x")) as t:
        while True:  # pragma: no branch (has exit in finally)
            try:
                fut.result()
                break
            except Exception as e:  # pragma: no cover (no such).
                tqdm_auto.write(str(e))
        t.update()

   

# Generated at 2022-06-24 10:07:23.686426
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import current_thread
    from . import test_utils

    def foo(n, sleep_for=0):
        time.sleep(sleep_for)
        return n

    mw = MonoWorker()
    assert mw.futures == deque([], 2)
    mw.submit(foo, 1, 0)
    assert mw.futures == deque([], 2)
    mw.submit(foo, 2, 0)
    assert mw.futures == deque([], 2)

    mw.submit(foo, 3, 1)
    assert (mw.futures
            == deque([foo(1, 0)._result, foo(2, 0)._result], 2))
    mw.submit(foo, 4, 0)
    assert mw.f

# Generated at 2022-06-24 10:07:32.732827
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from functools import partial
    from itertools import repeat, chain

    # Build a test that launches N dummy tasks concurrently
    def test_N_concurrent_tasks(N):
        from ..utils import FormatCustomText
        from multiprocessing.pool import ThreadPool

        # initialize objects with timeout
        pool = ThreadPool(N)
        tqdm_auto._instances.clear()
        _tqdm = partial(tqdm_auto, format=FormatCustomText('{l_bar}'))
        event = Event()
        timeout = 5
        w = MonoWorker()

        # launch N dummy tasks
        tasks = list(repeat(event, N))

# Generated at 2022-06-24 10:07:39.319455
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""

    def print_x_times(x, y):
        for _ in range(y):
            print(x)

    mw = MonoWorker()
    for i in range(10):
        mw.submit(print_x_times, x=i, y=20)
    # This should print the numbers from 0 to 9, 20 times each


# Generated at 2022-06-24 10:07:50.599413
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:08:01.189812
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def eprint(*args, **kwargs):
        import sys
        tqdm_auto.write(*args, file=sys.stderr, **kwargs)

    class _runner(object):
        """Simple runner."""
        def __init__(self, i):
            self.i = i
            self.evt = Event()

        def __call__(self):
            event = self.evt
            for _ in range(5):
                eprint("#{} running".format(self.i))
                time.sleep(0.5)
            event.set()
            eprint("#{} done".format(self.i))

    eprint("Instantiating MonoWorker")
    mono = MonoWorker()
    eprint("Submitting 5 runners")
    runners

# Generated at 2022-06-24 10:08:11.703691
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..__init__ import tqdm
    from .ascii import tqdm_gui

    class Bar(object):
        def __init__(self):
            self.val = 0

        def update(self, val):
            self.val = val

        def close(self):
            pass

    def wait(t):
        import time
        time.sleep(t)

    @tqdm_gui
    def test(worker):
        bars = [Bar() for _ in range(3)]
        futures = [worker.submit(wait, 0.2) for _ in bars]
        descs = [tqdm(total=3, desc=str(i), leave=False, bar_format='{desc}')
                 for i in range(3)]

# Generated at 2022-06-24 10:08:21.482762
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import __test_running_under_pytest__
    import pytest
    from time import sleep
    from threading import Event, Thread

    def setter(mw, event, sleep_time):
        """
        A blocking task
        :param mw:
        :param event:
        :param sleep_time:
        :return:
        """
        event.set()
        sleep(sleep_time)
        return "A", sleep_time

    def test_func(mw, event=None, sleep_time=None):
        """
        Test function.
        :param mw:
        :param event:
        :param sleep_time:
        :return:
        """

# Generated at 2022-06-24 10:08:29.321915
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from tqdm.contrib import MonoWorker
    w = MonoWorker()
    for i in range(4):
        w.submit(lambda x: x, i)
    assert len(w.futures) == 2


# Generated at 2022-06-24 10:08:39.172788
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from concurrent.futures import Future

    class FutureClass(Future):
        pass
    try:
        MonoWorker()
    except Exception:
        raise AssertionError("MonoWorker()")

    def func1(p1, p2=None, p3=None):
        if hasattr(func1, 'count'):
            func1.count += 1
        else:
            func1.count = 0
        if p1 <= 2:
            return p1
        else:
            return p2 + p3

    mw = MonoWorker()
    assert (mw.submit(func1, 1, p2=2, p3=3).result() == 1)
    assert (len(mw.futures) == 1 and mw.futures[0].done())

# Generated at 2022-06-24 10:08:45.016164
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def func(i, delay):
        time.sleep(delay)
        return i

    mw = MonoWorker()
    f1 = mw.submit(func, 1, 2)
    assert f1.result() == 1
    f2 = mw.submit(func, 2, 1)
    assert f2.result() == 2
    f3 = mw.submit(func, 3, 2)
    assert f3.result() == None
    f4 = mw.submit(func, 4, 1)
    assert f4.result() == 4
    f5 = mw.submit(func, 5, 2)
    assert f5.result() == None
    f6 = mw.submit(func, 6, 1)
    assert f6.result() == 6

# Generated at 2022-06-24 10:08:52.415255
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import multiprocessing as mp
    from time import sleep
    from ..auto import trange

    def id(n):
        return n

    def sleep_id(n):
        sleep(n)
        return n

    def sleep_throw(n):
        sleep(n)
        raise Exception("Slept for {} sec".format(n))

    def sleep_throw_async(n):
        sleep(n)
        throw_async(Exception("Slept for {} sec".format(n)))

    def throw_async(e):
        """Throw inside the worker, after func has returned"""
        raise e

    def sleep_throw_sync(n):
        sleep(n)
        throw_sync(Exception("Slept for {} sec".format(n)))


# Generated at 2022-06-24 10:08:58.289346
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()

    def sleep(duration):
        time.sleep(duration)
        return duration

    assert mw.submit(sleep, 1)

    assert mw.submit(sleep, 1)

    assert mw.submit(sleep, 4)

    assert mw.submit(sleep, 0.1)

    assert mw.futures[0] == mw.submit(sleep, 0)

# Generated at 2022-06-24 10:09:05.436114
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():  # pragma: no cover
    from time import sleep
    from random import shuffle, randint
    from copy import copy

    def endless_sleep():
        sleep(1000)

    def worker(w, secs=1):
        sleep(secs)
        w.append(secs)

    d = []
    w = MonoWorker()
    w.submit(worker, d, 2)
    w.submit(worker, d, 3)
    w.submit(worker, d, 4)
    assert d == [2]
    sleep(2.1)
    assert d == [2, 3]
    sleep(2.1)
    assert d == [2, 3, 4]

    d = []
    w = MonoWorker()
    w.submit(worker, d, 2)
    assert d == []

# Generated at 2022-06-24 10:09:09.623600
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit tests for constructor of class MonoWorker"""
    obj = MonoWorker()
    assert (obj is not None)
    assert (obj.pool is not None)
    assert (obj.futures is not None)
    assert (len(obj.futures) == 0)


# Generated at 2022-06-24 10:09:19.851268
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import sys

    saved_stdout = sys.stdout
    sys.stdout = open('/dev/null', 'w', 0)
    w = MonoWorker()

    def test_submit(i):
        # print('task %d' % i)
        sleep(1)

    # submit and discard
    for i in tqdm_auto.tqdm(range(10)):
        w.submit(test_submit, i)
        sleep(0.2)

    # submit, run, replace
    tasks = [w.submit(test_submit, i) for i in tqdm_auto.tqdm(range(4))]
    for task in tasks:
        task.result()
    sys.stdout.close()
    sys.stdout = saved_stdout

# Generated at 2022-06-24 10:09:28.672153
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    worker = MonoWorker()
    count1 = 0
    def target1():
        nonlocal count1
        count1 += 1
        time.sleep(1/1000)
        count1 += 1
        return count1
    count2 = 0
    def target2():
        nonlocal count2
        count2 += 1
        time.sleep(1/1000)
        count2 += 1
        return count2
    timeStart = time.time()
    futures = []
    for _ in range(3):
        futures.append(worker.submit(target1))
        futures.append(worker.submit(target2))
        time.sleep(1/1000)
    for future in futures:
        future.result()
    threading.Lock().release()
    timeEnd = time.time()

# Generated at 2022-06-24 10:09:37.721668
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test MonoWorker.submit()"""
    from time import sleep

    def f():
        sleep(0.5)
        return 'done'

    mw = MonoWorker()
    last = None
    for i in range(5):
        if i > 0:
            sleep(0.1)
        last = mw.submit(f)

    try:
        import pytest
        assert last.result() == 'done'
    except Exception as e:
        tqdm_auto.write("{}: {}".format(type(e).__name__, e))
        raise e



# Generated at 2022-06-24 10:09:45.580918
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def f1(i):
        sleep(0.5)
        print(i)
        return i

    def f2(i):
        sleep(1)
        raise Exception(i)

    for i in range(4):
        try:
            if i in (1, 2):
                mw.submit(f2, i)
            else:
                mw.submit(f1, i)
        except Exception as e:
            print(e)
        print('\n')

    mw.pool.shutdown(wait=True)


if __name__ == "__main__":
    mw = MonoWorker()
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:09:57.635311
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    processed = []
    def do(n):
        processed.append(n)
        time.sleep(0.2)
        return n
    worker = MonoWorker()
    assert not worker.pool._work_queue.qsize()
    assert not worker.pool._threads
    assert not worker.futures
    for i in range(3):
        worker.submit(do, i)   # queue to worker
        assert worker.pool._work_queue.qsize() <= 1
        assert worker.pool._threads
        assert len(worker.futures) <= 1
    for i in range(3):
        processed = []
        worker.submit(do, i)
        assert worker.pool._work_queue.qsize() <= 1
        assert worker.pool._threads

# Generated at 2022-06-24 10:10:05.107750
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import subprocess
    from random import randint

    def _test_func(i):
        time.sleep(random.randint(1, 3))
        return i

    t = time.time()
    with MonoWorker() as mw:
        submit_list = list()
        for i in range(1, 100):
            submit_list.append(mw.submit(_test_func, i))
            if randint(1, 2) == 1:
                submit_list.pop(0).wait()
    assert time.time() - t < 65



# Generated at 2022-06-24 10:10:12.992522
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mono = MonoWorker()
    assert mono.futures.maxlen == 2
    # test default no task
    assert (len(mono.futures) == 0 and
            mono.pool._work_queue.qsize() == 0 and  # pylint: disable=protected-access
            mono.pool._threads == 0)  # pylint: disable=protected-access
    # test max 1 running task
    mono.submit(time.sleep, .5)
    mono.submit(time.sleep, .5)
    assert (len(mono.futures) == 1 and
            mono.pool._work_queue.qsize() == 1 and  # pylint: disable=protected-access
            mono.pool._threads == 1)  # pylint: disable=protected-access

# Generated at 2022-06-24 10:10:16.514842
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    print(MonoWorker.__init__.__doc__)
    """
    test = MonoWorker()
    test.submit(tqdm_auto.write, 'testing')
    test.submit(tqdm_auto.write, 'MonoWorker')

# Generated at 2022-06-24 10:10:20.565744
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def add(a, b):
        time.sleep(0.1)
        return a + b
    mono = MonoWorker()
    res = []
    for i in range(5):
        res.append(mono.submit(add, i, i))
    for r in res:
        assert r.result() == 2 * res.index(r)

# Generated at 2022-06-24 10:10:28.217580
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    def f():
        import time
        time.sleep(.1)  # sleep a short amount of time
        return 1
    # test submit - if submit is successful, this should return 1
    w1 = MonoWorker()
    future1 = w1.submit(f)
    assert future1.result() == 1
    # test submit - if submit is unsuccessful, this should return 1
    w2 = MonoWorker()
    future2 = w2.submit(f)
    future3 = w2.submit(f)
    assert future3.result() == 1
    # test submit with arguments - if submit is successful, this should return 1
    w3 = MonoWorker()
    future4 = w3.submit(f, 1)
    assert future4.result() == 1
    # test submit with keyword arguments - if submit is successful, this should

# Generated at 2022-06-24 10:10:33.378570
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.futures is not None
    assert len(mw.futures) == 0
    assert mw.futures.maxlen == 2
    assert mw.pool is not None
    assert mw.pool._work_queue._maxsize == 1


# Generated at 2022-06-24 10:10:39.445773
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm.auto import trange

    def long_task(i):
        time.sleep(2)
        return 2 * i

    mono = MonoWorker()

    with trange(10) as t:
        for i in t:
            future = mono.submit(long_task, i)
            t.set_postfix(future=future)
            while not future.done():
                time.sleep(0.5)
                t.refresh()
            ans = future.result()
            t.set_postfix(ans=ans)


# Generated at 2022-06-24 10:10:47.351736
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import pytest

    def spurious_function():
        time.sleep(3)

    def test_submit():
        # Test 1: submit spurious function
        mw = MonoWorker()
        mw.submit(spurious_function)
        assert len(mw.futures) == 1
        # Test 2: submit and cancel
        mw.submit(spurious_function).cancel()
        assert len(mw.futures) == 1
        # Test 3: submit and wait
        mw.submit(spurious_function).result()

    t = test_submit  # noqa: F841
    pytest.main([__file__])

# Generated at 2022-06-24 10:10:57.947196
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..std import time
    from ..std import random
    from ..utils import format_sizeof
    import os
    import re

    def call_func_randomly(func, p, key, q, ctx, args, kwargs):
        """
        `func(*args, **kwargs)` is called randomly with probability `p`.

        Parameters
        ----------
        p : float [0, 1]
        args :
        kwargs :
        """
        func_str = key + str(args) + str(kwargs)
        t0 = time()
        mem0 = format_sizeof(os.getpid(), os.get_rss())

# Generated at 2022-06-24 10:11:03.075502
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    '''
    Test case for method submit of class MonoWorker.
    Test if the number of running functions equals one and the number of waiting
    functions equals one.
    '''
    import time
    import threading
    from concurrent.futures import TimeoutError
    from collections import Counter

    def run(waiting_time):
        time.sleep(waiting_time)

    def test_run(waiting_time):
        start_time = time.time()
        monoworker.submit(run, waiting_time)
        time.sleep(waiting_time - 1)
        monoworker.submit(run, 1)
        end_time = time.time()
        return end_time - start_time

    monoworker = MonoWorker()
    assert len(monoworker.pool._threads)

# Generated at 2022-06-24 10:11:12.135107
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed
    from ..manual import tqdm
    def f(sleep=3):
        tqdm.write('start')
        time.sleep(sleep)
        tqdm.write('end')
        return sleep

    w = MonoWorker()
    # Submit first job (that will finish before the second)
    fs = [w.submit(f, 3)]
    # Submit second job (that will finish after the first)
    fs.append(w.submit(f, 7))

    for f in as_completed(fs):
        tqdm.write(str(f.result()))


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:11:24.850263
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from .status_printer import StatusPrinter
    from .sync_utils import DummyTqdmFile

    progressbar = tqdm_auto.tqdm(total=4, file=DummyTqdmFile())
    with StatusPrinter(file=DummyTqdmFile()) as sp:
        with MonoWorker() as mono_worker:
            mono_worker.submit(sp.print_status, progressbar)
            mono_worker.submit(sp.print_status, progressbar)
            time.sleep(.5)
            mono_worker.submit(sp.print_status, progressbar)

# Generated at 2022-06-24 10:11:35.827439
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .async_ import as_completed
    from .import_compat import input, print

    def task(n):
        from time import sleep
        print("started {}".format(n))
        sleep(n)
        print("finished {}".format(n))
        return n

    mw = MonoWorker()
    print("submit 1")
    f1 = mw.submit(task, 1)
    print("submit 2")
    f2 = mw.submit(task, 2)
    print("submit 3")
    f3 = mw.submit(task, 3)
    print("submit 4")
    f4 = mw.submit(task, 4)
    print("submit 5")
    f5 = mw.submit(task, 5)
    print("submit 6 (will replace 4)")

# Generated at 2022-06-24 10:11:45.883848
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def res(delay):
        def r(arg, e):
            e.wait(timeout=delay)
            return arg
        return r

    e = Event()
    mw = MonoWorker()
    f = mw.submit(res(.1), 1, e)
    assert (f is not None)
    f = mw.submit(res(.1), 2, e)
    assert (f is not None)
    time.sleep(.2)
    assert (f.done())
    assert (f.result() == 1)

# Generated at 2022-06-24 10:11:56.713824
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()
    assert len(mw.futures) == 0

    f1 = mw.submit(lambda: time.sleep(0.1))
    assert len(mw.futures) == 1
    time.sleep(0.05)
    f2 = mw.submit(lambda: time.sleep(0.1))  # replaces waiting f1
    assert len(mw.futures) == 0
    f3 = mw.submit(lambda: time.sleep(0.1))
    assert len(mw.futures) == 1  # f2 is running, f3 waiting

    f4 = mw.submit(lambda: time.sleep(0.1))  # replaces waiting f3
    assert len(mw.futures) == 0

# Generated at 2022-06-24 10:12:04.183692
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.pool.__dict__['_max_workers'] == 1
    assert mw.futures.maxlen == 2
    assert mw.futures.__dict__['maxlen'] == 2
    assert mw.futures.__dict__['maxlen'] == mw.futures.maxlen
