

# Generated at 2022-06-24 10:01:51.843436
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    w = MonoWorker()
    if w.pool is None:
        raise Exception("Worker pool was not initialized")
    if w.futures is None:
        raise Exception("Worker futures deque was not initialized")
    return True


# Generated at 2022-06-24 10:01:52.662565
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()



# Generated at 2022-06-24 10:02:01.096618
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Check constructor of class MonoWorker."""
    mw = MonoWorker()

    # assert mw.futures is None
    # assert len(mw.pool._threads) == 0
    # assert len(mw.pool._work_queue) == 0
    # assert mw.pool._max_workers == 1
    # assert mw.pool.shutdown == False
    # assert mw.pool.shutdown_thread == False


# Generated at 2022-06-24 10:02:10.547846
# Unit test for constructor of class MonoWorker

# Generated at 2022-06-24 10:02:19.762887
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    class TestWorker():
        def __init__(self):
            self.test_val = 0
        def test_func(self):
            self.test_val = 1
    TestWorker().test_func()
    class MonoWorkerTester(MonoWorker):
        def __init__(self, *args, **kwargs):
            MonoWorker.__init__(self, *args, **kwargs)
            self.test_obj = TestWorker()
        def test_submit(self):
            self.submit(self.test_obj.test_func)
    test_obj = TestWorker()
    test_obj.test_func()
    assert test_obj.test_val == 1
    test_obj = TestWorker()
    a = MonoWorkerTester()
    a.test_submit()


# Generated at 2022-06-24 10:02:29.538427
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    ###################################################
    # Test basic correctness:
    #   1 task is running; 1 waiting -> 
    #       no error, 1 task is running; 1 waiting
    #   1 task is running; 0 waiting ->
    #       no error, 1 task is running; 1 waiting
    #   0 task is running; 1 waiting ->
    #       no error, 1 task is running; 0 waiting
    #   0 task is running; 0 waiting ->
    #       no error, 1 task is running; 0 waiting
    #   1 task running, 1 waiting ->
    #       no error, 1 task is running; 1 waiting
    ###################################################
    # testing global
    result = []
    max_step = 2
    case = lambda: result.append(True)
    # test case

# Generated at 2022-06-24 10:02:31.802687
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.futures.maxlen == 2


# Generated at 2022-06-24 10:02:33.580309
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    def square(x):
        return x**2
    assert worker.submit(square, 2)

# Generated at 2022-06-24 10:02:39.773322
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys
    from .tqdm import tqdm

    @MonoWorker
    @tqdm.func_closure
    def f():
        time.sleep(2)
        return 'foo'

    for _ in range(3):
        f()

    for _ in tqdm(range(3), file=sys.stdout):
        f()

    for _ in tqdm(range(3), file=sys.stderr):
        f()

    print(f.result())


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:02:46.913580
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import test

    test.fake_popen('pass')
    worker = MonoWorker()
    # Test: multiple submits
    worker.submit(tqdm_auto.write, 'a')
    worker.submit(tqdm_auto.write, 'b')
    worker.submit(tqdm_auto.write, 'c')
    # Test:
    worker.submit(tqdm_auto.write, 'd')
    # Test exception in submit
    worker.submit(tqdm_auto.write, 'e')
    worker.submit(tqdm_auto.write, 'f')
    # Test:
    tqdm_auto.write(worker.futures)
    test.fake_popen('fail')
    # Test:

# Generated at 2022-06-24 10:02:58.019452
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import traceback

    def write(*args):
        print(' '.join(map(str, args)))

    with MonoWorker() as m:
        for i in tqdm_auto.trange(3, desc="outer"):
            m.submit(time.sleep, 1)  # return = None

            def safe_traceback():
                traceback.print_stack()
            m.submit(safe_traceback)  # return = None

            write(m.submit(str, i))  # return = Future

            def sync_raise(exc):
                raise exc
            try:
                m.submit(sync_raise, RuntimeError(str(i)))  # return = failed future
            except Exception as e:
                write(e)


# Generated at 2022-06-24 10:02:58.721514
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert MonoWorker()

# Generated at 2022-06-24 10:03:09.622431
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .exceptions import DelayedKeyboardInterrupt

    import time

    import signal
    signal.signal(signal.SIGINT, signal.default_int_handler)

    def sleeping(seconds):
        import time
        import os
        time.sleep(seconds)
        return os.getpid()

    def check(test_func, expected, *args):
        tqdm_auto.write(">>> %s(*%r)" % (test_func.__name__, args))
        if hasattr(test_func, 'reset'):
            test_func.reset()
        got = test_func(*args)

# Generated at 2022-06-24 10:03:19.117688
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import time
    from time import sleep

    def sleep_func(sleep_time):
        print("Sleep for {}".format(sleep_time))
        sleep(sleep_time)

    # test constructor
    mono_worker = MonoWorker()
    assert isinstance(mono_worker.pool, ThreadPoolExecutor)
    assert isinstance(mono_worker.futures, deque)
    assert mono_worker.futures.maxlen == 2

    # test submit
    mono_worker.submit(sleep_func, 0.1)
    mono_worker.submit(sleep_func, 0.2)
    mono_worker.submit(sleep_func, 0.3)
    mono_worker.submit(sleep_func, 0.4)
    mono_worker.submit(sleep_func, 0.5)

    # test

# Generated at 2022-06-24 10:03:27.730361
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Initialize MonoWorker
    worker = MonoWorker()

    # Test that the generator is working properly
    def test_fibonacci_generator(n):
        a, b = 0, 1
        while a < n:
            yield a
            a, b = b, a+b
    tqdm_auto.write(list(test_fibonacci_generator(10)))  # outputs [0, 1, 1, 2, 3, 5, 8]
    tqdm_auto.write(list(test_fibonacci_generator(10)))  # outputs [0, 1, 1, 2, 3, 5, 8]

    # Test that .submit() properly runs the function in a mono-threaded context

# Generated at 2022-06-24 10:03:38.534554
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from time import sleep

    def f(x):
        sleep(x)
        return x**2

    class WaitDoneFuture(Future):
        """
        Future subclass which does not return until `.done()`
        """
        def result(self, timeout=None):
            while not self.done():
                sleep(0.1)
            return super(WaitDoneFuture, self).result(timeout)

        def __call__(self):
            return self.result()

    def test():
        # tqdm_auto.write("\n\n")
        tqdm_auto.write("\n")
        tqdm_auto.write("Testing MonoWorker.submit")

        mw = MonoWorker()

        # Check that both arguments work

# Generated at 2022-06-24 10:03:40.265707
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()



# Generated at 2022-06-24 10:03:42.321093
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mono = MonoWorker()
    assert len(mono.futures) == 0
    assert mono.pool._max_workers == 1


# Generated at 2022-06-24 10:03:46.899226
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    worker = MonoWorker()
    worker.submit(time.sleep, 1)
    worker.submit(time.sleep, 1)  # should clear waiting task
    worker.submit(time.sleep, 1)
    worker.submit(time.sleep, 1)  # now running, should not clear running task
    worker.submit(time.sleep, 1)  # should clear waiting task

# Generated at 2022-06-24 10:03:53.119364
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import _progbar
    from . import trange
    from time import sleep

    mono = MonoWorker()

    t1 = mono.submit(_progbar, trange, 5, desc='a')
    sleep(0.2)
    t2 = mono.submit(_progbar, trange, 5, desc='b')
    sleep(0.3)
    t3 = mono.submit(_progbar, trange, 5, desc='c')

    t1.result()
    t2.result()
    t3.result()

# Generated at 2022-06-24 10:04:01.121451
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker."""
    from time import sleep
    from concurrent.futures import CancelledError
    import sys

    def sleep_print(t, s):
        """`sleep` *t* seconds and then print *s*."""
        sleep(t)
        sys.stdout.write("\r" + str(s))
        sys.stdout.flush()

    class FakeFutures(object):
        """Fake futures class (for mocking)."""
        def __init__(self):
            self.append_args = []

        def append(self, future):
            """Fake append *future*."""
            self.append_args.append(future)

        def popleft(self):
            """Fake popleft."""
            return FakeFutures()


# Generated at 2022-06-24 10:04:05.547851
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    w = MonoWorker()
    assert len(w.futures) == 0


# Generated at 2022-06-24 10:04:12.405417
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Thread
    import random

    # Simulate 5 functions, each with a duration of 2s
    def func(id):
        sleep(2)
        return id

    # Create a list with the ids of the functions
    ids = [random.randint(0, 1000) for _ in range(5)]

    # Create a MonoWorker
    mw = MonoWorker()

    # Create a list with the threads
    threads = []
    for id in ids:
        threads.append(Thread(target=lambda x: mw.submit(func, x), args=(id,)))
    threads.append(Thread(target=lambda: mw.submit(func, -1)))

    # Start the threads
    for thread in threads:
        thread.start()

    # Join the threads

# Generated at 2022-06-24 10:04:23.056828
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    start_time = time.time()
    mono_worker = MonoWorker()

    def _test_func(name, wait):
        time.sleep(wait)
        return name

    # should not block
    mono_worker.submit(_test_func, '1', 0.5)
    mono_worker.submit(_test_func, '2', 0.5)
    mono_worker.submit(_test_func, '3', 0.5)
    mono_worker.submit(_test_func, '4', 0.5)
    mono_worker.submit(_test_func, '5', 0.5)
    mono_worker.submit(_test_func, '6', 0.5)

    for i in range(6):
        assert mono_worker.futures[i].result() == str(i+1)



# Generated at 2022-06-24 10:04:30.982539
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Lock
    from time import sleep
    from multiprocessing import Value

    def wait(*args):
        with lock:
            count.value = count.value + 1
        sleep(0.1)

    def cancel(*args):
        with lock:
            count.value = count.value + 1
        raise KeyboardInterrupt

    count = Value('i', 0)
    lock = Lock()
    try:
        mono_worker = MonoWorker()
        mono_worker.submit(wait)
        mono_worker.submit(wait)
        mono_worker.submit(cancel)
        sleep(0.1)
        assert count.value == 2
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-24 10:04:40.767882
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    class Sleeping(object):
        def __init__(self, delay, result=None,
                     raise_on_cancel=None, wake_up=None):
            self.delay = delay
            self.result = result
            self.raise_on_cancel = raise_on_cancel
            self.wake_up = wake_up
        def __call__(self):
            e = self.wake_up
            if e is not None:
                e.clear()
            try:
                sleep(self.delay)
            except BaseException as e:
                if self.raise_on_cancel:
                    raise
                return
            if e is not None:
                e.set()
            return self.result


# Generated at 2022-06-24 10:04:49.610709
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import threading

    def handle_exception(e, i):
        tqdm_auto.write('\n' + repr(e))

    def check_interleaved(s):
        s = sorted(s)
        # tqdm_auto.write('\n' + '-' * 80)
        # tqdm_auto.write('\n' + repr(s))
        assert all(s[i] >= s[i - 1] for i in range(1, len(s)))
        assert all(s[i] <= s[i - 1] + 1 for i in range(1, len(s)))

    def t(i):
        time.sleep(random.randint(1, 4))
        check_interleaved.s.append(i)


# Generated at 2022-06-24 10:04:53.877318
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from random import randint

    def slow(x):
        time.sleep(randint(2, 5))
        return x

    mono = MonoWorker()
    t = mono.submit(slow, 'waiting')
    assert not t.done()
    mono.submit(slow, 'replaced')
    assert t.done()



# Generated at 2022-06-24 10:04:54.762164
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()



# Generated at 2022-06-24 10:05:03.365491
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def func_1():
        time.sleep(3)
        return 1

    def func_2():
        return 2

    def func_3():
        return 3

    def func_exception():
        raise RuntimeError

    # test submit_first
    monoworker = MonoWorker()
    monoworker.submit(func_1)
    monoworker.submit(func_2)
    assert monoworker.futures[1].result() == 2
    assert monoworker.futures[0].result() == 1

    # test submit_last
    monoworker = MonoWorker()
    monoworker.submit(func_1)
    monoworker.submit(func_exception)
    assert monoworker.f

# Generated at 2022-06-24 10:05:12.668348
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing import Process
    import time
    import os
    import sys
    import signal

    def f1():
        time.sleep(5)

    def f2():
        time.sleep(5)

    def f3():
        global flag
        while flag:
            time.sleep(0.1)

    def worker(mw):
        p = Process(target=mw.submit, args=(f1,), kwargs={})
        p.start()
        p = Process(target=mw.submit, args=(f2,), kwargs={})
        p.start()
        return p


# Generated at 2022-06-24 10:05:24.657646
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures
    from threading import Thread
    from time import sleep

    def worker(interval):
        sleep(interval)
        return interval

    mw = MonoWorker()
    th = Thread(target=mw.pool.shutdown)
    th.start()
    mw.submit(worker, 0.1)
    assert mw.futures[0].result() == 0.1
    mw.submit(worker, 0.2)
    mw.submit(worker, 0.3)  # 0.2 will be discarded
    assert mw.futures[0].result() == 0.3
    mw.submit(worker, 0.4)  # 0.3 will be discarded
    assert mw.futures[0].result() == 0.4

# Generated at 2022-06-24 10:05:29.771182
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker = MonoWorker()
    mono_worker.submit(time.sleep, 0.5)
    mono_worker.submit(time.sleep, 0.5)
    mono_worker.submit(time.sleep, 0.5)
    mono_worker.submit(time.sleep, 0.5)



# Generated at 2022-06-24 10:05:37.741672
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import Timer
    from time import sleep

    def func(n):
        sleep(n)
        return n

    m = MonoWorker()
    with Timer() as t:
        while True:
            print(t.secs)
            if t.secs >= 5:
                break
            f = m.submit(func, t.secs)
            m.futures.append(f)
    print('end of with statement')
    sleep(1)
    print('after one second')
    for f in m.futures:
        print(f.result())

# Generated at 2022-06-24 10:05:46.869648
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import traceback

    def f1():
        try:
            return int(raw_input())
        except KeyboardInterrupt:
            tqdm_auto.write('{} KeyboardInterrupt'.format(traceback.format_exc().strip()))
            raise
        except Exception as e:
            tqdm_auto.write('{} {}'.format(traceback.format_exc().strip(), e))

    def f2():
        try:
            return int(raw_input()) + 1
        except KeyboardInterrupt:
            tqdm_auto.write('{} KeyboardInterrupt'.format(traceback.format_exc().strip()))
            raise
        except Exception as e:
            tqdm_auto.write('{} {}'.format(traceback.format_exc().strip(), e))

    mw = MonoWorker()

   

# Generated at 2022-06-24 10:05:48.006012
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker is not None


# Generated at 2022-06-24 10:06:00.112397
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .tests_main import class_parameterize_over
    from .._version import __author__ as author
    from time import sleep

    # noinspection PyUnusedLocal,PyShadowingNames
    def func(obj, i, wait_secs):
        sleep(wait_secs)
        return i

    # noinspection PyShadowingNames,PyUnusedLocal
    @class_parameterize_over(["run_index", "expected_return_value", "wait_secs"])
    class TestMonoWorker:
        @classmethod
        def setup_class(cls):
            cls.mono_worker = MonoWorker()


# Generated at 2022-06-24 10:06:01.050976
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw is not None


# Generated at 2022-06-24 10:06:08.923346
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    random.seed(0)

    def func(*args, **kwargs):
        import random
        import time
        time.sleep(random.random())
        return args, kwargs

    mono = MonoWorker()
    result = []  # results of all "submits"

    def submit(i):
        """
        Submits one task with args (args, kwargs, i)
        and appends the result (if not Exception) to *result*.
        """
        result.append(
            'running' if mono.submit(func, args, kwargs, i) is None
            else 'waiting')

    args = ('Foo', 'Bar')
    kwargs = {'foo': 'bar', 'bar': 'baz'}


# Generated at 2022-06-24 10:06:15.692492
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import threading
    import time
    import logging
    # Disable threading.Timer warning on openSUSE 42.3
    logging.getLogger("concurrent.futures.thread").setLevel(logging.WARNING)

    def func0():
        time.sleep(1)
        print("0_0", threading.current_thread().getName())

    def func1():
        time.sleep(1)
        print("1_1", threading.current_thread().getName())
    func1.__name__ = "func1"

    def func2():
        time.sleep(1)
        print("2_2", threading.current_thread().getName())
    func2.__name__ = "func2"

    def func3():
        time.sleep(1)

# Generated at 2022-06-24 10:06:21.686033
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from tqdm import trange

    def fast_func(x):
        sleep(0.1)
        return x

    def slow_func(x):
        sleep(1)
        return x

    mono_worker = MonoWorker()
    for i in trange(5):
        mono_worker.submit(fast_func, i)
        mono_worker.submit(slow_func, i)
        sleep(0.5)

# Generated at 2022-06-24 10:06:32.958323
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading
    from nose.tools import assert_equal


    def fake_func(a, b, c=3, d=4):
        time.sleep(.05)
        return a + b + c + d


    # Initialize MonoWorker
    mono = MonoWorker()

    # FIFO
    mono.submit(fake_func, 1, 1)
    time.sleep(.01)
    mono.submit(fake_func, 1, 1)
    time.sleep(.01)
    mono.submit(fake_func, 1, 1)
    time.sleep(.02)
    mono.submit(fake_func, 1, 1)
    time.sleep(.02)
    mono.submit(fake_func, 1, 1)
    time.sleep(.01)

# Generated at 2022-06-24 10:06:34.701415
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker."""
    x = MonoWorker()
    assert not x.submit(1)
    assert x.submit(print, "")

# Generated at 2022-06-24 10:06:44.530555
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:06:54.063761
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    
    class OneTimeFunc():
        def __init__(self, sleep_time):
            self.sleep_time = sleep_time
            self.is_called = False

        def call_once(self):
            if self.is_called:
                assert False, "Error: The function is called more than once!"
            self.is_called = True
            time.sleep(self.sleep_time)

    func_sleep_time = 1
    func = OneTimeFunc(func_sleep_time).call_once
    worker = MonoWorker()
    worker.submit(func)
    worker.submit(func)
    worker.submit(func)


test_MonoWorker()

# Generated at 2022-06-24 10:07:04.254127
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from operator import sub
    from threading import Thread
    from multiprocessing import Value

    def get_sub(a, b):
        sleep(0.01)
        return a - b

    def test_sub(a, b, v):
        t = Thread(target=lambda: v.value)
        t.daemon = True
        t.start()
        assert get_sub(a, b) == v.value
        t.join()

    task_data = [(3, 1, Value('i', 2)), (2, 1, Value('i', 1))]
    mw = MonoWorker()
    for data in task_data:
        args = data[:2]
        v = data[2]
        v.value = sub(*args)

# Generated at 2022-06-24 10:07:15.567183
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # dev test
    from time import sleep
    from threading import Event
    from random import random

    def task(n=0.7):
        """Task that sleeps for n seconds and prints its arguments."""
        ev.wait()
        sleep(n)
        print('args=', args, ' kwargs=', kwargs, ' n=', n)
        #print(threading.current_thread())

    worker = MonoWorker()
    ev = Event()

    for _ in range(4):
        args = tuple([random() for _ in range(5)])
        kwargs = dict([(str(random()), str(random())) for _ in range(5)])
        worker.submit(task, *args, **kwargs)
        worker.submit(task, *args, **kwargs)
    ev.set

# Generated at 2022-06-24 10:07:22.555222
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> from threading import Semaphore, Thread
    >>> from time import sleep
    >>> mw = MonoWorker()
    >>> sema = Semaphore(0)
    >>> def func(arg):
    ...     sema.release()
    ...     sleep(arg)
    >>> t = Thread(target=mw.submit, args=(func, 1))
    >>> t.daemon = True
    >>> t.start()
    >>> sema.acquire()
    >>> t = Thread(target=mw.submit, args=(func, 0.1))
    >>> t.daemon = True
    >>> t.start()
    >>> sema.acquire(timeout=1)
    >>> True
    """
    pass

# Generated at 2022-06-24 10:07:26.592857
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    assert len(mw.futures) == 0
    mw.submit(lambda: 2)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 2
    mw.submit(lambda: 3)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 3
    mw.submit(lambda: 4)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 3
    mw.submit(lambda: 5)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 5

# Generated at 2022-06-24 10:07:35.019149
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Thread
    mw = MonoWorker()
    for i in range(3):
        def double(i):
            sleep(2)
            return 2 * i
        mw.submit(double, i)
        assert len(mw.futures) == 1
        assert not mw.futures[0].done()
    for i in range(3):
        def double(i):
            sleep(2)
            return 2 * i
        mw.submit(double, i)
        assert len(mw.futures) == 1
        assert mw.futures[0].done()
        assert mw.futures[0].result() == 2 * (i + 1)
    sleep(2)
    mw.submit(lambda i: 2 * i)


# Generated at 2022-06-24 10:07:38.375006
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Make sure maxlength of deque is 2
    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert mw.futures.maxlen == 2

# Generated at 2022-06-24 10:07:39.790923
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # TODO: add tests
    pass



# Generated at 2022-06-24 10:07:42.805482
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test case for method submit of class MonoWorker
    def func(i):
        import time
        time.sleep(1)
        return i

    worker = MonoWorker()
    futures = list()
    for i in range(5):
        future = worker.submit(func, i)
        futures.append(future)

    for future in futures:
        print(future.result())

# Generated at 2022-06-24 10:07:43.563697
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert isinstance(MonoWorker(), MonoWorker)

# Generated at 2022-06-24 10:07:44.725226
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    return worker

# Generated at 2022-06-24 10:07:54.824868
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def _1(n):
        return n

    def _2(n):
        sleep(1)
        return n

    # A task should not be replaced if it is still running
    mw = MonoWorker()
    mw.submit(_1, 1)
    sleep(0.1)
    mw.submit(_2, 1)
    mw.submit(_1, 1)
    assert mw.futures[0].result(100) == 1, mw.futures[0].result(100)
    assert mw.futures[1].result(100) == 1, mw.futures[1].result(100)

    # A task should be replaced if it is still waiting
    mw = MonoWorker()
    mw.submit(_2, 1)
    sleep

# Generated at 2022-06-24 10:08:04.669259
# Unit test for constructor of class MonoWorker
def test_MonoWorker():  # pragma: no cover
    from time import sleep
    from concurrent.futures import as_completed
    from itertools import repeat

    worker = MonoWorker()

    def _sleep(x):
        sleep(x)
        return x

    n = 5
    with tqdm_auto.tqdm(total=n) as t:
        fs = [worker.submit(_sleep, x) for x in reversed(range(n))]
        for i, f in enumerate(as_completed(fs), 1):
            t.update()
            assert f.result() == i % 2  # check concurrent termination
        assert len(worker.futures) == 1  # check queue overflow

    # check queue overflow by excess

# Generated at 2022-06-24 10:08:06.539476
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert len(MonoWorker().futures) == 0
    assert len(MonoWorker(2).futures) == 0
    assert len(MonoWorker(1).futures) == 0

# Generated at 2022-06-24 10:08:14.165620
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(x):
        return x*3
    def f2(x):
        return x+3
    mw = MonoWorker()
    assert mw.futures == deque([])

    def test_arrange(mw):
        assert mw.futures == deque([], 2)
        future = mw.submit(f, 1)
        assert future
        assert mw.futures == deque([future], 2)
        assert future.result() == 3

        future = mw.submit(f, 2)
        assert future
        assert mw.futures == deque([future], 2)
        assert future.result() == 3

        future = mw.submit(f2, 3)
        assert future
        assert mw.futures == deque([future], 2)
       

# Generated at 2022-06-24 10:08:23.791474
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    from unittest import TestCase, main
    from tqdm.contrib.concurrency import MonoWorker

    mw = MonoWorker()

    class TestMW(TestCase):
        def setUp(self):
            self.lock = Lock()
            self.lock.acquire()

        def tearDown(self):
            self.lock.release()

    # Test discard when worker is running
    def test_discard_running(self):
        def run1():
            self.lock.acquire()
            return 1
        def run2():
            sleep(0.1)
            return 2
        def run3():
            self.lock.release()
            return 3
        mw.submit(run1)
        mw.submit(run2)

# Generated at 2022-06-24 10:08:29.504242
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm.contrib import MonoWorker

    def sleep_and_return(timeout, retval):
        time.sleep(timeout)
        return retval

    m = MonoWorker()
    assert m.submit(sleep_and_return, 0.2, 3)
    assert m.submit(sleep_and_return, 0.1, 4)  # should cancel previous
    assert m.submit(sleep_and_return, 0.1, 5)  # should cancel previous
    assert m.submit(sleep_and_return, 0.1, 6)  # should cancel previous
    time.sleep(0.3)
    assert m.futures[0].result(timeout=0) == 6

# Generated at 2022-06-24 10:08:31.813519
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    pass



# Generated at 2022-06-24 10:08:38.362564
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from .async_ import Event, set_event
    x = MonoWorker()
    assert x.pool.submit.__name__
    sleep_event = Event()
    done_event = Event()
    done_event2 = Event()
    y = x.submit(set_event, sleep_event)

    def test():
        """test function"""
        done_event.set()
        sleep_event.wait()
        done_event2.set()
        return "Hello, tqdm!"

    def test_err():
        """test function #2"""
        raise KeyError('key error')

    ok = x.submit(test)  # replace y
    sleep_event.set()
    ok.wait()
    assert ok.result() == "Hello, tqdm!"
    y.wait()


# Generated at 2022-06-24 10:08:44.343819
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func_A(a):
        import time
        time.sleep(1)
        return a
    def func_B(b):
        import time
        time.sleep(2)
        return b

    mw = MonoWorker()
    for a in [1, 2, 3]:
        mw.submit(func_A, a)
    for b in [1, 2, 3]:
        mw.submit(func_B, b)

    for a in mw.futures:
        print(a, a.result())  # 1, 1
    assert len(mw.futures) == 2
    print('OK')

# Generated at 2022-06-24 10:08:51.553273
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    MonoWorker()

    def _test_func(x):
        time.sleep(x)
        return x
    w = MonoWorker()
    w.submit(_test_func, 2)
    time.sleep(1)
    w.submit(_test_func, 3)
    time.sleep(4)
    w.submit(_test_func, 2)
    time.sleep(4)
    # for f in w.futures:
    #     print(f.result())

# Generated at 2022-06-24 10:08:57.542127
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from concurrent.futures import as_completed

    def f(n, n_sleep=1):
        sleep(n_sleep)
        return n

    w = MonoWorker()
    futs = [w.submit(f, n, n) for n in range(5)]
    for fut in as_completed(futs):
        assert fut.result() == 4
    assert len(w.futures) == 0

# Generated at 2022-06-24 10:09:05.015474
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Thread

    def wait_time(seconds):
        time.sleep(seconds)
        return seconds

    mw = MonoWorker()
    results = []

    def submit_task(delay):
        # the correct order is [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5]
        results.append(str(delay))
        r1 = mw.submit(wait_time, delay)
        r2 = mw.submit(wait_time, delay + 0.5)
        return r1, r2

    threads = [Thread(target=submit_task, args=(delay, ))
               for delay in range(0, 6)]

    for t in threads:
        t.start()

# Generated at 2022-06-24 10:09:13.335086
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import pytest
    class MonoWorkerTester(MonoWorker):
        def __init__(self):
            super(MonoWorkerTester, self).__init__()
            self.futures_expected_order = []
            self.futures_actual_order = []

        def submit(self, func, *args, **kwargs):
            self.futures_expected_order.append(func.__name__)
            return super(MonoWorkerTester, self).submit(func, *args, **kwargs)

        def track_futures(self):
            while True:
                time.sleep(1)
                for f in self.futures:
                    if f.done():
                        self.futures_actual_order.append(f.result())

# Generated at 2022-06-24 10:09:16.536171
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw, mw
    assert hasattr(mw, "pool"), mw
    assert hasattr(mw, "futures"), mw



# Generated at 2022-06-24 10:09:23.656508
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    mw = MonoWorker()

    def funct(msg, time):
        sleep(time)
        tqdm_auto.write(msg)
        return msg

    mw.submit(funct, "n", 1)
    mw.submit(funct, "n+1", 1)
    mw.submit(funct, "n+2", 1)
    assert mw.pool._work_queue.qsize() == 1
    assert len(mw.futures) == 1

# Generated at 2022-06-24 10:09:30.248255
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import string
    import unittest

    class TestMonoWorker(unittest.TestCase):
        def test1(self):
            mw = MonoWorker()
            results = []
            for i in range(2):
                time.sleep(random.uniform(0, 0.5))
                future = mw.submit(len, random.choice(string.ascii_letters))
                results.append(future)
            for result in results:
                self.assertEqual(result.result(), 1)

    unittest.main(argv=['first-arg-is-ignored'], exit=False, verbosity=2)



# Generated at 2022-06-24 10:09:40.914593
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test method submit of class MonoWorker"""
    from concurrent.futures import Future
    from time import sleep
    from threading import Thread
    from unittest import TestCase, main

    class MonoWorkerTest(TestCase):
        def test_MonoWorker_submit(self):
            def func(*args, **kwargs):
                return args, kwargs

            worker = MonoWorker()
            for i in range(4):
                future = worker.submit(func, "test", i, kw="kwargs")
                self.assertIsInstance(future, Future)
                self.assertEqual(len(worker.futures), i + 1)
                if i:
                    self.assertEqual(len(worker.futures), 2)
                    self.assertTrue(future.done())

# Generated at 2022-06-24 10:09:44.336728
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw
    assert mw.pool
    assert mw.futures
    assert mw.futures.maxlen == 2
    assert len(mw.futures) == 0
    assert mw.submit

# Generated at 2022-06-24 10:09:52.348302
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    import unittest

    class TestMonoWorker(unittest.TestCase):
        def setUp(self):
            self.worker = MonoWorker()
            time.sleep(0.1)

        def test_submit_one(self):
            """Submit one function, it is executed as soon as possible"""
            t = time.time()
            self.worker.submit(time.sleep, 0.2)
            self.assertLess(time.time() - t, 0.1,
                            "Submit should return immediately")
            t = time.time()
            self.worker.futures[0].result()
            self.assertGreater(time.time() - t, 0.1,
                               "Future should be executed after a delay")


# Generated at 2022-06-24 10:09:58.447004
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def do_work(job_id, duration):
        assert job_id != 666
        time.sleep(duration)
        return job_id

    mw = MonoWorker()
    id1 = mw.submit(do_work, 1, 5)
    id2 = mw.submit(do_work, 2, 3)
    if hasattr(id2, 'cancel'):
        id2.cancel()
    id3 = mw.submit(do_work, 3, 2)
    if hasattr(id3, 'cancel'):
        id3.cancel()
    id4 = mw.submit(do_work, 4, 1)
    if hasattr(id4, 'cancel'):
        id4.cancel()

# Generated at 2022-06-24 10:10:05.610093
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    # seed to ensure deterministic output
    import random; random.seed(1)
    import time

    def gen():
        x = 0
        while True:
            x += 1
            time.sleep(0.01)
            yield x
    g = gen()
    for _ in range(100):
        # mw.submit(lambda: next(g))
        if random.randrange(3):
            mw.submit(next, g)
    import concurrent.futures;
    concurrent.futures.wait(mw.futures)

# Generated at 2022-06-24 10:10:13.272997
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test MonoWorker.submit()"""
    import time

    def sleep_and_str(t, string):
        time.sleep(t)
        return string

    # Tests
    tqdm_auto.write('Basic test', end='')
    mw = MonoWorker()

    # Initial test
    assert mw.futures.maxlen == 2
    assert len(mw.futures) == 0

    # Start first task (t = 1)
    future = mw.submit(sleep_and_str, 1, '1')
    assert future.done() is False
    assert mw.futures.maxlen == 2
    assert len(mw.futures) == 1

    # Start second task (t = 2)

# Generated at 2022-06-24 10:10:21.937901
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Thread
    from time import sleep
    from unittest import TestCase

    class Test(TestCase):
        output = ''

        def run(self):
            '''
            Gather test results
            '''

# Generated at 2022-06-24 10:10:25.951439
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    worker = MonoWorker()
    futures = []
    print("Submitting 10 jobs with 2 workers")
    for _ in range(10):
        future = worker.submit(time.sleep, .5)
        assert future is not None, 'Worker returned a None future'
        futures.append(future)
    print("Jobs submitted")
    for future in futures:
        future.result()

# Generated at 2022-06-24 10:10:35.756803
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    class MyMonoWorker(MonoWorker):
        def __init__(self):
            super(MyMonoWorker, self).__init__()
            self.stop = Event()

        def submit(self, func, *args, **kwargs):
            def wrapped_func():
                while not self.stop.is_set():
                    sleep(.5)
                return func(*args, **kwargs)
            return super(MyMonoWorker, self).submit(wrapped_func, *args, **kwargs)

        def __call__(self, *args, **kwargs):
            return self.submit(*args, **kwargs)

        def stop_with(self, *args, **kwargs):
            return self.submit(*args, **kwargs)

   

# Generated at 2022-06-24 10:10:38.282699
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    a = MonoWorker()
    assert a.pool.max_workers == 1
    assert a.futures.maxlen == 2

# Manual test for constructor of class MonoWorker
test_MonoWorker()

# Generated at 2022-06-24 10:10:47.591072
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading
    from contextlib import contextmanager
    from functools import partial
    from ..utils import _decode_unicode
    from ..std import time as time_std
    from ..std import threading as threading_std

    @contextmanager
    def mock_time():
        # mock time.sleep()
        time_std.sleep = lambda _: None
        try:
            yield
        finally:
            # restore mock
            time_std.sleep = time.sleep

    @contextmanager
    def mock_threading():
        # mock threading.current_thread()
        threading_std.current_thread = lambda: threading.Thread()

        # mock threading.Thread.is_alive
        old_is_alive = threading.Thread.is_alive  # NOQA

       

# Generated at 2022-06-24 10:10:57.946836
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import concurrent.futures
    import random
    import time
    def func(i):
        print("function {} started at {}".format(i, time.time()))
        time.sleep(random.randint(1, 5))
        return i
    monoWorker = MonoWorker()
    # Submit the first function
    future = monoWorker.submit(func, 1)
    print("first {}".format(future))
    # Submit the second function which is currently running.
    # We are assuming that the second function will run after first
    # function is done.
    future = monoWorker.submit(func, 2)
    print("second {}".format(future))
    # This future is the first function, which is already done.
    print("first returned: {}".format(future.result()))
    # This future is the second

# Generated at 2022-06-24 10:11:02.518087
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def f(a, b):
        sleep(5)
        return a + b

    test_mw = MonoWorker()
    assert (test_mw.futures == deque([], 2))

    test_future = test_mw.submit(f, 1, 2)
    assert (test_mw.futures == deque([test_future], 2))
    assert (test_future.result() == 3)

    test_future2 = test_mw.submit(f, 5, 2)
    assert (test_mw.futures == deque([test_future, test_future2], 2))
    assert (test_future2.result() == 7)

# Generated at 2022-06-24 10:11:09.212949
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from random import random
    from concurrent.futures import wait
    from .tqdm_test_classes import FakeTqdmFile

    def slow_call(time):
        time.sleep(random() * 3)
        return random()

    time = time  # hide "global" time in this function's scope
    with tqdm_auto.tqdm(ascii=True) as t:
        with FakeTqdmFile(t) as f:
            mono = MonoWorker()
            for i in range(10):
                mono.submit(slow_call, time)
                wait(mono.futures)
                f.write(str(mono.futures[0].result()))
                t.update()



# Generated at 2022-06-24 10:11:17.237744
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading

    def doWork(i):
        time.sleep(1)

    m = MonoWorker()
    print('3 worker threads should run SPORADICALLY:')
    r = [m.submit(doWork, i) for i in range(3)]
    r = [m.submit(doWork, i) for i in range(3)]
    print('2 worker threads should run SPORADICALLY:')
    r = [m.submit(doWork, i) for i in range(2)]
    print('1 worker thread should run SPORADICALLY:')
    r = [m.submit(doWork, i) for i in range(1)]

# Generated at 2022-06-24 10:11:23.188989
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def work(x):
        time.sleep(x)
        return x

    mono_worker = MonoWorker()
    print('t0')
    t0 = time.time()
    print(mono_worker.submit(work, 0.1))
    print('t1')
    t1 = time.time()
    print(mono_worker.submit(work, 1))
    print('t2')
    t2 = time.time()
    print(mono_worker.submit(work, 0.2))
    print('t3')
    t3 = time.time()
    print('t0-t1: %f' % (t1 - t0))
    print('t1-t2: %f' % (t2 - t1))

# Generated at 2022-06-24 10:11:32.419449
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from ..utils import _term_move_up

    def do(i, b=0):
        time.sleep(1)
        if b:
            raise Exception("hi")
        return i

    tqdm_auto.write('testing MonoWorker')
    m = MonoWorker()
    for i in tqdm_auto(range(5), desc='w', leave=False):
        tqdm_auto.write(_term_move_up() + str(m.submit(do, i)))


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:11:40.926162
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import os
    import time
    from subprocess import Popen, PIPE
    from tempfile import mkdtemp
    import shutil
    from threading import Event
    from multiprocessing import Process
    from tqdm.contrib.concurrency import MonoWorker

    class A(object):

        def __init__(self, stop_event, a=0, b=0, time_event=None, result=None):
            self.stop_event = stop_event
            self.a = a
            self.b = b
            self.time_event = time_event
            self.result = result

        def run(self):
            while not self.stop_event.is_set():
                time.sleep(1)
                if self.time_event is not None:
                    self.time_event.set()
           

# Generated at 2022-06-24 10:11:42.409272
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()

# Generated at 2022-06-24 10:11:49.143043
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    mw = MonoWorker()
    assert len(mw.futures) == 0

    def abc(sleep_time):
        sleep(sleep_time)
        return 'abc'

    mw.submit(abc, .4)
    assert len(mw.futures) == 1
    mw.submit(abc, .4)
    assert len(mw.futures) == 1
    mw.submit(abc, .4).result()
    mw.submit(abc, .4).result()
    assert len(mw.futures) == 0