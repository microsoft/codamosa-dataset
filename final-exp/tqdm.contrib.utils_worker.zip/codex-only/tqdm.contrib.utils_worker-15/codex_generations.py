

# Generated at 2022-06-24 10:01:52.397163
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import _range
    from ..utils import FormatCustomText
    from ..utils import Unicode
    from . import format_meter_of_class

    # print '\b' * 80

    # MonoWorker
    print('''\nTesting MonoWorker...
        (should display one progress meter, overwritten many times)''')

    def long_process(desc=None):
        if desc:
            tqdm_auto.write(desc)
        for _ in _range(100):
            tqdm_auto.write("oneline\n")
            tqdm_auto.sleep(0.2)

    def short_process(desc=None):
        tqdm_auto.sleep(0.2)

    def fast_process(desc=None):
        tqdm_auto.sleep(0.05)

   

# Generated at 2022-06-24 10:02:00.622576
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from tqdm import trange

    def dummy_task(interval):
        from time import sleep
        sleep(interval)
        return interval

    #
    # `MonoWorker` with `max_workers=1`
    #
    w = MonoWorker()

    # Submit one dummy task
    task_1_waiting = w.submit(dummy_task, 0.5)  # if submitted too fast, test will fail

    # Submit another dummy task while the first is still running
    task_1_waiting = w.submit(dummy_task, 0.5)

    # Submit another dummy task while the first is still waiting
    task_1_waiting = w.submit(dummy_task, 0.5)

    # Submit another dummy task while the first is still waiting

# Generated at 2022-06-24 10:02:10.386645
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import randint
    from threading import current_thread

    def slow(t=0.5):
        """
        Some slow function to test
        """
        time.sleep(t)
        return (current_thread().name, t)

    mw = MonoWorker()
    lst, expected = [], list()
    for t in [0.1, 0.2, 0.3, 0.4]:
        f = mw.submit(slow, t)
        lst.append(f)
        expected.append(('Thread-1', 0.4))
    time.sleep(0.5)
    results = list(map(lambda x: x.result(), lst))
    assert (results == expected)

# Generated at 2022-06-24 10:02:19.580650
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from threading import Event, Thread
    from time import sleep

# Generated at 2022-06-24 10:02:29.346375
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from concurrent.futures import CancelledError

    def sleeper(i, sleep=0.1):
        if isinstance(sleep, int):
            sleep = sleep * 0.1
        time.sleep(sleep)
        return i

    m = MonoWorker()
    assert m.futures.maxlen == 2
    for i in range(10):
        f = m.submit(sleeper, i)
        assert len(m.futures) <= 1
    assert len(m.futures) == 1  # running
    time.sleep(2 * 0.1)
    assert f.done()
    assert len(m.futures) == 1  # finished running
    assert m.submit(sleeper, 'x', sleep=1)

# Generated at 2022-06-24 10:02:37.780814
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from random import randint

    def delayed_randint(a, b, delay):
        """Random integer `a <= N <= b` after waiting `delay` seconds."""
        sleep(delay)
        return randint(a, b)

    def create_get_randint(a, b, delay=0.1, retries=3):
        """
        Return a function that returns a random integer `a <= N <= b` after
        waiting `delay` seconds. Retry `retries` times in case of exception.
        """
        def get_randint():
            i = 0
            while True:
                try:
                    return delayed_randint(a, b, delay)
                except Exception as e:
                    i += 1
                    if i > retries:
                        raise e

# Generated at 2022-06-24 10:02:38.902712
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    MonoWorker()


# Generated at 2022-06-24 10:02:45.894080
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for class MonoWorker method submit."""
    import time
    def wait(dt):
        time.sleep(dt)
        return "Finished!" if dt != 0.5 else Exception()

    mw = MonoWorker()

    try:
        mw.submit(wait, 0.5)  # fast
        mw.submit(wait, 1)  # slow
        mw.submit(wait, 2)  # discarded
    except Exception:
        pass

    mw.submit(wait, 0.3)  # fast (replaces slow)
    time.sleep(0.4)
    try:
        mw.submit(wait, 2)  # discarded
    except Exception:
        pass

# Generated at 2022-06-24 10:02:57.150838
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:02:59.642677
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def test():
        return 0
    a = MonoWorker()
    assert a

# Generated at 2022-06-24 10:03:10.214648
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    "Unit test for constructor of class MonoWorker"
    import unittest
    import sys

    class TestWorker(unittest.TestCase):
        "Tests for constructor of class MonoWorker"
        def setUp(self):
            """
            Sets up the initial conditions for the test.
            """
            self.worker = MonoWorker()

        def test_submit(self):
            """
            Tests if `MonoWorker.submit` is functional.
            """
            queue = []
            fut = self.worker.submit(queue.append, "test")
            fut.result()
            self.assertEqual(queue, ["test"])

    if __name__ == "__main__":
        unittest.main(module=__name__, buffer=True, exit=False)

# Generated at 2022-06-24 10:03:19.339807
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def _test_func(arg):
        """pass"""
        return arg

    def _test_exception_func():
        """pass"""
        raise ValueError

    m = MonoWorker()
    m.submit(_test_func, '1')
    m.submit(_test_func, '2')
    m.submit(_test_func, '3')
    m.submit(_test_exception_func)
    assert m.futures[0].result() == '3'
    m.submit(_test_exception_func)
    try:
        m.futures[0].result()
    except Exception as e:
        if str(e) == 'ValueError':
            pass
        else:
            raise ValueError(str(e))

# Generated at 2022-06-24 10:03:28.226989
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import os
    import sys
    import subprocess as sp

    def sleep_printer_proc(seconds, pid):
        time.sleep(seconds)
        os.system("ps fx | grep echo | grep -v grep")

    mw = MonoWorker()
    pid = os.getpid()
    mw.submit(sleep_printer_proc, 1.0, pid)
    mw.submit(sleep_printer_proc, 1.0, pid)  # overrides previous task
    time.sleep(0.5)
    mw.submit(sleep_printer_proc, 1.0, pid)
    time.sleep(2.0)

# Generated at 2022-06-24 10:03:30.792447
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def wait_f(x):
        time.sleep(x)
        return x
    worker = MonoWorker()
    for i in range(10):
        worker.submit(wait_f, i / 10)
        time.sleep(0.01)

# Generated at 2022-06-24 10:03:39.906057
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from collections import deque
    from multiprocessing import Value
    from concurrent.futures import TimeoutError
    from .utils import TestCase, suppress

    def worker(val, wait_seconds, success=True):
        sleep(wait_seconds)
        if success:
            val.value = wait_seconds
        else:
            raise Exception()

    class TestMonoWorker(TestCase):
        def test_worker(self):
            val = Value('d', -1)
            wait_seconds = 0.1
            with suppress(Exception):
                worker(val, wait_seconds)
            self.assertAlmostEqual(val.value, wait_seconds)
            val.value = -1
            wait_seconds = 1

# Generated at 2022-06-24 10:03:48.460136
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    max_workers = 1
    1: running
    2: waiting
    """
    from queue import Queue, Empty
    from time import sleep
    from random import randint
    from threading import Thread
    from concurrent.futures import TimeoutError
    # ----
    q = Queue()
    m = MonoWorker()
    def producer():
        while True:
            sleep(randint(1, 10) / 10)
            n = randint(0, 100)
            q.put(n)
            m.submit(f, n)
    def f(n):
        m = q.get()
        assert n == m
        q.task_done()

# Generated at 2022-06-24 10:03:54.225679
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    try:
        worker = MonoWorker()
        worker.submit(lambda: True)
        worker.submit(lambda: True)
        worker.submit(lambda: True)
        worker.submit(lambda: True)
    except Exception:
        raise tqdm_auto.TqdmKeyError('MonoWorker() not working')


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:04:03.426637
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    _list = []

    def app(x):
        time.sleep(random.random())
        _list.append(x)

    mw = MonoWorker()
    mw.submit(app, 0)
    assert len(_list) == 0
    mw.submit(app, 1)
    mw.submit(app, 2)
    mw.submit(app, 3)
    assert len(_list) == 1
    assert _list[0] == 3
    mw.submit(app, 4)
    mw.submit(app, 5)
    mw.submit(app, 6)
    for _ in range(10):
        mw.submit(app, 7)
    assert len(_list) == 4
    assert _list[-1] == 7

# Generated at 2022-06-24 10:04:09.901235
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def func(i, sleep_factor=1.0):
        sleep(random() * sleep_factor)
        return i

    mono = MonoWorker()

    def _test(i):
        f = mono.submit(func, i, sleep_factor=2.0)
        f.add_done_callback(lambda f: tqdm_auto.write('{} done'.format(f.result())))

    for i in tqdm_auto.trange(10):
        _test(i)
    while mono.futures:
        sleep(0.1)

    # should print 0-7 done in random order at some point

# Generated at 2022-06-24 10:04:21.420947
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time
    import warnings
    warnings.filterwarnings("ignore", category=PendingDeprecationWarning)

    def func(delay, exception=None):
        time.sleep(delay)
        if exception:
            raise exception
        return time.time()

    # test with no exceptions
    worker = MonoWorker()

    for _ in range(10):
        worker.submit(func, 0.05)
        worker.submit(func, 2.0)
        time.sleep(0.1)

    # test with exception
    worker = MonoWorker()
    worker.submit(func, 2.0, Exception("foo"))
    worker.submit(func, 2.0, Exception("bar"))
    time.sleep(2.0)

# Generated at 2022-06-24 10:04:30.865794
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random, seed

    def foo(seed):
        """
        Return random value with vanilla random seed
        and compute-expensive random value with non-vanilla seed.
        """
        if seed == 0xDEADBEEF:
            sleep(0.5)
            return random()
        else:
            sleep(0.1)
            return seed  # average 0.5

    m = MonoWorker()
    f = m.submit(foo, 0xDEADBEEF)
    assert (f.result() - 0.5)**2 < 1e-8
    seed(0xDEADBEEF)
    assert (f.result() - foo(0xDEADBEEF)) < 1e-8
    assert len(m.futures) == 0

# Generated at 2022-06-24 10:04:39.353584
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def task(task_name, sleep_duration):
        sleep(sleep_duration)
        return "[{}]".format(task_name)

    mw = MonoWorker()
    # Futures will contain at most 1 finished task and 1 currently running
    submission = mw.submit(task, task_name="A", sleep_duration=5)
    sleep(1)
    submission = mw.submit(task, task_name="B", sleep_duration=1)  # replace
    result = submission.result()
    assert mw.futures[0].done() and not mw.futures[1]

# Generated at 2022-06-24 10:04:46.118337
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, time
    from sys import stdout

    def f(x):
        sleep(x)
        return time()

    mw = MonoWorker()
    xs = [2.0, 1.5, 3.5]
    last_start = [time()] * 2

    for x in xs:
        print
        ftime = last_start[0]  # f time, actual completion time
        stime = last_start[1]  # s time, actual submission time
        last_start = [time()]
        f = mw.submit(f, x)
        print("f submitted {:.1f}s after: {:.1f}s".format(time() - stime, x))

# Generated at 2022-06-24 10:04:52.908957
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from queue import Queue
    q = Queue()

    def _get(i):
        q.get()
        return i * 10

    m = MonoWorker()
    f = m.submit(_get, 1)
    q.put(1)
    assert f.result() == 10

    f = m.submit(_get, 2)
    f1 = m.submit(_get, 3)
    f2 = m.submit(_get, 4)
    assert f1.cancelled(), f2.cancelled()
    assert not f.done()

    f2 = m.submit(_get, 5)
    assert f2.done()
    assert not f2.cancelled()
    assert f2.result() == 5 * 10

# Generated at 2022-06-24 10:05:01.780304
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from operator import add, mul

    # An additive identity
    def _add_null(*args):
        return sum(args)

    # A multiplicative identity
    def _mul_null(*args):
        return reduce(mul, args)

    def add_null(*args):
        return _add_null(*args)

    def mul_null(*args):
        return _mul_null(*args)

    # Factorial with sleep
    def fact(n):
        time.sleep(1)
        return reduce(mul, xrange(2, n + 1))

    mw = MonoWorker()

    for _ in range(4):
        mw.submit(add_null, *xrange(10))
        mw.submit(mul_null, *map(fact, xrange(1, 6)))

# Generated at 2022-06-24 10:05:10.611310
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def add(a, b):
        sleep(0.1)
        return a+b

    from itertools import islice
    a = MonoWorker()
    b = [a.submit(add, 1, i) for i in range(10)]
    assert all(map(lambda f: f.done(), islice(b, 2, None)))
    assert all(map(lambda f: f.result() == 2, islice(b, 2, None)))
    assert b[0].result() == 1
    assert b[1].result() == 2

# Generated at 2022-06-24 10:05:21.758212
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..utils import FormatLabel
    from ..utils_tests import _run_cls

    class _T(MonoWorker):
        def __init__(self):
            super(_T, self).__init__()
            self.labels = []  # track state for testing

        def submit(self, func, *args, **kwargs):
            self.labels.append((kwargs.get('label') or '', 'submit'))
            return super(_T, self).submit(func, *args, **kwargs)

        def _run(self, func, args, kwargs):
            kwargs = kwargs.copy()
            label = kwargs.pop('label', '')
            self.labels.append((label, 'run'))
            return func(*args, **kwargs)

# Generated at 2022-06-24 10:05:30.984992
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    mw = MonoWorker()
    r1 = mw.submit(sleep, 2)
    r2 = mw.submit(sleep, 2)  # should cancel r1 and replace by r2
    r3 = mw.submit(sleep, 2)  # should cancel r2 and replace by r3
    r4 = mw.submit(sleep, 2)  # should be ignored
    assert r1.done()
    assert r2.done()
    assert not r3.done()
    assert not r4.done()
    r3.result()
    assert r3.done()

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:05:42.256965
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import concurrent.futures
    import tqdm.contrib
    from tqdm import tqdm

    def wait():
        time.sleep(random.random())

    workers = tqdm.contrib.MonoWorker()

    def submit(i):
        return workers.submit(wait)

    for i in tqdm(range(10)):
        submit(i)

    for i, fut in tqdm(enumerate(workers.futures), total=len(workers.futures)):
        try:
            fut.result()
        except concurrent.futures.CancelledError:
            pass
        except Exception as e:
            tqdm.write(str(e))

# Generated at 2022-06-24 10:05:53.032119
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def func(x):
        return x

    mw = MonoWorker()

    assert mw.futures.maxlen == 2
    assert len(mw.futures) == 0

    f1 = mw.submit(func, 'dummy1')
    f2 = mw.submit(func, 'dummy2')
    assert len(mw.futures) == 1  # oldest task discarded

    f3 = mw.submit(func, 'dummy3')
    assert len(mw.futures) == 1  # middle task discarded

    f4 = mw.submit(func, 'dummy4')
    assert len(mw.futures) == 1  # oldest task discarded

    f5 = mw.submit(func, 'dummy5')

# Generated at 2022-06-24 10:06:01.690669
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import concurrent.futures as cf
    a = MonoWorker()
    assert len(a.futures) == 0
    a.submit(time.sleep, 1)
    assert len(a.futures) == 1
    a.submit(random.randint, 0, 1)
    assert len(a.futures) == 1
    time.sleep(1.1)
    assert len(a.futures) == 0
    a.submit(time.sleep, 1)
    a.submit(time.sleep, 1)
    assert len(a.futures) == 1
    time.sleep(1.1)
    assert len(a.futures) == 0

    def error1():
        raise ValueError
    def error2():
        raise ValueError

# Generated at 2022-06-24 10:06:10.047684
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from nose.tools import assert_equal
    from numpy.random import randint

    # threading event
    e = threading.Event()
    # whether the task was cancelled - will be set to True if cancelled
    global_task_cancelled = False
    # indicates the task is completed - set to True when done
    global_task_done = False

    def do_task_cancel(task_number):
        global global_task_done

        # simulate a long running task
        # by waiting on event
        e.wait()

        global_task_done = True
        global_task_cancelled = task_number == 1

    def test_submit(task_numbers):
        global global_task_done, global_task_cancelled
        global_task_cancelled = False

# Generated at 2022-06-24 10:06:13.644610
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker is not None

    def pass_f():
        pass

    def sleep_f():
        pass

    worker.submit(pass_f)
    worker.submit(sleep_f)
    worker.submit(sleep_f)


# Generated at 2022-06-24 10:06:18.685268
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def wait(t):
        """Sleep for a while and return."""
        time.sleep(t)
        return t

    t_max = 2.0
    with tqdm_auto.tqdm(total=t_max) as t:
        mw = MonoWorker()
        exit_ = False
        while not exit_:
            t.update(0.1)
            f = mw.submit(wait, 0.5)
            if (t.n + f.result()) > t_max:
                f.cancel()
                exit_ = True
            else:
                t.update(f.result())
        return t.n

# Generated at 2022-06-24 10:06:25.009925
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from nose.tools import assert_equal
    from unittest.mock import patch

    with patch('tqdm.contrib.concurrency.MonoWorker.print') as mock_print:
        mock_print.return_value = None
        m = MonoWorker()
        m.submit(sleep, 0.1)
        m.submit(sleep, 0.2)
        # The first submitted sleep(0.1) was replaced.
    assert_equal(mock_print.call_count, 2)

# Generated at 2022-06-24 10:06:33.820808
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def fail():
        time.sleep(1)
        raise ValueError()

    def succeed():
        time.sleep(1)
        return

    worker = MonoWorker()

    worker.submit(fail)
    worker.submit(succeed)

    worker.submit(succeed)
    worker.submit(succeed)

    worker.submit(succeed)

    worker.submit(succeed)
    worker.submit(succeed)

    worker.submit(succeed)
    worker.submit(succeed)
    worker.submit(succeed)

    worker.submit(succeed)
    worker.submit(succeed)
    worker.submit(succeed)
    worker.submit(succeed)

    worker.submit(succeed)
    worker.submit

# Generated at 2022-06-24 10:06:43.972159
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-24 10:06:54.429743
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import os
    import sys
    from threading import Lock
    from tqdm import tqdm
    
    m = MonoWorker()

    def opener(path):
        open(path, 'w').close()
        return path

    def deleter(path, rm_lock):
        os.remove(path)
        rm_lock.acquire()
        try:
            with open(path, 'w') as f:
                f.flush()
        except:
            pass
        finally:
            rm_lock.release()

    rm_lock = Lock()
    for i in tqdm(range(5)):
        path = 'tmp/unit_test_MonoWorker_submit_{}.tmp'.format(i)
        f = m.submit(opener, path)

# Generated at 2022-06-24 10:06:59.014178
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker.pool._max_workers == 1
    assert worker.futures.maxlen == 2
    assert not worker.futures
    worker.submit(tqdm_auto.write, "a")
    assert len(worker.futures) == 1


# Generated at 2022-06-24 10:07:05.039231
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from ..utils import _supports_unicode
    from ..utils import format_sizeof
    from ..utils import sizeof_fmt

    def f(n, delay):
        sleep(delay)
        return n

    def test_case():
        tqdm_auto.write("TEST: MonoWorker")
        f = MonoWorker()
        assert len(f.futures) == 0

        f.submit(f, 1, 0)
        assert len(f.futures) == 1

        f.submit(f, 2, 0)
        assert len(f.futures) == 2

        f.submit(f, 3, 0)
        assert len(f.futures) == 2

        f.submit(f, 4, 0)
        assert len(f.futures)

# Generated at 2022-06-24 10:07:07.907420
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    worker = MonoWorker()
    assert len(worker.futures) == 0
    assert worker.pool.shutdown() is None



# Generated at 2022-06-24 10:07:12.897118
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def test_method(x, y, z):
        return x + y + z

    class TestedClass(object):
        def test_method(self, x, y, z):
            return x + y + z

    mono_worker = MonoWorker()
    test_inputs = [
        (test_method, 1, None, 2),  # tuple of method/function and all its args/kwargs
        (TestedClass().test_method, 2, None, 3),  # tuple of method/function and all its args/kwargs
    ]
    expected_outputs = [
        list(range(1, 6, 2)),  # list of return values
        list(range(2, 7, 2)),  # list of return values
    ]

# Generated at 2022-06-24 10:07:22.165482
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    import time
    import numpy as np
    from ..utils import format_sizeof
    from .. import trange

    mw = MonoWorker()

    def work(n):
        t = np.random.random(size=n)
        t += np.random.random(size=n)
        return t.nbytes

    f = mw.submit(work, int(1e8))
    for _ in trange(int(1e8), unit='B', unit_scale=True):
        pass
    f = mw.submit(work, int(1e8))
    with tqdm_auto.disable_deprecation_warning():
        for _ in trange(int(1e8), unit='B', unit_scale=True):
            pass

# Generated at 2022-06-24 10:07:31.878834
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():

    import time

    class MockTqdm(object):
        """Mock for `tqdm.tqdm_auto`"""
        def __init__(self):
            self.write_called = 0

        def write(self, s):
            self.write_called += 1
            print("MockTqdm : " + s)

        def close(self):
            pass

    m = MockTqdm()
    tqdm_auto.tqdm = m

    def test_func(x):
        time.sleep(0.05)
        return x ** 2

    mw = MonoWorker()
    mw.submit(test_func, 2)
    mw.submit(test_func, 3)
    mw.submit(test_func, 4)
    mw.submit(test_func, 5)

# Generated at 2022-06-24 10:07:41.359073
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def mul2(x):
        import time
        time.sleep(2)
        return x * 2

    def mul4(x):
        import time
        time.sleep(4)
        return x * 4

    worker = MonoWorker()
    a = worker.submit(mul2, 2)
    time.sleep(1)
    b = worker.submit(mul4, 4)  # immediate override
    time.sleep(3)  # still waiting
    future = worker.submit(mul4, 4)  # immediate override
    time.sleep(3)
    assert future.result() == 8
    assert b.done()
    assert b.result() == 16
    # a should be cancelled

# Generated at 2022-06-24 10:07:52.428522
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import cpu_count
    from queue import Empty, Queue
    import atexit
    from functools import partial

    # Test functions
    def f(i):
        sleep(i)
        return i

    def fl(i):
        sleep(i)
        return i
    atexit.register(fl, i=0.01)

    def fx(i):
        sleep(i)
        raise RuntimeError  # never called

    def f0():
        sleep(0)
        return 0

    def test_MonoWorker_submit_f(max_workers):
        mw = MonoWorker()
        q = Queue()
        f_ = partial(mw.submit, f)
        for i in range(10):
            q.put(f_(i))


# Generated at 2022-06-24 10:07:56.578914
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker."""
    def func(*args, **kwargs):
        pass
    worker = MonoWorker()
    assert worker.submit(func).done()

# Generated at 2022-06-24 10:08:05.319577
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from multiprocessing import cpu_count
    from random import randint

    def func_submit(mono, wait):
        if wait:
            time.sleep(wait)
        return (wait, mono.submit(time.sleep, 1))

    pool_size = cpu_count()
    workers = [MonoWorker() for _ in tqdm_auto.trange(pool_size)]
    # Parallelise workers
    futures = [worker.submit(func_submit, worker, randint(0, 2))
               for worker in workers]

    assert all(f.done() and not f.cancelled() for f in futures), \
        'All futures should have run'

# Generated at 2022-06-24 10:08:13.640630
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def writer(msg, i):
        tqdm_auto.write(msg)
        return msg, i

    mw = MonoWorker()
    # 1.
    expected = "1.1"
    mw.submit(writer, expected, 1)
    assert mw.futures[0].done()
    assert mw.futures[0].result() == (expected, 1)
    # 2.
    expected = "2"
    mw.submit(writer, expected, 2)
    assert mw.futures[0].done()
    assert mw.futures[0].result() == (expected, 2)
    # 3.
    expected = "3"
    mw.submit(writer, expected, 3)
    assert mw.futures[0].done()
    assert mw

# Generated at 2022-06-24 10:08:23.462229
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from time import sleep, time
    from unittest import TestCase

    class MonoWorkerTest(TestCase):
        def setUp(self):
            self.mw = MonoWorker()

        def test1(self):
            """Test immediate cancel"""
            # submit func that takes 10sec
            slowfunc = lambda x: sleep(x)
            future = self.mw.submit(slowfunc, 10)
            # submit func that takes 1sec
            fastfunc = lambda x: sleep(x)
            future = self.mw.submit(fastfunc, 1)
            # check that fastfunc won
            self.assertEqual(len(self.mw.futures), 1)

# Generated at 2022-06-24 10:08:34.151976
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def launch_and_await(future, sleep_time, error_msg):
        try:
            future.result()
        except Exception as e:
            tqdm_auto.write(error_msg)
        time.sleep(sleep_time)

    mw = MonoWorker()
    f = mw.submit(time.sleep, 10)
    assert len(mw.futures) == 1
    f.cancel()
    assert len(mw.futures) == 0
    launch_and_await(mw.submit(time.sleep, 10), 5, "Error when waiting")
    g = mw.submit(time.sleep, 10)
    assert len(mw.futures) == 1
    mw.submit(time.sleep, 8)

# Generated at 2022-06-24 10:08:40.828072
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from timeit import default_timer as timer

    def await_mono_task(pool, duration, timeout=None):
        """Ensure mono task was launched and not cancelled by waiting."""
        mono_future = pool.futures[0]
        if not mono_future.done():
            mono_future.result(timeout)  # will raise exception if cancelled
        end = timer()
        assert end - start >= duration, \
            "Mono task was cancelled by newer task within {}s".format(
                timeout or duration)

    def throw_exception(msg, timeout=None):
        """Throw exception at `timeout` after `duration`."""
        end = timer()
        assert end - start >= timeout, \
            "Exception was thrown too soon after {}s".format(timeout)
        raise Exception(msg)

    start = timer()


# Generated at 2022-06-24 10:08:43.547455
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time, random
    def t(*args, **kwargs):
        time.sleep(random.randint(1, 6))
        return 42
    mw = MonoWorker()
    for i in range(5):
        assert mw.submit(t, i)



# Generated at 2022-06-24 10:08:47.474745
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker.pool.max_workers == 1
    assert worker.futures.maxlen == 2
    assert len(worker.futures) == 0

# Generated at 2022-06-24 10:08:56.677826
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    t0 = time.time()
    # submit first job
    r1 = mw.submit(time.sleep, 3)
    # submit second job
    r2 = mw.submit(time.sleep, 3)
    # submit third job
    r3 = mw.submit(time.sleep, 3)
    # collect first result
    r1.result()
    # collect second result
    r2.result()
    print("Total time:", time.time() - t0)

# Generated at 2022-06-24 10:09:04.461784
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import multiprocessing
    import time
    mw = MonoWorker()
    q = multiprocessing.Queue()
    q.put(1)

    def f(x, y):
        return x + y

    f1 = mw.submit(f, q.get(), q.get())
    # The second submit should replace the first task
    f2 = mw.submit(f, 2, 3)
    time.sleep(0.1)
    assert f1.done()
    assert not f1.result()
    assert f2.done()
    assert f2.result() == 5

    f3 = mw.submit(f, 4, 5)
    assert f3.done()
    assert f3.result() == 9

# Generated at 2022-06-24 10:09:13.008059
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    from concurrent.futures import Future

    try:
        from concurrent.futures import as_completed  # Python 3.3+
    except ImportError:
        try:
            from .as_completed import as_completed
        except ImportError:
            raise ImportError(
                "as_completed not available: "
                "please install this module to test the MonoWorker class")

    def f(x):
        sleep(random())
        return x ** 2

    m = MonoWorker()
    futures = []
    tqdm_auto.write('submitting')
    for i in range(3):
        futures.append(m.submit(f, i))
    tqdm_auto.write('submitted')


# Generated at 2022-06-24 10:09:23.836626
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .threaded import ThreadedWrapper
    from .asyncio import AsyncioWrapper
    from .futures import FuturesWrapper
    wrapper_classes = [
        ThreadedWrapper, AsyncioWrapper, FuturesWrapper]
    with tqdm_auto.tqdm(wrapper_classes) as t:
        for wclass in t:
            t.set_description(wclass.__name__)
            mw = MonoWorker()
            # Start the first task
            f1 = mw.submit(time.sleep, 1)
            # Start the second task after 3/4 time for first task
            time.sleep(0.75)
            f2 = mw.submit(time.sleep, 2)
            # Clear second task after 1/4 time for first task
            time.sleep

# Generated at 2022-06-24 10:09:33.143204
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from multiprocessing import Process, Queue
    from os import getpid

    def func(q):
        q.put(getpid())

    q = Queue()

    mw = MonoWorker()
    proc = Process(target=func, args=(q,))
    proc.start()
    mw.submit(q.put, getpid())
    mw.submit(q.put, getpid())
    mw.submit(q.put, getpid())
    mw.submit(q.put, getpid())
    mw.submit(q.put, getpid())
    assert q.get() == proc.pid
    time.sleep(1)
    assert q.get() == proc.pid
    assert q.get() == proc.pid
    assert q.get() == proc.pid
   

# Generated at 2022-06-24 10:09:36.440887
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def foo(a, b):
        return a + b
    worker = MonoWorker()
    assert worker.submit(foo, 1, 2).result() == 3
    worker.submit(foo, 1, 2)



# Generated at 2022-06-24 10:09:43.877832
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    m_worker = MonoWorker()
    def func1(delay):
        time.sleep(delay)
        return 'hi'
    def func2(delay):
        time.sleep(delay)
        return 'bye'
    f1 = m_worker.submit(func1, 1)
    f2 = m_worker.submit(func2, 2)
    print('f1 =', f1.result())
    print('f2 =', f2.result())
    # # Output is:
    # f2 = bye
    # f1 = hi


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:09:55.196154
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Test for MonoWorker.submit().
    """
    import time
    from .pandas_io import tqdm as tqdm_pandas_io
    from .utils import tqdm as tqdm_utils

    # basic submit
    def retry(func, retries, delay):
        """
        Repeat `func` function until it does not raise an Exception.
        """
        for _ in tqdm_utils.trange(retries, desc='retry'):
            try:
                return func()
            except Exception:
                time.sleep(delay)

    worker = MonoWorker()

    def raise_func():
        """
        Function that raises an Exception.
        """
        raise Exception('bouh')


# Generated at 2022-06-24 10:10:00.325985
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    import sys
    import signal
    signal.signal(signal.SIGINT, signal.SIG_DFL)  # ensure we don't raise KeyboardInterrupt in main thread
    def raise_exc():
        raise ValueError("test exception thrown")
    def sleep_print(t, s):
        sleep(t)
        tqdm_auto.write(s)
    def test(func, should_raise):
        mw = MonoWorker()
        mw.submit(func)
        sleep(1)
        if mw.futures:
            assert not mw.futures[0].done()
        mw.submit(sleep_print, 5, "world")
        assert len(mw.futures) == 1

# Generated at 2022-06-24 10:10:07.297793
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()
    import time
    assert m.futures == deque([], 2)
    m.submit(time.sleep, 1)
    assert len(m.futures) == 1
    m.submit(time.sleep, 1)
    assert len(m.futures) == 1
    m.submit(time.sleep, 1)
    assert len(m.futures) == 2
    m.submit(time.sleep, 1)
    assert len(m.futures) == 2
    for f in m.futures:
        f.cancel()

# Generated at 2022-06-24 10:10:16.945271
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import traceback
    import threading
    import queue as Queue
    queue = Queue.Queue()

    def func(i):
        time.sleep(0.2)
        queue.put(i)

    mono = MonoWorker()
    for i in range(5):
        mono.submit(func, i)
        mono.pool.shutdown(wait=True)
        assert queue.empty()
        mono.submit(func, i)

    for i in range(4):
        assert queue.get() == i

    # NOTE: original queue.get() hangs
    with tqdm_auto.wrapattr(threading.Thread(target=queue.get, args=()),
                            '_target', lambda target: lambda: None):
        traceback.print_exc()

# Generated at 2022-06-24 10:10:24.969016
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for MonoWorker"""
    import time
    import threading
    import multiprocessing as mp
    import random
    import traceback
    import sys
    from os import devnull
    from contextlib import redirect_stdout
    from timeit import default_timer
    from ..tqdm import tqdm
    from ..utils import _term_move_up

    with redirect_stdout(open(devnull, 'w')):
        # Run tests
        with tqdm(total=N_THREADS, leave=False) as pbar:
            worker = MonoWorker()
            res = []

            def tfunc(i):
                time.sleep(random.random())
                res[i] = i

            # Run first task:
            start = default_timer()

# Generated at 2022-06-24 10:10:25.829865
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()


# Generated at 2022-06-24 10:10:35.672979
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Run quick tests for the MonoWorker class.
    """
    import os
    test_dir = os.path.dirname(os.path.abspath(__file__))
    test_file = os.path.join(test_dir, 'test_file.txt')
    test_file2 = os.path.join(test_dir, 'test_file2.txt')
    mw = MonoWorker()

    # Test behavior of an empty MonoWorker.
    assert (len(mw.futures) == 0)
    assert (mw.pool)
    assert (not mw.futures[-1].done())

    # Test behavior when submitting new task.
    mw.submit(tqdm_auto.write, test_file2)

# Generated at 2022-06-24 10:10:42.509829
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    task_running = [True]
    task_waiting = [None]

    def _submit(task_id):
        task_waiting[0] = task_id
        task_running[0] = False

    def _done(task_id):
        assert task_running[0] is False
        assert task_waiting[0] == task_id
        task_running[0] = True
        task_waiting[0] = None

    # init
    worker = MonoWorker()

    # submit task1
    assert len(worker.futures) == 0
    task1_fut = worker.submit(_submit, 1)
    assert len(worker.futures) == 1
    assert task_waiting[0] is None
    assert task_running[0] is True

    # submit task2
    task

# Generated at 2022-06-24 10:10:50.036764
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # import time

    # 1. Test that the number of pending futures is always at most 1
    worker = MonoWorker()
    # Submit an easy task
    def task():
        time.sleep(0.1)
        return 0
    worker.submit(task)
    time.sleep(0.05)
    assert len(worker.futures) == 1
    worker.submit(task)
    time.sleep(0.05)
    assert len(worker.futures) == 1
    worker.submit(task)
    time.sleep(0.05)
    assert len(worker.futures) == 1
    worker.submit(task)
    time.sleep(0.05)
    assert len(worker.futures) == 1
    # Wait for task to complete
    time.sleep(0.2)

   

# Generated at 2022-06-24 10:10:56.498233
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Function used for testing `MonoWorker` class `submit` method."""
    from time import sleep
    from random import randint
    from unittest.case import TestCase

    class Test_MonoWorker_submit(TestCase):
        def test_MonoWorker_submit(self):
            def task(x):
                sleep(randint(1, 3))
                return x

            mw = MonoWorker()
            for i in tqdm_auto.tqdm(range(100), desc='tasks'):
                n = randint(1, 5)
                ansr = range(n)
                futures = [mw.submit(task, i) for i in ansr]
                while futures:
                    future = futures.pop()

# Generated at 2022-06-24 10:10:59.593119
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Just make sure that constructor works as expected.
    """
    worker = MonoWorker()
    assert worker is not None

# Generated at 2022-06-24 10:11:05.232659
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def f(x):
        return x**2

    mw = MonoWorker()

    assert mw.submit(f, [42]) == None
    assert mw.submit(f, [42]) == None

    r = mw.submit(f, [42])
    time.sleep(0.1)
    assert r.done() == True
    assert r.result() == 1764


test_MonoWorker()

# Generated at 2022-06-24 10:11:15.885929
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from tqdm.contrib.concurrent import MonoWorker

    def foo(n):
        """Foo function"""
        time.sleep(n)
        return 42

    worker = MonoWorker()
    a = worker.submit(foo, 1)
    worker.submit(foo, 0.5)  # replace current task
    worker.submit(foo, 3)  # replace current task (again)
    worker.submit(foo, 0.1)  # replace current task (again and again)
    b = worker.submit(foo, 2)
    worker.submit(foo, 0.1)  # replace current task (again and again)
    assert b.done()
    assert b.result() == 42
    assert a.done()
    assert a.result() == 42
    assert not a.cancelled()


# Generated at 2022-06-24 10:11:20.976903
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import time_this
    mw = MonoWorker()
    assert len(mw.pool._threads) == 1
    assert len(mw.futures) == 0
    assert mw.futures.maxlen == 2
    import threading
    assert isinstance(mw.pool, ThreadPoolExecutor)
    assert isinstance(mw.pool._threads, set)
    assert len(mw.pool._threads) == 1
    assert isinstance(mw.pool._threads.pop(), threading.Thread)


# Generated at 2022-06-24 10:11:24.985463
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    mw = MonoWorker()

    def worker(n):
        time.sleep(0.2 + random.random() * 0.2)
        return n

    try:
        from queue import Empty
        mw.submit(worker, 0)
        for i in range(10):
            assert mw.submit(worker, i).result(timeout=0) == i
    except Empty:
        pass

# Generated at 2022-06-24 10:11:35.560869
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures
    mw = MonoWorker()
    print('SUBMIT 1')
    mw.submit(time.sleep, 1)
    time.sleep(0.2)
    print('SUBMIT 2')
    mw.submit(time.sleep, 9)  # should wait for SUBMIT 1
    print('SUBMIT 3')
    try:
        mw.submit(time.sleep, 1)
    except concurrent.futures.CancelledError:
        print('SUBMIT 3 cancelled')
    else:
        print('SUBMIT 3 not cancelled')
    print('FINISH')  # should only be printed after SUBMIT 1
    time.sleep(2)
    print('FINISH')  # should only be printed after SUBMIT 2

# Generated at 2022-06-24 10:11:48.070750
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import random
    import threading
    from tqdm.contrib import asyncio

    async def foo(x):
        """Testing job"""
        await asyncio.sleep(random.randrange(1, 3, 1) / 3)
        return x ** 2

    mw = asyncio.MonoWorker()
    # pylint: disable=invalid-name
    XXX = threading.Thread(target=lambda: asyncio.run(mw.submit(foo, 3)))
    XXX.start()
    time.sleep(0.2)
    XXX.join()
    time.sleep(0.1)
    XXX = threading.Thread(target=lambda: asyncio.run(mw.submit(foo, 6)))
    XXX.start()
    time.sleep(0.2)
