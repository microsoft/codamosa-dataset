

# Generated at 2022-06-24 10:01:59.049146
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from multiprocessing import Queue
    from time import sleep

    def f(x, q):
        sleep(0.1)
        q.put(x)

    q = Queue()
    w = MonoWorker()
    w.submit(f, 1, q)
    w.submit(f, 2, q)
    w.submit(f, 3, q)
    assert [q.get() for _ in range(3)] == [1, 2, 3]

# Generated at 2022-06-24 10:02:04.714335
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..auto import tqdm

    def time_futures(length):
        def _func(idx):
            time.sleep(0.5)
            return idx
        mw = MonoWorker()
        for i in tqdm(range(length), desc='Test'):
            mw.submit(_func, i)
    time_futures(10)

# Generated at 2022-06-24 10:02:14.618632
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import choice, randint
    items = [1, 2, 3, 4]

    def fun(item):
        sleep(item)
        return 2 * item

    mw = MonoWorker()
    tqdm_auto.write("Testing MonoWorker.submit() method")
    while items:
        item = choice(items)
        future = mw.submit(fun, item)
        items.remove(item)
        sleep(0.5)
        tqdm_auto.write("item={}, result={}".format(item, future.result()))

# Generated at 2022-06-24 10:02:16.846461
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert isinstance(worker.pool, ThreadPoolExecutor)
    assert worker.pool.max_workers == 1
    assert worker.futures.maxlen == 2
    assert not worker.futures

# Generated at 2022-06-24 10:02:27.140124
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import _range
    from time import sleep
    from .asyncio import AioBaseEventLoop

    def f(x):
        sleep(1)
        return x

    def g(x):
        sleep(.5)
        return x + 1

    aiobase = AioBaseEventLoop()


# Generated at 2022-06-24 10:02:35.602899
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import concurrent
    import functools

    @functools.lru_cache(maxsize=None)
    def compute(x):
        time.sleep(0.1)
        return x

    def do_compute(x):
        return compute(x)

    with MonoWorker() as w:
        f1 = w.submit(do_compute, 1)
        time.sleep(0.02)
        f2 = concurrent.futures.Future()  # should be discarded in constructor
        f2.set_result(2)
        w.futures.append(f2)
        f3 = w.submit(do_compute, 3)
        time.sleep(0.02)
        f1.cancel()  # should be discarded in constructor

# Generated at 2022-06-24 10:02:41.551180
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import traceback
    from multiprocessing import Process
    from multiprocessing.queues import Queue

    def reporter(q, dt):
        """
        Consumer.
        Consume task reports from `q` and write them to stdout.
        """
        for report in tqdm_auto.tqdm(iter(q.get, None), unit='hits'):
            tqdm_auto.write(report)
            time.sleep(dt)

    def task(q, dt):
        """
        Producer.
        Produce `dt`-sec-long task reports and put them in `q`.
        """

# Generated at 2022-06-24 10:02:54.131539
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from concurrent.futures import ThreadPoolExecutor
    from . import _tqdm

    def f(x):
        time.sleep(x)

    class tqdm_MonoWorker(object):
        """Helper to make tqdm-monitored MonoWorker"""
        def __init__(self, *args, **kwargs):
            self.mono = MonoWorker(*args, **kwargs)
            self.tqdm = _tqdm.tqdm()

        def submit(self, func, *args, **kwargs):
            from . import _tqdm  # avoid import cycle

# Generated at 2022-06-24 10:02:57.136349
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker"""
    # pylint: disable=W0612
    worker = MonoWorker()
    return None


# Generated at 2022-06-24 10:03:08.712775
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import pytest  # type: ignore
    try:
        from unittest import mock  # type: ignore
    except ImportError:
        import mock  # type: ignore

    @mock.patch('tqdm.contrib.concurrency.MonoWorker.pool',
                mock.Mock(wraps=mock.Mock()))
    def test_submit():
        def mock_submit(func, *args, **kwargs):
            return mock.Mock(spec=tqdm_auto.Future())

        MonoWorker.pool.submit.side_effect = mock_submit

        m = MonoWorker()
        val = object()
        func = lambda x: x

        m.pool.submit.assert_not_called()

        # test no change
        r = m.submit(func, val)

# Generated at 2022-06-24 10:03:18.406111
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    try:
        from unittest import mock
    except ImportError:
        mock = None
    if mock is not None:
        worker = MonoWorker()
        func = mock.Mock(wraps=lambda: None)
        worker.submit(func); func.assert_called_once_with()
        args = (1, )
        worker.submit(func, *args); func.assert_called_with(*args)
        kwargs = {'x': 1}
        worker.submit(func, **kwargs); func.assert_called_with(**kwargs)
        args = (1, )
        kwargs = {'x': 1}
        worker.submit(func, *args, **kwargs); func.assert_called_with(*args,
                                                                      **kwargs)
        # test queueing
       

# Generated at 2022-06-24 10:03:23.528841
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def _test_submit(l, n):
        """Return whether this task is the most recent submitted."""
        sleep(0.2)
        l.append(n)
        return n

    l = []
    mw = MonoWorker()
    for i in range(5):
        mw.submit(_test_submit, l, i)

    assert l == [4], "Unexpected result {}".format(l)

# Generated at 2022-06-24 10:03:31.291877
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Thread, Event
    from contextlib import closing

    from ..tqdm import trange

    test_result = []

    def work(i, start, end):
        for j in trange(start, end):
            test_result.append((i, j))
            sleep(0.01)

    def thread_work(i, end):
        t = Thread(target=work, args=(i, end - 5, end))
        t.start()
        return t

    def test_worker():
        with closing(MonoWorker()) as worker:
            thread_end = 5
            threads = (thread_work(i, thread_end) for i in range(8))
            for thread in threads:
                thread.join()


# Generated at 2022-06-24 10:03:39.840315
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    from time import sleep
    mono_worker = MonoWorker()
    for i in range(5):
        mono_worker.submit(sleep, 0.5)
        sleep(1)
    for i in range(5):
        mono_worker.submit(sleep, 1)
        sleep(0.5)
    mono_worker.submit(sleep, 0.3)

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:03:48.430584
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from . import cmd_line_parser
    tests = [
        ['tqdm.contrib.mono: submit', 'tests/test_MonoWorker.py'],
        ['tqdm.contrib.mono: submit', 'tests/test_MonoWorker.py'],
        ['tqdm.contrib.mono: submit', 'tests/test_MonoWorker.py'],
    ]
    mono = MonoWorker()

    def test_func(args):
        print(args)
        time.sleep(1)

    pbar = cmd_line_parser(desc=__doc__)
    for test in pbar(tests):
        mono.submit(test_func, test)
    for future in mono.futures:
        future.result()

# Generated at 2022-06-24 10:03:59.224677
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():  # pragma: no cover
    import time

    def delay_echo(x, sleep=0.2):
        time.sleep(sleep)
        return x

    # test limit of 2 running tasks at a time
    mw = MonoWorker()
    futures = [mw.submit(delay_echo, i, sleep=0.01)
               for i in range(20)]

    # test limit of 2 waiting tasks at a time
    mw = MonoWorker()
    futures = [mw.submit(delay_echo, i, sleep=0.1)
               for i in range(3)]
    for future in futures:
        assert future.result() == 2

    # test exception catching
    mw = MonoWorker()
    for i in range(10):
        future = mw.submit(delay_echo, i)

# Generated at 2022-06-24 10:04:08.985674
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    w = MonoWorker()
    assert w.submit(lambda: print(1))
    assert w.submit(lambda: print(2))  # replaces waiting
    assert len(w.futures) == 1
    assert not w.futures[0].done()
    assert not w.submit(lambda: print(3))  # rejected
    assert len(w.futures) == 1
    assert not w.futures[0].done()
    w.futures[0].result()
    assert w.submit(lambda: print(4))
    assert len(w.futures) == 1
    assert not w.futures[0].done()
    assert not w.submit(lambda: print(5))  # rejected
    assert len(w.futures) == 1
    assert not w.futures

# Generated at 2022-06-24 10:04:15.025465
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Note: this is not (yet?) a proper unit test
    from time import sleep, time
    from random import random

    def fib(n):
        if n < 2:
            return n
        return fib(n - 2) + fib(n - 1)

    start = time()

    def print_result(result):
        print(time() - start, end=' ')
        print(result)

    mw = MonoWorker()
    for _ in range(37):
        mw.submit(fib, 37).add_done_callback(print_result)
        sleep(random())

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:04:24.421010
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """ Unit test for method `submit` of class `MonoWorker` """
    import time
    import pdb
    import sys
    import traceback
    from inspect import isclass
    from concurrent.futures import CancelledError
    # pylint: disable=redefined-outer-name

    # Unit test for method submit of class MonoWorker
    def do_tests():
        """ Unit test for method `submit` of class `MonoWorker` """
        import time
        import multiprocessing

        def noop(t):
            """ do nothing for `t` seconds """
            time.sleep(t)

        def countdown(t):
            """ count down from `t` with a MonoWorker """
            mw = MonoWorker()
            pbar = tqdm_auto.tqdm(total=t)
           

# Generated at 2022-06-24 10:04:30.281148
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def test_waiting(i):
        time.sleep(1)
        return str(i)
    import tqdm.contrib.concurrency as tc
    worker = tc.MonoWorker()
    for i in range(10):
        worker.submit(test_waiting, i)
    # task 10 should have cancelled task 0,
    #  and task 0 should have cancelled task 1
    time.sleep(10)
    assert worker.futures == deque(['8', '9'])

# Generated at 2022-06-24 10:04:40.672798
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import os
    import time
    import webbrowser

    def wait_then_print(*args):
        time.sleep(3)
        return print(*args)

    mono_worker = MonoWorker()

    mono_worker.submit(wait_then_print, "try 1")
    mono_worker.submit(wait_then_print, "try 2")
    mono_worker.submit(wait_then_print, "try 3")

    print("Now do CTRL+C and if 'try 3' is not printed, it's normal.")
    mono_worker.submit(webbrowser.open, "https://github.com/")
    print("wait for webbrowser to open, then press Enter to continue")
    sys.stdin.readline()

    print("The web browser should only have opened once.")

# Generated at 2022-06-24 10:04:44.960816
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    mw = MonoWorker()

    with tqdm_auto.trange(10) as t:
        for i in t:
            t.set_description("test_%s" % i)
            future = mw.submit(time.sleep, 0.1)
            t.refresh()
            future.result()



# Generated at 2022-06-24 10:04:46.445446
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Test constructor of class `MonoWorker`
    """
    MonoWorker()

# Generated at 2022-06-24 10:04:53.471838
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Lock
    from ..utils import _term_move_up

    lock = Lock()

    def run_for(seconds):
        with lock:
            tqdm_auto.write('start')
        sleep(seconds)
        with lock:
            tqdm_auto.write('end')

    mono_worker = MonoWorker()
    print('submit 1 (should start):')
    mono_worker.submit(run_for, 1)
    sleep(1.5)
    _term_move_up()
    print('submit 2 (should start):')
    mono_worker.submit(run_for, 1)
    sleep(1.5)
    _term_move_up()
    print('submit 3 (should be discarded):')

# Generated at 2022-06-24 10:05:02.117677
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    from ..gui import tqdm
    from .async_generator import async_generator

    @async_generator
    def testTask():
        while True:
            yield [random.choice(['a', 'b', 'c', 'd', 'e'])]
            time.sleep(.1)

    # test 1
    def test_1(q, mw):
        with tqdm(async_gen=testTask(),
                  async_kwargs=dict(),
                  desc='test',
                  unit='char',
                  leave=False) as t1:
            while True:
                try:
                    x = q.get_nowait()
                except:
                    x = None
                if x is not None:
                    t1.update(1)

# Generated at 2022-06-24 10:05:05.540137
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.pool._max_workers == 1
    assert mw.futures.maxlen == 2
    assert len(mw.futures) == 0

# Generated at 2022-06-24 10:05:07.223227
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-24 10:05:08.039401
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    pass


# Generated at 2022-06-24 10:05:15.596463
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import TimeoutError
    from ..utils import _term_move_up

    test_name = 'MonoWorker'
    tqdm_auto.write('\n>>> Starting "{0}":'.format(test_name))

    # Create a MonoWorker
    mono = MonoWorker()

    # Create a function to test with
    def test(i):
        time.sleep(i)
        return i

    # Create and submit a bunch of future tests
    tqdm_auto.write('-- Deque with 1 empty slot --')
    f = mono.submit(test, 0.01)
    f = mono.submit(test, 0.02)
    tqdm_auto.write('-- Deque with 2 filled slots --')
    f = mono.submit(test, 0.03)

# Generated at 2022-06-24 10:05:18.688134
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()
    assert m.pool._max_workers == 1
    assert len(m.futures) == 0


# Generated at 2022-06-24 10:05:29.757842
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import itertools
    m = MonoWorker()

    def f(x):
        '''Note: this is not "thread-safe"'''
        f.i += 1
        time.sleep(0.01)
        return x * 2

    f.i = 0

    ls = list(itertools.islice(itertools.count(), 20))
    g = (m.submit(f, x) for x in ls)
    ls_result = []
    for _ in tqdm_auto.tqdm(g, desc='test_MonoWorker_submit'):
        ls_result.append(f.i)

    assert all(ls_result[1:] == ls_result[:-1])
    assert ls_result[0] + len(ls) == ls_result[-1]

# Generated at 2022-06-24 10:05:39.505633
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    from queue import Queue
    from concurrent.futures import wait
    from multiprocessing import cpu_count

    lock = Lock()
    que = Queue()
    worker = MonoWorker()
    for i in list(range(cpu_count())) + [None]:
        worker.submit(que.put, i)
        worker.submit(time.sleep, 100)
        worker.submit(que.put, i)
        worker.submit(time.sleep, 100)
    while True:
        try:
            wait(worker.futures, timeout=0.1)
        except Exception:
            continue
        else:
            break
    with lock:
        assert que.qsize() == cpu_count() + 1

# Generated at 2022-06-24 10:05:48.519970
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # No running, no waiting
    q = MonoWorker()
    assert q.submit(lambda: 0)
    assert len(q.futures) == 1
    # Running and waiting
    q.futures[0].result()
    assert q.submit(lambda: 1)
    assert q.submit(lambda: 2)
    assert len(q.futures) == 2
    assert q.futures[0].result() == 1
    # Try to clear waiting
    assert q.submit(lambda: 3)
    assert len(q.futures) == 2
    assert q.futures[0].result() == 3
    assert q.futures[1].result() == 2
    # Try to raise an exception
    assert not q.submit(lambda: 1/0)

# Generated at 2022-06-24 10:05:53.272684
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import multiprocessing
    import concurrent.futures
    import threading
    with tqdm_auto.tqdm(total=10) as pbar:
        mw = MonoWorker()
        for _ in range(10):
            mw.submit(time.sleep, .1)
            pbar.update()



# Generated at 2022-06-24 10:06:01.824607
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    tqdm_auto.write('\nTesting MonoWorker:')
    m = MonoWorker()

    # action 0
    action = 'action 0'
    tqdm_auto.write(action)
    fut0 = m.submit(time.sleep, 0.1)

    # action 1
    action = 'action 1'
    tqdm_auto.write(action)
    fut1 = m.submit(time.sleep, 0.1)

    # action 2
    action = 'action 2'
    tqdm_auto.write(action)
    fut2 = m.submit(time.sleep, 0.1)

    fut0.result()
    tqdm_auto.write('action 0 passed')
    fut2.result()
    tqdm_auto.write('action 2 passed')
   

# Generated at 2022-06-24 10:06:05.542437
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    mono_worker = MonoWorker()
    for i in range(4):
        mono_worker.submit(sleep, 1)
        mono_worker.submit(sleep, 1)
    sleep(5)
    mono_worker.submit(sleep, 1)
    sleep(5)
# enddef

# Generated at 2022-06-24 10:06:12.657747
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import TimeoutError, wait
    from functools import partial
    from ..utils import format_sizeof
    from random import random

    def print_stats():
        tqdm_auto.write("Queue: {}".format(format_sizeof(
            sum(task.result() for task in mono.futures))))

    import timeit
    mono = MonoWorker()

    task = mono.submit(partial(random).__call__)
    task.add_done_callback(print_stats)
    task = mono.submit(partial(random).__call__)
    task.add_done_callback(print_stats)

    n = timeit.timeit(lambda: mono.submit(partial(random).__call__),
                      number=10) * 1000 * 10

# Generated at 2022-06-24 10:06:18.064834
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    def foo(x):
        sleep(x)
        return x

    mono = MonoWorker()
    assert not mono.futures
    mono.submit(foo, 10)
    assert len(mono.futures) == 1
    mono.submit(foo, 5)
    assert len(mono.futures) == 2
    mono.submit(foo, 1)
    assert len(mono.futures) == 2
    mono.futures[1].result() == 1

# Generated at 2022-06-24 10:06:24.285465
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing import freeze_support
    from time import sleep, time

    def t(x):
        sleep(x)
        return 1 if x == 3 else 0

    freeze_support()
    monoworker = MonoWorker()

    monoworker.submit(t, 1)
    monoworker.submit(t, 2)
    monoworker.submit(t, 3)
    monoworker.submit(t, 4)
    monoworker.submit(t, 5)

    assert monoworker.futures[0].done()
    assert monoworker.futures[1].done()
    assert monoworker.futures[0].result() == 0
    assert monoworker.futures[1].result() == 1



# Generated at 2022-06-24 10:06:34.965074
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test `MonoWorker` object's submission function."""
    import time
    import signal
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    # Create a MonoWorker object
    mono = MonoWorker()
    # Submit some "tasks" and report their completion
    with tqdm_auto.tqdm() as t_bar:
        for i in t_bar:
            # Our "task" is a simple function but can be anything
            def task(delay=2):
                time.sleep(delay)
            # Get time for time comparison
            start = time.time()
            # Submit the task to the MonoWorker
            fut = mono.submit(task, delay=5)
            # Check if the task is complete
            if fut.done():
                tqdm_auto.write

# Generated at 2022-06-24 10:06:36.984684
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    assert MonoWorker()

# Generated at 2022-06-24 10:06:40.056842
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker"""
    worker = MonoWorker()
    assert worker.pool.max_workers == 1
    assert worker.futures.maxlen == 2
    assert len(worker.futures) == 0


# Generated at 2022-06-24 10:06:41.098131
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()



# Generated at 2022-06-24 10:06:47.974522
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    expected_outputs = []
    outputs = []

    def write(msg):
        outputs.append(msg)

    def mock_print(*args, **kwargs):
        msg = "mock-print:" + " ".join(str(a) for a in args)
        write(msg)

    def mock_input(*args, **kwargs):
        msg = "mock-input:" + " ".join(str(a) for a in args)
        write(msg)
        return "terminate"

    def side_effect(*args, **kwargs):
        msg = str(args)
        write(msg)

    def func1(x, y):
        sleep(1)
        return x + y

    def func2(x, y):
        sleep(1)
        return x - y

   

# Generated at 2022-06-24 10:06:55.911195
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # First we define a function that takes time to run
    def time_consuming_operation(i):
        time.sleep(1)
        return i
    # We initialize the MonoWorker
    mono_worker = MonoWorker()
    # And then Submit the function multiple times
    mono_worker.submit(time_consuming_operation, 1)
    mono_worker.submit(time_consuming_operation, 2)
    mono_worker.submit(time_consuming_operation, 3)
    # The result of the third call to submit should be 3
    assert mono_worker.futures[0].result() == 3
    assert mono_worker.futures[1] is None
    # The result of the second call to submit should be None
    assert mono_worker.futures[1] is None
    # The result of the first call to submit should

# Generated at 2022-06-24 10:06:57.438684
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()
    return m


# Generated at 2022-06-24 10:07:06.920443
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from collections import defaultdict

    def func(*args):
        '''Sleeing function'''
        sleep(1)
        return args

    exec_test = MonoWorker()
    exec_test.submit(1)
    func_args = defaultdict(dict)
    func_args[0][0] = func
    func_args[1][1] = func
    func_args[2][2] = func
    func_args[3][3] = func
    func_args[4][4] = func
    func_args[5][5] = func
    for i in range(6):
        assert i in func_args.keys()
        assert i in func_args[i].keys()
        res = exec_test.submit(func_args[i][i], i)
        assert res

# Generated at 2022-06-24 10:07:17.814892
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def wait(interval):
        time.sleep(interval)
        return interval

    wait_short = MonoWorker()
    wait_long = MonoWorker()
    t_start = time.time()

    # submit two long tasks to the long waiting list.
    # the first task will be discarded,
    # and the other task will be executed and then replaced by the next task.
    wait_long.submit(wait, 10)
    wait_long.submit(wait, 10)
    assert len(wait_long.futures) == 1
    wait10 = wait_long.futures[0]
    assert not wait10.done()
    wait_long.submit(wait, 10)
    assert len(wait_long.futures) == 1

# Generated at 2022-06-24 10:07:30.438507
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import as_completed

    from .utils import wrap_for_test

    # three numbers are passed to add(), but only the most recent two are
    # submitted to the MonoWorker.
    def add(a, b, c):
        time.sleep(0.01)
        return a + b + c

    A, B, C = [4, 5, 6]
    m = MonoWorker()

    assert len(m.futures) == 0

    assert m.submit(add, A, B, C)
    assert len(m.futures) == 1

    assert m.submit(add, A, B, C)
    assert len(m.futures) == 1

    # no result yet, there is one waiting then one running

# Generated at 2022-06-24 10:07:38.659922
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from contextlib import contextmanager
    from threading import Lock
    from time import sleep

    lock = Lock()
    max_delay = 0
    expected = None

    @contextmanager
    def delay(n):
        """Simulate time-taking operation."""
        try:
            global max_delay
            sleep(n)
            max_delay = max(max_delay, n)
            yield
        finally:
            sleep(n)
            max_delay = max(max_delay, n)

    def print_test_not_easy():
        """Simulate a function that takes a long time to execute."""
        with lock:
            global max_delay
            with delay(3):
                tqdm_auto.write('"print_test_not_easy"')
                max_delay = 3


# Generated at 2022-06-24 10:07:49.868699
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.futures.maxlen == 2
    mw.submit(tqdm_auto.write, "Hello, world!")
    while not mw.futures:
        pass
    assert mw.futures[0].done()
    mw.submit(tqdm_auto.write, "Foo")
    mw.submit(tqdm_auto.write, "Bar")
    assert len(mw.futures) == 2
    mw.submit(tqdm_auto.write, "Baz")
    assert len(mw.futures) == 2
    assert mw.futures[0].done() or mw.futures[0].running()

# Generated at 2022-06-24 10:08:00.560473
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import time
    import threading

    global counter
    counter = 0

    def func1(name, t):
        global counter
        counter += 1
        time.sleep(t)

    def func2(name):
        global counter
        counter += 1

    def test_func(n):
        global counter
        counter += 1
        time.sleep(0.05)
        try:
            func1(n, 0.05)
            func2(n)
        except Exception as e:
            tqdm_auto.write(e)

    threads = []
    sys.stdout = open('/dev/null', 'w')
    worker = MonoWorker()
    for i in range(1, 50):
        t = threading.Thread(target=worker.submit, args=(test_func, i))


# Generated at 2022-06-24 10:08:09.736861
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def print_pow(x, y):
        """Delayed x**y"""
        tqdm_auto.write(str(x**y))

    from time import sleep
    from concurrent.futures import as_completed

    mw = MonoWorker()
    for x in range(2):
        for y in range(4):
            mw.submit(print_pow, x, y)
            sleep(0.01)
    for future in as_completed(mw.futures):
        future.result()


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:08:20.248136
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from ..auto import tqdm

    c = MonoWorker()
    c.submit(sleep, 0.05)
    c.submit(sleep, 0.05)
    c.submit(sleep, 0.05)  # this will be discarded
    c.submit(sleep, 0.05)
    c.submit(sleep, 0.05)
    for _ in tqdm(range(2)):
        c.futures.popleft().result()  # blocking

    c = MonoWorker()
    c.submit(sleep, 0.05)
    c.submit(sleep, 0.05)
    c.submit(sleep, 0.05)  # this will be discarded
    c.submit(sleep, 0.05)
    c.submit(sleep, 0.05)

# Generated at 2022-06-24 10:08:28.670572
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import cpu_count
    from concurrent.futures import ProcessPoolExecutor, as_completed
    import tqdm

    def func(delay):
        sleep(delay)
        return delay

    results = []
    pbar = tqdm.tqdm()
    worker = MonoWorker()

    for delay in [.1, .5, .9, 1.3, 1.7]:
        future = worker.submit(func, delay)
        assert len(worker.futures) == 1
        if future:
            results.append(future)
        pbar.update()
    assert len(worker.futures) == 1, worker.futures
    future = worker.submit(lambda: 42)
    assert len(worker.futures) == 2, worker.f

# Generated at 2022-06-24 10:08:35.332546
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import NoDaemonPool
    from .tests import stream_writer
    import os
    import time
    try:
        from Queue import Queue
    except ImportError:
        from queue import Queue

    NUM_WORKERS = 2

    # 1) spawn worker threads
    work_queue = Queue()
    for _ in range(NUM_WORKERS):
        worker = MonoWorker()
        worker.pool = NoDaemonPool(max_workers=1)
        worker.submit(stream_writer, work_queue, 'test_MonoWorker_submit1.txt')
        worker.submit(stream_writer, work_queue, 'test_MonoWorker_submit2.txt')
        worker.submit(stream_writer, work_queue, 'test_MonoWorker_submit3.txt')
        worker.shut

# Generated at 2022-06-24 10:08:41.113813
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    pool = worker.pool
    assert len(worker.futures) == 0
    assert isinstance(pool, ThreadPoolExecutor)
    fut1 = worker.submit(id, 1)
    assert len(worker.futures) == 1
    assert isinstance(fut1.done(), bool)
    assert fut1.result() == 1
    assert len(worker.futures) == 0
    fut2 = worker.submit(id, 2)
    assert len(worker.futures) == 1
    fut3 = worker.submit(id, 3)
    assert len(worker.futures) == 2
    assert fut3.result() == 3
    assert fut2.result() == 2
    assert len(worker.futures) == 0

# Generated at 2022-06-24 10:08:52.174201
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import subprocess

    def foo():
        """Sleep for 1 sec"""
        time.sleep(1)
        tqdm_auto.write("Done foo")

    def bar():
        """Sleep for 2 sec"""
        time.sleep(2)
        tqdm_auto.write("Done bar")

    mw = MonoWorker()
    mw.submit(foo)
    assert mw.pool._work_queue.qsize() == 1
    mw.submit(bar)
    assert mw.pool._work_queue.qsize() == 1  # foo replaced by bar
    mw.submit(foo)
    assert mw.pool._work_queue.qsize() == 1  # bar replaced by foo
    mw.submit(foo)
    assert mw.pool._work_queue.qsize()

# Generated at 2022-06-24 10:08:57.721110
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random

    def _gen_random_random_call():
        time.sleep(random.random())
        return random.random()

    mw = MonoWorker()
    for i in tqdm_auto.trange(1000, desc='MonoWorker'):
        t = mw.submit(_gen_random_random_call)
        assert t.result() < 1

# Generated at 2022-06-24 10:09:03.985727
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def wait(secs):
        time.sleep(secs)
        return secs

    # Only one worker, no blocking behaviour
    worker = MonoWorker()
    assert worker.submit(wait, 2)
    assert worker.submit(wait, 1)
    assert worker.submit(wait, 3)
    assert worker.submit(wait, 4)
    assert worker.submit(wait, 4)
    assert worker.submit(wait, 4)
    assert worker.submit(wait, 4)
    # And test if tasks are discarded, and only the last one runs
    res = worker.futures[0].result()
    assert res == 4

# Generated at 2022-06-24 10:09:12.730172
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from random import shuffle
    from tqdm import trange

    mw = MonoWorker()
    for i in trange(4):  # make sure mono
        futures = []
        for j in range(6):
            futures.append(mw.submit(lambda x: sleep(x), 0.1))
        shuffle(futures)
        while futures:  # make sure newest is waiting
            futures.pop().result()

    mw = MonoWorker()
    with tqdm_auto.trange(4) as t:
        for j in range(6):
            future = mw.submit(lambda: sleep(0.1))
            t.update()
            future.result()

if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-24 10:09:17.635562
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    # Define test functions
    def func1():
        return 0
    def func2():
        return 1
    def func3():
        return 2
    # Test submitting of functions
    assert mw.submit(func1)
    assert mw.submit(func2)
    assert mw.submit(func3)

# Generated at 2022-06-24 10:09:27.334238
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import random
    import sys
    mw = MonoWorker()

    def long_blocking_func(sleep_time=0.5, *args, **kwargs):
        time.sleep(sleep_time)
        return 'ok'

    def long_blocking_func_error(sleep_time=0.5, *args, **kwargs):
        time.sleep(sleep_time)
        raise Exception('ERROR')

    completed = []  # in order
    args_list = \
        [[] for _ in range(5)] + \
        [[(i, 'a')] for i in range(5)] + \
        [[(j, 'a', i) for i in range(j)] for j in range(5)] + \
        [[('bar', 'baz')]]
    kwargs

# Generated at 2022-06-24 10:09:34.317294
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    def f(x):
        sleep(x)
        return x**2

    # Single submission
    w = MonoWorker()
    w.submit(f, 1)
    assert w.futures[0].result() == 1
    # Multiple submissions, one waiting
    w = MonoWorker()
    w.submit(f, 1)
    w.submit(f, 2)
    assert w.futures[0].result() == 4
    # Multiple submissions, one running
    w = MonoWorker()
    w.submit(f, 2)
    w.submit(f, 1)
    assert w.futures[0].result() == 4
    # Multiple submissions, one running and one waiting
    w = MonoWorker()
    a = w.submit(f, 2)

# Generated at 2022-06-24 10:09:40.133266
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time

    def func1():
        time.sleep(3)
        return 1

    def func2():
        time.sleep(2)
        return 2

    def func3():
        time.sleep(1)
        return 3

    mono = MonoWorker()
    f1 = mono.submit(func1)
    time.sleep(0.01)
    f2 = mono.submit(func2)
    time.sleep(0.01)
    assert len(mono.futures) == 2
    time.sleep(0.01)
    f3 = mono.submit(func3)
    time.sleep(0.01)
    assert len(mono.futures) == 1

    assert not f1.done()
    assert not f2.done()
    assert f3.done

# Generated at 2022-06-24 10:09:46.359937
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def sleep(s):
        time.sleep(s)  # sleep for a while
    mw = MonoWorker()
    A = mw.submit(sleep, 3)
    time.sleep(0.1)
    B = mw.submit(sleep, 0.5)
    time.sleep(2)
    D = mw.submit(sleep, 1.5)
    time.sleep(1.4)
    C = mw.submit(sleep, 2.5)
    print(A.result(), B.result(), C.result(), D.result())

# Generated at 2022-06-24 10:09:57.673965
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def pause_test(seconds):
        time.sleep(seconds)
        return seconds

    def pause_test_tqdm(seconds):
        for _ in tqdm_auto(_range(seconds)):
            time.sleep(1)
        return seconds

    # Test Pausing
    test_mono = MonoWorker()
    test_mono.submit(pause_test_tqdm, 2)
    time.sleep(1)
    test_mono.submit(pause_test_tqdm, 3)
    time.sleep(5)

    # Test Waiting
    test_mono = MonoWorker()
    test_mono.submit(pause_test, 2)
    time.sleep(3)
    test_mono.submit(pause_test, 3)


# Generated at 2022-06-24 10:10:07.382669
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from threading import Thread
    import queue

    def test_worker(name, delay, queue):
        """Test worker"""
        time.sleep(delay)
        queue.put("{} finished".format(name))

    def start_thread(name, delay):
        """Start a thread"""
        test_queue = queue.Queue()
        thread = Thread(target=test_worker, args=(name, delay, test_queue))
        thread.start()
        return test_queue

    worker = MonoWorker()
    # Start a thread and wait for completion
    first_thread = start_thread("first", 0.25)
    second_thread = start_thread("second", 0.5)
    third_thread = start_thread("third and last", 0.75)

    # Check if we get the expected answer
    assert first

# Generated at 2022-06-24 10:10:14.458748
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Value
    from multiprocessing.pool import NoWorkersAvailable
    import re

    def f(x, sleep_time=0.1, raises=False, exception=Exception):
        sleep(sleep_time)
        if raises:
            raise exception("Error while sleeping %0.1f seconds" % sleep_time)
        return x

    class Int(Value):
        def __int__(self):
            return self.value

    m = MonoWorker()
    n = 50  # Number of tasks
    a = 0  # Number of successfully executed tasks
    for i in range(n):
        sleep_time = (n - i) * 0.01
        future = m.submit(f, i, sleep_time)

# Generated at 2022-06-24 10:10:22.791509
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from math import exp
    from random import random
    from time import sleep

    # noinspection PyPackageRequirements
    from nose.tools import assert_equal, assert_true, assert_raises

    def wait(n):
        sleep(n * random())
        if 1.0 / (1 + exp(n)) < random():
            raise Exception('Oops...')
        return '%g' % n

    worker = MonoWorker()
    assert_equal(worker.futures.maxlen, 2)
    assert_equal(len(worker.futures), 0)  # empty
    assert_true(worker.submit(wait, 1.5).result(5), '1.5')  # running
    wait(0)
    assert_raises(Exception, lambda: worker.submit(wait, 1.5).result(0)) 

# Generated at 2022-06-24 10:10:27.712214
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..pandas import tqdm
    from time import sleep

    def f(x, y, z=0, sleep=sleep):
        sleep(z)
        return x + y

    m = MonoWorker()

    for i in tqdm(range(4)):
        for j in tqdm(range(4)):
            for k in tqdm(range(1, 4)):
                m.submit(f, i, j, z=k/10)
    m.pool.shutdown()

# Generated at 2022-06-24 10:10:36.743272
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
  import datetime
  MonoWorker().submit(print, "test")
  MonoWorker().submit(print, "test")
  MonoWorker().submit(print, "test")
  MonoWorker().submit(print, "test")
  MonoWorker().submit(print, "test")
  MonoWorker().submit(print, "test")
  MonoWorker().submit(print, "test")
  MonoWorker().submit(print, "test")
  MonoWorker().submit(print, "test")
  MonoWorker().submit(print, "test")
  MonoWorker().submit(print, "test")



# Generated at 2022-06-24 10:10:43.079154
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def fail(*args, **kwargs):
        raise TypeError

    def sleep(t):
        import time
        time.sleep(t)

    worker = MonoWorker()
    assert len(worker.futures) == 0
    assert not isinstance(worker.pool, ThreadPoolExecutor)

    # submit fails
    res = worker.submit(fail)
    assert res is None
    res = worker.submit(fail)
    assert res is None
    res = worker.submit(fail, 1)
    assert res is None
    res = worker.submit(fail, 1, 2)
    assert res is None

    # submit ok
    res = worker.submit(sleep, 0.01)

    # submit ok, but faster than previous function
    res2 = worker.submit(sleep, 0.1)

    # wait for function to complete

# Generated at 2022-06-24 10:10:54.811514
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import sys
    import time
    m = MonoWorker()
    a = m.submit(time.sleep, 1)
    m.submit(time.sleep, 1)
    time.sleep(.5)
    sys.stdout.write('\n')
    b = m.submit(time.sleep, 2)
    c = m.submit(time.sleep, 2)
    sys.stdout.write('\n')
    for _ in tqdm_auto.trange(3):
        time.sleep(1)
        sys.stdout.write('\n')
    d = m.submit(time.sleep, 2)
    e = m.submit(time.sleep, 2)
    sys.stdout.write('\n')
    # >>>
    #   b,c,d,e
    #   a,

# Generated at 2022-06-24 10:11:05.349201
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys
    mw = MonoWorker()

    def work(nap):
        time.sleep(nap)
        return nap

    def test_naps(naps):
        with tqdm_auto.tqdm(total=len(naps), leave=False, file=sys.stdout) as t:
            work(naps[0])
            for nap in naps[1:]:
                mw.submit(work, nap)
                t.update()
        del t

    test_naps([1] * 4)
    test_naps([1] * 2 + [2])
    test_naps([1] * 2 + [3] + [1])

# Generated at 2022-06-24 10:11:16.008933
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from collections import Counter
    from concurrent.futures import CancelledError
    from assertpy import assert_that

    class MockFuture(object):
        """ Implements `.result()` and `.done()`. """
        def __init__(self, _result, _done):
            self._result = _result
            self._done = _done

        def result(self):
            return self._result

        def done(self):
            return self._done

    def mock_submit(func, *args, **kwargs):
        return MockFuture(func(*args, **kwargs), True)

    def mock_write(output):
        global writes
        writes.append(output)

    mw = MonoWorker()
    mw.pool.submit = mock_submit

# Generated at 2022-06-24 10:11:26.193105
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import current_thread

    def worker(task, i):
        """Process task `i`."""
        def _worker(task, i):
            sleep(0.2)
            task.append(i)  # add `i` as next task
            task[0].add(current_thread().ident)  # add thread to list
        return _worker(task, i)

    # Initialise threads and task list
    workers = MonoWorker()
    task = [[], None]
    threads = set()


# Generated at 2022-06-24 10:11:32.212514
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def run_with_delay(sleep_time):
        time.sleep(sleep_time)
        return sleep_time

    worker = MonoWorker()
    for _ in tqdm_auto.tqdm(range(5)):
        worker.submit(run_with_delay, random.random() * 0.5)
    worker.pool.shutdown(wait=True)

# Generated at 2022-06-24 10:11:39.974094
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test `MonoWorker` constructor."""
    import time

    def do_foo(x):
        time.sleep(x)
        return x

    def do_bar(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    f1 = mw.submit(do_foo, 1)
    f1.result()  # wait for result
    f2 = mw.submit(do_foo, 2)
    f2.result()  # wait for result
    f3 = mw.submit(do_bar, 3)
    f3.result()  # wait for result
    f4 = mw.submit(do_bar, 4)

# Generated at 2022-06-24 10:11:49.684774
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def wait_secs(iwait, nm="task"):
        from time import sleep
        from sys import stdout
        tqdm_auto.write("\nIn {} to wait {} secs".format(
            nm, iwait), file=stdout)
        sleep(iwait)
        tqdm_auto.write("\n{} finished!".format(nm), file=stdout)

    mw = MonoWorker()
    mw.submit(wait_secs, iwait=1, nm="task_1")
    mw.submit(wait_secs, iwait=1, nm="task_2")
    mw.submit(wait_secs, iwait=1, nm="task_3")
    mw.submit(wait_secs, iwait=1, nm="task_4")
    mw

# Generated at 2022-06-24 10:11:56.648072
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import gc
    from concurrent.futures import CancelledError

    class TestObject(object):
        def running(self):
            time.sleep(2)
            return 42

        def waiting(self):
            time.sleep(2)
            return 21

    t = TestObject()
    mw = MonoWorker()
    running = mw.submit(t.running)
    waiting = mw.submit(t.waiting)
    time.sleep(1)
    assert running.running()
    assert waiting.done()
    assert not waiting.cancelled()
    assert waiting.running()
    assert running.done()
    assert running.result() == 42
    assert waiting.result() == 21
    del running
    del waiting
    del mw
    gc.collect()