

# Generated at 2022-06-24 10:02:05.131525
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading
    lock = threading.Lock()
    a = []
    def f(x):
        lock.acquire()
        a.append(x)
        lock.release()
        time.sleep(0.1)
    m = MonoWorker()
    threads = []
    for i in range(10):
        threads.append(threading.Thread(target=m.submit, args=(f, i)))
        threads[-1].start()
    for i in range(10):
        threads[i].join()
    assert a == [9]
    m.pool.shutdown()

# Generated at 2022-06-24 10:02:16.847243
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint
    import threading
    from ..utils import SimpleNamespace
    from itertools import count

    task_id = count()

    class Task(object):
        def __init__(self, task_id):
            self.task_id = task_id

        def run(self, sleep_time=0, except_on=None):
            tqdm_auto.write("Running task {0.task_id}".format(self))
            if except_on is not None and next(task_id) == except_on:
                raise Exception("Exception in task {0.task_id}".format(self))
            sleep(sleep_time)
            tqdm_auto.write("Finished task {0.task_id}".format(self))


# Generated at 2022-06-24 10:02:27.180996
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from random import random
    from concurrent.futures import TimeoutError

    # Instantiate tester
    m = MonoWorker()

    # Test constructor
    assert len(m.futures) == 0

    # Test submit functionality
    def rnd_sleep(time_in_sec):
        sleep(time_in_sec * (1 + random()))
        return time_in_sec

    # Test 1: test 1 sub submit (without timeout)
    start_time = tqdm_auto.default_timer()
    f0 = m.submit(rnd_sleep, 3)
    assert not f0.done()
    end_time = tqdm_auto.default_timer()
    assert end_time - start_time < 3 + 1e-2
    f0.result()
    end_

# Generated at 2022-06-24 10:02:30.218657
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert len(worker.futures) == 0
    assert worker.pool._max_workers == 1
    assert worker.pool._max_workers == worker.pool._work_queue.maxsize


# Generated at 2022-06-24 10:02:34.207606
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Tests if MonoWorker works as expected.
    """
    import time

    def _sleep_sort(n):
        time.sleep(n)
        return n

    mono = MonoWorker()
    for i in range(10):
        mono.submit(_sleep_sort, i)
        time.sleep(0.1)



# Generated at 2022-06-24 10:02:41.895173
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """ Do not run during packagings """
    from multiprocessing import TimeoutError

    Calls = [0]

    def func():
        Calls[0] += 1
        # print('func')
        raise TimeoutError

    mw = MonoWorker()

    # Submit
    assert not mw.submit(func)
    assert mw.submit(func)
    assert mw.futures[0].running()
    assert not mw.futures[0].done()
    assert Calls[0] == 1
    mw.futures[0].result(0)  # should get exception
    assert Calls[0] == 2
    mw.submit(func)
    assert Calls[0] == 3
    mw.futures[0].result(0)
    assert Calls[0] == 4
   

# Generated at 2022-06-24 10:02:45.808309
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker."""
    MonoWorker()


if __name__ == '__main__':
    from os import path
    # this if statement is needed to prevent recursive import in Python < 3.4
    import pytest
    pytest.main([path.abspath(__file__)])

# Generated at 2022-06-24 10:02:56.973377
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from datetime import datetime
    from unittest.mock import MagicMock
    from concurrent.futures import Future

    def sleep_task(i):
        sleep(i)
        return i

    # noinspection PyUnusedLocal
    def _check_futures(mock_func, futures, waiting_task, running_task,
                       max_workers_len=1, waiting_size=1, running_size=1,
                       waiting_task_size=1, running_task_size=1,
                       tasks=[0, 1, 2, 3]):
        assert futures.maxlen == max_workers_len + waiting_size
        assert len(futures) == running_size + waiting_size
        assert isinstance(futures[0], Future)

# Generated at 2022-06-24 10:03:02.945012
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import itertools
    import time
    from os import getcwd
    from os.path import basename
    from ..std.time import sleep
    from .tqdm_notebook import tqdm as tqdm_notebook
    from .tqdm import tqdm as tqdm_cli

    class Counter(MonoWorker):
        """
        Summary:

        Global instantiation: ``c = Counter()``

        Common use: ``c.submit(basename, getcwd())``
        """

        def __init__(self, iterable=[], desc=None, leave=False,
                     **kwargs):  # noqa: A002
            super(Counter, self).__init__()

# Generated at 2022-06-24 10:03:07.850682
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from .string import _basicsizeof
    import gc
    import random

    # prime memory use
    x = [None] * 1024
    x = []
    # x = [1, 5, 9]
    # x = list(range(1024))
    # x = list(range(1024 * 1024))
    # x = list(range(1024 * 1024 * 8))
    # x = list(range(1024 * 1024 * 16))
    # x = list(range(1024 * 1024 * 32))
    # x = list(range(1024 * 1024 * 32 * 2))

    # wait for idle memory
    for i in tqdm_auto.tqdm(range(10), desc="wait for idle"):
        sleep(.1)


# Generated at 2022-06-24 10:03:16.617276
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for `MonoWorker`."""
    import time

    def time_consuming_function(time_param, sleep_time):
        time.sleep(sleep_time)
        return time_param

    m = MonoWorker()
    f1 = m.submit(time_consuming_function, 1, 10)
    f2 = m.submit(time_consuming_function, 2, 0)
    done2, done1 = False, False
    for j in range(0, 20):
        for i in range(0, 5):
            if f1.done():
                done1 = True
            if f2.done():
                done2 = True
            time.sleep(0.1)
        if done1 and done2:
            break
    if not (done1 and f1.result() == 1):
        raise Value

# Generated at 2022-06-24 10:03:25.242996
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from itertools import count
    def task(i, sleeptime):
        sleep(sleeptime)
        return i

    worker = MonoWorker()
    for i, sleeptime in zip(count(), [2, 3, 10, 1, 5, 1, 1, 1, 1, 1]):
        worker.submit(task, i, sleeptime)

    finish = False
    while not finish:
        sleep(1)
        if len(worker.futures) == 1:
            assert worker.futures[0].result() == 5
            finish = True

    worker.pool.shutdown()
    assert len(worker.futures) == 0

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 10:03:32.504869
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from sys import version_info
    from concurrent.futures import ThreadPoolExecutor
    from unittest import TestCase, main

    class MonoWorkerTest(TestCase):
        """Test for MonoWorker class."""

        def setUp(self):
            self.mw = MonoWorker()

        def test_submit(self):
            """Test MonoWorker submit method."""
            self.assertEqual(len(self.mw.pool._threads), 0)
            self.assertEqual(len(self.mw.futures), 0)

            # first task (started)
            task1 = self.mw.submit(lambda x: x, 1)
            self.assertEqual(len(self.mw.pool._threads), 1)

# Generated at 2022-06-24 10:03:35.649961
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def job(seconds):
        time.sleep(seconds)
        return "done"

    mono = MonoWorker()
    print("Start running")
    result = mono.submit(job, 1)
    print("Start waiting")
    time.sleep(0.5)
    result = mono.submit(job, 0.1)
    print("Done waiting")
    print(result.result())



# Generated at 2022-06-24 10:03:42.854543
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from collections import defaultdict
    from concurrent.futures import ThreadPoolExecutor
    from functools import partial

    d = defaultdict(lambda: 0)
    d[1] = 0

    def func(i):
        d[1] += i

    def test_work(i):
        func(i)

    def test_wait(i):
        func(i)
        return d[1]

    with ThreadPoolExecutor(max_workers=1) as pool:
        work = partial(pool.submit, test_work)
        wait = partial(pool.submit, test_wait)

        work(2)
        assert d[1] == 0
        work(3).result()
        assert d[1] == 5
        assert wait(4).result() == 9
        assert wait(3).result() == 7

       

# Generated at 2022-06-24 10:03:50.819896
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    try:
        tqdm_auto.write("Test 1: Test constructor success")
        mw = MonoWorker()
        assert mw is not None
    except Exception as e:
        tqdm_auto.write("Test 1: Constructor failed" + str(e))
        raise e
    return

# Generated at 2022-06-24 10:03:52.188087
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker."""
    MonoWorker()


# Generated at 2022-06-24 10:03:56.366856
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def slow(n):
        time.sleep(n)
        return n

    mw = MonoWorker()
    for i in range(4):
        mw.submit(slow, i)

# Generated at 2022-06-24 10:04:04.807338
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    print("Testing MonoWorker.submit()")
    import multiprocessing
    from ._utils import _TestExecutorHelper
    from time import sleep
    from os import getpid
    from copy import deepcopy
    NUM_THREADS = 2
    d = NUM_THREADS // 2 + 1
    NUM_WORKER_THREADS = multiprocessing.cpu_count() // 2 + 1

    def do_work(timeout):
        sleep(timeout)
        return getpid()

    def check_for_duplicates(l):
        for item in l:
            if l.count(item) > 1:
                return False
        return True

    def check_for_discarded_work(pids, discarded_pids):
        for pid in pids:
            if pid in discarded_pids:
                return False


# Generated at 2022-06-24 10:04:12.461008
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    global out
    out = []
    def func(i):
        out.append("start %r" % i)
        time.sleep(1)
        out.append("stop %r" % i)
    global mw
    mw = MonoWorker()
    t0 = time.time()
    mw.submit(func, 0)
    mw.submit(func, 1)
    time.sleep(0.3)
    mw.submit(func, 2)
    time.sleep(0.3)
    mw.submit(func, 3)
    time.sleep(0.3)
    mw.submit(func, 4)
    time.sleep(0.3)
    mw.submit(func, 5)
    time.sleep(0.3)

# Generated at 2022-06-24 10:04:18.801104
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    mw = MonoWorker()
    assert len(mw.futures) == 0

    # Submit stuff
    ret1 = mw.submit(time.sleep, 2)
    assert len(mw.futures) == 1
    assert not ret1.done()
    ret2 = mw.submit(time.sleep, 4)
    assert len(mw.futures) == 2
    assert not ret2.done()
    ret3 = mw.submit(time.sleep, 6)
    assert len(mw.futures) == 2
    assert ret3.done()
    # Wait for `mw` not to be busy
    while mw.futures:
        time.sleep(1)
    assert len(mw.futures) == 0

# Generated at 2022-06-24 10:04:26.349314
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    class A(object):
        def __init__(self):
            self.foo = False
            self.bar = False

        def foo_func(self):
            self.foo = True

        def bar_func(self):
            self.bar = True

    a = A()
    worker = MonoWorker()
    worker.submit(a.foo_func)
    assert not a.foo
    worker.submit(a.bar_func)
    assert not a.bar
    worker.submit(a.bar_func)
    assert not a.bar
    worker.submit(a.bar_func)
    assert not a.bar
    a.foo = False
    assert not a.foo



# Generated at 2022-06-24 10:04:32.042526
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import numpy as np
    from . import tqdm_pandas

    def my_func(x, sleep):
        time.sleep(sleep)
        return np.abs(x)

    df = pd.DataFrame({'a': range(10), 'b': np.random.rand(10)})
    tqdm_df = tqdm_pandas(desc='Applying function...', leave=False)
    df['a'] = tqdm_df.progress_apply(
        my_func, axis=1, args=(0.01,))
    assert df['a'][0] == 0

# Generated at 2022-06-24 10:04:37.952837
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    m = MonoWorker()
    assert m.submit(time.sleep, 0.01).result(timeout=0.01) is None
    assert m.submit(time.sleep, 0.01).cancel()
    m.submit(time.sleep, 0.01)
    assert m.submit(time.sleep, 0.01) is None


# ======================== Unit Testing ======================== #



# Generated at 2022-06-24 10:04:45.278499
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()
    def square(x):
        return x * x

    # submit two tasks, each should be run
    res1 = mw.submit(square, 5)
    res2 = mw.submit(square, 6)
    assert res1.result() == 25
    assert res2.result() == 36

    # submit a third task, only the last should be run
    res3 = mw.submit(square, 7)
    assert res2.result() == 36  # first task should still be 36
    assert res3.result() == 49  # but new task should be 49

    # submit a fourth task, only the last should be run
    res4 = mw.submit(square, 8)
    assert res3.result() == 49  # 3rd task should still be 49
    assert res4.result()

# Generated at 2022-06-24 10:04:46.362645
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker."""
    m = MonoWorker()
    assert isinstance(m, MonoWorker)

# Generated at 2022-06-24 10:04:50.104581
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from collections import deque
    M = MonoWorker()
    M.pool
    assert isinstance(M.pool, ThreadPoolExecutor)
    assert len(M.futures) == 0
    assert isinstance(M.futures, deque)
    assert M.futures.maxlen == 2



# Generated at 2022-06-24 10:05:00.040130
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading
    def sleep(seconds):  # noqa
        time.sleep(seconds)
        return seconds

    mw = MonoWorker()

    num = 5
    start = time.time()
    for _ in range(num):
        ft = mw.submit(sleep, .1)
        ft.result()
    assert len(mw.futures) == 1
    assert time.time() - start >= .1
    assert time.time() - start < .2

    num = 3
    start = time.time()
    for _ in range(num):
        ft = mw.submit(sleep, .1)
        assert ft.result() == .1
    assert len(mw.futures) == 1
    assert time.time() - start >= .1
    assert time.time()

# Generated at 2022-06-24 10:05:01.529415
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test the constructor of the class MonoWorker"""
    a = MonoWorker()

    # Test the attributes of the instance
    assert a.futures

# Generated at 2022-06-24 10:05:09.430166
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def t_submitted(t):
        """Delay task t seconds."""
        time.sleep(t)
        return t

    mw = MonoWorker()

    fut10 = mw.submit(t_submitted, 10)
    fut20 = mw.submit(t_submitted, 20)
    fut25 = mw.submit(t_submitted, 25)
    assert not fut25.done()
    try:
        assert fut20.done()
    except:
        pass
    else:
        raise Exception("MonoWorker did not cancel previous task!")

    assert fut25.result() == 25

# Generated at 2022-06-24 10:05:18.876203
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def do_something(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert mw.submit(do_something, 1).result() == 1
    assert mw.submit(do_something, 1).result() == 1
    assert mw.submit(do_something, 2).result() == 1
    mw.submit(do_something, 3)
    assert mw.submit(do_something, 4).result() == 4
    assert mw.submit(do_something, 5).result() == 4



# Generated at 2022-06-24 10:05:21.588496
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    with tqdm_auto.tqdm(total=100) as t:
        MonoWorker()
        t.update()


# Generated at 2022-06-24 10:05:31.801145
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def wai(i):
        for _ in tqdm_auto(range(i), desc=str(i)):
            pass

    worker = MonoWorker()

    assert not worker.futures
    worker.submit(wai, 100)
    assert len(worker.futures) == 1
    worker.submit(wai, 1000)
    assert len(worker.futures) == 2
    worker.submit(wai, 10)
    assert len(worker.futures) == 2
    worker.submit(wai, 10000)
    assert len(worker.futures) == 2
    worker.submit(wai, 1)
    assert len(worker.futures) == 2
    worker.submit(wai, 1000)
    assert len(worker.futures) == 2

# Generated at 2022-06-24 10:05:37.283032
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import time

    m = MonoWorker()

    def f(i):
        time.sleep(2)
        sys.stdout.write(str(i + 1))

    m.submit(f, 0)
    m.submit(f, 1)

    sys.stdout.write('\n')

    assert sys.stdout.getvalue() == '\n1'

# Generated at 2022-06-24 10:05:45.536677
# Unit test for constructor of class MonoWorker
def test_MonoWorker():

    from concurrent.futures import Future
    from time import sleep

    def check_futures_states(*states):
        assert len(c.futures) == len(states)
        for i, st in enumerate(states):
            assert isinstance(c.futures[i], Future)
            assert c.futures[i].done() == st


    c = MonoWorker()

    f1 = c.submit(sleep, 1)
    check_futures_states(False, None)  # 1 running

    f2 = c.submit(sleep, 1)
    check_futures_states(False, False)  # 2 waiting

    sleep(0.1)
    check_futures_states(False, True)  # 1 running, 1 waiting


# Generated at 2022-06-24 10:05:50.325849
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading

    def do_work(sleep_seconds):
        time.sleep(sleep_seconds)
        return time.time()

    # Create worker
    worker = MonoWorker()
    # Test submission of a task
    for i in range(4):
        print('Submitting task', i)
        worker.submit(do_work, random.randint(3, 9))
    # Wait for all tasks to complete
    for f in worker.futures:
        f.result()

# Generated at 2022-06-24 10:06:00.384029
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .thread import mp_context
    from . import trange
    from multiprocessing import Pool

    def worker(x):
        time.sleep(0.1)
        return x**x

    n = 20
    mw = MonoWorker()
    p = Pool(1)
    with trange(n, desc='Submit') as t:
        for i in t:
            f = mw.submit(worker, i)
            if i == 5:
                tqdm_auto.write('First\n')
            if i == 10:
                tqdm_auto.write('First+Last\n')
            if f is not None:
                t.refresh()
                tqdm_auto.write('Worker: {}'.format(f.result()))

# Generated at 2022-06-24 10:06:08.059716
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Create dummy functions
    def fun(*args, **kwargs):
        return args, kwargs
    def click():
        return
    def click2():
        return
    def fail(a):
        raise ValueError(a)
    def fail2(a):
        raise ValueError(a)
    # Load MonoWorker
    monoworker = MonoWorker()
    # Check that submit is able to run the functions
    monoworker.submit(fun)
    monoworker.submit(click)
    monoworker.submit(click2)
    # Check that exceptions are properly printed
    monoworker.submit(fail, "a")
    monoworker.submit(fail2, "b")

# Generated at 2022-06-24 10:06:12.730621
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .sleep import sleep_task
    from time import time
    FUTURE_TIMEOUT = 1.  # seconds
    worker = MonoWorker()
    t0 = time()
    worker.submit(sleep_task, FUTURE_TIMEOUT * 3)
    worker.submit(sleep_task, FUTURE_TIMEOUT * 2)
    worker.submit(sleep_task, FUTURE_TIMEOUT * 1)
    assert time() - t0 < FUTURE_TIMEOUT * 1.5

# Generated at 2022-06-24 10:06:20.611567
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def e(x):
        if x == 'e':
            raise Exception(x)
        return x

    def f(a, b):
        return a + b

    m = MonoWorker()

    assert len(m.futures) == 0
    assert m.submit(f, 2, b=4).result() == 6
    assert len(m.futures) == 1

    assert m.submit(f, 3, b=7).result() == 10
    assert len(m.futures) == 1

    assert m.submit(e, 'x').result() == 'x'
    assert m.submit(e, 'y').result() == 'y'
    assert len(m.futures) == 1

    assert m.submit(e, 'z').result() == 'z'

# Generated at 2022-06-24 10:06:25.981083
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()

    f1 = mw.submit(lambda: tqdm_auto.write('hello'))
    f2 = mw.submit(lambda: tqdm_auto.write('world'))
    f3 = mw.submit(lambda: tqdm_auto.write('foo'))
    f4 = mw.submit(lambda: tqdm_auto.write('bar'))


if __name__ == '__main__':
    import sys
    test_MonoWorker_submit()

# Generated at 2022-06-24 10:06:30.380791
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def raise_exc():
        raise Exception("test")
    mono = MonoWorker()
    assert len(mono.futures) == 0
    mono.submit(raise_exc)
    assert len(mono.futures) == 1
    mono.submit(raise_exc)
    assert len(mono.futures) == 1

# Generated at 2022-06-24 10:06:36.743711
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import _range

    def test_thread(x):
        from threading import Thread
        from time import sleep

        def inner(_, x, sleep_time):
            sleep(sleep_time)
            return x

        thr = Thread(target=inner, args=(None, x, 0.01 * x * x))
        thr.start()
        return thr

    mw = MonoWorker()
    for i in _range(31):
        mw.submit(test_thread, i)
    assert len(mw.futures) == 2  # 1 running, 1 waiting
    mw.futures[0].result()
    assert len(mw.futures) == 1  # 1 running
    mw.futures[0].result()

# Generated at 2022-06-24 10:06:37.311094
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert MonoWorker().futures.maxlen == 2

# Generated at 2022-06-24 10:06:45.919490
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test `tqdm.contrib.MonoWorker.submit()`."""
    import time
    from ..auto import trange

    def test_func(i):
        time.sleep(1)
        return 42 / i

    class MonoWorkerBkp(MonoWorker):

        # overwrite cancel of concurrent.futures.Future
        def cancel(self, *args, **kwargs):
            print('cancelled')
            return super(MonoWorkerBkp, self).cancel(*args, **kwargs)

    mono_worker = MonoWorkerBkp()

    for i in trange(4, leave=False):
        mono_worker.submit(test_func, i)

    for i in trange(4, leave=False):
        mono_worker.submit(test_func, i)

# Generated at 2022-06-24 10:06:54.998706
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Lock
    import sys
    import os

    lock = Lock()
    m = MonoWorker()
    assert len(m.futures) == 0
    print(m.futures)
    for n in range(4):
        m.submit(sleep, n)
    sleep(0.1)
    print(m.futures)
    assert len(m.futures) == 1
    m.submit(sleep, 4)  # replace
    sleep(0.1)
    print(m.futures)
    assert len(m.futures) == 1
    m.submit(sleep, 5)  #replace
    sleep(0.1)
    print(m.futures)
    assert len(m.futures) == 1
   

# Generated at 2022-06-24 10:06:58.964972
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    mw = MonoWorker()
    for _ in range(5):
        tqdm_auto.write('iteration {}'.format(_))
        mw.submit(sleep, .1)
    mw.pool.shutdown()

# Generated at 2022-06-24 10:07:05.038494
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    '''
    Submit two `futures` tasks - one running and one waiting, then another
    waiting. The second waiting task is discarded.
    '''
    def _func(delay):
        '''
        This function is used as a task for the `MonoWorker` to execute.
        It uses the `tqdm.write()` to print a line of text.
        '''
        # Delay execution for `delay` seconds
        import time
        time.sleep(delay)
        tqdm_auto.write("Task executed")

    # Instantiate a `MonoWorker` object
    worker = MonoWorker()

    # Submit the _func function as a task, with a delay of 10 seconds
    future1 = worker.submit(_func, 10)
    # Submit another _func function as a task, with a delay of 15 seconds


# Generated at 2022-06-24 10:07:16.377711
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys
    from concurrent.futures import CancelledError

    def print_current_time(wait_seconds=0, num_repeats=1):
        for i in tqdm_auto(range(num_repeats), desc=str(wait_seconds),
                           leave=True, total=num_repeats):
            time.sleep(wait_seconds)
            sys.stdout.write(time.ctime() + '\n')
            sys.stdout.flush()

    print_current_time()
    print_current_time(10)

    mono_worker = MonoWorker()
    sys.stdout.write('Submit 2 tasks\n')
    sys.stdout.flush()
    task1 = mono_worker.submit(print_current_time, 5, 1)
    task2 = mono_

# Generated at 2022-06-24 10:07:21.516607
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()
    def foo():
        time.sleep(.5)
        return True
    mw.submit(foo)
    mw.submit(foo)  # does not replace waiting task
    assert mw.futures[0].result() is True
    for _ in range(5):
        mw.submit(foo)  # should replace running task
    assert mw.futures[0].result() is True

# Generated at 2022-06-24 10:07:23.009293
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()



# Generated at 2022-06-24 10:07:29.223445
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    mw = MonoWorker()

    def sleeper(*args, **kwargs):
        time.sleep(1)
        return args[0]

    x = mw.submit(sleeper, "a")
    assert x.result() == "a"
    y = mw.submit(sleeper, "b")
    z = mw.submit(sleeper, "c")
    assert y.result() == "b"
    assert z.result() == "b"

# Generated at 2022-06-24 10:07:37.988984
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Thread

    m = MonoWorker()
    assert m.pool.max_workers == 1
    assert len(m.futures) == 0

    def count():
        """Generate numbers forever."""
        num = 0
        while True:
            sleep(0.1)
            yield num
            num += 1

    t = Thread(target=count)
    t.daemon = True
    t.start()

    def start(x):
        return next(x)

    a = m.submit(start, count())
    sleep(0.2)
    assert len(m.futures) == 1
    assert a.result() == 0
    b = m.submit(start, count())
    sleep(0.2)
    assert len(m.futures) == 1

# Generated at 2022-06-24 10:07:49.290479
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..auto import tqdm
    from ..utils import _supports_unicode
    if not _supports_unicode():
        return
    mw = MonoWorker()

# Generated at 2022-06-24 10:07:59.809171
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import seed, uniform
    from threading import Thread

    # set random seed for reproducibility
    seed(4)

    mw = MonoWorker()

    check_list = []

    # mock function
    def func(x):
        # sleep for a random duration between 0 and 0.1 seconds
        sleep(uniform(0, .1))
        check_list.append(x)

    # start a thread to asynchronously call mw.submit with random parameters
    def thread_func():
        while True:
            x = uniform(0, 1)
            mw.submit(func, x)
            sleep(uniform(0, .1))

    thread = Thread(target=thread_func)
    thread.start()

    # wait for a duration of two seconds
    sleep(2)



# Generated at 2022-06-24 10:08:07.052687
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    from time import sleep

    class EventPool(MonoWorker):
        def wait_for_event(self, e):
            sleep(1)
            e.set()

    pool = EventPool()
    e = Event()
    pool.submit(pool.wait_for_event, e)
    sleep(0.5)
    assert not e.wait(0.5)
    assert e.wait(1)

# Generated at 2022-06-24 10:08:13.276395
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test class MonoWorker"""
    import time

    def f(slow, x, *args, **kwargs):
        """Sleep and return args"""
        time.sleep(slow)
        return x, args, kwargs

    from concurrent.futures import as_completed
    mono = MonoWorker()
    tqdm_auto.write("Test two fast ones, two slow ones, two faster ones")
    with tqdm_auto.tqdm(total=6, ncols=80) as t:
        futs = [mono.submit(f, 0.1, i) for i in range(5)]
        futs.append(mono.submit(f, 0.5, -1))

# Generated at 2022-06-24 10:08:21.052672
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from ..utils import _range

    def func(i):
        time.sleep(.1)
        return i

    mw = MonoWorker()

    for i in _range(10):
        mw.submit(func, i)
        time.sleep(random.uniform(0, .05))
        tqdm_auto.write("waiting: {0} running: {1}".format(
            sum(1 for f in mw.futures if not f.done()),
            sum(1 for f in mw.futures if f.done()) - 1))

# Generated at 2022-06-24 10:08:24.597487
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def f(n):
        sleep(random())
        return n

    l = []
    mw = MonoWorker()
    for i in range(10):
        l.append(mw.submit(f, i))
    for i in range(10):
        values = [l[i].result() for i in range(len(l)) if l[i] is not None]
        assert values == list(range(i + 1))

# Generated at 2022-06-24 10:08:31.503854
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from ..utils import _term_move_up
    from .concurrency import MonoWorker

    def f(x, y=None):
        sleep(0.1)
        return (x, y)

    m = MonoWorker()

    # Test that MonoWorker is not running a task before any are submitted
    assert len(m.futures) == 0

    # Test that MonoWorker runs a task after having one submitted
    m.submit(f, 0)
    assert len(m.futures) == 1
    assert m.futures[0].done(), "MonoWorker did not run task that was submitted"

    # Test that MonoWorker does not run more than one task at a time
    assert len(m.futures) == 1
    m.submit(f, 0)
   

# Generated at 2022-06-24 10:08:39.710516
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event, RLock
    from random import random
    from sys import stdout
    from math import sin  # OK to import math

    # This testcase is for use under threads only
    # It would fail under processes due to global interpreter lock.
    mw = MonoWorker()
    step_event = Event()
    sin_lock = RLock()
    start_time = 0
    tmax = 0.06
    count = 0
    asin_prefix = "abcd"

    class MockTqdm(object):
        @staticmethod
        def write(s):
            stdout.write(s)

    def asin(x):
        global mw, step_event, sin_lock, start_time, tmax, count, asin_prefix
        sleep(random())

# Generated at 2022-06-24 10:08:46.653870
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys
    import os
    import signal

    with tqdm_auto.tqdm(total=100) as pbar:
        def write(s):
            pbar.write(s)
            pbar.update(1)
        write("Testing MonoWorker...")
        w = MonoWorker()
        f1 = w.submit(write, "Foo!")
        write("Foo!")
        f2 = w.submit(write, "Waiting Foo!")
        write("Waiting Foo!")
        f3 = w.submit(write, "Waiting Bar!")
        write("Waiting Bar!")
        f4 = w.submit(write, "Bar!")
        write("Bar!")
        if f1.done():
            write("f1 is done")

# Generated at 2022-06-24 10:08:59.377175
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    import nose.tools as nt

    # Monkey-patch tqdm to avoid displaying the progressbars
    # print() would do the same but would be more confusing
    tqdm_auto.write = lambda x=None: None

    worker = MonoWorker()

    @worker.submit
    def func0():
        time.sleep(0.5)
        return 0

    @worker.submit
    def func1():
        time.sleep(0.5)
        return 1

    @worker.submit
    def func2():
        time.sleep(0.5)
        return 2

    @worker.submit
    def func3():
        time.sleep(0.5)
        return 3

    # func0 has been canceled and func1 is still running
    # func2 and func

# Generated at 2022-06-24 10:09:11.621321
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, unittest
    from queue import Queue
    from threading import Event

    N = 2
    M = 2  # Max number of Futures in deque
    futures_list = []
    results = []
    bar0 = tqdm_auto.tqdm(total=N, ncols=100)
    q = Queue()

    def func(x, *args, **kwargs):
        """Mock function."""
        time.sleep(x)
        q.put(x)
        return 0

    class Test(unittest.TestCase):
        """Test class."""
        def test(self):
            """Test method."""
            MW = MonoWorker()

# Generated at 2022-06-24 10:09:22.942188
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import concurrent.futures as futures
    from ..utils import format_sizeof
    from ..utils import format_interval

    def foo():
        import time
        import sys
        with tqdm_auto.tqdm(ascii=True) as t:
            for i in t:
                t.set_description('stuff')
                t.set_postfix(str='str', float=2.0, float2=2.0,
                              lst=[1, 2, 3], str2='str', float3=2.0,
                              int=4, float4=2.0)
                time.sleep(0.5)

    def bar():
        import sys
        import time
        time.sleep(2)
        sys.stderr.write('bar')

    worker = MonoWorker()
    worker

# Generated at 2022-06-24 10:09:30.467837
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker."""
    from ..utils import _term_move_up
    from ..utils import _range
    from concurrent.futures import as_completed

    with tqdm_auto.tqdm(total=None, leave=False) as t:
        worker = MonoWorker()
        for i in _range(4):
            f = worker.submit(lambda: 4)
            for _ in _range(5):
                tqdm_auto.write("%s: %s" % (i, f.result()))
            with t.external_write_mode():
                t.update()

    tqdm_auto.write("\n# Various tasks:")
    with tqdm_auto.tqdm(total=None, leave=False) as t:
        worker = MonoWork

# Generated at 2022-06-24 10:09:41.069776
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f1(x, y):
        return x + y
    def f2(x, y):
        return x - y
    def f3(x, y):
        return x * y
    def f4(x, y):
        return x / y

    # Should return 2
    w = MonoWorker()
    assert 2 == w.submit(f1, 1, 1).result()
    # Should replace f1 with f2 and return 1
    # (f1 should be discarded)
    assert 1 == w.submit(f2, 2, 1).result()
    # Should replace f2 with f3 and return 2
    # (f2 should be discarded)
    assert 2 == w.submit(f3, 2, 1).result()
    # Should replace f3 with f4 and return 2
    # (f3 should be discarded

# Generated at 2022-06-24 10:09:51.623639
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Usage example for `MonoWorker`."""
    from concurrent.futures import TimeoutError
    from time import sleep
    from itertools import count

    def slow_square(x):
        sleep(x / 3)
        return x ** 2

    def run_slow_square(i):
        with tqdm_auto.tqdm(disable=True, ncols=100) as t:
            try:
                t.postfix = 'waiting task' + str(i)
                result = slow_square(i)
            except (TimeoutError, IndexError):
                t.postfix = 'discarded task' + str(i)
            else:
                t.postfix = 'running task' + str(i)
                return result

    pool = MonoWorker()
    futs = []

# Generated at 2022-06-24 10:09:52.880674
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()



# Generated at 2022-06-24 10:09:59.088504
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    class Sleepy(object):
        def __init__(self, timeout):
            self.timeout = timeout
            self.event = Event()

        def __call__(self):
            sleep(self.timeout)
            self.event.set()

    def check_MonoWorker_submit(n_tasks, n_sec, n_worker=1):
        worker = MonoWorker()
        tasks = [Sleepy(n_sec / n_tasks) for _ in range(n_tasks)]
        for task in tasks:
            worker.submit(task)
        for task in tasks:
            task.event.wait()

    check_MonoWorker_submit(1, 1)
    check_MonoWorker_submit(2, 1)
    check_Mono

# Generated at 2022-06-24 10:10:08.322591
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .utils import get_futures

    def testfunc(i, sleep_time=0.1):
        """i: task number; sleep_time: time (in seconds) to sleep"""
        sleep(sleep_time)
        return i

    # test 1
    print("Test 1: normal case:")
    mw = MonoWorker()
    results = []

    for i in range(5):
        print("\n---submit a new task---")
        future = mw.submit(testfunc, i, sleep_time=0.1)
        results.append(future)

    completed, not_completed = get_futures(results, 0.3)
    assert (len(completed) == 5)

# Generated at 2022-06-24 10:10:15.113144
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import time
    from time import sleep
    from random import random
    from numpy.random import randint

    # noinspection PyUnusedLocal
    def do_work(i, sleep_time):
        sleep(sleep_time)
        return i

    def do_submit(worker, i, sleep_time):
        tic = time()
        future = worker.submit(do_work, i, sleep_time)
        toc = time()
        return toc-tic, future

    for i in range(3):
        if i == 0:
            # if this is the first time to invoke function do_submit
            # function do_work will be submitted immediately
            sleep_time = randint(10, 50)
        else:
            sleep_time = randint(20, 100)
        sleep(sleep_time)


# Generated at 2022-06-24 10:10:18.549999
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def sleep_many(n):
        from time import sleep
        sleep(n)
        return n

    worker = MonoWorker()
    for n in range(4):
        worker.submit(sleep_many, n)
    for r in worker.futures:
        assert r.result() == 3


# Generated at 2022-06-24 10:10:28.078049
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func(arg, sleep_secs):
        time.sleep(sleep_secs)
        return arg

    mw = MonoWorker()
    tqdm_auto.write("\ntest_MonoWorker_submit:")
    tqdm_auto.write("Running 'submit(func, 1, 2.0)'...")
    result1 = mw.submit(func, 1, 2.0)
    tqdm_auto.write("Running 'submit(func, 2, 7.0)'...\n")
    result2 = mw.submit(func, 2, 7.0)
    tqdm_auto.write("result1 is: %s" % result1.result())
    tqdm_auto.write("result2 is: %s" % result2.result())



# Generated at 2022-06-24 10:10:38.599903
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    mw = MonoWorker()

    i_fut = mw.submit(sleep, 0.1)  # returns None / finished immediately
    assert i_fut is None
    # mw.submit(sleep, 0.1)
    # mw.submit(sleep, 0.1)

    i_fut = mw.submit(sleep, 2)
    assert i_fut.done() is False
    assert len(mw.futures) == 1
    i_fut.result()  # blocks until sleep is finished
    assert i_fut.done() is True
    assert len(mw.futures) == 0

    i_fut = mw.submit(sleep, 2)

    ii_fut = mw.submit(sleep, 0.1)  # returns new and

# Generated at 2022-06-24 10:10:40.353031
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    '''
    Test constructor of class MonoWorker
    '''
    t = MonoWorke

# Generated at 2022-06-24 10:10:49.012561
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for `MonoWorker.submit()`."""
    from time import sleep
    from os import getpid
    from sys import version_info

    def square(x):
        """Square `x` and sleep a random time (2x slower)."""
        sleep(x / 2)
        return x ** 2

    def worker_test():
        pid = getpid()
        worker = MonoWorker()
        square_list = [worker.submit(square, i) for i in range(4)]

# Generated at 2022-06-24 10:10:56.768388
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm import trange
    from threading import Semaphore, Lock

    def launch(args):
        lock.acquire()
        tqdm_auto.write(args)
        sem.release()
        time.sleep(1)
        lock.release()

    lock = Lock()  # py2.7
    sem = Semaphore(1)
    mw = MonoWorker()
    with trange(10) as t:
        for i in t:
            mw.submit(launch, i)
            sem.acquire()
            sem.release()
            time.sleep(0.1)

# Generated at 2022-06-24 10:11:06.942147
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Lock
    from .tqdm_test_utils import with_progbar

    lock = Lock()
    queue = [0, 0]

    @with_progbar(100)
    def f(i):
        sleep(0.5)
        with lock:
            queue[0] = i

    with MonoWorker() as mw:
        mw.submit(f, 1)
        mw.submit(f, 2)
        mw.submit(f, 3)
        while queue[0] == 0:
            sleep(1)
        assert queue == [1, 0], 'First submitted job should run'
        mw.submit(f, 4)
        while queue[0] == 1:
            sleep(1)

# Generated at 2022-06-24 10:11:07.902642
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()
    return True

# Generated at 2022-06-24 10:11:17.509809
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    # import sys
    # sys.stderr = open('test_MonoWorker.err','w')
    with MonoWorker() as worker:
        f1 = worker.submit(time.sleep, 0.02)
        time.sleep(0.01)
        f2 = worker.submit(time.sleep, 0.03)
        # f1 should be cancelled
        assert f1.done()
        assert f1.cancelled()
        # f2 should be running
        assert not f2.done()
        f2.result()
        # f3 should be waiting
        f3 = worker.submit(time.sleep, 0.04)
        # f4 should be waiting
        f4 = worker.submit(time.sleep, 0.05)
        # f4 should be running

# Generated at 2022-06-24 10:11:22.463106
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    m = MonoWorker()
    #m.submit(time.sleep, 10)
    print(m.submit(time.sleep, 10))
    #time.sleep(1)
    #m.submit(time.sleep, 10)


#test_MonoWorker()

try:
    from tqdm.contrib.concurrent import process  # NOQA
except ImportError:
    pass

# Generated at 2022-06-24 10:11:34.079330
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from concurrent.futures import TimeoutError
    from time import sleep

    class A(object):
        def __init__(self):
            self.X = MonoWorker()
            self.Y = MonoWorker()

        def test(self):
            def f(s):
                sleep(s)
                return 's={s}'.format(s=s)

            def g(s):
                sleep(s)
                raise Exception('s={s}'.format(s=s))

            X = self.X
            Y = self.Y

            # test priority of both X and Y (by cancelling lower-priority tasks)
            assert X.submit(f, 8).result(timeout=9) == 's=8'
            assert X.submit(f, 4).result(timeout=5) == 's=4'

# Generated at 2022-06-24 10:11:41.989897
# Unit test for constructor of class MonoWorker

# Generated at 2022-06-24 10:11:48.324173
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from random import random

    def printer(s):
        sleep(random())
        print(s)

    m = MonoWorker()
    r = [m.submit(printer, s) for s in ['a', 'b', 'c', 'd', 'e', 'f']]
    assert len(r) == 6
    assert all(not f.done() for f in r)
    m.pool.shutdown(wait=True)
    assert all(f.done() for f in r)



# Generated at 2022-06-24 10:11:55.746992
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import string

    def _random_wait(tmin=0.5, tmax=2):
        time.sleep(random.random() * (tmax - tmin) + tmin)
        return ''.join(random.sample(string.ascii_uppercase, 5))

    # tqdm_auto.write('test_MonoWorker_submit ', end='')
    w = MonoWorker()
    # tqdm_auto.write('1:', end='')
    f1 = w.submit(_random_wait)
    # tqdm_auto.write('2:', end='')
    f2 = w.submit(_random_wait)
    # tqdm_auto.write('3:', end='')

# Generated at 2022-06-24 10:12:04.775270
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from queue import Queue
    from time import sleep

    def countdown(n, q):
        while n > 0:
            sleep(0.1)
            n -= 1
        q.put(n)

    q = Queue()
    mw = MonoWorker()
    mw.submit(countdown, 3, q)
    mw.submit(countdown, 2, q)
    mw.submit(countdown, 1, q)
    assert q.get() == 0