

# Generated at 2022-06-22 05:09:29.138380
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    mworker = MonoWorker()

    def task1(n):
        time.sleep(n)
        return n

    def task2(n):
        time.sleep(1)
        return n

    mworker.submit(task1, 2)
    mworker.submit(task2, 2)
    mworker.submit(task2, 2)
    mworker.submit(task2, 2)
    mworker.submit(task2, 2)
    mworker.submit(task2, 2)
    mworker.submit(task2, 2)
    mworker.submit(task2, 2)
    mworker.submit(task2, 2)
    mworker.submit(task2, 2)
    mworker.submit(task1, 2)

# Generated at 2022-06-22 05:09:40.509046
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    import os, sys
    sys.path.insert(
        0, os.path.abspath(
            os.path.join(os.path.dirname(__file__), '..')))
    from tqdm.contrib.concurrency import MonoWorker
    from time import time, sleep

    def f():
        start = time()
        sleep(0.1)
        return start

    def g():
        start = time()
        sleep(0.2)
        return start

    worker = MonoWorker()
    # Run one task
    assert worker.submit(f).result() == worker.submit(f).result()
    # Run another task, discarding old waiting task
    assert worker.submit(g) != worker.submit(g).result()
    # Run

# Generated at 2022-06-22 05:09:48.899175
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random

    def func(seconds):
        time.sleep(seconds)
        return seconds

    mw = MonoWorker()
    assert mw.submit(func, 1)
    assert mw.submit(func, 1)
    assert mw.submit(func, 1)
    assert mw.submit(func, 1)
    assert mw.submit(func, 1)
    assert mw.submit(func, 1)
    assert mw.submit(func, 1)
    assert mw.submit(func, 1)
    assert mw.submit(func, 1)
    assert mw.submit(func, 1)
    assert mw.submit(func, 1)
    assert mw.submit(func, 1)
    assert mw.submit(func, 1)

# Generated at 2022-06-22 05:09:59.171758
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Event
    def stub(t):
        sleep(t)
        return t
    mw = MonoWorker()
    assert mw.pool.max_workers == 1
    assert mw.futures.maxlen == 2
    assert len(mw.futures) == 0
    assert mw.submit(stub, 0.1) is None
    assert mw.submit(stub, 0.2)
    assert len(mw.futures) == 1
    assert mw.submit(stub, 0.3)
    assert len(mw.futures) == 2
    assert mw.submit(stub, 0.2)
    assert len(mw.futures) == 2
    assert mw.submit(stub, 0.1)


# Generated at 2022-06-22 05:10:09.084135
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from nose.tools import assert_equal
    from ..utils import format_sizeof

    def test_func(arg):
        return arg

    def test_func2(arg):
        sleep(2)

    # Initialisation
    mono = MonoWorker()
    assert_equal(mono.futures, deque([]))
    # First entry
    assert_equal(mono.submit(test_func, 1), 1)
    assert_equal(mono.futures, deque([1]))
    # Second entry, should replace first
    assert_equal(mono.submit(test_func, 2), 2)
    assert_equal(mono.futures, deque([2]))
    # Third entry, should be discarded

# Generated at 2022-06-22 05:10:18.514918
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from concurrent.futures import TimeoutError
    from tqdm import trange
    from multiprocessing import freeze_support

    def one_second_counter(i):
        for _ in trange(10, desc='step: {}'.format(i), leave=False):
            sleep(1/10)

    def main():
        freeze_support()
        w = MonoWorker()
        r = []
        for i in [1,2,3,4]:
            r.append(w.submit(one_second_counter, i))

        print('\nTest1: Should show \'step: 4\' only')
        try:
            for i in r:
                i.result()
        except TimeoutError:
            pass

        r2 = []

# Generated at 2022-06-22 05:10:25.613540
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    mw = MonoWorker()

    def slow_square(x):
        sleep(1)
        return x ** 2

    assert [mw.submit(slow_square, i).result() for i in range(4)] == [0, 1, 4, 9]
    for i in range(3):
        mw.submit(slow_square, i)
    sleep(1.1)
    assert mw.submit(slow_square, 4).result() == 16
    sleep(1.1)
    assert mw.submit(slow_square, 5).result() == 25

# Generated at 2022-06-22 05:10:32.082091
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread

    def sleep_10_times(n):
        sleep(10 * n)
        return n

    worker = MonoWorker()
    results = []

    def print_result(future):
        results.append(future.result())

    for n in range(20):
        if n % 2 == 0:
            worker.submit(sleep_10_times, n).add_done_callback(print_result)
        else:
            worker.submit(sleep_10_times, n).add_done_callback(print_result)
            sleep(0.01)

    sleep(7)
    assert results == list(range(20))

    # Test that "running" status updates while tasks are waiting
    worker = MonoWorker()


# Generated at 2022-06-22 05:10:39.774658
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    def f1():
        import time
        time.sleep(1)
        return 'f1'
    def f2():
        import time
        time.sleep(2)
        return 'f2'
    def f3():
        import time
        time.sleep(3)
        return 'f3'

    m = MonoWorker()
    f = {'f1': m.submit(f1), 'f2': m.submit(f2), 'f3': m.submit(f3)}
    for key in f:
        assert f[key].result() == key

# Generated at 2022-06-22 05:10:49.941684
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import _term_move_up
    from ..utils import _range
    from ..utils import _decr_instances
    from ..utils import format_sizeof

    L = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    total = len(L)


# Generated at 2022-06-22 05:10:57.325976
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Create MonoWorker and run two jobs
    mw = MonoWorker()
    running = mw.submit(lambda: 'running')
    waiting = mw.submit(lambda: 'waiting')
    # Check that only the second job is in the ThreadPoolExecutor
    assert running.done() and running.cancelled()
    assert not waiting.done() and not waiting.cancelled()
    # Check that get() returns the correct value for each job
    assert running.cancel()
    assert waiting.result() == 'waiting'
    print('Passed simple tests')

# Generated at 2022-06-22 05:11:07.047917
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time as time_

    def func_delayed(x, delay):
        time_.sleep(delay)
        return x

    mono_worker = MonoWorker()
    # waiting task
    t1 = mono_worker.submit(func_delayed, 1, 30)
    assert not t1.done()
    # new waiting task replaces previous waiting task
    t2 = mono_worker.submit(func_delayed, 2, 10)
    assert not t1.done()
    # waiting task becomes running task
    t3 = mono_worker.submit(func_delayed, 3, 1)
    assert t2.done()
    assert not t3.done()
    # running task only cancelled when new task submitted
    t4 = mono_worker.submit(func_delayed, 4, 40)
    assert t3.done()
   

# Generated at 2022-06-22 05:11:11.262000
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()
    assert mw.futures.maxlen == 2
    for _ in range(mw.futures.maxlen + 1):
        mw.submit(time.sleep, .1)
    assert len(mw.futures) == 1

# Generated at 2022-06-22 05:11:14.063940
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def f(x):
        # this way, we make sure x will never be garbage-collected
        return x*2

    w = MonoWorker()
    w.submit(f, 42)



# Generated at 2022-06-22 05:11:25.150024
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from operator import add
    from .utils import _range

    # Test 1
    def t(x):
        sleep(x)
        return x+1

    mw = MonoWorker()
    assert list(map(mw.submit, map(t, _range(3)))) == \
        list(map(mw.pool.submit, map(t, _range(3))))

    sleep(0.1)
    assert list(map(mw.submit, map(t, _range(3, 6)))) == \
        list(map(mw.pool.submit, map(t, _range(3, 6))))

    sleep(0.1)

# Generated at 2022-06-22 05:11:35.833850
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import os
    import time
    from contextlib import closing
    from .multiprocessing import Pipe
    from .threadpool import ThreadPool

    mw = MonoWorker()
    pool = ThreadPool()

# Generated at 2022-06-22 05:11:44.625187
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys

    mw = MonoWorker()
    tqdm_auto.write("Starting")
    time.sleep(1)

    def f(x):
        return x * 2

    for i in range(10):
        time.sleep(1)
        mw.submit(f, i)
        tqdm_auto.write(str(i))
        sys.stdout.flush()

    time.sleep(10)
    tqdm_auto.write("Done")

if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:11:54.847075
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from . import threading_utils
    # threading_utils.debug_print = True

    def f(x):
        time.sleep(x / 2)
        return x

    class Foo(tqdm_auto.tqdm):
        def __init__(self, *args, **kwargs):
            self.worker = MonoWorker()
            super(Foo, self).__init__(*args, **kwargs)

        def refresh(self, n=1, **kwargs):
            super(Foo, self).refresh(n, **kwargs)
            if threading_utils.is_main_thread() and self.worker:
                while self.worker.futures:
                    self.worker.futures.popleft().result()


# Generated at 2022-06-22 05:12:06.585528
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from concurrent.futures import ThreadPoolExecutor
    from .tests import TestMonitor
    import time

    class TestWorker(MonoWorker):
        def __init__(self):
            super(TestWorker, self).__init__()
            self.comp_time = TestMonitor()
            self.cancel_time = TestMonitor()
            self.results = deque()

        def submit(self, func, *args, **kwargs):
            future = super(TestWorker, self).submit(func, *args, **kwargs)
            future.add_done_callback(self._done)
            return future

        def _done(self, future):
            self.results.append(future.result())
            now = time.time()

# Generated at 2022-06-22 05:12:17.266917
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Unit test for constructor of class MonoWorker.
    """
    print("Testing MonoWorker()...", end='\r')
    import time
    import sys
    try:
        import Queue  # noqa
    except:
        try:
            import queue  # python3
        except:
            raise RuntimeError("Python built-in Queue not found")

    def _print(t):
        msg = "{{0:{0}}}".format(len(str(t.max)))
        sys.stdout.write(msg.format(t))
        sys.stdout.flush()

    def wait(t=0.5):
        for _ in tqdm_auto.trange(5, unit='wait'):
            time.sleep(t)

    def echo(t):
        return t


# Generated at 2022-06-22 05:12:23.664241
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> test_MonoWorker()
    """
    MonoWorker()



# Generated at 2022-06-22 05:12:32.304453
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from multiprocessing import cpu_count as get_ncpus
    from .functools_ext import l_map_mp

    N = get_ncpus() + 1
    mono_worker = MonoWorker()

    for i in range(N):
        assert len(mono_worker.futures) <= 1

    def f():
        time.sleep(0)
        return 0

    assert len(mono_worker.futures) == 0
    l_map_mp(mono_worker.submit, [f] * N)
    assert len(mono_worker.futures) == 1

# Generated at 2022-06-22 05:12:36.414113
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread

    def func(i, t=1):
        sleep(t)
        return i + 1

    mw = MonoWorker()

    # test empty queue
    for i in range(4):
        mw.submit(func, i)
        assert mw.futures[-1].result() == i + 1

    # test interrupts from outside
    t = Thread(target=func, args=(5,), kwargs={"t": 15})
    t.daemon = True
    t.start()
    sleep(1)
    for i in range(6, 8):
        mw.submit(func, i)
        assert mw.futures[-1].result() == i + 1

# Generated at 2022-06-22 05:12:46.747680
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import multiprocessing  # to ensure each task takes >1.1 secs
    mw = MonoWorker()
    test = [False] * 3

    def task(i):
        test[i] = True
        time.sleep(2)

    mw.submit(task, 0)
    time.sleep(1)
    assert all(not i for i in test)
    mw.submit(task, 1)
    time.sleep(1)
    assert all(not i for i in test)
    mw.submit(task, 2)
    time.sleep(1)
    assert all(not i for i in test)
    time.sleep(1)
    assert all(not i for i in test)
    time.sleep(1)
    assert all(not i for i in test)
   

# Generated at 2022-06-22 05:12:53.203410
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    def wait(seconds):
        tqdm_auto.write(seconds)
        time.sleep(seconds)
        return seconds
    mw = MonoWorker()
    assert mw.submit(wait, 2) is None
    assert mw.futures[0].result() == 2
    assert mw.submit(wait, 1) == 1
    assert mw.submit(wait, 0) is None
    assert mw.futures[0].result() == 0

# Generated at 2022-06-22 05:13:01.278996
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm.auto import trange
    from tqdm.contrib import MonoWorker

    def sleep_print(n):
        sleep(1)
        print('sleep_print({})'.format(n))

    mw = MonoWorker()
    with trange(3) as t:
        for n in t:
            mw.submit(sleep_print, n)

    # Expected output:
    #  0%|          | 0/3 [00:00<?, ?it/s]sleep_print(2)
    # 33%|█▍        | 1/3 [00:01<00:02,  1.00s/it]sleep_print(0)
    # 67%|█▋        | 2/3 [00:02<00:01,  1.00s

# Generated at 2022-06-22 05:13:03.022634
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random
    worker = MonoWorker()
    for i in range(5):
        worker.submit(sleep, random())
        sleep(0.1)

# Generated at 2022-06-22 05:13:08.292747
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert type(mw) is MonoWorker
    assert mw.pool is not None
    assert type(mw.pool) is ThreadPoolExecutor
    assert mw.futures is not None
    assert type(mw.futures) is deque


# Generated at 2022-06-22 05:13:14.699566
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Lock
    import random
    import sys

    if sys.version_info[0] >= 3:
        from queue import Queue
        from _thread import get_ident
    else:
        from Queue import Queue
        from thread import get_ident

    class GetIdentThreadPoolExecutor(ThreadPoolExecutor):
        """Get ident of running thread"""
        def submit(self, fn, *args, **kwargs):
            """Returns Future object with added `get_ident()` method."""
            future = super(GetIdentThreadPoolExecutor, self).submit(fn,
                                                                    *args,
                                                                    **kwargs)
            future.get_ident = lambda: fn(*args, **kwargs)
            return future


# Generated at 2022-06-22 05:13:25.988814
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from queue import Queue, Empty
    from threading import Thread

    def test_thread(task_queue, result_queue):
        from time import sleep

        def test_func(func, *args, **kwargs):
            from time import sleep
            sleep(0.1)
            return func(*args, **kwargs)

        def job(**kwargs):
            return True

        mw = MonoWorker()
        idx = 0

# Generated at 2022-06-22 05:13:40.698641
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import tqdm

    def test_func():
        time.sleep(1)


    worker = MonoWorker()
    run_futures = []

    for _ in tqdm.trange(1, 10):
        run_futures.append(worker.submit(test_func))
    for f in run_futures:
        f.result()
        tqdm.write("Test PASS")

# Generated at 2022-06-22 05:13:48.550648
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Run test first with shared_globals=False, then with shared_globals=True
    for shared_globals in [False, True]:
        # Create a MonoWorker object and run a task
        mono_worker = MonoWorker()
        task = mono_worker.submit(lambda: 2 + 2, shared_globals=shared_globals)
        # Check that the task is completed
        assert task.done() and task.result() == 4
        # Run a second task and check that it is executed immediately
        task = mono_worker.submit(lambda: 2 + 2, shared_globals=shared_globals)
        assert task.done() and task.result() == 4
        # For shared_globals=True, check that the task has been executed in the
        # main thread, by checking that the current

# Generated at 2022-06-22 05:13:52.340863
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from itertools import count

    def dummy_func(i):
        time.sleep(.5)
        return i

    mw = MonoWorker()
    for i in count():
        mw.submit(dummy_func, i)
        time.sleep(.3)

# Generated at 2022-06-22 05:13:57.960887
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from random import random

    def func(F, E):
        assert E.wait(0.1)  # expect E to be set
        F.write('{}\n'.format(random()))  # random output

    F = tqdm_auto._io.FileIO('test_MonoWorker_submit.txt', 'w')
    E = Event()

# Generated at 2022-06-22 05:13:58.755707
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()


# Generated at 2022-06-22 05:14:07.906983
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def time_consuming_func(x, multiplier=1):
        time.sleep(x * multiplier)
        return x * x

    mw = MonoWorker()

    print('First submit')
    assert mw.submit(time_consuming_func, 5, multiplier=0.1)

    print('Second submit')
    assert mw.submit(time_consuming_func, 6, multiplier=0.1)

    print('Third submit')
    assert mw.submit(time_consuming_func, 7, multiplier=0.1)

    time.sleep(2)
    print('Done')


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:14:17.375468
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    def wait(dur):
        sleep(dur)
        return dur

    mw = MonoWorker()
    assert mw.submit(wait, 1).result() == 1
    mw.submit(wait, .5).result() == .5
    mw.submit(wait, .25).result()  # discard
    mw.submit(wait, .1).result()  # discard
    mw.submit(wait, .01).result()  # discard
    assert mw.submit(wait, .001).result() == .001
    pass  # all non-error assertions should be passed

# Generated at 2022-06-22 05:14:27.582331
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from itertools import count
    from time import sleep
    done = False

    # Method to test
    def submit(*args, **kwargs):
        nonlocal done
        sleep(0.5)
        done = True
        return Future()

    # Create class to test
    class MonoWorkerBase(object):
        def __init__(self):
            self.futures = deque([], 2)
        def submit(self, *args, **kwargs):
            return submit(*args, **kwargs)

    class MonoWorker(MonoWorkerBase):
        def __init__(self):
            self.pool = ThreadPoolExecutor(max_workers=1)
            super(MonoWorker, self).__init__()

    # Test that the method works

# Generated at 2022-06-22 05:14:34.530489
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    from time import sleep
    worker = MonoWorker()
    sleep(0.01)
    worker.submit(sleep, 0.1)
    sleep(0.01)
    worker.submit(sleep, 0.01)
    assert len(worker.futures) == 2
    sleep(0.11)
    assert len(worker.futures) == 1
    sleep(0.02)
    assert len(worker.futures) == 0

# Generated at 2022-06-22 05:14:41.534749
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker."""
    from threading import Event, Thread
    from time import sleep
    from unittest import TestCase

    class MonoWorkerTestCase(TestCase):
        def test_submit(self):
            """Unit test for method submit of class MonoWorker."""
            e = Event()
            e.clear()

            def wait():
                e.wait()

            mw = MonoWorker()
            t = Thread(target=wait)
            t.start()
            sleep(0.1)
            # Case 1: waiting is clearable
            e.set()
            t.join()
            self.assertFalse(mw.submit(wait))
            # Case 2: waiting is not clearable
            t = Thread(target=wait)
            t.start()

# Generated at 2022-06-22 05:15:08.995785
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys
    import unittest
    from concurrent.futures import TimeoutError
    from concurrent.futures import CancelledError

    from ..auto import tqdm

    # Use the same timeouts for all tests
    TIMEOUT_SHORT = 0.5
    TIMEOUT_LONG = 1.0

    class TestMonoWorker(unittest.TestCase):

        def setUp(self):
            self.mw = MonoWorker()

        def test_cancel(self):
            """Test cancellation of MonoWorker tasks"""
            # Check that cancelling a task that has not been submitted
            # raises a ValueError
            fut = self.mw.submit(time.sleep, TIMEOUT_LONG)
            with self.assertRaises(ValueError):
                fut.cancel()

            #

# Generated at 2022-06-22 05:15:13.369763
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Constructor of class MonoWorker"""
    mono = MonoWorker()
    assert mono.pool._max_workers == 1
    assert mono.futures.maxlen == 2



# Generated at 2022-06-22 05:15:21.841715
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import subprocess
    from .sync_tqdm import tqdm
    from threading import Thread

    def _task(num_sleep=2):
        import time
        time.sleep(num_sleep)
        return str(num_sleep)

    def test_task_one_at_a_time(n=5):
        tqdm.write("\n")
        worker = MonoWorker()
        for _ in tqdm(range(n)):
            future = worker.submit(_task)
            tqdm.write(future.result())

    def test_task_flood(n=5):
        tqdm.write("\n")
        worker = MonoWorker()
        results = []
        for _ in tqdm(range(n)):
            results.append(worker.submit(_task))
       

# Generated at 2022-06-22 05:15:31.751007
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import sys
    import threading

    class TestThread(threading.Thread):
        def __init__(self, func, *args, **kwargs):
            threading.Thread.__init__(self)
            self.func = func
            self.args = args
            self.kwargs = kwargs

        def run(self):
            self.func(*self.args, **self.kwargs)

    def worker():
        time.sleep(random.randint(1, 5))
        tqdm_auto.write(str(threading.currentThread()))
    worker_args = ()
    worker_kwargs = {}

    tqdm_auto.write("Test 1")
    time.sleep(1)
    executor = MonoWorker()

# Generated at 2022-06-22 05:15:42.061636
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def cb(fn, *args, **kwargs):
        def wrap(*args, **kwargs):
            r = fn(*args, **kwargs)
            print(r)
            return r
        return wrap

    mw = MonoWorker()
    mw.submit(cb(time.sleep), 2)
    mw.submit(cb(time.sleep), .8)
    mw.submit(cb(time.sleep), .8)
    mw.submit(cb(time.sleep), .8)
    mw.submit(cb(time.sleep), .8)
    mw.submit(cb(time.sleep), .8)
    mw.submit(cb(time.sleep), 999)

# Generated at 2022-06-22 05:15:53.362472
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    worker = MonoWorker()
    assert len(worker.futures) == 0
    assert worker.futures.maxlen == 2
    worker.submit(time.sleep, 1)
    assert len(worker.futures) == 1
    worker.submit(time.sleep, 1)
    assert len(worker.futures) == 1
    worker.submit(time.sleep, 1)
    assert len(worker.futures) == 1
    worker.submit(time.sleep, 1)
    assert len(worker.futures) == 2
    worker.submit(time.sleep, 1)
    assert len(worker.futures) == 2
    worker.submit(time.sleep, 1)
    assert len(worker.futures) == 1
    time.sleep(1.2)
   

# Generated at 2022-06-22 05:16:03.457171
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def normal_function(arg):
        return "hello " + arg

    # normal function
    worker = MonoWorker()
    assert worker.submit(normal_function, "world").result() == "hello world"

    # delayed result, cancelable
    def delayed_function(arg, delay):
        time.sleep(delay)
        return "goodbye " + arg

    delayed_job = worker.submit(delayed_function, "world", 3)
    time.sleep(2)
    worker.submit(normal_function, "world")
    assert worker.submit(normal_function, "world").result() == "hello world"
    worker.submit(delayed_function, "world", 3)
    time.sleep(1)
    assert delayed_job.cancel()
    assert delayed_job.result() is None

   

# Generated at 2022-06-22 05:16:05.884549
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test that the MonoWorker constructor is working properly"""
    # Test that the constructor works properly
    MonoWorker()

# Generated at 2022-06-22 05:16:08.285232
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    assert MonoWorker() is not None


# Generated at 2022-06-22 05:16:17.429284
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func1():
        time.sleep(1)
        tqdm_auto.write('func1 done')
        return 1

    def func2():
        time.sleep(1)
        tqdm_auto.write('func2 done')
        return 2

    def func3():
        time.sleep(1)
        tqdm_auto.write('func3 done')
        return 3

    def sleep(seconds):
        time.sleep(seconds)

    def is_cancelled(future):
        try:
            future.result()
        except Exception as e:
            if 'Cancelled' in str(e):
                return True
        return False

    worker = MonoWorker()
    #assert(worker.futures.maxlen == 2)

    print('Submitting func1')
    future

# Generated at 2022-06-22 05:16:54.767869
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    '''
    Test if the class MonoWorker is working properly by creating
    an object of class MonoWorker and calling its function submit.
    '''
    obj = MonoWorker()
    obj.submit(print, 'first', 'second', sep='...')

# Generated at 2022-06-22 05:16:55.606411
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    MonoWorker()



# Generated at 2022-06-22 05:17:04.104228
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import timeit

    def wait_some(t=None):
        if t is None:
            time.sleep(1)
        else:
            time.sleep(t)

    def sync_wait_some(t=None):
        wait_some(t)
        return t

    pool = MonoWorker()
    with timeit(1, 's async submit') as t:
        for i in range(3):
            pool.submit(wait_some)
    with timeit(1, 's sync submit') as t:
        for i in range(3):
            sync_wait_some()
    assert t.elapsed > 0.1
    with timeit(1, 's async submit') as t:
        for i in range(6):
            pool.submit(wait_some, i)


# Generated at 2022-06-22 05:17:12.634456
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from os import getpid
    from concurrent.futures import FIRST_COMPLETED, wait
    from multiprocessing import Process, Queue
    
    def target(q):
        q.put((getpid(), MonoWorker().submit(lambda: sleep(1)).result()))
        q.put((getpid(), MonoWorker().submit(lambda: sleep(2)).result()))
    
    q = Queue()
    p1 = Process(target=target, args=(q,))
    p2 = Process(target=target, args=(q,))
    p1.start()
    p2.start()
    p1, p2 = wait([p1, p2], return_when=FIRST_COMPLETED)
    q.get()
    q.get()
    

# Generated at 2022-06-22 05:17:21.437456
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    worker = MonoWorker()

    def wait(delay):
        time.sleep(delay)
        return time.time()

    def display(name, delay):
        rst = worker.submit(wait, delay).result()
        print(name, " : ", rst)

    import multiprocessing
    p1 = multiprocessing.Process(target=display, args=("p1", 1.5))
    p2 = multiprocessing.Process(target=display, args=("p2", .5))
    p3 = multiprocessing.Process(target=display, args=("p3", .8))
    p4 = multiprocessing.Process(target=display, args=("p4", .3))
    p1.start()
    p2.start()
    p3.start()


# Generated at 2022-06-22 05:17:29.344796
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def _run(cur_t, cur_l):
        sleep(0.5)
        tqdm_auto.write("{}-{}".format(cur_t, cur_l))
        return cur_t * cur_l

    tqdm_auto.write("Testing MonoWorker.submit")
    mw = MonoWorker()
    fut1 = mw.submit(_run, 2, 3)
    fut2 = mw.submit(_run, 3, 4)
    fut3 = mw.submit(_run, 4, 5)
    fut4 = mw.submit(_run, 5, 6)
    tqdm_auto.write(fut1.result())
    tqdm_auto.write(fut2.result())

# Generated at 2022-06-22 05:17:37.194525
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Create the worker
    worker = MonoWorker()

    # Submit the first task
    def task(msg):
        tqdm_auto.write(msg)

    worker.submit(task, "first")

    # Submit the second task
    worker.submit(task, "second")

    # Submit the  third task (which will be discarded)
    worker.submit(task, "third")

    # Submit the fourth task
    worker.submit(task, "fourth")

# Generated at 2022-06-22 05:17:46.053934
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent.futures import ThreadPoolExecutor
    queue = deque([], 2)

    def log_time(n):
        queue.append(time.time())

    monoWorker = MonoWorker()
    threading_pool = ThreadPoolExecutor(max_workers=4)
    for i in range(4):
        threading_pool.submit(monoWorker.submit, log_time, i)
    time.sleep(0.5)
    assert len(queue) == 1
    assert queue[0] == queue[-1]

# Test that test is working
import nose

# Generated at 2022-06-22 05:17:57.428535
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .tqdm_test_classes import FakeTqdmFile

    # run with `coverage run --source=tqdm -m pytest test_MonoWorker.py`

    def waitfunc(it, delay=0.2):
        """Make screenshots, sleep `delay` seconds, return `it`."""
        sleep(delay)
        return it

    with FakeTqdmFile(encoding='utf8') as f:
        worker = MonoWorker()
        # submit the first task
        future_one = worker.submit(waitfunc, 1)
        # submit the second task
        future_two = worker.submit(waitfunc, 2)
        # submit the third task
        future_three = worker.submit(waitfunc, 3)
        # submit the forth task

# Generated at 2022-06-22 05:18:06.842932
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import os
    import sys
    import time
    from subprocess import Popen, PIPE
    from threading import Thread, Event
    from .utils import test_kwargs

    class TestStream(object):
        """Stream that automatically closes after the last write."""
        def __init__(self, out):
            self.out = out

        def write(self, s):
            self.out.write(s)
            self.out.flush()

        def close(self):
            self.out.close()

    def submit(desc, func, *args, **kwargs):
        """Non-blocking monitoring of `func(*args, **kwargs)`."""
        tfd = TestStream(sys.stderr)
        tfd.write(desc + ':')
        tfd.flush()
        ev = Event()
