

# Generated at 2022-06-22 05:09:21.195449
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    MonoWorker().submit(lambda x: x, 1)  # no error raised

# Generated at 2022-06-22 05:09:31.029572
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import threading

    def sleep_random():
        time.sleep(random.randint(1, 10))
        return

    monow = MonoWorker()
    for i in range(10):
        monow.submit(sleep_random)
        time.sleep(random.randint(0, 6))
        assert(len(monow.futures) <= 2)

    for _ in range(10):
        time.sleep(0.01)  # wait for sleep_random to finish

    for _ in range(10):
        monow.submit(sleep_random)
        time.sleep(random.randint(0, 6))
        assert(len(monow.futures) <= 2)

# Generated at 2022-06-22 05:09:42.749728
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    0: running
    1: waiting
    """
    import multiprocessing
    import time

    def func(x):
        time.sleep(0.1)
        return x

    n = multiprocessing.cpu_count()
    results = []
    mono = MonoWorker()

    def add(x):
        results.append(mono.submit(func, x))

    for x in range(1 + n * 2):
        add(x)
    assert len(mono.futures) == min(1 + n * 2, mono.futures.maxlen)

    for f in mono.futures:
        assert f.done()
    assert results[0].result() == 1 + n * 2 - 1
    assert results[1].result() == 1 + n * 2 - 1

# Generated at 2022-06-22 05:09:44.268467
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    test = MonoWorker()
    test.pool.shutdown(wait=True)



# Generated at 2022-06-22 05:09:56.405606
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import threading

    mw = MonoWorker()

    def do_my_job(i):
        print("Doing task %d" % i)
        time.sleep(random.uniform(.1, .3))
        print("Done task %d" % i)

    def delayer(i):
        time.sleep(i)
        do_my_job(i)

    class Thread(threading.Thread):
        def __init__(self, id):
            threading.Thread.__init__(self)
            self.id = id

        def run(self):
            print("Starting thread %d" % self.id)
            mw.submit(do_my_job, self.id)
            print("Exiting thread %d" % self.id)


# Generated at 2022-06-22 05:10:02.573865
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    from time import sleep
    from tqdm.contrib.concurrent import MonoWorker

    # FIFO:
    q = []
    appender = q.append

    # LIFO:
    # q = deque()
    # appender = q.appendleft

    def foo(i):
        sleep(10)
        appender(i)

    worker = MonoWorker()
    fut1 = worker.submit(foo, 1)
    fut2 = worker.submit(foo, 2)

    # Test without `fut2.cancel()`
    # Uncomment to test with `fut2.cancel()`:
    # fut2.cancel()

    assert fut2.done()
    qstat = fut1.done() and fut2.done()

# Generated at 2022-06-22 05:10:09.899871
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import re
    import sys
    from . import format_sizeof
    from .format_meter import FormatMeter as fm
    from .process_map import ProcessMap

    class Timeout(Exception):
        pass

    # functions

    def func(x, y=0, wait=0):
        for _ in range(wait + 1):
            sleep(1)
            yield
        sleep(1)
        return x * y

    def func_repr(x):
        return str(x)

    def func_timeout(x, nothing):
        raise Timeout(x)

    # tests

# Generated at 2022-06-22 05:10:19.035623
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Initialize dummy arguments
    func1 = lambda x: x
    func2 = lambda x: x ** 2
    func3 = lambda x: x ** 3
    args1 = (range(5), )
    args1a = (range(5), )
    args2 = (range(10), )
    args3 = (range(15), )
    mWorker = MonoWorker()
    futures = []

    # Make an assertion that the initial state of the mono worker is correct
    assert mWorker.futures == deque([], 2)

    # Submit the first function and check that the state is correct
    futures.append(mWorker.submit(func1, args1))
    assert mWorker.futures == deque([], 2)

    # Submit the second function and check that the state is correct

# Generated at 2022-06-22 05:10:28.030988
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def delayed_square(x):
        time.sleep(0.5)
        return x**x

    mw = MonoWorker()
    futures = []
    for i in range(3):
        futures.append(mw.submit(delayed_square, i))
    time.sleep(0.52)  # 0, 1, 2
    for i in range(3, 6):
        futures.append(mw.submit(delayed_square, i))
    time.sleep(0.52)  # 3, 4, 5
    for i in range(6, 9):
        futures.append(mw.submit(delayed_square, i))
    time.sleep(0.52)  # 6, 7, 8

# Generated at 2022-06-22 05:10:33.706261
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import concurrent.futures
    tqdm_auto.tqdm.write = lambda line: None  # disable tqdm_auto.write

    def func1(n, *args, **kwargs):
        time.sleep(n)
        return n

    def func2(n, *args, **kwargs):
        time.sleep(n)
        return n

    def run_futures(futures, n):
        total = 0
        for ft in futures:
            ft.result()
            total += n
        return total

    def test_wait(n):
        time.sleep(n)

    def test_func(worker, futures):
        futures.append(worker.submit(func1, 5))
        test_wait(1)

# Generated at 2022-06-22 05:10:45.347387
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def delay(x):
        return x

    mw = MonoWorker()
    assert isinstance(mw, MonoWorker)
    # test if old result is returned
    print("1 -------->")
    assert mw.submit(delay, 5) == 5
    # test if old task is cancelled
    print("2 -------->")
    assert mw.submit(tqdm_auto.sleep, 1) == None
    assert mw.submit(tqdm_auto.sleep, 1) == None
    assert mw.submit(tqdm_auto.sleep, 1) == None
    # test return value for new task
    print("3 -------->")
    assert mw.submit(delay, 10) == 10
    # test if new task cancels old task
    print("4 -------->")

# Generated at 2022-06-22 05:10:55.013150
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def heavy_task(wait):
        sleep(wait)

    def random_task(worker):
        wait = random()
        worker.submit(heavy_task, wait)
        return wait

    worker = MonoWorker()
    prev_tasks = {None, }
    for i in range(5):
        wait = random_task(worker)
        while not worker.futures[-1].done():
            sleep(0.5)
        tasks = {f.result() for f in worker.futures}
        assert len(tasks) == 2
        assert tasks == prev_tasks | {wait, }
        prev_tasks = tasks



# Generated at 2022-06-22 05:11:01.566484
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    N = 4
    mw = MonoWorker()

    def func(x):
        import time
        time.sleep(2)
        return x

    for i in range(N):
        fut = mw.submit(func, i)
        assert fut.result() == N-1

    assert len(mw.futures) == 2
    assert mw.futures.maxlen == 2

    # teardown:
    mw._pool.shutdown(wait=True)

# Generated at 2022-06-22 05:11:10.467528
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=missing-docstring
    import time
    import unittest

    class TestCase(unittest.TestCase):
        def test_all(self):
            def sleep_1(x):
                time.sleep(x)
                return x

            def sleep_2(x):
                time.sleep(x*2)
                return x**2

            m = MonoWorker()
            f1 = m.submit(sleep_1, 1)
            f2 = m.submit(sleep_1, 2)
            f3 = m.submit(sleep_2, 3)
            assert f1.done()
            assert f2.done()
            assert f3.result() == 9
            assert f3.done()

    unittest.main()

# Generated at 2022-06-22 05:11:21.469185
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import concurrent.futures
    from .setup import _test_worker

    mp = MonoWorker()
    mp.submit(_test_worker, 0, 1)
    mp.submit(_test_worker, 0, 3)
    mp.submit(_test_worker, 0, 5)
    assert set(fut.result() for fut in mp.futures) == set([4])

    # Test that submit() can be called concurrently (e.g. in a loop)
    mp = MonoWorker()
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(mp.submit, _test_worker, 0, 5)
                   for _ in range(8)]
    futures = (fut.result() for fut in futures)

# Generated at 2022-06-22 05:11:22.361904
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker is not None

# Generated at 2022-06-22 05:11:33.061534
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from .threaded_timer import Timer

    mw = MonoWorker()

    # Task 1
    timer = Timer()
    t1 = mw.submit(sleep, 2.0)

    # Task 2
    m1 = mw.submit(sleep, 0.5)
    timer.start()
    sleep(1.0)  # Less than 1.5 sec (1st arg of `sleep`)
    mw.submit(sleep, 1.5)  # This task replaces m1 (2nd arg of `sleep`)
    timer.stop()
    assert m1.done()
    assert timer.elapsed() <= 1.5  # m1 was cancelled in time

    # Task 3
    m1 = mw.submit(sleep, 0.5)
    sleep(1.0)  #

# Generated at 2022-06-22 05:11:33.973864
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()

# Generated at 2022-06-22 05:11:45.196599
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import sys
    import threading

    def func(arg1, arg2):
        sleep(0.01)
        sys.stdout.write(arg1 + arg2 + '\n')

    def test(arg1, arg2, lock):
        with lock:
            sys.stdout.write('test started\n')
            worker.submit(func, arg1, arg2)
            sys.stdout.write('test ended\n')

    worker = MonoWorker()
    lock = threading.Lock()

    for i in range(0, 3):
        input('Press any key to continue...\n')
        threading.Thread(target=test, args=('a' * i, 'b' * i, lock)).start()

# Generated at 2022-06-22 05:11:55.487858
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    def logtime_and_return(t):
        time.sleep(t)
        tqdm_auto.write('%f' % time.time())
        return t

    mw = MonoWorker()
    mw.submit(logtime_and_return, 0.5)
    mw.submit(logtime_and_return, 0.5)
    mw.submit(logtime_and_return, 0.5)
    # mw.submit(logtime_and_return, 0.5)
    mw.submit(logtime_and_return, 0.5)
    mw.submit(logtime_and_return, 0.5)
    mw.submit(logtime_and_return, 2.5)

# Generated at 2022-06-22 05:12:10.064338
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    mvp = MonoWorker()
    r = mvp.submit(time.sleep, 5)
    assert len(mvp.futures) == 1
    assert not r.done()

    r = mvp.submit(time.sleep, 5)
    assert len(mvp.futures) == 2
    assert not r.done()

    r = mvp.submit(time.sleep, 5)
    assert len(mvp.futures) == 2
    assert not r.done()

    import gc
    gc.collect()

    r = mvp.submit(time.sleep, 5)
    assert len(mvp.futures) == 2
    assert not r.done()

# Generated at 2022-06-22 05:12:13.004596
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def sleep_then_return(x, duration=0.1, step=0.01):
        for _ in tqdm_auto.trange(int(duration / step)):
            sleep(step)
        return x

    mw = MonoWorker()
    for i in range(4):
        mw.submit(sleep_then_return, i)
        mw.submit(sleep_then_return, i + 0.5, duration=0.2)

    sleep(1)

# Generated at 2022-06-22 05:12:17.689654
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    import time

    def foo(x=0):
        time.sleep(1)
        return x + 1

    mw = MonoWorker()
    assert mw.submit(foo, 0).result() == 1
    assert mw.submit(foo, 1).result() == 2

# Generated at 2022-06-22 05:12:27.504702
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Example of usage"""
    def worker(task):
        """Dummy worker"""
        for _ in tqdm_auto.trange(task):
            pass

    def submit(task, t):
        """Thread-safe submit of job"""
        t.submit(worker, task)

    tasks = tqdm_auto.tqdm(range(20))
    mw = MonoWorker()
    th = tqdm_auto.tqdm(tasks, desc='Submit', leave=False, miniters=1)
    for task in th:
        th.set_description("Task %d" % (task))
        submit(task, mw)

# Generated at 2022-06-22 05:12:39.400784
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from thread import get_ident
    from threading import Thread

    def f_return1():
        return 1
    def f_long():
        sleep(0.5)  # long-running task
        return 2
    def f_raise():
        raise Exception('test_MonoWorker_submit')
    def f_ident():
        return get_ident()

    mw = MonoWorker()

    result = mw.submit(f_return1)
    assert result.result() == 1
    assert len(mw.futures) == 1

    result = mw.submit(f_return1)  # replaced by this call
    assert result.result() == 1
    assert len(mw.futures) == 1

    result = mw.submit(f_return1)  # replaced by

# Generated at 2022-06-22 05:12:46.191842
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from concurrent.futures import CancelledError
    import os

    def worker(t):
        """Run some time"""
        sleep(t)
        return os.getpid()

    mw = MonoWorker()
    mw.submit(worker, 2)
    mw.submit(worker, 1)
    assert mw.futures[0].done()
    assert not mw.futures[1].done()
    try:
        mw.futures[1].result()
    except CancelledError:
        assert True
    else:
        assert False

# Generated at 2022-06-22 05:12:55.868561
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import TimeoutError
    def f(x):
        import time
        time.sleep(1)
        return x
    f0 = lambda: None
    w = MonoWorker()
    w.submit(f, 0)
    w.submit(f0)  # should not invoke f0
    w.submit(lambda: None)  # should not invoke lambda
    running = w.submit(f, 1)
    waiting = w.submit(f, 2)
    try:
        assert running.result(timeout=0) == 1
    except TimeoutError:
        pass
    else:
        assert False  # should not have finished yet
    assert waiting.result(timeout=1) == 2
    assert len(w.futures) == 1  # running should still be there

# Generated at 2022-06-22 05:13:05.195181
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    pool = MonoWorker()

    # Test first task, instance should have one task
    future = pool.submit(lambda : True)
    assert(len(pool.futures) == 1)
    assert(future.result() == True)

    # Test second task, instance should have two tasks
    future = pool.submit(lambda : True)
    assert(len(pool.futures) == 2)
    assert(future.result() == True)

    # Test third task, instance should have one task
    future = pool.submit(lambda : True)
    assert(len(pool.futures) == 1)
    assert(future.result() == True)

    # Test fourth task, instance should have one task
    future = pool.submit(lambda : True)
    assert(len(pool.futures) == 1)

# Generated at 2022-06-22 05:13:13.432319
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm.auto import tqdm

    # Unit test for method submit of class MonoWorker
    import time
    from tqdm.auto import tqdm

    def assert_first_done(lst):
        assert lst, 'Empty list'
        assert lst[0].done(), 'First not done'
        for f in lst[1:]:
            assert not f.done(), 'Second done'

    def assert_last_done(lst):
        assert lst, 'Empty list'
        assert lst[-1].done(), 'Last not done'
        for f in lst[:-1]:
            assert not f.done(), 'Second done'

    # Test setup
    worker = MonoWorker()
    # Test that waiting worker, if still running, is left as is

# Generated at 2022-06-22 05:13:24.084664
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import uuid
    def log(x):
        #print(x)
        time.sleep(1)
        return x

    def iterate():
        id0 = str(uuid.uuid1())
        id1 = str(uuid.uuid1())
        print('  id:', id0)
        assert(MonoWorker().submit(log, id0).result() == id0)
        print('  id:', id1)
        assert(MonoWorker().submit(log, id1).result() == id1)
        print('  id:', id0)
        assert(MonoWorker().submit(log, id0).result() == id0)

    iterate()

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:13:42.060381
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    m = MonoWorker()
    assert len(m.futures) == 0
    f1 = m.submit(time.sleep, 0.01)
    assert len(m.futures) == 1
    f1.wait()
    assert len(m.futures) == 0
    f1 = m.submit(time.sleep, 0.01)
    f2 = m.submit(time.sleep, 0.01)
    assert len(m.futures) == 2
    f2.wait()
    assert len(m.futures) == 1
    f1.wait()
    assert len(m.futures) == 0

# Generated at 2022-06-22 05:13:47.592995
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import multiprocessing
    from .monitor import monitor_process
    from .async_ import ThreadedWorker

    def dum():
        time.sleep(.01)
        return

    n = multiprocessing.cpu_count()
    with monitor_process() as process:
        with ThreadedWorker(n) as worker:
            for _ in tqdm_auto.tqdm(range(n + 1)):
                worker.submit(dum)
    assert process.cpu_percent() < 60

# Generated at 2022-06-22 05:13:57.472324
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Lock
    from concurrent.futures import Future
    lock = Lock()

    def func(i):
        sleep(0.1)
        with lock:
            global x
            x = i

    mw = MonoWorker()
    x = None
    assert x is None
    assert len(mw.futures) == 0
    future1 = mw.submit(func, 1)
    assert x is None
    assert list(mw.futures) == [future1]
    future2 = mw.submit(func, 2)
    assert x is None
    assert list(mw.futures) == [future1]
    future1.result()
    assert x == 1
    future2.result()
    assert x == 2

    x = None
    future

# Generated at 2022-06-22 05:14:07.573085
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()

    import time
    import threading
    def job(num, secs):
        time.sleep(secs)
        print('job' + str(num) + ' done!')
    mw.submit(job, 1, 3)
    mw.submit(job, 2, 2)
    mw.submit(job, 3, 1)
    # job1 and job2 will be discarded


# Generated at 2022-06-22 05:14:18.906033
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=unused-argument
    def f(x, delay=0.1):
        tqdm_auto.write("Running " + str(x))
        import time
        time.sleep(delay)
        return x

    m = MonoWorker()
    assert m.futures == deque([], 2)
    m.submit(f, 1)
    assert len(m.futures) == 1
    assert m.futures.pop().result() == 1
    m.submit(f, 2)
    assert len(m.futures) == 1
    assert m.futures.pop().result() == 2
    m1 = m.submit(f, 1)
    m2 = m.submit(f, 2, delay=0.2)

# Generated at 2022-06-22 05:14:28.849720
# Unit test for constructor of class MonoWorker

# Generated at 2022-06-22 05:14:35.806029
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import as_completed
    from time import sleep
    from random import randint

    def _test(duration):
        sleep(duration)
        return randint(0, duration - 1)

    mw = MonoWorker()
    mw.submit(_test, 1)
    for future in as_completed(mw.futures):
        assert future.result() < 1.5
    mw.submit(_test, 1)
    mw.submit(_test, 2)
    for future in as_completed(mw.futures):
        assert future.result() < 3.5

# Generated at 2022-06-22 05:14:42.431363
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import itertools
    import multiprocessing

    def func(sleep_time):
        time.sleep(sleep_time)
        return sleep_time

    with multiprocessing.Pool(1) as p:
        for sleep_time in [2, 3, 1, 4]:
            assert p.apply(func, args=(sleep_time,)) == sleep_time

    with MonoWorker() as p:
        for sleep_time in [2, 3, 1, 4]:
            assert p.submit(func, sleep_time).result() == sleep_time

    with MonoWorker() as p:
        for sleep_time in itertools.count(1):
            assert p.submit(func, sleep_time).result() == sleep_time
            time.sleep(sleep_time)

# Generated at 2022-06-22 05:14:52.461691
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test _thread-related code."""
    from future.utils import PY3
    from . import trange

    def count(n):
        for _ in trange(n):
            pass

    # Constructor only
    MonoWorker()
    del MonoWorker

    # test basic usage (no threading)
    mw = MonoWorker()
    f1 = mw.submit(count, 5)
    f2 = mw.submit(count, 3)
    f1.result()
    f2.result()

    # test multiple `trange`s in parallel
    mw = MonoWorker()
    f1 = mw.submit(count, 10)
    f2 = mw.submit(count, 10)
    f1.result()
    f2.result()


# Generated at 2022-06-22 05:15:03.250147
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Semaphore

    semaphore = Semaphore(2)

    def worker():
        sleep(1)
        semaphore.release()

    worker_pool = MonoWorker()

    with tqdm_auto.tqdm(total=3) as t:
        worker_pool.submit(worker)
        worker_pool.submit(worker)
        semaphore.acquire()
        t.update(1)
        worker_pool.submit(worker)
        worker_pool.submit(worker)
        worker_pool.submit(worker)
        semaphore.acquire()
        t.update(1)
        semaphore.acquire()
        t.update(1)

# Generated at 2022-06-22 05:15:30.918633
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Simple test that method `submit()` is working."""
    import time

    def _pause(interval, file=None):
        time.sleep(interval)
        tqdm_auto.write(str(interval), file=file)

    mw = MonoWorker()
    tqdm_auto.write('a 1...')
    mw.submit(_pause, 1, file=__file__)
    tqdm_auto.write('a 2...')
    mw.submit(_pause, 2, file=__file__)
    tqdm_auto.write('a 3...')
    mw.submit(_pause, 3, file=__file__)
    tqdm_auto.write('a 4...')
    mw.submit(_pause, 4, file=__file__)

# Generated at 2022-06-22 05:15:39.132365
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..tqdm import trange, tqdm_pandas
    from .import_tqdm import tqdm
    from threading import Thread, Lock
    from concurrent.futures import as_completed
    # check that it works as a single-threaded ThreadPoolExecutor
    task_queue = deque()

    def func(*args, **kwargs):
        sleep(0.1)
        task_queue.append((args, kwargs))

    pool = MonoWorker()
    for _ in range(10):
        pool.submit(func, "a", "b")
    assert pool.futures
    task_queue.appendleft(None)
    assert list(tqdm(as_completed(pool.futures),
                     desc="bar_futures")) == list

# Generated at 2022-06-22 05:15:49.653064
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import signal
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    from concurrent.futures import as_completed
    from ..utils import format_sizeof
    tqdm_auto.write('-' * 80)
    tqdm_auto.write(format_sizeof(MonoWorker.__dict__))
    worker = MonoWorker()
    for i in range(4):
        worker.submit(time.sleep, .01 + .01 * i)
        worker.futures[0].cancel()
        time.sleep(.001)

    tqdm_auto.write('-' * 80)
    tqdm_auto.write(format_sizeof(MonoWorker.__dict__))

    tqdm_auto.write('-' * 80)

# Generated at 2022-06-22 05:16:01.732957
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    from concurrent.futures import Future

    def slow_fib(n):
        t_start = time.time()
        a, b = 0, 1
        for _ in range(n):
            a, b = b, a+b
        time.sleep(n)
        return a, time.time() - t_start


    N = 10
    T = 0.1
    mw = MonoWorker()

    futs = []
    for _ in range(10):
        f = mw.submit(slow_fib, N)
        futs.append(f)
        N += 1
        time.sleep(T)
        T += 0.01

    for f in futs:
        assert isinstance(f, Future)
        assert not f.cancelled()
       

# Generated at 2022-06-22 05:16:07.352677
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import os
    os.system("rm -f test_MonoWorker_submit.log")
    mor = MonoWorker()
    mor.submit(time.sleep, 0.1)
    time.sleep(0.05)
    tqdm_auto.write("1")
    mor.submit(time.sleep, 0.1)
    time.sleep(0.05)
    tqdm_auto.write("2")
    mor.submit(time.sleep, 0.1)
    time.sleep(0.05)
    tqdm_auto.write("3")
    mor.submit(time.sleep, 0.1)
    time.sleep(0.05)
    tqdm_auto.write("4")
    time.sleep(0.3)

# Generated at 2022-06-22 05:16:11.838701
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Constructor
    mono = MonoWorker()
    assert mono.pool.__class__.__name__ == 'ThreadPoolExecutor'
    assert mono.futures.__class__.__name__ == 'deque'
    assert mono.futures.maxlen == 2
    assert not len(mono.futures)


# Generated at 2022-06-22 05:16:18.642687
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from concurrent.futures import Future, thread

    x = MonoWorker()

    # Task 0
    def f0(val=0):
        if val < 1:
            raise ValueError("val must be >= 1")
        return val

    future0 = x.submit(f0, 0)
    assert isinstance(future0, Future)
    assert not future0.done()
    assert future0.exception() is not None
    x.pool.shutdown(wait=False)

    # Task 1
    def f1(val=1):
        return val

    future1 = x.submit(f1, 1)
    assert isinstance(future1, Future)
    assert not future1.done()
    assert future1.exception() is None
    x.pool.shutdown(wait=False)

    # Task 2


# Generated at 2022-06-22 05:16:27.264408
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-22 05:16:31.416030
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker.pool._work_queue.maxsize == 1
    assert worker.pool.workers == set()
    assert worker.futures.maxlen == 2
    assert len(worker.futures) == 0

# Generated at 2022-06-22 05:16:39.702112
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from queue import Queue
    from threading import Thread

    def worker(q):
        mono_worker = MonoWorker()
        for f in q:
            f(mono_worker)
            sleep(0.1)

    q = Queue()
    for _ in range(10):
        q.put(lambda mono_worker: mono_worker.submit(lambda: sleep(1)))

    t = Thread(target=worker, args=(q,))
    t.daemon = True
    t.start()
    t.join()
    assert q.qsize() == 0

# Generated at 2022-06-22 05:17:06.962598
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    mw = MonoWorker()
    mw.submit(time.sleep, 1.)  # t = [0, 1]
    mw.submit(time.sleep, .5)  # t = [0, .5]
    t0 = time.time()
    time.sleep(1.)  # t = [1, 1.5]
    mw.submit(time.sleep, .5)  # t = [1.5, 2]
    time.sleep(.5)  # t = [2, 2.5]
    mw.submit(time.sleep, random.randint(3, 5))  # t = [2.5, 3]
    time.sleep(3.)  # t = [3, 6]

# Generated at 2022-06-22 05:17:17.451202
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def slow_add(a, b=1):
        import time
        time.sleep(0.5)
        return a + b
    def fast_add(a, b=1):
        import time
        time.sleep(0.1)
        return a + b
    mw = MonoWorker()
    f1 = mw.submit(slow_add, 0)
    f2 = mw.submit(slow_add, 0)
    f3 = mw.submit(slow_add, 0)
    f4 = mw.submit(fast_add, 0)
    f5 = mw.submit(fast_add, 0)
    assert f1 == f2
    assert f2 == f3
    assert f3 != f4
    assert f4 == f5
    assert f1.result() == 0

# Generated at 2022-06-22 05:17:19.139328
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import warnings
    w = warnings.catch_warnings(record=True)
    MonoWorker()
    assert not len(w)  # no warning

# Generated at 2022-06-22 05:17:27.749367
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def check_order(func, args, kwargs, order):
        """Check if execution steps are in the right order."""
        order.append(str(args))
        time.sleep(0.5)

    mono = MonoWorker()
    order = []

    mono.submit(check_order, 'the first', ('args',), {}, order)
    time.sleep(0.1)
    mono.submit(check_order, 'the second', ('args',), {}, order)
    time.sleep(1.1)

    assert order[0] == "('args',)"
    assert order[1] == "('args',)"

    order = []

    mono.submit(check_order, 'the first', ('args',), {}, order)
    time.sleep(0.1)
    mono.submit

# Generated at 2022-06-22 05:17:38.160243
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys
    from ._utils import _range

    sys.stderr.write("\nMonoWorker constructor: ")
    sys.stderr.flush()
    mw = MonoWorker()
    # Test empty
    assert not len(mw.futures)
    # Test one waiting
    mw.submit(time.sleep, 0.03)
    for _ in _range(5):
        assert len(mw.futures) == 1
        assert not mw.futures[0].done()
        time.sleep(0.01)
    time.sleep(0.06)
    assert mw.futures[0].done()
    # Test one already running, with another waiting
    mw.submit(time.sleep, 0.03)

# Generated at 2022-06-22 05:17:45.499938
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from tqdm import tqdm

    def f(i):
        sleep(0.1)
        return i

    with MonoWorker() as worker:
        res = []
        for i in tqdm(range(10), leave=False):
            res.append(worker.submit(f, i))

    assert all(future.done() for future in res)
    assert all(future.result() == i for i, future in enumerate(res))

# Generated at 2022-06-22 05:17:47.347145
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test the class MonoWorker"""
    MonoWorker()
    assert True


# Generated at 2022-06-22 05:17:59.098524
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # unit test for method submit of class MonoWorker
    import time
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            import logging
            import time

            logging.basicConfig(level=logging.DEBUG)
            print("Testing MonoWorker")
            import itertools

            def f(n):
                print("before sleep")
                time.sleep(n)
                print("after sleep")

            mono = MonoWorker()
            # 0-2s
            for i in itertools.count(0):
                t0 = time.time()
                mono.submit(f, i)
                t1 = time.time()
                print("took: ", t1 - t0)
                if i > 2:
                    break


# Generated at 2022-06-22 05:18:00.585091
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    f = MonoWorker()
    g = MonoWorker()

# Generated at 2022-06-22 05:18:08.298383
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    worker = MonoWorker()

    def wait(duration):
        time.sleep(duration)

    def fun1():
        worker.submit(wait, 3)
        worker.submit(wait, 6)
        worker.submit(wait, 2)
        worker.submit(wait, 5)
        worker.submit(wait, 2)

    def fun2():
        worker.submit(wait, 3)
        worker.submit(wait, 6)
        worker.submit(wait, 2)
        worker.submit(wait, 5)
        worker.submit(wait, 2)
        worker.submit(wait, 2)

    t0 = time.time()
    fun1()
    print("fun1", time.time() - t0)

    t0 = time.time()
    fun2()

# Generated at 2022-06-22 05:19:16.534269
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # MonoWorker must not be initialized before anything is printed
    # because it will interfere with the automatic bar display
    from ..utils import _term_move_up
    # MonoWorker()
    # Force printing
    tqdm_auto.write('')
    # Move cursor up to test if display is non-interfering
    _term_move_up()
    # Initialize testing MonoWorker
    mw = MonoWorker()
    # Test futures deque
    assert len(mw.futures) == 0, 'futures deque is not empty'
    assert mw.futures.maxlen == 2, 'futures deque maxlen is not 2'
    # Test submit function
    from time import sleep
    from tqdm import tqdm, trange
    from tqdm.utils import _range