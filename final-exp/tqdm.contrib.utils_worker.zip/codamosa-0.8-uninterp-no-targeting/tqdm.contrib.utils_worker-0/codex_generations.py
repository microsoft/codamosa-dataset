

# Generated at 2022-06-22 05:09:18.441670
# Unit test for constructor of class MonoWorker

# Generated at 2022-06-22 05:09:21.279154
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Create a MonoWorker instance
    mw = MonoWorker()
    # Submit a function without argument
    mw.submit(lambda: 'hello', 'world')



# Generated at 2022-06-22 05:09:32.060205
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test for MonoWorker"""
    import time
    from . import tqdm
    from . import tqdm_gui

    def task(i):
        "Some function that takes time"
        time.sleep(3)
        return i**2
    # Run tasks in a MonoWorker
    with MonoWorker() as mw:
        for i in tqdm_gui(range(10), leave=True,
                          desc="master", dynamic_ncols=True):
            fut = mw.submit(task, i)  # submit task
            while not fut.done():  # wait until task is done
                time.sleep(1)
            res = fut.result()
            print(res)
    mw.pool.shutdown(wait=False)

if __name__ == '__main__':
    test_

# Generated at 2022-06-22 05:09:37.795930
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    @MonoWorker.submit
    def test(x):
        sleep(1)
        return x

    test(1)
    test(2)


# Autocomplete for external editors/IDEs
if __doc__ is not None:
    __doc__ = __doc__.encode('utf-8').decode('utf-8')

# Generated at 2022-06-22 05:09:44.066789
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mono_worker = MonoWorker()

    def f(a):
        time.sleep(a)
        return a

    mono_worker.submit(f, 1.)
    mono_worker.submit(f, 1.)
    mono_worker.submit(f, 2.)
    mono_worker.submit(f, 2.)
    mono_worker.submit(f, 2.)
    mono_worker.submit(f, 2.)


# Generated at 2022-06-22 05:09:50.804914
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from .util import StringIO
    from .prange import prange
    import sys


# Generated at 2022-06-22 05:09:59.895739
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    for i in range(10):
        mw.submit(time.sleep, 2)
        print(mw.futures)
        time.sleep(0.1)
    time.sleep(1.2)
    for i in range(10):
        mw.submit(time.sleep, 5)
        print(mw.futures)
        time.sleep(0.1)
    # mw.submit(time.sleep, 2)
    # assert len(mw.futures) == 2
    # assert mw.futures[-1].running()  # last task is running
    # mw.submit(time.sleep, 3)  # should replace waiting
    # assert len(mw.futures) == 2
    # assert not m

# Generated at 2022-06-22 05:10:09.110030
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event
    res = []

    def foo(n, evt):
        evt.wait()
        time.sleep(1)
        res.append(n)

    # create a MonoWorker with a pool that contains only one worker
    mw = MonoWorker()

    # first task, which is also the only running task
    e1 = Event()
    f1 = mw.submit(foo, 1, e1)

    # second task, which is also the only waiting task
    e2 = Event()
    f2 = mw.submit(foo, 2, e2)

    # third task, which should always be discarded
    e3 = Event()
    f3 = mw.submit(foo, 3, e3)

    # the latter two futures should be discarded

# Generated at 2022-06-22 05:10:18.580600
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test MonoWorker.submit method."""
    import time
    mono_worker = MonoWorker()
    tqdm_auto.write('BEFORE')

    def task_delayed_sig(signal):
        if signal:
            signal.set()
        time.sleep(0.5)
        tqdm_auto.write('DELAYED SIG')

    def worker_submit(signal):
        if signal:
            signal.set()
        mono_worker.submit(task_delayed_sig, signal)

    def task_sig(signal):
        if signal:
            signal.set()
        tqdm_auto.write('SIG')

    def worker_submit2(signal):
        if signal:
            signal.set()

# Generated at 2022-06-22 05:10:27.487638
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method `submit` of class `MonoWorker`."""
    from time import time, sleep
    from concurrent.futures import as_completed
    from math import sqrt
    def some_func(*args, **kwargs):
        """Fake function"""
        sleep(0.5)

    # Testing successive calls to submit
    worker = MonoWorker()
    delay = 0.2
    t_start = time()
    for i in tqdm_auto.trange(5, desc='testing MonoWorker'):
        if i > 0:
            sleep(delay)
        futures = [worker.submit(some_func, (i, j, k), {'x': i})
                   for j in range(3) for k in range(3)]

# Generated at 2022-06-22 05:10:39.411008
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from random import random

    def sleeper(delay):
        time.sleep(delay)
        return delay

    mw = MonoWorker()
    now = time.time()
    fut = mw.submit(sleeper, 0.1)
    assert fut.done()
    assert time.time() - now < 0.1
    assert fut.result() == 0.1

    now = time.time()
    fut.cancel()  # no harm done
    assert not fut.done()
    assert time.time() - now < 0.1
    assert fut.result() == 0.1

    fut = mw.submit(sleeper, 0.1)
    now = time.time()
    fut2 = mw.submit(sleeper, 0.2)
    assert fut.done()

# Generated at 2022-06-22 05:10:49.319037
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread, Event
    from .util import do_nothing

    bar = tqdm_auto.tqdm(total=100, bar_format="{l_bar}")

    def a_sleep(t):
        sleep(t)
        bar.update(20)

    def b_sleep(t):
        sleep(t)
        bar.update(30)

    def c_sleep(t):
        sleep(t)
        bar.update(50)

    def submit_thread(mw, sleep_func, t, submit_events, sleep_events):
        submit_events.wait(0.0)
        sleep_events.clear()
        mw.submit(sleep_func, t)
        sleep_events.set()
        bar.update(10)


# Generated at 2022-06-22 05:10:57.082193
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    This shows that one call to the super()'s method with a single argument
    always adds to the pool's queue (if the queue isn't full). This shows that
    only one thread is running at any given time.
    """

    def test_func(argv):
        return argv

    from ..utils import _term_move_up
    from . import tqdm

    def test(n=20, total=10):
        with tqdm(total=total) as pbar:
            for i in range(n):
                pbar.write('______{i}. calling MonoWorker.submit(...)')
                pbar.update(1.0/n)
                MonoWorker().submit(test_func, 'argument')


# Generated at 2022-06-22 05:11:07.018804
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from concurrent import futures

    # Worker
    class Worker():

        def __init__(self, queue):
            self.queue = queue

        def fit(self):
            self.queue.append(1)
            time.sleep(1)  # worker takes 1 second to fit

    workers = [Worker(tqdm_auto._instances) for _ in range(10)]
    print('Creating 10 workers: DONE')

    # Running workers
    with MonoWorker() as pool:
        for worker in workers:
            pool.submit(worker.fit)

    assert len(tqdm_auto._instances) == 1, "Should have 1 running worker"
    time.sleep(1)  # wait for 1 second for the first worker to finish

# Generated at 2022-06-22 05:11:14.547220
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    import operator

    mw = MonoWorker()
    lock = Lock()
    cnt, cur_sum = 10, 0

    def some_fn(x):
        sleep(2)
        return x

    def tst(x):
        with lock:
            nonlocal cur_sum
            cur_sum = operator.add(cur_sum, x)
        return some_fn(x)

    with tqdm_auto.tqdm(total=cnt) as pbar:
        for x in pbar:
            f = mw.submit(tst, x)
            f.add_done_callback(lambda f: pbar.update())

    assert cur_sum == sum(range(cnt))

# Generated at 2022-06-22 05:11:23.176947
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import random, signal
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    from . import (test_worker_1, test_worker_2)
    from .test_worker import test_worker
    test_cases = [
        (random.random, (), {}),
        (test_worker, (), {}),
        (test_worker, (True,), {}),
        (test_worker_1, (), {}),
        (test_worker_2, (), {}),
    ]
    for func, args, kwargs in test_cases:
        test_MonoWorker_func(func, args, kwargs)


# Generated at 2022-06-22 05:11:33.933005
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    from collections import defaultdict
    from functools import partial

    class CallCounter(defaultdict):
        """
        Simple call counter (for testing purposes).
        """
        def __missing__(self, key):
            return 0

        def __call__(self, key):
            self[key] += 1
            print(self)

    counter = CallCounter()  # create a call counter
    mw = MonoWorker()  # create a MonoWorker

    # generate a bunch of functions
    def f(name, num=1, sleep=0):
        time.sleep(random.uniform(0, sleep))
        counter(name)
        return num

    funcs = [partial(f, i, sleep=random.uniform(0, 0.1))
             for i in range(10)]


# Generated at 2022-06-22 05:11:42.565646
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    class Waiter(object):
        """Wait for a given amount of time."""
        def __init__(self, secs):
            self.secs = secs

        def __call__(self):
            time.sleep(self.secs)
            return self.secs

    worker = MonoWorker()
    waiter = Waiter(0.1)
    for _ in range(6):
        worker.submit(waiter)
    for future in worker.futures:
        assert future.result() == waiter.secs



# Generated at 2022-06-22 05:11:45.685590
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert not mw.futures
    assert mw.pool.__class__.__name__ == 'ThreadPoolExecutor'


# Generated at 2022-06-22 05:11:56.657025
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import os
    import sys
    import threading
    from .threading import ThreadWithLogging

    class Sleeper(object):
        """Wait for N seconds, then return"""
        def __init__(self, *args, **kwargs):
            self.sleep_time = 2

        def __call__(self, *args, **kwargs):
            time.sleep(self.sleep_time)
            return self.sleep_time

    class SlowWriter(object):
        """Wait for N seconds, then raise IOError"""
        def __init__(self, *args, **kwargs):
            self.sleep_time = 2

        def __call__(self, *args, **kwargs):
            time.sleep(self.sleep_time)
            raise IOError("Error\n")


# Generated at 2022-06-22 05:12:06.499441
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from multiprocessing import Pool
    from itertools import repeat
    mw = MonoWorker()
    mw.submit(time.sleep, 1)
    p = Pool(2)
    mw.submit(p.map, time.sleep, repeat(1, repeat=1))

# Generated at 2022-06-22 05:12:17.174056
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import Future
    from subprocess import Popen, PIPE, CalledProcessError

    def noop(x):  # for testing
        return x
    def err(x):
        raise Exception("TEST EXCEPTION")
    def long(x):  # for testing
        from time import sleep
        sleep(0.1)
        return x
    def wait_for_future(future):
        # wait 0.1 sec
        import time
        start = time.time()
        while time.time() - start < 0.1:
            if future.done():
                break
        return 0
    def assert_success(future_list, result):
        assert len(future_list) == len(result)
        for i, r in enumerate(result):
            assert future_list[i].result() == r

# Generated at 2022-06-22 05:12:28.831576
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def test_func(prefix, sleep_time):
        time.sleep(sleep_time)
        print(prefix + "slept for %0.2f seconds" % sleep_time)
        return prefix + "slept for %0.2f seconds" % sleep_time
    w = MonoWorker()
    w.submit(test_func, "fast-1: ", 0.1)
    w.submit(test_func, "fast-2: ", 0.1)
    w.submit(test_func, "medium-1: ", 0.5)
    w.submit(test_func, "medium-2: ", 0.5)
    w.submit(test_func, "medium-3: ", 0.5)
    w.submit(test_func, "slow-1: ", 1)
    w.submit

# Generated at 2022-06-22 05:12:31.904843
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def test_func():
        return True

    monoWorker = MonoWorker()
    monoWorker.submit(test_func)
    assert monoWorker.futures[0].result() == True

# Generated at 2022-06-22 05:12:43.655803
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-22 05:12:49.052235
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    running = None
    for _ in range(6):
        # 1,2 running; 3,4 discarded; 5,6 waiting
        running = mw.submit(time.sleep, 1)
        time.sleep(0.1)
    running.result()  # Wait


# Generated at 2022-06-22 05:12:55.313202
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def _test_f():
        from time import sleep
        import random
        sleep(random.random() * 0.1)
        return True

    mw = MonoWorker()
    results = []
    for i in range(10):
        waiting = mw.submit(_test_f)
        if waiting:
            results.append(waiting.result())
    assert all(results)
    assert len(results) <= 2
    assert mw.pool._work_queue.unfinished_tasks == 0



# Generated at 2022-06-22 05:13:02.845262
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from concurrent.futures import Future
    from random import random
    from tqdm import tqdm

    def raiser(error):
        raise error

    def sleeper(seconds, cancel=False):
        if cancel:
            raise Future.cancelled_error()
        tqdm.sleep(seconds)

    def submitter(worker, seconds, error=None, cancel=False):
        if error:
            return worker.submit(raiser, error)
        else:
            return worker.submit(sleeper, seconds, cancel=cancel)

    tqdm.write("Testing MonoWorker ...")
    worker = MonoWorker()
    # test submit()
    tqdm.write("Testing submit() ...")
    tqdm.write("Sleeping for {} sec".format(random()))

# Generated at 2022-06-22 05:13:07.844274
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def wait():
        import time
        time.sleep(1)
    worker = MonoWorker()
    worker.submit(wait)
    worker.submit(wait)
    worker.submit(wait)
    worker.submit(wait)
    worker.submit(wait)


# Generated at 2022-06-22 05:13:09.225015
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.pool._max_workers == 1, mw.pool._max_workers

# Generated at 2022-06-22 05:13:20.138480
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def f():
        return 'M'
    f = MonoWorker().submit(f)
    assert f.result() == 'M'

# Generated at 2022-06-22 05:13:29.578778
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import inspect
    import numpy.random

    def func_one():
        time.sleep(1)
        return "one"

    def func_two():
        time.sleep(1)
        return "two"

    def func_three():
        return "three"

    def func_exception():
        1 / 0  # ZeroDivisionError

    def func_cancel(delay):
        for _ in range(delay):
            time.sleep(1)
        return "cancel"

    def func_no_such_method():
        return MonoWorker.no_such_method()

    def test_running():
        worker = MonoWorker()
        worker.submit(func_one)
        worker.submit(func_two)
        result = worker.futures[0].result()
        assert result

# Generated at 2022-06-22 05:13:32.293546
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    MonoWorker()
    print("Success")
    time.sleep(1)
    print("Success")

# Unit test of submit of class MonoWorker

# Generated at 2022-06-22 05:13:42.140940
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def task(i):
        time.sleep(0.1)
        return i

    mw = MonoWorker()

    # Fill the queue up to maxlen
    res = []
    futures = []
    for i in range(2):
        f = mw.submit(task, i)
        res.append(f.result())
        futures.append(f)
    assert len(res) == len(futures) == 2

    # Adding more tasks should replace the waiting task
    for i in range(2, 5):
        f = mw.submit(task, i)
        res.append(f.result())
    assert len(res) == 5

    # Wait for the running task to complete
    res.append(futures[0].result())
    assert len(res) == 6

# Generated at 2022-06-22 05:13:49.627933
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from io import BytesIO

    def f(x, io=BytesIO(), tsleep=0.1):
        time.sleep(tsleep)
        io.write(x)
        return io.getvalue()

    w1 = MonoWorker()
    w2 = MonoWorker()

    input("press enter to submit f(A)")
    x = w1.submit(f, "A")
    input("press enter to submit f(B)")
    y = w1.submit(f, "B")
    input("press enter to submit f(C)")
    z = w1.submit(f, "C")
    input("press enter to submit f(D)")
    z = w1.submit(f, "D")
    input("press enter to submit f(E)")
    z = w

# Generated at 2022-06-22 05:13:54.477872
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import multiprocessing
    from collections import namedtuple
    from concurrent.futures import as_completed
    from ..std import time as std_time
    from ..utils import format_sizeof

    def get_load_1():
        return multiprocessing.cpu_count()

    def get_load_2():
        time.sleep(0.3)
        return get_load_1()

    def test_func(func):
        client = MonoWorker()
        f = client.submit(func)
        std_time.sleep(0.1)
        f = client.submit(func)  # replace waiting
        std_time.sleep(1)  # should return immediately
        f = client.submit(func)  # replace running


# Generated at 2022-06-22 05:14:04.816429
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Test submission of multiple tasks to a MonoWorker.
    """
    import unittest

    class TestRun(Exception):
        pass

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.worker = MonoWorker()

        def test_run(self, num_tasks=10):
            """
            Create a stream of tasks and submit them to the MonoWorker.
            """
            statuses = []
            to_cancel = []
            for i in range(num_tasks):
                future = self.worker.submit(
                    _wait, 1, 2, status=i, statuses=statuses)
                if i < num_tasks // 2:
                    to_cancel.append(future)
            for future in to_cancel:
                future.cancel()

# Generated at 2022-06-22 05:14:08.877335
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    def f(x):
        sleep(x)
        return x * 0.1

    worker = MonoWorker()

    worker.submit(f, 1)
    worker.submit(f, 2)
    worker.submit(f, 3)
    worker.submit(f, 4)

    assert worker.futures[0].result() == 0.4

# Generated at 2022-06-22 05:14:19.894913
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method MonoWorker.submit"""
    import time
    import numpy as np

    def f(number, name, w_time, w_std, w_n=5):
        """f to be passed to pool"""
        while True:
            time.sleep(np.random.normal(w_time, w_time * w_std, w_n).min())
            print(str(number) + name)
            yield number

    worker = MonoWorker()

    for number in range(1001):
        name = ''
        if number % 5 == 0:
            name = 'F'
        elif number % 3 == 0:
            name = 'T'
        elif number % 2 == 0:
            name = 'E'
        if name == '':
            continue


# Generated at 2022-06-22 05:14:29.570605
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from itertools import count
    from os import cpu_count

    max_workers = cpu_count()

    def f(n):
        # non-deterministic wait
        sleep(abs(hash(n)) % 10)
        return n

    # test with single worker
    Q = MonoWorker()
    res = sorted(Q.submit(f, i) for i in count())
    assert len(res) == len(res) - 1 == res[-1].result() == list(range(len(res)))

    # test with multiple workers
    Q = ThreadPoolExecutor(max_workers=max_workers)
    res = sorted(Q.submit(f, i) for i in count(max_workers))
    assert len(res) == len(res) - max_workers == res[-1].result

# Generated at 2022-06-22 05:14:53.842616
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    class PhonyFuture(object):
        def __init__(self, num):
            self.num = num

        def cancel(self):
            pass

        def done(self):
            return self.num not in [-1, 0, 1]

    def submit(worker):
        worker.futures.append(PhonyFuture(-1))
        worker.futures.append(PhonyFuture(0))
        worker.futures.append(PhonyFuture(1))
        worker.futures.append(PhonyFuture(2))
        worker.futures.append(PhonyFuture(3))
        worker.futures.append(PhonyFuture(4))
        worker.futures.append(PhonyFuture(5))
        worker.futures.append(PhonyFuture(6))

   

# Generated at 2022-06-22 05:15:05.273446
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from math import isnan

    # pylint: disable=unused-argument
    def func_A(arg1, arg2, keyword1=None, keyword2=True):
        sleep(0.1)
        return (arg1, arg2, keyword1, keyword2)
    def func_B(arg1):
        sleep(0.1)
        return arg1
    def func_C():
        sleep(0.1)
        return None

    mono = MonoWorker()

    assert mono.submit(func_A, 1, 2).result() == (1, 2, None, True)
    assert mono.submit(func_C).result() is None
    assert mono.submit(func_B, 1).result() == 1
    # The command below should not be executed (replaced)

# Generated at 2022-06-22 05:15:16.805574
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test for MonoWorker constructor and methods.

    >>> import threading
    >>>
    >>> MonoWorker()
    <MonoWorker object, running jobs: 0, completed jobs: 0>
    >>>
    >>> MonoWorker.total_calls
    0
    >>> def func():
    ...     MonoWorker.total_calls += 1
    >>>
    >>> mw = MonoWorker()
    >>> assert mw.submit(func)
    >>> threading.current_thread().name
    'MainThread'
    >>> assert mw.submit(func)
    >>> assert mw.submit(func)
    >>> threading.current_thread().name
    'MainThread'
    >>>
    >>> MonoWorker.total_calls
    2
    """
    pass



# Generated at 2022-06-22 05:15:23.501931
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import _range

    def a(i):  # 2-3sec/i
        time.sleep(0.02 * (i + 1))
        return i + 1

    def b(i):  # 3-4sec/i
        time.sleep(0.03 * (i + 1))
        return -(i + 1)

    results = []
    mw = MonoWorker()

    # submit 5 tasks of a, with overwrite = False
    for i in _range(5):
        results.append(mw.submit(a, i))

    # submit 5 tasks of a, with overwrite = True
    for i in _range(5):
        results.append(mw.submit(a, i, overwrite=True))

    # submit 5 tasks of b, with overwrite = True

# Generated at 2022-06-22 05:15:31.041346
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test the `MonoWorker.submit` function."""
    import time

    def test_func(wait):
        tqdm_auto.write("Test start ", wait)
        time.sleep(wait)
        tqdm_auto.write("Test finished ", wait)

    mono_worker = MonoWorker()

    mono_worker.submit(test_func, 1)
    mono_worker.submit(test_func, 2)
    mono_worker.submit(test_func, 3)
    mono_worker.submit(test_func, 4)
    mono_worker.submit(test_func, 5)



# Generated at 2022-06-22 05:15:38.912792
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import _term_move_up

    from time import sleep
    from copy import copy

    mw = MonoWorker()

    def sub(i):
        sleep(1)
        return i

    start = int(tqdm_auto.default_timer())
    while tqdm_auto.default_timer() - start < 3:
        mw.submit(sub, copy(tqdm_auto.default_timer()))
        tqdm_auto.write('Moved up ' + str(tqdm_auto._term_move_up()))

    mw.pool.shutdown()
    sleep(2)
    print("\n\n")

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:15:46.501268
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def test_work():
        from time import sleep
        from random import random
        from ..utils import format_sizeof
        work = random() * 0.8
        for i in tqdm_auto.tqdm(
                unit='B', unit_scale=True, unit_divisor=1024,
                total=format_sizeof(work), desc='test'):
            sleep(random() * 0.1)
    mono_worker = MonoWorker()
    assert mono_worker.submit(test_work)
    assert mono_worker.submit(test_work)

# Generated at 2022-06-22 05:15:58.692264
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from .trange import TMonoRange as _t

    def slow_noisy_sleep(wait_time_secs, *args, **kwargs):
        """slow_noisy_sleep"""
        t = _t(wait_time_secs, leave=True)
        t_start = time.time()
        while time.time() - t_start < wait_time_secs:
            time.sleep(0.01)
            t.update()
        t.close()

    worker = MonoWorker()
    worker.submit(slow_noisy_sleep, 2)
    worker.submit(slow_noisy_sleep, 4)
    worker.submit(slow_noisy_sleep, 1)
    worker.submit(slow_noisy_sleep, 3)

# Generated at 2022-06-22 05:16:09.670754
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from contextlib import contextmanager
    from concurrent.futures import ThreadPoolExecutor

    def get_submit_res(pool, func, *args, **kwargs):
        """
        Default values for running and waiting tasks in class MonoWorker
        are used to customise expected result.
        """
        with ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(func, *args, **kwargs)

    @contextmanager
    def wait_for_completion(futures):
        yield
        for future in futures:
            future.result()

    @contextmanager
    def wait_for_cancel(futures):
        yield
        for future in futures:
            future.cancel()


# Generated at 2022-06-22 05:16:15.718801
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    # submit a task and wait for result
    result = worker.submit(lambda: "Hello")
    assert result.result() == "Hello"
    # submit a task and cancel
    result = worker.submit(lambda: "Bye")
    result.cancel()
    # submit a task and run the task which replaces the previous task
    result = worker.submit(lambda: "World")
    assert result.result() == "World"

# Generated at 2022-06-22 05:16:56.665906
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from ..guides import usage
    from ..utils import _range

    usage.dynamic_kwargs = True

    # Basic single case
    with tqdm_auto(_range(2)) as t:
        for i in t:
            time.sleep(.3)
            t.set_description("Waiting for {0}".format(i))
    # Multi case
    m = MonoWorker()
    with tqdm_auto(_range(3)) as t:
        for i in t:
            m.submit(time.sleep, .3)
            with tqdm_auto(_range(3)) as tt:
                for j in tt:
                    m.submit(time.sleep, .3)
                    tt.set_description("Waiting for {0}".format(i))
            t.set

# Generated at 2022-06-22 05:17:03.418393
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures as cf
    from tqdm import trange
    # With trange to reproduce #351
    mw = MonoWorker()
    delay = 0.1
    n = 2
    res_trange = []
    res_submit = []

    def long_func(i):
        time.sleep(delay)
        res_submit.append(i)
        return i

    with trange(n) as t:
        for i in t:
            res_trange.append(i)
            f = mw.submit(long_func, i)
            if f is not None:
                f.result()

# Generated at 2022-06-22 05:17:08.564262
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Arrange
    a = 0

    # Act
    worker = MonoWorker()
    worker.submit(lambda: a.append(2))
    worker.submit(lambda: a.append(1))
    worker.submit(lambda: a.append(3))
    worker.submit(lambda: a.append(4))
    # Assert
    assert a == [2, 1, 3, 4]



# Generated at 2022-06-22 05:17:15.044573
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import random
    from time import sleep
    from threading import Event
    from os import devnull
    from ..utils import _range

    def wait_for_x_secs(t, e):
        for _ in tqdm_auto(_range(2), desc=str(t), file=devnull):
            sleep(t)
        e.set()

    stop = Event()
    mw = MonoWorker()
    while not stop.wait(1):
        mw.submit(wait_for_x_secs, random(), stop)

# Generated at 2022-06-22 05:17:24.183374
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def foo(x):
        return x

    mw = MonoWorker()
    task = mw.submit(foo, 1)
    assert task.result() == 1, "`task.result()` must be 1"

    assert mw.submit(foo, 2).result() == 2, "`task.result()` must be 2"

    # This one doesn't run
    assert mw.submit(foo, 3).result() == 2, "`task.result()` must be 2"

    # Running this one always takes 3 seconds.
    def bar(x, y):
        time.sleep(3)
        return x + y

    task = mw.submit(bar, 1, 2)
    assert task.result() == 3, "`task.result()` must be 3"

# Generated at 2022-06-22 05:17:31.115120
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from .utils import temp_file

    class Callback(object):
        def __init__(self):
            self.complete = threading.Event()
            self.called = 0

        def __call__(self):
            assert not self.complete.is_set()
            self.called += 1
            self.complete.set()

    b = MonoWorker()
    with temp_file() as fname:
        with open(fname, 'w') as f:
            f.write('1')

        # test initial submission
        cb = Callback()
        assert cb.called == 0
        assert not cb.complete.is_set()
        b.submit(cb)
        assert cb.called == 0

# Generated at 2022-06-22 05:17:35.017709
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    MW = MonoWorker()
    res = []
    for i in tqdm_auto.tqdm(range(10)):
        MW.submit(res.append, i)
    time.sleep(1)
    assert res == list(range(10))

# Generated at 2022-06-22 05:17:41.511397
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..tqdm import tqdm
    from time import sleep

    def square(k):
        """Test square"""
        for i in tqdm(range(2 ** (10 + k)), desc='square', leave=False):
            sleep(0.01)
        return k ** 2

    test = ((i,) for i in range(2))
    with tqdm_auto.tqdm(total=2, desc='MonoWorker') as pbar:
        func = lambda i: square(i)
        mw = MonoWorker()
        for i in test:
            future = mw.submit(func=func, *i)
            future.add_done_callback(lambda fi: pbar.update())

# Generated at 2022-06-22 05:17:50.345664
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import sys
    import time

    with tqdm_auto.tqdm(total=2, leave=False) as t:
        def testfunc(x):
            sys.stderr.write(x)
            time.sleep(0.5)
        mono = MonoWorker()
        mono.submit(testfunc, "one")
        mono.submit(testfunc, "two")
        mono.submit(testfunc, "three")
        mono.submit(testfunc, "four")
        t.update()
        mono.submit(testfunc, "five")
        t.update()


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:18:01.902365
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    mw = MonoWorker()
    test_list = []

    def test_func(n):
        time.sleep(random.random())
        test_list.append(n)

    # T1: start 2nd running
    task1 = mw.submit(test_func, 1)
    # T2: start 1st running
    task2 = mw.submit(test_func, 2)
    # T3: replace 2nd waiting with 3rd running
    task3 = mw.submit(test_func, 3)
    # T4: start 4th running
    task4 = mw.submit(test_func, 4)
    # T5: replace 3rd running with 5th running
    task5 = mw.submit(test_func, 5)


# Generated at 2022-06-22 05:19:09.309155
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def test_f(i):
        import time
        time.sleep(1)
        return i

    mono_w = MonoWorker()
    mono_w.submit(test_f, 0)
    mono_w.submit(test_f, 1)
    mono_w.submit(test_f, 2)
    mono_w.submit(test_f, 3)
    mono_w.submit(test_f, 4)
    mono_w.submit(test_f, 5)
    mono_w.futures[0].result()
    mono_w.futures[1].result()

# Generated at 2022-06-22 05:19:10.729393
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    MonoWorker()



# Generated at 2022-06-22 05:19:22.198718
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    mw = MonoWorker()

    class TestFunc():
        def __init__(self, tup, to_sleep = None, name = None):
            self.tup = tup
            self.to_sleep = to_sleep
            self.name = name

        def __call__(self):
            if self.to_sleep is not None:
                time.sleep(self.to_sleep)