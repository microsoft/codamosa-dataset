

# Generated at 2022-06-22 05:09:21.237814
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    x = MonoWorker()
    y = MonoWorker()

    def foo(sleep):
        time.sleep(sleep)
        return 'done'

    def bar():
        raise RuntimeError("I'm a raise")

    # Test submit
    future_a = x.submit(foo, 1)
    future_b = x.submit(foo, 1)
    future_c = y.submit(foo, 0.2)
    assert future_a.done() is False
    assert future_b.done() is False
    assert future_c.result() == "done"

    # Test exception handling
    try:
        y.submit(bar())
    except Exception as e:
        assert str(e) == "I'm a raise"

    # Test cancel
    assert future_c.done() is True
    assert future

# Generated at 2022-06-22 05:09:30.681756
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep, time
    from unittest import TestCase
    from .utils import closing
    from .tests import range

    class Test(TestCase):
        def test(self):
            worker = MonoWorker()
            with closing(worker):
                worker.submit(sleep, 0.2)
                sleep(0.1)
                worker.submit(sleep, 0.3)
                sleep(0.1)
                worker.submit(sleep, 0.4)
                now = time()
                worker.futures[1].result()  # blocking
                self.assertGreater(time() - now, 0.4)

    test = Test()
    test.test()



# Generated at 2022-06-22 05:09:37.713178
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert len(worker.futures) == 0
    assert worker.pool
    assert worker.submit(int, "5")
    assert len(worker.futures) == 1
    assert worker.submit(int, "5")  # waiting task replaces current
    assert len(worker.futures) == 1
    assert worker.submit(int, "5")  # waiting task replaces current
    assert len(worker.futures) == 1

# Generated at 2022-06-22 05:09:47.371506
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from itertools import count
    from time import sleep
    from threading import current_thread
    from queue import Queue
    from multiprocessing import Pool

    def throw():
        sleep(0.01)
        raise Exception()

    def sleep1(sleep_queue=None):
        sleep(0.01)
        sleep_queue.put((current_thread(), sleep.__name__))

    def sleep2(sleep_queue=None):
        sleep(0.01)
        sleep_queue.put((current_thread(), sleep.__name__))

    def close_pool(pool):
        sleep(0.1)
        pool.close()

    def test_pool(pool):
        """Test worker pool by running two tasks in parallel"""
        sleep_queue = Queue()
        pool.submit(sleep1, sleep_queue)

# Generated at 2022-06-22 05:09:58.005805
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ._sys_info import MONOTONIC

    # pylint: disable=too-many-locals
    # pylint: disable=too-few-public-methods
    class Dummy:
        # pylint: disable=missing-docstring
        def __init__(self):
            self.name = None
            self.start = MONOTONIC()

        def __call__(self):
            self.name = "Dummy"
            self.sleep = 1
            self.post_start = MONOTONIC()
            sleep(self.sleep)
            self.post_end = MONOTONIC()

    dummy_pool = MonoWorker()
    dummy = Dummy()
    dummy_future = dummy_pool.submit(dummy)


# Generated at 2022-06-22 05:10:08.880008
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> from time import sleep
    >>> mw = MonoWorker()
    >>> mw.submit(sleep, 1); mw.submit(sleep, 2); mw.submit(sleep, 3)
    <Future at 0x... state=running>
    >>> mw.submit(sleep, 4); mw.submit(sleep, 5)
    <Future at 0x... state=running>
    >>> mw.submit(sleep, 6); mw.submit(sleep, 7)
    <Future at 0x... state=running>
    >>> mw.submit(sleep, 8); mw.submit(sleep, 9)
    <Future at 0x... state=running>
    >>> mw.submit(sleep, 10); mw.submit(sleep, 11)
    <Future at 0x... state=running>
    """



# Generated at 2022-06-22 05:10:18.283239
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, sys

    def f(x):
        return x**2

    def error(x):
        raise RuntimeError("error")

    worker = MonoWorker()

    for i in tqdm_auto.trange(100):
        y = worker.submit(f, i)
        worker.submit(error, i)
        time.sleep(0.01)
        if i%10 == 0:
            sys.stdout.write("\n")
        sys.stdout.write("{:3d} ".format(y.result()))
        sys.stdout.flush()
    sys.stdout.write("\n")

    print("")
    worker.submit(time.sleep, 0.2)
    with tqdm_auto.trange(1) as t:
        for i in t:
            time

# Generated at 2022-06-22 05:10:26.149954
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import format_sizeof
    from ..tqdm import trange

    def doit(*args, **kwargs):
        import time
        with trange(1000, leave=True, desc=format_sizeof(args, **kwargs)) as t:
            time.sleep(1)
            for i in t:
                time.sleep(.01)

    mw = MonoWorker()
    mw.submit(doit, 1)
    print("\n")
    mw.submit(doit, 1, a=1)
    print("\n")


if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:10:32.455277
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import random
    import time

    def long_task():
        task_id = random()
        tqdm_auto.write("starting {}".format(task_id))
        time.sleep(1)
        tqdm_auto.write("ending {}".format(task_id))

    w = MonoWorker()

    w.submit(long_task)
    w.submit(long_task)
    w.submit(long_task)
    w.submit(long_task)
    w.submit(long_task)
    w.submit(long_task)
    w.submit(long_task)
    w.submit(long_task)
    w.submit(long_task)
    w.submit(long_task)
    w.submit(long_task)
    w.submit(long_task)


# Generated at 2022-06-22 05:10:33.070246
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()



# Generated at 2022-06-22 05:10:39.332252
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert hasattr(worker, "pool")
    assert hasattr(worker, "futures")
    assert worker.pool.__class__ == ThreadPoolExecutor


# Generated at 2022-06-22 05:10:40.901940
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()


if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-22 05:10:51.236033
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from datetime import datetime
    from threading import Lock
    from sys import stdout
    from ..serial import tqdm as tqdm_serial

    def slow_func(func):
        def wrapper(*args, **kwargs):
            time.sleep(0.1)
            return func(*args, **kwargs)
        return wrapper

    def print_():
        print("%s  elapsed: %s" % (datetime.now(), time.time() - _start_time))

    @slow_func
    def func1():
        print_()

    @slow_func
    def func2():
        print_()
        # time.sleep(0.1)
        # print("calling func1")
        # func1()
        # time.sleep(0.1)
        # print("called  func

# Generated at 2022-06-22 05:10:57.726398
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .utils import SCREEN_WIDTH

    def wait(sec, id_):
        sleep(sec)
        return id_

    # test 1
    n = 5
    worker = MonoWorker()
    pbar = tqdm_auto.tqdm(n, bar_format="{desc}: {percentage:3.0f}%|{bar}|")
    for _ in range(n):
        worker.submit(wait, 0.01, id(_))
        pbar.update(1)
        pbar.set_description(str(len(worker.futures)))
    pbar.close()
    assert len(worker.futures) == 1
    worker.futures[0].result()  # wait for queue to empty
    assert len(worker.futures)

# Generated at 2022-06-22 05:11:06.925561
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from ..tqdm import tqdm

    work = MonoWorker()

    def f():
        for _ in tqdm(range(10)):
            time.sleep(0.1)
        return 'done'

    work.submit(f)
    work.submit(f)
    work.submit(f)

    assert str(work.futures) == '[<Future at 0x1094e1908 state=running>]'

    work.submit(f)
    work.submit(f)
    work.submit(f)

    assert str(work.futures) == '[<Future at 0x1094e1c50 state=running>]'

    time.sleep(3)
    
    assert str(work.futures) == 'deque([])'

# Generated at 2022-06-22 05:11:13.380796
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing import Lock
    from time import sleep, time

    class Sync:
        def __init__(self):
            self.lock = Lock()
            self.time = 0

    def target(sync):
        with sync.lock:
            sync.time = time()

    sync = Sync()
    mono = MonoWorker()
    for i in range(10):
        mono.submit(target, sync)
    sleep(1)
    for i in range(10):
        mono.submit(target, sync)

    with sync.lock:
        assert sync.time > 0
        assert sync.time < time()

# Generated at 2022-06-22 05:11:23.216813
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from .tests1 import sleep
    mw = MonoWorker()
    try:
        assert len(mw.futures) == 0
    except:
        raise Exception("test 1 failed!")
    try:
        assert mw.futures.maxlen == 2
    except:
        raise Exception("test 2 failed!")
    try:
        mw.submit(sleep, 0.5, 1)
        # Test that function is submitted to the queue, but not started
        time.sleep(0.1)
        assert len(mw.futures) == 1
        assert mw.futures.popleft().done() == False
    except:
        raise Exception("test 3 failed!")

# Generated at 2022-06-22 05:11:33.975431
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import os
    import time
    from itertools import count
    from threading import Lock

    # counter = count()
    lock = Lock()
    mw = MonoWorker()

    def foo_task(i):
        with lock:
            r = next(counter)
        tqdm_auto.write('{i}: {r}'.format(i=i, r=r))
        time.sleep(0.01)
        with lock:
            r = next(counter)
        return '{i}: {r}'.format(i=i, r=r)

    from threading import Thread
    counter = count()

    n_submits_per_time = 3
    n_submits_per_time_max = 5


# Generated at 2022-06-22 05:11:46.194431
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from traceback import format_exc
    from .tqdm_test_utils import DiscreteFuturesObserver, FakeTQDM

    def raise_error():
        raise ValueError("This is a test exception.")

    def wait_a_bit():
        sleep(0.01)

    def func_A(*args, **kwargs):
        return "A"

    def func_B(*args, **kwargs):
        return "B"

    def func_C(*args, **kwargs):
        return "C"


# Generated at 2022-06-22 05:11:56.915346
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import queue
    import random

    def _submit(mw, task_type, task_id):
        if task_type == 'sleep':
            q.put((task_id, 'start'))
            mw.submit(time.sleep, random.random())
        elif task_type == 'cancel':
            mw.submit(time.sleep, 0.01).cancel()
        elif task_type == 'cancel_waiting':
            mw.submit(lambda: q.put((task_id, 'start')),
                      random.random()).cancel()

    # Test if tasks are executed in the same order as they are submitted
    mw = MonoWorker()
    q = queue.Queue()
    for i in range(10):
        _submit(mw, 'sleep', i)


# Generated at 2022-06-22 05:12:09.984909
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .threads import threadmap
    import threading

    def f(i):
        sleep(1)
        return i * 2

    m = MonoWorker()
    assert len(m.futures) == 0, len(m.futures)

    assert [r.result() for r in threadmap(m.submit, f, range(10))] == \
        list(range(1, 20, 2))
    assert len(m.futures) == 0, len(m.futures)  # only one thread

    assert m.submit(f, 0).result() == 0  # no blocking

    assert [r.result() for r in threadmap(m.submit, f, range(10))] == \
        list(range(1, 20, 2))

# Generated at 2022-06-22 05:12:21.774080
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def print_args(*args, **kwargs):
        time.sleep(3)
        tqdm_auto.write("{}, {}".format(args, kwargs))

    worker = MonoWorker()
    assert worker.submit(print_args, "foo")
    assert worker.submit(print_args, "bar")
    assert worker.submit(print_args, "baz", "baz")
    assert worker.submit(print_args, "baz", "baz", "baz")

    #def assert_exception(func, *args, **kwargs):
    #    try:
    #        func(*args, **kwargs)
    #    except Exception as e:
    #        tqdm_auto.write(str(e))
    #    else:
    #        assert False, "

# Generated at 2022-06-22 05:12:31.271468
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def func():
        time.sleep(0.2)
        return "done"

    test = MonoWorker()
    test_future = test.submit(func)
    time.sleep(0.1)
    test_future2 = test.submit(func)
    test_future2.cancel()
    # test_future2 should be cancelled after 0.1 secs
    assert test_future2.done()
    # test_future should not be cancelled after 0.1 secs
    assert not test_future.done()
    test_future.result()  # should be 'done'


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:12:43.058259
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from queue import Queue

    def delay(n):
        sleep(n)
        return 'done'

    queue = Queue()
    worker = MonoWorker()
    Thread(target=lambda: queue.put(worker.submit(delay, 0.5))).start()
    sleep(0.2)
    res = queue.get()
    assert res.result() == 'done'

    Thread(target=lambda: queue.put(worker.submit(delay, 0.5))).start()
    sleep(0.1)
    res = queue.get()
    assert res.result() == 'done'

    class Exc(Exception):
        pass

    Thread(target=lambda: queue.put(worker.submit(lambda: 1 / 0))).start()

# Generated at 2022-06-22 05:12:51.045006
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys
    import tqdm

    def sleeper(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    futures = []

    for i in range(4):
        for j in tqdm.tqdm(range(2), leave=False):
            futures.append(mw.submit(sleeper, i))

    for future in futures:
        print(future.result(), end=',')

    mw.pool.shutdown(wait=True)

# Generated at 2022-06-22 05:12:59.669089
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import RLock
    from nose.tools import eq_

    m = MonoWorker()

    class Test(object):
        def __init__(self):
            self.lock = RLock()
            self.i, self.j = 0, 0

        def __call__(self):
            sleep(0.025)
            with self.lock:
                self.i += 1

        def __call2__(self):
            sleep(0.025)
            with self.lock:
                self.j += 1

    test = Test()
    m.submit(test)
    m.submit(test)
    m.submit(test)
    m.submit(test)
    m.submit(test)
    m.submit(test)
    m.submit(test)

# Generated at 2022-06-22 05:13:03.941452
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import multiprocessing
    import sys

    def func(i):
        time.sleep(1)
        tqdm_auto.write("{} {}".format(multiprocessing.current_process().name, i))

    worker = MonoWorker()
    for i in range(10):
        worker.submit(func, i)
    worker.pool.shutdown()
    try:
        sys.stdout.flush()
    except Exception:
        pass



# Generated at 2022-06-22 05:13:10.903405
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def test_func(n):
        time.sleep(n)
        return n

    mw = MonoWorker()

    n = 3
    assert n == mw.submit(test_func, n).result()

    n = 2
    assert n == mw.submit(test_func, n).result()

    n = 5
    assert n == mw.submit(test_func, n).result()

    n = 1
    assert n == mw.submit(test_func, n).result()

# Generated at 2022-06-22 05:13:15.844278
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from multiprocessing.dummy import Pool, Queue
    from contextlib import contextmanager

    def _test_pool():
        q = Queue()
        with Pool() as p:
            p.apply(q.put, (1,))
            p.apply(time.sleep, (1,))
            p.apply(q.put, (2,))
            assert q.get() == 1
            assert q.get() == 2

    def _test_monoworker():
        q = Queue()
        mw = MonoWorker()
        mw.submit(q.put, (1,))
        mw.submit(time.sleep, (1,))
        mw.submit(q.put, (2,))
        assert q.get() == 1
        assert q.get() == 2

# Generated at 2022-06-22 05:13:18.949766
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test the MonoWorker class"""
    test = MonoWorker()
    test.submit(range, 1)
    assert len(test.futures) == 1

# Generated at 2022-06-22 05:13:30.289739
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import BoundedSemaphore

    mw = MonoWorker()
    sem = BoundedSemaphore(value=0)
    runs = []

    def func(*args, **kwargs):
        sem.release()
        runs.append((args, kwargs))
        time.sleep(2)

    for i in range(5):
        mw.submit(func, i)
        time.sleep(1)

    # Check that the last one is running
    assert sem.acquire(blocking=False)
    assert sem.acquire(blocking=False) is False

    # Check that the first one is not running
    assert len(runs) == 1
    assert runs[0] == ((4,), {})

    # Cleanup
    sem.release()

# Generated at 2022-06-22 05:13:38.042065
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def dummy_func(duration):
        sleep(duration)

    worker = MonoWorker()

    # First submission
    f1 = worker.submit(dummy_func, 1)
    assert f1.running()
    assert not f1.done()
    assert not f1.cancelled()

    # Second submission, waits for first to be done
    f2 = worker.submit(dummy_func, 2)
    assert not f2.running()
    assert not f2.done()
    assert not f2.cancelled()

    # Wait for first task to be done (but for second to start)
    sleep(1)
    assert f1.done()
    assert not f2.running()
    assert not f2.done()
    assert not f2.cancelled()

    # Wait for

# Generated at 2022-06-22 05:13:46.830783
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-22 05:13:49.784828
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    worker = MonoWorker()
    for i in range(4):
        worker.submit(sleep, i).result()

    try:
        worker.submit(sleep, 1e100).result()
    except Exception as e:
        pass
    else:
        raise Exception("MonoWorker didn't raise exception!")

# Generated at 2022-06-22 05:13:59.496994
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from .queue import Queue
    from .util import ignore_ctrl_c

    def f(q):
        with ignore_ctrl_c():
            while True:
                q.put((time.time(), 1))
                time.sleep(.05)

    q = Queue()
    mw = MonoWorker()
    mw.submit(f, q)
    with ignore_ctrl_c():
        for _ in tqdm_auto.trange(5):
            _, v = q.get()
            q.task_done()
            if v == 1:
                time.sleep(1)
        mw.submit(f, q)
        for _ in tqdm_auto.trange(5):
            _, v = q.get()
            q.task_done()

# Generated at 2022-06-22 05:14:07.336519
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mono = MonoWorker()

    def dummy(x): pass
    mono.submit(dummy, "dummy1")
    mono.submit(dummy, "dummy2")  # should replace waiting task

    def fail(): raise Exception("fail")
    mono.submit(fail)  # should replace waiting task

    def long(x):
        import time
        time.sleep(x)
    mono.submit(long, 1)
    mono.submit(dummy, "dummy4")  # should only keep running task
    mono.submit(dummy, "dummy5")  # should only keep running task
    pass

# Generated at 2022-06-22 05:14:08.520680
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker"""
    assert isinstance(MonoWorker(), MonoWorker)


# Generated at 2022-06-22 05:14:17.661133
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()
    f1 = mw.submit(time.sleep, 0.2)
    assert not f1.done()
    f2 = mw.submit(time.sleep, 0.3)
    assert not f2.done()
    if __name__ != '__main__':
        assert not f1.done()  # cancelled
    assert f2.done()  # executed on time


if __name__ == '__main__':
    import nose
    nose.runmodule(argv=[__file__, '--verbosity=2'])

# Generated at 2022-06-22 05:14:27.780598
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f():
        time.sleep(2)
        return 1

    # Setup test
    mw = tqdm.contrib.MonoWorker()
    assert len(mw.futures) == 0

    # Execute submit
    mw.submit(f)
    assert len(mw.futures) == 1

    mw.submit(f)
    assert len(mw.futures) == 1

    time.sleep(1)
    mw.submit(f)
    assert len(mw.futures) == 1

    time.sleep(2)
    assert mw.futures[0].result() == 1
    assert len(mw.futures) == 1

    mw.submit(f)

# Generated at 2022-06-22 05:14:30.023679
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test instantiation of MonoWorker."""
    MonoWorker()


# Generated at 2022-06-22 05:14:46.848246
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    test = MonoWorker()
    test.submit("print(1 + 1)")
    test.submit("print(12 * 123)")
    test.submit("print(1 / 0)  # will be discarded")
    test.submit("print(3 - 3)  # will replace above running task")
    # test.submit("print(12 * 123)  # will be discarded")
    test.submit("print(1 // 0)")  # will replace above waiting task


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:14:49.437227
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.pool._max_workers == 1
    assert mw.futures.maxlen == 2


# Generated at 2022-06-22 05:15:00.098396
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(x, delay=0):
        time.sleep(delay)
        return x**2

    mw = MonoWorker()
    mw.submit(f, 3, delay=2)
    print(mw.submit(f, 1, delay=1).result())
    print(mw.submit(f, 2, delay=1).result())
    print(mw.submit(f, 3, delay=2).result())
    print(mw.submit(f, 4, delay=1).result())
    print(mw.submit(f, 5, delay=1).result())
    print(mw.futures)


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:15:11.344242
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test that `MonoWorker.submit` is working."""
    from unittest import main
    try:
        from unittest.mock import patch
    except ImportError:  # Python 2
        from mock import patch

    class Counter:
        def __init__(self):
            self.count = 0

        def __call__(self):
            prev_count = self.count
            self.count += 1
            return prev_count

    class TestMonoWorker(object):
        """Test class for MonoWorker."""
        def setUp(self):
            """Test setup."""
            self.counter = Counter()
            self.mw = MonoWorker()

        def test_submit(self):
            """Test to check if `submit` is working."""
            # Create a mock for `ThreadPoolExecutor.

# Generated at 2022-06-22 05:15:21.225654
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=too-many-locals
    import time
    import threading
    import queue
    import concurrent.futures
    from subprocess import check_call

    if not (hasattr(concurrent.futures, 'ProcessPoolExecutor')
            and hasattr(time, 'perf_counter')):         # pragma: no cover
        return

    def sleep_func(dur):
        def func():
            time.perf_counter()
            time.sleep(dur)
            time.perf_counter()
        return func

    # pylint: disable=too-many-nested-blocks, too-many-statements

# Generated at 2022-06-22 05:15:28.420191
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(x):
        import time
        time.sleep(0.5)
        return x

    from time import time
    from random import randint
    start = time()
    x = 5
    mono_worker = MonoWorker()
    for i in range(10):
        mono_worker.submit(f, i)
        assert mono_worker.futures[0].result() == i
    assert time() - start < 5

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:15:37.932462
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing import cpu_count
    import time

    def f(x):
        time.sleep(x)
        return x

    nthreads = cpu_count()
    test_results = []
    for n in range(nthreads):
        with MonoWorker() as m:
            m.submit(f, 1)
            m.submit(f, 3)
            test_results.append(m.futures.pop().result())
        assert test_results[-1] == 3, "last result should be 3 but was %r" % test_results
    assert m.pool.shutdown(wait=False)
    assert n + 1 == nthreads, "should execute %d times but was %d times" % (nthreads, n + 1)
    assert sum(test_results) == 3 * nthreads

# Generated at 2022-06-22 05:15:49.204992
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from subprocess import Popen, PIPE
    from tqdm import trange
    from threading import Lock
    from functools import partial

    mw = MonoWorker()
    lock = Lock()
    sleep_fn = partial(sleep, 1e-3)  # to prevent optimisation

    def _print_lines(fp, desc=''):
        for line in iter(fp.readline, ''):
            tqdm_auto.write('%s %s' % (desc, line))
        with lock:
            tqdm_auto.write('%s -- done' % desc)

    with open('/dev/null', 'w') as devnull:
        for _ in trange(50):
            # cmd = 'echo %d' % _
            cmd = 'tree -L 3'


# Generated at 2022-06-22 05:16:01.312960
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import threading
    import time
    M = MonoWorker()

    def seed():
        time.sleep(0.1)
        return "Hello"

    def noop():
        time.sleep(0.1)
        return None

    def raise_():
        time.sleep(0.1)
        raise Exception("Hi")

    def echo():
        time.sleep(0.1)
        return "World"

    def noexcept():
        time.sleep(0.1)
        return "Success"

    f0 = M.submit(seed)
    f1 = M.submit(noop)
    assert f0 is not f1
    f2 = M.submit(raise_)
    f3 = M.submit(echo)  # current worker is busy (f2 running + f3 waiting)

# Generated at 2022-06-22 05:16:06.693670
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    SLEEP = 0.01

    def first_task():
        sleep(SLEEP * 3)
        return 1
    def second_task():
        sleep(SLEEP)
        return 2

    worker = MonoWorker()
    result1 = worker.submit(first_task)
    sleep(SLEEP)
    assert len(worker.futures) == 1
    result2 = worker.submit(second_task)
    assert result2.result() == 2
    assert result1.result() == 1
    assert len(worker.futures) == 0
    tqdm_auto.write('Tests passed')

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-22 05:16:38.068213
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading

    def assert_(val, msg="Assertion failed"):
        if not val:
            raise AssertionError(msg)

    def test_timeout(seconds):
        """mono_worker timeout"""
        def foo():
            time.sleep(seconds)
            assert_(False, "timeout exceeded")
        mono_worker.submit(foo)
        mono_worker.submit(foo)

    def test_kill_waiting_task():
        """mono_worker kill waiting task"""
        def foo_running():
            time.sleep(0.1)

        def foo_waiting():
            time.sleep(0.1)
            assert_(False, "waiting task not cancelled")

        def foo_killed():
            time.sleep(0.1)
            assert_(False, "killed task executed")

# Generated at 2022-06-22 05:16:49.737989
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .misc import sleep
    from multiprocessing import Process
    import os, sys, io
    import re

    def get_txt(monow):
        c = 0
        while True:
            sleep(0.01)
            s = 'txt:%s' % (c,)
            c += 1
            if c > 2:
                raise ValueError(s)
            yield s

    def main():
        if os.explicit_getegid() is None:  # if not running as root user
            monow = MonoWorker()
            p = Process(target=run, args=(monow,))
            p.start()
            p.join()
        else:
            print("WARNING: You are running this test as root. "
                  "This will likely fail.\n")
            run()

    global output
    output

# Generated at 2022-06-22 05:16:52.953179
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from random import random

    mono = MonoWorker()
    for i in tqdm_auto(range(10)):
        # Note: no try-except clause
        mono.submit(time.sleep, random())


# Generated at 2022-06-22 05:17:01.535942
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    from time import sleep
    from random import random
    from .utils import seconds_to_str
    from .iter import join

    def rand_sleep(tmin=0.0, tmax=1.0, seed=None):
        """
        Return a random sleep function that sleeps for a random time in
        seconds between `tmin` and `tmax`.

        Parameters
        ----------
        tmin  : float, optional
            Min sleep time (default: 0.0)
        tmax  : float, optional
            Max sleep time (default: 1.0)
        seed  : int, optional
            Random seed (default: None)

        Returns
        -------
        func  : function
            Random sleep function ready to be submitted to thread workers.
        """

# Generated at 2022-06-22 05:17:06.961835
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import gc
    from threading import current_thread
    from queue import Queue
    from multiprocessing import Manager

    def runner():
        sleep(0.02)
        return current_thread().ident

    def tester(collector):
        for i in tqdm_auto.trange(10, desc="worker"):
            collector.append(worker.submit(runner))
        sleep(0.01)
        return collector

    manager = Manager()
    collector = manager.list()
    worker = MonoWorker()
    collector = tester(collector)
    p = tester(collector)
    t = tester(collector)
    while p.running() or t.running():
        pass
    assert len(collector) == 30

# Generated at 2022-06-22 05:17:17.451556
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    w = MonoWorker()

    def dummy(i):
        sleep(0.1)
        return i

    # Submit one task
    f = w.submit(dummy, 0)
    assert f.result() == f.result()  # Can be called multiple times
    assert len(w.pool._threads._threads) == 1

    # Submit second task
    g = w.submit(dummy, 1)
    assert f.done()
    assert g.result() == g.result()
    assert not f.done()
    assert f.result()[0] == 0  # Old task still gives results

    # Submit third task (replaces second task)
    h = w.submit(dummy, 2)
    assert len(w.pool._threads._threads) == 1  # Only one thread

# Generated at 2022-06-22 05:17:26.099599
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Event

    def foo(i, e):
        e.wait()
        return i

    # create objects
    ret = []
    e = Event()
    wk = MonoWorker()

    # submit several tasks
    for i in range(5):
        ret.append(wk.submit(foo, i, e))

    # start tasks
    e.set()

    # wait for tasks to finish
    while len(ret):
        r = ret.pop()
        assert r.result() == len(ret)

    # same but with multiple tasks doing wait at once
    e.clear()
    ret = [wk.submit(foo, i, e) for i in range(3)]
    time.sleep(0.1)  # wait for all tasks to enter the waiting state
    e.set()


# Generated at 2022-06-22 05:17:31.486431
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def f(n):
        time.sleep(n)
        return n

    try:
        MonoWorker()
    except Exception as e:
        print(e)
        raise AssertionError("MonoWorker() failed")

    mw = MonoWorker()
    for i in range(1, 4):
        assert mw.submit(f, i) is not None, str(i)
    time.sleep(1)
    assert mw.submit(f, 4) is not None, "4"
    time.sleep(2)
    assert mw.submit(f, 5) is not None, "5"
    time.sleep(1)
    assert mw.submit(f, 6) is not None, "6"
    time.sleep(1)

# Generated at 2022-06-22 05:17:40.405346
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def my_func(a, b=None):
        return a + b

    worker = MonoWorker()
    assert worker.submit(my_func, 1, 2) is None
    assert worker.submit(my_func, 2, 1) is None
    assert worker.submit(my_func, 1, 2) is None
    assert worker.submit(my_func, 3, 3) is None
    assert worker.submit(my_func, 4, 2) is None
    assert worker.submit(my_func, 5, 4) is None
    assert worker.submit(my_func, 1) is None
    assert worker.submit(my_func, 2) is None
    assert worker.submit(my_func, 1) is None
    assert worker.submit(my_func, 3) is None

# Generated at 2022-06-22 05:17:51.975021
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .utils import ThreadWithReturnValue
    from ..utils import _decode

    def sleep_and_print(time):
        import time as t
        t.sleep(time)
        return time

    mw = MonoWorker()

    thread1 = ThreadWithReturnValue(target=sleep_and_print, args=(0.5,))
    thread1.start()
    future1 = mw.submit(thread1.join)
    thread2 = ThreadWithReturnValue(target=sleep_and_print, args=(1.5,))
    thread2.start()
    future2 = mw.submit(thread2.join)
    thread3 = ThreadWithReturnValue(target=sleep_and_print, args=(2.5,))
    thread3.start()
    future3 = mw.submit(thread3.join)

   

# Generated at 2022-06-22 05:18:46.917192
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import randint
    import sys
    import os

    def f(x):
        """Sleep (x) seconds and print."""
        sleep(x)
        sys.stdout.write(str(x))
        sys.stdout.flush()

    f0 = f('0')
    sleep(.1)
    assert not f0.done()
    assert not f0.cancelled()
    mw = MonoWorker()
    f1 = mw.submit(f, 1)
    f2 = mw.submit(f, 2)
    assert f2 == f1

    sleep(2.2)  # give time for the 2 futures to "catch up"
    assert f1.done()
    assert f2.done()
    assert not f1.cancelled()

# Generated at 2022-06-22 05:18:52.691022
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import time
    from time import sleep
    from threading import Lock

    mw = MonoWorker()

    def run_func(mt, i, duration, lock=None):
        sleep(duration)
        assert mt.submit(run_func, mt, i + 1, duration).result() == i + 2
        with lock:
            mt.append(i)

    mt = []
    lock = Lock()
    t0 = time()
    assert mw.submit(run_func, mt, 1, 2, lock=lock).result() == 2
    assert run_func(mt, 1, 2, lock=lock) == 2
    assert time() - t0 < 3, "cmd1 should be queued behind cmd2 and finished."

# Generated at 2022-06-22 05:19:02.180005
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import logging
    import threading
    from unittest import TestCase

    logging.basicConfig(level=logging.INFO)
    logging.info("thread id %s" % threading.current_thread().ident)

    def operate(sleep_time):
        for i in tqdm_auto.tqdm(range(100), desc="operate"):
            time.sleep(sleep_time)
        return sleep_time

    def submit(worker, sleep_time):
        f = worker.submit(operate, sleep_time)
        logging.info("submit %s" % sleep_time)
        return f

    class MonoWorkerTest(TestCase):
        def test_submit(self):
            # Set up thread
            worker = MonoWorker()
            sleep_time = 0.1

# Generated at 2022-06-22 05:19:13.436446
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import Timer
    from ..utils import format_sizeof
    from ..utils import chunkize
    import multiprocessing

    def count_upwards(n=1000 ** 2):
        m = 0
        for i in range(n):
            m += i
        return m

    def count_downwards(n=1000 ** 2):
        m = 0
        for i in range(n):
            m -= i
        return m

    def do_nothing(n=1000 ** 2):
        pass

    def chunked_do_nothing(n=1000 ** 2):
        for _ in chunkize(range(n)):
            pass

    def loop(func, n):
        """To observe overheads"""
        func(n)
