

# Generated at 2022-06-22 05:09:21.321741
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def deque_len(deque):
        return len(deque) if deque else -1

    def deque_count(deque, val):
        return deque.count(val) if deque else -1

    from contextlib import contextmanager

    @contextmanager
    def timethis(name):
        t0 = time.time()
        yield
        print('%s: %.3f s' % (name, time.time() - t0))

    def func(value):
        time.sleep(0.5)
        return value

    mw = MonoWorker()
    print("Init deque:", mw.futures, deque_len(mw.futures),
          deque_count(mw.futures, None))


# Generated at 2022-06-22 05:09:22.823780
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert MonoWorker().pool._max_workers == 1

# Generated at 2022-06-22 05:09:24.711596
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Check if the constructor of MonoWorker class instantiates the class
    with no error.
    """
    MonoWorker()

# Generated at 2022-06-22 05:09:36.278205
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Test for expected behavior for arguments set to threads
    import time

    def func1(*args):
        time.sleep(args[0])
        return args[0]

    def func2(*args):
        time.sleep(args[0] * 10)
        return 2 * args[0]

    def func3(*args):
        time.sleep(args[0] * 100)
        return 3 * args[0]

    test1 = MonoWorker()

    start_time = time.time()
    test1.submit(func1, 2)
    test1.submit(func2, 2)
    test1.submit(func3, 2)
    while not test1.futures[0].done() or not test1.futures[1].done():
        time.sleep(0.01)

# Generated at 2022-06-22 05:09:46.154442
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=missing-docstring
    def func(i):
        tqdm_auto.write("running %d" % i)
        tqdm_auto.sleep(1)
        return i

    mono = MonoWorker()
    assert mono.futures == deque()
    f1 = mono.submit(func, 123)
    tqdm_auto.sleep(0.1)
    assert mono.futures == deque([f1])
    f1.result()
    assert mono.futures == deque()
    f2 = mono.submit(func, 123)
    tqdm_auto.sleep(0.1)
    assert mono.futures == deque([f2])
    f2.result()
    assert mono.futures == deque()

# Generated at 2022-06-22 05:09:57.428853
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import time, sleep
    from math import factorial
    from itertools import chain
    from heapq import nlargest

    MonoWorker_obj = MonoWorker()

    def test_factorial(n, sleep_sec=0, cancel=0):
        if cancel and n == cancel:
            raise Exception('cancel')
        sleep(sleep_sec)
        return factorial(n)

    times = []
    NUM_RUNS = 10
    CANCEL = 0
    REPEAT = 3
    tqdm_auto.write('testing {} jobs, {} repeats, cancel={}'.format(
        NUM_RUNS, REPEAT, CANCEL))

    for repeat in range(REPEAT):
        for n in range(NUM_RUNS):
            # submit asynchronously
            t0 = time

# Generated at 2022-06-22 05:10:05.824306
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()
    assert len(m.futures) == 0
    assert m.submit() is None

    def dummy_func():
        return 0
    f = m.submit(dummy_func)
    assert f is not None
    f.result()
    assert len(m.futures) == 1

    f = m.submit(dummy_func)
    assert f is not None
    f.result()
    assert len(m.futures) == 2

# Generated at 2022-06-22 05:10:07.385702
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """MonoWorker constructor test"""
    MonoWorker()

# Generated at 2022-06-22 05:10:15.602830
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import time

    def printer(tm):
        time.sleep(tm)
        print("{}s task done.".format(tm))

    # test success
    wk = MonoWorker()
    wk.submit(printer, 2)
    wk.submit(printer, 3)
    wk.submit(printer, 4)
    wk.submit(printer, 5)
    wk.submit(printer, 6)
    wk.submit(printer, 7)
    # test failure
    wk.submit(printer, 8)
    wk.submit(printer, 9)
    wk.submit(printer, 10)



# Generated at 2022-06-22 05:10:17.431836
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def test_constructor():
        MonoWorker()
    test_constructor()


# Generated at 2022-06-22 05:10:22.700895
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    pass


# Generated at 2022-06-22 05:10:30.048927
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    mw = MonoWorker()

    output = ""
    lock = threading.Lock()

    def write(s):
        global output
        lock.acquire()
        output += s
        lock.release()

    def worker(c):
        tqdm_auto.write("start {}".format(c))
        time.sleep(0.1 * (ord(c) - ord("A")))
        write("{}".format(c))
        tqdm_auto.write("finish {}".format(c))

    for i in range(5):
        for c in "ABCDE":
            mw.submit(worker, c)

    for i in range(3):
        time.sleep(1.1)
        write("{}".format(i))
        tqdm_

# Generated at 2022-06-22 05:10:37.593817
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    worker = MonoWorker()
    for i in range(2):
        assert len(worker.futures) == i
        worker.submit(time.sleep, i * 10)  # sleep should never fail
    assert len(worker.futures) == 1
    assert worker.futures[0].result() == 0
    assert len(worker.futures) == 1
    assert worker.submit(time.sleep, 10) is None  # sleep should never fail
    assert len(worker.futures) == 1
    assert worker.futures[0].result() == 10

# Generated at 2022-06-22 05:10:45.712341
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from queue import Queue
    MonoWorker = MonoWorker

    def slow_func_generator(limit, sleep_time, sleep_variance=0.3,
                            blocking_time=1):
        def rng():
            return 2 * sleep_variance * (tqdm_auto.random() - 0.5)

        def slow_func(i):
            time.sleep(sleep_time + rng())
            if i % 2:
                time.sleep(blocking_time + rng())
            return i
        for i in range(limit):
            yield slow_func, i
    limit = 10
    sleep_time = 0.5
    blocking_time = 1
    log = list()
    q = Queue()  # to receive results


# Generated at 2022-06-22 05:10:55.984957
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()
    # test task 2 takes longer than task 3
    time.sleep(0.01)
    f1 = mw.submit(time.sleep, 0.1)
    time.sleep(0.01)
    f2 = mw.submit(time.sleep, 0.2)
    time.sleep(0.01)
    f3 = mw.submit(time.sleep, 0.3)
    # test task 4 is queued and task 3 is discarded
    f4 = mw.submit(time.sleep, 0.4)
    # test task 5 is queued and task 4 is discarded
    f5 = mw.submit(time.sleep, 0.5)
    time.sleep(0.01)
    mw.pool.shutdown(wait=True)
    assert f

# Generated at 2022-06-22 05:11:06.071218
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from timeit import default_timer as timer
    from concurrent.futures import ThreadPoolExecutor
    from ..utils import test_env
    from ..utils import _range
    from .test_dataset import sleep_interruptibly

    assert test_env.get_test_env(False)
    with ThreadPoolExecutor(max_workers=2) as pool:
        def monitor():
            with tqdm_auto.tqdm(total=10) as monitor:
                for i in _range(10):
                    sleep_interruptibly(0.1)
                    monitor.update(1)

        m = MonoWorker()
        start = timer()
        m.submit(monitor)
        # no-op
        m.submit(monitor)
        m.submit(monitor)
        m.futures

# Generated at 2022-06-22 05:11:14.176166
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=missing-docstring
    import datetime
    import time
    import sys

    def slowpoke():
        time.sleep(1)
        return datetime.datetime.now()

    mono = MonoWorker()
    start = time.time()
    tasks = range(10)
    outputs = []
    for i in tasks:
        f = mono.submit(slowpoke)
        outputs.append(f.result())

    for i, output in enumerate(outputs):
        print('task #%d started at %s' % (i, output))
    end = time.time()
    print('total duration: %s' % (end - start))

    assert end - start < 15
    print('MonoWorker submit test passed')


# Generated at 2022-06-22 05:11:25.385728
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures
    import sys
    import os

    # ------------------------
    # setup

    mw = MonoWorker()
    sys.stdout.flush()
    os.system("echo -n > out.txt")
    os.system("echo -n > err.txt")

    # ------------------------
    # submit functions
    def func1():
        time.sleep(1)
        tqdm_auto.write("1")

    def func2():
        time.sleep(2)
        tqdm_auto.write("2")

    def func3():
        time.sleep(3)
        raise Exception("3")

    def func4():
        time.sleep(4)
        raise Exception("4")

    def func5():
        time.sleep(5)
        raise Exception("5")

# Generated at 2022-06-22 05:11:35.963054
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    print("Testing method submit of class MonoWorker:")

    import time

    def wait_n_seconds(n):
        time.sleep(n)
        return n

    # Prepare test parameters
    delays = [0.5, 0.3, 0.1]
    expected_delays = [0.5, 0.5, 0.5]

    # Create the object under test
    monoworker = MonoWorker()

    # Test run function
    for i in range(len(delays)):
        monoworker.submit(wait_n_seconds, delays[i])

    print("Waiting...")
    for i in range(len(delays)):
        delay = monoworker.futures[i].result()
        print("Delay {} = {}".format(i, delay))

# Generated at 2022-06-22 05:11:47.449171
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from concurrent.futures import TimeoutError
    from ..utils import format_sizeof, format_interval
    from ..utils import logging as logging_mod
    from .statistics import statsd_client as statsd
    from .statistics import statsd_server
    from .statistics.metering import Meter

    duration = 3  # seconds
    class StopableThreadPoolExecutor(ThreadPoolExecutor):
        def __init__(self, *args, **kwargs):
            self._stop_event = threading.Event()
            super(StopableThreadPoolExecutor, self).__init__(*args, **kwargs)


# Generated at 2022-06-22 05:11:52.202038
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert len(mw.futures) == 0
    assert mw.pool._max_workers == 1

# Generated at 2022-06-22 05:12:03.357223
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    import time
    import threading
    mw = MonoWorker()
    tqdm_auto.tqdm.write('Start')
    f = mw.submit(time.sleep, 1)
    tqdm_auto.tqdm.write('Submit')
    tqdm_auto.tqdm.write('Join')
    f.result()
    tqdm_auto.tqdm.write('Done')
    tqdm_auto.tqdm.write('Start')
    f = mw.submit(time.sleep, 1)
    tqdm_auto.tqdm.write('Submit')
    tqdm_auto.tqdm.write('Join')
    f.result()

# Generated at 2022-06-22 05:12:14.406031
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import RLock
    from time import sleep

    class PrintFunc(object):
        def __init__(self, step=0.2, tqdm_pos=0, lock=None):
            self.step = step
            self.tqdm_pos = tqdm_pos
            self.lock = lock

        def __call__(self, x):
            if self.lock is not None:
                with self.lock:
                    tqdm_auto.tqdm.write(x)
            else:
                tqdm_auto.tqdm.write(x)
            sleep(self.step)
            return x


# Generated at 2022-06-22 05:12:25.430666
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from tqdm._utils import _term_move_up

    def f(x):
        time.sleep(x)
        return x

    worker = MonoWorker()
    for i in range(5):
        worker.submit(f, i)

    for i in range(4):
        time.sleep(0.01 + i)
        tqdm_auto.write('{}'.format(i))

    with tqdm_auto.external_write_mode():
        print('{}'.format(''))
        print('{}'.format(''))
        print('{}'.format('-----'))
    #     tqdm_auto.write('{}'.format(i))
    #     tqdm_auto.write('{}'.format('====='))
    #     tqdm_auto

# Generated at 2022-06-22 05:12:36.764485
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random, time, threading

    def nonzero():
        """returns random non-zero number"""
        s = 1
        while not s:
            s = random.randrange(-1, 1)
        return s

    def worker(func, *args, **kwargs):
        """returns func(*args, **kwargs)"""
        return func(*args, **kwargs)

    def func1(*args, **kwargs):
        time.sleep(nonzero())
        return 1
    def func2(*args, **kwargs):
        time.sleep(nonzero())
        return 2

    n = 10

    mw = MonoWorker()

    def test_order(func1, func2):
        result_list = []
        for _ in range(n):
            f1 = func1()

# Generated at 2022-06-22 05:12:46.833519
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    m = MonoWorker()
    m.submit(time.sleep, 1)
    time.sleep(1)
    assert len(m.futures) == 0

    m = MonoWorker()
    m.submit(time.sleep, 1)
    time.sleep(0.5)
    m.submit(time.sleep, 1)
    time.sleep(1)
    assert len(m.futures) == 0

    m = MonoWorker()
    m.submit(time.sleep, 1)
    time.sleep(0.5)
    m.submit(time.sleep, 1)
    time.sleep(0.5)
    m.submit(time.sleep, 1)
    time.sleep(0.5)
    assert len(m.futures) == 2

# Generated at 2022-06-22 05:12:56.424180
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-22 05:13:03.573806
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Thread
    from contextlib import closing
    def foo(x):
        sleep(x)
        if x == 2:
            raise ValueError("x == 2")
        return -x
    with closing(MonoWorker()) as m:
        assert len(m.futures) == 0
        assert m.submit(foo, 0.01)
        assert len(m.futures) == 1
        assert m.submit(foo, 0.03)
        assert len(m.futures) == 1
        assert m.futures[0].result() == -0.01
        assert m.submit(foo, 0.01)
        assert len(m.futures) == 1
        assert m.futures[0].result() == -0.01

# Generated at 2022-06-22 05:13:11.488138
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test MonoWorker constructor."""
    try:
        import types  # Python 2
    except ImportError:
        import _types as types
    worker = MonoWorker()
    try:
        import concurrent.futures  # Python 3
    except ImportError:
        import futures as concurrent_futures
    try:
        assert isinstance(worker.pool,
                          concurrent_futures.thread.ThreadPoolExecutor)
        assert isinstance(worker.futures, types.DequeType)
        assert worker.futures.maxlen == 2
    except AttributeError:
        pass

# Generated at 2022-06-22 05:13:21.719956
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import itertools
    from threading import Semaphore, Thread
    from concurrent.futures import TimeoutError
    from ..utils import format_sizeof

    pool = MonoWorker()
    semaphore = Semaphore(0)

    def worker(index):
        semaphore.acquire()
        try:
            time.sleep(0.5)
        except:
            pass
        semaphore.release()

    for i in tqdm_auto.tqdm(
            itertools.count(),
            total=10,
            miniters=1,
            mininterval=0,
            desc='test_MonoWorker_submit'
    ):
        Thread(target=worker, args=(i,)).start()

# Generated at 2022-06-22 05:13:37.746749
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from multiprocessing import cpu_count
    from itertools import repeat

    def f(l, e, i):
        sleep(l)
        e.wait()
        return i
    l = [0.1, 0.1, 1, 1, 1]
    mw = MonoWorker()
    e = Event()
    e.set()
    try:
        for i in tqdm_auto(l):
            e.clear()
            mw.submit(f, i, e, i)
            sleep(0.1)
            e.set()
    except (KeyboardInterrupt, SystemExit):
        e.set()
        raise

    def f2(i):
        sleep(0.1)
        return i


# Generated at 2022-06-22 05:13:46.794905
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import concurrent.futures
    import itertools

    def echo(s):
        time.sleep(1)
        return s

    mw = MonoWorker()

    futs = [mw.submit(echo, i) for i in itertools.count()]

    assert futs[0] == mw.futures[0]
    assert len(mw.futures) == 1

    futs[1].cancel()
    time.sleep(0.1)
    assert futs[1] not in mw.futures
    assert len(mw.futures) == 1
    assert mw.futures[0] == futs[0]

    futs[2].result()
    assert futs[2] == mw.futures[0]
   

# Generated at 2022-06-22 05:13:47.461361
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert MonoWorker().submit

# Generated at 2022-06-22 05:13:57.405718
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    def check_submit(mworker, delay, exception=None):
        def _test_check_submit(mworker, exception):
            func = _test_check_submit
            func.count += 1
            func.result = ['running']
            func.mworker = mworker
            func.exception = exception
            try:
                time.sleep(func.count * delay)
            except Exception as e:
                func.result.append(str(e))
            else:
                func.result.append('waiting')
            if exception:
                raise func.exception
            return func.result

        _test_check_submit.count = 0
        _test_check_submit.result = []
        _test_check_submit.exception = exception
        _test_check_submit.mworker = m

# Generated at 2022-06-22 05:14:07.497723
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from concurrent.futures import Future
    class Future(Future):
        def __init__(self, *args, **kwargs):
            self._fin, self._time = kwargs.pop('fin', None), None
            super().__init__(*args, **kwargs)

        def set_running_or_notify_cancel(self):
            self._time = time.time()
            super().set_running_or_notify_cancel()

        def done(self):
            return self._fin or super().done()

        def cancel(self):
            if not self._fin:
                self._fin = True
            return super().cancel()

        def result(self, timeout=None):
            if self._fin:
                return self._time
            else:
                return super().result(timeout)

# Generated at 2022-06-22 05:14:18.749942
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    from threading import Event
    from tqdm.auto import tqdm
    from tqdm.contrib import MonoWorker

    class EventThread(threading.Thread):
        def __init__(self):
            super(EventThread, self).__init__()
            self.event = Event()

        def run(self):
            """Set the flag in an infinite loop"""
            while True:
                self.event.wait()
                time.sleep(1)
                self.event.clear()

    t = EventThread()
    t.start()

    def set_event(e):
        time.sleep(3 * random.random())
        e.set()

    # takes a lot of time
    m = MonoWorker()

# Generated at 2022-06-22 05:14:28.694900
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import sys
    import time

    def test_func(x):
        time.sleep(x)
        return x

    # Test classical case
    with MonoWorker() as mono:
        mono.submit(test_func, 1).result()
        mono.submit(test_func, 2).result()
        mono.submit(test_func, 3).result()
        mono.submit(test_func, 4).result()

    # Test with error during a future
    with MonoWorker() as mono:
        f1 = mono.submit(test_func, 2)
        f2 = mono.submit(test_func, 1)
        # At this point the thread is busy with f2, so the
        # following should clear f1 and replace it with f3
        time.sleep(0.5)  # wait for f2 to start
       

# Generated at 2022-06-22 05:14:37.506562
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Thread
    from queue import Queue, Empty

    def monitor(monitored, queue):
        for i in tqdm_auto(iterable=range(5),
                           desc='Monitoring [{}/5]'.format(len(monitored)),
                           total=5, unit='μs'):
            queue.put(monitored.popleft())
            time.sleep(1e-6)

    def f(queue, i):
        queue.put(i)
        time.sleep(1e-6)
        queue.put(i)

    monitored = deque()
    queue = Queue()
    mono_worker = MonoWorker()
    monitor_thread = Thread(target=monitor, args=(monitored, queue))
    monitor_thread.start()

# Generated at 2022-06-22 05:14:43.444835
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    t = MonoWorker()
    result = {'x': -1}

    class O:
        def get_result(self):
            return result['x']

        def square(self, x):
            result['x'] = x ** 2
            time.sleep(0.5)
            return x ** 2

        def sqroot(self, x):
            result['x'] = x ** 0.5
            return x ** 0.5

    o = O()

    # run two tasks at the same time
    for i in tqdm_auto.tqdm(range(10)):
        t.submit(o.square, i)

    # get result
    print(o.get_result())

    # test that calling sqroot only works if square is already done

# Generated at 2022-06-22 05:14:52.826753
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()

    def my_func(dur):
        time.sleep(dur)

    f1 = mw.submit(my_func, 1)
    time.sleep(0.05)
    f2 = mw.submit(my_func, 2)
    time.sleep(0.05)
    f3 = mw.submit(my_func, 3)

    assert f1.done()
    assert not f2.done()
    assert len(mw.futures) == 1
    f2.result()
    assert f2.done()

    try:
        f3.result()
    except Exception:
        pass
    assert f3.done()
    assert len(mw.futures) == 1

# Generated at 2022-06-22 05:15:09.032329
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert len(worker.futures) == 0

# Generated at 2022-06-22 05:15:17.329602
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from concurrent.futures import wait
    import tqdm.contrib.concurrency as tc
    import random

    tqdm_auto.write("testing MonoWorker:")
    mw = tc.MonoWorker()
    def busy_task(_):
        sleep(random.random())
        tqdm_auto.write("busy_task")
    mw.submit(busy_task, None)
    wait([mw.submit(busy_task, None)])
    mw.pool.shutdown()

# Generated at 2022-06-22 05:15:29.342790
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from sys import stderr
    from .tqdm import tqdm
    from .util import is_main_thread

    def myprint(s):
        sleep(0.01)
        tqdm.write('\r' + s, file=stderr)

    myprint('Begin test')
    mono = MonoWorker()

    # Test: mono.submit(myprint, 'Hello')
    myprint('Test mono.submit(myprint, "Hello")')
    assert is_main_thread()
    f = mono.submit(myprint, 'Hello')
    result = f.result()
    assert result is None
    assert f.done()  # Can get result
    myprint('End test\n')

    # Test: mono.submit(myprint, 'Hello').submit(myprint, '

# Generated at 2022-06-22 05:15:39.959284
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from concurrent.futures import TimeoutError
    from ..utils import _range

    mw = MonoWorker()

    def wait_for_result(f, timeout=0.5):
        try:
            return f.result(timeout=timeout)
        except TimeoutError as e:
            return str(e)

    def work(x):
        time.sleep(0.25)
        return x * 2

    def make_work(x):
        def w():
            return work(x)
        return w

    f = mw.submit(work, 9)
    assert wait_for_result(f) == 18

    for x in _range(10):
        mw.submit(make_work(x))


# Generated at 2022-06-22 05:15:51.096938
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import math
    import time
    import sys

    def func(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    t = time.time()
    # Run one long and one short task
    f = mw.submit(func, 3)
    assert f.result() == 3
    # Short task replaces long task and returns immediately
    f = mw.submit(func, 1)
    assert f.result() == 1
    delta = time.time() - t
    assert delta < 1.5

    # Run one long and two short tasks
    # (One short task per thread: short and long tasks will overlap)
    t = time.time()
    g = mw.submit(func, 5)
    f = mw.submit(func, 1)  # replaces g
    assert f

# Generated at 2022-06-22 05:16:02.171700
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import threading, time
    # Tests for task limit
    def task(i, t):
        time.sleep(t)
    worker = MonoWorker()

    # Too many tasks
    for i in range(MonoWorker.task_limit + 1):
        worker.submit(task, i, 1)
        time.sleep(0.1)
    assert len(worker.futures) == MonoWorker.task_limit

    # Too many tasks kept
    worker = MonoWorker()
    for i in range(MonoWorker.task_limit):
        worker.submit(task, i, 1)
    time.sleep(0.1)
    for i in range(MonoWorker.task_limit):
        worker.submit(task, i, 1)
    assert len(worker.futures) == MonoWorker

# Generated at 2022-06-22 05:16:14.031504
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def wait(t):
        import time
        time.sleep(t)
        return t

    mw = MonoWorker()

    f1 = mw.submit(wait, 10)
    assert not f1.done()
    assert mw.futures[0] is f1
    
    # f4 replaces f1 before f1 completes
    f4 = mw.submit(wait, 20)
    assert not f4.done()
    assert mw.futures[0] is f4
    assert mw.futures[1] is f1

    f3 = mw.submit(wait, 15)
    # f3 is not submitted, since f1 is running
    assert f3 is None
    assert mw.futures[0] is f4

# Generated at 2022-06-22 05:16:25.366260
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # type: () -> None
    """Unit test for constructor of class MonoWorker"""
    from multiprocessing import Lock, Process

    # Test simple (serial) constructor with exception
    def f():
        raise Exception

    m = MonoWorker()
    with tqdm_auto.tqdm(1) as t:
        t.write("Testing MonoWorker constructor with exception")
        m.submit(f)
        m.futures[0].result()
        t.update()

    # Test simple (serial) constructor with a single process
    def f(lock):
        from random import random
        from time import sleep
        with lock:
            sleep(0.5 * random())
            return 1

    m = MonoWorker()
    with tqdm_auto.tqdm(1) as t:
        t.write

# Generated at 2022-06-22 05:16:36.755412
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import os
    import random
    from threading import Thread
    from concurrent.futures import ThreadPoolExecutor
    from .tqdm import tqdm

    class FutureQueue(object):
        """Simulate futures.Queue, limited to `n` futures"""
        def __init__(self, n):
            self.queue = deque([], n)

        def __len__(self):
            return len(self.queue)

        def submit(self, func, *args, **kwargs):
            """Submit new task"""
            class T(object):
                def __init__(self):
                    self.done = False
                    self.out = None
                    T.t = Thread(target=self.run, args=(func, args, kwargs))
                    T.t.start()


# Generated at 2022-06-22 05:16:43.132761
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm import tqdm

    # Ensure that successive calls to submit do not accumulate
    mw = MonoWorker()
    for _ in tqdm(range(10)):
        mw.submit(sleep, 1)

    # Ensure that waiting jobs are cancelled and not discarded
    mw2 = MonoWorker()
    selected = [False]
    def select_job():
        """selects a job if it's first one submitted"""
        if not selected[0]:
            selected[0] = True
            return True
        return False

    for _ in tqdm(range(10)):
        if select_job():
            mw2.submit(lambda x: selected.append(x), True)
        else:
            mw2.submit(sleep, 1)

    # Ensure that discarding does

# Generated at 2022-06-22 05:17:17.906517
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from os import remove
    from time import sleep
    from .sync import TqdmSynchronisation
    from ..utils import _supports_unicode

    # pylint: disable=R0914,R0915
    def _task(filename, swap_bytes, tqdm_cls, miniters, mininterval, desc,
              ascii, unit, unit_divisor, total, dynamic_ncols, postfix,
              unit_scale, disable, unit_fmt):
        with TqdmSynchronisation() as tqdm:
            with open(filename, 'wb') as fh:
                if swap_bytes:
                    byteorder = fh.byteorder
                    fh.close()
                    fh = open(filename, 'rb')

# Generated at 2022-06-22 05:17:24.486909
# Unit test for constructor of class MonoWorker
def test_MonoWorker():  # pragma: no cover
    from threading import Event

    def wait(stop):
        """
        Wait for the stop event to be set, print a message and then exit.
        """
        stop.wait()
        tqdm_auto.write("stopped")

    stop = Event()
    worker = MonoWorker()
    worker.submit(wait, stop)
    stop.set()  # thread might not have started yet
    worker.submit(wait, stop)


if __name__ == '__main__':
    test_MonoWorker()  # pragma: no cover

# Generated at 2022-06-22 05:17:30.899940
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    class Counter():
        def __init__(self):
            self.value = 0
        def inc(self):
            self.value += 1
        def __repr__(self):
            return str(self.value)

    c = Counter()
    monoworker = MonoWorker()

    def _inc():
        c.inc()
        sleep(1)
        c.inc()

    for _ in range(5):
        monoworker.submit(_inc)

    sleep(1)
    monoworker.submit(_inc)
    assert repr(c) == '1'

    sleep(1)
    monoworker.submit(_inc)
    assert repr(c) == '3'

# Generated at 2022-06-22 05:17:36.918783
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def test(i):
        time.sleep(0.1)
        return i

    w = MonoWorker()
    for i in range(4):
        w.submit(test, i)
    assert len(w.futures) == 2
    assert w.futures[0].result() == 2
    assert w.futures[1].result() == 3

# Generated at 2022-06-22 05:17:40.161367
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..tqdm_gui import tgrange

    def worker(i):
        sleep(1)
        return i

    m = MonoWorker()
    for _ in tgrange(5, desc='test'):
        m.submit(worker, _)

if __name__ == '__main__':
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:17:43.623842
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> MonoWorker()
    Traceback (most recent call last):
    ...
    NameError: name 'MonoWorker' is not defined
    """
    pass

# Generated at 2022-06-22 05:17:49.291837
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import os
    import sys
    import time
    import threading
    import subprocess
    import multiprocessing
    import psutil
    try:
        from urlparse import urlparse
    except ImportError:
        from urllib.parse import urlparse
    from .trequests import get_with_tqdm

    nthreads = 2
    nprocs = 2

    def worker_thread(url):
        get_with_tqdm(url)

    def worker_proc(i):
        get_with_tqdm('https://raw.githubusercontent.com/tqdm/tqdm/master/_tqdm/tests/test_tqdm.py')

    mp_start_methods = [
        'fork',
        'spawn',
        'forkserver',
    ]
    mp_context

# Generated at 2022-06-22 05:18:00.940898
# Unit test for constructor of class MonoWorker

# Generated at 2022-06-22 05:18:11.504730
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from tqdm import trange
    import threading
    import sys

    def worker(n):
        sleep(1)
        return n * n

    mw = MonoWorker()

    def submit_non_blocking(i):
        return mw.submit(worker, i)

    with trange(10, ncols=70) as t:
        futures = []
        for i in t:
            futures.append(submit_non_blocking(i))
            t.set_postfix(future=futures[-1])

        if sys.version_info[0] >= 3:
            for future in tqdm_auto.tqdm(futures, mininterval=0.1):
                future.result()

    # Test clearing the future

# Generated at 2022-06-22 05:18:13.125917
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert MonoWorker().pool.__class__.__name__ == "ThreadPoolExecutor"
