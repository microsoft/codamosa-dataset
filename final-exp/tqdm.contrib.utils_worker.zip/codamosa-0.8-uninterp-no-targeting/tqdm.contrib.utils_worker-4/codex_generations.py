

# Generated at 2022-06-22 05:09:13.080404
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert MonoWorker()

# Generated at 2022-06-22 05:09:22.910953
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    from threading import Thread
    from line_profiler import LineProfiler

    def wait_1s(n):
        time.sleep(1)
        return n

    def wait_2s(n):
        time.sleep(2)
        return n

    def wait_3s(n):
        time.sleep(3)
        return n

    def test_submit(func):
        mw = MonoWorker()
        lp = LineProfiler()
        args = (mw, func)
        lp_wrapper = lp(test_submit)
        new_args = args + (lp_wrapper, )
        t = Thread(target=lp_wrapper, args=args)
        t.daemon = True
        t.start()
        t.join()
        lp.print_

# Generated at 2022-06-22 05:09:33.206196
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from multiprocessing import Process
    from threading import Thread
    from tqdm import tqdm
    mw = MonoWorker()
    assert len(mw.futures) == 0
    futures = [mw.submit(time.sleep, 1) for i in range(1, 4)]
    for future in tqdm(futures, desc='Threads running concurrently'):
        assert len(mw.futures) == 1
        f = futures[0]
        if future is not f:
            assert f.done()
        assert not future.done()
        try:
            future.result()
        except Exception as e:
            tqdm_auto.write(str(e))
        else:
            assert future.done()
    assert len(mw.futures) == 0

# Generated at 2022-06-22 05:09:36.483025
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Nothing to test.
    pass

if __name__ == '__main__':  # pragma: no cover
    test_MonoWorker()

# Generated at 2022-06-22 05:09:44.400452
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    m = MonoWorker()
    first = m.submit(lambda x: x + 1, 1)
    assert first == m.futures[0]
    second = m.submit(lambda x: x + 1, 2)
    assert second == m.futures[0]
    assert first.cancel()
    third = m.submit(lambda x: x + 1, 3)
    assert third == m.futures[0] == second
    assert first.done()
    assert first.cancelled()
    assert not second.cancelled()
    assert not third.cancelled()



# Generated at 2022-06-22 05:09:50.936534
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import tqdm

    def printer(msg, sleep=0):
        time.sleep(sleep)
        tqdm.write(msg)

    worker = MonoWorker()
    worker.submit(printer, 'a', 5)
    worker.submit(printer, 'b', 1)
    worker.submit(printer, 'c', 1)



# Generated at 2022-06-22 05:09:54.690539
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> MonoWorker()
    <tqdm.contrib.MonoWorker object at 0x7f966d4f3c18>
    """
    return MonoWorker()


# Generated at 2022-06-22 05:09:58.581383
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from random import random
    mw = MonoWorker()
    add_delays = lambda x: time.sleep(x)
    for i in tqdm_auto.tqdm(range(10), desc='task1', ncols=50):
        time.sleep(random())
        mw.submit(add_delays, random())
    print()



# Generated at 2022-06-22 05:10:08.946794
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=bare-except
    import time
    import random
    import sys

    def _test(w, n, running_wait=0, done_wait=0):
        for i in range(n):
            j = (n - 1) * 0.5 - abs(i % n - (n - 1) * 0.5)
            w.submit(_test_worker,
                     int(j) + random.random() * 0.5,
                     running_wait=running_wait,
                     done_wait=done_wait)
            for _ in range(i):
                time.sleep(0.2)
                sys.stderr.write('.')

    def _test_worker(x, running_wait=0, done_wait=0):
        time.sleep(running_wait)

# Generated at 2022-06-22 05:10:12.377499
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    worker = MonoWorker()
    def wait(n):
        time.sleep(n)
        return n
    assert worker.submit(wait, 3)
    assert worker.submit(wait, 2)

# Generated at 2022-06-22 05:10:21.395042
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import itertools
    import threading

    def task_1(delay, value):
        time.sleep(delay)
        return value

    def task_2(delay, value):
        time.sleep(delay)
        return value

    # Get the last value returned
    worker = MonoWorker()

    start = time.time()
    for i in tqdm_auto.tqdm(
            itertools.count(),
            desc="submitting",
            leave=False):
        worker.submit(task_1, 0.1, i)
        worker.submit(task_2, 0.2, i)
        worker.submit(task_1, 0.1, i)

        # Sleep so that the second task can be submitted
        time.sleep(0.015)


# Generated at 2022-06-22 05:10:29.378447
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock, Thread

    def print_and_sleep(s):
        with Lock():
            print(s, end='')
            sleep(0.1)

    MW = MonoWorker()
    for a in range(3):
        t = Thread(target=print_and_sleep, args=('a' + str(a),))
        MW.submit(t.start)  # the 1st submitted
    sleep(0.05)
    for b in range(3):
        t = Thread(target=print_and_sleep, args=('b' + str(b),))
        MW.submit(t.start)  # the 2nd submitted
    sleep(0.05)

# Generated at 2022-06-22 05:10:32.853352
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from uuid import uuid4 as uuid

    def temp(t):
        sleep(t/100)
        return t

    mw = MonoWorker()
    for i in tqdm_auto.tqdm(range(10)):
        mw.submit(temp, uuid())


# Generated at 2022-06-22 05:10:43.058441
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    def slowfunc(i):
        sleep(3)
        return i
    import sys
    import os
    import time
    sys.stderr.write(os.linesep)
    with MonoWorker() as worker:
        for i in range(10):
            worker.submit(slowfunc, i)
            time.sleep(0.1)
        future = worker.submit(slowfunc, 9999)
        time.sleep(1)
        worker.futures.appendleft(worker.futures.pop())  # re-insert running
        worker.submit(slowfunc, 8888)
        with tqdm_auto.tqdm(total=2) as progressbar:
            while not future.done():
                progressbar.update()
                time.sleep(0.01)
        assert 9

# Generated at 2022-06-22 05:10:53.399546
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import os

    def my_func(x):
        for i in tqdm_auto.tqdm("abc", leave=False):
            time.sleep(x)
            sys.stdout.flush()
            yield
        time.sleep(x)
        sys.stdout.flush()

    my_instance = MonoWorker()

    with tqdm_auto.tqdm("abc") as t:
        task_1 = my_instance.submit(my_func, 0.1)
        for i in t:
            time.sleep(1)
            t.set_description(u"xyz")
            sys.stdout.flush()
            if task_1.done():
                break

    time.sleep(0.2)
    assert not task_1.done()


# Generated at 2022-06-22 05:10:53.778392
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert MonoWorker()

# Generated at 2022-06-22 05:11:01.641769
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    n = 0
    def f(i):
        time.sleep(0.1 + i * 0.002)
        return i

    def f_err():
        raise ValueError

    mw = MonoWorker()
    for i in range(7):
        n += 1
        mw.submit(f, i)
    for i in range(3):
        n += 1
        # submit with error
        mw.submit(f_err)
    mw.submit(f, 9)  # check that last one is run

    assert n == 11
    assert mw.futures[-1].result() == 9

# Generated at 2022-06-22 05:11:10.879479
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from .async_ import test_futures, test_cancel, interrupt_main
    try:
        mw = MonoWorker()
    except Exception as e:
        raise Exception('MonoWorker failed to construct') from e
    from concurrent.futures import ThreadPoolExecutor
    try:
        assert isinstance(mw.pool, ThreadPoolExecutor)
    except Exception as e:
        raise Exception('MonoWorker failed to construct pool') from e
    try:
        assert isinstance(mw.futures, deque)
    except Exception as e:
        raise Exception('MonoWorker failed to construct futures') from e

# Generated at 2022-06-22 05:11:18.941533
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random

    def f(x):
        import time
        time.sleep(0.2)
        return x * random.random()

    w = MonoWorker()
    w.submit(f, 1)
    assert len(w.futures) == 1

    w.submit(f, 2)
    assert len(w.futures) == 1

    w.submit(f, 3)
    assert len(w.futures) == 1

    w.submit(f, 4)
    assert len(w.futures) == 1

    assert w.futures[0].result() == 4

# Generated at 2022-06-22 05:11:26.242799
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    '''
    >>> import time
    >>> mono = MonoWorker()
    >>> mono.submit(time.sleep, 0.1)
    <Future at 0x... state=running>
    >>> mono.submit(time.sleep, 0.2)
    <Future at 0x... state=running>
    >>> mono.submit(time.sleep, 0.3)
    >>> mono.submit(time.sleep, 0.4)
    >>> mono.submit(time.sleep, 0.5)
    '''
    pass

# Generated at 2022-06-22 05:11:42.179819
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from random import randint
    
    mw = MonoWorker()
    _, _, _, _, _, _, _, rand_num = 0, 0, 0, 0, 0, 0, 0, 0
    for i in range(8):
        if i % 2 == 0:
            mw.submit(time.sleep, 3)
        else:
            mw.submit(time.sleep, 0.5)
    for i in range(8):
        if i % 2 == 0:
            mw.submit(time.sleep, 3)
        else:
            mw.submit(time.sleep, 0.5)
    mw.submit(lambda: rand_num.append(randint(0,100)))

# Generated at 2022-06-22 05:11:52.552589
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def _test(x):
        time.sleep(x)
        return x

    # Create and populate MonoWorker
    mw = MonoWorker()
    mw.submit(_test, 3)
    mw.submit(_test, 2)
    mw.submit(_test, 1)

    # Should be one task running and one waiting (1)
    assert len(mw.futures) == 1
    assert not mw.futures[0].done()

    # Wait for task to finish
    mw.futures[0].result()

    # Now we should have one waiting task, that is the last submitted (1)
    assert len(mw.futures) == 1 and mw.futures[0].result() == 1

# Generated at 2022-06-22 05:12:04.020067
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import warnings
    warnings.filterwarnings('ignore', '.*concurrent.futures*')

    def f(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    assert len(mw.futures) == 0
    mw.submit(f, 0.1)
    assert len(mw.futures) == 1
    mw.submit(f, 0.1)
    assert len(mw.futures) == 1
    mw.submit(f, 0.1)
    assert len(mw.futures) == 1
    f3 = mw.submit(f, 1)
    assert len(mw.futures) == 2
    assert f3.result() == 1

# Generated at 2022-06-22 05:12:06.275215
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .tests import test_MonoWorker_submit
    test_MonoWorker_submit.__wrapped__()

# Generated at 2022-06-22 05:12:15.257529
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    ok = True
    m = MonoWorker()
    ok = ok and len(m.futures) == 0
    m.submit(lambda: 1)
    ok = ok and len(m.futures) == 1
    m.submit(lambda: 2)
    ok = ok and len(m.futures) == 2
    m.submit(lambda: 3)
    ok = ok and len(m.futures) == 2 and m.futures[0].result() == 2
    m.submit(lambda: 4)
    ok = ok and len(m.futures) == 1 and m.futures[0].result() == 4
    return ok

# Generated at 2022-06-22 05:12:16.229463
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    pass



# Generated at 2022-06-22 05:12:28.174146
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing.dummy import Pool as ThreadPool
    x = [i for i in range(10)]
    x_run = []
    x_wait = []

    def func(i):
        x_run.append(i)

    def func_wrapper(i, tq):
        tq.update()
        func(i)
        tq.set_description(str(len(x_run)))

    tq = tqdm_auto.tqdm(total=len(x),
                        desc='class MonoWorker', ascii=True)
    mw = MonoWorker()
    with ThreadPool(len(x)) as pool:
        for i in x:
            # fut = mw.submit(func, i)
            fut = mw.submit(func_wrapper, i, tq)
           

# Generated at 2022-06-22 05:12:33.458496
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker.pool.__class__.__name__ == 'ThreadPoolExecutor'
    assert worker.futures.__class__.__name__ == 'deque'
    assert worker.futures.maxlen == 2
    assert len(worker.futures) == 0

if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:12:44.665257
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from itertools import count

    def delay(*args, **kwargs):
        time.sleep(3)

    def delay_exc(*args, **kwargs):
        time.sleep(3)
        raise Exception('test')

    mw = MonoWorker()
    for n in count():
        if n == 0:
            mw.submit(delay, 'foo')
        elif n == 1:
            mw.submit(delay, 'bar')
        elif n == 2:
            mw.submit(delay, 'baz')
        elif n == 3:
            mw.submit(delay_exc)
        else:
            break
    time.sleep(1)
    assert mw.futures[-1].result() == 'baz'

# Generated at 2022-06-22 05:12:46.104321
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    w = MonoWorker()
    assert w.pool.shutdown()


# Generated at 2022-06-22 05:13:02.934355
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    import sys
    import os

    testdir = os.path.dirname(os.path.realpath(__file__))
    stdout = sys.stdout


# Generated at 2022-06-22 05:13:11.752932
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    # Can submit two tasks
    mw.submit(lambda: None)
    mw.submit(lambda: None)
    # Cannot submit a third task
    assert mw.submit(lambda: None) is None
    # Can submit a task after popping the first one
    mw.futures.popleft()
    assert mw.submit(lambda: None) is not None
    # Cannot submit a third task after 2 have been submitted
    assert mw.submit(lambda: None) is None
    # But a fourth one can be submitted after the third one is popped
    mw.futures.popleft()
    assert mw.submit(lambda: None) is not None

# Generated at 2022-06-22 05:13:21.830685
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Lock
    lock = Lock()
    def wait(seconds):
        with lock:
            time.sleep(seconds)
    def callback(seconds):
        pass
    MonoWorker().submit(wait, 0.1).add_done_callback(callback)
    MonoWorker().submit(wait, 0.2)
    MonoWorker().submit(wait, 0.3)
    MonoWorker().submit(wait, 0.4)
    MonoWorker().submit(wait, 0.5)
    MonoWorker().submit(wait, 0.6)
    MonoWorker().submit(wait, 0.7)
    MonoWorker().submit(wait, 0.8)
    MonoWorker().submit(wait, 0.9)
    MonoWorker().submit(wait, 1.0)
    MonoWorker

# Generated at 2022-06-22 05:13:30.140836
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, queue
    from collections import namedtuple

    def test_func(i: int, sleep_time: float, tqdm_kwargs: dict = None):
        """Return computed result and sleep time."""
        if tqdm_kwargs is not None:
            for _ in tqdm_auto(range(i), **tqdm_kwargs):
                time.sleep(sleep_time)
        else:
            time.sleep(i * sleep_time)
        return i

    def test_func_exception(sleep_time):
        time.sleep(sleep_time)
        1 / 0

    def test_add_one(i):
        return i + 1

    def test(sleep_time=0.05, limit=10):
        mw = MonoWorker()


# Generated at 2022-06-22 05:13:37.988268
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .utils import echo_sleep
    from time import sleep
    from concurrent.futures import Future
    from six.moves import range

    mw = MonoWorker()

    f1 = mw.submit(echo_sleep, 2)
    sleep(0.5)
    assert isinstance(f1, Future)
    assert f1.running()
    f2 = mw.submit(echo_sleep, 3)
    assert not f2.done()
    sleep(0.5)
    assert f1.running()  # f1 not complete, not cancel/override
    assert not f2.done()
    sleep(1.5)
    assert f1.done()
    assert not f2.done()  # f2 not override f1
    sleep(1.5)
    assert f2.done()  # f

# Generated at 2022-06-22 05:13:43.252663
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .helpers import TestException
    from time import sleep
    def raiseFunc(a):
        sleep(a)
        raise TestException('test exception')

    mw = MonoWorker()
    mw.submit(sleep, 0.1)
    # catch exception
    try:
        mw.submit(raiseFunc, 0.1)
    except TestException as e:
        assert str(e) == 'test exception'

# Generated at 2022-06-22 05:13:45.761104
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    worker = MonoWorker()
    assert worker.submit(time.sleep, 1)
    assert worker.submit(time.sleep, 2)
    assert worker.submit(time.sleep, 3)

# Generated at 2022-06-22 05:13:51.018629
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mono = MonoWorker()
    def test_func(num):
        time.sleep(1)
        return num ** 2
    nums = [x for x in range(5)]
    for num in nums:
        mono.submit(test_func, num)
    for num in nums:
        assert(mono.futures[0].result() == test_func(num))

# Generated at 2022-06-22 05:14:01.050185
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Thread

    m = MonoWorker()
    v = []
    r = [0,1,2]
    for i in range(3):
        m.submit(lambda x: sleep(.5) or v.append(x), *([i]))
        v.append(-i)
    assert v == [-2, -0, -1, 0]
    Thread(target=lambda: m.submit(lambda: sleep(.5) or v.append(3))).start()
    Thread(target=lambda: m.submit(lambda: sleep(.5) or v.append(4))).start()
    Thread(target=lambda: m.submit(lambda: sleep(.5) or v.append(5))).start()
    assert v == [-2, -0, -1, 0]


# Generated at 2022-06-22 05:14:03.054510
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading
    worker = MonoWorker()
    assert isinstance(worker, MonoWorker)



# Generated at 2022-06-22 05:14:29.117015
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Lock
    from unittest import TestCase
    from ..utils import _supports_unicode

    test_length = 10000
    lock = Lock()

    class MyTestCase(TestCase):
        """
        Tests for MonoWorker
        """
        def test_basics(self):
            """
            Basic test for MonoWorker
            """
            def my_job(i, lock=lock):
                """
                Function called by MonoWorker
                """
                with lock:
                    tqdm_auto.write("Starting: {}".format(i))
                sleep(i / 100)
                with lock:
                    tqdm_auto.write("Finishing: {}".format(i))

            mono_worker = MonoWorker()

# Generated at 2022-06-22 05:14:29.900748
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert MonoWorker()

# Generated at 2022-06-22 05:14:38.310397
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import threading

    # Test it works
    with tqdm_auto.tqdm() as t:
        m = MonoWorker()
        m.submit(t.update, 1)
        time.sleep(1)
        m.submit(t.update, 2)
        time.sleep(1)
        m.submit(t.update, 3)
        time.sleep(1)
        m.submit(t.update, 4)
        time.sleep(1)
        m.futures[1].cancel()
        m.submit(t.update, 5)
        time.sleep(1)
        m.submit(t.update, 6)
        time.sleep(1)
        m.futures[0].cancel()
        m.submit(t.update, 7)
        time

# Generated at 2022-06-22 05:14:49.926900
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import string
    import multiprocessing as mp
    from functools import partial

    def deque_str(d):
        dstr = ','.join((str(i) for i in d))
        return '[' + dstr + ']'

    def timeit(func):
        def func_wrapper(*args, **kwargs):
            t0 = time.time()
            try:
                return func(*args, **kwargs)
            finally:
                t1 = time.time()
                tqdm_auto.write(str(func))
                tqdm_auto.write('time: %f' % (t1 - t0))
        return func_wrapper

    def worker_factory(sleeptime, ind):
        def worker(sleeptime, ind):
            tqdm_auto

# Generated at 2022-06-22 05:15:01.560280
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..utils import _term_move_up
    import time
    import sys

    def delayed_print(x):
        for i in tqdm_auto.tqdm(range(int(x)), desc="##"):
            time.sleep(.5)

    def submit(mw, x):
        print("submit(" + repr(x) + ")")
        mw.submit(delayed_print, x)

    mw = MonoWorker()
    tqdm_auto.write("Should be 'submit(2)' then 'submit(3)' then '## 3'")
    submit(mw, 2)
    submit(mw, 3)
    # We need to sleep in case the threadpool is too quick
    time.sleep(.1)

# Generated at 2022-06-22 05:15:13.065765
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Test case for class MonoWorker
    is_on_windows: bool, True if the current platform is Windows.
    """
    import sys
    is_on_windows = (sys.platform == 'win32')
    if is_on_windows:
        assert 1 == 1
    else:
        import time
        import os
        import signal
        import subprocess

        def sleep_until_killed(delay):
            time.sleep(delay)

        def create_program_runner(cmd, sig):
            p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT,
                                 preexec_fn=lambda: signal.signal(signal.SIGINT,
                                     sig))
            return p.stdout.readline, p

# Generated at 2022-06-22 05:15:15.459478
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    try:
        mw = MonoWorker()
        assert True
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-22 05:15:22.775294
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from traceback import format_exc

    def f(i):
        sleep(.5)
        return i

    out = []
    def g(*a):
        try:
            out.append(a[0].result())
        except Exception:
            out.append(format_exc())

    w = MonoWorker()
    w.submit(f, 1)
    w.submit(f, 2).add_done_callback(g)
    sleep(.2)
    w.submit(f, 3)
    sleep(.2)
    w.submit(f, 4)
    sleep(.2)
    w.submit(f, 5).add_done_callback(g)
    sleep(2)

    assert out == [1, 2]

# Generated at 2022-06-22 05:15:29.117070
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import threading

    mw = MonoWorker()

    res = []
    def get_res(x):
        print('start', x)
        t = threading.Thread(target=res.append, args=(x,))
        t.start()
        t.join()
        print('end', x)

    from time import sleep
    for i in range(5):
        mw.submit(get_res, i)
        sleep(0.2)

    assert res == [4,]

# Generated at 2022-06-22 05:15:33.307194
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import tqdm
    with tqdm.tqdm() as t:
        m = MonoWorker()
        for i in range(10):
            def show(i):
                time.sleep(0.05)
                tqdm.tqdm.write('{}'.format(i))
            m.submit(show, i)
            t.update()

# Generated at 2022-06-22 05:16:10.032317
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    try:
        MonoWorker()
    except Exception:
        raise ValueError()


# Generated at 2022-06-22 05:16:18.094851
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def foo(i):
        return i
    import time
    mw = MonoWorker()
    assert mw.futures.maxlen == 2
    assert not len(mw.futures)
    # submit one task
    f1 = mw.submit(foo, 1)
    assert len(mw.futures) == 1
    # submit second task
    f2 = mw.submit(foo, 2)
    assert len(mw.futures) == 2
    # submit third task
    f3 = mw.submit(foo, 3)
    assert len(mw.futures) == 1
    assert f1.done()
    assert f2.cancelled()
    assert f3.running()
    # submit fourth task
    f4 = mw.submit(foo, 4)


# Generated at 2022-06-22 05:16:26.811102
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import random
    import threading
    def sleeper(name, delay):
        time.sleep(delay)
        return name, delay
    mw = MonoWorker()

# Generated at 2022-06-22 05:16:38.275969
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Test for `MonoWorker.submit`."""
    from time import sleep
    from random import randint

    mw = MonoWorker()
    futures = []
    for i in range(10):
        futures.append(mw.submit(sleep, randint(1, 6)))
        sleep(randint(1, 3))
    # done first
    done, not_done = [f for f in futures if f.done()], \
        [f for f in futures if not f.done()]
    mw.submit(sleep, 2)
    # done all
    for i in range(6):
        sleep(1)
        mw.submit(sleep, 0)
    assert len(mw.futures) == 1
    assert mw.futures[0].done()

# Generated at 2022-06-22 05:16:39.516018
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()



# Generated at 2022-06-22 05:16:50.762461
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Lock
    from time import sleep

    _test = 0

    lock = Lock()

    def test_1(s):
        global _test
        with lock:
            _test = 1

    def test_2(s):
        global _test
        with lock:
            _test = 2

    def test_3(s):
        global _test
        with lock:
            _test = 3

    mw = MonoWorker()

    mw.submit(test_1, 1)
    mw.submit(test_2, 1)
    mw.submit(test_3, 1)
    sleep(0.2)
    with lock:
        assert _test == 3

    mw.submit(test_1, 1)
    mw.submit(test_2, 1)
    mw.submit

# Generated at 2022-06-22 05:16:51.435397
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor for class MonoWorker"""
    MonoWorker()

# Generated at 2022-06-22 05:17:00.161201
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def do_sleep(t, desc=None):
        time.sleep(t)
        if desc:
            tqdm_auto.write(desc)
        return t

    with MonoWorker() as p:
        p.submit(do_sleep, 1)
        assert not p.futures[0].done()
        p.submit(do_sleep, 2)
        assert p.futures[0].done()
        assert not p.futures[1].done()
        p.submit(do_sleep, 3)
        assert p.futures[1].done()
        assert not p.futures[0].done()
        assert not p.futures[1].done()
        p.submit(do_sleep, 4)
        p.submit(do_sleep, 5)
       

# Generated at 2022-06-22 05:17:11.109624
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import os
    try:
        os.remove('test.log')
    except:
        pass

    def log(*args):
        with open('test.log', 'a') as f:
            f.write(' '.join(map(str, args)) + '\n')
    worker = MonoWorker()

    # test 1 proc
    start = time.time()
    f = worker.submit(log, 1, start)
    assert f.result() is None
    assert time.time() - start < 0.5
    assert open('test.log').read() == '1 0.0\n'

    # test 2 concur
    start = time.time()
    g = worker.submit(log, 2, start)  # replace previous
    assert g.result() is None
    assert time.time() - start

# Generated at 2022-06-22 05:17:19.573077
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    from random import random
    from time import sleep
    from time import time
    from multiprocessing import cpu_count

    n = cpu_count() + 1
    n_tasks = 10000
    max_sleep = 0.1
    max_wait = 0.1

    def worker(i):
        sleep(random() * max_sleep)
        return i

    def test_1():
        start_time = time()
        mw = MonoWorker()
        for _ in tqdm_auto.tqdm(range(n_tasks),
                               desc='test_1: %.03fs' % max_wait,
                               miniters=100):
            mw.submit(worker, _)

            # wait for currently running task to finish

# Generated at 2022-06-22 05:18:47.133775
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .utils import WorkerTestCase

    class Test(WorkerTestCase):
        def concurrent_test(self):
            def slow_func(x, sleep_second):
                sleep(sleep_second)
                return x
            worker = MonoWorker()
            futures = []
            res = []
            futures.append(worker.submit(slow_func, 0, 0.1))
            futures.append(worker.submit(slow_func, "1", 0.1))
            res.append(futures.pop().result())
            futures.append(worker.submit(slow_func, 2, 0.1))
            res.append(futures.pop().result())
            futures.append(worker.submit(slow_func, 3, 0.1))
            res.append(futures.pop().result())

# Generated at 2022-06-22 05:18:50.172720
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test MonoWorker constructor"""
    from .tests import TestMonoWorker
    TestMonoWorker().test_MonoWorker()


# Generated at 2022-06-22 05:18:55.975372
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .nonblocking import non_blocking

    def func(i):
        sleep(i)
        return i

    with non_blocking():
        mw = MonoWorker()
        for i in range(3):
            mw.submit(func, i)
            sleep(0.25)
        assert list(mw.futures) == [1, 2]

# Generated at 2022-06-22 05:19:06.496557
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Thread
    import sys
    import tqdm

    mw = MonoWorker()

    # test single-threaded task submitting
    t1 = mw.submit(sleep, 1)
    t2 = mw.submit(sleep, 1)
    assert t1 == t2

    # test multi-threaded task submitting
    t1 = Thread(target=mw.submit, args=(sleep, 1))
    t2 = Thread(target=mw.submit, args=(sleep, 1))
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    # test task cancellation
    t = tqdm.tqdm(total=10)
    t1 = mw.submit(sleep, 1)

# Generated at 2022-06-22 05:19:13.436963
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from .thread import thread_map
    from .multiprocessing import mp_map

    for map in thread_map, mp_map:
        n = 20
        mw = MonoWorker()
        mw.submit(sleep, 0.5)
        mw.submit(sleep, 0.2)
        values = map(int, mw, range(n))
        assert len([v for v in values if v is not None]) <= 1

