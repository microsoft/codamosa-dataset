

# Generated at 2022-06-22 05:09:29.524198
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=unused-variable
    from time import sleep
    @staticmethod
    def func1(*args):
        # pylint: disable=unused-variable
        sleep(0.1)

    @staticmethod
    def func2(*args):
        # pylint: disable=unused-variable
        sleep(1)

    @staticmethod
    def func3(*args):
        # pylint: disable=unused-variable
        sleep(2)

    @staticmethod
    def func4(*args):
        # pylint: disable=unused-variable
        sleep(2.1)

    # test 1
    mono1 = MonoWorker()
    mono1.submit(func1)
    mono1.submit(func2)
    mono1.submit(func3)
    assert mono1

# Generated at 2022-06-22 05:09:40.895012
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import subprocess

    mw = MonoWorker()
    assert len(mw.futures) == 0

    cmd = 'sleep 1; echo "Done sleep 1"'
    mw.submit(subprocess.check_output, cmd, shell=True)
    assert len(mw.futures) == 1

    f2 = mw.submit(subprocess.check_output, 'sleep 0.5; echo "Done sleep 0.5"', shell=True)
    assert len(mw.futures) == 1
    assert mw.futures[0] is f2

    cmd = 'sleep 0.1; echo "Done sleep 0.1"'
    mw.submit(subprocess.check_output, cmd, shell=True)

# Generated at 2022-06-22 05:09:49.166080
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event, Lock
    from multiprocessing import Value
    from queue import Queue
    from contextlib import contextmanager

    lock = Lock()
    event = Event()
    counter = Value('i', 0)

    class TqdmTest(object):
        """Mock for tqdm_auto.write"""

        def __init__(self):
            self.queue = Queue()

        def write(self, text):
            self.queue.put(text)

    tqdm = TqdmTest()

    worker = MonoWorker()

    @contextmanager
    def fail_after(seconds):
        "Context manager that fails after a given time"
        timeout = Event()
        tim = t = value = None


# Generated at 2022-06-22 05:09:55.001377
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Initialization of MonoWorker
    my_mono_worker = MonoWorker()
    assert(my_mono_worker.pool.max_workers == 1)
    assert(len(my_mono_worker.futures) == 0)
    assert(my_mono_worker.futures.maxlen == 2)

# Generated at 2022-06-22 05:10:01.794744
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    global MonoWorker

    class MonoWorker(object):
        """Supports one waiting task, and one running task (in the thread).
        """
        def __init__(self, desc=""):
            self.desc = desc
            self.completed = 0
            self.futures = deque([], 2)

        def submit(self, func, *args, **kwargs):
            """`func(*args, **kwargs)`."""
            futures = self.futures
            if len(futures) == futures.maxlen:
                running = futures.popleft()
                if not running.done():
                    if len(futures):  # clear waiting
                        waiting = futures.pop()
                        waiting.cancel()
                    futures.appendleft(running)  # re-insert running

# Generated at 2022-06-22 05:10:09.606120
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from concurrent.futures import ThreadPoolExecutor
    from time import time
    from time import sleep
    from random import random
    from tqdm.contrib import MonoWorker
    def long_running(x):
        sleep(x)
        return x

    no_of_workers = 6

    start = time()
    print("Creating jobs...")
    with ThreadPoolExecutor(max_workers=no_of_workers) as pool:
        jobs = [pool.submit(long_running, 2 * random()) for _ in tqdm_auto(range(16))]
        print("Waiting for jobs...")
        total = 0

        with MonoWorker() as worker:
            for job in jobs:
                total += job.result()
                worker.submit(long_running, job.result() / 2)

# Generated at 2022-06-22 05:10:18.877081
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import time, sleep
    from . import _MonoWorker as MW

    def fib(n):
        if n < 2:
            return n
        else:
            return fib(n - 1) + fib(n - 2)

    def fib_tqdm(n, sleep=sleep, tqdm=tqdm_auto):
        """Fibonacci sequence."""
        with tqdm_auto(total=n, unit='fib') as pbar:
            for i in range(n):
                sleep(0.1)
                pbar.update()
                if i > 1:
                    pbar.set_description("fib({}) = {}".format(i, pbar.n))
                    if (i < 10) and (pbar.n % (pbar.total // 10) == 0):
                        p

# Generated at 2022-06-22 05:10:22.405305
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Tests the constructor of the MonoWorker class
    """
    mono_worker = MonoWorker()
    assert isinstance(mono_worker, MonoWorker) == True


# Generated at 2022-06-22 05:10:29.849944
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import functools
    from operator import is_not
    from multiprocessing import Queue
    from concurrent.futures import Future, TimeoutError

    def verify(worker, waiting, running, msg=None):
        assert waiting is not None or running is not None, msg
        if msg:
            tqdm_auto.write(msg)
        if waiting is not None:
            assert worker.futures[-1] is waiting, msg
        if running is not None:
            assert worker.futures[0] is running, msg

    # setup
    q = Queue()
    worker = MonoWorker()
    waiting = None
    running = None

    # test
    # 1. first operation starts running
    running = worker.submit(q.get)

# Generated at 2022-06-22 05:10:39.130153
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time

    def delayed_print(*args, **kwargs):
        time.sleep(.5)
        tqdm_auto.write(*args, **kwargs)

    mw = MonoWorker()
    mw.submit(threading.Lock)
    time.sleep(.01)
    mw.submit(delayed_print, 'test')
    time.sleep(.01)
    assert 'test' in str(mw.futures)
    mw.submit(delayed_print, 'test2')
    time.sleep(.01)
    assert 'test' not in str(mw.futures)
    mw.submit(delayed_print, 'test3')
    time.sleep(.01)

# Generated at 2022-06-22 05:10:50.634734
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import threading
    import time

    mw = MonoWorker()

    def func(n):
        time.sleep(n)
        return n

    e1 = mw.submit(func, 1)
    e2 = mw.submit(func, 2)

    time.sleep(0.1)
    assert (threading.active_count() >= 3)  # Pool worker, thread 1, thread 2
    assert (len(mw.futures) == 1)

    time.sleep(1.1)
    assert (e1.result() == 1)
    assert (e2.result() == 2)
    assert (len(mw.futures) == 0)

test_MonoWorker()

# Generated at 2022-06-22 05:10:56.295759
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    def w1():
        sleep(2)
        return 1
    def w2():
        sleep(2)
        return 2
    def w3():
        sleep(2)
        return 3
    mp = MonoWorker()
    p1 = mp.submit(w1)
    p2 = mp.submit(w2)
    p3 = mp.submit(w3)
    assert p3.done()
    assert not p1.done()
    assert p2.done()
    assert p2.result() == 2
    assert p3.result() == 3

# Generated at 2022-06-22 05:11:06.426490
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from os import getpid
    pool = MonoWorker()
    assert len(pool.futures) == 0
    assert pool.submit(getpid).result() == pool.submit(getpid).result()
    # Smoke test
    pool.submit(getpid)
    pool.submit(getpid)
    pool.submit(getpid)
    pool.submit(getpid)
    pool.submit(getpid)
    assert len(pool.futures) == 1
    # Basic test
    assert pool.submit(getpid).result() == pool.submit(getpid).result()
    assert len(pool.futures) == 1
    assert pool.submit(getpid).result() != pool.submit(getpid).result()
    assert len(pool.futures) == 1
    # Test ordering

# Generated at 2022-06-22 05:11:11.623859
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import Pool
    import random
    import sys

    def tqdm(l, *args, **kwargs):
        return l

    def _pbar(name, sleep_time):
        with tqdm(total=None, desc=name) as prog:
            sleep(sleep_time)
            prog.update(1)

    tests = [
        (1, 0.2),
        (2, 0.1),
        (3, 0.05),
        (4, 0.1),
        (5, 0.2),
        (6, 0.3),
        (7, 0.1),
    ]
    random.shuffle(tests)
    mw = MonoWorker()
    for i, (name, sleep_time) in enumerate(tests):
        m

# Generated at 2022-06-22 05:11:22.283004
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Thread
    from traceback import format_exc
    from tqdm import tqdm

    try:  # Python 2
        from Queue import Queue  # noqa
    except ImportError:
        from queue import Queue  # noqa

    q = Queue()

    def sleep_success(*args, **kwargs):
        sleep(1)
        return 'success'

    def sleep_fail(*args, **kwargs):
        sleep(1)
        raise Exception('fail')

    def sleep_r(t, *args, **kwargs):
        sleep(t)
        return t

    def test_success(func, *args, **kwargs):
        tqdm_auto.write('Testing: {}'.format(func.__name__))
        e = MonoWorker()


# Generated at 2022-06-22 05:11:33.019925
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    # perform several tasks
    worker = MonoWorker()
    def test_task(n, sleep):
        time.sleep(sleep)
        return n
    t = worker.submit(test_task, 0, 0.3)
    tqdm_auto.write("0 => %s" % t.result())
    t = worker.submit(test_task, 1, 0.2)
    tqdm_auto.write("1 => %s" % t.result())
    t = worker.submit(test_task, 2, 0.4)
    tqdm_auto.write("2 => %s" % t.result())
    # replace waiting task
    def test_task_err(n, sleep):
        raise Exception("err")

# Generated at 2022-06-22 05:11:44.910410
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import signal
    signal.signal(signal.SIGINT, signal.SIG_DFL)  # needed for interrupts!
    import time
    import threading

    m = MonoWorker()

    def tst(i):
        time.sleep(.1)
        return i

    r = [m.submit(tst, i) for i in range(6)]
    assert r[0].result() == 5
    assert r[1].result() == 5
    assert r[2].done()
    assert r[3].result() == 5
    assert r[4].done()
    assert r[5].done()

    try:
        from tqdm.contrib import thread_map
    except ImportError:
        import traceback
        traceback.print_exc()

# Generated at 2022-06-22 05:11:47.489851
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    mono_worker = MonoWorker()
    assert mono_worker is not None

test_MonoWorker()

# Generated at 2022-06-22 05:11:58.623046
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from concurrent.futures import CancelledError
    # tqdm_auto.write(lambda s: len(s))
    pool = ThreadPoolExecutor(max_workers=2)
    def sleep_done(seconds):
        sleep(seconds)
        return seconds
    def sleep_cancel(seconds):
        sleep(seconds)

    def test_submit(waiting_seconds, running_seconds, expected,
                    expected_when_cancelled=None):
        """
        waiting_seconds: seconds of task which waits to be executed
        running_seconds: seconds of task which is currently being executed
        expected: expected output of all tasks
        expected_when_cancelled: expected output when running task is
        cancelled
        """
        worker = MonoWorker()
        old_write = tqdm_auto.write


# Generated at 2022-06-22 05:12:09.336425
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # pylint: disable=protected-access
    import time
    from ..auto import tqdm
    test_MonoWorker_submit.start = time.time()

    def run_func(i):
        """Yields the seconds that have elapsed on each call"""
        with tqdm(total=1) as pbar:
            while not pbar.n:
                pbar.set_description('%d' % i)
                pbar.update()
                yield time.time() - test_MonoWorker_submit.start

    mw = MonoWorker()

    # Start the background processes
    f1 = mw.submit(run_func, 1)
    f2 = mw.submit(run_func, 2)
    f3 = mw.submit(run_func, 3)

    # Join on the

# Generated at 2022-06-22 05:12:24.362397
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from multiprocessing import current_process
    from .utils import KeypressExit

    def func_out(*args, **kwargs):
        print('func_out:', current_process(), args, kwargs)
        print('func_out:', current_process(), 'sleeping')
        sleep(5)
        print('func_out:', current_process(), 'done')
        return 'func_out'

    def func_in(*args, **kwargs):
        print('func_in:', current_process(), args, kwargs)
        print('func_in:', current_process(), 'sleeping')
        sleep(5)
        print('func_in:', current_process(), 'done')
        return 'func_in'

    for i in range(4):
        worker = MonoWorker

# Generated at 2022-06-22 05:12:26.415831
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    return mw


# Generated at 2022-06-22 05:12:36.987500
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def _test(**kwargs):
        if kwargs['x'] < 0:
            raise Exception("Waiting for next task")
        else:
            return kwargs['x']

    def _sleep(x):
        from time import sleep
        sleep(x)

    from time import time
    from .tqdm_gui import tkinter_example

    n = 0

# Generated at 2022-06-22 05:12:45.332943
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> def dummy_func(x):
    ...     return x*x
    >>> monoworker = MonoWorker()
    >>> monoworker.submit(dummy_func, 1)
    >>> monoworker.submit(dummy_func, 2)
    >>> monoworker.submit(dummy_func, 3)
    >>> monoworker.futures[0].result()
    4
    >>> monoworker.futures[1].result()
    9
    """

if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-22 05:12:55.020227
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def do_sleep(seconds):
        import time
        time.sleep(seconds)

    mw = MonoWorker()
    assert len(mw.futures) == 0

    f1 = mw.submit(do_sleep, 1)
    assert len(mw.futures) == 1
    assert f1.done() is False

    f2 = mw.submit(do_sleep, 2)
    assert len(mw.futures) == 2
    assert f2.done() is False

    f3 = mw.submit(do_sleep, 3)
    assert len(mw.futures) == 2
    assert f3.done() is False

    # Sleep to ensure task is finished
    import time
    time.sleep(4)
    assert f1.done() is True
    assert f2

# Generated at 2022-06-22 05:13:01.310917
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """A basic test to ensure that the expected output is produced."""
    import time
    from random import randint
    from multiprocessing import cpu_count

    def some_func(n):
        """Test function"""
        time.sleep(n)
        return n

    with tqdm_auto.tqdm(desc='Test', total=10 * cpu_count()) as t:
        for i in range(10 * cpu_count()):
            mw = MonoWorker()
            mw.submit(some_func, randint(1, 4))
            time.sleep(1)
            t.update(1)
    print('Done')

# Generated at 2022-06-22 05:13:04.604331
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    worker = MonoWorker()
    for _ in range(10):
        worker.submit(2)
    assert len(worker.futures) == 2
    assert worker.futures[0].done()
    worker.submit(1)
    assert not worker.futures[0].done()
    assert len(worker.futures) == 1

# Generated at 2022-06-22 05:13:11.587693
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from ..auto import trange

    def func(i, j):
        return i, j

    mw = MonoWorker()
    for i in trange(3):
        mw.submit(func, i, "a")
    for i in trange(3):
        mw.submit(func, i, "b")
    for i in trange(3):
        mw.submit(func, i, "c")
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == (2, "c")

# Generated at 2022-06-22 05:13:21.718316
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Tests the MonoWorker._submit method."""
    import random
    import time
    import traceback
    from threading import Event
    from multiprocessing import Pipe
    from concurrent.futures import CancelledError

    end_test = Event()
    end_test.clear()

    # Define a function which is run in thread of MonoWorker
    def run_in_thread(arg_in, pipe_out):
        """
        A simple function which writes to a pipe and returns a random value.
        """
        tqdm_auto.write('starting thread')
        try:
            pipe_out.send(arg_in)
            pipe_out.close()
        except IOError:
            # The pipe is closed
            pass
        time.sleep(4)

# Generated at 2022-06-22 05:13:27.474036
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    >>> import time, sys
    >>> def a():
    ...     time.sleep(1); sys.stdout.write('a')
    >>> mw = MonoWorker()
    >>> mw.submit(a)
    >>> time.sleep(0.2)
    >>> mw.submit(a)
    >>> time.sleep(1.3) # should print 'a' then 'a'
    """
    pass



# Generated at 2022-06-22 05:13:41.019577
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def counter(i):
        time.sleep(0.1)
        return i
    mono = MonoWorker()
    assert mono.submit(counter, 1).result() == 1
    assert len(mono.futures) == 1
    mono.submit(counter, 2)
    assert len(mono.futures) == 1
    assert mono.submit(counter, 3).result() == 3
    assert len(mono.futures) == 1

# Generated at 2022-06-22 05:13:48.795769
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from threading import Event
    from .utils import qrange, b, SafeFormat

    def sleep_half_sec():
        sleep(0.5)

    class TestClass(object):
        """
        Class to simulate dummy test with parallel workers.
        """
        def __init__(self, *args, **kwargs):
            """
            Initialize the TestClass with the following parameters:
            :param int job_length: Length of one job.
            :param int job_sleep_time: Time of sleep before next job.
            :param bool continue_sleep: An option to sleep after job or not.
            :param str message: Message to print.
            """
            self.job_length = args[0]
            self.job_sleep_time = args[1]

# Generated at 2022-06-22 05:13:57.997945
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def test(time_limit, interval, test_type):
        import time
        from ..utils import _term_move_up

        def slow_square(x):
            time.sleep(interval)
            return x ** 2

        to_test = MonoWorker()
        # submit first task
        first_future = to_test.submit(slow_square, 3)
        assert first_future.result() == 9
        # submit second task before first one finishes
        # second task should replace first task
        second_future = to_test.submit(slow_square, 4)
        assert second_future.result() == 16
        try:
            assert first_future.result() == 9, "first task should finish"
        except Exception as e:
            pass

# Generated at 2022-06-22 05:14:08.125475
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from pytest import raises
    from time import sleep
    from .utils import Empty
    from threading import Thread
    mw = MonoWorker()
    assert mw.pool._max_workers == 1
    assert len(mw.futures) == 0

    # Test task 1:
    def task1():
        return 1 + 1
    mw.submit(task1)
    assert len(mw.futures) == 1
    assert mw.futures[0].result() == 2
    assert len(mw.futures) == 0

    # Test task 2:
    def task2():
        sleep(1)
        raise Exception("Task 2 failed")
    mw.submit(task2)
    assert len(mw.futures) == 1

# Generated at 2022-06-22 05:14:19.548587
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from .node import node
    from .tqdm import tqdm
    from .utils import Thread
    from .version import __version__

    print('Testing MonoWorker class')
    print('tqdm_contrib version:', __version__)
    count = 5
    mw = MonoWorker()
    t = tqdm(total=count, bar_format='{desc:<15} |{bar}| '
                                     '{n_fmt:>{cols}}/{total_fmt:<{cols}} '
                                     '{rate_fmt:>9s}')

    def thread_wrapper(n, desc):
        """Used to identify the actual thread"""
        ret = Thread(lambda: sleep(n * 0.1), desc=desc)
        ret.start()


# Generated at 2022-06-22 05:14:24.130830
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # A - class MonoWorker
    assert callable(MonoWorker)
    # B - constructor of class MonoWorker
    worker = MonoWorker()
    assert callable(worker.submit)

# Generated at 2022-06-22 05:14:25.894409
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def f():
        return 42

    w = MonoWorker()
    assert str(w.submit(f,).result()) == "42"

# Generated at 2022-06-22 05:14:36.049947
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Tests MonoWorker.submit()."""
    # pylint: disable=missing-docstring

    import time
    import sys

    def write(text):
        sys.stdout.write('%s\n' % text)

    def func(i):
        time.sleep(1)
        return i

    write('Submitting two tasks')
    mw = MonoWorker()
    mw.submit(func, 0)
    mw.submit(func, 1)
    assert mw.futures[0].result() == 1, 'Waiting task is not replaced'
    assert len(mw.futures) == 1, 'Too many waiting tasks'

    write('Testing no maxlen')
    mw = MonoWorker()
    mw.futures.maxlen = None
    mw.submit

# Generated at 2022-06-22 05:14:42.609188
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def _add(x, y):
        return x + y
    def _raise():
        raise Exception()

    mw = MonoWorker()

    # No tasks
    assert len(mw.futures) == 0

    # 1 task (waiting)
    r1 = mw.submit(_add, 1, 2)
    assert len(mw.futures) == 1
    assert r1 == mw.futures[-1]
    assert not r1.done()
    r1.result()  # wait for result
    assert r1.done()
    assert r1.result() == 3

    # 1 task (waiting), 1 task (running)
    r2 = mw.submit(_add, 3, 4)
    assert len(mw.futures) == 1
    assert r2 == m

# Generated at 2022-06-22 05:14:52.557451
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    import sys

    lock = Lock()

    def sleep_print(x):
        with lock:
            sys.stdout.write(str(x))
        sleep(1)
        with lock:
            sys.stdout.write('@')

    w = MonoWorker()
    futures = [w.submit(sleep_print, x) for x in 'abc']
    futures.extend([w.submit(sleep_print, x) for x in 'ABC'])
    futures.extend([w.submit(sleep_print, x) for x in '123'])
    for f in futures:
        f.result()
    assert repr(w) == ('<MonoWorker: '
                       'running=None, waiting=<Future at 0x%x state=finished>>')


# Generated at 2022-06-22 05:15:18.613324
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def func(it, e):
        # print('func start')
        sleep(it)
        # print('func end')
        e.set()
        return it

    mw = MonoWorker()
    e0, e1 = Event(), Event()
    w0, w1 = mw.submit(func, 0.5, e0), mw.submit(func, 0.5, e1)
    try:
        assert not e0.is_set()
        assert not e1.is_set()
        w2 = mw.submit(func, 0.5, Event())
        assert False
    except AssertionError:
        pass
    assert not e0.is_set()
    assert not e1.is_set()
    e0.wait()


# Generated at 2022-06-22 05:15:24.345746
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from contextlib import contextmanager
    from threading import Event

    @contextmanager
    def sleep_except(t=0.5, exc=None):
        e = Event()
        try:
            yield e
        except (KeyboardInterrupt, exc):
            raise
        except:
            pass
        finally:
            e.wait(t)

    def get_tasks(n):
        for i in tqdm_auto.tqdm_notebook(range(n), desc='TaskSource'):
            yield i

    def noop():
        pass

    def task(i):
        with sleep_except():
            tqdm_auto.tqdm_notebook(range(i), desc='Task')

    def test_submit_one(n=5, m=5):
        tqdm_auto

# Generated at 2022-06-22 05:15:29.230572
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def f(x):
        time.sleep(.1)
        return x

    w = MonoWorker()

    w.submit(f, 1)
    w.submit(f, 2)
    w.submit(f, 3)
    w.submit(f, 4)
    w.submit(f, 5)

    assert w.futures[-1].result() == 5
    assert len(w.futures) == 1

# Generated at 2022-06-22 05:15:31.483740
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()


if __name__ == '__main__':
    from .common_tests import CommonTests
    CommonTests().test_MonoWorker()

# Generated at 2022-06-22 05:15:39.338826
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # test submission of a job
    def test_func(a, b):
        return a + b
    mw = MonoWorker()
    assert mw.submit(test_func, 1, b=2).result() == 3, "Initial submission failed"
    # test cancelling a running task
    assert mw.submit(test_func, 5, b=6).cancelled(), "Cancelled second submission failed"
    # test cancelling a waiting task
    assert mw.submit(test_func, 5, b=6).result() == 11, "Cancelled third submission failed"
    assert mw.submit(test_func, 5, b=6).cancelled(), "Cancelled fourth submission failed"
    # test that that jobs cannot be submitted when the thread is busy

# Generated at 2022-06-22 05:15:49.823353
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from ..utils import format_sizeof

    def func(x):
        time.sleep(3)
        return x

    def func2(x):
        time.sleep(2)
        return x

    M = MonoWorker()
    M.submit(func, 1)
    assert not M.futures[0].done()
    M.submit(func2, 2)
    assert not M.futures[1].done()
    assert M.futures[0].done()
    M.submit(func2, 3)
    assert not M.futures[1].done()
    assert M.futures[0].done()
    time.sleep(2)
    assert M.futures[1].done()
    assert M.futures[0].done()

# Generated at 2022-06-22 05:15:55.421678
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def busy_wait(n):
        time.sleep(n)
        return n

    with MonoWorker() as w:
        future = w.submit(busy_wait, 1)
        future.result()



# Generated at 2022-06-22 05:16:04.759209
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from sys import stderr, maxint

    def from_test():
        time.sleep(10)
        stderr.write("test_MonoWorker.from_test\n")

    def from_test_1():
        time.sleep(maxint)
        stderr.write("test_MonoWorker.from_test_1\n")

    stderr.write("test_MonoWorker.ENTER\n")
    mw = MonoWorker()
    mw.submit(from_test)
    mw.submit(from_test_1)
    time.sleep(1)
    mw.submit(from_test)
    stderr.write("test_MonoWorker.EXIT\n")


if __name__ == "__main__":
    test_

# Generated at 2022-06-22 05:16:13.784057
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from colorama import Fore

    # This is what the user sees
    from tqdm import tqdm
    from tqdm.contrib.concurrency import thread_map  # for parallelisation
    tqdm_auto.write(Fore.BLUE + "Started")
    for w in tqdm(thread_map(
            sleep, range(4), ret_exc=True, desc='thread_map', ncols=60)):
        tqdm_auto.write(Fore.RED + repr(w))



# Generated at 2022-06-22 05:16:20.637746
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def wait_sleep(sec):
        from time import sleep
        sleep(sec)
    instance = MonoWorker()
    for sec in [3, 2, 1]:
        instance.submit(wait_sleep, sec)
    assert len(instance.futures) == 2

if __name__ == '__main__':
    test_MonoWorker()

# Generated at 2022-06-22 05:16:55.389555
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    assert len(mw.futures) == 0

    def f():
        time.sleep(1)  # thread blocks
    mw.submit(f)
    assert len(mw.futures) == 1

    mw.submit(f)
    assert len(mw.futures) == 2  # un-blocked

    def g():
        time.sleep(1)
        raise Exception('test')
    mw.submit(g)
    assert len(mw.futures) == 2  # un-blocked

    mw.submit(g)
    assert len(mw.futures) == 2  # un-blocked

# Generated at 2022-06-22 05:17:03.177308
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def foo(a):
        time.sleep(a)
        return a

    mw = MonoWorker()
    a = mw.submit(foo, 1)
    assert a == mw.futures[-1]
    assert len(mw.futures) == 1

    time.sleep(0.1)

    b = mw.submit(foo, 1)
    assert b != a
    assert b == mw.futures[-1]
    assert len(mw.futures) == 2

    time.sleep(0.1)

    c = mw.submit(foo, 1)
    assert c != b
    assert c == mw.futures[-1]
    assert len(mw.futures) == 2

# Generated at 2022-06-22 05:17:10.524394
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    def foo(res):
        time.sleep(res)
        return res

    mw = MonoWorker()
    f1 = mw.submit(foo, 10)
    f2 = mw.submit(foo, 1)
    f3 = mw.submit(foo, 3)
    f4 = mw.submit(foo, 5)
    assert f1 == f2
    assert not f1.done()
    assert f2.result() == 1
    assert f1.done()
    assert f4.done()
    assert f4.result() == 3
    assert f1.result() == 1

# Generated at 2022-06-22 05:17:14.384079
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def f(arg):
        import time
        time.sleep(1)
        return arg

    mw = MonoWorker()
    n = 2
    for i in range(n):
        mw.submit(f, i)
    for i in range(n):
        assert mw.futures[i].result() == i

# Generated at 2022-06-22 05:17:16.461265
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import _range
    MonoWorker()



# Generated at 2022-06-22 05:17:25.198426
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from traceback import print_exc
    from concurrent.futures import TimeoutError
    from multiprocessing import Event
    terminated = Event()

    def f(x):
        """Returns x"""
        sleep(0.3)
        return x

    def g(x):
        """Returns x"""
        sleep(0.1)
        return x

    mw = MonoWorker()
    result = []

    try:
        result.append(mw.submit(f, 1)  # 1
                          .result(timeout=0.1))
    except TimeoutError:
        pass
    except Exception:
        print_exc()

# Generated at 2022-06-22 05:17:29.375857
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .test_utils import random_int
    from time import sleep

    mw = MonoWorker()
    x = random_int()

    def func_1(a):
        assert a == x
        sleep(5)

    def func_2(a):
        assert a == x
        sleep(5)

    f1 = mw.submit(func_1, x)
    f2 = mw.submit(func_2, x)

# Generated at 2022-06-22 05:17:39.852257
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from concurrent.futures import ThreadPoolExecutor
    from time import sleep

    def get_fib(n):
        a, b = 0, 1
        for i in range(n):
            a, b = b, a + b
        return a
    #

    def get_fib_timeout(n):
        from time import sleep
        sleep(10)
        return get_fib(n)

    def submit(n):
        return MonoWorker().submit(get_fib_timeout, n*n)
    #


# Generated at 2022-06-22 05:17:51.128630
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .tests_common import _raise
    from ..utils import _range
    MonoWorker()  # constructor
    mw = MonoWorker()
    assert len(mw.pool._threads) == 1
    assert len(mw.futures) == 0
    assert mw.futures.maxlen == 2
    f = mw.submit(_raise, TypeError)
    with tqdm_auto.external_write_mode():
        f.result()
    f = mw.submit(tqdm_auto.sleep, 0.1)
    with tqdm_auto.external_write_mode():
        f.result()
    mw.futures.extend([None, None])

# Generated at 2022-06-22 05:18:00.336533
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from .common import _test_except

    _test_except(None, "", MonoWorker)
    mw = MonoWorker()
    _test_except(mw, "", mw.submit)
    _test_except(mw, "1", mw.submit, lambda x: x, 1.0)
    _test_except(mw, "2", mw.submit, lambda x: x, 1)
    _test_except(mw, "3", mw.submit, lambda x: x, "3")

if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:19:03.183632
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import time
    from . import sleep

    from ..utils import _range
    from ..tqdm_gui import tqdm

    def test_func(sleep_time):
        sleep(sleep_time * 0.01)  # sleep <&> pool
        return sleep_time

    worker = MonoWorker()
    start = time()
    with tqdm(_range(10), desc="sleeps") as t:
        for i, sleep_time in enumerate(t):
            assert worker.submit(test_func, sleep_time).result() == sleep_time
            assert worker.futures[0] == worker.futures[-1]

# Generated at 2022-06-22 05:19:04.458100
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.pool
    assert not mw.futures



# Generated at 2022-06-22 05:19:15.393871
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    import time

    mw = MonoWorker()

    class Task(object):
        def __init__(self, i):
            self.i = i
            self.done_ = False

        def __call__(self):
            time.sleep(random.random() * .1)
            self.done_ = True

    tasks = [Task(i) for i in range(10)]
    for i in range(10):
        mw.submit(tasks[i])
        time.sleep(.1)
        assert sum(t.done_ for t in tasks[:i + 1]) <= 1
    for t in tasks:
        assert t.done_

    # show coverage
    mw.future = None
    assert mw.submit(lambda x: x, 3) is None

# Generated at 2022-06-22 05:19:26.348806
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from .utils import UserList

    m = MonoWorker()

    def f(i, delay):
        sleep(delay)
        return [i, delay]

    def i(i, delay):
        sleep(delay)
        raise Exception

    def g():
        sleep(0.2)
        return []

    m.submit(g)
    u = UserList()
    m.submit(u.append, [1, 2])
    sleep(0.1)
    m.submit(u.append, [2, 3])
    assert u.data == [2, 3]
    m.submit(u.append, [3, 4])
    sleep(0.2)
    assert u.data == [3, 4, 4, 3]