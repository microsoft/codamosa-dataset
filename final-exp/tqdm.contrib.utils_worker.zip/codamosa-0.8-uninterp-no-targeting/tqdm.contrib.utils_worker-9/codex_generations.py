

# Generated at 2022-06-22 05:09:20.641214
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    worker = MonoWorker()
    assert worker is not None
    assert worker.futures.maxlen == 2


# Generated at 2022-06-22 05:09:25.499660
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    def echo(s, n=0.1):
        time.sleep(n)
        return s
    mono = MonoWorker()
    for i in range(5):
        mono.submit(echo, str(i))
    res = [f.result() for f in mono.futures]
    assert res == [str(4), str(4)]



# Generated at 2022-06-22 05:09:37.214412
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import multiprocessing

    def foo():
        return "done"

    dummy_worker = MonoWorker()

    dummy_worker.submit(foo)
    dummy_worker.submit(foo)
    dummy_worker.submit(foo)
    dummy_worker.submit(foo)
    dummy_worker.submit(foo)
    dummy_worker.submit(foo)

    dummy_worker.submit(foo)
    dummy_worker.submit(foo)
    dummy_worker.submit(foo)
    dummy_worker.submit(foo)
    dummy_worker.submit(foo)
    dummy_worker.submit(foo)

    dummy_worker.submit(foo)
    dummy_worker.submit(foo)
    dummy_worker.submit(foo)
    dummy_worker.submit(foo)

# Generated at 2022-06-22 05:09:46.975490
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import random
    from time import sleep

    import sys

    def idempotent_sleep(duration):
        sleep(duration)
        return duration

    def nothing():
        pass

    mw = MonoWorker()
    assert len(mw.futures) == 0

    mw.submit(nothing)
    assert len(mw.futures) == 0

    mw.submit(nothing)
    assert len(mw.futures) == 1

    f = mw.submit(idempotent_sleep, random())
    assert len(mw.futures) == 1
    assert f.running()
    assert f.done() is False

    sleep(2)
    assert f.done() is True
    assert f.result() > 0
    assert len(mw.futures) == 0

# Generated at 2022-06-22 05:09:57.611459
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Test Constructor
    mono_worker = MonoWorker()

    # Test submit
    def noop(*args, **kwargs):
        return 0

    def arg_func(arg):
        return arg
    expected_value = 3
    mono_worker.submit(arg_func, expected_value)
    # Test: simplest function can be called
    assert(mono_worker.futures.pop().result() == expected_value)

    # Test that:
    # 1. MonoWorker has at most 1 running and 1 waiting task
    # 2. MonoWorker does not create unwanted tasks
    # 3. MonoWorker discards the least recent task when queue is full
    for i in range(3):
        running = mono_worker.submit(noop)
        if i == 1:
            running.result()
        waiting = mono_

# Generated at 2022-06-22 05:10:04.992692
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    def print_arg(arg):
        print(arg)

    mw = MonoWorker()
    for i in range(5):
        mw.submit(sleep, i)
        mw.submit(print_arg, i)
    for i in range(5):
        future = mw.submit(sleep, i)
        future.result()

# Generated at 2022-06-22 05:10:14.675684
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing import Process, Manager
    from time import sleep
    from contextlib import contextmanager
    from random import random

    @contextmanager
    def wait_for(test, delay=0.1):
        for _ in range(int(2 ** 16 / delay)):
            yield
            if test():
                return

    args = (1, 2, 3)
    kwargs = {'a': 1, 'b': 2, 'c': 3}
    def f(args, kwargs):
        # print(args, kwargs)
        sleep(random())
        return args, kwargs

    with Manager() as manager:
        q = manager.Queue(1)
        def worker(args, kwargs):
            q.put(MonoWorker().submit(f, args, kwargs).result())


# Generated at 2022-06-22 05:10:21.310420
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from concurrent.futures import Future
    from ..utils import _term_move_up
    def func(*args, **kwargs):
        time.sleep(1e-3)
        return args, kwargs
    mw = MonoWorker()
    assert len(mw.futures) == 0
    # only one task at a time
    with tqdm_auto._lock:
        f1 = mw.submit(func, 1, foo=2, bar=3)
        time.sleep(1e-3)
        f2 = mw.submit(func, 4, foo=5, bar=6)
        time.sleep(1e-3)
        f3 = mw.submit(func, 7, foo=8, bar=9)

# Generated at 2022-06-22 05:10:29.378947
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def a(x=4):
        import time
        time.sleep(1)
        return x

    def b(x=6):
        import time
        time.sleep(1)
        return x + 1

    mono = MonoWorker()
    assert len(mono.futures) == 0
    assert mono.pool._work_queue.qsize() == 0

    future_a = mono.submit(a)
    assert len(mono.futures) == 1
    assert mono.pool._work_queue.qsize() == 1

    future_b = mono.submit(b)
    assert len(mono.futures) == 2
    assert mono.pool._work_queue.qsize() == 2

    future_c = mono.submit(a)
    assert len(mono.futures) == 2

# Generated at 2022-06-22 05:10:29.781765
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    assert MonoWorker()

# Generated at 2022-06-22 05:10:40.127964
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    m = MonoWorker()
    assert len(m.futures) == 0
    m.submit(time.sleep, 1)
    assert len(m.futures) == 1
    m.submit(time.sleep, 1)
    assert len(m.futures) == 1  # previous running task will be discarded


# Generated at 2022-06-22 05:10:40.901681
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()



# Generated at 2022-06-22 05:10:42.955501
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    MonoWorker()



# Generated at 2022-06-22 05:10:52.955085
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event
    from multiprocessing import Pool

    def test_func(a, b, done=None):
        """Sleeps for a seconds then returns a+b."""
        sleep(a)
        if done is not None:
            done.set()
        return a + b
    done = Event()
    mw = MonoWorker()
    fut = mw.submit(test_func, 0.01, 1, done)
    assert not fut.done()
    fut.result()

    def test_func_fail():
        """Raises exception."""
        raise RuntimeError("test_func_fail")
    mw = MonoWorker()
    assert mw.submit(test_func_fail) is None


# Generated at 2022-06-22 05:10:54.774797
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit-test constructor of class MonoWorker"""
    MonoWorker()  # simple constructor
    MonoWorker()  # global singleton



# Generated at 2022-06-22 05:11:04.177866
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    from time import sleep
    from . import MONO_WORKER

    def wait(dur):
        sleep(dur)
        return "checked"

    e = Event()
    e.clear()
    assert MONO_WORKER._pool._threads_queues
    assert not MONO_WORKER.futures
    assert not e.is_set()
    f0 = MONO_WORKER.submit(e.set)
    assert f0.done()
    assert not e.is_set()
    f1 = MONO_WORKER.submit(wait, 0.5)  # replace f0
    assert f1.done()
    assert not e.is_set()
    f2 = MONO_WORKER.submit(wait, 0.5)  # replace f1
    assert f

# Generated at 2022-06-22 05:11:10.538813
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from tqdm.contrib.concurrent import MonoWorker

    def slow_function(a, b):
        sleep(a)
        return a + b

    worker = MonoWorker()
    future = worker.submit(slow_function, 1, b=1)
    assert future.result() == 2
    future = worker.submit(slow_function, 2, b=2)
    assert future.result() == 4

    future = worker.submit(slow_function, 2, b=2)
    future2 = worker.submit(slow_function, 1, b=1)
    assert future.result() == 4
    assert future2.result() == 2

    future = worker.submit(slow_function, 2, b=2)
    future2 = worker.submit(slow_function, 1, b=1)

# Generated at 2022-06-22 05:11:21.558430
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # Empty case
    mono = MonoWorker()
    mono.submit(lambda: 'foo')
    assert len(mono.futures) == 1
    running = mono.futures.popleft()
    assert running.result() == 'foo'
    assert len(mono.futures) == 0

    # Replace waiting
    mono.submit(lambda: 'foo')
    mono.submit(lambda: 'bar')
    assert len(mono.futures) == 1
    running = mono.futures.popleft()
    assert running.result() == 'bar'
    assert len(mono.futures) == 0

    # Let running finish
    mono.submit(lambda: 'foo')
    mono.submit(lambda: 'bar')
    assert len(mono.futures) == 1


# Generated at 2022-06-22 05:11:31.938075
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from concurrent.futures import TimeoutError

    mw = MonoWorker()

    def slow(v):
        sleep(.5)
        return v

    def fail():
        raise ValueError('fail does fail')

    assert mw.submit(slow, 'run').result() == 'run', "run did not run"
    assert mw.submit(slow, 'discard-1').result() == 'discard-1', "discard-1 was not discarded"
    assert mw.submit(slow, 'discard-2').result() == 'discard-2', "discard-2 was not discarded"
    # check that run is still running

# Generated at 2022-06-22 05:11:40.248698
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def tester(timeout=0):
        import time
        time.sleep(timeout)
        return timeout
    test_queue = MonoWorker()
    running = test_queue.submit(tester, 0.5)
    waiting = test_queue.submit(tester, 0.5)
    assert running.done() == False
    f = running.result()
    assert f == 0.5
    assert waiting.done() == True
    assert waiting.cancel() == False


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:11:55.002058
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-22 05:12:06.711105
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def func_c():
        import time
        time.sleep(1)
        return 5

    def func_d():
        import time
        time.sleep(2)
        return 5

    import time
    mono = MonoWorker()

    # mono.submit(func_c)
    # mono.submit(func_c)
    # mono.submit(func_d)
    # mono.submit(func_d)
    # mono.submit(func_d)
    # mono.submit(func_d)
    # mono.submit(func_d)
    from concurrent.futures import Future
    futures = []
    futures.append(mono.submit(func_c))
    time.sleep(0.5)
    futures.append(mono.submit(func_d))
    time.sleep(0.5)

# Generated at 2022-06-22 05:12:15.348788
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import tqdm

    def delay(x):
        time.sleep(x)
        return x

    mw = MonoWorker()
    t = tqdm.tqdm()
    for x in t:
        mw.submit(delay, x / 20)
        if x > 1:
            futures = mw.futures
            if len(futures) > 1:
                # Check that only the newest running is retained
                assert set([futures[1].done(), futures[0].done()]) == \
                    set([False, True])
            if x > 3:
                break



# Generated at 2022-06-22 05:12:27.317344
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import threading
    import time
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.worker = MonoWorker()
            self.q = []
            self.lock = threading.Lock()
        def test_submit(self):
            def atomic(func):
                """Thread-safe execution of `func` w/ `self.lock`."""
                with self.lock:
                    func()
            def _wait(duration, name):
                time.sleep(duration)  # time-consuming task
                atomic(lambda: self.q.append(name))
            def sleep_sort(nums):
                for idx, num in enumerate(nums):
                    self.worker.submit(_wait, num, idx)

# Generated at 2022-06-22 05:12:39.147289
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from datetime import datetime
    from time import sleep
    from .tests import fake_enumerate

    mw = MonoWorker()

    def print_time(seconds, num, text):
        sleep(seconds)
        tqdm_auto.write('{0} - {1}: {2}'.format(datetime.now(), num, text))
    tasks = ['first', 'second', 'third']
    with tqdm_auto(total=len(tasks), ncols=70) as t:
        for _ in fake_enumerate(tasks, delay=0.5, unit='tasks'):
            mw.submit(print_time, seconds=1, num=t.n, text=tasks[t.n - 1])
            sleep(0.3)  # pause between tasks



# Generated at 2022-06-22 05:12:45.984278
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import sys

    def f(n):
        for i in range(n):
            time.sleep(0.01)
            sys.stderr.write('.')

    # create MonoWorker
    mw = MonoWorker()

    # submit f(40)
    mw.submit(f, 40)
    # submit f(20)
    mw.submit(f, 20)
    # submit f(20)
    mw.submit(f, 20)

    # wait for all tasks
    mw.pool.shutdown(wait=True)
    # Output:
    # ..

# Generated at 2022-06-22 05:12:55.658467
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """test MonoWorker's method submit"""
    class FooWorker(MonoWorker):
        def __init__(self):
            MonoWorker.__init__(self)
            self.num_called = 0

        def foo(self, *args, **kwargs):
            self.num_called += 1
            yield

    fw = FooWorker()
    for i in tqdm_auto.trange(10, desc="add"):
        fw.submit(fw.foo)
    for i in tqdm_auto.trange(5, desc="clear"):
        fw.submit(fw.foo)
    for i in tqdm_auto.trange(5, desc="bar"):
        fw.submit(fw.foo)
    assert fw.num_called == 5

# Generated at 2022-06-22 05:13:04.173342
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from contextlib import contextmanager
    from tqdm import tqdm
    with tqdm_test_strings() as lines:
        @contextmanager
        def tqdm_e():
            lines.clear()
            with tqdm(desc="test") as t:
                yield t
                lines.append(lines.last_printed_line)
        with tqdm_e() as t:
            t.write("1")
        with tqdm_e() as t:
            t.write("2")
        with tqdm_e() as t:
            t.write("3")

# Generated at 2022-06-22 05:13:13.213576
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from concurrent.futures import wait
    import pytest

    def timeout_fib(n):
        sleep(n)
        return n

    mw = MonoWorker()
    assert mw.futures.maxlen == 2
    assert len(mw.futures) == 0

    a = mw.submit(timeout_fib, 4)
    assert len(mw.futures) == 1

    b = mw.submit(timeout_fib, 3)
    assert len(mw.futures) == 1

    c = mw.submit(timeout_fib, 2)
    assert len(mw.futures) == 1

    d = mw.submit(timeout_fib, 1)
    assert len(mw.futures) == 1

   

# Generated at 2022-06-22 05:13:20.285534
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from test_tqdm import pretest_posttest

    def method(arg):
        return arg

    def test(arg, **kwargs):
        with pretest_posttest(kwargs) as (p, _):
            worker = MonoWorker()
            assert worker.submit(method, arg)
            # Should not replace the running task
            assert not worker.submit(method, arg)
            assert not worker.submit(method, arg)
            assert len(worker.futures) == 1

    test(0)
    test(1)
    test(2)
    test(3)

# Generated at 2022-06-22 05:13:36.673894
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from collections import deque
    from concurrent.futures import ThreadPoolExecutor

    # Basic functionality
    dut = MonoWorker()
    assert (isinstance(dut, object))
    assert (isinstance(dut.pool, ThreadPoolExecutor))
    assert (isinstance(dut.futures, deque))

    def delayed_return(x):
        sleep(1)
        return x * 2

    # Basic submit
    assert (dut.futures.maxlen == 2)
    f1 = dut.submit(delayed_return, 3)
    assert (len(dut.futures) == 1)
    assert (f1.result() == 6)
    assert (len(dut.futures) == 0)

    # Test task replacement

# Generated at 2022-06-22 05:13:46.306614
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from time import time
    from itertools import count

    mw = MonoWorker()
    list_of_times = []
    def timed_sleep(dur):
        start = time()
        sleep(dur)
        list_of_times.append(time() - start)
    future = mw.submit(timed_sleep, 0.1)
    # this should be running, but not waiting:
    assert(future.running())
    assert not future.done()
    assert( not len(mw.futures))
    sleep(0.2)
    assert(future.done())
    assert(not future.running())
    assert_allclose(list_of_times, [0.1], atol=0.05)

    # now we're running, and waiting (because we submit

# Generated at 2022-06-22 05:13:56.042565
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import operator

    def test_func(a, b):
        time.sleep(a)
        return a, b

    def timed_test_func(*args):
        tic = time.time()
        result = test_func(*args)
        toc = time.time()
        return toc - tic, result

    def test_that(x, y, *args):
        tic = time.time()
        result = timed_test_func(x, y)
        toc = time.time()
        assert operator.eq(result, (x, (x, y)))
        time.sleep(x)
        assert operator.eq(result, (x, (x, y)))
        return (toc - tic, result)

    worker = MonoWorker()


# Generated at 2022-06-22 05:14:05.912029
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    import multiprocessing as mp

    def raise_exception(exc, seconds):
        time.sleep(seconds)
        raise exc

    def raise_exception_random():
        import random
        raise_exception(ValueError, random.random() / 4)

    def task_counter(seconds):
        time.sleep(seconds)
        return seconds

    if __name__ == '__main__':
        with mp.Pool() as p:
            assert (p.map(task_counter, [0.1, 0.1, 0.1, 0.1])) == [0.1, 0.1, 0.1, 0.1]

    import tqdm
    worker = MonoWorker()


# Generated at 2022-06-22 05:14:11.914238
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    def run_futures(futures, n=None, attempts=0):
        n = n or len(futures)
        if n == 0:
            return
        if attempts > 8:
            raise Exception("All tasks were still pending. Aborting!")
        for f in futures:
            if f.done():
                f.result()  # raises any exceptions
        run_futures(futures, n - 1, attempts + 1)

    import time

    def func1(arg):
        time.sleep(0.01)
        return arg

    def func2(arg):
        time.sleep(0.03)
        return arg

    def func3(arg):
        time.sleep(0.1)
        return arg

    mw = MonoWorker()


# Generated at 2022-06-22 05:14:17.040334
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.futures.maxlen == 2
    import socket
    try:
        socket.setdefaulttimeout(2)
        mw.submit(socket.gethostbyname, "localhost")
        assert len(mw.futures) == 1
    finally:
        socket.setdefaulttimeout(None)

# Generated at 2022-06-22 05:14:27.282890
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import sys
    import threading
    from ..utils import _range

    class throwException(Exception):
        pass

    N = 10
    MUL = 3

    def foo(n):
        time.sleep(0.01)
        if n != N:
            raise throwException('FAIL')

    for n in _range(N):
        time.sleep(0.005)
        mw = MonoWorker()
        mw.submit(foo, n)

    time.sleep(0.3)

    for n in _range(N, N * MUL):
        time.sleep(0.005)
        mw = MonoWorker()
        mw.submit(foo, n)

    tic = time.time()
    time.sleep(0.1)
    toc = time.time()


# Generated at 2022-06-22 05:14:34.535665
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()
    #
    def dummy(i, j):
        time.sleep(0.2)
        return i + j
    assert mw.submit(dummy, 1, 2).result() == 3
    #
    assert mw.submit(dummy, 2, 3).result() == 5
    #
    assert mw.submit(dummy, 3, 4).result() == 5
    assert mw.submit(dummy, 4, 5).result() == 7

# Generated at 2022-06-22 05:14:35.687756
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    return mw


# Generated at 2022-06-22 05:14:42.377197
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test MonoWorker (multiprocessing thread pool)."""
    from random import random
    from time import sleep
    mw = MonoWorker()

    def f1(x):
        sleep(x)
        return random()

    def f2(x):
        sleep(x)
        raise Exception('f2 exception')

    def f3(x):
        sleep(x)
        return 1

    promises = []
    promises.extend([mw.submit(f1, 1) for _ in range(4)])
    promises.extend([mw.submit(f2, 1) for _ in range(4)])
    promises.extend([mw.submit(f3, 0.5) for _ in range(4)])
    for p in promises:
        if not p.cancelled():
            print

# Generated at 2022-06-22 05:15:01.718846
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from sys import exc_info, stderr
    from time import sleep
    from traceback import print_exception

    def print_exc(exc):
        print_exception(
            type(exc), exc, exc_info()[2], file=stderr,
            limit=tqdm_auto.default_mininterval)

    def same_name(name, func):
        return func.__name__.startswith(name)

    def func(n):
        sleep(n)
        return n

    def func_raise(*args, **kwargs):
        raise RuntimeError("func_raise")

    def func_print(*args, **kwargs):
        print("func_print:", args, kwargs)
        return 0.5


# Generated at 2022-06-22 05:15:03.605215
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.futures.maxlen == 2

# Generated at 2022-06-22 05:15:08.237245
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    import pandas as pd
    mw = MonoWorker()

    def _init(a):
        sleep(0.5)
        return pd.DataFrame([1, 2, 3])

    df = mw.submit(_init, 1)
    assert df is not None, 'DF should not be empty'

    # should throw error while submitting second task while first one is not finished
    df = mw.submit(_init, 2)
    assert df is None, 'DF should be empty'

# Generated at 2022-06-22 05:15:19.371475
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random

    def run_simple(secs):
        time.sleep(secs)
        return secs

    def run_bad(secs):
        time.sleep(secs)
        raise Exception('sleep {} seconds'.format(secs))

    def run_very_bad():
        raise Exception('immediately bad')

    def run_except(secs):
        time.sleep(secs)
        1//0

    def run_cancel(secs):
        time.sleep(secs)
        return 'cancelled'

    print('Running unit test for MonoWorker.submit.\n'
          'Check that long waiting tasks are replaced.\n\n')
    worker = MonoWorker()
    secs_max = 3
    secs_min = 1

# Generated at 2022-06-22 05:15:30.229875
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from ..utils import format_sizeof
    from pkg_resources import resource_stream
    from shutil import copyfileobj
    from tempfile import NamedTemporaryFile
    from tqdm import trange
    with resource_stream('tqdm', 'tests/3 MiB.txt') as f1:
        with NamedTemporaryFile(delete=False) as f2:
            copyfileobj(f1, f2)
    with open(f2.name, 'r') as f2:

        def read(f):
            return sum(1 for _ in tqdm_auto.tqdm(f, unit='B'))

        def read_queue(q):
            res = [0]
            for _ in trange(q.qsize()):
                res[0] += q.get().result()

# Generated at 2022-06-22 05:15:39.103172
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from collections import namedtuple
    from contextlib import contextmanager
    from threading import Thread
    from unittest import TestCase, main
    from subprocess import Popen, PIPE, STDOUT

    with open("test_mono.py", "wb") as f:
        f.write("#!/usr/bin/env python3\nimport time\nwhile True:\n\ttime.sleep(9999)\n".encode())
    p = Popen(["chmod", "+x", "test_mono.py"], stdout=PIPE, stderr=STDOUT)
    _, _ = p.communicate()

    @contextmanager
    def wait_threads(t, timeout=2):
        t.join(timeout)

# Generated at 2022-06-22 05:15:42.365038
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert len(mw.pool._threads) == 1
    assert len(mw.futures) == 0


# Generated at 2022-06-22 05:15:54.432502
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # test replacement of waiting task
    from time import sleep
    from threading import Lock
    from contextlib import contextmanager
    lock = Lock()
    with contextmanager(lock) as _hold_lock:
        worker = MonoWorker()
        print(worker.futures)

        def hit_lock(name):
            print('{} waiting...'.format(name))
            sleep(2)
            with _hold_lock:
                print('{} locking...'.format(name))
                sleep(2)

        worker.submit(hit_lock, 'task1')
        print(worker.futures)
        worker.submit(hit_lock, 'task2')
        print(worker.futures)
        worker.submit(hit_lock, 'task3')
        print(worker.futures)

# Generated at 2022-06-22 05:15:56.181877
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mono = MonoWorker()
    # make sure we can successfully submit at least one function
    mono.submit(lambda: None)

# Generated at 2022-06-22 05:16:06.263342
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Unit test for method submit of class MonoWorker"""
    import os
    import random
    import time
    import threading

    def download_file(name, url, output_file, bar=None):
        urlopen = url_fetch_wrapper(url)

# Generated at 2022-06-22 05:16:31.076244
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time, sys, os
    tqdm_auto.write("*** TEST START ***")
    mw = MonoWorker()
    rand = lambda: time.sleep(0.1 * (1 + random.random()))
    n = 0
    _runs = 5

    def f(i):
        rand()
        sys.stderr.write("<<< %d " % i)
        return i

    for _ in range(_runs):
        for j in range(2):
            i = n
            tqdm_auto.write(">>> %d" % i)
            ftr = mw.submit(f, i)
            n += 1
            ftr.result()
            tqdm_auto.write(">>> %d" % i)

# Generated at 2022-06-22 05:16:40.916027
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker."""
    from multiprocessing import cpu_count
    from time import sleep
    from random import random
    from collections.abc import Iterable
    workers = cpu_count()

    def func(x):
        """Return a random number after sleeping for x seconds."""
        sleep(x)
        return random()

    # Test efficient single-tasking
    t = MonoWorker()
    assert len(t.futures) == 0
    assert len(t._pool._threads) == 0

    f1 = t.submit(func, workers)
    assert len(t.futures) == 1
    assert len(t._pool._threads) == 1

    f2 = t.submit(func, workers)
    assert len(t.futures) == 1
    assert len

# Generated at 2022-06-22 05:16:45.379287
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    mw = MonoWorker()
    assert mw.pool
    assert mw.futures
    assert not mw.futures.maxlen
    assert not len(mw.futures)


# Generated at 2022-06-22 05:16:55.680201
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import queue
    import random

    def long_task(task_id, sleep_time):
        tqdm_auto.write('Start long task {0} after {1} seconds'
                        .format(task_id, sleep_time))
        time.sleep(sleep_time)
        tqdm_auto.write('Finish long task {0}'.format(task_id))

    def long_task2(task_id, sleep_time, q):
        tqdm_auto.write('Start long task {0} after {1} seconds'
                        .format(task_id, sleep_time))
        time.sleep(sleep_time)
        tqdm_auto.write('Finish long task {0}'.format(task_id))
        q.put('Task {0} is done'.format(task_id))

# Generated at 2022-06-22 05:17:00.992267
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    # We want predictable results for testing
    import numpy as np
    np.random.seed(1234567890)

    def bar(x):
        sleep(np.random.rand())
        return 2 * x

    W = MonoWorker()
    for i in tqdm_auto.trange(10, ncols=80, ascii=True, desc='t1'):
        W.submit(bar, i)


if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:17:10.444590
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    class Sleep(object):
        def __init__(self):
            self.recorded = []
        def record(self, i):
            time.sleep(0.5)
            self.recorded.append(i)
    mw = MonoWorker()
    s = Sleep()
    mw.submit(s.record, 1)
    mw.submit(s.record, 2)
    mw.submit(s.record, 3)
    time.sleep(1)
    assert len(s.recorded) == 1
    assert s.recorded[0] == 3
    time.sleep(1.5)
    assert len(s.recorded) == 2
    assert s.recorded[1] == 3

# Generated at 2022-06-22 05:17:14.928365
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def worker(a, b):
        from time import sleep
        sleep(1)
        return (a, b)
    worker_ = MonoWorker()
    for i in tqdm_auto.trange(10):
        worker_.submit(worker, "a", 1)
    assert len(worker_.futures) == 1
    assert worker_.futures[0].result() == ("a", 1)

# Generated at 2022-06-22 05:17:24.047048
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    worker = MonoWorker()
    sleep_ = lambda: sleep(0.1)

    def test_running():
        worker.submit(sleep_)
        assert len(worker.futures) == 1
        worker.submit(sleep_)
        assert len(worker.futures) == 1
        assert not worker.futures[0].done()
        sleep()
        assert worker.futures[0].done()
        assert not worker.futures[0].cancelled()
        assert not worker.futures[0].exception()

    def test_running_cancellation():
        worker.submit(sleep_)
        assert len(worker.futures) == 1
        worker.submit(sleep_)
        assert len(worker.futures) == 1

# Generated at 2022-06-22 05:17:28.054145
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from .tqdm_test_classes import TestMonitor

    monitor = TestMonitor()
    monitor.monitor()

    # Test
    def f():
        time.sleep(1)
        monitor.__exit__(None, None, None)
        return 10

    mw = MonoWorker()
    with monitor:
        x = mw.submit(f)
        assert x.result() == 10

# Generated at 2022-06-22 05:17:38.586049
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from random import randint
    from multiprocessing import cpu_count
    import time
    # Redirect output to stdout
    import sys
    old_stdout = sys.stdout
    sys.stdout = sys.__stdout__

    def wait(sec):
        time.sleep(sec)
        return sec

    MONOWORKER = MonoWorker()
    results = [0] * cpu_count()
    for i in range(cpu_count()*2):
        if i < cpu_count():
            results[i] = MONOWORKER.submit(wait, randint(1, cpu_count()))
        else:
            MONOWORKER.submit(wait, randint(1, cpu_count()))
    # Should be ~= to cpu_count()

# Generated at 2022-06-22 05:18:10.835104
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    mw = MonoWorker()

    def f(x):
        sleep(x)
        return x + 1

    r1 = mw.submit(f, 1)
    r2 = mw.submit(f, 2)
    assert (r1.result() == 2)  # will block
    assert (r2.result() == 3)

# Generated at 2022-06-22 05:18:22.485324
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def func():
        time.sleep(.01)

    t = MonoWorker()
    t.submit(func)
    t.submit(lambda: True)
    t.submit(func)
    t.submit(lambda: False)
    assert True and t.futures
    time.sleep(.05)
    assert len(t.futures) == 1 and True in t.futures
    time.sleep(.1)
    assert len(t.futures) == 0
    t.submit(func)
    t.submit(lambda: True)
    t.submit(func)
    t.submit(lambda: False)
    time.sleep(.1)
    assert len(t.futures) == 1 and False in t.futures
    time.sleep(.1)


# Generated at 2022-06-22 05:18:33.877144
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    
    # Create a worker
    worker = MonoWorker()
    assert worker.pool.max_workers == 1
    assert len(worker.futures) == 0

    # 1st call (no-thread)
    result = worker.submit(time.sleep, 1)
    assert len(worker.futures) == 1
    result.result()
    assert len(worker.futures) == 1

    # 2nd call (thread)
    result = worker.submit(time.sleep, 1)
    assert len(worker.futures) == 2
    result.result()
    assert len(worker.futures) == 1

    # 3rd call (thread)
    result = worker.submit(time.sleep, 1)
    assert len(worker.futures) == 2
    result.result()


# Generated at 2022-06-22 05:18:41.968882
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Lock
    lock = Lock()

    def foo(x):
        sleep(0.2)
        with lock:
            tqdm_auto.write(x)

    mw = MonoWorker()
    mw.submit(foo, 'running')
    sleep(0.1)
    mw.submit(foo, 'waiting')
    sleep(0.1)
    mw.submit(foo, 'waiting2')  # waiting is discarded
    mw.submit(foo, 'waiting3')  # waiting2 is discarded

# Generated at 2022-06-22 05:18:53.693370
# Unit test for constructor of class MonoWorker
def test_MonoWorker():  # pragma: no cover
    from time import sleep
    from .utils import _print_target_count

    def _func(msg):
        _print_target_count(msg)
        sleep(1)

    mw = MonoWorker()
    print("Submitting:")
    mw.submit(_func, "f1")
    sleep(0.01)
    print("Submitting:")
    mw.submit(_func, "f2")
    sleep(0.01)
    print("Submitting:")
    mw.submit(_func, "f3")
    sleep(0.01)
    print("Submitting:")
    mw.submit(_func, "f4")
    sleep(0.01)
    print("Submitting:")
    mw.submit(_func, "f5")

# Generated at 2022-06-22 05:19:02.578606
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from traceback import print_exc
    import sys

    def func1(wait):
        sleep(wait)
        while True:
            try:
                print(sys.stdin.readline(), end='')
            except KeyboardInterrupt:
                break

    def func2():
        while True:
            try:
                print(sys.stdin.readline(), end='')
            except KeyboardInterrupt:
                break

    mono = MonoWorker()
    tqdm_auto.write("Submitting func1(2)")
    mono.submit(func1, 2)
    tqdm_auto.write("Submitting func1(1)")
    mono.submit(func1, 1)
    tqdm_auto.write("Submitting func2")

# Generated at 2022-06-22 05:19:13.977380
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # Must run the following command before the test:
    # $ export UNIT_TEST_IGNORE_TIME=1
    from time import sleep

    def echo(*args, **kwargs):
        sleep(1)
        return tuple(args), kwargs

    mw = MonoWorker()
    f1 = mw.submit(echo, 1, x=1)
    f2 = mw.submit(echo, 2, x=2)
    f3 = mw.submit(echo, 3, x=3)
    assert (f1.result()[0] == (1,) and f1.result()[1] == dict(x=1))
    assert (f2.result()[0] == (3,) and f2.result()[1] == dict(x=3))
    assert f3.cancel()




# Generated at 2022-06-22 05:19:25.169293
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from multiprocessing import cpu_count
    from . import async_
    from .async_ import MonoWorker, AsyncObject
    from .async_ import future_map
    from .wrap_tqdm import tqdm
    from random import randint
    from time import sleep
    from timeit import timeit  # NOQA

    tqdm.set_lock(False)

    def task():
        sleep(randint(1, 3))
        return randint(0, 10)

    def do_task(tasks):
        """map over a list of tasks, with only one task running at a time"""
        with MonoWorker(max_workers=1) as p:
            for i, _ in enumerate(tqdm(tasks)):
                y = p.submit(task)