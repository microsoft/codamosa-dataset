

# Generated at 2022-06-22 05:09:29.524122
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import os
    import sys
    import time

    import pytest

    from tqdm.contrib.concurrency import MonoWorker

    def has_contrib_concurrency_deps():
        try:
            from concurrent.futures import ThreadPoolExecutor
        except ImportError:
            return False
        return True

    if not has_contrib_concurrency_deps():
        return  # noop

    # Test basic constructor and submit
    m = MonoWorker()
    assert len(m.futures) == 0
    assert m.pool._max_workers == 1
    assert hasattr(m.pool, '_work_queue')
    assert hasattr(m.pool, '_threads')
    p = m.submit(lambda: None)
    assert len(m.futures) == 1

# Generated at 2022-06-22 05:09:40.890057
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import current_thread

    import sys
    if sys.version_info < (3, 0, 0):
        from Queue import Queue
    else:
        from queue import Queue
    from multiprocessing import Process

    def provider(q, worker):
        def save_thread_id(worker):
            worker.thread_id = id(current_thread())

        # Set thread_id
        worker.submit(save_thread_id, worker)
        worker.futures[0].result()

        # Start tasks
        for i in range(5):
            worker.submit(sleep, 0.5)
            q.put((id(current_thread()), worker.futures[0].result()))
            sleep(0.5)

    q = Queue()
    worker = Mono

# Generated at 2022-06-22 05:09:49.166945
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import unittest
    from ..utils import _range

    class Test_MonoWorker_submit(unittest.TestCase):
        def test_func_returning(self):
            def func(*args, **kwargs):
                time.sleep(0.1)
                return args, kwargs

            mw = MonoWorker()
            self.assertEqual(len(mw.futures), 0)

            for i in _range(3):
                ret = mw.submit(func, 1, 2, 3, a=4, b=5)
                self.assertEqual(ret.result(), ((1, 2, 3), {'a': 4, 'b': 5}))
                self.assertEqual(len(mw.futures), 0)


# Generated at 2022-06-22 05:09:59.238248
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import concurrent.futures

    worker = MonoWorker()
    def wait():
        time.sleep(0.1)
    def raise_():
        raise Exception("bad")


    worker.submit(wait)
    t = worker.submit(wait)
    t.cancel()


    with tqdm_auto.tqdm(desc="Testing", leave=False) as t:
        worker.submit(wait)
        t.update(1)
        worker.submit(raise_)
        t.update(1)
        worker.submit(raise_)
        t.update(1)
        worker.submit(wait)
        t.update(1)
        worker.submit(wait)
        t.update(1)
        worker.submit(wait)
        t.update(1)
        worker

# Generated at 2022-06-22 05:10:09.085936
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import subprocess
    import time
    import sys

    def cat(filename):
        with open(filename) as fd:
            while True:
                buf = fd.read(1000)
                if not buf:
                    break
                sys.stderr.write(buf)
                sys.stderr.flush()

    def write_to_file(filename, num_chars):
        with open(filename, 'w') as fd:
            print("x" * num_chars, file=fd)

    with open("delete_me_0.txt", "w") as fd:  # touch file
        pass

    mono = MonoWorker()
    mono.submit(cat, "delete_me_0.txt")
    mono.submit(cat, "non_existing_file.txt")

# Generated at 2022-06-22 05:10:18.514202
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for MonoWorker"""
    from time import sleep
    from contextlib import ExitStack
    from concurrent.futures._base import CancelledError

    def check_cancelled(future):
        with ExitStack() as stack:
            stack.callback(future.cancel)
            with stack.enter_context(tqdm_auto.tqdm()) as _t:
                while not future.done():
                    sleep(.1)
                    _t.update(10)
        assert future.cancelled(), "Waiting task not cancelled!"
        with stack.pop_all():
            pass

    def task_A(name):
        sleep(5)
        tqdm_auto.write("{} done".format(name))

    def task_B(name):
        raise ValueError("{} failed!".format(name))

# Generated at 2022-06-22 05:10:27.320406
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import Event

    def job_1():
        timer.wait()
        return "job_1"

    def job_2():
        return "job_2"

    def job_3():
        return "job_3"

    def job_4():
        timer.wait()
        return "job_4"

    def job_5():
        return "job_5"

    def job_6():
        timer.wait()
        return "job_6"

    timer = Event()
    worker = MonoWorker()

    # Scenario:
    # - All jobs are submitted one after the other
    # - The timer ensures that job_1, job_4 and job_6 take 50ms to complete
    # Expected result:
    # - job_2 is the only job that is discarded as it

# Generated at 2022-06-22 05:10:29.646058
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from ..auto import tqdm

    m = MonoWorker()
    for i in tqdm(range(4), desc="outer loop"):
        future = m.submit(sleep, i)
        future.result()

# Generated at 2022-06-22 05:10:30.493086
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker."""

    MonoWorker()

# Generated at 2022-06-22 05:10:35.078743
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from ..utils import _supports_unicode
    from ..auto import tqdm as tqdm_auto

    t = tqdm_auto(leave=True)
    t.monitor_interval = 0

    # Create a variable with greater scope than `with` block
    if _supports_unicode:
        out = u'stuff'
    else:
        out = 'stuff'

    def print_stuff():
        time.sleep(0.1)
        print(out)
        time.sleep(0.2)

    # Singleton instance of MonoWorker
    worker = MonoWorker()

    with t:
        for _ in t:
            worker.submit(print_stuff)
            time.sleep(0.2)

    assert t.n == 5

# Generated at 2022-06-22 05:10:48.916906
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from random import random

    sleep_times = [random() for _ in range(4)]

    def sleeper(i):
        sleep(sleep_times[i])
        return i

    tqdm_auto.write('sleep times: ' + str(sleep_times))
    m = MonoWorker()
    for i in range(4):
        m.submit(sleeper, i)
    tqdm_auto.write('sleeper 0 returned: ' + str(m.futures[0].result()))
    tqdm_auto.write('sleeper 1 returned: ' + str(m.futures[1].result()))
    m.submit(sleeper, 4)
    tqdm_auto.write('sleeper 2 returned: ' + str(m.futures[1].result()))


# Generated at 2022-06-22 05:10:54.835825
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    def do_delay(n, i):
        sleep(n)
        return i

    mw = MonoWorker()
    for i in tqdm_auto.tqdm(range(10)):
        def callback(fut):
            print(fut.result())
        mw.submit(do_delay, i * 0.01, i).add_done_callback(callback)
    for f in mw.futures:
        f.result()

# Generated at 2022-06-22 05:10:59.199927
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    worker_concur = MonoWorker()
    assert worker_concur is not None
    assert worker_concur.pool is not None
    assert worker_concur.futures is not None


# Generated at 2022-06-22 05:11:07.212555
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    # import time
    import random
    # import threading
    import functools
    # import subprocess as sp

    def test_func(x, y, delay=None):
        # cmd = '{} {} {}'.format(x, y, delay)
        # ret = sp.check_output(cmd, shell=True)
        # return ret
        if delay is None:
            return (x, y)
        else:
            time.sleep(delay)
            return (x, y, delay)

    test_in = [(x, y, random.uniform(0.1, 0.4)) for x in range(5)
                                                for y in range(5)]
    random.shuffle(test_in)

    mw = MonoWorker()
    test_in_copy = test_in[:]

# Generated at 2022-06-22 05:11:11.662055
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker"""
    mw = MonoWorker()
    assert isinstance(mw.futures, deque)
    assert isinstance(mw.pool, ThreadPoolExecutor)
    assert mw.pool.max_workers == 1
    assert mw.futures.maxlen == 2


# Generated at 2022-06-22 05:11:22.322811
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from subprocess import Popen, PIPE, STDOUT
    from threading import Thread
    from time import sleep
    import unittest

    class TestMonoWorker(unittest.TestCase):
        def test(self):
            try:
                import psutil
            except ImportError:
                return
            m = MonoWorker()

            def worker(x):
                sleep(x)
                return x

            p = Popen(["ps", "aux"], stdout=PIPE, stderr=STDOUT)

            f1 = m.submit(worker, 0.1)
            f2 = m.submit(worker, 0.2)
            f3 = m.submit(worker, 0.1)

            pool_size = psutil.Process(m.pool._worker_handler._thread.ident) \
                .num_

# Generated at 2022-06-22 05:11:23.138454
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    a = MonoWorker()

# Generated at 2022-06-22 05:11:29.220044
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import random
    import time
    random.seed(0)
    def slow_incr(x):
        time.sleep(random.random() / 10)
        return x + 1

    worker = MonoWorker()
    assert worker.submit(slow_incr, 0).result() == 1
    assert worker.submit(slow_incr, 1).result() == 2
    assert worker.submit(slow_incr, 3).result() == 4

# Generated at 2022-06-22 05:11:37.053683
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from threading import current_thread
    w = MonoWorker()
    for i in [1, 2, 3, 4, 5]:
        w.submit(sleep, i)
        current_thread().join(0.01)
    assert w.futures[0].result() == 1
    assert not w.futures[1].cancelled()
    current_thread().join(0.01)
    assert w.futures[0].result() == 5
    assert not w.futures[1].cancelled()

# Generated at 2022-06-22 05:11:48.366484
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from random import random

    # Decorator for retrieving `futures` to check whether work is done
    def check_futures(func):
        def _wrapper(self):
            i = 0
            while True:
                result = func(self, i)
                if len(self.futures) == self.futures.maxlen:
                    break
                i += 1
                sleep(0.01)
            return result
        return _wrapper


    # dummy function
    def _add_random(x):
        sleep(random())
        return x + random()

    # Test MonoWorker()
    worker = MonoWorker()
    assert len(worker.futures) == 0

    # submit 1 task
    worker.submit(_add_random, random())

# Generated at 2022-06-22 05:12:03.784654
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    from concurrent.futures import TimeoutError
    from ..utils import _range

    def func(x):
        sleep(.1)
        return x**2

    def finished_count(mono):
        """Return the number of finished tasks (those for which
        either the result or the exception is available)."""
        return sum(map(lambda f: int(f.done()), mono.futures))

    def submit_one_by_one(mono):
        for i in _range(10):
            mono.submit(func, i)

        sleep(0.1)  # let's give it a chance to run once
        assert finished_count(mono) == 1
        sleep(0.3)  # and wait for the result to come out
        assert finished_count(mono) == 1



# Generated at 2022-06-22 05:12:14.750743
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import inspect

    def f(x):
        time.sleep(x)
        tqdm_auto.write('{} finished'.format(inspect.stack()[0][3]))
        return x

    def g(x):
        time.sleep(x)
        tqdm_auto.write('{} finished'.format(inspect.stack()[0][3]))
        return x

    mw = MonoWorker()
    running = mw.submit(f, 1)
    assert running.result() == 1
    assert len(mw.futures) == 0
    g1 = mw.submit(g, 3)
    assert g1.result() == 3
    assert len(mw.futures) == 0
    g2 = mw.submit(g, 5)
    g

# Generated at 2022-06-22 05:12:26.722358
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    mw = MonoWorker()
    time.sleep(0.1)  # wait for mw to start

    def f1(a):
        time.sleep(a)
        return 1

    def f2(a):
        time.sleep(a)
        return 2

    # submit f1 (wait: 1, run: None)
    r1 = mw.submit(f1, 1)
    assert len(mw.futures) == 1
    assert r1 is not None
    assert r1 in mw.futures
    assert not r1.done()

    r1.result()  # wait for r1 to complete
    assert len(mw.futures) == 0
    assert r1.done()

    # submit f1 (wait: 1, run: f1)
    r

# Generated at 2022-06-22 05:12:27.641999
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    # assert(True)
    pass

# Generated at 2022-06-22 05:12:39.551505
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():  # pragma: no cover
    import time
    from random import shuffle

    def test(i, *args, **kwargs):
        time.sleep(0.1 * (i % 5))
        return i

    # test insert
    import sys
    mw = MonoWorker()
    shuffle(range(10))
    for i in range(10):
        # print('I[{}]: {}'.format(i, i), file=sys.stderr)
        mw.submit(test, i, "hello", verbose=True)
    for f in mw.futures:
        # print('R[{}]: {}'.format(f.result(), f.result()), file=sys.stderr)
        assert f.result() == 9



# Generated at 2022-06-22 05:12:47.713693
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Unit test for constructor of class MonoWorker"""
    from . import thread_map, thread_apply
    from time import sleep
    from sys import version_info

    if version_info < (3, 0):
        from Queue import Queue, Empty
    else:
        from queue import Queue, Empty
    # single threaded: should finish in about 1.5sec
    for ret, _ in tqdm_auto(thread_apply(
            sleep, (1,), timeout=2.5, backend='threading')):
        pass

    def t(q):
        q.put(1)
        sleep(1)
        q.put(None)

    q = Queue()
    thread_map(t, (q,), backend='threading')
    assert q.get() is None

# Generated at 2022-06-22 05:12:49.053195
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """Test constructor of class MonoWorker"""
    assert MonoWorker()

# Generated at 2022-06-22 05:12:53.876777
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep

    def run(x):
        sleep(x)
        return x

    mw = MonoWorker()
    mw.submit(run, 0.1)
    mw.submit(run, 0.3)
    mw.submit(run, 0.5)

    assert mw.futures[0].result() == 0.5

# Generated at 2022-06-22 05:12:57.237610
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from concurrent.futures import Future
    from time import sleep
    def func(t):
        sleep(t)
        return "done"
    # noinspection PyTypeChecker
    assert isinstance(MonoWorker().submit(func, 0.5), Future)

# Generated at 2022-06-22 05:13:04.136809
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import threading
    from ..auto import tqdm as tqdm_auto

    # first argument is function
    # second argument is list of args
    # third argument is list of kwargs
    # fourth argument is expected results
    # fifth argument is string representing correct output

# Generated at 2022-06-22 05:13:14.859123
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()

    def func():
        time.sleep(0.1)
        return 0

    for _ in range(4):
        mw.submit(func)
    time.sleep(0.8)

# Generated at 2022-06-22 05:13:26.157262
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    mw = MonoWorker()

    def countdown(n, time=0.1):
        for i in tqdm_auto(range(n), leave=False):
            tqdm_auto.sleep(time)
            yield '{} - {}'.format(n, i)

    # Start running task
    assert len(mw.futures) == 0
    running = mw.submit(countdown, 5)
    assert len(mw.futures) == 1
    assert not running.done()

    # Start waiting task (replaces waiting task)
    assert len(mw.futures) == 1
    waiting = mw.submit(countdown, 1)
    assert len(mw.futures) == 2
    assert not waiting.done()

    # Start running task (replaces running task and cancels

# Generated at 2022-06-22 05:13:34.162777
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    def run(arg):
        time.sleep(1)
        return arg
    worker = MonoWorker()
    case1 = worker.submit(run, 'case1')
    worker.submit(run, 'case2')  # case2 replaces case1
    worker.submit(run, 'case3')  # case3 replaces case2
    assert case1.done()
    assert case1.result() == 'case1'

# Generated at 2022-06-22 05:13:42.217257
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def slow_square(x, wait=2):
        time.sleep(wait)
        return x ** 2

    worker = MonoWorker()

    future1 = worker.submit(slow_square, 2, .5)
    future2 = worker.submit(slow_square, 3, .5)
    future3 = worker.submit(slow_square, 4, .5)

    assert future1.done()
    assert not future2.done()
    assert future3.done()
    assert not future1.cancelled()
    assert not future2.cancelled()
    assert future3.cancelled()

    future2.result()

# Generated at 2022-06-22 05:13:47.180746
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    from ..auto import tqdm

    mw = MonoWorker()

    def timestring(delay):
        time.sleep(delay)
        return time.asctime()

    with tqdm(total=100, desc="100 secs test") as pbar:
        while pbar.n < pbar.total:
            pbar.write(mw.submit(timestring, 0.1).result())
            pbar.update()


# Generated at 2022-06-22 05:13:50.641683
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    m = MonoWorker()
    m.submit(time.sleep, 1000)
    m.submit(time.sleep, 1000)
    m.submit(time.sleep, 1000)
    m.submit(time.sleep, 1)
    assert len(m.futures) == 1
    assert not m.futures[0].done()
    time.sleep(0)  # yield
    assert len(m.futures) == 0

# Generated at 2022-06-22 05:13:58.755008
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    # (function, expected time of execution, error message)
    tasks = [
        (sleep, 0.5, "failure"),
        (sleep, 0.3, "failure"),
        (sleep, 0.1, "failure"),
        (sleep, 0.2, "failure")
    ]
    mw = MonoWorker()
    for (func, duration, msg) in tasks:
        mw.submit(func, duration)
    if len(mw.futures) != 1:
        raise Exception("Futures should contain exactly 1 element")
    mw.futures.pop()
    if len(mw.futures):
        raise Exception("Futures should be empty")

# Generated at 2022-06-22 05:14:08.733653
# Unit test for method submit of class MonoWorker

# Generated at 2022-06-22 05:14:15.178129
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep

    def g(i):
        sleep(0.1)
        return i

    monoWorker = MonoWorker()
    for i in range(10):
        monoWorker.submit(g,i)

    for f in monoWorker.futures:
        assert f.result()==9

if __name__ == "__main__":
    test_MonoWorker_submit()

# Generated at 2022-06-22 05:14:16.821207
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    pass



# Generated at 2022-06-22 05:14:41.110904
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    import math

    def really_important_heavy_task(n=100000):
        """A really important task which could block other tasks"""
        for i in tqdm_auto.tqdm(range(n)):
            time.sleep(0.000001)  # some work
            math.exp(0.1)  # some more work

    def test_func(n=100):
        """A test function"""
        for i in tqdm_auto.tqdm(range(n)):
            time.sleep(0.01)  # some work
            math.exp(0.1)  # some more work

    mw = MonoWorker()
    mw.submit(really_important_heavy_task, n=100000)

    test_func()



# Generated at 2022-06-22 05:14:51.689406
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from . import _range_of_progressables
    from .async_ import test_tqdm_async
    from . import test_tqdm

    ###########################################################################
    class DiscardTest(object):
        """
        Tests that `func(bar)` will be called once,
        with the most recently submitted `bar`.
        """
        def __init__(self, bar):
            self.bar = bar
            self.done = False

        def __call__(self):
            # A real method would perform some task,
            # and update the progress bar as it goes along
            time.sleep(0.2)
            self.bar.update()
            time.sleep(0.2)
            self.done = True

    ###########################################################################

# Generated at 2022-06-22 05:15:03.171026
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def test_inner(x):
        import time
        time.sleep(x)

    # test basic functionality
    mono_worker = MonoWorker()
    assert mono_worker.submit(test_inner, 1).result() == None
    assert mono_worker.submit(test_inner, 1).result() == None

    # test overwrite functionality
    mono_worker = MonoWorker()
    assert mono_worker.submit(test_inner, 1).result() == None
    assert mono_worker.submit(test_inner, 2).result() == None
    # test ThreadPoolExhaustedError
    mono_worker = MonoWorker()
    mono_worker.submit(test_inner, 1).result()
    mono_worker.submit(test_inner, 2).result()
    mono_worker.submit(test_inner, 3)


# Generated at 2022-06-22 05:15:04.125815
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    MonoWorker()



# Generated at 2022-06-22 05:15:13.898084
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    mw = MonoWorker()
    assert len(mw.futures) == 0  # no tasks
    fut1 = mw.submit(time.sleep, 1)
    assert len(mw.futures) == 1  # 1 task
    fut2 = mw.submit(time.sleep, 1)
    assert len(mw.futures) == 2  # 2 tasks
    assert mw.futures.popleft() is fut1  # task1
    assert mw.futures.popleft() is fut2  # task2


if __name__ == "__main__":
    test_MonoWorker()

# Generated at 2022-06-22 05:15:17.170080
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time
    # Check if the constructor is working properly
    mono_worker = MonoWorker()
    assert mono_worker.pool.__class__.__name__ == "ThreadPoolExecutor"
    assert not mono_worker.futures


# Generated at 2022-06-22 05:15:18.301022
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from .tests import test_MonoWorker
    test_MonoWorker()

# Generated at 2022-06-22 05:15:24.227046
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    Tests the MonoWorker class given a couple of functions that
    takes in a number and returns the time it takes to complete.
    """
    import time
    import random
    test_worker = MonoWorker()
    def test_func(x):
        delay = random.randrange(0, 20)
        time.sleep(delay)
        return delay

    future_0 = test_worker.submit(test_func, 1)
    future_0.result()

    future_1 = test_worker.submit(test_func, 1)
    future_1.result()

    future_2 = test_worker.submit(test_func, 1)
    future_2.result()

    future_3 = test_worker.submit(test_func, 1)
    future_3.result()

    future_4 = test_worker

# Generated at 2022-06-22 05:15:33.308228
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    import time

    def slow(i):
        time.sleep(0.1)
        return i

    mono = MonoWorker()
    mono.submit(slow, 8)  # slow(8) runs
    mono.submit(slow, 6)  # slow(6) replaces slow(8) as waiting
    mono.submit(slow, 4)  # slow(4) replaces slow(6) as waiting
    # slow(8) is still running
    assert not mono.futures[0].done()  # slow(8) still running
    # slow(4) is now the one waiting to run
    assert mono.futures[0].result() == 8  # slow(8) ran
    assert mono.futures[1].result() == 4  # slow(4) ran instead of slow(6)


# Generated at 2022-06-22 05:15:36.986697
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from random import random

    def task(i, wait=2):
        sleep(wait + random() * 2)
        return i * 2

    worker = MonoWorker()
    for i in tqdm_auto.trange(5):
        future = worker.submit(task, i, wait=0.5)
        assert future.result() == i * 2

# Generated at 2022-06-22 05:16:21.612172
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    def func_a():
        return 1
    def func_b():
        raise Exception("test")
    mw = MonoWorker()
    assert mw.submit(func_a).result() == 1
    assert mw.submit(func_a).done()  # no re-submit
    assert mw.submit(func_b).cancelled()

# Generated at 2022-06-22 05:16:22.576736
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mono = MonoWorker()

# Generated at 2022-06-22 05:16:31.572306
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from threading import Event
    from time import sleep
    import sys
    import traceback
    from .._tqdm import tqdm
    from ..utils import _term_move_up
    import unittest

    class DummyException(Exception):

        """Dummy exception"""

    class MonoWorkerTest(unittest.TestCase):

        """Test for MonoWorker"""

        def setUp(self):
            """setUp"""
            self.MW = MonoWorker()
            self.done = Event()
            self.err = None
            self.tqdm_lock = Event()
            self.tqdm_lock.set()
            self.tqdm_lock.clear()

        def tearDown(self):
            """tearDown"""
            if self.err:
                raise self.err


# Generated at 2022-06-22 05:16:36.877257
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    from time import sleep
    def function():
        sleep(1)
    w = MonoWorker()
    running = w.submit(function)
    w.submit(function)
    assert running.cancel()
    assert not running.done()
    running.result()

# Generated at 2022-06-22 05:16:39.117750
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    mw = MonoWorker()
    assert mw.pool._max_workers == 1
    assert mw.futures.maxlen == 2
    assert len(mw.futures) == 0


# Generated at 2022-06-22 05:16:50.506383
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    """
    >>> test_MonoWorker()
    >>> import sys
    >>> sys.stdout.seek(0)
    0
    >>> ' '.join(sys.stdout.read().split())
    '1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 10'
    """
    import atexit

    def f(x):
        import sys
        sys.stdout.write(str(x))
        return x

    def g(x):
        import sys
        sys.stdout.write(str(x))
        return x

    def h(x):
        import sys
        sys.stdout.write(str(x))
        return x

    def i(x):
        import sys
        sys.stdout.write(str(x))
        return x


# Generated at 2022-06-22 05:16:59.451084
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """
    Expected outcome:
    ```
    start
    No arguments for current task!
    No arguments for current task!
    Waiting for job to complete...
    Job completed: ['job 1']
    Waiting for job to complete...
    Job completed: ['job 2']
    Waiting for job to complete...
    Job completed: ['job 3']
    Waiting for job to complete...
    Job completed: ['job 4']
    Waiting for job to complete...
    Job completed: ['job 5']
    Waiting for job to complete...
    Job completed: ['job 6']
    end
    ```
    """

    def test1_start_job(i):
        # return print("Starting job " + str(i))
        import time
        time.sleep(2)
        return 'job ' + str(i)

    # submit one job on

# Generated at 2022-06-22 05:17:10.650900
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    from time import sleep
    from ..utils import format_size, format_interval

    def worker(sleeptime):
        sleep(sleeptime)
        return (sleeptime, 0)

    def test(sleeptimes, num_workers=1, desc=None):
        mw = MonoWorker()
        # sleep(num_workers+0.5)
        t = tqdm_auto(total=sum(sleeptimes), unit='files',
                      unit_scale=True, unit_divisor=1024,
                      miniters=1, bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} '
                      '[{elapsed}<{remaining}, {rate_noinv_fmt}{postfix}]')

# Generated at 2022-06-22 05:17:19.177269
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    import random
    import threading
    lock = threading.Lock()

    def random_task():
        with lock:
            time.sleep(random.random())

    worker = MonoWorker()

    def test_submit(name):
        with lock:
            print(name)
            worker.submit(random_task)

    t1 = threading.Thread(target=lambda: test_submit('t1'), name='t1')
    t2 = threading.Thread(target=lambda: test_submit('t2'), name='t2')
    t3 = threading.Thread(target=lambda: test_submit('t3'), name='t3')
    t1.daemon, t2.daemon, t3.daemon = True, True, True

    # Add delay to avoid flaky test

# Generated at 2022-06-22 05:17:27.783702
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time

    class ImmediateWorker(MonoWorker):
        def submit(self, func, *args, **kwargs):
            if len(self.futures) == self.futures.maxlen:
                # Clear running and waiting futures
                self.futures.popleft().cancel()
                self.futures.popleft().cancel()
            return super(ImmediateWorker, self).submit(func, *args, **kwargs)

    def sleeping_func(sleep=0.1):
        time.sleep(sleep)

    mw = ImmediateWorker()
    assert mw.submit(sleeping_func, 0), "smoke test"

    mw.submit(sleeping_func, 1)
    mw.submit(sleeping_func, 0.2)
    assert m

# Generated at 2022-06-22 05:19:01.123166
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    """Usage: python -m tqdm.contrib.mono_worker test_MonoWorker_submit"""
    import time
    from datetime import datetime

    def log_time(sec=1, func=None, *args, **kwargs):
        """Returns current time"""
        time.sleep(sec)
        return datetime.now()

    print()
    print("Submit ~4 times, one every second:")
    mw = MonoWorker()
    for _ in tqdm_auto.tqdm(range(4), ncols=80, desc='submit'):
        time.sleep(1)
        future = mw.submit(log_time, 3)
    tqdm_auto.write("Got result: %s" % future.result())

    print()

# Generated at 2022-06-22 05:19:05.577361
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import random
    from time import sleep
    from concurrent.futures import as_completed

    def slow(sec):
        sleep(sec)
        return sec

    m = MonoWorker()
    f = [m.submit(slow, random.random()) for _ in range(10)]
    for g in as_completed(f):
        assert g.result() != 0

# Generated at 2022-06-22 05:19:07.215149
# Unit test for constructor of class MonoWorker
def test_MonoWorker():
    _runner = MonoWorker()

# Generated at 2022-06-22 05:19:18.826798
# Unit test for method submit of class MonoWorker
def test_MonoWorker_submit():
    import time
    from threading import Barrier

    barrier = Barrier(2)
    barrier_calls = [1, 1]
    barrier_lock = {}

    def wait_barrier(index):
        # Do not run this test if no lock is available
        # (eg, this test is run in PyPy which does not support `with` locking)
        if hasattr(barrier_lock, "__enter__"):
            with barrier_lock:
                barrier_calls[index] += 1
        barrier.wait()
        return index

    worker = MonoWorker()
    assert not worker.futures  # should be empty

    # Test first
    future0 = worker.submit(wait_barrier, 0)
    assert len(worker.futures) == 1
    assert future0.result() == 0

    # Test second
